import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { seatingTables, seatingAssignments, guests, weddings } from "../../drizzle/schema";

export const seatingRouter = router({
  // Récupérer toutes les tables + invités assignés
  getFullPlan: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");
    const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
    const wedding = weddingRows[0];
    if (!wedding) return { tables: [], guests: [], assignments: [] };

    const tables = await db.select().from(seatingTables).where(eq(seatingTables.weddingId, wedding.id));
    const guestList = await db.select().from(guests).where(eq(guests.weddingId, wedding.id));
    const assignments = await db.select().from(seatingAssignments).where(eq(seatingAssignments.weddingId, wedding.id));

    return { tables, guests: guestList, assignments, weddingId: wedding.id };
  }),

  // Créer une table
  addTable: protectedProcedure
    .input(z.object({
      name: z.string().min(1),
      shape: z.enum(["round", "rectangular", "square"]).default("round"),
      capacity: z.number().min(1).max(50).default(8),
      positionX: z.number().default(0),
      positionY: z.number().default(0),
      colorHex: z.string().default("#F07167"),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      await db.insert(seatingTables).values({
        weddingId: wedding.id,
        name: input.name,
        shape: input.shape,
        capacity: input.capacity,
        positionX: input.positionX,
        positionY: input.positionY,
        colorHex: input.colorHex,
        notes: input.notes ?? null,
      });
      return { success: true };
    }),

  // Mettre à jour la position d'une table (drag & drop)
  updatePosition: protectedProcedure
    .input(z.object({
      tableId: z.number(),
      positionX: z.number(),
      positionY: z.number(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      await db.update(seatingTables)
        .set({ positionX: input.positionX, positionY: input.positionY })
        .where(and(eq(seatingTables.id, input.tableId), eq(seatingTables.weddingId, wedding.id)));
      return { success: true };
    }),

  // Mettre à jour une table (nom, capacité, couleur)
  updateTable: protectedProcedure
    .input(z.object({
      tableId: z.number(),
      name: z.string().min(1).optional(),
      capacity: z.number().min(1).max(50).optional(),
      colorHex: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      const updateData: Partial<typeof seatingTables.$inferInsert> = {};
      if (input.name !== undefined) updateData.name = input.name;
      if (input.capacity !== undefined) updateData.capacity = input.capacity;
      if (input.colorHex !== undefined) updateData.colorHex = input.colorHex;
      if (input.notes !== undefined) updateData.notes = input.notes;

      await db.update(seatingTables)
        .set(updateData)
        .where(and(eq(seatingTables.id, input.tableId), eq(seatingTables.weddingId, wedding.id)));
      return { success: true };
    }),

  // Supprimer une table
  deleteTable: protectedProcedure
    .input(z.object({ tableId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      // Supprimer les assignations de cette table d'abord
      await db.delete(seatingAssignments).where(eq(seatingAssignments.tableId, input.tableId));
      await db.delete(seatingTables)
        .where(and(eq(seatingTables.id, input.tableId), eq(seatingTables.weddingId, wedding.id)));
      return { success: true };
    }),

  // Assigner un invité à une table
  assignGuest: protectedProcedure
    .input(z.object({
      guestId: z.number(),
      tableId: z.number(),
      seatNumber: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      // Supprimer l'assignation précédente de cet invité
      await db.delete(seatingAssignments)
        .where(and(eq(seatingAssignments.guestId, input.guestId), eq(seatingAssignments.weddingId, wedding.id)));

      // Créer la nouvelle assignation
      await db.insert(seatingAssignments).values({
        weddingId: wedding.id,
        tableId: input.tableId,
        guestId: input.guestId,
        seatNumber: input.seatNumber ?? null,
      });
      return { success: true };
    }),

  // Retirer un invité d'une table
  unassignGuest: protectedProcedure
    .input(z.object({ guestId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      await db.delete(seatingAssignments)
        .where(and(eq(seatingAssignments.guestId, input.guestId), eq(seatingAssignments.weddingId, wedding.id)));
      return { success: true };
    }),

  // Générer un plan de table automatique par l'IA (groupes familiaux)
  autoAssign: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");
    const weddingRows = await db.select().from(weddings).where(eq(weddings.userId, ctx.user.id)).limit(1);
    const wedding = weddingRows[0];
    if (!wedding) throw new Error("Wedding not found");

    const tables = await db.select().from(seatingTables).where(eq(seatingTables.weddingId, wedding.id));
    const guestList = await db.select().from(guests).where(eq(guests.weddingId, wedding.id));

    if (tables.length === 0 || guestList.length === 0) {
      return { assigned: 0, message: "Créez d'abord des tables et ajoutez des invités." };
    }

    // Supprimer toutes les assignations existantes
    await db.delete(seatingAssignments).where(eq(seatingAssignments.weddingId, wedding.id));

    // Grouper les invités par groupe (famille, amis, etc.)
    const groups: Record<string, typeof guestList> = {};
    for (const g of guestList) {
      const key = g.group || "Autres";
      if (!groups[key]) groups[key] = [];
      groups[key].push(g);
    }

    let tableIndex = 0;
    let seatInTable = 0;
    let assigned = 0;

    for (const groupGuests of Object.values(groups)) {
      for (const guest of groupGuests) {
        if (tableIndex >= tables.length) break;
        const table = tables[tableIndex];
        if (!table) break;

        await db.insert(seatingAssignments).values({
          weddingId: wedding.id,
          tableId: table.id,
          guestId: guest.id,
          seatNumber: seatInTable + 1,
        });
        assigned++;
        seatInTable++;

        if (seatInTable >= (table.capacity || 8)) {
          tableIndex++;
          seatInTable = 0;
        }
      }
    }

    return { assigned, message: `${assigned} invité(s) placé(s) automatiquement.` };
  }),
});
