import { Express, Request, Response } from "express";
import Stripe from "stripe";
import { getDb } from "./db";
import { subscriptions } from "../drizzle/schema";
import { eq } from "drizzle-orm";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2025-04-30" as any });

export function registerStripeWebhook(app: Express) {
  // ⚠️ DOIT être enregistré AVANT express.json() — utilise express.raw()
  app.post(
    "/api/stripe/webhook",
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (req: any, res: Response, next: any) => {
      // Si le body est déjà parsé (JSON), on le re-sérialise pour la vérification
      if (req.headers["content-type"]?.includes("application/json") && !Buffer.isBuffer(req.body)) {
        const chunks: Buffer[] = [];
        req.on("data", (chunk: Buffer) => chunks.push(chunk));
        req.on("end", () => {
          (req as any).rawBody = Buffer.concat(chunks);
          next();
        });
      } else {
        next();
      }
    },
    async (req: Request, res: Response) => {
      const sig = req.headers["stripe-signature"] as string;
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

      let event: Stripe.Event;

      try {
        const rawBody = (req as any).rawBody || req.body;
        if (!webhookSecret) {
          console.warn("[Webhook] STRIPE_WEBHOOK_SECRET non configuré — vérification ignorée");
          event = JSON.parse(typeof rawBody === "string" ? rawBody : rawBody.toString()) as Stripe.Event;
        } else {
          event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);
        }
      } catch (err: any) {
        console.error("[Webhook] Signature invalide:", err.message);
        return res.status(400).json({ error: `Webhook Error: ${err.message}` });
      }

      // ─── Gestion des événements test ────────────────────────────────────────
      if (event.id.startsWith("evt_test_")) {
        console.log("[Webhook] Test event detected, returning verification response");
        return res.json({ verified: true });
      }

      console.log(`[Webhook] Événement reçu: ${event.type} (${event.id})`);

      const db = await getDb();
      if (!db) return res.status(500).json({ error: "DB unavailable" });

      try {
        switch (event.type) {
          // ─── Checkout complété ─────────────────────────────────────────────
          case "checkout.session.completed": {
            const session = event.data.object as Stripe.Checkout.Session;
            const userId = parseInt(session.metadata?.user_id || session.client_reference_id || "0");
            const plan = session.metadata?.plan as string;

            if (!userId || !plan) {
              console.warn("[Webhook] checkout.session.completed: userId ou plan manquant");
              break;
            }

            // Récupérer l'abonnement Stripe
            let stripeCustomerId = typeof session.customer === "string" ? session.customer : session.customer?.id;
            let stripeSubscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;

            // Upsert dans notre table subscriptions
            const existing = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).limit(1);

            if (existing[0]) {
              await db.update(subscriptions).set({
                plan: plan as any,
                status: "active",
                stripeCustomerId: stripeCustomerId || null,
                stripeSubscriptionId: stripeSubscriptionId || null,
                updatedAt: new Date(),
              }).where(eq(subscriptions.userId, userId));
            } else {
              await db.insert(subscriptions).values({
                userId,
                plan: plan as any,
                status: "active",
                stripeCustomerId: stripeCustomerId || null,
                stripeSubscriptionId: stripeSubscriptionId || null,
              });
            }

            console.log(`[Webhook] Abonnement activé: userId=${userId}, plan=${plan}`);
            break;
          }

          // ─── Abonnement mis à jour ─────────────────────────────────────────
          case "customer.subscription.updated": {
            const sub = event.data.object as Stripe.Subscription;
            const stripeSubscriptionId = sub.id;
            const status = sub.status === "active" ? "active" : sub.status === "canceled" ? "canceled" : "past_due";

            await db.update(subscriptions).set({
              status: status as any,
              updatedAt: new Date(),
            }).where(eq(subscriptions.stripeSubscriptionId, stripeSubscriptionId));

            console.log(`[Webhook] Abonnement mis à jour: ${stripeSubscriptionId} → ${status}`);
            break;
          }

          // ─── Abonnement annulé ─────────────────────────────────────────────
          case "customer.subscription.deleted": {
            const sub = event.data.object as Stripe.Subscription;
            await db.update(subscriptions).set({
              status: "canceled",
              plan: "free",
              updatedAt: new Date(),
            }).where(eq(subscriptions.stripeSubscriptionId, sub.id));

            console.log(`[Webhook] Abonnement annulé: ${sub.id}`);
            break;
          }

          // ─── Paiement échoué ───────────────────────────────────────────────
          case "invoice.payment_failed": {
            const invoice = event.data.object as Stripe.Invoice & { subscription?: string | { id: string } | null };
            const stripeSubscriptionId = typeof invoice.subscription === "string" ? invoice.subscription : (invoice.subscription as any)?.id;
            if (stripeSubscriptionId) {
              await db.update(subscriptions).set({
                status: "past_due",
                updatedAt: new Date(),
              }).where(eq(subscriptions.stripeSubscriptionId, stripeSubscriptionId));
            }
            console.log(`[Webhook] Paiement échoué pour l'abonnement: ${stripeSubscriptionId}`);
            break;
          }

          default:
            console.log(`[Webhook] Événement non géré: ${event.type}`);
        }
      } catch (err) {
        console.error("[Webhook] Erreur de traitement:", err);
        return res.status(500).json({ error: "Erreur interne" });
      }

      return res.json({ received: true });
    }
  );
}
