import { describe, it, expect, vi } from "vitest";

// ─── Mocks ────────────────────────────────────────────────────────────────────
vi.mock("../drizzle/schema", () => ({
  providerNotifications: {},
  providerContracts: {},
  providerSessions: {},
  providerInvitations: {},
  providers: {},
  weddings: {},
  users: {},
}));

vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
  getWeddingByUserId: vi.fn().mockResolvedValue(null),
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

vi.mock("drizzle-orm", () => ({
  eq: vi.fn(),
  and: vi.fn(),
  desc: vi.fn(),
}));

// ─── 1. Rappels email (notifyOwner) ──────────────────────────────────────────
describe("Rappels email automatiques (notifyOwner)", () => {
  it("notifyOwner est importé dans providerSpace", async () => {
    const { notifyOwner } = await import("./_core/notification");
    expect(typeof notifyOwner).toBe("function");
  });

  it("notifyOwner retourne true en cas de succès", async () => {
    const { notifyOwner } = await import("./_core/notification");
    const result = await notifyOwner({
      title: "Test invitation acceptée",
      content: "Un prestataire a accepté votre invitation.",
    });
    expect(result).toBe(true);
  });

  it("génère le bon titre pour une invitation acceptée", () => {
    const provName = "Studio Lumière";
    const title = `🎉 ${provName} a accepté votre invitation`;
    expect(title).toContain(provName);
    expect(title).toContain("accepté");
  });

  it("génère le bon titre pour un contrat signé", () => {
    const signerName = "Jean-Paul Martin";
    const contractTitle = "Contrat Photographe";
    const title = `✍️ Contrat signé par ${signerName}`;
    const content = `Votre prestataire a signé le contrat "${contractTitle}".`;
    expect(title).toContain(signerName);
    expect(content).toContain(contractTitle);
  });

  it("génère le bon titre pour un paiement reçu (acompte)", () => {
    const type = "deposit";
    const label = type === "deposit" ? "Acompte reçu" : "Solde reçu";
    const title = `💳 ${label} — Studio Lumière`;
    expect(title).toContain("Acompte reçu");
    expect(title).toContain("💳");
  });

  it("génère le bon titre pour un paiement reçu (solde)", () => {
    const type = "balance";
    const label = type === "deposit" ? "Acompte reçu" : "Solde reçu";
    const title = `💳 ${label} — Studio Lumière`;
    expect(title).toContain("Solde reçu");
  });
});

// ─── 2. Filtres notifications ─────────────────────────────────────────────────
describe("Filtres centre de notifications", () => {
  const mockNotifications = [
    { id: 1, type: "invitation_accepted", isRead: false, title: "Inv 1", message: "", createdAt: new Date() },
    { id: 2, type: "contract_signed",     isRead: true,  title: "Contrat 1", message: "", createdAt: new Date() },
    { id: 3, type: "payment_received",    isRead: false, title: "Paiement 1", message: "", createdAt: new Date() },
    { id: 4, type: "contract_signed",     isRead: false, title: "Contrat 2", message: "", createdAt: new Date() },
    { id: 5, type: "mission_update",      isRead: true,  title: "Mission 1", message: "", createdAt: new Date() },
  ];

  const filterNotifs = (notifs: typeof mockNotifications, filter: string) => {
    if (filter === "all")    return notifs;
    if (filter === "unread") return notifs.filter(n => !n.isRead);
    return notifs.filter(n => n.type === filter);
  };

  it("filtre 'all' retourne toutes les notifications", () => {
    const result = filterNotifs(mockNotifications, "all");
    expect(result).toHaveLength(5);
  });

  it("filtre 'unread' retourne uniquement les non lues", () => {
    const result = filterNotifs(mockNotifications, "unread");
    expect(result).toHaveLength(3);
    expect(result.every(n => !n.isRead)).toBe(true);
  });

  it("filtre 'contract_signed' retourne uniquement les contrats", () => {
    const result = filterNotifs(mockNotifications, "contract_signed");
    expect(result).toHaveLength(2);
    expect(result.every(n => n.type === "contract_signed")).toBe(true);
  });

  it("filtre 'invitation_accepted' retourne uniquement les invitations", () => {
    const result = filterNotifs(mockNotifications, "invitation_accepted");
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe(1);
  });

  it("filtre 'payment_received' retourne uniquement les paiements", () => {
    const result = filterNotifs(mockNotifications, "payment_received");
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe(3);
  });

  it("filtre 'mission_update' retourne uniquement les missions", () => {
    const result = filterNotifs(mockNotifications, "mission_update");
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe(5);
  });

  it("compte correctement les non lus par type", () => {
    const countUnreadByType = (type: string) =>
      mockNotifications.filter(n => n.type === type && !n.isRead).length;
    expect(countUnreadByType("contract_signed")).toBe(1);
    expect(countUnreadByType("invitation_accepted")).toBe(1);
    expect(countUnreadByType("payment_received")).toBe(1);
    expect(countUnreadByType("mission_update")).toBe(0);
  });

  it("les 6 onglets de filtre sont définis", () => {
    const FILTER_TABS = ["all", "unread", "invitation_accepted", "contract_signed", "payment_received", "mission_update"];
    expect(FILTER_TABS).toHaveLength(6);
    expect(FILTER_TABS).toContain("all");
    expect(FILTER_TABS).toContain("unread");
  });
});

// ─── 3. Tableau de bord analytique ───────────────────────────────────────────
describe("Tableau de bord analytique", () => {
  it("calcule correctement le pourcentage de budget utilisé", () => {
    const spentBudget = 8500;
    const totalBudget = 25000;
    const pct = Math.round((spentBudget / totalBudget) * 100);
    expect(pct).toBe(34);
  });

  it("retourne 0% si le budget total est 0", () => {
    const totalBudget = 0;
    const pct = totalBudget > 0 ? Math.round((5000 / totalBudget) * 100) : 0;
    expect(pct).toBe(0);
  });

  it("calcule correctement les RSVP par statut", () => {
    const guests = [
      { rsvpStatus: "confirmed" },
      { rsvpStatus: "confirmed" },
      { rsvpStatus: "pending" },
      { rsvpStatus: "declined" },
      { rsvpStatus: "pending" },
    ];
    const confirmed = guests.filter(g => g.rsvpStatus === "confirmed").length;
    const pending   = guests.filter(g => g.rsvpStatus === "pending").length;
    const declined  = guests.filter(g => g.rsvpStatus === "declined").length;
    expect(confirmed).toBe(2);
    expect(pending).toBe(2);
    expect(declined).toBe(1);
    expect(confirmed + pending + declined).toBe(guests.length);
  });

  it("calcule correctement les étapes de timeline", () => {
    const timeline = [
      { status: "done" }, { status: "done" }, { status: "pending" }, { status: "pending" },
    ];
    const doneSteps  = timeline.filter(t => t.status === "done").length;
    const totalSteps = timeline.length;
    expect(doneSteps).toBe(2);
    expect(totalSteps).toBe(4);
  });

  it("calcule correctement les prestataires réservés", () => {
    const providers = [
      { status: "booked" }, { status: "booked" }, { status: "pending" }, { status: "contacted" },
    ];
    const booked = providers.filter(p => p.status === "booked").length;
    expect(booked).toBe(2);
    expect(booked / providers.length).toBe(0.5);
  });

  it("les données du BarChart d'avancement sont correctement structurées", () => {
    const doneSteps = 3;
    const totalSteps = 5;
    const bookedProviders = 2;
    const totalProviders = 4;
    const spentBudget = 1000;

    const chartData = [
      { name: "Timeline", done: doneSteps,       total: totalSteps },
      { name: "Presta.",  done: bookedProviders,  total: totalProviders },
      { name: "Budget",   done: spentBudget > 0 ? 1 : 0, total: 1 },
    ];

    expect(chartData).toHaveLength(3);
    expect(chartData[0].done).toBe(3);
    expect(chartData[1].done).toBe(2);
    expect(chartData[2].done).toBe(1); // budget > 0
  });
});
