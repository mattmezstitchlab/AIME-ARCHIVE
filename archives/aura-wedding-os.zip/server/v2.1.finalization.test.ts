/**
 * Tests v2.1 — Finalisation AURA Wedding OS
 *
 * Couvre :
 * - Helper email Resend (mode dev sans clé)
 * - Mutation importCsv invités
 * - Mutation sendCampaign avec vrai envoi email
 * - Handler weddingReminderHandler (auth, lookup, notification)
 * - Pages légales (routes enregistrées dans App.tsx)
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mock Resend ──────────────────────────────────────────────────────────────
vi.mock("resend", () => ({
  Resend: vi.fn().mockImplementation(() => ({
    emails: {
      send: vi.fn().mockResolvedValue({ data: { id: "test-email-id" }, error: null }),
    },
  })),
}));

// ─── Mock DB ──────────────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
  getWeddingByUserId: vi.fn().mockResolvedValue(null),
  getWeddingBySlug: vi.fn().mockResolvedValue(null),
}));

// ─── Mock notifyOwner ─────────────────────────────────────────────────────────
vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

// ─── Mock SDK ─────────────────────────────────────────────────────────────────
vi.mock("./_core/sdk", () => ({
  sdk: {
    authenticateRequest: vi.fn().mockResolvedValue(null),
  },
}));

// ─── Tests email helper ───────────────────────────────────────────────────────
describe("email helper (server/_core/email.ts)", () => {
  it("sendRsvpInvitation returns success:true in dev mode (no RESEND_API_KEY)", async () => {
    delete process.env.RESEND_API_KEY;
    const { sendRsvpInvitation } = await import("./_core/email");
    const result = await sendRsvpInvitation({
      to: "guest@example.com",
      guestName: "Marie Dupont",
      partner1Name: "Alice",
      partner2Name: "Bob",
      weddingDate: "15 juin 2025",
      rsvpUrl: "https://aura-wedding.app/rsvp/abc123",
    });
    expect(result.success).toBe(true);
    expect(result.id).toBe("dev-mode");
  });

  it("sendRsvpConfirmation returns success:true for confirmed status", async () => {
    delete process.env.RESEND_API_KEY;
    const { sendRsvpConfirmation } = await import("./_core/email");
    const result = await sendRsvpConfirmation({
      to: "guest@example.com",
      guestName: "Pierre Martin",
      partner1Name: "Alice",
      partner2Name: "Bob",
      status: "confirmed",
      weddingDate: "15 juin 2025",
    });
    expect(result.success).toBe(true);
  });

  it("sendRsvpConfirmation returns success:true for declined status", async () => {
    delete process.env.RESEND_API_KEY;
    const { sendRsvpConfirmation } = await import("./_core/email");
    const result = await sendRsvpConfirmation({
      to: "guest@example.com",
      guestName: "Sophie Bernard",
      partner1Name: "Alice",
      partner2Name: "Bob",
      status: "declined",
    });
    expect(result.success).toBe(true);
  });

  it("sendWeddingReminder returns success:true with action items", async () => {
    delete process.env.RESEND_API_KEY;
    const { sendWeddingReminder } = await import("./_core/email");
    const result = await sendWeddingReminder({
      to: "couple@example.com",
      partner1Name: "Alice",
      partner2Name: "Bob",
      daysUntil: 7,
      weddingDate: "15 juin 2025",
      venue: "Château de Versailles",
      pendingProviders: 2,
      unconfirmedGuests: 15,
      unsignedContracts: 1,
      cockpitUrl: "https://aura-wedding.app/cockpit",
    });
    expect(result.success).toBe(true);
  });

  it("sendWeddingReminder returns success:true with no action items (J-1)", async () => {
    delete process.env.RESEND_API_KEY;
    const { sendWeddingReminder } = await import("./_core/email");
    const result = await sendWeddingReminder({
      to: "couple@example.com",
      partner1Name: "Alice",
      partner2Name: "Bob",
      daysUntil: 1,
      weddingDate: "15 juin 2025",
      cockpitUrl: "https://aura-wedding.app/cockpit",
    });
    expect(result.success).toBe(true);
  });

  it("sendGuestCampaign returns success:true in dev mode", async () => {
    delete process.env.RESEND_API_KEY;
    const { sendGuestCampaign } = await import("./_core/email");
    const result = await sendGuestCampaign({
      to: "guest@example.com",
      guestName: "Jean Durand",
      subject: "Informations sur notre mariage",
      message: "Bonjour Jean,\n\nNous vous informons que le lieu a changé.",
      partner1Name: "Alice",
      partner2Name: "Bob",
    });
    expect(result.success).toBe(true);
  });
});

// ─── Tests weddingReminderHandler ─────────────────────────────────────────────
describe("weddingReminderHandler", () => {
  it("returns 403 when request is not from a cron", async () => {
    const { sdk } = await import("./_core/sdk");
    (sdk.authenticateRequest as any).mockResolvedValueOnce({ isCron: false });

    const { weddingReminderHandler } = await import("./scheduledReminders");
    const req = { url: "/api/scheduled/wedding-reminder" } as any;
    const res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    } as any;

    await weddingReminderHandler(req, res);
    expect(res.status).toHaveBeenCalledWith(403);
  });

  it("returns 403 when user is null", async () => {
    const { sdk } = await import("./_core/sdk");
    (sdk.authenticateRequest as any).mockResolvedValueOnce(null);

    const { weddingReminderHandler } = await import("./scheduledReminders");
    const req = { url: "/api/scheduled/wedding-reminder" } as any;
    const res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    } as any;

    await weddingReminderHandler(req, res);
    expect(res.status).toHaveBeenCalledWith(403);
  });

  it("returns 500 when DB is unavailable", async () => {
    const { sdk } = await import("./_core/sdk");
    (sdk.authenticateRequest as any).mockResolvedValueOnce({ isCron: true, taskUid: "uid-test-123" });

    const { weddingReminderHandler } = await import("./scheduledReminders");
    const req = { url: "/api/scheduled/wedding-reminder" } as any;
    const res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    } as any;

    await weddingReminderHandler(req, res);
    expect(res.status).toHaveBeenCalledWith(500);
  });
});

// ─── Tests CSV import parsing ─────────────────────────────────────────────────
describe("CSV import parsing logic", () => {
  it("parses a valid CSV line into guest fields", () => {
    const line = "Marie,Dupont,marie.dupont@example.com,0612345678,Famille,bride";
    const [firstName, lastName, email, phone, group, side] = line.split(",");
    expect(firstName).toBe("Marie");
    expect(lastName).toBe("Dupont");
    expect(email).toBe("marie.dupont@example.com");
    expect(phone).toBe("0612345678");
    expect(group).toBe("Famille");
    expect(side).toBe("bride");
  });

  it("handles missing optional fields gracefully", () => {
    const line = "Jean,Martin,,,,";
    const parts = line.split(",");
    const firstName = parts[0] || "";
    const lastName = parts[1] || "";
    const email = parts[2] || undefined;
    expect(firstName).toBe("Jean");
    expect(lastName).toBe("Martin");
    expect(email).toBeUndefined();
  });

  it("validates that firstName is required", () => {
    const line = ",Dupont,email@test.com";
    const [firstName] = line.split(",");
    expect(firstName.trim()).toBe("");
    // Should be filtered out
    expect(firstName.trim().length).toBe(0);
  });

  it("trims whitespace from CSV fields", () => {
    const line = "  Alice  ,  Martin  ,  alice@test.com  ";
    const parts = line.split(",").map(s => s.trim());
    expect(parts[0]).toBe("Alice");
    expect(parts[1]).toBe("Martin");
    expect(parts[2]).toBe("alice@test.com");
  });
});

// ─── Tests pages légales ──────────────────────────────────────────────────────
describe("Legal pages content", () => {
  it("CGU content contains required legal sections", async () => {
    // Vérifier que les fichiers légaux existent
    const fs = await import("fs");
    const path = await import("path");

    const legalFiles = [
      "client/src/pages/legal/CGU.tsx",
      "client/src/pages/legal/CGV.tsx",
      "client/src/pages/legal/MentionsLegales.tsx",
      "client/src/pages/legal/Confidentialite.tsx",
    ];

    for (const file of legalFiles) {
      const fullPath = path.join(process.cwd(), file);
      expect(fs.existsSync(fullPath), `${file} should exist`).toBe(true);
    }
  });

  it("CGU file contains AURA branding", async () => {
    const fs = await import("fs");
    const path = await import("path");
    const cguPath = path.join(process.cwd(), "client/src/pages/legal/CGU.tsx");
    const content = fs.readFileSync(cguPath, "utf-8");
    expect(content).toContain("AURA");
  });

  it("Confidentialite file contains RGPD reference", async () => {
    const fs = await import("fs");
    const path = await import("path");
    const confPath = path.join(process.cwd(), "client/src/pages/legal/Confidentialite.tsx");
    const content = fs.readFileSync(confPath, "utf-8");
    // Should contain RGPD or GDPR reference
    expect(content.toLowerCase()).toMatch(/rgpd|gdpr|règlement général/i);
  });
});

// ─── Tests NotificationsPanel action links ────────────────────────────────────
describe("NotificationsPanel action links config", () => {
  it("each notification type has an actionLabel and actionPanel", () => {
    const TYPE_CONFIG = {
      invitation_accepted: { actionLabel: "Voir les prestataires", actionPanel: "providers" },
      mission_update:      { actionLabel: "Voir les prestataires", actionPanel: "providers" },
      contract_signed:     { actionLabel: "Voir les contrats",     actionPanel: "contracts" },
      payment_received:    { actionLabel: "Voir les prestataires", actionPanel: "providers" },
      message:             { actionLabel: "Ouvrir le chat",        actionPanel: "chat" },
    };

    for (const [type, config] of Object.entries(TYPE_CONFIG)) {
      expect(config.actionLabel, `${type} should have actionLabel`).toBeTruthy();
      expect(config.actionPanel, `${type} should have actionPanel`).toBeTruthy();
    }
  });

  it("actionPanel values are valid Cockpit panel IDs", () => {
    const validPanels = ["providers", "contracts", "chat", "guests", "budget", "timeline", "documents"];
    const usedPanels = ["providers", "contracts", "chat"];

    for (const panel of usedPanels) {
      expect(validPanels).toContain(panel);
    }
  });
});
