/**
 * email.ts — Helper Resend pour AURA Wedding OS
 *
 * Utilise la variable d'environnement RESEND_API_KEY.
 * Si la clé est absente, les envois sont loggés en console (mode dev).
 *
 * Templates disponibles :
 *   - sendRsvpInvitation   : lien RSVP personnalisé pour un invité
 *   - sendRsvpConfirmation : accusé de réception après réponse RSVP
 *   - sendWeddingReminder  : rappel J-30/J-7/J-1 aux mariés
 *   - sendGuestCampaign    : email groupé aux invités (campagne)
 */

import { Resend } from "resend";

const resend = process.env.RESEND_API_KEY
  ? new Resend(process.env.RESEND_API_KEY)
  : null;

const FROM = process.env.RESEND_FROM_EMAIL || "AURA Wedding OS <noreply@aura-wedding.app>";

// ─── Types ────────────────────────────────────────────────────────────────────
export interface EmailResult {
  success: boolean;
  id?: string;
  error?: string;
}

// ─── Helpers internes ─────────────────────────────────────────────────────────
function wrapHtml(content: string, title: string): string {
  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${title}</title>
  <style>
    body { margin: 0; padding: 0; background: #f0f4f8; font-family: 'Helvetica Neue', Arial, sans-serif; }
    .wrapper { max-width: 600px; margin: 40px auto; background: #E8EDF2; border-radius: 20px; overflow: hidden; box-shadow: 8px 8px 16px #c8cdd2, -8px -8px 16px #ffffff; }
    .header { background: linear-gradient(135deg, #F07167 0%, #C4A87B 100%); padding: 32px 40px; text-align: center; }
    .header h1 { margin: 0; color: white; font-size: 28px; font-weight: 700; letter-spacing: -0.5px; }
    .header p { margin: 8px 0 0; color: rgba(255,255,255,0.85); font-size: 14px; }
    .body { padding: 32px 40px; }
    .body p { color: #4a5568; line-height: 1.7; font-size: 15px; margin: 0 0 16px; }
    .cta { display: inline-block; margin: 24px 0; padding: 14px 32px; background: #F07167; color: white !important; text-decoration: none; border-radius: 12px; font-weight: 600; font-size: 15px; }
    .info-box { background: rgba(96,180,200,0.1); border-left: 3px solid #60B4C8; border-radius: 8px; padding: 16px 20px; margin: 20px 0; }
    .info-box p { margin: 0; color: #2d6a7a; font-size: 14px; }
    .footer { padding: 20px 40px; border-top: 1px solid rgba(0,0,0,0.06); text-align: center; }
    .footer p { margin: 0; color: #aab5c8; font-size: 12px; }
    .footer a { color: #F07167; text-decoration: none; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="header">
      <h1>💍 AURA Wedding OS</h1>
      <p>Votre assistant mariage intelligent</p>
    </div>
    <div class="body">
      ${content}
    </div>
    <div class="footer">
      <p>Vous recevez cet email car vous êtes lié(e) à un mariage sur <a href="https://aura-wedding.app">AURA Wedding OS</a>.</p>
      <p style="margin-top:8px;">© ${new Date().getFullYear()} AURA Wedding OS · <a href="https://aura-wedding.app/confidentialite">Confidentialité</a></p>
    </div>
  </div>
</body>
</html>`;
}

async function sendEmail(params: {
  to: string | string[];
  subject: string;
  html: string;
}): Promise<EmailResult> {
  if (!resend) {
    console.log(`[Email DEV] To: ${params.to} | Subject: ${params.subject}`);
    console.log("[Email DEV] RESEND_API_KEY not set — email not sent in dev mode");
    return { success: true, id: "dev-mode" };
  }

  try {
    const { data, error } = await resend.emails.send({
      from: FROM,
      to: Array.isArray(params.to) ? params.to : [params.to],
      subject: params.subject,
      html: params.html,
    });

    if (error) {
      console.error("[Email] Resend error:", error);
      return { success: false, error: error.message };
    }

    console.log(`[Email] Sent successfully: ${data?.id}`);
    return { success: true, id: data?.id };
  } catch (err) {
    console.error("[Email] Unexpected error:", err);
    return { success: false, error: (err as Error).message };
  }
}

// ─── Template 1 : Invitation RSVP ─────────────────────────────────────────────
export async function sendRsvpInvitation(params: {
  to: string;
  guestName: string;
  partner1Name: string;
  partner2Name: string;
  weddingDate: string;
  venue?: string;
  rsvpUrl: string;
}): Promise<EmailResult> {
  const { to, guestName, partner1Name, partner2Name, weddingDate, venue, rsvpUrl } = params;

  const html = wrapHtml(`
    <p>Cher(e) <strong>${guestName}</strong>,</p>
    <p>
      <strong>${partner1Name}</strong> et <strong>${partner2Name}</strong> ont le plaisir de vous inviter à célébrer leur mariage
      ${weddingDate ? `le <strong>${weddingDate}</strong>` : ""}
      ${venue ? ` à <strong>${venue}</strong>` : ""}.
    </p>
    <p>Merci de confirmer votre présence en cliquant sur le bouton ci-dessous :</p>
    <a href="${rsvpUrl}" class="cta">Répondre à l'invitation →</a>
    <div class="info-box">
      <p>Ce lien est personnel et vous est réservé. Vous pourrez indiquer votre régime alimentaire et si vous venez accompagné(e).</p>
    </div>
    <p>Au plaisir de vous retrouver pour ce moment inoubliable !</p>
    <p>Avec toute notre affection,<br/><strong>${partner1Name} & ${partner2Name}</strong></p>
  `, "Invitation à notre mariage");

  return sendEmail({
    to,
    subject: `💍 Invitation au mariage de ${partner1Name} & ${partner2Name}`,
    html,
  });
}

// ─── Template 2 : Confirmation RSVP ──────────────────────────────────────────
export async function sendRsvpConfirmation(params: {
  to: string;
  guestName: string;
  partner1Name: string;
  partner2Name: string;
  status: "confirmed" | "declined" | "maybe";
  weddingDate?: string;
  venue?: string;
}): Promise<EmailResult> {
  const { to, guestName, partner1Name, partner2Name, status, weddingDate, venue } = params;

  const statusMessages = {
    confirmed: {
      emoji: "🎉",
      title: "Votre présence est confirmée !",
      body: `Nous sommes ravis de vous compter parmi nos invités. Nous avons bien enregistré votre réponse et nous vous attendons avec impatience${weddingDate ? ` le ${weddingDate}` : ""}${venue ? ` à ${venue}` : ""}.`,
    },
    declined: {
      emoji: "💌",
      title: "Nous avons bien reçu votre réponse",
      body: `Nous sommes désolés de ne pas pouvoir vous compter parmi nous, mais nous comprenons. Nous vous souhaitons une belle journée ce jour-là et espérons vous retrouver bientôt.`,
    },
    maybe: {
      emoji: "🤔",
      title: "Réponse enregistrée",
      body: `Nous avons bien noté que vous n'êtes pas encore certain(e) de pouvoir être présent(e). N'hésitez pas à mettre à jour votre réponse dès que vous le saurez.`,
    },
  };

  const msg = statusMessages[status];

  const html = wrapHtml(`
    <p>Cher(e) <strong>${guestName}</strong>,</p>
    <p>${msg.emoji} <strong>${msg.title}</strong></p>
    <p>${msg.body}</p>
    <div class="info-box">
      <p>Votre réponse a été transmise à <strong>${partner1Name} & ${partner2Name}</strong>. Vous pouvez modifier votre réponse à tout moment en utilisant le lien de votre invitation.</p>
    </div>
    <p>Merci pour votre réponse rapide !</p>
    <p>Cordialement,<br/>L'équipe AURA Wedding OS pour <strong>${partner1Name} & ${partner2Name}</strong></p>
  `, `Confirmation RSVP — ${partner1Name} & ${partner2Name}`);

  return sendEmail({
    to,
    subject: `${msg.emoji} Confirmation RSVP — ${partner1Name} & ${partner2Name}`,
    html,
  });
}

// ─── Template 3 : Rappel mariés (J-30 / J-7 / J-1) ──────────────────────────
export async function sendWeddingReminder(params: {
  to: string;
  partner1Name: string;
  partner2Name: string;
  daysUntil: number;
  weddingDate: string;
  venue?: string;
  pendingProviders?: number;
  unconfirmedGuests?: number;
  unsignedContracts?: number;
  cockpitUrl: string;
}): Promise<EmailResult> {
  const { to, partner1Name, partner2Name, daysUntil, weddingDate, venue, pendingProviders, unconfirmedGuests, unsignedContracts, cockpitUrl } = params;

  const dayLabel = daysUntil === 1 ? "demain" : `dans ${daysUntil} jours`;
  const urgencyColor = daysUntil === 1 ? "#F07167" : daysUntil === 7 ? "#C4A87B" : "#60B4C8";

  const actionItems = [
    pendingProviders && pendingProviders > 0 ? `<li>⚠️ <strong>${pendingProviders} prestataire(s)</strong> sans confirmation</li>` : null,
    unconfirmedGuests && unconfirmedGuests > 0 ? `<li>👥 <strong>${unconfirmedGuests} invité(s)</strong> sans réponse RSVP</li>` : null,
    unsignedContracts && unsignedContracts > 0 ? `<li>📝 <strong>${unsignedContracts} contrat(s)</strong> non signé(s)</li>` : null,
  ].filter(Boolean);

  const html = wrapHtml(`
    <p>Bonjour <strong>${partner1Name} & ${partner2Name}</strong>,</p>
    <p>
      Votre grand jour approche ! Votre mariage est prévu <strong style="color:${urgencyColor}">${dayLabel}</strong>
      ${weddingDate ? `, le <strong>${weddingDate}</strong>` : ""}
      ${venue ? ` à <strong>${venue}</strong>` : ""}.
    </p>
    ${actionItems.length > 0 ? `
    <div class="info-box">
      <p><strong>Points d'attention :</strong></p>
      <ul style="margin:8px 0 0;padding-left:20px;color:#2d6a7a;">
        ${actionItems.join("\n        ")}
      </ul>
    </div>
    ` : `
    <div class="info-box">
      <p>🎉 Tout semble en ordre ! Profitez de ce moment magique.</p>
    </div>
    `}
    <a href="${cockpitUrl}" class="cta">Ouvrir mon Cockpit AURA →</a>
    <p>Nous vous souhaitons un mariage inoubliable !</p>
    <p>Avec tout notre soutien,<br/>L'équipe AURA Wedding OS</p>
  `, `Rappel J-${daysUntil} — Votre mariage approche !`);

  return sendEmail({
    to,
    subject: `💍 J-${daysUntil} — Votre mariage approche, ${partner1Name} !`,
    html,
  });
}

// ─── Template 4 : Campagne groupée (emails invités) ──────────────────────────
export async function sendGuestCampaign(params: {
  to: string;
  guestName: string;
  subject: string;
  message: string;
  partner1Name: string;
  partner2Name: string;
  rsvpUrl?: string;
}): Promise<EmailResult> {
  const { to, guestName, subject, message, partner1Name, partner2Name, rsvpUrl } = params;

  const html = wrapHtml(`
    <p>Cher(e) <strong>${guestName}</strong>,</p>
    ${message.split("\n").map(p => `<p>${p}</p>`).join("\n    ")}
    ${rsvpUrl ? `<a href="${rsvpUrl}" class="cta">Accéder à mon invitation →</a>` : ""}
    <p>Avec toute notre affection,<br/><strong>${partner1Name} & ${partner2Name}</strong></p>
  `, subject);

  return sendEmail({ to, subject, html });
}
