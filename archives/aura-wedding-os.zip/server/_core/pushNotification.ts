/**
 * AURA Wedding OS — Push Notification Helper
 *
 * Envoie des notifications push navigateur via Web Push API (VAPID).
 * Les abonnements sont stockés en base dans la table push_subscriptions.
 */

import webpush from "web-push";
import { getDb } from "../db";
import { pushSubscriptions } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

// ─── Configuration VAPID ──────────────────────────────────────────────────────
let vapidConfigured = false;

function ensureVapidConfigured() {
  if (vapidConfigured) return;
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  const ownerEmail = process.env.OWNER_EMAIL || "contact@aura-wedding.app";

  if (!publicKey || !privateKey) {
    console.warn("[Push] VAPID keys not configured — push notifications disabled");
    return;
  }

  webpush.setVapidDetails(`mailto:${ownerEmail}`, publicKey, privateKey);
  vapidConfigured = true;
}

// ─── Types ────────────────────────────────────────────────────────────────────
export interface PushPayload {
  title: string;
  body: string;
  icon?: string;
  tag?: string;
  url?: string;
  panel?: string;
  requireInteraction?: boolean;
  actions?: Array<{ action: string; title: string }>;
}

// ─── Envoyer une push à un abonnement spécifique ─────────────────────────────
export async function sendPushToSubscription(
  subscription: { endpoint: string; p256dh: string; auth: string },
  payload: PushPayload
): Promise<{ success: boolean; error?: string }> {
  ensureVapidConfigured();
  if (!vapidConfigured) return { success: false, error: "VAPID not configured" };

  try {
    await webpush.sendNotification(
      {
        endpoint: subscription.endpoint,
        keys: { p256dh: subscription.p256dh, auth: subscription.auth },
      },
      JSON.stringify(payload),
      { TTL: 86400 } // 24h TTL
    );
    return { success: true };
  } catch (err: any) {
    // 410 Gone = abonnement expiré, à supprimer
    if (err.statusCode === 410 || err.statusCode === 404) {
      return { success: false, error: "subscription-expired" };
    }
    console.error("[Push] Send error:", err.message);
    return { success: false, error: err.message };
  }
}

// ─── Envoyer une push à tous les abonnements d'un utilisateur ────────────────
export async function sendPushToUser(
  userId: string,
  payload: PushPayload
): Promise<{ sent: number; failed: number; expired: number }> {
  ensureVapidConfigured();
  if (!vapidConfigured) return { sent: 0, failed: 0, expired: 0 };

  const db = await getDb();
  if (!db) return { sent: 0, failed: 0, expired: 0 };

  const subs = await db
    .select()
    .from(pushSubscriptions)
    .where(eq(pushSubscriptions.userId, userId));

  let sent = 0, failed = 0, expired = 0;
  const expiredIds: number[] = [];

  await Promise.all(
    subs.map(async (sub) => {
      const result = await sendPushToSubscription(
        { endpoint: sub.endpoint, p256dh: sub.p256dh, auth: sub.auth },
        payload
      );
      if (result.success) {
        sent++;
      } else if (result.error === "subscription-expired") {
        expired++;
        expiredIds.push(sub.id);
      } else {
        failed++;
      }
    })
  );

  // Nettoyer les abonnements expirés
  if (expiredIds.length > 0) {
    await Promise.all(
      expiredIds.map((id) =>
        db.delete(pushSubscriptions).where(eq(pushSubscriptions.id, id))
      )
    );
    console.log(`[Push] Cleaned ${expiredIds.length} expired subscriptions for user ${userId}`);
  }

  return { sent, failed, expired };
}

// ─── Payloads prédéfinis ──────────────────────────────────────────────────────
export const PushTemplates = {
  weddingReminder: (daysUntil: number, partner1: string, partner2: string, weddingDate: string): PushPayload => ({
    title: `${daysUntil === 1 ? "💍" : daysUntil <= 7 ? "⏰" : "📅"} J-${daysUntil} — Votre mariage approche !`,
    body: `Le mariage de ${partner1} & ${partner2} est dans ${daysUntil} jour${daysUntil > 1 ? "s" : ""} (${weddingDate}). Cliquez pour vérifier votre Cockpit.`,
    tag: `wedding-reminder-j${daysUntil}`,
    url: "/cockpit",
    panel: "dashboard",
    requireInteraction: daysUntil <= 7,
  }),

  invitationAccepted: (providerName: string, category: string): PushPayload => ({
    title: "✅ Prestataire confirmé !",
    body: `${providerName} (${category}) a accepté votre invitation et rejoint votre espace AURA.`,
    tag: "provider-invitation-accepted",
    url: "/cockpit",
    panel: "providers",
  }),

  contractSigned: (providerName: string): PushPayload => ({
    title: "✍️ Contrat signé !",
    body: `${providerName} a signé le contrat. Vous pouvez le télécharger depuis le panneau Contrats.`,
    tag: "contract-signed",
    url: "/cockpit",
    panel: "contracts",
  }),

  paymentReceived: (providerName: string, amount: string): PushPayload => ({
    title: "💳 Paiement enregistré",
    body: `${providerName} a enregistré un paiement de ${amount}. Vérifiez votre suivi budget.`,
    tag: "payment-received",
    url: "/cockpit",
    panel: "providers",
  }),

  rsvpConfirmed: (guestName: string, status: "confirmed" | "declined"): PushPayload => ({
    title: status === "confirmed" ? "🎉 RSVP confirmé !" : "❌ RSVP décliné",
    body: status === "confirmed"
      ? `${guestName} a confirmé sa présence à votre mariage !`
      : `${guestName} ne pourra malheureusement pas être présent(e).`,
    tag: "rsvp-response",
    url: "/cockpit",
    panel: "guests",
  }),

  rsvpReceived: (guestName: string, status: string): PushPayload => ({
    title: status === "confirmed" ? "🎉 RSVP reçu !" : status === "declined" ? "❌ RSVP décliné" : "🤔 RSVP incertain",
    body: status === "confirmed"
      ? `${guestName} a confirmé sa présence à votre mariage !`
      : status === "declined"
      ? `${guestName} ne pourra malheureusement pas être présent(e).`
      : `${guestName} a répondu "peut-être" à votre invitation.`,
    tag: "rsvp-response",
    url: "/cockpit",
    panel: "guests",
  }),

  subscriptionActivated: (planName: string): PushPayload => ({
    title: "🌟 Abonnement activé !",
    body: `Votre abonnement AURA ${planName} est maintenant actif. Profitez de toutes les fonctionnalités premium !`,
    tag: "subscription-activated",
    url: "/cockpit",
    panel: "dashboard",
  }),
};
