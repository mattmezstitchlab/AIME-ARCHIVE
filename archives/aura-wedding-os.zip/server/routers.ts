import { z } from "zod";
import { nanoid } from "nanoid";
import { COOKIE_NAME } from "@shared/const";
import { providerSpaceRouter } from "./routers/providerSpace";
import { aiPlannerRouter } from "./routers/aiPlanner";
import { seatingRouter } from "./routers/seating";
import { subscriptionsRouter } from "./routers/subscriptions";
import { providerNotificationsRouter } from "./routers/providerNotifications";
import { remindersRouter } from "./routers/reminders";
import { pushRouter } from "./routers/push";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import * as db from "./db";
import { sendRsvpConfirmation } from "./_core/email";
import { sendPushToUser, PushTemplates } from "./_core/pushNotification";

// ─── Wedding Router ───────────────────────────────────────────────────────────
const weddingRouter = router({
  get: protectedProcedure.query(async ({ ctx }) => {
    return db.getWeddingByUserId(ctx.user.id);
  }),
  update: protectedProcedure
    .input(z.object({
      partner1Name: z.string().optional(),
      partner2Name: z.string().optional(),
      weddingDate: z.string().optional(),
      venue: z.string().optional(),
      city: z.string().optional(),
      guestCount: z.number().optional(),
      totalBudget: z.string().optional(),
      style: z.string().optional(),
      colorPalette: z.string().optional(),
      notes: z.string().optional(),
      miniSiteSlug: z.string().optional(),
      miniSiteEnabled: z.boolean().optional(),
      miniSiteContent: z.string().optional(),
      miniSiteWelcomeMsg: z.string().optional(),
      miniSiteThemeColor: z.string().optional(),
      miniSiteDressCode: z.string().optional(),
      miniSiteTransportInfo: z.string().optional(),
      miniSiteAccommodation: z.string().optional(),
      miniSiteShowTimeline: z.boolean().optional(),
      miniSiteShowPhotos: z.boolean().optional(),
      miniSiteShowRsvp: z.boolean().optional(),
      miniSiteShowMap: z.boolean().optional(),
      miniSiteShowPractical: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const data: Record<string, unknown> = { ...input };
      if (input.weddingDate) data.weddingDate = new Date(input.weddingDate);
      return db.upsertWedding(ctx.user.id, data as any);
    }),
  getBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const wedding = await db.getWeddingBySlug(input.slug);
      if (!wedding || !wedding.miniSiteEnabled) return null;
      return wedding;
    }),
  getPublicTimeline: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const wedding = await db.getWeddingBySlug(input.slug);
      if (!wedding || !wedding.miniSiteEnabled) return [];
      const events = await db.getTimelineEvents(wedding.id);
      return events.filter(e => e.status === 'confirmed' || e.status === 'done');
    }),
  getPublicPhotos: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const wedding = await db.getWeddingBySlug(input.slug);
      if (!wedding || !wedding.miniSiteEnabled) return [];
      const photos = await db.getPhotoWallPhotos(wedding.id, true);
      return photos;
    }),
  submitRsvpBySlug: publicProcedure
    .input(z.object({
      slug: z.string(),
      firstName: z.string(),
      lastName: z.string(),
      email: z.string().optional(),
      rsvpStatus: z.enum(['confirmed', 'declined', 'maybe']),
      plusOneConfirmed: z.boolean().optional(),
      dietaryRestrictions: z.string().optional(),
      message: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const wedding = await db.getWeddingBySlug(input.slug);
      if (!wedding) throw new Error('Mariage introuvable');
      const { slug, ...rsvpData } = input;
      const result = await db.submitPublicRsvp(wedding.id, rsvpData);

      // Envoyer un email de confirmation à l'invité si email fourni
      if (input.email && input.rsvpStatus !== 'maybe') {
        const weddingDateStr = wedding.weddingDate
          ? new Date(wedding.weddingDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
          : undefined;
        sendRsvpConfirmation({
          to: input.email,
          guestName: `${input.firstName} ${input.lastName}`.trim(),
          partner1Name: wedding.partner1Name || 'Les mariés',
          partner2Name: wedding.partner2Name || '',
          status: input.rsvpStatus as 'confirmed' | 'declined' | 'maybe',
          weddingDate: weddingDateStr,
          venue: wedding.venue ?? undefined,
        }).catch(err => console.error('[RSVP email] Failed:', err));
      }

      // Notification push navigateur aux mariés
      sendPushToUser(
        String(wedding.userId),
        PushTemplates.rsvpReceived(
          `${input.firstName} ${input.lastName}`.trim(),
          input.rsvpStatus
        )
      ).catch(() => {});
      return result;
    }),
});

// ─── Timeline Router ──────────────────────────────────────────────────────────
const timelineRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getTimelineEvents(wedding.id);
  }),
  add: protectedProcedure
    .input(z.object({
      title: z.string(),
      description: z.string().optional(),
      category: z.enum(["ceremony","reception","preparation","photo","transport","dinner","entertainment","administrative","other"]).default("other"),
      scheduledAt: z.string().optional(),
      durationMinutes: z.number().default(60),
      status: z.enum(["pending","confirmed","done","cancelled"]).default("pending"),
      location: z.string().optional(),
      notes: z.string().optional(),
      sortOrder: z.number().default(0),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const data: any = { ...input, weddingId: wedding.id };
      if (input.scheduledAt) data.scheduledAt = new Date(input.scheduledAt);
      return db.addTimelineEvent(data);
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      title: z.string().optional(),
      description: z.string().optional(),
      category: z.enum(["ceremony","reception","preparation","photo","transport","dinner","entertainment","administrative","other"]).optional(),
      scheduledAt: z.string().optional(),
      durationMinutes: z.number().optional(),
      status: z.enum(["pending","confirmed","done","cancelled"]).optional(),
      location: z.string().optional(),
      notes: z.string().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const updateData: any = { ...data };
      if (data.scheduledAt) updateData.scheduledAt = new Date(data.scheduledAt);
      await db.updateTimelineEvent(id, updateData);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteTimelineEvent(input.id);
      return { success: true };
    }),
});

// ─── Budget Router ────────────────────────────────────────────────────────────
const budgetRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getBudgetItems(wedding.id);
  }),
  add: protectedProcedure
    .input(z.object({
      category: z.enum(["venue","catering","photography","videography","music","flowers","dress","suit","rings","transport","accommodation","invitations","decoration","beauty","honeymoon","other"]).default("other"),
      label: z.string(),
      estimatedAmount: z.string().default("0"),
      actualAmount: z.string().optional(),
      paid: z.boolean().default(false),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      return db.addBudgetItem({ ...input, weddingId: wedding.id } as any);
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      label: z.string().optional(),
      estimatedAmount: z.string().optional(),
      actualAmount: z.string().optional(),
      paid: z.boolean().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateBudgetItem(id, data as any);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteBudgetItem(input.id);
      return { success: true };
    }),
  aiEstimate: protectedProcedure
    .input(z.object({ guestCount: z.number(), city: z.string().optional(), style: z.string().optional() }))
    .mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Tu es un expert en organisation de mariage en France. Génère une estimation de budget détaillée par catégorie en JSON." },
          { role: "user", content: `Mariage pour ${input.guestCount} personnes${input.city ? ` à ${input.city}` : ""}${input.style ? `, style: ${input.style}` : ""}. Donne une estimation réaliste par catégorie (venue, catering, photography, videography, music, flowers, dress, suit, rings, transport, decoration, invitations, beauty, honeymoon) en euros. Format JSON: {"items": [{"category": "...", "label": "...", "estimatedAmount": 0}]}` },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "budget_estimate",
            strict: true,
            schema: {
              type: "object",
              properties: {
                items: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      category: { type: "string" },
                      label: { type: "string" },
                      estimatedAmount: { type: "number" },
                    },
                    required: ["category", "label", "estimatedAmount"],
                    additionalProperties: false,
                  }
                }
              },
              required: ["items"],
              additionalProperties: false,
            }
          }
        }
      });
      const content = response.choices[0]?.message?.content as string | undefined;
      if (!content) return { items: [] };
      try { return JSON.parse(content); } catch { return { items: [] }; }
    }),
});

// ─── Providers Router ─────────────────────────────────────────────────────────
const providersRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getProviders(wedding.id);
  }),
  add: protectedProcedure
    .input(z.object({
      name: z.string(),
      category: z.enum(["photographer","videographer","caterer","florist","music","venue","transport","beauty","dress","suit","cake","animation","officiant","other"]).default("other"),
      email: z.string().optional(),
      phone: z.string().optional(),
      website: z.string().optional(),
      city: z.string().optional(),
      priceRange: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      return db.addProvider({ ...input, weddingId: wedding.id } as any);
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      category: z.enum(["photographer","videographer","caterer","florist","music","venue","transport","beauty","dress","suit","cake","animation","officiant","other"]).optional(),
      email: z.string().optional(),
      phone: z.string().optional(),
      website: z.string().optional(),
      city: z.string().optional(),
      priceRange: z.string().optional(),
      status: z.enum(["shortlisted","contacted","quote_received","booked","cancelled"]).optional(),
      rating: z.number().optional(),
      notes: z.string().optional(),
      quoteAmount: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateProvider(id, data as any);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteProvider(input.id);
      return { success: true };
    }),
  generateInviteLink: protectedProcedure
    .input(z.object({ providerId: z.number(), email: z.string().optional(), origin: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const token = nanoid(32);
      await db.addProviderInvitation({ weddingId: wedding.id, providerId: input.providerId, token, email: input.email });
      return { token, url: `${input.origin}/prestataire/${token}` };
    }),
  // Missions pour le dashboard analytique
  listMissions: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    const { providerMissions } = await import("../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    const dbConn = await db.getDb();
    if (!dbConn) return [];
    return dbConn.select().from(providerMissions)
      .where(eq(providerMissions.weddingId, wedding.id));
  }),
});

// ─── Guests Router ────────────────────────────────────────────────────────────
const guestsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getGuests(wedding.id);
  }),
  add: protectedProcedure
    .input(z.object({
      firstName: z.string(),
      lastName: z.string().optional(),
      email: z.string().optional(),
      phone: z.string().optional(),
      group: z.string().optional(),
      side: z.enum(["partner1","partner2","both"]).default("both"),
      plusOne: z.boolean().default(false),
      dietaryRestrictions: z.string().optional(),
      tableNumber: z.number().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const rsvpToken = nanoid(24);
      return db.addGuest({ ...input, weddingId: wedding.id, rsvpToken } as any);
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      firstName: z.string().optional(),
      lastName: z.string().optional(),
      email: z.string().optional(),
      phone: z.string().optional(),
      group: z.string().optional(),
      side: z.enum(["partner1","partner2","both"]).optional(),
      rsvpStatus: z.enum(["pending","confirmed","declined","maybe"]).optional(),
      plusOne: z.boolean().optional(),
      plusOneName: z.string().optional(),
      dietaryRestrictions: z.string().optional(),
      tableNumber: z.number().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateGuest(id, data as any);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteGuest(input.id);
      return { success: true };
    }),
  getRsvpLink: protectedProcedure
    .input(z.object({ guestId: z.number(), origin: z.string() }))
    .query(async ({ input }) => {
      const guestList = await db.getGuests(0);
      // We need to get the specific guest - let's just return the URL pattern
      return { url: `${input.origin}/rsvp/TOKEN` };
    }),
  // Import CSV en lot
  importCsv: protectedProcedure
    .input(z.object({
      guests: z.array(z.object({
        firstName: z.string(),
        lastName: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        group: z.string().optional(),
        side: z.enum(["partner1","partner2","both"]).default("both"),
        plusOne: z.boolean().default(false),
        dietaryRestrictions: z.string().optional(),
        tableNumber: z.number().optional(),
      }))
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      let imported = 0;
      const errors: string[] = [];
      for (const g of input.guests) {
        try {
          const rsvpToken = nanoid(24);
          await db.addGuest({ ...g, weddingId: wedding.id, rsvpToken } as any);
          imported++;
        } catch (e) {
          errors.push(`${g.firstName} ${g.lastName ?? ""}: ${(e as Error).message}`);
        }
      }
      return { imported, errors };
    }),

  // Portail invité connecté : récupère les infos du mariage associé à l'invité via son email
  getMyRsvp: protectedProcedure.query(async ({ ctx }) => {
    const dbConn = await db.getDb();
    if (!dbConn || !ctx.user.email) return null;
    const { guests: guestsTable, weddings: weddingsTable, timelineEvents } = await import("../drizzle/schema");
    const { eq, and } = await import("drizzle-orm");
    // Trouver l'invité par email
    const guestRows = await dbConn.select().from(guestsTable)
      .where(eq(guestsTable.email, ctx.user.email)).limit(1);
    if (!guestRows.length) return null;
    const guest = guestRows[0];
    // Récupérer le mariage
    const weddingRows = await dbConn.select().from(weddingsTable)
      .where(eq(weddingsTable.id, guest.weddingId)).limit(1);
    if (!weddingRows.length) return null;
    const wedding = weddingRows[0];
    // Récupérer la timeline publique (status = done ou in_progress)
    const timeline = await dbConn.select().from(timelineEvents)
      .where(and(eq(timelineEvents.weddingId, wedding.id)));
    return {
      wedding,
      timeline: timeline.sort((a, b) => {
        if (!a.scheduledAt && !b.scheduledAt) return 0;
        if (!a.scheduledAt) return 1;
        if (!b.scheduledAt) return -1;
        return new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime();
      }),
      rsvpStatus: guest.rsvpStatus,
      guestName: `${guest.firstName} ${guest.lastName || ""}`.trim(),
    };
  }),
});

// ─── RSVP Router (public) ─────────────────────────────────────────────────────
const rsvpRouter = router({
  getByToken: publicProcedure
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      const guest = await db.getGuestByRsvpToken(input.token);
      if (!guest) return null;
      const db2 = await db.getDb();
      let weddingData = null;
      if (db2) {
        const { weddings: weddingsTable } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const [wd] = await db2.select().from(weddingsTable).where(eq(weddingsTable.id, guest.weddingId)).limit(1);
        weddingData = wd ?? null;
      }
      return { guest, wedding: weddingData };
    }),
  respond: publicProcedure
    .input(z.object({
      token: z.string(),
      rsvpStatus: z.enum(["confirmed","declined","maybe"]),
      plusOneName: z.string().optional(),
      dietaryRestrictions: z.string().optional(),
      message: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const guest = await db.getGuestByRsvpToken(input.token);
      if (!guest) throw new Error("Invalid RSVP token");
      await db.updateGuest(guest.id, {
        rsvpStatus: input.rsvpStatus,
        plusOneName: input.plusOneName,
        dietaryRestrictions: input.dietaryRestrictions,
        rsvpRespondedAt: new Date(),
      });
      return { success: true };
    }),
});

// ─── Documents Router ─────────────────────────────────────────────────────────
const documentsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getDocuments(wedding.id);
  }),
  upload: protectedProcedure
    .input(z.object({
      name: z.string(),
      type: z.enum(["contract","quote","invoice","photo","other"]).default("other"),
      fileData: z.string(),
      mimeType: z.string(),
      providerId: z.number().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const buffer = Buffer.from(input.fileData, "base64");
      const fileKey = `weddings/${wedding.id}/documents/${nanoid()}-${input.name}`;
      const { key, url } = await storagePut(fileKey, buffer, input.mimeType);
      return db.addDocument({
        weddingId: wedding.id,
        name: input.name,
        type: input.type,
        fileKey: key,
        fileUrl: url,
        mimeType: input.mimeType,
        fileSize: buffer.length,
        providerId: input.providerId,
        notes: input.notes,
      } as any);
    }),
  sign: protectedProcedure
    .input(z.object({ id: z.number(), signatureData: z.string() }))
    .mutation(async ({ input }) => {
      await db.updateDocument(input.id, { signed: true, signedAt: new Date(), signatureData: input.signatureData });
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteDocument(input.id);
      return { success: true };
    }),
});

// ─── Memory Router ────────────────────────────────────────────────────────────
const memoryRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getMemories(wedding.id);
  }),
  add: protectedProcedure
    .input(z.object({
      title: z.string(),
      content: z.string().optional(),
      emotion: z.enum(["joy","love","excitement","gratitude","nostalgia","other"]).default("other"),
      mediaType: z.enum(["photo","video","audio","note"]).default("note"),
      eventDate: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const data: any = { ...input, weddingId: wedding.id };
      if (input.eventDate) data.eventDate = new Date(input.eventDate);
      return db.addMemory(data);
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteMemory(input.id);
      return { success: true };
    }),
});

// ─── Chat / IA AURA Router ────────────────────────────────────────────────────
const chatRouter = router({
  history: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getChatHistory(wedding.id);
  }),
  send: protectedProcedure
    .input(z.object({ message: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");

      // Save user message
      await db.addChatMessage({ weddingId: wedding.id, userId: ctx.user.id, role: "user", content: input.message });

      // Build context
      const history = await db.getChatHistory(wedding.id, 20);
      const weddingContext = `Mariage de ${wedding.partner1Name || "Partenaire 1"} et ${wedding.partner2Name || "Partenaire 2"}${wedding.weddingDate ? ` le ${new Date(wedding.weddingDate).toLocaleDateString("fr-FR")}` : ""}${wedding.venue ? ` à ${wedding.venue}` : ""}${wedding.city ? `, ${wedding.city}` : ""}. Budget total: ${wedding.totalBudget || "non défini"}€. Nombre d'invités: ${wedding.guestCount || 0}.`;

      const systemPrompt = `Tu es AURA, l'intelligence artificielle centrale d'une plateforme de gestion de mariage. Tu es chaleureuse, professionnelle et experte en organisation de mariages en France.

Contexte du mariage: ${weddingContext}

Ton rôle:
1. Répondre aux questions sur l'organisation du mariage
2. Détecter automatiquement les informations importantes dans les messages (date, budget, nombre d'invités, lieu, prestataires) et indiquer quels modules tu vas mettre à jour
3. Donner des conseils personnalisés et des recommandations
4. Aider à planifier et organiser toutes les étapes du mariage

Quand tu détectes des informations à propager, indique-le clairement dans ta réponse avec le format: [PROPAGATION: module1, module2, ...]

Réponds toujours en français, de manière chaleureuse et professionnelle.`;

      const messages: any[] = [
        { role: "system", content: systemPrompt },
        ...history.slice(-10).map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: input.message },
      ];

      const response = await invokeLLM({ messages });
      const assistantContent = (response.choices[0]?.message?.content as string) || "Je suis désolée, je n'ai pas pu traiter votre message.";

      // Detect propagated modules
      const propagationMatch = assistantContent.match(/\[PROPAGATION:\s*([^\]]+)\]/);
      const propagatedModules = propagationMatch ? propagationMatch[1] : null;

      // Auto-propagate: detect wedding date
      const dateMatch = input.message.match(/(\d{1,2})[\/\-\s](\d{1,2})[\/\-\s](20\d{2})/);
      if (dateMatch) {
        try {
          const [, day, month, year] = dateMatch;
          const weddingDate = new Date(`${year}-${month.padStart(2,'0')}-${day.padStart(2,'0')}`);
          await db.upsertWedding(ctx.user.id, { weddingDate });
        } catch {}
      }

      // Auto-propagate: detect budget
      const budgetMatch = input.message.match(/budget[^\d]*(\d[\d\s]*(?:000)?)\s*(?:€|euros?)/i);
      if (budgetMatch) {
        try {
          const amount = budgetMatch[1].replace(/\s/g, '');
          await db.upsertWedding(ctx.user.id, { totalBudget: amount });
        } catch {}
      }

      // Auto-propagate: detect guest count
      const guestMatch = input.message.match(/(\d+)\s*(?:invités?|personnes?|convives?)/i);
      if (guestMatch) {
        try {
          await db.upsertWedding(ctx.user.id, { guestCount: parseInt(guestMatch[1]) });
        } catch {}
      }

      // Save assistant response
      await db.addChatMessage({
        weddingId: wedding.id,
        userId: ctx.user.id,
        role: "assistant",
        content: assistantContent,
        propagatedModules,
      });

      return { content: assistantContent, propagatedModules };
    }),
});

// ─── Day-Of Router ────────────────────────────────────────────────────────────
const dayOfRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getDayOfEvents(wedding.id);
  }),
  add: protectedProcedure
    .input(z.object({
      title: z.string(),
      scheduledTime: z.string(),
      timelineEventId: z.number().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      return db.addDayOfEvent({
        weddingId: wedding.id,
        title: input.title,
        scheduledTime: new Date(input.scheduledTime),
        timelineEventId: input.timelineEventId,
        notes: input.notes,
      } as any);
    }),
  updateStatus: protectedProcedure
    .input(z.object({
      id: z.number(),
      status: z.enum(["upcoming","in_progress","done","delayed"]),
      delayMinutes: z.number().optional(),
      actualTime: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const updateData: any = { status: input.status };
      if (input.delayMinutes !== undefined) updateData.delayMinutes = input.delayMinutes;
      if (input.actualTime) updateData.actualTime = new Date(input.actualTime);
      await db.updateDayOfEvent(input.id, updateData);
      return { success: true };
    }),
  aiAdjust: protectedProcedure
    .input(z.object({ delayedEventId: z.number(), delayMinutes: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const events = await db.getDayOfEvents(wedding.id);
      const delayedEvent = events.find(e => e.id === input.delayedEventId);
      if (!delayedEvent) throw new Error("Event not found");

      // Update the delayed event
      await db.updateDayOfEvent(input.delayedEventId, { status: "delayed", delayMinutes: input.delayMinutes });

      // Cascade delay to subsequent events
      const delayedTime = new Date(delayedEvent.scheduledTime).getTime();
      const subsequentEvents = events.filter(e => new Date(e.scheduledTime).getTime() > delayedTime && e.id !== input.delayedEventId);

      for (const event of subsequentEvents) {
        const newTime = new Date(new Date(event.scheduledTime).getTime() + input.delayMinutes * 60000);
        await db.updateDayOfEvent(event.id, { scheduledTime: newTime } as any);
      }

      return { success: true, adjustedCount: subsequentEvents.length };
    }),
});

// ─── Photo Wall Router ────────────────────────────────────────────────────────
const photoWallRouter = router({
  list: publicProcedure
    .input(z.object({ weddingId: z.number(), approvedOnly: z.boolean().default(true) }))
    .query(async ({ input }) => {
      return db.getPhotoWallPhotos(input.weddingId, input.approvedOnly);
    }),
  upload: publicProcedure
    .input(z.object({
      weddingId: z.number(),
      uploaderName: z.string().optional(),
      guestToken: z.string().optional(),
      fileData: z.string(),
      mimeType: z.string(),
    }))
    .mutation(async ({ input }) => {
      const buffer = Buffer.from(input.fileData, "base64");
      const fileKey = `weddings/${input.weddingId}/photowall/${nanoid()}.jpg`;
      const { key, url } = await storagePut(fileKey, buffer, input.mimeType);

      // AI scoring via LLM vision
      let aiScore = 0.5;
      let aiApproved = true;
      let aiRejectionReason = null;

      try {
        const aiResponse = await invokeLLM({
          messages: [
            { role: "system", content: "Tu es un expert en photographie de mariage. Analyse cette photo et donne un score de qualité de 0 à 1 et si elle est appropriée pour un mur photo de mariage. Réponds en JSON." },
            { role: "user", content: `Analyse cette photo pour un mur photo de mariage (URL: ${url}). Score de qualité (0-1), appropriée (true/false), raison si rejetée.` }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "photo_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  score: { type: "number" },
                  approved: { type: "boolean" },
                  rejectionReason: { type: "string" }
                },
                required: ["score", "approved", "rejectionReason"],
                additionalProperties: false
              }
            }
          }
        });
        const content = aiResponse.choices[0]?.message?.content as string | undefined;
        if (content) {
          const parsed = JSON.parse(content);
          aiScore = parsed.score;
          aiApproved = parsed.approved && parsed.score > 0.3;
          aiRejectionReason = parsed.rejectionReason || null;
        }
      } catch {}

      let guestId: number | undefined;
      if (input.guestToken) {
        const guest = await db.getGuestByRsvpToken(input.guestToken);
        if (guest) guestId = guest.id;
      }

      return db.addPhotoWallPhoto({
        weddingId: input.weddingId,
        uploadedByGuestId: guestId,
        uploaderName: input.uploaderName,
        fileKey: key,
        fileUrl: url,
        aiScore: String(aiScore) as any,
        aiApproved,
        aiRejectionReason,
      } as any);
    }),
});

// ─── Provider Portal Router (public) ─────────────────────────────────────────
const providerPortalRouter = router({
  getByToken: publicProcedure
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      const invitation = await db.getProviderInvitationByToken(input.token);
      if (!invitation) return null;
      const db2 = await db.getDb();
      if (!db2) return null;
      const { providers: providersTable, weddings: weddingsTable } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const [provider] = await db2.select().from(providersTable).where(eq(providersTable.id, invitation.providerId)).limit(1);
      const [wedding] = await db2.select().from(weddingsTable).where(eq(weddingsTable.id, invitation.weddingId)).limit(1);
      return { invitation, provider: provider ?? null, wedding: wedding ?? null };
    }),
  accept: publicProcedure
    .input(z.object({ token: z.string() }))
    .mutation(async ({ input }) => {
      await db.acceptProviderInvitation(input.token);
      return { success: true };
    }),
});

// ─── User Router ──────────────────────────────────────────────────────────────
const userRouter = router({
  setRole: protectedProcedure
    .input(z.object({ userRole: z.enum(["married","guest","provider"]) }))
    .mutation(async ({ ctx, input }) => {
      await db.updateUserRole(ctx.user.id, input.userRole);
      if (input.userRole === "married") {
        await db.upsertWedding(ctx.user.id, {});
      }
      return { success: true };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  user: userRouter,
  wedding: weddingRouter,
  timeline: timelineRouter,
  budget: budgetRouter,
  providers: providersRouter,
  guests: guestsRouter,
  rsvp: rsvpRouter,
  documents: documentsRouter,
  memory: memoryRouter,
  chat: chatRouter,
  dayOf: dayOfRouter,
  photoWall: photoWallRouter,
  providerPortal: providerPortalRouter,
  providerSpace: providerSpaceRouter,
  aiPlanner: aiPlannerRouter,
  seating: seatingRouter,
  subscriptions: subscriptionsRouter,
  providerNotifications: providerNotificationsRouter,
  reminders: remindersRouter,
  push: pushRouter,
});

export type AppRouter = typeof appRouter;
