import { eq, and, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  users, weddings, timelineEvents, budgetItems, providers,
  guests, documents, memories, chatMessages, dayOfEvents,
  photoWallPhotos, providerInvitations,
  InsertUser, InsertWedding, InsertTimelineEvent, InsertBudgetItem,
  InsertProvider, InsertGuest, InsertDocument, InsertMemory,
  InsertChatMessage, InsertDayOfEvent, InsertPhotoWallPhoto, InsertProviderInvitation
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserRole(userId: number, userRole: "married" | "guest" | "provider") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ userRole }).where(eq(users.id, userId));
}

// ─── Weddings ─────────────────────────────────────────────────────────────────
export async function getWeddingByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(weddings).where(eq(weddings.userId, userId)).limit(1);
  return result[0] ?? null;
}

export async function upsertWedding(userId: number, data: Partial<InsertWedding>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getWeddingByUserId(userId);
  if (existing) {
    await db.update(weddings).set(data).where(eq(weddings.userId, userId));
    return { ...existing, ...data };
  } else {
    const [result] = await db.insert(weddings).values({ userId, ...data });
    return { id: (result as any).insertId, userId, ...data };
  }
}

export async function getWeddingBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(weddings).where(eq(weddings.miniSiteSlug, slug)).limit(1);
  return result[0] ?? null;
}

// ─── Timeline ─────────────────────────────────────────────────────────────────
export async function getTimelineEvents(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(timelineEvents).where(eq(timelineEvents.weddingId, weddingId)).orderBy(asc(timelineEvents.sortOrder), asc(timelineEvents.scheduledAt));
}

export async function addTimelineEvent(data: InsertTimelineEvent) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(timelineEvents).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updateTimelineEvent(id: number, data: Partial<InsertTimelineEvent>) {
  const db = await getDb();
  if (!db) return;
  await db.update(timelineEvents).set(data).where(eq(timelineEvents.id, id));
}

export async function deleteTimelineEvent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(timelineEvents).where(eq(timelineEvents.id, id));
}

// ─── Budget ───────────────────────────────────────────────────────────────────
export async function getBudgetItems(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(budgetItems).where(eq(budgetItems.weddingId, weddingId)).orderBy(asc(budgetItems.category));
}

export async function addBudgetItem(data: InsertBudgetItem) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(budgetItems).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updateBudgetItem(id: number, data: Partial<InsertBudgetItem>) {
  const db = await getDb();
  if (!db) return;
  await db.update(budgetItems).set(data).where(eq(budgetItems.id, id));
}

export async function deleteBudgetItem(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(budgetItems).where(eq(budgetItems.id, id));
}

// ─── Providers ────────────────────────────────────────────────────────────────
export async function getProviders(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(providers).where(eq(providers.weddingId, weddingId)).orderBy(asc(providers.category));
}

export async function addProvider(data: InsertProvider) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(providers).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updateProvider(id: number, data: Partial<InsertProvider>) {
  const db = await getDb();
  if (!db) return;
  await db.update(providers).set(data).where(eq(providers.id, id));
}

export async function deleteProvider(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(providers).where(eq(providers.id, id));
}

// ─── Guests ───────────────────────────────────────────────────────────────────
export async function getGuests(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(guests).where(eq(guests.weddingId, weddingId)).orderBy(asc(guests.lastName), asc(guests.firstName));
}

export async function addGuest(data: InsertGuest) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(guests).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updateGuest(id: number, data: Partial<InsertGuest>) {
  const db = await getDb();
  if (!db) return;
  await db.update(guests).set(data).where(eq(guests.id, id));
}

export async function deleteGuest(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(guests).where(eq(guests.id, id));
}

export async function getGuestByRsvpToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(guests).where(eq(guests.rsvpToken, token)).limit(1);
  return result[0] ?? null;
}

// ─── Documents ────────────────────────────────────────────────────────────────
export async function getDocuments(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documents).where(eq(documents.weddingId, weddingId)).orderBy(desc(documents.createdAt));
}

export async function addDocument(data: InsertDocument) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(documents).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updateDocument(id: number, data: Partial<InsertDocument>) {
  const db = await getDb();
  if (!db) return;
  await db.update(documents).set(data).where(eq(documents.id, id));
}

export async function deleteDocument(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(documents).where(eq(documents.id, id));
}

// ─── Memories ─────────────────────────────────────────────────────────────────
export async function getMemories(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(memories).where(eq(memories.weddingId, weddingId)).orderBy(desc(memories.createdAt));
}

export async function addMemory(data: InsertMemory) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(memories).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function deleteMemory(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(memories).where(eq(memories.id, id));
}

// ─── Chat ─────────────────────────────────────────────────────────────────────
export async function getChatHistory(weddingId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages).where(eq(chatMessages.weddingId, weddingId)).orderBy(asc(chatMessages.createdAt)).limit(limit);
}

export async function addChatMessage(data: InsertChatMessage) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(chatMessages).values(data);
  return { id: (result as any).insertId, ...data };
}

// ─── Day-Of Events ────────────────────────────────────────────────────────────
export async function getDayOfEvents(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dayOfEvents).where(eq(dayOfEvents.weddingId, weddingId)).orderBy(asc(dayOfEvents.scheduledTime));
}

export async function addDayOfEvent(data: InsertDayOfEvent) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(dayOfEvents).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updateDayOfEvent(id: number, data: Partial<InsertDayOfEvent>) {
  const db = await getDb();
  if (!db) return;
  await db.update(dayOfEvents).set(data).where(eq(dayOfEvents.id, id));
}

// ─── Photo Wall ───────────────────────────────────────────────────────────────
export async function getPhotoWallPhotos(weddingId: number, approvedOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (approvedOnly) {
    return db.select().from(photoWallPhotos).where(and(eq(photoWallPhotos.weddingId, weddingId), eq(photoWallPhotos.aiApproved, true))).orderBy(desc(photoWallPhotos.createdAt));
  }
  return db.select().from(photoWallPhotos).where(eq(photoWallPhotos.weddingId, weddingId)).orderBy(desc(photoWallPhotos.createdAt));
}

export async function addPhotoWallPhoto(data: InsertPhotoWallPhoto) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(photoWallPhotos).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function updatePhotoWallPhoto(id: number, data: Partial<InsertPhotoWallPhoto>) {
  const db = await getDb();
  if (!db) return;
  await db.update(photoWallPhotos).set(data).where(eq(photoWallPhotos.id, id));
}

// ─── Provider Invitations ─────────────────────────────────────────────────────
export async function getProviderInvitationByToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(providerInvitations).where(eq(providerInvitations.token, token)).limit(1);
  return result[0] ?? null;
}

export async function addProviderInvitation(data: InsertProviderInvitation) {
  const db = await getDb();
  if (!db) return;
  const [result] = await db.insert(providerInvitations).values(data);
  return { id: (result as any).insertId, ...data };
}

export async function acceptProviderInvitation(token: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(providerInvitations).set({ accepted: true, acceptedAt: new Date() }).where(eq(providerInvitations.token, token));
}

// ─── Public RSVP (from mini-site, no token required) ─────────────────────────
export async function submitPublicRsvp(weddingId: number, data: {
  firstName: string;
  lastName: string;
  email?: string;
  rsvpStatus: "confirmed" | "declined" | "maybe";
  plusOneConfirmed?: boolean;
  dietaryRestrictions?: string;
  message?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const { nanoid } = await import("nanoid");
  // Check if guest already exists by email
  if (data.email) {
    const existing = await db.select().from(guests)
      .where(and(eq(guests.weddingId, weddingId), eq(guests.email, data.email)))
      .limit(1);
    if (existing[0]) {
      await db.update(guests)
        .set({ rsvpStatus: data.rsvpStatus, plusOne: data.plusOneConfirmed ?? false, dietaryRestrictions: data.dietaryRestrictions ?? null, rsvpRespondedAt: new Date() })
        .where(eq(guests.id, existing[0].id));
      return { success: true, guestId: existing[0].id };
    }
  }
  const rsvpToken = nanoid(32);
  const [result] = await db.insert(guests).values({
    weddingId,
    firstName: data.firstName,
    lastName: data.lastName,
    email: data.email ?? null,
    rsvpStatus: data.rsvpStatus,
    plusOne: data.plusOneConfirmed ?? false,
    dietaryRestrictions: data.dietaryRestrictions ?? null,
    rsvpToken,
    rsvpRespondedAt: new Date(),
  });
  return { success: true, guestId: (result as any).insertId };
}
