/**
 * Tests v2.2 — Notifications Push Navigateur
 * Vérifie les templates, le helper sendPushToUser et le router push tRPC
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import { PushTemplates } from "./_core/pushNotification";

// ─── PushTemplates ────────────────────────────────────────────────────────────
describe("PushTemplates", () => {
  describe("weddingReminder", () => {
    it("génère le bon titre pour J-1", () => {
      const payload = PushTemplates.weddingReminder(1, "Alice", "Bob", "15 juin 2026");
      expect(payload.title).toContain("J-1");
      expect(payload.body).toContain("Alice");
      expect(payload.body).toContain("Bob");
      expect(payload.requireInteraction).toBe(true);
    });

    it("génère le bon titre pour J-7", () => {
      const payload = PushTemplates.weddingReminder(7, "Alice", "Bob", "15 juin 2026");
      expect(payload.title).toContain("J-7");
      expect(payload.requireInteraction).toBe(true);
    });

    it("génère le bon titre pour J-30", () => {
      const payload = PushTemplates.weddingReminder(30, "Alice", "Bob", "15 juin 2026");
      expect(payload.title).toContain("J-30");
      expect(payload.requireInteraction).toBe(false);
    });

    it("inclut le tag unique", () => {
      const payload = PushTemplates.weddingReminder(7, "Alice", "Bob", "15 juin 2026");
      expect(payload.tag).toBe("wedding-reminder-j7");
    });

    it("pointe vers /cockpit", () => {
      const payload = PushTemplates.weddingReminder(1, "Alice", "Bob", "15 juin 2026");
      expect(payload.url).toBe("/cockpit");
      expect(payload.panel).toBe("dashboard");
    });
  });

  describe("invitationAccepted", () => {
    it("génère le bon message", () => {
      const payload = PushTemplates.invitationAccepted("Fleuriste Dupont", "Fleuriste");
      expect(payload.title).toContain("confirmé");
      expect(payload.body).toContain("Fleuriste Dupont");
      expect(payload.body).toContain("Fleuriste");
      expect(payload.panel).toBe("providers");
    });
  });

  describe("contractSigned", () => {
    it("génère le bon message", () => {
      const payload = PushTemplates.contractSigned("Photographe Martin");
      expect(payload.title).toContain("signé");
      expect(payload.body).toContain("Photographe Martin");
      expect(payload.panel).toBe("contracts");
    });
  });

  describe("paymentReceived", () => {
    it("génère le bon message avec montant", () => {
      const payload = PushTemplates.paymentReceived("Traiteur Leblanc", "1500€");
      expect(payload.title).toContain("Paiement");
      expect(payload.body).toContain("Traiteur Leblanc");
      expect(payload.body).toContain("1500€");
    });

    it("génère le bon message sans montant", () => {
      const payload = PushTemplates.paymentReceived("Traiteur Leblanc", "");
      expect(payload.body).toContain("Traiteur Leblanc");
    });
  });

  describe("rsvpReceived", () => {
    it("génère le bon message pour une confirmation", () => {
      const payload = PushTemplates.rsvpReceived("Marie Dupont", "confirmed");
      expect(payload.title).toContain("RSVP");
      expect(payload.body).toContain("Marie Dupont");
      expect(payload.body).toContain("confirmé");
      expect(payload.panel).toBe("guests");
    });

    it("génère le bon message pour un refus", () => {
      const payload = PushTemplates.rsvpReceived("Jean Martin", "declined");
      expect(payload.body).toContain("Jean Martin");
      expect(payload.body).toContain("présent");
    });

    it("génère le bon message pour un maybe", () => {
      const payload = PushTemplates.rsvpReceived("Paul Durand", "maybe");
      expect(payload.body).toContain("Paul Durand");
      expect(payload.body).toContain("peut-être");
    });
  });

  describe("subscriptionActivated", () => {
    it("génère le bon message", () => {
      const payload = PushTemplates.subscriptionActivated("Premium");
      expect(payload.title).toContain("Abonnement");
      expect(payload.body).toContain("Premium");
    });
  });
});

// ─── sendPushToUser (mocked) ──────────────────────────────────────────────────
describe("sendPushToUser (mocked)", () => {
  it("retourne 0 envois si VAPID non configuré", async () => {
    // Sans clés VAPID, le helper retourne {sent:0, failed:0, expired:0}
    const originalPublic = process.env.VAPID_PUBLIC_KEY;
    const originalPrivate = process.env.VAPID_PRIVATE_KEY;
    delete process.env.VAPID_PUBLIC_KEY;
    delete process.env.VAPID_PRIVATE_KEY;

    // Réimporter pour forcer la re-évaluation
    const { sendPushToUser } = await import("./_core/pushNotification");
    const result = await sendPushToUser("user-123", {
      title: "Test",
      body: "Test body",
    });

    // Avec DB unavailable et VAPID non configuré, on attend 0 envois
    expect(result.sent).toBe(0);

    // Restaurer
    if (originalPublic) process.env.VAPID_PUBLIC_KEY = originalPublic;
    if (originalPrivate) process.env.VAPID_PRIVATE_KEY = originalPrivate;
  });
});

// ─── Intégration : tous les templates ont les champs requis ──────────────────
describe("PushTemplates — champs requis", () => {
  const allTemplates = [
    PushTemplates.weddingReminder(7, "A", "B", "1 jan 2026"),
    PushTemplates.invitationAccepted("Prov", "Cat"),
    PushTemplates.contractSigned("Prov"),
    PushTemplates.paymentReceived("Prov", "500€"),
    PushTemplates.rsvpReceived("Guest", "confirmed"),
    PushTemplates.subscriptionActivated("Essentiel"),
  ];

  allTemplates.forEach((template, i) => {
    it(`template[${i}] a title, body, tag et url`, () => {
      expect(template.title).toBeTruthy();
      expect(template.body).toBeTruthy();
      expect(template.tag).toBeTruthy();
      expect(template.url).toBe("/cockpit");
    });
  });
});
