import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB ──────────────────────────────────────────────────────────────────
vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return {
    ...actual,
    getDb: vi.fn().mockResolvedValue(null),
    getWeddingByUserId: vi.fn().mockResolvedValue(null),
  };
});

function createAuthContext(userId = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: "test-open-id",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {}, ip: "127.0.0.1" } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {}, ip: "127.0.0.1" } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────
describe("providerSpace.getDashboard", () => {
  it("retourne null si le token est vide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.providerSpace.getDashboard({ sessionToken: "" });
    expect(result).toBeNull();
  });

  it("retourne null si le token est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.providerSpace.getDashboard({ sessionToken: "invalid-token-xyz" });
    expect(result).toBeNull();
  });
});

describe("providerSpace.missions.list", () => {
  it("retourne un tableau vide si le token est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.providerSpace.missions.list({ sessionToken: "bad-token" });
    expect(result).toEqual([]);
  });
});

describe("providerSpace.contracts.list", () => {
  it("retourne un tableau vide si le token est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.providerSpace.contracts.list({ sessionToken: "bad-token" });
    expect(result).toEqual([]);
  });
});

describe("providerSpace.profile.get", () => {
  it("retourne null si le token est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.providerSpace.profile.get({ sessionToken: "bad-token" });
    expect(result).toBeNull();
  });
});

describe("providerSpace.contracts.create", () => {
  it("lève une erreur si l'utilisateur n'a pas de mariage", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(
      caller.providerSpace.contracts.create({
        providerId: 1,
        title: "Contrat Photographe",
        amount: "3500",
        depositAmount: "1000",
      })
    ).rejects.toThrow();
  });
});

describe("providerSpace.coupleContracts.list", () => {
  it("retourne un tableau vide si l'utilisateur n'a pas de mariage", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.providerSpace.coupleContracts.list();
    expect(result).toEqual([]);
  });
});

describe("providerSpace.acceptAndCreateSession", () => {
  it("lève une erreur si le token d'invitation est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.providerSpace.acceptAndCreateSession({ invitationToken: "invalid-token" })
    ).rejects.toThrow();
  });
});

describe("providerSpace.contracts.signAsProvider", () => {
  it("lève une erreur si la session est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.providerSpace.contracts.signAsProvider({
        sessionToken: "invalid-session",
        contractId: 1,
        signatureData: "data:image/png;base64,abc123",
        signerName: "Jean Dupont",
      })
    ).rejects.toThrow();
  });
});

describe("providerSpace.contracts.signAsCouple", () => {
  it("lève une erreur si le contrat n'existe pas", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(
      caller.providerSpace.contracts.signAsCouple({
        contractId: 99999,
        signatureData: "data:image/png;base64,abc123",
        signerName: "Sophie Martin",
      })
    ).rejects.toThrow();
  });
});

describe("providerSpace.profile.upsert", () => {
  it("lève une erreur si la session est invalide", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.providerSpace.profile.upsert({
        sessionToken: "invalid-session",
        businessName: "Studio Lumière",
        city: "Paris",
      })
    ).rejects.toThrow();
  });
});

describe("providerSpace.contracts.markPayment", () => {
  it("lève une erreur si le contrat n'existe pas (DB null)", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(
      caller.providerSpace.contracts.markPayment({ contractId: 99999, type: "deposit" })
    ).rejects.toThrow();
  });
});
