import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock de la base de données ───────────────────────────────────────────────
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
  getWeddingByUserId: vi.fn().mockResolvedValue(null),
  getWeddingBySlug: vi.fn().mockResolvedValue(null),
}));

// ─── Mock Stripe ──────────────────────────────────────────────────────────────
vi.mock("stripe", () => {
  return {
    default: vi.fn().mockImplementation(() => ({
      checkout: {
        sessions: {
          create: vi.fn().mockResolvedValue({ url: "https://checkout.stripe.com/test" }),
        },
      },
      billingPortal: {
        sessions: {
          create: vi.fn().mockResolvedValue({ url: "https://billing.stripe.com/test" }),
        },
      },
    })),
  };
});

// ─── Contexte d'authentification ─────────────────────────────────────────────
function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

// ─── Tests Router Seating ─────────────────────────────────────────────────────
describe("seating router", () => {
  it("getFullPlan lance une erreur si DB indisponible", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    // Avec DB null, le router lance une erreur TRPCError
    await expect(caller.seating.getFullPlan()).rejects.toThrow("DB unavailable");
  });
});

// ─── Tests Router Subscriptions ───────────────────────────────────────────────
describe("subscriptions router", () => {
  it("getCurrent retourne le plan gratuit par défaut si pas de DB", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.subscriptions.getCurrent();
    expect(result).toBeDefined();
    expect(result.plan).toBe("free");
    expect(result.status).toBe("active");
  });

  it("getPlans retourne les 4 plans AURA", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const plans = await caller.subscriptions.getPlans();
    expect(plans).toHaveLength(4);
    const planIds = plans.map((p) => p.id);
    expect(planIds).toContain("free");
    expect(planIds).toContain("essentiel");
    expect(planIds).toContain("premium");
    expect(planIds).toContain("prestige");
  });

  it("getPlans inclut les prix corrects", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const plans = await caller.subscriptions.getPlans();
    const free = plans.find((p) => p.id === "free");
    const essentiel = plans.find((p) => p.id === "essentiel");
    const premium = plans.find((p) => p.id === "premium");
    const prestige = plans.find((p) => p.id === "prestige");
    expect(free?.price).toBe(0);
    expect(essentiel?.price).toBe(1900);
    expect(premium?.price).toBe(3900);
    expect(prestige?.price).toBe(7900);
  });

  it("getPlans inclut les features pour chaque plan", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const plans = await caller.subscriptions.getPlans();
    for (const plan of plans) {
      expect(plan.features).toBeDefined();
      expect(plan.features.length).toBeGreaterThan(0);
    }
  });

  it("createCheckout nécessite un plan valide", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(
      caller.subscriptions.createCheckout({
        plan: "invalid" as any,
        origin: "https://example.com",
      })
    ).rejects.toThrow();
  });
});

// ─── Tests intégration appRouter ─────────────────────────────────────────────
describe("appRouter integration", () => {
  it("appRouter expose le router seating", () => {
    expect(appRouter._def.procedures).toHaveProperty("seating.getFullPlan");
    expect(appRouter._def.procedures).toHaveProperty("seating.addTable");
    expect(appRouter._def.procedures).toHaveProperty("seating.deleteTable");
    expect(appRouter._def.procedures).toHaveProperty("seating.assignGuest");
    expect(appRouter._def.procedures).toHaveProperty("seating.unassignGuest");
    expect(appRouter._def.procedures).toHaveProperty("seating.autoAssign");
  });

  it("appRouter expose le router subscriptions", () => {
    expect(appRouter._def.procedures).toHaveProperty("subscriptions.getCurrent");
    expect(appRouter._def.procedures).toHaveProperty("subscriptions.getPlans");
    expect(appRouter._def.procedures).toHaveProperty("subscriptions.createCheckout");
    expect(appRouter._def.procedures).toHaveProperty("subscriptions.createPortal");
  });
});
