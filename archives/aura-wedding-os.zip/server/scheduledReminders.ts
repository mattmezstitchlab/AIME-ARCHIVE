/**
 * Handler Heartbeat — /api/scheduled/wedding-reminder
 *
 * Déclenché par le cron Manus Heartbeat à J-30, J-7 et J-1 avant le mariage.
 * Authentifie la requête via sdk.authenticateRequest (user.isCron === true),
 * retrouve le mariage par taskUid, et envoie une notification push au propriétaire.
 */
import type { Request, Response } from "express";
import { sdk } from "./_core/sdk";
import { notifyOwner } from "./_core/notification";
import * as db from "./db";
import { weddings } from "../drizzle/schema";
import { or, eq } from "drizzle-orm";
import { sendPushToUser, PushTemplates } from "./_core/pushNotification";

export async function weddingReminderHandler(req: Request, res: Response) {
  try {
    // 1. Authentifier la requête cron
    const user = await sdk.authenticateRequest(req);
    if (!user?.isCron || !user?.taskUid) {
      return res.status(403).json({ error: "cron-only" });
    }

    const taskUid: string = user.taskUid;

    // 2. Retrouver le mariage lié à ce taskUid (J-30, J-7 ou J-1)
    const dbConn = await db.getDb();
    if (!dbConn) {
      return res.status(500).json({ error: "db-unavailable" });
    }

    const rows = await dbConn
      .select()
      .from(weddings)
      .where(
        or(
          eq(weddings.reminderJ30TaskUid, taskUid),
          eq(weddings.reminderJ7TaskUid, taskUid),
          eq(weddings.reminderJ1TaskUid, taskUid)
        )
      )
      .limit(1);

    const wedding = rows[0];
    if (!wedding) {
      // Orphan — le mariage a été supprimé ou le cron est périmé
      return res.json({ ok: true, skipped: "orphan" });
    }

    // 3. Déterminer le type de rappel (J-30, J-7 ou J-1)
    let daysLabel = "";
    let emoji = "💍";
    if (wedding.reminderJ30TaskUid === taskUid) {
      daysLabel = "J-30";
      emoji = "📅";
    } else if (wedding.reminderJ7TaskUid === taskUid) {
      daysLabel = "J-7";
      emoji = "⏰";
    } else if (wedding.reminderJ1TaskUid === taskUid) {
      daysLabel = "J-1";
      emoji = "💍";
    }

    const partner1 = wedding.partner1Name || "Partenaire 1";
    const partner2 = wedding.partner2Name || "Partenaire 2";
    const dateStr = wedding.weddingDate
      ? new Date(wedding.weddingDate).toLocaleDateString("fr-FR", {
          day: "numeric",
          month: "long",
          year: "numeric",
        })
      : "date non définie";

    // 4. Envoyer la notification push au propriétaire
    const daysUntil = daysLabel === "J-30" ? 30 : daysLabel === "J-7" ? 7 : 1;

    const sent = await notifyOwner({
      title: `${emoji} Rappel ${daysLabel} — Mariage de ${partner1} & ${partner2}`,
      content: `Votre mariage approche ! Il ne reste plus que ${daysUntil} jours avant le grand jour (${dateStr}).\n\nPensez à vérifier :\n• La confirmation de tous vos prestataires\n• La liste finale des invités\n• La timeline du Jour J\n• Les documents et contrats signés\n\nConnectez-vous à votre Cockpit AURA pour un dernier point.`,
    });

    // 5. Envoyer une notification push navigateur au propriétaire
    const ownerUserId = String(wedding.userId);
    const pushResult = await sendPushToUser(
      ownerUserId,
      PushTemplates.weddingReminder(daysUntil, partner1, partner2, dateStr)
    );
    console.log(`[wedding-reminder] Push result:`, pushResult);

    console.log(
      `[wedding-reminder] ${daysLabel} notification sent for wedding ${wedding.id}: ${sent}`
    );

    return res.json({ ok: true, daysLabel, weddingId: wedding.id, notified: sent });
  } catch (err: any) {
    console.error("[wedding-reminder] Error:", err);
    return res.status(500).json({
      error: err?.message ?? "unknown",
      stack: err?.stack,
      context: { url: req.url, taskUid: (req as any).taskUid },
      timestamp: new Date().toISOString(),
    });
  }
}
