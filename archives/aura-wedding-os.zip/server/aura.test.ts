import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB ─────────────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  getWeddingByUserId: vi.fn().mockResolvedValue({
    id: 1, userId: 1, partner1Name: "Alice", partner2Name: "Bob",
    weddingDate: new Date("2026-06-15"), guestCount: 100, totalBudget: "25000",
    miniSiteSlug: "alice-bob", miniSiteEnabled: true,
    createdAt: new Date(), updatedAt: new Date(),
  }),
  upsertWedding: vi.fn().mockResolvedValue({ id: 1 }),
  getWeddingBySlug: vi.fn().mockResolvedValue({
    id: 1, partner1Name: "Alice", partner2Name: "Bob",
    weddingDate: new Date("2026-06-15"), miniSiteEnabled: true,
    miniSiteSlug: "alice-bob",
  }),
  getTimelineEvents: vi.fn().mockResolvedValue([
    { id: 1, weddingId: 1, title: "Cérémonie", category: "ceremony", status: "confirmed", scheduledAt: new Date("2026-06-15T14:00:00"), createdAt: new Date(), updatedAt: new Date() }
  ]),
  addTimelineEvent: vi.fn().mockResolvedValue({ id: 2 }),
  updateTimelineEvent: vi.fn().mockResolvedValue({ id: 1 }),
  deleteTimelineEvent: vi.fn().mockResolvedValue(undefined),
  getBudgetItems: vi.fn().mockResolvedValue([
    { id: 1, weddingId: 1, category: "photography", label: "Photographe", estimatedAmount: "3000", actualAmount: "2800", paid: false, createdAt: new Date(), updatedAt: new Date() }
  ]),
  addBudgetItem: vi.fn().mockResolvedValue({ id: 2 }),
  updateBudgetItem: vi.fn().mockResolvedValue({ id: 1 }),
  deleteBudgetItem: vi.fn().mockResolvedValue(undefined),
  getProviders: vi.fn().mockResolvedValue([
    { id: 1, weddingId: 1, name: "Studio Lumière", category: "photographer", status: "booked", createdAt: new Date(), updatedAt: new Date() }
  ]),
  addProvider: vi.fn().mockResolvedValue({ id: 2 }),
  updateProvider: vi.fn().mockResolvedValue({ id: 1 }),
  deleteProvider: vi.fn().mockResolvedValue(undefined),
  addProviderInvitation: vi.fn().mockResolvedValue({ id: 1, token: "test-token-123" }),
  getGuests: vi.fn().mockResolvedValue([
    { id: 1, weddingId: 1, firstName: "Marie", lastName: "Dupont", rsvpToken: "rsvp-token-abc", rsvpStatus: "confirmed", createdAt: new Date(), updatedAt: new Date() }
  ]),
  addGuest: vi.fn().mockResolvedValue({ id: 2, rsvpToken: "new-token" }),
  updateGuest: vi.fn().mockResolvedValue({ id: 1 }),
  deleteGuest: vi.fn().mockResolvedValue(undefined),
  getGuestByRsvpToken: vi.fn().mockResolvedValue({
    id: 1, weddingId: 1, firstName: "Marie", lastName: "Dupont",
    rsvpToken: "rsvp-token-abc", rsvpStatus: "pending",
    createdAt: new Date(), updatedAt: new Date(),
  }),
  getDocuments: vi.fn().mockResolvedValue([]),
  addDocument: vi.fn().mockResolvedValue({ id: 1 }),
  updateDocument: vi.fn().mockResolvedValue({ id: 1 }),
  deleteDocument: vi.fn().mockResolvedValue(undefined),
  getMemories: vi.fn().mockResolvedValue([]),
  addMemory: vi.fn().mockResolvedValue({ id: 1 }),
  deleteMemory: vi.fn().mockResolvedValue(undefined),
  getChatMessages: vi.fn().mockResolvedValue([]),
  addChatMessage: vi.fn().mockResolvedValue({ id: 1 }),
  getDayOfEvents: vi.fn().mockResolvedValue([]),
  addDayOfEvent: vi.fn().mockResolvedValue({ id: 1 }),
  updateDayOfEvent: vi.fn().mockResolvedValue({ id: 1 }),
  getPhotoWallPhotos: vi.fn().mockResolvedValue([]),
  addPhotoWallPhoto: vi.fn().mockResolvedValue({ id: 1 }),
  getDb: vi.fn().mockResolvedValue(null),
  upsertUser: vi.fn().mockResolvedValue(undefined),
  getUserByOpenId: vi.fn().mockResolvedValue(undefined),
  getProviderInvitationByToken: vi.fn().mockResolvedValue(null),
  acceptProviderInvitation: vi.fn().mockResolvedValue(undefined),
  updateUserRole: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: JSON.stringify({
      reply: "Votre mariage est planifié pour le 15 juin 2026 !",
      propagatedModules: ["wedding"],
      extractedData: { weddingDate: "2026-06-15" }
    }) } }]
  })
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ key: "test-key", url: "/manus-storage/test-key" })
}));

// ─── Auth context helper ──────────────────────────────────────────────────────
function createAuthCtx(overrides?: Partial<TrpcContext["user"]>): TrpcContext {
  return {
    user: {
      id: 1, openId: "test-user", email: "test@aura.fr", name: "Test User",
      loginMethod: "manus", role: "user", createdAt: new Date(),
      updatedAt: new Date(), lastSignedIn: new Date(),
      ...overrides,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────
describe("AURA — Wedding Router", () => {
  it("wedding.get returns the wedding for the authenticated user", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.wedding.get();
    expect(result).toBeDefined();
    expect(result?.partner1Name).toBe("Alice");
    expect(result?.partner2Name).toBe("Bob");
  });

  it("wedding.getBySlug returns a public wedding by slug", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.wedding.getBySlug({ slug: "alice-bob" });
    expect(result).toBeDefined();
    expect(result?.miniSiteEnabled).toBe(true);
  });
});

describe("AURA — Timeline Router", () => {
  it("timeline.list returns events for the wedding", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.timeline.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result[0]?.title).toBe("Cérémonie");
  });

  it("timeline.add creates a new event", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.timeline.add({ title: "Vin d'honneur", category: "reception" });
    expect(result).toBeDefined();
  });
});

describe("AURA — Budget Router", () => {
  it("budget.list returns items for the wedding", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.budget.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result[0]?.label).toBe("Photographe");
  });
});

describe("AURA — Providers Router", () => {
  it("providers.list returns providers for the wedding", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.providers.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result[0]?.name).toBe("Studio Lumière");
  });

  it("providers.generateInviteLink returns a URL with a token", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.providers.generateInviteLink({ providerId: 1, origin: "https://aura.manus.space" });
    expect(result.url).toContain("/prestataire/");
  });
});

describe("AURA — Guests Router", () => {
  it("guests.list returns guests for the wedding", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.guests.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result[0]?.firstName).toBe("Marie");
  });

  it("guests.add creates a guest with an RSVP token", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.guests.add({ firstName: "Jean", side: "both" });
    expect(result).toBeDefined();
  });
});

describe("AURA — RSVP Router (public)", () => {
  it("rsvp.getByToken returns guest data for a valid token", async () => {
    const caller = appRouter.createCaller({ ...createAuthCtx(), user: null });
    const result = await caller.rsvp.getByToken({ token: "rsvp-token-abc" });
    expect(result?.guest?.firstName).toBe("Marie");
  });

  it("rsvp.respond updates the guest status", async () => {
    const caller = appRouter.createCaller({ ...createAuthCtx(), user: null });
    const result = await caller.rsvp.respond({ token: "rsvp-token-abc", rsvpStatus: "confirmed" });
    expect(result.success).toBe(true);
  });
});

describe("AURA — Auth Router", () => {
  it("auth.me returns the current user", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.auth.me();
    expect(result?.name).toBe("Test User");
  });

  it("auth.logout clears the session cookie", async () => {
    const ctx = createAuthCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
  });
});
