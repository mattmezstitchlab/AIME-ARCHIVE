CREATE TABLE `seating_assignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`tableId` int NOT NULL,
	`guestId` int NOT NULL,
	`seatNumber` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `seating_assignments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `seating_tables` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`name` varchar(128) NOT NULL,
	`shape` enum('round','rectangular','square') NOT NULL DEFAULT 'round',
	`capacity` int NOT NULL DEFAULT 8,
	`positionX` int DEFAULT 0,
	`positionY` int DEFAULT 0,
	`colorHex` varchar(16) DEFAULT '#F07167',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seating_tables_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`stripeCustomerId` varchar(128),
	`stripeSubscriptionId` varchar(128),
	`plan` enum('free','essentiel','premium','prestige') NOT NULL DEFAULT 'free',
	`status` enum('active','canceled','past_due','trialing','incomplete') NOT NULL DEFAULT 'active',
	`currentPeriodEnd` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `subscriptions_userId_unique` UNIQUE(`userId`)
);
