ALTER TABLE `weddings` ADD `miniSiteWelcomeMsg` text;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteThemeColor` varchar(32);--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteDressCode` text;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteTransportInfo` text;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteAccommodation` text;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteShowTimeline` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteShowPhotos` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteShowRsvp` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteShowMap` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `weddings` ADD `miniSiteShowPractical` boolean DEFAULT true;