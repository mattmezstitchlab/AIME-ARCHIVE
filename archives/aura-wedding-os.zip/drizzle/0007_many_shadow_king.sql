ALTER TABLE `weddings` ADD `reminderJ30TaskUid` varchar(65);--> statement-breakpoint
ALTER TABLE `weddings` ADD `reminderJ7TaskUid` varchar(65);--> statement-breakpoint
ALTER TABLE `weddings` ADD `reminderJ1TaskUid` varchar(65);