CREATE TABLE `provider_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`providerId` int NOT NULL,
	`type` enum('invitation_accepted','mission_update','contract_signed','payment_received','message') NOT NULL,
	`title` varchar(256) NOT NULL,
	`message` text NOT NULL,
	`isRead` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `provider_notifications_id` PRIMARY KEY(`id`)
);
