CREATE TABLE `budget_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`category` enum('venue','catering','photography','videography','music','flowers','dress','suit','rings','transport','accommodation','invitations','decoration','beauty','honeymoon','other') NOT NULL DEFAULT 'other',
	`label` varchar(256) NOT NULL,
	`estimatedAmount` decimal(10,2) DEFAULT '0',
	`actualAmount` decimal(10,2),
	`paid` boolean DEFAULT false,
	`providerId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `budget_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`propagatedModules` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `day_of_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`timelineEventId` int,
	`title` varchar(256) NOT NULL,
	`scheduledTime` timestamp NOT NULL,
	`actualTime` timestamp,
	`delayMinutes` int DEFAULT 0,
	`status` enum('upcoming','in_progress','done','delayed') NOT NULL DEFAULT 'upcoming',
	`notifiedProviders` boolean DEFAULT false,
	`notes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `day_of_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`providerId` int,
	`name` varchar(256) NOT NULL,
	`type` enum('contract','quote','invoice','photo','other') NOT NULL DEFAULT 'other',
	`fileKey` text,
	`fileUrl` text,
	`mimeType` varchar(128),
	`fileSize` int,
	`signed` boolean DEFAULT false,
	`signedAt` timestamp,
	`signatureData` text,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`firstName` varchar(128) NOT NULL,
	`lastName` varchar(128),
	`email` varchar(320),
	`phone` varchar(32),
	`group` varchar(64),
	`side` enum('partner1','partner2','both') DEFAULT 'both',
	`rsvpToken` varchar(64),
	`rsvpStatus` enum('pending','confirmed','declined','maybe') NOT NULL DEFAULT 'pending',
	`plusOne` boolean DEFAULT false,
	`plusOneName` varchar(256),
	`dietaryRestrictions` text,
	`tableNumber` int,
	`notes` text,
	`rsvpRespondedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `guests_id` PRIMARY KEY(`id`),
	CONSTRAINT `guests_rsvpToken_unique` UNIQUE(`rsvpToken`)
);
--> statement-breakpoint
CREATE TABLE `memories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`title` varchar(256) NOT NULL,
	`content` text,
	`emotion` enum('joy','love','excitement','gratitude','nostalgia','other') DEFAULT 'other',
	`mediaUrl` text,
	`mediaKey` text,
	`mediaType` enum('photo','video','audio','note') DEFAULT 'note',
	`eventDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `memories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `photo_wall_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`uploadedByGuestId` int,
	`uploaderName` varchar(128),
	`fileKey` text NOT NULL,
	`fileUrl` text NOT NULL,
	`thumbnailUrl` text,
	`aiScore` decimal(5,2),
	`aiApproved` boolean DEFAULT false,
	`aiRejectionReason` text,
	`featured` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `photo_wall_photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `provider_invitations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`providerId` int NOT NULL,
	`token` varchar(64) NOT NULL,
	`email` varchar(320),
	`accepted` boolean DEFAULT false,
	`acceptedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `provider_invitations_id` PRIMARY KEY(`id`),
	CONSTRAINT `provider_invitations_token_unique` UNIQUE(`token`)
);
--> statement-breakpoint
CREATE TABLE `providers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`userId` int,
	`name` varchar(256) NOT NULL,
	`category` enum('photographer','videographer','caterer','florist','music','venue','transport','beauty','dress','suit','cake','animation','officiant','other') NOT NULL DEFAULT 'other',
	`email` varchar(320),
	`phone` varchar(32),
	`website` text,
	`city` varchar(128),
	`priceRange` varchar(64),
	`status` enum('shortlisted','contacted','quote_received','booked','cancelled') NOT NULL DEFAULT 'shortlisted',
	`rating` int,
	`notes` text,
	`contractUrl` text,
	`quoteAmount` decimal(10,2),
	`bookedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `providers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `timeline_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`title` varchar(256) NOT NULL,
	`description` text,
	`category` enum('ceremony','reception','preparation','photo','transport','dinner','entertainment','administrative','other') NOT NULL DEFAULT 'other',
	`scheduledAt` timestamp,
	`durationMinutes` int DEFAULT 60,
	`status` enum('pending','confirmed','done','cancelled') NOT NULL DEFAULT 'pending',
	`providerId` int,
	`location` text,
	`notes` text,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `timeline_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weddings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`partner1Name` varchar(128),
	`partner2Name` varchar(128),
	`weddingDate` timestamp,
	`venue` text,
	`city` varchar(128),
	`guestCount` int DEFAULT 0,
	`totalBudget` decimal(10,2),
	`style` varchar(64),
	`colorPalette` varchar(128),
	`notes` text,
	`miniSiteSlug` varchar(64),
	`miniSiteEnabled` boolean DEFAULT false,
	`miniSiteContent` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weddings_id` PRIMARY KEY(`id`),
	CONSTRAINT `weddings_miniSiteSlug_unique` UNIQUE(`miniSiteSlug`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `userRole` enum('married','guest','provider','unset') DEFAULT 'unset' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(32);