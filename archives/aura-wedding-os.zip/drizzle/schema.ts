import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ───────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  userRole: mysqlEnum("userRole", ["married", "guest", "provider", "unset"]).default("unset").notNull(),
  avatarUrl: text("avatarUrl"),
  phone: varchar("phone", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Weddings ────────────────────────────────────────────────────────────────
export const weddings = mysqlTable("weddings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  partner1Name: varchar("partner1Name", { length: 128 }),
  partner2Name: varchar("partner2Name", { length: 128 }),
  weddingDate: timestamp("weddingDate"),
  venue: text("venue"),
  city: varchar("city", { length: 128 }),
  guestCount: int("guestCount").default(0),
  totalBudget: decimal("totalBudget", { precision: 10, scale: 2 }),
  style: varchar("style", { length: 64 }),
  colorPalette: varchar("colorPalette", { length: 128 }),
  notes: text("notes"),
  miniSiteSlug: varchar("miniSiteSlug", { length: 64 }).unique(),
  miniSiteEnabled: boolean("miniSiteEnabled").default(false),
  miniSiteContent: text("miniSiteContent"),
  miniSiteWelcomeMsg: text("miniSiteWelcomeMsg"),
  miniSiteThemeColor: varchar("miniSiteThemeColor", { length: 32 }),
  miniSiteDressCode: text("miniSiteDressCode"),
  miniSiteTransportInfo: text("miniSiteTransportInfo"),
  miniSiteAccommodation: text("miniSiteAccommodation"),
  miniSiteShowTimeline: boolean("miniSiteShowTimeline").default(true),
  miniSiteShowPhotos: boolean("miniSiteShowPhotos").default(true),
  miniSiteShowRsvp: boolean("miniSiteShowRsvp").default(true),
  miniSiteShowMap: boolean("miniSiteShowMap").default(true),
  miniSiteShowPractical: boolean("miniSiteShowPractical").default(true),
  // Rappels programmés — task UIDs des crons Heartbeat
  reminderJ30TaskUid: varchar("reminderJ30TaskUid", { length: 65 }),
  reminderJ7TaskUid: varchar("reminderJ7TaskUid", { length: 65 }),
  reminderJ1TaskUid: varchar("reminderJ1TaskUid", { length: 65 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Wedding = typeof weddings.$inferSelect;
export type InsertWedding = typeof weddings.$inferInsert;

// ─── Timeline Events ─────────────────────────────────────────────────────────
export const timelineEvents = mysqlTable("timeline_events", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", [
    "ceremony", "reception", "preparation", "photo", "transport",
    "dinner", "entertainment", "administrative", "other"
  ]).default("other").notNull(),
  scheduledAt: timestamp("scheduledAt"),
  durationMinutes: int("durationMinutes").default(60),
  status: mysqlEnum("status", ["pending", "confirmed", "done", "cancelled"]).default("pending").notNull(),
  providerId: int("providerId"),
  location: text("location"),
  notes: text("notes"),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TimelineEvent = typeof timelineEvents.$inferSelect;
export type InsertTimelineEvent = typeof timelineEvents.$inferInsert;

// ─── Budget Items ─────────────────────────────────────────────────────────────
export const budgetItems = mysqlTable("budget_items", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  category: mysqlEnum("category", [
    "venue", "catering", "photography", "videography", "music",
    "flowers", "dress", "suit", "rings", "transport", "accommodation",
    "invitations", "decoration", "beauty", "honeymoon", "other"
  ]).default("other").notNull(),
  label: varchar("label", { length: 256 }).notNull(),
  estimatedAmount: decimal("estimatedAmount", { precision: 10, scale: 2 }).default("0"),
  actualAmount: decimal("actualAmount", { precision: 10, scale: 2 }),
  paid: boolean("paid").default(false),
  providerId: int("providerId"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BudgetItem = typeof budgetItems.$inferSelect;
export type InsertBudgetItem = typeof budgetItems.$inferInsert;

// ─── Providers ───────────────────────────────────────────────────────────────
export const providers = mysqlTable("providers", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  userId: int("userId"),
  name: varchar("name", { length: 256 }).notNull(),
  category: mysqlEnum("category", [
    "photographer", "videographer", "caterer", "florist", "music",
    "venue", "transport", "beauty", "dress", "suit", "cake",
    "animation", "officiant", "other"
  ]).default("other").notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  website: text("website"),
  city: varchar("city", { length: 128 }),
  priceRange: varchar("priceRange", { length: 64 }),
  status: mysqlEnum("status", ["shortlisted", "contacted", "quote_received", "booked", "cancelled"]).default("shortlisted").notNull(),
  rating: int("rating"),
  notes: text("notes"),
  contractUrl: text("contractUrl"),
  quoteAmount: decimal("quoteAmount", { precision: 10, scale: 2 }),
  bookedAt: timestamp("bookedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Provider = typeof providers.$inferSelect;
export type InsertProvider = typeof providers.$inferInsert;

// ─── Guests ──────────────────────────────────────────────────────────────────
export const guests = mysqlTable("guests", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  firstName: varchar("firstName", { length: 128 }).notNull(),
  lastName: varchar("lastName", { length: 128 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  group: varchar("group", { length: 64 }),
  side: mysqlEnum("side", ["partner1", "partner2", "both"]).default("both"),
  rsvpToken: varchar("rsvpToken", { length: 64 }).unique(),
  rsvpStatus: mysqlEnum("rsvpStatus", ["pending", "confirmed", "declined", "maybe"]).default("pending").notNull(),
  plusOne: boolean("plusOne").default(false),
  plusOneName: varchar("plusOneName", { length: 256 }),
  dietaryRestrictions: text("dietaryRestrictions"),
  tableNumber: int("tableNumber"),
  notes: text("notes"),
  rsvpRespondedAt: timestamp("rsvpRespondedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Guest = typeof guests.$inferSelect;
export type InsertGuest = typeof guests.$inferInsert;

// ─── Documents ───────────────────────────────────────────────────────────────
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId"),
  name: varchar("name", { length: 256 }).notNull(),
  type: mysqlEnum("type", ["contract", "quote", "invoice", "photo", "other"]).default("other").notNull(),
  fileKey: text("fileKey"),
  fileUrl: text("fileUrl"),
  mimeType: varchar("mimeType", { length: 128 }),
  fileSize: int("fileSize"),
  signed: boolean("signed").default(false),
  signedAt: timestamp("signedAt"),
  signatureData: text("signatureData"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

// ─── Memories ────────────────────────────────────────────────────────────────
export const memories = mysqlTable("memories", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  content: text("content"),
  emotion: mysqlEnum("emotion", ["joy", "love", "excitement", "gratitude", "nostalgia", "other"]).default("other"),
  mediaUrl: text("mediaUrl"),
  mediaKey: text("mediaKey"),
  mediaType: mysqlEnum("mediaType", ["photo", "video", "audio", "note"]).default("note"),
  eventDate: timestamp("eventDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Memory = typeof memories.$inferSelect;
export type InsertMemory = typeof memories.$inferInsert;

// ─── Chat Messages ────────────────────────────────────────────────────────────
export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  propagatedModules: text("propagatedModules"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

// ─── Day-Of Events ────────────────────────────────────────────────────────────
export const dayOfEvents = mysqlTable("day_of_events", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  timelineEventId: int("timelineEventId"),
  title: varchar("title", { length: 256 }).notNull(),
  scheduledTime: timestamp("scheduledTime").notNull(),
  actualTime: timestamp("actualTime"),
  delayMinutes: int("delayMinutes").default(0),
  status: mysqlEnum("status", ["upcoming", "in_progress", "done", "delayed"]).default("upcoming").notNull(),
  notifiedProviders: boolean("notifiedProviders").default(false),
  notes: text("notes"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DayOfEvent = typeof dayOfEvents.$inferSelect;
export type InsertDayOfEvent = typeof dayOfEvents.$inferInsert;

// ─── Photo Wall ───────────────────────────────────────────────────────────────
export const photoWallPhotos = mysqlTable("photo_wall_photos", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  uploadedByGuestId: int("uploadedByGuestId"),
  uploaderName: varchar("uploaderName", { length: 128 }),
  fileKey: text("fileKey").notNull(),
  fileUrl: text("fileUrl").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  aiScore: decimal("aiScore", { precision: 5, scale: 2 }),
  aiApproved: boolean("aiApproved").default(false),
  aiRejectionReason: text("aiRejectionReason"),
  featured: boolean("featured").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PhotoWallPhoto = typeof photoWallPhotos.$inferSelect;
export type InsertPhotoWallPhoto = typeof photoWallPhotos.$inferInsert;

// ─── Provider Invitations (portail prestataire) ───────────────────────────────
export const providerInvitations = mysqlTable("provider_invitations", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId").notNull(),
  token: varchar("token", { length: 64 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  accepted: boolean("accepted").default(false),
  acceptedAt: timestamp("acceptedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProviderInvitation = typeof providerInvitations.$inferSelect;
export type InsertProviderInvitation = typeof providerInvitations.$inferInsert;

// ─── Provider Profiles (espace prestataire post-acceptation) ─────────────────
export const providerProfiles = mysqlTable("provider_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  providerId: int("providerId"),
  businessName: varchar("businessName", { length: 256 }),
  bio: text("bio"),
  category: mysqlEnum("category", [
    "photographer", "videographer", "caterer", "florist", "music",
    "venue", "transport", "beauty", "dress", "suit", "cake",
    "animation", "officiant", "other"
  ]).default("other"),
  city: varchar("city", { length: 128 }),
  phone: varchar("phone", { length: 32 }),
  email: varchar("email", { length: 320 }),
  website: text("website"),
  instagram: varchar("instagram", { length: 128 }),
  avatarUrl: text("avatarUrl"),
  coverUrl: text("coverUrl"),
  basePrice: decimal("basePrice", { precision: 10, scale: 2 }),
  currency: varchar("currency", { length: 8 }).default("EUR"),
  ibanLast4: varchar("ibanLast4", { length: 4 }),
  ibanHolder: varchar("ibanHolder", { length: 256 }),
  ibanFull: text("ibanFull"),
  stripeAccountId: varchar("stripeAccountId", { length: 128 }),
  availabilityNotes: text("availabilityNotes"),
  tags: text("tags"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProviderProfile = typeof providerProfiles.$inferSelect;
export type InsertProviderProfile = typeof providerProfiles.$inferInsert;

// ─── Provider Sessions (auth token pour l'espace prestataire) ────────────────
export const providerSessions = mysqlTable("provider_sessions", {
  id: int("id").autoincrement().primaryKey(),
  invitationId: int("invitationId").notNull(),
  providerId: int("providerId").notNull(),
  weddingId: int("weddingId").notNull(),
  sessionToken: varchar("sessionToken", { length: 128 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProviderSession = typeof providerSessions.$inferSelect;
export type InsertProviderSession = typeof providerSessions.$inferInsert;

// ─── Provider Contracts (contrats avec signature électronique) ───────────────
export const providerContracts = mysqlTable("provider_contracts", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  content: text("content"),
  fileKey: text("fileKey"),
  fileUrl: text("fileUrl"),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  depositAmount: decimal("depositAmount", { precision: 10, scale: 2 }),
  depositPaid: boolean("depositPaid").default(false),
  depositPaidAt: timestamp("depositPaidAt"),
  balancePaid: boolean("balancePaid").default(false),
  balancePaidAt: timestamp("balancePaidAt"),
  status: mysqlEnum("status", ["draft", "sent", "signed_provider", "signed_couple", "fully_signed", "cancelled"]).default("draft").notNull(),
  providerSignatureData: text("providerSignatureData"),
  providerSignedAt: timestamp("providerSignedAt"),
  providerSignerName: varchar("providerSignerName", { length: 256 }),
  coupleSignatureData: text("coupleSignatureData"),
  coupleSignedAt: timestamp("coupleSignedAt"),
  coupleSignerName: varchar("coupleSignerName", { length: 256 }),
  signatureIpProvider: varchar("signatureIpProvider", { length: 64 }),
  signatureIpCouple: varchar("signatureIpCouple", { length: 64 }),
  validUntil: timestamp("validUntil"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProviderContract = typeof providerContracts.$inferSelect;
export type InsertProviderContract = typeof providerContracts.$inferInsert;

// ─── Provider Missions (prestations assignées) ────────────────────────────────
export const providerMissions = mysqlTable("provider_missions", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId").notNull(),
  contractId: int("contractId"),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  scheduledAt: timestamp("scheduledAt"),
  durationMinutes: int("durationMinutes").default(60),
  location: text("location"),
  status: mysqlEnum("status", ["pending", "confirmed", "in_progress", "done", "cancelled"]).default("pending").notNull(),
  providerNotes: text("providerNotes"),
  coupleNotes: text("coupleNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProviderMission = typeof providerMissions.$inferSelect;
export type InsertProviderMission = typeof providerMissions.$inferInsert;

// ─── Onboarding Sessions (assistant conversationnel) ────────────────────────────
export const onboardingSessions = mysqlTable("onboarding_sessions", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  userId: int("userId").notNull(),
  currentStep: int("currentStep").default(0).notNull(),
  totalSteps: int("totalSteps").default(12).notNull(),
  answers: text("answers"), // JSON
  completed: boolean("completed").default(false),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OnboardingSession = typeof onboardingSessions.$inferSelect;
export type InsertOnboardingSession = typeof onboardingSessions.$inferInsert;

// ─── Email Campaigns (emails groupés personnalisés) ───────────────────────────
export const emailCampaigns = mysqlTable("email_campaigns", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  type: mysqlEnum("type", ["save_the_date", "invitation", "rsvp_reminder", "practical_info", "thank_you", "custom"]).default("custom").notNull(),
  subject: varchar("subject", { length: 256 }).notNull(),
  bodyTemplate: text("bodyTemplate").notNull(), // Template avec {{prenom}}, {{lien_rsvp}}, etc.
  status: mysqlEnum("status", ["draft", "scheduled", "sending", "sent", "failed"]).default("draft").notNull(),
  recipientFilter: mysqlEnum("recipientFilter", ["all", "confirmed", "pending", "declined", "no_response"]).default("all").notNull(),
  scheduledAt: timestamp("scheduledAt"),
  sentAt: timestamp("sentAt"),
  totalRecipients: int("totalRecipients").default(0),
  sentCount: int("sentCount").default(0),
  openCount: int("openCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EmailCampaign = typeof emailCampaigns.$inferSelect;
export type InsertEmailCampaign = typeof emailCampaigns.$inferInsert;

// ─── Email Logs (suivi par invité) ───────────────────────────────────────────────────
export const emailLogs = mysqlTable("email_logs", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  guestId: int("guestId"),
  recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
  recipientName: varchar("recipientName", { length: 256 }),
  personalizedSubject: varchar("personalizedSubject", { length: 256 }),
  personalizedBody: text("personalizedBody"),
  status: mysqlEnum("status", ["pending", "sent", "failed", "opened"]).default("pending").notNull(),
  sentAt: timestamp("sentAt"),
  openedAt: timestamp("openedAt"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmailLog = typeof emailLogs.$inferSelect;
export type InsertEmailLog = typeof emailLogs.$inferInsert;

// ─── AI Guide Tasks (guide d'organisation priorisé) ──────────────────────────
export const aiGuideTasks = mysqlTable("ai_guide_tasks", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", [
    "venue", "catering", "photography", "music", "flowers",
    "dress", "legal", "invitations", "transport", "honeymoon", "other"
  ]).default("other").notNull(),
  priority: mysqlEnum("priority", ["urgent", "high", "medium", "low"]).default("medium").notNull(),
  recommendedMonthsBefore: int("recommendedMonthsBefore").default(6),
  deadline: timestamp("deadline"),
  status: mysqlEnum("status", ["todo", "in_progress", "done", "skipped"]).default("todo").notNull(),
  aiGenerated: boolean("aiGenerated").default(true),
  linkedModule: varchar("linkedModule", { length: 64 }),
  sortOrder: int("sortOrder").default(0),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AiGuideTask = typeof aiGuideTasks.$inferSelect;
export type InsertAiGuideTask = typeof aiGuideTasks.$inferInsert;

// ─── Provider Matches (matching prestataire prédictif IA) ──────────────────────
export const providerMatches = mysqlTable("provider_matches", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  category: mysqlEnum("category", [
    "photographer", "videographer", "caterer", "florist", "music",
    "venue", "transport", "beauty", "dress", "suit", "cake",
    "animation", "officiant", "other"
  ]).default("other").notNull(),
  suggestedName: varchar("suggestedName", { length: 256 }).notNull(),
  suggestedCity: varchar("suggestedCity", { length: 128 }),
  suggestedEmail: varchar("suggestedEmail", { length: 320 }),
  suggestedWebsite: text("suggestedWebsite"),
  compatibilityScore: int("compatibilityScore").default(0), // 0-100
  justification: text("justification"),
  estimatedPrice: varchar("estimatedPrice", { length: 64 }),
  status: mysqlEnum("status", ["suggested", "contacted", "added", "dismissed"]).default("suggested").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProviderMatch = typeof providerMatches.$inferSelect;
export type InsertProviderMatch = typeof providerMatches.$inferInsert;

// ─── Narrative Memories (récit littéraire généré par l'IA) ───────────────────────
export const narrativeMemories = mysqlTable("narrative_memories", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  version: int("version").default(1).notNull(),
  narrative: text("narrative").notNull(),
  style: mysqlEnum("style", ["romantic", "poetic", "humorous", "classic"]).default("romantic").notNull(),
  approved: boolean("approved").default(false),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NarrativeMemory = typeof narrativeMemories.$inferSelect;
export type InsertNarrativeMemory = typeof narrativeMemories.$inferInsert;

// ─── Seating Plan (plan de table) ────────────────────────────────────────────
export const seatingTables = mysqlTable("seating_tables", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  shape: mysqlEnum("shape", ["round", "rectangular", "square"]).default("round").notNull(),
  capacity: int("capacity").default(8).notNull(),
  positionX: int("positionX").default(0),
  positionY: int("positionY").default(0),
  colorHex: varchar("colorHex", { length: 16 }).default("#F07167"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type SeatingTable = typeof seatingTables.$inferSelect;
export type InsertSeatingTable = typeof seatingTables.$inferInsert;

export const seatingAssignments = mysqlTable("seating_assignments", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  tableId: int("tableId").notNull(),
  guestId: int("guestId").notNull(),
  seatNumber: int("seatNumber"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type SeatingAssignment = typeof seatingAssignments.$inferSelect;
export type InsertSeatingAssignment = typeof seatingAssignments.$inferInsert;

// ─── Subscriptions (abonnements Stripe) ──────────────────────────────────────
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 128 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 128 }),
  plan: mysqlEnum("plan", ["free", "essentiel", "premium", "prestige"]).default("free").notNull(),
  status: mysqlEnum("status", ["active", "canceled", "past_due", "trialing", "incomplete"]).default("active").notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

// ─── Provider Notifications (notifications prestataires) ─────────────────────
export const providerNotifications = mysqlTable("provider_notifications", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId").notNull(),
  type: mysqlEnum("type", ["invitation_accepted", "mission_update", "contract_signed", "payment_received", "message"]).notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ProviderNotification = typeof providerNotifications.$inferSelect;
export type InsertProviderNotification = typeof providerNotifications.$inferInsert;

// ─── Push Subscriptions (notifications push navigateur) ──────────────────────
export const pushSubscriptions = mysqlTable("push_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: varchar("userId", { length: 128 }).notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  userAgent: varchar("userAgent", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PushSubscription = typeof pushSubscriptions.$inferSelect;
export type InsertPushSubscription = typeof pushSubscriptions.$inferInsert;
