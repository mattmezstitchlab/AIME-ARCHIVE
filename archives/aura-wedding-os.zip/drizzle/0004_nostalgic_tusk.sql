CREATE TABLE `ai_guide_tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`title` varchar(256) NOT NULL,
	`description` text,
	`category` enum('venue','catering','photography','music','flowers','dress','legal','invitations','transport','honeymoon','other') NOT NULL DEFAULT 'other',
	`priority` enum('urgent','high','medium','low') NOT NULL DEFAULT 'medium',
	`recommendedMonthsBefore` int DEFAULT 6,
	`deadline` timestamp,
	`status` enum('todo','in_progress','done','skipped') NOT NULL DEFAULT 'todo',
	`aiGenerated` boolean DEFAULT true,
	`linkedModule` varchar(64),
	`sortOrder` int DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ai_guide_tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `email_campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`type` enum('save_the_date','invitation','rsvp_reminder','practical_info','thank_you','custom') NOT NULL DEFAULT 'custom',
	`subject` varchar(256) NOT NULL,
	`bodyTemplate` text NOT NULL,
	`status` enum('draft','scheduled','sending','sent','failed') NOT NULL DEFAULT 'draft',
	`recipientFilter` enum('all','confirmed','pending','declined','no_response') NOT NULL DEFAULT 'all',
	`scheduledAt` timestamp,
	`sentAt` timestamp,
	`totalRecipients` int DEFAULT 0,
	`sentCount` int DEFAULT 0,
	`openCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `email_campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `email_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`guestId` int,
	`recipientEmail` varchar(320) NOT NULL,
	`recipientName` varchar(256),
	`personalizedSubject` varchar(256),
	`personalizedBody` text,
	`status` enum('pending','sent','failed','opened') NOT NULL DEFAULT 'pending',
	`sentAt` timestamp,
	`openedAt` timestamp,
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `email_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `narrative_memories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`version` int NOT NULL DEFAULT 1,
	`narrative` text NOT NULL,
	`style` enum('romantic','poetic','humorous','classic') NOT NULL DEFAULT 'romantic',
	`approved` boolean DEFAULT false,
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `narrative_memories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `onboarding_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`userId` int NOT NULL,
	`currentStep` int NOT NULL DEFAULT 0,
	`totalSteps` int NOT NULL DEFAULT 12,
	`answers` text,
	`completed` boolean DEFAULT false,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `onboarding_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `provider_matches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`category` enum('photographer','videographer','caterer','florist','music','venue','transport','beauty','dress','suit','cake','animation','officiant','other') NOT NULL DEFAULT 'other',
	`suggestedName` varchar(256) NOT NULL,
	`suggestedCity` varchar(128),
	`suggestedEmail` varchar(320),
	`suggestedWebsite` text,
	`compatibilityScore` int DEFAULT 0,
	`justification` text,
	`estimatedPrice` varchar(64),
	`status` enum('suggested','contacted','added','dismissed') NOT NULL DEFAULT 'suggested',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `provider_matches_id` PRIMARY KEY(`id`)
);
