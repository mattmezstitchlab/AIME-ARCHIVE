import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import {
  Check,
  Crown,
  Sparkles,
  Star,
  Heart,
  ArrowLeft,
  Zap,
  Shield,
  ExternalLink,
  X,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { Link, useLocation } from "wouter";

// ─── Plans AURA ───────────────────────────────────────────────────────────────
const PLANS = [
  {
    id: "free",
    name: "Gratuit",
    price: 0,
    period: "",
    description: "Pour découvrir AURA et commencer à organiser votre mariage.",
    color: "#aab5c8",
    icon: Heart,
    badge: null,
    features: [
      "Cockpit Mariés complet",
      "IA AURA (10 messages/jour)",
      "Jusqu'à 50 invités",
      "Mini-site basique",
      "Timeline & Budget",
      "Portail RSVP",
    ],
    limitations: [
      "IA limitée à 10 messages/jour",
      "50 invités maximum",
      "5 documents maximum",
    ],
  },
  {
    id: "essentiel",
    name: "Essentiel",
    price: 19,
    period: "/mois",
    description: "Pour les mariés qui veulent une organisation sans stress.",
    color: "#60B4C8",
    icon: Sparkles,
    badge: null,
    features: [
      "Tout du plan Gratuit",
      "IA AURA illimitée",
      "Jusqu'à 150 invités",
      "Mini-site personnalisé",
      "Emails groupés (500/mois)",
      "Plan de table drag & drop",
      "Export PDF timeline",
      "Support par email",
    ],
    limitations: [],
  },
  {
    id: "premium",
    name: "Premium",
    price: 39,
    period: "/mois",
    description: "La solution complète pour un mariage parfaitement orchestré.",
    color: "#F07167",
    icon: Star,
    badge: "Le plus populaire",
    features: [
      "Tout du plan Essentiel",
      "Invités illimités",
      "Matching prestataire IA",
      "Signature électronique",
      "Coordination Jour J temps réel",
      "Mur photo IA",
      "Mémoire narrative IA",
      "Analyseur de devis IA",
      "Support prioritaire",
    ],
    limitations: [],
  },
  {
    id: "prestige",
    name: "Prestige",
    price: 79,
    period: "/mois",
    description: "L'expérience ultime pour un mariage d'exception.",
    color: "#9B59B6",
    icon: Crown,
    badge: "Exclusif",
    features: [
      "Tout du plan Premium",
      "Wedding planner IA dédié",
      "Onboarding personnalisé 1h",
      "Livre souvenir IA offert",
      "Accès anticipé aux nouveautés",
      "Support téléphonique 7j/7",
      "Domaine personnalisé mini-site",
      "Rapport post-mariage complet",
    ],
    limitations: [],
  },
];

// ─── Composant Carte Plan ─────────────────────────────────────────────────────
function PlanCard({
  plan,
  currentPlan,
  onSubscribe,
  isLoading,
}: {
  plan: (typeof PLANS)[0];
  currentPlan: string;
  onSubscribe: (planId: string) => void;
  isLoading: boolean;
}) {
  const isActive = currentPlan === plan.id;
  const isPremium = plan.id === "premium";
  const Icon = plan.icon;

  return (
    <div
      className="relative flex flex-col rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1"
      style={{
        background: "#E8EDF2",
        boxShadow: isPremium
          ? `0 8px 32px rgba(240,113,103,0.25), 6px 6px 12px #c8cdd2, -6px -6px 12px #ffffff`
          : `6px 6px 12px #c8cdd2, -6px -6px 12px #ffffff`,
        border: isPremium ? `2px solid ${plan.color}` : "2px solid transparent",
      }}
    >
      {/* Badge */}
      {plan.badge && (
        <div
          className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold text-white"
          style={{ background: plan.color }}
        >
          {plan.badge}
        </div>
      )}

      {/* Header */}
      <div className="p-6 pb-4">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
          style={{ background: `${plan.color}20` }}
        >
          <Icon size={24} style={{ color: plan.color }} />
        </div>
        <h3
          className="text-xl font-bold mb-1"
          style={{ fontFamily: "Playfair Display, serif", color: "#4a5568" }}
        >
          {plan.name}
        </h3>
        <p className="text-sm text-gray-500 mb-4">{plan.description}</p>

        {/* Prix */}
        <div className="flex items-end gap-1 mb-1">
          <span
            className="text-4xl font-bold"
            style={{ color: plan.price === 0 ? "#aab5c8" : plan.color }}
          >
            {plan.price === 0 ? "0€" : `${plan.price}€`}
          </span>
          {plan.period && (
            <span className="text-gray-500 text-sm mb-1">{plan.period}</span>
          )}
        </div>
        {plan.price > 0 && (
          <p className="text-xs text-gray-400">Soit {(plan.price * 12).toFixed(0)}€/an · Résiliable à tout moment</p>
        )}
      </div>

      {/* Séparateur */}
      <div className="mx-6 h-px" style={{ background: "rgba(0,0,0,0.06)" }} />

      {/* Features */}
      <div className="p-6 flex-1">
        <ul className="space-y-2.5">
          {plan.features.map((feature) => (
            <li key={feature} className="flex items-start gap-2.5">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ background: `${plan.color}20` }}
              >
                <Check size={11} style={{ color: plan.color }} strokeWidth={3} />
              </div>
              <span className="text-sm text-gray-600">{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* CTA */}
      <div className="p-6 pt-0">
        {isActive ? (
          <div
            className="w-full py-3 rounded-xl text-center text-sm font-semibold"
            style={{ background: `${plan.color}20`, color: plan.color }}
          >
            ✓ Plan actuel
          </div>
        ) : plan.id === "free" ? (
          <Link href="/cockpit">
            <button
              className="w-full py-3 rounded-xl text-sm font-semibold transition-all"
              style={{
                background: "#E8EDF2",
                color: "#aab5c8",
                boxShadow: "3px 3px 6px #c8cdd2, -3px -3px 6px #ffffff",
              }}
            >
              Commencer gratuitement
            </button>
          </Link>
        ) : (
          <button
            onClick={() => onSubscribe(plan.id)}
            disabled={isLoading}
            className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90 active:scale-95"
            style={{
              background: plan.color,
              boxShadow: `0 4px 16px ${plan.color}40`,
            }}
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Redirection…
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <ExternalLink size={14} />
                Choisir {plan.name}
              </span>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function PaymentResultModal({ type, onClose }: { type: "success" | "cancel"; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.4)" }}>
      <div className="neu-card p-8 max-w-md w-full text-center relative" style={{ background: "#E8EDF2" }}>
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
          <X size={16} className="text-gray-500" />
        </button>
        {type === "success" ? (
          <>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "rgba(123,196,127,0.15)" }}>
              <CheckCircle size={32} style={{ color: "#7BC47F" }} />
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: "Playfair Display, serif", color: "#4a5568" }}>Paiement réussi !</h2>
            <p className="text-gray-500 mb-6">Votre abonnement est maintenant actif. Toutes les fonctionnalités de votre plan sont désormais disponibles dans votre Cockpit AURA.</p>
            <Link href="/cockpit">
              <button className="w-full py-3 rounded-xl text-white font-semibold" style={{ background: "#F07167" }} onClick={onClose}>
                Accéder à mon Cockpit
              </button>
            </Link>
          </>
        ) : (
          <>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "rgba(240,113,103,0.1)" }}>
              <AlertCircle size={32} style={{ color: "#F07167" }} />
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: "Playfair Display, serif", color: "#4a5568" }}>Paiement annulé</h2>
            <p className="text-gray-500 mb-6">Votre paiement a été annulé. Aucun montant n'a été débité. Vous pouvez réessayer à tout moment.</p>
            <button onClick={onClose} className="w-full py-3 rounded-xl font-semibold neu-btn" style={{ color: "#F07167" }}>
              Retour aux tarifs
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Page Tarifs ───────────────────────────────────────────────────────────────────────────────
export default function Pricing() {
  const { user } = useAuth();
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [paymentResult, setPaymentResult] = useState<"success" | "cancel" | null>(null);
  const [, setLocation] = useLocation();

  // Détecter le retour de Stripe (paramètres ?success=1 ou ?cancel=1)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("success") === "1") {
      setPaymentResult("success");
      // Nettoyer l'URL sans rechargement
      window.history.replaceState({}, "", "/tarifs");
    } else if (params.get("cancel") === "1") {
      setPaymentResult("cancel");
      window.history.replaceState({}, "", "/tarifs");
    }
  }, []);

  const { data: currentSub } = trpc.subscriptions.getCurrent.useQuery(undefined, {
    enabled: !!user,
  });

  const createCheckout = trpc.subscriptions.createCheckout.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) {
        toast.info("Redirection vers le paiement sécurisé…");
        window.open(data.checkoutUrl, "_blank");
      }
      setLoadingPlan(null);
    },
    onError: (err) => {
      toast.error("Erreur lors de la création du paiement : " + err.message);
      setLoadingPlan(null);
    },
  });

  const createPortal = trpc.subscriptions.createPortal.useMutation({
    onSuccess: (data) => {
      if (data.portalUrl) {
        window.open(data.portalUrl, "_blank");
      }
    },
    onError: () => toast.error("Impossible d'accéder au portail de gestion."),
  });

  const handleSubscribe = (planId: string) => {
    if (!user) {
      toast.error("Connectez-vous pour souscrire à un abonnement.");
      return;
    }
    setLoadingPlan(planId);
    createCheckout.mutate({
      plan: planId as "essentiel" | "premium" | "prestige",
      origin: window.location.origin,
      successUrl: `${window.location.origin}/tarifs?success=1`,
      cancelUrl: `${window.location.origin}/tarifs?cancel=1`,
    });
  };

  const currentPlan = currentSub?.plan ?? "free";

  return (
    <div className="min-h-screen" style={{ background: "#E8EDF2" }}>
      {/* Modal confirmation/annulation paiement */}
      {paymentResult && (
        <PaymentResultModal type={paymentResult} onClose={() => setPaymentResult(null)} />
      )}
      {/* Header */}
      <div className="px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Link href="/cockpit">
              <button className="neu-btn p-2">
                <ArrowLeft size={18} style={{ color: "#F07167" }} />
              </button>
            </Link>
          </div>

          {/* Hero */}
          <div className="text-center mb-12">
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6"
              style={{ background: "rgba(240,113,103,0.1)", color: "#F07167" }}
            >
              <Zap size={14} />
              Plans & Tarifs AURA
            </div>
            <h1
              className="text-4xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: "Playfair Display, serif", color: "#4a5568" }}
            >
              Votre mariage mérite
              <br />
              <span style={{ color: "#F07167" }}>le meilleur</span>
            </h1>
            <p className="text-lg text-gray-500 max-w-xl mx-auto">
              Choisissez le plan qui correspond à votre vision. Tous les plans incluent un accès complet au cockpit mariés et à l'IA AURA.
            </p>
          </div>

          {/* Grille des plans */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-12">
            {PLANS.map((plan) => (
              <PlanCard
                key={plan.id}
                plan={plan}
                currentPlan={currentPlan}
                onSubscribe={handleSubscribe}
                isLoading={loadingPlan === plan.id}
              />
            ))}
          </div>

          {/* Gestion abonnement actif */}
          {currentSub && currentSub.plan !== "free" && currentSub.stripeCustomerId && (
            <div className="neu-card p-6 text-center mb-8">
              <p className="text-gray-600 mb-3">
                Vous êtes actuellement abonné au plan{" "}
                <strong style={{ color: "#F07167" }}>
                  {currentSub.plan.charAt(0).toUpperCase() + currentSub.plan.slice(1)}
                </strong>.
              </p>
              <button
                onClick={() => createPortal.mutate({ origin: window.location.origin })}
                disabled={createPortal.isPending}
                className="neu-btn px-6 py-2 text-sm font-medium flex items-center gap-2 mx-auto"
                style={{ color: "#F07167" }}
              >
                <Shield size={14} />
                Gérer mon abonnement
              </button>
            </div>
          )}

          {/* FAQ / Garanties */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: Shield,
                title: "Paiement sécurisé",
                desc: "Transactions chiffrées via Stripe. Aucune donnée bancaire stockée sur nos serveurs.",
              },
              {
                icon: Zap,
                title: "Activation immédiate",
                desc: "Votre plan est activé instantanément après le paiement. Accès complet en quelques secondes.",
              },
              {
                icon: Heart,
                title: "Sans engagement",
                desc: "Résiliez à tout moment depuis votre espace client. Aucun frais caché.",
              },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="neu-card p-5 text-center">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-3"
                  style={{ background: "rgba(240,113,103,0.1)" }}
                >
                  <Icon size={20} style={{ color: "#F07167" }} />
                </div>
                <h4 className="font-semibold mb-1" style={{ color: "#4a5568" }}>{title}</h4>
                <p className="text-sm text-gray-500">{desc}</p>
              </div>
            ))}
          </div>

          {/* Note test Stripe */}
          <div
            className="mt-8 p-4 rounded-xl text-sm text-center"
            style={{ background: "rgba(96,180,200,0.1)", color: "#60B4C8", border: "1px solid rgba(96,180,200,0.3)" }}
          >
            <strong>Mode test Stripe actif</strong> — Utilisez la carte <code className="bg-white/50 px-1 rounded">4242 4242 4242 4242</code> avec n'importe quelle date future et CVV pour tester les paiements.
          </div>
        </div>
      </div>
    </div>
  );
}
