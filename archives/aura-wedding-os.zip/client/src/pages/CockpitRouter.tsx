import { useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Loader2, Heart } from "lucide-react";
import Cockpit from "./Cockpit";
import GuestPortal from "./GuestPortal";
import OnboardingChat from "./OnboardingChat";

/**
 * CockpitRouter — point d'entrée intelligent pour /cockpit
 * - Non connecté → redirige vers la page de login
 * - Rôle "married" → affiche le Cockpit Mariés
 * - Rôle "provider" → redirige vers le tableau de bord prestataire
 *   (le sessionToken doit être dans l'URL ou dans localStorage)
 * - Rôle "unset" → affiche l'écran de sélection de rôle
 */
export default function CockpitRouter() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const setRoleMutation = trpc.user.setRole.useMutation({
    onSuccess: () => window.location.reload(),
  });

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl();
    }
  }, [loading, isAuthenticated]);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 animate-spin mx-auto" style={{ color: "var(--coral)" }} />
          <p className="text-muted-foreground">Chargement de votre espace...</p>
        </div>
      </div>
    );
  }

  // Rôle non défini → écran de sélection
  if (user.userRole === "unset" || !user.userRole) {
    return <RoleSelector onSelect={(role) => setRoleMutation.mutate({ userRole: role })} isPending={setRoleMutation.isPending} />;
  }

  // Prestataire → redirection vers dashboard (avec token stocké en localStorage si disponible)
  if (user.userRole === "provider") {
    const storedToken = localStorage.getItem("aura_provider_token");
    if (storedToken) {
      setLocation(`/provider/dashboard?token=${storedToken}`);
      return null;
    }
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--neu-bg)" }}>
        <div className="neu-card p-10 max-w-md text-center space-y-4">
          <Heart className="w-12 h-12 mx-auto" style={{ color: "var(--coral)" }} />
          <h2 className="text-xl font-bold">Espace Prestataire</h2>
          <p className="text-muted-foreground">
            Pour accéder à votre espace prestataire, utilisez le lien d'invitation envoyé par les mariés.
          </p>
          <p className="text-sm text-muted-foreground">
            Vous n'avez pas reçu de lien ? Contactez directement les mariés pour qu'ils vous envoient une invitation depuis leur cockpit.
          </p>
        </div>
      </div>
    );
  }

  // Invité → Redirection vers /portail-invite (route dédiée)
  if (user.userRole === "guest") {
    setLocation("/portail-invite");
    return null;
  }

  // Mariés → Vérifier si onboarding nécessaire
  return <CockpitOrOnboarding />;
}

function CockpitOrOnboarding() {
  const { data: wedding, isLoading } = trpc.wedding.get.useQuery();
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
        <Loader2 className="w-10 h-10 animate-spin" style={{ color: "var(--coral)" }} />
      </div>
    );
  }
  // Si aucun mariage configuré, lancer l'onboarding
  if (!wedding || (!wedding.weddingDate && !wedding.venue && !wedding.partner1Name)) {
    return <OnboardingChat />;
  }
  return <Cockpit />;
}

// ─── Role Selector ────────────────────────────────────────────────────────────
function RoleSelector({
  onSelect, isPending,
}: {
  onSelect: (role: "married" | "guest" | "provider") => void;
  isPending: boolean;
}) {
  const roles = [
    {
      id: "married" as const,
      icon: "💍",
      title: "Je me marie",
      desc: "Accédez au cockpit complet : planification, budget, prestataires, invités, IA AURA.",
      color: "#F07167",
    },
    {
      id: "guest" as const,
      icon: "🎉",
      title: "Je suis invité(e)",
      desc: "Confirmez votre présence, accédez au programme et partagez des photos.",
      color: "#7BC47F",
    },
    {
      id: "provider" as const,
      icon: "🏢",
      title: "Je suis prestataire",
      desc: "Gérez vos missions, contrats et paiements pour les mariages qui vous ont invité.",
      color: "#C4A87B",
    },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>
      <div className="w-full max-w-2xl">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6"
            style={{ background: "linear-gradient(135deg, var(--coral-light), var(--coral))" }}>
            <Heart className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black mb-3">Bienvenue sur AURA</h1>
          <p className="text-muted-foreground text-lg">Qui êtes-vous ? Choisissez votre espace.</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          {roles.map(role => (
            <button
              key={role.id}
              onClick={() => onSelect(role.id)}
              disabled={isPending}
              className="neu-card p-6 text-left transition-all hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ cursor: "pointer" }}
            >
              <div className="text-4xl mb-4">{role.icon}</div>
              <h3 className="font-bold text-lg mb-2" style={{ color: role.color }}>{role.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{role.desc}</p>
            </button>
          ))}
        </div>

        {isPending && (
          <div className="text-center mt-6">
            <Loader2 className="w-6 h-6 animate-spin mx-auto" style={{ color: "var(--coral)" }} />
            <p className="text-sm text-muted-foreground mt-2">Création de votre espace...</p>
          </div>
        )}
      </div>
    </div>
  );
}
