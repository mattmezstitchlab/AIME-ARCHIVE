import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import {
  Heart, Clock, MapPin, Shirt, Car, Hotel, Camera,
  Loader2, ExternalLink, ChevronDown, ChevronUp, LogOut, ArrowLeft
} from "lucide-react";

/**
 * GuestPortal — Espace invité connecté post-RSVP
 * Accessible via /cockpit lorsque l'utilisateur a le rôle "guest"
 * Affiche : programme, infos pratiques, mur photo, mini-site du mariage
 */
export default function GuestPortal() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [expanded, setExpanded] = useState<string | null>("program");
  const toggle = (s: string) => setExpanded(p => p === s ? null : s);

  // Récupère le mariage associé à l'invité via son email
  const { data: guestInfo } = trpc.guests.getMyRsvp.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--coral)" }} />
    </div>
  );

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  if (!guestInfo) return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--neu-bg)" }}>
      <div className="neu-card p-10 max-w-md text-center space-y-4">
        <Heart className="w-12 h-12 mx-auto" style={{ color: "var(--coral)" }} />
        <h2 className="text-xl font-bold">Espace Invité</h2>
        <p className="text-muted-foreground">
          Vous n'êtes lié à aucun mariage pour le moment. Utilisez le lien RSVP envoyé par les mariés pour accéder à votre espace.
        </p>
        <button onClick={logout} className="text-sm text-muted-foreground hover:underline">Se déconnecter</button>
      </div>
    </div>
  );

  const { wedding, timeline, rsvpStatus } = guestInfo;
  const themeColor = (wedding as any).miniSiteThemeColor || "#F07167";
  const daysLeft = wedding.weddingDate
    ? Math.ceil((new Date(wedding.weddingDate).getTime() - Date.now()) / 86400000)
    : null;

  const Section = ({ id, icon: Icon, title, children }: {
    id: string; icon: React.ElementType; title: string; children: React.ReactNode;
  }) => (
    <div className="neu-card overflow-hidden">
      <button onClick={() => toggle(id)} className="w-full p-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: `${themeColor}20` }}>
            <Icon className="w-5 h-5" style={{ color: themeColor }} />
          </div>
          <span className="font-bold">{title}</span>
        </div>
        {expanded === id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>
      {expanded === id && <div className="px-5 pb-5">{children}</div>}
    </div>
  );

  return (
    <div className="min-h-screen" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <header className="sticky top-0 z-40 px-4 py-3 flex items-center justify-between"
        style={{ background: "var(--neu-bg)", boxShadow: "0 2px 10px rgba(0,0,0,0.05)" }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
            <Heart className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-bold text-sm">Portail Invité — {guestInfo.guestName}</p>
            <p className="text-xs text-muted-foreground">{wedding.partner1Name} & {wedding.partner2Name}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-3 py-1 rounded-full font-medium"
            style={{
              background: rsvpStatus === "confirmed" ? "#7BC47F20" : rsvpStatus === "declined" ? "#F0716720" : "#C4A87B20",
              color: rsvpStatus === "confirmed" ? "#7BC47F" : rsvpStatus === "declined" ? "#F07167" : "#C4A87B",
            }}>
            {rsvpStatus === "confirmed" ? "✓ Confirmé" : rsvpStatus === "declined" ? "✗ Décliné" : "? En attente"}
          </span>
          <button onClick={logout} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn" title="Se déconnecter">
            <LogOut className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </header>

      {/* Hero */}
      <div className="px-4 py-8 text-center"
        style={{ background: `linear-gradient(135deg, ${themeColor}10, ${themeColor}03)` }}>
        <h1 className="text-3xl font-black mb-2" style={{ fontFamily: "Playfair Display, serif" }}>
          {wedding.partner1Name} <span style={{ color: themeColor }}>&</span> {wedding.partner2Name}
        </h1>
        {wedding.weddingDate && (
          <p className="text-muted-foreground">
            {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
          </p>
        )}
        {daysLeft !== null && daysLeft > 0 && (
          <div className="inline-flex items-center gap-2 mt-4 neu-card px-6 py-3">
            <span className="text-2xl font-black" style={{ color: themeColor }}>J-{daysLeft}</span>
            <span className="text-muted-foreground text-sm">avant le grand jour</span>
          </div>
        )}
        {daysLeft === 0 && (
          <div className="inline-flex items-center gap-2 mt-4 neu-card px-6 py-3">
            <span className="text-xl font-black" style={{ color: themeColor }}>C'est aujourd'hui ! 🎉</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">

        {/* Lieu */}
        {(wedding.venue || wedding.city) && (
          <div className="neu-card p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: `${themeColor}20` }}>
              <MapPin className="w-5 h-5" style={{ color: themeColor }} />
            </div>
            <div className="flex-1">
              <p className="font-bold">{wedding.venue || "Lieu"}</p>
              {wedding.city && <p className="text-sm text-muted-foreground">{wedding.city}</p>}
              {wedding.city && (
                <a href={`https://maps.google.com/?q=${encodeURIComponent([wedding.venue, wedding.city].filter(Boolean).join(", "))}`}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs mt-1 hover:underline"
                  style={{ color: themeColor }}>
                  <ExternalLink className="w-3 h-3" /> Voir sur Maps
                </a>
              )}
            </div>
          </div>
        )}

        {/* Programme */}
        {timeline && timeline.length > 0 && (
          <Section id="program" icon={Clock} title={`Programme (${timeline.length} étapes)`}>
            <div className="space-y-3">
              {timeline.map((event: any, idx: number) => (
                <div key={event.id} className="flex items-start gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold"
                      style={{ background: `${themeColor}20`, color: themeColor }}>
                      {idx + 1}
                    </div>
                    {idx < timeline.length - 1 && (
                      <div className="w-0.5 h-5 mt-1" style={{ background: `${themeColor}30` }} />
                    )}
                  </div>
                  <div className="flex-1 pb-1">
                    <p className="font-semibold text-sm">{event.title}</p>
                    {event.scheduledAt && (
                      <p className="text-xs text-muted-foreground">
                        {new Date(event.scheduledAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                        {event.durationMinutes ? ` · ${event.durationMinutes} min` : ""}
                      </p>
                    )}
                    {event.location && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="w-3 h-3" />{event.location}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Section>
        )}

        {/* Infos pratiques */}
        {((wedding as any).miniSiteDressCode || (wedding as any).miniSiteTransportInfo || (wedding as any).miniSiteAccommodation) && (
          <Section id="practical" icon={Shirt} title="Infos pratiques">
            <div className="space-y-4">
              {(wedding as any).miniSiteDressCode && (
                <div className="flex items-start gap-3">
                  <Shirt className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: themeColor }} />
                  <div>
                    <p className="font-semibold text-sm mb-1">Dress code</p>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{(wedding as any).miniSiteDressCode}</p>
                  </div>
                </div>
              )}
              {(wedding as any).miniSiteTransportInfo && (
                <div className="flex items-start gap-3">
                  <Car className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: themeColor }} />
                  <div>
                    <p className="font-semibold text-sm mb-1">Transports</p>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{(wedding as any).miniSiteTransportInfo}</p>
                  </div>
                </div>
              )}
              {(wedding as any).miniSiteAccommodation && (
                <div className="flex items-start gap-3">
                  <Hotel className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: themeColor }} />
                  <div>
                    <p className="font-semibold text-sm mb-1">Hébergements</p>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{(wedding as any).miniSiteAccommodation}</p>
                  </div>
                </div>
              )}
            </div>
          </Section>
        )}

        {/* Mur photo */}
        {(wedding as any).miniSiteSlug && (
          <div className="neu-card p-5 text-center">
            <Camera className="w-8 h-8 mx-auto mb-3" style={{ color: themeColor }} />
            <p className="font-bold mb-1">Mur de photos</p>
            <p className="text-sm text-muted-foreground mb-3">Partagez vos photos du mariage en temps réel !</p>
            <a href={`/photowall/${(wedding as any).miniSiteSlug}`}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-white text-sm font-semibold"
              style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
              <Camera className="w-4 h-4" /> Accéder au mur de photos
            </a>
          </div>
        )}

        {/* Lien mini-site */}
        {(wedding as any).miniSiteSlug && (wedding as any).miniSiteEnabled && (
          <div className="text-center">
            <a href={`/mariage/${(wedding as any).miniSiteSlug}`}
              className="text-sm hover:underline" style={{ color: themeColor }}>
              Voir le mini-site complet du mariage →
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
