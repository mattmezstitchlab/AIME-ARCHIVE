import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function CGV() {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Retour à l'accueil
        </button>

        <h1 className="text-3xl font-black mb-2" style={{ color: "var(--coral)" }}>
          Conditions Générales de Vente
        </h1>
        <p className="text-sm text-muted-foreground mb-10">Dernière mise à jour : 11 mai 2026</p>

        <div className="space-y-8 text-sm leading-relaxed">
          <section>
            <h2 className="text-lg font-bold mb-3">1. Vendeur</h2>
            <p>
              AURA SAS, société par actions simplifiée au capital de 10 000 €, immatriculée au RCS de Paris sous le numéro 123 456 789, dont le siège social est situé au 12 rue de la Paix, 75001 Paris, France. Numéro de TVA intracommunautaire : FR 12 123456789. Contact : <a href="mailto:contact@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>contact@aura-wedding.fr</a>
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">2. Produits et services</h2>
            <p>
              AURA SAS commercialise des abonnements à la plateforme AURA Wedding OS selon les formules suivantes :
            </p>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 pr-4 font-semibold">Formule</th>
                    <th className="text-left py-2 pr-4 font-semibold">Prix mensuel TTC</th>
                    <th className="text-left py-2 font-semibold">Principales fonctionnalités</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  <tr>
                    <td className="py-2 pr-4">Gratuit</td>
                    <td className="py-2 pr-4">0 €</td>
                    <td className="py-2">Invités (50 max), Timeline, Budget basique</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Essentiel</td>
                    <td className="py-2 pr-4">9,90 €</td>
                    <td className="py-2">Invités illimités, Mini-site, Plan de table</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Premium</td>
                    <td className="py-2 pr-4">19,90 €</td>
                    <td className="py-2">IA complète, Emails groupés, Contrats</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Prestige</td>
                    <td className="py-2 pr-4">39,90 €</td>
                    <td className="py-2">Toutes fonctionnalités + support prioritaire</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="mt-3">
              Les prix sont indiqués en euros toutes taxes comprises (TVA 20 %). AURA SAS se réserve le droit de modifier ses tarifs à tout moment, les modifications prenant effet à la prochaine période de facturation.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">3. Commande et paiement</h2>
            <p>
              La souscription à un abonnement payant s'effectue via la page Tarifs du Service. Le paiement est traité de manière sécurisée par Stripe, prestataire de paiement agréé. Les informations bancaires de l'utilisateur ne sont jamais stockées sur les serveurs d'AURA SAS.
            </p>
            <p className="mt-2">
              L'abonnement est renouvelé automatiquement à chaque période (mensuelle ou annuelle) jusqu'à résiliation explicite par l'utilisateur. L'utilisateur recevra une confirmation de paiement par email à chaque renouvellement.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">4. Droit de rétractation</h2>
            <p>
              Conformément aux articles L.221-18 et suivants du Code de la consommation, l'utilisateur dispose d'un délai de <strong>14 jours calendaires</strong> à compter de la date de souscription pour exercer son droit de rétractation, sans avoir à justifier de motifs ni à payer de pénalités.
            </p>
            <p className="mt-2">
              Pour exercer ce droit, l'utilisateur doit notifier sa décision à AURA SAS par email à{" "}
              <a href="mailto:retractation@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                retractation@aura-wedding.fr
              </a>{" "}
              en indiquant clairement son intention de se rétracter, son nom, son adresse email et la date de souscription.
            </p>
            <p className="mt-2">
              <strong>Exception :</strong> Conformément à l'article L.221-28 du Code de la consommation, le droit de rétractation ne peut être exercé pour les contrats de fourniture de contenu numérique non fourni sur support matériel dont l'exécution a commencé avec l'accord préalable exprès du consommateur et renoncement exprès à son droit de rétractation. En souscrivant à un abonnement et en accédant immédiatement au Service, l'utilisateur reconnaît avoir expressément demandé l'exécution immédiate du contrat et renonce à son droit de rétractation pour la période déjà consommée.
            </p>
            <p className="mt-2">
              En cas de rétractation valide dans le délai de 14 jours, AURA SAS procédera au remboursement intégral de la somme versée dans un délai de 14 jours suivant la réception de la demande, par le même moyen de paiement que celui utilisé lors de la souscription.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">5. Résiliation et remboursements</h2>
            <p>
              L'utilisateur peut résilier son abonnement à tout moment depuis son espace client (Réglages → Abonnement) ou via le portail Stripe. La résiliation prend effet à la fin de la période de facturation en cours. Aucun remboursement au prorata n'est effectué pour la période restante, sauf dans le cadre du droit de rétractation décrit à l'article 4.
            </p>
            <p className="mt-2">
              En cas de dysfonctionnement grave du Service imputable à AURA SAS et persistant plus de 72 heures consécutives, l'utilisateur peut demander un avoir ou un remboursement au prorata en contactant le support.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">6. Garanties légales</h2>
            <p>
              Conformément aux articles L.217-4 et suivants du Code de la consommation, AURA SAS est tenue à la garantie légale de conformité pour les services numériques fournis. En cas de défaut de conformité, l'utilisateur peut demander la mise en conformité du Service dans un délai raisonnable.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">7. Service après-vente</h2>
            <p>
              Pour toute réclamation ou demande d'assistance, l'utilisateur peut contacter le service client à l'adresse{" "}
              <a href="mailto:support@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                support@aura-wedding.fr
              </a>
              . AURA SAS s'engage à répondre dans un délai de 48 heures ouvrées.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">8. Médiation des litiges</h2>
            <p>
              En cas de litige non résolu avec le service client, l'utilisateur peut recourir gratuitement à la médiation de la consommation. AURA SAS adhère au service de médiation CM2C (Centre de Médiation de la Consommation de Conciliateurs de Justice), accessible à l'adresse{" "}
              <a href="https://www.cm2c.net" target="_blank" rel="noopener noreferrer" className="underline" style={{ color: "var(--coral)" }}>
                www.cm2c.net
              </a>
              .
            </p>
            <p className="mt-2">
              La Commission européenne met également à disposition une plateforme de règlement en ligne des litiges (RLL) accessible à l'adresse{" "}
              <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener noreferrer" className="underline" style={{ color: "var(--coral)" }}>
                ec.europa.eu/consumers/odr
              </a>
              .
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">9. Droit applicable</h2>
            <p>
              Les présentes CGV sont soumises au droit français. En cas de litige, et après tentative de résolution amiable, les tribunaux de Paris seront seuls compétents.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
