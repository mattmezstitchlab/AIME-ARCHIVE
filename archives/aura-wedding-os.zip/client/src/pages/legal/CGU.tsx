import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function CGU() {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Retour à l'accueil
        </button>

        <h1 className="text-3xl font-black mb-2" style={{ color: "var(--coral)" }}>
          Conditions Générales d'Utilisation
        </h1>
        <p className="text-sm text-muted-foreground mb-10">Dernière mise à jour : 11 mai 2026</p>

        <div className="space-y-8 text-sm leading-relaxed">
          <section>
            <h2 className="text-lg font-bold mb-3">1. Présentation du service</h2>
            <p>
              AURA Wedding OS (ci-après « le Service ») est une plateforme SaaS de planification de mariage éditée par AURA SAS, société par actions simplifiée au capital de 10 000 €, immatriculée au RCS de Paris sous le numéro 123 456 789, dont le siège social est situé au 12 rue de la Paix, 75001 Paris, France. Le Service est accessible à l'adresse{" "}
              <a href="https://aurawedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                aurawedding.fr
              </a>
              .
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">2. Acceptation des conditions</h2>
            <p>
              L'accès et l'utilisation du Service impliquent l'acceptation pleine et entière des présentes Conditions Générales d'Utilisation (CGU). Toute personne qui accède au Service reconnaît avoir pris connaissance des présentes CGU et s'engage à les respecter. Si vous n'acceptez pas ces conditions, vous devez cesser immédiatement d'utiliser le Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">3. Description du Service</h2>
            <p>
              AURA Wedding OS propose aux couples en cours d'organisation de mariage un ensemble d'outils numériques comprenant notamment : la gestion de la liste d'invités et des confirmations de présence (RSVP), le suivi budgétaire, la gestion des prestataires, la création d'un mini-site de mariage personnalisé, un plan de table interactif, un assistant IA de planification, et des outils de communication avec les prestataires et les invités.
            </p>
            <p className="mt-2">
              Le Service est accessible via un abonnement mensuel ou annuel selon les formules décrites sur la page Tarifs. Une formule gratuite avec fonctionnalités limitées est également disponible.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">4. Inscription et compte utilisateur</h2>
            <p>
              L'inscription au Service nécessite la création d'un compte via le système d'authentification OAuth de Manus. L'utilisateur s'engage à fournir des informations exactes, complètes et à jour lors de son inscription. Chaque compte est strictement personnel et ne peut être partagé. L'utilisateur est seul responsable de la confidentialité de ses identifiants de connexion.
            </p>
            <p className="mt-2">
              AURA SAS se réserve le droit de suspendre ou de supprimer tout compte en cas de violation des présentes CGU, de comportement frauduleux ou d'utilisation abusive du Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">5. Utilisation acceptable</h2>
            <p>L'utilisateur s'engage à utiliser le Service de manière licite et à ne pas :</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Publier ou transmettre des contenus illicites, diffamatoires, obscènes ou portant atteinte aux droits de tiers ;</li>
              <li>Tenter de contourner les mesures de sécurité du Service ;</li>
              <li>Utiliser le Service à des fins commerciales non autorisées ;</li>
              <li>Collecter des données personnelles d'autres utilisateurs sans leur consentement ;</li>
              <li>Introduire des virus ou tout autre code malveillant dans le Service.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">6. Propriété intellectuelle</h2>
            <p>
              L'ensemble des éléments constituant le Service (textes, graphismes, logiciels, marques, logos) sont la propriété exclusive d'AURA SAS ou font l'objet d'une licence accordée à AURA SAS. Toute reproduction, représentation, modification ou exploitation non autorisée de ces éléments est strictement interdite.
            </p>
            <p className="mt-2">
              Les contenus créés par l'utilisateur (textes, photos, données de mariage) restent sa propriété. En les téléchargeant sur le Service, l'utilisateur accorde à AURA SAS une licence non exclusive, mondiale et gratuite pour les héberger, afficher et traiter dans le cadre de la fourniture du Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">7. Disponibilité du Service</h2>
            <p>
              AURA SAS s'efforce d'assurer la disponibilité du Service 24h/24 et 7j/7. Toutefois, des interruptions pour maintenance ou en cas de force majeure peuvent survenir. AURA SAS ne saurait être tenue responsable des conséquences d'une indisponibilité temporaire du Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">8. Limitation de responsabilité</h2>
            <p>
              Le Service est fourni « en l'état ». AURA SAS ne garantit pas que le Service sera exempt d'erreurs ou que les résultats obtenus via l'assistant IA seront exacts ou adaptés aux besoins spécifiques de l'utilisateur. Les suggestions générées par l'intelligence artificielle (prestataires, budgets, timelines) sont fournies à titre indicatif et ne constituent pas des conseils professionnels.
            </p>
            <p className="mt-2">
              La responsabilité d'AURA SAS ne pourra être engagée pour des dommages indirects, pertes de données ou manque à gagner résultant de l'utilisation ou de l'impossibilité d'utiliser le Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">9. Modification des CGU</h2>
            <p>
              AURA SAS se réserve le droit de modifier les présentes CGU à tout moment. Les utilisateurs seront informés des modifications substantielles par email ou via une notification dans le Service. La poursuite de l'utilisation du Service après notification vaut acceptation des nouvelles CGU.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">10. Résiliation</h2>
            <p>
              L'utilisateur peut résilier son compte à tout moment depuis les paramètres de son espace ou en contactant le support à l'adresse{" "}
              <a href="mailto:support@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                support@aura-wedding.fr
              </a>
              . La résiliation entraîne la suppression des données conformément à la politique de confidentialité.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">11. Droit applicable et juridiction</h2>
            <p>
              Les présentes CGU sont régies par le droit français. En cas de litige, les parties s'engagent à rechercher une solution amiable avant tout recours judiciaire. À défaut d'accord amiable, les tribunaux compétents de Paris seront seuls compétents.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">12. Contact</h2>
            <p>
              Pour toute question relative aux présentes CGU, vous pouvez contacter AURA SAS à l'adresse :{" "}
              <a href="mailto:legal@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                legal@aura-wedding.fr
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
