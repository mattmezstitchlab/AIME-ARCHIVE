import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Confidentialite() {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Retour à l'accueil
        </button>

        <h1 className="text-3xl font-black mb-2" style={{ color: "var(--coral)" }}>
          Politique de Confidentialité
        </h1>
        <p className="text-sm text-muted-foreground mb-10">Dernière mise à jour : 11 mai 2026 — Conforme au RGPD (UE) 2016/679</p>

        <div className="space-y-8 text-sm leading-relaxed">
          <section>
            <h2 className="text-lg font-bold mb-3">1. Responsable du traitement</h2>
            <p>
              Le responsable du traitement des données personnelles collectées via AURA Wedding OS est AURA SAS, dont le siège social est situé au 12 rue de la Paix, 75001 Paris, France. Pour toute question relative à la protection de vos données, vous pouvez contacter notre Délégué à la Protection des Données (DPO) à l'adresse :{" "}
              <a href="mailto:dpo@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                dpo@aura-wedding.fr
              </a>
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">2. Données collectées</h2>
            <p>AURA SAS collecte les catégories de données suivantes :</p>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 pr-4 font-semibold">Catégorie</th>
                    <th className="text-left py-2 pr-4 font-semibold">Données</th>
                    <th className="text-left py-2 font-semibold">Finalité</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  <tr>
                    <td className="py-2 pr-4">Identité</td>
                    <td className="py-2 pr-4">Prénom, nom, email</td>
                    <td className="py-2">Création et gestion du compte</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Mariage</td>
                    <td className="py-2 pr-4">Date, lieu, noms des partenaires, budget</td>
                    <td className="py-2">Fourniture du Service de planification</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Invités</td>
                    <td className="py-2 pr-4">Noms, emails, téléphones, régimes alimentaires</td>
                    <td className="py-2">Gestion des invitations et RSVP</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Prestataires</td>
                    <td className="py-2 pr-4">Noms, emails, tarifs, contrats</td>
                    <td className="py-2">Gestion des prestataires de mariage</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Paiement</td>
                    <td className="py-2 pr-4">Identifiant client Stripe (aucune donnée bancaire brute)</td>
                    <td className="py-2">Facturation et gestion des abonnements</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Navigation</td>
                    <td className="py-2 pr-4">Adresse IP, logs de connexion, cookies de session</td>
                    <td className="py-2">Sécurité et amélioration du Service</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4">Photos</td>
                    <td className="py-2 pr-4">Images téléchargées sur le mur photo ou les documents</td>
                    <td className="py-2">Fonctionnalités de partage photo</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">3. Bases légales du traitement</h2>
            <p>Les traitements effectués par AURA SAS reposent sur les bases légales suivantes :</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li><strong>Exécution du contrat</strong> : traitement nécessaire à la fourniture du Service souscrit (art. 6.1.b RGPD) ;</li>
              <li><strong>Intérêt légitime</strong> : amélioration du Service, sécurité, prévention de la fraude (art. 6.1.f RGPD) ;</li>
              <li><strong>Consentement</strong> : envoi de communications marketing, dépôt de cookies non essentiels (art. 6.1.a RGPD) ;</li>
              <li><strong>Obligation légale</strong> : conservation des données comptables et fiscales (art. 6.1.c RGPD).</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">4. Durée de conservation</h2>
            <p>Les données personnelles sont conservées selon les durées suivantes :</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Données de compte : pendant la durée de l'abonnement + 3 ans après résiliation ;</li>
              <li>Données de facturation : 10 ans (obligation comptable légale) ;</li>
              <li>Données d'invités : jusqu'à 1 an après la date du mariage, puis suppression automatique ;</li>
              <li>Photos et documents : jusqu'à suppression par l'utilisateur ou 2 ans après la date du mariage ;</li>
              <li>Logs de connexion : 12 mois.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">5. Destinataires des données</h2>
            <p>
              Les données personnelles peuvent être transmises aux sous-traitants suivants, dans le cadre strict de la fourniture du Service :
            </p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li><strong>Manus Technologies</strong> : hébergement et infrastructure cloud ;</li>
              <li><strong>Stripe Inc.</strong> : traitement des paiements (certifié PCI DSS) ;</li>
              <li><strong>Resend Inc.</strong> : envoi d'emails transactionnels ;</li>
              <li><strong>OpenAI / Manus AI</strong> : traitement des requêtes d'intelligence artificielle (données anonymisées).</li>
            </ul>
            <p className="mt-2">
              Ces sous-traitants sont liés par des accords de traitement des données conformes au RGPD. Aucune donnée n'est vendue à des tiers à des fins commerciales.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">6. Transferts hors UE</h2>
            <p>
              Certains de nos sous-traitants (Stripe, Resend, OpenAI) sont établis aux États-Unis. Ces transferts sont encadrés par les Clauses Contractuelles Types (CCT) approuvées par la Commission européenne, conformément à l'article 46 du RGPD.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">7. Vos droits</h2>
            <p>
              Conformément au RGPD, vous disposez des droits suivants concernant vos données personnelles :
            </p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li><strong>Droit d'accès</strong> (art. 15) : obtenir une copie de vos données ;</li>
              <li><strong>Droit de rectification</strong> (art. 16) : corriger des données inexactes ;</li>
              <li><strong>Droit à l'effacement</strong> (art. 17) : demander la suppression de vos données ;</li>
              <li><strong>Droit à la limitation</strong> (art. 18) : restreindre le traitement de vos données ;</li>
              <li><strong>Droit à la portabilité</strong> (art. 20) : recevoir vos données dans un format structuré ;</li>
              <li><strong>Droit d'opposition</strong> (art. 21) : vous opposer au traitement basé sur l'intérêt légitime ;</li>
              <li><strong>Droit de retrait du consentement</strong> : à tout moment pour les traitements basés sur le consentement.</li>
            </ul>
            <p className="mt-3">
              Pour exercer ces droits, contactez notre DPO à{" "}
              <a href="mailto:dpo@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>
                dpo@aura-wedding.fr
              </a>
              . Nous répondrons dans un délai maximum d'un mois. En cas de réponse insatisfaisante, vous pouvez introduire une réclamation auprès de la{" "}
              <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="underline" style={{ color: "var(--coral)" }}>
                CNIL
              </a>
              .
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">8. Sécurité des données</h2>
            <p>
              AURA SAS met en œuvre des mesures techniques et organisationnelles appropriées pour protéger vos données contre tout accès non autorisé, perte, altération ou divulgation. Ces mesures comprennent notamment : le chiffrement des données en transit (TLS 1.3), le chiffrement des données au repos, l'authentification à deux facteurs pour les accès administrateurs, et des audits de sécurité réguliers.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">9. Données des invités et prestataires</h2>
            <p>
              En utilisant AURA Wedding OS pour gérer les données de vos invités et prestataires, vous agissez en tant que responsable du traitement de ces données. AURA SAS agit en tant que sous-traitant. Vous êtes responsable d'informer vos invités et prestataires de la collecte et du traitement de leurs données personnelles via votre utilisation du Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">10. Modifications de la politique</h2>
            <p>
              AURA SAS se réserve le droit de modifier la présente politique de confidentialité à tout moment. Les modifications substantielles seront notifiées par email ou via une bannière d'information dans le Service. La date de dernière mise à jour est indiquée en haut de ce document.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
