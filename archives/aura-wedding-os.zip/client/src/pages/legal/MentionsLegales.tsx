import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function MentionsLegales() {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Retour à l'accueil
        </button>

        <h1 className="text-3xl font-black mb-2" style={{ color: "var(--coral)" }}>
          Mentions Légales
        </h1>
        <p className="text-sm text-muted-foreground mb-10">Dernière mise à jour : 11 mai 2026</p>

        <div className="space-y-8 text-sm leading-relaxed">
          <section>
            <h2 className="text-lg font-bold mb-3">1. Éditeur du site</h2>
            <div className="neu-card p-4 space-y-1">
              <p><strong>Raison sociale :</strong> AURA SAS</p>
              <p><strong>Forme juridique :</strong> Société par Actions Simplifiée (SAS)</p>
              <p><strong>Capital social :</strong> 10 000 €</p>
              <p><strong>Siège social :</strong> 12 rue de la Paix, 75001 Paris, France</p>
              <p><strong>RCS :</strong> Paris 123 456 789</p>
              <p><strong>Numéro de TVA intracommunautaire :</strong> FR 12 123456789</p>
              <p><strong>Directeur de la publication :</strong> [Nom du dirigeant]</p>
              <p><strong>Email :</strong> <a href="mailto:contact@aura-wedding.fr" className="underline" style={{ color: "var(--coral)" }}>contact@aura-wedding.fr</a></p>
              <p><strong>Téléphone :</strong> +33 (0)1 XX XX XX XX</p>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">2. Hébergeur</h2>
            <div className="neu-card p-4 space-y-1">
              <p><strong>Hébergeur :</strong> Manus Technologies</p>
              <p><strong>Adresse :</strong> [Adresse de l'hébergeur]</p>
              <p><strong>Site web :</strong> <a href="https://manus.im" target="_blank" rel="noopener noreferrer" className="underline" style={{ color: "var(--coral)" }}>manus.im</a></p>
            </div>
            <p className="mt-3">
              Les données sont hébergées sur des serveurs situés dans l'Union Européenne, conformément au Règlement Général sur la Protection des Données (RGPD).
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">3. Propriété intellectuelle</h2>
            <p>
              L'ensemble du contenu du site AURA Wedding OS (textes, images, graphismes, logo, icônes, sons, logiciels) est la propriété exclusive d'AURA SAS, à l'exception des contenus fournis par les partenaires ou les utilisateurs. Toute reproduction, distribution, modification, adaptation, retransmission ou publication de ces différents éléments est strictement interdite sans l'accord exprès par écrit d'AURA SAS.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">4. Liens hypertextes</h2>
            <p>
              Le site AURA Wedding OS peut contenir des liens hypertextes vers d'autres sites internet. AURA SAS n'exerce aucun contrôle sur ces sites et décline toute responsabilité quant à leur contenu ou à leurs pratiques en matière de protection des données personnelles.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">5. Cookies</h2>
            <p>
              Le site AURA Wedding OS utilise des cookies techniques nécessaires au fonctionnement du Service (session d'authentification, préférences d'affichage). Ces cookies ne collectent pas de données à des fins publicitaires.
            </p>
            <p className="mt-2">
              Des cookies analytiques peuvent être utilisés pour mesurer l'audience du site (nombre de visiteurs, pages consultées). Ces cookies sont anonymisés et ne permettent pas d'identifier personnellement les utilisateurs.
            </p>
            <p className="mt-2">
              L'utilisateur peut configurer son navigateur pour refuser les cookies. Toutefois, certaines fonctionnalités du Service peuvent être altérées en cas de désactivation des cookies techniques.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">6. Responsabilité</h2>
            <p>
              AURA SAS s'efforce d'assurer l'exactitude et la mise à jour des informations diffusées sur le site. Toutefois, AURA SAS ne peut garantir l'exactitude, la précision ou l'exhaustivité des informations mises à disposition sur ce site. En conséquence, AURA SAS décline toute responsabilité pour toute imprécision, inexactitude ou omission portant sur des informations disponibles sur le site.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold mb-3">7. Droit applicable</h2>
            <p>
              Les présentes mentions légales sont régies par le droit français. En cas de litige, les tribunaux français seront seuls compétents.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
