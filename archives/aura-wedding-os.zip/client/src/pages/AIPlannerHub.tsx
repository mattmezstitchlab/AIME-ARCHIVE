import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, ListChecks, Mail, Users, BookOpen, AlertTriangle,
  RefreshCw, Send, CheckCircle, Clock, TrendingUp,
  Star, MapPin, Euro, ExternalLink, Zap, Heart, Eye,
  FileText, Download, ThumbsUp, ThumbsDown, HelpCircle, Edit3,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type HubTab = "guide" | "emails" | "matching" | "memory" | "crisis" | "devis";

export default function AIPlannerHub() {
  const [activeTab, setActiveTab] = useState<HubTab>("guide");
  const weddingQuery = trpc.wedding.get.useQuery();
  const weddingId = weddingQuery.data?.id;

  const tabs: { id: HubTab; label: string; icon: React.ElementType }[] = [
    { id: "guide", label: "Guide", icon: ListChecks },
    { id: "emails", label: "Emails", icon: Mail },
    { id: "matching", label: "Matching", icon: Users },
    { id: "memory", label: "Mémoire", icon: BookOpen },
    { id: "crisis", label: "Crise J", icon: AlertTriangle },
    { id: "devis", label: "Devis IA", icon: FileText },
  ];

  return (
    <div className="space-y-4">
      <div className="neu-card p-2 flex gap-1 overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id ? "text-white shadow-inner" : "text-gray-600 neu-card"
            }`}
            style={activeTab === tab.id ? { background: "#F07167" } : {}}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {!weddingId ? (
            <div className="neu-card p-8 text-center">
              <Sparkles className="w-8 h-8 text-coral mx-auto mb-3 animate-pulse" />
              <p className="text-gray-500">Chargement...</p>
            </div>
          ) : (
            <>
              {activeTab === "guide" && <GuidePanel weddingId={weddingId} />}
              {activeTab === "emails" && <EmailsPanel weddingId={weddingId} />}
              {activeTab === "matching" && <MatchingPanel weddingId={weddingId} />}
              {activeTab === "memory" && <MemoryPanel weddingId={weddingId} />}
              {activeTab === "crisis" && <CrisisPanel weddingId={weddingId} />}
              {activeTab === "devis" && <QuoteAssistantPanel weddingId={weddingId} />}
            </>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ─── GUIDE ────────────────────────────────────────────────────────────────────
function GuidePanel({ weddingId }: { weddingId: number }) {
  const tasksQuery = trpc.aiPlanner.guide.list.useQuery({ weddingId });
  const generateMutation = trpc.aiPlanner.guide.generate.useMutation({
    onSuccess: () => { tasksQuery.refetch(); toast.success("Guide régénéré !"); },
  });
  const updateMutation = trpc.aiPlanner.guide.updateStatus.useMutation({
    onSuccess: () => tasksQuery.refetch(),
  });

  const priorityColors: Record<string, string> = {
    urgent: "#ef4444", high: "#F07167", medium: "#f59e0b", low: "#10b981",
  };
  const priorityLabels: Record<string, string> = {
    urgent: "Urgent", high: "Haute", medium: "Moyenne", low: "Basse",
  };

  const tasks = tasksQuery.data ?? [];
  const completed = tasks.filter(t => t.status === "done").length;
  const progress = tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="neu-card p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-bold text-gray-800">Guide d'organisation</h3>
            <p className="text-xs text-gray-500">{completed}/{tasks.length} tâches complétées</p>
          </div>
          <Button size="sm" onClick={() => generateMutation.mutate({ weddingId })} disabled={generateMutation.isPending}
            className="text-white text-xs rounded-xl" style={{ background: "#F07167" }}>
            {generateMutation.isPending ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
            <span className="ml-1">{tasks.length === 0 ? "Générer" : "Régénérer"}</span>
          </Button>
        </div>
        {tasks.length > 0 && (
          <div className="w-full h-2 rounded-full bg-gray-200 overflow-hidden">
            <div className="h-full rounded-full transition-all duration-500" style={{ width: `${progress}%`, background: "#F07167" }} />
          </div>
        )}
      </div>

      {tasks.length === 0 ? (
        <div className="neu-card p-8 text-center">
          <ListChecks className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Cliquez sur "Générer" pour créer votre guide personnalisé</p>
        </div>
      ) : (
        <div className="space-y-2">
          {tasks.map(task => (
            <div key={task.id} className={`neu-card p-3 flex items-start gap-3 transition-all ${task.status === "done" ? "opacity-60" : ""}`}>
              <button
                onClick={() => updateMutation.mutate({ taskId: task.id, status: task.status === "done" ? "todo" : "done" })}
                className={`w-5 h-5 rounded-full flex-shrink-0 mt-0.5 border-2 flex items-center justify-center transition-all ${
                  task.status === "done" ? "border-green-500 bg-green-500" : "border-gray-300"
                }`}
              >
                {task.status === "done" && <CheckCircle className="w-3 h-3 text-white" />}
              </button>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className={`text-sm font-medium text-gray-800 ${task.status === "done" ? "line-through" : ""}`}>{task.title}</p>
                  <span className="text-xs px-2 py-0.5 rounded-full text-white" style={{ background: priorityColors[task.priority] ?? "#aaa" }}>
                    {priorityLabels[task.priority] ?? task.priority}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-0.5">{task.description}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs text-gray-400 flex items-center gap-1"><Clock className="w-3 h-3" />{task.recommendedMonthsBefore} mois avant</span>
                  <span className="text-xs text-gray-400">{task.category}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── EMAILS ───────────────────────────────────────────────────────────────────
function EmailsPanel({ weddingId }: { weddingId: number }) {
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [currentCampaignId, setCurrentCampaignId] = useState<number | null>(null);
  const [previewData, setPreviewData] = useState<{ subject: string; body: string } | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const guestsQuery = trpc.guests.list.useQuery();
  const campaignsQuery = trpc.aiPlanner.email.listCampaigns.useQuery({ weddingId });
  const templatesQuery = trpc.aiPlanner.email.getTemplates.useQuery({ weddingId });

  const createCampaignMutation = trpc.aiPlanner.email.createCampaign.useMutation({
    onSuccess: (data) => {
      if (data) {
        setCurrentCampaignId(data.id);
        toast.success("Campagne créée !");
      }
    },
  });

  const previewMutation = trpc.aiPlanner.email.previewPersonalized.useQuery(
    currentCampaignId != null && previewData == null
      ? {
          weddingId,
          bodyTemplate: templatesQuery.data?.find(t => t.type === selectedType)?.body ?? "",
          subject: templatesQuery.data?.find(t => t.type === selectedType)?.subject ?? "",
          guestId: guestsQuery.data?.[0]?.id,
        }
      : undefined as any,
    { enabled: false }
  );

  const sendCampaignMutation = trpc.aiPlanner.email.sendCampaign.useMutation({
    onSuccess: (data) => {
      toast.success(`${data.sent} email(s) envoyé(s) avec succès !`);
      campaignsQuery.refetch();
      setSelectedType(null);
      setCurrentCampaignId(null);
      setPreviewData(null);
    },
  });

  const guests = guestsQuery.data ?? [];
  const templates = templatesQuery.data ?? [];

  const templateIcons: Record<string, React.ElementType> = {
    save_the_date: Heart,
    invitation: Mail,
    rsvp_reminder: Clock,
    practical_info: MapPin,
    thank_you: Star,
  };

  const handleSelectTemplate = (type: string) => {
    setSelectedType(type);
    setCurrentCampaignId(null);
    setPreviewData(null);
    const tpl = templates.find(t => t.type === type);
    if (tpl) {
      createCampaignMutation.mutate({
        weddingId,
        type: type as any,
        subject: tpl.subject,
        bodyTemplate: tpl.body,
        recipientFilter: type === "rsvp_reminder" ? "pending" : "all",
      });
    }
  };

  const handlePreview = async () => {
    const tpl = templates.find(t => t.type === selectedType);
    if (!tpl) return;
    const firstGuest = guests[0];
    const firstName = firstGuest?.firstName ?? "Sophie";
    const rsvpLink = `https://aura.wedding/rsvp/${firstGuest?.rsvpToken ?? "exemple"}`;
    const dateLimit = new Date(Date.now() + 30 * 86400000).toLocaleDateString("fr-FR");
    const body = tpl.body
      .replace(/\{\{prenom\}\}/g, firstName)
      .replace(/\{\{lien_rsvp\}\}/g, rsvpLink)
      .replace(/\{\{date_limite_rsvp\}\}/g, dateLimit);
    setPreviewData({ subject: tpl.subject.replace(/\{\{prenom\}\}/g, firstName), body });
  };

  return (
    <div className="space-y-4">
      <div className="neu-card p-4">
        <h3 className="font-bold text-gray-800 mb-3">Choisir un modèle d'email</h3>
        {templates.length === 0 ? (
          <div className="text-center py-4 text-gray-400 text-sm">Chargement des modèles...</div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {templates.map(t => {
              const Icon = templateIcons[t.type] ?? Mail;
              return (
                <button key={t.type} onClick={() => handleSelectTemplate(t.type)}
                  className={`p-3 rounded-xl text-left transition-all ${selectedType === t.type ? "text-white" : "neu-card"}`}
                  style={selectedType === t.type ? { background: "#F07167" } : {}}
                >
                  <Icon className={`w-4 h-4 mb-1 ${selectedType === t.type ? "text-white" : "text-coral"}`} />
                  <p className={`text-xs font-semibold ${selectedType === t.type ? "text-white" : "text-gray-800"}`}>{t.label}</p>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {selectedType && currentCampaignId && (
        <>
          <div className="neu-card p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-gray-800">Destinataires</h3>
              <div className="flex gap-2 overflow-x-auto">
                {[{ v: "all", l: "Tous" }, { v: "confirmed", l: "Confirmés" }, { v: "pending", l: "En attente" }].map(f => (
                  <button key={f.v} onClick={() => setFilterStatus(f.v)}
                    className={`px-2 py-1 rounded-xl text-xs whitespace-nowrap transition-all ${filterStatus === f.v ? "text-white" : "neu-card text-gray-600"}`}
                    style={filterStatus === f.v ? { background: "#F07167" } : {}}
                  >{f.l}</button>
                ))}
              </div>
            </div>
            <p className="text-xs text-gray-500">
              {guests.filter(g => {
                if (filterStatus === "all") return true;
                if (filterStatus === "confirmed") return g.rsvpStatus === "confirmed";
                if (filterStatus === "pending") return !g.rsvpStatus || g.rsvpStatus === "pending";
                return true;
              }).length} invité(s) · {guests.filter(g => g.email).length} avec email
            </p>
          </div>

          <div className="neu-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-gray-800">Prévisualisation</h3>
              <Button size="sm" onClick={handlePreview} className="text-white text-xs rounded-xl" style={{ background: "#F07167" }}>
                <Eye className="w-3 h-3 mr-1" />Aperçu
              </Button>
            </div>
            {previewData ? (
              <div className="space-y-2">
                <div className="bg-gray-50 rounded-xl p-2">
                  <p className="text-xs text-gray-400">Objet :</p>
                  <p className="text-sm font-medium text-gray-700">{previewData.subject}</p>
                </div>
                <div className="bg-white rounded-xl p-3 text-sm text-gray-700 whitespace-pre-wrap border border-gray-100 max-h-40 overflow-y-auto">{previewData.body}</div>
              </div>
            ) : (
              <div className="bg-gray-50 rounded-xl p-4 text-center text-gray-400 text-sm">Cliquez sur "Aperçu" pour voir votre email</div>
            )}
          </div>

          <Button className="w-full text-white font-semibold py-3 rounded-2xl flex items-center justify-center gap-2"
            style={{ background: "#F07167" }}
            disabled={sendCampaignMutation.isPending}
            onClick={() => sendCampaignMutation.mutate({ campaignId: currentCampaignId, weddingId })}
          >
            {sendCampaignMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Envoyer la campagne
          </Button>
        </>
      )}

      {(campaignsQuery.data?.length ?? 0) > 0 && (
        <div className="neu-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800">Historique des envois</h3>
            <EmailStatsBadge weddingId={weddingId} />
          </div>
          <div className="space-y-3">
            {campaignsQuery.data?.map(c => (
              <div key={c.id} className="p-3 rounded-xl bg-gray-50 space-y-2">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-700">{c.type.replace(/_/g, " ")}</p>
                    <p className="text-xs text-gray-400">{c.sentCount ?? 0} envois · {new Date(c.createdAt).toLocaleDateString("fr-FR")}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${c.status === "sent" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                    {c.status}
                  </span>
                </div>
                {c.status !== "sent" && (
                  <EditCampaignInline
                    campaignId={c.id}
                    initialSubject={c.subject ?? ""}
                    initialBody={c.bodyTemplate ?? ""}
                    onSaved={() => campaignsQuery.refetch()}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function EmailStatsBadge({ weddingId }: { weddingId: number }) {
  const statsQuery = trpc.aiPlanner.email.getStats.useQuery({ weddingId });
  if (!statsQuery.data) return null;
  const { sent, failed, total } = statsQuery.data;
  return (
    <div className="flex gap-1.5 text-xs">
      <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full">{sent} envoyés</span>
      {failed > 0 && <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-full">{failed} échecs</span>}
      <span className="bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">{total} total</span>
    </div>
  );
}

function EditCampaignInline({ campaignId, initialSubject, initialBody, onSaved }: {
  campaignId: number; initialSubject: string; initialBody: string; onSaved: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState(initialSubject);
  const [body, setBody] = useState(initialBody);
  const updateMutation = trpc.aiPlanner.email.updateCampaign.useMutation({
    onSuccess: () => { toast.success("Campagne mise à jour !"); setOpen(false); onSaved(); },
  });
  if (!open) return (
    <button onClick={() => setOpen(true)} className="text-xs underline" style={{ color: "#F07167" }}>Modifier le contenu</button>
  );
  return (
    <div className="space-y-2 mt-1">
      <input value={subject} onChange={e => setSubject(e.target.value)} placeholder="Objet de l'email"
        className="w-full text-xs border border-gray-200 rounded-xl px-3 py-2 focus:outline-none bg-white" />
      <textarea value={body} onChange={e => setBody(e.target.value)} rows={4} placeholder="Corps de l'email"
        className="w-full text-xs border border-gray-200 rounded-xl px-3 py-2 focus:outline-none resize-none bg-white" />
      <div className="flex gap-2">
        <button onClick={() => updateMutation.mutate({ campaignId, subject, body })} disabled={updateMutation.isPending}
          className="text-xs text-white px-3 py-1.5 rounded-xl" style={{ background: "#F07167" }}>
          {updateMutation.isPending ? "Sauvegarde..." : "Sauvegarder"}
        </button>
        <button onClick={() => setOpen(false)} className="text-xs text-gray-500 px-3 py-1.5 rounded-xl neu-card">Annuler</button>
      </div>
    </div>
  );
}

// ─── MATCHING ─────────────────────────────────────────────────────────────────
function MatchingPanel({ weddingId }: { weddingId: number }) {
  const matchesQuery = trpc.aiPlanner.matching.list.useQuery({ weddingId });
  const generateMutation = trpc.aiPlanner.matching.generate.useMutation({
    onSuccess: () => { matchesQuery.refetch(); toast.success("Suggestions mises à jour !"); },
  });
  const addProviderMutation = trpc.providers.add.useMutation({
    onSuccess: () => toast.success("Prestataire ajouté !"),
  });

  const matches = matchesQuery.data ?? [];
  const categoryIcons: Record<string, string> = {
    photographer: "📷", videographer: "🎬", caterer: "🍽️", florist: "💐",
    music: "🎵", venue: "🏛️", transport: "🚗", beauty: "💄",
    cake: "🎂", animation: "🎪", officiant: "💍",
  };

  return (
    <div className="space-y-4">
      {/* Avertissement fictif */}
      <div className="neu-card p-4 flex items-start gap-3" style={{ borderLeft: "3px solid #f59e0b" }}>
        <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: "#f59e0b" }} />
        <div>
          <p className="text-sm font-semibold" style={{ color: "#92400e" }}>Suggestions générées par l'IA — non vérifiées</p>
          <p className="text-xs mt-1" style={{ color: "#92400e" }}>
            Les prestataires suggérés ci-dessous sont des <strong>profils fictifs créés par l'IA</strong> à titre d'inspiration.
            Les noms, emails, sites web et tarifs sont <strong>inventoriés</strong> et ne correspondent pas à de vrais professionnels.
            Utilisez ces suggestions comme base de recherche, puis vérifiez l'existence et les tarifs réels avant tout contact.
          </p>
        </div>
      </div>
      <div className="neu-card p-4 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-gray-800">Matching Prestataires IA</h3>
          <p className="text-xs text-gray-500">Basé sur votre style, budget et région</p>
        </div>
        <Button size="sm" onClick={() => generateMutation.mutate({ weddingId })} disabled={generateMutation.isPending}
          className="text-white text-xs rounded-xl" style={{ background: "#F07167" }}>
          {generateMutation.isPending ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
          <span className="ml-1">{matches.length === 0 ? "Générer" : "Actualiser"}</span>
        </Button>
      </div>

      {matches.length === 0 ? (
        <div className="neu-card p-8 text-center">
          <Users className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Cliquez sur "Générer" pour obtenir des suggestions personnalisées</p>
        </div>
      ) : (
        <div className="space-y-3">
          {matches.map(match => (
            <div key={match.id} className="neu-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{categoryIcons[match.category] ?? "🤝"}</span>
                  <div>
                    <p className="font-semibold text-gray-800">{match.suggestedName}</p>
                    <p className="text-xs text-gray-500 flex items-center gap-1"><MapPin className="w-3 h-3" />{match.suggestedCity}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-coral" />
                    <span className="text-sm font-bold text-coral">{match.compatibilityScore}%</span>
                  </div>
                  <div className="w-16 h-1.5 rounded-full bg-gray-200 overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${match.compatibilityScore}%`, background: "#F07167" }} />
                  </div>
                </div>
              </div>
              <p className="text-xs text-gray-600 mt-2 italic">"{match.justification}"</p>
              <div className="flex items-center justify-between mt-3">
                <span className="text-xs font-medium text-gray-700 flex items-center gap-1"><Euro className="w-3 h-3" />{match.estimatedPrice}</span>
                <div className="flex gap-2">
                  {match.suggestedWebsite && (
                    <a href={match.suggestedWebsite} target="_blank" rel="noopener noreferrer" className="text-xs text-coral flex items-center gap-1 hover:underline">
                      <ExternalLink className="w-3 h-3" />Site
                    </a>
                  )}
                  <button
                    onClick={() => addProviderMutation.mutate({
                      name: match.suggestedName ?? "",
                      category: (match.category as any) ?? "other",
                      city: match.suggestedCity ?? undefined,
                      email: match.suggestedEmail ?? undefined,
                      website: match.suggestedWebsite ?? undefined,
                    })}
                    className="text-xs px-3 py-1 rounded-xl text-white" style={{ background: "#F07167" }}
                  >+ Ajouter</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── MÉMOIRE NARRATIVE ────────────────────────────────────────────────────────
function MemoryPanel({ weddingId }: { weddingId: number }) {
  const narrativesQuery = trpc.aiPlanner.narrative.list.useQuery({ weddingId });
  const generateMutation = trpc.aiPlanner.narrative.generate.useMutation({
    onSuccess: () => { narrativesQuery.refetch(); toast.success("Récit généré !"); },
  });
  const approveMutation = trpc.aiPlanner.narrative.approve.useMutation({
    onSuccess: () => narrativesQuery.refetch(),
  });
  const updateMutation = trpc.aiPlanner.narrative.update.useMutation({
    onSuccess: () => { narrativesQuery.refetch(); setEditMode(false); toast.success("Récit mis à jour !"); },
  });
  const [editMode, setEditMode] = useState(false);
  const [editText, setEditText] = useState("");

  const narratives = narrativesQuery.data ?? [];
  const latest = narratives[0];

  return (
    <div className="space-y-4">
      <div className="neu-card p-4 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-gray-800">Mémoire Émotionnelle IA</h3>
          <p className="text-xs text-gray-500">Votre histoire racontée par AURA</p>
        </div>
        <Button size="sm" onClick={() => generateMutation.mutate({ weddingId })} disabled={generateMutation.isPending}
          className="text-white text-xs rounded-xl" style={{ background: "#F07167" }}>
          {generateMutation.isPending ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
          <span className="ml-1">{latest ? "Régénérer" : "Générer"}</span>
        </Button>
      </div>

      {latest ? (
        <div className="neu-card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-coral" />
              <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Notre Histoire — par AURA</span>
            </div>
            {!latest.approved ? (
              <button onClick={() => approveMutation.mutate({ narrativeId: latest.id })}
                className="text-xs px-3 py-1 rounded-xl text-white" style={{ background: "#F07167" }}>
                Approuver
              </button>
            ) : (
              <span className="text-xs text-green-600 flex items-center gap-1"><CheckCircle className="w-3 h-3" />Approuvé</span>
            )}
          </div>
          {editMode ? (
            <div className="space-y-2">
              <textarea
                value={editText}
                onChange={e => setEditText(e.target.value)}
                className="w-full min-h-[200px] text-sm text-gray-700 leading-relaxed p-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-coral/30 resize-y"
              />
              <div className="flex gap-2">
                <button onClick={() => updateMutation.mutate({ narrativeId: latest.id, narrative: editText })}
                  disabled={updateMutation.isPending}
                  className="flex-1 py-2 rounded-xl text-white text-xs font-medium" style={{ background: "#F07167" }}>
                  {updateMutation.isPending ? "Sauvegarde..." : "Sauvegarder"}
                </button>
                <button onClick={() => setEditMode(false)}
                  className="px-4 py-2 rounded-xl text-xs text-gray-500 bg-gray-100 hover:bg-gray-200 transition-colors">
                  Annuler
                </button>
              </div>
            </div>
          ) : (
            <p className="text-sm text-gray-700 leading-relaxed italic whitespace-pre-wrap">{latest.narrative}</p>
          )}
          <div className="flex items-center gap-3 mt-3 flex-wrap">
            <p className="text-xs text-gray-400">Généré le {new Date(latest.createdAt).toLocaleDateString("fr-FR")} · Style : {latest.style}</p>
            {!editMode && (
              <button onClick={() => { setEditText(latest.narrative); setEditMode(true); }}
                className="flex items-center gap-1 text-xs text-gray-500 hover:text-coral transition-colors">
                <Edit3 className="w-3 h-3" /> Éditer
              </button>
            )}
            <button
              onClick={() => {
                const blob = new Blob([latest.narrative], { type: "text/plain;charset=utf-8" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a"); a.href = url; a.download = "notre-histoire-aura.txt"; a.click();
                URL.revokeObjectURL(url);
              }}
              className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-coral transition-colors">
              <Download className="w-3 h-3" /> Télécharger
            </button>
          </div>
        </div>
      ) : (
        <div className="neu-card p-8 text-center">
          <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm mb-2">AURA va rédiger le récit de votre mariage</p>
          <p className="text-xs text-gray-400">Basé sur vos réponses à l'onboarding et vos notes</p>
        </div>
      )}
    </div>
  );
}

// ─── CRISE JOUR J ─────────────────────────────────────────────────────────────
function CrisisPanel({ weddingId }: { weddingId: number }) {
  const [selectedProvider, setSelectedProvider] = useState("");
  const [delayMinutes, setDelayMinutes] = useState(30);
  const [crisisType, setCrisisType] = useState<"delay" | "cancellation" | "weather" | "other">("delay");
  const [crisisResult, setCrisisResult] = useState<string | null>(null);

  const providersQuery = trpc.providers.list.useQuery();
  const crisisMutation = trpc.aiPlanner.crisis.handle.useMutation({
    onSuccess: (data) => setCrisisResult(data.plan),
  });

  const crisisTypes: { id: "delay" | "cancellation" | "weather" | "other"; label: string; icon: React.ElementType }[] = [
    { id: "delay", label: "Retard prestataire", icon: Clock },
    { id: "cancellation", label: "Annulation", icon: AlertTriangle },
    { id: "weather", label: "Météo défavorable", icon: Zap },
    { id: "other", label: "Autre imprévu", icon: Star },
  ];

  return (
    <div className="space-y-4">
      <div className="neu-card p-4">
        <div className="flex items-center gap-2 mb-1">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          <h3 className="font-bold text-gray-800">Scénario de Crise Jour J</h3>
        </div>
        <p className="text-xs text-gray-500">AURA gère les imprévus et ajuste automatiquement le planning</p>
      </div>

      <div className="neu-card p-4 space-y-4">
        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">Type d'imprévu</p>
          <div className="grid grid-cols-2 gap-2">
            {crisisTypes.map(t => (
              <button key={t.id} onClick={() => setCrisisType(t.id)}
                className={`flex items-center gap-2 p-2 rounded-xl text-xs transition-all ${crisisType === t.id ? "text-white" : "neu-card text-gray-600"}`}
                style={crisisType === t.id ? { background: "#F07167" } : {}}
              >
                <t.icon className="w-3.5 h-3.5" />{t.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">Prestataire concerné</p>
          <select value={selectedProvider} onChange={e => setSelectedProvider(e.target.value)}
            className="w-full neu-card p-2 text-sm text-gray-700 rounded-xl outline-none">
            <option value="">Sélectionner un prestataire</option>
            {providersQuery.data?.map(p => <option key={p.id} value={p.name}>{p.name} ({p.category})</option>)}
          </select>
        </div>

        {crisisType === "delay" && (
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Retard estimé : {delayMinutes} minutes</p>
            <input type="range" min={10} max={120} step={5} value={delayMinutes} onChange={e => setDelayMinutes(Number(e.target.value))} className="w-full accent-coral" />
            <div className="flex justify-between text-xs text-gray-400"><span>10 min</span><span>2h</span></div>
          </div>
        )}

        <Button className="w-full text-white font-semibold py-3 rounded-2xl" style={{ background: "#F07167" }}
          disabled={!selectedProvider || crisisMutation.isPending}
          onClick={() => crisisMutation.mutate({ weddingId, crisisType, providerName: selectedProvider, delayMinutes })}
        >
          {crisisMutation.isPending
            ? <><RefreshCw className="w-4 h-4 animate-spin mr-2" />AURA analyse...</>
            : <><Zap className="w-4 h-4 mr-2" />Activer le protocole de crise</>}
        </Button>
      </div>

      {crisisResult && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="neu-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span className="text-sm font-bold text-gray-800">Plan de crise généré par AURA</span>
          </div>
          <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed bg-amber-50 rounded-xl p-3 border border-amber-100">
            {crisisResult}
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── ASSISTANT DEVIS ──────────────────────────────────────────────────────────
function QuoteAssistantPanel({ weddingId }: { weddingId: number }) {
  const [providerCategory, setProviderCategory] = useState("");
  const [providerName, setProviderName] = useState("");
  const [quoteAmount, setQuoteAmount] = useState("");
  const [quoteDetails, setQuoteDetails] = useState("");
  const [result, setResult] = useState<{
    assessment: string;
    marketComparison: string;
    counterOfferSuggestion: number | null;
    questionsToAsk: string[];
    redFlags: string[];
    positivePoints: string[];
    recommendation: string;
  } | null>(null);

  const analyzeMutation = trpc.aiPlanner.quoteAssistant.analyze.useMutation({
    onSuccess: (data) => { setResult(data as typeof result); toast.success("Analyse terminée !"); },
    onError: () => toast.error("Erreur lors de l'analyse"),
  });

  const categories = ["Photographe", "Vidéaste", "Traiteur", "DJ", "Orchestre", "Fleuriste", "Salle", "Wedding Planner", "Coiffeur/Maquilleur", "Autre"];

  const assessmentConfig: Record<string, { label: string; color: string; icon: React.ElementType }> = {
    bon_prix: { label: "Excellent prix", color: "#10b981", icon: ThumbsUp },
    prix_moyen: { label: "Prix dans la moyenne", color: "#f59e0b", icon: TrendingUp },
    prix_eleve: { label: "Prix élevé", color: "#F07167", icon: ThumbsDown },
    prix_tres_eleve: { label: "Prix très élevé", color: "#ef4444", icon: AlertTriangle },
  };

  return (
    <div className="space-y-4">
      <div className="neu-card p-4">
        <div className="flex items-center gap-2 mb-1">
          <FileText className="w-5 h-5" style={{ color: "#F07167" }} />
          <h3 className="font-bold text-gray-800">Analyseur de Devis IA</h3>
        </div>
        <p className="text-xs text-gray-500">AURA analyse votre devis et vous conseille sur la négociation</p>
      </div>

      <div className="neu-card p-4 space-y-3">
        <div>
          <label className="text-xs font-medium text-gray-600 mb-1 block">Catégorie du prestataire</label>
          <select value={providerCategory} onChange={e => setProviderCategory(e.target.value)}
            className="w-full neu-card p-2.5 text-sm text-gray-700 rounded-xl outline-none">
            <option value="">Sélectionner...</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-gray-600 mb-1 block">Nom du prestataire</label>
          <input value={providerName} onChange={e => setProviderName(e.target.value)}
            placeholder="Ex: Studio Lumière" className="w-full neu-input text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-gray-600 mb-1 block">Montant du devis (€)</label>
          <input type="number" value={quoteAmount} onChange={e => setQuoteAmount(e.target.value)}
            placeholder="Ex: 2500" className="w-full neu-input text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-gray-600 mb-1 block">Détails du devis (optionnel)</label>
          <textarea value={quoteDetails} onChange={e => setQuoteDetails(e.target.value)}
            placeholder="Décrivez ce qui est inclus dans le devis..."
            className="w-full neu-input text-sm resize-none" rows={3} />
        </div>
        <Button className="w-full text-white font-semibold py-3 rounded-2xl" style={{ background: "#F07167" }}
          disabled={!providerCategory || !providerName || !quoteAmount || analyzeMutation.isPending}
          onClick={() => analyzeMutation.mutate({ weddingId, providerCategory, providerName, quoteAmount: Number(quoteAmount), quoteDetails })}>
          {analyzeMutation.isPending
            ? <><RefreshCw className="w-4 h-4 animate-spin mr-2" />AURA analyse...</>
            : <><Sparkles className="w-4 h-4 mr-2" />Analyser ce devis</>}
        </Button>
      </div>

      {result && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
          {/* Verdict principal */}
          {(() => {
            const cfg = assessmentConfig[result.assessment] ?? assessmentConfig.prix_moyen;
            const Icon = cfg.icon;
            return (
              <div className="neu-card p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: cfg.color + "20" }}>
                  <Icon className="w-5 h-5" style={{ color: cfg.color }} />
                </div>
                <div>
                  <p className="font-bold text-gray-800">{cfg.label}</p>
                  <p className="text-xs text-gray-500">{result.marketComparison}</p>
                </div>
              </div>
            );
          })()}

          {/* Contre-offre */}
          {result.counterOfferSuggestion && (
            <div className="neu-card p-4">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Contre-offre suggérée</p>
              <p className="text-2xl font-black" style={{ color: "#F07167" }}>{result.counterOfferSuggestion.toLocaleString("fr-FR")} €</p>
              <p className="text-xs text-gray-400">soit {Math.round((1 - result.counterOfferSuggestion / Number(quoteAmount)) * 100)}% de réduction</p>
            </div>
          )}

          {/* Points positifs */}
          {result.positivePoints.length > 0 && (
            <div className="neu-card p-4">
              <p className="text-xs font-semibold text-green-600 uppercase tracking-wide mb-2 flex items-center gap-1">
                <ThumbsUp className="w-3 h-3" /> Points positifs
              </p>
              <ul className="space-y-1">
                {result.positivePoints.map((p, i) => (
                  <li key={i} className="text-sm text-gray-700 flex items-start gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-green-500 flex-shrink-0 mt-0.5" />{p}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Points de vigilance */}
          {result.redFlags.length > 0 && (
            <div className="neu-card p-4">
              <p className="text-xs font-semibold text-red-500 uppercase tracking-wide mb-2 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Points de vigilance
              </p>
              <ul className="space-y-1">
                {result.redFlags.map((f, i) => (
                  <li key={i} className="text-sm text-gray-700 flex items-start gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" />{f}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Questions à poser */}
          {result.questionsToAsk.length > 0 && (
            <div className="neu-card p-4">
              <p className="text-xs font-semibold text-blue-500 uppercase tracking-wide mb-2 flex items-center gap-1">
                <HelpCircle className="w-3 h-3" /> Questions à poser au prestataire
              </p>
              <ul className="space-y-1">
                {result.questionsToAsk.map((q, i) => (
                  <li key={i} className="text-sm text-gray-700 flex items-start gap-2">
                    <span className="font-bold text-blue-400 flex-shrink-0">{i + 1}.</span>{q}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Recommandation finale */}
          <div className="neu-card p-4" style={{ borderLeft: "3px solid #F07167" }}>
            <p className="text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: "#F07167" }}>Recommandation AURA</p>
            <p className="text-sm text-gray-700 leading-relaxed">{result.recommendation}</p>
          </div>

          {/* Export */}
          <button
            onClick={() => {
              const text = `ANALYSE DE DEVIS — AURA Wedding OS\n\n` +
                `Prestataire: ${providerName} (${providerCategory})\nMontant: ${quoteAmount}€\n\n` +
                `VERDICT: ${assessmentConfig[result.assessment]?.label ?? result.assessment}\n${result.marketComparison}\n\n` +
                (result.counterOfferSuggestion ? `CONTRE-OFFRE SUGGÉRÉE: ${result.counterOfferSuggestion}€\n\n` : "") +
                `POINTS POSITIFS:\n${result.positivePoints.map(p => `• ${p}`).join("\n")}\n\n` +
                `POINTS DE VIGILANCE:\n${result.redFlags.map(f => `• ${f}`).join("\n")}\n\n` +
                `QUESTIONS À POSER:\n${result.questionsToAsk.map((q, i) => `${i + 1}. ${q}`).join("\n")}\n\n` +
                `RECOMMANDATION: ${result.recommendation}`;
              const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a"); a.href = url; a.download = `analyse-devis-${providerName.replace(/\s/g, "-")}.txt`; a.click();
              URL.revokeObjectURL(url);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm text-gray-600 neu-card hover:text-coral transition-colors">
            <Download className="w-4 h-4" /> Exporter l'analyse
          </button>
        </motion.div>
      )}
    </div>
  );
}
