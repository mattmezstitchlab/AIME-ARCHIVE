import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import SignaturePad from "@/components/SignaturePad";
import {
  FileText, PenLine, CheckCircle2, Clock, ShieldCheck,
  Plus, Euro, Loader2, AlertCircle, ChevronDown, ChevronUp,
  Banknote, Calendar
} from "lucide-react";

const STATUS_COLORS: Record<string, string> = {
  draft:           "bg-gray-100 text-gray-600",
  sent:            "bg-blue-100 text-blue-700",
  signed_provider: "bg-orange-100 text-orange-700",
  signed_couple:   "bg-indigo-100 text-indigo-700",
  fully_signed:    "bg-green-100 text-green-700",
  cancelled:       "bg-red-100 text-red-700",
};

const STATUS_LABELS: Record<string, string> = {
  draft:           "Brouillon",
  sent:            "Envoyé au prestataire",
  signed_provider: "Signé par le prestataire",
  signed_couple:   "Signé par vous",
  fully_signed:    "Entièrement signé",
  cancelled:       "Annulé",
};

function NeuCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl p-5 ${className}`}
      style={{ background: "#eef0f5", boxShadow: "6px 6px 12px #d1d4db, -6px -6px 12px #ffffff" }}>
      {children}
    </div>
  );
}

interface ContractManagerProps {
  providers: Array<{ id: number; name: string; category: string }>;
}

export default function ContractManager({ providers }: ContractManagerProps) {
  const [showCreate, setShowCreate] = useState(false);
  const [showSign, setShowSign] = useState(false);
  const [signContractId, setSignContractId] = useState<number | null>(null);
  const [signerName, setSignerName] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const [form, setForm] = useState({
    providerId: 0,
    title: "",
    content: "",
    amount: "",
    depositAmount: "",
    validUntil: "",
    notes: "",
  });

  const { data: contracts = [], refetch } = trpc.providerSpace.coupleContracts.list.useQuery();

  const createContract = trpc.providerSpace.contracts.create.useMutation({
    onSuccess: () => {
      toast.success("Contrat créé et envoyé au prestataire");
      setShowCreate(false);
      setForm({ providerId: 0, title: "", content: "", amount: "", depositAmount: "", validUntil: "", notes: "" });
      refetch();
    },
    onError: () => toast.error("Erreur lors de la création du contrat"),
  });

  const signAsCouple = trpc.providerSpace.contracts.signAsCouple.useMutation({
    onSuccess: (data) => {
      toast.success(
        data.status === "fully_signed"
          ? "Contrat entièrement signé par les deux parties !"
          : "Votre signature a été enregistrée. En attente de la signature du prestataire."
      );
      setShowSign(false);
      setSignContractId(null);
      refetch();
    },
    onError: () => toast.error("Erreur lors de la signature"),
  });

  const markPayment = trpc.providerSpace.contracts.markPayment.useMutation({
    onSuccess: () => { toast.success("Paiement enregistré"); refetch(); },
    onError: () => toast.error("Erreur lors de l'enregistrement"),
  });

  const pendingSignature = contracts.filter(c =>
    c.status === "signed_provider" && !c.coupleSignatureData
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
          <FileText size={20} className="text-[#F07167]" />
          Gestion des contrats
        </h2>
        <Button
          onClick={() => setShowCreate(true)}
          style={{ background: "#F07167", color: "white", border: "none" }}
          className="gap-1"
          size="sm"
        >
          <Plus size={14} /> Nouveau contrat
        </Button>
      </div>

      {/* Alerte signatures en attente */}
      {pendingSignature.length > 0 && (
        <div className="p-3 rounded-xl bg-orange-50 border border-orange-200 flex items-start gap-2">
          <AlertCircle size={16} className="text-orange-500 mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-medium text-orange-700">
              {pendingSignature.length} contrat{pendingSignature.length > 1 ? "s" : ""} en attente de votre signature
            </p>
            <p className="text-xs text-orange-600 mt-0.5">
              Le prestataire a signé. Signez à votre tour pour finaliser le contrat.
            </p>
          </div>
        </div>
      )}

      {/* Liste des contrats */}
      {contracts.length === 0 ? (
        <NeuCard className="text-center py-10">
          <FileText size={40} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500 mb-2">Aucun contrat créé pour l'instant.</p>
          <Button
            size="sm"
            onClick={() => setShowCreate(true)}
            style={{ background: "#F07167", color: "white", border: "none" }}
          >
            <Plus size={14} className="mr-1" /> Créer le premier contrat
          </Button>
        </NeuCard>
      ) : (
        contracts.map(contract => (
          <NeuCard key={contract.id}>
            {/* En-tête contrat */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <h3 className="font-semibold text-gray-800">{contract.title}</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[contract.status]}`}>
                    {STATUS_LABELS[contract.status]}
                  </span>
                </div>
                <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                  {contract.amount && (
                    <span className="flex items-center gap-1">
                      <Euro size={12} /> {parseFloat(contract.amount).toLocaleString("fr-FR")} €
                    </span>
                  )}
                  {contract.depositAmount && (
                    <span className="flex items-center gap-1 text-xs text-gray-400">
                      Acompte : {parseFloat(contract.depositAmount).toLocaleString("fr-FR")} €
                    </span>
                  )}
                  {contract.validUntil && (
                    <span className="flex items-center gap-1 text-xs text-gray-400">
                      <Calendar size={11} /> Valide jusqu'au {new Date(contract.validUntil).toLocaleDateString("fr-FR")}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* Bouton signer */}
                {contract.status === "signed_provider" && !contract.coupleSignatureData && (
                  <Button
                    size="sm"
                    onClick={() => { setSignContractId(contract.id); setShowSign(true); }}
                    style={{ background: "#F07167", color: "white", border: "none" }}
                    className="gap-1"
                  >
                    <PenLine size={14} /> Signer
                  </Button>
                )}
                {contract.status === "fully_signed" && (
                  <span className="flex items-center gap-1 text-green-600 text-xs font-medium">
                    <ShieldCheck size={14} /> Signé
                  </span>
                )}

                {/* Toggle détails */}
                <button
                  onClick={() => setExpandedId(expandedId === contract.id ? null : contract.id)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  {expandedId === contract.id ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
              </div>
            </div>

            {/* Détails expandables */}
            {expandedId === contract.id && (
              <div className="mt-4 space-y-3 border-t border-gray-200 pt-4">
                {/* Signatures */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-white/60">
                    <p className="text-xs text-gray-400 mb-1">Signature prestataire</p>
                    {contract.providerSignatureData ? (
                      <div>
                        <img src={contract.providerSignatureData} alt="Signature prestataire" className="h-10 rounded border border-gray-200 bg-white mb-1" />
                        <p className="text-xs text-green-600 flex items-center gap-1">
                          <ShieldCheck size={11} /> {contract.providerSignerName} — {new Date(contract.providerSignedAt!).toLocaleDateString("fr-FR")}
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-orange-500 flex items-center gap-1">
                        <Clock size={11} /> En attente
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl bg-white/60">
                    <p className="text-xs text-gray-400 mb-1">Votre signature</p>
                    {contract.coupleSignatureData ? (
                      <div>
                        <img src={contract.coupleSignatureData} alt="Votre signature" className="h-10 rounded border border-gray-200 bg-white mb-1" />
                        <p className="text-xs text-green-600 flex items-center gap-1">
                          <ShieldCheck size={11} /> {contract.coupleSignerName} — {new Date(contract.coupleSignedAt!).toLocaleDateString("fr-FR")}
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-gray-400 flex items-center gap-1">
                        <Clock size={11} /> Non signé
                      </p>
                    )}
                  </div>
                </div>

                {/* Paiements */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/60">
                    <div>
                      <p className="text-xs text-gray-400">Acompte</p>
                      <p className="text-sm font-medium text-gray-700">
                        {contract.depositAmount ? `${parseFloat(contract.depositAmount).toLocaleString("fr-FR")} €` : "—"}
                      </p>
                    </div>
                    {contract.depositPaid ? (
                      <span className="text-xs text-green-600 flex items-center gap-1">
                        <CheckCircle2 size={12} /> Payé
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs h-7"
                        onClick={() => markPayment.mutate({ contractId: contract.id, type: "deposit" })}
                      >
                        <Banknote size={11} className="mr-1" /> Marquer payé
                      </Button>
                    )}
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/60">
                    <div>
                      <p className="text-xs text-gray-400">Solde</p>
                      <p className="text-sm font-medium text-gray-700">
                        {contract.amount && contract.depositAmount
                          ? `${(parseFloat(contract.amount) - parseFloat(contract.depositAmount)).toLocaleString("fr-FR")} €`
                          : "—"}
                      </p>
                    </div>
                    {contract.balancePaid ? (
                      <span className="text-xs text-green-600 flex items-center gap-1">
                        <CheckCircle2 size={12} /> Payé
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs h-7"
                        onClick={() => markPayment.mutate({ contractId: contract.id, type: "balance" })}
                      >
                        <Banknote size={11} className="mr-1" /> Marquer payé
                      </Button>
                    )}
                  </div>
                </div>

                {/* Contenu */}
                {contract.content && (
                  <div className="p-3 rounded-xl bg-white/60 text-xs text-gray-600 whitespace-pre-wrap max-h-40 overflow-y-auto">
                    {contract.content}
                  </div>
                )}
              </div>
            )}
          </NeuCard>
        ))
      )}

      {/* ── Dialog Création Contrat ── */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg" style={{ background: "#E8EDF2", border: "none", borderRadius: "1.5rem" }}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-gray-800">
              <Plus size={18} className="text-[#F07167]" />
              Nouveau contrat prestataire
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Prestataire</label>
              <select
                value={form.providerId}
                onChange={e => setForm(prev => ({ ...prev, providerId: parseInt(e.target.value) }))}
                className="w-full rounded-xl px-3 py-2 text-sm border-0 outline-none"
                style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
              >
                <option value={0}>Sélectionner un prestataire...</option>
                {providers.map(p => (
                  <option key={p.id} value={p.id}>{p.name} ({p.category})</option>
                ))}
              </select>
            </div>
            {[
              { key: "title", label: "Titre du contrat", placeholder: "Contrat Photographe — Mariage Sophie & Thomas" },
              { key: "amount", label: "Montant total (€)", placeholder: "3500" },
              { key: "depositAmount", label: "Acompte (€)", placeholder: "1000" },
              { key: "validUntil", label: "Valide jusqu'au", placeholder: "", type: "date" },
            ].map(field => (
              <div key={field.key}>
                <label className="text-xs text-gray-500 mb-1 block">{field.label}</label>
                <Input
                  type={field.type ?? "text"}
                  value={(form as any)[field.key]}
                  onChange={e => setForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                  placeholder={field.placeholder}
                  className="rounded-xl border-0"
                  style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
                />
              </div>
            ))}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Contenu du contrat</label>
              <Textarea
                value={form.content}
                onChange={e => setForm(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Rédigez ici les clauses du contrat, les prestations incluses, les conditions d'annulation..."
                rows={5}
                className="rounded-xl border-0"
                style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
              />
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="ghost" onClick={() => setShowCreate(false)}>Annuler</Button>
              <Button
                onClick={() => createContract.mutate(form)}
                disabled={createContract.isPending || !form.providerId || !form.title}
                style={{ background: "#F07167", color: "white", border: "none" }}
                className="gap-1"
              >
                {createContract.isPending ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                Créer et envoyer
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Dialog Signature Mariés ── */}
      <Dialog open={showSign} onOpenChange={setShowSign}>
        <DialogContent className="max-w-lg" style={{ background: "#E8EDF2", border: "none", borderRadius: "1.5rem" }}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-gray-800">
              <PenLine size={18} className="text-[#F07167]" />
              Signer le contrat
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {signContractId && (() => {
              const contract = contracts.find(c => c.id === signContractId);
              return contract ? (
                <div className="p-3 rounded-xl bg-white/60 text-sm">
                  <p className="font-semibold text-gray-800">{contract.title}</p>
                  {contract.amount && (
                    <p className="text-gray-500 text-xs mt-0.5">Montant : {parseFloat(contract.amount).toLocaleString("fr-FR")} €</p>
                  )}
                  {contract.providerSignatureData && (
                    <div className="mt-2 flex items-center gap-2">
                      <img src={contract.providerSignatureData} alt="Signature prestataire" className="h-8 rounded border border-gray-200 bg-white" />
                      <span className="text-xs text-green-600 flex items-center gap-1">
                        <ShieldCheck size={11} /> Signé par {contract.providerSignerName}
                      </span>
                    </div>
                  )}
                </div>
              ) : null;
            })()}

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Votre nom complet</label>
              <Input
                value={signerName}
                onChange={e => setSignerName(e.target.value)}
                placeholder="Sophie Martin"
                className="rounded-xl border-0"
                style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
              />
            </div>

            <SignaturePad
              label="Votre signature"
              signerName={signerName || undefined}
              width={460}
              height={160}
              onCancel={() => { setShowSign(false); setSignContractId(null); }}
              onSave={(dataUrl) => {
                if (!signerName.trim()) {
                  toast.error("Veuillez saisir votre nom complet.");
                  return;
                }
                if (!signContractId) return;
                signAsCouple.mutate({
                  contractId: signContractId,
                  signatureData: dataUrl,
                  signerName: signerName.trim(),
                });
              }}
            />

            <p className="text-xs text-gray-400 text-center">
              En validant, vous acceptez que cette signature électronique ait valeur légale (eIDAS UE n°910/2014).
              Horodatage : {new Date().toLocaleString("fr-FR")}.
            </p>

            {signAsCouple.isPending && (
              <div className="flex items-center justify-center gap-2 text-[#F07167]">
                <Loader2 size={16} className="animate-spin" />
                <span className="text-sm">Enregistrement...</span>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
