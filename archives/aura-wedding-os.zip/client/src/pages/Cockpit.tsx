import { useState, useRef, useEffect } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import NotificationsPanel from "@/components/NotificationsPanel";
import CsvImportModal from "@/components/CsvImportModal";
import { PushNotificationsCard } from "@/components/PushNotificationsCard";
import { jsPDF } from "jspdf";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import {
  Heart, Sparkles, Clock, Wallet, Users, Store, FileText,
  Camera, Brain, MapPin, Calendar, Settings, LogOut,
  Plus, Send, ChevronRight, Check, X, Edit2, Trash2,
  Download, Upload, Star, Phone, Mail, Globe, BarChart2, Moon, Sun,
  Music, Flower2, Home, Bell, Search, Filter, PenLine,
  AlertTriangle, RefreshCw, Zap
} from "lucide-react";
import { toast } from "sonner";
import ContractManager from "./ContractManager";
import AIPlannerHub from "./AIPlannerHub";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, RadialBarChart, RadialBar } from "recharts";
import OnboardingChat from "./OnboardingChat";

// ─── Panel types ─────────────────────────────────────────────────────────────
type PanelId = "dashboard" | "chat" | "timeline" | "budget" | "providers" | "contracts" | "guests" | "documents" | "memory" | "minisite" | "dayof" | "photowall" | "settings";

interface PictoItem {
  id: PanelId;
  icon: React.ElementType;
  label: string;
  badge?: number;
  color?: string;
}

const PICTOS: PictoItem[] = [
  { id: "dashboard", icon: Home, label: "Accueil" },
  { id: "chat", icon: Sparkles, label: "AURA IA", color: "var(--coral)" },
  { id: "timeline", icon: Clock, label: "Timeline", badge: 0 },
  { id: "budget", icon: Wallet, label: "Budget" },
  { id: "providers", icon: Store, label: "Presta." },
  { id: "guests", icon: Users, label: "Invités" },
  { id: "contracts", icon: PenLine, label: "Contrats" },
  { id: "documents", icon: FileText, label: "Docs" },
  { id: "memory", icon: Brain, label: "Mémoire" },
  { id: "minisite", icon: Globe, label: "Mini-site" },
  { id: "dayof", icon: Calendar, label: "Jour J" },
  { id: "photowall", icon: Camera, label: "Photos" },
  { id: "settings", icon: Settings, label: "Réglages" },
];

// ─── Cockpit Shell ────────────────────────────────────────────────────────────
export default function Cockpit() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activePanel, setActivePanel] = useState<PanelId>("dashboard");
  const [showNotifications, setShowNotifications] = useState(false);
  const { data: notifCount } = trpc.providerNotifications.unreadCount.useQuery(undefined, {
    refetchInterval: 15000,
  });
  const unreadNotifCount = notifCount?.count || 0;

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl();
    }
  }, [loading, isAuthenticated]);

  if (loading) return <CockpitSkeleton />;
  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen flex" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>
      {/* ─── Sidebar ─────────────────────────────────────────────────── */}
      <aside className="w-20 lg:w-24 flex flex-col items-center py-6 gap-2 fixed left-0 top-0 bottom-0 z-40"
        style={{ background: "var(--neu-bg)", boxShadow: "4px 0 15px rgba(0,0,0,0.05)" }}>
        {/* Logo */}
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 neu-btn-coral cursor-pointer" onClick={() => setLocation("/")}>
          <Heart className="w-6 h-6 text-white" />
        </div>
        {/* Pictos */}
        <div className="flex flex-col gap-2 flex-1 w-full px-2">
          {PICTOS.map(({ id, icon: Icon, label, badge, color }) => (
            <button
              key={id}
              onClick={() => setActivePanel(id)}
              className={`neu-picto w-full ${activePanel === id ? "active" : ""}`}
              style={{ padding: "0.625rem" }}
            >
              <Icon className="w-5 h-5" style={{ color: activePanel === id ? "var(--coral)" : color || "#8a9ab5" }} />
              <span className="text-[9px] font-medium" style={{ color: activePanel === id ? "var(--coral)" : "#8a9ab5" }}>
                {label}
              </span>
              {badge && badge > 0 ? <div className="neu-badge">{badge}</div> : null}
            </button>
          ))}
        </div>
        {/* Notifications */}
        <button
          onClick={() => setShowNotifications(s => !s)}
          className="neu-picto w-full mx-2 relative"
          style={{ padding: "0.625rem" }}
        >
          <Bell className="w-5 h-5 text-muted-foreground" />
          <span className="text-[9px] text-muted-foreground">Alertes</span>
          {unreadNotifCount > 0 && (
            <div className="neu-badge" style={{ background: "var(--coral)" }}>{unreadNotifCount > 9 ? "9+" : unreadNotifCount}</div>
          )}
        </button>
        {/* Dark mode toggle */}
        <DarkModeToggle />
        {/* Logout */}
        <button onClick={logout} className="neu-picto w-full mx-2" style={{ padding: "0.625rem" }}>
          <LogOut className="w-5 h-5 text-muted-foreground" />
          <span className="text-[9px] text-muted-foreground">Sortir</span>
        </button>
      </aside>

      {/* ─── Main Content ─────────────────────────────────────────────── */}
      <main className="flex-1 ml-20 lg:ml-24 p-6 overflow-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePanel}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activePanel === "dashboard" && <DashboardPanel setActivePanel={setActivePanel} user={user} />}
            {activePanel === "chat" && <ChatPanel />}
            {activePanel === "timeline" && <TimelinePanel />}
            {activePanel === "budget" && <BudgetPanel />}
            {activePanel === "providers" && <ProvidersPanel />}
            {activePanel === "guests" && <GuestsPanel />}
            {activePanel === "contracts" && <ContractsPanel />}
            {activePanel === "documents" && <DocumentsPanel />}
            {activePanel === "memory" && <MemoryPanel />}
            {activePanel === "minisite" && <MiniSitePanel />}
            {activePanel === "dayof" && <DayOfPanel />}
            {activePanel === "photowall" && <PhotoWallPanel />}
            {activePanel === "settings" && <SettingsPanel user={user} />}
          </motion.div>
        </AnimatePresence>
      </main>
      {showNotifications && <NotificationsPanel onClose={() => setShowNotifications(false)} />}
    </div>
  );
}

// ─── Dark Mode Toggle ─────────────────────────────────────────────────────────
function DarkModeToggle() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      className="neu-picto w-full mx-2"
      style={{ padding: "0.625rem" }}
      title={theme === "dark" ? "Mode clair" : "Mode sombre"}
    >
      {theme === "dark"
        ? <Sun className="w-5 h-5" style={{ color: "#F0A067" }} />
        : <Moon className="w-5 h-5 text-muted-foreground" />
      }
      <span className="text-[9px] text-muted-foreground">{theme === "dark" ? "Clair" : "Sombre"}</span>
    </button>
  );
}
// ─── Skeleton ─────────────────────────────────────────────────────────────────
function CockpitSkeleton() {
  return (
    <div className="min-h-screen flex" style={{ background: "var(--neu-bg)" }}>
      <div className="w-20 lg:w-24" style={{ background: "var(--neu-bg)", boxShadow: "4px 0 15px rgba(0,0,0,0.05)" }} />
      <div className="flex-1 p-6 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl neu-btn-coral flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Heart className="w-8 h-8 text-white" />
          </div>
          <p className="text-muted-foreground">Chargement de votre espace AURA...</p>
        </div>
      </div>
    </div>
  );
}

// ─── Panel Header ─────────────────────────────────────────────────────────────
function PanelHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-8">
      <div>
        <h1 className="text-2xl font-black">{title}</h1>
        {subtitle && <p className="text-muted-foreground text-sm mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

// ─── Reminders Card ─────────────────────────────────────────────────────────
function RemindersCard() {
  const utils = trpc.useUtils();
  const { data: status, isLoading } = trpc.reminders.status.useQuery();
  const setupMutation = trpc.reminders.setup.useMutation({
    onSuccess: () => {
      toast.success("Rappels programmés avec succès !");
      utils.reminders.status.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });
  const cancelMutation = trpc.reminders.cancel.useMutation({
    onSuccess: () => {
      toast.success("Rappels annulés.");
      utils.reminders.status.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const reminders = status?.reminders ?? [
    { label: "J-30", taskUid: null },
    { label: "J-7",  taskUid: null },
    { label: "J-1",  taskUid: null },
  ];

  return (
    <div className="neu-card p-6 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-bold">Rappels programmés</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Notifications automatiques à J-30, J-7 et J-1 avant votre mariage</p>
        </div>
        <div className="flex gap-2">
          {status?.active ? (
            <button
              onClick={() => cancelMutation.mutate()}
              disabled={cancelMutation.isPending}
              className="px-4 py-2 text-xs font-semibold rounded-xl border border-red-200 text-red-500 hover:bg-red-50 disabled:opacity-50 transition-colors"
            >
              {cancelMutation.isPending ? "Annulation..." : "Annuler les rappels"}
            </button>
          ) : null}
          <button
            onClick={() => setupMutation.mutate()}
            disabled={setupMutation.isPending || isLoading}
            className="neu-btn-coral px-4 py-2 text-xs font-semibold text-white rounded-xl disabled:opacity-50"
          >
            {setupMutation.isPending ? "Programmation..." : status?.active ? "Reprogrammer" : "Activer les rappels"}
          </button>
        </div>
      </div>

      {/* Liste des 3 rappels */}
      <div className="grid grid-cols-3 gap-3">
        {reminders.map(({ label, taskUid }) => (
          <div
            key={label}
            className="rounded-xl p-3 text-center"
            style={{
              background: taskUid ? "rgba(240,113,103,0.08)" : "var(--neu-shadow-light)",
              border: taskUid ? "1px solid rgba(240,113,103,0.2)" : "1px solid transparent",
            }}
          >
            <div className="text-lg mb-1">
              {label === "J-30" ? "📅" : label === "J-7" ? "⏰" : "💍"}
            </div>
            <div className="text-sm font-bold" style={{ color: taskUid ? "var(--coral)" : undefined }}>{label}</div>
            <div className="text-[10px] text-muted-foreground mt-0.5">
              {taskUid ? "✓ Programmé" : "Non actif"}
            </div>
          </div>
        ))}
      </div>

      {!status?.weddingDate && (
        <p className="text-xs text-amber-600 mt-3 p-2 rounded-lg" style={{ background: "rgba(245,158,11,0.08)" }}>
          ⚠️ Définissez d'abord la date de votre mariage ci-dessus pour activer les rappels.
        </p>
      )}
    </div>
  );
}

// ─── Dashboard Panel ──────────────────────────────────────────────────────────
function DashboardPanel({ setActivePanel, user }: { setActivePanel: (p: PanelId) => void; user: any }) {
  const { data: wedding } = trpc.wedding.get.useQuery();
  const { data: guests } = trpc.guests.list.useQuery();
  const { data: budgetItems } = trpc.budget.list.useQuery();
  const { data: providers } = trpc.providers.list.useQuery();
  const { data: timeline } = trpc.timeline.list.useQuery();
  const { data: missions } = trpc.providers.listMissions.useQuery();
  const confirmedMissions = missions?.filter((m: any) => m.status === "completed").length || 0;
  const totalMissions = missions?.length || 0;

  const confirmedGuests = guests?.filter(g => g.rsvpStatus === "confirmed").length || 0;
  const totalGuests = guests?.length || 0;
  const bookedProviders = providers?.filter(p => p.status === "booked").length || 0;
  const totalBudget = budgetItems?.reduce((s, i) => s + parseFloat(String(i.estimatedAmount || 0)), 0) || 0;
  const spentBudget = budgetItems?.reduce((s, i) => s + parseFloat(String(i.actualAmount || 0)), 0) || 0;
  const doneSteps = timeline?.filter(t => t.status === "done").length || 0;
  const totalSteps = timeline?.length || 0;

  const daysLeft = wedding?.weddingDate
    ? Math.ceil((new Date(wedding.weddingDate).getTime() - Date.now()) / 86400000)
    : null;

  return (
    <div>
      <PanelHeader
        title={`Bonjour ${user?.name?.split(" ")[0] || ""}  ✨`}
        subtitle="Voici l'état de votre mariage aujourd'hui"
      />
      {/* Wedding date banner */}
      {daysLeft !== null && (
        <div className="neu-card p-6 mb-6 flex items-center justify-between" style={{ background: "linear-gradient(135deg, rgba(240,113,103,0.08), rgba(240,113,103,0.03))" }}>
          <div>
            <p className="text-sm text-muted-foreground">Votre grand jour</p>
            <h2 className="text-3xl font-black" style={{ color: "var(--coral)" }}>
              {daysLeft > 0 ? `J-${daysLeft}` : daysLeft === 0 ? "Aujourd'hui !" : "Passé"}
            </h2>
            {wedding?.weddingDate && (
              <p className="text-sm text-muted-foreground mt-1">
                {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
              </p>
            )}
          </div>
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center neu-btn-coral">
            <Heart className="w-8 h-8 text-white" />
          </div>
        </div>
      )}
      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Invités confirmés", value: `${confirmedGuests}/${totalGuests}`, icon: Users, color: "#60B4C8", panel: "guests" as PanelId },
          { label: "Prestataires réservés", value: `${bookedProviders}/${providers?.length || 0}`, icon: Store, color: "#7BC47F", panel: "providers" as PanelId },
          { label: "Budget utilisé", value: `${Math.round(spentBudget).toLocaleString("fr-FR")}€`, sub: `sur ${Math.round(totalBudget).toLocaleString("fr-FR")}€`, icon: Wallet, color: "var(--coral)", panel: "budget" as PanelId },
          { label: "Étapes planifiées", value: `${doneSteps}/${totalSteps}`, icon: Clock, color: "#C4A87B", panel: "timeline" as PanelId },
        ].map(({ label, value, sub, icon: Icon, color, panel }) => (
          <button key={label} onClick={() => setActivePanel(panel)} className="neu-card p-5 text-left hover:scale-[1.02] transition-transform">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center neu-inset">
                <Icon className="w-5 h-5" style={{ color }} />
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>
            <p className="text-2xl font-black mb-1" style={{ color }}>{value}</p>
            {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
            <p className="text-xs text-muted-foreground mt-1">{label}</p>
          </button>
        ))}
      </div>
      {/* ── Analytics Section ─────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Budget gauge */}
        <div className="neu-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-sm">Budget</h4>
            <span className="text-xs text-muted-foreground">
              {totalBudget > 0 ? `${Math.round((spentBudget / totalBudget) * 100)}%` : "—"}
            </span>
          </div>
          <ResponsiveContainer width="100%" height={120}>
            <RadialBarChart
              cx="50%" cy="100%"
              innerRadius="60%" outerRadius="90%"
              startAngle={180} endAngle={0}
              data={[
                { name: "Restant", value: Math.max(0, totalBudget - spentBudget), fill: "var(--neu-shadow-light)" },
                { name: "Dépensé", value: spentBudget, fill: "var(--coral)" },
              ]}
            >
              <RadialBar dataKey="value" />
              <Tooltip formatter={(v: number) => `${Math.round(v).toLocaleString("fr-FR")}€`} />
            </RadialBarChart>
          </ResponsiveContainer>
          <div className="flex justify-between text-xs mt-1">
            <span className="text-muted-foreground">Dépensé : <strong style={{ color: "var(--coral)" }}>{Math.round(spentBudget).toLocaleString("fr-FR")}€</strong></span>
            <span className="text-muted-foreground">Total : {Math.round(totalBudget).toLocaleString("fr-FR")}€</span>
          </div>
        </div>

        {/* RSVP donut */}
        <div className="neu-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-sm">RSVP Invités</h4>
            <span className="text-xs text-muted-foreground">{totalGuests} invités</span>
          </div>
          <ResponsiveContainer width="100%" height={120}>
            <PieChart>
              <Pie
                data={[
                  { name: "Confirmés", value: guests?.filter(g => g.rsvpStatus === "confirmed").length || 0 },
                  { name: "En attente", value: guests?.filter(g => g.rsvpStatus === "pending").length || 0 },
                  { name: "Déclinés",  value: guests?.filter(g => g.rsvpStatus === "declined").length || 0 },
                ]}
                cx="50%" cy="50%"
                innerRadius={30} outerRadius={50}
                dataKey="value"
                paddingAngle={2}
              >
                <Cell fill="#7BC47F" />
                <Cell fill="#C4A87B" />
                <Cell fill="#F07167" />
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-around text-[10px] mt-1">
            {[
              { label: "Confirmés", color: "#7BC47F", count: guests?.filter(g => g.rsvpStatus === "confirmed").length || 0 },
              { label: "Attente",   color: "#C4A87B", count: guests?.filter(g => g.rsvpStatus === "pending").length || 0 },
              { label: "Déclinés", color: "#F07167", count: guests?.filter(g => g.rsvpStatus === "declined").length || 0 },
            ].map(({ label, color, count }) => (
              <span key={label} className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full" style={{ background: color }} />
                <span className="text-muted-foreground">{label} <strong>{count}</strong></span>
              </span>
            ))}
          </div>
        </div>

        {/* Missions bar chart */}
        <div className="neu-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-sm">Avancement global</h4>
            <span className="text-xs text-muted-foreground">{doneSteps}/{totalSteps} étapes</span>
          </div>
          <ResponsiveContainer width="100%" height={120}>
            <BarChart
              data={[
                { name: "Timeline", done: doneSteps, total: totalSteps },
              { name: "Presta.", done: bookedProviders,   total: providers?.length || 0 },
              { name: "Missions", done: confirmedMissions, total: Math.max(totalMissions, 1) },
              ]}
              barSize={16}
              margin={{ top: 4, right: 4, left: -20, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip />
              <Bar dataKey="total" fill="var(--neu-shadow-light)" radius={[4,4,0,0]} name="Total" />
              <Bar dataKey="done"  fill="var(--coral)"            radius={[4,4,0,0]} name="Fait" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quick actions */}
      <div className="neu-card p-6">
        <h3 className="font-bold mb-4">Accès rapide</h3>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {PICTOS.filter(p => !["dashboard", "settings"].includes(p.id)).map(({ id, icon: Icon, label }) => (
            <button key={id} onClick={() => setActivePanel(id)} className="neu-picto p-3 gap-1">
              <Icon className="w-5 h-5" style={{ color: "var(--coral)" }} />
              <span className="text-[10px] text-muted-foreground">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Chat Panel (IA AURA) ─────────────────────────────────────────────────────
type ChatTab = "chat" | "onboarding" | "hub";
function ChatPanel() {
  const [chatTab, setChatTab] = useState<ChatTab>("chat");
  const chatTabs: { id: ChatTab; label: string; emoji: string }[] = [
    { id: "chat", label: "Chat AURA", emoji: "💬" },
    { id: "onboarding", label: "Onboarding", emoji: "🎯" },
    { id: "hub", label: "Hub IA", emoji: "✨" },
  ];
  return (
    <div className="flex flex-col" style={{ minHeight: "calc(100vh - 3rem)" }}>
      <PanelHeader title="AURA — Intelligence Artificielle" subtitle="Votre wedding planner IA personnel" />
      {/* Tab switcher */}
      <div className="neu-card p-1.5 flex gap-1 mb-6">
        {chatTabs.map(t => (
          <button key={t.id} onClick={() => setChatTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              chatTab === t.id ? "text-white shadow-inner" : "text-gray-600"
            }`}
            style={chatTab === t.id ? { background: "#F07167" } : {}}>
            <span>{t.emoji}</span>{t.label}
          </button>
        ))}
      </div>
      {chatTab === "onboarding" && <OnboardingChat />}
      {chatTab === "hub" && <AIPlannerHub />}
      {chatTab === "chat" && <ChatConversation />}
    </div>
  );
}
function ChatConversation() {
  const { data: history, refetch } = trpc.chat.history.useQuery();
  const sendMutation = trpc.chat.send.useMutation({ onSuccess: () => { refetch(); setInput(""); } });
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [history]);

  const handleSend = () => {
    if (!input.trim() || sendMutation.isPending) return;
    sendMutation.mutate({ message: input.trim() });
  };

  return (
    <div className="flex flex-col h-[calc(100vh-3rem)]">
      <PanelHeader title="AURA — Votre IA" subtitle="Parlez à AURA, elle organise tout pour vous" />
      {/* Messages */}
      <div className="flex-1 overflow-auto space-y-4 mb-4 pr-2">
        {(!history || history.length === 0) && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 neu-btn-coral">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-2">Bonjour ! Je suis AURA</h3>
            <p className="text-muted-foreground text-sm max-w-md mx-auto">
              Dites-moi la date de votre mariage, votre budget, le nombre d'invités... Je mets tout à jour automatiquement dans vos modules.
            </p>
            <div className="flex flex-wrap gap-2 justify-center mt-6">
              {["Notre mariage est le 15 juin 2026", "Budget de 25 000€ pour 120 invités", "Nous cherchons un photographe à Paris"].map(s => (
                <button key={s} onClick={() => setInput(s)} className="neu-btn px-4 py-2 text-sm text-muted-foreground rounded-xl">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
        {history?.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role === "assistant" && (
              <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mr-3 neu-btn-coral">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            )}
            <div className={`max-w-[75%] rounded-2xl px-4 py-3 ${msg.role === "user" ? "text-white" : "neu-card"}`}
              style={msg.role === "user" ? { background: "linear-gradient(135deg, var(--coral-light), var(--coral))" } : {}}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
              {msg.propagatedModules && (
                <div className="mt-2 pt-2 border-t border-white/20">
                  <p className="text-xs opacity-70">Modules mis à jour : {msg.propagatedModules}</p>
                </div>
              )}
            </div>
          </div>
        ))}
        {sendMutation.isPending && (
          <div className="flex justify-start">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mr-3 neu-btn-coral">
              <Sparkles className="w-4 h-4 text-white animate-pulse" />
            </div>
            <div className="neu-card rounded-2xl px-4 py-3">
              <div className="flex gap-1">
                {[0,1,2].map(i => <div key={i} className="w-2 h-2 rounded-full animate-bounce" style={{ background: "var(--coral)", animationDelay: `${i*0.15}s` }} />)}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      {/* Input */}
      <div className="flex gap-3">
        <input
          className="neu-input flex-1"
          placeholder="Parlez à AURA... (date, budget, invités, prestataires...)"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && !e.shiftKey && handleSend()}
        />
        <button onClick={handleSend} disabled={!input.trim() || sendMutation.isPending}
          className="neu-btn-coral w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 disabled:opacity-50">
          <Send className="w-5 h-5 text-white" />
        </button>
      </div>
    </div>
  );
}

// ─── Timeline Panel ───────────────────────────────────────────────────────────
function TimelinePanel() {
  const { data: events, refetch } = trpc.timeline.list.useQuery();
  const addMutation = trpc.timeline.add.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm(defaultForm); } });
  const updateMutation = trpc.timeline.update.useMutation({ onSuccess: () => refetch() });
  const deleteMutation = trpc.timeline.delete.useMutation({ onSuccess: () => refetch() });

  const defaultForm = { title: "", category: "other" as const, scheduledAt: "", durationMinutes: 60, status: "pending" as const, location: "", notes: "" };
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(defaultForm);

  const CATEGORIES = [
    { value: "ceremony", label: "Cérémonie", color: "#F07167" },
    { value: "reception", label: "Réception", color: "#60B4C8" },
    { value: "preparation", label: "Préparation", color: "#7BC47F" },
    { value: "photo", label: "Photo", color: "#C4A87B" },
    { value: "transport", label: "Transport", color: "#B47BC4" },
    { value: "dinner", label: "Dîner", color: "#F0A067" },
    { value: "entertainment", label: "Animation", color: "#7BC4B4" },
    { value: "administrative", label: "Administratif", color: "#8a9ab5" },
    { value: "other", label: "Autre", color: "#aab5c8" },
  ];

  const getCatColor = (cat: string) => CATEGORIES.find(c => c.value === cat)?.color || "#aab5c8";
  const getCatLabel = (cat: string) => CATEGORIES.find(c => c.value === cat)?.label || cat;

  const STATUS_COLORS: Record<string, string> = {
    pending: "#aab5c8", confirmed: "#60B4C8", done: "#7BC47F", cancelled: "#F07167"
  };

  return (
    <div>
      {/* Badge AURA suggère */}
      <div className="flex items-center gap-2 mb-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium" style={{ background: "rgba(240,113,103,0.1)", color: "var(--coral)" }}>
          <Sparkles className="w-3 h-3" />
          AURA suggère — Parlez à AURA pour générer votre timeline Jour J complète automatiquement
        </div>
      </div>
      <PanelHeader
        title="Timeline"
        subtitle="Planifiez toutes les étapes de votre mariage"
        action={
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (!events || events.length === 0) { return; }
                const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
                const coral = [240, 113, 103];
                const gray = [74, 85, 104];
                const lightGray = [170, 181, 200];
                // Header
                doc.setFillColor(240, 113, 103);
                doc.rect(0, 0, 210, 30, "F");
                doc.setTextColor(255, 255, 255);
                doc.setFontSize(22);
                doc.setFont("helvetica", "bold");
                doc.text("AURA Wedding OS", 15, 15);
                doc.setFontSize(12);
                doc.setFont("helvetica", "normal");
                doc.text("Timeline de votre mariage", 15, 23);
                // Date d'export
                doc.setFontSize(9);
                doc.text(`Exporté le ${new Date().toLocaleDateString("fr-FR")}`, 150, 23);
                // Contenu
                let y = 45;
                const sorted = [...events].sort((a, b) => {
                  if (!a.scheduledAt) return 1;
                  if (!b.scheduledAt) return -1;
                  return new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime();
                });
                sorted.forEach((event, i) => {
                  if (y > 270) { doc.addPage(); y = 20; }
                  // Ligne de séparation
                  doc.setDrawColor(232, 237, 242);
                  doc.line(15, y - 3, 195, y - 3);
                  // Heure
                  doc.setTextColor(...lightGray as [number,number,number]);
                  doc.setFontSize(9);
                  doc.setFont("helvetica", "normal");
                  const time = event.scheduledAt ? new Date(event.scheduledAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) : "--:--";
                  doc.text(time, 15, y + 4);
                  // Titre
                  doc.setTextColor(...gray as [number,number,number]);
                  doc.setFontSize(11);
                  doc.setFont("helvetica", "bold");
                  doc.text(event.title, 40, y + 4);
                  // Durée
                  doc.setFontSize(9);
                  doc.setFont("helvetica", "normal");
                  doc.setTextColor(...lightGray as [number,number,number]);
                  doc.text(`${event.durationMinutes || 60} min`, 165, y + 4);
                  // Lieu
                  if (event.location) {
                    doc.setFontSize(9);
                    doc.setTextColor(...lightGray as [number,number,number]);
                    doc.text(`📍 ${event.location}`, 40, y + 10);
                    y += 16;
                  } else {
                    y += 12;
                  }
                });
                // Footer
                doc.setFillColor(240, 113, 103);
                doc.rect(0, 285, 210, 12, "F");
                doc.setTextColor(255, 255, 255);
                doc.setFontSize(8);
                doc.text("Généré par AURA Wedding OS — aurawedding-5jwpbq82.manus.space", 15, 292);
                doc.save("timeline-mariage-aura.pdf");
              }}
              className="neu-btn px-4 py-2.5 text-sm font-medium rounded-xl flex items-center gap-2"
              style={{ color: "#F07167" }}
            >
              <Download className="w-4 h-4" /> Export PDF
            </button>
            <button onClick={() => setShowForm(true)} className="neu-btn-coral px-5 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2">
              <Plus className="w-4 h-4" /> Ajouter
            </button>
          </div>
        }
      />
      {/* Form */}
      {showForm && (
        <div className="neu-card p-6 mb-6">
          <h3 className="font-bold mb-4">Nouvelle étape</h3>
          <div className="grid grid-cols-2 gap-4">
            <input className="neu-input col-span-2" placeholder="Titre de l'étape" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            <select className="neu-input" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as any }))}>
              {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
            <select className="neu-input" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}>
              <option value="pending">En attente</option>
              <option value="confirmed">Confirmé</option>
              <option value="done">Fait</option>
              <option value="cancelled">Annulé</option>
            </select>
            <input type="datetime-local" className="neu-input" value={form.scheduledAt} onChange={e => setForm(f => ({ ...f, scheduledAt: e.target.value }))} />
            <input type="number" className="neu-input" placeholder="Durée (min)" value={form.durationMinutes} onChange={e => setForm(f => ({ ...f, durationMinutes: parseInt(e.target.value) || 60 }))} />
            <input className="neu-input" placeholder="Lieu" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} />
            <input className="neu-input" placeholder="Notes" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => addMutation.mutate(form as any)} disabled={!form.title || addMutation.isPending}
              className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
              {addMutation.isPending ? "Ajout..." : "Ajouter"}
            </button>
            <button onClick={() => { setShowForm(false); setForm(defaultForm); }} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {/* Events list */}
      {(!events || events.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucune étape planifiée. Commencez par ajouter les grandes étapes de votre mariage.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {events.map(event => (
            <div key={event.id} className="neu-card p-5 flex items-center gap-4">
              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: getCatColor(event.category) }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-semibold">{event.title}</h4>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: `${getCatColor(event.category)}20`, color: getCatColor(event.category) }}>
                    {getCatLabel(event.category)}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: `${STATUS_COLORS[event.status]}20`, color: STATUS_COLORS[event.status] }}>
                    {event.status === "pending" ? "En attente" : event.status === "confirmed" ? "Confirmé" : event.status === "done" ? "Fait" : "Annulé"}
                  </span>
                </div>
                <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                  {event.scheduledAt && <span>{new Date(event.scheduledAt).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>}
                  {event.durationMinutes && <span>{event.durationMinutes} min</span>}
                  {event.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{event.location}</span>}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button onClick={() => updateMutation.mutate({ id: event.id, status: event.status === "done" ? "pending" : "done" })}
                  className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                  <Check className="w-4 h-4" style={{ color: event.status === "done" ? "#7BC47F" : "#aab5c8" }} />
                </button>
                <button onClick={() => deleteMutation.mutate({ id: event.id })}
                  className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                  <Trash2 className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Budget Panel ─────────────────────────────────────────────────────────────
function BudgetPanel() {
  const { data: wedding } = trpc.wedding.get.useQuery();
  const { data: items, refetch } = trpc.budget.list.useQuery();
  const addMutation = trpc.budget.add.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm(defaultForm); } });
  const updateMutation = trpc.budget.update.useMutation({ onSuccess: () => refetch() });
  const deleteMutation = trpc.budget.delete.useMutation({ onSuccess: () => refetch() });
  const aiMutation = trpc.budget.aiEstimate.useMutation({ onSuccess: (data) => {
    data.items.forEach((item: any) => addMutation.mutate({ ...item, estimatedAmount: String(item.estimatedAmount) }));
  }});

  const defaultForm = { category: "other" as const, label: "", estimatedAmount: "", actualAmount: "", paid: false, notes: "" };
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(defaultForm);

  const totalEstimated = items?.reduce((s, i) => s + parseFloat(String(i.estimatedAmount || 0)), 0) || 0;
  const totalActual = items?.reduce((s, i) => s + parseFloat(String(i.actualAmount || 0)), 0) || 0;
  const totalBudget = parseFloat(String(wedding?.totalBudget || 0));
  const progress = totalBudget > 0 ? Math.min((totalEstimated / totalBudget) * 100, 100) : 0;

  const CATEGORIES = [
    { value: "venue", label: "Lieu" }, { value: "catering", label: "Traiteur" },
    { value: "photography", label: "Photographe" }, { value: "videography", label: "Vidéaste" },
    { value: "music", label: "Musique" }, { value: "flowers", label: "Fleurs" },
    { value: "dress", label: "Robe" }, { value: "suit", label: "Costume" },
    { value: "rings", label: "Alliances" }, { value: "transport", label: "Transport" },
    { value: "accommodation", label: "Hébergement" }, { value: "invitations", label: "Invitations" },
    { value: "decoration", label: "Décoration" }, { value: "beauty", label: "Beauté" },
    { value: "honeymoon", label: "Voyage de noces" }, { value: "other", label: "Autre" },
  ];

  // Group by category for chart
  const byCategory = items?.reduce((acc: Record<string, number>, item) => {
    const cat = item.category;
    acc[cat] = (acc[cat] || 0) + parseFloat(String(item.estimatedAmount || 0));
    return acc;
  }, {}) || {};

  return (
    <div>
      {/* Badge AURA suggère */}
      <div className="flex items-center gap-2 mb-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium" style={{ background: "rgba(240,113,103,0.1)", color: "var(--coral)" }}>
          <Sparkles className="w-3 h-3" />
          AURA suggère — Cliquez sur « Estimation IA » pour générer votre budget automatiquement
        </div>
      </div>
      <PanelHeader
        title="Budget"
        subtitle="Suivez vos dépenses en temps réel"
        action={
          <div className="flex gap-2">
            <button onClick={() => aiMutation.mutate({ guestCount: wedding?.guestCount || 80, city: wedding?.city || undefined })}
              disabled={aiMutation.isPending}
              className="neu-btn px-4 py-2.5 text-sm font-medium rounded-xl flex items-center gap-2">
              <Sparkles className="w-4 h-4" style={{ color: "var(--coral)" }} />
              {aiMutation.isPending ? "Génération..." : "Estimation IA"}
            </button>
            <button onClick={() => setShowForm(true)} className="neu-btn-coral px-5 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2">
              <Plus className="w-4 h-4" /> Ajouter
            </button>
          </div>
        }
      />
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: "Budget total", value: `${totalBudget.toLocaleString("fr-FR")}€`, color: "#8a9ab5" },
          { label: "Estimé", value: `${Math.round(totalEstimated).toLocaleString("fr-FR")}€`, color: "var(--coral)" },
          { label: "Dépensé", value: `${Math.round(totalActual).toLocaleString("fr-FR")}€`, color: "#7BC47F" },
        ].map(({ label, value, color }) => (
          <div key={label} className="neu-card p-5">
            <p className="text-xs text-muted-foreground mb-1">{label}</p>
            <p className="text-2xl font-black" style={{ color }}>{value}</p>
          </div>
        ))}
      </div>
      {/* Progress */}
      {totalBudget > 0 && (
        <div className="neu-card p-5 mb-6">
          <div className="flex justify-between text-sm mb-3">
            <span className="text-muted-foreground">Utilisation du budget</span>
            <span className="font-bold" style={{ color: progress > 90 ? "#F07167" : "var(--coral)" }}>{Math.round(progress)}%</span>
          </div>
          <div className="h-4 rounded-full neu-inset overflow-hidden">
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${progress}%`, background: progress > 90 ? "linear-gradient(90deg, #F07167, #e05a50)" : "linear-gradient(90deg, var(--coral-light), var(--coral))" }} />
          </div>
        </div>
      )}
      {/* Recharts — Graphiques */}
      {items && items.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
          <div className="neu-card p-5">
            <h3 className="font-semibold text-sm mb-4">Répartition par catégorie</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={Object.entries(byCategory).map(([cat, val]) => ({ name: CATEGORIES.find(c => c.value === cat)?.label || cat, value: Math.round(val as number) }))} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {Object.keys(byCategory).map((_, i) => <Cell key={i} fill={["#F07167","#60B4C8","#7BC47F","#C4A87B","#B47BC4","#F0A067","#7BC4B4","#8a9ab5"][i % 8]} />)}
                </Pie>
                <Tooltip formatter={(v: any) => `${Number(v).toLocaleString("fr-FR")}\u20ac`} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="neu-card p-5">
            <h3 className="font-semibold text-sm mb-4">Estimé vs Réel</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={Object.entries(byCategory).slice(0, 6).map(([cat, est]) => ({ name: CATEGORIES.find(c => c.value === cat)?.label?.slice(0,6) || cat, "Estimé": Math.round(est as number), "Réel": Math.round(items?.filter(i => i.category === cat).reduce((s, i) => s + parseFloat(String(i.actualAmount || 0)), 0) || 0) }))} barSize={14}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip formatter={(v: any) => `${Number(v).toLocaleString("fr-FR")}\u20ac`} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Estimé" fill="#F07167" radius={[4,4,0,0]} />
                <Bar dataKey="Réel" fill="#7BC47F" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
      {/* Form */}
      {showForm && (
        <div className="neu-card p-6 mb-6">
          <h3 className="font-bold mb-4">Nouvelle dépense</h3>
          <div className="grid grid-cols-2 gap-4">
            <select className="neu-input" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as any }))}>
              {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
            <input className="neu-input" placeholder="Libellé" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} />
            <input type="number" className="neu-input" placeholder="Montant estimé (€)" value={form.estimatedAmount} onChange={e => setForm(f => ({ ...f, estimatedAmount: e.target.value }))} />
            <input type="number" className="neu-input" placeholder="Montant réel (€)" value={form.actualAmount} onChange={e => setForm(f => ({ ...f, actualAmount: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => addMutation.mutate(form as any)} disabled={!form.label || addMutation.isPending}
              className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
              {addMutation.isPending ? "Ajout..." : "Ajouter"}
            </button>
            <button onClick={() => { setShowForm(false); setForm(defaultForm); }} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {/* Items list */}
      {(!items || items.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Wallet className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground mb-4">Aucune dépense enregistrée.</p>
          <button onClick={() => aiMutation.mutate({ guestCount: wedding?.guestCount || 80 })} className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl">
            Générer une estimation IA
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map(item => (
            <div key={item.id} className="neu-card p-4 flex items-center gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{item.label}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                    {CATEGORIES.find(c => c.value === item.category)?.label}
                  </span>
                  {item.paid && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(123,196,127,0.2)", color: "#7BC47F" }}>Payé</span>}
                </div>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="font-bold text-sm" style={{ color: "var(--coral)" }}>{parseFloat(String(item.estimatedAmount || 0)).toLocaleString("fr-FR")}€</p>
                {item.actualAmount && <p className="text-xs text-muted-foreground">{parseFloat(String(item.actualAmount)).toLocaleString("fr-FR")}€ réel</p>}
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => updateMutation.mutate({ id: item.id, paid: !item.paid })} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                  <Check className="w-4 h-4" style={{ color: item.paid ? "#7BC47F" : "#aab5c8" }} />
                </button>
                <button onClick={() => deleteMutation.mutate({ id: item.id })} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                  <Trash2 className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Providers Panel ──────────────────────────────────────────────────────────
function ProvidersPanel() {
  const { data: providers, refetch } = trpc.providers.list.useQuery();
  const addMutation = trpc.providers.add.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm(defaultForm); } });
  const updateMutation = trpc.providers.update.useMutation({ onSuccess: () => refetch() });
  const deleteMutation = trpc.providers.delete.useMutation({ onSuccess: () => refetch() });
  const inviteMutation = trpc.providers.generateInviteLink.useMutation();

  const defaultForm = { name: "", category: "other" as const, email: "", phone: "", website: "", city: "", priceRange: "", notes: "" };
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(defaultForm);
  const [filterCat, setFilterCat] = useState<string>("all");
  const [selectedProvider, setSelectedProvider] = useState<any>(null);
  const [inviteLink, setInviteLink] = useState<string | null>(null);

  const CATEGORIES = [
    { value: "photographer", label: "Photographe", icon: Camera },
    { value: "videographer", label: "Vidéaste", icon: Camera },
    { value: "caterer", label: "Traiteur", icon: Store },
    { value: "florist", label: "Fleuriste", icon: Flower2 },
    { value: "music", label: "Musique", icon: Music },
    { value: "venue", label: "Lieu", icon: MapPin },
    { value: "transport", label: "Transport", icon: ChevronRight },
    { value: "beauty", label: "Beauté", icon: Star },
    { value: "dress", label: "Robe", icon: Heart },
    { value: "suit", label: "Costume", icon: Heart },
    { value: "cake", label: "Gâteau", icon: Star },
    { value: "animation", label: "Animation", icon: Music },
    { value: "officiant", label: "Officiant", icon: Users },
    { value: "other", label: "Autre", icon: Store },
  ];

  const STATUS_COLORS: Record<string, string> = {
    shortlisted: "#aab5c8", contacted: "#60B4C8", quote_received: "#C4A87B", booked: "#7BC47F", cancelled: "#F07167"
  };
  const STATUS_LABELS: Record<string, string> = {
    shortlisted: "Présélectionné", contacted: "Contacté", quote_received: "Devis reçu", booked: "Réservé", cancelled: "Annulé"
  };

  const filtered = filterCat === "all" ? providers : providers?.filter(p => p.category === filterCat);

  const handleInvite = async (provider: any) => {
    const result = await inviteMutation.mutateAsync({ providerId: provider.id, email: provider.email || undefined, origin: window.location.origin });
    setInviteLink(result.url);
  };

  return (
    <div>
      {/* Badge AURA suggère */}
      <div className="flex items-center gap-2 mb-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium" style={{ background: "rgba(240,113,103,0.1)", color: "var(--coral)" }}>
          <Sparkles className="w-3 h-3" />
          AURA suggère — Utilisez l'onglet « Matching IA » pour trouver les meilleurs prestataires selon votre profil
        </div>
      </div>
      <PanelHeader
        title="Prestataires"
        subtitle="Gérez vos prestataires de mariage"
        action={
          <button onClick={() => setShowForm(true)} className="neu-btn-coral px-5 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2">
            <Plus className="w-4 h-4" /> Ajouter
          </button>
        }
      />
      {/* Category filters */}
      <div className="flex gap-2 flex-wrap mb-6">
        <button onClick={() => setFilterCat("all")} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${filterCat === "all" ? "neu-btn-coral text-white" : "neu-btn text-muted-foreground"}`}>
          Tous
        </button>
        {CATEGORIES.slice(0, 8).map(c => (
          <button key={c.value} onClick={() => setFilterCat(c.value)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${filterCat === c.value ? "neu-btn-coral text-white" : "neu-btn text-muted-foreground"}`}>
            {c.label}
          </button>
        ))}
      </div>
      {/* Form */}
      {showForm && (
        <div className="neu-card p-6 mb-6">
          <h3 className="font-bold mb-4">Nouveau prestataire</h3>
          <div className="grid grid-cols-2 gap-4">
            <input className="neu-input" placeholder="Nom" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            <select className="neu-input" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as any }))}>
              {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
            <input className="neu-input" placeholder="Email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            <input className="neu-input" placeholder="Téléphone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            <input className="neu-input" placeholder="Site web" value={form.website} onChange={e => setForm(f => ({ ...f, website: e.target.value }))} />
            <input className="neu-input" placeholder="Ville" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
            <input className="neu-input" placeholder="Fourchette de prix" value={form.priceRange} onChange={e => setForm(f => ({ ...f, priceRange: e.target.value }))} />
            <input className="neu-input" placeholder="Notes" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => addMutation.mutate(form as any)} disabled={!form.name || addMutation.isPending}
              className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
              {addMutation.isPending ? "Ajout..." : "Ajouter"}
            </button>
            <button onClick={() => { setShowForm(false); setForm(defaultForm); }} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {/* Invite link modal */}
      {inviteLink && (
        <div className="neu-card p-5 mb-6 border-2" style={{ borderColor: "var(--coral)" }}>
          <p className="font-semibold mb-2">Lien d'invitation prestataire</p>
          <div className="flex gap-2">
            <input readOnly className="neu-input flex-1 text-sm" value={inviteLink} />
            <button onClick={() => { navigator.clipboard.writeText(inviteLink); setInviteLink(null); }}
              className="neu-btn-coral px-4 py-2 text-sm font-semibold text-white rounded-xl">Copier</button>
          </div>
        </div>
      )}
      {/* Cards grid */}
      {(!filtered || filtered.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Store className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucun prestataire. Ajoutez vos prestataires pour les gérer depuis AURA.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered?.map(provider => (
            <div key={provider.id} className="neu-card p-5 cursor-pointer hover:scale-[1.02] transition-transform" onDoubleClick={() => setSelectedProvider(provider)}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-bold">{provider.name}</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">{CATEGORIES.find(c => c.value === provider.category)?.label}</p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full" style={{ background: `${STATUS_COLORS[provider.status || "shortlisted"]}20`, color: STATUS_COLORS[provider.status || "shortlisted"] }}>
                  {STATUS_LABELS[provider.status || "shortlisted"]}
                </span>
              </div>
              {provider.city && <p className="text-xs text-muted-foreground flex items-center gap-1 mb-2"><MapPin className="w-3 h-3" />{provider.city}</p>}
              {provider.priceRange && <p className="text-xs font-medium mb-3" style={{ color: "var(--coral)" }}>{provider.priceRange}</p>}
              <div className="flex gap-2">
                <select className="neu-input text-xs py-1.5 flex-1" value={provider.status || "shortlisted"}
                  onChange={e => updateMutation.mutate({ id: provider.id, status: e.target.value as any })}>
                  <option value="shortlisted">Présélectionné</option>
                  <option value="contacted">Contacté</option>
                  <option value="quote_received">Devis reçu</option>
                  <option value="booked">Réservé</option>
                  <option value="cancelled">Annulé</option>
                </select>
                <button onClick={() => handleInvite(provider)} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn flex-shrink-0" title="Inviter">
                  <Mail className="w-4 h-4" style={{ color: "var(--coral)" }} />
                </button>
                <button onClick={() => deleteMutation.mutate({ id: provider.id })} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn flex-shrink-0">
                  <Trash2 className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
// ─── Guests Panel ───────────────────────────────────────────────────────────────────────────────
function GuestsPanel() {
  const [, setLocation] = useLocation();
  const { data: guests, refetch } = trpc.guests.list.useQuery();
  const addMutation = trpc.guests.add.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm(defaultForm); } });
  const updateMutation = trpc.guests.update.useMutation({ onSuccess: () => refetch() });
  const deleteMutation = trpc.guests.delete.useMutation({ onSuccess: () => refetch() });

  const defaultForm = { firstName: "", lastName: "", email: "", phone: "", group: "", side: "both" as const, plusOne: false, dietaryRestrictions: "", tableNumber: undefined as number | undefined };
  const [showForm, setShowForm] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [form, setForm] = useState(defaultForm);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  const confirmed = guests?.filter(g => g.rsvpStatus === "confirmed").length || 0;
  const declined = guests?.filter(g => g.rsvpStatus === "declined").length || 0;
  const pending = guests?.filter(g => g.rsvpStatus === "pending").length || 0;

  const copyRsvpLink = (token: string) => {
    const url = `${window.location.origin}/rsvp/${token}`;
    navigator.clipboard.writeText(url);
    setCopiedToken(token);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  const STATUS_COLORS: Record<string, string> = { pending: "#aab5c8", confirmed: "#7BC47F", declined: "#F07167", maybe: "#C4A87B" };
  const STATUS_LABELS: Record<string, string> = { pending: "En attente", confirmed: "Confirmé", declined: "Décliné", maybe: "Peut-être" };

  return (
    <div>
      <PanelHeader
        title="Invités"
        subtitle={`${guests?.length || 0} invités · ${confirmed} confirmés · ${declined} déclinés · ${pending} en attente`}
        action={
          <div className="flex items-center gap-2">
            <button onClick={() => setLocation('/plan-de-table')} className="neu-btn px-4 py-2.5 text-sm font-medium rounded-xl flex items-center gap-2" style={{color:'#F07167'}}>
              <MapPin className="w-4 h-4" /> Plan de table
            </button>
            <button onClick={() => setShowCsvImport(true)} className="neu-btn px-4 py-2.5 text-sm font-medium rounded-xl flex items-center gap-2" style={{color:'#60B4C8'}}>
              <Upload className="w-4 h-4" /> Import CSV
            </button>
            <button onClick={() => setShowForm(true)} className="neu-btn-coral px-5 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2">
              <Plus className="w-4 h-4" /> Ajouter
            </button>
          </div>
        }
      />
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: "Confirmés", value: confirmed, color: "#7BC47F" },
          { label: "En attente", value: pending, color: "#aab5c8" },
          { label: "Déclinés", value: declined, color: "#F07167" },
        ].map(({ label, value, color }) => (
          <div key={label} className="neu-card p-4 text-center">
            <p className="text-2xl font-black" style={{ color }}>{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>
      {/* Form */}
      {showForm && (
        <div className="neu-card p-6 mb-6">
          <h3 className="font-bold mb-4">Nouvel invité</h3>
          <div className="grid grid-cols-2 gap-4">
            <input className="neu-input" placeholder="Prénom *" value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} />
            <input className="neu-input" placeholder="Nom" value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} />
            <input className="neu-input" placeholder="Email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            <input className="neu-input" placeholder="Téléphone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            <input className="neu-input" placeholder="Groupe (famille, amis...)" value={form.group} onChange={e => setForm(f => ({ ...f, group: e.target.value }))} />
            <select className="neu-input" value={form.side} onChange={e => setForm(f => ({ ...f, side: e.target.value as any }))}>
              <option value="both">Les deux</option>
              <option value="partner1">Côté Partenaire 1</option>
              <option value="partner2">Côté Partenaire 2</option>
            </select>
            <input type="number" className="neu-input" placeholder="Table n°" value={form.tableNumber || ""} onChange={e => setForm(f => ({ ...f, tableNumber: parseInt(e.target.value) || undefined }))} />
            <input className="neu-input" placeholder="Régime alimentaire" value={form.dietaryRestrictions} onChange={e => setForm(f => ({ ...f, dietaryRestrictions: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => addMutation.mutate(form as any)} disabled={!form.firstName || addMutation.isPending}
              className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
              {addMutation.isPending ? "Ajout..." : "Ajouter"}
            </button>
            <button onClick={() => { setShowForm(false); setForm(defaultForm); }} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {/* Guest list */}
      {(!guests || guests.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucun invité. Ajoutez vos invités pour générer leurs liens RSVP uniques.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {guests.map(guest => (
            <div key={guest.id} className="neu-card p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 neu-inset font-bold text-sm" style={{ color: "var(--coral)" }}>
                {guest.firstName[0]}{guest.lastName?.[0] || ""}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{guest.firstName} {guest.lastName}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  {guest.email && <span>{guest.email}</span>}
                  {guest.group && <span className="px-2 py-0.5 rounded-full bg-muted">{guest.group}</span>}
                  {guest.tableNumber && <span>Table {guest.tableNumber}</span>}
                </div>
              </div>
              <span className="text-xs px-2 py-1 rounded-full flex-shrink-0" style={{ background: `${STATUS_COLORS[guest.rsvpStatus || "pending"]}20`, color: STATUS_COLORS[guest.rsvpStatus || "pending"] }}>
                {STATUS_LABELS[guest.rsvpStatus || "pending"]}
              </span>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => copyRsvpLink(guest.rsvpToken ?? "")} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn" title="Copier lien RSVP">
                  {copiedToken === (guest.rsvpToken ?? "") ? <Check className="w-4 h-4" style={{ color: "#7BC47F" }} /> : <Mail className="w-4 h-4" style={{ color: "var(--coral)" }} />}
                </button>
                <button onClick={() => deleteMutation.mutate({ id: guest.id })} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                  <Trash2 className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      {showCsvImport && (
        <CsvImportModal
          onClose={() => setShowCsvImport(false)}
          onImported={() => { refetch(); setShowCsvImport(false); }}
        />
      )}
    </div>
  );
}

// ─── Documents Panel ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
function DocumentsPanel() {
  const { data: documents, refetch } = trpc.documents.list.useQuery();
  const uploadMutation = trpc.documents.upload.useMutation({ onSuccess: () => { refetch(); } });
  const deleteMutation = trpc.documents.delete.useMutation({ onSuccess: () => refetch() });
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = async (file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = (e.target?.result as string).split(",")[1];
      await uploadMutation.mutateAsync({ name: file.name, type: "other", fileData: base64, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const TYPE_ICONS: Record<string, React.ElementType> = { contract: FileText, quote: BarChart2, invoice: Wallet, photo: Camera, other: FileText };
  const TYPE_LABELS: Record<string, string> = { contract: "Contrat", quote: "Devis", invoice: "Facture", photo: "Photo", other: "Autre" };

  return (
    <div>
      <PanelHeader title="Documents" subtitle="Gérez vos contrats, devis et factures" />
      {/* Drop zone */}
      <div
        className={`border-2 border-dashed rounded-2xl p-10 text-center mb-6 transition-all cursor-pointer ${isDragging ? "border-coral bg-coral/5" : "border-border"}`}
        style={isDragging ? { borderColor: "var(--coral)" } : {}}
        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => document.getElementById("file-input")?.click()}
      >
        <Upload className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
        <p className="font-semibold mb-1">Glissez-déposez vos documents ici</p>
        <p className="text-sm text-muted-foreground">ou cliquez pour sélectionner</p>
        <input id="file-input" type="file" className="hidden" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
      </div>
      {uploadMutation.isPending && <div className="text-center py-4 text-muted-foreground text-sm">Upload en cours...</div>}
      {(!documents || documents.length === 0) ? (
        <div className="text-center py-12 neu-card">
          <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucun document. Glissez vos contrats et devis ici.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {documents.map(doc => {
            const Icon = TYPE_ICONS[doc.type] || FileText;
            return (
              <div key={doc.id} className="neu-card p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center neu-inset flex-shrink-0">
                  <Icon className="w-5 h-5" style={{ color: "var(--coral)" }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{doc.name}</p>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                    <span>{TYPE_LABELS[doc.type]}</span>
                    {doc.signed && <span className="text-green-500">Signé</span>}
                    <span>{new Date(doc.createdAt).toLocaleDateString("fr-FR")}</span>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <a href={doc.fileUrl ?? "#"} target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                    <Download className="w-4 h-4" style={{ color: "var(--coral)" }} />
                  </a>
                  <button onClick={() => deleteMutation.mutate({ id: doc.id })} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
                    <Trash2 className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Memory Panel ─────────────────────────────────────────────────────────────
function MemoryPanel() {
  const { data: memories, refetch } = trpc.memory.list.useQuery();
  const addMutation = trpc.memory.add.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm(defaultForm); } });
  const deleteMutation = trpc.memory.delete.useMutation({ onSuccess: () => refetch() });

  const defaultForm = { title: "", content: "", emotion: "joy" as const, mediaType: "note" as const, eventDate: "" };
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(defaultForm);

  const EMOTIONS = [
    { value: "joy", label: "Joie", emoji: "😊" },
    { value: "love", label: "Amour", emoji: "❤️" },
    { value: "excitement", label: "Excitation", emoji: "✨" },
    { value: "gratitude", label: "Gratitude", emoji: "🙏" },
    { value: "nostalgia", label: "Nostalgie", emoji: "🌸" },
    { value: "other", label: "Autre", emoji: "💭" },
  ];

  return (
    <div>
      <PanelHeader
        title="Mémoire"
        subtitle="Capturez les moments précieux de votre parcours"
        action={
          <button onClick={() => setShowForm(true)} className="neu-btn-coral px-5 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2">
            <Plus className="w-4 h-4" /> Ajouter
          </button>
        }
      />
      {showForm && (
        <div className="neu-card p-6 mb-6">
          <h3 className="font-bold mb-4">Nouveau souvenir</h3>
          <div className="grid grid-cols-2 gap-4">
            <input className="neu-input col-span-2" placeholder="Titre" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            <textarea className="neu-input col-span-2 resize-none" rows={3} placeholder="Décrivez ce moment..." value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} />
            <select className="neu-input" value={form.emotion} onChange={e => setForm(f => ({ ...f, emotion: e.target.value as any }))}>
              {EMOTIONS.map(e => <option key={e.value} value={e.value}>{e.emoji} {e.label}</option>)}
            </select>
            <input type="date" className="neu-input" value={form.eventDate} onChange={e => setForm(f => ({ ...f, eventDate: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => addMutation.mutate(form as any)} disabled={!form.title || addMutation.isPending}
              className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
              {addMutation.isPending ? "Ajout..." : "Ajouter"}
            </button>
            <button onClick={() => { setShowForm(false); setForm(defaultForm); }} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {(!memories || memories.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Brain className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucun souvenir. Capturez les moments forts de votre préparation.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {memories.map(memory => {
            const emotion = EMOTIONS.find(e => e.value === memory.emotion);
            return (
              <div key={memory.id} className="neu-card p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{emotion?.emoji}</span>
                    <div>
                      <h4 className="font-bold">{memory.title}</h4>
                      <p className="text-xs text-muted-foreground">{emotion?.label}</p>
                    </div>
                  </div>
                  <button onClick={() => deleteMutation.mutate({ id: memory.id })} className="w-7 h-7 rounded-lg flex items-center justify-center neu-btn">
                    <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
                {memory.content && <p className="text-sm text-muted-foreground leading-relaxed">{memory.content}</p>}
                {memory.eventDate && <p className="text-xs text-muted-foreground mt-3">{new Date(memory.eventDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Mini-site Panel ──────────────────────────────────────────────────────────
function MiniSitePanel() {
  const { data: wedding, refetch } = trpc.wedding.get.useQuery();
  const updateMutation = trpc.wedding.update.useMutation({ onSuccess: () => { refetch(); } });
  const [form, setForm] = useState({
    slug: "", enabled: false, welcomeMsg: "", themeColor: "#F07167",
    dressCode: "", transportInfo: "", accommodation: "",
    showTimeline: true, showPhotos: true, showRsvp: true, showMap: true, showPractical: true,
  });

  useEffect(() => {
    if (wedding) setForm({
      slug: wedding.miniSiteSlug || "",
      enabled: wedding.miniSiteEnabled || false,
      welcomeMsg: (wedding as any).miniSiteWelcomeMsg || "",
      themeColor: (wedding as any).miniSiteThemeColor || "#F07167",
      dressCode: (wedding as any).miniSiteDressCode || "",
      transportInfo: (wedding as any).miniSiteTransportInfo || "",
      accommodation: (wedding as any).miniSiteAccommodation || "",
      showTimeline: (wedding as any).miniSiteShowTimeline !== false,
      showPhotos: (wedding as any).miniSiteShowPhotos !== false,
      showRsvp: (wedding as any).miniSiteShowRsvp !== false,
      showMap: (wedding as any).miniSiteShowMap !== false,
      showPractical: (wedding as any).miniSiteShowPractical !== false,
    });
  }, [wedding]);

  const siteUrl = form.slug ? `${window.location.origin}/mariage/${form.slug}` : null;
  const f = (k: keyof typeof form, v: any) => setForm(p => ({ ...p, [k]: v }));
  const save = () => updateMutation.mutate({
    miniSiteSlug: form.slug, miniSiteEnabled: form.enabled,
    miniSiteWelcomeMsg: form.welcomeMsg, miniSiteThemeColor: form.themeColor,
    miniSiteDressCode: form.dressCode, miniSiteTransportInfo: form.transportInfo,
    miniSiteAccommodation: form.accommodation,
    miniSiteShowTimeline: form.showTimeline, miniSiteShowPhotos: form.showPhotos,
    miniSiteShowRsvp: form.showRsvp, miniSiteShowMap: form.showMap,
    miniSiteShowPractical: form.showPractical,
  } as any);

  const Toggle = ({ val, onToggle, label }: { val: boolean; onToggle: () => void; label: string }) => (
    <label className="flex items-center gap-3 cursor-pointer">
      <button type="button" onClick={onToggle}
        className="w-11 h-6 rounded-full transition-all flex-shrink-0 relative"
        style={{ background: val ? "var(--coral)" : "#c8d0dc" }}>
        <div className="w-4 h-4 rounded-full bg-white shadow absolute top-1 transition-all"
          style={{ left: val ? "calc(100% - 20px)" : "4px" }} />
      </button>
      <span className="text-sm">{label}</span>
    </label>
  );

  const PRESET_COLORS = ["#F07167", "#C4A87B", "#7BC47F", "#60B4C8", "#9B8EC4", "#E8A598"];

  return (
    <div className="space-y-6">
      <PanelHeader title="Mini-site" subtitle="Créez votre page web de mariage personnalisée pour vos invités" />

      {/* URL + activation */}
      <div className="neu-card p-6">
        <h3 className="font-bold mb-4">Adresse & activation</h3>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Adresse du mini-site</label>
            <div className="flex gap-2 items-center flex-wrap">
              <span className="text-xs text-muted-foreground flex-shrink-0">{window.location.origin}/mariage/</span>
              <input className="neu-input flex-1 min-w-[150px]" placeholder="prenom-prenom-2025" value={form.slug}
                onChange={e => f("slug", e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))} />
            </div>
          </div>
          <Toggle val={form.enabled} onToggle={() => f("enabled", !form.enabled)}
            label={form.enabled ? "Mini-site activé — visible par tous" : "Mini-site désactivé — brouillon"} />
        </div>
      </div>

      {/* Personnalisation */}
      <div className="neu-card p-6">
        <h3 className="font-bold mb-4">Personnalisation</h3>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Message d'accueil</label>
            <textarea className="neu-input w-full resize-none" rows={3}
              placeholder="Un mot pour vos invités..."
              value={form.welcomeMsg} onChange={e => f("welcomeMsg", e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-2">Couleur du thème</label>
            <div className="flex items-center gap-3 flex-wrap">
              <input type="color" value={form.themeColor} onChange={e => f("themeColor", e.target.value)}
                className="w-10 h-10 rounded-xl cursor-pointer" style={{ border: "none", padding: 0 }} />
              <span className="text-sm font-mono text-muted-foreground">{form.themeColor}</span>
              <div className="flex gap-2 flex-wrap">
                {PRESET_COLORS.map(c => (
                  <button key={c} onClick={() => f("themeColor", c)}
                    className="w-7 h-7 rounded-full transition-all"
                    style={{ background: c, outline: form.themeColor === c ? "3px solid #333" : "none", outlineOffset: "2px" }} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Infos pratiques */}
      <div className="neu-card p-6">
        <h3 className="font-bold mb-4">Informations pratiques</h3>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Dress code</label>
            <textarea className="neu-input w-full resize-none" rows={2}
              placeholder="Tenue de soirée, couleurs à éviter..."
              value={form.dressCode} onChange={e => f("dressCode", e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Transports & accès</label>
            <textarea className="neu-input w-full resize-none" rows={2}
              placeholder="Navette depuis la gare à 14h, parking gratuit..."
              value={form.transportInfo} onChange={e => f("transportInfo", e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Hébergements recommandés</label>
            <textarea className="neu-input w-full resize-none" rows={2}
              placeholder="Hôtel du Château à 500m, code promo MARIAGE2025..."
              value={form.accommodation} onChange={e => f("accommodation", e.target.value)} />
          </div>
        </div>
      </div>

      {/* Sections visibles */}
      <div className="neu-card p-6">
        <h3 className="font-bold mb-4">Sections visibles sur le mini-site</h3>
        <div className="space-y-3">
          <Toggle val={form.showRsvp} onToggle={() => f("showRsvp", !form.showRsvp)} label="Formulaire RSVP" />
          <Toggle val={form.showTimeline} onToggle={() => f("showTimeline", !form.showTimeline)} label="Programme de la journée" />
          <Toggle val={form.showPhotos} onToggle={() => f("showPhotos", !form.showPhotos)} label="Galerie photos" />
          <Toggle val={form.showMap} onToggle={() => f("showMap", !form.showMap)} label="Lien Google Maps" />
          <Toggle val={form.showPractical} onToggle={() => f("showPractical", !form.showPractical)} label="Infos pratiques (dress code, transports, hébergements)" />
        </div>
      </div>

      {/* Save + preview */}
      <div className="flex gap-3">
        <button onClick={save} disabled={!form.slug || updateMutation.isPending}
          className="flex-1 neu-btn-coral py-3 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
          {updateMutation.isPending ? "Sauvegarde..." : "Sauvegarder les modifications"}
        </button>
        {siteUrl && (
          <a href={siteUrl} target="_blank" rel="noopener noreferrer"
            className="neu-btn px-5 py-3 text-sm font-semibold rounded-xl">Prévisualiser</a>
        )}
      </div>

      {siteUrl && form.enabled && (
        <div className="neu-card p-5 flex items-center justify-between">
          <div>
            <p className="font-semibold mb-1">Mini-site en ligne ✓</p>
            <a href={siteUrl} target="_blank" rel="noopener noreferrer" className="text-sm hover:underline" style={{ color: "var(--coral)" }}>{siteUrl}</a>
          </div>
          <button onClick={() => navigator.clipboard.writeText(siteUrl)}
            className="neu-btn px-4 py-2 text-sm rounded-xl">Copier le lien</button>
        </div>
      )}
    </div>
  );
}

// ─── Day-Of Panel ─────────────────────────────────────────────────────────
function DayOfPanel() {
  const { data: wedding } = trpc.wedding.get.useQuery();
  const { data: events, refetch } = trpc.dayOf.list.useQuery();
  const addMutation = trpc.dayOf.add.useMutation({ onSuccess: () => { refetch(); setShowForm(false); setForm(defaultForm); } });
  const updateMutation = trpc.dayOf.updateStatus.useMutation({ onSuccess: () => refetch() });
  const aiAdjustMutation = trpc.dayOf.aiAdjust.useMutation({ onSuccess: () => refetch() });
  const crisisMutation = trpc.aiPlanner.crisis.handle.useMutation({
    onSuccess: () => {
      toast.success("Protocole de crise activ\u00e9 ! Plan g\u00e9n\u00e9r\u00e9 par AURA.");
      setCrisisMode(false);
      setCrisisPlan("");
      refetch();
    },
    onError: () => toast.error("Erreur lors de l'activation du mode crise"),
  });
  const defaultForm = { title: "", scheduledTime: "", notes: "" };
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(defaultForm);
  const [delayEvent, setDelayEvent] = useState<{ id: number; title: string } | null>(null);
  const [delayMinutes, setDelayMinutes] = useState(15);
  const [crisisMode, setCrisisMode] = useState(false);
  const [crisisDescription, setCrisisDescription] = useState("");
  const [crisisDelayMinutes, setCrisisDelayMinutes] = useState(30);
  const [crisisType, setCrisisType] = useState<"delay"|"cancellation"|"weather"|"other">("delay");
  const [crisisPlan, setCrisisPlan] = useState("");
  const STATUS_COLORS: Record<string, string> = { upcoming: "#aab5c8", in_progress: "#60B4C8", done: "#7BC47F", delayed: "#F07167" };
  const STATUS_LABELS: Record<string, string> = { upcoming: "\u00c0 venir", in_progress: "En cours", done: "Termin\u00e9", delayed: "Retard" };
  return (
    <div>
      <PanelHeader
        title="Coordination Jour J"
        subtitle="G\u00e9rez le planning en temps r\u00e9el le jour de votre mariage"
        action={
          <div className="flex gap-2">
            <button
              onClick={() => setShowForm(true)}
              className="neu-btn px-4 py-2.5 text-sm font-medium rounded-xl flex items-center gap-2">
              <Plus className="w-4 h-4" style={{ color: "var(--coral)" }} /> Ajouter
            </button>
            <button onClick={() => setCrisisMode(true)}
              className="neu-btn-coral px-4 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2">
              <Bell className="w-4 h-4" /> Mode Crise IA
            </button>
          </div>
        }
      />
      {/* Mode Crise IA */}
      {crisisMode && (
        <div className="neu-card p-5 mb-6 border-2 animate-pulse-once" style={{ borderColor: "#F07167" }}>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-5 h-5" style={{ color: "#F07167" }} />
            <h3 className="font-bold text-gray-800">Mode Crise IA — Gestion d'impr\u00e9vu</h3>
          </div>
          <p className="text-xs text-gray-500 mb-4">D\u00e9crivez l'impr\u00e9vu. AURA va automatiquement recalculer le planning, notifier les prestataires impact\u00e9s et informer votre wedding planner.</p>
          <div className="space-y-3">
            <textarea
              className="w-full neu-input text-sm resize-none"
              rows={3}
              placeholder="ex : Le traiteur a 45 min de retard. Le photographe est bloqu\u00e9 dans les embouteillages..."
              value={crisisDescription}
              onChange={e => setCrisisDescription(e.target.value)}
            />
            <div className="flex items-center gap-3">
              <label className="text-sm text-gray-600">Retard estim\u00e9 :</label>
              <input type="number" className="neu-input w-20 text-sm" value={crisisDelayMinutes}
                onChange={e => setCrisisDelayMinutes(parseInt(e.target.value) || 30)} />
              <span className="text-sm text-gray-500">minutes</span>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => crisisMutation.mutate({ weddingId: wedding?.id ?? 0, crisisType, providerName: crisisDescription.substring(0, 60), delayMinutes: crisisDelayMinutes })}
                disabled={!crisisDescription || crisisMutation.isPending}
                className="neu-btn-coral px-5 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50 flex items-center gap-2">
                {crisisMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                Activer le protocole de crise
              </button>
              <button onClick={() => { setCrisisMode(false); setCrisisDescription(""); }} className="neu-btn px-5 py-2.5 text-sm rounded-xl">Annuler</button>
            </div>
          </div>
        </div>
      )}
      {/* Delay modal */}
      {delayEvent && (
        <div className="neu-card p-5 mb-6 border-2" style={{ borderColor: "#F07167" }}>
          <p className="font-semibold mb-3">Signaler un retard : {delayEvent.title}</p>
          <div className="flex gap-3 items-center">
            <input type="number" className="neu-input w-24" value={delayMinutes} onChange={e => setDelayMinutes(parseInt(e.target.value) || 15)} />
            <span className="text-sm text-muted-foreground">minutes de retard</span>
            <button onClick={() => { aiAdjustMutation.mutate({ delayedEventId: delayEvent.id, delayMinutes }); setDelayEvent(null); }}
              className="neu-btn-coral px-4 py-2 text-sm font-semibold text-white rounded-xl">
              Ajuster avec l'IA
            </button>
            <button onClick={() => setDelayEvent(null)} className="neu-btn px-4 py-2 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {showForm && (
        <div className="neu-card p-6 mb-6">
          <h3 className="font-bold mb-4">Nouvel événement Jour J</h3>
          <div className="grid grid-cols-2 gap-4">
            <input className="neu-input col-span-2" placeholder="Titre" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            <input type="datetime-local" className="neu-input col-span-2" value={form.scheduledTime} onChange={e => setForm(f => ({ ...f, scheduledTime: e.target.value }))} />
            <input className="neu-input col-span-2" placeholder="Notes" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => addMutation.mutate(form as any)} disabled={!form.title || !form.scheduledTime || addMutation.isPending}
              className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl disabled:opacity-50">
              {addMutation.isPending ? "Ajout..." : "Ajouter"}
            </button>
            <button onClick={() => { setShowForm(false); setForm(defaultForm); }} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Annuler</button>
          </div>
        </div>
      )}
      {(!events || events.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucun événement Jour J. Planifiez le déroulé de votre journée.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {events.map(event => (
            <div key={event.id} className="neu-card p-5 flex items-center gap-4">
              <div className="text-center flex-shrink-0 w-16">
                <p className="text-lg font-black" style={{ color: STATUS_COLORS[event.status || "upcoming"] }}>
                  {new Date(event.scheduledTime).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                </p>
                {event.delayMinutes && event.delayMinutes > 0 && (
                  <p className="text-xs" style={{ color: "#F07167" }}>+{event.delayMinutes}min</p>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold">{event.title}</h4>
                <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: `${STATUS_COLORS[event.status || "upcoming"]}20`, color: STATUS_COLORS[event.status || "upcoming"] }}>
                  {STATUS_LABELS[event.status || "upcoming"]}
                </span>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <select className="neu-input text-xs py-1.5 w-28" value={event.status || "upcoming"}
                  onChange={e => updateMutation.mutate({ id: event.id, status: e.target.value as any })}>
                  <option value="upcoming">À venir</option>
                  <option value="in_progress">En cours</option>
                  <option value="done">Terminé</option>
                  <option value="delayed">Retard</option>
                </select>
                <button onClick={() => setDelayEvent({ id: event.id, title: event.title })} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn" title="Signaler retard">
                  <Clock className="w-4 h-4" style={{ color: "#F07167" }} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Photo Wall Panel ─────────────────────────────────────────────────────────
function PhotoWallPanel() {
  const { data: wedding } = trpc.wedding.get.useQuery();
  const { data: photos, refetch } = trpc.photoWall.list.useQuery(
    { weddingId: wedding?.id || 0, approvedOnly: false },
    { enabled: !!wedding?.id }
  );
  const uploadMutation = trpc.photoWall.upload.useMutation({ onSuccess: () => refetch() });

  const handleFile = async (file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = (e.target?.result as string).split(",")[1];
      await uploadMutation.mutateAsync({ weddingId: wedding!.id, fileData: base64, mimeType: file.type, uploaderName: "Mariés" });
    };
    reader.readAsDataURL(file);
  };

  const approved = photos?.filter(p => p.aiApproved).length || 0;
  const rejected = photos?.filter(p => !p.aiApproved).length || 0;

  return (
    <div>
      <PanelHeader title="Mur Photo Live" subtitle="Les invités uploadent, l'IA filtre, vous profitez" />
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: "Total", value: photos?.length || 0, color: "#aab5c8" },
          { label: "Approuvées", value: approved, color: "#7BC47F" },
          { label: "Filtrées", value: rejected, color: "#F07167" },
        ].map(({ label, value, color }) => (
          <div key={label} className="neu-card p-4 text-center">
            <p className="text-2xl font-black" style={{ color }}>{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>
      {/* Upload */}
      <div className="neu-card p-5 mb-6">
        <p className="font-semibold mb-3">Ajouter une photo</p>
        <input type="file" accept="image/*" className="hidden" id="photo-input" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
        <button onClick={() => document.getElementById("photo-input")?.click()} disabled={!wedding || uploadMutation.isPending}
          className="neu-btn-coral px-6 py-2.5 text-sm font-semibold text-white rounded-xl flex items-center gap-2 disabled:opacity-50">
          <Upload className="w-4 h-4" />
          {uploadMutation.isPending ? "Analyse IA en cours..." : "Uploader une photo"}
        </button>
      </div>
      {/* Photo grid */}
      {(!photos || photos.length === 0) ? (
        <div className="text-center py-16 neu-card">
          <Camera className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Aucune photo. Partagez le lien de votre mini-site avec vos invités pour qu'ils uploadent leurs photos.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {photos.map(photo => (
            <div key={photo.id} className={`relative rounded-2xl overflow-hidden aspect-square ${!photo.aiApproved ? "opacity-50" : ""}`}>
              <img src={photo.fileUrl} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                <span className="text-white text-xs font-medium">{photo.uploaderName || "Invité"}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${photo.aiApproved ? "bg-green-500/80 text-white" : "bg-red-500/80 text-white"}`}>
                  {photo.aiApproved ? "✓" : "✗"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Settings Panel ───────────────────────────────────────────────────────────
function SettingsPanel({ user }: { user: any }) {
  const { data: wedding, refetch } = trpc.wedding.get.useQuery();
  const updateMutation = trpc.wedding.update.useMutation({ onSuccess: () => refetch() });
  const [form, setForm] = useState({ partner1Name: "", partner2Name: "", weddingDate: "", venue: "", city: "", guestCount: 0, totalBudget: "", style: "" });

  useEffect(() => {
    if (wedding) setForm({
      partner1Name: wedding.partner1Name || "",
      partner2Name: wedding.partner2Name || "",
      weddingDate: wedding.weddingDate ? new Date(wedding.weddingDate).toISOString().split("T")[0] : "",
      venue: wedding.venue || "",
      city: wedding.city || "",
      guestCount: wedding.guestCount || 0,
      totalBudget: String(wedding.totalBudget || ""),
      style: wedding.style || "",
    });
  }, [wedding]);

  return (
    <div>
      <PanelHeader title="Réglages" subtitle="Configurez les informations de votre mariage" />
      <div className="neu-card p-6">
        <h3 className="font-bold mb-6">Informations du mariage</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Prénom Partenaire 1</label>
            <input className="neu-input" value={form.partner1Name} onChange={e => setForm(f => ({ ...f, partner1Name: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Prénom Partenaire 2</label>
            <input className="neu-input" value={form.partner2Name} onChange={e => setForm(f => ({ ...f, partner2Name: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Date du mariage</label>
            <input type="date" className="neu-input" value={form.weddingDate} onChange={e => setForm(f => ({ ...f, weddingDate: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Nombre d'invités</label>
            <input type="number" className="neu-input" value={form.guestCount} onChange={e => setForm(f => ({ ...f, guestCount: parseInt(e.target.value) || 0 }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Lieu de réception</label>
            <input className="neu-input" value={form.venue} onChange={e => setForm(f => ({ ...f, venue: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Ville</label>
            <input className="neu-input" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Budget total (€)</label>
            <input type="number" className="neu-input" value={form.totalBudget} onChange={e => setForm(f => ({ ...f, totalBudget: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Style du mariage</label>
            <input className="neu-input" placeholder="Champêtre, bohème, classique..." value={form.style} onChange={e => setForm(f => ({ ...f, style: e.target.value }))} />
          </div>
        </div>
        <button onClick={() => updateMutation.mutate(form as any)} disabled={updateMutation.isPending}
          className="neu-btn-coral px-8 py-3 text-sm font-semibold text-white rounded-xl mt-6 disabled:opacity-50">
          {updateMutation.isPending ? "Sauvegarde..." : "Sauvegarder les modifications"}
        </button>
      </div>
      {/* User info */}
      <div className="neu-card p-6 mt-4">
        <h3 className="font-bold mb-4">Mon compte</h3>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center neu-btn-coral text-white font-bold text-xl">
            {user?.name?.[0] || "?"}
          </div>
          <div>
            <p className="font-semibold">{user?.name}</p>
            <p className="text-sm text-muted-foreground">{user?.email}</p>
          </div>
        </div>
      </div>
      {/* Rappels programmés */}
      <RemindersCard />
    </div>
  );
}

// ─── Contracts Panel ──────────────────────────────────────────────────────────
function ContractsPanel() {
  const { data: providers } = trpc.providers.list.useQuery();
  const providerList = (providers || []).map(p => ({
    id: p.id,
    name: p.name,
    category: p.category,
  }));

  return (
    <div>
      <PanelHeader
        title="Contrats"
        subtitle="Créez, envoyez et signez électroniquement vos contrats prestataires"
      />
      <ContractManager providers={providerList} />
    </div>
  );
}
