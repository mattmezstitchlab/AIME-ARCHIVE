import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import SignaturePad from "@/components/SignaturePad";
import {
  Heart, Calendar, FileText, CreditCard, User,
  CheckCircle2, Clock, AlertCircle, XCircle,
  ChevronRight, MapPin, Euro, Banknote, PenLine,
  Building2, Phone, Mail, Globe, Instagram,
  Loader2, ShieldCheck, Star
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────
type TabId = "overview" | "missions" | "contracts" | "payments" | "profile";

const TABS: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: "overview",   label: "Vue d'ensemble", icon: <Heart size={16} /> },
  { id: "missions",   label: "Missions",        icon: <Calendar size={16} /> },
  { id: "contracts",  label: "Contrats",        icon: <FileText size={16} /> },
  { id: "payments",   label: "Paiements",       icon: <CreditCard size={16} /> },
  { id: "profile",    label: "Mon profil",      icon: <User size={16} /> },
];

const STATUS_COLORS: Record<string, string> = {
  pending:        "bg-yellow-100 text-yellow-700",
  confirmed:      "bg-blue-100 text-blue-700",
  in_progress:    "bg-purple-100 text-purple-700",
  done:           "bg-green-100 text-green-700",
  cancelled:      "bg-red-100 text-red-700",
  draft:          "bg-gray-100 text-gray-600",
  sent:           "bg-blue-100 text-blue-700",
  signed_provider:"bg-orange-100 text-orange-700",
  signed_couple:  "bg-indigo-100 text-indigo-700",
  fully_signed:   "bg-green-100 text-green-700",
};

const STATUS_LABELS: Record<string, string> = {
  pending:        "En attente",
  confirmed:      "Confirmée",
  in_progress:    "En cours",
  done:           "Terminée",
  cancelled:      "Annulée",
  draft:          "Brouillon",
  sent:           "Envoyé",
  signed_provider:"Signé par vous",
  signed_couple:  "Signé par les mariés",
  fully_signed:   "Entièrement signé",
};

function NeuCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-2xl p-5 ${className}`}
      style={{
        background: "#eef0f5",
        boxShadow: "6px 6px 12px #d1d4db, -6px -6px 12px #ffffff",
      }}
    >
      {children}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function ProviderDashboard() {
  const [, params] = useLocation();
  // Extract token from URL: /provider/dashboard?token=xxx
  const searchParams = new URLSearchParams(window.location.search);
  const sessionToken = searchParams.get("token") ?? "";

  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [signContractId, setSignContractId] = useState<number | null>(null);
  const [showSignDialog, setShowSignDialog] = useState(false);
  const [signerName, setSignerName] = useState("");

  const { data: dashboard, isLoading, refetch } = trpc.providerSpace.getDashboard.useQuery(
    { sessionToken },
    { enabled: !!sessionToken, refetchInterval: 30000 }
  );

  const updateMissionStatus = trpc.providerSpace.missions.updateStatus.useMutation({
    onSuccess: () => { toast.success("Statut mis à jour"); refetch(); },
    onError: () => toast.error("Erreur lors de la mise à jour"),
  });

  const signContract = trpc.providerSpace.contracts.signAsProvider.useMutation({
    onSuccess: (data) => {
      toast.success(
        data.status === "fully_signed"
          ? "Contrat entièrement signé !"
          : "Votre signature a été enregistrée. En attente de la signature des mariés."
      );
      setShowSignDialog(false);
      setSignContractId(null);
      refetch();
    },
    onError: () => toast.error("Erreur lors de la signature"),
  });

  const upsertProfile = trpc.providerSpace.profile.upsert.useMutation({
    onSuccess: () => { toast.success("Profil mis à jour"); refetch(); },
    onError: () => toast.error("Erreur lors de la mise à jour du profil"),
  });

  const [profileForm, setProfileForm] = useState({
    businessName: "", bio: "", city: "", phone: "", email: "",
    website: "", instagram: "", basePrice: "", ibanHolder: "",
    ibanFull: "", availabilityNotes: "", tags: "",
  });

  useEffect(() => {
    if (dashboard?.profile) {
      setProfileForm({
        businessName: dashboard.profile.businessName ?? "",
        bio: dashboard.profile.bio ?? "",
        city: dashboard.profile.city ?? "",
        phone: dashboard.profile.phone ?? "",
        email: dashboard.profile.email ?? "",
        website: dashboard.profile.website ?? "",
        instagram: dashboard.profile.instagram ?? "",
        basePrice: dashboard.profile.basePrice ?? "",
        ibanHolder: dashboard.profile.ibanHolder ?? "",
        ibanFull: dashboard.profile.ibanFull ?? "",
        availabilityNotes: dashboard.profile.availabilityNotes ?? "",
        tags: dashboard.profile.tags ?? "",
      });
    }
  }, [dashboard?.profile]);

  if (!sessionToken) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#E8EDF2" }}>
        <NeuCard className="max-w-md text-center">
          <AlertCircle className="mx-auto mb-3 text-red-400" size={40} />
          <h2 className="text-xl font-bold text-gray-800 mb-2">Accès invalide</h2>
          <p className="text-gray-500">Le lien d'accès est manquant ou invalide.</p>
        </NeuCard>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#E8EDF2" }}>
        <Loader2 className="animate-spin text-[#F07167]" size={40} />
      </div>
    );
  }

  if (!dashboard) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#E8EDF2" }}>
        <NeuCard className="max-w-md text-center">
          <XCircle className="mx-auto mb-3 text-red-400" size={40} />
          <h2 className="text-xl font-bold text-gray-800 mb-2">Session expirée</h2>
          <p className="text-gray-500">Votre session a expiré. Veuillez demander un nouveau lien aux mariés.</p>
        </NeuCard>
      </div>
    );
  }

  const { provider, wedding, missions, contracts } = dashboard;

  const pendingContracts = contracts.filter(c => c.status === "sent" || c.status === "signed_couple");
  const signedContracts = contracts.filter(c => c.status === "fully_signed");
  const pendingMissions = missions.filter(m => m.status === "pending" || m.status === "confirmed");
  const totalAmount = contracts.reduce((sum, c) => sum + parseFloat(c.amount ?? "0"), 0);
  const paidAmount = contracts.reduce((sum, c) => {
    let paid = 0;
    if (c.depositPaid) paid += parseFloat(c.depositAmount ?? "0");
    if (c.balancePaid) paid += (parseFloat(c.amount ?? "0") - parseFloat(c.depositAmount ?? "0"));
    return sum + paid;
  }, 0);

  return (
    <div className="min-h-screen" style={{ background: "#E8EDF2" }}>
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-white/60" style={{ background: "rgba(232,237,242,0.95)", backdropFilter: "blur(12px)" }}>
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "#F07167" }}>
              <Heart size={18} className="text-white" />
            </div>
            <div>
              <span className="font-bold text-gray-800 text-sm">AURA</span>
              <span className="text-gray-400 text-xs ml-1">Espace Prestataire</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold text-gray-800">{provider?.name}</p>
            <p className="text-xs text-gray-500">{wedding?.partner1Name} & {wedding?.partner2Name}</p>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
        {/* Navigation tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all"
              style={activeTab === tab.id ? {
                background: "#F07167", color: "white",
                boxShadow: "3px 3px 6px #d1d4db, -3px -3px 6px #ffffff",
              } : {
                background: "#eef0f5", color: "#6b7280",
                boxShadow: "3px 3px 6px #d1d4db, -3px -3px 6px #ffffff",
              }}
            >
              {tab.icon}
              {tab.label}
              {tab.id === "contracts" && pendingContracts.length > 0 && (
                <span className="ml-1 w-4 h-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                  {pendingContracts.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* ── Vue d'ensemble ── */}
        {activeTab === "overview" && (
          <div className="space-y-4">
            {/* KPIs */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "Missions", value: missions.length, sub: `${pendingMissions.length} en attente`, icon: <Calendar size={20} />, color: "#F07167" },
                { label: "Contrats", value: contracts.length, sub: `${signedContracts.length} signés`, icon: <FileText size={20} />, color: "#6366f1" },
                { label: "Total HT", value: `${totalAmount.toLocaleString("fr-FR")} €`, sub: "montant total", icon: <Euro size={20} />, color: "#10b981" },
                { label: "Encaissé", value: `${paidAmount.toLocaleString("fr-FR")} €`, sub: `${totalAmount > 0 ? Math.round(paidAmount / totalAmount * 100) : 0}% payé`, icon: <Banknote size={20} />, color: "#f59e0b" },
              ].map((kpi, i) => (
                <NeuCard key={i} className="text-center">
                  <div className="w-10 h-10 rounded-xl mx-auto mb-2 flex items-center justify-center" style={{ background: `${kpi.color}20`, color: kpi.color }}>
                    {kpi.icon}
                  </div>
                  <p className="text-xl font-bold text-gray-800">{kpi.value}</p>
                  <p className="text-xs text-gray-500">{kpi.label}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{kpi.sub}</p>
                </NeuCard>
              ))}
            </div>

            {/* Infos mariage */}
            <NeuCard>
              <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <Heart size={16} className="text-[#F07167]" />
                Le mariage
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                <div>
                  <p className="text-gray-400 text-xs">Couple</p>
                  <p className="font-medium text-gray-800">{wedding?.partner1Name} & {wedding?.partner2Name}</p>
                </div>
                {wedding?.weddingDate && (
                  <div>
                    <p className="text-gray-400 text-xs">Date</p>
                    <p className="font-medium text-gray-800">
                      {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                    </p>
                  </div>
                )}
                {wedding?.venue && (
                  <div>
                    <p className="text-gray-400 text-xs">Lieu</p>
                    <p className="font-medium text-gray-800">{wedding.venue}</p>
                  </div>
                )}
                {wedding?.city && (
                  <div>
                    <p className="text-gray-400 text-xs">Ville</p>
                    <p className="font-medium text-gray-800">{wedding.city}</p>
                  </div>
                )}
                {wedding?.guestCount && (
                  <div>
                    <p className="text-gray-400 text-xs">Invités</p>
                    <p className="font-medium text-gray-800">{wedding.guestCount} personnes</p>
                  </div>
                )}
              </div>
            </NeuCard>

            {/* Contrats à signer en urgence */}
            {pendingContracts.length > 0 && (
              <NeuCard>
                <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <AlertCircle size={16} className="text-orange-500" />
                  Action requise — Contrats à signer
                </h3>
                <div className="space-y-2">
                  {pendingContracts.map(contract => (
                    <div key={contract.id} className="flex items-center justify-between p-3 rounded-xl bg-orange-50 border border-orange-100">
                      <div>
                        <p className="font-medium text-gray-800 text-sm">{contract.title}</p>
                        <p className="text-xs text-gray-500">
                          {contract.amount ? `${parseFloat(contract.amount).toLocaleString("fr-FR")} €` : "Montant non défini"}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => { setSignContractId(contract.id); setShowSignDialog(true); }}
                        style={{ background: "#F07167", color: "white", border: "none" }}
                        className="gap-1"
                      >
                        <PenLine size={14} />
                        Signer
                      </Button>
                    </div>
                  ))}
                </div>
              </NeuCard>
            )}

            {/* Prochaines missions */}
            {pendingMissions.length > 0 && (
              <NeuCard>
                <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <Calendar size={16} className="text-[#F07167]" />
                  Prochaines missions
                </h3>
                <div className="space-y-2">
                  {pendingMissions.slice(0, 3).map(mission => (
                    <div key={mission.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/60">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-800 text-sm truncate">{mission.title}</p>
                        {mission.scheduledAt && (
                          <p className="text-xs text-gray-500">
                            {new Date(mission.scheduledAt).toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short" })}
                            {" · "}
                            {new Date(mission.scheduledAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                          </p>
                        )}
                        {mission.location && (
                          <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                            <MapPin size={10} /> {mission.location}
                          </p>
                        )}
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[mission.status]}`}>
                        {STATUS_LABELS[mission.status]}
                      </span>
                    </div>
                  ))}
                </div>
              </NeuCard>
            )}
          </div>
        )}

        {/* ── Missions ── */}
        {activeTab === "missions" && (
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-gray-800">Mes missions</h2>
            {missions.length === 0 ? (
              <NeuCard className="text-center py-10">
                <Calendar size={40} className="mx-auto text-gray-300 mb-3" />
                <p className="text-gray-500">Aucune mission assignée pour l'instant.</p>
              </NeuCard>
            ) : (
              missions.map(mission => (
                <NeuCard key={mission.id}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-800">{mission.title}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[mission.status]}`}>
                          {STATUS_LABELS[mission.status]}
                        </span>
                      </div>
                      {mission.description && (
                        <p className="text-sm text-gray-500 mb-2">{mission.description}</p>
                      )}
                      <div className="flex flex-wrap gap-3 text-xs text-gray-400">
                        {mission.scheduledAt && (
                          <span className="flex items-center gap-1">
                            <Clock size={12} />
                            {new Date(mission.scheduledAt).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                            {" à "}
                            {new Date(mission.scheduledAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                          </span>
                        )}
                        {mission.durationMinutes && (
                          <span className="flex items-center gap-1">
                            <Clock size={12} />
                            {mission.durationMinutes} min
                          </span>
                        )}
                        {mission.location && (
                          <span className="flex items-center gap-1">
                            <MapPin size={12} />
                            {mission.location}
                          </span>
                        )}
                      </div>
                      {mission.coupleNotes && (
                        <div className="mt-2 p-2 rounded-lg bg-blue-50 text-xs text-blue-700">
                          <strong>Note des mariés :</strong> {mission.coupleNotes}
                        </div>
                      )}
                    </div>
                    {/* Actions rapides */}
                    <div className="flex flex-col gap-1 shrink-0">
                      {mission.status === "pending" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs"
                          onClick={() => updateMissionStatus.mutate({ sessionToken, missionId: mission.id, status: "confirmed" })}
                        >
                          <CheckCircle2 size={12} className="mr-1" /> Confirmer
                        </Button>
                      )}
                      {mission.status === "confirmed" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs"
                          onClick={() => updateMissionStatus.mutate({ sessionToken, missionId: mission.id, status: "done" })}
                        >
                          <CheckCircle2 size={12} className="mr-1" /> Terminer
                        </Button>
                      )}
                    </div>
                  </div>
                </NeuCard>
              ))
            )}
          </div>
        )}

        {/* ── Contrats ── */}
        {activeTab === "contracts" && (
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-gray-800">Mes contrats</h2>
            {contracts.length === 0 ? (
              <NeuCard className="text-center py-10">
                <FileText size={40} className="mx-auto text-gray-300 mb-3" />
                <p className="text-gray-500">Aucun contrat pour l'instant.</p>
              </NeuCard>
            ) : (
              contracts.map(contract => (
                <NeuCard key={contract.id}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h3 className="font-semibold text-gray-800">{contract.title}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[contract.status]}`}>
                          {STATUS_LABELS[contract.status]}
                        </span>
                      </div>

                      {/* Montants */}
                      <div className="flex gap-4 text-sm mb-2">
                        {contract.amount && (
                          <div>
                            <p className="text-xs text-gray-400">Montant total</p>
                            <p className="font-semibold text-gray-800">{parseFloat(contract.amount).toLocaleString("fr-FR")} €</p>
                          </div>
                        )}
                        {contract.depositAmount && (
                          <div>
                            <p className="text-xs text-gray-400">Acompte</p>
                            <p className="font-semibold text-gray-800">{parseFloat(contract.depositAmount).toLocaleString("fr-FR")} €</p>
                          </div>
                        )}
                      </div>

                      {/* Paiements */}
                      <div className="flex gap-3 text-xs">
                        <span className={`flex items-center gap-1 ${contract.depositPaid ? "text-green-600" : "text-gray-400"}`}>
                          {contract.depositPaid ? <CheckCircle2 size={12} /> : <Clock size={12} />}
                          Acompte {contract.depositPaid ? "reçu" : "en attente"}
                        </span>
                        <span className={`flex items-center gap-1 ${contract.balancePaid ? "text-green-600" : "text-gray-400"}`}>
                          {contract.balancePaid ? <CheckCircle2 size={12} /> : <Clock size={12} />}
                          Solde {contract.balancePaid ? "reçu" : "en attente"}
                        </span>
                      </div>

                      {/* Signatures */}
                      <div className="mt-2 flex gap-3 text-xs">
                        <span className={`flex items-center gap-1 ${contract.providerSignatureData ? "text-green-600" : "text-orange-500"}`}>
                          {contract.providerSignatureData ? <ShieldCheck size={12} /> : <PenLine size={12} />}
                          Votre signature {contract.providerSignatureData ? `(${new Date(contract.providerSignedAt!).toLocaleDateString("fr-FR")})` : "manquante"}
                        </span>
                        <span className={`flex items-center gap-1 ${contract.coupleSignatureData ? "text-green-600" : "text-gray-400"}`}>
                          {contract.coupleSignatureData ? <ShieldCheck size={12} /> : <Clock size={12} />}
                          Signature mariés {contract.coupleSignatureData ? `(${new Date(contract.coupleSignedAt!).toLocaleDateString("fr-FR")})` : "en attente"}
                        </span>
                      </div>

                      {/* Contenu du contrat */}
                      {contract.content && (
                        <details className="mt-3">
                          <summary className="text-xs text-[#F07167] cursor-pointer hover:underline">Voir le contenu du contrat</summary>
                          <div className="mt-2 p-3 rounded-xl bg-white/70 text-xs text-gray-600 whitespace-pre-wrap max-h-48 overflow-y-auto">
                            {contract.content}
                          </div>
                        </details>
                      )}

                      {/* Signature prestataire affichée */}
                      {contract.providerSignatureData && (
                        <div className="mt-3">
                          <p className="text-xs text-gray-400 mb-1">Votre signature :</p>
                          <img
                            src={contract.providerSignatureData}
                            alt="Signature prestataire"
                            className="h-12 rounded border border-gray-200 bg-white"
                          />
                        </div>
                      )}
                    </div>

                    {/* Action signer */}
                    {!contract.providerSignatureData && (contract.status === "sent" || contract.status === "signed_couple") && (
                      <Button
                        size="sm"
                        onClick={() => { setSignContractId(contract.id); setShowSignDialog(true); }}
                        style={{ background: "#F07167", color: "white", border: "none" }}
                        className="gap-1 shrink-0"
                      >
                        <PenLine size={14} />
                        Signer
                      </Button>
                    )}
                    {contract.status === "fully_signed" && (
                      <div className="flex items-center gap-1 text-green-600 text-xs font-medium shrink-0">
                        <ShieldCheck size={16} />
                        Signé
                      </div>
                    )}
                  </div>
                </NeuCard>
              ))
            )}
          </div>
        )}

        {/* ── Paiements ── */}
        {activeTab === "payments" && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-gray-800">Suivi des paiements</h2>

            {/* Récapitulatif */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Total contractualisé", value: totalAmount, color: "#6366f1" },
                { label: "Encaissé", value: paidAmount, color: "#10b981" },
                { label: "Restant dû", value: totalAmount - paidAmount, color: "#f59e0b" },
              ].map((item, i) => (
                <NeuCard key={i} className="text-center">
                  <p className="text-lg font-bold" style={{ color: item.color }}>
                    {item.value.toLocaleString("fr-FR")} €
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{item.label}</p>
                </NeuCard>
              ))}
            </div>

            {/* Détail par contrat */}
            {contracts.map(contract => (
              <NeuCard key={contract.id}>
                <h3 className="font-semibold text-gray-800 mb-3">{contract.title}</h3>
                <div className="space-y-2">
                  {/* Acompte */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/60">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Acompte</p>
                      <p className="text-xs text-gray-400">
                        {contract.depositAmount ? `${parseFloat(contract.depositAmount).toLocaleString("fr-FR")} €` : "Non défini"}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {contract.depositPaid ? (
                        <span className="flex items-center gap-1 text-green-600 text-xs font-medium">
                          <CheckCircle2 size={14} /> Reçu le {new Date(contract.depositPaidAt!).toLocaleDateString("fr-FR")}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-orange-500 text-xs">
                          <Clock size={14} /> En attente
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Solde */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/60">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Solde</p>
                      <p className="text-xs text-gray-400">
                        {contract.amount && contract.depositAmount
                          ? `${(parseFloat(contract.amount) - parseFloat(contract.depositAmount)).toLocaleString("fr-FR")} €`
                          : "Non défini"}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {contract.balancePaid ? (
                        <span className="flex items-center gap-1 text-green-600 text-xs font-medium">
                          <CheckCircle2 size={14} /> Reçu le {new Date(contract.balancePaidAt!).toLocaleDateString("fr-FR")}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-orange-500 text-xs">
                          <Clock size={14} /> En attente
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </NeuCard>
            ))}

            {/* Coordonnées bancaires */}
            {dashboard.profile?.ibanLast4 && (
              <NeuCard>
                <h3 className="font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <Banknote size={16} className="text-[#F07167]" />
                  Vos coordonnées bancaires
                </h3>
                <p className="text-sm text-gray-600">
                  Titulaire : <strong>{dashboard.profile.ibanHolder}</strong>
                </p>
                <p className="text-sm text-gray-600">
                  IBAN se terminant par : <strong>****{dashboard.profile.ibanLast4}</strong>
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  Pour modifier vos coordonnées bancaires, rendez-vous dans l'onglet "Mon profil".
                </p>
              </NeuCard>
            )}
          </div>
        )}

        {/* ── Profil ── */}
        {activeTab === "profile" && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-gray-800">Mon profil prestataire</h2>
            <NeuCard>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { key: "businessName", label: "Nom commercial", icon: <Building2 size={14} />, placeholder: "Studio Lumière" },
                  { key: "city", label: "Ville", icon: <MapPin size={14} />, placeholder: "Paris" },
                  { key: "phone", label: "Téléphone", icon: <Phone size={14} />, placeholder: "+33 6 00 00 00 00" },
                  { key: "email", label: "Email professionnel", icon: <Mail size={14} />, placeholder: "contact@studio.fr" },
                  { key: "website", label: "Site web", icon: <Globe size={14} />, placeholder: "https://studio.fr" },
                  { key: "instagram", label: "Instagram", icon: <Instagram size={14} />, placeholder: "@studio_lumiere" },
                  { key: "basePrice", label: "Tarif de base (€)", icon: <Euro size={14} />, placeholder: "2500" },
                  { key: "ibanHolder", label: "Titulaire du compte", icon: <Banknote size={14} />, placeholder: "Jean Dupont" },
                  { key: "ibanFull", label: "IBAN complet", icon: <Banknote size={14} />, placeholder: "FR76 3000 6000 0112 3456 7890 189" },
                ].map(field => (
                  <div key={field.key}>
                    <label className="text-xs text-gray-500 flex items-center gap-1 mb-1">
                      {field.icon} {field.label}
                    </label>
                    <Input
                      value={(profileForm as any)[field.key]}
                      onChange={e => setProfileForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                      placeholder={field.placeholder}
                      className="rounded-xl border-0"
                      style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
                    />
                  </div>
                ))}
                <div className="md:col-span-2">
                  <label className="text-xs text-gray-500 flex items-center gap-1 mb-1">
                    <Star size={14} /> Bio / Présentation
                  </label>
                  <Textarea
                    value={profileForm.bio}
                    onChange={e => setProfileForm(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Décrivez votre activité, votre style, votre expérience..."
                    rows={3}
                    className="rounded-xl border-0"
                    style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="text-xs text-gray-500 flex items-center gap-1 mb-1">
                    <Calendar size={14} /> Notes de disponibilité
                  </label>
                  <Textarea
                    value={profileForm.availabilityNotes}
                    onChange={e => setProfileForm(prev => ({ ...prev, availabilityNotes: e.target.value }))}
                    placeholder="Ex: disponible tous les week-ends de mai à octobre..."
                    rows={2}
                    className="rounded-xl border-0"
                    style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
                  />
                </div>
              </div>
              <div className="mt-4 flex justify-end">
                <Button
                  onClick={() => upsertProfile.mutate({ sessionToken, ...profileForm })}
                  disabled={upsertProfile.isPending}
                  style={{ background: "#F07167", color: "white", border: "none" }}
                  className="gap-2"
                >
                  {upsertProfile.isPending ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                  Enregistrer le profil
                </Button>
              </div>
            </NeuCard>
          </div>
        )}
      </div>

      {/* ── Dialog Signature Électronique ── */}
      <Dialog open={showSignDialog} onOpenChange={setShowSignDialog}>
        <DialogContent className="max-w-lg" style={{ background: "#E8EDF2", border: "none", borderRadius: "1.5rem" }}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-gray-800">
              <PenLine size={18} className="text-[#F07167]" />
              Signature électronique du contrat
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Contrat sélectionné */}
            {signContractId && (() => {
              const contract = contracts.find(c => c.id === signContractId);
              return contract ? (
                <div className="p-3 rounded-xl bg-white/60 text-sm">
                  <p className="font-semibold text-gray-800">{contract.title}</p>
                  {contract.amount && (
                    <p className="text-gray-500 text-xs mt-0.5">Montant : {parseFloat(contract.amount).toLocaleString("fr-FR")} €</p>
                  )}
                  {contract.content && (
                    <div className="mt-2 max-h-24 overflow-y-auto text-xs text-gray-600 whitespace-pre-wrap border-t border-gray-100 pt-2">
                      {contract.content}
                    </div>
                  )}
                </div>
              ) : null;
            })()}

            {/* Nom du signataire */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Votre nom complet (tel qu'il apparaîtra sur le contrat)</label>
              <Input
                value={signerName}
                onChange={e => setSignerName(e.target.value)}
                placeholder="Jean Dupont"
                className="rounded-xl border-0"
                style={{ background: "#f0f2f7", boxShadow: "inset 2px 2px 5px #d1d4db, inset -2px -2px 5px #ffffff" }}
              />
            </div>

            {/* Pad de signature */}
            <SignaturePad
              label="Dessinez votre signature"
              signerName={signerName || undefined}
              width={460}
              height={160}
              onCancel={() => { setShowSignDialog(false); setSignContractId(null); }}
              onSave={(dataUrl) => {
                if (!signerName.trim()) {
                  toast.error("Veuillez saisir votre nom complet avant de signer.");
                  return;
                }
                if (!signContractId) return;
                signContract.mutate({
                  sessionToken,
                  contractId: signContractId,
                  signatureData: dataUrl,
                  signerName: signerName.trim(),
                });
              }}
            />

            {/* Mention légale */}
            <p className="text-xs text-gray-400 text-center">
              En validant votre signature, vous acceptez que cette signature électronique ait valeur légale conformément au règlement eIDAS (UE n°910/2014).
              Date et heure d'horodatage : {new Date().toLocaleString("fr-FR")}.
            </p>

            {signContract.isPending && (
              <div className="flex items-center justify-center gap-2 text-[#F07167]">
                <Loader2 size={16} className="animate-spin" />
                <span className="text-sm">Enregistrement de la signature...</span>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
