import { useState, useRef } from "react";
import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Camera, Upload, Loader2, Heart, X } from "lucide-react";

export default function PhotoWallPublic() {
  const params = useParams<{ slug: string }>();
  const { data: wedding } = trpc.wedding.getBySlug.useQuery(
    { slug: params.slug || "" },
    { enabled: !!params.slug }
  );
  const { data: photos, refetch } = trpc.photoWall.list.useQuery(
    { weddingId: wedding?.id || 0, approvedOnly: true },
    { enabled: !!wedding?.id, refetchInterval: 10000 }
  );
  const uploadMutation = trpc.photoWall.upload.useMutation({ onSuccess: () => { refetch(); setUploaderName(""); setUploaded(true); } });
  const [uploaderName, setUploaderName] = useState("");
  const [uploaded, setUploaded] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    if (!wedding) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = (e.target?.result as string).split(",")[1];
      await uploadMutation.mutateAsync({
        weddingId: wedding.id,
        fileData: base64,
        mimeType: file.type,
        uploaderName: uploaderName || "Invité"
      });
    };
    reader.readAsDataURL(file);
  };

  if (!wedding) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--coral)" }} />
    </div>
  );

  return (
    <div className="min-h-screen" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div className="text-center py-12 px-4" style={{ background: "linear-gradient(135deg, rgba(240,113,103,0.1), rgba(240,113,103,0.03))" }}>
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4 neu-btn-coral">
          <Camera className="w-7 h-7 text-white" />
        </div>
        <h1 className="text-3xl font-black mb-2" style={{ fontFamily: "Playfair Display, serif" }}>
          {wedding.partner1Name} & {wedding.partner2Name}
        </h1>
        <p className="text-muted-foreground">Mur de photos en direct — partagez vos moments !</p>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Upload section */}
        {!uploaded ? (
          <div className="neu-card p-6 mb-8">
            <h2 className="font-bold mb-4">Partager une photo</h2>
            <div className="space-y-4">
              <input
                className="neu-input"
                placeholder="Votre prénom (optionnel)"
                value={uploaderName}
                onChange={e => setUploaderName(e.target.value)}
              />
              <div
                className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${isDragging ? "" : "border-border"}`}
                style={isDragging ? { borderColor: "var(--coral)", background: "rgba(240,113,103,0.05)" } : {}}
                onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={e => { e.preventDefault(); setIsDragging(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
                <p className="font-medium mb-1">Glissez votre photo ici</p>
                <p className="text-sm text-muted-foreground">ou cliquez pour sélectionner</p>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              </div>
              {uploadMutation.isPending && (
                <div className="text-center py-3 text-sm text-muted-foreground flex items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" style={{ color: "var(--coral)" }} />
                  L'IA analyse votre photo...
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="neu-card p-6 mb-8 text-center">
            <Heart className="w-10 h-10 mx-auto mb-3" style={{ color: "var(--coral)" }} />
            <p className="font-bold mb-2">Photo partagée !</p>
            <p className="text-sm text-muted-foreground mb-4">L'IA a analysé votre photo. Si elle est approuvée, elle apparaîtra dans le mur.</p>
            <button onClick={() => setUploaded(false)} className="neu-btn px-6 py-2.5 text-sm rounded-xl">Partager une autre photo</button>
          </div>
        )}

        {/* Photo grid */}
        {(!photos || photos.length === 0) ? (
          <div className="text-center py-16 neu-card">
            <Camera className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">Soyez le premier à partager une photo !</p>
          </div>
        ) : (
          <div className="columns-2 sm:columns-3 lg:columns-4 gap-3 space-y-3">
            {photos.map(photo => (
              <div key={photo.id} className="break-inside-avoid rounded-2xl overflow-hidden relative group">
                <img src={photo.fileUrl ?? ""} alt="" className="w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute bottom-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-white text-xs font-medium">{photo.uploaderName || "Invité"}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
