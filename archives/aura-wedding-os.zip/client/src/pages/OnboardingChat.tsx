import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Sparkles, CheckCircle, ArrowRight, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

type Message = {
  id: string;
  role: "aura" | "user";
  content: string;
  timestamp: Date;
};

type Question = {
  step: number;
  key: string;
  question: string;
  type: string;
  placeholder?: string;
  icon: string;
  choices?: string[];
};

export default function OnboardingChat() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [selectedChoices, setSelectedChoices] = useState<string[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [weddingId, setWeddingId] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const weddingQuery = trpc.wedding.get.useQuery(undefined, { enabled: !!user });
  const allQuestionsQuery = trpc.aiPlanner.onboarding.getAllQuestions.useQuery(undefined, { enabled: !!user });
  const startMutation = trpc.aiPlanner.onboarding.startOrResume.useMutation();
  const submitAnswerMutation = trpc.aiPlanner.onboarding.submitAnswer.useMutation();
  const generateTimelineMutation = trpc.aiPlanner.generateDayOfTimeline.useMutation();
  const generateGuideMutation = trpc.aiPlanner.guide.generate.useMutation();
  const generateMatchingMutation = trpc.aiPlanner.matching.generate.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => { scrollToBottom(); }, [messages, isTyping]);

  useEffect(() => {
    if (!user || !weddingQuery.data || !allQuestionsQuery.data) return;
    const wedding = weddingQuery.data;
    setWeddingId(wedding.id);

    // Démarrer ou reprendre la session
    startMutation.mutateAsync({ weddingId: wedding.id }).then((session) => {
      if (session.completed) {
        setIsCompleted(true);
        return;
      }
      const currentStep = session.currentStep ?? 0;
      const question = allQuestionsQuery.data[currentStep];
      if (!question) return;

      // Message de bienvenue
      const welcomeMsg: Message = {
        id: "welcome",
        role: "aura",
        content: currentStep === 0
          ? "Bonjour ! Je suis **AURA**, votre wedding planner IA personnel. Je suis tellement heureuse de vous accompagner dans cette aventure magique ! 💕\n\nJe vais vous poser quelques questions pour créer votre planning personnalisé, générer votre timeline du Jour J et vous guider dans l'organisation. Cela ne prend que 5 minutes !"
          : `Bienvenue à nouveau ! Vous en étiez à l'étape ${currentStep + 1}/${allQuestionsQuery.data.length}. Continuons !`,
        timestamp: new Date(),
      };

      setMessages([welcomeMsg]);

      setTimeout(() => {
        addAuraMessage(question.question, question);
      }, 1200);
    });
  }, [user, weddingQuery.data, allQuestionsQuery.data]);

  const addAuraMessage = (content: string, question?: Question) => {
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, {
        id: `aura-${Date.now()}`,
        role: "aura",
        content,
        timestamp: new Date(),
      }]);
      if (question) setCurrentQuestion(question);
    }, 800 + Math.random() * 400);
  };

  const handleSendAnswer = async (value?: string | string[]) => {
    if (!weddingId || !currentQuestion) return;
    const answer = value ?? (currentQuestion.type === "multiChoice" ? selectedChoices : inputValue);
    if (!answer || (Array.isArray(answer) && answer.length === 0)) return;

    // Validation date de mariage : refuser les dates passées
    if (currentQuestion.key === "weddingDate" && typeof answer === "string") {
      const chosenDate = new Date(answer);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (!isNaN(chosenDate.getTime()) && chosenDate < today) {
        addAuraMessage("⚠️ Cette date est déjà passée ! Veuillez choisir une date future pour votre mariage.", currentQuestion);
        setInputValue("");
        return;
      }
    }

    const displayValue = Array.isArray(answer) ? answer.join(", ") : String(answer);

    // Ajouter le message utilisateur
    setMessages(prev => [...prev, {
      id: `user-${Date.now()}`,
      role: "user",
      content: displayValue,
      timestamp: new Date(),
    }]);
    setInputValue("");
    setSelectedChoices([]);
    setCurrentQuestion(null);

    try {
      const result = await submitAnswerMutation.mutateAsync({
        weddingId,
        step: currentQuestion.step,
        key: currentQuestion.key,
        value: Array.isArray(answer) ? answer : String(answer),
      });

      if (result.completed) {
        // Génération automatique de tout
        setIsTyping(true);
        setTimeout(async () => {
          setIsTyping(false);
          setMessages(prev => [...prev, {
            id: `aura-complete`,
            role: "aura",
            content: "🎉 **Parfait !** J'ai toutes les informations dont j'ai besoin.\n\nJe génère maintenant :\n- ✅ Votre **timeline complète du Jour J**\n- ✅ Votre **guide d'organisation** priorisé\n- ✅ Des **suggestions de prestataires** compatibles\n\nCela prend quelques secondes...",
            timestamp: new Date(),
          }]);

          // Générer en parallèle
          await Promise.allSettled([
            generateTimelineMutation.mutateAsync({ weddingId }),
            generateGuideMutation.mutateAsync({ weddingId }),
            generateMatchingMutation.mutateAsync({ weddingId }),
          ]);

          setIsTyping(true);
          setTimeout(() => {
            setIsTyping(false);
            setIsCompleted(true);
            setMessages(prev => [...prev, {
              id: `aura-done`,
              role: "aura",
              content: "✨ **Tout est prêt !** Votre espace AURA est maintenant configuré avec :\n\n💍 Votre **profil de mariage** complet\n📅 Votre **timeline Jour J** générée minute par minute\n📋 Votre **guide d'organisation** avec les priorités\n🤝 Des **prestataires suggérés** selon votre style et budget\n💰 Votre **budget** réparti par catégorie\n\nBienvenue dans votre cockpit AURA !",
              timestamp: new Date(),
            }]);
          }, 2000);
        }, 1500);
      } else {
        // Prochaine question
        const allQuestions = allQuestionsQuery.data ?? [];
        const nextQuestion = allQuestions[result.nextStep];
        if (nextQuestion) {
          // Réponse contextuelle de l'IA
          const contextualResponses: Record<string, string> = {
            names: `Enchanté${displayValue.includes("&") ? "s" : ""} ! 💕`,
            weddingDate: `Quelle belle date en perspective ! `,
            venue: displayValue.toLowerCase().includes("pas encore") ? "Pas de panique, on va vous aider à trouver ! " : "Excellent choix ! ",
            city: `${displayValue}, magnifique région pour un mariage ! `,
            guestCount: `${displayValue} invités, c'est parfait pour une belle célébration ! `,
            budget: "Très bien, je vais adapter mes suggestions à votre budget. ",
            style: `Le style "${displayValue}" est absolument magnifique ! `,
            ceremony: "Excellent choix de cérémonie ! ",
            moments: "Ces moments vont créer des souvenirs inoubliables ! ",
            bookedProviders: displayValue.includes("Aucun") ? "Pas de problème, je vais vous suggérer les meilleurs ! " : "Super, je vais compléter votre équipe ! ",
            constraints: "Noté, j'en tiendrai compte dans toutes mes suggestions. ",
          };
          const contextual = contextualResponses[currentQuestion.key] ?? "";
          addAuraMessage(`${contextual}${nextQuestion.question}`, nextQuestion);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const toggleChoice = (choice: string) => {
    setSelectedChoices(prev =>
      prev.includes(choice) ? prev.filter(c => c !== choice) : [...prev, choice]
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#E8EDF2" }}>
        <div className="neu-card p-8 text-center">
          <Sparkles className="w-8 h-8 text-coral mx-auto mb-3 animate-pulse" />
          <p className="text-gray-500">Chargement d'AURA...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#E8EDF2" }}>
        <div className="neu-card p-10 text-center max-w-md">
          <Heart className="w-12 h-12 text-coral mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Bienvenue sur AURA</h2>
          <p className="text-gray-500 mb-6">Connectez-vous pour commencer votre aventure avec votre wedding planner IA</p>
          <a href={getLoginUrl()} className="neu-btn inline-flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-2xl" style={{ background: "#F07167" }}>
            <Sparkles className="w-4 h-4" />
            Se connecter
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "#E8EDF2" }}>
      {/* Header */}
      <div className="neu-card mx-4 mt-4 p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #F07167, #e85d52)" }}>
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="font-bold text-gray-800">AURA — Wedding Planner IA</h1>
          <p className="text-xs text-gray-500">Votre assistante personnelle pour le plus beau jour de votre vie</p>
        </div>
        {allQuestionsQuery.data && (
          <div className="ml-auto text-sm text-gray-500">
            {Math.min((weddingQuery.data ? 0 : 0), allQuestionsQuery.data.length)}/{allQuestionsQuery.data.length} étapes
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.role === "aura" && (
                <div className="w-8 h-8 rounded-full flex items-center justify-center mr-2 flex-shrink-0 mt-1" style={{ background: "linear-gradient(135deg, #F07167, #e85d52)" }}>
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
              )}
              <div
                className={`max-w-xs sm:max-w-md lg:max-w-lg rounded-2xl px-4 py-3 ${
                  msg.role === "aura"
                    ? "neu-card text-gray-700"
                    : "text-white"
                }`}
                style={msg.role === "user" ? { background: "#F07167" } : {}}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap" dangerouslySetInnerHTML={{
                  __html: msg.content
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/\n/g, '<br/>')
                }} />
              </div>
            </motion.div>
          ))}

          {/* Indicateur de frappe */}
          {isTyping && (
            <motion.div
              key="typing"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #F07167, #e85d52)" }}>
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="neu-card px-4 py-3 flex gap-1">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-2 h-2 rounded-full bg-coral animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Zone de saisie */}
      {!isCompleted && currentQuestion && !isTyping && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="px-4 pb-4 space-y-3"
        >
          {/* Choix multiples */}
          {(currentQuestion.type === "choice" || currentQuestion.type === "multiChoice") && currentQuestion.choices && (
            <div className="flex flex-wrap gap-2">
              {currentQuestion.choices.map(choice => (
                <button
                  key={choice}
                  onClick={() => {
                    if (currentQuestion.type === "choice") {
                      handleSendAnswer(choice);
                    } else {
                      toggleChoice(choice);
                    }
                  }}
                  className={`px-4 py-2 rounded-2xl text-sm font-medium transition-all ${
                    selectedChoices.includes(choice)
                      ? "text-white shadow-inner"
                      : "neu-card text-gray-700 hover:shadow-md"
                  }`}
                  style={selectedChoices.includes(choice) ? { background: "#F07167" } : {}}
                >
                  {choice}
                </button>
              ))}
              {currentQuestion.type === "multiChoice" && selectedChoices.length > 0 && (
                <button
                  onClick={() => handleSendAnswer(selectedChoices)}
                  className="px-4 py-2 rounded-2xl text-sm font-semibold text-white flex items-center gap-1"
                  style={{ background: "#F07167" }}
                >
                  Confirmer <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>
          )}

          {/* Saisie texte / nombre */}
          {(currentQuestion.type === "text" || currentQuestion.type === "number" || currentQuestion.type === "date" || currentQuestion.type === "textarea") && (
            <div className="neu-card p-2 flex gap-2">
              {currentQuestion.type === "textarea" ? (
                <textarea
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  placeholder={currentQuestion.placeholder}
                  className="flex-1 bg-transparent text-sm text-gray-700 placeholder-gray-400 outline-none resize-none p-2"
                  rows={3}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSendAnswer(); } }}
                />
              ) : (
                <input
                  type={currentQuestion.type === "number" ? "number" : currentQuestion.type === "date" ? "date" : "text"}
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  placeholder={currentQuestion.placeholder}
                  className="flex-1 bg-transparent text-sm text-gray-700 placeholder-gray-400 outline-none p-2"
                  onKeyDown={e => { if (e.key === "Enter") handleSendAnswer(); }}
                  autoFocus
                />
              )}
              <button
                onClick={() => handleSendAnswer()}
                disabled={!inputValue.trim()}
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white disabled:opacity-40 transition-all"
                style={{ background: "#F07167" }}
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          )}
        </motion.div>
      )}

      {/* Écran de complétion */}
      {isCompleted && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="px-4 pb-6"
        >
          <div className="neu-card p-6 text-center">
            <CheckCircle className="w-12 h-12 mx-auto mb-3" style={{ color: "#F07167" }} />
            <h3 className="text-lg font-bold text-gray-800 mb-2">Votre espace est prêt !</h3>
            <p className="text-sm text-gray-500 mb-4">Timeline, guide et suggestions générés automatiquement</p>
            <Button
              onClick={() => navigate("/cockpit")}
              className="w-full text-white font-semibold py-3 rounded-2xl"
              style={{ background: "#F07167" }}
            >
              Accéder à mon Cockpit AURA
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
