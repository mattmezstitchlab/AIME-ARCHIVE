import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import {
  Heart, Sparkles, Users, Briefcase, Calendar, Brain, Wallet,
  Camera, Check, ArrowRight, ChevronRight,
  Instagram, Facebook, MapPin, Music
} from "lucide-react";

// ─── Scroll reveal hook ───────────────────────────────────────────────────────
function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("opacity-100", "translate-y-0");
            entry.target.classList.remove("opacity-0", "translate-y-10");
          }
        });
      },
      { threshold: 0.12 }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

// ─── Sticky header hook ───────────────────────────────────────────────────────
function useStickyHeader() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return scrolled;
}

// ─── Animated counter ─────────────────────────────────────────────────────────
function AnimatedNumber({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        let start = 0;
        const step = target / 60;
        const timer = setInterval(() => {
          start += step;
          if (start >= target) { setCount(target); clearInterval(timer); }
          else setCount(Math.floor(start));
        }, 16);
        observer.disconnect();
      }
    });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);
  return <span ref={ref}>{count.toLocaleString("fr-FR")}{suffix}</span>;
}

// ─── Section header ───────────────────────────────────────────────────────────
function SectionHeader({ label, title, dark = false }: { label: string; title: string; dark?: boolean }) {
  return (
    <div className="text-center mb-16 reveal opacity-0 translate-y-10 transition-all duration-700">
      <div className="flex items-center justify-center gap-3 mb-3">
        <div className="w-1.5 h-1.5 rounded-full" style={{ background: "#E8826A" }} />
        <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "#E8826A" }}>{label}</span>
        <div className="w-1.5 h-1.5 rounded-full" style={{ background: "#E8826A" }} />
      </div>
      <h2
        className={`text-4xl lg:text-5xl font-black ${dark ? "text-white" : "text-gray-800"}`}
        style={{ fontFamily: "'Playfair Display', serif" }}
      >
        {title}
      </h2>
      <div className="flex items-center justify-center gap-1.5 mt-4">
        {[0, 1, 2].map((i) => (
          <div key={i} className="w-1.5 h-1.5 rounded-full" style={{ background: "#E8826A", opacity: i === 1 ? 1 : 0.4 }} />
        ))}
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const scrolled = useStickyHeader();
  useScrollReveal();

  const handleCTA = () => {
    if (isAuthenticated) setLocation("/cockpit");
    else window.location.href = getLoginUrl();
  };

  const features = [
    { icon: <Calendar className="w-7 h-7" />, title: "Timeline IA", desc: "Un planning personnalisé généré par IA pour ne rien oublier et profiter sereinement." },
    { icon: <Wallet className="w-7 h-7" />, title: "Budget intelligent", desc: "Suivez vos dépenses en temps réel et recevez des recommandations pour optimiser votre budget." },
    { icon: <Users className="w-7 h-7" />, title: "Gestion invités", desc: "Gérez vos invités facilement, suivez les réponses et personnalisez chaque invitation." },
    { icon: <Briefcase className="w-7 h-7" />, title: "Portail prestataires", desc: "Trouvez, comparez et collaborez avec vos prestataires au même endroit." },
    { icon: <Heart className="w-7 h-7" />, title: "Mini-site personnalisé", desc: "Créez votre mini-site de mariage pour partager toutes les informations essentielles." },
    { icon: <Camera className="w-7 h-7" />, title: "Plan de table", desc: "Organisez vos tables en toute simplicité pour une réception harmonieuse et réussie." },
  ];

  const plans = [
    {
      name: "Essentiel",
      icon: <Heart className="w-6 h-6" style={{ color: "#E8826A" }} />,
      price: "29€", period: "/mois",
      features: ["Planning & checklist personnalisés", "Liste d'invités et gestion RSVP", "Budget et suivi des dépenses", "Mini-site de mariage"],
      cta: "Choisir Essentiel", highlight: false,
    },
    {
      name: "Premium",
      icon: <Sparkles className="w-6 h-6" style={{ color: "#E8826A" }} />,
      price: "59€", period: "/mois",
      features: ["Tout ce qui est inclus dans Essentiel", "Portail prestataires complet", "Assistance IA prioritaire", "Modèles et inspirations exclusifs", "Gestion simplifiée et centralisée"],
      cta: "Choisir Premium", highlight: true,
    },
    {
      name: "Prestige",
      icon: <Brain className="w-6 h-6" style={{ color: "#E8826A" }} />,
      price: "99€", period: "/mois",
      features: ["Tout ce qui est inclus dans Premium", "Accompagnement personnalisé 1:1", "Coordination jour J incluse", "Planning illimité et ajustements", "Support dédié par téléphone"],
      cta: "Choisir Prestige", highlight: false,
    },
  ];

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ══════════════════════════════════════════════════════════════════
          HEADER — transparent → opaque au scroll
      ══════════════════════════════════════════════════════════════════ */}
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? "rgba(26, 26, 46, 0.95)" : "transparent",
          backdropFilter: scrolled ? "blur(12px)" : "none",
          borderBottom: scrolled ? "1px solid rgba(232, 130, 106, 0.15)" : "none",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "#E8826A" }}>
              <Heart className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-white text-lg tracking-wide">AURA</span>
            <span className="text-white/40 text-xs uppercase tracking-widest hidden sm:block">Wedding OS</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            {[
              { label: "Fonctionnalités", href: "#features" },
              { label: "Tarifs", href: "/tarifs" },
              { label: "À propos", href: "#" },
            ].map((item) => (
              <a key={item.label} href={item.href} className="text-sm text-white/70 hover:text-white transition-colors">
                {item.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <button onClick={handleCTA} className="text-sm text-white/70 hover:text-white transition-colors hidden sm:block">
              {isAuthenticated ? "Mon Cockpit" : "Connexion"}
            </button>
            <button
              onClick={handleCTA}
              className="px-5 py-2 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90"
              style={{ background: "#E8826A" }}
            >
              {isAuthenticated ? "Accéder au Cockpit" : "Essayer gratuitement"}
            </button>
          </div>
        </div>
      </header>

      {/* ══════════════════════════════════════════════════════════════════
          SECTION 1 — HERO (fond sombre immersif)
      ══════════════════════════════════════════════════════════════════ */}
      <section className="relative min-h-screen flex items-center overflow-hidden" style={{ background: "#1a1a2e" }}>
        {/* Fond photo avec overlay */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('https://res.cloudinary.com/divou1vcx/image/upload/v1778123484/Two_astronauts_floating_together_in_space_wearing_elegant_wedding_outfits_connected_by_soft_light_emotional_poetic_cinematic_lighting_clouds_and_stars_dark_background_luxury_editorial_style_4k_eamjce.jpg')", opacity: 1 }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(135deg, rgba(26,26,46,0.75) 0%, rgba(26,26,46,0.45) 50%, rgba(26,26,46,0.65) 100%)" }}
        />

        <div className="relative z-10 max-w-7xl mx-auto px-6 pt-24 pb-16 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Texte gauche */}
            <div>
              <div
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-6"
                style={{ background: "rgba(232,130,106,0.15)", color: "#E8826A", border: "1px solid rgba(232,130,106,0.3)" }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                Votre wedding planner intelligent
              </div>

              <h1
                className="text-5xl lg:text-6xl font-black text-white leading-tight mb-6"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                Organisez votre<br />
                <span style={{ color: "#E8826A", fontStyle: "italic" }}>mariage parfait</span><br />
                avec l'IA
              </h1>

              <p className="text-white/65 text-lg leading-relaxed mb-8 max-w-md">
                AURA, votre wedding planner intelligent qui transforme chaque détail en un moment d'exception.
                De l'inspiration à la célébration, nous sommes à vos côtés.
              </p>

              <div className="flex flex-wrap gap-4 mb-10">
                <button
                  onClick={handleCTA}
                  className="flex items-center gap-2 px-8 py-4 rounded-2xl text-white font-bold text-base transition-all hover:opacity-90 hover:scale-105"
                  style={{ background: "#E8826A" }}
                >
                  Commencer maintenant
                  <ArrowRight className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setLocation("/tarifs")}
                  className="flex items-center gap-2 px-8 py-4 rounded-2xl text-white font-bold text-base transition-all hover:bg-white/10"
                  style={{ border: "1px solid rgba(255,255,255,0.25)" }}
                >
                  Voir les tarifs
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              <div className="flex items-center gap-2 text-white/40 text-sm mb-10">
                <div className="w-4 h-4 rounded-full flex items-center justify-center" style={{ background: "rgba(232,130,106,0.2)" }}>
                  <Check className="w-2.5 h-2.5" style={{ color: "#E8826A" }} />
                </div>
                Données sécurisées et confidentialité garantie
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-8 border-t border-white/10">
                {[
                  { value: 2400, suffix: "+", label: "Couples accompagnés" },
                  { value: 98, suffix: "%", label: "Satisfaction" },
                  { value: 12, suffix: "", label: "Modules tout-en-un" },
                ].map((stat) => (
                  <div key={stat.label}>
                    <div className="text-2xl font-black text-white">
                      <AnimatedNumber target={stat.value} suffix={stat.suffix} />
                    </div>
                    <div className="text-white/40 text-xs mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Dashboard neumorphique — île claire sur fond sombre */}
            <div className="hidden lg:flex justify-center">
              <div
                className="w-full max-w-sm rounded-3xl p-6 reveal opacity-0 translate-y-10 transition-all duration-700"
                style={{ background: "#E8EDF2", boxShadow: "0 20px 60px rgba(0,0,0,0.45), 0 8px 24px rgba(0,0,0,0.25)" }}
              >
                <div className="flex items-center justify-between mb-5">
                  <div>
                    <p className="text-xs text-gray-400 uppercase tracking-widest">Votre mariage</p>
                    <p className="font-semibold text-gray-700 text-sm mt-0.5">Camille & Alexandre</p>
                  </div>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "#E8826A" }}>
                    <Heart className="w-5 h-5 text-white" />
                  </div>
                </div>

                <div className="rounded-2xl p-4 mb-4" style={{ background: "#dce1e6", boxShadow: "inset 2px 2px 5px #c8cdd2, inset -2px -2px 5px #f0f4f8" }}>
                  <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">Il reste</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black text-gray-800">247</span>
                    <span className="text-lg font-light text-gray-500 italic" style={{ fontFamily: "Playfair Display, serif" }}>jours</span>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-400 mb-2">
                    <span>Progression globale</span>
                    <span>68%</span>
                  </div>
                  <div className="h-2 rounded-full" style={{ background: "#dce1e6", boxShadow: "inset 2px 2px 4px #c8cdd2, inset -2px -2px 4px #f0f4f8" }}>
                    <div className="h-2 rounded-full" style={{ width: "68%", background: "#E8826A" }} />
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-2 mb-4">
                  {[
                    { icon: <Calendar className="w-4 h-4" />, label: "Planning" },
                    { icon: <Users className="w-4 h-4" />, label: "Invités" },
                    { icon: <Briefcase className="w-4 h-4" />, label: "Presta." },
                    { icon: <Wallet className="w-4 h-4" />, label: "Budget" },
                  ].map((m) => (
                    <div
                      key={m.label}
                      className="rounded-xl p-2 flex flex-col items-center gap-1"
                      style={{ background: "#E8EDF2", boxShadow: "3px 3px 6px #c8cdd2, -3px -3px 6px #f8fbff" }}
                    >
                      <div style={{ color: "#E8826A" }}>{m.icon}</div>
                      <span className="text-xs text-gray-500">{m.label}</span>
                    </div>
                  ))}
                </div>

                <div className="rounded-xl p-3 flex items-center gap-3" style={{ background: "#E8EDF2", boxShadow: "3px 3px 6px #c8cdd2, -3px -3px 6px #f8fbff" }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "#E8826A" }}>
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-700">AURA IA vous accompagne</p>
                    <p className="text-xs text-gray-400 truncate">Suggestions personnalisées</p>
                  </div>
                  <button
                    className="text-xs font-semibold px-3 py-1.5 rounded-lg flex-shrink-0"
                    style={{ background: "rgba(232,130,106,0.12)", color: "#E8826A", border: "1px solid rgba(232,130,106,0.25)" }}
                  >
                    Demander
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════
          SECTION 2 — TROIS ESPACES (fond clair #E8EDF2, neumorphique pur)
      ══════════════════════════════════════════════════════════════════ */}
      <section className="py-24" style={{ background: "#E8EDF2" }}>
        <div className="max-w-6xl mx-auto px-6">
          <SectionHeader label="AURA" title="Trois espaces, une vision" />
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <Heart className="w-10 h-10" />, title: "Espace Mariés", desc: "Un espace privé pour organiser, suivre et vivre chaque étape de votre mariage.", delay: "0ms" },
              { icon: <Users className="w-10 h-10" />, title: "Espace Invités", desc: "Toutes les informations utiles pour accompagner vos invités en toute simplicité.", delay: "150ms" },
              { icon: <Briefcase className="w-10 h-10" />, title: "Espace Prestataires", desc: "Un espace dédié pour collaborer et coordonner avec vos prestataires de confiance.", delay: "300ms" },
            ].map((card) => (
              <div
                key={card.title}
                className="reveal opacity-0 translate-y-10 transition-all duration-700 rounded-3xl p-8 flex flex-col items-center text-center group cursor-pointer"
                style={{ background: "#E8EDF2", boxShadow: "10px 10px 20px #c8cdd2, -10px -10px 20px #ffffff", transitionDelay: card.delay }}
              >
                <div
                  className="w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-transform group-hover:scale-105"
                  style={{ background: "#E8EDF2", boxShadow: "8px 8px 16px #c8cdd2, -8px -8px 16px #ffffff", color: "#E8826A" }}
                >
                  {card.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {card.title}
                </h3>
                <div className="w-4 h-0.5 rounded-full mb-3" style={{ background: "#E8826A" }} />
                <p className="text-gray-500 text-sm leading-relaxed">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════
          SECTION 3 — FONCTIONNALITÉS (fond chaud #F5EDE8, texture florale)
      ══════════════════════════════════════════════════════════════════ */}
      <section id="features" className="py-24 relative overflow-hidden" style={{ background: "#E8EDF2" }}>
        {/* Texture florale subtile */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23E8826A' fill-opacity='0.035'%3E%3Ccircle cx='40' cy='20' r='6'/%3E%3Ccircle cx='40' cy='60' r='6'/%3E%3Ccircle cx='20' cy='40' r='6'/%3E%3Ccircle cx='60' cy='40' r='6'/%3E%3Ccircle cx='40' cy='40' r='3'/%3E%3C/g%3E%3C/svg%3E")`,
           backgroundSize: "80px 80px",
          }}
        />
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <SectionHeader label="AURA" title="Tout ce dont vous avez besoin" />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feat, i) => (
              <div
                key={feat.title}
                className="reveal opacity-0 translate-y-10 transition-all duration-700 rounded-2xl p-6 flex items-start gap-4 group cursor-pointer"
                style={{
                  background: "#E8EDF2",
                  boxShadow: "6px 6px 14px #c8cdd2, -6px -6px 14px #ffffff",
                  transitionDelay: `${i * 80}ms`,
                }}
              >
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-105"
                  style={{ background: "#E8EDF2", boxShadow: "4px 4px 8px #c8cdd2, -4px -4px 8px #ffffff", color: "#E8826A" }}
                >
                  {feat.icon}
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 mb-1.5">{feat.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{feat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════
          SECTION 4 — TARIFS (fond sombre + dark neumorphism)
      ══════════════════════════════════════════════════════════════════ */}
      <section id="pricing" className="py-24 relative overflow-hidden" style={{ background: "#1a1a2e" }}>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/manus-storage/pricing-bg_0fce70c6.jpg')", opacity: 0.18 }}
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(26,26,46,0.7) 0%, rgba(26,26,46,0.9) 100%)" }} />

        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <SectionHeader label="AURA" title="Choisissez votre formule" dark />

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, i) => (
              <div
                key={plan.name}
                className="reveal opacity-0 translate-y-10 transition-all duration-700 rounded-3xl p-8 flex flex-col relative"
                style={{
                  background: "#252545",
                  boxShadow: plan.highlight
                    ? "10px 10px 20px #0f0f1e, -10px -10px 20px #2e2e5a, 0 0 0 1.5px #E8826A"
                    : "10px 10px 20px #0f0f1e, -10px -10px 20px #2e2e5a",
                  transitionDelay: `${i * 120}ms`,
                }}
              >
                {plan.highlight && (
                  <div
                    className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-xs font-bold px-4 py-1.5 rounded-full text-white whitespace-nowrap"
                    style={{ background: "#E8826A" }}
                  >
                    Recommandé
                  </div>
                )}

                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                  style={{ background: "#1e1e3a", boxShadow: "4px 4px 8px #0f0f1e, -4px -4px 8px #2e2e5a" }}
                >
                  {plan.icon}
                </div>

                <h3 className="text-xl font-bold text-white mb-1" style={{ fontFamily: "Playfair Display, serif" }}>
                  {plan.name}
                </h3>
                <div className="flex items-baseline gap-1 mb-5">
                  <span className="text-4xl font-black text-white">{plan.price}</span>
                  <span className="text-white/40 text-sm">{plan.period}</span>
                </div>

                <div className="h-px mb-5" style={{ background: "rgba(255,255,255,0.08)" }} />

                <ul className="space-y-3 mb-8 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm text-white/65">
                      <Check className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "#E8826A" }} />
                      {f}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => setLocation("/tarifs")}
                  className="w-full py-3.5 rounded-xl text-sm font-bold transition-all hover:opacity-90"
                  style={
                    plan.highlight
                      ? { background: "#E8826A", color: "white" }
                      : { background: "transparent", color: "#E8826A", border: "1.5px solid rgba(232,130,106,0.4)" }
                  }
                >
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap justify-center gap-8 mt-12 reveal opacity-0 translate-y-10 transition-all duration-700">
            {["Essai gratuit 14 jours", "Sans engagement", "Résiliation en 1 clic"].map((g) => (
              <div key={g} className="flex items-center gap-2 text-white/50 text-sm">
                <Check className="w-4 h-4" style={{ color: "#E8826A" }} />
                {g}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════
          FOOTER (fond sombre #0f0f1a, continuité avec Tarifs)
      ══════════════════════════════════════════════════════════════════ */}
      <footer style={{ background: "#0f0f1a" }}>
        {/* Séparateur coral */}
        <div className="flex items-center px-6">
          <div className="flex-1 h-px" style={{ background: "rgba(232,130,106,0.25)" }} />
          <div className="mx-4">
            <Heart className="w-4 h-4" style={{ color: "#E8826A", opacity: 0.6 }} />
          </div>
          <div className="flex-1 h-px" style={{ background: "rgba(232,130,106,0.25)" }} />
        </div>

        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid md:grid-cols-4 gap-10">
            {/* Logo + réseaux */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2.5 mb-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "#E8826A" }}>
                  <Heart className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-white text-lg">AURA</span>
              </div>
              <p className="text-xs text-white/30 uppercase tracking-widest mb-4">Wedding OS · Paris</p>
              <p className="text-white/45 text-sm leading-relaxed mb-6">
                L'application de wedding planning intelligente qui transforme chaque détail en un moment d'exception.
              </p>
              <div className="flex gap-2">
                {[Instagram, Facebook, MapPin, Music].map((Icon, i) => (
                  <div
                    key={i}
                    className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer transition-all hover:scale-110"
                    style={{ background: "#1a1a2e", boxShadow: "3px 3px 6px #080810, -3px -3px 6px #252545" }}
                  >
                    <Icon className="w-4 h-4 text-white/40" />
                  </div>
                ))}
              </div>
            </div>

            {/* Fonctionnalités */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: "#E8826A" }}>
                Fonctionnalités
              </h4>
              <ul className="space-y-2.5">
                {["Planning", "Invités", "Prestataires", "Budget", "Mini-site", "AURA IA"].map((l) => (
                  <li key={l}><a href="#" className="text-white/45 text-sm hover:text-white transition-colors">{l}</a></li>
                ))}
              </ul>
            </div>

            {/* Tarifs */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: "#E8826A" }}>
                Tarifs
              </h4>
              <ul className="space-y-2.5">
                {["Essentiel", "Premium", "Prestige", "Comparatif"].map((l) => (
                  <li key={l}><a href="/tarifs" className="text-white/45 text-sm hover:text-white transition-colors">{l}</a></li>
                ))}
              </ul>
            </div>

            {/* Newsletter */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: "#E8826A" }}>
                Restez inspirés
              </h4>
              <p className="text-white/45 text-sm mb-4 leading-relaxed">
                Recevez nos conseils, inspirations et nouveautés pour un mariage à votre image.
              </p>
              <div className="space-y-2">
                <input
                  type="email"
                  placeholder="Votre adresse e-mail"
                  className="w-full px-4 py-3 rounded-xl text-sm text-white/70 outline-none placeholder:text-white/25"
                  style={{ background: "#1a1a2e", boxShadow: "inset 3px 3px 6px #080810, inset -3px -3px 6px #252545", border: "none" }}
                />
                <button
                  className="w-full py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90"
                  style={{ background: "#E8826A" }}
                >
                  S'inscrire →
                </button>
              </div>
            </div>
          </div>

          {/* Bottom bar */}
          <div
            className="mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"
            style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
          >
            <p className="text-white/25 text-xs">© 2026 AURA Wedding OS. Tous droits réservés.</p>
            <div className="flex items-center gap-4 text-xs text-white/25">
              {[
                { label: "CGU", href: "/cgu" },
                { label: "CGV", href: "/cgv" },
                { label: "Mentions légales", href: "/mentions-legales" },
                { label: "Confidentialité", href: "/confidentialite" },
              ].map((link) => (
                <a key={link.label} href={link.href} className="hover:text-white/60 transition-colors">
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
