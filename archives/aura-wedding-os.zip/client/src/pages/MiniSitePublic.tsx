import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import {
  Heart, MapPin, Calendar, Camera, Loader2, X, Clock,
  Utensils, Car, Hotel, Shirt, ChevronDown, ChevronUp,
  Check, Send, Image as ImageIcon, ExternalLink
} from "lucide-react";

// ─── Countdown ────────────────────────────────────────────────────────────────
function Countdown({ weddingDate }: { weddingDate: Date }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  useEffect(() => {
    const calc = () => {
      const diff = new Date(weddingDate).getTime() - Date.now();
      if (diff <= 0) return setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      setTimeLeft({
        days: Math.floor(diff / 86400000),
        hours: Math.floor((diff % 86400000) / 3600000),
        minutes: Math.floor((diff % 3600000) / 60000),
        seconds: Math.floor((diff % 60000) / 1000),
      });
    };
    calc();
    const t = setInterval(calc, 1000);
    return () => clearInterval(t);
  }, [weddingDate]);
  const items = [
    { label: "Jours", value: timeLeft.days },
    { label: "Heures", value: timeLeft.hours },
    { label: "Minutes", value: timeLeft.minutes },
    { label: "Secondes", value: timeLeft.seconds },
  ];
  return (
    <div className="flex gap-3 justify-center flex-wrap mt-6">
      {items.map(({ label, value }) => (
        <div key={label} className="text-center neu-card px-5 py-4 min-w-[72px]">
          <p className="text-3xl font-black" style={{ color: "var(--coral)" }}>{String(value).padStart(2, "0")}</p>
          <p className="text-xs text-muted-foreground mt-1">{label}</p>
        </div>
      ))}
    </div>
  );
}

// ─── RSVP Form ────────────────────────────────────────────────────────────────
function RsvpForm({ slug }: { slug: string }) {
  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "",
    rsvpStatus: "confirmed" as "confirmed" | "declined" | "maybe",
    plusOneConfirmed: false, dietaryRestrictions: "", message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const submitMutation = trpc.wedding.submitRsvpBySlug.useMutation({
    onSuccess: () => setSubmitted(true),
  });

  if (submitted) return (
    <div className="text-center py-8">
      <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "rgba(123,196,127,0.15)" }}>
        <Check className="w-8 h-8" style={{ color: "#7BC47F" }} />
      </div>
      <h3 className="text-xl font-bold mb-2">Réponse enregistrée !</h3>
      <p className="text-muted-foreground">Merci pour votre réponse. Les mariés ont été notifiés.</p>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-medium text-muted-foreground block mb-1">Prénom *</label>
          <input className="neu-input w-full" placeholder="Prénom" value={form.firstName}
            onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} />
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground block mb-1">Nom *</label>
          <input className="neu-input w-full" placeholder="Nom" value={form.lastName}
            onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} />
        </div>
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1">Email</label>
        <input className="neu-input w-full" type="email" placeholder="votre@email.com" value={form.email}
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-2">Votre réponse *</label>
        <div className="flex gap-2">
          {([
            { value: "confirmed", label: "✓ Je serai là !", color: "#7BC47F" },
            { value: "declined", label: "✗ Je ne pourrai pas", color: "#F07167" },
            { value: "maybe", label: "? Peut-être", color: "#C4A87B" },
          ] as const).map(opt => (
            <button key={opt.value} onClick={() => setForm(f => ({ ...f, rsvpStatus: opt.value }))}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all"
              style={{
                background: form.rsvpStatus === opt.value ? opt.color : "transparent",
                color: form.rsvpStatus === opt.value ? "white" : opt.color,
                border: `2px solid ${opt.color}`,
              }}>
              {opt.label}
            </button>
          ))}
        </div>
      </div>
      {form.rsvpStatus === "confirmed" && (
        <label className="flex items-center gap-3 cursor-pointer">
          <div onClick={() => setForm(f => ({ ...f, plusOneConfirmed: !f.plusOneConfirmed }))}
            className="w-5 h-5 rounded-md flex items-center justify-center transition-all"
            style={{
              background: form.plusOneConfirmed ? "var(--coral)" : "transparent",
              border: `2px solid var(--coral)`,
            }}>
            {form.plusOneConfirmed && <Check className="w-3 h-3 text-white" />}
          </div>
          <span className="text-sm">J'amène un(e) accompagnant(e)</span>
        </label>
      )}
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1">Régime alimentaire / allergies</label>
        <input className="neu-input w-full" placeholder="Végétarien, sans gluten..." value={form.dietaryRestrictions}
          onChange={e => setForm(f => ({ ...f, dietaryRestrictions: e.target.value }))} />
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1">Message aux mariés</label>
        <textarea className="neu-input w-full resize-none" rows={3} placeholder="Un mot pour les mariés..."
          value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} />
      </div>
      <button
        onClick={() => submitMutation.mutate({ slug, ...form })}
        disabled={!form.firstName || !form.lastName || submitMutation.isPending}
        className="w-full py-3.5 rounded-2xl text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50"
        style={{ background: "linear-gradient(135deg, var(--coral-light), var(--coral))" }}>
        {submitMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
        {submitMutation.isPending ? "Envoi en cours..." : "Envoyer ma réponse"}
      </button>
    </div>
  );
}

// ─── Category icons for timeline ─────────────────────────────────────────────
const CAT_ICONS: Record<string, React.ElementType> = {
  ceremony: Heart, reception: Utensils, preparation: Shirt,
  photo: Camera, transport: Car, dinner: Utensils,
  entertainment: Heart, administrative: Calendar, other: Clock,
};
const CAT_LABELS: Record<string, string> = {
  ceremony: "Cérémonie", reception: "Réception", preparation: "Préparation",
  photo: "Photos", transport: "Transport", dinner: "Dîner",
  entertainment: "Animation", administrative: "Administratif", other: "Autre",
};

// ─── Accordion Section ────────────────────────────────────────────────────────
function AccordionSection({
  id, icon: Icon, title, subtitle, expanded, onToggle, children, themeColor,
}: {
  id: string; icon: React.ElementType; title: string; subtitle?: string;
  expanded: boolean; onToggle: () => void; children: React.ReactNode; themeColor: string;
}) {
  return (
    <div className="neu-card overflow-hidden">
      <button onClick={onToggle} className="w-full p-6 flex items-center justify-between text-left">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">{title}</h2>
            {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
          </div>
        </div>
        {expanded ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
      </button>
      {expanded && <div className="px-6 pb-6">{children}</div>}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function MiniSitePublic() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug || "";
  const [expandedSection, setExpandedSection] = useState<string | null>("rsvp");
  const toggleSection = (id: string) => setExpandedSection(prev => prev === id ? null : id);

  const { data: wedding, isLoading } = trpc.wedding.getBySlug.useQuery(
    { slug }, { enabled: !!slug }
  );
  const { data: timeline } = trpc.wedding.getPublicTimeline.useQuery(
    { slug }, { enabled: !!slug && !!wedding?.miniSiteShowTimeline }
  );
  const { data: photos } = trpc.wedding.getPublicPhotos.useQuery(
    { slug }, { enabled: !!slug && !!wedding?.miniSiteShowPhotos }
  );

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--coral)" }} />
    </div>
  );

  if (!wedding) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <div className="text-center neu-card p-10 max-w-md mx-4">
        <X className="w-12 h-12 mx-auto mb-4" style={{ color: "#F07167" }} />
        <h2 className="text-xl font-bold mb-2">Page introuvable</h2>
        <p className="text-muted-foreground">Ce mini-site n'existe pas ou n'est pas encore activé.</p>
      </div>
    </div>
  );

  const themeColor = wedding.miniSiteThemeColor || "#F07167";
  const daysLeft = wedding.weddingDate
    ? Math.ceil((new Date(wedding.weddingDate).getTime() - Date.now()) / 86400000)
    : null;
  const isToday = daysLeft === 0;
  const isPast = daysLeft !== null && daysLeft < 0;
  const hasPractical = wedding.miniSiteDressCode || wedding.miniSiteTransportInfo || wedding.miniSiteAccommodation;

  return (
    <div className="min-h-screen" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>

      {/* ── Hero ── */}
      <div className="relative overflow-hidden" style={{
        background: `linear-gradient(135deg, ${themeColor}18, ${themeColor}05)`,
        minHeight: "65vh"
      }}>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="absolute rounded-full"
              style={{
                width: `${100 + i * 50}px`, height: `${100 + i * 50}px`,
                background: themeColor, opacity: 0.06,
                top: `${8 + i * 14}%`, left: `${3 + i * 18}%`,
                animation: `float ${3 + i * 0.7}s ease-in-out infinite alternate`,
              }} />
          ))}
        </div>
        <div className="relative z-10 flex flex-col items-center justify-center text-center px-4 py-20 lg:py-28">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center mb-8"
            style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
            <Heart className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl lg:text-7xl font-black mb-4" style={{ fontFamily: "Playfair Display, serif" }}>
            {wedding.partner1Name} <span style={{ color: themeColor }}>&</span> {wedding.partner2Name}
          </h1>
          {wedding.weddingDate && (
            <p className="text-xl text-muted-foreground">
              {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
            </p>
          )}
          {wedding.weddingDate && !isPast && !isToday && (
            <Countdown weddingDate={new Date(wedding.weddingDate)} />
          )}
          {isToday && (
            <div className="neu-card px-8 py-4 inline-flex items-center gap-3 mt-6">
              <span className="text-3xl font-black" style={{ color: themeColor }}>C'est aujourd'hui ! 🎉</span>
            </div>
          )}
          {isPast && (
            <div className="neu-card px-8 py-4 inline-flex items-center gap-3 mt-6">
              <span className="text-xl font-bold text-muted-foreground">Mariage célébré ♥</span>
            </div>
          )}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="max-w-3xl mx-auto px-4 py-12 space-y-6">

        {/* Message de bienvenue */}
        {wedding.miniSiteWelcomeMsg && (
          <div className="neu-card p-8 text-center">
            <p className="text-lg leading-relaxed italic text-muted-foreground">"{wedding.miniSiteWelcomeMsg}"</p>
            <p className="mt-4 font-semibold" style={{ color: themeColor }}>
              — {wedding.partner1Name} & {wedding.partner2Name}
            </p>
          </div>
        )}

        {/* Lieu */}
        {(wedding.venue || wedding.city) && (
          <div className="neu-card p-8 flex items-start gap-6">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
              <MapPin className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold mb-2">Le lieu</h2>
              {wedding.venue && <p className="font-semibold text-lg">{wedding.venue}</p>}
              {wedding.city && <p className="text-muted-foreground">{wedding.city}</p>}
              {wedding.miniSiteShowMap && (
                <a href={`https://maps.google.com/?q=${encodeURIComponent([wedding.venue, wedding.city].filter(Boolean).join(", "))}`}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 mt-3 text-sm font-medium hover:underline"
                  style={{ color: themeColor }}>
                  <ExternalLink className="w-4 h-4" /> Voir sur Google Maps
                </a>
              )}
            </div>
          </div>
        )}

        {/* Date */}
        {wedding.weddingDate && (
          <div className="neu-card p-8 flex items-start gap-6">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
              <Calendar className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold mb-2">La date</h2>
              <p className="font-semibold text-lg">
                {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
              </p>
            </div>
          </div>
        )}

        {/* Programme */}
        {wedding.miniSiteShowTimeline && timeline && timeline.length > 0 && (
          <AccordionSection id="timeline" icon={Clock} title="Programme" subtitle={`${timeline.length} étape${timeline.length > 1 ? "s" : ""}`}
            expanded={expandedSection === "timeline"} onToggle={() => toggleSection("timeline")} themeColor={themeColor}>
            <div className="space-y-3">
              {timeline.map((event, idx) => {
                const Icon = CAT_ICONS[event.category] || Clock;
                return (
                  <div key={event.id} className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ background: `${themeColor}20`, color: themeColor }}>
                        <Icon className="w-4 h-4" />
                      </div>
                      {idx < timeline.length - 1 && (
                        <div className="w-0.5 h-6 mt-1" style={{ background: `${themeColor}30` }} />
                      )}
                    </div>
                    <div className="flex-1 pb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold">{event.title}</p>
                        <span className="text-xs px-2 py-0.5 rounded-full"
                          style={{ background: `${themeColor}15`, color: themeColor }}>
                          {CAT_LABELS[event.category] || event.category}
                        </span>
                      </div>
                      {event.scheduledAt && (
                        <p className="text-sm text-muted-foreground mt-0.5">
                          {new Date(event.scheduledAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                          {event.durationMinutes ? ` · ${event.durationMinutes} min` : ""}
                        </p>
                      )}
                      {event.location && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3" />{event.location}
                        </p>
                      )}
                      {event.description && <p className="text-sm text-muted-foreground mt-1">{event.description}</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </AccordionSection>
        )}

        {/* RSVP */}
        {wedding.miniSiteShowRsvp && (
          <AccordionSection id="rsvp" icon={Heart} title="Confirmer ma présence" subtitle="Répondez directement ici"
            expanded={expandedSection === "rsvp"} onToggle={() => toggleSection("rsvp")} themeColor={themeColor}>
            <RsvpForm slug={slug} />
          </AccordionSection>
        )}

        {/* Infos pratiques */}
        {wedding.miniSiteShowPractical && hasPractical && (
          <AccordionSection id="practical" icon={Shirt} title="Infos pratiques" subtitle="Dress code, transports, hébergements"
            expanded={expandedSection === "practical"} onToggle={() => toggleSection("practical")} themeColor={themeColor}>
            <div className="space-y-5">
              {wedding.miniSiteDressCode && (
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${themeColor}15` }}>
                    <Shirt className="w-5 h-5" style={{ color: themeColor }} />
                  </div>
                  <div>
                    <p className="font-semibold mb-1">Dress code</p>
                    <p className="text-muted-foreground text-sm whitespace-pre-wrap">{wedding.miniSiteDressCode}</p>
                  </div>
                </div>
              )}
              {wedding.miniSiteTransportInfo && (
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${themeColor}15` }}>
                    <Car className="w-5 h-5" style={{ color: themeColor }} />
                  </div>
                  <div>
                    <p className="font-semibold mb-1">Transports</p>
                    <p className="text-muted-foreground text-sm whitespace-pre-wrap">{wedding.miniSiteTransportInfo}</p>
                  </div>
                </div>
              )}
              {wedding.miniSiteAccommodation && (
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${themeColor}15` }}>
                    <Hotel className="w-5 h-5" style={{ color: themeColor }} />
                  </div>
                  <div>
                    <p className="font-semibold mb-1">Hébergements</p>
                    <p className="text-muted-foreground text-sm whitespace-pre-wrap">{wedding.miniSiteAccommodation}</p>
                  </div>
                </div>
              )}
            </div>
          </AccordionSection>
        )}

        {/* Notre histoire */}
        {wedding.notes && (
          <div className="neu-card p-8">
            <h2 className="text-xl font-bold mb-4">Notre histoire</h2>
            <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{wedding.notes}</p>
          </div>
        )}

        {/* Galerie photos */}
        {wedding.miniSiteShowPhotos && photos && photos.length > 0 && (
          <AccordionSection id="photos" icon={ImageIcon}
            title="Galerie photos"
            subtitle={`${photos.length} photo${photos.length > 1 ? "s" : ""} partagée${photos.length > 1 ? "s" : ""}`}
            expanded={expandedSection === "photos"} onToggle={() => toggleSection("photos")} themeColor={themeColor}>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {photos.map(photo => (
                <div key={photo.id} className="relative rounded-2xl overflow-hidden aspect-square">
                  <img src={photo.fileUrl} alt="" className="w-full h-full object-cover" />
                  {photo.uploaderName && (
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                      <p className="text-white text-xs font-medium">{photo.uploaderName}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </AccordionSection>
        )}

        {/* Mur photo live */}
        <div className="neu-card p-8 text-center">
          <Camera className="w-10 h-10 mx-auto mb-4" style={{ color: themeColor }} />
          <h2 className="text-xl font-bold mb-2">Mur de photos en direct</h2>
          <p className="text-muted-foreground mb-4">
            Partagez vos photos du mariage en temps réel et voyez celles des autres invités !
          </p>
          <a href={`/photowall/${slug}`}
            className="inline-flex items-center gap-2 px-8 py-3 rounded-2xl text-white font-semibold"
            style={{ background: `linear-gradient(135deg, ${themeColor}cc, ${themeColor})` }}>
            <Camera className="w-5 h-5" /> Accéder au mur de photos
          </a>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-muted-foreground text-sm border-t"
        style={{ borderColor: "rgba(0,0,0,0.06)" }}>
        <p>Créé avec <span style={{ color: themeColor }}>♥</span> sur <strong>AURA Wedding OS</strong></p>
      </div>
    </div>
  );
}
