import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Store, Heart, Calendar, MapPin, Check, Loader2, X, Mail, Phone, Globe, ArrowRight } from "lucide-react";
import { useState } from "react";

export default function ProviderPortal() {
  const params = useParams<{ token: string }>();
  const [, setLocation] = useLocation();
  const [sessionToken, setSessionToken] = useState<string | null>(null);

  const { data, isLoading } = trpc.providerPortal.getByToken.useQuery(
    { token: params.token || "" },
    { enabled: !!params.token }
  );

  // Mutation qui crée une vraie session de 30 jours et retourne le sessionToken
  const acceptMutation = trpc.providerSpace.acceptAndCreateSession.useMutation({
    onSuccess: (result) => {
      setSessionToken(result.sessionToken);
    },
  });

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--coral)" }} />
    </div>
  );

  if (!data || !data.invitation) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <div className="text-center neu-card p-10 max-w-md mx-4">
        <X className="w-12 h-12 mx-auto mb-4" style={{ color: "#F07167" }} />
        <h2 className="text-xl font-bold mb-2">Invitation invalide</h2>
        <p className="text-muted-foreground">Ce lien d'invitation n'est pas valide ou a expiré.</p>
      </div>
    </div>
  );

  const { invitation, provider, wedding } = data;
  const alreadyAccepted = invitation.accepted === true;

  // Si déjà accepté et qu'on a un sessionToken stocké localement → bouton pour accéder au dashboard
  const dashboardUrl = sessionToken
    ? `/provider/dashboard?token=${sessionToken}`
    : null;

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>
      <div className="w-full max-w-xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 neu-btn-coral">
            <Store className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-black mb-2">Invitation Prestataire</h1>
          <p className="text-muted-foreground">Vous avez été invité(e) à rejoindre l'espace prestataire AURA</p>
        </div>

        {/* Wedding info */}
        {wedding && (
          <div className="neu-card p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Heart className="w-5 h-5" style={{ color: "var(--coral)" }} />
              <h2 className="font-bold">Le mariage</h2>
            </div>
            <div className="space-y-3">
              <p className="font-semibold text-lg">{wedding.partner1Name} & {wedding.partner2Name}</p>
              {wedding.weddingDate && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</span>
                </div>
              )}
              {wedding.venue && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>{wedding.venue}{wedding.city ? `, ${wedding.city}` : ""}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Provider info */}
        {provider && (
          <div className="neu-card p-6 mb-6">
            <h2 className="font-bold mb-4">Votre fiche prestataire</h2>
            <div className="space-y-3">
              <p className="font-semibold text-lg">{provider.name}</p>
              {provider.email && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-4 h-4" />
                  <span>{provider.email}</span>
                </div>
              )}
              {provider.phone && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4" />
                  <span>{provider.phone}</span>
                </div>
              )}
              {provider.website && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Globe className="w-4 h-4" />
                  <a href={provider.website} target="_blank" rel="noopener noreferrer" className="hover:underline" style={{ color: "var(--coral)" }}>{provider.website}</a>
                </div>
              )}
            </div>
          </div>
        )}

        {/* State: session just created → show access button */}
        {sessionToken && dashboardUrl ? (
          <div className="neu-card p-6 text-center space-y-4">
            <Check className="w-12 h-12 mx-auto" style={{ color: "#7BC47F" }} />
            <p className="font-bold text-lg">Invitation acceptée !</p>
            <p className="text-muted-foreground text-sm">Votre espace prestataire est prêt. Accédez-y maintenant et conservez ce lien pour y revenir.</p>
            <div className="flex flex-col gap-3">
              <button
                onClick={() => setLocation(dashboardUrl)}
                className="w-full py-4 rounded-2xl text-white font-bold text-lg flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, var(--coral-light), var(--coral))" }}
              >
                Accéder à mon espace prestataire <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigator.clipboard.writeText(`${window.location.origin}${dashboardUrl}`)}
                className="w-full py-3 rounded-2xl text-sm font-medium neu-btn"
              >
                Copier le lien de mon espace
              </button>
            </div>
          </div>
        ) : alreadyAccepted ? (
          /* Already accepted in a previous session — show info */
          <div className="neu-card p-6 text-center space-y-4">
            <Check className="w-12 h-12 mx-auto" style={{ color: "#7BC47F" }} />
            <p className="font-bold text-lg">Invitation déjà acceptée</p>
            <p className="text-muted-foreground text-sm">
              Vous avez déjà accepté cette invitation. Si vous avez perdu votre lien d'accès, demandez aux mariés de vous renvoyer une invitation.
            </p>
            <button
              onClick={() => acceptMutation.mutate({ invitationToken: params.token! })}
              disabled={acceptMutation.isPending}
              className="w-full py-3 rounded-2xl text-white font-semibold disabled:opacity-50"
              style={{ background: "linear-gradient(135deg, var(--coral-light), var(--coral))" }}
            >
              {acceptMutation.isPending ? "Génération en cours..." : "Générer un nouveau lien d'accès"}
            </button>
          </div>
        ) : (
          /* Not yet accepted */
          <button
            onClick={() => acceptMutation.mutate({ invitationToken: params.token! })}
            disabled={acceptMutation.isPending}
            className="w-full py-4 rounded-2xl text-white font-bold text-lg disabled:opacity-50 flex items-center justify-center gap-2"
            style={{ background: "linear-gradient(135deg, var(--coral-light), var(--coral))" }}
          >
            {acceptMutation.isPending ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Création de votre espace...</>
            ) : (
              <>Accepter l'invitation et accéder à mon espace <ArrowRight className="w-5 h-5" /></>
            )}
          </button>
        )}

        <p className="text-center text-xs text-muted-foreground mt-6">
          Propulsé par <span style={{ color: "var(--coral)" }}>AURA Wedding OS</span>
        </p>
      </div>
    </div>
  );
}
