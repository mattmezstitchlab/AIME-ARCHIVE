import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Heart, Check, X, HelpCircle, Loader2 } from "lucide-react";

export default function RsvpPortal() {
  const params = useParams<{ token: string }>();
  const token = params.token;

  const { data: rsvpData, isLoading, error } = trpc.rsvp.getByToken.useQuery(
    { token: token || "" },
    { enabled: !!token }
  );
  const guest = rsvpData?.guest ?? null;
  const wedding = rsvpData?.wedding ?? null;
  const rsvpMutation = trpc.rsvp.respond.useMutation();

  const [status, setStatus] = useState<"confirmed" | "declined" | "maybe" | null>(null);
  const [message, setMessage] = useState("");
  const [dietary, setDietary] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (guest) {
      setStatus((guest.rsvpStatus as "confirmed" | "declined" | "maybe" | null) || null);
      setDietary(guest.dietaryRestrictions || "");
    }
  }, [guest]);

  const handleSubmit = async () => {
    if (!status || !guest) return;
    await rsvpMutation.mutateAsync({ token: token!, rsvpStatus: status, message, dietaryRestrictions: dietary });
    setSubmitted(true);
  };

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--coral)" }} />
    </div>
  );

  if (error || !guest || !rsvpData) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <div className="text-center neu-card p-10 max-w-md mx-4">
        <X className="w-12 h-12 mx-auto mb-4" style={{ color: "#F07167" }} />
        <h2 className="text-xl font-bold mb-2">Lien invalide</h2>
        <p className="text-muted-foreground">Ce lien RSVP n'est pas valide ou a expiré.</p>
      </div>
    </div>
  );

  if (submitted) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--neu-bg)" }}>
      <div className="text-center neu-card p-10 max-w-md mx-4">
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 neu-btn-coral">
          <Check className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-black mb-3">Merci {guest.firstName} !</h2>
        <p className="text-muted-foreground">
          {status === "confirmed" ? "Votre présence est confirmée. Nous avons hâte de vous voir !" :
           status === "declined" ? "Nous sommes désolés que vous ne puissiez pas venir." :
           "Votre réponse a bien été enregistrée."}
        </p>
        {wedding && (
          <div className="mt-6 p-4 rounded-xl" style={{ background: "rgba(240,113,103,0.08)" }}>
            <p className="font-bold" style={{ color: "var(--coral)" }}>
              {wedding.partner1Name} & {wedding.partner2Name}
            </p>
            {wedding.weddingDate && (
              <p className="text-sm text-muted-foreground mt-1">
                {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--neu-bg)", fontFamily: "Inter, sans-serif" }}>
      <div className="w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 neu-btn-coral">
            <Heart className="w-8 h-8 text-white" />
          </div>
          {wedding && (
            <>
              <h1 className="text-3xl font-black mb-2">{wedding.partner1Name} & {wedding.partner2Name}</h1>
              {wedding.weddingDate && (
                <p className="text-muted-foreground">
                  {new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                </p>
              )}
              {wedding.venue && <p className="text-muted-foreground text-sm mt-1">{wedding.venue}{wedding.city ? `, ${wedding.city}` : ""}</p>}
            </>
          )}
        </div>

        {/* RSVP Card */}
        <div className="neu-card p-8">
          <h2 className="text-xl font-bold mb-2">Bonjour {guest.firstName} {guest.lastName || ""} !</h2>
          <p className="text-muted-foreground mb-6">Merci de confirmer votre présence à notre mariage.</p>

          {/* Status buttons */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            {[
              { value: "confirmed" as const, label: "Je serai là !", icon: Check, color: "#7BC47F" },
              { value: "maybe" as const, label: "Peut-être", icon: HelpCircle, color: "#C4A87B" },
              { value: "declined" as const, label: "Je ne peux pas", icon: X, color: "#F07167" },
            ].map(({ value, label, icon: Icon, color }) => (
              <button
                key={value}
                onClick={() => setStatus(value)}
                className={`p-4 rounded-2xl flex flex-col items-center gap-2 transition-all ${status === value ? "scale-105" : ""}`}
                style={{
                  background: status === value ? `${color}20` : "var(--neu-bg)",
                  boxShadow: status === value
                    ? `inset 3px 3px 8px rgba(0,0,0,0.1), inset -3px -3px 8px rgba(255,255,255,0.8), 0 0 0 2px ${color}`
                    : "5px 5px 15px rgba(0,0,0,0.08), -5px -5px 15px rgba(255,255,255,0.9)"
                }}
              >
                <Icon className="w-6 h-6" style={{ color }} />
                <span className="text-xs font-medium text-center" style={{ color: status === value ? color : undefined }}>{label}</span>
              </button>
            ))}
          </div>

          {/* Dietary */}
          <div className="mb-4">
            <label className="text-sm font-medium mb-2 block">Régime alimentaire / allergies</label>
            <input className="neu-input w-full" placeholder="Végétarien, sans gluten, allergie aux noix..." value={dietary} onChange={e => setDietary(e.target.value)} />
          </div>

          {/* Message */}
          <div className="mb-6">
            <label className="text-sm font-medium mb-2 block">Un message pour les mariés (optionnel)</label>
            <textarea className="neu-input w-full resize-none" rows={3} placeholder="Vos vœux, une anecdote..." value={message} onChange={e => setMessage(e.target.value)} />
          </div>

          <button
            onClick={handleSubmit}
            disabled={!status || rsvpMutation.isPending}
            className="w-full py-4 rounded-2xl text-white font-bold text-lg disabled:opacity-50 transition-all"
            style={{ background: "linear-gradient(135deg, var(--coral-light), var(--coral))" }}
          >
            {rsvpMutation.isPending ? "Envoi en cours..." : "Confirmer ma réponse"}
          </button>
        </div>
      </div>
    </div>
  );
}
