import { useState, useCallback } from "react";
import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
  useDroppable,
  useDraggable,
} from "@dnd-kit/core";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Users,
  Plus,
  Trash2,
  Circle,
  Square,
  RectangleHorizontal,
  ArrowLeft,
  Save,
  Sparkles,
} from "lucide-react";
import { Link } from "wouter";

// ─── Types ────────────────────────────────────────────────────────────────────
interface SeatingTable {
  id: number;
  name: string;
  shape: "round" | "rectangular" | "square";
  capacity: number;
  positionX: number | null;
  positionY: number | null;
  notes?: string | null;
}

interface Guest {
  id: number;
  firstName: string;
  lastName: string | null;
  rsvpStatus?: string | null;
  tableNumber?: number | string | null;
}

interface Assignment {
  id: number;
  guestId: number;
  tableId: number;
  seatNumber?: number | null;
}

// ─── Composant Table ─────────────────────────────────────────────────────────
function TableCard({
  table,
  guests,
  onDelete,
}: {
  table: SeatingTable;
  guests: Guest[];
  onDelete: (id: number) => void;
}) {
  const { setNodeRef, isOver } = useDroppable({ id: `table-${table.id}` });
  const occupancy = guests.length;
  const isFull = occupancy >= table.capacity;

  const shapeIcon =
    table.shape === "round" ? (
      <Circle size={14} />
    ) : table.shape === "square" ? (
      <Square size={14} />
    ) : (
      <RectangleHorizontal size={14} />
    );

  return (
    <div
      ref={setNodeRef}
      className="neu-card p-4 relative transition-all"
      style={{
        minWidth: 200,
        border: isOver ? "2px solid #F07167" : "2px solid transparent",
        background: isOver ? "rgba(240,113,103,0.05)" : undefined,
      }}
    >
      {/* Header table */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-coral">{shapeIcon}</span>
          <span className="font-semibold text-sm" style={{ color: "#4a5568" }}>
            {table.name}
          </span>
        </div>
        <button
          onClick={() => onDelete(table.id)}
          className="text-gray-400 hover:text-red-400 transition-colors"
        >
          <Trash2 size={14} />
        </button>
      </div>

      {/* Jauge capacité */}
      <div className="mb-3">
        <div className="flex justify-between text-xs text-gray-500 mb-1">
          <span>{occupancy} / {table.capacity} places</span>
          <span className={isFull ? "text-red-400" : "text-green-500"}>
            {isFull ? "Complet" : `${table.capacity - occupancy} libre${table.capacity - occupancy > 1 ? "s" : ""}`}
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-gray-200 overflow-hidden">
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${Math.min(100, (occupancy / table.capacity) * 100)}%`,
              background: isFull ? "#ef4444" : "#F07167",
            }}
          />
        </div>
      </div>

      {/* Liste des invités assignés */}
      <div className="space-y-1 min-h-[40px]">
        {guests.length === 0 ? (
          <p className="text-xs text-gray-400 italic text-center py-2">
            Glissez des invités ici
          </p>
        ) : (
          guests.map((g) => (
            <GuestChip key={g.id} guest={g} inTable />
          ))
        )}
      </div>
    </div>
  );
}

// ─── Composant Chip Invité ────────────────────────────────────────────────────
function GuestChip({ guest, inTable }: { guest: Guest; inTable?: boolean }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `guest-${guest.id}`,
    data: { guest },
  });

      const initials = `${guest.firstName[0] ?? '?'}${(guest.lastName ?? '?')[0]}`.toUpperCase();
  const statusColor =
    guest.rsvpStatus === "confirmed"
      ? "#22c55e"
      : guest.rsvpStatus === "declined"
      ? "#ef4444"
      : "#f59e0b";

  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className="flex items-center gap-2 px-2 py-1 rounded-lg cursor-grab active:cursor-grabbing select-none transition-all"
      style={{
        background: isDragging ? "rgba(240,113,103,0.15)" : "rgba(232,237,242,0.8)",
        opacity: isDragging ? 0.5 : 1,
        boxShadow: isDragging ? "0 4px 12px rgba(240,113,103,0.3)" : undefined,
        border: "1px solid rgba(0,0,0,0.06)",
      }}
    >
      <div
        className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
        style={{ background: statusColor }}
      >
        {initials}
      </div>
      <span className="text-xs font-medium truncate" style={{ color: "#4a5568" }}>
                {guest.firstName} {guest.lastName ?? ''}
              </span>
    </div>
  );
}

// ─── Page Principale ──────────────────────────────────────────────────────────
export default function SeatingPlan() {
  const [newTableName, setNewTableName] = useState("");
  const [newTableShape, setNewTableShape] = useState<"round" | "rectangular" | "square">("round");
  const [newTableCapacity, setNewTableCapacity] = useState(8);
  const [showAddTable, setShowAddTable] = useState(false);
  const [activeGuest, setActiveGuest] = useState<Guest | null>(null);

  const utils = trpc.useUtils();

  // Queries
  const { data, isLoading } = trpc.seating.getFullPlan.useQuery();

  // Mutations
  const addTable = trpc.seating.addTable.useMutation({
    onSuccess: () => {
      utils.seating.getFullPlan.invalidate();
      setNewTableName("");
      setShowAddTable(false);
      toast.success("Table créée !");
    },
  });

  const deleteTable = trpc.seating.deleteTable.useMutation({
    onSuccess: () => {
      utils.seating.getFullPlan.invalidate();
      toast.success("Table supprimée");
    },
  });

  const assignGuest = trpc.seating.assignGuest.useMutation({
    onSuccess: () => utils.seating.getFullPlan.invalidate(),
  });

  const removeGuest = trpc.seating.unassignGuest.useMutation({
    onSuccess: () => utils.seating.getFullPlan.invalidate(),
  });

  const autoArrange = trpc.seating.autoAssign.useMutation({
    onSuccess: () => {
      utils.seating.getFullPlan.invalidate();
      toast.success("Placement automatique effectué !");
    },
  });

  // DnD sensors
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } })
  );

  // Calculs
  const tables: SeatingTable[] = data?.tables ?? [];
  const allGuests: Guest[] = data?.guests ?? [];
  const assignments: Assignment[] = data?.assignments ?? [];

  const getGuestsForTable = useCallback(
    (tableId: number) => {
      const assignedIds = assignments
        .filter((a) => a.tableId === tableId)
        .map((a) => a.guestId);
      return allGuests.filter((g) => assignedIds.includes(g.id));
    },
    [assignments, allGuests]
  );

  const unassignedGuests = allGuests.filter(
    (g) => !assignments.some((a) => a.guestId === g.id)
  );

  const confirmedGuests = allGuests.filter((g) => g.rsvpStatus === "confirmed");

  // Drag handlers
  const handleDragStart = (event: DragStartEvent) => {
    const guestId = parseInt(String(event.active.id).replace("guest-", ""));
    const guest = allGuests.find((g) => g.id === guestId);
    if (guest) setActiveGuest(guest);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveGuest(null);
    const { active, over } = event;
    if (!over) return;

    const guestId = parseInt(String(active.id).replace("guest-", ""));
    const overId = String(over.id);

    if (overId === "unassigned") {
      // Retirer l'invité de sa table
      const assignment = assignments.find((a) => a.guestId === guestId);
      if (assignment) {
        removeGuest.mutate({ guestId });
      }
      return;
    }

    if (overId.startsWith("table-")) {
      const tableId = parseInt(overId.replace("table-", ""));
      const table = tables.find((t) => t.id === tableId);
      if (!table) return;

      const currentGuests = getGuestsForTable(tableId);
      if (currentGuests.length >= table.capacity) {
        toast.error("Cette table est complète !");
        return;
      }

      assignGuest.mutate({ guestId, tableId });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#E8EDF2" }}>
        <div className="neu-card p-8 text-center">
          <div className="w-12 h-12 rounded-full border-4 border-coral border-t-transparent animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Chargement du plan de table…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#E8EDF2" }}>
      {/* Header */}
      <div className="sticky top-0 z-20 px-6 py-4" style={{ background: "#E8EDF2" }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/cockpit">
              <button className="neu-btn p-2">
                <ArrowLeft size={18} style={{ color: "#F07167" }} />
              </button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold" style={{ fontFamily: "Playfair Display, serif", color: "#4a5568" }}>
                Plan de Table
              </h1>
              <p className="text-sm text-gray-500">
                {confirmedGuests.length} invités confirmés · {tables.length} table{tables.length > 1 ? "s" : ""} · {assignments.length} placé{assignments.length > 1 ? "s" : ""}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => autoArrange.mutate()}
              disabled={autoArrange.isPending || tables.length === 0}
              className="neu-btn px-4 py-2 flex items-center gap-2 text-sm"
              style={{ color: "#F07167" }}
            >
              <Sparkles size={16} />
              Placement auto IA
            </button>
            <button
              onClick={() => setShowAddTable(true)}
              className="neu-btn px-4 py-2 flex items-center gap-2 text-sm font-semibold"
              style={{ background: "#F07167", color: "white" }}
            >
              <Plus size={16} />
              Ajouter une table
            </button>
          </div>
        </div>
      </div>

      {/* Modal ajout table */}
      {showAddTable && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
          <div className="neu-card p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-bold mb-4" style={{ fontFamily: "Playfair Display, serif", color: "#4a5568" }}>
              Nouvelle table
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-600 mb-1 block">Nom de la table</label>
                <input
                  value={newTableName}
                  onChange={(e) => setNewTableName(e.target.value)}
                  placeholder="Table des mariés, Table 1…"
                  className="w-full px-3 py-2 rounded-xl text-sm"
                  style={{ background: "#E8EDF2", border: "none", boxShadow: "inset 3px 3px 6px #c8cdd2, inset -3px -3px 6px #ffffff", color: "#4a5568" }}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600 mb-1 block">Forme</label>
                <div className="flex gap-2">
                  {(["round", "rectangular", "square"] as const).map((shape) => (
                    <button
                      key={shape}
                      onClick={() => setNewTableShape(shape)}
                      className="flex-1 py-2 rounded-xl text-xs font-medium transition-all"
                      style={{
                        background: newTableShape === shape ? "#F07167" : "#E8EDF2",
                        color: newTableShape === shape ? "white" : "#4a5568",
                        boxShadow: newTableShape === shape ? "0 4px 12px rgba(240,113,103,0.3)" : "3px 3px 6px #c8cdd2, -3px -3px 6px #ffffff",
                      }}
                    >
                      {shape === "round" ? "Ronde" : shape === "rectangular" ? "Rectangulaire" : "Carrée"}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600 mb-1 block">Capacité ({newTableCapacity} places)</label>
                <input
                  type="range"
                  min={2}
                  max={20}
                  value={newTableCapacity}
                  onChange={(e) => setNewTableCapacity(parseInt(e.target.value))}
                  className="w-full accent-coral"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowAddTable(false)}
                  className="flex-1 neu-btn py-2 text-sm text-gray-500"
                >
                  Annuler
                </button>
                <button
                  onClick={() => {
                    if (!newTableName.trim()) { toast.error("Donnez un nom à la table"); return; }
                    addTable.mutate({ name: newTableName, shape: newTableShape, capacity: newTableCapacity });
                  }}
                  disabled={addTable.isPending}
                  className="flex-1 py-2 rounded-xl text-sm font-semibold text-white transition-all"
                  style={{ background: "#F07167", boxShadow: "0 4px 12px rgba(240,113,103,0.3)" }}
                >
                  {addTable.isPending ? "Création…" : "Créer"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Zone principale DnD */}
      <DndContext sensors={sensors} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
        <div className="max-w-7xl mx-auto px-6 pb-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Colonne invités non placés */}
            <div className="lg:col-span-1">
              <UnassignedZone guests={unassignedGuests} />
            </div>

            {/* Zone tables */}
            <div className="lg:col-span-3">
              {tables.length === 0 ? (
                <div className="neu-card p-12 text-center">
                  <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ background: "rgba(240,113,103,0.1)" }}>
                    <Users size={28} style={{ color: "#F07167" }} />
                  </div>
                  <h3 className="text-lg font-semibold mb-2" style={{ color: "#4a5568" }}>
                    Aucune table créée
                  </h3>
                  <p className="text-gray-500 text-sm mb-4">
                    Commencez par créer vos tables pour organiser le placement de vos invités.
                  </p>
                  <button
                    onClick={() => setShowAddTable(true)}
                    className="px-6 py-2 rounded-xl text-sm font-semibold text-white"
                    style={{ background: "#F07167" }}
                  >
                    Créer ma première table
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {tables.map((table) => (
                    <TableCard
                      key={table.id}
                      table={table}
                      guests={getGuestsForTable(table.id)}
                      onDelete={(id) => deleteTable.mutate({ tableId: id })}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Overlay drag */}
        <DragOverlay>
          {activeGuest && (
            <div
              className="flex items-center gap-2 px-3 py-2 rounded-xl shadow-xl"
              style={{ background: "#F07167", color: "white" }}
            >
              <div className="w-6 h-6 rounded-full bg-white/30 flex items-center justify-center text-xs font-bold">
                {activeGuest.firstName[0]}{(activeGuest.lastName ?? '?')[0]}
              </div>
              <span className="text-sm font-medium">
                {activeGuest.firstName} {activeGuest.lastName}
              </span>
            </div>
          )}
        </DragOverlay>
      </DndContext>
    </div>
  );
}

// ─── Zone invités non placés ──────────────────────────────────────────────────
function UnassignedZone({ guests }: { guests: Guest[] }) {
  const { setNodeRef, isOver } = useDroppable({ id: "unassigned" });

  return (
    <div
      ref={setNodeRef}
      className="neu-card p-4 sticky top-24"
      style={{
        border: isOver ? "2px solid #F07167" : "2px solid transparent",
        background: isOver ? "rgba(240,113,103,0.05)" : undefined,
        maxHeight: "calc(100vh - 120px)",
        overflowY: "auto",
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Users size={16} style={{ color: "#F07167" }} />
        <h3 className="font-semibold text-sm" style={{ color: "#4a5568" }}>
          Non placés
        </h3>
        <span className="ml-auto text-xs px-2 py-0.5 rounded-full font-medium"
          style={{ background: "rgba(240,113,103,0.15)", color: "#F07167" }}>
          {guests.length}
        </span>
      </div>

      {guests.length === 0 ? (
        <p className="text-xs text-gray-400 italic text-center py-4">
          Tous les invités sont placés 🎉
        </p>
      ) : (
        <div className="space-y-1.5">
          {guests.map((g) => (
            <GuestChip key={g.id} guest={g} />
          ))}
        </div>
      )}
    </div>
  );
}
