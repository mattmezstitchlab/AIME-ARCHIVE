import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ProviderDashboard from "./pages/ProviderDashboard";
import CockpitRouter from './pages/CockpitRouter';
import RsvpPortal from "./pages/RsvpPortal";
import MiniSitePublic from "./pages/MiniSitePublic";
import ProviderPortal from "./pages/ProviderPortal";
import PhotoWallPublic from "./pages/PhotoWallPublic";
import SeatingPlan from "./pages/SeatingPlan";
import Pricing from "./pages/Pricing";
import GuestPortal from "./pages/GuestPortal";
import CGU from "./pages/legal/CGU";
import CGV from "./pages/legal/CGV";
import MentionsLegales from "./pages/legal/MentionsLegales";
import Confidentialite from "./pages/legal/Confidentialite";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/cockpit" component={CockpitRouter} />
      <Route path="/rsvp/:token" component={RsvpPortal} />
      <Route path="/mariage/:slug" component={MiniSitePublic} />
      <Route path="/prestataire/:token" component={ProviderPortal} />
      <Route path="/photowall/:slug" component={PhotoWallPublic} />
      <Route path="/provider/dashboard" component={ProviderDashboard} />
      <Route path="/plan-de-table" component={SeatingPlan} />
      <Route path="/tarifs" component={Pricing} />
      <Route path="/portail-invite" component={GuestPortal} />
      <Route path="/cgu" component={CGU} />
      <Route path="/cgv" component={CGV} />
      <Route path="/mentions-legales" component={MentionsLegales} />
      <Route path="/confidentialite" component={Confidentialite} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
