/**
 * AURA Wedding OS — Hook usePushNotifications
 *
 * Gère l'enregistrement du Service Worker, la demande de permission,
 * l'abonnement/désabonnement aux notifications push navigateur.
 */

import { useState, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

// Clé publique VAPID exposée au frontend
const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY as string;

// Convertir la clé VAPID base64url en Uint8Array
function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length) as Uint8Array<ArrayBuffer>;
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export type PushPermission = "default" | "granted" | "denied" | "unsupported";

export interface UsePushNotificationsReturn {
  permission: PushPermission;
  isSubscribed: boolean;
  isLoading: boolean;
  isSupported: boolean;
  subscribe: () => Promise<void>;
  unsubscribe: () => Promise<void>;
  sendTest: () => Promise<void>;
}

export function usePushNotifications(): UsePushNotificationsReturn {
  const [permission, setPermission] = useState<PushPermission>("default");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentEndpoint, setCurrentEndpoint] = useState<string | null>(null);

  const isSupported =
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    !!VAPID_PUBLIC_KEY;

  // Requêtes tRPC
  const statusQuery = trpc.push.status.useQuery(undefined, {
    enabled: isSupported,
    refetchOnWindowFocus: false,
  });

  const subscribeMutation = trpc.push.subscribe.useMutation({
    onSuccess: () => {
      setIsSubscribed(true);
      statusQuery.refetch();
    },
    onError: (err) => {
      toast.error(`Erreur d'abonnement : ${err.message}`);
    },
  });

  const unsubscribeMutation = trpc.push.unsubscribe.useMutation({
    onSuccess: () => {
      setIsSubscribed(false);
      setCurrentEndpoint(null);
      statusQuery.refetch();
    },
    onError: (err) => {
      toast.error(`Erreur de désabonnement : ${err.message}`);
    },
  });

  const sendTestMutation = trpc.push.sendTest.useMutation({
    onSuccess: (data) => {
      if (data.sent > 0) {
        toast.success("Notification de test envoyée !");
      } else {
        toast.warning("Aucun abonnement actif trouvé. Abonnez-vous d'abord.");
      }
    },
    onError: () => {
      toast.error("Erreur lors de l'envoi de la notification de test.");
    },
  });

  // Initialiser la permission et l'état d'abonnement
  useEffect(() => {
    if (!isSupported) {
      setPermission("unsupported");
      return;
    }

    setPermission(Notification.permission as PushPermission);

    // Enregistrer le Service Worker
    navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then(async (registration) => {
        const sub = await registration.pushManager.getSubscription();
        if (sub) {
          setCurrentEndpoint(sub.endpoint);
          setIsSubscribed(true);
        }
      })
      .catch((err) => {
        console.warn("[Push] Service Worker registration failed:", err);
      });
  }, [isSupported]);

  // Synchroniser avec le statut serveur
  useEffect(() => {
    if (statusQuery.data) {
      setIsSubscribed(statusQuery.data.subscribed);
    }
  }, [statusQuery.data]);

  // S'abonner aux notifications push
  const subscribe = useCallback(async () => {
    if (!isSupported) {
      toast.error("Votre navigateur ne supporte pas les notifications push.");
      return;
    }

    setIsLoading(true);
    try {
      // Demander la permission
      const perm = await Notification.requestPermission();
      setPermission(perm as PushPermission);

      if (perm !== "granted") {
        toast.warning(
          perm === "denied"
            ? "Notifications bloquées. Autorisez-les dans les paramètres de votre navigateur."
            : "Permission refusée."
        );
        return;
      }

      // Enregistrer le Service Worker
      const registration = await navigator.serviceWorker.ready;

      // Créer l'abonnement push
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });

      const subJson = subscription.toJSON();
      if (!subJson.endpoint || !subJson.keys?.p256dh || !subJson.keys?.auth) {
        throw new Error("Abonnement push invalide");
      }

      setCurrentEndpoint(subJson.endpoint);

      // Enregistrer en base via tRPC
      await subscribeMutation.mutateAsync({
        endpoint: subJson.endpoint,
        p256dh: subJson.keys.p256dh,
        auth: subJson.keys.auth,
        userAgent: navigator.userAgent.substring(0, 512),
      });

      toast.success("Notifications push activées ! Vous recevrez vos rappels J-30, J-7 et J-1.");
    } catch (err: any) {
      console.error("[Push] Subscribe error:", err);
      toast.error(`Impossible d'activer les notifications : ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  }, [isSupported, subscribeMutation]);

  // Se désabonner
  const unsubscribe = useCallback(async () => {
    if (!isSupported) return;

    setIsLoading(true);
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();

      if (subscription) {
        await subscription.unsubscribe();
        await unsubscribeMutation.mutateAsync({ endpoint: subscription.endpoint });
      }

      toast.success("Notifications push désactivées.");
    } catch (err: any) {
      console.error("[Push] Unsubscribe error:", err);
      toast.error(`Erreur lors de la désactivation : ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  }, [isSupported, unsubscribeMutation]);

  // Envoyer une notification de test
  const sendTest = useCallback(async () => {
    await sendTestMutation.mutateAsync();
  }, [sendTestMutation]);

  return {
    permission,
    isSubscribed,
    isLoading: isLoading || subscribeMutation.isPending || unsubscribeMutation.isPending,
    isSupported,
    subscribe,
    unsubscribe,
    sendTest,
  };
}
