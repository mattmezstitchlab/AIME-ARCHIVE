import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Bell, CheckCheck, X, Users, FileText, CreditCard, MessageSquare, Zap, ArrowRight } from "lucide-react";
import { toast } from "sonner";
// ─── Type configuration ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
const TYPE_CONFIG = {
  invitation_accepted: { icon: Users,          label: "Invitation", color: "#7BC47F", actionLabel: "Voir les prestataires", actionPanel: "providers" },
  mission_update:      { icon: Zap,            label: "Mission",    color: "#60B4C8", actionLabel: "Voir les prestataires", actionPanel: "providers" },
  contract_signed:     { icon: FileText,       label: "Contrat",    color: "#F07167", actionLabel: "Voir les contrats",    actionPanel: "contracts" },
  payment_received:    { icon: CreditCard,     label: "Paiement",   color: "#9B8FD4", actionLabel: "Voir les prestataires", actionPanel: "providers" },
  message:             { icon: MessageSquare,  label: "Message",    color: "#C4A87B", actionLabel: "Ouvrir le chat",       actionPanel: "chat" },
} as const;

type NotifType = keyof typeof TYPE_CONFIG;
type FilterTab = "all" | "unread" | NotifType;

const FILTER_TABS: { id: FilterTab; label: string }[] = [
  { id: "all",                 label: "Tout" },
  { id: "unread",              label: "Non lus" },
  { id: "invitation_accepted", label: "Invitations" },
  { id: "contract_signed",     label: "Contrats" },
  { id: "payment_received",    label: "Paiements" },
  { id: "mission_update",      label: "Missions" },
];

interface NotificationsPanelProps {
  onClose: () => void;
}

export default function NotificationsPanel({ onClose, onNavigate }: NotificationsPanelProps & { onNavigate?: (panel: string) => void }) {
  const [activeFilter, setActiveFilter] = useState<FilterTab>("all");
  const [, setLocation] = useLocation();

  const { data: notifications, refetch } = trpc.providerNotifications.list.useQuery(undefined, {
    refetchInterval: 15000,
  });

  const markReadMutation = trpc.providerNotifications.markRead.useMutation({
    onSuccess: () => refetch(),
  });
  const markAllReadMutation = trpc.providerNotifications.markAllRead.useMutation({
    onSuccess: () => {
      refetch();
      toast.success("Toutes les notifications marquées comme lues");
    },
  });

  const all = notifications || [];
  const unreadCount = all.filter(n => !n.isRead).length;

  const filtered = all.filter(n => {
    if (activeFilter === "all")    return true;
    if (activeFilter === "unread") return !n.isRead;
    return n.type === activeFilter;
  });

  const badgeFor = (tab: FilterTab): number => {
    if (tab === "all")    return 0;
    if (tab === "unread") return unreadCount;
    return all.filter(n => n.type === tab && !n.isRead).length;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-end"
      onClick={onClose}
    >
      <div
        className="mt-4 mr-4 w-[420px] max-h-[85vh] overflow-hidden rounded-2xl flex flex-col shadow-2xl"
        onClick={e => e.stopPropagation()}
        style={{ background: "var(--neu-bg)", border: "1px solid color-mix(in srgb, var(--border) 60%, transparent)" }}
      >
        {/* ── Header ─────────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b border-border/30">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5" style={{ color: "var(--coral)" }} />
            <h3 className="font-bold text-sm">Notifications prestataires</h3>
            {unreadCount > 0 && (
              <span
                className="px-2 py-0.5 rounded-full text-xs font-bold text-white"
                style={{ background: "var(--coral)" }}
              >
                {unreadCount}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            {unreadCount > 0 && (
              <button
                onClick={() => markAllReadMutation.mutate()}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors"
                title="Tout marquer comme lu"
              >
                <CheckCheck className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* ── Filter tabs ─────────────────────────────────────────────────── */}
        <div className="px-3 pt-2.5 pb-0">
          <div className="flex gap-1 overflow-x-auto pb-2 scrollbar-none">
            {FILTER_TABS.map(tab => {
              const isActive = activeFilter === tab.id;
              const badge = badgeFor(tab.id);
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap flex-shrink-0 ${
                    isActive
                      ? "text-white"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  }`}
                  style={isActive ? { background: "var(--coral)" } : {}}
                >
                  {tab.label}
                  {badge > 0 && !isActive && (
                    <span
                      className="w-4 h-4 rounded-full text-[9px] font-bold text-white flex items-center justify-center"
                      style={{ background: "var(--coral)" }}
                    >
                      {badge > 9 ? "9+" : badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          <div className="h-px bg-border/30" />
        </div>

        {/* ── Notification list ───────────────────────────────────────────── */}
        <div className="overflow-y-auto flex-1">
          {filtered.length === 0 ? (
            <div className="p-8 text-center">
              <Bell className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-30" />
              <p className="text-sm text-muted-foreground">
                {activeFilter === "unread"
                  ? "Aucune notification non lue"
                  : activeFilter === "all"
                  ? "Aucune notification"
                  : `Aucune notification « ${FILTER_TABS.find(t => t.id === activeFilter)?.label} »`}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Les activités de vos prestataires apparaîtront ici
              </p>
            </div>
          ) : (
            <div className="divide-y divide-border/20">
              {filtered.map(notif => {
                const config = TYPE_CONFIG[notif.type as NotifType] ?? TYPE_CONFIG.message;
                const Icon = config.icon;
                return (
                  <div
                    key={notif.id}
                    className={`p-4 flex gap-3 hover:bg-muted/30 transition-colors ${
                      !notif.isRead ? "bg-muted/10" : ""
                    }`}
                    onClick={() => !notif.isRead && markReadMutation.mutate({ id: notif.id })}
                  >
                    {/* Icon bubble */}
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: `${config.color}20` }}
                    >
                      <Icon className="w-4 h-4" style={{ color: config.color }} />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p
                          className={`text-sm font-medium leading-snug ${
                            !notif.isRead ? "text-foreground" : "text-muted-foreground"
                          }`}
                        >
                          {notif.title}
                        </p>
                        {!notif.isRead && (
                          <div
                            className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5"
                            style={{ background: "var(--coral)" }}
                          />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                        {notif.message}
                      </p>
                      <div className="flex items-center justify-between gap-2 mt-1.5">
                        <div className="flex items-center gap-2">
                          <span
                            className="text-[10px] px-1.5 py-0.5 rounded-md font-medium"
                            style={{ background: `${config.color}18`, color: config.color }}
                          >
                            {config.label}
                          </span>
                          <span className="text-[10px] text-muted-foreground">
                            {new Date(notif.createdAt).toLocaleString("fr-FR", {
                              day: "2-digit",
                              month: "short",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </div>
                        {(config as any).actionLabel && (
                          <button
                            className="flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-lg transition-colors hover:opacity-80"
                            style={{ background: `${config.color}18`, color: config.color }}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!notif.isRead) markReadMutation.mutate({ id: notif.id });
                              if (onNavigate) onNavigate((config as any).actionPanel);
                              onClose();
                            }}
                          >
                            {(config as any).actionLabel}
                            <ArrowRight className="w-2.5 h-2.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Footer ─────────────────────────────────────────────────────── */}
        {all.length > 0 && (
          <div className="px-4 py-2 border-t border-border/30 text-center">
            <p className="text-[10px] text-muted-foreground">
              {all.length} notification{all.length > 1 ? "s" : ""} au total
              {unreadCount > 0 ? ` · ${unreadCount} non lue${unreadCount > 1 ? "s" : ""}` : " · tout lu"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
