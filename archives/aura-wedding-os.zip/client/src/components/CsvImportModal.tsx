import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Upload, X, FileText, AlertTriangle, CheckCircle, Download,
  Users, ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";

// ─── Types ────────────────────────────────────────────────────────────────────
interface ParsedGuest {
  firstName: string;
  lastName?: string;
  email?: string;
  phone?: string;
  group?: string;
  side?: "partner1" | "partner2" | "both";
  plusOne?: boolean;
  dietaryRestrictions?: string;
  tableNumber?: number;
  _rowIndex: number;
  _errors: string[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

function parseCsv(text: string): ParsedGuest[] {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return [];

  const headers = parseCsvLine(lines[0]).map(h => h.toLowerCase().replace(/[^a-z0-9]/g, ""));

  const HEADER_MAP: Record<string, keyof ParsedGuest> = {
    prenom: "firstName", firstname: "firstName", nom: "lastName", lastname: "lastName",
    email: "email", telephone: "phone", phone: "phone", tel: "phone",
    groupe: "group", group: "group", table: "tableNumber", tablenumber: "tableNumber",
    cote: "side", side: "side", plusone: "plusOne", accompagnant: "plusOne",
    regimealimentaire: "dietaryRestrictions", dietary: "dietaryRestrictions",
    restrictions: "dietaryRestrictions",
  };

  const colMap: Record<number, keyof ParsedGuest> = {};
  headers.forEach((h, i) => {
    if (HEADER_MAP[h]) colMap[i] = HEADER_MAP[h];
  });

  return lines.slice(1).map((line, idx) => {
    const cells = parseCsvLine(line);
    const guest: ParsedGuest = {
      firstName: "",
      _rowIndex: idx + 2,
      _errors: [],
    };

    Object.entries(colMap).forEach(([colIdx, field]) => {
      const val = cells[parseInt(colIdx)] ?? "";
      if (!val) return;
      if (field === "firstName" || field === "lastName" || field === "email" ||
          field === "phone" || field === "group" || field === "dietaryRestrictions") {
        (guest as any)[field] = val;
      } else if (field === "tableNumber") {
        const n = parseInt(val);
        if (!isNaN(n)) guest.tableNumber = n;
      } else if (field === "side") {
        const v = val.toLowerCase();
        if (v === "partner1" || v === "marie1" || v === "1") guest.side = "partner1";
        else if (v === "partner2" || v === "marie2" || v === "2") guest.side = "partner2";
        else guest.side = "both";
      } else if (field === "plusOne") {
        guest.plusOne = ["oui", "yes", "true", "1"].includes(val.toLowerCase());
      }
    });

    if (!guest.firstName) guest._errors.push("Prénom manquant");
    if (guest.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guest.email)) {
      guest._errors.push("Email invalide");
    }

    return guest;
  }).filter(g => g.firstName || g._errors.length > 0);
}

// ─── Composant principal ──────────────────────────────────────────────────────
interface CsvImportModalProps {
  onClose: () => void;
  onImported: () => void;
}

export default function CsvImportModal({ onClose, onImported }: CsvImportModalProps) {
  const [step, setStep] = useState<"upload" | "preview" | "importing" | "done">("upload");
  const [parsedGuests, setParsedGuests] = useState<ParsedGuest[]>([]);
  const [importResult, setImportResult] = useState<{ imported: number; errors: string[] } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const importMutation = trpc.guests.importCsv.useMutation({
    onSuccess: (data) => {
      setImportResult(data);
      setStep("done");
      if (data.imported > 0) {
        toast.success(`${data.imported} invité(s) importé(s) avec succès !`);
        onImported();
      }
    },
    onError: (err) => {
      toast.error("Erreur lors de l'import : " + err.message);
      setStep("preview");
    },
  });

  const handleFile = (file: File) => {
    if (!file.name.endsWith(".csv") && file.type !== "text/csv") {
      toast.error("Veuillez sélectionner un fichier CSV.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const guests = parseCsv(text);
      if (guests.length === 0) {
        toast.error("Aucun invité trouvé dans le fichier. Vérifiez le format.");
        return;
      }
      setParsedGuests(guests);
      setStep("preview");
    };
    reader.readAsText(file, "UTF-8");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleImport = () => {
    const validGuests = parsedGuests.filter(g => g._errors.length === 0);
    if (validGuests.length === 0) {
      toast.error("Aucun invité valide à importer.");
      return;
    }
    setStep("importing");
    importMutation.mutate({
      guests: validGuests.map(({ _rowIndex, _errors, ...g }) => ({
        ...g,
        side: g.side ?? "both",
        plusOne: g.plusOne ?? false,
      })),
    });
  };

  const downloadTemplate = () => {
    const csv = "Prénom,Nom,Email,Téléphone,Groupe,Côté (partner1/partner2/both),Accompagnant (oui/non),Régime alimentaire,Table\nSophie,Martin,sophie@exemple.fr,0612345678,Famille,partner1,non,,1\nThomas,Dupont,thomas@exemple.fr,,Amis,partner2,oui,Végétarien,2\n";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "modele_invites_aura.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const validCount = parsedGuests.filter(g => g._errors.length === 0).length;
  const errorCount = parsedGuests.filter(g => g._errors.length > 0).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.4)" }}>
      <div className="neu-card w-full max-w-2xl max-h-[90vh] flex flex-col" style={{ background: "#E8EDF2" }}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(240,113,103,0.1)" }}>
              <Upload className="w-5 h-5" style={{ color: "#F07167" }} />
            </div>
            <div>
              <h2 className="font-bold text-gray-800">Importer des invités (CSV)</h2>
              <p className="text-xs text-gray-500">
                {step === "upload" && "Glissez-déposez votre fichier CSV"}
                {step === "preview" && `${parsedGuests.length} ligne(s) détectée(s)`}
                {step === "importing" && "Import en cours..."}
                {step === "done" && "Import terminé"}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center neu-btn">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 pb-6">
          {/* Step: Upload */}
          {step === "upload" && (
            <div className="space-y-4">
              {/* Drop zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all"
                style={{
                  borderColor: isDragging ? "#F07167" : "#c8cdd2",
                  background: isDragging ? "rgba(240,113,103,0.05)" : "transparent",
                }}
              >
                <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="font-medium text-gray-600 mb-1">Glissez votre fichier CSV ici</p>
                <p className="text-sm text-gray-400">ou cliquez pour sélectionner</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,text/csv"
                  className="hidden"
                  onChange={(e) => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }}
                />
              </div>

              {/* Format attendu */}
              <div className="neu-card p-4">
                <p className="text-xs font-semibold text-gray-700 mb-2">Format attendu (colonnes CSV) :</p>
                <div className="flex flex-wrap gap-1.5">
                  {["Prénom*", "Nom", "Email", "Téléphone", "Groupe", "Côté", "Accompagnant", "Régime alimentaire", "Table"].map(col => (
                    <span key={col} className="text-xs px-2 py-0.5 rounded-full" style={{ background: col.includes("*") ? "rgba(240,113,103,0.15)" : "#dde2e8", color: col.includes("*") ? "#F07167" : "#6b7280" }}>
                      {col}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-gray-400 mt-2">* Champ obligatoire · Encodage UTF-8 recommandé</p>
              </div>

              {/* Télécharger le modèle */}
              <button
                onClick={downloadTemplate}
                className="w-full neu-btn py-3 text-sm font-medium flex items-center justify-center gap-2"
                style={{ color: "#F07167" }}
              >
                <Download className="w-4 h-4" />
                Télécharger le modèle CSV
              </button>
            </div>
          )}

          {/* Step: Preview */}
          {step === "preview" && (
            <div className="space-y-4">
              {/* Résumé */}
              <div className="grid grid-cols-2 gap-3">
                <div className="neu-card p-3 text-center">
                  <p className="text-2xl font-bold" style={{ color: "#7BC47F" }}>{validCount}</p>
                  <p className="text-xs text-gray-500">Invités valides</p>
                </div>
                <div className="neu-card p-3 text-center">
                  <p className="text-2xl font-bold" style={{ color: errorCount > 0 ? "#F07167" : "#aab5c8" }}>{errorCount}</p>
                  <p className="text-xs text-gray-500">Lignes avec erreurs</p>
                </div>
              </div>

              {/* Tableau de prévisualisation */}
              <div className="overflow-x-auto rounded-xl" style={{ maxHeight: "300px" }}>
                <table className="w-full text-xs">
                  <thead>
                    <tr className="sticky top-0" style={{ background: "#E8EDF2" }}>
                      <th className="text-left p-2 text-gray-500 font-medium">Ligne</th>
                      <th className="text-left p-2 text-gray-500 font-medium">Prénom</th>
                      <th className="text-left p-2 text-gray-500 font-medium">Nom</th>
                      <th className="text-left p-2 text-gray-500 font-medium">Email</th>
                      <th className="text-left p-2 text-gray-500 font-medium">Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parsedGuests.map((g) => (
                      <tr key={g._rowIndex} className="border-t" style={{ borderColor: "rgba(0,0,0,0.05)" }}>
                        <td className="p-2 text-gray-400">{g._rowIndex}</td>
                        <td className="p-2 font-medium text-gray-700">{g.firstName || "—"}</td>
                        <td className="p-2 text-gray-600">{g.lastName || "—"}</td>
                        <td className="p-2 text-gray-500">{g.email || "—"}</td>
                        <td className="p-2">
                          {g._errors.length > 0 ? (
                            <span className="flex items-center gap-1 text-red-500">
                              <AlertTriangle className="w-3 h-3" />
                              {g._errors.join(", ")}
                            </span>
                          ) : (
                            <span className="flex items-center gap-1" style={{ color: "#7BC47F" }}>
                              <CheckCircle className="w-3 h-3" />
                              OK
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {errorCount > 0 && (
                <div className="neu-card p-3 flex items-start gap-2" style={{ borderLeft: "3px solid #f59e0b" }}>
                  <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "#f59e0b" }} />
                  <p className="text-xs text-gray-600">
                    Les lignes avec erreurs seront ignorées. Seuls les {validCount} invités valides seront importés.
                  </p>
                </div>
              )}

              <div className="flex gap-3">
                <button onClick={() => setStep("upload")} className="flex-1 neu-btn py-3 text-sm font-medium text-gray-600">
                  ← Changer de fichier
                </button>
                <Button
                  onClick={handleImport}
                  disabled={validCount === 0}
                  className="flex-1 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2"
                  style={{ background: "#F07167" }}
                >
                  <Users className="w-4 h-4" />
                  Importer {validCount} invité(s)
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Step: Importing */}
          {step === "importing" && (
            <div className="py-12 text-center">
              <div className="w-12 h-12 border-4 border-t-transparent rounded-full animate-spin mx-auto mb-4" style={{ borderColor: "#F07167", borderTopColor: "transparent" }} />
              <p className="font-medium text-gray-700">Import en cours...</p>
              <p className="text-sm text-gray-400 mt-1">Création des {validCount} invités</p>
            </div>
          )}

          {/* Step: Done */}
          {step === "done" && importResult && (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto" style={{ background: "rgba(123,196,127,0.15)" }}>
                <CheckCircle className="w-8 h-8" style={{ color: "#7BC47F" }} />
              </div>
              <div>
                <p className="text-xl font-bold text-gray-800">{importResult.imported} invité(s) importé(s)</p>
                {importResult.errors.length > 0 && (
                  <p className="text-sm text-gray-500 mt-1">{importResult.errors.length} ligne(s) ignorée(s)</p>
                )}
              </div>
              {importResult.errors.length > 0 && (
                <div className="text-left neu-card p-3 max-h-32 overflow-y-auto">
                  {importResult.errors.map((err, i) => (
                    <p key={i} className="text-xs text-red-500">{err}</p>
                  ))}
                </div>
              )}
              <Button onClick={onClose} className="w-full text-white font-semibold py-3 rounded-xl" style={{ background: "#F07167" }}>
                Fermer
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
