/**
 * AURA Wedding OS — PushNotificationsCard
 *
 * Composant UI pour activer/désactiver les notifications push navigateur
 * dans le panneau Réglages du Cockpit.
 */

import { Bell, BellOff, BellRing, Loader2, CheckCircle, AlertTriangle, Info } from "lucide-react";
import { usePushNotifications } from "@/hooks/usePushNotifications";
import { Button } from "@/components/ui/button";

export function PushNotificationsCard() {
  const { permission, isSubscribed, isLoading, isSupported, subscribe, unsubscribe, sendTest } =
    usePushNotifications();

  // Navigateur non compatible
  if (!isSupported) {
    return (
      <div className="neu-card p-5 rounded-2xl">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl neu-btn flex items-center justify-center flex-shrink-0">
            <BellOff className="w-5 h-5 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-1">Notifications push</h3>
            <p className="text-sm text-muted-foreground">
              Votre navigateur ne supporte pas les notifications push. Essayez Chrome, Firefox ou Edge.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="neu-card p-5 rounded-2xl space-y-4">
      {/* En-tête */}
      <div className="flex items-start gap-3">
        <div
          className={`w-10 h-10 rounded-xl neu-btn flex items-center justify-center flex-shrink-0 ${
            isSubscribed ? "text-green-500" : "text-muted-foreground"
          }`}
        >
          {isSubscribed ? (
            <BellRing className="w-5 h-5" />
          ) : (
            <Bell className="w-5 h-5" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-foreground">Notifications push</h3>
            {isSubscribed && (
              <span className="inline-flex items-center gap-1 text-xs bg-green-500/10 text-green-600 dark:text-green-400 px-2 py-0.5 rounded-full font-medium">
                <CheckCircle className="w-3 h-3" />
                Actif
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            Recevez vos rappels J-30, J-7 et J-1 directement dans votre navigateur, même quand le site est fermé.
          </p>
        </div>
      </div>

      {/* Alerte permission refusée */}
      {permission === "denied" && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-destructive/10 text-destructive text-sm">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>
            Les notifications sont bloquées dans votre navigateur. Pour les activer, cliquez sur le cadenas dans la barre d'adresse → Notifications → Autoriser.
          </span>
        </div>
      )}

      {/* Info sur les rappels */}
      {!isSubscribed && permission !== "denied" && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-primary/5 text-sm text-muted-foreground">
          <Info className="w-4 h-4 flex-shrink-0 mt-0.5 text-primary" />
          <span>
            Vous recevrez une notification à <strong>J-30</strong>, <strong>J-7</strong> et <strong>J-1</strong> avant votre mariage, ainsi que des alertes en temps réel pour les événements prestataires (contrats, paiements, RSVP).
          </span>
        </div>
      )}

      {/* Boutons d'action */}
      <div className="flex flex-wrap gap-2">
        {!isSubscribed ? (
          <Button
            onClick={subscribe}
            disabled={isLoading || permission === "denied"}
            className="flex items-center gap-2"
            size="sm"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Bell className="w-4 h-4" />
            )}
            Activer les notifications
          </Button>
        ) : (
          <>
            <Button
              onClick={sendTest}
              disabled={isLoading}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <BellRing className="w-4 h-4" />
              )}
              Tester
            </Button>
            <Button
              onClick={unsubscribe}
              disabled={isLoading}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 text-destructive hover:text-destructive"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <BellOff className="w-4 h-4" />
              )}
              Désactiver
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
