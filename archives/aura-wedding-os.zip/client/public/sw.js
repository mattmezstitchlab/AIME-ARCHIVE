/**
 * AURA Wedding OS — Service Worker
 * Gère les notifications push navigateur et le cache offline basique.
 */

const CACHE_NAME = "aura-v1";
const OFFLINE_URL = "/";

// ─── Installation ─────────────────────────────────────────────────────────────
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.add(OFFLINE_URL))
  );
  self.skipWaiting();
});

// ─── Activation ───────────────────────────────────────────────────────────────
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ─── Réception d'une notification push ───────────────────────────────────────
self.addEventListener("push", (event) => {
  if (!event.data) return;

  let payload;
  try {
    payload = event.data.json();
  } catch {
    payload = { title: "AURA Wedding OS", body: event.data.text(), icon: "/favicon.ico" };
  }

  const title = payload.title || "AURA Wedding OS";
  const options = {
    body: payload.body || "",
    icon: payload.icon || "/favicon.ico",
    badge: "/favicon.ico",
    tag: payload.tag || "aura-notification",
    data: {
      url: payload.url || "/cockpit",
      panel: payload.panel || null,
    },
    actions: payload.actions || [],
    requireInteraction: payload.requireInteraction || false,
    silent: false,
    vibrate: [200, 100, 200],
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// ─── Clic sur une notification ────────────────────────────────────────────────
self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  const targetUrl = event.notification.data?.url || "/cockpit";
  const panel = event.notification.data?.panel;

  // Construire l'URL avec le panel en paramètre si présent
  const url = panel ? `${targetUrl}?panel=${panel}` : targetUrl;

  event.waitUntil(
    clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((windowClients) => {
        // Chercher un onglet déjà ouvert sur le domaine
        for (const client of windowClients) {
          if (client.url.includes(self.location.origin) && "focus" in client) {
            client.navigate(url);
            return client.focus();
          }
        }
        // Sinon ouvrir un nouvel onglet
        if (clients.openWindow) {
          return clients.openWindow(url);
        }
      })
  );
});

// ─── Fermeture d'une notification ────────────────────────────────────────────
self.addEventListener("notificationclose", () => {
  // Optionnel : analytics de fermeture
});

// ─── Fetch (cache-first pour les assets statiques) ───────────────────────────
self.addEventListener("fetch", (event) => {
  // Ne pas intercepter les requêtes API
  if (event.request.url.includes("/api/")) return;
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
