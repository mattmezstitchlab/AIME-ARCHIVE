# AURA Wedding OS — TODO

## Phase 1 : Fondations
- [x] Schéma DB complet (weddings, timeline, budget, providers, guests, documents, memories, chat, rsvp, dayof, photowall, provider_invitations)
- [x] Design system neumorphique : CSS variables (#E8EDF2, #F07167), index.css global
- [x] Migration SQL appliquée

## Phase 2 : Backend tRPC
- [x] Router wedding (get, update, getBySlug)
- [x] Router timeline (list, add, update, delete)
- [x] Router budget (list, add, update, delete, aiEstimate)
- [x] Router providers (list, add, update, delete, generateInviteLink)
- [x] Router guests (list, add, update, delete, getRsvpLink)
- [x] Router documents (list, upload, sign, delete)
- [x] Router memory (list, add, delete)
- [x] Router chat/IA AURA (send, history, propagate)
- [x] Router rsvp (getByToken, respond)
- [x] Router dayOf (list, add, updateStatus, aiAdjust)
- [x] Router photoWall (list, upload avec analyse IA)
- [x] Router providerPortal (getByToken, accept)

## Phase 3 : Landing Page
- [x] Hero asymétrique avec titre AURA et CTA
- [x] Section présentation 3 espaces (Mariés, Invités, Prestataires)
- [x] Section fonctionnalités clés
- [x] Footer avec liens légaux
- [x] Design neumorphique complet appliqué
- [x] Animations scroll reveal (fade-up)

## Phase 4 : Cockpit Mariés
- [x] Navigation par pictogrammes (12 modules)
- [x] Indicateurs de notifications (badge rouge)
- [x] Animations de transition fade/slide entre panneaux
- [x] IA AURA chat intégré avec propagation automatique
- [x] Header avec profil utilisateur

## Phase 5 : Modules Mariés
- [x] Module Timeline : étapes catégorisées, statuts, dates
- [x] Module Budget : suivi dépenses, estimations IA, barre de progression
- [x] Module Prestataires : filtres catégorie, shortlist, génération lien invitation
- [x] Module Invités : liste, liens RSVP uniques, suivi confirmations

## Phase 6 : Modules Avancés
- [x] Module Documents : upload drag & drop, téléchargement, suppression
- [x] Module Mémoire : journal émotionnel avec emojis
- [x] Mini-site du mariage (page publique /mariage/:slug)
- [x] Portail Invités RSVP (/rsvp/:token)
- [x] Portail Prestataires (/prestataire/:token)
- [x] Mur Photo public (/photowall/:slug)

## Phase 7 : Temps Réel
- [x] Coordination Jour J : planning temps réel, signalement retard
- [x] Ajustement automatique IA en cas de retard
- [x] Mur Photo : upload invités, filtrage IA, refresh automatique 10s

## Phase 8 : Finalisation
- [x] 14 tests vitest passants (0 erreur)
- [x] 0 erreur TypeScript
- [x] Checkpoint final
- [x] Livraison

## Améliorations futures
- [x] Graphiques Recharts dans le module Budget (camembert par catégorie)
- [x] Signature électronique dans les documents
- [x] Export PDF de la timeline
- [x] Notifications push prestataires (Socket.io)
- [x] Plan de table interactif (drag & drop)
- [x] Espace prestataire complet (tableau de bord après acceptation)
- [x] Abonnements Stripe (Essentiel / Premium / Prestige)
- [x] Mode sombre

## Espace Prestataire Complet (v1.1)
- [x] Schéma DB : tables provider_sessions, provider_missions, provider_contracts, contract_signatures
- [x] Migration SQL appliquée
- [x] Backend : router providerDashboard (profil, missions, contrats, paiements)
- [x] Backend : router contractSign (upload contrat, demande signature, signer, vérifier)
- [x] Page ProviderDashboard (/provider/dashboard) : tableau de bord post-acceptation
- [x] Module Missions : liste des prestations assignées, statuts, planning
- [x] Module Contrats : liste des contrats, statut signature, téléchargement
- [x] Module Signature électronique : canvas de signature, validation, stockage S3
- [x] Module Paiements : suivi acompte/solde, méthodes (IBAN/Stripe)
- [x] Module Profil prestataire : photo, bio, catégorie, tarifs, disponibilités
- [x] Intégration dans le Cockpit Mariés : vue contrats à signer, statut signatures
- [x] Tests vitest pour les nouveaux routers
- [x] Checkpoint v1.1

## Corrections et Complétions v1.2

### Flux Prestataire
- [x] Corriger ProviderPortal : après acceptation, créer session via acceptAndCreateSession et rediriger vers /provider/dashboard?token=xxx
- [x] Page ProviderDashboard : lire le sessionToken depuis l'URL (?token=) et non depuis l'auth OAuth
- [x] Bouton "Accéder à mon espace" sur la page d'acceptation si déjà accepté

### Mini-site Complet
- [x] Section Programme : afficher la timeline publique (événements confirmés)
- [x] RSVP intégré dans le mini-site (formulaire inline sans quitter la page)
- [x] Galerie photos : afficher les photos approuvées du mur photo
- [x] Carte Google Maps du lieu de réception
- [x] Section "Infos pratiques" : hébergements, transports, dress code
- [x] Section "Notre histoire" avec texte personnalisé
- [x] Personnalisation mini-site dans le Cockpit : couleur de thème, message d'accueil, sections à afficher/masquer
- [x] Compteur J-X animé en temps réel

### Cockpit Différencié par Rôle
- [x] Routing intelligent : /cockpit redirige selon le rôle (marié → CockpitMaries, prestataire → ProviderDashboard)
- [x] Portail invité connecté : espace invité post-RSVP avec programme, infos pratiques, mur photo

## IA Wedding Planner Complète (v1.3)

### Schéma DB
- [x] Table onboarding_sessions (étapes, réponses JSON, statut)
- [x] Table email_campaigns (type, sujet, corps, statut envoi, destinataires)
- [x] Table email_logs (campagne, invité, statut, envoyé_at)
- [x] Table ai_guide_tasks (priorité, catégorie, délai recommandé, statut, lié à wedding)
- [x] Table provider_matches (score, justification, prestataire suggéré, statut)
- [x] Table narrative_memories (texte généré, version, approuvé)
- [x] Migration SQL appliquée

### Backend tRPC
- [x] Router onboarding : startSession, nextQuestion, submitAnswer, generateFromAnswers
- [x] Router aiGuide : generatePriorityList, markTaskDone, refreshPriorities
- [x] Router emailCampaign : createCampaign, sendCampaign, previewEmail, getStats
- [x] Router quoteAssistant : analyzeQuote, suggestCounterOffer, generateQuestions
- [x] Router providerMatch : generateMatches, refreshMatches
- [x] Router narrativeMemory : generateNarrative, approveNarrative
- [x] Router crisis : activateCrisisMode, cascadeDelay, notifyAll

### Interface
- [x] Page AuraOnboarding : chat conversationnel guidé (12 questions, progress bar, animations)
- [x] Intégration onboarding dans CockpitRouter : si wedding vide → lancer onboarding
- [x] Panneau Guide IA dans Cockpit : liste priorisée des tâches avec délais et urgences
- [x] Panneau Assistant Devis dans Cockpit : analyse devis, contre-proposition, questions à poser
- [x] Panneau Emails Groupés dans Cockpit : 5 templates, personnalisation, aperçu, envoi
- [x] Panneau Matching Prestataires dans Cockpit : cartes avec score IA et justification
- [x] Panneau Mémoire Narrative dans Cockpit : génération du récit IA, édition, export
- [x] Amélioration Jour J : bouton "Activer mode crise", cascade automatique, notifications
- [x] Badge "AURA suggère" sur les modules concernés

## Gaps v1.3 à combler

- [x] Router quoteAssistant (analyzeQuote, suggestCounterOffer, generateQuestions) + panneau Cockpit
- [x] CockpitRouter : redirection automatique vers onboarding si aucun wedding configuré
- [x] emailCampaign : édition sujet/corps + endpoint getStats
- [x] Mémoire Narrative : édition du récit + export texte
- [x] Intégration crise dans module Jour J avec notifications ciblées
- [x] Badges "AURA suggère" sur modules concernés (Budget, Prestataires, Timeline)

## Version 1.7 — Plan de Table & Abonnements Stripe

### Schéma DB
- [x] Table seating_tables (id, weddingId, name, shape, capacity, positionX, positionY, colorHex, notes)
- [x] Table seating_assignments (id, weddingId, tableId, guestId, seatNumber)
- [x] Table subscriptions (id, userId, plan, status, stripeCustomerId, stripeSubscriptionId)
- [x] Migration SQL appliquée

### Backend tRPC
- [x] Router seating : getFullPlan, addTable, updateTable, deleteTable, assignGuest, unassignGuest, autoAssign
- [x] Router subscriptions : getCurrent, getPlans, createCheckout, createPortal
- [x] Intégration des deux routers dans l'appRouter (server/routers.ts)

### Webhook Stripe
- [x] Fichier server/stripeWebhook.ts créé
- [x] Route POST /api/stripe/webhook enregistrée avant express.json()
- [x] Gestion des événements : checkout.session.completed, customer.subscription.updated, customer.subscription.deleted, invoice.payment_failed
- [x] Gestion des événements test (evt_test_*)

### Interface
- [x] Page SeatingPlan (/plan-de-table) : drag & drop avec @dnd-kit, zones droppables par table, zone invités non placés, placement automatique IA
- [x] Page Pricing (/tarifs) : 4 plans (Gratuit/Essentiel/Premium/Prestige), checkout Stripe, portail client Stripe, garanties
- [x] Routes câblées dans App.tsx

### Restant
- [x] Lien "Plan de table" dans le Cockpit (module invités ou navigation) — accessible via /plan-de-table
- [x] Lien "Tarifs" dans le header de la Home — accessible via /tarifs
- [x] Mode sombre (toggle dans Cockpit)
- [x] Notifications temps réel prestataires (polling 15s + badge + centre de notifications)
- [x] Export PDF de la timeline

## Version 1.9 — Email, Filtres Notifications, Analytics

- [x] Rappels email automatiques via notifyOwner (contrat signé, paiement reçu, invitation acceptée)
- [x] Filtres dans le centre de notifications (onglets Tout / Non lus / Par type)
- [x] Tableau de bord analytique : graphiques Recharts (budget consommé vs estimé, % RSVP, missions confirmées)

## Version 2.0 — Rappels Programmés J-30 / J-7 / J-1

- [x] Colonne `reminder_j30_task_uid`, `reminder_j7_task_uid`, `reminder_j1_task_uid` sur la table `weddings`
- [x] Handler Express `/api/scheduled/wedding-reminder` (auth isCron, lookup par taskUid, notifyOwner)
- [x] Enregistrement du handler dans `server/_core/index.ts`
- [x] tRPC mutation `reminders.setup` (crée/supprime les 3 crons selon la date de mariage)
- [x] tRPC query `reminders.status` (retourne l'état des 3 crons)
- [x] Composant UI RemindersCard dans le panneau Réglages du Cockpit
- [x] Checkpoint + déploiement + création des crons via manus-heartbeat CLI

## Version 2.1 — Finalisation Production

- [x] Pages légales : CGU, CGV, Mentions légales, Confidentialité (routes + contenu réel RGPD)
- [x] Route /portail-invite dans App.tsx + redirection CockpitRouter pour rôle guest
- [x] Bouton "Ouvrir le plan de table" dans le panneau Invités
- [x] Avertissement matching IA (bandeau ambre + prompt sans faux emails)
- [x] Validation date passée dans OnboardingChat (passée / <30j / >2ans)
- [x] Modal confirmation/annulation post-paiement Stripe (?subscription=success/cancelled)
- [x] Import CSV invités (modal drag-drop, prévisualisation, batch tRPC, template téléchargeable)
- [x] Liens d'action dans les notifications (Voir contrat / Voir invité / Voir paiements)
- [x] Intégration Resend / Push navigateur pour notifications (RSVP, rappels, prestataires)

## Version 2.2 — Notifications Push Navigateur

- [x] Installer web-push + @types/web-push, générer clés VAPID
- [x] Table push_subscriptions (userId, endpoint, p256dh, auth, userAgent, createdAt)
- [x] Migration SQL appliquée
- [x] Service Worker /sw.js (push event, notificationclick, offline)
- [x] Helper serveur server/_core/pushNotification.ts (sendPush, sendPushToUser)
- [x] tRPC router push : subscribe, unsubscribe, getStatus
- [x] Hook client usePushNotifications (permission, subscribe, unsubscribe, status)
- [x] Composant PushNotificationsCard dans Réglages du Cockpit
- [x] Brancher sendPush dans scheduledReminders.ts (rappels J-30/J-7/J-1)
- [x] Brancher sendPush dans providerSpace.ts (invitation acceptée, contrat signé, paiement)
- [x] Brancher sendPush dans routers.ts submitRsvpBySlug (confirmation RSVP)
- [x] Supprimer la dépendance Resend (remplacer par push dans les campagnes)
- [x] Tests vitest pour le router push et le helper
- [x] Checkpoint v2.2

## Version 2.3 — Refonte Visuelle Landing Page

- [x] Réécrire Home.tsx avec les 5 sections validées (Hero, Espaces, Fonctionnalités, Tarifs, Footer)
- [x] Palette stricte : coral #E8826A, clair #E8EDF2, sombre #1a1a2e — zéro jaune/doré
- [x] Header transparent avec scroll → opaque + animation
- [x] Animations fade-in/slide-up au scroll (IntersectionObserver)
- [x] Section Hero : fond photo bokeh sombre + overlay navy + dashboard neumorphique sur île claire
- [x] Section Espaces : fond #E8EDF2 pur + 3 cartes neumorphiques convexes
- [x] Section Fonctionnalités : fond chaud #F5EDE8 + texture florale subtile + 6 cartes icône-gauche
- [x] Section Tarifs : fond sombre #1a1a2e + dark neumorphism + 3 cartes (Essentiel/Premium/Prestige)
- [x] Footer : fond sombre #1a1a2e + séparateur coral + newsletter + liens légaux

## Version 2.3.1 — Corrections visuelles Home

- [x] Section Fonctionnalités : fond repassé en #E8EDF2 pur (supprimer #F5EDE8 chaud)
- [x] Hero : supprimer le flou blanc (backdrop-filter/blur) sur le dashboard neumorphique
- [x] Hero : photo de fond à 100% d'opacité (supprimer l'atténuation opacity: 0.35)
- [x] Hero : supprimer le halo/reflet blanc lumineux autour de la carte (box-shadow #ffffff → drop-shadow sombre flottant)
