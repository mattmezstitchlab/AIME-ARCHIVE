import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { StitchLabApp } from "./components/StitchLabApp";
import { StitchGridWidget } from "./components/StitchGridWidget";
import { LandingScreen } from "./components/LandingScreen";
import { StitchLabExperience } from "./components/StitchLabExperience";
import { WidgetShowcase } from "./components/WidgetShowcase";
import { SquareEditor } from "./components/SquareEditor";
import { GameGrid } from "./components/GameGrid";
import { BetaTest } from "./components/BetaTest";
import { Point } from "./components/Point";
import { PointLanding } from "./components/PointLanding";
import { TimeHeart } from "./components/TimeHeart";
import { ImagineLanding } from "./components/ImagineLanding";
import { InstrumentBuilderLanding } from "./components/InstrumentBuilderLanding";
import { WedpopLanding } from "./components/WedpopLanding";
import { NordicOSLanding } from "./components/NordicOSLanding";
import { TetrisJungLanding } from "./components/TetrisJungLanding";
import { LuthierLabLanding } from "./components/LuthierLabLanding";
import { HeroCinematic } from "./components/HeroCinematic";
import type { PlayerData, AccessibilityMode } from "./components/game-data";

type Screen =
  | "landing"
  | "experience"
  | "stitchlab-app"
  | "stitch-grid-widget"
  | "editor"
  | "game"
  | "hero-cinematic"
  | "widget-showcase"
  | "beta-test"
  | "point"
  | "point-landing"
  | "timeheart"
  | "imagine"
  | "instrument-builder"
  | "wedpop"
  | "nordic-os"
  | "tetris-jung"
  | "luthier-lab";

export default function App() {
  const [screen, setScreen] = useState<Screen>("stitchlab-app");
  const [mode, setMode] = useState<AccessibilityMode>("default");
  const [currentPlayer, setCurrentPlayer] = useState<PlayerData | null>(null);
  const [lastStitchKey, setLastStitchKey] = useState<string | null>(null);

  const handleEditorComplete = (data: {
    pseudo: string;
    city: string;
    intention: string;
    colorHex: string;
    colorCode: string;
    symbol: string;
    symbol2?: string;
    symbolSize: number;
    symbolRotation: number;
    symbolContrast: number;
  }) => {
    setCurrentPlayer({
      id: "me",
      pseudo: data.pseudo,
      city: data.city,
      intention: data.intention,
      colorHex: data.colorHex,
      colorCode: data.colorCode,
      symbol: data.symbol,
      symbol2: data.symbol2,
      symbolSize: data.symbolSize,
      symbolRotation: data.symbolRotation,
      symbolContrast: data.symbolContrast,
      x: 0,
      y: 0,
    });
    setScreen("hero-cinematic");
  };

  const go = (s: Screen) => () => setScreen(s);

  return (
    <div
      className="size-full"
      style={{ fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}
    >
      <AnimatePresence mode="wait">
        {/* ═══ LANDING — Just the ♥ ═══ */}
        {screen === "landing" && (
          <motion.div key="landing" exit={{ opacity: 0 }} transition={{ duration: 0.6 }}>
            <LandingScreen onEnter={go("stitchlab-app")} />
          </motion.div>
        )}

        {/* ═══ EXPERIENCE — The single screen ═══ */}
        {screen === "experience" && (
          <motion.div
            key="experience"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <StitchLabExperience
              onBack={go("landing")}
            />
          </motion.div>
        )}

        {/* ═══ Existing screens ═══ */}
        {screen === "widget-showcase" && (
          <motion.div
            key="widget-showcase"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <WidgetShowcase onBack={go("landing")} />
          </motion.div>
        )}

        {screen === "editor" && (
          <motion.div
            key="editor"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <SquareEditor onComplete={handleEditorComplete} mode={mode} />
          </motion.div>
        )}

        {screen === "game" && currentPlayer && (
          <motion.div
            key="game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <GameGrid
              currentPlayer={currentPlayer}
              mode={mode}
              onModeChange={setMode}
            />
          </motion.div>
        )}

        {screen === "beta-test" && (
          <motion.div
            key="beta-test"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <BetaTest onBack={go("landing")} />
          </motion.div>
        )}

        {screen === "point" && (
          <motion.div
            key="point"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Point onBack={go("landing")} />
          </motion.div>
        )}

        {screen === "point-landing" && (
          <motion.div
            key="point-landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <PointLanding
              onBack={go("landing")}
              onTryPoint={go("point")}
            />
          </motion.div>
        )}

        {screen === "timeheart" && (
          <motion.div
            key="timeheart"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <TimeHeart onBack={go("stitchlab-app")} lastStitchKey={lastStitchKey} />
          </motion.div>
        )}

        {screen === "imagine" && (
          <motion.div
            key="imagine"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ImagineLanding
              onBack={go("landing")}
              onNavigate={(s) => setScreen(s as Screen)}
            />
          </motion.div>
        )}

        {screen === "instrument-builder" && (
          <motion.div
            key="instrument-builder"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <InstrumentBuilderLanding
              onBack={go("landing")}
              onNavigate={(s) => setScreen(s as Screen)}
            />
          </motion.div>
        )}

        {screen === "wedpop" && (
          <motion.div
            key="wedpop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <WedpopLanding
              onBack={go("landing")}
              onNavigate={(s) => setScreen(s as Screen)}
            />
          </motion.div>
        )}

        {screen === "nordic-os" && (
          <motion.div
            key="nordic-os"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <NordicOSLanding
              onBack={go("landing")}
              onNavigate={(s) => setScreen(s as Screen)}
            />
          </motion.div>
        )}

        {screen === "tetris-jung" && (
          <motion.div
            key="tetris-jung"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <TetrisJungLanding
              onBack={go("landing")}
              onNavigate={(s) => setScreen(s as Screen)}
            />
          </motion.div>
        )}

        {screen === "luthier-lab" && (
          <motion.div
            key="luthier-lab"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <LuthierLabLanding
              onBack={go("landing")}
              onNavigate={(s) => setScreen(s as Screen)}
            />
          </motion.div>
        )}

        {screen === "stitchlab-app" && (
          <motion.div
            key="stitchlab-app"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <StitchLabApp
              onBack={go("landing")}
              onShowTimeHeart={go("timeheart")}
              onLastStitchChange={setLastStitchKey}
            />
          </motion.div>
        )}

        {screen === "stitch-grid-widget" && (
          <motion.div
            key="stitch-grid-widget"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <StitchGridWidget
              onBack={go("landing")}
            />
          </motion.div>
        )}

        {screen === "hero-cinematic" && currentPlayer && (
          <motion.div
            key="hero-cinematic"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <HeroCinematic
              player={currentPlayer}
              onComplete={() => setScreen("game")}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}