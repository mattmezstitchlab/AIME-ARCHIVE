import { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayerSquare } from "./PlayerSquare";
import { useResponsive } from "./useResponsive";
import { HEART_RED } from "./game-data";
import { ArrowLeft, Check, RotateCcw, Sparkles } from "lucide-react";

// ═══════════════════════════════════════════
// PATTERN DISCOVERY — iPad Tutorial
// Step-by-step stitching on a cross-stitch grid
// Discover the before/after magic
// ═══════════════════════════════════════════

// Heart pattern on 10x10 grid (1 = stitch, 0 = empty)
const HEART_GRID: number[][] = [
  [0, 0, 1, 1, 0, 0, 1, 1, 0, 0],
  [0, 1, 1, 1, 1, 1, 1, 1, 1, 0],
  [0, 1, 1, 1, 1, 1, 1, 1, 1, 0],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [0, 1, 1, 1, 1, 1, 1, 1, 1, 0],
  [0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
  [0, 0, 0, 1, 1, 1, 1, 0, 0, 0],
  [0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
];

// Color palette for the heart cells — various reds and pinks
const PALETTE = ["#E3243B", "#C72B3B", "#E8177F", "#D4556B", "#B8293D", "#E84C6F", "#CC3355", "#F4607A", "#A22040", "#D93A5C"];

// Build fill order (top-left to bottom-right, only filled cells)
function buildFillOrder() {
  const cells: { r: number; c: number; color: string }[] = [];
  let colorIdx = 0;
  for (let r = 0; r < 10; r++) {
    for (let c = 0; c < 10; c++) {
      if (HEART_GRID[r][c] === 1) {
        cells.push({ r, c, color: PALETTE[colorIdx % PALETTE.length] });
        colorIdx++;
      }
    }
  }
  return cells;
}

type Phase = "intro" | "stitching" | "complete" | "compare";

interface PatternDiscoveryProps {
  onBack: () => void;
}

export function PatternDiscovery({ onBack }: PatternDiscoveryProps) {
  const { isMobile } = useResponsive();
  const [phase, setPhase] = useState<Phase>("intro");
  const [currentStep, setCurrentStep] = useState(0);
  const [filledCells, setFilledCells] = useState<Set<string>>(new Set());
  const [showBefore, setShowBefore] = useState(true);

  const fillOrder = useMemo(() => buildFillOrder(), []);
  const totalCells = fillOrder.length;
  const progress = (currentStep / totalCells) * 100;

  // Auto-start after intro
  useEffect(() => {
    if (phase === "intro") {
      const timer = setTimeout(() => setPhase("stitching"), 2200);
      return () => clearTimeout(timer);
    }
  }, [phase]);

  const handleCellClick = useCallback(
    (r: number, c: number) => {
      if (phase !== "stitching" || currentStep >= totalCells) return;
      const target = fillOrder[currentStep];
      if (r === target.r && c === target.c) {
        setFilledCells((prev) => new Set(prev).add(`${r},${c}`));
        const next = currentStep + 1;
        setCurrentStep(next);
        if (next >= totalCells) {
          setTimeout(() => setPhase("complete"), 600);
        }
      }
    },
    [phase, currentStep, totalCells, fillOrder]
  );

  const handleReset = () => {
    setPhase("intro");
    setCurrentStep(0);
    setFilledCells(new Set());
    setShowBefore(true);
  };

  const cellSize = isMobile ? 28 : 36;
  const gridGap = isMobile ? 1.5 : 2;
  const ipadW = isMobile ? 310 : 420;
  const ipadH = isMobile ? 430 : 570;

  // The current blinking target
  const blinkTarget = phase === "stitching" && currentStep < totalCells ? fillOrder[currentStep] : null;

  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center"
      style={{ backgroundColor: "#0A0A0A" }}
    >
      {/* Back button */}
      <motion.button
        className="fixed top-4 left-4 z-30 flex items-center gap-1.5 cursor-pointer border-none"
        style={{
          backgroundColor: "rgba(255,255,255,0.06)",
          color: "rgba(255,255,255,0.5)",
          fontSize: 10,
          fontWeight: 400,
          padding: "8px 14px",
          borderRadius: 10,
          border: "1px solid rgba(255,255,255,0.06)",
        }}
        onClick={onBack}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        whileHover={{ scale: 1.03, backgroundColor: "rgba(255,255,255,0.1)" }}
        whileTap={{ scale: 0.97 }}
      >
        <ArrowLeft size={12} />
      </motion.button>

      {/* ═══ INTRO PHASE ═══ */}
      <AnimatePresence>
        {phase === "intro" && (
          <motion.div
            className="absolute inset-0 flex flex-col items-center justify-center gap-6 z-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <PlayerSquare
                colorHex={HEART_RED}
                symbol="♥"
                size={isMobile ? 60 : 80}
                symbolSize={50}
                glowing
              />
            </motion.div>
            <motion.p
              style={{
                fontSize: isMobile ? 14 : 18,
                fontWeight: 200,
                color: "rgba(255,255,255,0.5)",
                letterSpacing: "0.06em",
              }}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              Brode ton premier motif
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ IPAD FRAME ═══ */}
      <AnimatePresence>
        {(phase === "stitching" || phase === "complete" || phase === "compare") && (
          <motion.div
            className="relative flex flex-col items-center"
            initial={{ opacity: 0, scale: 0.85, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.8, type: "spring", stiffness: 60 }}
          >
            {/* iPad body */}
            <div
              className="relative rounded-2xl flex flex-col items-center overflow-hidden"
              style={{
                width: ipadW,
                height: ipadH,
                backgroundColor: "#1a1a1a",
                border: "3px solid #333",
                boxShadow: "0 8px 40px rgba(0,0,0,0.5), 0 0 60px rgba(232,23,127,0.05)",
              }}
            >
              {/* Camera notch */}
              <div
                className="w-2 h-2 rounded-full mt-2 mb-1"
                style={{ backgroundColor: "rgba(255,255,255,0.08)" }}
              />

              {/* Screen area */}
              <div
                className="flex-1 w-[92%] rounded-sm flex flex-col items-center justify-center relative"
                style={{ backgroundColor: "#0A0A0A" }}
              >
                {/* Progress bar */}
                {phase === "stitching" && (
                  <div
                    className="absolute top-3 left-4 right-4"
                    style={{ height: 2, backgroundColor: "rgba(255,255,255,0.04)", borderRadius: 1 }}
                  >
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: HEART_RED }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                )}

                {/* ═══ THE GRID ═══ */}
                <AnimatePresence mode="wait">
                  {phase === "compare" ? (
                    <motion.div
                      key="compare"
                      className="flex flex-col items-center gap-4"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      {/* Before / After toggle */}
                      <div className="flex gap-4 mb-2">
                        <motion.button
                          className="cursor-pointer border-none"
                          style={{
                            backgroundColor: showBefore ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.02)",
                            color: showBefore ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.25)",
                            fontSize: 10,
                            fontWeight: 500,
                            letterSpacing: "0.08em",
                            padding: "6px 16px",
                            borderRadius: 8,
                          }}
                          onClick={() => setShowBefore(true)}
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.97 }}
                        >
                          AVANT
                        </motion.button>
                        <motion.button
                          className="cursor-pointer border-none"
                          style={{
                            backgroundColor: !showBefore ? HEART_RED + "20" : "rgba(255,255,255,0.02)",
                            color: !showBefore ? HEART_RED : "rgba(255,255,255,0.25)",
                            fontSize: 10,
                            fontWeight: 500,
                            letterSpacing: "0.08em",
                            padding: "6px 16px",
                            borderRadius: 8,
                          }}
                          onClick={() => setShowBefore(false)}
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.97 }}
                        >
                          APRÈS
                        </motion.button>
                      </div>

                      <CompareGrid
                        cellSize={cellSize}
                        gap={gridGap}
                        fillOrder={fillOrder}
                        showFilled={!showBefore}
                      />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="grid"
                      className="flex flex-col items-center"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    >
                      {/* Counter */}
                      <motion.p
                        className="mb-3"
                        style={{
                          fontSize: 10,
                          color: "rgba(255,255,255,0.2)",
                          fontWeight: 300,
                          letterSpacing: "0.05em",
                        }}
                      >
                        {currentStep} / {totalCells} points
                      </motion.p>

                      {/* Grid */}
                      <div
                        className="grid"
                        style={{
                          gridTemplateColumns: `repeat(10, ${cellSize}px)`,
                          gap: gridGap,
                        }}
                      >
                        {HEART_GRID.flat().map((cell, i) => {
                          const r = Math.floor(i / 10);
                          const c = i % 10;
                          const key = `${r},${c}`;
                          const isFilled = filledCells.has(key);
                          const isTarget = blinkTarget && blinkTarget.r === r && blinkTarget.c === c;
                          const fillInfo = fillOrder.find((f) => f.r === r && f.c === c);

                          return (
                            <motion.div
                              key={key}
                              className="relative cursor-pointer rounded-[1px]"
                              style={{
                                width: cellSize,
                                height: cellSize,
                                backgroundColor: isFilled
                                  ? fillInfo?.color || HEART_RED
                                  : cell === 1
                                  ? "rgba(255,255,255,0.03)"
                                  : "rgba(255,255,255,0.008)",
                                border: isTarget
                                  ? `1.5px solid ${HEART_RED}`
                                  : cell === 1
                                  ? "1px solid rgba(255,255,255,0.04)"
                                  : "1px solid rgba(255,255,255,0.015)",
                              }}
                              onClick={() => handleCellClick(r, c)}
                              animate={
                                isTarget
                                  ? {
                                      backgroundColor: [
                                        "rgba(232,23,127,0.08)",
                                        "rgba(232,23,127,0.25)",
                                        "rgba(232,23,127,0.08)",
                                      ],
                                      boxShadow: [
                                        "0 0 0 0 rgba(232,23,127,0)",
                                        "0 0 8px 2px rgba(232,23,127,0.2)",
                                        "0 0 0 0 rgba(232,23,127,0)",
                                      ],
                                    }
                                  : isFilled
                                  ? { scale: [1, 1.08, 1] }
                                  : {}
                              }
                              transition={
                                isTarget
                                  ? { duration: 1.2, repeat: Infinity, ease: "easeInOut" }
                                  : isFilled
                                  ? { duration: 0.3 }
                                  : {}
                              }
                              whileHover={
                                cell === 1 && !isFilled
                                  ? { backgroundColor: "rgba(232,23,127,0.1)" }
                                  : {}
                              }
                              whileTap={cell === 1 ? { scale: 0.9 } : {}}
                            >
                              {/* Cross-stitch marks on filled cells */}
                              {isFilled && (
                                <motion.div
                                  className="absolute inset-0 flex items-center justify-center"
                                  style={{ fontSize: cellSize * 0.5, color: "rgba(255,255,255,0.7)", lineHeight: 1 }}
                                  initial={{ opacity: 0, scale: 0 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  transition={{ type: "spring", stiffness: 200 }}
                                >
                                  ✕
                                </motion.div>
                              )}
                            </motion.div>
                          );
                        })}
                      </div>

                      {/* Hint */}
                      {phase === "stitching" && currentStep === 0 && (
                        <motion.p
                          className="mt-3"
                          style={{ fontSize: 9, color: "rgba(255,255,255,0.2)", fontWeight: 300 }}
                          animate={{ opacity: [0.3, 0.7, 0.3] }}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          ↑ Clique sur la case qui clignote
                        </motion.p>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Home indicator */}
              <div
                className="w-8 h-0.5 rounded-full my-2"
                style={{ backgroundColor: "rgba(255,255,255,0.1)" }}
              />
            </div>

            {/* ═══ COMPLETE OVERLAY ═══ */}
            <AnimatePresence>
              {phase === "complete" && (
                <motion.div
                  className="absolute inset-0 flex flex-col items-center justify-center gap-4 z-10 rounded-2xl"
                  style={{
                    backgroundColor: "rgba(0,0,0,0.7)",
                    backdropFilter: "blur(4px)",
                  }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.2 }}
                  >
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center"
                      style={{
                        backgroundColor: HEART_RED,
                        boxShadow: `0 0 30px ${HEART_RED}40`,
                      }}
                    >
                      <Check size={24} color="#fff" strokeWidth={2.5} />
                    </div>
                  </motion.div>

                  <motion.p
                    style={{ color: "#fff", fontSize: 16, fontWeight: 300, letterSpacing: "0.06em" }}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                  >
                    Pattern terminé
                  </motion.p>

                  <motion.div
                    className="flex gap-3 mt-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                  >
                    <motion.button
                      className="cursor-pointer border-none flex items-center gap-1.5"
                      style={{
                        backgroundColor: HEART_RED,
                        color: "#fff",
                        fontSize: 10,
                        fontWeight: 500,
                        padding: "10px 20px",
                        borderRadius: 10,
                        letterSpacing: "0.08em",
                      }}
                      onClick={() => setPhase("compare")}
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                    >
                      <Sparkles size={11} />
                      AVANT / APRÈS
                    </motion.button>

                    <motion.button
                      className="cursor-pointer border-none flex items-center gap-1.5"
                      style={{
                        backgroundColor: "rgba(255,255,255,0.08)",
                        color: "rgba(255,255,255,0.6)",
                        fontSize: 10,
                        fontWeight: 400,
                        padding: "10px 16px",
                        borderRadius: 10,
                      }}
                      onClick={handleReset}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      <RotateCcw size={10} />
                      Recommencer
                    </motion.button>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Compare Grid ───
function CompareGrid({
  cellSize,
  gap,
  fillOrder,
  showFilled,
}: {
  cellSize: number;
  gap: number;
  fillOrder: { r: number; c: number; color: string }[];
  showFilled: boolean;
}) {
  const fillMap = new Map(fillOrder.map((f) => [`${f.r},${f.c}`, f.color]));

  return (
    <motion.div
      className="grid"
      style={{
        gridTemplateColumns: `repeat(10, ${cellSize}px)`,
        gap,
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {HEART_GRID.flat().map((cell, i) => {
        const r = Math.floor(i / 10);
        const c = i % 10;
        const key = `${r},${c}`;
        const color = fillMap.get(key);
        const filled = showFilled && !!color;

        return (
          <motion.div
            key={key}
            className="rounded-[1px]"
            style={{
              width: cellSize,
              height: cellSize,
              backgroundColor: filled
                ? color
                : cell === 1
                ? "rgba(255,255,255,0.03)"
                : "rgba(255,255,255,0.008)",
              border: cell === 1
                ? "1px solid rgba(255,255,255,0.04)"
                : "1px solid rgba(255,255,255,0.015)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: cellSize * 0.5,
              color: "rgba(255,255,255,0.7)",
            }}
            animate={filled ? { scale: [0.5, 1.05, 1] } : {}}
            transition={filled ? { duration: 0.4, delay: i * 0.02 } : {}}
          >
            {filled && "✕"}
          </motion.div>
        );
      })}
    </motion.div>
  );
}