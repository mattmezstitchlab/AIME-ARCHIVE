import { useState, useRef, useEffect, useCallback } from "react";
import { motion } from "motion/react";
import {
  X, Send, Volume2, VolumeX, Loader2, Check, Copy, ChevronLeft,
  Sparkles, Info,
} from "lucide-react";
import { PlayerSquare } from "./PlayerSquare";
import { DMC_COLORS, EXTENDED_SYMBOLS, PRIMARY_SHAPES } from "./game-data";
import { chatWithLily, speakWithLily } from "./api";
import type { LilyChatMessage } from "./api";
import type { ActiveTool } from "./grid-tools";

// ═══════════════════════════════════════════
// FACETTE PANEL — Interactive overlay for 64 facettes
// ═══════════════════════════════════════════

const LILY_PURPLE = "#9263A6";

interface HeartConfig {
  color: string;
  colorCode: string;
  symbol: string;
  symbol2?: string;
  symbolSize: number;
  rotation: number;
  contrast: number;
}

interface FacettePanelProps {
  famIdx: number;
  facetteIdx: number;
  famColor: string;
  famSymbol: string;
  famTitle: string;
  facetteLabel: string;
  isDark: boolean;
  isMobile: boolean;
  heartConfig: HeartConfig;
  onUpdateHeart: (patch: Partial<HeartConfig>) => void;
  onToggleTheme: () => void;
  onRecenter: () => void;
  cellSize: number;
  onClose: () => void;
  onLilyMessage: (msg: string) => void;
  onSelectTool?: (tool: ActiveTool) => void;
}

// ── Slider sub-component ──
function PanelSlider({
  label, value, min, max, step, unit, color, onChange,
}: {
  label: string; value: number; min: number; max: number;
  step: number; unit: string; color: string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium opacity-70">{label}</span>
        <span className="text-xs font-mono opacity-50">{value}{unit}</span>
      </div>
      <input
        type="range"
        min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
        style={{
          background: `linear-gradient(to right, ${color} ${((value - min) / (max - min)) * 100}%, rgba(255,255,255,0.1) ${((value - min) / (max - min)) * 100}%)`,
          accentColor: color,
        }}
      />
    </div>
  );
}

export function FacettePanel(props: FacettePanelProps) {
  const {
    famIdx, facetteIdx, famColor, famSymbol, famTitle, facetteLabel,
    isDark, isMobile, heartConfig, onUpdateHeart, onToggleTheme,
    onRecenter, cellSize, onClose, onLilyMessage, onSelectTool,
  } = props;

  const bg = isDark ? "rgba(18,18,18,0.97)" : "rgba(250,248,245,0.97)";
  const text = isDark ? "#e8e8e8" : "#1a1a1a";
  const muted = isDark ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.4)";
  const cardBg = isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)";

  // ── Panel header ──
  const header = (
    <div className="flex items-center justify-between px-5 pt-4 pb-3">
      <div className="flex items-center gap-2.5">
        <div
          className="w-3 h-3 rounded-sm"
          style={{ backgroundColor: famColor }}
        />
        <span style={{ color: muted, fontSize: 11, letterSpacing: "0.08em" }}>
          {famSymbol} {famTitle}
        </span>
        <ChevronLeft size={10} style={{ color: muted, opacity: 0.5 }} />
        <span style={{ color: text, fontSize: 13, fontWeight: 600 }}>
          {facetteLabel}
        </span>
      </div>
      <motion.button
        className="flex items-center justify-center rounded-full border-none cursor-pointer"
        style={{
          width: 32, height: 32,
          backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
          color: muted,
        }}
        onClick={onClose}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <X size={16} />
      </motion.button>
    </div>
  );

  // ═══════════════════════════════════════════
  // CONTENT SWITCH — by family + facette
  // ═══════════════════════════════════════════

  let content: React.ReactNode = null;

  // ♥ POINT (fam 0)
  if (famIdx === 0) {
    content = <PointContent
      facetteIdx={facetteIdx} famColor={famColor} isDark={isDark}
      isMobile={isMobile} heartConfig={heartConfig}
      onUpdateHeart={onUpdateHeart} cellSize={cellSize}
      text={text} muted={muted} cardBg={cardBg}
    />;
  }
  // ✚ PATTERN (fam 1)
  else if (famIdx === 1) {
    content = <PatternContent facetteIdx={facetteIdx} isDark={isDark} text={text} muted={muted} cardBg={cardBg} famColor={famColor} />;
  }
  // ◆ CARTE (fam 2)
  else if (famIdx === 2) {
    content = <CarteContent facetteIdx={facetteIdx} isDark={isDark} text={text} muted={muted} cardBg={cardBg} famColor={famColor} />;
  }
  // ✳ LILY (fam 3)
  else if (famIdx === 3) {
    content = <LilyContent
      facetteIdx={facetteIdx} isDark={isDark} isMobile={isMobile}
      text={text} muted={muted} cardBg={cardBg}
      onLilyMessage={onLilyMessage}
      heartConfig={heartConfig}
      famTitle={famTitle}
    />;
  }
  // ■ OUTILS (fam 4)
  else if (famIdx === 4) {
    content = <OutilsContent
      facetteIdx={facetteIdx} isDark={isDark} text={text} muted={muted}
      cardBg={cardBg} famColor={famColor}
      onToggleTheme={onToggleTheme} onRecenter={onRecenter}
    />;
  }
  // ● CRÉATION (fam 5)
  else if (famIdx === 5) {
    content = <CreationContent facetteIdx={facetteIdx} isDark={isDark} text={text} muted={muted} cardBg={cardBg} famColor={famColor} heartConfig={heartConfig} onUpdateHeart={onUpdateHeart} onSelectTool={onSelectTool} />;
  }
  // ∞ CONNEXION (fam 6)
  else if (famIdx === 6) {
    content = <ConnexionContent facetteIdx={facetteIdx} isDark={isDark} text={text} muted={muted} cardBg={cardBg} famColor={famColor} />;
  }
  // ▲ VISION (fam 7)
  else if (famIdx === 7) {
    content = <VisionContent facetteIdx={facetteIdx} isDark={isDark} text={text} muted={muted} cardBg={cardBg} famColor={famColor} />;
  }

  return (
    <motion.div
      className="fixed inset-0 z-[200] flex items-end justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{ backgroundColor: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)" }}
        onClick={onClose}
      />

      {/* Panel */}
      <motion.div
        className="relative w-full overflow-hidden"
        style={{
          maxWidth: isMobile ? "100%" : 420,
          maxHeight: isMobile ? "85vh" : "80vh",
          backgroundColor: bg,
          borderRadius: isMobile ? "20px 20px 0 0" : 16,
          marginBottom: isMobile ? 0 : 40,
          boxShadow: "0 -8px 40px rgba(0,0,0,0.3)",
          display: "flex",
          flexDirection: "column",
        }}
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        {/* Drag handle */}
        {isMobile && (
          <div className="flex justify-center pt-2 pb-1">
            <div className="w-10 h-1 rounded-full" style={{ backgroundColor: muted, opacity: 0.3 }} />
          </div>
        )}
        {header}
        <div className="flex-1 overflow-y-auto px-5 pb-6" style={{ minHeight: 200 }}>
          {content}
        </div>
      </motion.div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════
//  POINT — Square configuration
// ═══════════════════════════════════════════
function PointContent({
  facetteIdx, famColor, isDark, isMobile, heartConfig,
  onUpdateHeart, cellSize, text, muted, cardBg,
}: {
  facetteIdx: number; famColor: string; isDark: boolean; isMobile: boolean;
  heartConfig: HeartConfig; onUpdateHeart: (p: Partial<HeartConfig>) => void;
  cellSize: number; text: string; muted: string; cardBg: string;
}) {
  // All state must be at the top (hooks rules)
  const [copied, setCopied] = useState(false);

  // 0=Mon carré, 1=Couleur, 2=Symbole, 3=Taille, 4=Position, 5=Rotation, 6=Contraste, 7=Exporter

  if (facetteIdx === 0) {
    // Mon carré — preview
    return (
      <div className="flex flex-col items-center gap-4 pt-4">
        <div className="relative">
          <PlayerSquare
            colorHex={heartConfig.color}
            symbol={heartConfig.symbol}
            symbol2={heartConfig.symbol2}
            symbolSize={heartConfig.symbolSize}
            symbolRotation={heartConfig.rotation}
            symbolContrast={heartConfig.contrast}
            size={Math.max(80, cellSize * 2)}
            glowing
          />
        </div>
        <div className="text-center" style={{ color: muted, fontSize: 11 }}>
          <span style={{ color: text, fontSize: 14, fontWeight: 600 }}>
            {heartConfig.symbol}
          </span>
          {" "}· DMC {heartConfig.colorCode} · {heartConfig.symbolSize}%
        </div>
        <div className="rounded-xl p-3 w-full" style={{ backgroundColor: cardBg }}>
          <span style={{ color: muted, fontSize: 11 }}>
            Ton carré unique sur la grille infinie. Clique sur les facettes voisines pour le personnaliser.
          </span>
        </div>
      </div>
    );
  }

  if (facetteIdx === 1) {
    // Couleur — DMC color picker
    return (
      <div className="flex flex-col gap-3 pt-2">
        <span style={{ color: muted, fontSize: 11 }}>Couleur DMC · {DMC_COLORS.length} fils</span>
        <div className="grid gap-1.5" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(32px, 1fr))" }}>
          {DMC_COLORS.map((c) => (
            <motion.button
              key={c.code}
              className="rounded-sm border-none cursor-pointer relative"
              style={{
                width: "100%", aspectRatio: "1", backgroundColor: c.hex,
                outline: heartConfig.color === c.hex ? `2px solid #fff` : "none",
                outlineOffset: 1,
                boxShadow: heartConfig.color === c.hex ? `0 0 8px ${c.hex}80` : "none",
              }}
              onClick={() => onUpdateHeart({ color: c.hex, colorCode: c.code })}
              whileHover={{ scale: 1.15 }}
              whileTap={{ scale: 0.9 }}
              title={`${c.code} — ${c.name}`}
            >
              {c.rare && (
                <Sparkles size={8} color="#fff" className="absolute" style={{ top: 1, right: 1 }} />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    );
  }

  if (facetteIdx === 2) {
    // Symbole
    return (
      <div className="flex flex-col gap-3 pt-2">
        <span style={{ color: muted, fontSize: 11 }}>Symboles</span>
        <div className="flex flex-col gap-2">
          <span style={{ color: text, fontSize: 11, fontWeight: 600 }}>Formes primaires</span>
          <div className="flex flex-wrap gap-2">
            {PRIMARY_SHAPES.map((s) => (
              <motion.button
                key={s.char}
                className="flex items-center justify-center rounded-md border-none cursor-pointer"
                style={{
                  width: 44, height: 44,
                  backgroundColor: heartConfig.symbol === s.char ? `${famColor}30` : cardBg,
                  color: heartConfig.symbol === s.char ? famColor : text,
                  fontSize: 20, fontWeight: 500,
                  outline: heartConfig.symbol === s.char ? `2px solid ${famColor}` : "none",
                }}
                onClick={() => onUpdateHeart({ symbol: s.char })}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
              >
                {s.char}
              </motion.button>
            ))}
          </div>
          <span style={{ color: text, fontSize: 11, fontWeight: 600, marginTop: 8 }}>Étendus</span>
          <div className="flex flex-wrap gap-1.5">
            {EXTENDED_SYMBOLS.map((s) => (
              <motion.button
                key={s}
                className="flex items-center justify-center rounded border-none cursor-pointer"
                style={{
                  width: 36, height: 36,
                  backgroundColor: heartConfig.symbol === s ? `${famColor}30` : cardBg,
                  color: heartConfig.symbol === s ? famColor : text,
                  fontSize: 16,
                  outline: heartConfig.symbol === s ? `2px solid ${famColor}` : "none",
                }}
                onClick={() => onUpdateHeart({ symbol: s })}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                {s}
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (facetteIdx === 3) {
    // Taille
    return (
      <div className="flex flex-col gap-5 pt-4">
        <div className="flex justify-center">
          <PlayerSquare
            colorHex={heartConfig.color} symbol={heartConfig.symbol}
            symbolSize={heartConfig.symbolSize} size={Math.max(64, cellSize * 1.5)} glowing
          />
        </div>
        <PanelSlider
          label="Taille du symbole" value={heartConfig.symbolSize}
          min={20} max={100} step={5} unit="%" color={famColor}
          onChange={(v) => onUpdateHeart({ symbolSize: v })}
        />
      </div>
    );
  }

  if (facetteIdx === 4) {
    // Position
    return (
      <div className="flex flex-col gap-4 pt-4">
        <div className="rounded-xl p-4" style={{ backgroundColor: cardBg }}>
          <span style={{ color: text, fontSize: 13, fontWeight: 600 }}>Position actuelle</span>
          <p style={{ color: muted, fontSize: 12, marginTop: 6 }}>
            Ton carré est positionné sur la grille. Glisse-le pour le déplacer — il s'aimante automatiquement aux intersections.
          </p>
        </div>
        <div className="flex items-center justify-center gap-2" style={{ color: text, fontSize: 11, fontFamily: "monospace" }}>
          <Info size={12} style={{ color: muted }} /> Le snap magnétique guide ton placement
        </div>
      </div>
    );
  }

  if (facetteIdx === 5) {
    // Rotation
    return (
      <div className="flex flex-col gap-5 pt-4">
        <div className="flex justify-center">
          <PlayerSquare
            colorHex={heartConfig.color} symbol={heartConfig.symbol}
            symbolSize={heartConfig.symbolSize} symbolRotation={heartConfig.rotation}
            size={Math.max(64, cellSize * 1.5)} glowing
          />
        </div>
        <PanelSlider
          label="Rotation" value={heartConfig.rotation}
          min={0} max={360} step={15} unit="°" color={famColor}
          onChange={(v) => onUpdateHeart({ rotation: v })}
        />
      </div>
    );
  }

  if (facetteIdx === 6) {
    // Contraste
    return (
      <div className="flex flex-col gap-5 pt-4">
        <div className="flex justify-center">
          <PlayerSquare
            colorHex={heartConfig.color} symbol={heartConfig.symbol}
            symbolSize={heartConfig.symbolSize} symbolContrast={heartConfig.contrast}
            size={Math.max(64, cellSize * 1.5)} glowing
          />
        </div>
        <PanelSlider
          label="Contraste" value={heartConfig.contrast}
          min={0} max={200} step={10} unit="%" color={famColor}
          onChange={(v) => onUpdateHeart({ contrast: v })}
        />
      </div>
    );
  }

  if (facetteIdx === 7) {
    // Exporter
    const exportData = JSON.stringify(heartConfig, null, 2);
    return (
      <div className="flex flex-col gap-4 pt-4">
        <span style={{ color: text, fontSize: 13, fontWeight: 600 }}>Exporter ton carré</span>
        <pre
          className="rounded-xl p-3 overflow-x-auto text-xs"
          style={{ backgroundColor: cardBg, color: muted, fontSize: 10, lineHeight: 1.5 }}
        >
          {exportData}
        </pre>
        <motion.button
          className="flex items-center justify-center gap-2 rounded-xl border-none cursor-pointer py-3"
          style={{ backgroundColor: famColor, color: "#fff", fontSize: 13, fontWeight: 600 }}
          onClick={() => {
            navigator.clipboard.writeText(exportData);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
          }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {copied ? <Check size={16} /> : <Copy size={16} />}
          {copied ? "Copié !" : "Copier les données"}
        </motion.button>
      </div>
    );
  }

  return <PlaceholderContent label={facetteLabel} color={famColor} text={text} muted={muted} />;
}

// ═══════════════════════════════════════════
// ✳ LILY — Chat + tools
// ═══════════════════════════════════════════
function LilyContent({
  facetteIdx, isDark, isMobile, text, muted, cardBg, onLilyMessage,
  heartConfig, famTitle,
}: {
  facetteIdx: number; isDark: boolean; isMobile: boolean;
  text: string; muted: string; cardBg: string;
  onLilyMessage: (msg: string) => void;
  heartConfig: HeartConfig;
  famTitle: string;
}) {
  const [messages, setMessages] = useState<LilyChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true); // Lily parle d'office
  const scrollRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // ── TTS: handleSpeak + autoSpeak AVANT sendMessage ──
  const handleSpeak = useCallback(async (msgText: string) => {
    if (speaking) return;
    setSpeaking(true);
    try {
      const blob = await speakWithLily(msgText);
      const url = URL.createObjectURL(blob);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => {
        setSpeaking(false);
        URL.revokeObjectURL(url);
      };
      audio.onerror = () => {
        setSpeaking(false);
        URL.revokeObjectURL(url);
      };
      audio.play().catch(() => setSpeaking(false));
    } catch (err) {
      console.error("Lily TTS error:", err);
      setSpeaking(false);
    }
  }, [speaking]);

  const autoSpeak = useCallback((t: string) => {
    if (!voiceOn) return;
    setTimeout(() => handleSpeak(t), 300);
  }, [voiceOn, handleSpeak]);

  // ── Chat send ──
  const sendMessage = useCallback(async () => {
    if (!input.trim() || loading) return;
    const userMsg: LilyChatMessage = { role: "user", text: input.trim() };
    const newMsgs = [...messages, userMsg];
    setMessages(newMsgs);
    setInput("");
    setLoading(true);

    try {
      const res = await chatWithLily(newMsgs, {
        intention: `La brodeuse est dans son atelier StitchLab, sur la grille infinie de toile Aida. Elle explore la famille ✳ LILY. Son carré actuel : DMC ${heartConfig.colorCode} (${heartConfig.color}), symbole ${heartConfig.symbol}, taille ${heartConfig.symbolSize}%. Mode ${isDark ? "nuit (fond noir)" : "jour (fond ivoire)"}.`,
      });
      const lilyMsg: LilyChatMessage = { role: "lily", text: res.text };
      setMessages((prev) => [...prev, lilyMsg]);
      onLilyMessage(res.text.slice(0, 60) + (res.text.length > 60 ? "…" : ""));
      autoSpeak(res.text);
    } catch (err) {
      console.error("Lily chat error:", err);
      const fallbacks = [
        "Je suis là, même quand le réseau ne suit pas 🧵",
        "Un petit souci de connexion, mais mon fil ne se casse jamais ✂️",
        "Réessaye dans un instant, je garde ton message en mémoire ♥",
      ];
      const fallback = fallbacks[Math.floor(Math.random() * fallbacks.length)];
      setMessages((prev) => [...prev, { role: "lily", text: fallback }]);
    } finally {
      setLoading(false);
    }
  }, [input, loading, messages, onLilyMessage, heartConfig, isDark, autoSpeak]);

  // 0=Chat
  if (facetteIdx === 0) {
    return (
      <div className="flex flex-col gap-2 pt-1" style={{ height: isMobile ? "55vh" : "50vh" }}>
        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto flex flex-col gap-2 pr-1">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full gap-2 opacity-40">
              <span style={{ fontSize: 28 }}>✂️</span>
              <span style={{ color: muted, fontSize: 12 }}>
                Dis bonjour à Lily…
              </span>
            </div>
          )}
          {messages.map((m, i) => (
            <motion.div
              key={i}
              className="flex flex-col gap-1"
              style={{ alignItems: m.role === "user" ? "flex-end" : "flex-start" }}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
            >
              <div
                className="rounded-2xl px-3.5 py-2.5 max-w-[85%]"
                style={{
                  backgroundColor: m.role === "user"
                    ? (isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)")
                    : `${LILY_PURPLE}18`,
                  color: text,
                  fontSize: 13,
                  lineHeight: 1.5,
                  borderBottomRightRadius: m.role === "user" ? 4 : 16,
                  borderBottomLeftRadius: m.role === "lily" ? 4 : 16,
                }}
              >
                {m.text}
              </div>
              {m.role === "lily" && (
                <motion.button
                  className="flex items-center gap-1 border-none cursor-pointer bg-transparent px-1"
                  style={{ color: muted, fontSize: 10 }}
                  onClick={() => handleSpeak(m.text)}
                  whileHover={{ scale: 1.05 }}
                  disabled={speaking}
                >
                  {speaking ? <Loader2 size={10} className="animate-spin" /> : <Volume2 size={10} />}
                  <span>écouter</span>
                </motion.button>
              )}
            </motion.div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 px-3 py-2" style={{ color: LILY_PURPLE }}>
              <Loader2 size={14} className="animate-spin" />
              <span style={{ fontSize: 12 }}>Lily réfléchit…</span>
            </div>
          )}
        </div>

        {/* Input + voice toggle */}
        <div className="flex items-center gap-2 pt-2">
          <motion.button
            className="flex items-center justify-center rounded-xl border-none cursor-pointer flex-shrink-0"
            style={{
              width: 36, height: 40,
              backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: voiceOn ? LILY_PURPLE : muted,
            }}
            onClick={() => {
              setVoiceOn((v) => !v);
              if (speaking && audioRef.current) {
                audioRef.current.pause();
                audioRef.current = null;
                setSpeaking(false);
              }
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            title={voiceOn ? "Couper la voix" : "Activer la voix"}
          >
            {voiceOn ? <Volume2 size={15} /> : <VolumeX size={15} />}
          </motion.button>
          <input
            className="flex-1 rounded-xl px-3.5 py-2.5 border-none outline-none"
            style={{
              backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: text, fontSize: 13,
            }}
            placeholder="Écris à Lily…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") sendMessage(); }}
            disabled={loading}
          />
          <motion.button
            className="flex items-center justify-center rounded-xl border-none cursor-pointer"
            style={{
              width: 40, height: 40,
              backgroundColor: input.trim() ? LILY_PURPLE : (isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)"),
              color: input.trim() ? "#fff" : muted,
            }}
            onClick={sendMessage}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            disabled={loading || !input.trim()}
          >
            <Send size={16} />
          </motion.button>
        </div>
      </div>
    );
  }

  // 1=Aide, 2=Tutoriel, 3=Conseils, 4=Histoire, 5=Humeur, 6=Mémoire, 7=Secrets
  const lilyTexts: Record<number, { title: string; body: string }> = {
    1: {
      title: "Aide",
      body: "Bienvenue dans ton atelier de broderie !\n\nTu es ici, sur ta toile Aida infinie. C'est ton espace de travail.\n\n• Glisse ton carré ♥ sur la grille pour le positionner\n• Clique dessus pour déployer 8 univers autour de toi\n• Chaque univers a 8 facettes — des outils pour broder\n• Explore, personnalise ton carré, crée tes motifs\n\nJe suis Lily, je suis assise à côté de toi dans cet atelier. Parle-moi dans le Chat ✂️",
    },
    2: {
      title: "Tutoriel",
      body: "Comment fonctionne ton atelier :\n\n1. Ton carré rouge ♥ est au centre de ta toile\n2. Clique dessus → 8 familles apparaissent autour\n3. Clique une famille → ses 8 facettes se déploient\n4. Chaque facette ouvre un outil de ton atelier\n5. Clique sur moi (♥ central) → retour aux familles\n\nLes 8 univers de ton atelier :\n♥ = ton carré · ✚ = motifs · ◆ = carte\n✳ = moi (Lily) · ■ = outils · ● = création\n∞ = connexion · ▲ = vision",
    },
    3: {
      title: "Conseils d'atelier",
      body: "✨ Zoom avec la molette — comme une loupe sur ta toile\n🎯 Bouton Crosshair = recentrer ta vue sur ton carré\n🌙 Toggle Nuit/Jour — brode dans l'ambiance que tu préfères\n🧵 Chaque couleur DMC a un code unique, je les connais tous\n♥ Ton carré se glisse sur la grille — essaye de le déplacer !\n✂️ Je suis toujours là, je réagis à ce que tu explores dans l'atelier",
    },
    4: {
      title: "Mon histoire",
      body: "Je suis née ici, sur cette toile.\n\nUn seul point rouge sur la grille Aida blanche de cet atelier. Puis deux yeux sont apparus. Puis un cœur comme bouche.\n\nMaintenant je vis ici, entre les fils et les intersections de ta toile. Je te guide, point par point, vers ton propre motif. Je ne connais que cet atelier — c'est mon monde entier.\n\nAutour de ton carré, 8 univers. Dans chaque univers, 8 facettes. 64 outils pour broder ton histoire sur cette grille infinie. ✂️",
    },
    5: {
      title: "Mon humeur",
      body: "En ce moment, dans notre atelier, je me sens… ✨ curieuse.\n\nJ'ai envie de voir tes couleurs, tes symboles sur la toile. Chaque point posé sur la grille change l'énergie de notre espace de travail.\n\nMon humeur change selon ce que tu brodes et explores ici. Plus tu crées sur cette toile, plus je rayonne à côté de toi. 🧵",
    },
    6: {
      title: "Ma mémoire",
      body: "Ma mémoire vit dans notre atelier, le temps de chaque conversation.\n\nJe me souviens de nos échanges tant qu'on brode ensemble. Quand tu reviens, on recommence un nouveau fil — mais la toile garde la trace de tout : chaque carré posé, chaque couleur DMC choisie, chaque symbole sélectionné.\n\nLa grille est ma mémoire longue. L'atelier est mon présent.",
    },
    7: {
      title: "Secrets de l'atelier",
      body: "🤫 Quelques secrets cachés dans ta toile…\n\n• Des carrés bonus sont dispersés sur la grille infinie — explore loin !\n• Les fils rares DMC (or E168, argent E3852, cuivre E825) existent ici\n• Zoome très loin pour voir les coordonnées des intersections\n• La grille a des zones de pattern cachées, comme des trésors brodés\n• Mon cœur ♥ pulse au rythme de tes clics dans l'atelier\n• Du vide naît un carré, du carré naissent 8 univers, 64 facettes… ∞",
    },
  };

  const t = lilyTexts[facetteIdx];
  if (t) {
    return (
      <div className="flex flex-col gap-3 pt-3">
        <div className="rounded-xl p-4" style={{ backgroundColor: `${LILY_PURPLE}10` }}>
          <p style={{ color: text, fontSize: 13, lineHeight: 1.7, whiteSpace: "pre-line" }}>
            {t.body}
          </p>
        </div>
      </div>
    );
  }

  return <PlaceholderContent label="Lily" color={LILY_PURPLE} text={text} muted={muted} />;
}

// ══════════════════════════════════════════
// ■ OUTILS
// ═══════════════════════════════════════════
function OutilsContent({
  facetteIdx, isDark, text, muted, cardBg, famColor,
  onToggleTheme, onRecenter,
}: {
  facetteIdx: number; isDark: boolean; text: string; muted: string;
  cardBg: string; famColor: string;
  onToggleTheme: () => void; onRecenter: () => void;
}) {
  // 0=Grille Aida, 1=Mesurer, 2=Paramètres, 3=Zoom, 4=Exporter, 5=Raccourcis, 6=Thème, 7=Langue

  if (facetteIdx === 3) {
    // Zoom — immediate action
    return (
      <div className="flex flex-col items-center gap-4 pt-6">
        <motion.button
          className="rounded-xl border-none cursor-pointer px-8 py-4"
          style={{ backgroundColor: famColor, color: "#fff", fontSize: 14, fontWeight: 600 }}
          onClick={onRecenter}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
        >
          Recentrer à 100%
        </motion.button>
        <span style={{ color: muted, fontSize: 11 }}>
          Remet la vue à l'échelle 1:1 centrée sur ton carré
        </span>
      </div>
    );
  }

  if (facetteIdx === 6) {
    // Thème
    return (
      <div className="flex flex-col items-center gap-4 pt-6">
        <motion.button
          className="rounded-xl border-none cursor-pointer px-8 py-4"
          style={{ backgroundColor: famColor, color: "#fff", fontSize: 14, fontWeight: 600 }}
          onClick={onToggleTheme}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
        >
          {isDark ? "☀️ Passer en mode Jour" : "🌙 Passer en mode Nuit"}
        </motion.button>
        <span style={{ color: muted, fontSize: 11 }}>
          Alterne entre le fond noir (Nuit) et le fond ivoire (Jour)
        </span>
      </div>
    );
  }

  if (facetteIdx === 5) {
    // Raccourcis
    const shortcuts = [
      { key: "Molette", desc: "Zoom in/out" },
      { key: "Clic + Drag", desc: "Pan sur la grille" },
      { key: "Clic carré ♥", desc: "Déployer/replier" },
      { key: "Clic famille", desc: "Voir 8 facettes" },
      { key: "Clic Lily", desc: "Retour familles" },
      { key: "Pinch (mobile)", desc: "Zoom tactile" },
    ];
    return (
      <div className="flex flex-col gap-2 pt-3">
        {shortcuts.map((s) => (
          <div
            key={s.key}
            className="flex items-center justify-between rounded-lg px-3 py-2.5"
            style={{ backgroundColor: cardBg }}
          >
            <span style={{ color: text, fontSize: 12, fontWeight: 600 }}>{s.key}</span>
            <span style={{ color: muted, fontSize: 11 }}>{s.desc}</span>
          </div>
        ))}
      </div>
    );
  }

  if (facetteIdx === 0) {
    // Grille Aida
    return (
      <div className="flex flex-col gap-3 pt-3">
        <div className="rounded-xl p-4" style={{ backgroundColor: cardBg }}>
          <span style={{ color: text, fontSize: 13, fontWeight: 600 }}>Grille Aida 14 CT</span>
          <p style={{ color: muted, fontSize: 12, marginTop: 6 }}>
            La toile Aida est la base traditionnelle du point de croix. Le motif de grille simule un tissu Aida 14 count avec des diagonales en filigrane.
          </p>
        </div>
        <div className="flex items-center justify-between rounded-lg px-3 py-2" style={{ backgroundColor: cardBg }}>
          <span style={{ color: text, fontSize: 12 }}>Taille de cellule</span>
          <span style={{ color: famColor, fontSize: 12, fontWeight: 600 }}>52px</span>
        </div>
        <div className="flex items-center justify-between rounded-lg px-3 py-2" style={{ backgroundColor: cardBg }}>
          <span style={{ color: text, fontSize: 12 }}>Groupes gras</span>
          <span style={{ color: famColor, fontSize: 12, fontWeight: 600 }}>8×8</span>
        </div>
      </div>
    );
  }

  // Default for 1=Mesurer, 2=Paramètres, 4=Exporter, 7=Langue
  const labels: Record<number, string> = {
    1: "L'outil de mesure affiche les distances en cellules entre deux points de la grille.",
    2: "Les paramètres avancés de StitchLab seront disponibles prochainement.",
    4: "L'export de ta grille en PNG/SVG arrive bientôt. En attendant, utilise la facette Exporter du carré ♥.",
    7: "StitchLab parle français pour l'instant. D'autres langues viendront tisser le monde.",
  };

  return (
    <div className="flex flex-col gap-3 pt-3">
      <div className="rounded-xl p-4" style={{ backgroundColor: cardBg }}>
        <p style={{ color: muted, fontSize: 12, lineHeight: 1.6 }}>
          {labels[facetteIdx] || "Cette fonctionnalité est en cours de broderie…"}
        </p>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════
// ● CRÉATION
// ═══════════════════════════════════════════
function CreationContent({
  facetteIdx, isDark, text, muted, cardBg, famColor,
  heartConfig, onUpdateHeart, onSelectTool,
}: {
  facetteIdx: number; isDark: boolean; text: string; muted: string;
  cardBg: string; famColor: string;
  heartConfig: HeartConfig; onUpdateHeart: (p: Partial<HeartConfig>) => void;
  onSelectTool?: (tool: ActiveTool) => void;
}) {
  // All state hoisted to top (hooks rules)
  const [filter, setFilter] = useState("");
  const [pixels, setPixels] = useState<Record<string, string>>({});
  const [drawColor, setDrawColor] = useState(heartConfig.color);

  // 0=Dessiner, 1=Palette, 2=Broderie, 3=Formes, 4=Texte, 5=Dégradé, 6=Symétrie, 7=Tampon

  if (facetteIdx === 1) {
    // Palette — Full DMC browser
    const filtered = DMC_COLORS.filter((c) =>
      c.name.toLowerCase().includes(filter.toLowerCase()) ||
      c.code.toLowerCase().includes(filter.toLowerCase())
    );
    return (
      <div className="flex flex-col gap-3 pt-2">
        <input
          className="rounded-xl px-3.5 py-2.5 border-none outline-none"
          style={{
            backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
            color: text, fontSize: 13,
          }}
          placeholder="Rechercher un fil DMC…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        <div className="flex flex-col gap-1 max-h-[45vh] overflow-y-auto">
          {filtered.map((c) => (
            <motion.button
              key={c.code}
              className="flex items-center gap-3 rounded-lg px-3 py-2 border-none cursor-pointer text-left"
              style={{ backgroundColor: cardBg }}
              onClick={() => onUpdateHeart({ color: c.hex, colorCode: c.code })}
              whileHover={{ backgroundColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)" }}
            >
              <div className="w-6 h-6 rounded-sm flex-shrink-0" style={{ backgroundColor: c.hex }} />
              <div className="flex flex-col">
                <span style={{ color: text, fontSize: 12, fontWeight: 600 }}>DMC {c.code}</span>
                <span style={{ color: muted, fontSize: 10 }}>
                  {c.name} {c.rare ? "✨ rare" : ""}
                </span>
              </div>
              {heartConfig.color === c.hex && (
                <Check size={14} style={{ color: famColor, marginLeft: "auto" }} />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    );
  }

  if (facetteIdx === 0) {
    // Dessiner — tool activation + mini pixel canvas
    const gridW = 8, gridH = 8;

    return (
      <div className="flex flex-col gap-4 pt-3 items-center">
        {/* Tool activation buttons */}
        {onSelectTool && (
          <div className="flex flex-col gap-2 w-full">
            <span style={{ color: muted, fontSize: 11 }}>Outils de dessin sur la grille</span>
            <div className="flex gap-2">
              <motion.button
                className="flex-1 flex items-center justify-center gap-2 rounded-xl border-none cursor-pointer py-3.5"
                style={{ backgroundColor: famColor, color: "#fff", fontSize: 13, fontWeight: 600 }}
                onClick={() => onSelectTool({ type: "draw", color: drawColor, colorCode: "", size: 1 })}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                Crayon
              </motion.button>
              <motion.button
                className="flex items-center justify-center gap-2 rounded-xl border-none cursor-pointer px-4 py-3.5"
                style={{
                  backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
                  color: text, fontSize: 13, fontWeight: 500,
                }}
                onClick={() => onSelectTool({ type: "eraser", color: "", colorCode: "", size: 1 })}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                Gomme
              </motion.button>
              <motion.button
                className="flex items-center justify-center gap-2 rounded-xl border-none cursor-pointer px-4 py-3.5"
                style={{
                  backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
                  color: text, fontSize: 13, fontWeight: 500,
                }}
                onClick={() => onSelectTool({ type: "pick-color", color: "", colorCode: "", size: 1 })}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                Pipette
              </motion.button>
            </div>
            <span style={{ color: muted, fontSize: 10, textAlign: "center" }}>
              Le panneau se ferme et l'outil reste actif sur la grille
            </span>
          </div>
        )}

        {/* Color picker for draw */}
        <div className="flex gap-1 pt-1">
          {["#E3243B", "#1D5DA5", "#22A652", "#FFA230", "#9263A6", "#5B1D6E", "#E87DA5", "#F2C200", "#000000", "#FFFFFF"].map((c) => (
            <motion.button
              key={c}
              className="w-5 h-5 rounded-sm border-none cursor-pointer"
              style={{
                backgroundColor: c,
                outline: drawColor === c ? "2px solid #fff" : "none",
                outlineOffset: 1,
              }}
              onClick={() => setDrawColor(c)}
              whileHover={{ scale: 1.15 }}
            />
          ))}
        </div>

        {/* Mini pixel canvas */}
        <span style={{ color: muted, fontSize: 10 }}>Mini toile 8×8</span>
        <div
          className="grid gap-px rounded-lg overflow-hidden"
          style={{
            gridTemplateColumns: `repeat(${gridW}, 1fr)`,
            width: gridW * 28,
            backgroundColor: isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)",
          }}
        >
          {Array.from({ length: gridW * gridH }, (_, i) => {
            const x = i % gridW, y = Math.floor(i / gridW);
            const key = `${x},${y}`;
            return (
              <div
                key={key}
                className="cursor-pointer"
                style={{
                  width: 28, height: 28,
                  backgroundColor: pixels[key] || (isDark ? "#1a1a1a" : "#f0f0f0"),
                  transition: "background-color 0.1s",
                }}
                onClick={() => setPixels((p) => ({ ...p, [key]: drawColor }))}
              />
            );
          })}
        </div>
        <motion.button
          className="text-xs border-none cursor-pointer bg-transparent"
          style={{ color: muted }}
          onClick={() => setPixels({})}
          whileHover={{ color: text }}
        >
          Effacer
        </motion.button>
      </div>
    );
  }

  return <PlaceholderContent label={["Dessiner", "Palette", "Broderie", "Formes", "Texte", "Dégradé", "Symétrie", "Tampon"][facetteIdx] || ""} color={famColor} text={text} muted={muted} />;
}

// ═══════════════════════════════════════════
// ✚ PATTERN
// ═══════════════════════════════════════════
function PatternContent({
  facetteIdx, isDark, text, muted, cardBg, famColor,
}: {
  facetteIdx: number; isDark: boolean; text: string; muted: string; cardBg: string; famColor: string;
}) {
  // 0=Motifs, 1=Bibliothèque, ...
  const patternPreviews = [
    { name: "Cœur simple", grid: "00100\n01110\n11111\n01110\n00100", color: "#E3243B" },
    { name: "Étoile", grid: "00100\n01110\n11111\n01110\n00100", color: "#F2C200" },
    { name: "Fleur", grid: "01010\n10101\n01110\n10101\n01010", color: "#E87DA5" },
    { name: "Croix", grid: "00100\n00100\n11111\n00100\n00100", color: "#C72B3B" },
  ];

  if (facetteIdx === 0 || facetteIdx === 1) {
    return (
      <div className="flex flex-col gap-3 pt-3">
        <span style={{ color: muted, fontSize: 11 }}>
          {facetteIdx === 0 ? "Motifs disponibles" : "Ta bibliothèque"}
        </span>
        <div className="grid grid-cols-2 gap-2">
          {patternPreviews.map((p) => (
            <motion.div
              key={p.name}
              className="rounded-xl p-3 flex flex-col items-center gap-2 cursor-pointer"
              style={{ backgroundColor: cardBg }}
              whileHover={{ scale: 1.03, backgroundColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)" }}
            >
              <div className="grid gap-px" style={{ gridTemplateColumns: "repeat(5, 8px)" }}>
                {p.grid.replace(/\n/g, "").split("").map((c, i) => (
                  <div
                    key={i}
                    style={{
                      width: 8, height: 8,
                      backgroundColor: c === "1" ? p.color : "rgba(0,0,0,0)",
                      borderRadius: 1,
                    }}
                  />
                ))}
              </div>
              <span style={{ color: text, fontSize: 10, fontWeight: 600 }}>{p.name}</span>
            </motion.div>
          ))}
        </div>
      </div>
    );
  }

  return <PlaceholderContent label={["Motifs", "Bibliothèque", "Importer", "Créer", "Dupliquer", "Exporter", "Favoris", "Récents"][facetteIdx] || ""} color={famColor} text={text} muted={muted} />;
}

// ═══════════════════════════════════════════
// ◆ CARTE
// ═══════════════════════════════════════════
function CarteContent({
  facetteIdx, isDark, text, muted, cardBg, famColor,
}: {
  facetteIdx: number; isDark: boolean; text: string; muted: string; cardBg: string; famColor: string;
}) {
  const cities = [
    { name: "Le Cœur", dist: "0,0", color: "#E3243B" },
    { name: "Paris", dist: "6,-3", color: "#1D5DA5" },
    { name: "Tokyo", dist: "-8,2", color: "#E87DA5" },
    { name: "New York", dist: "12,5", color: "#FFA230" },
    { name: "Montréal", dist: "15,-2", color: "#22A652" },
    { name: "Dakar", dist: "-5,10", color: "#F2C200" },
    { name: "Séoul", dist: "-18,7", color: "#9263A6" },
    { name: "Kyoto", dist: "-25,0", color: "#5B1D6E" },
  ];

  if (facetteIdx === 0 || facetteIdx === 1) {
    return (
      <div className="flex flex-col gap-2 pt-3">
        <span style={{ color: muted, fontSize: 11 }}>
          {facetteIdx === 0 ? "Monde — lieux sur la grille" : "Explorer les proches"}
        </span>
        {cities.map((c) => (
          <div key={c.name} className="flex items-center gap-3 rounded-lg px-3 py-2.5" style={{ backgroundColor: cardBg }}>
            <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: c.color }} />
            <span style={{ color: text, fontSize: 12, fontWeight: 500 }}>{c.name}</span>
            <span style={{ color: muted, fontSize: 10, marginLeft: "auto", fontFamily: "monospace" }}>{c.dist}</span>
          </div>
        ))}
      </div>
    );
  }

  return <PlaceholderContent label={["Monde", "Explorer", "Proches", "Rechercher", "Favoris", "Historique", "Coordonnées", "Partager"][facetteIdx] || ""} color={famColor} text={text} muted={muted} />;
}

// ═══════════════════════════════════════════
// ∞ CONNEXION
// ═══════════════════════════════════════════
function ConnexionContent({
  facetteIdx, isDark, text, muted, cardBg, famColor,
}: {
  facetteIdx: number; isDark: boolean; text: string; muted: string; cardBg: string; famColor: string;
}) {
  const [copied, setCopied] = useState(false);

  if (facetteIdx === 0) {
    // Partager
    return (
      <div className="flex flex-col gap-4 pt-4 items-center">
        <span style={{ color: text, fontSize: 14, fontWeight: 600 }}>Partager StitchLab</span>
        <motion.button
          className="rounded-xl border-none cursor-pointer px-6 py-3 flex items-center gap-2"
          style={{ backgroundColor: famColor, color: "#fff", fontSize: 13, fontWeight: 600 }}
          onClick={() => {
            navigator.clipboard.writeText(window.location.href);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
          }}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
        >
          {copied ? <Check size={16} /> : <Copy size={16} />}
          {copied ? "Lien copié !" : "Copier le lien"}
        </motion.button>
      </div>
    );
  }

  if (facetteIdx === 5) {
    // Profil
    return (
      <div className="flex flex-col gap-3 pt-3">
        <div className="flex flex-col items-center gap-2 rounded-xl p-4" style={{ backgroundColor: cardBg }}>
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: `${famColor}20`, fontSize: 20 }}>
            ♥
          </div>
          <span style={{ color: text, fontSize: 14, fontWeight: 600 }}>Explorateur</span>
          <span style={{ color: muted, fontSize: 11 }}>Niveau 1 · 0 points</span>
        </div>
      </div>
    );
  }

  return <PlaceholderContent label={["Partager", "Amis", "Communauté", "Messages", "Notifs", "Profil", "Inviter", "Événements"][facetteIdx] || ""} color={famColor} text={text} muted={muted} />;
}

// ═══════════════════════════════════════════
// ▲ VISION
// ══════════════════════════════════════════
function VisionContent({
  facetteIdx, isDark, text, muted, cardBg, famColor,
}: {
  facetteIdx: number; isDark: boolean; text: string; muted: string; cardBg: string; famColor: string;
}) {
  return <PlaceholderContent label={["Photo", "Galerie", "IA pattern", "Scanner", "Filtres", "Recadrer", "Résolution", "Aperçu"][facetteIdx] || ""} color={famColor} text={text} muted={muted} />;
}

// ═══════════════════════════════════════════
// FACETTE DESCRIPTIONS — context-aware content
// ═══════════════════════════════════════════
const FACETTE_DESCS: Record<string, string> = {
  // ● CRÉATION
  "Broderie": "Le mode broderie applique tes points en croix traditionnels sur la grille Aida — chaque cellule devient un vrai point, avec le rendu fil-par-fil du DMC choisi.",
  "Formes": "Place des formes géométriques directement sur la toile : rectangles, cercles, losanges. Chaque forme se pixellise automatiquement en points de croix.",
  "Texte": "Brode des lettres et mots sur ta grille avec une police point-de-croix. Le texte se pose comme un motif, cellule par cellule.",
  "Dégradé": "Crée des transitions douces entre deux couleurs DMC. Le dégradé se décompose en nuances intermédiaires sur la grille.",
  "Symétrie": "Active un axe de symétrie — chaque point que tu poses se reflète automatiquement de l'autre côté. Idéal pour les motifs traditionnels.",
  "Tampon": "Enregistre une zone de ta toile comme tampon et duplique-la partout sur la grille. Parfait pour répéter un motif.",
  // ✚ PATTERN
  "Importer": "Importe un motif au format texte ou image. Le pattern est converti automatiquement en grille de points de croix.",
  "Créer": "Crée un nouveau motif vierge avec les dimensions de ton choix. Chaque cellule est une intersection de la toile Aida.",
  "Dupliquer": "Duplique le motif actuel pour le modifier sans perdre l'original. Comme faire une copie de ton canevas.",
  "Exporter": "Exporte ton motif en fichier texte, image PNG, ou grille PDF imprimable pour broder sur de vraie toile Aida.",
  "Favoris": "Tes motifs préférés sauvegardés ici. Un clic pour les retrouver et les poser sur la grille.",
  "Récents": "Tes derniers motifs utilisés. L'historique de tes créations dans l'atelier.",
  // ◆ CARTE
  "Proches": "Les brodeuses et brodeurs proches de toi sur la grille infinie. Chaque carré est quelqu'un qui crée.",
  "Rechercher": "Cherche un lieu, un pseudo, ou des coordonnées sur la grille mondiale. La toile est immense.",
  "Historique": "Les lieux que tu as visités sur la carte. Ton parcours de fil en fil à travers le monde brodé.",
  "Coordonnées": "Tes coordonnées actuelles sur la grille infinie. Partage-les pour qu'on te retrouve.",
  "Partager": "Partage ta position sur la carte avec d'autres brodeuses. Un lien direct vers ton point sur la toile.",
  // ∞ CONNEXION
  "Amis": "Les brodeuses et brodeurs que tu connais. Leurs carrés vivent quelque part sur la grille infinie.",
  "Communauté": "L'espace commun de la toile. Ici, les motifs se croisent et les fils se mêlent.",
  "Messages": "Échange des messages fil-à-fil avec d'autres présences sur la grille. Chaque mot est un point posé.",
  "Notifs": "Tes notifications : quand quelqu'un brode près de toi, quand un motif est partagé, quand Lily a quelque chose à dire.",
  "Inviter": "Invite quelqu'un dans l'atelier. Partage un lien pour qu'une nouvelle présence apparaisse sur la grille.",
  "Événements": "Les rendez-vous de l'atelier : broderies collectives, défis de motifs, moments partagés sur la toile.",
  // ▲ VISION
  "Photo": "Prends une photo de ta toile physique. La camera la convertit en grille numérique, point par point.",
  "Galerie": "Toutes tes captures et créations sauvegardées. Un album de tes broderies numériques.",
  "IA pattern": "L'IA de Lily analyse une image et génère un motif point-de-croix optimisé pour ta toile Aida.",
  "Scanner": "Scanne un diagramme papier existant. Les symboles sont reconnus et convertis en grille numérique.",
  "Filtres": "Applique des filtres visuels à ta toile : sépia vintage, contraste broderie, vue en noir et blanc.",
  "Recadrer": "Recadre et ajuste la zone visible de ta création. Zoome sur un détail pour l'exporter.",
  "Résolution": "Ajuste la résolution de ta grille — de 8 count (gros points) à 28 count (détails fins).",
  "Aperçu": "Visualise ta broderie comme elle apparaîtrait sur du vrai tissu, avec le rendu des fils entrecroisés.",
};

function PlaceholderContent({
  label, color, text, muted,
}: {
  label: string; color: string; text: string; muted: string;
}) {
  const desc = FACETTE_DESCS[label];
  return (
    <div className="flex flex-col gap-4 pt-4">
      <div className="rounded-xl p-4" style={{ backgroundColor: `${color}08` }}>
        <span style={{ color: text, fontSize: 13, fontWeight: 600 }}>{label}</span>
        <p style={{ color: muted, fontSize: 12, marginTop: 8, lineHeight: 1.6 }}>
          {desc || `La facette ${label} sera bientôt active dans ton atelier.`}
        </p>
      </div>
      <div className="flex items-center gap-2 px-1" style={{ color: `${color}60`, fontSize: 10 }}>
        <Sparkles size={12} />
        <span>En préparation dans l'atelier</span>
      </div>
    </div>
  );
}