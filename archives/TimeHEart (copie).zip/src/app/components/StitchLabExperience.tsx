import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayerSquare } from "./PlayerSquare";
import { useResponsive } from "./useResponsive";
import { HEART_RED, DMC_COLORS } from "./game-data";
import {
  ArrowLeft, ArrowRight, Download,
  Camera, SkipForward, Sparkles, RotateCcw, User,
  Pipette, Hash, Timer, Palette, StickyNote, Scissors, Share2,
} from "lucide-react";

// ═══════════════════════════════════════════
// THE STITCHLAB EXPERIENCE — single screen
// iPad centered · 64 elements · photo → grid
// ═══════════════════════════════════════════

// ─── 64 ELEMENTS ─── (8 families × 8)
const FAMILIES = [
  { symbol: "♥", title: "POINT", color: "#E8177F" },
  { symbol: "✚", title: "PATTERN", color: "#C72B3B" },
  { symbol: "◆", title: "CARTE", color: "#22A652" },
  { symbol: "✳", title: "LILY", color: "#9263A6" },
  { symbol: "■", title: "OUTILS", color: "#FFA230" },
  { symbol: "●", title: "CRÉATION", color: "#1D5DA5" },
  { symbol: "∞", title: "CONNEXION", color: "#E87DA5" },
  { symbol: "▲", title: "VISION", color: "#5B1D6E" },
];

const ELEMENTS: { family: number; title: string; desc: string }[] = [
  // POINT (0-7)
  { family: 0, title: "Le Cube", desc: "6 faces, 6 dimensions de ton intention créative" },
  { family: 0, title: "Qui", desc: "Ton identité unique — un carré parmi des millions" },
  { family: 0, title: "Quoi", desc: "L'intention que tu portes ce jour" },
  { family: 0, title: "Où", desc: "L'endroit qui t'appelle sur la grille" },
  { family: 0, title: "Quand", desc: "Le moment juste pour poser ton point" },
  { family: 0, title: "Comment", desc: "La technique qui te parle" },
  { family: 0, title: "Pourquoi", desc: "La raison profonde de chaque geste" },
  { family: 0, title: "Avec qui", desc: "Les fils se croisent, les humains aussi" },
  // PATTERN (8-15)
  { family: 1, title: "Grille", desc: "Chaque pixel devient un point de croix" },
  { family: 1, title: "DMC", desc: "500 couleurs de fil réelles à portée de doigt" },
  { family: 1, title: "Photo → Grille", desc: "Ta photo transformée en broderie" },
  { family: 1, title: "Symboles", desc: "✕ ♥ ● ■ — un langage sur chaque case" },
  { family: 1, title: "Niveaux", desc: "Du carré simple au portrait complexe" },
  { family: 1, title: "Templates", desc: "Des motifs prêts à broder, offerts" },
  { family: 1, title: "Export PDF", desc: "La grille imprimable, haute définition" },
  { family: 1, title: "Rendu", desc: "Visualise le résultat avant de broder" },
  // CARTE (16-23)
  { family: 2, title: "Grille infinie", desc: "Le monde entier en point de croix" },
  { family: 2, title: "Géolocalisation", desc: "Ton carré posé là où tu es" },
  { family: 2, title: "Voisins", desc: "Qui brode autour de toi ?" },
  { family: 2, title: "Territoires", desc: "Des zones à découvrir en marchant" },
  { family: 2, title: "Chemins", desc: "Tes trajets deviennent des motifs" },
  { family: 2, title: "Points d'intérêt", desc: "Des trésors cachés sur la grille" },
  { family: 2, title: "Événements", desc: "Sorties broderie en vrai" },
  { family: 2, title: "Mémoire", desc: "L'histoire de chaque lieu, brodée" },
  // LILY (24-31)
  { family: 3, title: "IA créative", desc: "Elle brode des réponses avec toi" },
  { family: 3, title: "Voix", desc: "Elle te parle — voix Nova, douce" },
  { family: 3, title: "Couleurs", desc: "Elle t'aide à choisir ta palette" },
  { family: 3, title: "Narration", desc: "Elle raconte l'histoire de ton motif" },
  { family: 3, title: "Analyse", desc: "Elle lit et comprend ton pattern" },
  { family: 3, title: "Suggestion", desc: "Des motifs personnalisés rien que pour toi" },
  { family: 3, title: "Dialogue", desc: "Conversation ouverte, sans limites" },
  { family: 3, title: "Mémoire", desc: "Elle se souvient de toi" },
  // OUTILS (32-39)
  { family: 4, title: "Compteur", desc: "Compte chaque point posé" },
  { family: 4, title: "Timer", desc: "Mesure ton temps de création" },
  { family: 4, title: "Palette DMC", desc: "Référence couleurs toujours là" },
  { family: 4, title: "Conversion", desc: "RGB → DMC en un geste" },
  { family: 4, title: "Calculateur", desc: "Tissu, fils, dimensions — tout calculé" },
  { family: 4, title: "Notes", desc: "Ton journal de broderie" },
  { family: 4, title: "Ambiance", desc: "Musique douce pendant que tu brodes" },
  { family: 4, title: "Partage", desc: "Montre ton avancement au monde" },
  // CRÉATION (40-47)
  { family: 5, title: "Portrait", desc: "Ton visage brodé, point par point" },
  { family: 5, title: "Paysage", desc: "Un lieu transformé en broderie" },
  { family: 5, title: "Abstrait", desc: "Formes libres, expression pure" },
  { family: 5, title: "Typographie", desc: "Des mots brodés avec amour" },
  { family: 5, title: "Mandala", desc: "Motifs circulaires méditatifs" },
  { family: 5, title: "Pixel Art", desc: "Du numérique au fil" },
  { family: 5, title: "Collaboration", desc: "Broder un motif à plusieurs" },
  { family: 5, title: "Génératif", desc: "L'IA crée avec toi, en temps réel" },
  // CONNEXION (48-55)
  { family: 6, title: "Ton carré", desc: "Ton identité — couleur, symbole, intention" },
  { family: 6, title: "Intention", desc: "Ce que tu portes aujourd'hui" },
  { family: 6, title: "Rencontre", desc: "Croiser le carré de quelqu'un" },
  { family: 6, title: "Échange", desc: "Partager un symbole, créer un lien" },
  { family: 6, title: "Groupe", desc: "Broder ensemble autour d'une table" },
  { family: 6, title: "Événement", desc: "Une sortie créative partagée" },
  { family: 6, title: "Cadeau", desc: "Offrir un motif brodé" },
  { family: 6, title: "Liens tissés", desc: "Chaque fil croisé est une connexion" },
  // VISION (56-63)
  { family: 7, title: "Laboratoire", desc: "Tout peut changer — c'est un lab" },
  { family: 7, title: "Évolution", desc: "De nouvelles idées chaque semaine" },
  { family: 7, title: "Communauté", desc: "Construire ensemble, fil après fil" },
  { family: 7, title: "Open source", desc: "Ouvert, partagé, libre" },
  { family: 7, title: "Hardware", desc: "Un jour — la broderie connectée" },
  { family: 7, title: "Exposition", desc: "Galerie physique de vos oeuvres" },
  { family: 7, title: "Festival", desc: "StitchLab Live — on se retrouve" },
  { family: 7, title: "Infini", desc: "La grille n'a pas de fin. Toi non plus." },
];

// ─── PHASES ───
type Phase = "welcome" | "elements" | "square" | "profile" | "processing" | "result";

// ─── NEAREST DMC COLOR ───
function hexToRgb(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return { r, g, b };
}

const DMC_RGB = DMC_COLORS.filter((c) => !c.rare).map((c) => ({
  ...c,
  ...hexToRgb(c.hex),
}));

function nearestDMC(r: number, g: number, b: number) {
  let best = DMC_RGB[0];
  let bestDist = Infinity;
  for (const dmc of DMC_RGB) {
    const dr = dmc.r - r;
    const dg = dmc.g - g;
    const db = dmc.b - b;
    const dist = dr * dr + dg * dg + db * db;
    if (dist < bestDist) {
      bestDist = dist;
      best = dmc;
    }
  }
  return best;
}

// ─── GRID SYMBOLS ───
const GRID_SYMBOLS = ["✕", "♥", "●", "■", "▲", "◆", "✦", "★", "○", "□"];

// ─── MINI DOCK TOOLS (pictos) ───
const DOCK_TOOLS: { icon: typeof Pipette; color: string; label: string }[] = [
  { icon: Pipette,    color: "#C72B3B", label: "DMC" },
  { icon: Hash,       color: "#9263A6", label: "Compteur" },
  { icon: Timer,      color: "#42A350", label: "Timer" },
  { icon: Palette,    color: "#4685B7", label: "Palette" },
  { icon: StickyNote, color: "#FFB515", label: "Notes" },
  { icon: Camera,     color: "#EB5B2E", label: "Pattern" },
  { icon: Scissors,   color: "#9263A6", label: "Lily" },
  { icon: Share2,     color: "#6BA7B0", label: "Partage" },
];

// Grid positions for 8 neighbors around center [1,1]
// Order: N, NE, E, SE, S, SW, W, NW
const DOCK_POS: [number, number][] = [
  [1, 0], [2, 0], [2, 1], [2, 2],
  [1, 2], [0, 2], [0, 1], [0, 0],
];

function MiniDockAnimation() {
  const [step, setStep] = useState(0);
  // Cycle: 0-4 closed | 5-12 deploy one-by-one | 13-22 hold open | 23-30 close one-by-one | 31-35 closed
  const totalSteps = 36;

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((s) => (s + 1) % totalSteps);
    }, 380);
    return () => clearInterval(interval);
  }, []);

  const getToolVisible = (toolIndex: number) => {
    if (step >= 5 && step <= 12) {
      // Deploying: tool i appears at step 5+i
      return step >= 5 + toolIndex;
    } else if (step >= 13 && step <= 22) {
      // All visible
      return true;
    } else if (step >= 23 && step <= 30) {
      // Closing in reverse: tool 7 hides first at step 23, tool 0 at step 30
      return step < 23 + (8 - toolIndex);
    }
    return false;
  };

  // Is the center "breathing" (pulsing when closed)
  const centerPulsing = step < 5 || step > 30;

  const cellSize = 18;
  const gap = 3;
  const gridPx = cellSize * 3 + gap * 2;

  return (
    <div
      className="relative"
      style={{ width: gridPx, height: gridPx }}
    >
      {/* Center square — always visible */}
      <motion.div
        className="absolute rounded-[3px] flex items-center justify-center"
        style={{
          left: cellSize + gap,
          top: cellSize + gap,
          width: cellSize,
          height: cellSize,
          backgroundColor: "#1a1a1a",
          border: `1.5px solid ${centerPulsing ? HEART_RED + "60" : "rgba(255,255,255,0.1)"}`,
        }}
        animate={
          centerPulsing
            ? { boxShadow: [`0 0 6px ${HEART_RED}40`, `0 0 14px ${HEART_RED}60`, `0 0 6px ${HEART_RED}40`] }
            : { boxShadow: `0 0 4px ${HEART_RED}20` }
        }
        transition={centerPulsing ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : { duration: 0.3 }}
      >
        <span style={{ fontSize: 9, color: HEART_RED, lineHeight: 1 }}>♥</span>
      </motion.div>

      {/* 8 tool squares */}
      {DOCK_TOOLS.map((tool, i) => {
        const visible = getToolVisible(i);
        const [col, row] = DOCK_POS[i];
        const Icon = tool.icon;

        return (
          <AnimatePresence key={i}>
            {visible && (
              <motion.div
                className="absolute rounded-[3px] flex items-center justify-center"
                style={{
                  left: col * (cellSize + gap),
                  top: row * (cellSize + gap),
                  width: cellSize,
                  height: cellSize,
                  backgroundColor: `${tool.color}18`,
                  border: `1px solid ${tool.color}30`,
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{
                  scale: 1,
                  opacity: 1,
                  boxShadow: `0 0 8px ${tool.color}20`,
                }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ duration: 0.28, type: "spring", stiffness: 350, damping: 18 }}
              >
                <Icon size={9} color={tool.color} strokeWidth={1.5} />
              </motion.div>
            )}
          </AnimatePresence>
        );
      })}
    </div>
  );
}

interface StitchLabExperienceProps {
  onBack: () => void;
}

export function StitchLabExperience({ onBack }: StitchLabExperienceProps) {
  const { isMobile, vw } = useResponsive();
  const [phase, setPhase] = useState<Phase>("welcome");
  const [elementIdx, setElementIdx] = useState(0);
  const [autoPlay, setAutoPlay] = useState(false);
  const [profileData, setProfileData] = useState({ pseudo: "", name: "", email: "" });
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [gridResult, setGridResult] = useState<
    { hex: string; code: string; symbol: string }[][] | null
  >(null);
  const [gridSize] = useState(28);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // iPad dimensions
  const ipadW = isMobile ? Math.min(vw - 32, 340) : 420;
  const ipadH = isMobile ? Math.round(ipadW * 1.38) : 580;

  // Welcome → auto transition
  useEffect(() => {
    if (phase === "welcome") {
      const t = setTimeout(() => setPhase("elements"), 2400);
      return () => clearTimeout(t);
    }
  }, [phase]);

  // Autoplay
  useEffect(() => {
    if (!autoPlay || phase !== "elements") return;
    const t = setInterval(() => {
      setElementIdx((prev) => {
        if (prev >= 63) {
          setAutoPlay(false);
          setTimeout(() => setPhase("square"), 600);
          return 63;
        }
        return prev + 1;
      });
    }, 1800);
    return () => clearInterval(t);
  }, [autoPlay, phase]);

  // Navigate elements
  const goNext = useCallback(() => {
    if (elementIdx >= 63) {
      setPhase("square");
    } else {
      setElementIdx((p) => p + 1);
    }
  }, [elementIdx]);

  const goPrev = useCallback(() => {
    setElementIdx((p) => Math.max(0, p - 1));
  }, []);

  const skipToSquare = () => {
    setAutoPlay(false);
    setPhase("square");
  };

  // Photo handling
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setPhotoPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  // Process photo → cross-stitch
  const processPhoto = useCallback(() => {
    if (!photoPreview) return;
    setPhase("processing");

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = gridSize;
      canvas.height = gridSize;
      const ctx = canvas.getContext("2d")!;

      // Draw resized image
      const aspect = img.width / img.height;
      let sx = 0, sy = 0, sw = img.width, sh = img.height;
      if (aspect > 1) {
        sx = (img.width - img.height) / 2;
        sw = img.height;
      } else {
        sy = (img.height - img.width) / 2;
        sh = img.width;
      }
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, gridSize, gridSize);

      const imageData = ctx.getImageData(0, 0, gridSize, gridSize);
      const grid: { hex: string; code: string; symbol: string }[][] = [];

      // Track which DMC colors we've used, assign symbols
      const colorToSymbol = new Map<string, string>();
      let symbolIdx = 0;

      for (let y = 0; y < gridSize; y++) {
        const row: typeof grid[0] = [];
        for (let x = 0; x < gridSize; x++) {
          const idx = (y * gridSize + x) * 4;
          const r = imageData.data[idx];
          const g = imageData.data[idx + 1];
          const b = imageData.data[idx + 2];
          const dmc = nearestDMC(r, g, b);

          if (!colorToSymbol.has(dmc.code)) {
            colorToSymbol.set(dmc.code, GRID_SYMBOLS[symbolIdx % GRID_SYMBOLS.length]);
            symbolIdx++;
          }

          row.push({
            hex: dmc.hex,
            code: dmc.code,
            symbol: colorToSymbol.get(dmc.code) || "✕",
          });
        }
        grid.push(row);
      }

      setGridResult(grid);
      setTimeout(() => setPhase("result"), 1200);
    };
    img.src = photoPreview;
  }, [photoPreview, gridSize]);

  // Download grid as PNG
  const downloadGrid = useCallback(() => {
    if (!gridResult) return;
    const scale = 20;
    const size = gridSize * scale;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d")!;

    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        const cell = gridResult[y][x];
        ctx.fillStyle = cell.hex;
        ctx.fillRect(x * scale, y * scale, scale, scale);
        // Grid line
        ctx.strokeStyle = "rgba(0,0,0,0.1)";
        ctx.strokeRect(x * scale, y * scale, scale, scale);
        // Symbol
        ctx.fillStyle = "rgba(0,0,0,0.4)";
        ctx.font = `${scale * 0.4}px Inter, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(cell.symbol, x * scale + scale / 2, y * scale + scale / 2);
      }
    }

    const link = document.createElement("a");
    link.download = `stitchlab-${profileData.pseudo || "pattern"}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  }, [gridResult, gridSize, profileData.pseudo]);

  // Current element
  const currentEl = ELEMENTS[elementIdx];
  const currentFam = FAMILIES[currentEl?.family ?? 0];
  const progress = ((elementIdx + 1) / 64) * 100;

  // Cell size for result grid
  const resultCellSize = Math.max(6, Math.floor((ipadW - 40) / gridSize));

  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center overflow-hidden"
      style={{ backgroundColor: "#0A0A0A" }}
    >
      {/* Back */}
      <motion.button
        className="fixed top-4 left-4 z-40 flex items-center gap-1.5 cursor-pointer border-none"
        style={{
          backgroundColor: "rgba(255,255,255,0.06)",
          color: "rgba(255,255,255,0.5)",
          fontSize: 10,
          padding: "8px 14px",
          borderRadius: 10,
          border: "1px solid rgba(255,255,255,0.06)",
        }}
        onClick={onBack}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <ArrowLeft size={12} />
      </motion.button>

      {/* Skip button (during elements) */}
      <AnimatePresence>
        {phase === "elements" && (
          <motion.button
            className="fixed top-4 right-4 z-40 flex items-center gap-1.5 cursor-pointer border-none"
            style={{
              backgroundColor: "rgba(255,255,255,0.06)",
              color: "rgba(255,255,255,0.4)",
              fontSize: 9,
              padding: "8px 14px",
              borderRadius: 10,
              border: "1px solid rgba(255,255,255,0.05)",
              letterSpacing: "0.08em",
            }}
            onClick={skipToSquare}
            whileHover={{ scale: 1.03, color: "rgba(255,255,255,0.7)" }}
            whileTap={{ scale: 0.97 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <SkipForward size={10} />
            PASSER
          </motion.button>
        )}
      </AnimatePresence>

      {/* ═══ THE IPAD ═══ */}
      <motion.div
        className="relative"
        initial={{ opacity: 0, scale: 0.85, y: 40 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 1.2, type: "spring", stiffness: 40 }}
      >
        {/* iPad body */}
        <div
          className="relative rounded-[20px] flex flex-col items-center overflow-hidden"
          style={{
            width: ipadW,
            height: ipadH,
            backgroundColor: "#1a1a1a",
            border: "3px solid #2a2a2a",
            boxShadow:
              "0 12px 60px rgba(0,0,0,0.6), 0 0 80px rgba(232,23,127,0.04), inset 0 1px 0 rgba(255,255,255,0.05)",
          }}
        >
          {/* Camera notch */}
          <div
            className="w-1.5 h-1.5 rounded-full mt-2.5"
            style={{ backgroundColor: "rgba(255,255,255,0.06)" }}
          />

          {/* ═══ SCREEN ═══ */}
          <div
            className="flex-1 w-[92%] mt-1.5 mb-1 rounded-sm overflow-hidden relative flex flex-col"
            style={{ backgroundColor: "#0A0A0A" }}
          >
            <AnimatePresence mode="wait">
              {/* ── WELCOME ── */}
              {phase === "welcome" && (
                <motion.div
                  key="welcome"
                  className="flex-1 flex flex-col items-center justify-center gap-5"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.6 }}
                >
                  <motion.div
                    animate={{ y: [0, -6, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <PlayerSquare
                      colorHex={HEART_RED}
                      symbol="♥"
                      size={isMobile ? 48 : 60}
                      symbolSize={40}
                      glowing
                    />
                  </motion.div>
                  <div className="flex flex-col items-center gap-1">
                    <p style={{ fontSize: 11, fontWeight: 300, color: "rgba(255,255,255,0.5)", letterSpacing: "0.2em" }}>
                      BIENVENUE DANS
                    </p>
                    <p style={{ fontSize: isMobile ? 20 : 26, fontWeight: 200, color: "#fff", letterSpacing: "0.08em" }}>
                      Stitch<span style={{ color: HEART_RED }}>Lab</span>
                    </p>
                  </div>
                  <p style={{ fontSize: 9, color: "rgba(255,255,255,0.2)", fontWeight: 300 }}>
                    64 facettes à découvrir
                  </p>
                </motion.div>
              )}

              {/* ── ELEMENTS ── */}
              {phase === "elements" && currentEl && (
                <motion.div
                  key="elements"
                  className="flex-1 flex flex-col"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {/* Progress bar */}
                  <div className="px-3 pt-2.5">
                    <div style={{ height: 2, backgroundColor: "rgba(255,255,255,0.04)", borderRadius: 1 }}>
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: currentFam.color }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 0.4 }}
                      />
                    </div>
                    {/* Family dots → mini PlayerSquares */}
                    <div className="flex justify-center gap-1.5 mt-2">
                      {FAMILIES.map((f, i) => {
                        const isActive = Math.floor(elementIdx / 8) === i;
                        const isPast = Math.floor(elementIdx / 8) > i;
                        return (
                          <motion.div
                            key={i}
                            className="cursor-pointer relative"
                            onClick={() => {
                              setElementIdx(i * 8);
                              setAutoPlay(false);
                            }}
                            whileHover={{ scale: 1.3 }}
                            animate={isActive ? { y: [0, -2, 0] } : {}}
                            transition={isActive
                              ? { duration: 1.5, repeat: Infinity, ease: "easeInOut" }
                              : { duration: 0.2 }
                            }
                          >
                            <PlayerSquare
                              colorHex={isActive || isPast ? f.color : "#222"}
                              symbol={f.symbol}
                              size={isActive ? 18 : 14}
                              symbolSize={isActive ? 11 : 8}
                              glowing={isActive}
                            />
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Element content */}
                  <div className="flex-1 flex flex-col items-center justify-center px-6">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={elementIdx}
                        className="flex flex-col items-center text-center gap-3"
                        initial={{ opacity: 0, x: 30 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -30 }}
                        transition={{ duration: 0.3 }}
                      >
                        {/* Family PlayerSquare — glowing */}
                        <motion.div
                          animate={{ y: [0, -4, 0] }}
                          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                        >
                          <PlayerSquare
                            colorHex={currentFam.color}
                            symbol={currentFam.symbol}
                            size={isMobile ? 52 : 64}
                            symbolSize={isMobile ? 34 : 42}
                            glowing
                          />
                        </motion.div>

                        {/* Family label */}
                        <p style={{
                          fontSize: 8,
                          fontWeight: 600,
                          color: currentFam.color,
                          letterSpacing: "0.2em",
                          textTransform: "uppercase",
                        }}>
                          {currentFam.title}
                        </p>

                        {/* Element title */}
                        <h2 style={{
                          fontSize: isMobile ? 22 : 28,
                          fontWeight: 200,
                          color: "#fff",
                          letterSpacing: "0.04em",
                          lineHeight: 1.2,
                        }}>
                          {currentEl.title}
                        </h2>

                        {/* Element desc */}
                        <p style={{
                          fontSize: isMobile ? 11 : 13,
                          fontWeight: 300,
                          color: "rgba(255,255,255,0.4)",
                          lineHeight: 1.7,
                          maxWidth: 260,
                        }}>
                          {currentEl.desc}
                        </p>

                        {/* Counter */}
                        <p style={{
                          fontSize: 9,
                          color: "rgba(255,255,255,0.15)",
                          fontWeight: 300,
                          marginTop: 8,
                        }}>
                          {elementIdx + 1} / 64
                        </p>
                      </motion.div>
                    </AnimatePresence>
                  </div>

                  {/* Navigation */}
                  <div className="flex items-center justify-between px-4 pb-3">
                    <motion.button
                      className="w-9 h-9 rounded-full flex items-center justify-center cursor-pointer border-none"
                      style={{
                        backgroundColor: elementIdx > 0 ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0)",
                        color: elementIdx > 0 ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.1)",
                      }}
                      onClick={goPrev}
                      disabled={elementIdx === 0}
                      whileHover={elementIdx > 0 ? { scale: 1.1 } : {}}
                      whileTap={elementIdx > 0 ? { scale: 0.9 } : {}}
                    >
                      <ArrowLeft size={14} />
                    </motion.button>

                    <motion.button
                      className="cursor-pointer border-none"
                      style={{
                        backgroundColor: autoPlay ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.03)",
                        color: autoPlay ? currentFam.color : "rgba(255,255,255,0.3)",
                        fontSize: 8,
                        fontWeight: 500,
                        letterSpacing: "0.1em",
                        padding: "6px 12px",
                        borderRadius: 6,
                      }}
                      onClick={() => setAutoPlay(!autoPlay)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {autoPlay ? "⏸ PAUSE" : "▶ AUTO"}
                    </motion.button>

                    <motion.button
                      className="w-9 h-9 rounded-full flex items-center justify-center cursor-pointer border-none"
                      style={{
                        backgroundColor: "rgba(255,255,255,0.06)",
                        color: "rgba(255,255,255,0.5)",
                      }}
                      onClick={goNext}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <ArrowRight size={14} />
                    </motion.button>
                  </div>
                </motion.div>
              )}

              {/* ── THE SQUARE ALONE ── */}
              {phase === "square" && (
                <motion.div
                  key="square"
                  className="flex-1 flex flex-col items-center justify-center gap-6 px-6"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  {/* The square — alone, majestic */}
                  <motion.div
                    animate={{ y: [0, -6, 0] }}
                    transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <PlayerSquare
                      colorHex={HEART_RED}
                      symbol="♥"
                      size={isMobile ? 80 : 100}
                      symbolSize={70}
                      glowing
                    />
                  </motion.div>

                  <div className="flex flex-col items-center gap-2 text-center">
                    <motion.p
                      style={{
                        fontSize: isMobile ? 18 : 22,
                        fontWeight: 200,
                        color: "#fff",
                        letterSpacing: "0.06em",
                      }}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                    >
                      Ton carré.
                    </motion.p>
                    <motion.p
                      style={{
                        fontSize: isMobile ? 11 : 13,
                        fontWeight: 300,
                        color: "rgba(255,255,255,0.35)",
                        lineHeight: 1.8,
                        maxWidth: 240,
                      }}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.8 }}
                    >
                      Une couleur. Un symbole. Une intention.
                      <br />
                      C'est tout ce qu'il te faut pour commencer.
                    </motion.p>
                    <motion.p
                      style={{
                        fontSize: 8,
                        fontWeight: 400,
                        color: "rgba(255,255,255,0.15)",
                        letterSpacing: "0.2em",
                        marginTop: 8,
                      }}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.2 }}
                    >
                      CECI EST UN LABORATOIRE
                    </motion.p>
                  </div>

                  <motion.button
                    className="flex items-center gap-2 cursor-pointer border-none mt-2"
                    style={{
                      backgroundColor: HEART_RED,
                      color: "#fff",
                      fontSize: 11,
                      fontWeight: 500,
                      padding: "12px 28px",
                      borderRadius: 12,
                      letterSpacing: "0.06em",
                    }}
                    onClick={() => setPhase("profile")}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.6 }}
                    whileHover={{ scale: 1.04, boxShadow: `0 0 24px ${HEART_RED}50` }}
                    whileTap={{ scale: 0.96 }}
                  >
                    <Camera size={13} />
                    Teste sur ta photo
                  </motion.button>
                </motion.div>
              )}

              {/* ── PROFILE ── */}
              {phase === "profile" && (
                <motion.div
                  key="profile"
                  className="flex-1 flex flex-col items-center px-5 overflow-y-auto"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  style={{ paddingTop: 16, paddingBottom: 16 }}
                >
                  <p style={{
                    fontSize: 8, fontWeight: 600, color: HEART_RED,
                    letterSpacing: "0.2em", marginBottom: 12,
                  }}>
                    TON APERÇU
                  </p>

                  {/* Photo upload zone */}
                  <motion.div
                    className="relative cursor-pointer rounded-xl flex items-center justify-center overflow-hidden"
                    style={{
                      width: isMobile ? 110 : 130,
                      height: isMobile ? 110 : 130,
                      backgroundColor: "rgba(255,255,255,0.03)",
                      border: "2px dashed rgba(255,255,255,0.08)",
                    }}
                    onClick={() => fileInputRef.current?.click()}
                    whileHover={{ borderColor: "rgba(232,23,127,0.3)", scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {photoPreview ? (
                      <img
                        src={photoPreview}
                        alt="preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <User size={24} color="rgba(255,255,255,0.15)" />
                        <p style={{ fontSize: 8, color: "rgba(255,255,255,0.2)", fontWeight: 300, textAlign: "center" }}>
                          Ta photo
                        </p>
                      </div>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handlePhotoUpload}
                    />
                  </motion.div>

                  {/* Form fields */}
                  <div className="w-full flex flex-col gap-3 mt-5">
                    {[
                      { key: "pseudo" as const, label: "Pseudo", placeholder: "ton_pseudo" },
                      { key: "name" as const, label: "Nom", placeholder: "Ton nom" },
                      { key: "email" as const, label: "Email", placeholder: "toi@email.com" },
                    ].map((field) => (
                      <div key={field.key} className="flex flex-col gap-1">
                        <label style={{ fontSize: 8, color: "rgba(255,255,255,0.3)", fontWeight: 500, letterSpacing: "0.1em" }}>
                          {field.label}
                        </label>
                        <input
                          type={field.key === "email" ? "email" : "text"}
                          value={profileData[field.key]}
                          onChange={(e) => setProfileData((p) => ({ ...p, [field.key]: e.target.value }))}
                          placeholder={field.placeholder}
                          className="w-full outline-none"
                          style={{
                            backgroundColor: "rgba(255,255,255,0.04)",
                            border: "1px solid rgba(255,255,255,0.06)",
                            borderRadius: 8,
                            padding: "10px 12px",
                            fontSize: 12,
                            color: "#fff",
                            fontFamily: "inherit",
                          }}
                        />
                      </div>
                    ))}
                  </div>

                  {/* Submit */}
                  <motion.button
                    className="w-full flex items-center justify-center gap-2 cursor-pointer border-none mt-5"
                    style={{
                      backgroundColor: photoPreview ? HEART_RED : "rgba(255,255,255,0.04)",
                      color: photoPreview ? "#fff" : "rgba(255,255,255,0.2)",
                      fontSize: 11,
                      fontWeight: 500,
                      padding: "12px",
                      borderRadius: 10,
                      letterSpacing: "0.06em",
                    }}
                    onClick={processPhoto}
                    disabled={!photoPreview}
                    whileHover={photoPreview ? { scale: 1.02 } : {}}
                    whileTap={photoPreview ? { scale: 0.98 } : {}}
                  >
                    <Sparkles size={12} />
                    Convertir en broderie
                  </motion.button>

                  {/* Or go back */}
                  <button
                    className="mt-3 cursor-pointer border-none bg-transparent"
                    style={{ fontSize: 9, color: "rgba(255,255,255,0.2)" }}
                    onClick={() => setPhase("square")}
                  >
                    ← Retour
                  </button>
                </motion.div>
              )}

              {/* ── PROCESSING ── */}
              {phase === "processing" && (
                <motion.div
                  key="processing"
                  className="flex-1 flex flex-col items-center justify-center gap-5"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  >
                    <Sparkles size={24} color={HEART_RED} />
                  </motion.div>
                  <p style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", fontWeight: 300 }}>
                    Conversion en cours…
                  </p>
                  <p style={{ fontSize: 9, color: "rgba(255,255,255,0.15)", fontWeight: 300 }}>
                    Photo → DMC → Grille point de croix
                  </p>
                </motion.div>
              )}

              {/* ── RESULT ── */}
              {phase === "result" && gridResult && (
                <motion.div
                  key="result"
                  className="flex-1 flex flex-col items-center overflow-y-auto"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.6 }}
                  style={{ paddingTop: 12, paddingBottom: 12 }}
                >
                  <p style={{
                    fontSize: 8, fontWeight: 600, color: HEART_RED,
                    letterSpacing: "0.2em", marginBottom: 8,
                  }}>
                    TA GRILLE BRODERIE
                  </p>

                  {profileData.pseudo && (
                    <p style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 8, fontWeight: 300 }}>
                      @{profileData.pseudo}
                    </p>
                  )}

                  {/* The grid */}
                  <div
                    className="grid mx-auto"
                    style={{
                      gridTemplateColumns: `repeat(${gridSize}, ${resultCellSize}px)`,
                      gap: 0.5,
                    }}
                  >
                    {gridResult.flat().map((cell, i) => (
                      <motion.div
                        key={i}
                        style={{
                          width: resultCellSize,
                          height: resultCellSize,
                          backgroundColor: cell.hex,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: Math.max(4, resultCellSize * 0.45),
                          color: "rgba(0,0,0,0.2)",
                          lineHeight: 1,
                        }}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.0008 }}
                      >
                        {resultCellSize >= 8 && cell.symbol}
                      </motion.div>
                    ))}
                  </div>

                  {/* Color legend (compact) */}
                  <div className="flex flex-wrap gap-1 mt-3 px-3 justify-center">
                    {(() => {
                      const used = new Map<string, { hex: string; code: string; symbol: string }>();
                      gridResult.flat().forEach((c) => {
                        if (!used.has(c.code)) used.set(c.code, c);
                      });
                      return Array.from(used.values()).slice(0, 12).map((c) => (
                        <div
                          key={c.code}
                          className="flex items-center gap-1"
                          style={{ fontSize: 6, color: "rgba(255,255,255,0.3)" }}
                        >
                          <div
                            className="rounded-sm"
                            style={{ width: 8, height: 8, backgroundColor: c.hex }}
                          />
                          <span>{c.symbol}</span>
                          <span>{c.code}</span>
                        </div>
                      ));
                    })()}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 mt-4 px-4">
                    <motion.button
                      className="flex-1 flex items-center justify-center gap-1.5 cursor-pointer border-none"
                      style={{
                        backgroundColor: HEART_RED,
                        color: "#fff",
                        fontSize: 10,
                        fontWeight: 500,
                        padding: "10px",
                        borderRadius: 8,
                        letterSpacing: "0.06em",
                      }}
                      onClick={downloadGrid}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Download size={11} />
                      Télécharger PNG
                    </motion.button>

                    <motion.button
                      className="flex items-center justify-center gap-1.5 cursor-pointer border-none"
                      style={{
                        backgroundColor: "rgba(255,255,255,0.06)",
                        color: "rgba(255,255,255,0.5)",
                        fontSize: 10,
                        padding: "10px 14px",
                        borderRadius: 8,
                      }}
                      onClick={() => {
                        setPhase("profile");
                        setGridResult(null);
                      }}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <RotateCcw size={10} />
                    </motion.button>
                  </div>

                  {/* Back to square */}
                  <button
                    className="mt-3 cursor-pointer border-none bg-transparent"
                    style={{ fontSize: 9, color: "rgba(255,255,255,0.2)" }}
                    onClick={() => setPhase("square")}
                  >
                    ← Retour au concept
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Home indicator */}
          <div
            className="w-8 h-0.5 rounded-full mb-2"
            style={{ backgroundColor: "rgba(255,255,255,0.08)" }}
          />
        </div>

        {/* ═══ LEAVES / SECTIONS around iPad ═══ */}
        {phase === "elements" && !isMobile && (
          <>
            {/* Left leaf — family PlayerSquare */}
            <motion.div
              className="absolute rounded-lg px-3 py-2.5 flex flex-col items-center gap-1.5 pointer-events-none"
              style={{
                left: -160,
                top: "20%",
                width: 130,
                backgroundColor: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.04)",
                transform: "rotate(-3deg)",
              }}
              animate={{ y: [0, -4, 0], opacity: [0.5, 0.8, 0.5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <PlayerSquare
                colorHex={FAMILIES[Math.floor(elementIdx / 8)].color}
                symbol={FAMILIES[Math.floor(elementIdx / 8)].symbol}
                size={28}
                symbolSize={18}
                glowing
              />
              <p style={{ fontSize: 8, color: "rgba(255,255,255,0.25)", fontWeight: 300 }}>
                {FAMILIES[Math.floor(elementIdx / 8)].title}
              </p>
              <p style={{ fontSize: 7, color: "rgba(255,255,255,0.12)" }}>
                Famille {Math.floor(elementIdx / 8) + 1}/8
              </p>
            </motion.div>

            {/* Right leaf */}
            <motion.div
              className="absolute rounded-lg px-3 py-2.5 flex flex-col gap-1 pointer-events-none"
              style={{
                right: -160,
                top: "35%",
                width: 130,
                backgroundColor: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.04)",
                transform: "rotate(2deg)",
              }}
              animate={{ y: [0, -3, 0], opacity: [0.4, 0.7, 0.4] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            >
              <p style={{ fontSize: 7, color: "rgba(255,255,255,0.15)", letterSpacing: "0.1em" }}>PROGRESSION</p>
              <div className="flex gap-0.5">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div
                    key={i}
                    className="rounded-sm"
                    style={{
                      width: 10,
                      height: 4,
                      backgroundColor:
                        i <= Math.floor(elementIdx / 8)
                          ? FAMILIES[i].color
                          : "rgba(255,255,255,0.04)",
                    }}
                  />
                ))}
              </div>
              <p style={{ fontSize: 7, color: "rgba(255,255,255,0.12)" }}>
                {elementIdx + 1}/64 éléments
              </p>
            </motion.div>

            {/* Bottom leaf → Mini Dock Widget */}
            <motion.div
              className="absolute flex flex-col items-center gap-2 pointer-events-none"
              style={{
                bottom: -75,
                left: "50%",
                transform: "translateX(-50%)",
              }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5, duration: 0.8 }}
            >
              <MiniDockAnimation />
              <span style={{
                fontSize: 8,
                color: "rgba(255,255,255,0.12)",
                letterSpacing: "0.12em",
                fontWeight: 400,
              }}>
                STITCHDOCK
              </span>
            </motion.div>
          </>
        )}
      </motion.div>

      {/* Hidden canvas */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}