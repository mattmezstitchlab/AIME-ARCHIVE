import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft,
  Heart,
  Users,
  Sun,
  MapPin,
  Accessibility,
  Gift,
  Sparkles,
  TreePine,
  Music,
  Palette,
  UtensilsCrossed,
  ChevronRight,
  Hand,
  Eye,
  Baby,
  Clock,
} from "lucide-react";
import heroImage from "figma:asset/3709f40c6e9786acea3616a9b9c96620d31681e1.png";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// ═══════════════════════════════════════════
// SOLISORTIES
// Des sorties solidaires accessibles a tous.
// Don libre. Inclusion. Simplicite.
// ═══════════════════════════════════════════

const BG = "#FEFCF7";
const TEXT_PRIMARY = "#2C2C2C";
const TEXT_SECONDARY = "#777";
const TEXT_MUTED = "#AAA";
const ACCENT_WARM = "#D4875A";
const ACCENT_BLUE = "#5C7A8C";
const ACCENT_GOLD = "#C8A96E";
const ACCENT_GREEN = "#6B9E7A";

// ─── OUTINGS DATA ───
const EXAMPLE_OUTINGS = [
  {
    title: "Balade en foret",
    desc: "Marche douce en foret avec pause gouter partage",
    icon: TreePine,
    color: ACCENT_GREEN,
    tags: ["Accessible PMR", "Enfants bienvenus"],
    donSuggere: "Don libre",
    image: "https://images.unsplash.com/photo-1744160335022-d520b6fd6374?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZnJpZW5kcyUyMHdhbGtpbmclMjBwYXJrJTIwdG9nZXRoZXJ8ZW58MXx8fHwxNzcwNDczOTk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    title: "Pique-nique solidaire",
    desc: "Chacun apporte ce qu'il peut, on partage tout",
    icon: UtensilsCrossed,
    color: ACCENT_WARM,
    tags: ["Gratuit", "Intergenerationnel"],
    donSuggere: "Don libre",
    image: "https://images.unsplash.com/photo-1624678064418-f9f08012b6e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBwaWNuaWMlMjBzdW5zZXQlMjB3YXJtJTIwbGlnaHR8ZW58MXx8fHwxNzcwNDczOTk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    title: "Atelier creatif en plein air",
    desc: "Dessin, broderie ou musique dans un parc",
    icon: Palette,
    color: ACCENT_BLUE,
    tags: ["Materiel fourni", "Debutants"],
    donSuggere: "Don libre",
    image: "https://images.unsplash.com/photo-1761435739748-879d2ecf0c70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZ3JvdXAlMjBvdXRkb29yJTIwY29tbXVuaXR5JTIwZ2F0aGVyaW5nfGVufDF8fHx8MTc3MDQ3Mzk5NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    title: "Concert partage",
    desc: "Musique live dans un lieu atypique, ouvert a tous",
    icon: Music,
    color: "#9263A6",
    tags: ["Inclusion", "Toutes oreilles"],
    donSuggere: "Don libre",
    image: "https://images.unsplash.com/photo-1655720359248-eeace8c709c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kcyUyMGNpcmNsZSUyMHVuaXR5JTIwc29saWRhcml0eSUyMHRvZ2V0aGVyfGVufDF8fHx8MTc3MDQ3Mzk5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

// ─── THREE PILLARS ───
const PILLARS = [
  {
    icon: Gift,
    title: "Don libre",
    desc: "Pas de prix fixe. Chacun donne ce qu'il peut, ce qu'il veut. La valeur d'une sortie ne se mesure pas en euros.",
    color: ACCENT_GOLD,
  },
  {
    icon: Users,
    title: "Inclusion",
    desc: "Aucune condition. Seniors, enfants, personnes en situation de handicap, migrants, isoles — tout le monde est le bienvenu.",
    color: ACCENT_GREEN,
  },
  {
    icon: Sun,
    title: "Simplicite",
    desc: "Pas d'inscription compliquee, pas d'appli lourde. On propose, on rejoint, on partage. C'est tout.",
    color: ACCENT_WARM,
  },
];

// ─── HOW IT WORKS ───
const STEPS = [
  { num: "01", text: "Quelqu'un propose une sortie", sub: "Un lieu, une heure, une activite simple" },
  { num: "02", text: "Tout le monde peut rejoindre", sub: "Sans inscription, sans condition financiere" },
  { num: "03", text: "On vit le moment ensemble", sub: "Le lien social se cree naturellement" },
  { num: "04", text: "Don libre a la fin", sub: "Chacun donne selon ses moyens, ou rien du tout" },
];

interface SolisortiesLandingProps {
  onBack?: () => void;
}

export function SolisortiesLanding({ onBack }: SolisortiesLandingProps) {
  const [expandedOuting, setExpandedOuting] = useState<number | null>(null);
  const [isMobile] = useState(() => window.innerWidth < 640);

  return (
    <div
      className="fixed inset-0 overflow-y-auto overflow-x-hidden"
      style={{ backgroundColor: BG, scrollBehavior: "smooth" }}
    >
      {/* ═══ HERO ═══ */}
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
        {/* Back button */}
        {onBack && (
          <motion.button
            className="absolute top-4 left-4 z-20 flex items-center gap-2 border-none cursor-pointer rounded-lg px-3 py-1.5"
            style={{ backgroundColor: "rgba(255,255,255,0.7)", color: TEXT_SECONDARY, fontSize: 11, backdropFilter: "blur(10px)" }}
            onClick={onBack}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft size={14} />
            Retour
          </motion.button>
        )}

        {/* Hero image background */}
        <div className="absolute inset-0 z-0">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${heroImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              filter: "brightness(0.6) saturate(0.8)",
            }}
          />
          {/* Gradient overlay */}
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(180deg, rgba(254,252,247,0.1) 0%, rgba(254,252,247,0.0) 30%, rgba(254,252,247,0.6) 80%, ${BG} 100%)`,
            }}
          />
        </div>

        {/* Hero content */}
        <div className="relative z-10 flex flex-col items-center text-center px-6 mt-16">
          {/* Badge */}
          <motion.div
            className="flex items-center gap-2 rounded-full px-4 py-1.5 mb-8"
            style={{ backgroundColor: "rgba(255,255,255,0.15)", backdropFilter: "blur(20px)" }}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Heart size={10} fill="#fff" color="#fff" />
            <span style={{ fontSize: 9, color: "#fff", letterSpacing: "0.2em", fontWeight: 500 }}>
              SOLIDARITE & INCLUSION
            </span>
          </motion.div>

          {/* Title */}
          <motion.h1
            style={{
              fontSize: isMobile ? "clamp(36px, 12vw, 52px)" : "clamp(48px, 7vw, 72px)",
              fontWeight: 200,
              color: "#fff",
              letterSpacing: "-0.02em",
              lineHeight: 1.05,
              marginBottom: 16,
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 1 }}
          >
            Soli<span style={{ fontWeight: 500 }}>sorties</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            style={{
              fontSize: isMobile ? 14 : 17,
              color: "rgba(255,255,255,0.8)",
              fontWeight: 300,
              maxWidth: 440,
              lineHeight: 1.7,
              marginBottom: 32,
            }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
          >
            Des sorties solidaires accessibles a tous.
            <br />
            <span style={{ color: "rgba(255,255,255,0.5)" }}>Don libre. Inclusion. Simplicite.</span>
          </motion.p>

          {/* Stats row */}
          <motion.div
            className="flex items-center gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
          >
            {[
              { value: "0€", label: "prix minimum" },
              { value: "∞", label: "bienvenus" },
              { value: "♥", label: "don libre" },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center gap-1">
                <span style={{ fontSize: 22, fontWeight: 300, color: "#fff" }}>{stat.value}</span>
                <span style={{ fontSize: 8, color: "rgba(255,255,255,0.4)", letterSpacing: "0.1em" }}>
                  {stat.label}
                </span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.4 }}
          transition={{ delay: 2 }}
        >
          <motion.div
            className="w-px h-8"
            style={{ backgroundColor: TEXT_MUTED }}
            animate={{ scaleY: [0.4, 1, 0.4] }}
            transition={{ duration: 2.5, repeat: Infinity }}
          />
          <span style={{ fontSize: 8, color: TEXT_MUTED, letterSpacing: "0.15em" }}>decouvrir</span>
        </motion.div>
      </section>

      {/* ═══ MANIFESTO ═══ */}
      <section
        className="flex flex-col items-center justify-center py-24 px-6"
        style={{ minHeight: "60vh" }}
      >
        <motion.p
          className="text-center"
          style={{
            fontSize: isMobile ? 20 : "clamp(22px, 3.5vw, 34px)",
            fontWeight: 300,
            color: TEXT_PRIMARY,
            lineHeight: 1.8,
            maxWidth: 600,
          }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 1 }}
        >
          Recréer du{" "}
          <span style={{ fontWeight: 500, color: ACCENT_WARM }}>lien social</span>
          <br />
          sans contrainte économique.
        </motion.p>
        <motion.p
          className="text-center mt-6"
          style={{
            fontSize: isMobile ? 12 : 14,
            color: TEXT_SECONDARY,
            lineHeight: 1.8,
            maxWidth: 480,
            fontWeight: 300,
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          Solisorties naît d'un constat simple : trop de gens restent isoles parce qu'ils n'ont pas les moyens,
          pas la mobilite, ou simplement pas l'occasion de sortir. Nous proposons une alternative radicalement humaine.
        </motion.p>
      </section>

      {/* ═══ THREE PILLARS ═══ */}
      <section className="py-16 px-6">
        <motion.p
          className="text-center mb-16"
          style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.25em", fontWeight: 400 }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          TROIS PILIERS
        </motion.p>

        <div
          className="mx-auto grid gap-6"
          style={{
            maxWidth: 900,
            gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
          }}
        >
          {PILLARS.map((pillar, i) => (
            <motion.div
              key={pillar.title}
              className="flex flex-col items-center text-center p-8 rounded-2xl"
              style={{
                backgroundColor: "#fff",
                border: "1px solid rgba(0,0,0,0.04)",
                boxShadow: "0 2px 20px rgba(0,0,0,0.03)",
              }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.8 }}
            >
              <motion.div
                className="flex items-center justify-center rounded-2xl mb-5"
                style={{
                  width: 56,
                  height: 56,
                  backgroundColor: `${pillar.color}12`,
                }}
                whileHover={{ scale: 1.08, backgroundColor: `${pillar.color}20` }}
              >
                <pillar.icon size={24} color={pillar.color} strokeWidth={1.5} />
              </motion.div>
              <h3 style={{ fontSize: 16, fontWeight: 500, color: TEXT_PRIMARY, marginBottom: 8 }}>
                {pillar.title}
              </h3>
              <p style={{ fontSize: 12, color: TEXT_SECONDARY, lineHeight: 1.7, fontWeight: 300 }}>
                {pillar.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ═══ INCLUSION BAR ═══ */}
      <section className="py-20 px-6">
        <motion.div
          className="mx-auto rounded-3xl p-8 md:p-12 relative overflow-hidden"
          style={{
            maxWidth: 900,
            background: `linear-gradient(135deg, ${ACCENT_BLUE}08, ${ACCENT_GREEN}08)`,
            border: "1px solid rgba(0,0,0,0.03)",
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <p
            className="text-center mb-10"
            style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.25em" }}
          >
            ACCESSIBLE A TOUS
          </p>

          <div
            className="grid gap-6"
            style={{ gridTemplateColumns: isMobile ? "repeat(2, 1fr)" : "repeat(4, 1fr)" }}
          >
            {[
              { icon: Accessibility, label: "Mobilite reduite", desc: "Parcours adaptes PMR", color: ACCENT_BLUE },
              { icon: Eye, label: "Deficience visuelle", desc: "Accompagnement dedie", color: ACCENT_GREEN },
              { icon: Baby, label: "Familles & enfants", desc: "Activites pour tous ages", color: ACCENT_WARM },
              { icon: Hand, label: "Isolement social", desc: "Premier pas facilite", color: ACCENT_GOLD },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                className="flex flex-col items-center text-center gap-3 p-4"
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div
                  className="flex items-center justify-center rounded-full"
                  style={{
                    width: 44,
                    height: 44,
                    backgroundColor: `${item.color}15`,
                  }}
                >
                  <item.icon size={20} color={item.color} strokeWidth={1.5} />
                </div>
                <span style={{ fontSize: 11, fontWeight: 500, color: TEXT_PRIMARY }}>{item.label}</span>
                <span style={{ fontSize: 10, color: TEXT_SECONDARY, fontWeight: 300 }}>{item.desc}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ═══ HOW IT WORKS ═══ */}
      <section className="py-20 px-6">
        <motion.p
          className="text-center mb-4"
          style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.25em" }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          COMMENT CA MARCHE
        </motion.p>
        <motion.h2
          className="text-center mb-16"
          style={{ fontSize: isMobile ? 22 : 28, fontWeight: 300, color: TEXT_PRIMARY }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Quatre gestes, <span style={{ fontWeight: 500 }}>zero friction</span>.
        </motion.h2>

        <div className="mx-auto" style={{ maxWidth: 560 }}>
          {STEPS.map((step, i) => (
            <motion.div
              key={step.num}
              className="flex items-start gap-5 mb-10"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
            >
              <span
                style={{
                  fontSize: 28,
                  fontWeight: 200,
                  color: ACCENT_WARM,
                  opacity: 0.4,
                  minWidth: 44,
                  lineHeight: 1,
                }}
              >
                {step.num}
              </span>
              <div>
                <p style={{ fontSize: 14, fontWeight: 500, color: TEXT_PRIMARY, marginBottom: 4 }}>
                  {step.text}
                </p>
                <p style={{ fontSize: 12, color: TEXT_SECONDARY, fontWeight: 300 }}>{step.sub}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ═══ EXAMPLE OUTINGS ═══ */}
      <section className="py-20 px-6" style={{ backgroundColor: "#F9F6F0" }}>
        <motion.p
          className="text-center mb-4"
          style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.25em" }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          EXEMPLES DE SORTIES
        </motion.p>
        <motion.h2
          className="text-center mb-16"
          style={{ fontSize: isMobile ? 20 : 26, fontWeight: 300, color: TEXT_PRIMARY }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Simples. <span style={{ fontWeight: 500, color: ACCENT_WARM }}>Genereuses</span>. Ouvertes.
        </motion.h2>

        <div
          className="mx-auto grid gap-5"
          style={{
            maxWidth: 900,
            gridTemplateColumns: isMobile ? "1fr" : "repeat(2, 1fr)",
          }}
        >
          {EXAMPLE_OUTINGS.map((outing, i) => (
            <motion.div
              key={outing.title}
              className="rounded-2xl overflow-hidden cursor-pointer"
              style={{
                backgroundColor: "#fff",
                border: "1px solid rgba(0,0,0,0.04)",
                boxShadow: "0 2px 16px rgba(0,0,0,0.03)",
              }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              whileHover={{ y: -3, boxShadow: "0 8px 30px rgba(0,0,0,0.06)" }}
              onClick={() => setExpandedOuting(expandedOuting === i ? null : i)}
            >
              {/* Image */}
              <div className="relative" style={{ height: 160, overflow: "hidden" }}>
                <ImageWithFallback
                  src={outing.image}
                  alt={outing.title}
                  className="w-full h-full object-cover"
                  style={{ filter: "saturate(0.85)" }}
                />
                {/* Gradient overlay */}
                <div
                  className="absolute inset-0"
                  style={{
                    background: "linear-gradient(0deg, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0) 60%)",
                  }}
                />
                {/* Don libre badge */}
                <div
                  className="absolute bottom-3 right-3 flex items-center gap-1 rounded-full px-3 py-1"
                  style={{ backgroundColor: "rgba(255,255,255,0.85)", backdropFilter: "blur(8px)" }}
                >
                  <Gift size={10} color={ACCENT_GOLD} />
                  <span style={{ fontSize: 9, color: TEXT_PRIMARY, fontWeight: 500 }}>Don libre</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div
                    className="flex items-center justify-center rounded-lg"
                    style={{ width: 32, height: 32, backgroundColor: `${outing.color}12` }}
                  >
                    <outing.icon size={16} color={outing.color} strokeWidth={1.5} />
                  </div>
                  <h3 style={{ fontSize: 14, fontWeight: 500, color: TEXT_PRIMARY }}>{outing.title}</h3>
                </div>
                <p style={{ fontSize: 12, color: TEXT_SECONDARY, fontWeight: 300, lineHeight: 1.6, marginBottom: 10 }}>
                  {outing.desc}
                </p>
                <div className="flex flex-wrap gap-2">
                  {outing.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full px-3 py-1"
                      style={{
                        fontSize: 9,
                        backgroundColor: `${outing.color}08`,
                        color: outing.color,
                        fontWeight: 500,
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Expanded detail */}
                <AnimatePresence>
                  {expandedOuting === i && (
                    <motion.div
                      className="mt-4 pt-4"
                      style={{ borderTop: "1px solid rgba(0,0,0,0.04)" }}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="flex items-center gap-4 mb-3">
                        <div className="flex items-center gap-1.5">
                          <Clock size={11} color={TEXT_MUTED} />
                          <span style={{ fontSize: 10, color: TEXT_SECONDARY }}>2-3h</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <MapPin size={11} color={TEXT_MUTED} />
                          <span style={{ fontSize: 10, color: TEXT_SECONDARY }}>A definir ensemble</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Users size={11} color={TEXT_MUTED} />
                          <span style={{ fontSize: 10, color: TEXT_SECONDARY }}>5-15 pers.</span>
                        </div>
                      </div>
                      <p style={{ fontSize: 11, color: TEXT_SECONDARY, fontWeight: 300, lineHeight: 1.6 }}>
                        Aucune reservation necessaire. Venez comme vous etes.
                        Le don est libre et anonyme — donnez ce que vous pouvez,
                        ou ne donnez rien. L'essentiel est d'etre la.
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ═══ PHILOSOPHY ═══ */}
      <section className="py-24 px-6">
        <div className="mx-auto flex flex-col items-center" style={{ maxWidth: 640 }}>
          <motion.div
            className="mb-10"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <img
              src={heroImage}
              alt="Solidarite"
              className="rounded-3xl"
              style={{
                width: isMobile ? "100%" : 320,
                height: isMobile ? 200 : 220,
                objectFit: "cover",
                filter: "saturate(0.9)",
                boxShadow: "0 12px 40px rgba(0,0,0,0.08)",
              }}
            />
          </motion.div>

          <motion.blockquote
            className="text-center"
            style={{
              fontSize: isMobile ? 16 : 20,
              fontWeight: 300,
              color: TEXT_PRIMARY,
              lineHeight: 1.8,
              fontStyle: "italic",
            }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            "La vraie richesse, c'est la presence.
            <br />
            Le vrai luxe, c'est le temps partage.
            <br />
            <span style={{ color: ACCENT_WARM }}>Le vrai don, c'est l'attention."</span>
          </motion.blockquote>

          <motion.div
            className="mt-8 flex flex-col items-center gap-2"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center gap-3">
              {[ACCENT_WARM, ACCENT_BLUE, ACCENT_GREEN, ACCENT_GOLD, "#9263A6"].map((c, i) => (
                <motion.div
                  key={i}
                  className="rounded-full"
                  style={{ width: 6, height: 6, backgroundColor: c, opacity: 0.5 }}
                  animate={{ opacity: [0.3, 0.7, 0.3] }}
                  transition={{ duration: 3, delay: i * 0.4, repeat: Infinity }}
                />
              ))}
            </div>
            <p style={{ fontSize: 9, color: TEXT_MUTED, letterSpacing: "0.15em" }}>SOLISORTIES</p>
          </motion.div>
        </div>
      </section>

      {/* ═══ DON LIBRE EXPLAINED ═══ */}
      <section className="py-20 px-6" style={{ backgroundColor: "#F9F6F0" }}>
        <div className="mx-auto" style={{ maxWidth: 600 }}>
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <p style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.25em", marginBottom: 12 }}>
              LE DON LIBRE
            </p>
            <h2 style={{ fontSize: isMobile ? 20 : 26, fontWeight: 300, color: TEXT_PRIMARY, lineHeight: 1.5 }}>
              Pas un prix. Pas une obligation.
              <br />
              <span style={{ fontWeight: 500, color: ACCENT_GOLD }}>Un geste.</span>
            </h2>
          </motion.div>

          <div className="flex flex-col gap-4">
            {[
              { q: "Combien donner ?", a: "Ce que vous voulez. 0€, 2€, 20€. Il n'y a pas de minimum, pas de jugement." },
              { q: "Et si je ne peux rien donner ?", a: "Votre presence EST votre contribution. Le lien humain n'a pas de prix." },
              { q: "Ou va l'argent ?", a: "Il couvre les frais reels (transports, materiel). Le surplus finance les sorties suivantes, pour ceux qui ne peuvent pas donner." },
              { q: "C'est vraiment sans condition ?", a: "Vraiment. Pas de compte, pas de jugement, pas de regard. Juste du partage." },
            ].map((faq, i) => (
              <motion.div
                key={faq.q}
                className="p-5 rounded-xl"
                style={{ backgroundColor: "#fff", border: "1px solid rgba(0,0,0,0.03)" }}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <p style={{ fontSize: 13, fontWeight: 500, color: TEXT_PRIMARY, marginBottom: 6 }}>{faq.q}</p>
                <p style={{ fontSize: 12, color: TEXT_SECONDARY, fontWeight: 300, lineHeight: 1.7 }}>{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ STITCH CONNECTION ═══ */}
      <section className="py-20 px-6">
        <motion.div
          className="mx-auto rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
          style={{
            maxWidth: 700,
            background: "linear-gradient(135deg, #E8177F08, #9263A608)",
            border: "1px solid rgba(232,23,127,0.06)",
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <p style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.2em", marginBottom: 16 }}>
            DANS L'ECOSYSTEME STITCHLAB
          </p>
          <h3 style={{ fontSize: isMobile ? 18 : 22, fontWeight: 300, color: TEXT_PRIMARY, lineHeight: 1.6, marginBottom: 12 }}>
            Solisorties vit sur la <span style={{ fontWeight: 500, color: "#E8177F" }}>carte StitchLab</span>.
          </h3>
          <p style={{ fontSize: 12, color: TEXT_SECONDARY, fontWeight: 300, lineHeight: 1.8, maxWidth: 480, margin: "0 auto 20px" }}>
            Chaque sortie solidaire apparait comme un point lumineux sur la grille geolocalisee.
            L'inclusivite de Solisorties rejoint l'inclusivite du Point :
            expert, debutante, enfant, senior — tout le monde a sa place.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <span
              className="rounded-full px-3 py-1"
              style={{ fontSize: 9, backgroundColor: "#E8177F10", color: "#E8177F", fontWeight: 500 }}
            >
              POINT
            </span>
            <span style={{ color: TEXT_MUTED, fontSize: 10 }}>+</span>
            <span
              className="rounded-full px-3 py-1"
              style={{ fontSize: 9, backgroundColor: `${ACCENT_WARM}15`, color: ACCENT_WARM, fontWeight: 500 }}
            >
              SOLISORTIES
            </span>
            <span style={{ color: TEXT_MUTED, fontSize: 10 }}>+</span>
            <span
              className="rounded-full px-3 py-1"
              style={{ fontSize: 9, backgroundColor: "#9263A610", color: "#9263A6", fontWeight: 500 }}
            >
              TIMEHEART
            </span>
          </div>
        </motion.div>
      </section>

      {/* ═══ CTA FOOTER ═══ */}
      <section className="py-24 px-6 flex flex-col items-center justify-center gap-8">
        <motion.div
          className="flex items-center gap-3"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <Sparkles size={16} color={ACCENT_GOLD} strokeWidth={1.5} />
          <span style={{ fontSize: 10, color: TEXT_MUTED, letterSpacing: "0.2em" }}>REJOINDRE</span>
          <Sparkles size={16} color={ACCENT_GOLD} strokeWidth={1.5} />
        </motion.div>

        <motion.h2
          className="text-center"
          style={{
            fontSize: isMobile ? 24 : 32,
            fontWeight: 200,
            color: TEXT_PRIMARY,
            lineHeight: 1.4,
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Sortir ensemble.
          <br />
          <span style={{ fontWeight: 500, color: ACCENT_WARM }}>Donner librement.</span>
        </motion.h2>

        <motion.button
          className="flex items-center gap-3 cursor-pointer border-none rounded-xl"
          style={{
            background: `linear-gradient(135deg, ${ACCENT_WARM}, ${ACCENT_GOLD})`,
            color: "#fff",
            fontSize: 12,
            fontWeight: 500,
            letterSpacing: "0.1em",
            padding: isMobile ? "14px 32px" : "16px 40px",
            boxShadow: `0 4px 20px ${ACCENT_WARM}40`,
          }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          whileHover={{ scale: 1.04, boxShadow: `0 8px 30px ${ACCENT_WARM}50` }}
          whileTap={{ scale: 0.96 }}
        >
          <Heart size={14} fill="#fff" />
          PROPOSER UNE SORTIE
          <ChevronRight size={14} />
        </motion.button>

        <motion.p
          style={{ fontSize: 10, color: TEXT_MUTED, fontWeight: 300 }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          Aucune inscription requise — venez comme vous etes
        </motion.p>

        {/* Concept info */}
        <motion.p
          className="text-center mt-8"
          style={{ fontSize: 8, color: "rgba(0,0,0,0.15)", letterSpacing: "0.15em", maxWidth: 300, lineHeight: 1.8 }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          CONCEPT ORIGINAL &middot; INCLUSION &middot; DON LIBRE
          <br />
          PARTIE DE L'ECOSYSTEME STITCHLAB
        </motion.p>

        <div className="h-12" />
      </section>
    </div>
  );
}