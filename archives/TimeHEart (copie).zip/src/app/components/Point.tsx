import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Camera, Upload, FileText, Image as ImageIcon, FolderOpen, Clipboard, Plus, LayoutGrid,
  Pipette, Search, Heart, Palette, Clock, Circle, Scan, Sparkles,
  Pencil, Highlighter, Eraser, PaintBucket, Brush, Undo2,
  Type, Hash, Shapes, Star, Eye, BookOpen, AlignCenter, Accessibility,
  Grid3X3, ZoomIn, Ruler, Crosshair, Maximize2,
  Download, Printer, Save, Copy, History, Archive, File, FileImage,
  Scissors, Play, Award, HelpCircle, Timer, Lightbulb, Wrench,
  Share2, Link, MessageCircle, Mail, Users, Send, QrCode, Globe,
  X, Check, ChevronLeft, Minus,
} from "lucide-react";
import { DMC_COLORS } from "./game-data";

// ═══════════════════════════════════════════
// POINT — The Magic Cross-Stitch Rubik's Cube
// One square. Eight tools. Eight sub-options each.
// Visionary concept since 2003.
// ═══════════════════════════════════════════

const FUCHSIA = "#E8177F";
const ORANGE = "#EB5B2E";
const GRADIENT = `linear-gradient(135deg, ${FUCHSIA}, ${ORANGE})`;

// ─── UTILITY ───
function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

// ═══════════════════════════════════════════
// SUB-OPTION DEFINITIONS (8 per tool)
// ═══════════════════════════════════════════

interface SubOption {
  key: string;
  label: string;
  icon: typeof Camera;
  desc: string;
}

interface ToolDef {
  key: string;
  label: string;
  icon: typeof Camera;
  color: string;
  desc: string;
  subs: SubOption[];
}

const TOOLS: ToolDef[] = [
  // ─── ROW 1: ENTRER / CAPTER / TRADUIRE (Voir → Traduire → Structurer) ───
  // Position: N (top-center) = DMC
  {
    key: "dmc", label: "DMC", icon: Pipette, color: "#C72B3B", desc: "Traduire en couleurs",
    subs: [
      { key: "browse", label: "Parcourir", icon: Palette, desc: "Toutes les 500 DMC" },
      { key: "search", label: "Chercher", icon: Search, desc: "Par nom ou code" },
      { key: "favorites", label: "Favoris", icon: Heart, desc: "Tes couleurs préférées" },
      { key: "family", label: "Familles", icon: Circle, desc: "Par famille de teinte" },
      { key: "recent", label: "Récents", icon: Clock, desc: "Dernières utilisées" },
      { key: "wheel", label: "Roue", icon: Sparkles, desc: "Roue chromatique" },
      { key: "scan", label: "Scanner", icon: Scan, desc: "Identifier un fil" },
      { key: "custom", label: "Custom", icon: Plus, desc: "Couleur personnalisée" },
    ],
  },
  // Position: NE (top-right) = Grille
  {
    key: "grid", label: "Grille", icon: Grid3X3, color: "#4685B7", desc: "Poser la toile",
    subs: [
      { key: "aida11", label: "11 ct", icon: Grid3X3, desc: "Gros points" },
      { key: "aida14", label: "14 ct", icon: Grid3X3, desc: "Standard" },
      { key: "aida16", label: "16 ct", icon: Grid3X3, desc: "Moyen-fin" },
      { key: "aida18", label: "18 ct", icon: Grid3X3, desc: "Fin" },
      { key: "zoom", label: "Zoom", icon: ZoomIn, desc: "Loupe + / -" },
      { key: "ruler", label: "Règle", icon: Ruler, desc: "Mesurer" },
      { key: "center", label: "Centre", icon: Crosshair, desc: "Marquer le centre" },
      { key: "resize", label: "Taille", icon: Maximize2, desc: "Redimensionner" },
    ],
  },
  // ─── ROW 2: CRÉER / ♥ / SIGNER ───
  // Position: E (middle-right) = Symboles
  {
    key: "symbols", label: "Symboles", icon: Type, color: "#9263A6", desc: "Donner du sens",
    subs: [
      { key: "geo", label: "Géo", icon: Shapes, desc: "Formes géométriques" },
      { key: "letters", label: "Lettres", icon: Type, desc: "Alphabets complets" },
      { key: "numbers", label: "Chiffres", icon: Hash, desc: "0-9 et codes" },
      { key: "stitch", label: "Broderie", icon: Scissors, desc: "Symboles traditionnels" },
      { key: "access", label: "Accessibilité", icon: Accessibility, desc: "Contrastes forts" },
      { key: "popular", label: "Populaires", icon: Star, desc: "Les plus utilisés" },
      { key: "center", label: "Centrer", icon: AlignCenter, desc: "Aligner les symboles" },
      { key: "preview", label: "Aperçu", icon: Eye, desc: "Voir avec/sans" },
    ],
  },
  // ─── ROW 3: GUIDER / SORTIR / TRANSMETTRE ───
  // Position: SE (bottom-right) = Partage
  {
    key: "share", label: "Partage", icon: Share2, color: "#6BA7B0", desc: "Transmettre",
    subs: [
      { key: "link", label: "Lien", icon: Link, desc: "Copier le lien" },
      { key: "message", label: "Message", icon: MessageCircle, desc: "Envoyer à quelqu'un" },
      { key: "email", label: "Email", icon: Mail, desc: "Par email" },
      { key: "community", label: "Communauté", icon: Users, desc: "StitchLab" },
      { key: "web", label: "Web", icon: Globe, desc: "Publier en ligne" },
      { key: "send", label: "Envoyer", icon: Send, desc: "Envoi direct" },
      { key: "qr", label: "QR Code", icon: QrCode, desc: "Scanner pour voir" },
      { key: "copy", label: "Copier", icon: Copy, desc: "Texte résumé" },
    ],
  },
  // Position: S (bottom-center) = Export
  {
    key: "export", label: "Export", icon: Download, color: "#42A350", desc: "Sortir l'œuvre",
    subs: [
      { key: "pdf", label: "PDF", icon: FileText, desc: "Pattern complet" },
      { key: "png", label: "PNG", icon: FileImage, desc: "Image grille" },
      { key: "txt", label: "TXT", icon: File, desc: "Légende texte" },
      { key: "print", label: "Imprimer", icon: Printer, desc: "Impression directe" },
      { key: "save", label: "Sauver", icon: Save, desc: "Enregistrer projet" },
      { key: "copy", label: "Dupliquer", icon: Copy, desc: "Copier le pattern" },
      { key: "history", label: "Versions", icon: History, desc: "Historique" },
      { key: "archive", label: "Archive", icon: Archive, desc: "Archiver" },
    ],
  },
  // Position: SW (bottom-left) = Lily ✂️
  {
    key: "lily", label: "Lily", icon: Scissors, color: "#9263A6", desc: "Ta guide broderie",
    subs: [
      { key: "start", label: "Débuter", icon: Play, desc: "Premiers pas" },
      { key: "technique", label: "Technique", icon: BookOpen, desc: "Apprendre les gestes" },
      { key: "colors", label: "Couleurs", icon: Palette, desc: "Conseils palette" },
      { key: "trouble", label: "Problème", icon: HelpCircle, desc: "Résoudre un souci" },
      { key: "tips", label: "Astuces", icon: Lightbulb, desc: "Tips de pro" },
      { key: "timer", label: "Minuteur", icon: Timer, desc: "Pauses régulières" },
      { key: "progress", label: "Progrès", icon: Award, desc: "Ton avancement" },
      { key: "tools", label: "Outils", icon: Wrench, desc: "Matériel conseillé" },
    ],
  },
  // Position: W (middle-left) = Crayon
  {
    key: "draw", label: "Crayon", icon: Pencil, color: "#1a1a1a", desc: "Broder point par point",
    subs: [
      { key: "pencil", label: "Crayon", icon: Pencil, desc: "Point par point" },
      { key: "marker", label: "Marqueur", icon: Highlighter, desc: "Surligner une zone" },
      { key: "eraser", label: "Gomme", icon: Eraser, desc: "Effacer des points" },
      { key: "fill", label: "Remplir", icon: PaintBucket, desc: "Remplir une zone" },
      { key: "brush", label: "Pinceau", icon: Brush, desc: "Trait libre" },
      { key: "pick", label: "Pipette", icon: Pipette, desc: "Capturer une couleur" },
      { key: "undo", label: "Annuler", icon: Undo2, desc: "Retour en arrière" },
      { key: "line", label: "Ligne", icon: Minus, desc: "Trait droit" },
    ],
  },
  // Position: NW (top-left) = Photo
  {
    key: "photo", label: "Photo", icon: Camera, color: "#EB5B2E", desc: "Capturer le réel",
    subs: [
      { key: "gallery", label: "Galerie", icon: Camera, desc: "Depuis la galerie" },
      { key: "file", label: "Fichier", icon: Upload, desc: "Parcourir fichiers" },
      { key: "pdf", label: "PDF", icon: FileText, desc: "Pattern PDF" },
      { key: "image", label: "Image", icon: ImageIcon, desc: "PNG, JPG, SVG" },
      { key: "project", label: "Projet", icon: FolderOpen, desc: "Ouvrir un projet" },
      { key: "paste", label: "Coller", icon: Clipboard, desc: "Depuis le presse-papier" },
      { key: "blank", label: "Vierge", icon: Plus, desc: "Toile vierge" },
      { key: "template", label: "Modèle", icon: LayoutGrid, desc: "Choisir un modèle" },
    ],
  },
];

// 3×3 GRID LAYOUT — maps array index to position
// ┌────────┬────────┬────────┐
// │ NW [7] │ N  [0] │ NE [1] │  ← Row 1: Photo · DMC · Grille
// │ Photo  │ DMC    │ Grille │
// ├────────┼────────┼────────┤
// │ W  [6] │  ♥ ♥   │ E  [2] │  ← Row 2: Crayon · POINT · Symboles
// │ Crayon │ CŒUR   │ Symb.  │
// ├────────┼────────┼────────┤
// │ SW [5] │ S  [4] │ SE [3] │  ← Row 3: Lily · Export · Partage
// │ Lily   │ Export │ Partage│
// └────────┴────────┴────────┘
const OFFSETS: [number, number][] = [
  [0, -1], [1, -1], [1, 0], [1, 1],
  [0, 1], [-1, 1], [-1, 0], [-1, -1],
];

// ═══════════════════════════════════════════
// HEARTBEAT — Lub-dub cardiac rhythm
// ═══════════════════════════════════════════
const HEARTBEAT_KEYFRAMES = {
  scale: [1, 1.08, 1, 1.05, 1, 1, 1],
};
const HEARTBEAT_TRANSITION = {
  duration: 1.8,
  repeat: Infinity,
  ease: "easeInOut" as const,
  times: [0, 0.12, 0.24, 0.34, 0.46, 0.7, 1],
};

// ═══════════════════════════════════════════
// FUNCTIONAL PANELS (activated by sub-options)
// ═══════════════════════════════════════════

function PhotoImportPanel({ onClose }: { onClose: () => void }) {
  const [preview, setPreview] = useState<string | null>(null);
  const [legend, setLegend] = useState<{ code: string; name: string; hex: string; sym: string; count: number }[]>([]);
  const [gridW, setGridW] = useState(32);
  const [maxColors, setMaxColors] = useState(8);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const SYMS = ["X", "O", "+", "=", "/", "#", "@", "*", "~", "Z", "V", "T", "S", "M", "N"];

  const processImage = useCallback(() => {
    const img = imgRef.current;
    if (!img) return;
    const w = gridW;
    const aspect = img.height / img.width;
    const h = Math.round(w * aspect);
    const sampleCanvas = document.createElement("canvas");
    sampleCanvas.width = w; sampleCanvas.height = h;
    const sctx = sampleCanvas.getContext("2d")!;
    sctx.imageSmoothingEnabled = true;
    sctx.drawImage(img, 0, 0, w, h);
    const imageData = sctx.getImageData(0, 0, w, h);
    const pixels = imageData.data;
    const usable = DMC_COLORS.filter(c => !c.rare);
    const colorCounts = new Map<string, number>();
    const pixelDMC: string[][] = [];
    for (let y = 0; y < h; y++) {
      pixelDMC[y] = [];
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const r = pixels[i], g = pixels[i + 1], b = pixels[i + 2];
        let best = usable[0], bestD = Infinity;
        for (const c of usable) {
          const [cr, cg, cb] = hexToRgb(c.hex);
          const d = (r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2;
          if (d < bestD) { bestD = d; best = c; }
        }
        pixelDMC[y][x] = best.code;
        colorCounts.set(best.code, (colorCounts.get(best.code) || 0) + 1);
      }
    }
    const sorted = [...colorCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, maxColors);
    const keepCodes = new Set(sorted.map(s => s[0]));
    const legendData = sorted.map((entry, i) => {
      const dmc = DMC_COLORS.find(c => c.code === entry[0])!;
      return { code: dmc.code, name: dmc.name, hex: dmc.hex, sym: SYMS[i] || "?", count: entry[1] };
    });
    setLegend(legendData);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cellPx = Math.max(4, Math.min(8, Math.floor(260 / w)));
    canvas.width = w * cellPx; canvas.height = h * cellPx;
    const ctx = canvas.getContext("2d")!;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const code = pixelDMC[y][x];
        if (keepCodes.has(code)) {
          ctx.fillStyle = DMC_COLORS.find(c => c.code === code)?.hex || "#ccc";
        } else {
          ctx.fillStyle = DMC_COLORS.find(c => c.code === sorted[0][0])?.hex || "#ccc";
        }
        ctx.fillRect(x * cellPx, y * cellPx, cellPx - 0.3, cellPx - 0.3);
      }
    }
    setPreview(canvas.toDataURL());
  }, [gridW, maxColors]);

  const handleFile = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => { imgRef.current = img; processImage(); };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  }, [processImage]);

  useEffect(() => { if (imgRef.current) processImage(); }, [gridW, maxColors, processImage]);

  return (
    <motion.div className="flex flex-col gap-3"
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}>
      <canvas ref={canvasRef} className="hidden" />

      {!preview && !imgRef.current ? (
        <label className="flex flex-col items-center gap-3 cursor-pointer py-8 rounded-2xl"
          style={{ border: "2px dashed rgba(0,0,0,0.1)", backgroundColor: "rgba(0,0,0,0.015)" }}>
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background: GRADIENT }}>
            <Camera size={22} color="#fff" strokeWidth={1.5} />
          </div>
          <span style={{ fontSize: 13, color: "#999", fontWeight: 500 }}>Choisir une photo</span>
          <span style={{ fontSize: 10, color: "#ccc" }}>Conversion DMC instantanée</span>
          <input type="file" accept="image/*" className="hidden"
            onChange={(e) => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} />
        </label>
      ) : (
        <div className="flex flex-col gap-3">
          <div className="flex gap-4">
            <div className="flex-1">
              <label style={{ fontSize: 9, color: "#999", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                Largeur : {gridW} cases
              </label>
              <input type="range" min={16} max={80} value={gridW} onChange={(e) => setGridW(+e.target.value)}
                className="w-full" style={{ accentColor: FUCHSIA, height: 2 }} />
            </div>
            <div className="flex-1">
              <label style={{ fontSize: 9, color: "#999", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                Couleurs : {maxColors}
              </label>
              <input type="range" min={2} max={15} value={maxColors} onChange={(e) => setMaxColors(+e.target.value)}
                className="w-full" style={{ accentColor: "#C72B3B", height: 2 }} />
            </div>
          </div>
          {preview && (
            <img src={preview} alt="Pattern" className="rounded-xl w-full"
              style={{ imageRendering: "pixelated", maxHeight: 160, objectFit: "contain", border: "1px solid rgba(0,0,0,0.06)" }} />
          )}
          {legend.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {legend.map(l => (
                <div key={l.code} className="flex items-center gap-1.5 px-2 py-1 rounded-lg"
                  style={{ backgroundColor: `${l.hex}15`, border: `1px solid ${l.hex}30` }}>
                  <div className="w-4 h-4 rounded-[3px]" style={{ backgroundColor: l.hex }} />
                  <span style={{ fontSize: 9, color: "#666", fontWeight: 600 }}>{l.sym}</span>
                  <span style={{ fontSize: 8, color: "#999" }}>{l.code}</span>
                </div>
              ))}
            </div>
          )}
          <motion.button className="self-center px-4 py-2 rounded-xl border-none cursor-pointer"
            style={{ fontSize: 10, backgroundColor: "rgba(0,0,0,0.04)", color: "#999" }}
            onClick={() => { setPreview(null); imgRef.current = null; setLegend([]); }}
            whileTap={{ scale: 0.9 }}>
            Changer de photo
          </motion.button>
        </div>
      )}
    </motion.div>
  );
}

// DMC Browser Panel
function DMCBrowsePanel() {
  const [search, setSearch] = useState("");
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const allColors = DMC_COLORS.filter(c => !c.rare);
  const filtered = search.trim()
    ? allColors.filter(c => c.code.toLowerCase().includes(search.toLowerCase()) || c.name.toLowerCase().includes(search.toLowerCase()))
    : allColors;
  const selected = selectedColor ? allColors.find(c => c.code === selectedColor) : null;

  return (
    <motion.div className="flex flex-col gap-3"
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}>
      <div className="flex items-center gap-2 rounded-xl px-3 py-2" style={{ backgroundColor: "rgba(0,0,0,0.03)" }}>
        <Search size={14} color="#ccc" />
        <input className="flex-1 border-none outline-none" style={{ backgroundColor: "rgba(0,0,0,0)", fontSize: 13, color: "#1a1a1a" }}
          placeholder="Chercher DMC..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <span style={{ fontSize: 10, color: "#ccc" }}>{filtered.length}</span>
      </div>
      {selected && (
        <motion.div className="flex items-center gap-3 px-4 py-3 rounded-xl"
          style={{ backgroundColor: `${selected.hex}15`, border: `1px solid ${selected.hex}30` }}
          initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}>
          <div className="w-10 h-10 rounded-lg" style={{ backgroundColor: selected.hex, border: "1px solid rgba(0,0,0,0.08)" }} />
          <div className="flex-1">
            <div style={{ fontSize: 15, fontWeight: 600, color: "#1a1a1a" }}>DMC {selected.code}</div>
            <div style={{ fontSize: 10, color: "#888" }}>{selected.name}</div>
          </div>
          <motion.button className="w-8 h-8 rounded-lg flex items-center justify-center border-none cursor-pointer"
            style={{ backgroundColor: copied ? "rgba(66,163,80,0.15)" : "rgba(0,0,0,0.05)", color: copied ? "#42A350" : "#999" }}
            onClick={() => { navigator.clipboard.writeText(`DMC ${selected.code} ${selected.hex}`); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
            whileTap={{ scale: 0.85 }}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
          </motion.button>
        </motion.div>
      )}
      <div className="grid gap-0.5 overflow-y-auto" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(28px, 1fr))", maxHeight: 150 }}>
        {filtered.slice(0, 120).map((c) => (
          <motion.button key={c.code} className="rounded-[3px] border-none cursor-pointer"
            style={{
              aspectRatio: "1", backgroundColor: c.hex,
              outline: selectedColor === c.code ? `2.5px solid #1a1a1a` : "1px solid rgba(0,0,0,0.06)",
              outlineOffset: selectedColor === c.code ? -1 : 0,
            }}
            onClick={() => { setSelectedColor(c.code); setCopied(false); }}
            whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.85 }}
            title={`DMC ${c.code} — ${c.name}`} />
        ))}
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════
// MAIN POINT COMPONENT
// ═══════════════════════════════════════════

type PointPhase = "jewelry-box" | "reveal" | "idle" | "unfolded" | "tool-detail";

interface PointProps {
  onBack?: () => void;
}

export function Point({ onBack }: PointProps) {
  const [phase, setPhase] = useState<PointPhase>("jewelry-box");
  const [activeTool, setActiveTool] = useState<string | null>(null);
  const [activePanel, setActivePanel] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Responsive cell size
  const cellSize = 72;
  const gap = 6;
  const totalCell = cellSize + gap;

  // Auto-advance through intro
  useEffect(() => {
    if (phase === "jewelry-box") {
      const t = setTimeout(() => setPhase("reveal"), 2200);
      return () => clearTimeout(t);
    }
    if (phase === "reveal") {
      const t = setTimeout(() => setPhase("idle"), 1600);
      return () => clearTimeout(t);
    }
  }, [phase]);

  const handleCenterClick = () => {
    if (phase === "idle") setPhase("unfolded");
    else if (phase === "unfolded") {
      setActiveTool(null);
      setPhase("idle");
    }
    else if (phase === "tool-detail") {
      setActiveTool(null);
      setActivePanel(null);
      setPhase("unfolded");
    }
  };

  const handleToolClick = (toolKey: string) => {
    setActiveTool(toolKey);
    setPhase("tool-detail");
    setActivePanel(null);
    setActionFeedback(null);
  };

  const handleSubClick = (toolKey: string, subKey: string) => {
    // Special functional panels
    if (toolKey === "photo" && subKey === "gallery") {
      setActivePanel("photo-import");
      return;
    }
    if (toolKey === "dmc" && subKey === "browse") {
      setActivePanel("dmc-browse");
      return;
    }
    // Generic feedback for other sub-options
    const tool = TOOLS.find(t => t.key === toolKey);
    const sub = tool?.subs.find(s => s.key === subKey);
    if (sub) {
      setActionFeedback(sub.label);
      setTimeout(() => setActionFeedback(null), 1500);
    }
  };

  const currentTool = activeTool ? TOOLS.find(t => t.key === activeTool) : null;

  // What items to show in the 8 squares?
  const displayItems = phase === "tool-detail" && currentTool
    ? currentTool.subs.map(s => ({
        key: s.key,
        label: s.label,
        icon: s.icon,
        color: currentTool.color,
        desc: s.desc,
        isSub: true,
      }))
    : TOOLS.map(t => ({
        key: t.key,
        label: t.label,
        icon: t.icon,
        color: t.color,
        desc: t.desc,
        isSub: false,
      }));

  return (
    <div className="fixed inset-0 flex items-center justify-center overflow-hidden"
      style={{ fontFamily: "'Inter', -apple-system, sans-serif" }}>

      {/* ═══ PHASE 1: JEWELRY BOX ═══ */}
      <AnimatePresence>
        {phase === "jewelry-box" && (
          <motion.div key="jewelry-box" className="fixed inset-0 z-50 flex items-center justify-center"
            style={{ backgroundColor: "#000" }}
            exit={{ opacity: 0 }} transition={{ duration: 1 }}>

            {/* Ambient glow */}
            <motion.div className="absolute rounded-full"
              style={{
                width: 240, height: 240,
                background: `radial-gradient(circle, ${FUCHSIA}40 0%, ${ORANGE}20 50%, rgba(0,0,0,0) 70%)`,
              }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: [0, 1.5, 1.2], opacity: [0, 0.8, 0.6] }}
              transition={{ duration: 2, ease: "easeOut" }} />

            {/* Light crack vertical */}
            <motion.div className="absolute"
              style={{ width: 2, height: 0, background: GRADIENT, borderRadius: 1 }}
              animate={{ height: [0, 70, 90, 50], opacity: [0, 1, 0.8, 1] }}
              transition={{ duration: 1.5, ease: "easeInOut" }} />

            {/* Light crack horizontal */}
            <motion.div className="absolute"
              style={{ height: 2, width: 0, background: GRADIENT, borderRadius: 1 }}
              animate={{ width: [0, 70, 90, 50], opacity: [0, 1, 0.8, 1] }}
              transition={{ duration: 1.5, ease: "easeInOut", delay: 0.3 }} />

            {/* Sparkle particles */}
            {[...Array(8)].map((_, i) => (
              <motion.div key={i} className="absolute rounded-full"
                style={{ width: 3, height: 3, background: i % 2 === 0 ? FUCHSIA : ORANGE }}
                initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                animate={{
                  x: Math.cos((i / 8) * Math.PI * 2) * 70,
                  y: Math.sin((i / 8) * Math.PI * 2) * 70,
                  opacity: [0, 0.9, 0],
                  scale: [0, 1.2, 0],
                }}
                transition={{ duration: 1.5, delay: 0.8 + i * 0.06, ease: "easeOut" }} />
            ))}

            {/* Text */}
            <motion.span className="absolute" style={{ marginTop: 120 }}
              initial={{ opacity: 0 }} animate={{ opacity: 0.5 }}
              transition={{ delay: 1.2, duration: 0.8 }}>
              <span style={{ fontSize: 10, background: GRADIENT, WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)", letterSpacing: "0.4em", fontWeight: 300 }}>
                POINT
              </span>
            </motion.span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ BACKGROUND ═══ */}
      <motion.div className="fixed inset-0 -z-10"
        style={{ backgroundColor: "#000" }}
        animate={{
          backgroundColor: phase === "jewelry-box" ? "#000" : phase === "reveal" ? "#0a0a0a" : "#FAF8F5",
        }}
        transition={{ duration: 1.5 }} />

      {/* ═══ BACK BUTTON ═══ */}
      <AnimatePresence>
        {phase !== "jewelry-box" && onBack && (
          <motion.button
            className="fixed top-5 left-5 z-40 flex items-center gap-2 cursor-pointer border-none rounded-xl px-4 py-2.5"
            style={{ backgroundColor: "rgba(0,0,0,0.05)", color: "#999", fontSize: 12 }}
            onClick={onBack}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ delay: 0.5 }}
            whileHover={{ x: -3 }} whileTap={{ scale: 0.95 }}>
            <ChevronLeft size={14} /> Retour
          </motion.button>
        )}
      </AnimatePresence>

      {/* ═══ BREADCRUMB (in tool-detail) ═══ */}
      <AnimatePresence>
        {phase === "tool-detail" && currentTool && (
          <motion.div className="fixed top-5 z-30 flex items-center gap-2"
            style={{ left: "50%", transform: "translateX(-50%)" }}
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <motion.button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border-none cursor-pointer"
              style={{ backgroundColor: `${currentTool.color}15`, color: currentTool.color, fontSize: 11, fontWeight: 500 }}
              onClick={() => { setActiveTool(null); setActivePanel(null); setPhase("unfolded"); }}
              whileTap={{ scale: 0.95 }}>
              <ChevronLeft size={12} />
              {currentTool.label}
            </motion.button>
            <span style={{ fontSize: 9, color: "#ccc" }}>{currentTool.desc}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ THE CUBE ═══ */}
      <AnimatePresence>
        {(phase === "reveal" || phase === "idle" || phase === "unfolded" || phase === "tool-detail") && !activePanel && (
          <motion.div className="relative z-10"
            style={{ width: totalCell * 3, height: totalCell * 3 }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}>

            {/* 8 SURROUNDING SQUARES */}
            <AnimatePresence mode="wait">
              {(phase === "unfolded" || phase === "tool-detail") && (
                <motion.div key={phase === "tool-detail" ? `subs-${activeTool}` : "tools"}>
                  {displayItems.map((item, i) => {
                    const [ox, oy] = OFFSETS[i];
                    const Icon = item.icon;

                    return (
                      <motion.div key={`${item.key}-${i}`} className="absolute z-10"
                        style={{
                          left: (1 + ox) * totalCell,
                          top: (1 + oy) * totalCell,
                          width: cellSize,
                          height: cellSize,
                        }}
                        initial={{ opacity: 0, scale: 0, x: -ox * totalCell, y: -oy * totalCell, rotate: -90 }}
                        animate={{ opacity: 1, scale: 1, x: 0, y: 0, rotate: 0 }}
                        exit={{ opacity: 0, scale: 0, x: -ox * totalCell, y: -oy * totalCell, rotate: 90 }}
                        transition={{ type: "spring", stiffness: 400, damping: 24, delay: i * 0.04 }}>
                        <motion.button
                          className="w-full h-full flex flex-col items-center justify-center rounded-xl border-none cursor-pointer relative overflow-hidden"
                          style={{
                            backgroundColor: item.color,
                            boxShadow: `0 4px 20px ${item.color}40`,
                          }}
                          onClick={() => {
                            if (item.isSub) {
                              handleSubClick(activeTool!, item.key);
                            } else {
                              handleToolClick(item.key);
                            }
                          }}
                          whileHover={{ scale: 1.08, boxShadow: `0 8px 30px ${item.color}50` }}
                          whileTap={{ scale: 0.92 }}>

                          {/* Icon — big and white */}
                          <Icon size={26} strokeWidth={1.8} color="#fff" />

                          {/* Label */}
                          <span style={{
                            fontSize: 8,
                            color: "rgba(255,255,255,0.85)",
                            marginTop: 5,
                            letterSpacing: "0.04em",
                            fontWeight: 500,
                            textTransform: "uppercase",
                          }}>
                            {item.label}
                          </span>

                          {/* Subtle inner glow */}
                          <div className="absolute inset-0 rounded-xl pointer-events-none"
                            style={{
                              background: `radial-gradient(circle at 30% 30%, rgba(255,255,255,0.15) 0%, rgba(0,0,0,0) 60%)`,
                            }} />
                        </motion.button>
                      </motion.div>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>

            {/* ═══ CENTER SQUARE — THE POINT ═══ */}
            <motion.button
              className="absolute z-20 flex flex-col items-center justify-center border-none cursor-pointer overflow-hidden rounded-xl"
              style={{
                left: totalCell,
                top: totalCell,
                width: cellSize,
                height: cellSize,
                background: phase === "tool-detail" && currentTool
                  ? currentTool.color
                  : GRADIENT,
                boxShadow: phase === "unfolded" || phase === "tool-detail"
                  ? `0 8px 36px ${FUCHSIA}45`
                  : `0 6px 30px ${FUCHSIA}35, 0 0 70px ${FUCHSIA}15`,
              }}
              onClick={handleCenterClick}
              initial={{ scale: 0, opacity: 0, rotate: -180 }}
              animate={{
                scale: 1, opacity: 1, rotate: 0,
                ...(phase === "idle" ? HEARTBEAT_KEYFRAMES : {}),
              }}
              transition={phase === "idle" ? HEARTBEAT_TRANSITION : { type: "spring", stiffness: 300, damping: 20, delay: 0.2 }}
              whileHover={{ scale: phase === "idle" ? 1.12 : 1.06 }}
              whileTap={{ scale: 0.88 }}>

              {/* White Heart */}
              {(phase !== "tool-detail") && (
                <span style={{
                  fontSize: 28,
                  color: "#fff",
                  lineHeight: 1,
                  textShadow: "0 2px 8px rgba(0,0,0,0.15)",
                  position: "relative",
                  zIndex: 2,
                }}>
                  ♥
                </span>
              )}

              {/* Tool icon when in detail mode */}
              {phase === "tool-detail" && currentTool && (
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 400, damping: 20 }}>
                  <currentTool.icon size={28} strokeWidth={1.8} color="#fff" />
                </motion.div>
              )}

              {/* Rotating Cross X */}
              <motion.div
                className="absolute"
                style={{ zIndex: 1 }}
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}>
                <X size={52} strokeWidth={0.6} color="rgba(255,255,255,0.2)" />
              </motion.div>

              {/* Inner glow */}
              <div className="absolute inset-0 rounded-xl pointer-events-none"
                style={{
                  background: "radial-gradient(circle at 35% 35%, rgba(255,255,255,0.2) 0%, rgba(0,0,0,0) 60%)",
                }} />

              {/* Idle pulse glow */}
              {phase === "idle" && (
                <motion.div className="absolute inset-0 rounded-xl pointer-events-none"
                  style={{ background: `radial-gradient(circle, rgba(255,255,255,0.2) 0%, rgba(0,0,0,0) 70%)` }}
                  animate={{ opacity: [0, 0.6, 0] }}
                  transition={{ duration: 2.5, repeat: Infinity }} />
              )}
            </motion.button>

            {/* Action feedback toast */}
            <AnimatePresence>
              {actionFeedback && (
                <motion.div className="absolute z-40 flex items-center gap-2 px-4 py-2.5 rounded-full"
                  style={{
                    top: totalCell * 3 + 16,
                    left: "50%",
                    transform: "translateX(-50%)",
                    backgroundColor: currentTool?.color || "#1a1a1a",
                    color: "#fff",
                    fontSize: 12,
                    fontWeight: 500,
                    boxShadow: `0 4px 20px ${currentTool?.color || "#1a1a1a"}50`,
                    whiteSpace: "nowrap",
                  }}
                  initial={{ opacity: 0, y: -8, scale: 0.9 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.9 }}>
                  <Check size={14} />
                  {actionFeedback}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ FUNCTIONAL PANEL (replaces cube when active) ═══ */}
      <AnimatePresence>
        {activePanel && (
          <motion.div className="fixed inset-0 z-30 flex items-center justify-center px-4"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="w-full max-w-sm rounded-3xl overflow-hidden"
              style={{
                backgroundColor: "rgba(255,255,255,0.98)",
                backdropFilter: "blur(30px)",
                boxShadow: `0 20px 60px rgba(0,0,0,0.1), 0 0 0 1px ${currentTool?.color || FUCHSIA}15`,
              }}
              initial={{ y: 30, scale: 0.95 }} animate={{ y: 0, scale: 1 }} exit={{ y: 30, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}>
              {/* Panel header */}
              <div className="flex items-center justify-between px-5 py-4"
                style={{ borderBottom: `1px solid rgba(0,0,0,0.06)` }}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: currentTool?.color || FUCHSIA }}>
                    {currentTool && <currentTool.icon size={16} color="#fff" strokeWidth={1.5} />}
                  </div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: "#1a1a1a" }}>
                      {activePanel === "photo-import" ? "Photo" : activePanel === "dmc-browse" ? "Palette DMC" : ""}
                    </div>
                    <div style={{ fontSize: 9, color: "#bbb" }}>{currentTool?.desc}</div>
                  </div>
                </div>
                <motion.button className="w-8 h-8 flex items-center justify-center rounded-full border-none cursor-pointer"
                  style={{ backgroundColor: "rgba(0,0,0,0.05)", color: "#999" }}
                  onClick={() => setActivePanel(null)}
                  whileTap={{ scale: 0.85 }}>
                  <X size={14} />
                </motion.button>
              </div>
              {/* Panel content */}
              <div className="px-5 py-4 max-h-[420px] overflow-y-auto">
                {activePanel === "photo-import" && <PhotoImportPanel onClose={() => setActivePanel(null)} />}
                {activePanel === "dmc-browse" && <DMCBrowsePanel />}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ IDLE LABEL ═══ */}
      <AnimatePresence>
        {(phase === "idle" || phase === "reveal") && (
          <motion.div className="fixed z-10 flex flex-col items-center gap-1.5"
            style={{ bottom: "14%" }}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }} transition={{ delay: 0.8, duration: 0.6 }}>
            <motion.span
              style={{
                fontSize: 13,
                letterSpacing: "0.4em",
                fontWeight: 600,
                background: GRADIENT,
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "rgba(0,0,0,0)",
              }}
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 3, repeat: Infinity }}>
              POINT
            </motion.span>
            <span style={{ fontSize: 10, color: "#bbb", letterSpacing: "0.08em" }}>
              Touche le cœur
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ UNFOLDED LABEL ═══ */}
      <AnimatePresence>
        {phase === "unfolded" && (
          <motion.div className="fixed z-10 flex flex-col items-center gap-1"
            style={{ bottom: "8%" }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            exit={{ opacity: 0 }} transition={{ delay: 0.3 }}>
            <span style={{ fontSize: 10, color: "#ccc", letterSpacing: "0.06em" }}>
              8 outils · 1 carré · tout ton atelier
            </span>
            <span style={{ fontSize: 8, color: "#ddd" }}>
              Chaque outil ouvre 8 options
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ TOOL-DETAIL LABEL ═══ */}
      <AnimatePresence>
        {phase === "tool-detail" && !activePanel && currentTool && (
          <motion.div className="fixed z-10 flex flex-col items-center gap-1"
            style={{ bottom: "8%" }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            exit={{ opacity: 0 }} transition={{ delay: 0.2 }}>
            <span style={{ fontSize: 10, color: currentTool.color, letterSpacing: "0.06em", fontWeight: 500 }}>
              {currentTool.label}
            </span>
            <span style={{ fontSize: 8, color: "#ccc" }}>
              Choisis parmi 8 options · Centre pour revenir
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}