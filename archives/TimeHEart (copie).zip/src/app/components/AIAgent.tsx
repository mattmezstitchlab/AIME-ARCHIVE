import { useState, useRef, useEffect, useCallback, type Dispatch, type SetStateAction } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Send, Sparkles, MapPin, ImagePlus, Download, Scissors, Wifi, WifiOff, Volume2, VolumeX, BarChart3 } from "lucide-react";
import { useResponsive } from "./useResponsive";
import * as api from "./api";
import {
  BG_IVORY,
  DMC_COLORS,
  MOCK_PLAYERS,
  PLAYER_INTERESTS,
  INTEREST_KEYWORDS,
  type InterestTag,
  type PlayerData,
} from "./game-data";

// ═══════════════════════════════════════════
// LILY — AI Embroidery Expert for StitchLab
// Powered by Claude (Anthropic) with fallback
// to local knowledge base when offline.
// Voice: OpenAI TTS — Nova
// ═══════════════════════════════════════════

interface AIAgentProps {
  visible: boolean;
  onClose: () => void;
  onTeleportTo?: (x: number, y: number) => void;
  playerPos?: { x: number; y: number };
  currentPlayer?: PlayerData;
  userInterests: Set<InterestTag>;
  onUserInterestsChange: Dispatch<SetStateAction<Set<InterestTag>>>;
  suggestedPlayers: Set<string>;
  onSuggestedPlayersChange: Dispatch<SetStateAction<Set<string>>>;
}

interface Message {
  id: number;
  role: "lily" | "user";
  text: string;
  suggestion?: { pseudo: string; color: string; symbol: string; x: number; y: number };
  pattern?: PatternData;
}

interface PatternData {
  grid: { hex: string; dmcCode: string; symbol: string }[][];
  width: number;
  height: number;
  legend: { dmcCode: string; hex: string; symbol: string; name: string; count: number }[];
  imageUrl: string;
}

// ─── LOCAL FALLBACK KNOWLEDGE BASE ───
const KNOWLEDGE: { keywords: string[]; answer: string }[] = [
  { keywords: ["aida", "toile", "tissu", "count", "ct"], answer: "La toile Aida est ideale pour debuter. 14 count = 14 points par pouce (debutant). 16-18 count pour des details plus fins. Le lin 28-32 count pour les expertes. Evenweave pour un look plus doux. Pro tip : prelave toujours ta toile !" },
  { keywords: ["dmc", "fil", "mouline", "echevette"], answer: "DMC, c'est LA reference depuis 1746. 500+ couleurs de mouline 6 brins. Pour le point de croix, on utilise generalement 2 brins sur Aida 14ct. L'astuce : separe chaque brin puis rassemble-les pour un rendu plus lisse. C'est le \"railroading\"." },
  { keywords: ["debutant", "debuter", "commencer", "apprendre", "premier"], answer: "Pour debuter : 1) Procure-toi de la toile Aida 14ct blanche, un tambour 15cm, des aiguilles 24, et quelques echevettes DMC. 2) Commence par un petit motif (max 50x50 points). 3) Demarre toujours par le centre. 4) Fais tous les demi-points dans le meme sens !" },
  { keywords: ["point de croix", "cross stitch", "croix"], answer: "Le point de croix : deux diagonales croisees sur une case de la toile. Regle d'or : toutes les croix dans le meme sens (/ dessous, \\ dessus, ou l'inverse — mais toujours pareil). Ca fait toute la difference de proprete." },
  { keywords: ["noeud", "knot", "francais", "french"], answer: "Le noeud francais : enroule le fil 1-2 fois autour de l'aiguille, puis pique juste a cote du point de sortie. L'erreur classique : piquer au meme endroit (le noeud passe a travers). Avec un Colonial Knot, c'est plus facile et plus rond !" },
  { keywords: ["tambour", "hoop", "cercle", "cadre"], answer: "Le tambour (hoop) garde ta toile tendue. 15cm pour debuter, plus grand pour les gros projets. En bois de hetre ou en plastique Nurge (top qualite). Un Q-snap est genial pour les grands ouvrages." },
  { keywords: ["pattern", "patron", "grille", "motif", "convertir", "photo"], answer: "Tu veux un pattern ? Glisse-depose une photo dans notre conversation et je la transforme en grille point de croix avec les codes DMC !" },
  { keywords: ["backstitch", "arriere", "contour"], answer: "Le point arriere (backstitch) sert aux contours et details. Toujours le faire EN DERNIER, apres tous les points de croix. Utilise 1 brin de DMC 310 (noir) pour un contour fin et net." },
  { keywords: ["blackwork", "black work"], answer: "Le blackwork est une technique de broderie en noir utilisant des motifs geometriques repetes. Originaire d'Espagne, popularise en Angleterre par Catherine d'Aragon. C'est HYPNOTIQUE." },
  { keywords: ["hardanger"], answer: "Le hardanger, c'est la haute couture de la broderie ! Originaire de Norvege, il combine des blocs de points satin (kloster blocks) avec des fils coupes et tisses." },
  { keywords: ["sashiko"], answer: "Le sashiko japonais : broderie fonctionnelle a l'origine (renforcement des textiles). Points avant reguliers, motifs geometriques zen. Fil blanc sur indigo, c'est la signature." },
  { keywords: ["lily", "toi", "qui es"], answer: "Je suis Lily, l'ame de StitchLab et ta compagne de broderie. Demande-moi n'importe quoi sur les points, les fils, les techniques... ou glisse-moi une photo !" },
  { keywords: ["battement", "coeur", "pulse"], answer: "Un battement est ta facon de dire « je brode ici ». Un pulse visible par toutes les brodeuses autour de toi." },
  { keywords: ["sortie", "event", "evenement", "atelier"], answer: "Les sorties sont des ateliers et rencontres broderie ! Cree-en une depuis le menu radial. Stitch & bitch, atelier initiation, broderie au cafe..." },
];

function findKnowledgeAnswer(input: string): string | null {
  const lower = input.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  for (const entry of KNOWLEDGE) {
    for (const kw of entry.keywords) {
      const kwNorm = kw.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (lower.includes(kwNorm)) return entry.answer;
    }
  }
  return null;
}

// ─── DMC COLOR MATCHING ───
const DMC_NON_RARE = DMC_COLORS.filter((c) => !c.rare && c.code !== "Blanc" && c.code !== "310");

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function colorDistance(a: [number, number, number], b: [number, number, number]): number {
  return Math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2);
}

function findNearestDMC(r: number, g: number, b: number, palette: typeof DMC_NON_RARE) {
  let best = palette[0];
  let bestDist = Infinity;
  for (const c of palette) {
    const rgb = hexToRgb(c.hex);
    const d = colorDistance([r, g, b], rgb);
    if (d < bestDist) { bestDist = d; best = c; }
  }
  return best;
}

const PATTERN_SYMBOLS = ["X", "O", "+", "=", "/", "\\", "#", "@", "*", "~", "Z", "V", "N", "T", "U", "S", "A", "D", "H", "M"];

function imageToPattern(img: HTMLImageElement, targetWidth: number = 40, maxColors: number = 12): PatternData {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d")!;
  const aspect = img.height / img.width;
  const w = targetWidth;
  const h = Math.round(w * aspect);
  canvas.width = w; canvas.height = h;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(img, 0, 0, w, h);
  const imageData = ctx.getImageData(0, 0, w, h);
  const pixels = imageData.data;
  const colorCounts = new Map<string, { dmc: typeof DMC_NON_RARE[0]; count: number }>();
  const rawGrid: { r: number; g: number; b: number }[][] = [];
  for (let y = 0; y < h; y++) {
    rawGrid[y] = [];
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      rawGrid[y][x] = { r: pixels[i], g: pixels[i + 1], b: pixels[i + 2] };
      const dmc = findNearestDMC(pixels[i], pixels[i + 1], pixels[i + 2], DMC_NON_RARE);
      const existing = colorCounts.get(dmc.code);
      if (existing) existing.count++; else colorCounts.set(dmc.code, { dmc, count: 1 });
    }
  }
  const sortedColors = Array.from(colorCounts.entries()).sort((a, b) => b[1].count - a[1].count).slice(0, maxColors);
  const allowedPalette = sortedColors.map(([, v]) => v.dmc);
  const legend: PatternData["legend"] = allowedPalette.map((dmc, i) => ({
    dmcCode: dmc.code, hex: dmc.hex, symbol: PATTERN_SYMBOLS[i % PATTERN_SYMBOLS.length], name: dmc.name, count: 0,
  }));
  const symbolMap = new Map<string, string>();
  legend.forEach((l) => symbolMap.set(l.dmcCode, l.symbol));
  const grid: PatternData["grid"] = [];
  for (let y = 0; y < h; y++) {
    grid[y] = [];
    for (let x = 0; x < w; x++) {
      const { r, g, b } = rawGrid[y][x];
      const dmc = findNearestDMC(r, g, b, allowedPalette);
      const sym = symbolMap.get(dmc.code) || "?";
      grid[y][x] = { hex: dmc.hex, dmcCode: dmc.code, symbol: sym };
      const leg = legend.find((l) => l.dmcCode === dmc.code);
      if (leg) leg.count++;
    }
  }
  const previewCanvas = document.createElement("canvas");
  const pctx = previewCanvas.getContext("2d")!;
  const cellPx = 6;
  previewCanvas.width = w * cellPx; previewCanvas.height = h * cellPx;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { pctx.fillStyle = grid[y][x].hex; pctx.fillRect(x * cellPx, y * cellPx, cellPx, cellPx); }
  return { grid, width: w, height: h, legend, imageUrl: previewCanvas.toDataURL("image/png") };
}

function detectInterests(text: string): InterestTag[] {
  const lower = text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const found: InterestTag[] = [];
  for (const [tag, keywords] of Object.entries(INTEREST_KEYWORDS)) {
    for (const kw of keywords) { if (lower.includes(kw.normalize("NFD").replace(/[\u0300-\u036f]/g, ""))) { found.push(tag as InterestTag); break; } }
  }
  return found;
}

function getDirection(fromX: number, fromY: number, toX: number, toY: number): string {
  const dx = toX - fromX; const dy = toY - fromY; const dist = Math.round(Math.sqrt(dx * dx + dy * dy));
  const parts: string[] = [];
  if (dy < -1) parts.push("nord"); if (dy > 1) parts.push("sud");
  if (dx > 1) parts.push("est"); if (dx < -1) parts.push("ouest");
  return `${parts.join("-") || "tout pres"}, a ${dist} pas`;
}

function findMatches(userInterests: Set<InterestTag>, alreadySuggested: Set<string>) {
  if (userInterests.size === 0) return [];
  const matches: { player: PlayerData; profile: typeof PLAYER_INTERESTS[0]; overlap: InterestTag[]; score: number }[] = [];
  for (const profile of PLAYER_INTERESTS) {
    if (alreadySuggested.has(profile.playerId)) continue;
    const overlap = profile.interests.filter((i) => userInterests.has(i));
    if (overlap.length > 0) {
      const player = MOCK_PLAYERS.find((p) => p.id === profile.playerId);
      if (player) matches.push({ player, profile, overlap, score: overlap.length });
    }
  }
  return matches.sort((a, b) => b.score - a.score).slice(0, 3);
}

// ═══════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════

export function AIAgent({
  visible, onClose, onTeleportTo, playerPos = { x: 0, y: 0 },
  currentPlayer, userInterests, onUserInterestsChange,
  suggestedPlayers, onSuggestedPlayersChange,
}: AIAgentProps) {
  const { isMobile } = useResponsive();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [initialized, setInitialized] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [aiConnected, setAiConnected] = useState(true);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<number | null>(null);
  const [sessionCost, setSessionCost] = useState(0);
  const [showUsage, setShowUsage] = useState(false);
  const [globalUsage, setGlobalUsage] = useState<api.LilyUsageResponse | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const idRef = useRef(0);
  const voiceEnabledRef = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioUrlRef = useRef<string | null>(null);
  const ttsCacheRef = useRef<Map<string, Blob>>(new Map());

  const nextId = () => ++idRef.current;

  // Keep ref in sync with state for use in callbacks
  useEffect(() => { voiceEnabledRef.current = voiceEnabled; }, [voiceEnabled]);

  // Simple hash for client-side cache key
  const hashForCache = (text: string): string => {
    let h = 0;
    const s = text.trim().toLowerCase();
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    }
    return `tts-${h >>> 0}`;
  };

  // ─── VOICE — OpenAI TTS (Nova) with client cache ───
  const speak = useCallback(async (text: string, msgId: number) => {
    try {
      // Stop any current playback
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }

      setSpeakingMsgId(msgId);

      const cacheKey = hashForCache(text);
      let audioBlob = ttsCacheRef.current.get(cacheKey);

      if (!audioBlob) {
        audioBlob = await api.speakWithLily(text);
        ttsCacheRef.current.set(cacheKey, audioBlob);
      }

      const url = URL.createObjectURL(audioBlob);
      audioUrlRef.current = url;

      const audio = new Audio(url);
      audioRef.current = audio;

      audio.onended = () => {
        setSpeakingMsgId(null);
        URL.revokeObjectURL(url);
        audioUrlRef.current = null;
        audioRef.current = null;
      };
      audio.onerror = () => {
        console.error("Lily Nova audio playback error");
        setSpeakingMsgId(null);
        URL.revokeObjectURL(url);
        audioUrlRef.current = null;
        audioRef.current = null;
      };

      await audio.play();
    } catch (err) {
      console.error("Lily TTS (Nova) error:", err);
      setSpeakingMsgId(null);
    }
  }, []);

  const stopSpeaking = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    setSpeakingMsgId(null);
  }, []);

  useEffect(() => { if (!visible) stopSpeaking(); }, [visible, stopSpeaking]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) audioRef.current.pause();
      if (audioUrlRef.current) URL.revokeObjectURL(audioUrlRef.current);
    };
  }, []);

  // Initialize Lily's greeting
  useEffect(() => {
    if (visible && !initialized) {
      const greetId = nextId();
      setMessages([{ id: greetId, role: "lily", text: "Bonjour ! Je suis Lily, ton experte broderie." }]);
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { id: nextId(), role: "lily", text: "Pose-moi n'importe quelle question sur les points, les fils DMC, les techniques... ou glisse-moi une photo et je te genere un pattern point de croix instantanement !" },
        ]);
      }, 1200);
      setInitialized(true);
    }
  }, [visible, initialized]);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const addLilyMessage = useCallback((text: string, suggestion?: Message["suggestion"], pattern?: PatternData) => {
    const id = nextId();
    setMessages((prev) => [...prev, { id, role: "lily", text, suggestion, pattern }]);
    // Auto-speak if voice is enabled
    if (voiceEnabledRef.current && !pattern) {
      setTimeout(() => speak(text, id), 100);
    }
  }, [speak]);

  // ─── SEND TO LILY AI ───
  const sendToLily = useCallback(async (allMessages: Message[]) => {
    const userContext: api.LilyUserContext = {
      pseudo: currentPlayer?.pseudo, city: currentPlayer?.city,
      intention: currentPlayer?.intention, interests: Array.from(userInterests),
    };
    const chatMessages: api.LilyChatMessage[] = allMessages
      .filter((m) => m.text && !m.text.startsWith("[Photo"))
      .map((m) => ({ role: m.role, text: m.text }));
    try {
      setIsThinking(true);
      const response = await api.chatWithLily(chatMessages, userContext);
      setAiConnected(true);
      return response.text;
    } catch (err) {
      console.error("Lily AI error, falling back to local:", err);
      setAiConnected(false);
      const lastUserMsg = allMessages.filter((m) => m.role === "user").pop();
      if (lastUserMsg) { const local = findKnowledgeAnswer(lastUserMsg.text); if (local) return local; }
      return "Hmm, le fil s'est emmele... Reessaie dans un instant. En attendant, n'hesite pas a me glisser une photo pour un pattern !";
    } finally {
      setIsThinking(false);
    }
  }, [currentPlayer, userInterests]);

  // ─── PHOTO → PATTERN ───
  const handleImageFile = useCallback((file: File) => {
    setMessages((prev) => [...prev, { id: nextId(), role: "user", text: `[Photo : ${file.name}]` }]);
    setTimeout(() => addLilyMessage("Je regarde ta photo... Laisse-moi analyser les couleurs et creer ta grille DMC..."), 400);
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        try {
          const pattern = imageToPattern(img, 40, 12);
          setTimeout(() => {
            addLilyMessage(`Voila ton pattern ! ${pattern.width}x${pattern.height} points, ${pattern.legend.length} couleurs DMC. Chaque symbole correspond a un fil.`, undefined, pattern);
            const patternContext: Message = {
              id: nextId(), role: "user",
              text: `Je viens de convertir une photo en pattern ${pattern.width}x${pattern.height} avec ${pattern.legend.length} couleurs DMC (${pattern.legend.map(l => `DMC ${l.dmcCode} ${l.name}`).join(", ")}). Donne-moi un conseil pour broder ce pattern.`,
            };
            setMessages((prev) => {
              sendToLily([...prev, patternContext]).then((tip) => { if (tip) addLilyMessage(tip); });
              return prev;
            });
          }, 1500);
        } catch { addLilyMessage("Hmm, je n'ai pas reussi a lire cette image. Essaie avec un JPG ou PNG classique !"); }
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  }, [addLilyMessage, sendToLily]);

  const handleDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); }, []);
  const handleDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); }, []);
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type.startsWith("image/")) handleImageFile(files[0]);
  }, [handleImageFile]);

  // ─── TEXT SEND ───
  const handleSend = useCallback(async () => {
    if (!input.trim() || isThinking) return;
    const userText = input.trim();
    const userMsg: Message = { id: nextId(), role: "user", text: userText };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    const newInterests = detectInterests(userText);
    const updatedInterests = new Set(userInterests);
    newInterests.forEach((i) => updatedInterests.add(i));
    if (newInterests.length > 0) onUserInterestsChange(updatedInterests);
    const allMessages = [...messages, userMsg];
    const response = await sendToLily(allMessages);
    if (response) addLilyMessage(response);
    if (updatedInterests.size >= 2) {
      const matches = findMatches(updatedInterests, suggestedPlayers);
      if (matches.length > 0) {
        const best = matches[0];
        const dir = getDirection(playerPos.x, playerPos.y, best.player.x, best.player.y);
        setTimeout(() => {
          addLilyMessage(
            `Il y a une brodeuse pas loin qui partage tes passions... ${best.profile.lilyNote} Points communs : ${best.overlap.join(", ")}. Direction ${dir}.`,
            { pseudo: best.player.pseudo, color: best.player.colorHex, symbol: best.player.symbol, x: best.player.x, y: best.player.y },
          );
          onSuggestedPlayersChange((prev) => { const n = new Set(prev); n.add(best.player.id); return n; });
        }, 2000);
      }
    }
  }, [input, isThinking, messages, userInterests, suggestedPlayers, playerPos, addLilyMessage, onUserInterestsChange, onSuggestedPlayersChange, sendToLily]);

  const interestChips = Array.from(userInterests);

  const downloadPattern = useCallback((pattern: PatternData) => {
    const lines: string[] = [
      "═══════════════════════════════════════",
      "  STITCHLAB — Pattern genere par Lily",
      `  ${pattern.width} x ${pattern.height} points`,
      `  ${pattern.legend.length} couleurs DMC`,
      "═══════════════════════════════════════", "",
      "LEGENDE :",
    ];
    pattern.legend.forEach((l) => lines.push(`  ${l.symbol}  →  DMC ${l.dmcCode} (${l.name}) — ${l.count} points`));
    lines.push("", "GRILLE :", "  " + Array.from({ length: pattern.width }, (_, i) => (i % 10 === 0 ? "|" : " ")).join(""));
    pattern.grid.forEach((row, y) => lines.push(`${String(y + 1).padStart(3, " ")} ${row.map((c) => c.symbol).join("")}`));
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `stitchlab-pattern-${pattern.width}x${pattern.height}.txt`; a.click();
    URL.revokeObjectURL(url);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <>
          <motion.div
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(250,248,245,0.4)", backdropFilter: "blur(4px)" }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.div
            className="fixed z-50 flex flex-col rounded-2xl overflow-hidden"
            style={{
              bottom: isMobile ? 10 : 40, right: isMobile ? 10 : 40, left: isMobile ? 10 : "auto",
              width: isMobile ? "calc(100vw - 20px)" : 400,
              height: isMobile ? "calc(100vh - 120px)" : 580, maxHeight: "85vh",
              backgroundColor: "rgba(255,255,255,0.97)", backdropFilter: "blur(24px)",
              boxShadow: "0 16px 64px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.02)",
            }}
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.25 }}
            onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}
          >
            {/* HEADER */}
            <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid rgba(0,0,0,0.04)" }}>
              <div className="flex items-center gap-2.5">
                <motion.div
                  className="rounded-[4px] flex items-center justify-center"
                  style={{ width: 32, height: 32, background: "linear-gradient(135deg, #9263A6 0%, #6B3F7F 100%)", boxShadow: "0 2px 8px rgba(146,99,166,0.3)" }}
                  animate={{ scale: [1, 1.03, 1] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                  <Scissors size={14} color="#fff" strokeWidth={1.5} />
                </motion.div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span style={{ fontSize: 13, fontWeight: 500, color: "#1a1a1a" }}>Lily</span>
                    <motion.div className="flex items-center gap-0.5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
                      {aiConnected ? <Wifi size={8} color="#42A350" strokeWidth={2} /> : <WifiOff size={8} color="#ccc" strokeWidth={2} />}
                      <span style={{ fontSize: 7, color: aiConnected ? "#42A350" : "#ccc", fontWeight: 400, letterSpacing: "0.04em" }}>
                        {aiConnected ? "IA" : "local"}
                      </span>
                    </motion.div>
                  </div>
                  <span style={{ fontSize: 8, color: "#9263A6", letterSpacing: "0.06em", fontWeight: 400 }}>
                    {userInterests.size === 0 ? "Experte broderie · StitchLab" :
                      userInterests.size < 3 ? "Decouvre ton style" : `${userInterests.size} passions detectees`}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {/* VOICE TOGGLE */}
                <motion.button
                  className="flex items-center justify-center rounded-full border-none cursor-pointer"
                  style={{
                    width: 28, height: 28,
                    backgroundColor: voiceEnabled ? "rgba(146,99,166,0.12)" : "rgba(0,0,0,0.04)",
                    color: voiceEnabled ? "#9263A6" : "#ccc",
                  }}
                  onClick={() => {
                    if (voiceEnabled) stopSpeaking();
                    setVoiceEnabled(!voiceEnabled);
                  }}
                  whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                  title={voiceEnabled ? "Desactiver la voix de Lily" : "Activer la voix de Lily"}
                >
                  {voiceEnabled ? <Volume2 size={12} /> : <VolumeX size={12} />}
                </motion.button>
                <motion.button
                  className="flex items-center justify-center rounded-full border-none cursor-pointer"
                  style={{ width: 28, height: 28, backgroundColor: "rgba(0,0,0,0.04)", color: "#aaa" }}
                  onClick={onClose}
                  whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                >
                  <X size={13} />
                </motion.button>
              </div>
            </div>

            {/* INTEREST CHIPS */}
            {interestChips.length > 0 && (
              <motion.div
                className="flex flex-wrap gap-1 px-4 py-2"
                style={{ borderBottom: "1px solid rgba(0,0,0,0.03)" }}
                initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} transition={{ duration: 0.3 }}
              >
                {interestChips.map((tag) => (
                  <span key={tag} className="px-2 py-0.5 rounded-full"
                    style={{ fontSize: 8, fontWeight: 400, color: "#9263A6", backgroundColor: "#9263A610", letterSpacing: "0.04em" }}>
                    {tag}
                  </span>
                ))}
              </motion.div>
            )}

            {/* DRAG OVERLAY */}
            <AnimatePresence>
              {isDragging && (
                <motion.div
                  className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3"
                  style={{ backgroundColor: "rgba(146,99,166,0.06)", border: "2px dashed #9263A640", borderRadius: 16 }}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                >
                  <ImagePlus size={40} color="#9263A6" strokeWidth={1} />
                  <span style={{ fontSize: 13, color: "#9263A6", fontWeight: 500 }}>Depose ta photo ici</span>
                  <span style={{ fontSize: 10, color: "#9263A680" }}>Lily la transforme en pattern point de croix</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* MESSAGES */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-3">
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
                  initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}
                >
                  {/* Message bubble with voice button for Lily messages */}
                  <div className="flex items-end gap-1.5 group" style={{ maxWidth: "88%" }}>
                    <div
                      className="rounded-2xl px-3.5 py-2.5 flex-1"
                      style={{
                        backgroundColor: msg.role === "user" ? "#1a1a1a" : "rgba(146,99,166,0.06)",
                        color: msg.role === "user" ? BG_IVORY : "#555",
                        fontSize: 12, lineHeight: 1.7, fontWeight: 400,
                        borderTopRightRadius: msg.role === "user" ? 4 : 18,
                        borderTopLeftRadius: msg.role === "lily" ? 4 : 18,
                      }}
                    >
                      {msg.text}
                    </div>

                    {/* Speaker button on Lily messages */}
                    {msg.role === "lily" && (
                      <motion.button
                        className="flex items-center justify-center rounded-full border-none cursor-pointer flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        style={{
                          width: 22, height: 22, marginBottom: 4,
                          backgroundColor: speakingMsgId === msg.id ? "rgba(146,99,166,0.15)" : "rgba(0,0,0,0.04)",
                          color: speakingMsgId === msg.id ? "#9263A6" : "#bbb",
                        }}
                        onClick={() => speakingMsgId === msg.id ? stopSpeaking() : speak(msg.text, msg.id)}
                        whileHover={{ scale: 1.15 }} whileTap={{ scale: 0.9 }}
                        title="Ecouter"
                      >
                        {speakingMsgId === msg.id ? (
                          <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 0.6, repeat: Infinity }}>
                            <Volume2 size={10} />
                          </motion.div>
                        ) : (
                          <Volume2 size={10} />
                        )}
                      </motion.button>
                    )}
                  </div>

                  {/* PATTERN DISPLAY */}
                  {msg.pattern && (
                    <motion.div className="mt-2 rounded-xl overflow-hidden"
                      style={{ maxWidth: "95%", backgroundColor: "#fff", border: "1px solid rgba(146,99,166,0.12)", boxShadow: "0 2px 16px rgba(146,99,166,0.08)" }}
                      initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}
                    >
                      <div className="p-3">
                        <img src={msg.pattern.imageUrl} alt="Cross-stitch pattern" className="w-full rounded-lg"
                          style={{ imageRendering: "pixelated", border: "1px solid rgba(0,0,0,0.06)" }} />
                      </div>
                      <div className="px-3 pb-2">
                        <p style={{ fontSize: 8, letterSpacing: "0.12em", color: "#bbb", textTransform: "uppercase", marginBottom: 6 }}>
                          Legende DMC — {msg.pattern.legend.length} couleurs
                        </p>
                        <div className="grid grid-cols-2 gap-1">
                          {msg.pattern.legend.map((l) => (
                            <div key={l.dmcCode} className="flex items-center gap-1.5 py-0.5">
                              <div className="rounded-[2px] flex items-center justify-center" style={{ width: 16, height: 16, backgroundColor: l.hex, fontSize: 8, color: "#fff", fontWeight: 700 }}>{l.symbol}</div>
                              <span style={{ fontSize: 8, color: "#888" }}>{l.dmcCode} <span style={{ color: "#ccc" }}>({l.count})</span></span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <motion.button
                        className="w-full flex items-center justify-center gap-2 py-2.5 border-none cursor-pointer"
                        style={{ backgroundColor: "#9263A6", color: "#fff", fontSize: 10, fontWeight: 500, borderBottomLeftRadius: 12, borderBottomRightRadius: 12 }}
                        onClick={() => downloadPattern(msg.pattern!)}
                        whileHover={{ backgroundColor: "#7B4F8F" }} whileTap={{ scale: 0.98 }}
                      >
                        <Download size={12} strokeWidth={1.5} />
                        Telecharger le pattern
                      </motion.button>
                    </motion.div>
                  )}

                  {/* PLAYER SUGGESTION */}
                  {msg.suggestion && (
                    <motion.div
                      className="mt-2 flex items-center gap-2.5 px-3 py-2.5 rounded-xl cursor-pointer"
                      style={{ backgroundColor: "rgba(255,255,255,0.9)", border: "1px solid rgba(146,99,166,0.15)", boxShadow: "0 2px 12px rgba(146,99,166,0.08)" }}
                      initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2, duration: 0.3 }}
                      onClick={() => onTeleportTo?.(msg.suggestion!.x, msg.suggestion!.y)}
                      whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                    >
                      <div className="rounded-[3px] flex items-center justify-center flex-shrink-0"
                        style={{ width: 28, height: 28, backgroundColor: msg.suggestion.color, fontSize: 13, color: "#fff", lineHeight: 1 }}>
                        {msg.suggestion.symbol}
                      </div>
                      <div className="flex flex-col flex-1">
                        <span style={{ fontSize: 11, fontWeight: 500, color: "#1a1a1a" }}>{msg.suggestion.pseudo}</span>
                        <span style={{ fontSize: 8, color: "#bbb" }}>Coordonnees {msg.suggestion.x}, {msg.suggestion.y}</span>
                      </div>
                      <div className="flex items-center gap-1" style={{ color: "#9263A6" }}>
                        <MapPin size={10} strokeWidth={1.5} />
                        <span style={{ fontSize: 8, fontWeight: 400 }}>Visiter</span>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              ))}

              {/* Thinking indicator */}
              {isThinking && (
                <motion.div className="flex items-start" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
                  <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-2xl" style={{ backgroundColor: "rgba(146,99,166,0.06)", borderTopLeftRadius: 4 }}>
                    <div className="flex gap-1">
                      {[0, 0.2, 0.4].map((d) => (
                        <motion.div key={d} className="rounded-full" style={{ width: 4, height: 4, backgroundColor: "#9263A6" }}
                          animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 1, repeat: Infinity, delay: d }} />
                      ))}
                    </div>
                    <span style={{ fontSize: 9, color: "#B48DC4", fontStyle: "italic" }}>Lily reflechit...</span>
                  </div>
                </motion.div>
              )}
            </div>

            {/* INPUT */}
            <div className="flex items-center gap-2 px-3 py-2.5" style={{ borderTop: "1px solid rgba(0,0,0,0.04)" }}>
              <motion.button
                className="flex items-center justify-center rounded-xl border-none cursor-pointer"
                style={{ width: 36, height: 36, backgroundColor: "rgba(146,99,166,0.06)", color: "#9263A6" }}
                onClick={() => fileInputRef.current?.click()}
                whileHover={{ scale: 1.05, backgroundColor: "rgba(146,99,166,0.12)" }} whileTap={{ scale: 0.95 }}
                title="Envoyer une photo pour un pattern"
              >
                <ImagePlus size={14} strokeWidth={1.5} />
              </motion.button>
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden"
                onChange={(e) => { if (e.target.files?.[0]) handleImageFile(e.target.files[0]); e.target.value = ""; }} />
              <input
                type="text" value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") handleSend(); }}
                placeholder={isThinking ? "Lily reflechit..." : "Parle broderie avec Lily..."}
                disabled={isThinking}
                className="flex-1 px-3 py-2 rounded-xl border-none outline-none"
                style={{ backgroundColor: "rgba(0,0,0,0.03)", fontSize: 12, color: "#1a1a1a", opacity: isThinking ? 0.5 : 1 }}
              />
              <motion.button
                className="flex items-center justify-center rounded-xl border-none cursor-pointer"
                style={{
                  width: 36, height: 36,
                  backgroundColor: input.trim() && !isThinking ? "#9263A6" : "rgba(0,0,0,0.04)",
                  color: input.trim() && !isThinking ? "#fff" : "#ccc",
                }}
                onClick={handleSend}
                whileHover={input.trim() && !isThinking ? { scale: 1.05 } : {}}
                whileTap={input.trim() && !isThinking ? { scale: 0.95 } : {}}
              >
                <Send size={14} strokeWidth={1.5} />
              </motion.button>
            </div>

            {/* FOOTER */}
            <div className="flex items-center gap-2 px-4 py-2" style={{ borderTop: "1px solid rgba(0,0,0,0.03)" }}>
              <Sparkles size={9} color="#9263A6" strokeWidth={1.5} />
              <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ backgroundColor: "rgba(0,0,0,0.04)" }}>
                <motion.div className="h-full rounded-full"
                  style={{ background: "linear-gradient(90deg, #B48DC4 0%, #9263A6 50%, #6B3F7F 100%)" }}
                  animate={{ width: `${Math.min(userInterests.size * 15, 100)}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }} />
              </div>
              <span style={{ fontSize: 7, color: "#ccc", letterSpacing: "0.06em" }}>Expertise</span>
              {/* USAGE TOGGLE — admin only */}
              <motion.button
                className="flex items-center justify-center rounded-full border-none cursor-pointer"
                style={{ width: 18, height: 18, backgroundColor: showUsage ? "rgba(146,99,166,0.12)" : "rgba(0,0,0,0.03)", color: showUsage ? "#9263A6" : "#ddd" }}
                onClick={() => {
                  setShowUsage(!showUsage);
                  if (!showUsage) { api.getLilyUsage().then(setGlobalUsage).catch(() => {}); }
                }}
                whileHover={{ scale: 1.15 }} whileTap={{ scale: 0.85 }}
                title="Usage & couts Lily"
              >
                <BarChart3 size={8} />
              </motion.button>
            </div>

            {/* USAGE DASHBOARD PANEL */}
            <AnimatePresence>
              {showUsage && globalUsage && (
                <motion.div
                  className="px-4 py-3"
                  style={{ borderTop: "1px solid rgba(146,99,166,0.08)", backgroundColor: "rgba(146,99,166,0.02)" }}
                  initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span style={{ fontSize: 8, fontWeight: 600, color: "#9263A6", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                      Metrologie Lily
                    </span>
                    <span style={{ fontSize: 11, fontWeight: 600, color: "#1a1a1a" }}>
                      ${globalUsage.usage.estimatedCostUSD.toFixed(4)}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    <div className="flex flex-col items-center rounded-lg py-1.5" style={{ backgroundColor: "rgba(0,0,0,0.02)" }}>
                      <span style={{ fontSize: 14, fontWeight: 300, color: "#1a1a1a" }}>{globalUsage.usage.totalChatCalls}</span>
                      <span style={{ fontSize: 7, color: "#bbb" }}>chats</span>
                    </div>
                    <div className="flex flex-col items-center rounded-lg py-1.5" style={{ backgroundColor: "rgba(0,0,0,0.02)" }}>
                      <span style={{ fontSize: 14, fontWeight: 300, color: "#1a1a1a" }}>{globalUsage.usage.totalTTSCalls}</span>
                      <span style={{ fontSize: 7, color: "#bbb" }}>TTS</span>
                    </div>
                    <div className="flex flex-col items-center rounded-lg py-1.5" style={{ backgroundColor: "rgba(0,0,0,0.02)" }}>
                      <span style={{ fontSize: 14, fontWeight: 300, color: "#42A350" }}>{globalUsage.derived?.ttsCacheHitRate || 0}%</span>
                      <span style={{ fontSize: 7, color: "#bbb" }}>cache</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {globalUsage.derived?.costBreakdown && (
                      <div className="flex items-center gap-2 flex-1">
                        <div className="flex flex-col">
                          <span style={{ fontSize: 7, color: "#bbb" }}>Claude</span>
                          <span style={{ fontSize: 9, color: "#666" }}>
                            ${(globalUsage.derived.costBreakdown.claudeInput + globalUsage.derived.costBreakdown.claudeOutput).toFixed(4)}
                          </span>
                        </div>
                        <div className="flex flex-col">
                          <span style={{ fontSize: 7, color: "#bbb" }}>Nova</span>
                          <span style={{ fontSize: 9, color: "#666" }}>
                            ${globalUsage.derived.costBreakdown.tts.toFixed(4)}
                          </span>
                        </div>
                        {globalUsage.derived.savedByCache > 0 && (
                          <div className="flex flex-col">
                            <span style={{ fontSize: 7, color: "#42A350" }}>Economise</span>
                            <span style={{ fontSize: 9, color: "#42A350", fontWeight: 500 }}>
                              -${globalUsage.derived.savedByCache.toFixed(4)}
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                    <motion.button
                      className="px-2 py-1 rounded-md border-none cursor-pointer"
                      style={{ fontSize: 7, backgroundColor: "rgba(0,0,0,0.04)", color: "#ccc" }}
                      onClick={() => { api.getLilyUsage().then(setGlobalUsage).catch(() => {}); }}
                      whileTap={{ scale: 0.9 }}
                    >
                      Refresh
                    </motion.button>
                  </div>
                  <div className="mt-2 pt-1.5" style={{ borderTop: "1px dashed rgba(0,0,0,0.06)" }}>
                    <span style={{ fontSize: 7, color: "#ddd", lineHeight: 1.6 }}>
                      {globalUsage.usage.totalInputTokens.toLocaleString()} tokens in · {globalUsage.usage.totalOutputTokens.toLocaleString()} tokens out · {globalUsage.usage.totalTTSChars.toLocaleString()} chars TTS
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}