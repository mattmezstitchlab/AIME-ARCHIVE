import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Flower2, MapPin, X } from "lucide-react";
import { useResponsive } from "./useResponsive";
import {
  MOCK_PLAYERS,
  PLAYER_INTERESTS,
  type InterestTag,
  type PlayerData,
} from "./game-data";

// ═══════════════════════════════════════════
// LILY NOTIFICATION
// Ambient, poetic notifications when a
// matching player is nearby on the grid
// ═══════════════════════════════════════════

interface LilyNotificationProps {
  playerPos: { x: number; y: number };
  userInterests: Set<InterestTag>;
  suggestedPlayers: Set<string>;
  onTeleportTo?: (x: number, y: number) => void;
  onOpenLily?: () => void;
  onDismiss?: (playerId: string) => void;
}

interface NearbyMatch {
  player: PlayerData;
  overlap: InterestTag[];
  distance: number;
  lilyNote: string;
}

const PROXIMITY_RADIUS = 10; // cells
const CHECK_INTERVAL = 8000; // check every 8 seconds (meditative pace)
const DISPLAY_DURATION = 12000; // show notification for 12 seconds

const LILY_WHISPERS = [
  "Lily a repere un fil...",
  "Une brodeuse pas loin...",
  "Un motif en commun...",
  "Lily sent une connexion...",
  "Memes couleurs, meme passion...",
];

export function LilyNotification({
  playerPos,
  userInterests,
  suggestedPlayers,
  onTeleportTo,
  onOpenLily,
  onDismiss,
}: LilyNotificationProps) {
  const { isMobile } = useResponsive();
  const [currentNotif, setCurrentNotif] = useState<NearbyMatch | null>(null);
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const findNearbyMatch = useCallback((): NearbyMatch | null => {
    if (userInterests.size < 1) return null;

    const matches: NearbyMatch[] = [];

    for (const profile of PLAYER_INTERESTS) {
      // Skip already suggested/dismissed/notified players
      if (suggestedPlayers.has(profile.playerId)) continue;
      if (dismissed.has(profile.playerId)) continue;

      const player = MOCK_PLAYERS.find((p) => p.id === profile.playerId);
      if (!player) continue;

      const dx = player.x - playerPos.x;
      const dy = player.y - playerPos.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance <= PROXIMITY_RADIUS && distance > 0) {
        const overlap = profile.interests.filter((i) => userInterests.has(i));
        if (overlap.length > 0) {
          matches.push({
            player,
            overlap,
            distance: Math.round(distance),
            lilyNote: profile.lilyNote,
          });
        }
      }
    }

    // Pick the closest match
    matches.sort((a, b) => a.distance - b.distance);
    return matches[0] || null;
  }, [playerPos, userInterests, suggestedPlayers, dismissed]);

  // Periodic check for nearby matches
  useEffect(() => {
    if (userInterests.size === 0) return;

    const check = () => {
      const match = findNearbyMatch();
      if (match && !visible) {
        setCurrentNotif(match);
        setVisible(true);

        // Auto-hide after duration
        setTimeout(() => {
          setVisible(false);
        }, DISPLAY_DURATION);
      }
    };

    // Initial check after a delay
    const initialTimeout = setTimeout(check, 4000);
    const interval = setInterval(check, CHECK_INTERVAL);

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, [findNearbyMatch, userInterests, visible]);

  const handleDismiss = useCallback(() => {
    setVisible(false);
    if (currentNotif) {
      setDismissed((prev) => {
        const n = new Set(prev);
        n.add(currentNotif.player.id);
        return n;
      });
      onDismiss?.(currentNotif.player.id);
    }
  }, [currentNotif, onDismiss]);

  const handleVisit = useCallback(() => {
    if (currentNotif) {
      onTeleportTo?.(currentNotif.player.x, currentNotif.player.y);
      setVisible(false);
      setDismissed((prev) => {
        const n = new Set(prev);
        n.add(currentNotif.player.id);
        return n;
      });
    }
  }, [currentNotif, onTeleportTo]);

  const whisper = LILY_WHISPERS[Math.floor(Math.random() * LILY_WHISPERS.length)];

  return (
    <AnimatePresence>
      {visible && currentNotif && (
        <motion.div
          className="fixed z-40"
          style={{
            top: isMobile ? 70 : 80,
            right: isMobile ? 10 : 20,
            left: isMobile ? 10 : "auto",
            width: isMobile ? "calc(100vw - 20px)" : 300,
          }}
          initial={{ opacity: 0, y: -12, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -8, scale: 0.98 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              backgroundColor: "rgba(255,255,255,0.95)",
              backdropFilter: "blur(20px)",
              boxShadow: "0 8px 40px rgba(146,99,166,0.12), 0 0 0 1px rgba(146,99,166,0.06)",
            }}
          >
            {/* Top accent line */}
            <motion.div
              className="h-[2px]"
              style={{ background: "linear-gradient(90deg, rgba(0,0,0,0) 0%, #B48DC4 50%, rgba(0,0,0,0) 100%)" }}
              animate={{ opacity: [0.4, 0.8, 0.4] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />

            <div className="px-4 py-3">
              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <motion.div
                    className="rounded-[3px] flex items-center justify-center"
                    style={{
                      width: 20, height: 20,
                      background: "linear-gradient(135deg, #B48DC4 0%, #9263A6 100%)",
                    }}
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <Flower2 size={10} color="#fff" strokeWidth={1.5} />
                  </motion.div>
                  <span style={{ fontSize: 9, color: "#B48DC4", fontWeight: 400, letterSpacing: "0.04em" }}>
                    {whisper}
                  </span>
                </div>
                <motion.button
                  className="flex items-center justify-center rounded-full border-none cursor-pointer"
                  style={{ width: 20, height: 20, backgroundColor: "rgba(0,0,0,0)" }}
                  onClick={handleDismiss}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X size={10} color="#ccc" />
                </motion.button>
              </div>

              {/* Match content */}
              <div className="flex items-start gap-3">
                {/* Player square */}
                <motion.div
                  className="rounded-[3px] flex items-center justify-center flex-shrink-0"
                  style={{
                    width: 36, height: 36,
                    backgroundColor: currentNotif.player.colorHex,
                    fontSize: 17, color: "#fff", lineHeight: 1,
                    boxShadow: `0 2px 12px ${currentNotif.player.colorHex}30`,
                  }}
                  animate={{ scale: [1, 1.02, 1] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                >
                  {currentNotif.player.symbol}
                </motion.div>

                <div className="flex-1 min-w-0">
                  <p style={{
                    fontSize: 11, color: "#555", lineHeight: 1.6,
                    fontWeight: 400, margin: 0,
                  }}>
                    {currentNotif.lilyNote}
                  </p>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {currentNotif.overlap.map((tag) => (
                      <span
                        key={tag}
                        className="px-1.5 py-0.5 rounded-full"
                        style={{ fontSize: 7, color: "#9263A6", backgroundColor: "#9263A610" }}
                      >
                        {tag}
                      </span>
                    ))}
                    <span style={{ fontSize: 7, color: "#ccc", alignSelf: "center" }}>
                      · {currentNotif.distance} pas
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-3">
                <motion.button
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border-none cursor-pointer py-2"
                  style={{
                    backgroundColor: "#9263A6",
                    color: "#fff",
                    fontSize: 10,
                    fontWeight: 500,
                  }}
                  onClick={handleVisit}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <MapPin size={10} strokeWidth={1.5} />
                  Visiter
                </motion.button>
                <motion.button
                  className="flex items-center justify-center gap-1.5 rounded-xl border-none cursor-pointer py-2 px-4"
                  style={{
                    backgroundColor: "rgba(146,99,166,0.08)",
                    color: "#9263A6",
                    fontSize: 10,
                    fontWeight: 400,
                  }}
                  onClick={() => { onOpenLily?.(); setVisible(false); }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Flower2 size={10} strokeWidth={1.5} />
                  Parler à Lily
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}