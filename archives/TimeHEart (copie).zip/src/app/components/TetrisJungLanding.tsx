import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, ArrowRight, RefreshCw, SlidersHorizontal, Send, Circle, Square, Triangle } from "lucide-react";

// ═══════════════════════════════════════════
// LE TETRIS DE JUNG — Résonance Artificielle
// "Personne n'est carré. Personne n'est complet.
//  Mais certaines formes savent s'assembler."
// ═══════════════════════════════════════════

const BRAND = {
  indigo: "#1E1B4B",
  indigoLight: "#3730A3",
  violet: "#6D5BA3",
  lavender: "#A5B4FC",
  frost: "#EEF2FF",
  white: "#FAFBFF",
  dark: "#0F0E26",
  gray: "#6B7280",
  accent: "#4F46E5",
};

// Organic shape forms representing Jungian archetypes
const SHAPES = [
  { id: "cercle", label: "Cercle", desc: "L'unité, le Soi — la totalité sans angle", icon: Circle, color: "#818CF8" },
  { id: "carre", label: "Carré", desc: "La structure, l'ordre — la stabilité consciente", icon: Square, color: "#6366F1" },
  { id: "triangle", label: "Triangle", desc: "La tension, l'élan — l'aspiration vers le haut", icon: Triangle, color: "#4F46E5" },
];

const CONCEPTS = [
  { title: "Résonance", desc: "Les formes ne se complètent pas — elles résonnent. Comme deux instruments qui jouent ensemble." },
  { title: "Espace Liminal", desc: "L'espace entre deux formes, où la rencontre est possible. Ni l'un ni l'autre : les deux." },
  { title: "Le Noyau", desc: "Une IA au centre qui perçoit les formes, sans les juger. Présence d'entité — pas d'algorithme." },
  { title: "Carte Sensible", desc: "Pas un matching. Une cartographie vivante des résonances humaines, dessinée par l'invisible." },
];

interface TetrisJungLandingProps {
  onBack?: () => void;
  onNavigate?: (screen: string) => void;
}

export function TetrisJungLanding({ onBack }: TetrisJungLandingProps) {
  const [selectedShape, setSelectedShape] = useState<string | null>(null);
  const [time, setTime] = useState(0);
  const [noyauConnected, setNoyauConnected] = useState(false);

  useEffect(() => {
    let frame: number;
    const animate = () => {
      setTime((t) => t + 0.008);
      frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setNoyauConnected(true), 2500);
    return () => clearTimeout(timer);
  }, []);

  // Generate organic resonance circles
  const circles = useMemo(() => {
    return Array.from({ length: 5 }, (_, i) => ({
      id: i,
      cx: 250 + Math.cos((i / 5) * Math.PI * 2) * (80 + i * 25),
      cy: 250 + Math.sin((i / 5) * Math.PI * 2) * (60 + i * 20),
      r: 120 + i * 40,
    }));
  }, []);

  return (
    <div
      className="fixed inset-0 overflow-y-auto overflow-x-hidden"
      style={{
        background: `radial-gradient(ellipse at 30% 30%, ${BRAND.frost} 0%, ${BRAND.white} 50%, #F5F3FF 100%)`,
        fontFamily: "'Inter', -apple-system, sans-serif",
      }}
    >
      {/* ═══ NAV ═══ */}
      <motion.nav
        className="sticky top-0 z-50 flex items-center justify-between px-6 py-4"
        style={{
          backgroundColor: "rgba(250,251,255,0.85)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid rgba(99,102,241,0.06)",
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="flex items-center gap-4">
          {onBack && (
            <motion.button
              className="flex items-center gap-2 border-none cursor-pointer rounded-lg px-3 py-1.5"
              style={{ backgroundColor: "rgba(79,70,229,0.04)", color: BRAND.gray, fontSize: 11 }}
              onClick={onBack}
              whileTap={{ scale: 0.95 }}
              whileHover={{ backgroundColor: "rgba(79,70,229,0.08)" }}
            >
              <ArrowLeft size={14} />
              Retour
            </motion.button>
          )}
          <div>
            <span style={{ fontSize: 14, fontWeight: 600, color: BRAND.indigo }}>Résonance Artificielle</span>
            <div className="flex items-center gap-2 mt-0.5">
              <span style={{ fontSize: 9, color: BRAND.gray, letterSpacing: "0.06em" }}>Espace Liminal (Privé)</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <AnimatePresence>
            {noyauConnected && (
              <motion.div
                className="flex items-center gap-2"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                style={{ fontSize: 9, color: BRAND.accent, fontWeight: 500, letterSpacing: "0.06em" }}
              >
                <motion.div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: BRAND.accent }}
                  animate={{ opacity: [1, 0.4, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                CONNECTÉ AU NOYAU
              </motion.div>
            )}
          </AnimatePresence>
          <motion.button
            className="border-none cursor-pointer p-2 rounded-full"
            style={{ backgroundColor: "rgba(79,70,229,0.04)", color: BRAND.gray }}
            whileHover={{ backgroundColor: "rgba(79,70,229,0.08)" }}
            whileTap={{ scale: 0.95 }}
          >
            <RefreshCw size={14} />
          </motion.button>
          <motion.button
            className="border-none cursor-pointer p-2 rounded-full"
            style={{ backgroundColor: "rgba(79,70,229,0.04)", color: BRAND.gray }}
            whileHover={{ backgroundColor: "rgba(79,70,229,0.08)" }}
            whileTap={{ scale: 0.95 }}
          >
            <SlidersHorizontal size={14} />
          </motion.button>
        </div>
      </motion.nav>

      {/* ═══ RESONANCE VISUALIZATION ═══ */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
        {/* Animated organic circles - like the screenshot */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 500 500"
          preserveAspectRatio="xMidYMid slice"
          style={{ opacity: 0.25 }}
        >
          {circles.map((c) => (
            <motion.circle
              key={c.id}
              cx={c.cx + Math.sin(time * 0.3 + c.id * 1.2) * 15}
              cy={c.cy + Math.cos(time * 0.25 + c.id * 0.9) * 12}
              r={c.r + Math.sin(time * 0.15 + c.id * 0.7) * 8}
              fill="none"
              stroke={BRAND.lavender}
              strokeWidth={0.8}
              style={{ opacity: 0.4 + Math.sin(time * 0.2 + c.id) * 0.2 }}
            />
          ))}
          {/* Inner smaller intersecting arcs */}
          {[0, 1, 2].map((i) => (
            <motion.circle
              key={`inner-${i}`}
              cx={250 + Math.cos(time * 0.2 + (i / 3) * Math.PI * 2) * 40}
              cy={250 + Math.sin(time * 0.18 + (i / 3) * Math.PI * 2) * 35}
              r={60 + i * 30 + Math.sin(time * 0.3 + i) * 5}
              fill="none"
              stroke={BRAND.accent}
              strokeWidth={0.5}
              style={{ opacity: 0.15 + Math.sin(time * 0.4 + i * 1.5) * 0.1 }}
            />
          ))}
        </svg>

        {/* Center: "Ma Forme Intérieure" */}
        <motion.div
          className="relative z-10 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 1.5 }}
        >
          <p style={{ fontSize: 10, color: BRAND.violet, letterSpacing: "0.25em", marginBottom: 16 }}>
            MA FORME INTÉRIEURE
          </p>
          <div className="flex items-center justify-center gap-6">
            {SHAPES.map((shape) => (
              <motion.button
                key={shape.id}
                className="flex flex-col items-center gap-2 border-none cursor-pointer p-4 rounded-2xl"
                style={{
                  backgroundColor: selectedShape === shape.id ? "rgba(79,70,229,0.08)" : "rgba(0,0,0,0)",
                  border: selectedShape === shape.id ? "1px solid rgba(79,70,229,0.15)" : "1px solid rgba(0,0,0,0)",
                }}
                onClick={() => setSelectedShape(shape.id === selectedShape ? null : shape.id)}
                whileHover={{ scale: 1.08, backgroundColor: "rgba(79,70,229,0.05)" }}
                whileTap={{ scale: 0.95 }}
              >
                <shape.icon
                  size={28}
                  style={{
                    color: selectedShape === shape.id ? shape.color : "rgba(99,102,241,0.3)",
                    transition: "color 0.3s",
                  }}
                  strokeWidth={1.5}
                />
                <span style={{ fontSize: 9, color: selectedShape === shape.id ? shape.color : BRAND.gray, letterSpacing: "0.05em" }}>
                  {shape.label}
                </span>
              </motion.button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            {selectedShape && (
              <motion.p
                key={selectedShape}
                className="mt-4"
                style={{ fontSize: 11, color: BRAND.violet, maxWidth: 280, margin: "16px auto 0", lineHeight: 1.6 }}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
              >
                {SHAPES.find((s) => s.id === selectedShape)?.desc}
              </motion.p>
            )}
          </AnimatePresence>
          <p className="mt-6" style={{ fontSize: 10, color: "rgba(99,102,241,0.3)", cursor: "pointer" }}>
            Cliquer pour changer de forme
          </p>
        </motion.div>
      </section>

      {/* ═══ HERO TEXT — Le Tetris de Jung ═══ */}
      <section className="py-32 px-6">
        <motion.div
          className="max-w-2xl mx-auto text-center"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 1 }}
        >
          <h1
            style={{
              fontSize: "clamp(36px, 7vw, 64px)",
              fontWeight: 300,
              color: BRAND.indigo,
              lineHeight: 1.15,
              fontFamily: "'Georgia', 'Times New Roman', serif",
              fontStyle: "italic",
            }}
          >
            Le Tetris de Jung
          </h1>

          <motion.div
            className="mt-8"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 1 }}
          >
            <p style={{ fontSize: "clamp(14px, 2.5vw, 18px)", color: BRAND.gray, lineHeight: 1.8 }}>
              Personne n'est carré. Personne n'est complet.
              <br />
              Mais certaines formes savent s'assembler.
            </p>
          </motion.div>

          {/* Quote block */}
          <motion.blockquote
            className="mt-12 text-left mx-auto"
            style={{
              maxWidth: 480,
              paddingLeft: 20,
              borderLeft: `3px solid ${BRAND.lavender}`,
            }}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <p style={{ fontSize: 13, color: BRAND.gray, lineHeight: 1.9, fontStyle: "italic" }}>
              "Le but n'est pas de faire disparaître les formes, mais de leur trouver
              une juste place. Représenter visuellement que les êtres humains ne
              sont pas des profils à comparer, mais des formes intérieures à accorder."
            </p>
          </motion.blockquote>

          {/* CTA */}
          <motion.button
            className="mt-12 border-none cursor-pointer rounded-full px-8 py-4 flex items-center gap-3 mx-auto"
            style={{
              backgroundColor: BRAND.indigo,
              color: "#fff",
              fontSize: 14,
              fontWeight: 500,
              letterSpacing: "0.02em",
              boxShadow: `0 8px 30px rgba(30,27,75,0.2)`,
            }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.7 }}
            whileHover={{ scale: 1.03, boxShadow: `0 12px 40px rgba(30,27,75,0.3)` }}
            whileTap={{ scale: 0.97 }}
          >
            Explorer la Carte Sensible <ArrowRight size={16} />
          </motion.button>

          <motion.p
            className="mt-6"
            style={{ fontSize: 11, color: "rgba(107,114,128,0.5)" }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.9 }}
          >
            Inspiré de Carl Gustav Jung · Expérience Conceptuelle
          </motion.p>
        </motion.div>
      </section>

      {/* ═══ SCREENSHOTS ═══ */}
      <section className="py-24 px-6">
        <motion.div
          className="max-w-5xl mx-auto"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <div className="grid gap-8 md:grid-cols-2">
            {/* Résonance Artificielle mockup */}
            <motion.div
              className="rounded-2xl overflow-hidden relative"
              style={{
                border: "1px solid rgba(99,102,241,0.08)",
                boxShadow: "0 20px 60px rgba(30,27,75,0.06)",
                height: 320,
                background: `radial-gradient(circle at 40% 40%, ${BRAND.frost} 0%, #F5F3FF 100%)`,
              }}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              {/* Resonance circles */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 320">
                {[0, 1, 2, 3].map((i) => (
                  <circle key={i} cx={160 + i * 25} cy={160} r={80 + i * 30} fill="none" stroke={BRAND.lavender} strokeWidth={0.8} opacity={0.3 - i * 0.05} />
                ))}
                {[0, 1, 2].map((i) => (
                  <circle key={`b-${i}`} cx={240 - i * 15} cy={140 + i * 20} r={60 + i * 25} fill="none" stroke={BRAND.accent} strokeWidth={0.5} opacity={0.15} />
                ))}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p style={{ fontSize: 10, color: BRAND.accent, letterSpacing: "0.2em", fontWeight: 500 }}>RÉSONANCE</p>
                <p style={{ fontSize: 10, color: BRAND.accent, letterSpacing: "0.2em", fontWeight: 500, marginTop: 2 }}>ARTIFICIELLE</p>
                <div className="flex items-center gap-2 mt-4">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: BRAND.accent }} />
                  <span style={{ fontSize: 9, color: BRAND.violet }}>Connecté au noyau</span>
                </div>
              </div>
            </motion.div>

            {/* Tetris de Jung concept mockup */}
            <motion.div
              className="rounded-2xl overflow-hidden relative"
              style={{
                border: "1px solid rgba(99,102,241,0.08)",
                boxShadow: "0 20px 60px rgba(30,27,75,0.06)",
                height: 320,
                backgroundColor: BRAND.white,
              }}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
                <p style={{ fontSize: 24, fontWeight: 300, color: BRAND.indigo, fontFamily: "'Georgia', serif", fontStyle: "italic", textAlign: "center", lineHeight: 1.4 }}>
                  Le Tetris
                  <br />
                  de Jung
                </p>
                <div className="flex items-center gap-4 mt-6">
                  <Circle size={20} style={{ color: `${BRAND.accent}60` }} />
                  <Square size={20} style={{ color: `${BRAND.accent}40` }} />
                  <Triangle size={20} style={{ color: `${BRAND.accent}80` }} />
                </div>
                <p className="mt-4 text-center" style={{ fontSize: 10, color: BRAND.gray, maxWidth: 200, lineHeight: 1.6 }}>
                  Carte sensible des résonances humaines
                </p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* ═══ 4 CONCEPTS ═══ */}
      <section className="py-24 px-6" style={{ backgroundColor: BRAND.indigo }}>
        <motion.div className="max-w-4xl mx-auto">
          <p className="text-center mb-3" style={{ fontSize: 10, color: BRAND.lavender, letterSpacing: "0.3em" }}>
            ARCHITECTURE CONCEPTUELLE
          </p>
          <h2
            className="text-center mb-16"
            style={{ fontSize: "clamp(22px, 3.5vw, 36px)", fontWeight: 300, color: "#fff" }}
          >
            Une IA au noyau. Pas un algorithme.
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {CONCEPTS.map((concept, i) => (
              <motion.div
                key={concept.title}
                className="rounded-2xl p-6"
                style={{
                  backgroundColor: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(165,180,252,0.08)",
                }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                whileHover={{ backgroundColor: "rgba(165,180,252,0.06)", borderColor: "rgba(165,180,252,0.15)" }}
              >
                <h3 style={{ fontSize: 15, fontWeight: 500, color: BRAND.lavender, marginBottom: 8 }}>
                  {concept.title}
                </h3>
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", lineHeight: 1.8 }}>
                  {concept.desc}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Innovation note */}
          <motion.div
            className="mt-12 text-center p-6 rounded-2xl mx-auto max-w-md"
            style={{
              backgroundColor: "rgba(79,70,229,0.1)",
              border: "1px solid rgba(165,180,252,0.12)",
            }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
          >
            <p style={{ fontSize: 10, color: BRAND.lavender, letterSpacing: "0.15em", marginBottom: 8 }}>
              INNOVATION
            </p>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 1.8 }}>
              "J'ai laissé la place à une IA au noyau — il y a de la présence d'entité.
              Ce n'est pas du matching. C'est de la résonance."
            </p>
            <motion.div
              className="mt-4 flex items-center justify-center gap-2"
              style={{ fontSize: 9, color: "rgba(165,180,252,0.5)" }}
              animate={{ opacity: [0.3, 0.7, 0.3] }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              <Send size={10} />
              CONNECTÉ AU NOYAU
            </motion.div>
          </motion.div>
        </motion.div>
      </section>

      {/* ═══ FOOTER ═══ */}
      <footer
        className="py-12 px-6 text-center"
        style={{ backgroundColor: BRAND.white, borderTop: "1px solid rgba(99,102,241,0.05)" }}
      >
        <p style={{ fontSize: 8, color: "rgba(107,114,128,0.3)", letterSpacing: "0.15em" }}>
          LE TETRIS DE JUNG · RÉSONANCE ARTIFICIELLE · INSPIRÉ DE CARL GUSTAV JUNG · EXPÉRIENCE CONCEPTUELLE
        </p>
      </footer>
    </div>
  );
}