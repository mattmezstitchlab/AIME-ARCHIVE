import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { StitchLabMark } from "./StitchLabLogo";
import {
  Clock, MapPin, Compass, Users,
  Footprints, Ear, Paintbrush, Share2, Sparkles, VolumeX,
  User, Users2, Globe,
  TreePine, Coffee, Waves, Trees, Building2, Landmark, Flower2, BrickWall,
  Navigation, Radar,
  CalendarClock, CalendarDays, CalendarRange,
} from "lucide-react";
import { useResponsive } from "./useResponsive";
import {
  HEARTBEAT_INTENTIONS,
  HEARTBEAT_OPENNESS,
  HEARTBEAT_WHEN_OPTIONS,
  HEARTBEAT_WHERE_OPTIONS,
  SYMBOLIC_PLACES,
  HEART_RED,
  type HeartbeatWhen,
  type HeartbeatWhere,
  type HeartbeatIntention,
  type HeartbeatOpenness,
  type Heartbeat,
  type AccessibilityMode,
} from "./game-data";

// ── Lucide icon mapping for sections ──
const SECTION_ICONS: Record<string, React.ReactNode> = {
  Quand: <Clock size={13} strokeWidth={1.5} />,
  Où: <MapPin size={13} strokeWidth={1.5} />,
  Intention: <Compass size={13} strokeWidth={1.5} />,
  Ouverture: <Users size={13} strokeWidth={1.5} />,
};

// ── Lucide icon mapping for when ──
const WHEN_ICONS: Record<HeartbeatWhen, React.ReactNode> = {
  maintenant: <CalendarClock size={12} strokeWidth={1.5} />,
  aujourdhui: <CalendarDays size={12} strokeWidth={1.5} />,
  weekend: <CalendarRange size={12} strokeWidth={1.5} />,
};

// ── Lucide icon mapping for where ──
const WHERE_ICONS: Record<string, React.ReactNode> = {
  ici: <Navigation size={12} strokeWidth={1.5} />,
  autour: <Radar size={12} strokeWidth={1.5} />,
};

// ── Lucide icon mapping for intentions ──
const INTENTION_ICONS: Record<HeartbeatIntention, React.ReactNode> = {
  marcher: <Footprints size={12} strokeWidth={1.5} />,
  écouter: <Ear size={12} strokeWidth={1.5} />,
  créer: <Paintbrush size={12} strokeWidth={1.5} />,
  partager: <Share2 size={12} strokeWidth={1.5} />,
  célébrer: <Sparkles size={12} strokeWidth={1.5} />,
  silence: <VolumeX size={12} strokeWidth={1.5} />,
};

// ── Lucide icon mapping for openness ──
const OPENNESS_ICONS: Record<HeartbeatOpenness, React.ReactNode> = {
  seul: <User size={12} strokeWidth={1.5} />,
  quelques: <Users2 size={12} strokeWidth={1.5} />,
  ouvert: <Globe size={12} strokeWidth={1.5} />,
};

// ── Lucide icon mapping for symbolic places ──
const PLACE_ICONS: Record<string, React.ReactNode> = {
  "Un parc": <TreePine size={11} strokeWidth={1.5} />,
  "Un café": <Coffee size={11} strokeWidth={1.5} />,
  "Une rivière": <Waves size={11} strokeWidth={1.5} />,
  "Une forêt": <Trees size={11} strokeWidth={1.5} />,
  "Un toit": <Building2 size={11} strokeWidth={1.5} />,
  "Une place": <Landmark size={11} strokeWidth={1.5} />,
  "Un jardin": <Flower2 size={11} strokeWidth={1.5} />,
  "Un pont": <BrickWall size={11} strokeWidth={1.5} />,
};

interface HeartbeatCreatorProps {
  visible: boolean;
  onClose: () => void;
  onCreateHeartbeat: (hb: Omit<Heartbeat, "id" | "creatorId" | "creatorPseudo" | "creatorColor" | "creatorSymbol" | "x" | "y" | "createdAt">) => void;
  mode: AccessibilityMode;
}

export function HeartbeatCreator({ visible, onClose, onCreateHeartbeat, mode }: HeartbeatCreatorProps) {
  const { isMobile } = useResponsive();
  const [when, setWhen] = useState<HeartbeatWhen>("maintenant");
  const [where, setWhere] = useState<HeartbeatWhere>("ici");
  const [customPlace, setCustomPlace] = useState("");
  const [intention, setIntention] = useState<HeartbeatIntention>("marcher");
  const [openness, setOpenness] = useState<HeartbeatOpenness>("ouvert");

  const isSenior = mode === "senior";
  const fontSize = isMobile ? 12 : isSenior ? 14 : 12;

  const handleCreate = () => {
    const finalWhere = where === "ici" || where === "autour" ? where : customPlace || where;
    onCreateHeartbeat({
      when,
      where: finalWhere,
      whereName: customPlace || undefined,
      intention,
      openness,
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {visible && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(250,248,245,0.6)", backdropFilter: "blur(8px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Panel */}
          <motion.div
            className="fixed inset-x-4 top-1/2 z-50 max-w-[420px] mx-auto rounded-2xl flex flex-col gap-5"
            style={{
              backgroundColor: "rgba(255,255,255,0.94)",
              backdropFilter: "blur(24px)",
              boxShadow: "0 16px 64px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.02)",
              transform: "translateY(-50%)",
              padding: isMobile ? 16 : 24,
              maxHeight: isMobile ? "88vh" : undefined,
              overflow: isMobile ? "auto" : undefined,
            }}
            initial={{ opacity: 0, y: "-46%", scale: 0.96 }}
            animate={{ opacity: 1, y: "-50%", scale: 1 }}
            exit={{ opacity: 0, y: "-46%", scale: 0.97 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            {/* Header */}
            <div className="flex items-center gap-2">
              <StitchLabMark size={14} />
              <span style={{ fontSize: 10, letterSpacing: "0.15em", color: "#bbb", textTransform: "uppercase", fontWeight: 300 }}>
                Déposer un battement
              </span>
            </div>

            {/* ─── QUAND ─── */}
            <ChoiceSection label="Quand" emoji={SECTION_ICONS["Quand"]} fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {HEARTBEAT_WHEN_OPTIONS.map((opt) => (
                  <PillButton
                    key={opt.key}
                    label={opt.label}
                    icon={WHEN_ICONS[opt.key]}
                    active={when === opt.key}
                    onClick={() => setWhen(opt.key)}
                    fontSize={fontSize}
                  />
                ))}
              </div>
            </ChoiceSection>

            {/* ─── OÙ ─── */}
            <ChoiceSection label="Où" emoji={SECTION_ICONS["Où"]} fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {HEARTBEAT_WHERE_OPTIONS.map((opt) => (
                  <PillButton
                    key={opt.key}
                    label={opt.label}
                    icon={WHERE_ICONS[opt.key]}
                    active={where === opt.key}
                    onClick={() => { setWhere(opt.key); setCustomPlace(""); }}
                    fontSize={fontSize}
                  />
                ))}
                {SYMBOLIC_PLACES.map((place) => (
                  <PillButton
                    key={place}
                    label={place}
                    icon={PLACE_ICONS[place]}
                    active={where === place}
                    onClick={() => { setWhere(place); setCustomPlace(place); }}
                    fontSize={fontSize}
                    subtle
                  />
                ))}
              </div>
            </ChoiceSection>

            {/* ─── INTENTION ─── */}
            <ChoiceSection label="Intention" emoji={SECTION_ICONS["Intention"]} fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {HEARTBEAT_INTENTIONS.map((opt) => (
                  <PillButton
                    key={opt.key}
                    label={opt.label}
                    icon={INTENTION_ICONS[opt.key]}
                    active={intention === opt.key}
                    onClick={() => setIntention(opt.key)}
                    fontSize={fontSize}
                  />
                ))}
              </div>
            </ChoiceSection>

            {/* ─── OUVERTURE ─── */}
            <ChoiceSection label="Ouverture" emoji={SECTION_ICONS["Ouverture"]} fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {HEARTBEAT_OPENNESS.map((opt) => (
                  <PillButton
                    key={opt.key}
                    label={opt.label}
                    icon={OPENNESS_ICONS[opt.key]}
                    active={openness === opt.key}
                    onClick={() => setOpenness(opt.key)}
                    fontSize={fontSize}
                  />
                ))}
              </div>
            </ChoiceSection>

            {/* ─── VALIDATE ─── */}
            <div className="flex gap-3 pt-1">
              <button
                className="flex-1 py-2.5 rounded-xl cursor-pointer border-none"
                style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#aaa", fontSize: fontSize - 1 }}
                onClick={onClose}
              >
                Annuler
              </button>
              <motion.button
                className="flex-1 py-2.5 rounded-xl cursor-pointer border-none flex items-center justify-center gap-2"
                style={{
                  backgroundColor: "#1a1a1a",
                  color: "#FAF8F5",
                  fontSize: fontSize - 1,
                  letterSpacing: "0.06em",
                }}
                onClick={handleCreate}
                whileHover={{ scale: 1.01, backgroundColor: "#333" }}
                whileTap={{ scale: 0.99 }}
              >
                <motion.span
                  animate={{ scale: [1, 1.2, 1, 1.15, 1, 1, 1] }}
                  transition={{ duration: 1.8, repeat: Infinity, times: [0, 0.1, 0.2, 0.3, 0.4, 0.6, 1] }}
                  style={{ color: HEART_RED, fontSize: fontSize }}
                >
                  ♥
                </motion.span>
                Déposer
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ── Section ──
function ChoiceSection({ label, emoji, fontSize, children }: {
  label: string; emoji: React.ReactNode; fontSize: number; children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-1.5" style={{ color: "#999" }}>
        {emoji}
        <span style={{ fontSize: fontSize - 2, color: "#999", fontWeight: 400, letterSpacing: "0.04em" }}>
          {label}
        </span>
      </div>
      {children}
    </div>
  );
}

// ── Pill Button ──
function PillButton({ label, icon, active, onClick, fontSize, subtle = false }: {
  label: string; icon?: React.ReactNode; active: boolean; onClick: () => void; fontSize: number; subtle?: boolean;
}) {
  return (
    <motion.button
      className="px-3 py-1.5 rounded-full cursor-pointer border-none whitespace-nowrap flex items-center gap-1.5"
      style={{
        backgroundColor: active ? "#1a1a1a" : subtle ? "rgba(0,0,0,0.02)" : "rgba(0,0,0,0.04)",
        color: active ? "#FAF8F5" : subtle ? "#ccc" : "#888",
        fontSize: fontSize - 2,
        fontWeight: active ? 500 : 400,
      }}
      onClick={onClick}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
    >
      {icon && <span className="flex items-center">{icon}</span>}
      {label}
    </motion.button>
  );
}