import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayerSquare } from "./PlayerSquare";
import { HEART_RED } from "./game-data";
import { useResponsive } from "./useResponsive";
import {
  Heart, LayoutGrid, Map, Scissors, Wrench, Palette,
  Share2, Eye, ChevronDown, ArrowRight, Sparkles,
} from "lucide-react";

// ═══════════════════════════════════════════
// LANDING — The Patent Page
// Auto-playing hero: 1 → 8 → 64
// The concept IS the landing.
// ═══════════════════════════════════════════

const FAMILIES = [
  {
    symbol: "♥", title: "POINT", subtitle: "L'intention", color: "#E8177F", icon: Heart,
    desc: "Qui tu es. Ce que tu portes. Le premier geste sur la grille.",
    elements: ["Le Cube", "Qui", "Quoi", "Où", "Quand", "Comment", "Pourquoi", "Avec qui"],
  },
  {
    symbol: "✚", title: "PATTERN", subtitle: "La création", color: "#C72B3B", icon: LayoutGrid,
    desc: "Photo vers grille. DMC. Symboles. L'art du motif brodé.",
    elements: ["Grille", "DMC", "Photo → Grille", "Symboles", "Niveaux", "Templates", "Export", "Rendu"],
  },
  {
    symbol: "◆", title: "CARTE", subtitle: "Le territoire", color: "#22A652", icon: Map,
    desc: "La grille infinie. Géolocalisation. Voisins. La mémoire des lieux.",
    elements: ["Grille infinie", "Géoloc.", "Voisins", "Territoires", "Chemins", "Lieux", "Événements", "Mémoire"],
  },
  {
    symbol: "✳", title: "LILY", subtitle: "L'intelligence", color: "#9263A6", icon: Scissors,
    desc: "L'IA créative. Voix. Analyse. Elle brode des réponses avec toi.",
    elements: ["IA créative", "Voix", "Couleurs", "Narration", "Analyse", "Suggestion", "Dialogue", "Mémoire"],
  },
  {
    symbol: "■", title: "OUTILS", subtitle: "Le métier", color: "#FFA230", icon: Wrench,
    desc: "Compteur. Timer. Palette DMC. Notes. Tout pour ta session.",
    elements: ["Compteur", "Timer", "Palette", "Conversion", "Calcul", "Notes", "Ambiance", "Partage"],
  },
  {
    symbol: "●", title: "CRÉATION", subtitle: "L'expression", color: "#1D5DA5", icon: Palette,
    desc: "Portrait. Paysage. Pixel art. Mandala. Ton art, fil à fil.",
    elements: ["Portrait", "Paysage", "Abstrait", "Typo", "Mandala", "Pixel Art", "Collab", "Génératif"],
  },
  {
    symbol: "∞", title: "CONNEXION", subtitle: "Le lien", color: "#E87DA5", icon: Share2,
    desc: "Ton carré rencontre d'autres. Échanges. Groupes. Liens tissés.",
    elements: ["Ton carré", "Intention", "Rencontre", "Échange", "Groupe", "Événement", "Cadeau", "Liens"],
  },
  {
    symbol: "▲", title: "VISION", subtitle: "Le futur", color: "#5B1D6E", icon: Eye,
    desc: "Laboratoire. Open source. Hardware. Festival. L'infini.",
    elements: ["Lab", "Évolution", "Communauté", "Open src", "Hardware", "Expo", "Festival", "Infini"],
  },
];

// Grid positions for 8 neighbors around center [1,1]
// Order: N, NE, E, SE, S, SW, W, NW
const GRID_POS: [number, number][] = [
  [1, 0], [2, 0], [2, 1], [2, 2],
  [1, 2], [0, 2], [0, 1], [0, 0],
];

// Concept section: flat 3x3 mapping (-1 = center)
const GRID_3X3 = [7, 0, 1, 6, -1, 2, 5, 4, 3];

// ═══════════════════════════════════════════
// HERO AUTO-ANIMATION
// 82 steps · 420ms each · ~34s cycle
// ═══════════════════════════════════════════

const TOTAL_STEPS = 82;
const STEP_MS = 420;

// Phase boundaries
const DEPLOY_START = 5;   // steps 5-12: deploy families
const DEPLOY_END = 12;
const HOLD_END = 15;      // steps 13-15: hold all
const VISIT_START = 16;   // steps 16-71: visit each family
const VISIT_END = 71;
const VISIT_LEN = 7;      // 7 steps per family visit
const RETRACT_START = 72; // steps 72-75: retract
const RETRACT_END = 75;
// steps 76-81: pause

type Phase =
  | { type: "closed" }
  | { type: "deploying"; count: number }
  | { type: "hold" }
  | { type: "visiting"; family: number; sub: number }
  | { type: "retracting"; step: number }
  | { type: "paused" };

function getPhase(step: number): Phase {
  if (step < DEPLOY_START) return { type: "closed" };
  if (step <= DEPLOY_END) return { type: "deploying", count: step - DEPLOY_START + 1 };
  if (step <= HOLD_END) return { type: "hold" };
  if (step <= VISIT_END) {
    const vs = step - VISIT_START;
    return { type: "visiting", family: Math.floor(vs / VISIT_LEN), sub: vs % VISIT_LEN };
  }
  if (step <= RETRACT_END) return { type: "retracting", step: step - RETRACT_START };
  return { type: "paused" };
}

function isFamVisible(famIdx: number, step: number): boolean {
  const p = getPhase(step);
  if (p.type === "deploying") return famIdx < p.count;
  if (p.type === "hold" || p.type === "visiting") return true;
  if (p.type === "retracting") {
    // Close 2 at a time in reverse: step0→hide 7,6  step1→hide 5,4 ...
    const closed = (p.step + 1) * 2;
    return famIdx < 8 - closed;
  }
  return false;
}

function getCounter(step: number): number {
  const p = getPhase(step);
  if (p.type === "visiting") {
    const done = p.family + (p.sub >= 2 ? 1 : 0);
    return done * 8;
  }
  if (p.type === "retracting" || p.type === "paused") return 64;
  return 0;
}

// ─── Burst positions: 8 dots in a circle ───
function burstPositions(radius: number) {
  return Array.from({ length: 8 }, (_, i) => {
    const a = (i / 8) * Math.PI * 2 - Math.PI / 2;
    return { x: Math.cos(a) * radius, y: Math.sin(a) * radius };
  });
}

// ═══ The animated hero grid ═══
function HeroAnimation({
  cellSize,
  gap,
  isMobile,
}: {
  cellSize: number;
  gap: number;
  isMobile: boolean;
}) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const iv = setInterval(() => setStep((s) => (s + 1) % TOTAL_STEPS), STEP_MS);
    return () => clearInterval(iv);
  }, []);

  const phase = getPhase(step);
  const counter = getCounter(step);
  const gridPx = cellSize * 3 + gap * 2;
  const burst = useMemo(() => burstPositions(cellSize * 0.85), [cellSize]);

  // Active family info
  const activeFam = phase.type === "visiting" ? phase.family : -1;
  const showBurst = phase.type === "visiting" && phase.sub >= 2 && phase.sub <= 5;
  const isTapping = phase.type === "visiting" && phase.sub === 1;

  // Finger position: center of active family square
  const fingerTarget = activeFam >= 0 ? (() => {
    const [col, row] = GRID_POS[activeFam];
    return {
      x: col * (cellSize + gap) + cellSize / 2,
      y: row * (cellSize + gap) + cellSize + 6,
    };
  })() : null;

  // Center is pulsing when nothing else is happening
  const centerPulsing = phase.type === "closed" || phase.type === "paused";

  return (
    <div className="flex flex-col items-center gap-0">
      {/* THE GRID */}
      <div className="relative" style={{ width: gridPx, height: gridPx, overflow: "visible" }}>
        {/* ─── Center Heart ─── */}
        <motion.div
          className="absolute z-10"
          style={{
            left: cellSize + gap,
            top: cellSize + gap,
            width: cellSize,
            height: cellSize,
          }}
        >
          {/* Pulse rings when closed */}
          {centerPulsing && (
            <>
              <motion.div
                className="absolute rounded-lg pointer-events-none"
                style={{ inset: -12, border: "1px solid rgba(232,23,127,0.15)" }}
                animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.8, 0.3] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.div
                className="absolute rounded-xl pointer-events-none"
                style={{ inset: -24, border: "1px solid rgba(232,23,127,0.06)" }}
                animate={{ scale: [1, 1.1, 1], opacity: [0.1, 0.4, 0.1] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              />
            </>
          )}

          <motion.div
            animate={centerPulsing ? { y: [0, -5, 0] } : { y: 0 }}
            transition={
              centerPulsing
                ? { duration: 3.5, repeat: Infinity, ease: "easeInOut" }
                : { duration: 0.3 }
            }
          >
            <PlayerSquare
              colorHex={HEART_RED}
              symbol="♥"
              size={cellSize}
              symbolSize={Math.round(cellSize * 0.65)}
              glowing
            />
          </motion.div>
        </motion.div>

        {/* ─── 8 Family Squares ─── */}
        {FAMILIES.map((fam, i) => {
          const visible = isFamVisible(i, step);
          const isActive = activeFam === i;
          const [col, row] = GRID_POS[i];
          const Icon = fam.icon;
          const cx = col * (cellSize + gap);
          const cy = row * (cellSize + gap);

          return (
            <AnimatePresence key={fam.title}>
              {visible && (
                <motion.div
                  className="absolute rounded-[4px] flex flex-col items-center justify-center gap-0.5"
                  style={{
                    left: cx,
                    top: cy,
                    width: cellSize,
                    height: cellSize,
                    backgroundColor: isActive ? `${fam.color}22` : `${fam.color}10`,
                    border: `1.5px solid ${isActive ? fam.color + "60" : fam.color + "28"}`,
                    zIndex: isActive ? 5 : 1,
                  }}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{
                    scale: isActive && isTapping ? 0.92 : 1,
                    opacity: 1,
                    boxShadow: isActive
                      ? `0 0 24px ${fam.color}30, inset 0 0 12px ${fam.color}10`
                      : `0 0 12px ${fam.color}08`,
                  }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{
                    scale: { duration: 0.15 },
                    default: { duration: 0.35, type: "spring", stiffness: 260, damping: 18 },
                  }}
                >
                  <Icon
                    size={isMobile ? 14 : 20}
                    color={fam.color}
                    strokeWidth={1.5}
                  />
                  <span
                    style={{
                      fontSize: isMobile ? 5 : 7,
                      color: isActive ? fam.color : `${fam.color}90`,
                      fontWeight: 600,
                      letterSpacing: "0.06em",
                    }}
                  >
                    {fam.title}
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          );
        })}

        {/* ─── Element Burst (8 dots around active family) ─── */}
        <AnimatePresence>
          {showBurst && activeFam >= 0 && (() => {
            const fam = FAMILIES[activeFam];
            const [col, row] = GRID_POS[activeFam];
            const centerX = col * (cellSize + gap) + cellSize / 2;
            const centerY = row * (cellSize + gap) + cellSize / 2;
            const dotSize = isMobile ? 7 : 9;

            return burst.map((pos, di) => (
              <motion.div
                key={`burst-${activeFam}-${di}`}
                className="absolute rounded-full pointer-events-none"
                style={{
                  width: dotSize,
                  height: dotSize,
                  left: centerX - dotSize / 2,
                  top: centerY - dotSize / 2,
                  backgroundColor: fam.color,
                  boxShadow: `0 0 10px ${fam.color}70`,
                  zIndex: 8,
                }}
                initial={{ x: 0, y: 0, scale: 0, opacity: 0 }}
                animate={{ x: pos.x, y: pos.y, scale: 1, opacity: 0.95 }}
                exit={{ x: 0, y: 0, scale: 0, opacity: 0 }}
                transition={{
                  duration: 0.4,
                  delay: di * 0.04,
                  type: "spring",
                  stiffness: 300,
                  damping: 16,
                }}
              />
            ));
          })()}
        </AnimatePresence>

        {/* ─── Element labels (tiny names around active) ─── */}
        <AnimatePresence>
          {showBurst && activeFam >= 0 && (() => {
            const fam = FAMILIES[activeFam];
            const [col, row] = GRID_POS[activeFam];
            const centerX = col * (cellSize + gap) + cellSize / 2;
            const centerY = row * (cellSize + gap) + cellSize / 2;
            const labelR = cellSize * (isMobile ? 1.05 : 1.2);

            return fam.elements.map((el, ei) => {
              const a = (ei / 8) * Math.PI * 2 - Math.PI / 2;
              const lx = Math.cos(a) * labelR;
              const ly = Math.sin(a) * labelR;
              return (
                <motion.span
                  key={`label-${activeFam}-${ei}`}
                  className="absolute pointer-events-none whitespace-nowrap"
                  style={{
                    left: centerX,
                    top: centerY,
                    fontSize: isMobile ? 8 : 10,
                    color: `${fam.color}DD`,
                    fontWeight: 500,
                    textAlign: "center",
                    zIndex: 9,
                    transform: "translate(-50%, -50%)",
                    textShadow: `0 0 8px ${fam.color}40`,
                  }}
                  initial={{ x: 0, y: 0, opacity: 0, scale: 0.5 }}
                  animate={{ x: lx, y: ly, opacity: 1, scale: 1 }}
                  exit={{ x: 0, y: 0, opacity: 0, scale: 0.5 }}
                  transition={{
                    duration: 0.4,
                    delay: ei * 0.04,
                    type: "spring",
                    stiffness: 280,
                    damping: 18,
                  }}
                >
                  {el}
                </motion.span>
              );
            });
          })()}
        </AnimatePresence>

        {/* ─── Touch cursor / finger ─── */}
        <AnimatePresence>
          {fingerTarget && phase.type === "visiting" && (phase as { sub: number }).sub <= 5 && (
            <motion.div
              className="absolute pointer-events-none"
              style={{
                width: 18,
                height: 18,
                zIndex: 20,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{
                opacity: isTapping ? 1 : 0.7,
                scale: isTapping ? 0.8 : 1,
                left: fingerTarget.x - 9,
                top: fingerTarget.y - 4,
              }}
              exit={{ opacity: 0, scale: 0.5 }}
              transition={{
                left: { duration: 0.35, ease: "easeInOut" },
                top: { duration: 0.35, ease: "easeInOut" },
                scale: { duration: 0.12 },
                opacity: { duration: 0.2 },
              }}
            >
              <span style={{ fontSize: 14, filter: "drop-shadow(0 1px 3px rgba(0,0,0,0.5))" }}>
                👆
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ─── Tap ripple ─── */}
        <AnimatePresence>
          {isTapping && activeFam >= 0 && (() => {
            const fam = FAMILIES[activeFam];
            const [col, row] = GRID_POS[activeFam];
            const cx = col * (cellSize + gap) + cellSize / 2;
            const cy = row * (cellSize + gap) + cellSize / 2;
            return (
              <motion.div
                key={`ripple-${activeFam}`}
                className="absolute rounded-full pointer-events-none"
                style={{
                  width: cellSize,
                  height: cellSize,
                  left: cx - cellSize / 2,
                  top: cy - cellSize / 2,
                  border: `2px solid ${fam.color}`,
                  zIndex: 6,
                }}
                initial={{ scale: 0.3, opacity: 0.8 }}
                animate={{ scale: 1.4, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              />
            );
          })()}
        </AnimatePresence>
      </div>

      {/* ─── Counter & active label ─── */}
      <div className="flex flex-col items-center gap-1 mt-5" style={{ minHeight: 44 }}>
        {/* Active family label */}
        <AnimatePresence mode="wait">
          {activeFam >= 0 && (
            <motion.div
              key={`fam-label-${activeFam}`}
              className="flex items-center gap-2"
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.2 }}
            >
              <div
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: FAMILIES[activeFam].color }}
              />
              <span
                style={{
                  fontSize: isMobile ? 9 : 11,
                  color: FAMILIES[activeFam].color,
                  fontWeight: 500,
                  letterSpacing: "0.1em",
                }}
              >
                {FAMILIES[activeFam].title}
              </span>
              <span
                style={{
                  fontSize: isMobile ? 8 : 10,
                  color: "rgba(255,255,255,0.2)",
                  fontWeight: 300,
                  fontStyle: "italic",
                }}
              >
                {FAMILIES[activeFam].subtitle}
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Running counter */}
        <AnimatePresence mode="wait">
          {counter > 0 ? (
            <motion.div
              key={`count-${counter}`}
              className="flex items-baseline gap-1"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.15 }}
            >
              <span
                style={{
                  fontSize: isMobile ? 20 : 28,
                  fontWeight: 200,
                  color: counter === 64 ? HEART_RED : "rgba(255,255,255,0.5)",
                  fontVariantNumeric: "tabular-nums",
                }}
              >
                {counter}
              </span>
              <span
                style={{
                  fontSize: isMobile ? 8 : 10,
                  color: "rgba(255,255,255,0.12)",
                  fontWeight: 300,
                }}
              >
                / 64
              </span>
            </motion.div>
          ) : (
            <motion.span
              key="zero"
              style={{
                fontSize: isMobile ? 8 : 10,
                color: "rgba(255,255,255,0.1)",
                letterSpacing: "0.15em",
                fontWeight: 300,
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              0 → 64
            </motion.span>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// MAIN LANDING COMPONENT
// ═══════════════════════════════════════════

interface LandingScreenProps {
  onEnter: () => void;
}

export function LandingScreen({ onEnter }: LandingScreenProps) {
  const { isMobile } = useResponsive();
  const [hoveredFamily, setHoveredFamily] = useState<number | null>(null);

  const cellSize = isMobile ? 52 : 76;
  const gap = isMobile ? 4 : 6;

  return (
    <div
      className="min-h-screen w-full overflow-y-auto"
      style={{
        backgroundColor: "#0A0A0A",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      {/* ═══════════════════════════════════════
           HERO — Auto-playing animation
         ═══════════════════════════════════════ */}
      <section
        className="relative flex flex-col items-center justify-center px-6"
        style={{ minHeight: "100vh" }}
      >
        {/* Ambient particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 24 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full"
              style={{
                width: i % 5 === 0 ? 3 : 1.5,
                height: i % 5 === 0 ? 3 : 1.5,
                backgroundColor:
                  i % 3 === 0
                    ? "rgba(232,23,127,0.1)"
                    : "rgba(255,255,255,0.02)",
                left: `${5 + ((i * 23) % 90)}%`,
                top: `${3 + ((i * 31) % 94)}%`,
              }}
              animate={{ opacity: [0.1, 0.45, 0.1] }}
              transition={{
                duration: 4 + (i % 4),
                repeat: Infinity,
                delay: i * 0.25,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Radial glow */}
        <motion.div
          className="absolute pointer-events-none"
          style={{
            width: isMobile ? 340 : 520,
            height: isMobile ? 340 : 520,
            background:
              "radial-gradient(circle, rgba(232,23,127,0.08) 0%, rgba(146,99,166,0.03) 35%, rgba(0,0,0,0) 60%)",
          }}
          animate={{ scale: [1, 1.15, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* STITCH × LAB */}
        <motion.p
          style={{
            fontSize: isMobile ? 9 : 10,
            fontWeight: 300,
            color: "rgba(255,255,255,0.12)",
            letterSpacing: "0.35em",
            textTransform: "uppercase",
            marginBottom: isMobile ? 16 : 28,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1.5 }}
        >
          STITCH ✕ LAB
        </motion.p>

        {/* ═══ THE AUTO-ANIMATION ═══ */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8, duration: 1.2, type: "spring", stiffness: 50 }}
        >
          <HeroAnimation cellSize={cellSize} gap={gap} isMobile={isMobile} />
        </motion.div>

        {/* Tagline */}
        <motion.p
          style={{
            fontSize: isMobile ? 14 : 20,
            fontWeight: 200,
            color: "rgba(255,255,255,0.35)",
            letterSpacing: "0.04em",
            textAlign: "center",
            marginTop: isMobile ? 16 : 24,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
        >
          Un carré.{" "}
          <span style={{ color: HEART_RED, fontWeight: 400 }}>Huit</span> univers.{" "}
          <span style={{ fontWeight: 400 }}>Soixante-quatre</span> facettes.
        </motion.p>

        {/* CTA in hero */}
        <motion.button
          className="flex items-center gap-2 cursor-pointer border-none mt-6"
          style={{
            background: `linear-gradient(135deg, ${HEART_RED}, #9263A6)`,
            color: "#fff",
            fontSize: isMobile ? 11 : 13,
            fontWeight: 500,
            padding: isMobile ? "10px 22px" : "12px 28px",
            borderRadius: 12,
            letterSpacing: "0.06em",
            boxShadow: `0 4px 20px ${HEART_RED}25`,
          }}
          onClick={onEnter}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 3 }}
          whileHover={{ scale: 1.03, boxShadow: `0 6px 30px ${HEART_RED}40` }}
          whileTap={{ scale: 0.97 }}
        >
          <Sparkles size={13} />
          Entrer dans le laboratoire
        </motion.button>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.35 }}
          transition={{ delay: 4 }}
        >
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <ChevronDown size={16} color="rgba(255,255,255,0.3)" />
          </motion.div>
          <span
            style={{
              fontSize: 8,
              color: "rgba(255,255,255,0.12)",
              letterSpacing: "0.12em",
            }}
          >
            SCROLL
          </span>
        </motion.div>
      </section>

      {/* ═══════════════════════════════════════
           CONCEPT — De 0 à 64 (Le Brevet)
         ═══════════════════════════════════════ */}
      <section className="py-20 md:py-28 px-6">
        <motion.div
          className="max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-3 mb-10">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: HEART_RED }} />
            <span style={{ fontSize: 9, letterSpacing: "0.16em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase", fontWeight: 400 }}>
              Le concept
            </span>
          </div>

          <h2 style={{ fontSize: isMobile ? 24 : 34, fontWeight: 200, color: "#fff", lineHeight: 1.3, marginBottom: 20 }}>
            De <span style={{ fontWeight: 600 }}>zéro</span> à{" "}
            <span style={{ color: HEART_RED, fontWeight: 600 }}>soixante-quatre</span>.
          </h2>

          <p style={{ fontSize: isMobile ? 12 : 14, color: "rgba(255,255,255,0.35)", lineHeight: 1.9, fontWeight: 300, maxWidth: 480 }}>
            Comme un point de croix sur une toile Aida, un carré a{" "}
            <strong style={{ color: "rgba(255,255,255,0.6)" }}>huit voisins</strong>.
            Chaque voisin est un univers. Chaque univers contient huit facettes.
            <br /><br />
            <strong style={{ color: "rgba(255,255,255,0.6)" }}>1 × 8 × 8 = 64.</strong>{" "}
            Toute l'expérience naît d'un seul carré.
          </p>

          {/* ─── 1 → 8 → 64 Visual ─── */}
          <div className="mt-16 flex items-center justify-center gap-6 md:gap-10 flex-wrap">
            <motion.div className="flex flex-col items-center gap-3"
              initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
              <PlayerSquare colorHex={HEART_RED} symbol="♥" size={isMobile ? 38 : 50} symbolSize={32} />
              <span style={{ fontSize: isMobile ? 22 : 30, fontWeight: 200, color: "rgba(255,255,255,0.5)" }}>1</span>
            </motion.div>

            <motion.div style={{ color: "rgba(255,255,255,0.1)" }}
              initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.4 }}>
              <ArrowRight size={isMobile ? 16 : 20} />
            </motion.div>

            <motion.div className="flex flex-col items-center gap-3"
              initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.5 }}>
              <div className="grid grid-cols-3" style={{ gap: 2 }}>
                {GRID_3X3.map((famIdx, i) => {
                  if (famIdx === -1) {
                    return (
                      <div key="center" className="rounded-[3px] flex items-center justify-center"
                        style={{ width: isMobile ? 18 : 24, height: isMobile ? 18 : 24, backgroundColor: HEART_RED }}>
                        <span style={{ fontSize: isMobile ? 8 : 10, color: "#fff" }}>♥</span>
                      </div>
                    );
                  }
                  const fam = FAMILIES[famIdx];
                  const Icon = fam.icon;
                  return (
                    <div key={famIdx} className="rounded-[3px] flex items-center justify-center"
                      style={{ width: isMobile ? 18 : 24, height: isMobile ? 18 : 24, backgroundColor: `${fam.color}20`, border: `1px solid ${fam.color}30` }}>
                      <Icon size={isMobile ? 7 : 9} color={fam.color} strokeWidth={1.5} />
                    </div>
                  );
                })}
              </div>
              <span style={{ fontSize: isMobile ? 22 : 30, fontWeight: 200, color: "rgba(255,255,255,0.5)" }}>8</span>
            </motion.div>

            <motion.div style={{ color: "rgba(255,255,255,0.1)" }}
              initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.7 }}>
              <ArrowRight size={isMobile ? 16 : 20} />
            </motion.div>

            <motion.div className="flex flex-col items-center gap-3"
              initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.8 }}>
              <div className="grid grid-cols-8" style={{ gap: 1 }}>
                {FAMILIES.map((fam, fi) =>
                  Array.from({ length: 8 }).map((_, ei) => (
                    <motion.div key={`${fi}-${ei}`} className="rounded-[1px]"
                      style={{ width: isMobile ? 6 : 8, height: isMobile ? 6 : 8, backgroundColor: fam.color, opacity: 0.2 + ei * 0.1 }}
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 0.2 + ei * 0.1 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.8 + (fi * 8 + ei) * 0.008 }}
                    />
                  ))
                )}
              </div>
              <span style={{ fontSize: isMobile ? 22 : 30, fontWeight: 200, color: HEART_RED }}>64</span>
            </motion.div>
          </div>

          <motion.div className="mt-12 text-center"
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.6 }}>
            <p style={{ fontSize: isMobile ? 9 : 11, color: "rgba(255,255,255,0.12)", letterSpacing: "0.2em", fontWeight: 300 }}>
              UN CARRÉ &middot; HUIT DIRECTIONS &middot; SOIXANTE-QUATRE FACETTES
            </p>
          </motion.div>
        </motion.div>
      </section>

      {/* ═══════════════════════════════════════
           THE 8 UNIVERSES
         ═══════════════════════════════════════ */}
      <section className="py-20 md:py-28 px-6" style={{ backgroundColor: "rgba(255,255,255,0.015)" }}>
        <motion.div className="max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.6 }}>
          <div className="flex items-center gap-3 mb-10">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: HEART_RED }} />
            <span style={{ fontSize: 9, letterSpacing: "0.16em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase", fontWeight: 400 }}>
              Les 8 univers
            </span>
          </div>

          <h2 style={{ fontSize: isMobile ? 22 : 30, fontWeight: 200, color: "#fff", lineHeight: 1.3, marginBottom: 12 }}>
            Chaque direction est un <em style={{ fontStyle: "italic", color: HEART_RED }}>monde</em>.
          </h2>
          <p style={{ fontSize: isMobile ? 11 : 13, color: "rgba(255,255,255,0.25)", lineHeight: 1.7, fontWeight: 300, marginBottom: 32, maxWidth: 440 }}>
            Huit univers rangés dans l'ordre du brevet. Chacun contient huit
            facettes — soixante-quatre possibilités nées d'un seul carré.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {FAMILIES.map((fam, i) => {
              const Icon = fam.icon;
              const isExpanded = hoveredFamily === i;
              return (
                <motion.div key={fam.title}
                  className="rounded-2xl px-5 py-4 cursor-default"
                  style={{
                    backgroundColor: isExpanded ? `${fam.color}0C` : "rgba(255,255,255,0.02)",
                    border: `1px solid ${isExpanded ? `${fam.color}25` : "rgba(255,255,255,0.04)"}`,
                    transition: "all 0.3s ease",
                  }}
                  onMouseEnter={() => setHoveredFamily(i)}
                  onMouseLeave={() => setHoveredFamily(null)}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${fam.color}15` }}>
                      <Icon size={18} color={fam.color} strokeWidth={1.5} />
                    </div>
                    <div className="flex flex-col gap-0.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span style={{ fontSize: 7, color: fam.color, fontWeight: 600, letterSpacing: "0.12em", opacity: 0.7 }}>
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <span style={{ fontSize: 13, fontWeight: 500, color: "rgba(255,255,255,0.85)" }}>
                          {fam.title}
                        </span>
                        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", fontWeight: 300, fontStyle: "italic" }}>
                          {fam.subtitle}
                        </span>
                      </div>
                      <p style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", lineHeight: 1.5 }}>
                        {fam.desc}
                      </p>
                    </div>
                  </div>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div className="flex flex-wrap gap-1.5 mt-3 ml-[52px]"
                        initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25 }}>
                        {fam.elements.map((el, ei) => (
                          <span key={el} className="px-2 py-0.5 rounded-md"
                            style={{ fontSize: 9, color: fam.color, backgroundColor: `${fam.color}0A`, border: `1px solid ${fam.color}15`, fontWeight: 400 }}>
                            {String(i * 8 + ei + 1).padStart(2, "0")} {el}
                          </span>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>

          <motion.div className="mt-8 text-center"
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.5 }}>
            <p style={{ fontSize: 10, color: "rgba(255,255,255,0.12)", letterSpacing: "0.15em", fontWeight: 300 }}>
              8 UNIVERS &times; 8 FACETTES = <span style={{ color: HEART_RED, fontWeight: 500 }}>64</span> POSSIBILITÉS
            </p>
          </motion.div>
        </motion.div>
      </section>

      {/* ═══════════════════════════════════════
           THE ORDER — Timeline
         ═══════════════════════════════════════ */}
      <section className="py-20 md:py-28 px-6">
        <motion.div className="max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.8 }}>
          <div className="flex items-center gap-3 mb-10">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: HEART_RED }} />
            <span style={{ fontSize: 9, letterSpacing: "0.16em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase", fontWeight: 400 }}>
              L'ordre
            </span>
          </div>

          <h2 style={{ fontSize: isMobile ? 22 : 30, fontWeight: 200, color: "#fff", lineHeight: 1.3, marginBottom: 20 }}>
            L'ordre n'est pas <em style={{ fontStyle: "italic", color: "rgba(255,255,255,0.25)" }}>arbitraire</em>.
          </h2>

          <p style={{ fontSize: isMobile ? 12 : 14, color: "rgba(255,255,255,0.35)", lineHeight: 1.9, fontWeight: 300, maxWidth: 480 }}>
            Les 8 directions suivent la logique du{" "}
            <strong style={{ color: "rgba(255,255,255,0.6)" }}>point de croix</strong>.
            Du <strong style={{ color: HEART_RED }}>cœur</strong> (l'intention)
            au sommet (la vision), chaque étape prépare la suivante.
          </p>

          <div className="mt-12 relative">
            <div className="absolute left-5 top-0 bottom-0 w-px"
              style={{ background: "linear-gradient(to bottom, rgba(255,255,255,0.04), rgba(232,23,127,0.15), rgba(255,255,255,0.04))" }} />

            {FAMILIES.map((fam, i) => {
              const Icon = fam.icon;
              return (
                <motion.div key={fam.title} className="relative flex items-center gap-4 py-3"
                  initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 relative z-10"
                    style={{ backgroundColor: `${fam.color}15`, border: `1.5px solid ${fam.color}30` }}>
                    <Icon size={14} color={fam.color} strokeWidth={1.5} />
                  </div>
                  <div className="flex flex-col gap-0.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <span style={{ fontSize: 7, color: fam.color, fontWeight: 600, letterSpacing: "0.1em" }}>
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span style={{ fontSize: 12, fontWeight: 500, color: "rgba(255,255,255,0.7)" }}>
                        {fam.title}
                      </span>
                      <span style={{ fontSize: 10, color: "rgba(255,255,255,0.15)", fontWeight: 300, fontStyle: "italic" }}>
                        — {fam.subtitle}
                      </span>
                    </div>
                    <p style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", lineHeight: 1.5 }}>
                      {fam.elements.join(" · ")}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </section>

      {/* ═══════════════════════════════════════
           CTA — Enter the Lab
         ═══════════════════════════════════════ */}
      <section className="py-24 md:py-32 px-6 flex flex-col items-center relative">
        <div className="absolute pointer-events-none"
          style={{ width: 400, height: 400, top: "50%", left: "50%", transform: "translate(-50%, -50%)", background: "radial-gradient(circle, rgba(232,23,127,0.06) 0%, rgba(0,0,0,0) 60%)" }} />

        <motion.div className="relative flex flex-col items-center gap-6"
          initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <motion.div animate={{ y: [0, -4, 0] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}>
            <PlayerSquare colorHex={HEART_RED} symbol="♥" size={36} symbolSize={24} glowing />
          </motion.div>

          <h2 style={{ fontSize: isMobile ? 20 : 28, fontWeight: 200, color: "#fff", textAlign: "center", lineHeight: 1.3 }}>
            Prêt à explorer ?
          </h2>
          <p style={{ fontSize: isMobile ? 11 : 13, color: "rgba(255,255,255,0.3)", textAlign: "center", maxWidth: 380, lineHeight: 1.8, fontWeight: 300 }}>
            Le laboratoire est un espace vivant. Chaque visite est
            différente. Les 64 facettes t'attendent.
          </p>

          <motion.button className="flex items-center gap-2 cursor-pointer border-none mt-2"
            style={{
              background: `linear-gradient(135deg, ${HEART_RED}, #9263A6)`,
              color: "#fff", fontSize: isMobile ? 12 : 14, fontWeight: 500,
              padding: "14px 32px", borderRadius: 14, letterSpacing: "0.06em",
              boxShadow: `0 4px 24px ${HEART_RED}30`,
            }}
            onClick={onEnter}
            whileHover={{ scale: 1.03, boxShadow: `0 6px 32px ${HEART_RED}45` }}
            whileTap={{ scale: 0.97 }}>
            <Sparkles size={14} />
            Entrer dans le laboratoire
          </motion.button>

          <p style={{ fontSize: 9, color: "rgba(255,255,255,0.1)", letterSpacing: "0.12em", marginTop: 8 }}>
            64 FACETTES &middot; 8 UNIVERS &middot; 1 CARRÉ
          </p>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 flex items-center justify-center" style={{ borderTop: "1px solid rgba(255,255,255,0.03)" }}>
        <span style={{ fontSize: 9, color: "rgba(255,255,255,0.08)", letterSpacing: "0.08em" }}>
          STITCHLAB — 2026
        </span>
      </footer>
    </div>
  );
}