import { motion } from "motion/react";
import { ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { useResponsive } from "./useResponsive";
import type { AccessibilityMode } from "./game-data";

interface ZoomControlsProps {
  zoom: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomReset: () => void;
  mode: AccessibilityMode;
}

// Extended zoom levels — more dezoom for exploring
const ZOOM_LEVELS = [0.15, 0.2, 0.3, 0.4, 0.5, 0.65, 0.8, 1, 1.25, 1.5, 2];

export function ZoomControls({ zoom, onZoomIn, onZoomOut, onZoomReset, mode }: ZoomControlsProps) {
  const { isMobile } = useResponsive();
  const isSenior = mode === "senior";
  const btnSize = isMobile ? 26 : isSenior ? 36 : 30;
  const iconSize = isMobile ? 11 : isSenior ? 16 : 13;

  const canZoomIn = zoom < ZOOM_LEVELS[ZOOM_LEVELS.length - 1];
  const canZoomOut = zoom > ZOOM_LEVELS[0];
  const isDefault = zoom === 1;
  const pct = Math.round(zoom * 100);

  return (
    <div
      className="fixed z-30 flex items-center gap-0.5 rounded-xl"
      style={{
        top: isMobile ? 10 : 16,
        right: isMobile ? 48 : 60,
        backgroundColor: "rgba(255,255,255,0.75)",
        backdropFilter: "blur(14px)",
        boxShadow: "0 2px 12px rgba(0,0,0,0.04), 0 0 0 1px rgba(0,0,0,0.02)",
        padding: isMobile ? "2px 3px" : "4px 6px",
      }}
    >
      <ZoomBtn onClick={onZoomOut} disabled={!canZoomOut} size={btnSize} label="Zoom arrière">
        <ZoomOut size={iconSize} strokeWidth={1.6} />
      </ZoomBtn>

      <motion.button
        className="flex items-center justify-center cursor-pointer border-none rounded-lg"
        style={{
          height: btnSize,
          minWidth: isMobile ? 32 : 40,
          backgroundColor: isDefault ? "rgba(0,0,0,0)" : "rgba(0,0,0,0.04)",
          color: isDefault ? "#ccc" : "#888",
          fontSize: isMobile ? 8 : isSenior ? 10 : 9,
          fontWeight: 500,
          fontVariantNumeric: "tabular-nums",
          padding: "0 4px",
        }}
        onClick={onZoomReset}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label="Réinitialiser zoom"
      >
        {isDefault ? <Maximize2 size={iconSize - 2} strokeWidth={1.4} /> : `${pct}%`}
      </motion.button>

      <ZoomBtn onClick={onZoomIn} disabled={!canZoomIn} size={btnSize} label="Zoom avant">
        <ZoomIn size={iconSize} strokeWidth={1.6} />
      </ZoomBtn>
    </div>
  );
}

function ZoomBtn({ onClick, disabled, size, label, children }: {
  onClick: () => void; disabled: boolean; size: number; label: string; children: React.ReactNode;
}) {
  return (
    <motion.button
      className="flex items-center justify-center rounded-lg cursor-pointer border-none"
      style={{
        width: size,
        height: size,
        backgroundColor: "rgba(0,0,0,0)",
        color: disabled ? "#ddd" : "#888",
        opacity: disabled ? 0.4 : 1,
        pointerEvents: disabled ? "none" : "auto",
      }}
      onClick={onClick}
      whileHover={{ scale: 1.1, backgroundColor: "rgba(0,0,0,0.04)" }}
      whileTap={{ scale: 0.9 }}
      aria-label={label}
    >
      {children}
    </motion.button>
  );
}

export { ZOOM_LEVELS };
