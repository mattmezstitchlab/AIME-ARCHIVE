import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayerSquare } from "./PlayerSquare";
import { StitchLabLogo } from "./StitchLabLogo";
import { LilyFace } from "./LilyFace";
import { HEART_RED } from "./game-data";
import { useResponsive } from "./useResponsive";
import { FacettePanel } from "./FacettePanel";
import type { ActiveTool, ToolType, GridPaints } from "./grid-tools";
import { cellKey } from "./grid-tools";
import {
  Sun, Moon, ArrowLeft, Crosshair, ZoomIn, ZoomOut, Maximize2,
  Heart, LayoutGrid, Map, Scissors, Wrench, Palette, Share2, Eye,
  Camera, Droplet, Star, Move, RotateCw, Contrast, Download,
  BookOpen, Plus, Copy, Upload, Bookmark, Clock,
  Globe, Compass, Users, Search, MapPin,
  MessageCircle, HelpCircle, GraduationCap, Lightbulb, Book, Smile, Brain, Lock,
  Ruler, Settings, Command, Pencil, Paintbrush, Hexagon,
  Droplets, FlipHorizontal2, CircleDot, MessageSquare, Bell, User, UserPlus,
  Calendar, Sparkles, ScanLine, SlidersHorizontal, Crop,
  ImageIcon, TypeIcon,
  Eraser, Hand, Pipette,
} from "lucide-react";

// ═══════════════════════════════════════════
// STITCHLAB — The Grid App
// Magnetic snap · Step dots · Lily awakening
// ═══════════════════════════════════════════

const LILY_PURPLE = "#9263A6";

// ── Facette icon maps (one per family, 8 icons each) ──
const FAC_ICONS = [
  [Heart, Droplet, Star, Maximize2, Move, RotateCw, Contrast, Download],
  [LayoutGrid, BookOpen, Download, Plus, Copy, Upload, Bookmark, Clock],
  [Globe, Compass, Users, Search, Bookmark, Clock, MapPin, Share2],
  [MessageCircle, HelpCircle, GraduationCap, Lightbulb, Book, Smile, Brain, Lock],
  [LayoutGrid, Ruler, Settings, ZoomIn, Download, Command, Moon, Globe],
  [Pencil, Palette, Paintbrush, Hexagon, TypeIcon, Droplets, FlipHorizontal2, CircleDot],
  [Share2, Users, Globe, MessageSquare, Bell, User, UserPlus, Calendar],
  [Camera, ImageIcon, Sparkles, ScanLine, SlidersHorizontal, Crop, Maximize2, Eye],
];

const FAMILIES = [
  {
    symbol: "♥", title: "POINT", color: "#E8177F", icon: Heart,
    facettes: ["Mon carré", "Couleur", "Symbole", "Taille", "Position", "Rotation", "Contraste", "Exporter"],
  },
  {
    symbol: "✚", title: "PATTERN", color: "#C72B3B", icon: LayoutGrid,
    facettes: ["Motifs", "Bibliothèque", "Importer", "Créer", "Dupliquer", "Exporter", "Favoris", "Récents"],
  },
  {
    symbol: "◆", title: "CARTE", color: "#22A652", icon: Map,
    facettes: ["Monde", "Explorer", "Proches", "Rechercher", "Favoris", "Historique", "Coordonnées", "Partager"],
  },
  {
    symbol: "✳", title: "LILY", color: LILY_PURPLE, icon: Scissors,
    facettes: ["Chat", "Aide", "Tutoriel", "Conseils", "Histoire", "Humeur", "Mémoire", "Secrets"],
  },
  {
    symbol: "■", title: "OUTILS", color: "#FFA230", icon: Wrench,
    facettes: ["Grille Aida", "Mesurer", "Paramètres", "Zoom", "Exporter", "Raccourcis", "Thème", "Langue"],
  },
  {
    symbol: "●", title: "CRÉATION", color: "#1D5DA5", icon: Palette,
    facettes: ["Dessiner", "Palette", "Broderie", "Formes", "Texte", "Dégradé", "Symétrie", "Tampon"],
  },
  {
    symbol: "∞", title: "CONNEXION", color: "#E87DA5", icon: Share2,
    facettes: ["Partager", "Amis", "Communauté", "Messages", "Notifs", "Profil", "Inviter", "Événements"],
  },
  {
    symbol: "▲", title: "VISION", color: "#5B1D6E", icon: Eye,
    facettes: ["Photo", "Galerie", "IA pattern", "Scanner", "Filtres", "Recadrer", "Résolution", "Aperçu"],
  },
];

// ── Color nuancier utilities ──
function hexToHsl(hex: string): [number, number, number] {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return [h * 360, s * 100, l * 100];
}

function hslToHex(h: number, s: number, l: number): string {
  s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * Math.max(0, Math.min(1, c))).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

// step 0 = lightest (top-left, 1ère étape), step 7 = darkest (bottom-right, dernière étape)
function getFacetteColor(baseHex: string, step: number): string {
  const [h, s, l] = hexToHsl(baseHex);
  // Lightness offsets: gentle gradient from light to deep
  const offsets = [22, 17, 12, 7, 0, -6, -12, -18];
  const newL = Math.max(12, Math.min(85, l + offsets[step]));
  // Slightly desaturate lighter shades, boost darker ones
  const newS = Math.max(20, Math.min(100, s + (step < 3 ? -6 : step > 5 ? 4 : 0)));
  return hslToHex(h, newS, newL);
}

// ── Reading order: maps NEIGHBOR_OFFSETS index → facette index (0-7)
// Layout:  NW(7)  N(0)  NE(1)    ← row 1 (top)
//          W(6)   [♥]   E(2)     ← row 2 (mid)
//          SW(5)  S(4)  SE(3)    ← row 3 (bot)
// Reading L→R, T→B:  NW→N→NE → W→E → SW→S→SE = facettes 0,1,2,3,4,5,6,7
const READING_ORDER = [1, 2, 4, 7, 6, 5, 3, 0];

// N, NE, E, SE, S, SW, W, NW
const NEIGHBOR_OFFSETS: [number, number][] = [
  [0, -1], [1, -1], [1, 0], [1, 1],
  [0, 1], [-1, 1], [-1, 0], [-1, -1],
];

const MIN_ZOOM = 0.15;
const MAX_ZOOM = 4;
const DRAG_THRESHOLD = 4;

const pmod = (v: number, m: number) => ((v % m) + m) % m;

// ── Journey steps ──
type JourneyStep = "place" | "deployed" | "lily-calls" | "lily-awake";

const STEP_LABELS: Record<JourneyStep, string> = {
  place: "Place ton carré",
  deployed: "8 univers",
  "lily-calls": "Lily t'attend…",
  "lily-awake": "Lily est là ✂",
};
const STEPS_ORDER: JourneyStep[] = ["place", "deployed", "lily-calls", "lily-awake"];

interface StitchLabAppProps {
  onBack: () => void;
  onShowTimeHeart?: () => void;
  onLastStitchChange?: (key: string | null) => void;
}

export function StitchLabApp({ onBack, onShowTimeHeart, onLastStitchChange }: StitchLabAppProps) {
  const { isMobile, vw, vh } = useResponsive();
  const [isDark, setIsDark] = useState(true);
  const [deployed, setDeployed] = useState(true);
  const [activeFam, setActiveFam] = useState<number | null>(null);
  const [isPanningVisual, setIsPanningVisual] = useState(false);
  const [isDraggingHeart, setIsDraggingHeart] = useState(false);
  const [journeyStep, setJourneyStep] = useState<JourneyStep>("lily-awake");
  const [lilyMessage, setLilyMessage] = useState<string | null>("Explore chaque univers ! Clique sur un carré pour voir ce qu'il propose ✨");

  const cellSize = isMobile ? 40 : 52;

  // ─── Active tool & grid paint state ──
  const [activeTool, setActiveTool] = useState<ActiveTool | null>(null);
  const [gridPaints, setGridPaints] = useState<GridPaints>({});
  const drawingRef = useRef(false); // is pointer held down while drawing
  const lastPaintedCellRef = useRef<string | null>(null);

  // ─── Photo import (activates ▲ VISION) ──
  const [importedPhoto, setImportedPhoto] = useState<string | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // ─── Heart config (editable via facettes) ──
  const [heartConfig, setHeartConfig] = useState({
    color: HEART_RED,
    colorCode: "666",
    symbol: "♥",
    symbol2: undefined as string | undefined,
    symbolSize: 50,
    rotation: 0,
    contrast: 100,
  });

  const handleUpdateHeart = useCallback((patch: Partial<typeof heartConfig>) => {
    setHeartConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  // ─── Photo import handler (activates ▲ VISION) ──
  const handlePhotoImport = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setImportedPhoto(ev.target?.result as string);
      // Auto-deploy + activate VISION family (index 7)
      setDeployed(true);
      setActiveFam(7);
      setLilyMessage("Photo importee ! Les facettes ▲ VISION sont activees — explore Photo, IA pattern, Scanner...");
    };
    reader.readAsDataURL(file);
  }, []);

  // ─── Facette panel state ──
  const [openPanel, setOpenPanel] = useState<{ fam: number; facette: number } | null>(null);

  // ─── Heart position in CELL units ──
  // heartCell represents which grid INTERSECTION the heart is centered on
  const [heartCell, setHeartCell] = useState({ cx: 0, cy: 0 });
  // Heart CENTER is at grid intersection (cx*cellSize, cy*cellSize)
  // Heart top-left is offset by -cellSize/2 so center lands on the intersection
  const heartWorldX = heartCell.cx * cellSize - cellSize / 2;
  const heartWorldY = heartCell.cy * cellSize - cellSize / 2;
  const heartCenterX = heartCell.cx * cellSize;
  const heartCenterY = heartCell.cy * cellSize;

  // ─── Camera ──
  const [camera, setCamera] = useState({ x: 0, y: 0, zoom: 1 });
  const cameraRef = useRef(camera);
  cameraRef.current = camera;

  const containerRef = useRef<HTMLDivElement>(null);

  // Pan refs
  const panRef = useRef({
    active: false, pointerId: -1,
    startX: 0, startY: 0, camX: 0, camY: 0, moved: false,
  });
  const wasDraggingCanvasRef = useRef(false);

  // Heart drag refs
  const heartDragRef = useRef({
    active: false, pointerId: -1,
    startX: 0, startY: 0,
    origWorldX: 0, origWorldY: 0,
    moved: false,
  });

  // Magnetic guide lines (world coords, visible while dragging)
  const [snapGuides, setSnapGuides] = useState<{ hx: number | null; hy: number | null }>({ hx: null, hy: null });

  // Pinch
  const pinchRef = useRef({ active: false, dist: 0, zoom: 1, cx: 0, cy: 0 });

  // ─── Init camera centered on heart ───
  useEffect(() => {
    // Heart center is at world (0,0), center that in viewport
    setCamera({
      x: vw / 2,
      y: vh / 2,
      zoom: 1,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ─── Step auto-advance: no longer needed (click goes straight to lily-awake) ───

  // ─── Lily message is set directly in click handler ───

  // ─── Screen → grid cell conversion ───
  const screenToCell = useCallback((clientX: number, clientY: number): [number, number] => {
    const cam = cameraRef.current;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return [0, 0];
    const mx = clientX - rect.left;
    const my = clientY - rect.top;
    const wx = (mx - cam.x) / cam.zoom;
    const wy = (my - cam.y) / cam.zoom;
    // Cell origin is at top-left of cell, cell centers are at half-cell offsets
    // Grid cells are indexed so that cell (0,0) goes from world (0,0) to (cellSize, cellSize)
    const cx = Math.floor(wx / cellSize);
    const cy = Math.floor(wy / cellSize);
    return [cx, cy];
  }, [cellSize]);

  // ─── Paint a cell (for draw / eraser / pick-color) ───
  const paintCell = useCallback((clientX: number, clientY: number) => {
    if (!activeTool) return;
    const [cx, cy] = screenToCell(clientX, clientY);
    const key = cellKey(cx, cy);
    if (key === lastPaintedCellRef.current) return; // skip duplicates
    lastPaintedCellRef.current = key;

    if (activeTool.type === "draw") {
      setGridPaints((prev) => ({ ...prev, [key]: activeTool.color }));
      onLastStitchChange?.(key);
    } else if (activeTool.type === "eraser") {
      setGridPaints((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    } else if (activeTool.type === "pick-color") {
      const existing = gridPaints[key];
      if (existing) {
        setActiveTool((t) => t ? { ...t, color: existing, type: "draw" } : t);
        setLilyMessage(`Couleur captée : ${existing}`);
      }
    }
  }, [activeTool, screenToCell, gridPaints]);

  // ─── Wheel zoom ───
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handler = (e: WheelEvent) => {
      e.preventDefault();
      const cam = cameraRef.current;
      const rect = el.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const factor = e.deltaY > 0 ? 0.92 : 1.09;
      const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, cam.zoom * factor));
      const wx = (mx - cam.x) / cam.zoom;
      const wy = (my - cam.y) / cam.zoom;
      setCamera({ x: mx - wx * newZoom, y: my - wy * newZoom, zoom: newZoom });
    };
    el.addEventListener("wheel", handler, { passive: false });
    return () => el.removeEventListener("wheel", handler);
  }, []);

  // ═══ CANVAS PAN ═══
  const handleCanvasPointerDown = useCallback((e: React.PointerEvent) => {
    if (e.button !== 0) return;
    // If a drawing tool is active, start drawing instead of panning
    if (activeTool && activeTool.type !== "hand") {
      drawingRef.current = true;
      lastPaintedCellRef.current = null;
      paintCell(e.clientX, e.clientY);
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      return;
    }
    setActiveFam(null);
    setOpenPanel(null);
    panRef.current = {
      active: true, pointerId: e.pointerId,
      startX: e.clientX, startY: e.clientY,
      camX: cameraRef.current.x, camY: cameraRef.current.y,
      moved: false,
    };
    wasDraggingCanvasRef.current = false;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }, [activeTool, paintCell]);

  const handleCanvasPointerMove = useCallback((e: React.PointerEvent) => {
    // Drawing mode: paint continuously
    if (drawingRef.current && activeTool && activeTool.type !== "hand") {
      paintCell(e.clientX, e.clientY);
      return;
    }
    const p = panRef.current;
    if (!p.active || e.pointerId !== p.pointerId) return;
    const dx = e.clientX - p.startX;
    const dy = e.clientY - p.startY;
    if (Math.abs(dx) + Math.abs(dy) > DRAG_THRESHOLD) {
      p.moved = true;
      wasDraggingCanvasRef.current = true;
      setIsPanningVisual(true);
      setCamera((c) => ({ ...c, x: p.camX + dx, y: p.camY + dy }));
    }
  }, [activeTool, paintCell]);

  const handleCanvasPointerUp = useCallback((e: React.PointerEvent) => {
    if (drawingRef.current) {
      drawingRef.current = false;
      lastPaintedCellRef.current = null;
      return;
    }
    if (e.pointerId === panRef.current.pointerId) {
      panRef.current.active = false;
      setIsPanningVisual(false);
      setTimeout(() => { wasDraggingCanvasRef.current = false; }, 10);
    }
  }, []);

  // ═══ HEART DRAG with magnetic snap guides ═══
  const handleHeartPointerDown = useCallback((e: React.PointerEvent) => {
    e.stopPropagation();
    if (e.button !== 0) return;
    heartDragRef.current = {
      active: true, pointerId: e.pointerId,
      startX: e.clientX, startY: e.clientY,
      origWorldX: heartCell.cx * cellSize,
      origWorldY: heartCell.cy * cellSize,
      moved: false,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }, [heartCell, cellSize]);

  const handleHeartPointerMove = useCallback((e: React.PointerEvent) => {
    const h = heartDragRef.current;
    if (!h.active || e.pointerId !== h.pointerId) return;
    const cam = cameraRef.current;
    const dx = (e.clientX - h.startX) / cam.zoom;
    const dy = (e.clientY - h.startY) / cam.zoom;
    if (Math.abs(dx) + Math.abs(dy) > DRAG_THRESHOLD / cam.zoom) {
      h.moved = true;
      setIsDraggingHeart(true);
      const newCx = Math.round((h.origWorldX + dx) / cellSize);
      const newCy = Math.round((h.origWorldY + dy) / cellSize);
      setHeartCell({ cx: newCx, cy: newCy });
      // Magnetic snap guide lines at the snap position
      setSnapGuides({ hx: newCx * cellSize, hy: newCy * cellSize });
    }
  }, [cellSize]);

  const handleHeartPointerUp = useCallback((e: React.PointerEvent) => {
    const h = heartDragRef.current;
    if (e.pointerId !== h.pointerId) return;
    const wasDrag = h.moved;
    h.active = false;
    setIsDraggingHeart(false);
    setSnapGuides({ hx: null, hy: null });
    if (!wasDrag) {
      // Click on heart:
      // If in facette mode → go back to family view
      // If families shown → collapse
      // If collapsed → deploy + awaken Lily
      if (activeFam !== null) {
        setActiveFam(null);
        setOpenPanel(null);
        setLilyMessage(null);
      } else {
        setDeployed((d) => {
          if (d) {
            setJourneyStep("place");
            setLilyMessage(null);
          } else {
            setJourneyStep("lily-awake");
            setLilyMessage(null);
          }
          return !d;
        });
      }
    }
  }, [activeFam]);

  // ═══ TOUCH PINCH ═══
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const [t1, t2] = [e.touches[0], e.touches[1]];
      pinchRef.current = {
        active: true,
        dist: Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY),
        zoom: cameraRef.current.zoom,
        cx: (t1.clientX + t2.clientX) / 2,
        cy: (t1.clientY + t2.clientY) / 2,
      };
    }
  }, []);
  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 2 && pinchRef.current.active) {
      const [t1, t2] = [e.touches[0], e.touches[1]];
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const scale = dist / pinchRef.current.dist;
      const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, pinchRef.current.zoom * scale));
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const mx = pinchRef.current.cx - rect.left;
      const my = pinchRef.current.cy - rect.top;
      const cam = cameraRef.current;
      const wx = (mx - cam.x) / cam.zoom;
      const wy = (my - cam.y) / cam.zoom;
      setCamera({ x: mx - wx * newZoom, y: my - wy * newZoom, zoom: newZoom });
    }
  }, []);
  const handleTouchEnd = useCallback(() => { pinchRef.current.active = false; }, []);

  // ═══ ZOOM + RECENTER ═══
  const zoomTowardCenter = useCallback(
    (factor: number) => {
      setCamera((c) => {
        const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, c.zoom * factor));
        const wx = (vw / 2 - c.x) / c.zoom;
        const wy = (vh / 2 - c.y) / c.zoom;
        return { x: vw / 2 - wx * newZoom, y: vh / 2 - wy * newZoom, zoom: newZoom };
      });
    },
    [vw, vh]
  );

  const recenter = useCallback(() => {
    setCamera({ x: vw / 2 - heartCenterX, y: vh / 2 - heartCenterY, zoom: 1 });
  }, [vw, vh, heartCenterX, heartCenterY]);

  // ─── Theme ───
  const bg = isDark ? "#0A0A0A" : "#F5F2ED";
  const textMuted = isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.35)";
  const textSoft = isDark ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.15)";
  const textFaint = isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)";

  // ─── Grid pattern ───
  const z = camera.zoom;
  const scaledCell = cellSize * z;
  const scaledBold = 8 * cellSize * z;

  const fineC = isDark ? "%23ffffff" : "%23000000";
  const fineOp = isDark ? "0.04" : "0.06";
  const diagOp = isDark ? "0.012" : "0.02";
  const boldOp = isDark ? "0.07" : "0.10";

  const finePatternSvg = `url("data:image/svg+xml,%3Csvg width='${cellSize}' height='${cellSize}' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='${cellSize}' height='${cellSize}' fill='none' stroke='${fineC}' stroke-opacity='${fineOp}' stroke-width='0.5'/%3E%3Cline x1='0' y1='0' x2='${cellSize}' y2='${cellSize}' stroke='${fineC}' stroke-opacity='${diagOp}' stroke-width='0.3'/%3E%3Cline x1='${cellSize}' y1='0' x2='0' y2='${cellSize}' stroke='${fineC}' stroke-opacity='${diagOp}' stroke-width='0.3'/%3E%3C/svg%3E")`;

  const bold8 = 8 * cellSize;
  const boldPatternSvg = `url("data:image/svg+xml,%3Csvg width='${bold8}' height='${bold8}' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='${bold8}' height='${bold8}' fill='none' stroke='${fineC}' stroke-opacity='${boldOp}' stroke-width='1'/%3E%3C/svg%3E")`;

  const bgPosX = pmod(camera.x, scaledCell);
  const bgPosY = pmod(camera.y, scaledCell);
  const boldPosX = pmod(camera.x, scaledBold);
  const boldPosY = pmod(camera.y, scaledBold);

  // ─── Visible coords ───
  const visibleCoords = useMemo(() => {
    const wl = -camera.x / z;
    const wr = (vw - camera.x) / z;
    const wt = -camera.y / z;
    const wb = (vh - camera.y) / z;
    const bSize = 8 * cellSize;
    const x0 = Math.floor(wl / bSize) - 1;
    const x1 = Math.ceil(wr / bSize) + 1;
    const y0 = Math.floor(wt / bSize) - 1;
    const y1 = Math.ceil(wb / bSize) + 1;
    const labels: { gx: number; gy: number; px: number; py: number }[] = [];
    for (let xi = x0; xi <= x1; xi++) {
      for (let yi = y0; yi <= y1; yi++) {
        if (xi === 0 && yi === 0) continue;
        labels.push({ gx: xi * 8, gy: yi * 8, px: xi * bSize, py: yi * bSize });
      }
    }
    return labels;
  }, [camera.x, camera.y, z, vw, vh, cellSize]);

  const zoomPct = Math.round(z * 100);
  const axisLen = Math.max(vw, vh) / z + 2000;

  const heartCursor = isDraggingHeart ? "grabbing" : "grab";
  const canvasCursor = activeTool && activeTool.type !== "hand"
    ? (activeTool.type === "draw" ? "crosshair" : activeTool.type === "eraser" ? "crosshair" : "crosshair")
    : isPanningVisual ? "grabbing" : "grab";

  const isLilyAwake = journeyStep === "lily-awake";
  const currentStepIdx = STEPS_ORDER.indexOf(journeyStep);

  return (
    <div
      className="relative w-full h-screen overflow-hidden select-none"
      style={{
        backgroundColor: bg,
        transition: "background-color 0.8s ease",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      {/* Hidden photo file input */}
      <input ref={photoInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoImport} />

      {/* ═══ GRID VIEWPORT ═══ */}
      <div
        ref={containerRef}
        className="absolute inset-0"
        style={{
          cursor: canvasCursor,
          backgroundImage: `${boldPatternSvg}, ${finePatternSvg}`,
          backgroundSize: `${scaledBold}px ${scaledBold}px, ${scaledCell}px ${scaledCell}px`,
          backgroundPosition: `${boldPosX}px ${boldPosY}px, ${bgPosX}px ${bgPosY}px`,
          touchAction: "none",
        }}
        onPointerDown={handleCanvasPointerDown}
        onPointerMove={handleCanvasPointerMove}
        onPointerUp={handleCanvasPointerUp}
        onPointerCancel={handleCanvasPointerUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* ─── Transform layer (world space) ─── */}
        <div
          className="absolute"
          style={{
            left: 0, top: 0,
            transform: `translate(${camera.x}px, ${camera.y}px) scale(${z})`,
            transformOrigin: "0 0",
            willChange: "transform",
          }}
        >
          {/* ── Red crosshair axes (world 0,0 = grid intersection) ── */}
          {/* Vertical axis at x=0 */}
          <div
            className="absolute pointer-events-none"
            style={{
              left: 0, top: -axisLen,
              width: 1, height: axisLen * 2,
              background: `linear-gradient(to bottom, rgba(0,0,0,0) 0%, ${HEART_RED}18 30%, ${HEART_RED}30 48%, ${HEART_RED}30 52%, ${HEART_RED}18 70%, rgba(0,0,0,0) 100%)`,
            }}
          />
          {/* Horizontal axis at y=0 */}
          <div
            className="absolute pointer-events-none"
            style={{
              left: -axisLen, top: 0,
              width: axisLen * 2, height: 1,
              background: `linear-gradient(to right, rgba(0,0,0,0) 0%, ${HEART_RED}18 30%, ${HEART_RED}30 48%, ${HEART_RED}30 52%, ${HEART_RED}18 70%, rgba(0,0,0,0) 100%)`,
            }}
          />
          {/* Origin glow dot at (0,0) */}
          <div
            className="absolute pointer-events-none rounded-full"
            style={{
              left: -3, top: -3,
              width: 6, height: 6,
              backgroundColor: `${HEART_RED}40`,
              boxShadow: `0 0 8px ${HEART_RED}30`,
            }}
          />

          {/* ── Coordinate labels ── */}
          {visibleCoords.map((c) => (
            <span
              key={`c-${c.gx}-${c.gy}`}
              className="absolute pointer-events-none"
              style={{
                left: c.px + 3, top: c.py + 2,
                fontSize: 7, color: textFaint,
                fontVariantNumeric: "tabular-nums",
                whiteSpace: "nowrap",
                transition: "color 0.8s ease",
              }}
            >
              {c.gx},{c.gy}
            </span>
          ))}

          {/* ═══ MAGNETIC SNAP GUIDE LINES ═══ */}
          <AnimatePresence>
            {isDraggingHeart && snapGuides.hx !== null && (
              <>
                {/* Vertical guide through grid intersection */}
                <motion.div
                  key="guide-v"
                  className="absolute pointer-events-none"
                  style={{
                    left: snapGuides.hx!,
                    top: -axisLen,
                    width: 1,
                    height: axisLen * 2,
                    background: `linear-gradient(to bottom, rgba(0,0,0,0) 0%, ${LILY_PURPLE}50 35%, ${LILY_PURPLE}90 50%, ${LILY_PURPLE}50 65%, rgba(0,0,0,0) 100%)`,
                  }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.12 }}
                />
                {/* Horizontal guide through grid intersection */}
                <motion.div
                  key="guide-h"
                  className="absolute pointer-events-none"
                  style={{
                    left: -axisLen,
                    top: snapGuides.hy!,
                    width: axisLen * 2,
                    height: 1,
                    background: `linear-gradient(to right, rgba(0,0,0,0) 0%, ${LILY_PURPLE}50 35%, ${LILY_PURPLE}90 50%, ${LILY_PURPLE}50 65%, rgba(0,0,0,0) 100%)`,
                  }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.12 }}
                />
                {/* Intersection diamond */}
                <motion.div
                  key="guide-dot"
                  className="absolute pointer-events-none"
                  style={{
                    left: snapGuides.hx! - 4,
                    top: snapGuides.hy! - 4,
                    width: 8,
                    height: 8,
                    borderRadius: 2,
                    backgroundColor: `${LILY_PURPLE}80`,
                    boxShadow: `0 0 8px ${LILY_PURPLE}60`,
                    transform: "rotate(45deg)",
                  }}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ duration: 0.15, type: "spring", stiffness: 300 }}
                />
              </>
            )}
          </AnimatePresence>

          {/* ═══ CROSS-STITCH PATTERN (photo converted to pixel grid) ═══ */}
          {/* (removed — photo import panel suppressed) */}

          {/* ═══ PAINTED GRID CELLS ═══ */}
          {Object.entries(gridPaints).map(([key, color]) => {
            const [cx, cy] = key.split(",").map(Number);
            return (
              <div
                key={`p-${key}`}
                className="absolute pointer-events-none"
                style={{
                  left: cx * cellSize,
                  top: cy * cellSize,
                  width: cellSize,
                  height: cellSize,
                  backgroundColor: color,
                  opacity: 0.85,
                  borderRadius: 1,
                }}
              />
            );
          })}

          {/* ═══ DRAGGABLE HEART GROUP ═══ */}
          <div
            className="absolute"
            style={{
              left: heartWorldX,
              top: heartWorldY,
              transition: isDraggingHeart ? "none" : "left 0.15s ease, top 0.15s ease",
            }}
          >
            {/* ── Heart / Lily square ── */}
            <motion.div
              className="absolute z-10"
              style={{
                left: 0, top: 0,
                width: cellSize, height: cellSize,
                cursor: heartCursor,
              }}
              onPointerDown={handleHeartPointerDown}
              onPointerMove={handleHeartPointerMove}
              onPointerUp={handleHeartPointerUp}
              onPointerCancel={handleHeartPointerUp}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.6, duration: 0.8, type: "spring", stiffness: 60 }}
            >
              {/* Glow background */}
              <motion.div
                className="absolute rounded-md pointer-events-none"
                style={{
                  inset: -8,
                  background: `radial-gradient(circle, ${isLilyAwake ? LILY_PURPLE : HEART_RED}15 0%, rgba(0,0,0,0) 70%)`,
                }}
                animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              />

              {/* Pulse rings (only before Lily awakens) */}
              {!deployed && !isDraggingHeart && !isLilyAwake && (
                <>
                  <motion.div
                    className="absolute rounded-md pointer-events-none"
                    style={{ inset: -6, border: `1px solid ${HEART_RED}20` }}
                    animate={{ scale: [1, 1.12, 1], opacity: [0.2, 0.6, 0.2] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <motion.div
                    className="absolute rounded-lg pointer-events-none"
                    style={{ inset: -14, border: `1px solid ${HEART_RED}0A` }}
                    animate={{ scale: [1, 1.08, 1], opacity: [0.1, 0.3, 0.1] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  />
                </>
              )}

              {/* Drag indicator */}
              {isDraggingHeart && (
                <motion.div
                  className="absolute pointer-events-none rounded-[3px]"
                  style={{
                    inset: -4,
                    border: `2px dashed ${LILY_PURPLE}60`,
                  }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.15 }}
                />
              )}

              {/* THE SQUARE: always red, with face when Lily is awake */}
              <AnimatePresence mode="wait">
                {isLilyAwake ? (
                  <motion.div
                    key="lily"
                    initial={{ scale: 0.8, rotateY: 90 }}
                    animate={{ scale: 1, rotateY: 0 }}
                    transition={{ duration: 0.6, type: "spring", stiffness: 80 }}
                  >
                    <LilyFace
                      size={cellSize}
                      colorHex={HEART_RED}
                      speaking={!!lilyMessage}
                      message={lilyMessage ?? undefined}
                      isDark={isDark}
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="heart"
                    exit={{ scale: 0.8, rotateY: -90, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <PlayerSquare
                      colorHex={HEART_RED}
                      symbol="♥"
                      size={cellSize}
                      symbolSize={Math.round(cellSize * 0.7)}
                      glowing
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* ── 8 DEPLOYED SQUARES: families or facettes (8→64) ── */}
            <AnimatePresence mode="wait">
              {deployed && (
                <motion.div
                  key={activeFam === null ? "families" : `fac-${activeFam}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.15 }}
                >
                  {NEIGHBOR_OFFSETS.map((offset, i) => {
                    const [dx, dy] = offset;
                    const px = dx * cellSize;
                    const py = dy * cellSize;

                    const inFacetteMode = activeFam !== null;
                    const readingIdx = READING_ORDER[i]; // 0=top-left first, 7=bottom-right last
                    const fam = inFacetteMode ? FAMILIES[activeFam] : FAMILIES[i];
                    const color = inFacetteMode
                      ? getFacetteColor(fam.color, readingIdx)
                      : fam.color;
                    const label = inFacetteMode ? fam.facettes[readingIdx] : fam.title;
                    const Icon = inFacetteMode ? FAC_ICONS[activeFam][readingIdx] : fam.icon;

                    return (
                      <motion.div
                        key={`pos-${i}`}
                        className="absolute"
                        style={{
                          left: px, top: py,
                          width: cellSize, height: cellSize,
                          cursor: "pointer",
                          zIndex: 50,
                        }}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{
                          delay: i * 0.04, duration: 0.35,
                          type: "spring", stiffness: 220, damping: 18,
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!inFacetteMode) {
                            setActiveFam(i);
                            setLilyMessage(`${FAMILIES[i].symbol} ${FAMILIES[i].title} — 8 facettes`);
                          } else {
                            // Open the facette panel
                            setLilyMessage(`${fam.symbol} ${label}`);
                            setOpenPanel({ fam: activeFam!, facette: readingIdx });
                          }
                        }}
                      >
                        <motion.div
                          className="absolute inset-0 rounded-[3px] flex flex-col items-center justify-center gap-0.5 overflow-hidden"
                          style={{
                            backgroundColor: color,
                            boxShadow: (!inFacetteMode && i === 7 && importedPhoto)
                              ? `0 0 28px ${color}90, 0 0 56px ${color}40, 0 2px 8px rgba(0,0,0,0.3)`
                              : `0 0 18px ${color}50, 0 2px 8px rgba(0,0,0,0.3)`,
                          }}
                          whileHover={{ scale: 1.08 }}
                          whileTap={{ scale: 0.94 }}
                          animate={(!inFacetteMode && i === 7 && importedPhoto)
                            ? { scale: [1, 1.06, 1] }
                            : {}}
                          transition={(!inFacetteMode && i === 7 && importedPhoto)
                            ? { duration: 2, repeat: Infinity, ease: "easeInOut" }
                            : undefined}
                        >
                          <Icon size={isMobile ? 14 : 18} color="#fff" strokeWidth={1.8} />
                          {!inFacetteMode && (
                            <span
                              style={{
                                fontSize: isMobile ? 5 : 7,
                                color: "#fff",
                                fontWeight: 700,
                                letterSpacing: "0.1em",
                                textShadow: "0 1px 2px rgba(0,0,0,0.3)",
                              }}
                            >
                              {label}
                            </span>
                          )}
                        </motion.div>
                      </motion.div>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* ═══ HEADER ═══ */}
      <motion.div
        className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between pointer-events-none"
        style={{
          padding: isMobile ? "12px 16px" : "16px 24px",
          background: isDark
            ? "linear-gradient(to bottom, rgba(10,10,10,0.95) 0%, rgba(10,10,10,0.7) 60%, rgba(10,10,10,0) 100%)"
            : "linear-gradient(to bottom, rgba(245,242,237,0.95) 0%, rgba(245,242,237,0.7) 60%, rgba(245,242,237,0) 100%)",
          transition: "background 0.8s ease",
        }}
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <div className="flex items-center gap-3 pointer-events-auto">
          <motion.button
            className="flex items-center justify-center cursor-pointer border-none rounded-full"
            style={{
              width: isMobile ? 36 : 34, height: isMobile ? 36 : 34,
              backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: textMuted, transition: "all 0.3s ease",
            }}
            onClick={onBack}
            whileHover={{ scale: 1.1, backgroundColor: isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)" }}
            whileTap={{ scale: 0.9 }}
            aria-label="Retour"
          >
            <ArrowLeft size={16} />
          </motion.button>
          <StitchLabLogo size="sm" />
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          {/* ── TimeHeart Map ── */}
          {onShowTimeHeart && (
            <motion.button
              className="relative flex items-center gap-2 cursor-pointer border-none rounded-full overflow-hidden"
              style={{
                padding: isMobile ? "7px 12px" : "7px 14px",
                background: isDark
                  ? "linear-gradient(135deg, rgba(232,23,127,0.15) 0%, rgba(146,99,166,0.15) 100%)"
                  : "linear-gradient(135deg, rgba(232,23,127,0.10) 0%, rgba(146,99,166,0.10) 100%)",
                color: HEART_RED,
                fontSize: 12, fontWeight: 500,
                transition: "all 0.3s ease",
              }}
              onClick={onShowTimeHeart}
              whileHover={{ scale: 1.05, boxShadow: `0 0 20px ${HEART_RED}30` }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background: `radial-gradient(circle at 30% 50%, ${HEART_RED}12 0%, rgba(0,0,0,0) 70%)`,
                }}
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.span
                style={{ fontSize: 14, position: "relative" }}
                animate={{ scale: [1, 1.15, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                ♥
              </motion.span>
              <span className="relative" style={{ letterSpacing: "0.06em" }}>TimeHeart</span>
            </motion.button>
          )}

          {/* ── Import Photo → activates ▲ VISION ── */}
          <motion.button
            className="relative flex items-center gap-1.5 cursor-pointer border-none rounded-full overflow-hidden"
            style={{
              padding: isMobile ? "7px 10px" : "7px 12px",
              background: importedPhoto
                ? "linear-gradient(135deg, rgba(91,29,110,0.2) 0%, rgba(146,99,166,0.15) 100%)"
                : isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: importedPhoto ? "#9263A6" : textMuted,
              fontSize: 11, fontWeight: 500, transition: "all 0.3s ease",
            }}
            onClick={() => photoInputRef.current?.click()}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Camera size={13} />
            {importedPhoto ? "▲" : "Photo"}
          </motion.button>

          <motion.button
            className="flex items-center justify-center cursor-pointer border-none rounded-full"
            style={{
              width: isMobile ? 36 : 34, height: isMobile ? 36 : 34,
              backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: `${HEART_RED}80`, transition: "all 0.3s ease",
            }}
            onClick={recenter}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            aria-label="Recentrer"
          >
            <Crosshair size={15} />
          </motion.button>

          <motion.button
            className="flex items-center gap-2 cursor-pointer border-none rounded-full"
            style={{
              padding: isMobile ? "7px 14px" : "7px 16px",
              backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)",
              color: textMuted, fontSize: 12, fontWeight: 400, transition: "all 0.3s ease",
            }}
            onClick={() => setIsDark(!isDark)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <AnimatePresence mode="wait">
              {isDark ? (
                <motion.div key="moon" initial={{ rotate: -30, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 30, opacity: 0 }} transition={{ duration: 0.2 }}>
                  <Moon size={14} />
                </motion.div>
              ) : (
                <motion.div key="sun" initial={{ rotate: -30, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 30, opacity: 0 }} transition={{ duration: 0.2 }}>
                  <Sun size={14} />
                </motion.div>
              )}
            </AnimatePresence>
            <span>{isDark ? "Nuit" : "Jour"}</span>
          </motion.button>
        </div>
      </motion.div>

      {/* ═══ JOURNEY STEP DOTS (bottom-left) ═══ */}
      <motion.div
        className="absolute z-30 flex items-center gap-2 pointer-events-none"
        style={{
          bottom: isMobile ? 62 : 68,
          left: isMobile ? 16 : 24,
        }}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0, duration: 0.6 }}
      >
        {STEPS_ORDER.map((step, idx) => {
          const isCurrent = idx === currentStepIdx;
          const isPast = idx < currentStepIdx;
          const dotColor = step === "lily-calls" || step === "lily-awake"
            ? LILY_PURPLE
            : HEART_RED;

          return (
            <motion.div
              key={step}
              className="relative flex items-center justify-center"
              style={{ width: isCurrent ? 28 : 8, height: 8 }}
              animate={{ width: isCurrent ? 28 : 8 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
            >
              <motion.div
                className="rounded-full"
                style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: isCurrent ? 4 : 999,
                  backgroundColor: isPast || isCurrent
                    ? dotColor
                    : isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)",
                  opacity: isCurrent ? 1 : isPast ? 0.5 : 0.3,
                  boxShadow: isCurrent ? `0 0 10px ${dotColor}50` : "none",
                  transition: "background-color 0.4s ease, opacity 0.4s ease",
                }}
              />

              {/* Current step label */}
              <AnimatePresence>
                {isCurrent && (
                  <motion.span
                    className="absolute whitespace-nowrap pointer-events-none"
                    style={{
                      top: -22,
                      left: "50%",
                      transform: "translateX(-50%)",
                      fontSize: 9,
                      fontWeight: 400,
                      color: dotColor,
                      letterSpacing: "0.06em",
                      opacity: 0.8,
                    }}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 0.8, y: 0 }}
                    exit={{ opacity: 0, y: 4 }}
                    transition={{ duration: 0.3 }}
                  >
                    {STEP_LABELS[step]}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </motion.div>

      {/* ═══ ZOOM CONTROLS (bottom-right) ═══ */}
      <motion.div
        className="absolute z-30 flex items-center gap-1 rounded-xl pointer-events-auto"
        style={{
          bottom: isMobile ? 62 : 68,
          right: isMobile ? 12 : 20,
          padding: "4px 6px",
          backgroundColor: isDark ? "rgba(30,30,30,0.85)" : "rgba(255,255,255,0.85)",
          backdropFilter: "blur(14px)",
          border: `1px solid ${isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)"}`,
          boxShadow: isDark ? "0 4px 16px rgba(0,0,0,0.4)" : "0 4px 16px rgba(0,0,0,0.06)",
          transition: "all 0.8s ease",
        }}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <motion.button
          className="flex items-center justify-center cursor-pointer border-none rounded-lg"
          style={{
            width: isMobile ? 34 : 30, height: isMobile ? 34 : 30,
            backgroundColor: "rgba(0,0,0,0)",
            color: z <= MIN_ZOOM ? (isDark ? "#555" : "#ccc") : (isDark ? "#aaa" : "#888"),
            opacity: z <= MIN_ZOOM ? 0.4 : 1,
          }}
          onClick={() => zoomTowardCenter(0.8)}
          whileHover={{ scale: 1.1, backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)" }}
          whileTap={{ scale: 0.9 }}
          disabled={z <= MIN_ZOOM}
        >
          <ZoomOut size={15} strokeWidth={1.6} />
        </motion.button>

        <motion.button
          className="flex items-center justify-center cursor-pointer border-none rounded-lg"
          style={{
            height: isMobile ? 34 : 30, minWidth: isMobile ? 44 : 42,
            backgroundColor: "rgba(0,0,0,0)",
            color: zoomPct === 100 ? (isDark ? "#555" : "#ccc") : (isDark ? "#aaa" : "#888"),
            fontSize: isMobile ? 11 : 10, fontWeight: 500, fontVariantNumeric: "tabular-nums",
          }}
          onClick={recenter}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {zoomPct === 100 ? <Maximize2 size={13} strokeWidth={1.4} /> : `${zoomPct}%`}
        </motion.button>

        <motion.button
          className="flex items-center justify-center cursor-pointer border-none rounded-lg"
          style={{
            width: isMobile ? 34 : 30, height: isMobile ? 34 : 30,
            backgroundColor: "rgba(0,0,0,0)",
            color: z >= MAX_ZOOM ? (isDark ? "#555" : "#ccc") : (isDark ? "#aaa" : "#888"),
            opacity: z >= MAX_ZOOM ? 0.4 : 1,
          }}
          onClick={() => zoomTowardCenter(1.25)}
          whileHover={{ scale: 1.1, backgroundColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.04)" }}
          whileTap={{ scale: 0.9 }}
          disabled={z >= MAX_ZOOM}
        >
          <ZoomIn size={15} strokeWidth={1.6} />
        </motion.button>
      </motion.div>

      {/* ═══ BOTTOM STATUS BAR ═══ */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 z-30 flex items-center justify-center pointer-events-none"
        style={{
          padding: isMobile ? "20px 16px" : "24px 24px",
          background: isDark
            ? "linear-gradient(to top, rgba(10,10,10,0.95) 0%, rgba(10,10,10,0.6) 60%, rgba(10,10,10,0) 100%)"
            : "linear-gradient(to top, rgba(245,242,237,0.95) 0%, rgba(245,242,237,0.6) 60%, rgba(245,242,237,0) 100%)",
          transition: "background 0.8s ease",
        }}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <div className="flex items-center gap-3 flex-wrap justify-center">
          <span style={{
            fontSize: isMobile ? 11 : 13, color: textSoft,
            letterSpacing: "0.12em", textTransform: "uppercase" as const,
            fontWeight: 400, transition: "color 0.8s ease",
          }}>
            Grille infinie
          </span>

          <div className="rounded-full" style={{ width: 4, height: 4, backgroundColor: textSoft, transition: "background-color 0.8s ease" }} />

          <span style={{
            fontSize: isMobile ? 11 : 13, color: textSoft,
            letterSpacing: "0.08em", fontVariantNumeric: "tabular-nums",
            fontWeight: 400, transition: "color 0.8s ease",
          }}>
            {isLilyAwake ? "✂" : "♥"} {heartCell.cx},{heartCell.cy}
          </span>

          <div className="rounded-full" style={{ width: 4, height: 4, backgroundColor: textSoft, transition: "background-color 0.8s ease" }} />

          <span style={{
            fontSize: isMobile ? 11 : 13,
            color: activeFam !== null
              ? `${FAMILIES[activeFam].color}90`
              : isLilyAwake ? `${LILY_PURPLE}70` : deployed ? `${HEART_RED}70` : textSoft,
            letterSpacing: "0.08em", fontWeight: deployed ? 500 : 400,
            transition: "color 0.8s ease",
          }}>
            {activeFam !== null
              ? `${FAMILIES[activeFam].symbol} ${FAMILIES[activeFam].title} · 8 facettes`
              : isLilyAwake ? "Lily active" : deployed ? "8 univers" : "1 carré"}
          </span>

          <div className="rounded-full" style={{ width: 4, height: 4, backgroundColor: textSoft, transition: "background-color 0.8s ease" }} />

          <span style={{
            fontSize: isMobile ? 11 : 13, color: textSoft,
            fontVariantNumeric: "tabular-nums", fontWeight: 400, transition: "color 0.8s ease",
          }}>
            {zoomPct}%
          </span>
        </div>
      </motion.div>

      {/* ═══ FACETTE PANEL ═══ */}
      <AnimatePresence>
        {openPanel && (
          <FacettePanel
            key={`panel-${openPanel.fam}-${openPanel.facette}`}
            famIdx={openPanel.fam}
            facetteIdx={openPanel.facette}
            famColor={FAMILIES[openPanel.fam].color}
            famSymbol={FAMILIES[openPanel.fam].symbol}
            famTitle={FAMILIES[openPanel.fam].title}
            facetteLabel={FAMILIES[openPanel.fam].facettes[openPanel.facette]}
            isDark={isDark}
            isMobile={isMobile}
            heartConfig={heartConfig}
            onUpdateHeart={handleUpdateHeart}
            onToggleTheme={() => setIsDark((d) => !d)}
            onRecenter={recenter}
            cellSize={cellSize}
            onClose={() => setOpenPanel(null)}
            onLilyMessage={setLilyMessage}
            onSelectTool={(tool: ActiveTool) => {
              setActiveTool(tool);
              setOpenPanel(null);
              setLilyMessage(
                tool.type === "draw" ? `Crayon actif — ${tool.color}`
                : tool.type === "eraser" ? "Gomme active"
                : tool.type === "pick-color" ? "Pipette active"
                : tool.type === "fill" ? "Remplissage actif"
                : null
              );
            }}
          />
        )}
      </AnimatePresence>

      {/* ═══ FLOATING TOOL BAR ═══ */}
      <AnimatePresence>
        {activeTool && activeTool.type !== "hand" && (
          <motion.div
            className="absolute z-40 flex items-center gap-1 rounded-2xl pointer-events-auto"
            style={{
              left: "50%",
              bottom: isMobile ? 110 : 116,
              transform: "translateX(-50%)",
              padding: "5px 8px",
              backgroundColor: isDark ? "rgba(26,26,26,0.92)" : "rgba(255,255,255,0.92)",
              backdropFilter: "blur(16px)",
              border: `1px solid ${isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)"}`,
              boxShadow: isDark
                ? "0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04)"
                : "0 8px 32px rgba(0,0,0,0.1)",
            }}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.25, type: "spring", stiffness: 300, damping: 25 }}
          >
            {/* Color swatch (only for draw) */}
            {activeTool.type === "draw" && (
              <div
                className="rounded-md flex-shrink-0"
                style={{
                  width: isMobile ? 28 : 24,
                  height: isMobile ? 28 : 24,
                  backgroundColor: activeTool.color,
                  boxShadow: `0 0 8px ${activeTool.color}40`,
                }}
              />
            )}

            {/* Separator */}
            {activeTool.type === "draw" && (
              <div style={{
                width: 1,
                height: 20,
                backgroundColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)",
                margin: "0 2px",
              }} />
            )}

            {/* Tool buttons */}
            {([
              { type: "draw" as ToolType, icon: Pencil, label: "Crayon" },
              { type: "eraser" as ToolType, icon: Eraser, label: "Gomme" },
              { type: "pick-color" as ToolType, icon: Pipette, label: "Pipette" },
            ] as const).map((t) => {
              const isActive = activeTool.type === t.type;
              const CREATION_BLUE = "#1D5DA5";
              return (
                <motion.button
                  key={t.type}
                  className="flex items-center justify-center cursor-pointer border-none rounded-lg"
                  style={{
                    width: isMobile ? 38 : 34,
                    height: isMobile ? 38 : 34,
                    backgroundColor: isActive
                      ? `${CREATION_BLUE}25`
                      : "rgba(0,0,0,0)",
                    color: isActive
                      ? CREATION_BLUE
                      : isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.4)",
                  }}
                  onClick={() => {
                    setActiveTool((prev) => prev ? { ...prev, type: t.type } : prev);
                    setLilyMessage(
                      t.type === "draw" ? `Crayon actif — ${activeTool.color}`
                      : t.type === "eraser" ? "Gomme active"
                      : "Pipette active"
                    );
                  }}
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.92 }}
                  title={t.label}
                >
                  <t.icon size={isMobile ? 17 : 15} strokeWidth={isActive ? 2.2 : 1.6} />
                </motion.button>
              );
            })}

            {/* Separator */}
            <div style={{
              width: 1,
              height: 20,
              backgroundColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)",
              margin: "0 2px",
            }} />

            {/* Hand (deactivate tool) */}
            <motion.button
              className="flex items-center justify-center cursor-pointer border-none rounded-lg"
              style={{
                width: isMobile ? 38 : 34,
                height: isMobile ? 38 : 34,
                backgroundColor: "rgba(0,0,0,0)",
                color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.4)",
              }}
              onClick={() => {
                setActiveTool(null);
                setLilyMessage(null);
              }}
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.92 }}
              title="Main (pan)"
            >
              <Hand size={isMobile ? 17 : 15} strokeWidth={1.6} />
            </motion.button>

            {/* Clear all button */}
            {Object.keys(gridPaints).length > 0 && (
              <>
                <div style={{
                  width: 1,
                  height: 20,
                  backgroundColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)",
                  margin: "0 2px",
                }} />
                <motion.button
                  className="flex items-center gap-1.5 cursor-pointer border-none rounded-lg px-2"
                  style={{
                    height: isMobile ? 38 : 34,
                    backgroundColor: "rgba(0,0,0,0)",
                    color: isDark ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.3)",
                    fontSize: 10,
                  }}
                  onClick={() => {
                    setGridPaints({});
                    setLilyMessage("Toile effacée ✨");
                  }}
                  whileHover={{ scale: 1.05, color: "#E3243B" }}
                  whileTap={{ scale: 0.95 }}
                  title="Tout effacer"
                >
                  <Eraser size={12} />
                  <span>Effacer</span>
                </motion.button>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}