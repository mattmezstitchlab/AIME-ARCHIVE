import { useState, useRef } from "react";
import { motion, AnimatePresence, useScroll, useTransform } from "motion/react";
import {
  ArrowLeft,
  Heart,
  Clock,
  Wrench,
  Globe,
  Fingerprint,
  Scissors,
  ChevronDown,
  ExternalLink,
  Eye,
  Music,
  Compass,
  Triangle,
  Square,
  Circle,
} from "lucide-react";

// ─── FIGMA ASSETS ───
import imgTimeheart from "figma:asset/a6b4877ddc7ec40650cf3a6685af5c39fad24014.png";
import imgInstrument from "figma:asset/ba890b9b7fad8547284a24c48f3ba7d4efd013ed.png";
import imgMondeAime from "figma:asset/2d0bb311a63323e4c242fbadace1afb69da02d91.png";
import imgSignature from "figma:asset/d824b14d516c02a3ec34f8b695702b87a4ffe82f.png";
import imgFingerprint from "figma:asset/1952e144328b49c8f1c9966f818c49c807d18b2e.png";
import imgPartition from "figma:asset/870ed16479e2bbd6328cb2817c4e9687df42cd7e.png";

// ══════════════════════════════════════════════════
// IMAGINE — L'ecosysteme AIME
// Le monde aime : inclusion, simplicite, resonance
// ══════════════════════════════════════════════════

const BG_DARK = "#0D0F14";

// ─── CONCEPT DATA ───
interface Concept {
  id: string;
  num: string;
  title: string;
  subtitle: string;
  description: string;
  longDesc: string;
  image: string;
  accent: string;
  accentLight: string;
  icon: typeof Heart;
  tags: string[];
  status: string;
}

const CONCEPTS: Concept[] = [
  {
    id: "timeheart",
    num: "01",
    title: "Timeheart",
    subtitle: "Interface temporelle",
    description:
      "Une interface temporelle ou le temps devient circulaire, vivant et sensible.",
    longDesc:
      "Le temps n'y est plus lineaire mais circulaire, vivant, sensible. Graines temporelles, cadran 24h, reconnaissance silencieuse et partitions visuelles permettent de vivre le temps comme une matiere relationnelle.",
    image: imgTimeheart,
    accent: "#4A7B9C",
    accentLight: "#4A7B9C15",
    icon: Clock,
    tags: ["Temps circulaire", "Graines temporelles", "Reconnaissance silencieuse"],
    status: "Recherche",
  },
  {
    id: "instrument",
    num: "02",
    title: "Instrument Builder",
    subtitle: "Moteur de coherence",
    description:
      "Un moteur universel de coherence sans code reliant intention et deploiement.",
    longDesc:
      "Il permet de concevoir des systemes complexes sans code, en reliant intention, structure et deploiement reel. Il constitue la colonne vertebrale technique et pedagogique d'IMAGINE, avec une logique transmissible et potentiellement brevetable.",
    image: imgInstrument,
    accent: "#7A8DA0",
    accentLight: "#7A8DA015",
    icon: Wrench,
    tags: ["Sans code", "Coherence", "Brevetable"],
    status: "Prototype",
  },
  {
    id: "monde-aime",
    num: "03",
    title: "Le Monde Aime",
    subtitle: "Ecosysteme global",
    description:
      "L'ecosysteme global reliant toutes les applications Aime dans une vision societale.",
    longDesc:
      "Le monde aime est l'ecosysteme global qui relie toutes les applications Aime. Il propose une vision societale fondee sur l'inclusion, la simplicite et la resonance humaine plutot que sur la performance.",
    image: imgMondeAime,
    accent: "#C8A06E",
    accentLight: "#C8A06E15",
    icon: Globe,
    tags: ["Inclusion", "Simplicite", "Resonance"],
    status: "Vision",
  },
  {
    id: "aime",
    num: "04",
    title: "Ai+me",
    subtitle: "Espace personnel augmente",
    description:
      "Un espace personnel augmente ou l'IA accompagne sans intrusion ni automatisme excessif.",
    longDesc:
      "L'intelligence artificielle y accompagne l'utilisateur dans la continuite de ses intentions, sans intrusion ni automatisme excessif. Avec Lily — l'IA compagne — qui aide a trier, classer et reclasser dans des categories au sein du Grand Monde.",
    image: imgPartition,
    accent: "#9263A6",
    accentLight: "#9263A615",
    icon: Scissors,
    tags: ["Lily", "IA compagne", "Intentions"],
    status: "En cours",
  },
  {
    id: "signature",
    num: "05",
    title: "Signature Vibratoire",
    subtitle: "Empreinte symbolique",
    description:
      "Une empreinte symbolique qui traduit l'essence d'une personne ou d'un projet.",
    longDesc:
      "Elle depasse l'identite visuelle classique pour devenir un outil de reconnaissance, d'accordage et de continuite. Elle peut prendre la forme de graphismes, de partitions, de QR d'intention ou de contrats symboliques.",
    image: imgFingerprint,
    accent: "#4ABBC8",
    accentLight: "#4ABBC815",
    icon: Fingerprint,
    tags: ["Accordage", "QR d'intention", "Continuite"],
    status: "Concept",
  },
];

// ─── FLOATING PARTICLE ───
function FloatingParticle({ delay, x, y }: { delay: number; x: number; y: number }) {
  return (
    <motion.div
      className="absolute rounded-full"
      style={{
        width: Math.random() * 3 + 1,
        height: Math.random() * 3 + 1,
        left: `${x}%`,
        top: `${y}%`,
        backgroundColor: "rgba(255,255,255,0.3)",
      }}
      animate={{
        y: [-10, 10, -10],
        opacity: [0.1, 0.5, 0.1],
      }}
      transition={{
        duration: 4 + Math.random() * 4,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    />
  );
}

interface ImagineLandingProps {
  onBack?: () => void;
  onNavigate?: (screen: string) => void;
}

export function ImagineLanding({ onBack, onNavigate }: ImagineLandingProps) {
  const [expandedConcept, setExpandedConcept] = useState<string | null>(null);
  const [isMobile] = useState(() => window.innerWidth < 640);
  const [particles] = useState(() =>
    Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 5,
    }))
  );
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  const heroOpacity = useTransform(scrollYProgress, [0, 0.08], [1, 0]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-y-auto overflow-x-hidden"
      style={{ backgroundColor: BG_DARK, scrollBehavior: "smooth" }}
    >
      {/* ═══════════ HERO ═══════════ */}
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
        {/* Background image */}
        <motion.div className="absolute inset-0 z-0" style={{ opacity: heroOpacity }}>
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${imgMondeAime})`,
              backgroundSize: "cover",
              backgroundPosition: "center 40%",
              filter: "brightness(0.4) saturate(0.7)",
            }}
          />
          {/* Particles */}
          {particles.map((p) => (
            <FloatingParticle key={p.id} x={p.x} y={p.y} delay={p.delay} />
          ))}
          {/* Gradient */}
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(180deg, rgba(13,15,20,0.3) 0%, rgba(13,15,20,0) 30%, rgba(13,15,20,0.4) 70%, ${BG_DARK} 100%)`,
            }}
          />
        </motion.div>

        {/* Back button */}
        {onBack && (
          <motion.button
            className="absolute top-4 left-4 z-20 flex items-center gap-2 border-none cursor-pointer rounded-lg px-3 py-1.5"
            style={{
              backgroundColor: "rgba(255,255,255,0.08)",
              color: "rgba(255,255,255,0.6)",
              fontSize: 11,
              backdropFilter: "blur(10px)",
            }}
            onClick={onBack}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            whileHover={{ backgroundColor: "rgba(255,255,255,0.12)" }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft size={14} />
            Retour
          </motion.button>
        )}

        {/* Hero content */}
        <div className="relative z-10 flex flex-col items-center text-center px-6">
          {/* Logo shapes */}
          <motion.div
            className="flex items-center gap-3 mb-8"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <motion.div
              animate={{ rotate: [0, 60, 0] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Triangle size={10} color="rgba(255,255,255,0.3)" strokeWidth={1} />
            </motion.div>
            <motion.div
              animate={{ rotate: [0, -45, 0] }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            >
              <Square size={10} color="rgba(255,255,255,0.3)" strokeWidth={1} />
            </motion.div>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <Circle size={10} color="rgba(255,255,255,0.3)" strokeWidth={1} />
            </motion.div>
          </motion.div>

          {/* Pre-title */}
          <motion.p
            style={{
              fontSize: 9,
              color: "rgba(255,255,255,0.3)",
              letterSpacing: "0.35em",
              fontWeight: 400,
              marginBottom: 20,
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
          >
            L'ECOSYSTEME
          </motion.p>

          {/* Title */}
          <motion.h1
            style={{
              fontSize: isMobile ? "clamp(42px, 14vw, 60px)" : "clamp(56px, 8vw, 88px)",
              fontWeight: 200,
              color: "#fff",
              letterSpacing: "-0.03em",
              lineHeight: 1,
              marginBottom: 20,
            }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 1.2 }}
          >
            Le Monde{" "}
            <span
              style={{
                fontWeight: 500,
                background: "linear-gradient(135deg, #C8A06E, #E8177F, #9263A6)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Aime
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            style={{
              fontSize: isMobile ? 13 : 16,
              color: "rgba(255,255,255,0.45)",
              fontWeight: 300,
              maxWidth: 500,
              lineHeight: 1.8,
              marginBottom: 40,
            }}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
          >
            Cinq instruments. Une vision.
            <br />
            <span style={{ color: "rgba(255,255,255,0.25)" }}>
              Inclusion, simplicite, resonance humaine.
            </span>
          </motion.p>

          {/* 5 concept dots */}
          <motion.div
            className="flex items-center gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
          >
            {CONCEPTS.map((c, i) => (
              <motion.div
                key={c.id}
                className="flex flex-col items-center gap-2 cursor-pointer"
                whileHover={{ scale: 1.1 }}
                onClick={() => {
                  const el = document.getElementById(`concept-${c.id}`);
                  el?.scrollIntoView({ behavior: "smooth" });
                }}
              >
                <motion.div
                  className="rounded-full"
                  style={{
                    width: 8,
                    height: 8,
                    backgroundColor: c.accent,
                    opacity: 0.6,
                  }}
                  animate={{ opacity: [0.3, 0.8, 0.3] }}
                  transition={{ duration: 3, delay: i * 0.5, repeat: Infinity }}
                />
                <span
                  style={{
                    fontSize: 7,
                    color: "rgba(255,255,255,0.2)",
                    letterSpacing: "0.1em",
                    whiteSpace: "nowrap",
                  }}
                >
                  {c.num}
                </span>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.3 }}
          transition={{ delay: 2.2 }}
        >
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <ChevronDown size={16} color="rgba(255,255,255,0.4)" />
          </motion.div>
        </motion.div>
      </section>

      {/* ═══════════ MANIFESTO ═══════════ */}
      <section className="py-32 px-6 flex flex-col items-center justify-center">
        <motion.p
          className="text-center"
          style={{
            fontSize: isMobile ? 18 : "clamp(20px, 3vw, 30px)",
            fontWeight: 300,
            color: "rgba(255,255,255,0.7)",
            lineHeight: 2,
            maxWidth: 560,
          }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 1 }}
        >
          Pas un produit.
          <br />
          Pas une plateforme.
          <br />
          <span style={{ fontWeight: 500, color: "#C8A06E" }}>Un ecosysteme vivant</span>
          <br />
          <span style={{ color: "rgba(255,255,255,0.3)" }}>
            ou chaque instrument amplifie les autres.
          </span>
        </motion.p>
      </section>

      {/* ═══════════ 5 CONCEPTS ═══════════ */}
      {CONCEPTS.map((concept, idx) => (
        <ConceptSection
          key={concept.id}
          concept={concept}
          index={idx}
          isMobile={isMobile}
          isExpanded={expandedConcept === concept.id}
          onToggle={() =>
            setExpandedConcept(expandedConcept === concept.id ? null : concept.id)
          }
          onNavigate={onNavigate}
        />
      ))}

      {/* ═══════════ INTERCONNECTION ═══════════ */}
      <section className="py-32 px-6">
        <motion.div
          className="mx-auto flex flex-col items-center"
          style={{ maxWidth: 700 }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <p
            style={{
              fontSize: 9,
              color: "rgba(255,255,255,0.2)",
              letterSpacing: "0.3em",
              marginBottom: 24,
            }}
          >
            INTERCONNEXION
          </p>

          {/* Ecosystem visual */}
          <div
            className="relative flex items-center justify-center mb-12"
            style={{ width: isMobile ? 280 : 400, height: isMobile ? 280 : 400 }}
          >
            {/* Central glow */}
            <motion.div
              className="absolute rounded-full"
              style={{
                width: 60,
                height: 60,
                background:
                  "radial-gradient(circle, rgba(200,160,110,0.3) 0%, rgba(200,160,110,0) 70%)",
              }}
              animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.8, 0.5] }}
              transition={{ duration: 4, repeat: Infinity }}
            />
            <Heart size={16} color="#C8A06E" fill="#C8A06E" style={{ opacity: 0.6 }} />

            {/* Orbiting concepts */}
            {CONCEPTS.map((c, i) => {
              const angle = (i * 72 - 90) * (Math.PI / 180);
              const r = isMobile ? 100 : 150;
              const cx = Math.cos(angle) * r;
              const cy = Math.sin(angle) * r;
              return (
                <motion.div
                  key={c.id}
                  className="absolute flex flex-col items-center gap-2"
                  style={{
                    left: `calc(50% + ${cx}px - 28px)`,
                    top: `calc(50% + ${cy}px - 28px)`,
                  }}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + i * 0.12, type: "spring" }}
                >
                  <motion.div
                    className="flex items-center justify-center rounded-full"
                    style={{
                      width: 56,
                      height: 56,
                      backgroundColor: `${c.accent}15`,
                      border: `1px solid ${c.accent}25`,
                    }}
                    animate={{ boxShadow: [`0 0 0px ${c.accent}00`, `0 0 20px ${c.accent}20`, `0 0 0px ${c.accent}00`] }}
                    transition={{ duration: 4, delay: i * 0.6, repeat: Infinity }}
                  >
                    <c.icon size={18} color={c.accent} strokeWidth={1.5} />
                  </motion.div>
                  <span
                    style={{
                      fontSize: 8,
                      color: "rgba(255,255,255,0.3)",
                      letterSpacing: "0.08em",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {c.title}
                  </span>
                </motion.div>
              );
            })}

            {/* Connection lines */}
            <svg
              className="absolute inset-0"
              style={{ width: "100%", height: "100%", overflow: "visible" }}
            >
              {CONCEPTS.map((c, i) => {
                const angle = (i * 72 - 90) * (Math.PI / 180);
                const r = isMobile ? 100 : 150;
                const cx = Math.cos(angle) * r;
                const cy = Math.sin(angle) * r;
                return (
                  <motion.line
                    key={c.id}
                    x1="50%"
                    y1="50%"
                    x2={`calc(50% + ${cx}px)`}
                    y2={`calc(50% + ${cy}px)`}
                    stroke={c.accent}
                    strokeWidth={0.5}
                    strokeOpacity={0.15}
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.5 + i * 0.1, duration: 0.8 }}
                  />
                );
              })}
            </svg>
          </div>

          <motion.p
            className="text-center"
            style={{
              fontSize: isMobile ? 14 : 17,
              fontWeight: 300,
              color: "rgba(255,255,255,0.5)",
              lineHeight: 1.8,
              maxWidth: 420,
            }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
          >
            Chaque instrument partage le meme ADN combinatoire.
            <br />
            <span style={{ color: "rgba(255,255,255,0.25)" }}>
              Recursif. 8×8. Infini. Transmissible.
            </span>
          </motion.p>
        </motion.div>
      </section>

      {/* ═══════════ SIGNATURE GALLERY ═══════════ */}
      <section className="py-24 px-6">
        <motion.p
          className="text-center mb-4"
          style={{
            fontSize: 9,
            color: "rgba(255,255,255,0.2)",
            letterSpacing: "0.3em",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          PARTITIONS & SIGNATURES
        </motion.p>
        <motion.h2
          className="text-center mb-12"
          style={{
            fontSize: isMobile ? 20 : 26,
            fontWeight: 200,
            color: "rgba(255,255,255,0.7)",
          }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Quand le temps devient <span style={{ fontWeight: 400, color: "#4ABBC8" }}>partition</span>
        </motion.h2>

        <div
          className="mx-auto grid gap-4"
          style={{
            maxWidth: 800,
            gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr",
          }}
        >
          {[
            { img: imgPartition, label: "(temps & silence)", desc: "Partition temporelle — les 5 dimensions comme portee musicale" },
            { img: imgSignature, label: "Ondes & cristal", desc: "Signature vibratoire — formes ondulantes et structures cristallines" },
          ].map((item, i) => (
            <motion.div
              key={item.label}
              className="rounded-2xl overflow-hidden relative group"
              style={{ border: "1px solid rgba(255,255,255,0.05)" }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
            >
              <img
                src={item.img}
                alt={item.label}
                className="w-full"
                style={{
                  height: isMobile ? 180 : 220,
                  objectFit: "cover",
                  filter: "brightness(0.85)",
                }}
              />
              <div
                className="absolute inset-0 flex flex-col justify-end p-5"
                style={{
                  background:
                    "linear-gradient(0deg, rgba(13,15,20,0.8) 0%, rgba(13,15,20,0) 60%)",
                }}
              >
                <span
                  style={{
                    fontSize: 13,
                    fontWeight: 400,
                    color: "rgba(255,255,255,0.8)",
                    marginBottom: 4,
                  }}
                >
                  {item.label}
                </span>
                <span
                  style={{
                    fontSize: 10,
                    color: "rgba(255,255,255,0.35)",
                    fontWeight: 300,
                  }}
                >
                  {item.desc}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ═══════════ LILY / AI+ME ═══════════ */}
      <section className="py-24 px-6">
        <motion.div
          className="mx-auto rounded-3xl p-8 md:p-12 relative overflow-hidden"
          style={{
            maxWidth: 700,
            background: "linear-gradient(135deg, #9263A608, #E8177F05)",
            border: "1px solid rgba(146,99,166,0.1)",
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          {/* Lily icon */}
          <motion.div
            className="flex items-center justify-center rounded-2xl mb-6 mx-auto"
            style={{
              width: 56,
              height: 56,
              backgroundColor: "rgba(146,99,166,0.1)",
            }}
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 6, repeat: Infinity }}
          >
            <Scissors size={24} color="#9263A6" strokeWidth={1.5} />
          </motion.div>

          <h3
            className="text-center mb-3"
            style={{
              fontSize: isMobile ? 18 : 22,
              fontWeight: 300,
              color: "rgba(255,255,255,0.8)",
            }}
          >
            Lily, <span style={{ fontWeight: 500, color: "#9263A6" }}>l'IA compagne</span>
          </h3>

          <p
            className="text-center mb-6"
            style={{
              fontSize: 12,
              color: "rgba(255,255,255,0.35)",
              fontWeight: 300,
              lineHeight: 1.8,
              maxWidth: 440,
              margin: "0 auto",
            }}
          >
            Lily accompagne dans chaque instrument. Elle ne decide pas — elle eclaire.
            Tri photo, classement par categories, assistance vocale Nova,
            navigation dans le Grand Monde. Toujours presente, jamais intrusive.
          </p>

          <div className="flex items-center justify-center gap-4 flex-wrap">
            {[
              { icon: Triangle, label: "Tri" },
              { icon: Square, label: "Classe" },
              { icon: Circle, label: "Relie" },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                className="flex items-center gap-2 rounded-full px-4 py-2"
                style={{
                  backgroundColor: "rgba(146,99,166,0.08)",
                  border: "1px solid rgba(146,99,166,0.1)",
                }}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 + i * 0.1 }}
              >
                <item.icon size={12} color="#9263A6" strokeWidth={1.5} />
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", fontWeight: 400 }}>
                  {item.label}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ═══════════ VISION ═══════════ */}
      <section className="py-32 px-6 flex flex-col items-center">
        <motion.div
          className="text-center"
          style={{ maxWidth: 560 }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <p
            style={{
              fontSize: 9,
              color: "rgba(255,255,255,0.2)",
              letterSpacing: "0.3em",
              marginBottom: 20,
            }}
          >
            VISION SOCIETALE
          </p>

          <h2
            style={{
              fontSize: isMobile ? 22 : 30,
              fontWeight: 200,
              color: "rgba(255,255,255,0.75)",
              lineHeight: 1.6,
              marginBottom: 20,
            }}
          >
            Concevoir des outils qui{" "}
            <span
              style={{
                fontWeight: 500,
                background: "linear-gradient(90deg, #C8A06E, #E8177F)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              amplifient l'humain
            </span>
            <br />
            plutot que le remplacer.
          </h2>

          <p
            style={{
              fontSize: 12,
              color: "rgba(255,255,255,0.25)",
              lineHeight: 1.8,
              fontWeight: 300,
            }}
          >
            Pas de matching algorithmique. Pas de performance. Pas de surveillance.
            <br />
            Juste la resonance entre les presences humaines.
          </p>
        </motion.div>

        {/* Pillars */}
        <motion.div
          className="mt-16 grid gap-6"
          style={{
            maxWidth: 700,
            gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          {[
            {
              icon: Eye,
              title: "Inclusion radicale",
              desc: "Chaque outil est concu pour tous, sans exception ni condition.",
              color: "#C8A06E",
            },
            {
              icon: Compass,
              title: "Simplicite profonde",
              desc: "La complexite est absorbee par le systeme, pas imposee a l'utilisateur.",
              color: "#E8177F",
            },
            {
              icon: Music,
              title: "Resonance vivante",
              desc: "Les connexions emergent naturellement, sans algorithme ni matching.",
              color: "#9263A6",
            },
          ].map((pillar, i) => (
            <motion.div
              key={pillar.title}
              className="flex flex-col items-center text-center p-6 rounded-2xl"
              style={{
                backgroundColor: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.04)",
              }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 + i * 0.12 }}
            >
              <div
                className="flex items-center justify-center rounded-xl mb-4"
                style={{
                  width: 44,
                  height: 44,
                  backgroundColor: `${pillar.color}10`,
                }}
              >
                <pillar.icon size={20} color={pillar.color} strokeWidth={1.5} />
              </div>
              <h4
                style={{
                  fontSize: 13,
                  fontWeight: 500,
                  color: "rgba(255,255,255,0.7)",
                  marginBottom: 6,
                }}
              >
                {pillar.title}
              </h4>
              <p
                style={{
                  fontSize: 11,
                  color: "rgba(255,255,255,0.25)",
                  lineHeight: 1.7,
                  fontWeight: 300,
                }}
              >
                {pillar.desc}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* ═══════════ CTA ═══════════ */}
      <section className="py-24 px-6 flex flex-col items-center gap-8">
        <motion.div
          className="flex items-center gap-3"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          {CONCEPTS.map((c) => (
            <motion.div
              key={c.id}
              className="rounded-full"
              style={{ width: 5, height: 5, backgroundColor: c.accent }}
              animate={{ opacity: [0.2, 0.7, 0.2] }}
              transition={{ duration: 4, delay: CONCEPTS.indexOf(c) * 0.6, repeat: Infinity }}
            />
          ))}
        </motion.div>

        <motion.h2
          className="text-center"
          style={{
            fontSize: isMobile ? 24 : 34,
            fontWeight: 200,
            color: "rgba(255,255,255,0.7)",
            lineHeight: 1.4,
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Le monde{" "}
          <span
            style={{
              fontWeight: 500,
              background: "linear-gradient(135deg, #C8A06E, #E8177F)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            aime
          </span>
          .
        </motion.h2>

        <motion.p
          className="text-center"
          style={{
            fontSize: 11,
            color: "rgba(255,255,255,0.2)",
            fontWeight: 300,
            maxWidth: 300,
            lineHeight: 1.8,
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          5 instruments &middot; 1 vision &middot; ADN recursif 8×8
          <br />
          Inclusion &middot; Simplicite &middot; Resonance
        </motion.p>

        <motion.p
          style={{
            fontSize: 7,
            color: "rgba(255,255,255,0.08)",
            letterSpacing: "0.2em",
            marginTop: 32,
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          IMAGINE &middot; ECOSYSTEME AIME &middot; CONCEPT ORIGINAL
        </motion.p>

        <div className="h-16" />
      </section>
    </div>
  );
}

// ═══════════════════════════════════════
// CONCEPT SECTION — Full-width immersive
// ═══════════════════════════════════════
function ConceptSection({
  concept,
  index,
  isMobile,
  isExpanded,
  onToggle,
  onNavigate,
}: {
  concept: Concept;
  index: number;
  isMobile: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  onNavigate?: (screen: string) => void;
}) {
  const isEven = index % 2 === 0;

  return (
    <section
      id={`concept-${concept.id}`}
      className="py-20 px-6"
      style={{
        backgroundColor: isEven ? "rgba(255,255,255,0.01)" : "rgba(0,0,0,0)",
      }}
    >
      <div
        className="mx-auto"
        style={{
          maxWidth: 900,
          display: "grid",
          gridTemplateColumns: isMobile ? "1fr" : isEven ? "1fr 1.1fr" : "1.1fr 1fr",
          gap: isMobile ? 24 : 48,
          alignItems: "center",
        }}
      >
        {/* Image */}
        <motion.div
          className="rounded-2xl overflow-hidden relative"
          style={{
            order: isMobile ? 0 : isEven ? 0 : 1,
            border: `1px solid ${concept.accent}15`,
          }}
          initial={{ opacity: 0, x: isEven ? -30 : 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <img
            src={concept.image}
            alt={concept.title}
            className="w-full"
            style={{
              height: isMobile ? 200 : 280,
              objectFit: "cover",
              filter: "brightness(0.85) saturate(0.9)",
            }}
          />
          {/* Overlay */}
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(135deg, ${concept.accent}15, rgba(0,0,0,0))`,
            }}
          />
          {/* Status badge */}
          <div
            className="absolute top-4 left-4 rounded-full px-3 py-1"
            style={{
              backgroundColor: "rgba(0,0,0,0.5)",
              backdropFilter: "blur(10px)",
              border: `1px solid ${concept.accent}30`,
            }}
          >
            <span style={{ fontSize: 8, color: concept.accent, fontWeight: 500, letterSpacing: "0.1em" }}>
              {concept.status.toUpperCase()}
            </span>
          </div>
        </motion.div>

        {/* Content */}
        <motion.div
          className="flex flex-col"
          style={{ order: isMobile ? 1 : isEven ? 1 : 0 }}
          initial={{ opacity: 0, x: isEven ? 30 : -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.15 }}
        >
          {/* Number */}
          <span
            style={{
              fontSize: 36,
              fontWeight: 200,
              color: concept.accent,
              opacity: 0.25,
              lineHeight: 1,
              marginBottom: 8,
            }}
          >
            {concept.num}
          </span>

          {/* Title */}
          <h2
            style={{
              fontSize: isMobile ? 24 : 30,
              fontWeight: 300,
              color: "rgba(255,255,255,0.85)",
              lineHeight: 1.2,
              marginBottom: 4,
            }}
          >
            {concept.title}
          </h2>

          <p
            style={{
              fontSize: 11,
              color: concept.accent,
              fontWeight: 400,
              letterSpacing: "0.05em",
              marginBottom: 16,
            }}
          >
            {concept.subtitle}
          </p>

          {/* Description */}
          <p
            style={{
              fontSize: 13,
              color: "rgba(255,255,255,0.5)",
              fontWeight: 300,
              lineHeight: 1.8,
              marginBottom: 16,
            }}
          >
            {concept.description}
          </p>

          {/* Expand button */}
          <motion.button
            className="flex items-center gap-2 border-none cursor-pointer self-start mb-4"
            style={{
              backgroundColor: "rgba(0,0,0,0)",
              color: concept.accent,
              fontSize: 10,
              fontWeight: 400,
              padding: 0,
            }}
            onClick={onToggle}
            whileHover={{ x: 3 }}
          >
            {isExpanded ? "Reduire" : "En savoir plus"}
            <motion.span animate={{ rotate: isExpanded ? 180 : 0 }} transition={{ duration: 0.3 }}>
              <ChevronDown size={12} />
            </motion.span>
          </motion.button>

          {/* Expanded content */}
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.4 }}
                className="overflow-hidden"
              >
                <p
                  style={{
                    fontSize: 12,
                    color: "rgba(255,255,255,0.35)",
                    fontWeight: 300,
                    lineHeight: 1.8,
                    marginBottom: 16,
                    paddingTop: 8,
                    borderTop: "1px solid rgba(255,255,255,0.05)",
                  }}
                >
                  {concept.longDesc}
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {concept.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full px-3 py-1"
                style={{
                  fontSize: 9,
                  backgroundColor: concept.accentLight,
                  color: concept.accent,
                  fontWeight: 400,
                  border: `1px solid ${concept.accent}15`,
                }}
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Navigate button for Timeheart */}
          {concept.id === "timeheart" && onNavigate && (
            <motion.button
              className="flex items-center gap-2 mt-5 border-none cursor-pointer self-start rounded-lg px-4 py-2"
              style={{
                backgroundColor: `${concept.accent}12`,
                color: concept.accent,
                fontSize: 10,
                fontWeight: 500,
                letterSpacing: "0.05em",
                border: `1px solid ${concept.accent}20`,
              }}
              onClick={() => onNavigate("timeheart")}
              whileHover={{ backgroundColor: `${concept.accent}20` }}
              whileTap={{ scale: 0.97 }}
            >
              <ExternalLink size={11} />
              Ouvrir Timeheart
            </motion.button>
          )}

          {/* Navigate button for Instrument Builder */}
          {concept.id === "instrument" && onNavigate && (
            <motion.button
              className="flex items-center gap-2 mt-5 border-none cursor-pointer self-start rounded-lg px-4 py-2"
              style={{
                backgroundColor: `${concept.accent}12`,
                color: concept.accent,
                fontSize: 10,
                fontWeight: 500,
                letterSpacing: "0.05em",
                border: `1px solid ${concept.accent}20`,
              }}
              onClick={() => onNavigate("instrument-builder")}
              whileHover={{ backgroundColor: `${concept.accent}20` }}
              whileTap={{ scale: 0.97 }}
            >
              <ExternalLink size={11} />
              Ouvrir l'Instrument
            </motion.button>
          )}
        </motion.div>
      </div>
    </section>
  );
}