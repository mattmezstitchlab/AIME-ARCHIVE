import { motion } from "motion/react";

// ═══════════════════════════════════════════
// LILY FACE — Kawaii character born from the heart
// Square with two eyes + smile
// ═══════════════════════════════════════════

interface LilyFaceProps {
  size: number;
  colorHex?: string;
  speaking?: boolean;
  message?: string;
  isDark?: boolean;
}

export function LilyFace({ size, colorHex = "#E3243B", speaking = false }: LilyFaceProps) {
  const eyeSize = size * 0.13;
  const eyeY = size * 0.36;
  const eyeSpacing = size * 0.22;
  const mouthY = size * 0.58;
  const mouthWidth = size * 0.18;
  const shineSize = eyeSize * 0.35;
  const c = colorHex;

  return (
    <motion.div
      className="relative select-none"
      style={{ width: size, height: size }}
    >
      {/* Red body */}
      <motion.div
        className="absolute inset-0 rounded-[3px]"
        style={{
          backgroundColor: c,
          boxShadow: `0 0 18px 4px ${c}50, 0 0 36px 8px ${c}25, inset 0 1px 2px rgba(255,255,255,0.15)`,
        }}
        animate={{
          boxShadow: speaking
            ? [
                `0 0 18px 4px ${c}50, 0 0 36px 8px ${c}25`,
                `0 0 28px 8px ${c}60, 0 0 48px 12px ${c}35`,
                `0 0 18px 4px ${c}50, 0 0 36px 8px ${c}25`,
              ]
            : `0 0 18px 4px ${c}50, 0 0 36px 8px ${c}25`,
        }}
        transition={speaking ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
      />

      {/* Left eye */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: eyeSize,
          height: eyeSize * 1.15,
          backgroundColor: "#fff",
          left: size / 2 - eyeSpacing - eyeSize / 2,
          top: eyeY,
          boxShadow: "0 1px 3px rgba(0,0,0,0.15)",
        }}
        animate={{ scaleY: [1, 1, 0.1, 1, 1] }}
        transition={{
          duration: 4,
          repeat: Infinity,
          times: [0, 0.45, 0.48, 0.51, 1],
          ease: "easeInOut",
        }}
      >
        <div
          className="absolute rounded-full"
          style={{
            width: eyeSize * 0.55,
            height: eyeSize * 0.55,
            backgroundColor: "#2D1B3D",
            left: "50%",
            top: "50%",
            transform: "translate(-50%, -45%)",
          }}
        />
        <div
          className="absolute rounded-full"
          style={{
            width: shineSize,
            height: shineSize,
            backgroundColor: "#fff",
            left: "60%",
            top: "25%",
          }}
        />
      </motion.div>

      {/* Right eye */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: eyeSize,
          height: eyeSize * 1.15,
          backgroundColor: "#fff",
          left: size / 2 + eyeSpacing - eyeSize / 2,
          top: eyeY,
          boxShadow: "0 1px 3px rgba(0,0,0,0.15)",
        }}
        animate={{ scaleY: [1, 1, 0.1, 1, 1] }}
        transition={{
          duration: 4,
          repeat: Infinity,
          times: [0, 0.45, 0.48, 0.51, 1],
          ease: "easeInOut",
        }}
      >
        <div
          className="absolute rounded-full"
          style={{
            width: eyeSize * 0.55,
            height: eyeSize * 0.55,
            backgroundColor: "#2D1B3D",
            left: "50%",
            top: "50%",
            transform: "translate(-50%, -45%)",
          }}
        />
        <div
          className="absolute rounded-full"
          style={{
            width: shineSize,
            height: shineSize,
            backgroundColor: "#fff",
            left: "60%",
            top: "25%",
          }}
        />
      </motion.div>

      {/* Mouth = heart */}
      <motion.div
        className="absolute flex items-center justify-center"
        style={{
          left: size / 2 - mouthWidth * 0.7,
          top: mouthY - mouthWidth * 0.15,
          width: mouthWidth * 1.4,
          height: mouthWidth * 0.9,
          fontSize: mouthWidth * 1.1,
          lineHeight: 1,
          color: "#fff",
          textShadow: "0 1px 2px rgba(0,0,0,0.15)",
        }}
        animate={
          speaking
            ? { scale: [1, 1.2, 0.9, 1.15, 1] }
            : { scale: [1, 1.08, 1] }
        }
        transition={
          speaking
            ? { duration: 0.6, repeat: Infinity, ease: "easeInOut" }
            : { duration: 2.5, repeat: Infinity, ease: "easeInOut" }
        }
      >
        ♥
      </motion.div>
    </motion.div>
  );
}
