import { motion, AnimatePresence } from "motion/react";
import { Settings, X } from "lucide-react";
import { useResponsive } from "./useResponsive";
import type { AccessibilityMode } from "./game-data";

interface SettingsPanelProps {
  mode: AccessibilityMode;
  onModeChange: (mode: AccessibilityMode) => void;
  open: boolean;
  onToggle: () => void;
}

const MODE_OPTIONS: { key: AccessibilityMode; label: string; emoji: string; desc: string }[] = [
  { key: "default", label: "Standard", emoji: "◉", desc: "Expérience classique" },
  { key: "child", label: "Enfant", emoji: "◎", desc: "Contrastes forts, symboles simples" },
  { key: "senior", label: "Senior", emoji: "◈", desc: "Flèches XXL, police large, zoom" },
  { key: "accessibility", label: "Accessibilité", emoji: "◇", desc: "Clavier seul, contraste élevé" },
];

export function SettingsPanel({ mode, onModeChange, open, onToggle }: SettingsPanelProps) {
  const { isMobile } = useResponsive();
  const btnSize = isMobile ? 32 : 36;

  return (
    <>
      {/* Toggle */}
      <motion.button
        className="fixed z-50 flex items-center justify-center rounded-full cursor-pointer border-none"
        style={{
          top: isMobile ? 10 : 16,
          right: isMobile ? 10 : 16,
          width: btnSize,
          height: btnSize,
          backgroundColor: "rgba(255,255,255,0.75)",
          backdropFilter: "blur(12px)",
          boxShadow: "0 1px 8px rgba(0,0,0,0.04)",
          color: "#aaa",
        }}
        onClick={onToggle}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        aria-label="Paramètres"
      >
        {open ? <X size={isMobile ? 13 : 15} /> : <Settings size={isMobile ? 13 : 15} />}
      </motion.button>

      {/* Panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed z-50 rounded-2xl p-4 flex flex-col gap-2"
            style={{
              top: isMobile ? 48 : 56,
              right: isMobile ? 10 : 16,
              left: isMobile ? 10 : "auto",
              backgroundColor: "rgba(255,255,255,0.94)",
              backdropFilter: "blur(24px)",
              boxShadow: "0 8px 40px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.02)",
              minWidth: isMobile ? undefined : 220,
            }}
            initial={{ opacity: 0, y: -8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.98 }}
            transition={{ duration: 0.2 }}
          >
            <p style={{ fontSize: 9, letterSpacing: "0.18em", color: "#bbb", textTransform: "uppercase", marginBottom: 2 }}>
              Mode
            </p>

            {MODE_OPTIONS.map((m) => {
              const isActive = mode === m.key;
              return (
                <motion.button
                  key={m.key}
                  className="flex items-center gap-2.5 px-3 py-2 rounded-xl cursor-pointer border-none text-left w-full"
                  style={{
                    backgroundColor: isActive ? "rgba(0,0,0,0.05)" : "rgba(0,0,0,0)",
                    color: isActive ? "#1a1a1a" : "#999",
                  }}
                  onClick={() => onModeChange(m.key)}
                  whileHover={{ backgroundColor: "rgba(0,0,0,0.03)" }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span style={{ fontSize: 13, opacity: isActive ? 1 : 0.5 }}>{m.emoji}</span>
                  <div className="flex flex-col">
                    <span style={{ fontSize: isMobile ? 11 : 12, fontWeight: isActive ? 500 : 400 }}>{m.label}</span>
                    <span style={{ fontSize: isMobile ? 8 : 9, color: "#ccc", fontWeight: 300 }}>{m.desc}</span>
                  </div>
                </motion.button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
