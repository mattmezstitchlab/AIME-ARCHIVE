import { motion, AnimatePresence } from "motion/react";
import { X, MessageCircle, CalendarDays, Image, Send, Plus, Camera } from "lucide-react";
import { useResponsive } from "./useResponsive";
import { BG_IVORY, MOCK_PLAYERS } from "./game-data";

// ─── SHARED PANEL WRAPPER ───
function PanelWrapper({
  visible,
  onClose,
  title,
  icon,
  iconColor,
  children,
}: {
  visible: boolean;
  onClose: () => void;
  title: string;
  icon: React.ReactNode;
  iconColor: string;
  children: React.ReactNode;
}) {
  const { isMobile } = useResponsive();

  return (
    <AnimatePresence>
      {visible && (
        <>
          <motion.div
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(250,248,245,0.4)", backdropFilter: "blur(4px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed z-50 flex flex-col rounded-2xl overflow-hidden"
            style={{
              bottom: isMobile ? 10 : 40,
              left: isMobile ? 10 : 40,
              right: isMobile ? 10 : "auto",
              width: isMobile ? "calc(100vw - 20px)" : 360,
              height: isMobile ? "calc(100vh - 180px)" : 480,
              maxHeight: "70vh",
              backgroundColor: "rgba(255,255,255,0.97)",
              backdropFilter: "blur(24px)",
              boxShadow: "0 16px 64px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.02)",
            }}
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.25 }}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: "1px solid rgba(0,0,0,0.04)" }}
            >
              <div className="flex items-center gap-2">
                <div
                  className="flex items-center justify-center rounded-lg"
                  style={{ width: 28, height: 28, backgroundColor: `${iconColor}20` }}
                >
                  {icon}
                </div>
                <span style={{ fontSize: 12, fontWeight: 500, color: "#1a1a1a" }}>{title}</span>
              </div>
              <motion.button
                className="flex items-center justify-center rounded-full border-none cursor-pointer"
                style={{ width: 28, height: 28, backgroundColor: "rgba(0,0,0,0.04)", color: "#aaa" }}
                onClick={onClose}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X size={13} />
              </motion.button>
            </div>
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── MESSAGING PANEL ───
export function MessagingPanel({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const conversations = MOCK_PLAYERS.slice(0, 6);

  return (
    <PanelWrapper
      visible={visible}
      onClose={onClose}
      title="Messages"
      icon={<MessageCircle size={14} color="#4685B7" strokeWidth={1.5} />}
      iconColor="#4685B7"
    >
      <div className="flex-1 overflow-y-auto">
        {conversations.map((p) => (
          <motion.div
            key={p.id}
            className="flex items-center gap-3 px-4 py-3 cursor-pointer"
            style={{ borderBottom: "1px solid rgba(0,0,0,0.02)" }}
            whileHover={{ backgroundColor: "rgba(0,0,0,0.02)" }}
          >
            <div
              className="rounded-[3px] flex items-center justify-center flex-shrink-0"
              style={{
                width: 36, height: 36, backgroundColor: p.colorHex,
                fontSize: 14, color: "#fff",
              }}
            >
              {p.symbol}
            </div>
            <div className="flex flex-col flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span style={{ fontSize: 12, fontWeight: 500, color: "#1a1a1a" }}>{p.pseudo}</span>
                <span style={{ fontSize: 8, color: "#ddd" }}>
                  {Math.floor(Math.random() * 60)}m
                </span>
              </div>
              <span style={{ fontSize: 10, color: "#bbb", fontWeight: 300 }} className="truncate">
                {p.intention || p.city || "..."}
              </span>
            </div>
            {Math.random() > 0.5 && (
              <div
                className="rounded-full flex-shrink-0"
                style={{ width: 7, height: 7, backgroundColor: "#4685B7" }}
              />
            )}
          </motion.div>
        ))}
      </div>

      {/* Compose bar */}
      <div
        className="flex items-center gap-2 px-3 py-2.5"
        style={{ borderTop: "1px solid rgba(0,0,0,0.04)" }}
      >
        <input
          type="text"
          placeholder="Écrire un message..."
          className="flex-1 px-3 py-2 rounded-xl border-none outline-none"
          style={{ backgroundColor: "rgba(0,0,0,0.03)", fontSize: 12, color: "#1a1a1a" }}
        />
        <motion.button
          className="flex items-center justify-center rounded-xl border-none cursor-pointer"
          style={{ width: 36, height: 36, backgroundColor: "rgba(0,0,0,0.04)", color: "#ccc" }}
          whileHover={{ scale: 1.05 }}
        >
          <Send size={14} strokeWidth={1.5} />
        </motion.button>
      </div>
    </PanelWrapper>
  );
}

// ─── AGENDA PANEL ───
const SAMPLE_EVENTS = [
  { title: "Marche silencieuse", time: "10:00", date: "Demain", color: "#C72B3B", participants: 3 },
  { title: "Atelier broderie", time: "14:00", date: "Dim 9 fév", color: "#9263A6", participants: 0 },
  { title: "Méditation du matin", time: "07:30", date: "Aujourd'hui", color: "#FF6533", participants: 2 },
  { title: "Écoute de la rivière", time: "16:00", date: "Mar 10 fév", color: "#42A350", participants: 0 },
];

export function AgendaPanel({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  return (
    <PanelWrapper
      visible={visible}
      onClose={onClose}
      title="Agenda"
      icon={<CalendarDays size={14} color="#42A350" strokeWidth={1.5} />}
      iconColor="#42A350"
    >
      <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2">
        {/* Today */}
        <span style={{ fontSize: 9, letterSpacing: "0.12em", color: "#ccc", textTransform: "uppercase" }}>
          Prochains rendez-vous
        </span>

        {SAMPLE_EVENTS.map((ev, i) => (
          <motion.div
            key={i}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer"
            style={{ backgroundColor: "rgba(0,0,0,0.02)" }}
            whileHover={{ backgroundColor: "rgba(0,0,0,0.04)" }}
          >
            <div
              className="rounded-[2px] flex-shrink-0"
              style={{ width: 4, height: 32, backgroundColor: ev.color }}
            />
            <div className="flex flex-col flex-1">
              <span style={{ fontSize: 12, fontWeight: 500, color: "#1a1a1a" }}>{ev.title}</span>
              <span style={{ fontSize: 10, color: "#bbb" }}>{ev.date} · {ev.time}</span>
            </div>
            {ev.participants > 0 && (
              <span
                className="flex items-center justify-center rounded-full"
                style={{
                  minWidth: 20, height: 20, backgroundColor: `${ev.color}15`,
                  fontSize: 9, color: ev.color, fontWeight: 500, padding: "0 6px",
                }}
              >
                {ev.participants}
              </span>
            )}
          </motion.div>
        ))}

        {/* Empty state hint */}
        <div className="flex flex-col items-center gap-2 py-6">
          <span style={{ fontSize: 10, color: "#ddd" }}>
            Crée ou rejoins une sortie pour remplir ton agenda
          </span>
        </div>
      </div>

      <div className="px-4 pb-3">
        <motion.button
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl cursor-pointer border-none"
          style={{ backgroundColor: "#1a1a1a", color: BG_IVORY, fontSize: 11, fontWeight: 400, letterSpacing: "0.06em" }}
          whileHover={{ scale: 1.01, backgroundColor: "#333" }}
          whileTap={{ scale: 0.99 }}
        >
          <Plus size={12} /> Créer une sortie
        </motion.button>
      </div>
    </PanelWrapper>
  );
}

// ─── MEDIA PANEL ───
const PLACEHOLDER_COLORS = [
  "#C72B3B20", "#0F3F8C20", "#9263A620", "#F2C20020",
  "#E87DA520", "#007B4320", "#4685B720", "#FF653320",
  "#5B1D6E20", "#42A35020", "#EB5B2E20", "#6BA7B020",
];

export function MediaPanel({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  return (
    <PanelWrapper
      visible={visible}
      onClose={onClose}
      title="Médias"
      icon={<Image size={14} color="#6BA7B0" strokeWidth={1.5} />}
      iconColor="#6BA7B0"
    >
      <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-3">
        <span style={{ fontSize: 9, letterSpacing: "0.12em", color: "#ccc", textTransform: "uppercase" }}>
          Photos déposées sur la grille
        </span>

        {/* Grid of placeholder thumbnails */}
        <div className="grid grid-cols-3 gap-1.5">
          {PLACEHOLDER_COLORS.map((bg, i) => (
            <motion.div
              key={i}
              className="aspect-square rounded-lg flex items-center justify-center cursor-pointer"
              style={{ backgroundColor: bg }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Camera size={14} color="#bbb" strokeWidth={1} />
            </motion.div>
          ))}
        </div>

        <div className="flex flex-col items-center gap-2 py-4">
          <span style={{ fontSize: 10, color: "#ddd", textAlign: "center" }}>
            Dépose une photo sur ta case depuis le menu radial
          </span>
        </div>
      </div>

      <div className="px-4 pb-3">
        <motion.button
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl cursor-pointer border-none"
          style={{ backgroundColor: "#1a1a1a", color: BG_IVORY, fontSize: 11, fontWeight: 400, letterSpacing: "0.06em" }}
          whileHover={{ scale: 1.01, backgroundColor: "#333" }}
          whileTap={{ scale: 0.99 }}
        >
          <Camera size={12} /> Déposer une photo
        </motion.button>
      </div>
    </PanelWrapper>
  );
}
