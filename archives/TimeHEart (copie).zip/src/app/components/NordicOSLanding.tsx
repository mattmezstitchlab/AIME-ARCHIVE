import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Mountain, Users, MapPin, Flag, Zap, BarChart3, Shield, ChevronRight, CloudSun, Wind, Calendar, Compass, TreePine } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// ═══════════════════════════════════════════
// NORDIC OS — Système d'exploitation événementiel
// Thème : vert forêt / blanc neige / air frais
// ═══════════════════════════════════════════

const HERO_IMG = "https://images.unsplash.com/photo-1765128158698-7aea8e110efa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxub3JkaWMlMjBtb3VudGFpbiUyMGhpa2luZyUyMG91dGRvb3IlMjBldmVudHxlbnwxfHx8fDE3NzA0ODAyNjh8MA&ixlib=rb-4.1.0&q=80&w=1080";

const C = {
  bg: "#0B1A12",
  green: "#22A652",
  greenLight: "#34C96A",
  greenDark: "#1A7A3D",
  greenGlow: "rgba(34,166,82,0.12)",
  white: "#F0F5F2",
  snow: "#E8EDE9",
  textSoft: "rgba(240,245,242,0.5)",
  textMuted: "rgba(240,245,242,0.25)",
  border: "rgba(34,166,82,0.12)",
  card: "rgba(255,255,255,0.03)",
};

const FEATURES = [
  { icon: Calendar, label: "Planning", desc: "Calendrier partagé avec météo intégrée", color: C.green },
  { icon: MapPin, label: "Cartographie", desc: "Carte interactive des lieux et parcours", color: C.greenLight },
  { icon: Users, label: "Équipes", desc: "Gestion des groupes et rôles bénévoles", color: C.green },
  { icon: Shield, label: "Sécurité", desc: "Check-lists, protocoles et alertes", color: "#E8B44F" },
  { icon: CloudSun, label: "Météo", desc: "Prévisions en temps réel par zone", color: "#7CB3D4" },
  { icon: BarChart3, label: "Dashboard", desc: "Vue d'ensemble et KPIs de l'événement", color: C.greenLight },
  { icon: Compass, label: "Navigation", desc: "Guidage GPS des participants", color: C.green },
  { icon: TreePine, label: "Impact", desc: "Empreinte écologique et compensation", color: "#6BAF6B" },
];

const EVENTS_DEMO = [
  { name: "Trail des Fjords", date: "15 mars", participants: 240, status: "Inscriptions ouvertes" },
  { name: "Nordic Camp Weekend", date: "22 avril", participants: 85, status: "Complet" },
  { name: "Raid Forêt Boréale", date: "10 juin", participants: 120, status: "Bientôt" },
];

interface NordicOSLandingProps {
  onBack?: () => void;
  onNavigate?: (screen: string) => void;
}

export function NordicOSLanding({ onBack, onNavigate }: NordicOSLandingProps) {
  const [activeTab, setActiveTab] = useState<"overview" | "features" | "events">("overview");

  return (
    <div
      className="fixed inset-0 overflow-y-auto"
      style={{
        backgroundColor: C.bg,
        fontFamily: "'Inter', -apple-system, sans-serif",
      }}
    >
      {/* ═══ HEADER ═══ */}
      <motion.header
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-5 py-3.5"
        style={{
          backgroundColor: "rgba(11,26,18,0.85)",
          backdropFilter: "blur(20px)",
          borderBottom: `1px solid ${C.border}`,
        }}
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center gap-3">
          {onBack && (
            <motion.button
              className="flex items-center justify-center rounded-lg border-none cursor-pointer"
              style={{ width: 34, height: 34, backgroundColor: "rgba(34,166,82,0.08)", color: C.textSoft }}
              onClick={onBack}
              whileHover={{ scale: 1.05, backgroundColor: "rgba(34,166,82,0.15)" }}
              whileTap={{ scale: 0.9 }}
            >
              <ArrowLeft size={15} />
            </motion.button>
          )}
          <div className="flex items-center gap-2">
            <Mountain size={14} color={C.green} strokeWidth={1.5} />
            <span style={{ fontSize: 12, color: C.green, fontWeight: 600, letterSpacing: "0.08em" }}>
              NORDIC OS
            </span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1">
          {(["overview", "features", "events"] as const).map((tab) => (
            <button
              key={tab}
              className="border-none cursor-pointer rounded-lg px-3 py-1.5"
              style={{
                backgroundColor: activeTab === tab ? "rgba(34,166,82,0.12)" : "rgba(0,0,0,0)",
                color: activeTab === tab ? C.green : C.textSoft,
                fontSize: 10,
                fontWeight: activeTab === tab ? 500 : 400,
                letterSpacing: "0.04em",
                textTransform: "capitalize",
              }}
              onClick={() => setActiveTab(tab)}
            >
              {tab === "overview" ? "Vue" : tab === "features" ? "Modules" : "Événements"}
            </button>
          ))}
        </div>
      </motion.header>

      <AnimatePresence mode="wait">
        {activeTab === "overview" && (
          <motion.div
            key="overview"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* ═══ HERO ═══ */}
            <section className="relative" style={{ height: "65vh", minHeight: 400 }}>
              <ImageWithFallback
                src={HERO_IMG}
                alt="Nordic landscape"
                className="absolute inset-0 w-full h-full object-cover"
                style={{ opacity: 0.4, filter: "brightness(0.5) saturate(0.7)" }}
              />
              <div
                className="absolute inset-0"
                style={{ background: `linear-gradient(to bottom, ${C.bg}44 0%, ${C.bg} 100%)` }}
              />

              <div className="relative z-10 flex flex-col items-center justify-end h-full pb-12 px-6">
                <motion.div
                  className="flex items-center gap-2 px-3 py-1 rounded-full mb-5"
                  style={{ backgroundColor: C.greenGlow, border: `1px solid ${C.border}` }}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <Wind size={10} color={C.green} />
                  <span style={{ fontSize: 9, color: C.green, fontWeight: 500, letterSpacing: "0.08em" }}>
                    OUTDOOR EVENT SYSTEM
                  </span>
                </motion.div>

                <motion.h1
                  className="text-center"
                  style={{
                    fontSize: "clamp(28px, 5vw, 48px)",
                    fontWeight: 200,
                    color: C.white,
                    lineHeight: 1.25,
                    letterSpacing: "-0.02em",
                  }}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6, duration: 0.8 }}
                >
                  Organiser.
                  <br />
                  <span style={{ fontWeight: 500, color: C.green }}>En plein air.</span>
                </motion.h1>

                <motion.p
                  className="text-center max-w-md mt-4"
                  style={{ fontSize: 14, color: C.textSoft, lineHeight: 1.8, fontWeight: 300 }}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 }}
                >
                  Le système d'exploitation pour événements outdoor.
                  Trails, raids, camps, festivals — tout pilotable depuis un seul dashboard.
                </motion.p>

                <motion.div
                  className="flex items-center gap-3 mt-8"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.2 }}
                >
                  <motion.button
                    className="flex items-center gap-2 px-6 py-3 rounded-xl border-none cursor-pointer"
                    style={{
                      backgroundColor: C.green,
                      color: "#fff",
                      fontSize: 12,
                      fontWeight: 600,
                      letterSpacing: "0.06em",
                    }}
                    onClick={() => setActiveTab("events")}
                    whileHover={{ scale: 1.03, backgroundColor: C.greenLight }}
                    whileTap={{ scale: 0.97 }}
                  >
                    Voir les événements
                    <ChevronRight size={14} />
                  </motion.button>
                  <motion.button
                    className="flex items-center gap-2 px-5 py-3 rounded-xl border-none cursor-pointer"
                    style={{
                      backgroundColor: "rgba(34,166,82,0.08)",
                      border: `1px solid ${C.border}`,
                      color: C.green,
                      fontSize: 12,
                      fontWeight: 400,
                    }}
                    onClick={() => setActiveTab("features")}
                    whileHover={{ scale: 1.03, backgroundColor: "rgba(34,166,82,0.15)" }}
                    whileTap={{ scale: 0.97 }}
                  >
                    Modules
                  </motion.button>
                </motion.div>
              </div>
            </section>

            {/* ═══ STATS BAR ═══ */}
            <section
              className="flex items-center justify-center gap-8 py-6 px-6"
              style={{ borderBottom: `1px solid ${C.border}` }}
            >
              {[
                { value: "2.4k", label: "Participants" },
                { value: "12", label: "Événements" },
                { value: "98%", label: "Satisfaction" },
                { value: "0", label: "Incidents" },
              ].map((s, i) => (
                <motion.div
                  key={s.label}
                  className="flex flex-col items-center"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 * i }}
                >
                  <span style={{ fontSize: 20, fontWeight: 600, color: C.green }}>{s.value}</span>
                  <span style={{ fontSize: 9, color: C.textMuted, letterSpacing: "0.06em", marginTop: 2 }}>
                    {s.label}
                  </span>
                </motion.div>
              ))}
            </section>

            {/* ═══ QUICK FEATURES ═══ */}
            <section className="py-16 px-6">
              <div className="max-w-2xl mx-auto">
                <motion.h2
                  style={{ fontSize: 24, fontWeight: 200, color: C.white, marginBottom: 24 }}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                >
                  Tout pour l'outdoor.
                  <span style={{ color: C.textMuted }}> Rien de superflu.</span>
                </motion.h2>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {FEATURES.slice(0, 4).map((f, i) => (
                    <motion.div
                      key={f.label}
                      className="flex flex-col items-center gap-2 rounded-xl py-5 px-3"
                      style={{
                        backgroundColor: C.card,
                        border: `1px solid ${C.border}`,
                      }}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.08 * i }}
                    >
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${f.color}12` }}
                      >
                        <f.icon size={18} color={f.color} strokeWidth={1.5} />
                      </div>
                      <span style={{ fontSize: 11, fontWeight: 500, color: C.white }}>{f.label}</span>
                      <span style={{ fontSize: 9, color: C.textMuted, textAlign: "center", lineHeight: 1.4 }}>
                        {f.desc}
                      </span>
                    </motion.div>
                  ))}
                </div>

                <motion.button
                  className="flex items-center gap-2 mx-auto mt-6 px-4 py-2 rounded-lg border-none cursor-pointer"
                  style={{ backgroundColor: "rgba(0,0,0,0)", color: C.green, fontSize: 11, fontWeight: 400 }}
                  onClick={() => setActiveTab("features")}
                  whileHover={{ scale: 1.03 }}
                >
                  Voir les 8 modules <ChevronRight size={12} />
                </motion.button>
              </div>
            </section>

            {/* ═══ CTA ═══ */}
            <section className="py-16 px-6 flex flex-col items-center" style={{ borderTop: `1px solid ${C.border}` }}>
              <Mountain size={20} color={C.green} strokeWidth={1} />
              <p style={{ fontSize: 12, color: C.textMuted, marginTop: 12, textAlign: "center", maxWidth: 360, lineHeight: 1.8 }}>
                Nordic OS est en développement. Rejoignez les premiers organisateurs outdoor.
              </p>
              {onNavigate && (
                <motion.button
                  className="mt-6 flex items-center gap-2 px-5 py-2.5 rounded-lg border-none cursor-pointer"
                  style={{ backgroundColor: "rgba(34,166,82,0.08)", color: C.green, fontSize: 11, border: `1px solid ${C.border}` }}
                  onClick={() => onNavigate("landing")}
                  whileHover={{ scale: 1.03, backgroundColor: "rgba(34,166,82,0.15)" }}
                >
                  Retour à l'écosystème
                </motion.button>
              )}
            </section>
          </motion.div>
        )}

        {activeTab === "features" && (
          <motion.div
            key="features"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="pt-20 pb-16 px-6"
          >
            <div className="max-w-2xl mx-auto">
              <motion.h2
                style={{ fontSize: 24, fontWeight: 200, color: C.white, marginBottom: 8 }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                8 modules.
              </motion.h2>
              <motion.p
                style={{ fontSize: 13, color: C.textSoft, marginBottom: 28, lineHeight: 1.7 }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                Chaque module couvre un aspect clé de l'organisation outdoor.
              </motion.p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {FEATURES.map((f, i) => (
                  <motion.div
                    key={f.label}
                    className="flex items-start gap-3 rounded-xl px-4 py-4"
                    style={{
                      backgroundColor: C.card,
                      border: `1px solid ${C.border}`,
                    }}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * i }}
                  >
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${f.color}12` }}
                    >
                      <f.icon size={16} color={f.color} strokeWidth={1.5} />
                    </div>
                    <div>
                      <span style={{ fontSize: 12, fontWeight: 500, color: C.white, display: "block" }}>
                        {f.label}
                      </span>
                      <span style={{ fontSize: 10, color: C.textMuted, lineHeight: 1.5, display: "block", marginTop: 2 }}>
                        {f.desc}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "events" && (
          <motion.div
            key="events"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="pt-20 pb-16 px-6"
          >
            <div className="max-w-2xl mx-auto">
              <motion.h2
                style={{ fontSize: 24, fontWeight: 200, color: C.white, marginBottom: 8 }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                Événements
              </motion.h2>
              <motion.p
                style={{ fontSize: 13, color: C.textSoft, marginBottom: 28, lineHeight: 1.7 }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                Les prochains événements gérés par Nordic OS.
              </motion.p>

              <div className="flex flex-col gap-3">
                {EVENTS_DEMO.map((ev, i) => (
                  <motion.div
                    key={ev.name}
                    className="flex items-center gap-4 rounded-xl px-5 py-4"
                    style={{
                      backgroundColor: C.card,
                      border: `1px solid ${C.border}`,
                    }}
                    initial={{ opacity: 0, x: -15 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.08 * i }}
                  >
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{
                        backgroundColor: ev.status === "Complet" ? "rgba(232,180,79,0.1)" : C.greenGlow,
                      }}
                    >
                      <Flag
                        size={16}
                        color={ev.status === "Complet" ? "#E8B44F" : C.green}
                        strokeWidth={1.5}
                      />
                    </div>
                    <div className="flex-1">
                      <span style={{ fontSize: 13, fontWeight: 500, color: C.white, display: "block" }}>
                        {ev.name}
                      </span>
                      <span style={{ fontSize: 10, color: C.textMuted, display: "block", marginTop: 2 }}>
                        {ev.date} · {ev.participants} participants
                      </span>
                    </div>
                    <span
                      className="px-2.5 py-1 rounded-full"
                      style={{
                        fontSize: 9,
                        fontWeight: 500,
                        letterSpacing: "0.04em",
                        backgroundColor: ev.status === "Complet"
                          ? "rgba(232,180,79,0.1)"
                          : ev.status === "Bientôt"
                          ? "rgba(255,255,255,0.04)"
                          : C.greenGlow,
                        color: ev.status === "Complet"
                          ? "#E8B44F"
                          : ev.status === "Bientôt"
                          ? C.textSoft
                          : C.green,
                      }}
                    >
                      {ev.status}
                    </span>
                  </motion.div>
                ))}
              </div>

              <motion.button
                className="flex items-center gap-2 mx-auto mt-8 px-6 py-3 rounded-xl border-none cursor-pointer"
                style={{
                  backgroundColor: C.green,
                  color: "#fff",
                  fontSize: 12,
                  fontWeight: 600,
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                whileHover={{ scale: 1.03, backgroundColor: C.greenLight }}
                whileTap={{ scale: 0.97 }}
              >
                <Zap size={13} />
                Créer un événement
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
