import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Camera, Pipette, Pencil, Type, Grid3X3, Download, Scissors, Share2,
  Heart, ChevronDown, Play, ExternalLink, Sparkles,
  ArrowRight, X,
  Star, Globe, BookOpen, Menu, Layers, MousePointer,
  Hand, Compass, Crown, Eye,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// Screenshot imports from 2003 video
import imgHommeMachine from "figma:asset/213351ef126f02fd979ac2457f7daeb0723367b8.png";
import imgMusicbox from "figma:asset/8fdac0edcd11df1aaeb727af15084080ab51d1aa.png";
import imgFaceGrid from "figma:asset/1e04a73744cfff6aea63ac5fa0c2afdc3356ae0f.png";
import imgGridSquares from "figma:asset/2c990818db2b102c8055ceee10f768fb3b13911f.png";

// ═══════════════════════════════════════════
// POINT LANDING — Showcase & Demo Page
// "Un carré. Huit outils. L'infini de la broderie."
// ═══════════════════════════════════════════

const FUCHSIA = "#E8177F";
const ORANGE = "#EB5B2E";
const GRADIENT = `linear-gradient(135deg, ${FUCHSIA}, ${ORANGE})`;
const PURPLE = "#9263A6";
const BG = "#FAF8F5";

// ─── TOOL DATA (matching Point.tsx layout) ───
const CUBE_TOOLS = [
  { label: "DMC", icon: Pipette, color: "#C72B3B", pos: "N" },
  { label: "Grille", icon: Grid3X3, color: "#4685B7", pos: "NE" },
  { label: "Symboles", icon: Type, color: "#9263A6", pos: "E" },
  { label: "Partage", icon: Share2, color: "#6BA7B0", pos: "SE" },
  { label: "Export", icon: Download, color: "#42A350", pos: "S" },
  { label: "Lily", icon: Scissors, color: "#9263A6", pos: "SW" },
  { label: "Crayon", icon: Pencil, color: "#1a1a1a", pos: "W" },
  { label: "Photo", icon: Camera, color: "#EB5B2E", pos: "NW" },
];

const OFFSETS: [number, number][] = [
  [0, -1], [1, -1], [1, 0], [1, 1],
  [0, 1], [-1, 1], [-1, 0], [-1, -1],
];

// ─── PIPELINE ROWS ───
const PIPELINE = [
  {
    title: "Voir · Traduire · Structurer",
    subtitle: "LIGNE 1 — ENTRER",
    color: "#EB5B2E",
    items: [
      { icon: Camera, label: "Photo", desc: "Importer une image du réel" },
      { icon: Pipette, label: "DMC", desc: "Traduire en langage couleur" },
      { icon: Grid3X3, label: "Grille", desc: "Poser le cadre, la toile" },
    ],
  },
  {
    title: "Créer · ♥ · Signer",
    subtitle: "LIGNE 2 — CRÉER",
    color: FUCHSIA,
    items: [
      { icon: Pencil, label: "Crayon", desc: "Le geste direct, broder" },
      { icon: Heart, label: "POINT", desc: "Le cœur, l'identité" },
      { icon: Type, label: "Symboles", desc: "Donner du sens, signer" },
    ],
  },
  {
    title: "Guider · Sortir · Transmettre",
    subtitle: "LIGNE 3  LIBÉRER",
    color: "#42A350",
    items: [
      { icon: Scissors, label: "Lily", desc: "Guide IA, soutien humain" },
      { icon: Download, label: "Export", desc: "Sortir l'œuvre finie" },
      { icon: Share2, label: "Partage", desc: "Transmettre au monde" },
    ],
  },
];

// ─── MINI CUBE COMPONENT (for hero) ───
function MiniCube({ onTryFull }: { onTryFull: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const [activeTool, setActiveTool] = useState<number | null>(null);
  const cellSize = 64;
  const gap = 5;
  const totalCell = cellSize + gap;

  const handleCenterClick = () => {
    if (!expanded) setExpanded(true);
    else if (activeTool !== null) setActiveTool(null);
    else setExpanded(false);
  };

  return (
    <div className="relative" style={{ width: totalCell * 3, height: totalCell * 3 }}>
      {/* 8 tool squares */}
      <AnimatePresence>
        {expanded && CUBE_TOOLS.map((tool, i) => {
          const [ox, oy] = OFFSETS[i];
          const Icon = tool.icon;
          const isActive = activeTool === i;

          return (
            <motion.button key={tool.label}
              className="absolute z-10 flex flex-col items-center justify-center rounded-xl border-none cursor-pointer overflow-hidden"
              style={{
                left: (1 + ox) * totalCell,
                top: (1 + oy) * totalCell,
                width: cellSize,
                height: cellSize,
                backgroundColor: tool.color,
                boxShadow: isActive
                  ? `0 6px 24px ${tool.color}60`
                  : `0 3px 14px ${tool.color}35`,
              }}
              initial={{ opacity: 0, scale: 0, x: -ox * totalCell, y: -oy * totalCell }}
              animate={{ opacity: 1, scale: isActive ? 1.08 : 1, x: 0, y: 0 }}
              exit={{ opacity: 0, scale: 0, x: -ox * totalCell, y: -oy * totalCell }}
              transition={{ type: "spring", stiffness: 450, damping: 25, delay: i * 0.04 }}
              onClick={() => setActiveTool(activeTool === i ? null : i)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.92 }}>
              <Icon size={22} strokeWidth={1.8} color="#fff" />
              <span style={{ fontSize: 7, color: "rgba(255,255,255,0.85)", marginTop: 4, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                {tool.label}
              </span>
              <div className="absolute inset-0 rounded-xl pointer-events-none"
                style={{ background: "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.15) 0%, rgba(0,0,0,0) 60%)" }} />
            </motion.button>
          );
        })}
      </AnimatePresence>

      {/* Center — The POINT */}
      <motion.button
        className="absolute z-20 flex flex-col items-center justify-center border-none cursor-pointer overflow-hidden rounded-xl"
        style={{
          left: totalCell,
          top: totalCell,
          width: cellSize,
          height: cellSize,
          background: GRADIENT,
          boxShadow: `0 6px 28px ${FUCHSIA}40, 0 0 50px ${FUCHSIA}15`,
        }}
        onClick={handleCenterClick}
        animate={!expanded ? {
          scale: [1, 1.06, 1, 1.04, 1, 1, 1],
        } : {}}
        transition={!expanded ? {
          duration: 1.8,
          repeat: Infinity,
          ease: "easeInOut",
          times: [0, 0.12, 0.24, 0.34, 0.46, 0.7, 1],
        } : { type: "spring", stiffness: 300, damping: 20 }}
        whileHover={{ scale: expanded ? 1.05 : 1.12 }}
        whileTap={{ scale: 0.88 }}>
        <span style={{ fontSize: 26, color: "#fff", lineHeight: 1, position: "relative", zIndex: 2, textShadow: "0 2px 8px rgba(0,0,0,0.15)" }}>
          ♥
        </span>
        <motion.div className="absolute" style={{ zIndex: 1 }}
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}>
          <X size={46} strokeWidth={0.5} color="rgba(255,255,255,0.2)" />
        </motion.div>
        <div className="absolute inset-0 rounded-xl pointer-events-none"
          style={{ background: "radial-gradient(circle at 35% 35%, rgba(255,255,255,0.2) 0%, rgba(0,0,0,0) 60%)" }} />
      </motion.button>

      {/* "Try Full" CTA when expanded */}
      <AnimatePresence>
        {expanded && (
          <motion.button
            className="absolute z-30 flex items-center gap-2 px-4 py-2 rounded-full border-none cursor-pointer"
            style={{
              top: totalCell * 3 + 14,
              left: "50%",
              transform: "translateX(-50%)",
              background: GRADIENT,
              color: "#fff",
              fontSize: 11,
              fontWeight: 500,
              boxShadow: `0 4px 20px ${FUCHSIA}40`,
              whiteSpace: "nowrap",
            }}
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            onClick={onTryFull}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}>
            <Play size={12} fill="#fff" />
            Expérience complète
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── SECTION COMPONENTS ───

function SectionDivider() {
  return (
    <div className="flex items-center justify-center py-2">
      <div style={{ width: 40, height: 2, background: GRADIENT, borderRadius: 1, opacity: 0.3 }} />
    </div>
  );
}

// ═══════════════════════════════════════════
// MAIN LANDING COMPONENT
// ═══════════════════════════════════════════

interface PointLandingProps {
  onBack?: () => void;
  onTryPoint?: () => void;
}

export function PointLanding({ onBack, onTryPoint }: PointLandingProps) {
  return (
    <div className="fixed inset-0 overflow-y-auto overflow-x-hidden"
      style={{ backgroundColor: BG, fontFamily: "'Inter', -apple-system, sans-serif", WebkitOverflowScrolling: "touch" }}>

      {/* ═══ STICKY NAV ═══ */}
      <motion.nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-3"
        style={{ backgroundColor: "rgba(250,248,245,0.9)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(0,0,0,0.04)" }}>
        <div className="flex items-center gap-3">
          {onBack && (
            <motion.button className="flex items-center gap-1.5 border-none cursor-pointer rounded-lg px-3 py-1.5"
              style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#999", fontSize: 11 }}
              onClick={onBack} whileTap={{ scale: 0.95 }}>
              ← Retour
            </motion.button>
          )}
          <span style={{ fontSize: 14, fontWeight: 700, background: GRADIENT, WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)" }}>
            POINT
          </span>
          <span style={{ fontSize: 9, color: "#ccc", letterSpacing: "0.08em" }}>by StitchLab</span>
        </div>
        <motion.button
          className="flex items-center gap-2 border-none cursor-pointer rounded-full px-4 py-2"
          style={{ background: GRADIENT, color: "#fff", fontSize: 11, fontWeight: 500 }}
          onClick={onTryPoint}
          whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
          <Heart size={12} fill="#fff" />
          Essayer
        </motion.button>
      </motion.nav>

      {/* ═══ HERO ═══ */}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-16 px-6">
        {/* Badge */}
        <motion.div className="flex items-center gap-2 px-4 py-1.5 rounded-full mb-8"
          style={{ backgroundColor: `${FUCHSIA}08`, border: `1px solid ${FUCHSIA}15` }}
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}>
          <Sparkles size={12} color={FUCHSIA} />
          <span style={{ fontSize: 10, color: FUCHSIA, fontWeight: 500, letterSpacing: "0.04em" }}>
            CONCEPT BREVETÉ · VISION 2003
          </span>
        </motion.div>

        {/* Title */}
        <motion.h1 className="text-center mb-3"
          style={{ fontSize: "clamp(28px, 5vw, 52px)", fontWeight: 800, color: "#1a1a1a", lineHeight: 1.1, letterSpacing: "-0.02em" }}
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}>
          Un carré.
          <br />
          <span style={{ background: GRADIENT, WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)" }}>
            Huit outils.
          </span>
          <br />
          L'infini de la broderie.
        </motion.h1>

        <motion.p className="text-center max-w-md mb-10"
          style={{ fontSize: "clamp(13px, 2vw, 16px)", color: "#888", lineHeight: 1.7 }}
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}>
          POINT réinvente l'interface de création en broderie.
          <br />
          Un cube qui se déplie, 64 fonctions, zéro complexité.
        </motion.p>

        {/* INTERACTIVE MINI CUBE */}
        <motion.div className="mb-8"
          initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6, type: "spring", stiffness: 200, damping: 20 }}>
          <MiniCube onTryFull={() => onTryPoint?.()} />
        </motion.div>

        <motion.p
          style={{ fontSize: 11, color: "#bbb", letterSpacing: "0.06em" }}
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}>
          Touche le cœur pour déplier
        </motion.p>

        {/* Scroll indicator */}
        <motion.div className="absolute bottom-8 left-0 right-0 flex flex-col items-center gap-1"
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 2, repeat: Infinity }}>
          <span style={{ fontSize: 9, color: "#ccc", letterSpacing: "0.1em" }}>DÉCOUVRIR</span>
          <ChevronDown size={16} color="#ccc" />
        </motion.div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: PIPELINE MENTAL ═══ */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            <span style={{ fontSize: 10, color: FUCHSIA, letterSpacing: "0.2em", fontWeight: 600, textTransform: "uppercase" }}>
              Architecture
            </span>
            <h2 className="mt-3" style={{ fontSize: "clamp(22px, 4vw, 36px)", fontWeight: 700, color: "#1a1a1a", lineHeight: 1.2 }}>
              Trois lignes. Trois gestes mentaux.
            </h2>
            <p className="mt-3" style={{ fontSize: 14, color: "#999", maxWidth: 460, margin: "12px auto 0" }}>
              L'ordre des outils suit le pipeline naturel de la pensée créative. Pas besoin d'apprendre — tu sais déjà.
            </p>
          </motion.div>

          {PIPELINE.map((row, ri) => (
            <motion.div key={ri} className="mb-12"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: ri * 0.1 }}>
              {/* Row header */}
              <div className="flex items-center gap-3 mb-5">
                <div className="w-8 h-0.5 rounded-full" style={{ backgroundColor: row.color }} />
                <span style={{ fontSize: 9, color: row.color, letterSpacing: "0.12em", fontWeight: 600, textTransform: "uppercase" }}>
                  {row.subtitle}
                </span>
              </div>
              <h3 className="mb-4" style={{ fontSize: 18, fontWeight: 600, color: "#1a1a1a" }}>
                {row.title}
              </h3>

              {/* 3 items */}
              <div className="grid grid-cols-3 gap-4">
                {row.items.map((item, ii) => {
                  const Icon = item.icon;
                  const isCenter = item.label === "POINT";
                  return (
                    <motion.div key={ii}
                      className="flex flex-col items-center gap-3 py-6 px-3 rounded-2xl"
                      style={{
                        backgroundColor: isCenter ? "rgba(0,0,0,0)" : "rgba(255,255,255,0.8)",
                        background: isCenter ? GRADIENT : undefined,
                        border: isCenter ? "none" : "1px solid rgba(0,0,0,0.04)",
                        boxShadow: isCenter
                          ? `0 8px 30px ${FUCHSIA}25`
                          : "0 2px 12px rgba(0,0,0,0.03)",
                      }}
                      whileHover={{ y: -3, boxShadow: isCenter ? `0 12px 40px ${FUCHSIA}35` : "0 6px 20px rgba(0,0,0,0.06)" }}>
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                        style={{
                          backgroundColor: isCenter ? "rgba(255,255,255,0.2)" : `${row.color}12`,
                        }}>
                        <Icon size={20} color={isCenter ? "#fff" : row.color} strokeWidth={1.8} />
                      </div>
                      <span style={{
                        fontSize: 12, fontWeight: 600,
                        color: isCenter ? "#fff" : "#1a1a1a",
                      }}>
                        {item.label}
                      </span>
                      <span style={{
                        fontSize: 10, textAlign: "center", lineHeight: 1.5,
                        color: isCenter ? "rgba(255,255,255,0.8)" : "#999",
                      }}>
                        {item.desc}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: ZÉRO MENU — L'ARGUMENT MASSUE ═══ */}
      <section className="py-28 px-6" style={{ backgroundColor: "#fff" }}>
        <div className="max-w-4xl mx-auto">
          <motion.div className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            <span style={{ fontSize: 10, color: "#C72B3B", letterSpacing: "0.2em", fontWeight: 600, textTransform: "uppercase" }}>
              Le paradoxe
            </span>
            <h2 className="mt-3" style={{ fontSize: "clamp(26px, 5vw, 44px)", fontWeight: 800, color: "#1a1a1a", lineHeight: 1.1 }}>
              64 fonctions.
              <br />
              <span style={{ background: GRADIENT, WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)" }}>
                Zéro menu.
              </span>
            </h2>
          </motion.div>

          {/* AVANT / APRÈS — Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {/* AVANT — Traditional UI */}
            <motion.div className="rounded-2xl overflow-hidden"
              style={{ border: "1px solid rgba(0,0,0,0.08)" }}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}>
              {/* Header */}
              <div className="px-5 py-3 flex items-center justify-between"
                style={{ backgroundColor: "#f5f5f5", borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
                <span style={{ fontSize: 11, fontWeight: 600, color: "#999", letterSpacing: "0.06em" }}>AVANT</span>
                <span style={{ fontSize: 9, color: "#ccc" }}>Logiciel classique</span>
              </div>
              {/* Fake complex UI */}
              <div className="p-5" style={{ backgroundColor: "#fafafa" }}>
                {/* Menu bar */}
                <div className="flex items-center gap-2 mb-3 pb-2" style={{ borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
                  <Menu size={14} color="#999" />
                  {["Fichier", "Édition", "Affichage", "Outils", "Filtres", "Aide"].map(m => (
                    <span key={m} style={{ fontSize: 8, color: "#aaa", padding: "2px 4px" }}>{m}</span>
                  ))}
                </div>
                {/* Toolbar rows */}
                <div className="flex gap-1 mb-2 flex-wrap">
                  {[...Array(16)].map((_, i) => (
                    <div key={i} className="rounded" style={{ width: 18, height: 18, backgroundColor: `rgba(0,0,0,${0.04 + (i % 3) * 0.02})` }} />
                  ))}
                </div>
                <div className="flex gap-1 mb-3 flex-wrap">
                  {[...Array(12)].map((_, i) => (
                    <div key={i} className="rounded" style={{ width: 18, height: 18, backgroundColor: `rgba(0,0,0,${0.03 + (i % 4) * 0.02})` }} />
                  ))}
                </div>
                {/* Side panel */}
                <div className="flex gap-3">
                  <div className="flex-1 rounded-lg" style={{ height: 80, backgroundColor: "rgba(0,0,0,0.03)" }} />
                  <div className="flex flex-col gap-1" style={{ width: 60 }}>
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="rounded" style={{ height: 10, backgroundColor: `rgba(0,0,0,${0.03 + i * 0.01})` }} />
                    ))}
                  </div>
                </div>
                {/* Dropdown mockup */}
                <div className="mt-3 rounded-lg p-2" style={{ backgroundColor: "#fff", border: "1px solid rgba(0,0,0,0.08)", width: "60%" }}>
                  {["Option 1", "Option 2", "Plus d'options ▸", "Paramètres ▸", "Avancé ▸"].map(o => (
                    <div key={o} className="py-1 px-2 rounded" style={{ fontSize: 7, color: "#999" }}>{o}</div>
                  ))}
                </div>
              </div>
              {/* Verdict */}
              <div className="px-5 py-3 flex items-center gap-3" style={{ backgroundColor: "#fff4f4" }}>
                <Layers size={14} color="#C72B3B" />
                <div>
                  <span style={{ fontSize: 10, fontWeight: 600, color: "#C72B3B" }}>6 menus</span>
                  <span style={{ fontSize: 10, color: "#999" }}> · 28 icônes · 5 sous-menus · 3 panneaux</span>
                </div>
              </div>
            </motion.div>

            {/* APRÈS — POINT */}
            <motion.div className="rounded-2xl overflow-hidden"
              style={{ border: `1px solid ${FUCHSIA}20` }}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}>
              {/* Header */}
              <div className="px-5 py-3 flex items-center justify-between"
                style={{ background: "linear-gradient(135deg, rgba(232,23,127,0.06), rgba(235,91,46,0.06))", borderBottom: `1px solid ${FUCHSIA}10` }}>
                <span style={{ fontSize: 11, fontWeight: 600, background: GRADIENT, WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)", letterSpacing: "0.06em" }}>APRÈS</span>
                <span style={{ fontSize: 9, color: FUCHSIA }}>POINT</span>
              </div>
              {/* The cube — center of the screen, nothing else */}
              <div className="flex items-center justify-center py-12" style={{ backgroundColor: BG }}>
                <div className="grid grid-cols-3 gap-1" style={{ width: 108 }}>
                  {[...Array(9)].map((_, i) => {
                    const isCenter = i === 4;
                    const cubeColors = ["#EB5B2E", "#C72B3B", "#4685B7", "#1a1a1a", FUCHSIA, "#9263A6", "#9263A6", "#42A350", "#6BA7B0"];
                    const cubeIcons = [Camera, Pipette, Grid3X3, Pencil, Heart, Type, Scissors, Download, Share2];
                    const Icon = cubeIcons[i];
                    return (
                      <motion.div key={i}
                        className="rounded-lg flex items-center justify-center"
                        style={{
                          width: 32, height: 32,
                          background: isCenter ? GRADIENT : cubeColors[i],
                          boxShadow: isCenter ? `0 3px 12px ${FUCHSIA}40` : `0 1px 4px ${cubeColors[i]}30`,
                        }}
                        animate={isCenter ? { scale: [1, 1.08, 1] } : {}}
                        transition={isCenter ? { duration: 1.8, repeat: Infinity } : {}}>
                        <Icon size={14} color="#fff" strokeWidth={1.8} />
                      </motion.div>
                    );
                  })}
                </div>
              </div>
              {/* Verdict */}
              <div className="px-5 py-3 flex items-center gap-3"
                style={{ background: "linear-gradient(135deg, rgba(232,23,127,0.06), rgba(235,91,46,0.06))" }}>
                <MousePointer size={14} color={FUCHSIA} />
                <div>
                  <span style={{ fontSize: 10, fontWeight: 600, color: FUCHSIA }}>0 menu</span>
                  <span style={{ fontSize: 10, color: "#999" }}> · 9 carrés · 64 fonctions · 1 geste</span>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Big stat row */}
          <motion.div className="grid grid-cols-3 gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            {[
              { value: "0", unit: "menu", detail: "Aucun menu déroulant, hamburger, ou barre d'outils" },
              { value: "9", unit: "carrés", detail: "Visibles simultanément — jamais plus, jamais moins" },
              { value: "64", unit: "fonctions", detail: "Accessibles en 2 touches maximum depuis le ♥" },
            ].map((stat, i) => (
              <motion.div key={i} className="text-center py-6 px-3 rounded-2xl"
                style={{ backgroundColor: BG }}
                whileHover={{ y: -2 }}>
                <span style={{
                  fontSize: "clamp(32px, 5vw, 52px)",
                  fontWeight: 800,
                  background: GRADIENT,
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "rgba(0,0,0,0)",
                  lineHeight: 1,
                }}>
                  {stat.value}
                </span>
                <div style={{ fontSize: 11, fontWeight: 600, color: "#1a1a1a", marginTop: 4 }}>
                  {stat.unit}
                </div>
                <div style={{ fontSize: 9, color: "#999", marginTop: 6, lineHeight: 1.5 }}>
                  {stat.detail}
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Explanation block */}
          <motion.div className="rounded-2xl p-8 text-center"
            style={{
              background: "linear-gradient(135deg, rgba(232,23,127,0.03), rgba(235,91,46,0.03))",
              border: `1px solid ${FUCHSIA}10`,
            }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, color: "#1a1a1a", marginBottom: 12 }}>
              Comment c'est possible ?
            </h3>
            <p style={{ fontSize: 13, color: "#666", lineHeight: 1.8, maxWidth: 520, margin: "0 auto" }}>
              Le secret : <strong style={{ color: "#1a1a1a" }}>la récursivité</strong>. Quand tu touches un outil,
              les 8 carrés autour du cœur <strong style={{ color: "#1a1a1a" }}>changent de contenu</strong> — pas d'ouverture
              de panneau, pas de navigation, pas de page qui change. Le cube reste le cube.
              Tu es toujours au même endroit. Seul le <em>sens</em> des carrés évolue.
            </p>
            <div className="flex items-center justify-center gap-4 mt-6">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ backgroundColor: "rgba(0,0,0,0.03)" }}>
                <span style={{ fontSize: 9, color: "#999" }}>Touche 1 :</span>
                <span style={{ fontSize: 9, fontWeight: 600, color: FUCHSIA }}>♥ → 8 outils</span>
              </div>
              <ArrowRight size={12} color="#ccc" />
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ backgroundColor: "rgba(0,0,0,0.03)" }}>
                <span style={{ fontSize: 9, color: "#999" }}>Touche 2 :</span>
                <span style={{ fontSize: 9, fontWeight: 600, color: ORANGE }}>Outil → 8 sous-options</span>
              </div>
            </div>
            <p className="mt-4" style={{ fontSize: 11, color: "#bbb" }}>
              2 touches. 64 possibilités. Zéro charge cognitive.
            </p>
          </motion.div>
        </div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: INCLUSIVITÉ ═══ */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            <span style={{ fontSize: 10, color: PURPLE, letterSpacing: "0.2em", fontWeight: 600, textTransform: "uppercase" }}>
              Inclusivité
            </span>
            <h2 className="mt-3" style={{ fontSize: "clamp(22px, 4vw, 36px)", fontWeight: 700, color: "#1a1a1a", lineHeight: 1.2 }}>
              Pour toutes les mains.
            </h2>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { icon: Hand, label: "Enfants", desc: "Gros boutons colorés, gestes intuitifs", color: "#EB5B2E" },
              { icon: Compass, label: "Débutantes", desc: "Lily guide chaque étape", color: "#4685B7" },
              { icon: Crown, label: "Expertes", desc: "64 fonctions pro accessibles", color: FUCHSIA },
              { icon: Eye, label: "Seniors", desc: "Police lisible, contrastes forts", color: PURPLE },
            ].map((profile, i) => {
              const PIcon = profile.icon;
              return (
              <motion.div key={i}
                className="flex flex-col items-center gap-3 py-6 px-3 rounded-2xl"
                style={{
                  backgroundColor: "rgba(255,255,255,0.7)",
                  border: "1px solid rgba(0,0,0,0.04)",
                }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -3 }}>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
                  style={{ background: `${profile.color}12` }}>
                  <PIcon size={22} color={profile.color} strokeWidth={1.6} />
                </div>
                <span style={{ fontSize: 13, fontWeight: 600, color: "#1a1a1a" }}>{profile.label}</span>
                <span style={{ fontSize: 10, color: "#999", textAlign: "center", lineHeight: 1.5 }}>{profile.desc}</span>
              </motion.div>
              );
            })}
          </div>

          {/* Image mise en situation */}
          <motion.div className="mt-12 rounded-2xl overflow-hidden"
            style={{ boxShadow: "0 8px 40px rgba(0,0,0,0.08)" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1584949091882-158ebf933cda?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHRhYmxldCUyMGRpZ2l0YWwlMjBjcmFmdGluZyUyMGNvbG9yZnVsJTIwdGhyZWFkc3xlbnwxfHx8fDE3NzA0NzMxNjh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Femme avec tablette et fils de broderie colorés"
                className="w-full object-cover"
                style={{ height: "clamp(200px, 30vw, 320px)" }}
              />
              <div className="absolute inset-0"
                style={{ background: "linear-gradient(to top, rgba(250,248,245,0.9) 0%, rgba(0,0,0,0) 60%)" }} />
              <div className="absolute bottom-6 left-6 right-6">
                <p style={{ fontSize: 14, fontWeight: 600, color: "#1a1a1a" }}>
                  La broderie n'a pas d'âge.
                </p>
                <p style={{ fontSize: 11, color: "#888", marginTop: 4 }}>
                  POINT non plus.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: ORIGIN STORY ═══ */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div className="flex flex-col md:flex-row gap-10 items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>

            {/* Text */}
            <div className="flex-1">
              <span style={{ fontSize: 10, color: "#C72B3B", letterSpacing: "0.2em", fontWeight: 600, textTransform: "uppercase" }}>
                Origin Story
              </span>
              <h2 className="mt-3 mb-5" style={{ fontSize: "clamp(22px, 4vw, 34px)", fontWeight: 700, color: "#1a1a1a", lineHeight: 1.2 }}>
                Une vision de 2003.
                <br />
                <span style={{ color: "#888", fontWeight: 400 }}>Concrétisée 22 ans plus tard.</span>
              </h2>
              <p style={{ fontSize: 13, color: "#888", lineHeight: 1.8, marginBottom: 16 }}>
                En 2003, l'idée d'un cube qui se déplie en interface apparaît dans une vision créative.
                Un carré qui contient tout, qui se transforme au toucher, qui ne surcharge jamais l'esprit.
              </p>
              <p style={{ fontSize: 13, color: "#888", lineHeight: 1.8, marginBottom: 20 }}>
                22 ans plus tard, avec l'IA, le canvas, et la communauté des brodeuses,
                cette vision prend vie dans <strong style={{ color: "#1a1a1a" }}>POINT</strong> — le premier outil
                de broderie numérique qui pense comme un artisan.
              </p>

              {/* Timeline */}
              <div className="flex items-center gap-4 mb-6">
                {[
                  { year: "2003", event: "La vision" },
                  { year: "2024", event: "StitchLab" },
                  { year: "2025", event: "POINT" },
                  { year: "2026", event: "Brevet" },
                ].map((t, i) => (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <div className="w-2 h-2 rounded-full"
                      style={{ background: i === 2 ? GRADIENT : `rgba(0,0,0,${0.08 + i * 0.06})` }} />
                    <span style={{ fontSize: 10, fontWeight: 600, color: i === 2 ? FUCHSIA : "#1a1a1a" }}>
                      {t.year}
                    </span>
                    <span style={{ fontSize: 8, color: "#bbb" }}>{t.event}</span>
                  </div>
                ))}
              </div>

              {/* YouTube link */}
              <motion.a
                href="https://www.youtube.com/watch?v=XgKcenvjMdI"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl no-underline"
                style={{
                  backgroundColor: "rgba(0,0,0,0.04)",
                  color: "#666",
                  fontSize: 12,
                  fontWeight: 500,
                  border: "1px solid rgba(0,0,0,0.06)",
                }}
                whileHover={{ scale: 1.02, backgroundColor: "rgba(0,0,0,0.06)" }}
                whileTap={{ scale: 0.98 }}>
                <Play size={14} color="#C72B3B" />
                Voir la vidéo originale (2003)
                <ExternalLink size={10} color="#ccc" />
              </motion.a>
            </div>

            {/* Visual — Screenshots from 2003 video */}
            <div className="shrink-0" style={{ width: "clamp(200px, 40vw, 280px)" }}>
              {/* Main image — homme-machine */}
              <motion.div className="rounded-2xl overflow-hidden mb-3"
                style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.12)", border: "1px solid rgba(0,0,0,0.06)" }}
                whileHover={{ scale: 1.02 }}>
                <img src={imgHommeMachine} alt="L'homme-machine — Vision 2003" className="w-full object-cover" style={{ height: 200 }} />
                <div className="px-3 py-2" style={{ backgroundColor: "#fff" }}>
                  <span style={{ fontSize: 8, color: FUCHSIA, fontWeight: 600, letterSpacing: "0.06em" }}>HOMME-MACHINE</span>
                  <p style={{ fontSize: 7, color: "#999", marginTop: 2 }}>L'humain en grille face au cube récursif — 2003</p>
                </div>
              </motion.div>
              {/* Grid of smaller screenshots */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { src: imgGridSquares, label: "Grille récursive" },
                  { src: imgMusicbox, label: "MUSICBOX" },
                  { src: imgFaceGrid, label: "Interface mentale" },
                ].map((shot, i) => (
                  <motion.div key={i} className="rounded-lg overflow-hidden"
                    style={{ boxShadow: "0 2px 8px rgba(0,0,0,0.08)", border: "1px solid rgba(0,0,0,0.04)" }}
                    whileHover={{ scale: 1.05 }}>
                    <img src={shot.src} alt={shot.label} className="w-full object-cover" style={{ height: 56 }} />
                    <div className="px-1.5 py-1" style={{ backgroundColor: "#fff" }}>
                      <span style={{ fontSize: 6, color: "#999" }}>{shot.label}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
              <p className="mt-2 text-center" style={{ fontSize: 7, color: "#ccc" }}>
                Captures d'écran de la vidéo originale · 2003
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: WIDGET CONCEPT ═══ */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            <span style={{ fontSize: 10, color: "#4685B7", letterSpacing: "0.2em", fontWeight: 600, textTransform: "uppercase" }}>
              Widget
            </span>
            <h2 className="mt-3" style={{ fontSize: "clamp(22px, 4vw, 36px)", fontWeight: 700, color: "#1a1a1a", lineHeight: 1.2 }}>
              Un seul carré. Partout.
            </h2>
            <p className="mt-3 mx-auto" style={{ fontSize: 14, color: "#999", maxWidth: 460, lineHeight: 1.7 }}>
              Le widget POINT, c'est juste un ♥. Un seul carré, en bas d'écran.
              Touche-le, et l'atelier complet se déplie. 64 fonctions dans 1 pixel.
            </p>
          </motion.div>

          {/* Widget visual — single heart */}
          <motion.div className="mt-12 flex flex-col sm:flex-row gap-8 justify-center items-center"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>

            {/* Desktop mockup */}
            <div className="rounded-2xl p-5" style={{ backgroundColor: "#fff", border: "1px solid rgba(0,0,0,0.06)", boxShadow: "0 4px 20px rgba(0,0,0,0.05)" }}>
              <div className="flex items-center gap-1.5 mb-4">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#FF5F57" }} />
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#FEBC2E" }} />
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#28C840" }} />
                <span style={{ fontSize: 8, color: "#ccc", marginLeft: 8 }}>stitchlab.app</span>
              </div>
              {/* Page content placeholder */}
              <div className="relative rounded-xl px-6 py-10" style={{ backgroundColor: "#fafafa", width: 200 }}>
                {/* Fake content lines */}
                <div className="flex flex-col gap-2 mb-6">
                  <div className="rounded" style={{ height: 6, width: "80%", backgroundColor: "rgba(0,0,0,0.06)" }} />
                  <div className="rounded" style={{ height: 6, width: "60%", backgroundColor: "rgba(0,0,0,0.04)" }} />
                  <div className="rounded" style={{ height: 6, width: "70%", backgroundColor: "rgba(0,0,0,0.03)" }} />
                </div>
                <div className="rounded-lg" style={{ height: 40, backgroundColor: "rgba(0,0,0,0.03)" }} />

                {/* The single ♥ widget — bottom right */}
                <motion.div className="absolute rounded-xl flex items-center justify-center"
                  style={{
                    bottom: 8, right: 8,
                    width: 28, height: 28,
                    background: GRADIENT,
                    boxShadow: `0 3px 12px ${FUCHSIA}40`,
                  }}
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 1.8, repeat: Infinity }}>
                  <span style={{ fontSize: 12, color: "#fff" }}>♥</span>
                </motion.div>
              </div>
              <div className="flex items-center justify-end gap-1 mt-2">
                <ArrowRight size={8} color="#ccc" />
                <span style={{ fontSize: 7, color: "#ccc" }}>Un seul bouton</span>
              </div>
            </div>

            {/* Arrow */}
            <div className="hidden sm:flex flex-col items-center gap-1">
              <span style={{ fontSize: 7, color: "#ccc" }}>touche</span>
              <ArrowRight size={16} color="#ccc" />
              <span style={{ fontSize: 7, color: "#ccc" }}>déplie</span>
            </div>

            {/* Mobile mockup — deployed */}
            <div className="rounded-3xl p-3" style={{ backgroundColor: "#000", width: 150 }}>
              <div className="rounded-2xl py-4 px-3 flex flex-col items-center" style={{ backgroundColor: BG }}>
                <span style={{ fontSize: 6, color: "#bbb", marginBottom: 6, letterSpacing: "0.08em" }}>DÉPLIÉ</span>
                {/* Full cube deployed */}
                <div className="grid grid-cols-3 gap-0.5" style={{ width: 78 }}>
                  {[...Array(9)].map((_, i) => {
                    const isCenter = i === 4;
                    const miniColors = ["#EB5B2E", "#C72B3B", "#4685B7", "#1a1a1a", FUCHSIA, "#9263A6", "#9263A6", "#42A350", "#6BA7B0"];
                    const miniIcons = [Camera, Pipette, Grid3X3, Pencil, Heart, Type, Scissors, Download, Share2];
                    const MIcon = miniIcons[i];
                    return (
                      <motion.div key={i} className="rounded-[4px] flex items-center justify-center"
                        style={{
                          width: 24, height: 24,
                          background: isCenter ? GRADIENT : miniColors[i],
                          boxShadow: isCenter ? `0 2px 6px ${FUCHSIA}40` : "none",
                        }}
                        animate={isCenter ? { scale: [1, 1.08, 1] } : {}}
                        transition={isCenter ? { duration: 1.8, repeat: Infinity } : {}}>
                        <MIcon size={10} color="#fff" strokeWidth={1.8} />
                      </motion.div>
                    );
                  })}
                </div>
                <span style={{ fontSize: 6, color: "#ccc", marginTop: 6 }}>64 fonctions</span>
              </div>
              {/* Home bar */}
              <div className="mx-auto mt-2 rounded-full" style={{ width: 40, height: 3, backgroundColor: "#444" }} />
            </div>
          </motion.div>
        </div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: MISE EN SITUATION ═══ */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>
            <span style={{ fontSize: 10, color: "#42A350", letterSpacing: "0.2em", fontWeight: 600, textTransform: "uppercase" }}>
              En situation
            </span>
            <h2 className="mt-3" style={{ fontSize: "clamp(22px, 4vw, 36px)", fontWeight: 700, color: "#1a1a1a", lineHeight: 1.2 }}>
              Ce que POINT change.
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {[
              {
                icon: Camera,
                title: "Photo → Pattern en 3 clics",
                desc: "Prends une photo, POINT la convertit en grille DMC avec symboles. Tu choisis le nombre de couleurs et la taille.",
                color: "#EB5B2E",
              },
              {
                icon: Globe,
                title: "Partage instantané",
                desc: "QR code, lien, message — ton pattern part en 2 secondes vers ta communauté de brodeuses.",
                color: "#6BA7B0",
              },
              {
                icon: BookOpen,
                title: "Lily t'accompagne",
                desc: "L'IA broderie te conseille en temps réel. Technique, couleurs, pauses — Lily est là.",
                color: PURPLE,
              },
              {
                icon: Star,
                title: "64 fonctions, 0 menu",
                desc: "Pas de barre d'outils, pas de menu hamburger, pas de sous-menus. Juste le cube.",
                color: FUCHSIA,
              },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div key={i}
                  className="p-6 rounded-2xl"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.7)",
                    border: "1px solid rgba(0,0,0,0.04)",
                    boxShadow: "0 2px 12px rgba(0,0,0,0.03)",
                  }}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ delay: i * 0.08 }}
                  whileHover={{ y: -3 }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: `${item.color}12` }}>
                    <Icon size={18} color={item.color} strokeWidth={1.8} />
                  </div>
                  <h4 style={{ fontSize: 14, fontWeight: 600, color: "#1a1a1a", marginBottom: 6 }}>
                    {item.title}
                  </h4>
                  <p style={{ fontSize: 12, color: "#888", lineHeight: 1.6 }}>
                    {item.desc}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <SectionDivider />

      {/* ═══ SECTION: CTA FINAL ═══ */}
      <section className="py-32 px-6">
        <div className="max-w-lg mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}>

            {/* Mini heart */}
            <motion.div className="w-16 h-16 rounded-2xl mx-auto mb-8 flex items-center justify-center"
              style={{ background: GRADIENT, boxShadow: `0 8px 32px ${FUCHSIA}35` }}
              animate={{ scale: [1, 1.06, 1, 1.04, 1, 1, 1] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut", times: [0, 0.12, 0.24, 0.34, 0.46, 0.7, 1] }}>
              <span style={{ fontSize: 24, color: "#fff" }}>♥</span>
            </motion.div>

            <h2 style={{ fontSize: "clamp(24px, 5vw, 40px)", fontWeight: 800, color: "#1a1a1a", lineHeight: 1.1, marginBottom: 12 }}>
              Prête à broder ?
            </h2>
            <p style={{ fontSize: 14, color: "#888", lineHeight: 1.7, marginBottom: 24 }}>
              Touche le cœur. Tout se déplie.
            </p>

            <motion.button
              className="inline-flex items-center gap-3 border-none cursor-pointer rounded-2xl px-8 py-4"
              style={{
                background: GRADIENT,
                color: "#fff",
                fontSize: 15,
                fontWeight: 600,
                letterSpacing: "0.08em",
                boxShadow: `0 8px 32px ${FUCHSIA}40`,
              }}
              onClick={onTryPoint}
              whileHover={{ scale: 1.04, boxShadow: `0 12px 40px ${FUCHSIA}50` }}
              whileTap={{ scale: 0.96 }}>
              <Heart size={18} fill="#fff" />
              OUVRIR POINT
            </motion.button>

            <p className="mt-6" style={{ fontSize: 10, color: "#ccc" }}>
              Gratuit · Sans inscription · Fonctionne sur mobile
            </p>
          </motion.div>
        </div>
      </section>

      {/* ═══ FOOTER ═══ */}
      <footer className="py-10 px-6 text-center"
        style={{ borderTop: "1px solid rgba(0,0,0,0.04)" }}>
        <div className="flex flex-col items-center gap-3">
          <span style={{ fontSize: 12, fontWeight: 700, background: GRADIENT, WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)" }}>
            POINT
          </span>
          <span style={{ fontSize: 9, color: "#ccc" }}>
            par StitchLab · Concept original 2003 · Made with ♥
          </span>
          <span style={{ fontSize: 8, color: "#ddd" }}>
            Interface récursive 8×8 · Brevet en cours d'étude
          </span>
        </div>
      </footer>
    </div>
  );
}