import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Download, Code, Sparkles, Box, Zap, Palette, Hash, Timer, StickyNote, Camera, Scissors, Share2, Pipette } from "lucide-react";
import { StitchDock } from "./StitchDock";
import { StitchLabLogo, StitchLabMark } from "./StitchLabLogo";

// ═══════════════════════════════════════════
// WIDGET SHOWCASE — Dark Edition
// Le widget rose émerge du noir absolu
// ═══════════════════════════════════════════

interface WidgetShowcaseProps {
  onBack: () => void;
}

const FEATURES = [
  { icon: Pipette, label: "DMC Finder", desc: "Choisis une couleur, trouve le fil DMC exact", color: "#C72B3B" },
  { icon: Hash, label: "Compteur", desc: "Compte tes points et tes rangs sans perdre le fil", color: "#E8177F" },
  { icon: Timer, label: "Timer", desc: "Chronomètre tes sessions, estime ta vitesse", color: "#42A350" },
  { icon: Palette, label: "Palette", desc: "Gère la palette DMC de ton projet en cours", color: "#4685B7" },
  { icon: StickyNote, label: "Notes", desc: "Notes rapides sans quitter ton ouvrage", color: "#FFB515" },
  { icon: Camera, label: "Pattern", desc: "Photo vers grille pixelisée en un clic", color: "#EB5B2E" },
  { icon: Scissors, label: "Lily IA", desc: "Conseils broderie instantanés par IA", color: "#9263A6" },
  { icon: Share2, label: "Partage", desc: "Exporte et partage ton avancement", color: "#6BA7B0" },
];

export function WidgetShowcase({ onBack }: WidgetShowcaseProps) {
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);

  return (
    <div
      className="min-h-screen w-full overflow-y-auto"
      style={{
        backgroundColor: "#0A0A0A",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      {/* HEADER — glass dark */}
      <motion.header
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4"
        style={{
          backgroundColor: "rgba(10,10,10,0.8)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid rgba(255,255,255,0.04)",
        }}
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center gap-3">
          <motion.button
            className="flex items-center justify-center rounded-xl border-none cursor-pointer"
            style={{
              width: 36, height: 36,
              backgroundColor: "rgba(255,255,255,0.06)",
              color: "rgba(255,255,255,0.5)",
            }}
            onClick={onBack}
            whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.1)" }}
            whileTap={{ scale: 0.9 }}
          >
            <ArrowLeft size={16} />
          </motion.button>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", letterSpacing: "0.1em", fontWeight: 300 }}>
            STITCHLAB
          </span>
        </div>
        <motion.button
          className="flex items-center gap-2 px-4 py-2 rounded-xl border-none cursor-pointer"
          style={{
            background: "linear-gradient(135deg, #E8177F, #9263A6)",
            color: "#fff",
            fontSize: 11,
            fontWeight: 500,
          }}
          whileHover={{ scale: 1.03, boxShadow: "0 4px 20px rgba(232,23,127,0.3)" }}
          whileTap={{ scale: 0.97 }}
        >
          <Download size={12} />
          Télécharger
        </motion.button>
      </motion.header>

      {/* ═══ HERO — Black void, widget emerges ═══ */}
      <section
        className="relative flex flex-col items-center justify-center px-6"
        style={{ minHeight: "100vh" }}
      >
        {/* Subtle radial glow behind widget */}
        <motion.div
          className="absolute pointer-events-none"
          style={{
            width: 600,
            height: 600,
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            background: "radial-gradient(circle, rgba(232,23,127,0.06) 0%, rgba(146,99,166,0.03) 40%, rgba(0,0,0,0) 70%)",
          }}
          animate={{ scale: [1, 1.15, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Floating grid dots in background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 40 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full"
              style={{
                width: 2,
                height: 2,
                backgroundColor: i % 5 === 0 ? "rgba(232,23,127,0.2)" : "rgba(255,255,255,0.04)",
                left: `${5 + (i * 17) % 90}%`,
                top: `${8 + (i * 23) % 85}%`,
              }}
              animate={{
                opacity: [0.2, 0.6, 0.2],
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 3 + (i % 4),
                repeat: Infinity,
                delay: i * 0.15,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* NOUVEAU badge */}
        <motion.div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full mb-8"
          style={{
            backgroundColor: "rgba(232,23,127,0.08)",
            border: "1px solid rgba(232,23,127,0.15)",
          }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Sparkles size={10} color="#E8177F" />
          <span style={{ fontSize: 10, color: "#E8177F", fontWeight: 500, letterSpacing: "0.06em" }}>
            NOUVEAU
          </span>
        </motion.div>

        {/* Title */}
        <motion.h1
          className="text-center"
          style={{
            fontSize: "clamp(28px, 5.5vw, 52px)",
            fontWeight: 200,
            color: "#fff",
            lineHeight: 1.2,
            letterSpacing: "-0.02em",
            marginBottom: 16,
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          Un carré.
          <br />
          <span style={{ fontWeight: 500 }}>Huit outils.</span>
          <br />
          <span
            style={{
              background: "linear-gradient(135deg, #E8177F, #9263A6)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Tout l'art
          </span>{" "}
          de broder.
        </motion.h1>

        <motion.p
          className="text-center max-w-md"
          style={{ fontSize: 14, color: "rgba(255,255,255,0.35)", lineHeight: 1.8, fontWeight: 300 }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <strong style={{ color: "rgba(255,255,255,0.6)" }}>StitchDock</strong> déploie 8 micro-outils de broderie
          depuis un seul carré. Comme un point de croix qui s'ouvre.
        </motion.p>

        {/* ═══ THE WIDGET — the star of the show ═══ */}
        <motion.div
          className="relative mt-16 mb-8 flex items-center justify-center"
          initial={{ opacity: 0, scale: 0.6, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 1.2, type: "spring", stiffness: 60 }}
        >
          {/* Pink glow behind widget */}
          <motion.div
            className="absolute rounded-full pointer-events-none"
            style={{
              width: 250,
              height: 250,
              background: "radial-gradient(circle, rgba(232,23,127,0.12) 0%, rgba(146,99,166,0.05) 50%, rgba(0,0,0,0) 70%)",
            }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
          <StitchDock cellSize={56} showcase />
        </motion.div>

        <motion.p
          style={{ fontSize: 11, color: "rgba(255,255,255,0.2)", fontStyle: "italic" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8 }}
        >
          Clique le carré noir pour ouvrir
        </motion.p>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.3 }}
          transition={{ delay: 2.5 }}
        >
          <motion.div
            className="w-px"
            style={{ height: 32, backgroundColor: "rgba(255,255,255,0.2)" }}
            animate={{ scaleY: [0.3, 1, 0.3] }}
            transition={{ duration: 2.5, repeat: Infinity }}
          />
          <span style={{ fontSize: 8, color: "rgba(255,255,255,0.2)", letterSpacing: "0.12em" }}>scroll</span>
        </motion.div>
      </section>

      {/* ═══ CONCEPT — La grille est l'interface ═══ */}
      <section className="py-24 px-6">
        <motion.div
          className="max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-3 mb-8">
            <Box size={14} color="rgba(255,255,255,0.2)" strokeWidth={1} />
            <span style={{ fontSize: 9, letterSpacing: "0.16em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase", fontWeight: 400 }}>
              Le concept
            </span>
          </div>

          <h2 style={{ fontSize: 28, fontWeight: 200, color: "#fff", lineHeight: 1.4, marginBottom: 16 }}>
            La grille <em style={{ fontStyle: "italic", color: "#E8177F" }}>est</em> l'interface
          </h2>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.35)", lineHeight: 1.9, maxWidth: 520, fontWeight: 300 }}>
            En broderie, tout commence par une grille. StitchDock prend cette métaphore au pied de la lettre :
            <strong style={{ color: "rgba(255,255,255,0.6)" }}> un carré central déploie 8 carrés autour de lui</strong> — exactement
            comme les 8 voisins d'un point sur une toile Aida.
          </p>

          {/* Grid metaphor */}
          <div className="mt-14 flex items-center justify-center gap-12">
            <div className="flex flex-col items-center gap-3">
              <div className="grid grid-cols-3 gap-[2px]">
                {Array.from({ length: 9 }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="rounded-[3px]"
                    style={{
                      width: 26, height: 26,
                      backgroundColor: i === 4 ? "#fff" : "rgba(255,255,255,0.06)",
                      border: i !== 4 ? "1px solid rgba(255,255,255,0.06)" : "none",
                    }}
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.06 * i }}
                  />
                ))}
              </div>
              <span style={{ fontSize: 9, color: "rgba(255,255,255,0.15)", letterSpacing: "0.06em" }}>Grille Aida</span>
            </div>

            <motion.div
              style={{ fontSize: 18, color: "rgba(255,255,255,0.1)" }}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
            >
              →
            </motion.div>

            <div className="flex flex-col items-center gap-3">
              <div className="grid grid-cols-3 gap-[2px]">
                {[
                  "#C72B3B", "#E8177F", "#42A350",
                  "#6BA7B0", "#1a1a1a", "#4685B7",
                  "#EB5B2E", "#9263A6", "#FFB515",
                ].map((color, i) => (
                  <motion.div
                    key={i}
                    className="rounded-[3px] flex items-center justify-center"
                    style={{
                      width: 26, height: 26,
                      backgroundColor: i === 4 ? color : `${color}20`,
                      border: i !== 4 ? `1px solid ${color}30` : "none",
                      boxShadow: i !== 4 ? `0 0 12px ${color}10` : "none",
                    }}
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.06 * i + 0.3 }}
                  >
                    {i === 4 && <StitchLabMark size={10} animate={false} />}
                  </motion.div>
                ))}
              </div>
              <span style={{ fontSize: 9, color: "rgba(255,255,255,0.15)", letterSpacing: "0.06em" }}>StitchDock</span>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ═══ 8 TOOLS ═══ */}
      <section className="py-24 px-6" style={{ backgroundColor: "rgba(255,255,255,0.015)" }}>
        <motion.div
          className="max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center gap-3 mb-8">
            <Zap size={14} color="rgba(255,255,255,0.2)" strokeWidth={1} />
            <span style={{ fontSize: 9, letterSpacing: "0.16em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase", fontWeight: 400 }}>
              8 outils
            </span>
          </div>

          <h2 style={{ fontSize: 28, fontWeight: 200, color: "#fff", lineHeight: 1.4, marginBottom: 32 }}>
            Tout ce dont une brodeuse a besoin.
            <br />
            <span style={{ color: "rgba(255,255,255,0.25)" }}>Dans un widget de 150 pixels.</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.label}
                className="flex items-start gap-3 rounded-2xl px-5 py-4 cursor-default"
                style={{
                  backgroundColor: hoveredFeature === i ? `${f.color}10` : "rgba(255,255,255,0.02)",
                  border: `1px solid ${hoveredFeature === i ? `${f.color}25` : "rgba(255,255,255,0.04)"}`,
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={() => setHoveredFeature(i)}
                onMouseLeave={() => setHoveredFeature(null)}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{ backgroundColor: `${f.color}12` }}
                >
                  <f.icon size={14} color={f.color} strokeWidth={1.5} />
                </div>
                <div className="flex flex-col gap-0.5">
                  <span style={{ fontSize: 12, fontWeight: 500, color: "rgba(255,255,255,0.85)" }}>{f.label}</span>
                  <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", lineHeight: 1.5 }}>{f.desc}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ═══ CODE / DEVELOPER ═══ */}
      <section className="py-24 px-6">
        <motion.div
          className="max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center gap-3 mb-8">
            <Code size={14} color="rgba(255,255,255,0.2)" strokeWidth={1} />
            <span style={{ fontSize: 9, letterSpacing: "0.16em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase", fontWeight: 400 }}>
              Intégrer
            </span>
          </div>

          <h2 style={{ fontSize: 28, fontWeight: 200, color: "#fff", lineHeight: 1.4, marginBottom: 16 }}>
            Un composant React.
            <br />
            <span style={{ color: "rgba(255,255,255,0.25)" }}>Une ligne de code.</span>
          </h2>

          {/* Code block */}
          <div
            className="rounded-2xl overflow-hidden mt-8"
            style={{
              backgroundColor: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <div className="flex items-center gap-1.5 px-4 py-2.5" style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#ff5f57" }} />
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#febd2e" }} />
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#27c840" }} />
              <span style={{ fontSize: 9, color: "rgba(255,255,255,0.2)", marginLeft: 8 }}>App.tsx</span>
            </div>
            <pre className="px-5 py-4 overflow-x-auto" style={{ fontSize: 12, lineHeight: 1.8, margin: 0 }}>
              <code>
                <span style={{ color: "#C792EA" }}>import</span>
                <span style={{ color: "rgba(255,255,255,0.7)" }}> {"{ StitchDock }"} </span>
                <span style={{ color: "#C792EA" }}>from</span>
                <span style={{ color: "#C3E88D" }}> "@stitchlab/dock"</span>
                <span style={{ color: "rgba(255,255,255,0.2)" }}>;</span>
                {"\n\n"}
                <span style={{ color: "rgba(255,255,255,0.2)" }}>{"// Flottant, coin bas-droit"}</span>
                {"\n"}
                <span style={{ color: "#89DDFF" }}>{"<"}</span>
                <span style={{ color: "#FFCB6B" }}>StitchDock</span>
                <span style={{ color: "#89DDFF" }}>{" />"}</span>
                {"\n\n"}
                <span style={{ color: "rgba(255,255,255,0.2)" }}>{"// Taille personnalisée"}</span>
                {"\n"}
                <span style={{ color: "#89DDFF" }}>{"<"}</span>
                <span style={{ color: "#FFCB6B" }}>StitchDock</span>
                <span style={{ color: "#C792EA" }}> cellSize</span>
                <span style={{ color: "#89DDFF" }}>{"={"}</span>
                <span style={{ color: "#F78C6C" }}>48</span>
                <span style={{ color: "#89DDFF" }}>{"}"}</span>
                <span style={{ color: "#89DDFF" }}>{" />"}</span>
              </code>
            </pre>
          </div>

          {/* Usage ideas */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { title: "Blog broderie", desc: "Widget flottant pour tes lectrices" },
              { title: "Boutique Etsy", desc: "Aide intégrée à tes fiches produit" },
              { title: "App mobile", desc: "Hub compact pour brodeuses en mouvement" },
            ].map((use) => (
              <div
                key={use.title}
                className="rounded-xl px-4 py-3"
                style={{
                  backgroundColor: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.04)",
                }}
              >
                <p style={{ fontSize: 11, fontWeight: 500, color: "rgba(255,255,255,0.7)", marginBottom: 2 }}>{use.title}</p>
                <p style={{ fontSize: 10, color: "rgba(255,255,255,0.2)" }}>{use.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ═══ CTA ═══ */}
      <section className="py-24 px-6 flex flex-col items-center relative">
        {/* Glow */}
        <div
          className="absolute pointer-events-none"
          style={{
            width: 400,
            height: 400,
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            background: "radial-gradient(circle, rgba(232,23,127,0.04) 0%, rgba(0,0,0,0) 60%)",
          }}
        />
        <motion.div
          className="relative flex flex-col items-center gap-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <StitchLabMark size={24} animate />
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.3)", textAlign: "center", maxWidth: 400, lineHeight: 1.8, fontWeight: 300 }}>
            StitchDock sera disponible en widget React autonome, extension Chrome,
            et bientôt en app iOS. Un seul carré pour toute ta broderie.
          </p>
          <div className="flex items-center gap-3 flex-wrap justify-center">
            <motion.button
              className="flex items-center gap-2 px-6 py-3 rounded-xl border-none cursor-pointer"
              style={{
                background: "linear-gradient(135deg, #E8177F, #9263A6)",
                color: "#fff",
                fontSize: 13,
                fontWeight: 500,
                boxShadow: "0 4px 20px rgba(232,23,127,0.25)",
              }}
              whileHover={{ scale: 1.03, boxShadow: "0 6px 30px rgba(232,23,127,0.35)" }}
              whileTap={{ scale: 0.97 }}
            >
              <Download size={14} />
              Être notifié au lancement
            </motion.button>
            <motion.button
              className="flex items-center gap-2 px-6 py-3 rounded-xl border-none cursor-pointer"
              style={{
                backgroundColor: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.06)",
                color: "rgba(255,255,255,0.5)",
                fontSize: 13,
                fontWeight: 400,
              }}
              onClick={onBack}
              whileHover={{ scale: 1.03, backgroundColor: "rgba(255,255,255,0.06)" }}
              whileTap={{ scale: 0.97 }}
            >
              Retour à StitchLab
            </motion.button>
          </div>
        </motion.div>
      </section>

      {/* FOOTER */}
      <footer className="py-8 px-6 flex items-center justify-center" style={{ borderTop: "1px solid rgba(255,255,255,0.03)" }}>
        <span style={{ fontSize: 9, color: "rgba(255,255,255,0.1)", letterSpacing: "0.08em" }}>
          STITCHDOCK par STITCHLAB — 2026
        </span>
      </footer>
    </div>
  );
}
