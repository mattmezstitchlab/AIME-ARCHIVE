import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Map, X, Locate, Maximize2, Minimize2 } from "lucide-react";
import { useResponsive } from "./useResponsive";
import {
  MOCK_PLAYERS,
  BONUS_SQUARES,
  PATTERN_ZONES,
  BG_IVORY,
  HEART_RED,
  SORTIE_COLOR,
  type PlayerData,
  type Heartbeat,
  type SortieEvent,
  type AccessibilityMode,
} from "./game-data";

interface MinimapProps {
  playerPos: { x: number; y: number };
  currentPlayer: PlayerData;
  trail: { x: number; y: number }[];
  heartbeats: Heartbeat[];
  sorties: SortieEvent[];
  discoveredBonuses: Set<string>;
  mode: AccessibilityMode;
  onTeleport: (x: number, y: number) => void;
}

function computeBounds(
  playerPos: { x: number; y: number },
  trail: { x: number; y: number }[],
  heartbeats: Heartbeat[],
  sorties: SortieEvent[],
) {
  let minX = playerPos.x, maxX = playerPos.x, minY = playerPos.y, maxY = playerPos.y;
  const expand = (x: number, y: number) => {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
  };
  MOCK_PLAYERS.forEach((p) => expand(p.x, p.y));
  BONUS_SQUARES.forEach((b) => expand(b.x, b.y));
  heartbeats.forEach((h) => expand(h.x, h.y));
  sorties.forEach((s) => expand(s.x, s.y));
  trail.forEach((t) => expand(t.x, t.y));
  PATTERN_ZONES.forEach((z) => {
    expand(z.cx - z.radius, z.cy - z.radius);
    expand(z.cx + z.radius, z.cy + z.radius);
  });
  const pad = 3;
  return { minX: minX - pad, maxX: maxX + pad, minY: minY - pad, maxY: maxY + pad };
}

export function Minimap({
  playerPos,
  currentPlayer,
  trail,
  heartbeats,
  sorties,
  discoveredBonuses,
  mode,
  onTeleport,
}: MinimapProps) {
  const { isMobile, isTablet } = useResponsive();
  const [open, setOpen] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const isSenior = mode === "senior";

  const baseMapW = isMobile ? 160 : isTablet ? 180 : isSenior ? 240 : 200;
  const baseMapH = isMobile ? 130 : isTablet ? 150 : isSenior ? 200 : 170;
  const mapW = fullscreen ? (isMobile ? window.innerWidth - 40 : window.innerWidth - 80) : baseMapW;
  const mapH = fullscreen ? (isMobile ? window.innerHeight - 120 : window.innerHeight - 160) : baseMapH;

  const bounds = useMemo(
    () => computeBounds(playerPos, trail, heartbeats, sorties),
    [playerPos, trail, heartbeats, sorties],
  );

  const worldW = bounds.maxX - bounds.minX || 1;
  const worldH = bounds.maxY - bounds.minY || 1;
  const scale = Math.min(mapW / worldW, mapH / worldH) * 0.88;

  const toScreen = useCallback(
    (wx: number, wy: number) => ({
      sx: mapW / 2 + (wx - (bounds.minX + worldW / 2)) * scale,
      sy: mapH / 2 + (wy - (bounds.minY + worldH / 2)) * scale,
    }),
    [bounds, worldW, worldH, scale, mapW, mapH],
  );

  const fromScreen = useCallback(
    (sx: number, sy: number) => ({
      wx: Math.round((sx - mapW / 2) / scale + bounds.minX + worldW / 2),
      wy: Math.round((sy - mapH / 2) / scale + bounds.minY + worldH / 2),
    }),
    [bounds, worldW, worldH, scale, mapW, mapH],
  );

  const handleMapClick = useCallback(
    (e: React.MouseEvent<SVGSVGElement>) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      const { wx, wy } = fromScreen(sx, sy);
      onTeleport(wx, wy);
    },
    [fromScreen, onTeleport],
  );

  // Pre-render all dots
  const dots = useMemo(() => {
    const result: React.ReactNode[] = [];

    // Pattern zones
    PATTERN_ZONES.forEach((z) => {
      const { sx, sy } = toScreen(z.cx, z.cy);
      const r = z.radius * scale;
      result.push(
        <circle key={`zone-${z.name}`} cx={sx} cy={sy} r={r}
          fill="rgba(0,0,0,0.02)" stroke="rgba(0,0,0,0.04)" strokeWidth={0.5} strokeDasharray="2 2" />,
      );
      if (fullscreen) {
        result.push(
          <text key={`zl-${z.name}`} x={sx} y={sy + r + 10}
            textAnchor="middle" fill="#ccc" fontSize={8} fontWeight={300}>
            {z.name}
          </text>,
        );
      }
    });

    // Trail
    if (trail.length > 1) {
      const points = trail.map((t) => { const { sx, sy } = toScreen(t.x, t.y); return `${sx},${sy}`; });
      result.push(
        <polyline key="trail" points={points.join(" ")} fill="none"
          stroke={currentPlayer.colorHex} strokeWidth={fullscreen ? 2 : 1.2}
          strokeLinecap="round" strokeLinejoin="round" opacity={0.35} />,
      );
    }

    // Bonuses
    BONUS_SQUARES.forEach((b) => {
      const key = `${b.x},${b.y}`;
      if (discoveredBonuses.has(key)) {
        const { sx, sy } = toScreen(b.x, b.y);
        const sz = fullscreen ? 5 : 3;
        result.push(
          <rect key={`bonus-${key}`} x={sx - sz / 2} y={sy - sz / 2} width={sz} height={sz}
            rx={0.5} fill={b.colorHex || "#E8D06A"} opacity={0.6} />,
        );
      }
    });

    // Heartbeats
    heartbeats.forEach((h) => {
      const { sx, sy } = toScreen(h.x, h.y);
      const s = fullscreen ? 1.5 : 1;
      result.push(
        <g key={`hb-${h.id}`}>
          <circle cx={sx} cy={sy} r={4 * s} fill={HEART_RED} opacity={0.08} />
          <circle cx={sx} cy={sy} r={2.5 * s} fill={HEART_RED} opacity={0.2} />
          <circle cx={sx} cy={sy} r={1.2 * s} fill={HEART_RED} opacity={0.5} />
        </g>,
      );
    });

    // Sorties (amber diamonds)
    sorties.forEach((s) => {
      const { sx, sy } = toScreen(s.x, s.y);
      const sz = fullscreen ? 7 : 5;
      result.push(
        <g key={`sortie-${s.id}`}>
          <circle cx={sx} cy={sy} r={sz + 3} fill={`${SORTIE_COLOR}10`} />
          <rect x={sx - sz / 2} y={sy - sz / 2} width={sz} height={sz}
            rx={1} fill={SORTIE_COLOR} stroke="#fff" strokeWidth={0.8}
            transform={`rotate(45 ${sx} ${sy})`} />
          {fullscreen && (
            <text x={sx} y={sy + sz + 10} textAnchor="middle" fill={SORTIE_COLOR} fontSize={7} fontWeight={400}>
              {s.title.length > 16 ? s.title.slice(0, 14) + "…" : s.title}
            </text>
          )}
        </g>,
      );
    });

    // Players
    MOCK_PLAYERS.forEach((p) => {
      const { sx, sy } = toScreen(p.x, p.y);
      const sz = fullscreen ? 8 : 5;
      result.push(
        <g key={`player-${p.id}`}>
          <rect x={sx - sz / 2} y={sy - sz / 2} width={sz} height={sz}
            rx={fullscreen ? 1.5 : 0.8} fill={p.colorHex}
            stroke="rgba(255,255,255,0.6)" strokeWidth={fullscreen ? 1 : 0.5} />
          {fullscreen && (
            <text x={sx} y={sy + sz / 2 + 10} textAnchor="middle" fill="#aaa" fontSize={7} fontWeight={300}>
              {p.pseudo}
            </text>
          )}
        </g>,
      );
    });

    return result;
  }, [toScreen, trail, currentPlayer, heartbeats, sorties, discoveredBonuses, fullscreen, scale]);

  const playerScreen = useMemo(() => toScreen(playerPos.x, playerPos.y), [toScreen, playerPos]);

  const viewportRect = useMemo(() => {
    const viewCells = 12;
    const halfW = viewCells * scale;
    const halfH = viewCells * scale * 0.7;
    return { x: playerScreen.sx - halfW, y: playerScreen.sy - halfH, w: halfW * 2, h: halfH * 2 };
  }, [playerScreen, scale]);

  return (
    <>
      {/* Toggle button */}
      <motion.button
        className="fixed z-40 flex items-center justify-center rounded-full cursor-pointer border-none"
        style={{
          left: isMobile ? 10 : 16,
          bottom: isMobile ? 150 : isTablet ? 170 : isSenior ? 240 : 190,
          width: isMobile ? 30 : isSenior ? 42 : 36,
          height: isMobile ? 30 : isSenior ? 42 : 36,
          backgroundColor: open ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.75)",
          backdropFilter: "blur(12px)", boxShadow: "0 1px 8px rgba(0,0,0,0.04)",
          color: open ? "#666" : "#aaa",
        }}
        onClick={() => { setOpen((v) => !v); if (open) setFullscreen(false); }}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        aria-label="Carte du monde"
      >
        {open ? <X size={isMobile ? 12 : 15} /> : <Map size={isMobile ? 12 : 15} />}
      </motion.button>

      {/* Map panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed z-35 rounded-2xl overflow-hidden"
            style={{
              left: fullscreen ? (isMobile ? 10 : 40) : (isMobile ? 10 : 16),
              bottom: fullscreen ? (isMobile ? 10 : 40) : (isMobile ? 188 : isTablet ? 210 : isSenior ? 290 : 234),
              width: fullscreen ? (isMobile ? "calc(100vw - 20px)" : "calc(100vw - 80px)") : baseMapW + 24,
              backgroundColor: "rgba(255,255,255,0.92)",
              backdropFilter: "blur(20px)",
              boxShadow: "0 8px 40px rgba(0,0,0,0.07), 0 0 0 1px rgba(0,0,0,0.03)",
            }}
            initial={{ opacity: 0, y: 12, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.96 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            layout
          >
            {/* Header */}
            <div className="flex items-center justify-between px-3 pt-2.5 pb-1">
              <div className="flex items-center gap-1.5">
                <span style={{ fontSize: 8, letterSpacing: "0.15em", color: "#bbb", fontWeight: 500, textTransform: "uppercase" }}>
                  {fullscreen ? "Vue satellite" : "Mappemonde"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span style={{ fontSize: 9, color: "#ccc", fontVariantNumeric: "tabular-nums" }}>
                  <Locate size={9} color="#ccc" strokeWidth={1.5} style={{ display: "inline", marginRight: 3, verticalAlign: "middle" }} />
                  {playerPos.x}, {playerPos.y}
                </span>
                <button
                  onClick={() => setFullscreen((v) => !v)}
                  className="flex items-center justify-center w-5 h-5 rounded cursor-pointer border-none"
                  style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#bbb" }}
                >
                  {fullscreen ? <Minimize2 size={10} /> : <Maximize2 size={10} />}
                </button>
              </div>
            </div>

            {/* Hint */}
            <div className="px-3 pb-0.5">
              <span style={{ fontSize: 7, color: "#ccc", fontWeight: 300 }}>
                Cliquez pour vous téléporter
              </span>
            </div>

            {/* SVG Map */}
            <div className="px-3 pb-3">
              <svg
                width={mapW}
                height={mapH}
                viewBox={`0 0 ${mapW} ${mapH}`}
                style={{
                  borderRadius: 10,
                  backgroundColor: BG_IVORY,
                  border: "1px solid rgba(0,0,0,0.03)",
                  cursor: "crosshair",
                }}
                onClick={handleMapClick}
              >
                {/* Grid */}
                <defs>
                  <pattern id="minimapGrid" width={scale} height={scale}
                    patternUnits="userSpaceOnUse"
                    patternTransform={`translate(${playerScreen.sx % scale} ${playerScreen.sy % scale})`}>
                    <rect width={scale} height={scale} fill="none" stroke="rgba(0,0,0,0.03)" strokeWidth={0.3} />
                  </pattern>
                </defs>
                <rect width={mapW} height={mapH} fill="url(#minimapGrid)" />

                {/* Origin crosshair */}
                {(() => {
                  const { sx, sy } = toScreen(0, 0);
                  return (
                    <g opacity={0.08}>
                      <line x1={sx} y1={0} x2={sx} y2={mapH} stroke="#000" strokeWidth={0.5} strokeDasharray="3 3" />
                      <line x1={0} y1={sy} x2={mapW} y2={sy} stroke="#000" strokeWidth={0.5} strokeDasharray="3 3" />
                    </g>
                  );
                })()}

                {dots}

                {/* Viewport rect */}
                <rect x={viewportRect.x} y={viewportRect.y} width={viewportRect.w} height={viewportRect.h}
                  fill="rgba(0,0,0,0.02)" stroke="rgba(0,0,0,0.12)" strokeWidth={0.8} rx={2} strokeDasharray="3 2" />

                {/* Current player */}
                <rect x={playerScreen.sx - 3.5} y={playerScreen.sy - 3.5} width={7} height={7}
                  rx={1} fill={currentPlayer.colorHex} stroke="#fff" strokeWidth={1.5} />
                <rect x={playerScreen.sx - 5} y={playerScreen.sy - 5} width={10} height={10}
                  rx={2} fill="none" stroke={currentPlayer.colorHex} strokeWidth={0.8} opacity={0.4} />
                {fullscreen && (
                  <text x={playerScreen.sx} y={playerScreen.sy + 14} textAnchor="middle"
                    fill={currentPlayer.colorHex} fontSize={9} fontWeight={500}>
                    {currentPlayer.pseudo} (vous)
                  </text>
                )}
              </svg>

              {/* Legend */}
              <div className="flex items-center gap-3 mt-2 flex-wrap" style={{ fontSize: 8, color: "#bbb", fontWeight: 300 }}>
                <LegendDot color={currentPlayer.colorHex} label="Vous" ring />
                <LegendDot color="#4685B7" label="Joueurs" />
                <LegendDot color={HEART_RED} label="Battements" pulse />
                <LegendDot color={SORTIE_COLOR} label="Sorties" diamond />
                <LegendDot color="#E8D06A" label="Bonus" />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function LegendDot({ color, label, ring, pulse, diamond }: {
  color: string; label: string; ring?: boolean; pulse?: boolean; diamond?: boolean;
}) {
  return (
    <span className="flex items-center gap-1">
      <span
        style={{
          display: "inline-block",
          width: 6, height: 6,
          borderRadius: ring ? 1 : pulse ? 3 : diamond ? 0 : 1,
          backgroundColor: color,
          border: ring ? `1px solid ${color}` : "none",
          boxShadow: pulse ? `0 0 3px ${color}60` : "none",
          transform: diamond ? "rotate(45deg) scale(0.8)" : "none",
          opacity: 0.7,
        }}
      />
      {label}
    </span>
  );
}