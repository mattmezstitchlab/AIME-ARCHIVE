import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayerSquare } from "./PlayerSquare";
import { useResponsive } from "./useResponsive";
import { HEART_RED, BG_IVORY, DMC_COLORS } from "./game-data";
import { ArrowLeft, Compass, X } from "lucide-react";

// ═══════════════════════════════════════════
// MAP EXPLORER — Walk the cross-stitch grid
// Discover the iPad, concept leaves, and more
// ═══════════════════════════════════════════

const CELL = 36;
const MAP_CELLS = 80;
const MAP_PX = MAP_CELLS * CELL;

// Items on the map
const IPAD_POS = { x: 40, y: 26 };

const LEAVES: {
  x: number;
  y: number;
  label: string;
  desc: string;
  color: string;
  emoji: string;
  angle: number;
}[] = [
  { x: 36, y: 23, label: "POINT", desc: "Le cube interactif — 6 faces, 6 dimensions de ton intention créative.", color: "#E8177F", emoji: "♥", angle: -8 },
  { x: 44, y: 24, label: "Pattern", desc: "Transforme n'importe quelle image en grille de broderie point par point.", color: "#9263A6", emoji: "✦", angle: 12 },
  { x: 37, y: 29, label: "Lily", desc: "L'IA créative qui t'accompagne — elle brode des réponses avec toi.", color: "#9263A6", emoji: "✂", angle: -5 },
  { x: 44, y: 28, label: "Carte", desc: "Une grille infinie, géolocalisée. Chaque point = une connexion humaine.", color: "#22A652", emoji: "🗺", angle: 7 },
  { x: 40, y: 32, label: "StitchDock", desc: "8 outils de broderie dans un widget — compteur, timer, palette DMC…", color: "#E8177F", emoji: "◆", angle: -3 },
];

// Decorative ambient stitches
const AMBIENT_STITCHES = Array.from({ length: 40 }).map((_, i) => {
  const normalColors = DMC_COLORS.filter((c) => !c.rare);
  return {
    x: 10 + ((i * 17 + 3) % 60),
    y: 10 + ((i * 23 + 7) % 60),
    color: normalColors[i % normalColors.length].hex,
    symbol: ["✳", "◆", "●", "■", "✦", "○", "□", "△"][i % 8],
    opacity: 0.06 + (i % 5) * 0.02,
  };
});

interface MapExplorerProps {
  onDiscoverPattern: () => void;
  onBack: () => void;
}

export function MapExplorer({ onDiscoverPattern, onBack }: MapExplorerProps) {
  const { isMobile } = useResponsive();
  const [playerPos, setPlayerPos] = useState({ x: 40, y: 40 });
  const [targetPos, setTargetPos] = useState<{ x: number; y: number } | null>(null);
  const [trail, setTrail] = useState<{ x: number; y: number }[]>([]);
  const [selectedLeaf, setSelectedLeaf] = useState<number | null>(null);
  const [iPadNear, setIPadNear] = useState(false);
  const [iPadActivated, setIPadActivated] = useState(false);
  const [showCompass, setShowCompass] = useState(true);
  const mapRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number>(0);

  // Camera position (centered on player)
  const cameraX = -(playerPos.x * CELL) + (typeof window !== "undefined" ? window.innerWidth / 2 : 400);
  const cameraY = -(playerPos.y * CELL) + (typeof window !== "undefined" ? window.innerHeight / 2 : 400);

  // Distance to iPad
  const distToIPad = Math.sqrt(
    Math.pow(playerPos.x - IPAD_POS.x, 2) + Math.pow(playerPos.y - IPAD_POS.y, 2)
  );

  // Check iPad proximity
  useEffect(() => {
    setIPadNear(distToIPad < 3);
  }, [distToIPad]);

  // Walking animation
  useEffect(() => {
    if (!targetPos) return;

    let lastTime = performance.now();
    const trailSet = new Set(trail.map((t) => `${t.x},${t.y}`));

    const step = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;

      setPlayerPos((prev) => {
        const dx = targetPos.x - prev.x;
        const dy = targetPos.y - prev.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 0.4) {
          setTargetPos(null);
          return { x: targetPos.x, y: targetPos.y };
        }

        const speed = 6;
        const move = Math.min(speed * dt, dist);
        const nx = prev.x + (dx / dist) * move;
        const ny = prev.y + (dy / dist) * move;

        // Add to trail
        const rx = Math.round(nx);
        const ry = Math.round(ny);
        const key = `${rx},${ry}`;
        if (!trailSet.has(key)) {
          trailSet.add(key);
          setTrail((p) => [...p.slice(-80), { x: rx, y: ry }]);
        }

        return { x: nx, y: ny };
      });

      rafRef.current = requestAnimationFrame(step);
    };

    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, [targetPos]);

  // Handle map click
  const handleMapClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (selectedLeaf !== null) {
        setSelectedLeaf(null);
        return;
      }
      if (!mapRef.current) return;
      const rect = mapRef.current.getBoundingClientRect();
      const mx = (e.clientX - rect.left) / CELL;
      const my = (e.clientY - rect.top) / CELL;
      // Clamp to map bounds
      const tx = Math.max(2, Math.min(MAP_CELLS - 2, mx));
      const ty = Math.max(2, Math.min(MAP_CELLS - 2, my));
      setTargetPos({ x: tx, y: ty });
    },
    [selectedLeaf]
  );

  // Handle iPad click
  const handleIPadClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (distToIPad < 3) {
      setIPadActivated(true);
      setTimeout(() => onDiscoverPattern(), 800);
    } else {
      // Walk to iPad
      setTargetPos({ x: IPAD_POS.x, y: IPAD_POS.y + 2 });
    }
  };

  // Handle leaf click
  const handleLeafClick = (e: React.MouseEvent, idx: number) => {
    e.stopPropagation();
    const leaf = LEAVES[idx];
    const dist = Math.sqrt(
      Math.pow(playerPos.x - leaf.x, 2) + Math.pow(playerPos.y - leaf.y, 2)
    );
    if (dist < 3) {
      setSelectedLeaf(idx);
    } else {
      setTargetPos({ x: leaf.x, y: leaf.y + 1 });
    }
  };

  // Compass direction to iPad
  const angleToIPad = Math.atan2(IPAD_POS.y - playerPos.y, IPAD_POS.x - playerPos.x);
  const compassDeg = (angleToIPad * 180) / Math.PI - 90;

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ backgroundColor: BG_IVORY }}>
      {/* Zoomout transition */}
      <AnimatePresence>
        {iPadActivated && (
          <motion.div
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "#000" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          />
        )}
      </AnimatePresence>

      {/* THE MAP */}
      <motion.div
        ref={mapRef}
        className="absolute"
        style={{
          width: MAP_PX,
          height: MAP_PX,
          cursor: "crosshair",
        }}
        animate={{ x: cameraX, y: cameraY }}
        transition={{ type: "spring", stiffness: 50, damping: 18 }}
        onClick={handleMapClick}
      >
        {/* Grid lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ opacity: 0.06 }}>
          <defs>
            <pattern id="mapGrid" width={CELL} height={CELL} patternUnits="userSpaceOnUse">
              <path d={`M ${CELL} 0 L 0 0 0 ${CELL}`} fill="none" stroke="#000" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#mapGrid)" />
        </svg>

        {/* Ambient decorative stitches */}
        {AMBIENT_STITCHES.map((s, i) => (
          <div
            key={`amb-${i}`}
            className="absolute pointer-events-none select-none"
            style={{
              left: s.x * CELL + 4,
              top: s.y * CELL + 4,
              width: CELL - 8,
              height: CELL - 8,
              backgroundColor: s.color,
              opacity: s.opacity,
              borderRadius: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 10,
              color: "rgba(255,255,255,0.5)",
            }}
          >
            {s.symbol}
          </div>
        ))}

        {/* Trail */}
        {trail.map((t, i) => (
          <motion.div
            key={`trail-${t.x}-${t.y}-${i}`}
            className="absolute rounded-sm pointer-events-none"
            style={{
              left: t.x * CELL + 6,
              top: t.y * CELL + 6,
              width: CELL - 12,
              height: CELL - 12,
              backgroundColor: HEART_RED,
            }}
            initial={{ opacity: 0.2, scale: 0.5 }}
            animate={{ opacity: 0.06, scale: 1 }}
            transition={{ duration: 2 }}
          />
        ))}

        {/* ═══ CONCEPT LEAVES ═══ */}
        {LEAVES.map((leaf, idx) => {
          const leafDist = Math.sqrt(
            Math.pow(playerPos.x - leaf.x, 2) + Math.pow(playerPos.y - leaf.y, 2)
          );
          const isNear = leafDist < 3;
          return (
            <motion.div
              key={`leaf-${idx}`}
              className="absolute cursor-pointer"
              style={{
                left: leaf.x * CELL - 14,
                top: leaf.y * CELL - 14,
                width: CELL + 28,
                height: CELL + 20,
                zIndex: 5,
              }}
              onClick={(e) => handleLeafClick(e, idx)}
            >
              <motion.div
                className="w-full h-full rounded-md flex flex-col items-center justify-center gap-1 select-none"
                style={{
                  backgroundColor: "#fff",
                  border: `1px solid ${isNear ? leaf.color + "40" : "rgba(0,0,0,0.06)"}`,
                  boxShadow: isNear
                    ? `0 4px 16px ${leaf.color}20, 0 1px 3px rgba(0,0,0,0.05)`
                    : "0 1px 4px rgba(0,0,0,0.04)",
                  transform: `rotate(${leaf.angle}deg)`,
                }}
                animate={isNear ? { y: [-1, -4, -1], scale: 1.08 } : { y: 0, scale: 1 }}
                transition={isNear ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : { duration: 0.3 }}
              >
                <span style={{ fontSize: 16 }}>{leaf.emoji}</span>
                <span style={{ fontSize: 7, fontWeight: 600, color: leaf.color, letterSpacing: "0.08em" }}>
                  {leaf.label}
                </span>
              </motion.div>
            </motion.div>
          );
        })}

        {/* ═══ THE IPAD ═══ */}
        <motion.div
          className="absolute cursor-pointer"
          style={{
            left: IPAD_POS.x * CELL - 40,
            top: IPAD_POS.y * CELL - 55,
            width: 116,
            height: 155,
            zIndex: 10,
          }}
          onClick={handleIPadClick}
        >
          {/* iPad glow when near */}
          {iPadNear && (
            <motion.div
              className="absolute rounded-2xl pointer-events-none"
              style={{
                inset: -12,
                background: "radial-gradient(circle, rgba(232,23,127,0.12) 0%, rgba(0,0,0,0) 70%)",
              }}
              animate={{ scale: [1, 1.15, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          )}

          {/* iPad body */}
          <div
            className="w-full h-full rounded-xl flex flex-col items-center justify-center relative overflow-hidden"
            style={{
              backgroundColor: "#1a1a1a",
              border: "3px solid #333",
              boxShadow: iPadNear
                ? "0 8px 32px rgba(0,0,0,0.3), 0 0 24px rgba(232,23,127,0.15)"
                : "0 4px 16px rgba(0,0,0,0.15)",
            }}
          >
            {/* Screen content */}
            <div
              className="flex-1 w-[88%] mt-3 rounded-sm flex flex-col items-center justify-center gap-2"
              style={{ backgroundColor: "#0A0A0A" }}
            >
              {/* Mini pattern preview */}
              <div className="grid" style={{ gridTemplateColumns: "repeat(5, 8px)", gap: 1 }}>
                {[
                  0, 1, 0, 1, 0,
                  1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1,
                  0, 1, 1, 1, 0,
                  0, 0, 1, 0, 0,
                ].map((filled, i) => (
                  <motion.div
                    key={i}
                    className="rounded-[0.5px]"
                    style={{
                      width: 8,
                      height: 8,
                      backgroundColor: filled ? HEART_RED : "rgba(255,255,255,0.04)",
                    }}
                    animate={
                      filled && iPadNear
                        ? { opacity: [0.4, 1, 0.4] }
                        : { opacity: filled ? 0.3 : 0.1 }
                    }
                    transition={
                      filled && iPadNear
                        ? { duration: 1.5, repeat: Infinity, delay: i * 0.08 }
                        : {}
                    }
                  />
                ))}
              </div>
              {iPadNear && (
                <motion.p
                  style={{ fontSize: 5, color: "rgba(255,255,255,0.4)", fontWeight: 300 }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  Touche pour broder
                </motion.p>
              )}
            </div>
            {/* Home indicator */}
            <div
              className="w-6 h-0.5 rounded-full mb-2 mt-2"
              style={{ backgroundColor: "rgba(255,255,255,0.15)" }}
            />
          </div>
        </motion.div>

        {/* ═══ PLAYER ═══ */}
        <motion.div
          className="absolute z-20 pointer-events-none"
          style={{
            left: playerPos.x * CELL - 18,
            top: playerPos.y * CELL - 18,
          }}
        >
          <PlayerSquare
            colorHex={HEART_RED}
            symbol="♥"
            size={CELL}
            symbolSize={30}
            isCurrentPlayer
            glowing
          />
        </motion.div>
      </motion.div>

      {/* ═══ UI OVERLAY ═══ */}
      {/* Back button */}
      <motion.button
        className="fixed top-4 left-4 z-30 flex items-center gap-1.5 cursor-pointer border-none"
        style={{
          backgroundColor: "rgba(255,255,255,0.85)",
          backdropFilter: "blur(8px)",
          color: "#666",
          fontSize: 10,
          fontWeight: 400,
          padding: "8px 14px",
          borderRadius: 10,
          border: "1px solid rgba(0,0,0,0.06)",
        }}
        onClick={onBack}
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
      >
        <ArrowLeft size={12} />
      </motion.button>

      {/* Compass — points to iPad */}
      {!iPadNear && showCompass && (
        <motion.div
          className="fixed z-30 flex flex-col items-center gap-1.5"
          style={{
            bottom: isMobile ? 28 : 36,
            right: isMobile ? 16 : 24,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <motion.div
            className="w-12 h-12 rounded-full flex items-center justify-center"
            style={{
              backgroundColor: "rgba(255,255,255,0.9)",
              backdropFilter: "blur(8px)",
              border: "1px solid rgba(0,0,0,0.06)",
              boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
            }}
          >
            <motion.div
              animate={{ rotate: compassDeg }}
              transition={{ type: "spring", stiffness: 100, damping: 15 }}
            >
              <Compass size={18} color={HEART_RED} strokeWidth={1.5} />
            </motion.div>
          </motion.div>
          <span style={{ fontSize: 8, color: "#999", fontWeight: 300, letterSpacing: "0.04em" }}>
            {Math.round(distToIPad)} pas
          </span>
        </motion.div>
      )}

      {/* iPad nearby hint */}
      <AnimatePresence>
        {iPadNear && !iPadActivated && (
          <motion.div
            className="fixed z-30 flex items-center gap-2"
            style={{
              bottom: isMobile ? 28 : 36,
              left: "50%",
              transform: "translateX(-50%)",
              backgroundColor: "rgba(0,0,0,0.8)",
              backdropFilter: "blur(8px)",
              color: "#fff",
              fontSize: 11,
              fontWeight: 400,
              padding: "10px 20px",
              borderRadius: 12,
              letterSpacing: "0.04em",
            }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
          >
            <motion.span
              style={{ color: HEART_RED }}
              animate={{ opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              ♥
            </motion.span>
            Touche l'iPad pour broder
          </motion.div>
        )}
      </AnimatePresence>

      {/* Leaf detail popup */}
      <AnimatePresence>
        {selectedLeaf !== null && (
          <motion.div
            className="fixed inset-0 z-40 flex items-center justify-center"
            style={{ backgroundColor: "rgba(0,0,0,0.3)", backdropFilter: "blur(4px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedLeaf(null)}
          >
            <motion.div
              className="relative rounded-xl p-5 max-w-xs w-full mx-4"
              style={{
                backgroundColor: "#fff",
                boxShadow: "0 12px 40px rgba(0,0,0,0.12)",
                border: `1px solid ${LEAVES[selectedLeaf].color}15`,
              }}
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="absolute top-3 right-3 cursor-pointer border-none bg-transparent"
                onClick={() => setSelectedLeaf(null)}
              >
                <X size={14} color="#ccc" />
              </button>
              <span style={{ fontSize: 28 }}>{LEAVES[selectedLeaf].emoji}</span>
              <h3
                style={{
                  fontSize: 14,
                  fontWeight: 600,
                  color: LEAVES[selectedLeaf].color,
                  letterSpacing: "0.06em",
                  marginTop: 8,
                  marginBottom: 6,
                }}
              >
                {LEAVES[selectedLeaf].label}
              </h3>
              <p style={{ fontSize: 12, color: "#666", lineHeight: 1.7, fontWeight: 300 }}>
                {LEAVES[selectedLeaf].desc}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Intro hint */}
      <motion.div
        className="fixed z-20 flex flex-col items-center gap-1"
        style={{ top: isMobile ? 16 : 24, left: "50%", transform: "translateX(-50%)" }}
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <p
          style={{
            fontSize: 10,
            color: "#999",
            fontWeight: 300,
            letterSpacing: "0.06em",
            backgroundColor: "rgba(255,255,255,0.85)",
            backdropFilter: "blur(8px)",
            padding: "6px 14px",
            borderRadius: 8,
            border: "1px solid rgba(0,0,0,0.04)",
          }}
        >
          Clique pour marcher · Explore la carte
        </p>
      </motion.div>
    </div>
  );
}
