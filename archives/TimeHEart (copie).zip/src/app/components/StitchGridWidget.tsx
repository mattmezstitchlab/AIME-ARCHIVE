import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ZoomIn, ZoomOut, Maximize2, Grid3x3, ChevronRight,
  BookOpen, Calendar, Palette, Hash,
} from "lucide-react";

// ═══════════════════════════════════════════════════════════
// STITCH GRID WIDGET — Standalone embeddable component
// Infinite grid · Red counting lines · Pattern rendering
// Pan & zoom · Pattern card overlay
// ═══════════════════════════════════════════════════════════

const EXAMPLE_IMAGE_URL =
  "https://images.unsplash.com/photo-1720982018832-35b144516bb9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbWJyb2lkZXJ5JTIwZmxvd2VyJTIwY29sb3JmdWx8ZW58MXx8fHwxNzcwNDk3NzI4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

// ── Types ──
interface PatternPixel {
  r: number; g: number; b: number; a: number;
  symbol: string;
}

interface PatternData {
  name: string;
  gridWidth: number;
  gridHeight: number;
  colors: number;
  difficulty: "Facile" | "Moyen" | "Difficile";
  progress: number;
  date: string;
  pixels: PatternPixel[][];
  previewUrl?: string;
}

// ── Constants ──
const STITCH_SYMBOLS = ["✕", "♥", "✚", "◆", "■", "●", "▲", "✳", "◇", "○", "□", "△", "★", "⊕", "⬟", "⊗"];
const MIN_ZOOM = 0.15;
const MAX_ZOOM = 6;
const DRAG_THRESHOLD = 4;

const pmod = (v: number, m: number) => ((v % m) + m) % m;

// ── Color quantization ──
function quantize(v: number, levels: number): number {
  const step = 256 / levels;
  return Math.min(Math.floor(v / step) * step + Math.floor(step / 2), 255);
}
function colorBucket(r: number, g: number, b: number, levels: number): number {
  const qr = Math.floor(quantize(r, levels) / (256 / levels));
  const qg = Math.floor(quantize(g, levels) / (256 / levels));
  const qb = Math.floor(quantize(b, levels) / (256 / levels));
  return qr * levels * levels + qg * levels + qb;
}

// ══════════════════════════
// PATTERN CARD COMPONENT
// ══════════════════════════
function PatternCard({
  pattern,
  onOpen,
}: {
  pattern: PatternData;
  onOpen?: () => void;
}) {
  const diffColor =
    pattern.difficulty === "Facile" ? "#22C55E" :
    pattern.difficulty === "Moyen" ? "#F97316" : "#EF4444";

  return (
    <motion.div
      className="rounded-2xl overflow-hidden cursor-pointer"
      style={{
        background: "#FFFFFF",
        boxShadow: "0 2px 20px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.04)",
        width: 320,
      }}
      whileHover={{ scale: 1.02, boxShadow: "0 4px 30px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.06)" }}
      transition={{ duration: 0.25 }}
      onClick={onOpen}
    >
      {/* Preview image */}
      <div
        className="flex items-center justify-center"
        style={{
          background: "#F5F5F5",
          height: 180,
          overflow: "hidden",
        }}
      >
        {pattern.previewUrl ? (
          <img
            src={pattern.previewUrl}
            alt={pattern.name}
            crossOrigin="anonymous"
            style={{
              maxWidth: "80%",
              maxHeight: "85%",
              imageRendering: "pixelated",
              objectFit: "contain",
            }}
          />
        ) : (
          <div
            className="flex items-center justify-center"
            style={{
              width: 100,
              height: 100,
              background: "#E5E5E5",
              borderRadius: 12,
              fontSize: 36,
              color: "#999",
            }}
          >
            ✕
          </div>
        )}
      </div>

      {/* Info */}
      <div style={{ padding: "14px 18px 16px" }}>
        <div className="flex items-center justify-between">
          <span style={{ fontSize: 16, fontWeight: 600, color: "#111" }}>
            {pattern.name}
          </span>
          <ChevronRight size={18} color="#CCC" />
        </div>

        <div
          className="flex items-center gap-3 flex-wrap"
          style={{ marginTop: 6, fontSize: 12, color: "#888" }}
        >
          <span className="flex items-center gap-1">
            <Hash size={12} />
            {pattern.gridWidth}x{pattern.gridHeight}
          </span>
          <span className="flex items-center gap-1">
            <Palette size={12} />
            {pattern.colors} couleurs
          </span>
          <span
            style={{
              color: diffColor,
              fontWeight: 600,
              fontSize: 12,
            }}
          >
            {pattern.difficulty}
          </span>
        </div>

        {/* Progress bar */}
        <div style={{ marginTop: 10 }}>
          <div
            style={{
              height: 4,
              borderRadius: 2,
              background: "#F0F0F0",
              overflow: "hidden",
            }}
          >
            <motion.div
              style={{
                height: "100%",
                borderRadius: 2,
                background: "linear-gradient(90deg, #3B82F6, #2563EB)",
              }}
              initial={{ width: 0 }}
              animate={{ width: `${pattern.progress}%` }}
              transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
            />
          </div>
        </div>

        <div
          className="flex items-center justify-between"
          style={{ marginTop: 8, fontSize: 11, color: "#AAA" }}
        >
          <span>{pattern.progress}%</span>
          <div className="flex items-center gap-3">
            <span
              className="flex items-center gap-1 cursor-pointer"
              style={{ color: "#F97316", fontWeight: 600 }}
            >
              <BookOpen size={11} /> Guide
            </span>
            <span className="flex items-center gap-1">
              <Calendar size={11} /> {pattern.date}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ══════════════════════════════════════
// INFINITE STITCH GRID (Standalone)
// ══════════════════════════════════════
function InfiniteStitchGrid({
  pattern,
  cellSize = 18,
}: {
  pattern: PatternData;
  cellSize?: number;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [camera, setCamera] = useState({ x: 0, y: 0, zoom: 1.8 });
  const cameraRef = useRef(camera);
  cameraRef.current = camera;

  const [dims, setDims] = useState({ w: 800, h: 600 });
  const initializedRef = useRef(false);

  // Resize observer
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const obs = new ResizeObserver((entries) => {
      const { width, height } = entries[0].contentRect;
      if (width > 0 && height > 0) {
        setDims({ w: width, h: height });
      }
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Center pattern initially (only once)
  useEffect(() => {
    if (initializedRef.current) return;
    if (dims.w <= 1 || dims.h <= 1) return;
    initializedRef.current = true;

    const pw = pattern.gridWidth * cellSize * 1.8;
    const ph = pattern.gridHeight * cellSize * 1.8;
    setCamera({
      x: (dims.w - pw) / 2,
      y: (dims.h - ph) / 2,
      zoom: 1.8,
    });
  }, [dims.w, dims.h, pattern.gridWidth, pattern.gridHeight, cellSize]);

  // ─── Pan state ───
  const panRef = useRef({
    active: false, pointerId: -1,
    startX: 0, startY: 0,
    origX: 0, origY: 0,
    moved: false,
  });

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    if (e.button !== 0) return;
    panRef.current = {
      active: true, pointerId: e.pointerId,
      startX: e.clientX, startY: e.clientY,
      origX: cameraRef.current.x, origY: cameraRef.current.y,
      moved: false,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }, []);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    const p = panRef.current;
    if (!p.active || e.pointerId !== p.pointerId) return;
    const dx = e.clientX - p.startX;
    const dy = e.clientY - p.startY;
    if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
      p.moved = true;
    }
    setCamera((c) => ({ ...c, x: p.origX + dx, y: p.origY + dy }));
  }, []);

  const handlePointerUp = useCallback(() => {
    panRef.current.active = false;
  }, []);

  // Wheel zoom
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.08 : 1 / 1.08;
    setCamera((c) => {
      const newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, c.zoom * factor));
      const rect = containerRef.current?.getBoundingClientRect();
      const mx = rect ? e.clientX - rect.left : dims.w / 2;
      const my = rect ? e.clientY - rect.top : dims.h / 2;
      return {
        x: mx - (mx - c.x) * (newZoom / c.zoom),
        y: my - (my - c.y) * (newZoom / c.zoom),
        zoom: newZoom,
      };
    });
  }, [dims]);

  const zoomTo = useCallback((targetZoom: number) => {
    setCamera((c) => {
      const nz = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, targetZoom));
      return {
        x: dims.w / 2 - (dims.w / 2 - c.x) * (nz / c.zoom),
        y: dims.h / 2 - (dims.h / 2 - c.y) * (nz / c.zoom),
        zoom: nz,
      };
    });
  }, [dims]);

  const fitPattern = useCallback(() => {
    const pw = pattern.gridWidth * cellSize;
    const ph = pattern.gridHeight * cellSize;
    const padding = 60;
    const fitZoom = Math.min(
      (dims.w - padding * 2) / pw,
      (dims.h - padding * 2) / ph,
      MAX_ZOOM
    );
    setCamera({
      x: (dims.w - pw * fitZoom) / 2,
      y: (dims.h - ph * fitZoom) / 2,
      zoom: fitZoom,
    });
  }, [dims, pattern, cellSize]);

  // ─── Render on canvas ───
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = dims.w * dpr;
    canvas.height = dims.h * dpr;
    canvas.style.width = `${dims.w}px`;
    canvas.style.height = `${dims.h}px`;

    const ctx = canvas.getContext("2d")!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, dims.w, dims.h);

    const z = camera.zoom;
    const sc = cellSize * z;

    // ── Infinite background grid (subtle) ──
    const offX = pmod(camera.x, sc);
    const offY = pmod(camera.y, sc);

    ctx.strokeStyle = "rgba(0,0,0,0.06)";
    ctx.lineWidth = 0.5;

    for (let x = offX; x < dims.w + sc; x += sc) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, dims.h);
      ctx.stroke();
    }
    for (let y = offY; y < dims.h + sc; y += sc) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(dims.w, y);
      ctx.stroke();
    }

    // ── Bold RED lines every 10 cells (industry standard) ──
    const bold10 = 10 * sc;
    const boldOffX = pmod(camera.x, bold10);
    const boldOffY = pmod(camera.y, bold10);

    ctx.strokeStyle = "rgba(220, 50, 50, 0.22)";
    ctx.lineWidth = 1.2;

    for (let x = boldOffX; x < dims.w + bold10; x += bold10) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, dims.h);
      ctx.stroke();
    }
    for (let y = boldOffY; y < dims.h + bold10; y += bold10) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(dims.w, y);
      ctx.stroke();
    }

    // ── Pattern pixels ──
    const px = pattern.pixels;
    const pw = pattern.gridWidth;
    const ph = pattern.gridHeight;

    for (let row = 0; row < ph; row++) {
      for (let col = 0; col < pw; col++) {
        const pixel = px[row]?.[col];
        if (!pixel || pixel.a < 20) continue;

        const sx = camera.x + col * sc;
        const sy = camera.y + row * sc;

        // Skip if off screen
        if (sx + sc < 0 || sx > dims.w || sy + sc < 0 || sy > dims.h) continue;

        // Cell background (saturated)
        ctx.fillStyle = `rgba(${pixel.r},${pixel.g},${pixel.b},${pixel.a / 255 * 0.92})`;
        ctx.fillRect(sx + 0.5, sy + 0.5, sc - 1, sc - 1);

        // Cross-stitch "X" texture
        if (sc > 6) {
          const inset = Math.max(1, sc * 0.12);
          ctx.strokeStyle = "rgba(255,255,255,0.15)";
          ctx.lineWidth = Math.max(0.4, sc * 0.04);
          ctx.beginPath();
          ctx.moveTo(sx + inset, sy + inset);
          ctx.lineTo(sx + sc - inset, sy + sc - inset);
          ctx.moveTo(sx + sc - inset, sy + inset);
          ctx.lineTo(sx + inset, sy + sc - inset);
          ctx.stroke();
        }

        // Symbol (only if zoomed enough)
        if (sc > 12) {
          const brightness = pixel.r * 0.299 + pixel.g * 0.587 + pixel.b * 0.114;
          ctx.fillStyle = brightness > 140 ? "rgba(0,0,0,0.5)" : "rgba(255,255,255,0.6)";
          ctx.font = `${Math.max(6, sc * 0.38)}px "Inter", sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(pixel.symbol, sx + sc / 2, sy + sc / 2);
        }

        // Cell border
        ctx.strokeStyle = "rgba(0,0,0,0.08)";
        ctx.lineWidth = 0.4;
        ctx.strokeRect(sx + 0.5, sy + 0.5, sc - 1, sc - 1);
      }
    }

    // ── Pattern boundary (RED frame) ──
    const bx = camera.x;
    const by = camera.y;
    const bw = pw * sc;
    const bh = ph * sc;
    ctx.strokeStyle = "rgba(220, 50, 50, 0.6)";
    ctx.lineWidth = 2;
    ctx.strokeRect(bx, by, bw, bh);

    // ── RED counting lines INSIDE pattern every 10 cells ──
    ctx.strokeStyle = "rgba(220, 50, 50, 0.35)";
    ctx.lineWidth = 1;
    for (let i = 10; i < pw; i += 10) {
      const lx = bx + i * sc;
      ctx.beginPath();
      ctx.moveTo(lx, by);
      ctx.lineTo(lx, by + bh);
      ctx.stroke();
    }
    for (let i = 10; i < ph; i += 10) {
      const ly = by + i * sc;
      ctx.beginPath();
      ctx.moveTo(bx, ly);
      ctx.lineTo(bx + bw, ly);
      ctx.stroke();
    }

    // ── Row/column numbers (every 10, outside pattern) ──
    if (sc > 5) {
      ctx.fillStyle = "rgba(220, 50, 50, 0.5)";
      ctx.font = `${Math.max(8, Math.min(12, sc * 0.5))}px "Inter", sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";
      for (let i = 0; i <= pw; i += 10) {
        if (i === 0) continue;
        ctx.fillText(`${i}`, bx + i * sc, by - 4);
      }
      ctx.textAlign = "right";
      ctx.textBaseline = "middle";
      for (let i = 0; i <= ph; i += 10) {
        if (i === 0) continue;
        ctx.fillText(`${i}`, bx - 6, by + i * sc);
      }
    }
  }, [camera, dims, cellSize, pattern]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden"
      style={{
        background: "#FAFAF8",
        borderRadius: 16,
        cursor: panRef.current.active ? "grabbing" : "grab",
      }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0"
        style={{ touchAction: "none" }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onWheel={handleWheel}
      />

      {/* Zoom controls */}
      <div
        className="absolute flex flex-col gap-1"
        style={{ bottom: 16, right: 16 }}
      >
        <button
          onClick={() => zoomTo(camera.zoom * 1.3)}
          className="flex items-center justify-center rounded-lg"
          style={{
            width: 36, height: 36,
            background: "rgba(255,255,255,0.9)",
            boxShadow: "0 1px 8px rgba(0,0,0,0.08)",
            border: "1px solid rgba(0,0,0,0.06)",
            cursor: "pointer",
          }}
        >
          <ZoomIn size={16} color="#555" />
        </button>
        <button
          onClick={() => zoomTo(camera.zoom / 1.3)}
          className="flex items-center justify-center rounded-lg"
          style={{
            width: 36, height: 36,
            background: "rgba(255,255,255,0.9)",
            boxShadow: "0 1px 8px rgba(0,0,0,0.08)",
            border: "1px solid rgba(0,0,0,0.06)",
            cursor: "pointer",
          }}
        >
          <ZoomOut size={16} color="#555" />
        </button>
        <button
          onClick={fitPattern}
          className="flex items-center justify-center rounded-lg"
          style={{
            width: 36, height: 36,
            background: "rgba(255,255,255,0.9)",
            boxShadow: "0 1px 8px rgba(0,0,0,0.08)",
            border: "1px solid rgba(0,0,0,0.06)",
            cursor: "pointer",
          }}
        >
          <Maximize2 size={16} color="#555" />
        </button>
      </div>

      {/* Grid info badge */}
      <div
        className="absolute flex items-center gap-2"
        style={{
          top: 12, left: 12,
          background: "rgba(255,255,255,0.92)",
          padding: "6px 12px",
          borderRadius: 8,
          fontSize: 11,
          color: "#888",
          boxShadow: "0 1px 6px rgba(0,0,0,0.06)",
          fontWeight: 500,
        }}
      >
        <Grid3x3 size={13} />
        {pattern.gridWidth}×{pattern.gridHeight} &middot;{" "}
        {Math.round(camera.zoom * 100)}%
      </div>
    </div>
  );
}

// ══════════════════════════════════════
// IMAGE → PATTERN CONVERTER
// ══════════════════════════════════════
function imageToPattern(
  imageUrl: string,
  name: string,
  maxCells: number = 40,
): Promise<PatternData> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const aspect = img.naturalWidth / img.naturalHeight;
      let cols: number, rows: number;
      if (aspect >= 1) {
        cols = Math.min(maxCells, Math.ceil(img.naturalWidth / 8));
        rows = Math.round(cols / aspect);
      } else {
        rows = Math.min(maxCells, Math.ceil(img.naturalHeight / 8));
        cols = Math.round(rows * aspect);
      }
      cols = Math.max(8, Math.min(maxCells, cols));
      rows = Math.max(8, Math.min(maxCells, rows));

      const offscreen = document.createElement("canvas");
      offscreen.width = cols;
      offscreen.height = rows;
      const ctx = offscreen.getContext("2d")!;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "medium";
      ctx.drawImage(img, 0, 0, cols, rows);
      const imageData = ctx.getImageData(0, 0, cols, rows);

      const bucketSet = new Map<number, number>();
      let bucketCounter = 0;
      const pixels: PatternPixel[][] = [];

      for (let y = 0; y < rows; y++) {
        const row: PatternPixel[] = [];
        for (let x = 0; x < cols; x++) {
          const idx = (y * cols + x) * 4;
          const r = imageData.data[idx];
          const g = imageData.data[idx + 1];
          const b = imageData.data[idx + 2];
          const a = imageData.data[idx + 3];

          const bucket = colorBucket(r, g, b, 8);
          if (!bucketSet.has(bucket)) {
            bucketSet.set(bucket, bucketCounter++);
          }
          const symbolIdx = bucketSet.get(bucket)! % STITCH_SYMBOLS.length;

          row.push({
            r, g, b, a,
            symbol: STITCH_SYMBOLS[symbolIdx],
          });
        }
        pixels.push(row);
      }

      resolve({
        name,
        gridWidth: cols,
        gridHeight: rows,
        colors: bucketSet.size,
        difficulty: bucketSet.size > 20 ? "Difficile" : bucketSet.size > 10 ? "Moyen" : "Facile",
        progress: 17,
        date: "07 fév. 2026",
        pixels,
        previewUrl: imageUrl,
      });
    };
    img.src = imageUrl;
  });
}

// ══════════════════════════════════════
// MAIN WIDGET SHOWCASE
// ══════════════════════════════════════
export function StitchGridWidget({ onBack }: { onBack?: () => void }) {
  const [pattern, setPattern] = useState<PatternData | null>(null);
  const [viewMode, setViewMode] = useState<"card" | "grid">("card");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load the example pattern
  useEffect(() => {
    imageToPattern(EXAMPLE_IMAGE_URL, "Fleur de Printemps", 30).then(setPattern);
  }, []);

  const handleUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    imageToPattern(url, file.name.replace(/\.[^.]+$/, ""), 50).then((p) => {
      setPattern(p);
      setViewMode("grid");
    });
    e.target.value = "";
  }, []);

  if (!pattern) {
    return (
      <div className="flex items-center justify-center w-full h-screen" style={{ background: "#F9F9F7" }}>
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          style={{ fontSize: 32 }}
        >
          ✕
        </motion.div>
      </div>
    );
  }

  return (
    <div
      className="flex flex-col w-full h-screen"
      style={{
        background: "#F9F9F7",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      {/* ── Header ── */}
      <div
        className="flex items-center justify-between shrink-0"
        style={{ padding: "16px 20px", borderBottom: "1px solid rgba(0,0,0,0.06)" }}
      >
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="flex items-center justify-center rounded-lg"
              style={{
                width: 36, height: 36,
                background: "rgba(0,0,0,0.04)",
                border: "none", cursor: "pointer",
              }}
            >
              <ChevronRight size={18} color="#666" style={{ transform: "rotate(180deg)" }} />
            </button>
          )}
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#111" }}>
              Stitch Grid Widget
            </div>
            <div style={{ fontSize: 12, color: "#999" }}>
              Grille infinie avec lignes rouges — exportable
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Toggle Card/Grid */}
          <div
            className="flex rounded-lg overflow-hidden"
            style={{
              border: "1px solid rgba(0,0,0,0.08)",
              background: "#FFF",
            }}
          >
            <button
              onClick={() => setViewMode("card")}
              className="flex items-center gap-1 px-3 py-1.5"
              style={{
                fontSize: 12, fontWeight: 500, border: "none", cursor: "pointer",
                background: viewMode === "card" ? "#111" : "rgba(0,0,0,0)",
                color: viewMode === "card" ? "#FFF" : "#666",
                transition: "all 0.2s",
              }}
            >
              Card
            </button>
            <button
              onClick={() => setViewMode("grid")}
              className="flex items-center gap-1 px-3 py-1.5"
              style={{
                fontSize: 12, fontWeight: 500, border: "none", cursor: "pointer",
                background: viewMode === "grid" ? "#111" : "rgba(0,0,0,0)",
                color: viewMode === "grid" ? "#FFF" : "#666",
                transition: "all 0.2s",
              }}
            >
              Grille
            </button>
          </div>

          {/* Upload */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-4 py-2 rounded-full"
            style={{
              background: "linear-gradient(135deg, #3B82F6, #2563EB)",
              color: "#FFF",
              fontSize: 13,
              fontWeight: 600,
              border: "none",
              cursor: "pointer",
              boxShadow: "0 2px 12px rgba(37,99,235,0.3)",
            }}
          >
            + Importer
          </button>
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 min-h-0 relative">
        <AnimatePresence mode="wait">
          {viewMode === "card" ? (
            <motion.div
              key="card-view"
              className="flex items-center justify-center w-full h-full"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex flex-col items-center gap-6">
                <PatternCard
                  pattern={pattern}
                  onOpen={() => setViewMode("grid")}
                />
                <div style={{ fontSize: 12, color: "#BBB", textAlign: "center" }}>
                  Clique sur la card pour ouvrir la grille infinie
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="grid-view"
              className="absolute inset-0"
              style={{ padding: 12 }}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.4 }}
            >
              <InfiniteStitchGrid pattern={pattern} cellSize={18} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Bottom info bar ── */}
      <div
        className="flex items-center justify-between shrink-0"
        style={{
          padding: "10px 20px",
          borderTop: "1px solid rgba(0,0,0,0.06)",
          background: "#FFF",
          fontSize: 11,
          color: "#AAA",
        }}
      >
        <span>{pattern.name} — {pattern.gridWidth}×{pattern.gridHeight} — {pattern.colors} couleurs</span>
        <span style={{ color: "#DC3232", fontWeight: 600 }}>
          Lignes rouges tous les 10 carrés
        </span>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleUpload}
      />
    </div>
  );
}
