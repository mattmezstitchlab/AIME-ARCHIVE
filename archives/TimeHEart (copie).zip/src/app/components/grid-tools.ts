// ═══════════════════════════════════════════
// GRID TOOLS — Active tool types for the StitchLab grid
// ═══════════════════════════════════════════

export type ToolType = "hand" | "draw" | "eraser" | "pick-color" | "fill";

export interface ActiveTool {
  type: ToolType;
  color: string;       // hex color for drawing
  colorCode: string;   // DMC code
  size: number;        // brush size in cells (1 = single cell)
}

// Grid paint: each cell can hold a color
export type GridPaints = Record<string, string>; // "x,y" -> hex color

export function cellKey(x: number, y: number): string {
  return `${x},${y}`;
}

export function parseCellKey(key: string): [number, number] {
  const [x, y] = key.split(",").map(Number);
  return [x, y];
}
