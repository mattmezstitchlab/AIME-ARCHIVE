import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, ChevronRight, ChevronDown, ChevronUp,
  ZoomIn, ZoomOut, RotateCcw, GripVertical, AlertTriangle, Lightbulb,
  CheckCircle2, Circle, Play, Bot, Wrench, Flame, Eye, EyeOff, 
  Music, Volume2
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// ═══════════════════════════════════════════════
// LUTHIERLAB — Atelier Interactif de Lutherie
// "Sur la table en bois, les outils sont prêts.
//  Le saxophone attend. Le Maître guide."
// ═══════════════════════════════════════════════

const WOOD_BG = "https://images.unsplash.com/photo-1618178167824-cc143a5976e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwd29vZCUyMHRhYmxlJTIwdGV4dHVyZSUyMHdhcm18ZW58MXx8fHwxNzcwNDc5NDA4fDA&ixlib=rb-4.1.0&q=80&w=1080";
const SAX_IMG = "https://images.unsplash.com/photo-1732532399621-afd080eb0b52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXhvcGhvbmUlMjBnb2xkZW4lMjBrZXlzJTIwZGV0YWlsJTIwbXVzaWN8ZW58MXx8fHwxNzcwNDc5MDYwfDA&ixlib=rb-4.1.0&q=80&w=1080";

const C = {
  wood: "#2A1F14",
  woodLight: "#3D2E1F",
  woodWarm: "#4A3626",
  leather: "#5C3D2E",
  brass: "#C9A86C",
  brassLight: "#E8C9A0",
  brassGlow: "#D4A55A",
  copper: "#B87333",
  felt: "#2D4A3E",
  feltLight: "#3D6B5A",
  lamp: "#FFD699",
  lampGlow: "rgba(255,214,153,0.15)",
  text: "#E8DDD0",
  textSoft: "#A89880",
  textMuted: "#6B5D4F",
  green: "#6BAF6B",
  red: "#C45A5A",
  panel: "rgba(30,22,14,0.92)",
  panelBorder: "rgba(201,168,108,0.1)",
};

// The real tools a luthier uses, displayed on the workbench
const WORKBENCH_TOOLS = [
  { id: "tournevis", emoji: "🔧", name: "Tournevis plat", desc: "Pour les vis de charnière", category: "VISSERIE", x: 8, y: 18 },
  { id: "cruciforme", emoji: "🔩", name: "Cruciforme", desc: "Vis de garde et de clé", category: "VISSERIE", x: 15, y: 32 },
  { id: "pince", emoji: "🪛", name: "Pince bec fin", desc: "Manipulation des ressorts", category: "MANIPULATION", x: 5, y: 50 },
  { id: "cle", emoji: "🔑", name: "Clé à ressort", desc: "Monter/démonter les ressorts-aiguilles", category: "MANIPULATION", x: 12, y: 65 },
  { id: "fer", emoji: "🔥", name: "Fer à tamponner", desc: "Chauffer la gomme-laque", category: "TAMPONNAGE", x: 78, y: 20 },
  { id: "lampe", emoji: "🕯️", name: "Lampe à alcool", desc: "Source de chaleur contrôlée", category: "TAMPONNAGE", x: 85, y: 35 },
  { id: "extracteur", emoji: "🔨", name: "Pad slick", desc: "Retirer et poser les tampons", category: "TAMPONNAGE", x: 82, y: 52 },
  { id: "mandrin", emoji: "📐", name: "Mandrin conique", desc: "Calibrer les cheminées", category: "FINITION", x: 88, y: 68 },
  { id: "huile", emoji: "💧", name: "Huile pour clés", desc: "Lubrification des mécanismes", category: "FINITION", x: 80, y: 80 },
  { id: "chamois", emoji: "🧽", name: "Peau de chamois", desc: "Polissage final", category: "FINITION", x: 10, y: 82 },
];

// 14-step formation
const STEPS = [
  { id: 1, phase: "DÉMONTAGE", label: "Retirer le bec", tool: "Pince bec fin", zone: "bec" },
  { id: 2, phase: "DÉMONTAGE", label: "Retirer la ligature", tool: "Tournevis plat", zone: "bec" },
  { id: 3, phase: "DÉMONTAGE", label: "Démonter le bocal", tool: "Clé à ressort", zone: "bocal" },
  { id: 4, phase: "DÉMONTAGE", label: "Clé d'octave du bocal", tool: "Cruciforme", zone: "bocal" },
  { id: 5, phase: "DÉMONTAGE", label: "Retirer les vis de charnière", tool: "Tournevis plat", zone: "corps" },
  { id: 6, phase: "DÉMONTAGE", label: "Retirer les ressorts", tool: "Pince bec fin", zone: "corps" },
  { id: 7, phase: "TAMPONNAGE", label: "Retirer les anciens tampons", tool: "Pad slick", zone: "corps" },
  { id: 8, phase: "TAMPONNAGE", label: "Chauffer la gomme-laque", tool: "Lampe à alcool", zone: "corps" },
  { id: 9, phase: "TAMPONNAGE", label: "Poser les nouveaux tampons", tool: "Fer à tamponner", zone: "corps" },
  { id: 10, phase: "TAMPONNAGE", label: "Ajuster le nivelage", tool: "Mandrin conique", zone: "corps" },
  { id: 11, phase: "REMONTAGE", label: "Remettre les ressorts", tool: "Pince bec fin", zone: "corps" },
  { id: 12, phase: "REMONTAGE", label: "Revisser les charnières", tool: "Tournevis plat", zone: "corps" },
  { id: 13, phase: "FINITION", label: "Huiler les mécanismes", tool: "Huile pour clés", zone: "corps" },
  { id: 14, phase: "FINITION", label: "Polir et nettoyer", tool: "Peau de chamois", zone: "pavillon" },
];

const PHASE_COLORS: Record<string, string> = {
  "DÉMONTAGE": "#C45A5A",
  "TAMPONNAGE": "#C9A86C",
  "REMONTAGE": "#5A8ED4",
  "FINITION": "#6BAF6B",
};

interface LuthierLabLandingProps {
  onBack?: () => void;
  onNavigate?: (screen: string) => void;
}

export function LuthierLabLanding({ onBack }: LuthierLabLandingProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [hoveredTool, setHoveredTool] = useState<string | null>(null);
  const [showGuide, setShowGuide] = useState(true);
  const [showSteps, setShowSteps] = useState(false);
  const [lampOn, setLampOn] = useState(true);
  const [saxDrag, setSaxDrag] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [hoveredZone, setHoveredZone] = useState<string | null>(null);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [showIntro, setShowIntro] = useState(true);
  const dragStart = useRef({ x: 0, y: 0 });
  const posStart = useRef({ x: 0, y: 0 });

  const step = STEPS[currentStep];
  const progress = ((currentStep + 1) / STEPS.length) * 100;
  const phaseColor = PHASE_COLORS[step.phase] || C.brass;

  // Auto-select tool matching current step
  useEffect(() => {
    const matchingTool = WORKBENCH_TOOLS.find(t => t.name === step.tool);
    if (matchingTool) setSelectedTool(matchingTool.id);
  }, [currentStep]);

  const advanceStep = useCallback(() => {
    setCompletedSteps(prev => new Set([...prev, currentStep]));
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  }, [currentStep]);

  // Drag saxophone
  const handleSaxDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY };
    posStart.current = { ...saxDrag };
  }, [saxDrag]);

  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (!isDragging) return;
      setSaxDrag({
        x: posStart.current.x + (e.clientX - dragStart.current.x),
        y: posStart.current.y + (e.clientY - dragStart.current.y),
      });
    };
    const up = () => setIsDragging(false);
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
    return () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); };
  }, [isDragging]);

  // ═══ INTRO SCREEN ═══
  if (showIntro) {
    return (
      <div className="fixed inset-0 overflow-hidden" style={{ backgroundColor: "#0E0A06" }}>
        {/* Wooden texture under */}
        <div className="absolute inset-0">
          <ImageWithFallback
            src={WOOD_BG}
            alt=""
            className="w-full h-full object-cover"
            style={{ opacity: 0.2, filter: "brightness(0.4) saturate(0.5)" }}
          />
          <div
            className="absolute inset-0"
            style={{ background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 30%, rgba(0,0,0,0.7) 100%)" }}
          />
        </div>

        {/* Back button */}
        {onBack && (
          <motion.button
            className="absolute top-5 left-5 z-50 flex items-center gap-1.5 border-none cursor-pointer rounded-lg px-3 py-1.5"
            style={{ backgroundColor: "rgba(201,168,108,0.08)", color: C.textSoft, fontSize: 11 }}
            onClick={onBack}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft size={13} />
            Retour
          </motion.button>
        )}

        {/* Center content */}
        <div className="relative z-10 flex flex-col items-center justify-center h-full px-6">
          {/* Warm glow */}
          <motion.div
            className="absolute pointer-events-none"
            style={{
              width: 500, height: 500,
              background: "radial-gradient(circle, rgba(201,168,108,0.08) 0%, rgba(0,0,0,0) 60%)",
            }}
            animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />

          {/* Saxophone icon */}
          <motion.div
            className="mb-8"
            style={{ fontSize: 60 }}
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 1.2, type: "spring", stiffness: 60 }}
          >
            🎷
          </motion.div>

          {/* Title */}
          <motion.h1
            className="text-center"
            style={{
              fontSize: "clamp(28px, 5vw, 48px)",
              fontWeight: 200,
              color: C.text,
              lineHeight: 1.3,
              letterSpacing: "-0.02em",
            }}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            LuthierLab
          </motion.h1>

          <motion.p
            className="text-center mt-3"
            style={{
              fontSize: 10,
              color: C.textMuted,
              letterSpacing: "0.25em",
              fontWeight: 300,
              textTransform: "uppercase",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.8 }}
          >
            Atelier de lutherie saxophone
          </motion.p>

          <motion.p
            className="text-center mt-6 max-w-md"
            style={{
              fontSize: 14,
              color: C.textSoft,
              lineHeight: 1.9,
              fontWeight: 300,
            }}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.3, duration: 0.8 }}
          >
            14 étapes pour apprendre à démonter, tamponner et remonter
            un saxophone. Sur une table en bois, avec les vrais outils.
          </motion.p>

          {/* Phases preview */}
          <motion.div
            className="flex items-center gap-4 mt-8"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.6, duration: 0.6 }}
          >
            {Object.entries(PHASE_COLORS).map(([phase, color]) => (
              <div key={phase} className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                <span style={{ fontSize: 9, color: C.textMuted, letterSpacing: "0.04em" }}>{phase}</span>
              </div>
            ))}
          </motion.div>

          {/* Enter button */}
          <motion.button
            className="mt-12 px-8 py-3.5 rounded-xl border-none cursor-pointer flex items-center gap-2"
            style={{
              background: `linear-gradient(135deg, ${C.brass}, ${C.copper})`,
              color: "#1A1108",
              fontSize: 13,
              fontWeight: 600,
              letterSpacing: "0.06em",
              boxShadow: `0 6px 24px rgba(201,168,108,0.25)`,
            }}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2, duration: 0.6 }}
            whileHover={{ scale: 1.04, boxShadow: `0 8px 32px rgba(201,168,108,0.35)` }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setShowIntro(false)}
          >
            Ouvrir l'atelier
            <ChevronRight size={15} />
          </motion.button>

          {/* Bottom info */}
          <motion.div
            className="absolute bottom-8 flex flex-col items-center gap-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ delay: 2.5 }}
          >
            <span style={{ fontSize: 8, color: C.textMuted, letterSpacing: "0.1em" }}>
              FORMATION INTERACTIVE · 14 ÉTAPES
            </span>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 overflow-hidden"
      style={{ fontFamily: "'Inter', -apple-system, sans-serif", backgroundColor: C.wood }}
    >
      {/* ═══ WOODEN TABLE BACKGROUND ═══ */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={WOOD_BG}
          alt=""
          className="w-full h-full object-cover"
          style={{ opacity: lampOn ? 0.5 : 0.25, transition: "opacity 1s", filter: "brightness(0.6) saturate(0.7)" }}
        />
        {/* Warm lamp glow */}
        <motion.div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: lampOn
              ? `radial-gradient(ellipse at 50% 35%, ${C.lampGlow} 0%, rgba(0,0,0,0) 55%)`
              : "none",
          }}
          animate={{ opacity: lampOn ? [0.8, 1, 0.8] : 0 }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Vignette */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 40%, rgba(0,0,0,0.6) 100%)" }}
        />
      </div>

      {/* ═══ TOP BAR — Atelier ═══ */}
      <motion.header
        className="relative z-40 flex items-center justify-between px-4 py-2.5"
        style={{ backgroundColor: C.panel, borderBottom: `1px solid ${C.panelBorder}`, backdropFilter: "blur(12px)" }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="flex items-center gap-3">
          {onBack && (
            <motion.button
              className="flex items-center gap-1.5 border-none cursor-pointer rounded-lg px-3 py-1.5"
              style={{ backgroundColor: "rgba(201,168,108,0.08)", color: C.textSoft, fontSize: 11 }}
              onClick={onBack}
              whileTap={{ scale: 0.95 }}
            >
              <ArrowLeft size={13} />
              Retour
            </motion.button>
          )}
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: `linear-gradient(135deg, ${C.brass}, ${C.copper})`, fontSize: 12 }}
            >
              🎷
            </div>
            <div>
              <span style={{ fontSize: 13, fontWeight: 600, color: C.text, letterSpacing: "-0.01em" }}>
                LuthierLab
              </span>
              <span style={{ fontSize: 8, color: C.textMuted, display: "block", letterSpacing: "0.1em", marginTop: -1 }}>
                ATELIER INTERACTIF
              </span>
            </div>
          </div>
        </div>

        {/* Step indicator + controls */}
        <div className="flex items-center gap-3">
          {/* Progress mini bar */}
          <div className="hidden sm:flex items-center gap-2">
            <span style={{ fontSize: 9, color: C.textMuted, letterSpacing: "0.06em" }}>{step.phase}</span>
            <div className="w-20 h-1 rounded-full" style={{ backgroundColor: "rgba(201,168,108,0.1)" }}>
              <motion.div
                className="h-full rounded-full"
                style={{ backgroundColor: phaseColor }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <span style={{ fontSize: 9, color: C.textSoft }}>{currentStep + 1}/{STEPS.length}</span>
          </div>

          {/* Lamp toggle */}
          <motion.button
            className="p-1.5 rounded-lg border-none cursor-pointer"
            style={{ backgroundColor: lampOn ? "rgba(255,214,153,0.12)" : "rgba(0,0,0,0)", color: lampOn ? C.lamp : C.textMuted }}
            onClick={() => setLampOn(!lampOn)}
            whileTap={{ scale: 0.9 }}
            title="Lampe d'atelier"
          >
            {lampOn ? <Eye size={14} /> : <EyeOff size={14} />}
          </motion.button>

          {/* Zoom */}
          <div className="hidden md:flex items-center gap-1">
            <button className="p-1 border-none cursor-pointer rounded" style={{ backgroundColor: "rgba(0,0,0,0)", color: C.textSoft }} onClick={() => setZoom(Math.min(180, zoom + 20))}>
              <ZoomIn size={13} />
            </button>
            <span style={{ fontSize: 9, color: C.textMuted, minWidth: 30, textAlign: "center" }}>{zoom}%</span>
            <button className="p-1 border-none cursor-pointer rounded" style={{ backgroundColor: "rgba(0,0,0,0)", color: C.textSoft }} onClick={() => setZoom(Math.max(50, zoom - 20))}>
              <ZoomOut size={13} />
            </button>
            <button className="p-1 border-none cursor-pointer rounded" style={{ backgroundColor: "rgba(0,0,0,0)", color: C.textSoft }} onClick={() => { setZoom(100); setSaxDrag({ x: 0, y: 0 }); }}>
              <RotateCcw size={13} />
            </button>
          </div>
        </div>
      </motion.header>

      {/* ═══ MAIN WORKSPACE ═══ */}
      <div className="relative flex-1 overflow-hidden" style={{ height: "calc(100vh - 48px)" }}>

        {/* ── TOOLS scattered on the workbench ── */}
        {WORKBENCH_TOOLS.map((tool, i) => {
          const isActive = selectedTool === tool.id;
          const isNeeded = step.tool === tool.name;
          const isHovered = hoveredTool === tool.id;
          return (
            <motion.div
              key={tool.id}
              className="absolute z-20 cursor-pointer select-none"
              style={{
                left: `${tool.x}%`,
                top: `${tool.y}%`,
              }}
              initial={{ opacity: 0, scale: 0, rotate: -20 + Math.random() * 40 }}
              animate={{
                opacity: 1,
                scale: isActive ? 1.2 : 1,
                rotate: isActive ? 0 : -10 + i * 7,
              }}
              transition={{ delay: 0.3 + i * 0.08, type: "spring", stiffness: 200 }}
              onClick={() => setSelectedTool(isActive ? null : tool.id)}
              onMouseEnter={() => setHoveredTool(tool.id)}
              onMouseLeave={() => setHoveredTool(null)}
              whileHover={{ scale: 1.25, zIndex: 50 }}
              whileTap={{ scale: 0.9 }}
            >
              {/* Tool glow when needed for current step */}
              {isNeeded && (
                <motion.div
                  className="absolute -inset-3 rounded-full"
                  style={{ backgroundColor: "rgba(201,168,108,0.15)" }}
                  animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
              <div
                className="relative flex items-center justify-center rounded-xl"
                style={{
                  width: 48,
                  height: 48,
                  backgroundColor: isActive ? "rgba(201,168,108,0.2)" : "rgba(42,31,20,0.7)",
                  border: isNeeded ? `2px solid ${C.brassGlow}` : isActive ? `1px solid ${C.brass}50` : `1px solid ${C.panelBorder}`,
                  backdropFilter: "blur(4px)",
                  boxShadow: isActive
                    ? `0 4px 20px rgba(201,168,108,0.25), 0 0 30px rgba(201,168,108,0.1)`
                    : "0 2px 8px rgba(0,0,0,0.4)",
                  transition: "all 0.3s",
                  fontSize: 22,
                }}
              >
                {tool.emoji}
              </div>

              {/* Tooltip */}
              <AnimatePresence>
                {(isHovered || isActive) && (
                  <motion.div
                    className="absolute left-1/2 -translate-x-1/2 rounded-lg px-3 py-2"
                    style={{
                      bottom: "calc(100% + 8px)",
                      backgroundColor: C.panel,
                      border: `1px solid ${C.panelBorder}`,
                      backdropFilter: "blur(12px)",
                      whiteSpace: "nowrap",
                      zIndex: 60,
                    }}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 4 }}
                  >
                    <p style={{ fontSize: 11, fontWeight: 600, color: isNeeded ? C.brassGlow : C.text }}>{tool.name}</p>
                    <p style={{ fontSize: 9, color: C.textMuted, marginTop: 1 }}>{tool.desc}</p>
                    {isNeeded && (
                      <p style={{ fontSize: 8, color: C.brassGlow, marginTop: 3, letterSpacing: "0.08em" }}>
                        ▸ REQUIS POUR L'ÉTAPE {step.id}
                      </p>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}

        {/* ── SAXOPHONE — center of the workbench ── */}
        <motion.div
          className="absolute z-10 cursor-grab active:cursor-grabbing select-none"
          style={{
            left: "50%",
            top: "50%",
            width: `clamp(180px, ${zoom * 2.8}px, 500px)`,
            transform: `translate(calc(-50% + ${saxDrag.x}px), calc(-50% + ${saxDrag.y}px))`,
          }}
          onMouseDown={handleSaxDown}
          initial={{ opacity: 0, scale: 0.8, y: 30 }}
          animate={{ opacity: 1, scale: zoom / 100, y: 0 }}
          transition={{ duration: 1.2, delay: 0.5, type: "spring", stiffness: 80 }}
        >
          {/* Warm glow under the sax */}
          <div
            className="absolute -inset-12 rounded-full pointer-events-none"
            style={{
              background: lampOn
                ? `radial-gradient(ellipse, rgba(201,168,108,0.1) 0%, rgba(0,0,0,0) 60%)`
                : "none",
            }}
          />
          <ImageWithFallback
            src={SAX_IMG}
            alt="Saxophone — pièce maîtresse"
            className="w-full h-auto pointer-events-none"
            style={{
              filter: lampOn
                ? "brightness(0.9) contrast(1.1) saturate(1.1)"
                : "brightness(0.5) contrast(1.1) saturate(0.6)",
              transition: "filter 1s",
              userSelect: "none",
              borderRadius: 12,
            }}
            draggable={false}
          />
          {/* Drag badge */}
          <motion.div
            className="absolute -top-5 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2.5 py-1 rounded-full pointer-events-none"
            style={{ backgroundColor: C.panel, border: `1px solid ${C.panelBorder}` }}
            animate={{ opacity: isDragging ? 0 : [0.5, 0.8, 0.5] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <GripVertical size={9} style={{ color: C.textMuted }} />
            <span style={{ fontSize: 7, color: C.textMuted, letterSpacing: "0.08em" }}>DÉPLACER</span>
          </motion.div>
        </motion.div>

        {/* ── BOTTOM: Step navigation bar ── */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 z-30"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          {/* Steps list (expandable) */}
          <AnimatePresence>
            {showSteps && (
              <motion.div
                className="mx-4 mb-2 rounded-2xl overflow-hidden"
                style={{ backgroundColor: C.panel, border: `1px solid ${C.panelBorder}`, backdropFilter: "blur(16px)", maxHeight: 280, overflowY: "auto" }}
                initial={{ opacity: 0, y: 10, height: 0 }}
                animate={{ opacity: 1, y: 0, height: "auto" }}
                exit={{ opacity: 0, y: 10, height: 0 }}
              >
                <div className="p-3 space-y-0.5">
                  {STEPS.map((s, i) => {
                    const done = i < currentStep;
                    const active = i === currentStep;
                    const pColor = PHASE_COLORS[s.phase] || C.brass;
                    return (
                      <motion.button
                        key={s.id}
                        className="flex items-center gap-2.5 w-full text-left border-none cursor-pointer py-2 px-3 rounded-xl"
                        style={{
                          backgroundColor: active ? "rgba(201,168,108,0.1)" : "rgba(0,0,0,0)",
                          transition: "all 0.2s",
                        }}
                        onClick={() => { setCurrentStep(i); setShowSteps(false); }}
                        whileHover={{ backgroundColor: "rgba(201,168,108,0.06)" }}
                      >
                        {done ? (
                          <CheckCircle2 size={13} style={{ color: C.green }} />
                        ) : active ? (
                          <Play size={13} style={{ color: pColor }} />
                        ) : (
                          <Circle size={13} style={{ color: C.textMuted }} />
                        )}
                        <span
                          className="px-1.5 py-0.5 rounded"
                          style={{ fontSize: 7, fontWeight: 600, color: pColor, backgroundColor: `${pColor}15`, letterSpacing: "0.04em" }}
                        >
                          {s.phase}
                        </span>
                        <span style={{
                          fontSize: 11,
                          color: active ? C.text : done ? C.textSoft : C.textMuted,
                          fontWeight: active ? 500 : 400,
                          flex: 1,
                        }}>
                          {s.label}
                        </span>
                        <span style={{ fontSize: 9, color: C.textMuted }}>{s.tool}</span>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main step bar */}
          <div
            className="mx-4 mb-4 rounded-2xl overflow-hidden"
            style={{ backgroundColor: C.panel, border: `1px solid ${C.panelBorder}`, backdropFilter: "blur(16px)" }}
          >
            {/* Progress bar at top */}
            <div className="h-0.5" style={{ backgroundColor: "rgba(201,168,108,0.06)" }}>
              <motion.div
                className="h-full"
                style={{ backgroundColor: phaseColor }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.4 }}
              />
            </div>

            <div className="flex items-center gap-3 px-4 py-3">
              {/* Step nav */}
              <motion.button
                className="p-2 rounded-xl border-none cursor-pointer"
                style={{
                  backgroundColor: "rgba(201,168,108,0.06)",
                  color: currentStep > 0 ? C.textSoft : C.textMuted,
                }}
                onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
                whileTap={{ scale: 0.9 }}
              >
                <ArrowLeft size={14} />
              </motion.button>

              {/* Current step info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span
                    className="px-2 py-0.5 rounded-md"
                    style={{ fontSize: 8, fontWeight: 700, color: phaseColor, backgroundColor: `${phaseColor}15`, letterSpacing: "0.05em" }}
                  >
                    ÉTAPE {step.id}
                  </span>
                  <span style={{ fontSize: 8, color: C.textMuted, letterSpacing: "0.06em" }}>{step.phase}</span>
                </div>
                <p style={{ fontSize: 13, fontWeight: 500, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {step.label}
                </p>
                <p style={{ fontSize: 10, color: C.textMuted, marginTop: 1 }}>
                  Outil : {step.tool}
                </p>
              </div>

              {/* Expand steps list */}
              <motion.button
                className="p-2 rounded-xl border-none cursor-pointer"
                style={{ backgroundColor: "rgba(201,168,108,0.06)", color: C.textSoft }}
                onClick={() => setShowSteps(!showSteps)}
                whileTap={{ scale: 0.9 }}
              >
                {showSteps ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
              </motion.button>

              {/* Next step */}
              <motion.button
                className="px-4 py-2 rounded-xl border-none cursor-pointer flex items-center gap-1.5"
                style={{
                  background: `linear-gradient(135deg, ${C.brass}, ${C.copper})`,
                  color: C.wood,
                  fontSize: 11,
                  fontWeight: 600,
                  boxShadow: `0 4px 16px rgba(201,168,108,0.25)`,
                }}
                onClick={advanceStep}
                whileHover={{ scale: 1.03, boxShadow: `0 6px 24px rgba(201,168,108,0.35)` }}
                whileTap={{ scale: 0.97 }}
              >
                Suivant
                <ChevronRight size={13} />
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* ── RIGHT PANEL: Maître Luthier IA ── */}
        <AnimatePresence>
          {showGuide && (
            <motion.aside
              className="absolute top-2 right-2 z-30 overflow-hidden rounded-2xl"
              style={{
                width: 260,
                backgroundColor: C.panel,
                border: `1px solid ${C.panelBorder}`,
                backdropFilter: "blur(16px)",
                boxShadow: "0 12px 40px rgba(0,0,0,0.4)",
              }}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ delay: 0.8, duration: 0.6 }}
            >
              {/* Header */}
              <div className="flex items-center gap-2.5 p-3" style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: `linear-gradient(135deg, ${C.brass}30, ${C.copper}30)`, border: `1px solid ${C.brass}25` }}
                >
                  <Bot size={15} style={{ color: C.brass }} />
                </div>
                <div className="flex-1">
                  <p style={{ fontSize: 12, fontWeight: 600, color: C.text }}>Maître Luthier</p>
                  <div className="flex items-center gap-1">
                    <motion.div
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: C.green }}
                      animate={{ opacity: [1, 0.3, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                    <span style={{ fontSize: 8, color: C.green }}>En ligne</span>
                  </div>
                </div>
                <motion.button
                  className="p-1 border-none cursor-pointer rounded-lg"
                  style={{ backgroundColor: "rgba(0,0,0,0)", color: C.textMuted }}
                  onClick={() => setShowGuide(false)}
                  whileHover={{ color: C.text }}
                >
                  ✕
                </motion.button>
              </div>

              {/* Instructions */}
              <div className="p-3">
                <div className="mb-3 p-2.5 rounded-xl" style={{ backgroundColor: "rgba(201,168,108,0.05)", border: `1px solid ${C.panelBorder}` }}>
                  <p style={{ fontSize: 11, color: C.text, lineHeight: 1.7 }}>
                    <span style={{ color: C.brass, fontWeight: 600 }}>Étape {step.id}</span> — {step.label}
                  </p>
                  <p style={{ fontSize: 10, color: C.textMuted, marginTop: 6, lineHeight: 1.6 }}>
                    {step.phase === "DÉMONTAGE" && "Travaillez avec précaution. Chaque vis, chaque ressort a sa place."}
                    {step.phase === "TAMPONNAGE" && "La chaleur doit être maîtrisée. Le tampon doit s'asseoir parfaitement."}
                    {step.phase === "REMONTAGE" && "L'ordre inverse est crucial. Vérifiez chaque articulation."}
                    {step.phase === "FINITION" && "La touche finale fait la différence entre un bon et un excellent travail."}
                  </p>
                </div>

                {/* Tips */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2 p-2 rounded-lg" style={{ backgroundColor: "rgba(107,175,107,0.06)" }}>
                    <Lightbulb size={11} style={{ color: C.green, marginTop: 2, flexShrink: 0 }} />
                    <p style={{ fontSize: 10, color: "rgba(107,175,107,0.8)", lineHeight: 1.5 }}>
                      Sélectionnez l'outil surligné en doré sur la table pour avancer.
                    </p>
                  </div>
                  <div className="flex items-start gap-2 p-2 rounded-lg" style={{ backgroundColor: "rgba(196,90,90,0.06)" }}>
                    <AlertTriangle size={11} style={{ color: C.red, marginTop: 2, flexShrink: 0 }} />
                    <p style={{ fontSize: 10, color: "rgba(196,90,90,0.7)", lineHeight: 1.5 }}>
                      Ne jamais forcer un mécanisme. La patience est la clé.
                    </p>
                  </div>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Re-show guide button when hidden */}
        {!showGuide && (
          <motion.button
            className="absolute top-2 right-2 z-30 p-2.5 rounded-full border-none cursor-pointer"
            style={{
              background: `linear-gradient(135deg, ${C.brass}30, ${C.copper}30)`,
              border: `1px solid ${C.brass}20`,
              backdropFilter: "blur(8px)",
              color: C.brass,
            }}
            onClick={() => setShowGuide(true)}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Bot size={16} />
          </motion.button>
        )}

        {/* ── AMBIENT: Workshop label ── */}
        <motion.div
          className="absolute top-2 left-1/2 -translate-x-1/2 z-20 px-3 py-1.5 rounded-full"
          style={{
            backgroundColor: C.panel,
            border: `1px solid ${C.panelBorder}`,
            backdropFilter: "blur(8px)",
          }}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
        >
          <div className="flex items-center gap-2">
            <Music size={10} style={{ color: C.brass, opacity: 0.5 }} />
            <span style={{ fontSize: 8, color: C.textMuted, letterSpacing: "0.12em" }}>
              PLAN DE TRAVAIL · ATELIER LUTHIER
            </span>
            <Volume2 size={10} style={{ color: C.textMuted, opacity: 0.3 }} />
          </div>
        </motion.div>
      </div>
    </div>
  );
}