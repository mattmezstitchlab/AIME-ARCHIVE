import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Palette, Timer, Hash, StickyNote, Scissors,
  Camera, Share2, Pipette, X, Play, Pause, RotateCcw,
  Plus, Minus, Copy, Check, ChevronDown, Download, MapPin,
} from "lucide-react";
import { DMC_COLORS } from "./game-data";

// ═══════════════════════════════════════════
// STITCHDOCK — The Cross-Stitch Widget
// 1 square → 8 squares. Each square = a tool.
// Metaphor: a cross-stitch grid IS the UI.
// ═══════════════════════════════════════════

// ─── TOOL DEFINITIONS ───
type ToolKey = "dmc" | "counter" | "timer" | "palette" | "notes" | "pattern" | "lily" | "share";

interface ToolDef {
  key: ToolKey;
  label: string;
  icon: typeof Palette;
  color: string;
  description: string;
}

const TOOLS: ToolDef[] = [
  { key: "dmc",     label: "DMC",      icon: Pipette,    color: "#C72B3B", description: "Trouve le fil DMC le plus proche" },
  { key: "counter", label: "Compteur", icon: Hash,       color: "#9263A6", description: "Compte tes rangs et points" },
  { key: "timer",   label: "Timer",    icon: Timer,      color: "#42A350", description: "Chronometre ta session broderie" },
  { key: "palette", label: "Palette",  icon: Palette,    color: "#4685B7", description: "Gere ta palette de projet" },
  { key: "notes",   label: "Notes",    icon: StickyNote,  color: "#FFB515", description: "Notes rapides de projet" },
  { key: "pattern", label: "Pattern",  icon: Camera,     color: "#EB5B2E", description: "Photo vers grille rapide" },
  { key: "lily",    label: "Lily",     icon: Scissors,   color: "#9263A6", description: "Demande a Lily" },
  { key: "share",   label: "Partage",  icon: Share2,     color: "#6BA7B0", description: "Partage ton avancement" },
];

// 8 positions: N, NE, E, SE, S, SW, W, NW
const OFFSETS: [number, number][] = [
  [0, -1], [1, -1], [1, 0], [1, 1],
  [0, 1], [-1, 1], [-1, 0], [-1, -1],
];

// ─── DMC COLOR TOOL ───
function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function findNearestDMC(hex: string) {
  const [r, g, b] = hexToRgb(hex);
  let best = DMC_COLORS[0];
  let bestDist = Infinity;
  for (const c of DMC_COLORS) {
    if (c.rare) continue;
    const [cr, cg, cb] = hexToRgb(c.hex);
    const d = Math.sqrt((r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2);
    if (d < bestDist) { bestDist = d; best = c; }
  }
  return best;
}

// ─── TOOL PANELS ───

function DMCTool() {
  const [color, setColor] = useState("#C72B3B");
  const dmc = findNearestDMC(color);
  const [copied, setCopied] = useState(false);

  return (
    <div className="flex flex-col gap-3 p-1">
      <div className="flex items-center gap-3">
        <input
          type="color" value={color} onChange={(e) => setColor(e.target.value)}
          className="w-10 h-10 rounded-lg border-none cursor-pointer"
          style={{ padding: 0 }}
        />
        <div className="flex flex-col gap-0.5 flex-1">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-[2px]" style={{ backgroundColor: dmc.hex, border: "1px solid rgba(0,0,0,0.08)" }} />
            <span style={{ fontSize: 14, fontWeight: 600, color: "#1a1a1a" }}>DMC {dmc.code}</span>
            <motion.button
              className="flex items-center justify-center rounded-md border-none cursor-pointer"
              style={{ width: 22, height: 22, backgroundColor: copied ? "#42A35015" : "rgba(0,0,0,0.04)", color: copied ? "#42A350" : "#999" }}
              onClick={() => { navigator.clipboard.writeText(`DMC ${dmc.code}`); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
              whileTap={{ scale: 0.85 }}
            >
              {copied ? <Check size={10} /> : <Copy size={10} />}
            </motion.button>
          </div>
          <span style={{ fontSize: 10, color: "#999" }}>{dmc.name}</span>
        </div>
      </div>
      <div className="grid grid-cols-8 gap-0.5">
        {DMC_COLORS.filter(c => !c.rare).slice(0, 24).map((c) => (
          <motion.button
            key={c.code}
            className="rounded-[2px] border-none cursor-pointer"
            style={{ width: "100%", aspectRatio: "1", backgroundColor: c.hex, outline: color === c.hex ? "2px solid #1a1a1a" : "1px solid rgba(0,0,0,0.06)", outlineOffset: -1 }}
            onClick={() => setColor(c.hex)}
            whileHover={{ scale: 1.15 }} whileTap={{ scale: 0.9 }}
            title={`DMC ${c.code} — ${c.name}`}
          />
        ))}
      </div>
    </div>
  );
}

function CounterTool() {
  const [count, setCount] = useState(0);
  const [rows, setRows] = useState(0);

  return (
    <div className="flex flex-col items-center gap-3 p-1">
      <div className="flex flex-col items-center">
        <span style={{ fontSize: 8, color: "#bbb", letterSpacing: "0.1em", textTransform: "uppercase" }}>Points</span>
        <motion.span
          key={count}
          style={{ fontSize: 36, fontWeight: 300, color: "#1a1a1a", lineHeight: 1.1, fontVariantNumeric: "tabular-nums" }}
          initial={{ scale: 1.1, opacity: 0.6 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          {count.toLocaleString()}
        </motion.span>
      </div>
      <div className="flex items-center gap-2">
        <motion.button
          className="flex items-center justify-center rounded-lg border-none cursor-pointer"
          style={{ width: 40, height: 40, backgroundColor: "rgba(0,0,0,0.04)", color: "#999" }}
          onClick={() => setCount(Math.max(0, count - 1))}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.9 }}
        >
          <Minus size={16} />
        </motion.button>
        <motion.button
          className="flex items-center justify-center rounded-xl border-none cursor-pointer"
          style={{ width: 64, height: 48, background: "linear-gradient(135deg, #9263A6 0%, #6B3F7F 100%)", color: "#fff" }}
          onClick={() => setCount(count + 1)}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.92 }}
        >
          <Plus size={20} />
        </motion.button>
        <motion.button
          className="flex items-center justify-center rounded-lg border-none cursor-pointer"
          style={{ width: 40, height: 40, backgroundColor: "rgba(0,0,0,0.04)", color: "#999" }}
          onClick={() => { setRows(rows + 1); }}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.9 }}
        >
          <ChevronDown size={16} />
        </motion.button>
      </div>
      <div className="flex items-center gap-4">
        <span style={{ fontSize: 10, color: "#bbb" }}>Rang <strong style={{ color: "#9263A6" }}>{rows}</strong></span>
        <motion.button
          className="flex items-center gap-1 border-none cursor-pointer rounded-md px-2 py-1"
          style={{ backgroundColor: "rgba(0,0,0,0.03)", color: "#ccc", fontSize: 9 }}
          onClick={() => { setCount(0); setRows(0); }}
          whileTap={{ scale: 0.9 }}
        >
          <RotateCcw size={8} /> Reset
        </motion.button>
      </div>
    </div>
  );
}

function TimerTool() {
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => setSeconds((s) => s + 1), 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [running]);

  const format = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
      ? `${h}:${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`
      : `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex flex-col items-center gap-3 p-1">
      <span style={{ fontSize: 8, color: "#bbb", letterSpacing: "0.1em", textTransform: "uppercase" }}>Session broderie</span>
      <motion.span
        style={{ fontSize: 32, fontWeight: 300, color: running ? "#42A350" : "#1a1a1a", lineHeight: 1, fontVariantNumeric: "tabular-nums", fontFamily: "'Inter', monospace" }}
        animate={running ? { opacity: [1, 0.6, 1] } : { opacity: 1 }}
        transition={running ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
      >
        {format(seconds)}
      </motion.span>
      <div className="flex items-center gap-2">
        <motion.button
          className="flex items-center justify-center rounded-xl border-none cursor-pointer"
          style={{
            width: 48, height: 40,
            backgroundColor: running ? "rgba(0,0,0,0.06)" : "#42A350",
            color: running ? "#999" : "#fff",
          }}
          onClick={() => setRunning(!running)}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.92 }}
        >
          {running ? <Pause size={16} /> : <Play size={16} />}
        </motion.button>
        <motion.button
          className="flex items-center justify-center rounded-xl border-none cursor-pointer"
          style={{ width: 40, height: 40, backgroundColor: "rgba(0,0,0,0.04)", color: "#ccc" }}
          onClick={() => { setRunning(false); setSeconds(0); }}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.9 }}
        >
          <RotateCcw size={14} />
        </motion.button>
      </div>
      {seconds > 60 && (
        <motion.span
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          style={{ fontSize: 9, color: "#bbb", fontStyle: "italic" }}
        >
          ~{Math.round(seconds / 60 * 12)} points a 12 pts/min
        </motion.span>
      )}
    </div>
  );
}

function PaletteTool() {
  const [palette, setPalette] = useState<string[]>(["#C72B3B", "#9263A6", "#42A350", "#4685B7"]);
  const [adding, setAdding] = useState(false);
  const [newColor, setNewColor] = useState("#FFB515");

  return (
    <div className="flex flex-col gap-3 p-1">
      <span style={{ fontSize: 8, color: "#bbb", letterSpacing: "0.1em", textTransform: "uppercase" }}>Palette projet</span>
      <div className="flex flex-wrap gap-1.5">
        {palette.map((hex, i) => {
          const dmc = findNearestDMC(hex);
          return (
            <motion.div
              key={`${hex}-${i}`}
              className="flex flex-col items-center gap-0.5 cursor-pointer group"
              whileHover={{ scale: 1.08 }}
            >
              <div className="rounded-[3px] relative" style={{ width: 32, height: 32, backgroundColor: hex }}>
                <motion.button
                  className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full flex items-center justify-center border-none cursor-pointer opacity-0 group-hover:opacity-100"
                  style={{ backgroundColor: "#1a1a1a", color: "#fff", fontSize: 8 }}
                  onClick={() => setPalette(palette.filter((_, j) => j !== i))}
                  whileTap={{ scale: 0.8 }}
                >
                  <X size={7} />
                </motion.button>
              </div>
              <span style={{ fontSize: 7, color: "#999" }}>{dmc.code}</span>
            </motion.div>
          );
        })}
        {palette.length < 12 && !adding && (
          <motion.button
            className="flex items-center justify-center rounded-[3px] border-none cursor-pointer"
            style={{ width: 32, height: 32, border: "1px dashed rgba(0,0,0,0.15)", backgroundColor: "rgba(0,0,0,0)" , color: "#ccc" }}
            onClick={() => setAdding(true)}
            whileHover={{ scale: 1.08, borderColor: "rgba(0,0,0,0.3)" }}
          >
            <Plus size={12} />
          </motion.button>
        )}
      </div>
      <AnimatePresence>
        {adding && (
          <motion.div
            className="flex items-center gap-2"
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
          >
            <input type="color" value={newColor} onChange={(e) => setNewColor(e.target.value)}
              className="w-7 h-7 rounded-md border-none cursor-pointer" style={{ padding: 0 }} />
            <span style={{ fontSize: 10, color: "#999" }}>DMC {findNearestDMC(newColor).code}</span>
            <motion.button
              className="px-2 py-1 rounded-md border-none cursor-pointer"
              style={{ fontSize: 9, backgroundColor: "#42A350", color: "#fff" }}
              onClick={() => { setPalette([...palette, newColor]); setAdding(false); }}
              whileTap={{ scale: 0.9 }}
            >
              Ajouter
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NotesTool() {
  const [notes, setNotes] = useState("Projet en cours :\n- Toile Aida 14ct\n- 6 couleurs DMC\n- Motif 80x60");

  return (
    <div className="flex flex-col gap-2 p-1">
      <span style={{ fontSize: 8, color: "#bbb", letterSpacing: "0.1em", textTransform: "uppercase" }}>Notes projet</span>
      <textarea
        value={notes} onChange={(e) => setNotes(e.target.value)}
        className="w-full rounded-lg border-none outline-none resize-none"
        style={{
          minHeight: 100, padding: 10, fontSize: 11, lineHeight: 1.6,
          backgroundColor: "rgba(0,0,0,0.02)", color: "#555",
          fontFamily: "'Inter', sans-serif",
        }}
      />
      <span style={{ fontSize: 8, color: "#ddd" }}>{notes.length} car.</span>
    </div>
  );
}

function PatternTool() {
  const [preview, setPreview] = useState<string | null>(null);
  const [legend, setLegend] = useState<{ code: string; name: string; hex: string; symbol: string; count: number }[]>([]);
  const [gridSize, setGridSize] = useState<{ w: number; h: number } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const SYMS = ["X", "O", "+", "=", "/", "#", "@", "*", "~", "Z", "V", "T"];

  const handleFile = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Downscale for cross-stitch grid
        const targetW = 28;
        const aspect = img.height / img.width;
        const w = targetW;
        const h = Math.round(w * aspect);

        // Sample pixels at low res
        const sampleCanvas = document.createElement("canvas");
        sampleCanvas.width = w; sampleCanvas.height = h;
        const sctx = sampleCanvas.getContext("2d")!;
        sctx.imageSmoothingEnabled = true;
        sctx.drawImage(img, 0, 0, w, h);
        const imageData = sctx.getImageData(0, 0, w, h);
        const pixels = imageData.data;

        // Match each pixel to nearest DMC
        const usable = DMC_COLORS.filter(c => !c.rare && c.code !== "Blanc" && c.code !== "310");
        const colorCounts = new Map<string, number>();
        const pixelDMC: string[][] = [];

        for (let y = 0; y < h; y++) {
          pixelDMC[y] = [];
          for (let x = 0; x < w; x++) {
            const i = (y * w + x) * 4;
            const r = pixels[i], g = pixels[i + 1], b = pixels[i + 2];
            let best = usable[0], bestD = Infinity;
            for (const c of usable) {
              const [cr, cg, cb] = hexToRgb(c.hex);
              const d = (r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2;
              if (d < bestD) { bestD = d; best = c; }
            }
            pixelDMC[y][x] = best.code;
            colorCounts.set(best.code, (colorCounts.get(best.code) || 0) + 1);
          }
        }

        // Keep top 10 colors
        const sorted = [...colorCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10);
        const keepCodes = new Set(sorted.map(s => s[0]));

        // Build legend
        const legendData = sorted.map((entry, i) => {
          const dmc = DMC_COLORS.find(c => c.code === entry[0])!;
          return { code: dmc.code, name: dmc.name, hex: dmc.hex, symbol: SYMS[i] || "?", count: entry[1] };
        });
        setLegend(legendData);

        // Render visual grid
        const canvas = canvasRef.current;
        if (!canvas) return;
        const cellPx = 6;
        canvas.width = w * cellPx;
        canvas.height = h * cellPx;
        const ctx = canvas.getContext("2d")!;

        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const code = pixelDMC[y][x];
            const dmc = DMC_COLORS.find(c => c.code === code);
            if (dmc && keepCodes.has(code)) {
              ctx.fillStyle = dmc.hex;
            } else {
              // Map to nearest kept color
              ctx.fillStyle = DMC_COLORS.find(c => c.code === sorted[0][0])?.hex || "#ccc";
            }
            ctx.fillRect(x * cellPx, y * cellPx, cellPx - 0.5, cellPx - 0.5);
          }
        }

        setPreview(canvas.toDataURL());
        setGridSize({ w, h });
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  }, []);

  const downloadPattern = useCallback(() => {
    if (!legend.length || !gridSize) return;
    const lines = [
      "═══════════════════════════",
      "  STITCHLAB — StitchDock Pattern",
      `  ${gridSize.w} x ${gridSize.h} points`,
      `  ${legend.length} couleurs DMC`,
      "═══════════════════════════", "",
      "LEGENDE :",
    ];
    legend.forEach(l => lines.push(`  ${l.symbol}  →  DMC ${l.code} (${l.name}) — ${l.count} pts`));
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `stitchdock-pattern-${gridSize.w}x${gridSize.h}.txt`; a.click();
    URL.revokeObjectURL(url);
  }, [legend, gridSize]);

  return (
    <div className="flex flex-col items-center gap-3 p-1">
      <canvas ref={canvasRef} className="hidden" />
      {preview ? (
        <div className="flex flex-col items-center gap-2 w-full">
          <img src={preview} alt="Pattern" className="rounded-lg max-w-full" style={{ imageRendering: "pixelated", maxHeight: 120, border: "1px solid rgba(0,0,0,0.06)" }} />
          {/* DMC Legend */}
          {legend.length > 0 && (
            <div className="w-full flex flex-wrap gap-1 mt-1">
              {legend.slice(0, 8).map(l => (
                <div key={l.code} className="flex items-center gap-1 px-1.5 py-0.5 rounded" style={{ backgroundColor: "rgba(0,0,0,0.02)" }}>
                  <div className="w-2.5 h-2.5 rounded-[1px]" style={{ backgroundColor: l.hex }} />
                  <span style={{ fontSize: 7, color: "#999" }}>{l.symbol} {l.code}</span>
                </div>
              ))}
            </div>
          )}
          {gridSize && (
            <span style={{ fontSize: 8, color: "#bbb" }}>{gridSize.w}×{gridSize.h} points · {legend.length} DMC</span>
          )}
          <div className="flex gap-2">
            <motion.button className="px-3 py-1.5 rounded-lg border-none cursor-pointer flex items-center gap-1"
              style={{ fontSize: 9, backgroundColor: "#EB5B2E", color: "#fff" }}
              onClick={downloadPattern} whileTap={{ scale: 0.9 }}>
              <Download size={9} /> .txt
            </motion.button>
            <motion.button className="px-3 py-1.5 rounded-lg border-none cursor-pointer"
              style={{ fontSize: 9, backgroundColor: "rgba(0,0,0,0.04)", color: "#999" }}
              onClick={() => { setPreview(null); setLegend([]); setGridSize(null); }} whileTap={{ scale: 0.9 }}>
              Nouvelle
            </motion.button>
          </div>
        </div>
      ) : (
        <label className="flex flex-col items-center gap-2 cursor-pointer py-6 w-full rounded-xl"
          style={{ border: "2px dashed rgba(0,0,0,0.08)", backgroundColor: "rgba(0,0,0,0.01)" }}>
          <Camera size={24} color="#ccc" strokeWidth={1} />
          <span style={{ fontSize: 11, color: "#bbb" }}>Glisse une photo</span>
          <span style={{ fontSize: 8, color: "#ddd" }}>→ grille DMC instantanee</span>
          <input type="file" accept="image/*" className="hidden"
            onChange={(e) => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} />
        </label>
      )}
    </div>
  );
}

function LilyTool() {
  // Contextual guide — Lily adapts her tips to the embroiderer's current session
  const [sessionPhase, setSessionPhase] = useState<"start" | "stitching" | "finishing" | "break">("start");
  const [tipIndex, setTipIndex] = useState(0);

  const phaseTips: Record<string, { emoji: string; tips: string[] }> = {
    start: {
      emoji: "🧵",
      tips: [
        "Avant de commencer, verifie ta lumiere. Un bon eclairage, c'est 50% du confort.",
        "Separe chaque brin de fil un par un, puis rassemble-les. Le resultat sera bien plus lisse.",
        "Centre ton motif sur la toile : plie en 4, marque le centre, commence la.",
        "Choisis un tambour adapte a ta zone de travail. Trop grand = tension inegale.",
      ],
    },
    stitching: {
      emoji: "✂️",
      tips: [
        "Respire. La broderie n'est pas une course. Chaque point compte.",
        "Verifie regulierement l'envers de ton ouvrage — c'est un bon indicateur de proprete.",
        "Si ton fil vrille, laisse pendre l'aiguille pour qu'il se detorsade naturellement.",
        "Pense a changer de zone tous les 15-20 min pour eviter la fatigue des yeux.",
        "Le railroading (poser les brins a plat avec l'aiguille) change tout sur le rendu.",
      ],
    },
    finishing: {
      emoji: "🎀",
      tips: [
        "Le backstitch toujours EN DERNIER, apres tous les points de croix.",
        "Pour les contours, 1 brin de DMC 310 (noir) suffit. Fin et net.",
        "Lave ton ouvrage a l'eau tiede avec un savon doux, seche a plat.",
        "Un repassage a la vapeur sur l'envers, avec un tissu entre le fer et l'ouvrage.",
      ],
    },
    break: {
      emoji: "☕",
      tips: [
        "Pause meritee ! Etire tes doigts, tes poignets, ton cou.",
        "Bois un verre d'eau. La broderie deshydrate plus qu'on ne croit.",
        "C'est le moment de prendre une photo de ton avancement !",
        "Profite de la pause pour recompter tes rangs. Mieux vaut prevenir...",
      ],
    },
  };

  const current = phaseTips[sessionPhase];
  const tip = current.tips[tipIndex % current.tips.length];

  const phases: { key: typeof sessionPhase; label: string; icon: string }[] = [
    { key: "start", label: "Debut", icon: "🧵" },
    { key: "stitching", label: "En cours", icon: "✂️" },
    { key: "finishing", label: "Finitions", icon: "🎀" },
    { key: "break", label: "Pause", icon: "☕" },
  ];

  return (
    <div className="flex flex-col gap-3 p-1">
      {/* Header */}
      <div className="flex items-center gap-2">
        <div className="w-6 h-6 rounded-[3px] flex items-center justify-center"
          style={{ background: "linear-gradient(135deg, #9263A6, #6B3F7F)" }}>
          <Scissors size={10} color="#fff" strokeWidth={1.5} />
        </div>
        <div className="flex flex-col">
          <span style={{ fontSize: 11, fontWeight: 500, color: "#1a1a1a" }}>Guide Lily</span>
          <span style={{ fontSize: 7, color: "#9263A6", letterSpacing: "0.06em" }}>Conseils selon ta phase</span>
        </div>
      </div>

      {/* Phase selector */}
      <div className="flex gap-1">
        {phases.map(p => (
          <motion.button
            key={p.key}
            className="flex-1 flex flex-col items-center gap-0.5 py-1.5 rounded-lg border-none cursor-pointer"
            style={{
              backgroundColor: sessionPhase === p.key ? "rgba(146,99,166,0.08)" : "rgba(0,0,0,0.02)",
              border: `1px solid ${sessionPhase === p.key ? "rgba(146,99,166,0.2)" : "rgba(0,0,0,0.04)"}`,
            }}
            onClick={() => { setSessionPhase(p.key); setTipIndex(0); }}
            whileTap={{ scale: 0.95 }}
          >
            <span style={{ fontSize: 12 }}>{p.icon}</span>
            <span style={{ fontSize: 7, color: sessionPhase === p.key ? "#9263A6" : "#ccc", fontWeight: sessionPhase === p.key ? 500 : 400 }}>
              {p.label}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Contextual tip */}
      <motion.div
        key={`${sessionPhase}-${tipIndex}`}
        className="rounded-xl px-3 py-2.5"
        style={{ backgroundColor: "rgba(146,99,166,0.04)", fontSize: 11, lineHeight: 1.6, color: "#555" }}
        initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
      >
        <span style={{ fontSize: 13, marginRight: 6 }}>{current.emoji}</span>
        {tip}
      </motion.div>

      {/* Next tip */}
      <motion.button
        className="self-start px-3 py-1.5 rounded-lg border-none cursor-pointer flex items-center gap-1"
        style={{ fontSize: 10, backgroundColor: "rgba(146,99,166,0.08)", color: "#9263A6" }}
        onClick={() => setTipIndex(i => i + 1)}
        whileTap={{ scale: 0.9 }}
      >
        <MapPin size={8} /> Conseil suivant
      </motion.button>
    </div>
  );
}

function ShareTool() {
  const [copied, setCopied] = useState(false);
  const stats = "Session broderie :\n132 points | 4 rangs | 18 min\nPalette : DMC 321, 553, 702, 798\nvia StitchDock";

  return (
    <div className="flex flex-col gap-3 p-1 items-center">
      <span style={{ fontSize: 8, color: "#bbb", letterSpacing: "0.1em", textTransform: "uppercase" }}>Partager</span>
      <div className="rounded-xl px-3 py-2 w-full"
        style={{ backgroundColor: "rgba(0,0,0,0.02)", fontSize: 10, lineHeight: 1.6, color: "#888", whiteSpace: "pre-line" }}>
        {stats}
      </div>
      <motion.button
        className="flex items-center gap-1.5 px-4 py-2 rounded-xl border-none cursor-pointer"
        style={{ backgroundColor: copied ? "#42A350" : "#6BA7B0", color: "#fff", fontSize: 11, fontWeight: 500 }}
        onClick={() => { navigator.clipboard.writeText(stats); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
        whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.95 }}
      >
        {copied ? <Check size={12} /> : <Copy size={12} />}
        {copied ? "Copie !" : "Copier"}
      </motion.button>
    </div>
  );
}

const TOOL_COMPONENTS: Record<ToolKey, () => JSX.Element> = {
  dmc: DMCTool,
  counter: CounterTool,
  timer: TimerTool,
  palette: PaletteTool,
  notes: NotesTool,
  pattern: PatternTool,
  lily: LilyTool,
  share: ShareTool,
};

// ═══════════════════════════════════════════
// MAIN WIDGET COMPONENT
// ═══════════════════════════════════════════

interface StitchDockProps {
  /** Widget sizing */
  cellSize?: number;
  /** Show in demo/showcase mode */
  showcase?: boolean;
}

export function StitchDock({ cellSize = 52, showcase = false }: StitchDockProps) {
  const [open, setOpen] = useState(false);
  const [activeTool, setActiveTool] = useState<ToolKey | null>(null);
  const gap = 5;
  const totalCell = cellSize + gap;

  const handleToolClick = (key: ToolKey) => {
    if (activeTool === key) {
      setActiveTool(null);
    } else {
      setActiveTool(key);
    }
  };

  const handleClose = () => {
    setActiveTool(null);
    setOpen(false);
  };

  const activeToolDef = activeTool ? TOOLS.find((t) => t.key === activeTool) : null;
  const ActiveComponent = activeTool ? TOOL_COMPONENTS[activeTool] : null;

  return (
    <div className="relative" style={{ width: totalCell * 3, height: totalCell * 3 }}>
      {/* BACKDROP when open */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-0"
            style={{ backgroundColor: "rgba(0,0,0,0)" }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={handleClose}
          />
        )}
      </AnimatePresence>

      {/* 8 TOOL SQUARES */}
      <AnimatePresence>
        {open && TOOLS.map((tool, i) => {
          const [ox, oy] = OFFSETS[i];
          const isActive = activeTool === tool.key;
          const Icon = tool.icon;

          return (
            <motion.div
              key={tool.key}
              className="absolute z-10"
              style={{
                left: (1 + ox) * totalCell,
                top: (1 + oy) * totalCell,
                width: cellSize,
                height: cellSize,
              }}
              initial={{ opacity: 0, scale: 0.2 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.2 }}
              transition={{ type: "spring", stiffness: 600, damping: 28, delay: i * 0.025 }}
            >
              <motion.button
                className="w-full h-full flex flex-col items-center justify-center rounded-[4px] border-none cursor-pointer relative overflow-hidden"
                style={{
                  backgroundColor: isActive ? `${tool.color}12` : "rgba(255,255,255,0.95)",
                  backdropFilter: "blur(16px)",
                  boxShadow: isActive
                    ? `0 4px 20px ${tool.color}30, 0 0 0 1.5px ${tool.color}`
                    : `0 2px 12px rgba(0,0,0,0.06), 0 0 0 1px ${tool.color}20`,
                }}
                onClick={() => handleToolClick(tool.key)}
                whileHover={{ scale: 1.08, boxShadow: `0 4px 20px ${tool.color}25` }}
                whileTap={{ scale: 0.92 }}
              >
                {/* Colored top bar */}
                <div className="absolute top-0 left-0 right-0" style={{ height: 2.5, backgroundColor: tool.color }} />
                <Icon size={16} strokeWidth={1.5} color={tool.color} />
                <span style={{ fontSize: 7, color: "#999", marginTop: 3, fontWeight: 400, letterSpacing: "0.02em" }}>
                  {tool.label}
                </span>
              </motion.button>
            </motion.div>
          );
        })}
      </AnimatePresence>

      {/* CENTER SQUARE — toggle button */}
      <motion.button
        className="absolute z-20 flex items-center justify-center rounded-[4px] border-none cursor-pointer overflow-hidden"
        style={{
          left: totalCell,
          top: totalCell,
          width: cellSize,
          height: cellSize,
          backgroundColor: open ? "#1a1a1a" : "#1a1a1a",
          boxShadow: open
            ? "0 8px 32px rgba(0,0,0,0.15)"
            : "0 4px 20px rgba(0,0,0,0.12)",
        }}
        onClick={() => open ? handleClose() : setOpen(true)}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.94 }}
        layout
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.15 }}>
              <X size={18} color="#fff" strokeWidth={1.5} />
            </motion.div>
          ) : (
            <motion.div key="logo" className="flex flex-col items-center gap-0.5" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.8, opacity: 0 }}>
              <motion.svg width={16} height={16} viewBox="0 0 24 24" fill="none"
                animate={{ rotate: [0, 90, 0] }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
              >
                <line x1="4" y1="4" x2="20" y2="20" stroke="#C72B3B" strokeWidth="2.5" strokeLinecap="round" />
                <line x1="20" y1="4" x2="4" y2="20" stroke="#C72B3B" strokeWidth="2.5" strokeLinecap="round" />
                <circle cx="4" cy="4" r="1.5" fill="#C72B3B" />
                <circle cx="20" cy="4" r="1.5" fill="#C72B3B" />
                <circle cx="4" cy="20" r="1.5" fill="#C72B3B" />
                <circle cx="20" cy="20" r="1.5" fill="#C72B3B" />
              </motion.svg>
              <span style={{ fontSize: 5.5, color: "rgba(255,255,255,0.5)", letterSpacing: "0.14em", fontWeight: 500 }}>DOCK</span>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* TOOL PANEL — expands below the grid */}
      <AnimatePresence>
        {activeTool && activeToolDef && ActiveComponent && (
          <motion.div
            className="absolute z-30 rounded-2xl overflow-hidden"
            style={{
              top: totalCell * 3 + 8,
              left: "50%",
              transform: "translateX(-50%)",
              width: Math.max(totalCell * 3, 260),
              backgroundColor: "rgba(255,255,255,0.97)",
              backdropFilter: "blur(24px)",
              boxShadow: `0 12px 48px rgba(0,0,0,0.08), 0 0 0 1px ${activeToolDef.color}15`,
            }}
            initial={{ opacity: 0, y: -8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            {/* Panel header */}
            <div className="flex items-center justify-between px-4 py-2.5" style={{ borderBottom: `1px solid ${activeToolDef.color}10` }}>
              <div className="flex items-center gap-2">
                <activeToolDef.icon size={12} color={activeToolDef.color} strokeWidth={1.5} />
                <span style={{ fontSize: 11, fontWeight: 500, color: "#1a1a1a" }}>{activeToolDef.label}</span>
              </div>
              <motion.button
                className="w-5 h-5 flex items-center justify-center rounded-full border-none cursor-pointer"
                style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#ccc" }}
                onClick={() => setActiveTool(null)}
                whileTap={{ scale: 0.8 }}
              >
                <X size={9} />
              </motion.button>
            </div>
            {/* Panel content */}
            <div className="px-4 py-3">
              <ActiveComponent />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}