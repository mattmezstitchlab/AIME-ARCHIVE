import { motion, AnimatePresence } from "motion/react";
import {
  Heart, CalendarHeart, Image, Scissors,
  User, CalendarDays, MessageCircle, Compass,
} from "lucide-react";
import { useResponsive } from "./useResponsive";
import { HEART_RED, SORTIE_COLOR, type RadialAction, type RadialMenuItem, DEFAULT_RADIAL_ITEMS } from "./game-data";

interface RadialMenuProps {
  visible: boolean;
  cellSize: number;
  totalCell: number;
  playerColor: string;
  onAction: (action: RadialAction) => void;
  onClose: () => void;
  items?: RadialMenuItem[];
}

// 8 directions: N, NE, E, SE, S, SW, W, NW
const OFFSETS: [number, number][] = [
  [0, -1],  // N
  [1, -1],  // NE
  [1, 0],   // E
  [1, 1],   // SE
  [0, 1],   // S
  [-1, 1],  // SW
  [-1, 0],  // W
  [-1, -1], // NW
];

const ACTION_ICONS: Record<RadialAction, typeof Heart> = {
  battement: Heart,
  sortie: CalendarHeart,
  medias: Image,
  agent: Scissors,
  profil: User,
  agenda: CalendarDays,
  messages: MessageCircle,
  explorer: Compass,
};

const ACTION_COLORS: Record<RadialAction, string> = {
  battement: HEART_RED,
  sortie: SORTIE_COLOR,
  medias: "#6BA7B0",
  agent: "#9263A6",
  profil: "#1a1a1a",
  agenda: "#42A350",
  messages: "#4685B7",
  explorer: "#FFB515",
};

export function RadialMenu({
  visible,
  cellSize,
  totalCell,
  playerColor,
  onAction,
  onClose,
  items = DEFAULT_RADIAL_ITEMS,
}: RadialMenuProps) {
  const { isMobile } = useResponsive();
  const iconSize = isMobile ? 14 : 16;
  const menuCellSize = cellSize * 0.85;

  return (
    <AnimatePresence>
      {visible && (
        <>
          {/* Backdrop — click to close */}
          <motion.div
            className="fixed inset-0 z-15"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Menu items */}
          {items.map((item, i) => {
            const [ox, oy] = OFFSETS[item.position];
            const Icon = ACTION_ICONS[item.key];
            const color = ACTION_COLORS[item.key];
            const x = ox * totalCell;
            const y = oy * totalCell;

            return (
              <motion.div
                key={item.key}
                className="absolute z-20 cursor-pointer"
                style={{
                  left: `calc(50% + ${x}px - ${menuCellSize / 2}px)`,
                  top: `calc(50% + ${y}px - ${menuCellSize / 2}px)`,
                }}
                initial={{ opacity: 0, scale: 0.3 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.3 }}
                transition={{
                  type: "spring",
                  stiffness: 500,
                  damping: 25,
                  delay: i * 0.03,
                }}
              >
                <motion.button
                  className="flex flex-col items-center justify-center rounded-[3px] border-none cursor-pointer relative overflow-hidden"
                  style={{
                    width: menuCellSize,
                    height: menuCellSize,
                    backgroundColor: "rgba(255,255,255,0.92)",
                    backdropFilter: "blur(12px)",
                    boxShadow: `0 2px 12px rgba(0,0,0,0.06), 0 0 0 1px ${color}25`,
                  }}
                  onClick={() => onAction(item.key)}
                  whileHover={{ scale: 1.12, boxShadow: `0 4px 20px ${color}30` }}
                  whileTap={{ scale: 0.9 }}
                >
                  {/* Colored top bar */}
                  <div
                    className="absolute top-0 left-0 right-0"
                    style={{ height: 2.5, backgroundColor: color }}
                  />
                  <Icon
                    size={iconSize}
                    strokeWidth={1.6}
                    color={color}
                  />
                  <span
                    style={{
                      fontSize: isMobile ? 6 : 7,
                      color: "#999",
                      fontWeight: 400,
                      letterSpacing: "0.02em",
                      marginTop: 2,
                      lineHeight: 1,
                    }}
                  >
                    {item.label}
                  </span>
                </motion.button>
              </motion.div>
            );
          })}
        </>
      )}
    </AnimatePresence>
  );
}