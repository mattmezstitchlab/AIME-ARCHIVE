import { motion, AnimatePresence } from "motion/react";
import {
  CalendarHeart, Clock, MapPin, Users, X,
  Footprints, Palette, Brain, Sparkles, Ear, Compass,
  Timer, UserPlus, UserMinus,
} from "lucide-react";
import {
  SORTIE_CATEGORIES,
  SORTIE_DURATIONS,
  SORTIE_COLOR,
  type SortieEvent,
  type SortieCategory,
  type AccessibilityMode,
} from "./game-data";
import { useResponsive } from "./useResponsive";

const CATEGORY_ICONS: Record<SortieCategory, React.ReactNode> = {
  marche: <Footprints size={12} strokeWidth={1.5} />,
  atelier: <Palette size={12} strokeWidth={1.5} />,
  meditation: <Brain size={12} strokeWidth={1.5} />,
  celebration: <Sparkles size={12} strokeWidth={1.5} />,
  ecoute: <Ear size={12} strokeWidth={1.5} />,
  decouverte: <Compass size={12} strokeWidth={1.5} />,
};

interface SortieInfoCardProps {
  sortie: SortieEvent | null;
  visible: boolean;
  onClose: () => void;
  onJoin: (sortieId: string) => void;
  onLeave: (sortieId: string) => void;
  currentPlayerId: string;
  mode: AccessibilityMode;
}

export function SortieInfoCard({
  sortie,
  visible,
  onClose,
  onJoin,
  onLeave,
  currentPlayerId,
  mode,
}: SortieInfoCardProps) {
  const { isMobile } = useResponsive();
  const isSenior = mode === "senior";
  const fontSize = isMobile ? 12 : isSenior ? 14 : 12;

  if (!sortie) return null;

  const isCreator = sortie.creatorId === currentPlayerId;
  const hasJoined = sortie.participants.some((p) => p.id === currentPlayerId);
  const isFull = sortie.maxParticipants ? sortie.participants.length >= sortie.maxParticipants : false;
  const catLabel = SORTIE_CATEGORIES.find((c) => c.key === sortie.category)?.label || sortie.category;
  const durLabel = SORTIE_DURATIONS.find((d) => d.key === sortie.duration)?.label || sortie.duration;

  const formatDate = (d: string) => {
    const date = new Date(d + "T00:00:00");
    return date.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed top-5 left-1/2 -translate-x-1/2 z-40"
          style={{ maxWidth: isMobile ? "calc(100vw - 24px)" : "90vw", width: isMobile ? "calc(100vw - 24px)" : 380 }}
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.98 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <div
            className="rounded-2xl px-5 py-4 flex flex-col gap-3"
            style={{
              backgroundColor: "rgba(255,255,255,0.96)",
              backdropFilter: "blur(24px)",
              boxShadow: `0 8px 40px rgba(0,0,0,0.06), 0 0 0 1px ${SORTIE_COLOR}15`,
              borderTop: `2px solid ${SORTIE_COLOR}30`,
            }}
          >
            {/* Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <CalendarHeart size={16} color={SORTIE_COLOR} strokeWidth={1.5} />
                <span style={{ fontSize: 9, letterSpacing: "0.12em", color: SORTIE_COLOR, fontWeight: 500, textTransform: "uppercase" }}>
                  Sortie
                </span>
              </div>
              <button
                onClick={onClose}
                className="flex items-center justify-center w-6 h-6 rounded-full cursor-pointer border-none"
                style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#bbb" }}
              >
                <X size={12} />
              </button>
            </div>

            {/* Title + Creator */}
            <div>
              <h3 style={{ fontSize: fontSize + 2, fontWeight: 600, color: "#1a1a1a", margin: 0 }}>
                {sortie.title}
              </h3>
              <div className="flex items-center gap-1.5 mt-1">
                <span
                  className="inline-block w-2.5 h-2.5 rounded-[2px]"
                  style={{ backgroundColor: sortie.creatorColor }}
                />
                <span style={{ fontSize: fontSize - 2, color: "#999", fontWeight: 300 }}>
                  par {sortie.creatorPseudo}
                </span>
              </div>
            </div>

            {sortie.description && (
              <p style={{ fontSize: fontSize - 1, color: "#777", fontWeight: 300, fontStyle: "italic", margin: 0, lineHeight: 1.5 }}>
                « {sortie.description} »
              </p>
            )}

            {/* Info pills */}
            <div className="flex flex-wrap gap-2">
              <InfoPill icon={CATEGORY_ICONS[sortie.category]} label={catLabel} color={SORTIE_COLOR} fontSize={fontSize} />
              <InfoPill icon={<CalendarHeart size={10} strokeWidth={1.5} />} label={formatDate(sortie.date)} fontSize={fontSize} />
              {sortie.time && (
                <InfoPill icon={<Clock size={10} strokeWidth={1.5} />} label={sortie.time} fontSize={fontSize} />
              )}
              <InfoPill icon={<Timer size={10} strokeWidth={1.5} />} label={durLabel} fontSize={fontSize} />
              {sortie.placeName && (
                <InfoPill icon={<MapPin size={10} strokeWidth={1.5} />} label={sortie.placeName} fontSize={fontSize} />
              )}
            </div>

            {/* Participants */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-1.5">
                <Users size={11} color="#999" strokeWidth={1.5} />
                <span style={{ fontSize: fontSize - 2, color: "#999" }}>
                  {sortie.participants.length}
                  {sortie.maxParticipants ? ` / ${sortie.maxParticipants}` : ""}
                  {" "}participant{sortie.participants.length !== 1 ? "s" : ""}
                </span>
              </div>
              {sortie.participants.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {sortie.participants.map((p) => (
                    <span
                      key={p.id}
                      className="flex items-center gap-1 px-2 py-0.5 rounded-full"
                      style={{ backgroundColor: `${p.color}12`, fontSize: fontSize - 3 }}
                    >
                      <span className="inline-block w-2 h-2 rounded-[1px]" style={{ backgroundColor: p.color }} />
                      <span style={{ color: "#777" }}>{p.pseudo}</span>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Join / Leave button */}
            {!isCreator && (
              <div className="pt-1">
                {hasJoined ? (
                  <motion.button
                    className="w-full py-2 rounded-xl cursor-pointer border-none flex items-center justify-center gap-2"
                    style={{
                      backgroundColor: "rgba(0,0,0,0.04)",
                      color: "#999",
                      fontSize: fontSize - 1,
                    }}
                    onClick={() => onLeave(sortie.id)}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <UserMinus size={13} strokeWidth={1.5} />
                    Se retirer
                  </motion.button>
                ) : (
                  <motion.button
                    className="w-full py-2.5 rounded-xl cursor-pointer border-none flex items-center justify-center gap-2"
                    style={{
                      backgroundColor: isFull ? "rgba(0,0,0,0.06)" : SORTIE_COLOR,
                      color: isFull ? "#bbb" : "#fff",
                      fontSize: fontSize - 1,
                      letterSpacing: "0.04em",
                    }}
                    onClick={() => !isFull && onJoin(sortie.id)}
                    whileHover={isFull ? {} : { scale: 1.01 }}
                    whileTap={isFull ? {} : { scale: 0.99 }}
                  >
                    <UserPlus size={13} strokeWidth={1.5} />
                    {isFull ? "Complet" : "Rejoindre"}
                  </motion.button>
                )}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function InfoPill({
  icon,
  label,
  color,
  fontSize,
}: {
  icon: React.ReactNode;
  label: string;
  color?: string;
  fontSize: number;
}) {
  return (
    <span
      className="flex items-center gap-1 px-2 py-1 rounded-full"
      style={{
        fontSize: fontSize - 3,
        backgroundColor: color ? `${color}10` : "rgba(0,0,0,0.03)",
        color: color || "#999",
        fontWeight: 400,
      }}
    >
      {icon}
      {label}
    </span>
  );
}