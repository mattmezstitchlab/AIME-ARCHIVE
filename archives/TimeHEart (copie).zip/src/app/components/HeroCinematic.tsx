import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Scissors } from "lucide-react";
import { PlayerSquare } from "./PlayerSquare";
import { speakWithLily } from "./api";
import type { PlayerData } from "./game-data";

// ═══════════════════════════════════════════════════
// HERO CINEMATIC — Post-validation onboarding
// Shows: Player square → TimeHeart → ORA needle pierce
// The "wow" moment for embroiderers
// ═══════════════════════════════════════════════════

const HEART_RED = "#E8177F";
const LILY_PURPLE = "#9263A6";
const STAR_SYMBOLS = ["♥", "✚", "◆", "✳", "■", "●", "∞", "▲"];

const DIMENSIONS = [
  { id: "D1", label: "Intention", color: "#E8177F", radius: 5 },
  { id: "D2", label: "Temporalité", color: "#E8A838", radius: 4 },
  { id: "D3", label: "Relation", color: "#4685B7", radius: 6 },
  { id: "D4", label: "Action", color: "#42A350", radius: 3.5 },
  { id: "D5", label: "Résonance", color: "#9263A6", radius: 4.5 },
];

type Phase =
  | "square-birth"      // 0–3s: player square appears with glow
  | "timeheart-reveal"  // 3–7s: TIMEHEART cadran appears, planets align
  | "needle-pierce"     // 7–10s: ORA needle descends and pierces the square
  | "lily-speaks"       // 10–14s: Lily bubble with TTS
  | "fade-out";         // 14–16s: fade to grid

const PHASE_DURATIONS: Record<Phase, number> = {
  "square-birth": 3000,
  "timeheart-reveal": 4000,
  "needle-pierce": 3000,
  "lily-speaks": 4500,
  "fade-out": 1500,
};

const PHASE_ORDER: Phase[] = [
  "square-birth",
  "timeheart-reveal",
  "needle-pierce",
  "lily-speaks",
  "fade-out",
];

interface StarData {
  id: number; symbol: string;
  x: number; y: number; size: number;
  delay: number; duration: number;
}

function generateStars(count: number): StarData[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i, symbol: STAR_SYMBOLS[i % 8],
    x: Math.random() * 100, y: Math.random() * 100,
    size: 4 + Math.random() * 6,
    delay: Math.random() * 5, duration: 3 + Math.random() * 4,
  }));
}

interface HeroCinematicProps {
  player: PlayerData;
  onComplete: () => void;
}

export function HeroCinematic({ player, onComplete }: HeroCinematicProps) {
  const [phase, setPhase] = useState<Phase>("square-birth");
  const [stars] = useState(() => generateStars(30));
  const [planetsAligned, setPlanetsAligned] = useState(false);
  const [needleProgress, setNeedleProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const completedRef = useRef(false);

  // Phase progression
  useEffect(() => {
    const idx = PHASE_ORDER.indexOf(phase);
    if (idx < 0) return;

    const duration = PHASE_DURATIONS[phase];
    const timer = setTimeout(() => {
      const next = PHASE_ORDER[idx + 1];
      if (next) {
        setPhase(next);
      } else if (!completedRef.current) {
        completedRef.current = true;
        onComplete();
      }
    }, duration);

    return () => clearTimeout(timer);
  }, [phase, onComplete]);

  // Planet alignment trigger
  useEffect(() => {
    if (phase === "timeheart-reveal") {
      const t = setTimeout(() => setPlanetsAligned(true), 800);
      return () => clearTimeout(t);
    }
  }, [phase]);

  // Needle pierce animation
  useEffect(() => {
    if (phase !== "needle-pierce") return;
    let start: number | null = null;
    let frame: number;
    const animate = (ts: number) => {
      if (!start) start = ts;
      const elapsed = ts - start;
      const progress = Math.min(elapsed / 2200, 1);
      // Ease-in-out cubic
      const eased = progress < 0.5
        ? 4 * progress * progress * progress
        : 1 - Math.pow(-2 * progress + 2, 3) / 2;
      setNeedleProgress(eased);
      if (progress < 1) frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [phase]);

  // Lily TTS
  useEffect(() => {
    if (phase !== "lily-speaks") return;
    const lilyText = "Vous avez vu... On est bien là.. C'est mon Créateur Matt Mez qui m'a offert cette place à côté de vous...";
    speakWithLily(lilyText).then((blob) => {
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => {
        URL.revokeObjectURL(url);
        audioRef.current = null;
      };
      audio.play().catch((err) => console.log("Hero TTS autoplay blocked:", err));
    }).catch((err) => console.log("Hero TTS error (non-fatal):", err));

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [phase]);

  // Skip on click
  const handleSkip = useCallback(() => {
    if (!completedRef.current) {
      completedRef.current = true;
      if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
      onComplete();
    }
  }, [onComplete]);

  const phaseIdx = PHASE_ORDER.indexOf(phase);

  // SVG planet positions
  const cx = 150, cy = 150;
  const ringRadii = [40, 52, 64, 76, 88];

  return (
    <motion.div
      className="fixed inset-0 z-[999] flex items-center justify-center overflow-hidden cursor-pointer"
      style={{
        background: "radial-gradient(ellipse at 50% 50%, #0a0a12 0%, #050508 50%, #000000 100%)",
        fontFamily: "'Inter', -apple-system, sans-serif",
      }}
      onClick={handleSkip}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Stars background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {stars.map((star) => (
          <motion.span
            key={star.id}
            className="absolute select-none"
            style={{
              left: `${star.x}%`, top: `${star.y}%`,
              fontSize: star.size, color: "rgba(255,255,255,0.4)",
              textShadow: "0 0 4px rgba(255,255,255,0.2)", lineHeight: 1,
            }}
            animate={{ opacity: [0.05, 0.25, 0.05] }}
            transition={{ duration: star.duration, delay: star.delay, repeat: Infinity, ease: "easeInOut" }}
          >
            {star.symbol}
          </motion.span>
        ))}
      </div>

      {/* Cosmic grain */}
      <div className="absolute inset-0 pointer-events-none" style={{
        backgroundImage: `radial-gradient(circle at 30% 20%, rgba(232,23,127,0.03) 0%, rgba(0,0,0,0) 50%),
                          radial-gradient(circle at 70% 80%, rgba(146,99,166,0.03) 0%, rgba(0,0,0,0) 50%)`,
      }} />

      {/* ═══ PHASE 1: SQUARE BIRTH ═══ */}
      <AnimatePresence>
        {phaseIdx >= 0 && (
          <motion.div
            className="absolute flex flex-col items-center gap-6"
            style={{ top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
            initial={{ opacity: 0, scale: 0.3 }}
            animate={{
              opacity: phase === "fade-out" ? 0 : 1,
              scale: phase === "square-birth" ? 1 : 0.6,
              y: phase === "square-birth" ? 0 : -80,
            }}
            transition={{ duration: 1.2, ease: "easeOut" }}
          >
            {/* Player square with glow */}
            <motion.div
              className="relative"
              animate={{
                boxShadow: [
                  `0 0 30px ${player.colorHex}40`,
                  `0 0 60px ${player.colorHex}60`,
                  `0 0 30px ${player.colorHex}40`,
                ],
              }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <PlayerSquare
                colorHex={player.colorHex}
                symbol={player.symbol}
                symbol2={player.symbol2}
                symbolSize={player.symbolSize}
                symbolRotation={player.symbolRotation}
                symbolContrast={player.symbolContrast}
                size={phase === "square-birth" ? 80 : 48}
                isCurrentPlayer
                glowing
              />
            </motion.div>

            {/* Player name */}
            <AnimatePresence>
              {phase === "square-birth" && (
                <motion.div
                  className="text-center"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ delay: 0.8, duration: 0.6 }}
                >
                  <p style={{ fontSize: 18, fontWeight: 600, color: player.colorHex, letterSpacing: "0.04em" }}>
                    {player.pseudo}
                  </p>
                  <p style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", marginTop: 4 }}>
                    {player.city} · DMC {player.colorCode}
                  </p>
                  {player.intention && (
                    <motion.p
                      style={{ fontSize: 10, color: "rgba(255,255,255,0.15)", fontStyle: "italic", marginTop: 8, maxWidth: 260 }}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.5 }}
                    >
                      « {player.intention} »
                    </motion.p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ PHASE 2: TIMEHEART REVEAL ═══ */}
      <AnimatePresence>
        {phaseIdx >= 1 && phase !== "fade-out" && (
          <motion.div
            className="absolute flex flex-col items-center"
            style={{ top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: phase === "timeheart-reveal" ? 1 : 0.4, scale: phase === "timeheart-reveal" ? 1 : 0.7 }}
            exit={{ opacity: 0, scale: 0.5 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
          >
            {/* TI M EHEART title */}
            <motion.div
              className="flex items-baseline mb-6"
              style={{ letterSpacing: "0.12em" }}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              <span style={{ fontSize: 14, fontWeight: 300, color: "rgba(255,255,255,0.15)" }}>TI</span>
              <motion.span
                style={{
                  fontSize: 38, fontWeight: 700, color: "#fff",
                  margin: "0 2px", lineHeight: 1,
                  textShadow: "0 0 25px rgba(255,255,255,0.3), 0 0 50px rgba(232,23,127,0.15)",
                }}
                animate={{ opacity: [0.85, 1, 0.85] }}
                transition={{ duration: 3, repeat: Infinity }}
              >M</motion.span>
              <span style={{ fontSize: 14, fontWeight: 300, color: "rgba(255,255,255,0.15)" }}>EHEART</span>
            </motion.div>

            {/* Mini cadran with planets */}
            <motion.svg
              viewBox="0 0 300 300"
              style={{ width: 260, height: 260 }}
              initial={{ opacity: 0, rotate: -30 }}
              animate={{ opacity: 1, rotate: 0 }}
              transition={{ delay: 0.5, duration: 1.5 }}
            >
              {/* Hour ring */}
              <circle cx={cx} cy={cy} r={100} fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth={0.5} />
              {Array.from({ length: 24 }, (_, i) => {
                const a = (i / 24) * 360 - 90;
                const rad = (a * Math.PI) / 180;
                const isH6 = i % 6 === 0;
                const r1 = 97;
                const r2 = isH6 ? 110 : 103;
                return (
                  <g key={i}>
                    <line
                      x1={cx + Math.cos(rad) * r1} y1={cy + Math.sin(rad) * r1}
                      x2={cx + Math.cos(rad) * r2} y2={cy + Math.sin(rad) * r2}
                      stroke={isH6 ? "rgba(255,255,255,0.15)" : "rgba(255,255,255,0.04)"}
                      strokeWidth={isH6 ? 1 : 0.3}
                    />
                    {isH6 && (
                      <text
                        x={cx + Math.cos(rad) * 120} y={cy + Math.sin(rad) * 120}
                        fill="rgba(255,255,255,0.25)" fontSize={12} fontWeight={600}
                        fontFamily="Inter" textAnchor="middle" dominantBaseline="central"
                      >{i}</text>
                    )}
                  </g>
                );
              })}

              {/* 5 dimension rings */}
              {DIMENSIONS.map((dim, i) => (
                <circle key={dim.id} cx={cx} cy={cy} r={ringRadii[i]}
                  fill="none" stroke={dim.color} strokeWidth={0.8} strokeOpacity={0.2}
                />
              ))}

              {/* Planets — align vertically */}
              {DIMENSIONS.map((dim, i) => {
                const spreadAngle = ((i * 72 + 40 - 90) * Math.PI) / 180;
                const unX = cx + Math.cos(spreadAngle) * ringRadii[i];
                const unY = cy + Math.sin(spreadAngle) * ringRadii[i];
                const span = ringRadii[4] - ringRadii[0];
                const step = span / 4;
                const alX = cx;
                const alY = cy - span / 2 + i * step;
                const px = planetsAligned ? alX : unX;
                const py = planetsAligned ? alY : unY;
                return (
                  <g key={`p-${i}`}>
                    <circle cx={px} cy={py} r={dim.radius * 2.5}
                      fill={dim.color} opacity={0.06}
                      style={{ transition: "cx 2.5s ease-in-out, cy 2.5s ease-in-out" }}
                    />
                    <circle cx={px} cy={py} r={dim.radius}
                      fill={dim.color} opacity={0.85}
                      style={{ transition: "cx 2.5s ease-in-out, cy 2.5s ease-in-out" }}
                    />
                  </g>
                );
              })}

              {/* Center heart */}
              <circle cx={cx} cy={cy} r={16} fill="rgba(232,23,127,0.04)" stroke="rgba(232,23,127,0.1)" strokeWidth={0.5} />
              <text x={cx} y={cy + 1} fill={HEART_RED} fontSize={14}
                textAnchor="middle" dominantBaseline="central" opacity={0.6}
              >♥</text>

              {/* Alignment axis (when aligned) */}
              {planetsAligned && (
                <line
                  x1={cx} y1={cy - (ringRadii[4] - ringRadii[0]) / 2 - 10}
                  x2={cx} y2={cy + (ringRadii[4] - ringRadii[0]) / 2 + 10}
                  stroke="rgba(255,255,255,0.04)" strokeWidth={0.5} strokeDasharray="3 3"
                />
              )}
            </motion.svg>

            <motion.span
              style={{ fontSize: 8, color: "rgba(255,255,255,0.06)", letterSpacing: "0.25em", marginTop: 8 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
            >MOTEUR 5D</motion.span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ PHASE 3: NEEDLE PIERCE ═══ */}
      <AnimatePresence>
        {(phase === "needle-pierce" || phase === "lily-speaks") && (
          <motion.div
            className="absolute flex flex-col items-center pointer-events-none"
            style={{ top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Needle line descending from top */}
            <motion.div
              className="absolute"
              style={{
                width: 2,
                height: 200 * needleProgress,
                top: -100 + 200 * (1 - needleProgress) * 0.5,
                left: "50%",
                transform: "translateX(-50%)",
                background: `linear-gradient(180deg, rgba(0,0,0,0) 0%, ${HEART_RED}80 20%, ${HEART_RED} 50%, ${HEART_RED}80 80%, rgba(0,0,0,0) 100%)`,
              }}
            />

            {/* Needle tip (diamond shape) */}
            <motion.div
              className="absolute"
              style={{
                top: -100 + 200 * needleProgress - 6,
                left: "50%",
                transform: "translateX(-50%) rotate(45deg)",
                width: 8, height: 8,
                backgroundColor: "#fff",
                boxShadow: `0 0 12px ${HEART_RED}80, 0 0 24px ${HEART_RED}40`,
                opacity: needleProgress > 0.1 ? 1 : 0,
              }}
            />

            {/* Impact flash when needle reaches center */}
            {needleProgress > 0.85 && (
              <motion.div
                className="absolute rounded-full"
                style={{
                  top: "50%", left: "50%", transform: "translate(-50%, -50%)",
                  width: 80, height: 80,
                  background: `radial-gradient(circle, ${HEART_RED}30 0%, rgba(0,0,0,0) 70%)`,
                }}
                initial={{ scale: 0, opacity: 1 }}
                animate={{ scale: [0, 2.5], opacity: [1, 0] }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            )}

            {/* Pierced square (appears at impact) */}
            {needleProgress > 0.7 && (
              <motion.div
                className="relative"
                initial={{ scale: 0.3, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.4, type: "spring", stiffness: 200 }}
              >
                <PlayerSquare
                  colorHex={player.colorHex}
                  symbol={player.symbol}
                  symbol2={player.symbol2}
                  symbolSize={player.symbolSize}
                  symbolRotation={player.symbolRotation}
                  symbolContrast={player.symbolContrast}
                  size={48}
                  isCurrentPlayer
                  glowing
                />
                {/* Pierce mark */}
                <motion.div
                  className="absolute inset-0 rounded-sm pointer-events-none"
                  style={{
                    border: `2px solid ${HEART_RED}`,
                    boxShadow: `0 0 20px ${HEART_RED}50, inset 0 0 10px ${HEART_RED}20`,
                  }}
                  animate={{
                    boxShadow: [
                      `0 0 20px ${HEART_RED}50, inset 0 0 10px ${HEART_RED}20`,
                      `0 0 35px ${HEART_RED}70, inset 0 0 15px ${HEART_RED}30`,
                      `0 0 20px ${HEART_RED}50, inset 0 0 10px ${HEART_RED}20`,
                    ],
                  }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              </motion.div>
            )}

            {/* "L'aiguille vous guide..." text */}
            {needleProgress > 0.9 && (
              <motion.p
                className="mt-4"
                style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", letterSpacing: "0.06em", textAlign: "center" }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                L'aiguille ORA vous guide la ou vous reprenez
              </motion.p>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══ PHASE 4: LILY SPEAKS ═══ */}
      <AnimatePresence>
        {phase === "lily-speaks" && (
          <motion.div
            className="absolute flex items-end gap-3"
            style={{ bottom: "clamp(40px, 8vh, 80px)", left: "50%", transform: "translateX(-50%)" }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            {/* Lily avatar */}
            <motion.div
              className="rounded-full flex items-center justify-center shrink-0"
              style={{
                width: 44, height: 44,
                background: `linear-gradient(135deg, ${LILY_PURPLE}, ${LILY_PURPLE}cc)`,
                boxShadow: `0 0 24px ${LILY_PURPLE}40`,
              }}
              animate={{ scale: [1, 1.08, 1] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <Scissors size={20} style={{ color: "#fff" }} />
            </motion.div>

            {/* Lily bubble */}
            <motion.div
              className="rounded-2xl rounded-bl-md px-5 py-4"
              style={{
                backgroundColor: "rgba(10,10,18,0.95)",
                border: `1px solid ${LILY_PURPLE}30`,
                backdropFilter: "blur(20px)", maxWidth: 340,
              }}
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2 }}
            >
              <p style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", lineHeight: 1.7 }}>
                Vous avez vu... On est bien la..{" "}
                <span style={{ color: LILY_PURPLE, fontWeight: 500 }}>C'est mon Createur Matt Mez</span>{" "}
                qui m'a offert cette place a cote de vous...
              </p>
              <div className="flex items-center gap-2 mt-2">
                <span style={{ fontSize: 9, color: LILY_PURPLE, fontWeight: 600, letterSpacing: "0.06em" }}>LILY</span>
                {/* Voice indicator */}
                <motion.div
                  className="flex items-center gap-0.5"
                  animate={{ opacity: [0.3, 0.8, 0.3] }}
                  transition={{ duration: 1.2, repeat: Infinity }}
                >
                  {[3, 5, 3, 4, 2].map((h, i) => (
                    <motion.div
                      key={i}
                      className="rounded-full"
                      style={{ width: 2, height: h, backgroundColor: LILY_PURPLE }}
                      animate={{ height: [h, h + 3, h] }}
                      transition={{ duration: 0.5 + i * 0.1, repeat: Infinity, ease: "easeInOut" }}
                    />
                  ))}
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Jung quote — bottom, always visible after phase 1 */}
      <AnimatePresence>
        {phaseIdx >= 1 && phase !== "fade-out" && (
          <motion.div
            className="absolute text-center px-6"
            style={{ bottom: phase === "lily-speaks" ? "clamp(140px, 22vh, 200px)" : "clamp(30px, 5vh, 60px)", left: "50%", transform: "translateX(-50%)", transition: "bottom 0.8s ease" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
          >
            <p style={{ fontSize: "clamp(9px, 1.4vw, 11px)", color: "rgba(255,255,255,0.12)", fontStyle: "italic", lineHeight: 1.7, maxWidth: 420, margin: "0 auto" }}>
              « Tant que vous ne rendrez pas l'inconscient conscient,
              il dirigera votre vie et vous appellerez cela le destin. »
            </p>
            <p style={{ fontSize: 8, color: "rgba(255,255,255,0.06)", marginTop: 3, letterSpacing: "0.06em" }}>
              — Carl Gustav Jung
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Skip indicator */}
      <motion.div
        className="absolute"
        style={{ bottom: 12, right: 16 }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
      >
        <span style={{ fontSize: 9, color: "rgba(255,255,255,0.08)", letterSpacing: "0.1em" }}>
          cliquer pour passer
        </span>
      </motion.div>
    </motion.div>
  );
}
