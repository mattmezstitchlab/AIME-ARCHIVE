import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PlayerSquare } from "./PlayerSquare";
import { StitchLabLogo } from "./StitchLabLogo";
import { useResponsive } from "./useResponsive";
import {
  DMC_COLORS, PRIMARY_SHAPES, EXTENDED_SYMBOLS, BG_IVORY,
  type AccessibilityMode,
} from "./game-data";

interface SquareEditorProps {
  onComplete: (data: {
    pseudo: string;
    city: string;
    intention: string;
    colorHex: string;
    colorCode: string;
    symbol: string;
    symbol2?: string;
    symbolSize: number;
    symbolRotation: number;
    symbolContrast: number;
  }) => void;
  mode: AccessibilityMode;
}

export function SquareEditor({ onComplete, mode }: SquareEditorProps) {
  const { isMobile, isTablet } = useResponsive();
  const [pseudo, setPseudo] = useState("");
  const [city, setCity] = useState("");
  const [intention, setIntention] = useState("");
  const [selectedColor, setSelectedColor] = useState(DMC_COLORS[2]);
  const [selectedSymbol, setSelectedSymbol] = useState("■");
  const [selectedSymbol2, setSelectedSymbol2] = useState<string | null>(null);
  const [symbolSize, setSymbolSize] = useState(50);
  const [symbolRotation, setSymbolRotation] = useState(0);
  const [symbolContrast, setSymbolContrast] = useState(100);
  const [activeTab, setActiveTab] = useState<"color" | "symbol" | "adjust">("color");

  const normalColors = DMC_COLORS.filter((c) => !c.rare);
  const isSenior = mode === "senior";
  const isChild = mode === "child";
  const isLargeMode = isSenior || isChild;
  const baseFontSize = isMobile ? 13 : isSenior ? 16 : 14;
  const canProceed = pseudo.trim().length > 0;

  const previewSize = isMobile ? 90 : isTablet ? 110 : isSenior ? 140 : 120;
  const colorSwatchSize = isMobile ? 28 : isLargeMode ? 36 : 26;
  const maxColorGridH = isMobile ? 180 : 260;

  const handleComplete = () => {
    if (!canProceed) return;
    onComplete({
      pseudo: pseudo.trim(),
      city: city.trim(),
      intention: intention.trim(),
      colorHex: selectedColor.hex,
      colorCode: selectedColor.code,
      symbol: selectedSymbol,
      symbol2: selectedSymbol2 || undefined,
      symbolSize,
      symbolRotation,
      symbolContrast,
    });
  };

  const handleSymbol2Click = (sym: string) => {
    if (selectedSymbol2 === sym) setSelectedSymbol2(null);
    else setSelectedSymbol2(sym);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center overflow-hidden" style={{ backgroundColor: BG_IVORY }}>
      {/* Blurred grid background */}
      <div className="absolute inset-0 opacity-[0.04]" style={{ filter: "blur(4px)" }}>
        <svg className="w-full h-full">
          <defs>
            <pattern id="editorGrid" width="52" height="52" patternUnits="userSpaceOnUse">
              <path d="M 52 0 L 0 0 0 52" fill="none" stroke="#000" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#editorGrid)" />
        </svg>
      </div>

      {/* Header */}
      <motion.div
        className="fixed top-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <StitchLabLogo size={isMobile ? "sm" : "sm"} animate />
        <span style={{ fontSize: 9, letterSpacing: "0.12em", color: "#ddd", fontWeight: 300, marginTop: 2 }}>
          Creez votre presence
        </span>
      </motion.div>

      {/* Editor panel */}
      <motion.div
        className="relative z-10 flex flex-col gap-5 w-full rounded-2xl"
        style={{
          flexDirection: isMobile ? "column" : undefined,
          maxWidth: isMobile ? "calc(100vw - 32px)" : isTablet ? 680 : 920,
          margin: isMobile ? "0 16px" : "0 16px",
          padding: isMobile ? 20 : isTablet ? 24 : 40,
          backgroundColor: "rgba(255,255,255,0.75)",
          backdropFilter: "blur(24px)",
          boxShadow: "0 8px 60px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.02)",
          maxHeight: isMobile ? "82vh" : "85vh",
          overflow: "auto",
          marginTop: isMobile ? 50 : 0,
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Mobile: vertical stack. Desktop: side by side */}
        <div className={`flex ${isMobile ? "flex-col" : "flex-row"} gap-${isMobile ? "4" : isTablet ? "6" : "10"}`}>
          {/* Left: Preview + Identity */}
          <div className={`flex ${isMobile ? "flex-row items-center gap-4" : "flex-col items-center gap-5"} ${!isMobile ? "min-w-[210px]" : ""}`}>
            {!isMobile && (
              <p style={{ fontSize: 9, letterSpacing: "0.2em", color: "#ccc", textTransform: "uppercase" }}>
                Aperçu
              </p>
            )}

            <motion.div layout transition={{ type: "spring", stiffness: 400, damping: 30 }}>
              <PlayerSquare
                colorHex={selectedColor.hex}
                symbol={selectedSymbol}
                symbol2={selectedSymbol2 || undefined}
                symbolSize={symbolSize}
                symbolRotation={symbolRotation}
                symbolContrast={symbolContrast}
                size={previewSize}
                isCurrentPlayer
                mode={mode}
              />
            </motion.div>

            <div className={isMobile ? "flex-1 min-w-0" : "text-center"}>
              {!isMobile && (
                <>
                  <p style={{ fontSize: 10, color: "#bbb" }}>DMC {selectedColor.code}</p>
                  <p style={{ fontSize: 9, color: "#ddd" }}>{selectedColor.name}</p>
                </>
              )}

              {/* Identity fields — on mobile, beside preview */}
              {isMobile && (
                <div className="flex flex-col gap-2">
                  <FieldInput label="Pseudo" required value={pseudo} onChange={setPseudo} placeholder="Votre nom" maxLength={20} fontSize={baseFontSize} compact />
                  <FieldInput label="Ville" value={city} onChange={setCity} placeholder="Optionnel" maxLength={30} fontSize={baseFontSize} compact />
                </div>
              )}
            </div>
          </div>

          {/* Desktop: Identity fields below preview */}
          {!isMobile && (
            <div className="flex flex-col items-center">
              <div className="flex flex-col gap-3 w-full max-w-[220px]">
                <FieldInput label="Pseudo" required value={pseudo} onChange={setPseudo} placeholder="Votre nom" maxLength={20} fontSize={baseFontSize} />
                <FieldInput label="Ville" value={city} onChange={setCity} placeholder="Optionnel" maxLength={30} fontSize={baseFontSize} />
                <FieldInput label="Intention" value={intention} onChange={setIntention} placeholder="Un mot doux" maxLength={40} fontSize={baseFontSize} />
              </div>
            </div>
          )}

          {/* Right: Pickers */}
          <div className="flex-1 flex flex-col gap-3 min-w-0">
            {isMobile && (
              <FieldInput label="Intention" value={intention} onChange={setIntention} placeholder="Un mot doux" maxLength={40} fontSize={baseFontSize} compact />
            )}

            {/* Tabs */}
            <div className="flex gap-0.5 p-1 rounded-lg" style={{ backgroundColor: "rgba(0,0,0,0.03)" }}>
              {([
                { key: "color" as const, label: "Couleurs" },
                { key: "symbol" as const, label: "Formes" },
                { key: "adjust" as const, label: "Ajuster" },
              ]).map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className="flex-1 py-2 px-2 rounded-md cursor-pointer border-none transition-all"
                  style={{
                    backgroundColor: activeTab === tab.key ? "#fff" : "rgba(0,0,0,0)",
                    boxShadow: activeTab === tab.key ? "0 1px 4px rgba(0,0,0,0.05)" : "none",
                    fontSize: isMobile ? 11 : isSenior ? 12 : 11,
                    color: activeTab === tab.key ? "#1a1a1a" : "#aaa",
                    fontWeight: activeTab === tab.key ? 500 : 400,
                  }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <AnimatePresence mode="wait">
              {activeTab === "color" && (
                <motion.div
                  key="color"
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 8 }}
                  transition={{ duration: 0.15 }}
                  className="flex flex-col gap-2"
                >
                  <p style={{ fontSize: 9, color: "#ccc", letterSpacing: "0.05em" }}>
                    Palette DMC — {normalColors.length} fils
                  </p>
                  <div
                    className="grid gap-1 overflow-y-auto pr-1"
                    style={{
                      gridTemplateColumns: `repeat(auto-fill, minmax(${colorSwatchSize}px, 1fr))`,
                      maxHeight: maxColorGridH,
                    }}
                  >
                    {normalColors.map((color) => (
                      <motion.button
                        key={color.code}
                        className="aspect-square rounded-[2px] cursor-pointer border-none p-0"
                        style={{
                          backgroundColor: color.hex,
                          outline: selectedColor.code === color.code ? "2px solid #1a1a1a" : "1px solid rgba(0,0,0,0.06)",
                          outlineOffset: selectedColor.code === color.code ? 1 : 0,
                        }}
                        onClick={() => setSelectedColor(color)}
                        whileHover={{ scale: 1.2 }}
                        whileTap={{ scale: 0.9 }}
                        title={`DMC ${color.code} — ${color.name}`}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {activeTab === "symbol" && (
                <motion.div
                  key="symbol"
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 8 }}
                  transition={{ duration: 0.15 }}
                  className="flex flex-col gap-4 overflow-y-auto pr-1"
                  style={{ maxHeight: isMobile ? 220 : 320 }}
                >
                  {/* Primary shapes */}
                  <div className="flex flex-col gap-2">
                    <p style={{ fontSize: 9, color: "#bbb", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                      Forme principale
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {PRIMARY_SHAPES.map((shape) => (
                        <motion.button
                          key={shape.char}
                          className="flex flex-col items-center gap-0.5 rounded-lg cursor-pointer border-none"
                          style={{
                            padding: isMobile ? "6px 8px" : "8px 10px",
                            backgroundColor: selectedSymbol === shape.char ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.015)",
                            outline: selectedSymbol === shape.char ? "2px solid #1a1a1a" : "none",
                            outlineOffset: 1,
                            minWidth: isMobile ? 40 : isLargeMode ? 52 : 44,
                          }}
                          onClick={() => setSelectedSymbol(shape.char)}
                          whileHover={{ scale: 1.08 }}
                          whileTap={{ scale: 0.92 }}
                        >
                          <span style={{ fontSize: isMobile ? 16 : isLargeMode ? 20 : 17 }}>{shape.char}</span>
                          <span style={{ fontSize: isMobile ? 7 : 8, color: "#ccc" }}>{shape.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  {/* Extended symbols */}
                  <div className="flex flex-col gap-2">
                    <p style={{ fontSize: 9, color: "#ccc", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                      Symboles étendus
                    </p>
                    <div
                      className="grid gap-1"
                      style={{ gridTemplateColumns: `repeat(auto-fill, minmax(${isMobile ? 32 : isLargeMode ? 42 : 34}px, 1fr))` }}
                    >
                      {EXTENDED_SYMBOLS.map((sym) => (
                        <motion.button
                          key={sym}
                          className="aspect-square rounded-md cursor-pointer border-none flex items-center justify-center"
                          style={{
                            backgroundColor: selectedSymbol === sym ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.015)",
                            fontSize: isMobile ? 13 : isLargeMode ? 16 : 14,
                            outline: selectedSymbol === sym ? "2px solid #1a1a1a" : "none",
                            outlineOffset: 1,
                          }}
                          onClick={() => setSelectedSymbol(sym)}
                          whileHover={{ scale: 1.12 }}
                          whileTap={{ scale: 0.88 }}
                        >
                          {sym}
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  {/* Superposition */}
                  <div className="flex flex-col gap-2">
                    <p style={{ fontSize: 9, color: "#ccc", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                      Superposition (optionnel)
                    </p>
                    <p style={{ fontSize: 8, color: "#ddd" }}>
                      Ajoutez un second motif — cliquez à nouveau pour retirer
                    </p>
                    <div
                      className="grid gap-1"
                      style={{ gridTemplateColumns: `repeat(auto-fill, minmax(${isMobile ? 28 : isLargeMode ? 38 : 30}px, 1fr))` }}
                    >
                      {PRIMARY_SHAPES.filter((s) => s.char !== selectedSymbol).map((shape) => (
                        <motion.button
                          key={`s2-${shape.char}`}
                          className="aspect-square rounded-md cursor-pointer border-none flex items-center justify-center"
                          style={{
                            backgroundColor: selectedSymbol2 === shape.char ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.015)",
                            fontSize: isMobile ? 11 : isLargeMode ? 14 : 12,
                            outline: selectedSymbol2 === shape.char ? "2px solid #1a1a1a" : "none",
                            outlineOffset: 1,
                            opacity: 0.7,
                          }}
                          onClick={() => handleSymbol2Click(shape.char)}
                          whileHover={{ scale: 1.1, opacity: 1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          {shape.char}
                        </motion.button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === "adjust" && (
                <motion.div
                  key="adjust"
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 8 }}
                  transition={{ duration: 0.15 }}
                  className="flex flex-col gap-5 py-2"
                >
                  <SliderControl label="Taille du symbole" value={symbolSize} min={20} max={100} onChange={setSymbolSize} fontSize={baseFontSize} />
                  <SliderControl label="Rotation" value={symbolRotation} min={0} max={360} onChange={setSymbolRotation} suffix="°" fontSize={baseFontSize} />
                  <SliderControl label="Contraste" value={symbolContrast} min={20} max={100} onChange={setSymbolContrast} suffix="%" fontSize={baseFontSize} />
                </motion.div>
              )}
            </AnimatePresence>

            {/* CTA */}
            <div className="mt-auto pt-3">
              <motion.button
                className="w-full py-3 rounded-xl cursor-pointer border-none"
                style={{
                  backgroundColor: canProceed ? "#1a1a1a" : "#e5e5e5",
                  color: canProceed ? BG_IVORY : "#bbb",
                  fontSize: isMobile ? 12 : isSenior ? 14 : 12,
                  fontWeight: 400,
                  letterSpacing: "0.1em",
                  pointerEvents: canProceed ? "auto" : "none",
                }}
                onClick={handleComplete}
                whileHover={canProceed ? { scale: 1.01, backgroundColor: "#333" } : {}}
                whileTap={canProceed ? { scale: 0.99 } : {}}
              >
                REJOINDRE LA GRILLE
              </motion.button>
              {!canProceed && (
                <p style={{ fontSize: 9, color: "#ddd", textAlign: "center", marginTop: 6, fontWeight: 300 }}>
                  Un pseudo est nécessaire pour exister
                </p>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function FieldInput({
  label, value, onChange, placeholder, maxLength, fontSize, required = false, compact = false,
}: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder: string; maxLength: number; fontSize: number; required?: boolean; compact?: boolean;
}) {
  return (
    <div>
      <label
        style={{
          fontSize: compact ? 8 : 9, color: "#aaa", letterSpacing: "0.12em",
          textTransform: "uppercase", display: "block", marginBottom: compact ? 2 : 4, fontWeight: 400,
        }}
      >
        {label} {required && <span style={{ color: "#ccc" }}>*</span>}
      </label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        maxLength={maxLength}
        className="w-full rounded-lg border-none outline-none"
        style={{
          backgroundColor: "rgba(0,0,0,0.025)",
          fontSize,
          color: "#1a1a1a",
          fontWeight: 400,
          padding: compact ? "6px 10px" : "8px 12px",
        }}
      />
    </div>
  );
}

function SliderControl({
  label, value, min, max, onChange, suffix = "", fontSize = 14,
}: {
  label: string; value: number; min: number; max: number;
  onChange: (v: number) => void; suffix?: string; fontSize?: number;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex justify-between items-center">
        <span style={{ fontSize: fontSize - 3, color: "#999", fontWeight: 400 }}>{label}</span>
        <span style={{ fontSize: fontSize - 3, color: "#ccc" }}>{value}{suffix}</span>
      </div>
      <input
        type="range" min={min} max={max} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-[3px] rounded-full appearance-none cursor-pointer"
        style={{ background: `linear-gradient(to right, #1a1a1a ${pct}%, #eee ${pct}%)`, accentColor: "#1a1a1a" }}
      />
    </div>
  );
}