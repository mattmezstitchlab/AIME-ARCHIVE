import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";

// ═══════════════════════════════════════════
// CROSS-STITCH PATTERN RENDERER
// Converts any photo into a pixelated grid
// with cross-stitch symbols per cell
// ═══════════════════════════════════════════

// Symbols used in cross-stitch patterns — each mapped to a color bucket
const STITCH_SYMBOLS = ["✕", "♥", "✚", "◆", "■", "●", "▲", "✳", "◇", "○", "□", "△", "★", "⬟", "⬡", "⊕"];

interface PixelData {
  r: number;
  g: number;
  b: number;
  a: number;
  symbol: string;
  colorKey: number; // bucket index for symbol assignment
}

interface CrossStitchPatternProps {
  imageUrl: string;
  cellSize: number;
  maxCells?: number; // max cells on longest side (default 64)
  isDark?: boolean;
  onReady?: (width: number, height: number) => void;
}

// Quantize a color channel to reduce palette
function quantize(v: number, levels: number): number {
  const step = 256 / levels;
  return Math.min(Math.floor(v / step) * step + Math.floor(step / 2), 255);
}

// Create a unique-ish color bucket key from quantized RGB
function colorBucket(r: number, g: number, b: number, levels: number): number {
  const qr = Math.floor(quantize(r, levels) / (256 / levels));
  const qg = Math.floor(quantize(g, levels) / (256 / levels));
  const qb = Math.floor(quantize(b, levels) / (256 / levels));
  return qr * levels * levels + qg * levels + qb;
}

export function CrossStitchPattern({
  imageUrl,
  cellSize,
  maxCells = 64,
  isDark = true,
  onReady,
}: CrossStitchPatternProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pixels, setPixels] = useState<PixelData[][] | null>(null);
  const [gridSize, setGridSize] = useState<{ cols: number; rows: number } | null>(null);
  const [loaded, setLoaded] = useState(false);

  // Store onReady in a ref to avoid it being a useEffect dependency
  const onReadyRef = useRef(onReady);
  onReadyRef.current = onReady;

  // Process image → pixel grid
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      // Calculate grid dimensions
      const aspect = img.naturalWidth / img.naturalHeight;
      let cols: number, rows: number;
      if (aspect >= 1) {
        cols = Math.min(maxCells, Math.ceil(img.naturalWidth / 8));
        rows = Math.round(cols / aspect);
      } else {
        rows = Math.min(maxCells, Math.ceil(img.naturalHeight / 8));
        cols = Math.round(rows * aspect);
      }
      cols = Math.max(8, Math.min(maxCells, cols));
      rows = Math.max(8, Math.min(maxCells, rows));

      // Draw downsampled on offscreen canvas
      const offscreen = document.createElement("canvas");
      offscreen.width = cols;
      offscreen.height = rows;
      const ctx = offscreen.getContext("2d")!;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "medium";
      ctx.drawImage(img, 0, 0, cols, rows);
      const imageData = ctx.getImageData(0, 0, cols, rows);

      // Build color bucket → symbol map
      const bucketSet = new Map<number, number>();
      let bucketCounter = 0;

      // Extract pixel data
      const grid: PixelData[][] = [];
      for (let y = 0; y < rows; y++) {
        const row: PixelData[] = [];
        for (let x = 0; x < cols; x++) {
          const idx = (y * cols + x) * 4;
          const r = imageData.data[idx];
          const g = imageData.data[idx + 1];
          const b = imageData.data[idx + 2];
          const a = imageData.data[idx + 3];

          const bucket = colorBucket(r, g, b, 8);
          if (!bucketSet.has(bucket)) {
            bucketSet.set(bucket, bucketCounter++);
          }
          const symbolIdx = bucketSet.get(bucket)! % STITCH_SYMBOLS.length;

          row.push({
            r, g, b, a,
            symbol: STITCH_SYMBOLS[symbolIdx],
            colorKey: bucket,
          });
        }
        grid.push(row);
      }

      setPixels(grid);
      setGridSize({ cols, rows });
      onReadyRef.current?.(cols * cellSize, rows * cellSize);
    };
    img.src = imageUrl;
  }, [imageUrl, cellSize, maxCells]);

  // Render on canvas
  useEffect(() => {
    if (!pixels || !gridSize || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const { cols, rows } = gridSize;
    const dpr = window.devicePixelRatio || 1;

    canvas.width = cols * cellSize * dpr;
    canvas.height = rows * cellSize * dpr;
    canvas.style.width = `${cols * cellSize}px`;
    canvas.style.height = `${rows * cellSize}px`;

    const ctx = canvas.getContext("2d")!;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, cols * cellSize, rows * cellSize);

    const symbolFontSize = Math.max(6, cellSize * 0.42);
    const gridLineColor = isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.08)";
    const symbolShadow = isDark ? "rgba(0,0,0,0.8)" : "rgba(0,0,0,0.5)";

    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const px = pixels[y][x];
        if (px.a < 20) continue; // skip transparent

        const cx = x * cellSize;
        const cy = y * cellSize;

        // ── Colored cell background ──
        ctx.fillStyle = `rgba(${px.r},${px.g},${px.b},${px.a / 255 * 0.85})`;
        ctx.fillRect(cx + 0.5, cy + 0.5, cellSize - 1, cellSize - 1);

        // ── Cross-stitch texture (X diagonal lines) ──
        ctx.strokeStyle = `rgba(255,255,255,0.12)`;
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(cx + 2, cy + 2);
        ctx.lineTo(cx + cellSize - 2, cy + cellSize - 2);
        ctx.moveTo(cx + cellSize - 2, cy + 2);
        ctx.lineTo(cx + 2, cy + cellSize - 2);
        ctx.stroke();

        // ── Symbol in center ──
        const brightness = (px.r * 0.299 + px.g * 0.587 + px.b * 0.114);
        const textColor = brightness > 140 ? "rgba(0,0,0,0.55)" : "rgba(255,255,255,0.65)";

        ctx.font = `${symbolFontSize}px "Inter", sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        // Slight shadow for readability
        ctx.fillStyle = symbolShadow;
        ctx.fillText(px.symbol, cx + cellSize / 2 + 0.5, cy + cellSize / 2 + 0.5);

        ctx.fillStyle = textColor;
        ctx.fillText(px.symbol, cx + cellSize / 2, cy + cellSize / 2);

        // ── Grid cell border ──
        ctx.strokeStyle = gridLineColor;
        ctx.lineWidth = 0.4;
        ctx.strokeRect(cx + 0.5, cy + 0.5, cellSize - 1, cellSize - 1);
      }
    }

    // ── Bold lines every 8 cells ──
    ctx.strokeStyle = isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.15)";
    ctx.lineWidth = 1.2;
    for (let x = 0; x <= cols; x += 8) {
      ctx.beginPath();
      ctx.moveTo(x * cellSize, 0);
      ctx.lineTo(x * cellSize, rows * cellSize);
      ctx.stroke();
    }
    for (let y = 0; y <= rows; y += 8) {
      ctx.beginPath();
      ctx.moveTo(0, y * cellSize);
      ctx.lineTo(cols * cellSize, y * cellSize);
      ctx.stroke();
    }

    setLoaded(true);
  }, [pixels, gridSize, cellSize, isDark]);

  if (!gridSize) return null;

  return (
    <motion.div
      className="pointer-events-none"
      style={{
        width: gridSize.cols * cellSize,
        height: gridSize.rows * cellSize,
      }}
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.96 }}
      transition={{ duration: 1.2, ease: "easeOut" }}
    >
      <canvas
        ref={canvasRef}
        style={{
          imageRendering: "pixelated",
          display: "block",
        }}
      />
    </motion.div>
  );
}