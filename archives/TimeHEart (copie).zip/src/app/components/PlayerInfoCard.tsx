import { motion, AnimatePresence } from "motion/react";
import { StitchLabMark } from "./StitchLabLogo";
import { PlayerSquare } from "./PlayerSquare";
import {
  HEARTBEAT_INTENTIONS,
  HEART_RED,
  type PlayerData,
  type BonusSquare,
  type Heartbeat,
  type AccessibilityMode,
} from "./game-data";
import { useResponsive } from "./useResponsive";

interface PlayerInfoCardProps {
  player: PlayerData | null;
  bonus: BonusSquare | null;
  heartbeat?: Heartbeat | null;
  visible: boolean;
  onClose: () => void;
  mode: AccessibilityMode;
}

export function PlayerInfoCard({ player, bonus, heartbeat, visible, onClose, mode }: PlayerInfoCardProps) {
  const { isMobile } = useResponsive();
  const isSenior = mode === "senior";
  const baseFontSize = isMobile ? 12 : isSenior ? 15 : 13;

  const hasContent = player || bonus || heartbeat;

  return (
    <AnimatePresence>
      {visible && hasContent && (
        <motion.div
          className="fixed top-5 left-1/2 -translate-x-1/2 z-40"
          style={{ maxWidth: isMobile ? "calc(100vw - 32px)" : "90vw" }}
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.98 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <div
            className="rounded-2xl px-5 py-4 flex flex-col gap-3 cursor-pointer"
            style={{
              backgroundColor: "rgba(255,255,255,0.92)",
              backdropFilter: "blur(24px)",
              boxShadow: "0 8px 40px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.02)",
              minWidth: 240,
            }}
            onClick={onClose}
          >
            {/* Player info */}
            {player && (
              <div className="flex items-center gap-4">
                <PlayerSquare
                  colorHex={player.colorHex}
                  symbol={player.symbol}
                  symbolSize={player.symbolSize}
                  symbolRotation={player.symbolRotation}
                  symbolContrast={player.symbolContrast}
                  size={isSenior ? 60 : 48}
                  mode={mode}
                />
                <div className="flex flex-col gap-0.5 min-w-0">
                  <span style={{ fontSize: baseFontSize + 1, color: "#1a1a1a", fontWeight: 500 }}>
                    {player.pseudo}
                  </span>
                  {player.city && (
                    <span style={{ fontSize: baseFontSize - 2, color: "#aaa", fontWeight: 300 }}>
                      {player.city}
                    </span>
                  )}
                  {player.intention && (
                    <span style={{ fontSize: baseFontSize - 2, color: "#ccc", fontStyle: "italic", fontWeight: 300 }}>
                      « {player.intention} »
                    </span>
                  )}
                  <span style={{ fontSize: 9, color: "#e0e0e0", marginTop: 1, letterSpacing: "0.05em" }}>
                    DMC {player.colorCode} · {player.symbol}
                  </span>
                </div>
              </div>
            )}

            {/* Heartbeat info */}
            {heartbeat && (
              <div className="flex items-start gap-3" style={{ borderTop: player ? "1px solid rgba(0,0,0,0.04)" : "none", paddingTop: player ? 10 : 0 }}>
                <motion.div
                  className="flex-shrink-0 mt-0.5"
                  animate={{ scale: [1, 1.15, 1, 1.1, 1, 1, 1] }}
                  transition={{ duration: 1.8, repeat: Infinity, times: [0, 0.1, 0.2, 0.3, 0.4, 0.6, 1] }}
                >
                  <StitchLabMark size={16} animate={false} />
                </motion.div>
                <div className="flex flex-col gap-1">
                  <span style={{ fontSize: baseFontSize - 1, color: "#1a1a1a", fontWeight: 500 }}>
                    Battement
                    {!player && <span style={{ color: "#aaa", fontWeight: 300 }}> · {heartbeat.creatorPseudo}</span>}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    <InfoPill
                      label={formatWhen(heartbeat.when)}
                      color={HEART_RED}
                      fontSize={baseFontSize}
                    />
                    <InfoPill
                      label={heartbeat.whereName || formatWhere(heartbeat.where)}
                      fontSize={baseFontSize}
                    />
                    <InfoPill
                      label={`${getIntentionEmoji(heartbeat.intention)} ${heartbeat.intention}`}
                      fontSize={baseFontSize}
                    />
                    <InfoPill
                      label={formatOpenness(heartbeat.openness)}
                      fontSize={baseFontSize}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Bonus info */}
            {bonus && !player && !heartbeat && (
              <div className="flex items-center gap-4">
                <motion.span
                  style={{ fontSize: 32 }}
                  animate={{ scale: [1, 1.12, 1] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                >
                  {bonus.value}
                </motion.span>
                <div className="flex flex-col gap-0.5">
                  <span style={{ fontSize: baseFontSize, color: "#1a1a1a", fontWeight: 500 }}>
                    {bonus.type === "rare_color" && "Couleur DMC rare"}
                    {bonus.type === "special_symbol" && "Symbole spécial"}
                    {bonus.type === "seed" && "Graine trouvée"}
                    {bonus.type === "glow" && "Lumière éphémère"}
                  </span>
                  <span style={{ fontSize: baseFontSize - 3, color: "#ccc", fontWeight: 300 }}>
                    Découvert par exploration
                  </span>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function InfoPill({ label, color, fontSize }: { label: string; color?: string; fontSize: number }) {
  return (
    <span
      className="px-2 py-0.5 rounded-full"
      style={{
        fontSize: fontSize - 4,
        backgroundColor: color ? `${color}12` : "rgba(0,0,0,0.04)",
        color: color || "#999",
        fontWeight: 400,
      }}
    >
      {label}
    </span>
  );
}

function formatWhen(when: string): string {
  switch (when) {
    case "maintenant": return "Maintenant";
    case "aujourdhui": return "Aujourd'hui";
    case "weekend": return "Ce week-end";
    default: return when;
  }
}

function formatWhere(where: string): string {
  switch (where) {
    case "ici": return "Ici";
    case "autour": return "Autour";
    default: return where;
  }
}

function formatOpenness(openness: string): string {
  switch (openness) {
    case "seul": return "Seul·e";
    case "quelques": return "Quelques-uns";
    case "ouvert": return "Ouvert";
    default: return openness;
  }
}

function getIntentionEmoji(intention: string): string {
  const match = HEARTBEAT_INTENTIONS.find((i) => i.key === intention);
  return match?.emoji || "";
}