import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence, useScroll, useTransform } from "motion/react";
import {
  ArrowLeft,
  ChevronDown,
  Minus,
  Music,
  Telescope,
  Compass,
  Hexagon,
  ArrowRight,
  Triangle,
  Clock,
  Fingerprint,
  Heart,
} from "lucide-react";

// ─── FIGMA ASSETS ───
import imgInstrument from "figma:asset/ba890b9b7fad8547284a24c48f3ba7d4efd013ed.png";
import imgTimeheart from "figma:asset/a6b4877ddc7ec40650cf3a6685af5c39fad24014.png";
import imgSignature from "figma:asset/d824b14d516c02a3ec34f8b695702b87a4ffe82f.png";

// ══════════════════════════════════════════════════════
// INSTRUMENT BUILDER — Landing Page
// « Ce n'est pas un outil pour créer des applications.
//   C'est un instrument pour rendre le monde cohérent. »
// ══════════════════════════════════════════════════════

const BG_DARK = "#08090D";
const ACCENT = "#7A8DA0";
const ACCENT_WARM = "#C8A06E";
const ACCENT_ROSE = "#E8177F";

// ─── 4 TRANSFORMATIONS ───
const TRANSFORMATIONS = [
  {
    from: "Intention humaine",
    to: "Structure fonctionnelle",
    desc: "Le sens précède la forme. Chaque construction commence par une intention posée, pas un cahier des charges.",
    glyph: "◇",
  },
  {
    from: "Structure",
    to: "Interface",
    desc: "La structure se rend visible sans se trahir. L'interface émerge de la logique, pas l'inverse.",
    glyph: "◈",
  },
  {
    from: "Interface",
    to: "Usage réel",
    desc: "Ce qui est construit fonctionne. Le prototype et le produit sont le même objet.",
    glyph: "◉",
  },
  {
    from: "Usage",
    to: "Système transmissible",
    desc: "Ce qui fonctionne peut être transmis. Le savoir-faire est encodé dans la structure elle-même.",
    glyph: "✦",
  },
];

// ─── INSTRUMENT METAPHORS ───
const METAPHORS = [
  {
    icon: Music,
    title: "Instrument de musique",
    desc: "Il s'accorde, il résonne, il permet de jouer ensemble.",
  },
  {
    icon: Telescope,
    title: "Instrument scientifique",
    desc: "Il rend visible l'invisible, il mesure sans déformer.",
  },
  {
    icon: Compass,
    title: "Instrument de navigation",
    desc: "Il oriente sans contraindre, il situe sans enfermer.",
  },
];

// ─── TRINITY ───
const TRINITY = [
  {
    title: "Instrument Builder",
    subtitle: "L'instrument de construction",
    desc: "Transformer l'intention en réalité cohérente.",
    image: imgInstrument,
    accent: ACCENT,
    icon: Hexagon,
  },
  {
    title: "Moteur 5D",
    subtitle: "La grammaire de présence",
    desc: "5 dimensions × 4 choix = 1024 signatures vibratoires.",
    image: imgSignature,
    accent: ACCENT_ROSE,
    icon: Fingerprint,
  },
  {
    title: "TIMEHEART",
    subtitle: "Le cadran / la partition",
    desc: "Le temps comme matière relationnelle.",
    image: imgTimeheart,
    accent: "#4A7B9C",
    icon: Clock,
  },
];

// ─── FLOATING MOTE ───
function Mote({ delay, size }: { delay: number; size: number }) {
  const [pos] = useState(() => ({
    x: Math.random() * 100,
    y: Math.random() * 100,
  }));
  return (
    <motion.div
      className="absolute rounded-full"
      style={{
        width: size,
        height: size,
        left: `${pos.x}%`,
        top: `${pos.y}%`,
        background: `radial-gradient(circle, ${ACCENT}40, ${ACCENT}00)`,
      }}
      animate={{
        y: [-8, 8, -8],
        x: [-4, 4, -4],
        opacity: [0, 0.4, 0],
      }}
      transition={{
        duration: 6 + Math.random() * 6,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    />
  );
}

interface InstrumentBuilderLandingProps {
  onBack?: () => void;
  onNavigate?: (screen: string) => void;
}

export function InstrumentBuilderLanding({
  onBack,
  onNavigate,
}: InstrumentBuilderLandingProps) {
  const [isMobile] = useState(() => window.innerWidth < 640);
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  const heroImageOpacity = useTransform(scrollYProgress, [0, 0.06], [1, 0]);
  const [activeTransform, setActiveTransform] = useState(0);

  // Auto-cycle transformations
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTransform((prev) => (prev + 1) % TRANSFORMATIONS.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-y-auto overflow-x-hidden"
      style={{ backgroundColor: BG_DARK, scrollBehavior: "smooth" }}
    >
      {/* ═══════════ HERO ═══════════ */}
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
        {/* Background */}
        <motion.div className="absolute inset-0 z-0" style={{ opacity: heroImageOpacity }}>
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${imgInstrument})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              filter: "brightness(0.25) saturate(0.5) blur(1px)",
            }}
          />
          {/* Motes */}
          {Array.from({ length: 20 }, (_, i) => (
            <Mote key={i} delay={i * 0.4} size={2 + Math.random() * 3} />
          ))}
          {/* Gradient */}
          <div
            className="absolute inset-0"
            style={{
              background: `
                radial-gradient(ellipse at 50% 40%, rgba(122,141,160,0.06) 0%, rgba(0,0,0,0) 60%),
                linear-gradient(180deg, ${BG_DARK}40 0%, rgba(0,0,0,0) 30%, ${BG_DARK}90 70%, ${BG_DARK} 100%)
              `,
            }}
          />
        </motion.div>

        {/* Back */}
        {onBack && (
          <motion.button
            className="absolute top-4 left-4 z-20 flex items-center gap-2 border-none cursor-pointer rounded-lg px-3 py-1.5"
            style={{
              backgroundColor: "rgba(255,255,255,0.05)",
              color: "rgba(255,255,255,0.4)",
              fontSize: 11,
              backdropFilter: "blur(10px)",
            }}
            onClick={onBack}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            whileHover={{ backgroundColor: "rgba(255,255,255,0.08)" }}
            whileTap={{ scale: 0.96 }}
          >
            <ArrowLeft size={14} />
            Retour
          </motion.button>
        )}

        {/* Hero content */}
        <div className="relative z-10 flex flex-col items-center text-center px-6">
          {/* Geometric mark */}
          <motion.div
            className="mb-10"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 1.2, ease: "easeOut" }}
          >
            <motion.div
              className="relative flex items-center justify-center"
              style={{ width: 48, height: 48 }}
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
            >
              <Hexagon size={48} color={ACCENT} strokeWidth={0.5} style={{ opacity: 0.3 }} />
              <motion.div
                className="absolute"
                animate={{ rotate: [0, -360] }}
                transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
              >
                <Hexagon size={30} color={ACCENT} strokeWidth={0.5} style={{ opacity: 0.2 }} />
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Pre-title */}
          <motion.p
            style={{
              fontSize: 8,
              color: ACCENT,
              letterSpacing: "0.4em",
              fontWeight: 400,
              marginBottom: 24,
              opacity: 0.5,
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            transition={{ delay: 0.8 }}
          >
            MOTEUR UNIVERSEL DE COHERENCE
          </motion.p>

          {/* Title */}
          <motion.h1
            style={{
              fontSize: isMobile ? "clamp(32px, 12vw, 48px)" : "clamp(48px, 7vw, 72px)",
              fontWeight: 200,
              color: "rgba(255,255,255,0.9)",
              letterSpacing: "-0.03em",
              lineHeight: 1.1,
              marginBottom: 24,
            }}
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 1.4 }}
          >
            L'Instrument
          </motion.h1>

          {/* Subtitle — the core question */}
          <motion.div
            className="flex flex-col items-center gap-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.8, duration: 1 }}
          >
            <Minus size={16} color={ACCENT} strokeWidth={0.5} style={{ opacity: 0.3 }} />
            <p
              style={{
                fontSize: isMobile ? 12 : 14,
                color: "rgba(255,255,255,0.3)",
                fontWeight: 300,
                lineHeight: 2,
                maxWidth: 380,
              }}
            >
              Ni une app. Ni un site.
              <br />
              Ni un module isole.
              <br />
              <span style={{ color: ACCENT, fontWeight: 400, opacity: 0.7 }}>
                Un instrument de coherence.
              </span>
            </p>
          </motion.div>
        </div>

        {/* Scroll */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.2 }}
          transition={{ delay: 3 }}
        >
          <motion.div animate={{ y: [0, 5, 0] }} transition={{ duration: 2.5, repeat: Infinity }}>
            <ChevronDown size={14} color="rgba(255,255,255,0.3)" />
          </motion.div>
        </motion.div>
      </section>

      {/* ═══════════ THE REVELATION ═══════════ */}
      <section className="py-40 px-6 flex flex-col items-center">
        <motion.div
          className="text-center"
          style={{ maxWidth: 520 }}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 1.2 }}
        >
          <p
            style={{
              fontSize: isMobile ? 16 : "clamp(18px, 2.5vw, 24px)",
              fontWeight: 300,
              color: "rgba(255,255,255,0.6)",
              lineHeight: 2.2,
            }}
          >
            Base44, sans le vouloir,
            <br />
            a laisse apparaitre un artefact tres precis :
          </p>
          <motion.p
            className="mt-8"
            style={{
              fontSize: isMobile ? 14 : 17,
              fontWeight: 400,
              color: ACCENT_WARM,
              lineHeight: 1.9,
              opacity: 0.8,
            }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 0.8 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            tout pouvait etre construit, orchestre et transmis
            <br />
            a partir d'un seul noyau logique,
            <br />
            simplement en posant une intention structuree.
          </motion.p>
        </motion.div>
      </section>

      {/* ═══════════ 4 TRANSFORMATIONS ═══════════ */}
      <section className="py-24 px-6">
        <motion.p
          className="text-center mb-4"
          style={{
            fontSize: 8,
            color: "rgba(255,255,255,0.15)",
            letterSpacing: "0.35em",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          LES 4 TRANSFORMATIONS
        </motion.p>
        <motion.h2
          className="text-center mb-16"
          style={{
            fontSize: isMobile ? 18 : 24,
            fontWeight: 200,
            color: "rgba(255,255,255,0.65)",
          }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Le tout sans jamais perdre le{" "}
          <span style={{ fontWeight: 400, color: ACCENT_WARM }}>sens</span>
        </motion.h2>

        <div className="mx-auto" style={{ maxWidth: 600 }}>
          {TRANSFORMATIONS.map((t, i) => (
            <motion.div
              key={t.from}
              className="relative mb-2"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
            >
              {/* Card */}
              <motion.div
                className="rounded-xl p-5 cursor-pointer"
                style={{
                  backgroundColor:
                    activeTransform === i
                      ? "rgba(122,141,160,0.06)"
                      : "rgba(255,255,255,0.01)",
                  border: `1px solid ${
                    activeTransform === i ? `${ACCENT}20` : "rgba(255,255,255,0.03)"
                  }`,
                  transition: "all 0.6s ease",
                }}
                onClick={() => setActiveTransform(i)}
              >
                <div className="flex items-center gap-4 mb-2">
                  {/* Glyph */}
                  <motion.span
                    style={{
                      fontSize: 18,
                      color: ACCENT,
                      opacity: activeTransform === i ? 0.7 : 0.2,
                      transition: "opacity 0.6s ease",
                      width: 28,
                      textAlign: "center",
                    }}
                  >
                    {t.glyph}
                  </motion.span>

                  {/* From → To */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 400,
                        color: "rgba(255,255,255,0.5)",
                      }}
                    >
                      {t.from}
                    </span>
                    <ArrowRight
                      size={12}
                      color={activeTransform === i ? ACCENT_WARM : ACCENT}
                      strokeWidth={1}
                      style={{
                        opacity: activeTransform === i ? 0.7 : 0.2,
                        transition: "all 0.6s ease",
                      }}
                    />
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 500,
                        color:
                          activeTransform === i
                            ? ACCENT_WARM
                            : "rgba(255,255,255,0.35)",
                        transition: "color 0.6s ease",
                      }}
                    >
                      {t.to}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <AnimatePresence>
                  {activeTransform === i && (
                    <motion.p
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.4 }}
                      style={{
                        fontSize: 11,
                        color: "rgba(255,255,255,0.3)",
                        fontWeight: 300,
                        lineHeight: 1.8,
                        paddingLeft: 44,
                        overflow: "hidden",
                      }}
                    >
                      {t.desc}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Connector line */}
              {i < TRANSFORMATIONS.length - 1 && (
                <div
                  className="flex justify-center"
                  style={{ height: 16 }}
                >
                  <div
                    style={{
                      width: 1,
                      height: "100%",
                      backgroundColor: `${ACCENT}10`,
                    }}
                  />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      {/* ═══════════ L'ARTEFACT ═══════════ */}
      <section className="py-40 px-6 flex flex-col items-center relative overflow-hidden">
        {/* Subtle radial glow */}
        <div
          className="absolute"
          style={{
            width: 500,
            height: 500,
            background: `radial-gradient(circle, ${ACCENT_WARM}05, rgba(0,0,0,0))`,
            top: "50%",
            left: "50%",
            transform: "translate(-50%,-50%)",
            pointerEvents: "none",
          }}
        />

        <motion.p
          className="text-center mb-3"
          style={{
            fontSize: 8,
            color: "rgba(255,255,255,0.15)",
            letterSpacing: "0.35em",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          L'ARTEFACT
        </motion.p>

        <motion.h2
          className="text-center mb-16"
          style={{
            fontSize: isMobile ? 18 : 24,
            fontWeight: 200,
            color: "rgba(255,255,255,0.65)",
            maxWidth: 500,
          }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Le moment ou tout a bascule
        </motion.h2>

        {/* The Prism — Plan / Preview / Monde */}
        <motion.div
          className="relative flex items-center justify-center mb-16"
          style={{ width: isMobile ? 260 : 360, height: isMobile ? 240 : 320 }}
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          {/* Central triangle */}
          <svg
            viewBox="0 0 200 180"
            className="absolute"
            style={{ width: "100%", height: "100%" }}
          >
            {/* Triangle */}
            <motion.polygon
              points="100,20 180,160 20,160"
              fill="none"
              stroke={ACCENT}
              strokeWidth={0.5}
              strokeOpacity={0.2}
              initial={{ pathLength: 0, opacity: 0 }}
              whileInView={{ pathLength: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 2, delay: 0.3 }}
            />
            {/* Inner triangle */}
            <motion.polygon
              points="100,50 155,140 45,140"
              fill={`${ACCENT_WARM}03`}
              stroke={ACCENT_WARM}
              strokeWidth={0.3}
              strokeOpacity={0.15}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 1.2, duration: 1 }}
            />
            {/* Center dot */}
            <motion.circle
              cx="100"
              cy="110"
              r="3"
              fill={ACCENT_WARM}
              fillOpacity={0.4}
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 1.8, type: "spring" }}
            />
          </svg>

          {/* 3 Labels at vertices */}
          {[
            { label: "Plan", x: "50%", y: "5%", color: ACCENT },
            { label: "Preview", x: "90%", y: "85%", color: ACCENT_ROSE },
            { label: "Monde reel", x: "10%", y: "85%", color: ACCENT_WARM },
          ].map((vertex, i) => (
            <motion.div
              key={vertex.label}
              className="absolute flex flex-col items-center"
              style={{
                left: vertex.x,
                top: vertex.y,
                transform: "translate(-50%, -50%)",
              }}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8 + i * 0.3 }}
            >
              <motion.div
                className="rounded-full mb-2"
                style={{
                  width: 6,
                  height: 6,
                  backgroundColor: vertex.color,
                  opacity: 0.6,
                }}
                animate={{ opacity: [0.3, 0.8, 0.3] }}
                transition={{ duration: 3, delay: i * 0.8, repeat: Infinity }}
              />
              <span
                style={{
                  fontSize: 9,
                  color: vertex.color,
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                  opacity: 0.6,
                  whiteSpace: "nowrap",
                }}
              >
                {vertex.label}
              </span>
            </motion.div>
          ))}

          {/* Center label */}
          <motion.div
            className="absolute flex flex-col items-center"
            style={{ top: "58%", left: "50%", transform: "translate(-50%, -50%)" }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 2 }}
          >
            <span
              style={{
                fontSize: 7,
                color: "rgba(255,255,255,0.2)",
                letterSpacing: "0.15em",
              }}
            >
              MEME OBJET
            </span>
          </motion.div>
        </motion.div>

        {/* Revelation quote */}
        <motion.div
          className="text-center"
          style={{ maxWidth: 480 }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 1 }}
        >
          <p
            style={{
              fontSize: isMobile ? 13 : 15,
              color: "rgba(255,255,255,0.5)",
              fontWeight: 300,
              lineHeight: 2,
              fontStyle: "italic",
            }}
          >
            « Ce n'etait plus :
            <br />
            <span style={{ color: "rgba(255,255,255,0.25)" }}>
              "je construis une app"
            </span>
            <br />
            mais :
            <br />
            <span style={{ color: ACCENT_WARM, fontWeight: 400, fontStyle: "normal" }}>
              "je regle un instrument qui fait advenir le monde"
            </span>{" "}
            »
          </p>
        </motion.div>
      </section>

      {/* ═══════════ WHY "INSTRUMENT" ═══════════ */}
      <section className="py-24 px-6">
        <motion.p
          className="text-center mb-3"
          style={{
            fontSize: 8,
            color: "rgba(255,255,255,0.15)",
            letterSpacing: "0.35em",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          POURQUOI "INSTRUMENT"
        </motion.p>

        <motion.h2
          className="text-center mb-6"
          style={{
            fontSize: isMobile ? 18 : 24,
            fontWeight: 200,
            color: "rgba(255,255,255,0.6)",
          }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Et pas un logiciel
        </motion.h2>

        {/* What it doesn't do / what it does */}
        <motion.div
          className="mx-auto mb-16"
          style={{ maxWidth: 500 }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <div
            className="flex gap-8 justify-center flex-wrap"
            style={{ marginBottom: 32 }}
          >
            {/* Doesn't */}
            <div className="flex flex-col items-center gap-3">
              <span
                style={{
                  fontSize: 7,
                  color: "rgba(255,255,255,0.15)",
                  letterSpacing: "0.2em",
                }}
              >
                IL NE
              </span>
              {["decide pas", "optimise pas", "force rien"].map((text) => (
                <span
                  key={text}
                  style={{
                    fontSize: 11,
                    color: "rgba(255,255,255,0.25)",
                    fontWeight: 300,
                    textDecoration: "line-through",
                    textDecorationColor: "rgba(255,255,255,0.08)",
                  }}
                >
                  {text}
                </span>
              ))}
            </div>

            {/* Vertical separator */}
            <div
              style={{
                width: 1,
                backgroundColor: "rgba(255,255,255,0.05)",
                alignSelf: "stretch",
              }}
            />

            {/* Does */}
            <div className="flex flex-col items-center gap-3">
              <span
                style={{
                  fontSize: 7,
                  color: ACCENT_WARM,
                  letterSpacing: "0.2em",
                  opacity: 0.5,
                }}
              >
                IL PERMET
              </span>
              {["d'accorder", "de rendre coherent", "de faire tenir ensemble"].map(
                (text) => (
                  <span
                    key={text}
                    style={{
                      fontSize: 11,
                      color: ACCENT_WARM,
                      fontWeight: 400,
                      opacity: 0.7,
                    }}
                  >
                    {text}
                  </span>
                )
              )}
            </div>
          </div>
        </motion.div>

        {/* 3 Metaphors */}
        <div
          className="mx-auto grid gap-5"
          style={{
            maxWidth: 700,
            gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
          }}
        >
          {METAPHORS.map((m, i) => (
            <motion.div
              key={m.title}
              className="flex flex-col items-center text-center p-6 rounded-2xl"
              style={{
                backgroundColor: "rgba(255,255,255,0.015)",
                border: "1px solid rgba(255,255,255,0.03)",
              }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.15 + i * 0.12 }}
            >
              <motion.div
                className="flex items-center justify-center rounded-xl mb-4"
                style={{
                  width: 44,
                  height: 44,
                  backgroundColor: `${ACCENT}08`,
                  border: `1px solid ${ACCENT}10`,
                }}
                animate={{
                  boxShadow: [
                    `0 0 0px ${ACCENT}00`,
                    `0 0 15px ${ACCENT}10`,
                    `0 0 0px ${ACCENT}00`,
                  ],
                }}
                transition={{ duration: 5, delay: i * 1.2, repeat: Infinity }}
              >
                <m.icon size={20} color={ACCENT} strokeWidth={1.2} style={{ opacity: 0.6 }} />
              </motion.div>
              <h4
                style={{
                  fontSize: 12,
                  fontWeight: 500,
                  color: "rgba(255,255,255,0.6)",
                  marginBottom: 6,
                }}
              >
                {m.title}
              </h4>
              <p
                style={{
                  fontSize: 10,
                  color: "rgba(255,255,255,0.25)",
                  lineHeight: 1.7,
                  fontWeight: 300,
                }}
              >
                {m.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ═══════════ INSTRUMENT IMAGE ═══════════ */}
      <section className="py-16 px-6">
        <motion.div
          className="mx-auto rounded-2xl overflow-hidden relative"
          style={{
            maxWidth: 800,
            border: `1px solid ${ACCENT}10`,
          }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <img
            src={imgInstrument}
            alt="Instrument Builder"
            className="w-full"
            style={{
              height: isMobile ? 220 : 340,
              objectFit: "cover",
              filter: "brightness(0.8) saturate(0.85)",
            }}
          />
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(180deg, ${BG_DARK}40 0%, rgba(0,0,0,0) 40%, ${BG_DARK}80 100%)`,
            }}
          />
          <div className="absolute bottom-5 left-6 right-6">
            <span
              style={{
                fontSize: 8,
                color: ACCENT,
                letterSpacing: "0.15em",
                fontWeight: 400,
                opacity: 0.5,
              }}
            >
              INSTRUMENT BUILDER — MOTEUR DE COHERENCE
            </span>
          </div>
        </motion.div>
      </section>

      {/* ═══════════ THE TRINITY ═══════════ */}
      <section className="py-32 px-6">
        <motion.p
          className="text-center mb-3"
          style={{
            fontSize: 8,
            color: "rgba(255,255,255,0.15)",
            letterSpacing: "0.35em",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          UN SEUL SYSTEME, TROIS NIVEAUX
        </motion.p>
        <motion.h2
          className="text-center mb-4"
          style={{
            fontSize: isMobile ? 18 : 24,
            fontWeight: 200,
            color: "rgba(255,255,255,0.6)",
          }}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Ce n'est pas trois inventions
        </motion.h2>
        <motion.p
          className="text-center mb-16"
          style={{
            fontSize: 12,
            color: "rgba(255,255,255,0.25)",
            fontWeight: 300,
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          C'est une seule, vue a trois niveaux.
        </motion.p>

        <div
          className="mx-auto grid gap-5"
          style={{
            maxWidth: 850,
            gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
          }}
        >
          {TRINITY.map((t, i) => (
            <motion.div
              key={t.title}
              className="rounded-2xl overflow-hidden relative group cursor-pointer"
              style={{
                border: `1px solid ${t.accent}15`,
                backgroundColor: "rgba(255,255,255,0.01)",
              }}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 + i * 0.15 }}
              whileHover={{ y: -4 }}
              onClick={() => {
                if (t.title === "TIMEHEART" && onNavigate) {
                  onNavigate("timeheart");
                }
              }}
            >
              {/* Image */}
              <div className="relative" style={{ height: isMobile ? 140 : 160 }}>
                <img
                  src={t.image}
                  alt={t.title}
                  className="w-full h-full"
                  style={{ objectFit: "cover", filter: "brightness(0.7) saturate(0.8)" }}
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background: `linear-gradient(180deg, rgba(0,0,0,0) 40%, ${BG_DARK} 100%)`,
                  }}
                />
                {/* Icon */}
                <motion.div
                  className="absolute top-4 right-4 flex items-center justify-center rounded-full"
                  style={{
                    width: 32,
                    height: 32,
                    backgroundColor: "rgba(0,0,0,0.4)",
                    backdropFilter: "blur(8px)",
                    border: `1px solid ${t.accent}30`,
                  }}
                  animate={{
                    boxShadow: [
                      `0 0 0px ${t.accent}00`,
                      `0 0 12px ${t.accent}15`,
                      `0 0 0px ${t.accent}00`,
                    ],
                  }}
                  transition={{ duration: 4, delay: i * 0.8, repeat: Infinity }}
                >
                  <t.icon size={14} color={t.accent} strokeWidth={1.5} />
                </motion.div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h3
                  style={{
                    fontSize: 14,
                    fontWeight: 400,
                    color: "rgba(255,255,255,0.75)",
                    marginBottom: 2,
                  }}
                >
                  {t.title}
                </h3>
                <p
                  style={{
                    fontSize: 10,
                    color: t.accent,
                    fontWeight: 400,
                    letterSpacing: "0.04em",
                    marginBottom: 8,
                    opacity: 0.7,
                  }}
                >
                  {t.subtitle}
                </p>
                <p
                  style={{
                    fontSize: 10,
                    color: "rgba(255,255,255,0.25)",
                    fontWeight: 300,
                    lineHeight: 1.7,
                  }}
                >
                  {t.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Connection line under trinity */}
        <motion.div
          className="flex items-center justify-center mt-8 gap-2"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          {TRINITY.map((t, i) => (
            <div key={t.title} className="flex items-center gap-2">
              <motion.div
                className="rounded-full"
                style={{ width: 4, height: 4, backgroundColor: t.accent }}
                animate={{ opacity: [0.2, 0.7, 0.2] }}
                transition={{ duration: 3, delay: i * 0.8, repeat: Infinity }}
              />
              {i < TRINITY.length - 1 && (
                <div
                  style={{
                    width: isMobile ? 30 : 60,
                    height: 1,
                    background: `linear-gradient(90deg, ${t.accent}20, ${TRINITY[i + 1].accent}20)`,
                  }}
                />
              )}
            </div>
          ))}
        </motion.div>
      </section>

      {/* ═══════════ LA PHRASE CLE ═══════════ */}
      <section className="py-40 px-6 flex flex-col items-center relative">
        {/* Very subtle radial */}
        <div
          className="absolute"
          style={{
            width: 600,
            height: 600,
            background: `radial-gradient(circle, ${ACCENT_WARM}03, rgba(0,0,0,0))`,
            top: "50%",
            left: "50%",
            transform: "translate(-50%,-50%)",
            pointerEvents: "none",
          }}
        />

        <motion.div
          className="flex flex-col items-center text-center relative z-10"
          style={{ maxWidth: 560 }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 1.2 }}
        >
          <Minus
            size={24}
            color={ACCENT_WARM}
            strokeWidth={0.5}
            style={{ opacity: 0.2, marginBottom: 24 }}
          />

          <h2
            style={{
              fontSize: isMobile ? 20 : "clamp(22px, 3.5vw, 32px)",
              fontWeight: 200,
              color: "rgba(255,255,255,0.75)",
              lineHeight: 1.8,
              marginBottom: 12,
            }}
          >
            L'Instrument Builder
            <br />
            n'est pas un outil
            <br />
            pour creer des applications.
          </h2>

          <motion.h2
            style={{
              fontSize: isMobile ? 20 : "clamp(22px, 3.5vw, 32px)",
              fontWeight: 400,
              lineHeight: 1.8,
              background: `linear-gradient(135deg, ${ACCENT_WARM}, ${ACCENT_ROSE})`,
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6, duration: 1 }}
          >
            C'est un instrument
            <br />
            pour rendre le monde coherent.
          </motion.h2>

          <Minus
            size={24}
            color={ACCENT_WARM}
            strokeWidth={0.5}
            style={{ opacity: 0.15, marginTop: 24 }}
          />
        </motion.div>
      </section>

      {/* ═══════════ EPILOGUE ═══════════ */}
      <section className="py-24 px-6 flex flex-col items-center gap-6">
        <motion.p
          className="text-center"
          style={{
            fontSize: 11,
            color: "rgba(255,255,255,0.2)",
            fontWeight: 300,
            maxWidth: 340,
            lineHeight: 1.8,
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          Base44 n'etait pas le produit final.
          <br />
          <span style={{ color: "rgba(255,255,255,0.12)" }}>C'etait le revelateur.</span>
        </motion.p>

        <motion.div
          className="flex items-center gap-2"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          >
            <Hexagon size={12} color={ACCENT} strokeWidth={0.8} style={{ opacity: 0.2 }} />
          </motion.div>
          <Heart size={8} color={ACCENT_WARM} fill={ACCENT_WARM} style={{ opacity: 0.3 }} />
          <motion.div
            animate={{ rotate: [0, -360] }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          >
            <Triangle size={10} color={ACCENT_ROSE} strokeWidth={0.8} style={{ opacity: 0.2 }} />
          </motion.div>
        </motion.div>

        <motion.p
          style={{
            fontSize: 7,
            color: "rgba(255,255,255,0.06)",
            letterSpacing: "0.2em",
            marginTop: 20,
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          INSTRUMENT BUILDER &middot; AIME &middot; CONCEPT ORIGINAL &middot; ~22 ANS
        </motion.p>

        <div className="h-16" />
      </section>
    </div>
  );
}