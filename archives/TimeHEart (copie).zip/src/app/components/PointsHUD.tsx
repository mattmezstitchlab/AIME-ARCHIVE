import { motion, AnimatePresence } from "motion/react";
import { useResponsive } from "./useResponsive";
import type { AccessibilityMode } from "./game-data";

interface PointsHUDProps {
  points: number;
  lastEvent: { type: string; points: number; id: number } | null;
  steps: number;
  discoveries: number;
  mode: AccessibilityMode;
}

export function PointsHUD({ points, lastEvent, steps, discoveries, mode }: PointsHUDProps) {
  const { isMobile } = useResponsive();
  const isSenior = mode === "senior";
  const fontSize = isMobile ? 10 : isSenior ? 13 : 11;

  return (
    <div
      className="fixed z-30 flex flex-col items-end gap-2"
      style={{
        bottom: isMobile ? 10 : 20,
        right: isMobile ? 10 : 16,
      }}
    >
      {/* Floating point notification */}
      <AnimatePresence>
        {lastEvent && (
          <motion.div
            key={lastEvent.id}
            className="px-2 py-0.5 rounded-full"
            style={{
              backgroundColor: "rgba(255,255,255,0.85)",
              backdropFilter: "blur(10px)",
              fontSize: isMobile ? 9 : 10,
              color: "#888",
              boxShadow: "0 1px 6px rgba(0,0,0,0.04)",
            }}
            initial={{ opacity: 0, y: 10, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.4 }}
          >
            <span style={{ color: lastEvent.type === "heartbeat" ? "#E3243B" : lastEvent.type === "sortie" ? "#D4A060" : "#aaa" }}>
              +{lastEvent.points}
            </span>
            <span style={{ color: "#ddd", marginLeft: 4 }}>
              {lastEvent.type === "move" && "pas"}
              {lastEvent.type === "discover" && "découverte"}
              {lastEvent.type === "stillness" && "contemplation"}
              {lastEvent.type === "encounter" && "rencontre"}
              {lastEvent.type === "heartbeat" && "battement"}
              {lastEvent.type === "sortie" && "sortie créée"}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats pill */}
      <div
        className="flex items-center rounded-xl"
        style={{
          gap: isMobile ? 6 : 12,
          padding: isMobile ? "4px 8px" : "6px 12px",
          backgroundColor: "rgba(255,255,255,0.65)",
          backdropFilter: "blur(12px)",
          boxShadow: "0 1px 8px rgba(0,0,0,0.03)",
        }}
      >
        <StatItem label="🧵" value={points} fontSize={fontSize} />
        <Divider />
        <StatItem label="👣" value={steps} fontSize={fontSize} />
        <Divider />
        <StatItem label="✦" value={discoveries} fontSize={fontSize} />
      </div>
    </div>
  );
}

function StatItem({ label, value, fontSize }: { label: string; value: number; fontSize: number }) {
  return (
    <div className="flex items-center gap-1">
      <span style={{ fontSize: fontSize - 1 }}>{label}</span>
      <span style={{ fontSize, color: "#999", fontWeight: 400, fontVariantNumeric: "tabular-nums" }}>
        {value}
      </span>
    </div>
  );
}

function Divider() {
  return <div style={{ width: 1, height: 12, backgroundColor: "rgba(0,0,0,0.06)" }} />;
}
