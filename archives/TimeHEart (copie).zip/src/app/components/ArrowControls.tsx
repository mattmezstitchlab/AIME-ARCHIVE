import { motion } from "motion/react";
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { useResponsive } from "./useResponsive";
import type { AccessibilityMode } from "./game-data";

interface ArrowControlsProps {
  onMove: (dx: number, dy: number) => void;
  mode: AccessibilityMode;
}

export function ArrowControls({ onMove, mode }: ArrowControlsProps) {
  const { isMobile, isTablet } = useResponsive();
  const isSenior = mode === "senior";
  const isChild = mode === "child";
  const isLarge = isSenior || isChild;

  // Responsive sizes
  const btnSize = isMobile
    ? (isLarge ? 56 : 44)
    : isTablet
      ? (isLarge ? 60 : 46)
      : (isLarge ? 68 : 48);

  const iconSize = isMobile
    ? (isLarge ? 22 : 16)
    : isTablet
      ? (isLarge ? 24 : 17)
      : (isLarge ? 26 : 18);

  const gapSize = isMobile ? 2 : isLarge ? 5 : 3;
  const bottomOffset = isMobile ? 12 : 20;

  return (
    <div
      className="fixed left-1/2 -translate-x-1/2 z-30"
      style={{ bottom: bottomOffset, touchAction: "none" }}
    >
      <div className="flex flex-col items-center" style={{ gap: gapSize }}>
        <ArrowBtn dx={0} dy={-1} icon={ChevronUp} size={btnSize} iconSize={iconSize} onMove={onMove} label="Haut" isMobile={isMobile} />
        <div className="flex items-center" style={{ gap: gapSize }}>
          <ArrowBtn dx={-1} dy={0} icon={ChevronLeft} size={btnSize} iconSize={iconSize} onMove={onMove} label="Gauche" isMobile={isMobile} />
          <div
            className="rounded-lg flex items-center justify-center"
            style={{ width: btnSize, height: btnSize, backgroundColor: "rgba(255,255,255,0.15)" }}
          >
            <div className="rounded-full" style={{ width: 4, height: 4, backgroundColor: "rgba(0,0,0,0.08)" }} />
          </div>
          <ArrowBtn dx={1} dy={0} icon={ChevronRight} size={btnSize} iconSize={iconSize} onMove={onMove} label="Droite" isMobile={isMobile} />
        </div>
        <ArrowBtn dx={0} dy={1} icon={ChevronDown} size={btnSize} iconSize={iconSize} onMove={onMove} label="Bas" isMobile={isMobile} />
      </div>
    </div>
  );
}

function ArrowBtn({
  dx, dy, icon: Icon, size, iconSize, onMove, label, isMobile,
}: {
  dx: number; dy: number; icon: typeof ChevronUp;
  size: number; iconSize: number; onMove: (dx: number, dy: number) => void; label: string; isMobile: boolean;
}) {
  return (
    <motion.button
      className="flex items-center justify-center cursor-pointer border-none"
      style={{
        width: size,
        height: size,
        borderRadius: isMobile ? 14 : 16,
        backgroundColor: "rgba(255,255,255,0.8)",
        backdropFilter: "blur(12px)",
        boxShadow: "0 2px 10px rgba(0,0,0,0.04), 0 0 0 1px rgba(0,0,0,0.03)",
        color: "#666",
      }}
      onClick={() => onMove(dx, dy)}
      whileHover={{ scale: 1.08, backgroundColor: "rgba(255,255,255,0.95)" }}
      whileTap={{ scale: 0.88, backgroundColor: "rgba(0,0,0,0.04)" }}
      aria-label={label}
    >
      <Icon size={iconSize} strokeWidth={1.8} />
    </motion.button>
  );
}
