import { motion, AnimatePresence } from "motion/react";
import { X, Footprints, Sparkles, Eye } from "lucide-react";
import { PlayerSquare } from "./PlayerSquare";
import { StitchLabBadge } from "./StitchLabLogo";
import { useResponsive } from "./useResponsive";
import type { PlayerData, AccessibilityMode } from "./game-data";

interface ProfilePanelProps {
  visible: boolean;
  onClose: () => void;
  player: PlayerData;
  mode: AccessibilityMode;
  onModeChange: (mode: AccessibilityMode) => void;
  stats: { points: number; steps: number; discoveries: number };
}

const MODE_OPTIONS: { key: AccessibilityMode; label: string; icon: string; desc: string }[] = [
  { key: "default", label: "Standard", icon: "◉", desc: "Expérience classique" },
  { key: "child", label: "Enfant", icon: "◎", desc: "Contrastes forts" },
  { key: "senior", label: "Senior", icon: "◈", desc: "Taille XXL" },
  { key: "accessibility", label: "Accessibilité", icon: "◇", desc: "Clavier, contraste" },
];

export function ProfilePanel({ visible, onClose, player, mode, onModeChange, stats }: ProfilePanelProps) {
  const { isMobile } = useResponsive();

  return (
    <AnimatePresence>
      {visible && (
        <>
          <motion.div
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(250,248,245,0.5)", backdropFilter: "blur(6px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.div
            className="fixed z-50 rounded-2xl flex flex-col gap-5 overflow-y-auto"
            style={{
              top: isMobile ? 10 : 40,
              right: isMobile ? 10 : 40,
              left: isMobile ? 10 : "auto",
              width: isMobile ? "calc(100vw - 20px)" : 320,
              maxHeight: isMobile ? "calc(100vh - 20px)" : "calc(100vh - 80px)",
              backgroundColor: "rgba(255,255,255,0.96)",
              backdropFilter: "blur(24px)",
              boxShadow: "0 16px 64px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.02)",
              padding: isMobile ? 16 : 24,
            }}
            initial={{ opacity: 0, x: 20, scale: 0.96 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 10, scale: 0.98 }}
            transition={{ duration: 0.25 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between">
              <StitchLabBadge size="sm" />
              <motion.button
                className="flex items-center justify-center rounded-full border-none cursor-pointer"
                style={{ width: 28, height: 28, backgroundColor: "rgba(0,0,0,0.04)", color: "#aaa" }}
                onClick={onClose}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X size={13} />
              </motion.button>
            </div>

            {/* Player card */}
            <div className="flex items-center gap-4">
              <PlayerSquare
                colorHex={player.colorHex}
                symbol={player.symbol}
                symbol2={player.symbol2}
                symbolSize={player.symbolSize}
                symbolRotation={player.symbolRotation}
                symbolContrast={player.symbolContrast}
                size={56}
                isCurrentPlayer
                mode={mode}
              />
              <div className="flex flex-col gap-0.5 min-w-0">
                <span style={{ fontSize: 15, fontWeight: 500, color: "#1a1a1a" }}>
                  {player.pseudo}
                </span>
                {player.city && (
                  <span style={{ fontSize: 11, color: "#bbb" }}>{player.city}</span>
                )}
                {player.intention && (
                  <span style={{ fontSize: 10, color: "#ccc", fontStyle: "italic" }}>
                    {player.intention}
                  </span>
                )}
              </div>
            </div>

            {/* Stats */}
            <div className="flex gap-3">
              <StatBox icon={<Footprints size={12} strokeWidth={1.5} />} label="Pas" value={stats.steps} />
              <StatBox icon={<Sparkles size={12} strokeWidth={1.5} />} label="Fils" value={stats.points} />
              <StatBox icon={<Eye size={12} strokeWidth={1.5} />} label="Découvertes" value={stats.discoveries} />
            </div>

            {/* Color & code */}
            <div className="flex items-center gap-3 px-3 py-2 rounded-xl" style={{ backgroundColor: "rgba(0,0,0,0.02)" }}>
              <div className="rounded-[2px]" style={{ width: 20, height: 20, backgroundColor: player.colorHex }} />
              <div className="flex flex-col">
                <span style={{ fontSize: 10, color: "#999" }}>DMC {player.colorCode}</span>
                <span style={{ fontSize: 9, color: "#ccc" }}>Position: {player.x}, {player.y}</span>
              </div>
            </div>

            {/* Divider */}
            <div style={{ height: 1, backgroundColor: "rgba(0,0,0,0.04)" }} />

            {/* Mode */}
            <div className="flex flex-col gap-2">
              <span style={{ fontSize: 9, letterSpacing: "0.18em", color: "#bbb", textTransform: "uppercase" }}>
                Mode
              </span>
              {MODE_OPTIONS.map((m) => {
                const isActive = mode === m.key;
                return (
                  <motion.button
                    key={m.key}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-xl cursor-pointer border-none text-left w-full"
                    style={{
                      backgroundColor: isActive ? "rgba(0,0,0,0.05)" : "rgba(0,0,0,0)",
                      color: isActive ? "#1a1a1a" : "#999",
                    }}
                    onClick={() => onModeChange(m.key)}
                    whileHover={{ backgroundColor: "rgba(0,0,0,0.03)" }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <span style={{ fontSize: 13, opacity: isActive ? 1 : 0.5 }}>{m.icon}</span>
                    <div className="flex flex-col">
                      <span style={{ fontSize: 11, fontWeight: isActive ? 500 : 400 }}>{m.label}</span>
                      <span style={{ fontSize: 8, color: "#ccc", fontWeight: 300 }}>{m.desc}</span>
                    </div>
                  </motion.button>
                );
              })}
            </div>

            {/* Footer */}
            <div className="flex flex-col items-center gap-1 pt-2">
              <span style={{ fontSize: 8, color: "#ddd", letterSpacing: "0.1em" }}>
                STITCHLAB — Where stitchers connect
              </span>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div
      className="flex-1 flex flex-col items-center gap-1 py-2 rounded-xl"
      style={{ backgroundColor: "rgba(0,0,0,0.02)" }}
    >
      <div className="flex items-center gap-1" style={{ color: "#bbb" }}>
        {icon}
        <span style={{ fontSize: 8, letterSpacing: "0.05em", color: "#ccc" }}>{label}</span>
      </div>
      <span style={{ fontSize: 16, fontWeight: 500, color: "#1a1a1a", fontVariantNumeric: "tabular-nums" }}>
        {value}
      </span>
    </div>
  );
}