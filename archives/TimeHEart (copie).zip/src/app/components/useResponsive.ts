import { useState, useEffect } from "react";

export type DeviceType = "mobile" | "tablet" | "desktop";

export function useResponsive() {
  const [vw, setVw] = useState(window.innerWidth);
  const [vh, setVh] = useState(window.innerHeight);

  useEffect(() => {
    const handle = () => {
      setVw(window.innerWidth);
      setVh(window.innerHeight);
    };
    window.addEventListener("resize", handle);
    return () => window.removeEventListener("resize", handle);
  }, []);

  const device: DeviceType = vw < 640 ? "mobile" : vw < 1024 ? "tablet" : "desktop";
  const isMobile = device === "mobile";
  const isTablet = device === "tablet";
  const isDesktop = device === "desktop";

  return { vw, vh, device, isMobile, isTablet, isDesktop };
}
