import { useState, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, Scissors, Send, Star, MessageCircle,
  Sparkles, CheckCircle, AlertCircle, Clock, Smartphone,
  BarChart3, Heart, ChevronRight, Wifi, WifiOff,
} from "lucide-react";
import { StitchLabLogo } from "./StitchLabLogo";
import { StitchDock } from "./StitchDock";
import { useResponsive } from "./useResponsive";
import { BG_IVORY } from "./game-data";
import * as api from "./api";
import { projectId, publicAnonKey } from "/utils/supabase/info";

// ═══════════════════════════════════════════
// BETA TEST — User Testing & Feedback Page
// Real validation from real stitchers.
// ═══════════════════════════════════════════

type TestStep = "intro" | "dock-test" | "lily-test" | "feedback" | "results";

interface FeedbackData {
  testerName: string;
  stitchingLevel: "debutante" | "intermediaire" | "experte";
  dockRating: number;
  dockFavoriteTools: string[];
  dockEaseOfUse: number;
  lilyRating: number;
  lilyHelpful: boolean;
  lilyVoiceOpinion: "adore" | "bien" | "bof" | "non";
  wouldPay: boolean;
  maxPrice: string;
  freeText: string;
  timestamp: number;
}

const PRICE_OPTIONS = ["0 — gratuit seulement", "2.99 /mois", "4.99 /mois", "9.99 /mois", "14.99 /mois"];

export function BetaTest({ onBack }: { onBack: () => void }) {
  const { isMobile } = useResponsive();
  const [step, setStep] = useState<TestStep>("intro");
  const [feedback, setFeedback] = useState<Partial<FeedbackData>>({
    dockFavoriteTools: [],
    dockRating: 0,
    dockEaseOfUse: 0,
    lilyRating: 0,
    lilyVoiceOpinion: "bien",
    stitchingLevel: "intermediaire",
    wouldPay: false,
    maxPrice: "4.99 /mois",
  });
  const [submitted, setSubmitted] = useState(false);
  const [lilyMessages, setLilyMessages] = useState<{ role: "user" | "lily"; text: string }[]>([]);
  const [lilyInput, setLilyInput] = useState("");
  const [lilyThinking, setLilyThinking] = useState(false);
  const [lilyConnected, setLilyConnected] = useState(true);
  const [allFeedback, setAllFeedback] = useState<FeedbackData[]>([]);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [lilyMessages]);

  // Load all feedback for results
  useEffect(() => {
    if (step === "results") {
      api.getLilyUsage().catch(() => {});
      // Load feedback from KV
      fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-952ea964/beta/feedback`,
        { headers: { Authorization: `Bearer ${publicAnonKey}` } }
      ).catch(() => {});
    }
  }, [step]);

  const sendLilyMessage = useCallback(async () => {
    if (!lilyInput.trim() || lilyThinking) return;
    const userMsg = lilyInput.trim();
    setLilyInput("");
    const newMessages = [...lilyMessages, { role: "user" as const, text: userMsg }];
    setLilyMessages(newMessages);
    setLilyThinking(true);
    try {
      const chatMsgs: api.LilyChatMessage[] = newMessages.map(m => ({
        role: m.role === "lily" ? "lily" : "user",
        text: m.text,
      }));
      const res = await api.chatWithLily(chatMsgs, { pseudo: feedback.testerName || "Testeuse Beta" });
      setLilyConnected(true);
      setLilyMessages(prev => [...prev, { role: "lily", text: res.text }]);
    } catch {
      setLilyConnected(false);
      setLilyMessages(prev => [...prev, {
        role: "lily",
        text: "Oups, je n'arrive pas a me connecter... Mais en vrai, je suis Lily, l'experte broderie de StitchLab ! Pose-moi des questions sur les fils DMC, les techniques, ou glisse-moi une photo.",
      }]);
    } finally {
      setLilyThinking(false);
    }
  }, [lilyInput, lilyThinking, lilyMessages, feedback.testerName]);

  const submitFeedback = useCallback(async () => {
    const data: FeedbackData = {
      testerName: feedback.testerName || "Anonyme",
      stitchingLevel: feedback.stitchingLevel || "intermediaire",
      dockRating: feedback.dockRating || 0,
      dockFavoriteTools: feedback.dockFavoriteTools || [],
      dockEaseOfUse: feedback.dockEaseOfUse || 0,
      lilyRating: feedback.lilyRating || 0,
      lilyHelpful: feedback.lilyRating ? feedback.lilyRating >= 3 : false,
      lilyVoiceOpinion: feedback.lilyVoiceOpinion || "bien",
      wouldPay: feedback.wouldPay || false,
      maxPrice: feedback.maxPrice || "0",
      freeText: feedback.freeText || "",
      timestamp: Date.now(),
    };
    setSubmitted(true);
    // Non-blocking save
    try {
      const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-952ea964`;
      await fetch(`${BASE}/beta/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${publicAnonKey}` },
        body: JSON.stringify(data),
      });
    } catch (e) {
      console.log("Feedback save (non-critical):", e);
    }
    setTimeout(() => setStep("results"), 1500);
  }, [feedback]);

  const updateFeedback = (key: keyof FeedbackData, value: any) => {
    setFeedback(prev => ({ ...prev, [key]: value }));
  };

  const toggleTool = (tool: string) => {
    setFeedback(prev => {
      const tools = prev.dockFavoriteTools || [];
      return {
        ...prev,
        dockFavoriteTools: tools.includes(tool) ? tools.filter(t => t !== tool) : [...tools, tool],
      };
    });
  };

  // Styles
  const cardStyle: React.CSSProperties = {
    backgroundColor: "rgba(255,255,255,0.85)",
    backdropFilter: "blur(20px)",
    borderRadius: 16,
    border: "1px solid rgba(0,0,0,0.04)",
    boxShadow: "0 4px 24px rgba(0,0,0,0.03)",
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 10,
    fontWeight: 500,
    color: "#888",
    letterSpacing: "0.08em",
    textTransform: "uppercase" as const,
    marginBottom: 8,
  };

  return (
    <div
      className="fixed inset-0 overflow-y-auto"
      style={{ backgroundColor: BG_IVORY, fontFamily: "'Inter', -apple-system, sans-serif" }}
    >
      {/* HEADER */}
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4"
        style={{ backgroundColor: "rgba(250,248,245,0.9)", backdropFilter: "blur(12px)" }}
      >
        <motion.button
          className="flex items-center gap-2 cursor-pointer border-none"
          style={{ backgroundColor: "rgba(0,0,0,0)", color: "#999", fontSize: 11 }}
          onClick={onBack}
          whileHover={{ x: -3 }} whileTap={{ scale: 0.95 }}
        >
          <ArrowLeft size={14} strokeWidth={1.5} />
          Retour
        </motion.button>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: "#42A350" }} />
          <span style={{ fontSize: 9, color: "#42A350", fontWeight: 500, letterSpacing: "0.08em" }}>
            BETA TEST
          </span>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 pb-20" style={{ paddingTop: 8 }}>
        <AnimatePresence mode="wait">

          {/* ═══ STEP 1: INTRO ═══ */}
          {step === "intro" && (
            <motion.div
              key="intro"
              className="flex flex-col items-center gap-8 pt-8"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.5 }}
            >
              <StitchLabLogo size="md" animate />

              <div className="flex flex-col items-center gap-2">
                <span style={{ fontSize: 8, color: "#9263A6", letterSpacing: "0.2em", fontWeight: 500, textTransform: "uppercase" }}>
                  Session de test beta
                </span>
                <h2 className="text-center" style={{ fontSize: isMobile ? 22 : 26, fontWeight: 300, color: "#1a1a1a", lineHeight: 1.4 }}>
                  Aide-nous a creer<br />le compagnon de broderie ideal
                </h2>
                <p className="text-center" style={{ fontSize: 12, color: "#999", maxWidth: 360, lineHeight: 1.7, marginTop: 8 }}>
                  Tu vas tester 2 fonctionnalites de StitchLab. Ca prend ~3 minutes.
                  Ton avis compte enormement.
                </p>
              </div>

              {/* Name + Level */}
              <div className="w-full flex flex-col gap-4" style={{ ...cardStyle, padding: isMobile ? 20 : 24 }}>
                <div>
                  <label style={labelStyle}>Ton prenom ou pseudo</label>
                  <input
                    className="w-full border-none outline-none"
                    style={{
                      backgroundColor: "rgba(0,0,0,0.02)",
                      borderRadius: 10,
                      padding: "10px 14px",
                      fontSize: 13,
                      color: "#1a1a1a",
                    }}
                    placeholder="Ex: Marie, BrodeuseDu44..."
                    value={feedback.testerName || ""}
                    onChange={e => updateFeedback("testerName", e.target.value)}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Ton niveau en broderie</label>
                  <div className="flex gap-2">
                    {(["debutante", "intermediaire", "experte"] as const).map(level => (
                      <motion.button
                        key={level}
                        className="flex-1 cursor-pointer border-none py-2 rounded-lg"
                        style={{
                          backgroundColor: feedback.stitchingLevel === level ? "rgba(146,99,166,0.1)" : "rgba(0,0,0,0.02)",
                          color: feedback.stitchingLevel === level ? "#9263A6" : "#aaa",
                          fontSize: 11,
                          fontWeight: feedback.stitchingLevel === level ? 500 : 400,
                          border: `1px solid ${feedback.stitchingLevel === level ? "rgba(146,99,166,0.2)" : "rgba(0,0,0,0.04)"}`,
                        }}
                        onClick={() => updateFeedback("stitchingLevel", level)}
                        whileTap={{ scale: 0.97 }}
                      >
                        {level === "debutante" ? "Debutante" : level === "intermediaire" ? "Intermediaire" : "Experte"}
                      </motion.button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Test steps preview */}
              <div className="w-full flex flex-col gap-2">
                {[
                  { icon: Sparkles, label: "Test 1 — StitchDock", desc: "Le widget micro-outils broderie", time: "~1 min" },
                  { icon: Scissors, label: "Test 2 — Lily IA", desc: "L'assistante broderie intelligente", time: "~1 min" },
                  { icon: Heart, label: "Ton avis", desc: "Feedback et prix acceptable", time: "~1 min" },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    className="flex items-center gap-3 w-full px-4 py-3 rounded-xl"
                    style={{ backgroundColor: "rgba(0,0,0,0.015)" }}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + i * 0.15 }}
                  >
                    <item.icon size={14} color="#9263A6" strokeWidth={1.5} />
                    <div className="flex-1">
                      <div style={{ fontSize: 12, color: "#1a1a1a", fontWeight: 400 }}>{item.label}</div>
                      <div style={{ fontSize: 9, color: "#bbb" }}>{item.desc}</div>
                    </div>
                    <span style={{ fontSize: 8, color: "#ddd" }}>{item.time}</span>
                  </motion.div>
                ))}
              </div>

              <motion.button
                className="w-full cursor-pointer border-none py-3.5 rounded-xl"
                style={{ backgroundColor: "#1a1a1a", color: BG_IVORY, fontSize: 12, fontWeight: 400, letterSpacing: "0.08em" }}
                onClick={() => setStep("dock-test")}
                whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              >
                COMMENCER LE TEST
              </motion.button>
            </motion.div>
          )}

          {/* ═══ STEP 2: STITCH DOCK TEST ═══ */}
          {step === "dock-test" && (
            <motion.div
              key="dock-test"
              className="flex flex-col gap-6 pt-4"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex flex-col items-center gap-2">
                <span style={{ fontSize: 8, color: "#9263A6", letterSpacing: "0.2em", fontWeight: 500 }}>TEST 1 / 3</span>
                <h3 style={{ fontSize: 18, fontWeight: 300, color: "#1a1a1a", textAlign: "center" }}>
                  StitchDock
                </h3>
                <p style={{ fontSize: 11, color: "#999", textAlign: "center", lineHeight: 1.6 }}>
                  Clique le carre noir pour ouvrir le widget.<br />
                  Explore les 8 outils, puis donne ton avis.
                </p>
              </div>

              {/* Live StitchDock */}
              <div
                className="relative flex items-center justify-center overflow-hidden rounded-2xl"
                style={{ height: 320, backgroundColor: "rgba(0,0,0,0.015)", border: "1px dashed rgba(0,0,0,0.06)" }}
              >
                <StitchDock />
                <div className="absolute bottom-3 left-0 right-0 text-center">
                  <span style={{ fontSize: 8, color: "#ccc", letterSpacing: "0.08em" }}>
                    Interactif — clique le carre central
                  </span>
                </div>
              </div>

              {/* Rating */}
              <div style={{ ...cardStyle, padding: 20 }}>
                <label style={labelStyle}>Note le widget (1-5)</label>
                <div className="flex gap-2 justify-center">
                  {[1, 2, 3, 4, 5].map(n => (
                    <motion.button
                      key={n}
                      className="cursor-pointer border-none rounded-lg"
                      style={{
                        width: 44, height: 44,
                        backgroundColor: (feedback.dockRating || 0) >= n ? "rgba(146,99,166,0.12)" : "rgba(0,0,0,0.02)",
                        border: `1px solid ${(feedback.dockRating || 0) >= n ? "rgba(146,99,166,0.25)" : "rgba(0,0,0,0.04)"}`,
                      }}
                      onClick={() => updateFeedback("dockRating", n)}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Star
                        size={16}
                        fill={(feedback.dockRating || 0) >= n ? "#9263A6" : "none"}
                        color={(feedback.dockRating || 0) >= n ? "#9263A6" : "#ddd"}
                        strokeWidth={1.5}
                      />
                    </motion.button>
                  ))}
                </div>

                <label style={{ ...labelStyle, marginTop: 16 }}>Facilite d'utilisation (1-5)</label>
                <div className="flex gap-2 justify-center">
                  {[1, 2, 3, 4, 5].map(n => (
                    <motion.button
                      key={n}
                      className="cursor-pointer border-none rounded-lg text-center"
                      style={{
                        width: 44, height: 44,
                        backgroundColor: (feedback.dockEaseOfUse || 0) >= n ? "rgba(66,163,80,0.1)" : "rgba(0,0,0,0.02)",
                        border: `1px solid ${(feedback.dockEaseOfUse || 0) >= n ? "rgba(66,163,80,0.2)" : "rgba(0,0,0,0.04)"}`,
                        fontSize: 14,
                        color: (feedback.dockEaseOfUse || 0) >= n ? "#42A350" : "#ddd",
                      }}
                      onClick={() => updateFeedback("dockEaseOfUse", n)}
                      whileTap={{ scale: 0.9 }}
                    >
                      {n}
                    </motion.button>
                  ))}
                </div>

                <label style={{ ...labelStyle, marginTop: 16 }}>Tes outils preferes (clique)</label>
                <div className="flex flex-wrap gap-1.5 justify-center">
                  {["DMC Finder", "Compteur", "Timer", "Palette", "Notes", "Pattern", "Lily", "Partage"].map(tool => {
                    const selected = (feedback.dockFavoriteTools || []).includes(tool);
                    return (
                      <motion.button
                        key={tool}
                        className="cursor-pointer border-none rounded-lg px-3 py-1.5"
                        style={{
                          backgroundColor: selected ? "rgba(146,99,166,0.1)" : "rgba(0,0,0,0.02)",
                          color: selected ? "#9263A6" : "#bbb",
                          fontSize: 10,
                          fontWeight: selected ? 500 : 400,
                          border: `1px solid ${selected ? "rgba(146,99,166,0.2)" : "rgba(0,0,0,0.04)"}`,
                        }}
                        onClick={() => toggleTool(tool)}
                        whileTap={{ scale: 0.95 }}
                      >
                        {selected && <CheckCircle size={8} className="inline mr-1" />}
                        {tool}
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              <motion.button
                className="w-full cursor-pointer border-none py-3 rounded-xl flex items-center justify-center gap-2"
                style={{ backgroundColor: "#1a1a1a", color: BG_IVORY, fontSize: 11, letterSpacing: "0.06em" }}
                onClick={() => setStep("lily-test")}
                whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              >
                Suivant — Tester Lily IA <ChevronRight size={12} />
              </motion.button>
            </motion.div>
          )}

          {/* ═══ STEP 3: LILY AI TEST ═══ */}
          {step === "lily-test" && (
            <motion.div
              key="lily-test"
              className="flex flex-col gap-5 pt-4"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex flex-col items-center gap-2">
                <span style={{ fontSize: 8, color: "#9263A6", letterSpacing: "0.2em", fontWeight: 500 }}>TEST 2 / 3</span>
                <h3 style={{ fontSize: 18, fontWeight: 300, color: "#1a1a1a", textAlign: "center" }}>
                  Lily, ton assistante broderie
                </h3>
                <p style={{ fontSize: 11, color: "#999", textAlign: "center", lineHeight: 1.6 }}>
                  Pose-lui une question sur la broderie.<br />
                  Elle connait les fils DMC, les techniques, tout.
                </p>
              </div>

              {/* Mini chat */}
              <div style={{ ...cardStyle, overflow: "hidden" }}>
                {/* Chat header */}
                <div className="flex items-center gap-2.5 px-4 py-3" style={{ borderBottom: "1px solid rgba(0,0,0,0.04)" }}>
                  <div
                    className="rounded-md flex items-center justify-center"
                    style={{ width: 28, height: 28, background: "linear-gradient(135deg, #9263A6, #6B3F7F)" }}
                  >
                    <Scissors size={12} color="#fff" strokeWidth={1.5} />
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1.5">
                      <span style={{ fontSize: 12, fontWeight: 500, color: "#1a1a1a" }}>Lily</span>
                      {lilyConnected
                        ? <Wifi size={8} color="#42A350" strokeWidth={2} />
                        : <WifiOff size={8} color="#ccc" strokeWidth={2} />
                      }
                      <span style={{ fontSize: 7, color: lilyConnected ? "#42A350" : "#ccc" }}>
                        {lilyConnected ? "IA Claude" : "local"}
                      </span>
                    </div>
                    <span style={{ fontSize: 8, color: "#9263A6" }}>Experte broderie</span>
                  </div>
                </div>

                {/* Messages */}
                <div
                  ref={chatRef}
                  className="flex flex-col gap-2.5 overflow-y-auto px-4 py-3"
                  style={{ height: 220, scrollBehavior: "smooth" }}
                >
                  {/* Welcome */}
                  <div className="flex gap-2" style={{ maxWidth: "85%" }}>
                    <div className="px-3 py-2 rounded-xl" style={{ backgroundColor: "rgba(146,99,166,0.06)", fontSize: 12, color: "#444", lineHeight: 1.6 }}>
                      Bonjour{feedback.testerName ? ` ${feedback.testerName}` : ""} ! Je suis Lily. Pose-moi une question sur la broderie — fils DMC, techniques, toiles...
                    </div>
                  </div>

                  {lilyMessages.map((msg, i) => (
                    <div
                      key={i}
                      className="flex"
                      style={{ justifyContent: msg.role === "user" ? "flex-end" : "flex-start", maxWidth: "85%" ,
                        alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
                      }}
                    >
                      <div
                        className="px-3 py-2 rounded-xl"
                        style={{
                          backgroundColor: msg.role === "user" ? "#1a1a1a" : "rgba(146,99,166,0.06)",
                          color: msg.role === "user" ? "#fff" : "#444",
                          fontSize: 12,
                          lineHeight: 1.6,
                        }}
                      >
                        {msg.text}
                      </div>
                    </div>
                  ))}

                  {lilyThinking && (
                    <div className="flex gap-2" style={{ maxWidth: "85%" }}>
                      <div className="px-3 py-2 rounded-xl" style={{ backgroundColor: "rgba(146,99,166,0.06)" }}>
                        <motion.div
                          className="flex gap-1"
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ duration: 1.2, repeat: Infinity }}
                        >
                          {[0, 1, 2].map(d => (
                            <div key={d} className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: "#9263A6" }} />
                          ))}
                        </motion.div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Input */}
                <div className="flex items-center gap-2 px-3 py-2.5" style={{ borderTop: "1px solid rgba(0,0,0,0.04)" }}>
                  <input
                    className="flex-1 border-none outline-none"
                    style={{ backgroundColor: "rgba(0,0,0,0.02)", borderRadius: 10, padding: "8px 12px", fontSize: 12, color: "#1a1a1a" }}
                    placeholder="Ex: C'est quoi le point arriere ?"
                    value={lilyInput}
                    onChange={e => setLilyInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && sendLilyMessage()}
                    disabled={lilyThinking}
                  />
                  <motion.button
                    className="cursor-pointer border-none rounded-lg flex items-center justify-center"
                    style={{ width: 32, height: 32, backgroundColor: lilyInput.trim() ? "#9263A6" : "rgba(0,0,0,0.04)", color: lilyInput.trim() ? "#fff" : "#ddd" }}
                    onClick={sendLilyMessage}
                    whileTap={{ scale: 0.9 }}
                    disabled={!lilyInput.trim() || lilyThinking}
                  >
                    <Send size={12} />
                  </motion.button>
                </div>

                {/* Suggestions */}
                <div className="flex gap-1.5 px-3 pb-3 flex-wrap">
                  {["Qu'est-ce que le DMC 321 ?", "Conseils pour debuter", "C'est quoi le backstitch ?"].map(q => (
                    <motion.button
                      key={q}
                      className="cursor-pointer border-none rounded-full px-2.5 py-1"
                      style={{ backgroundColor: "rgba(0,0,0,0.02)", color: "#bbb", fontSize: 9, border: "1px solid rgba(0,0,0,0.04)" }}
                      onClick={() => { setLilyInput(q); }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {q}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Rating */}
              <div style={{ ...cardStyle, padding: 20 }}>
                <label style={labelStyle}>Note Lily (1-5)</label>
                <div className="flex gap-2 justify-center">
                  {[1, 2, 3, 4, 5].map(n => (
                    <motion.button
                      key={n}
                      className="cursor-pointer border-none rounded-lg"
                      style={{
                        width: 44, height: 44,
                        backgroundColor: (feedback.lilyRating || 0) >= n ? "rgba(146,99,166,0.12)" : "rgba(0,0,0,0.02)",
                        border: `1px solid ${(feedback.lilyRating || 0) >= n ? "rgba(146,99,166,0.25)" : "rgba(0,0,0,0.04)"}`,
                      }}
                      onClick={() => updateFeedback("lilyRating", n)}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Star
                        size={16}
                        fill={(feedback.lilyRating || 0) >= n ? "#9263A6" : "none"}
                        color={(feedback.lilyRating || 0) >= n ? "#9263A6" : "#ddd"}
                        strokeWidth={1.5}
                      />
                    </motion.button>
                  ))}
                </div>
              </div>

              <motion.button
                className="w-full cursor-pointer border-none py-3 rounded-xl flex items-center justify-center gap-2"
                style={{ backgroundColor: "#1a1a1a", color: BG_IVORY, fontSize: 11, letterSpacing: "0.06em" }}
                onClick={() => setStep("feedback")}
                whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              >
                Suivant — Donner mon avis final <ChevronRight size={12} />
              </motion.button>
            </motion.div>
          )}

          {/* ═══ STEP 4: FINAL FEEDBACK ═══ */}
          {step === "feedback" && (
            <motion.div
              key="feedback"
              className="flex flex-col gap-6 pt-4"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex flex-col items-center gap-2">
                <span style={{ fontSize: 8, color: "#9263A6", letterSpacing: "0.2em", fontWeight: 500 }}>TEST 3 / 3</span>
                <h3 style={{ fontSize: 18, fontWeight: 300, color: "#1a1a1a", textAlign: "center" }}>
                  Ton avis compte
                </h3>
              </div>

              {/* Voice opinion */}
              <div style={{ ...cardStyle, padding: 20 }}>
                <label style={labelStyle}>Lily pourrait te parler avec une vraie voix (TTS Nova). Ton avis ?</label>
                <div className="flex gap-2 flex-wrap">
                  {([
                    { key: "adore", label: "J'adorerais !", color: "#9263A6" },
                    { key: "bien", label: "Pourquoi pas", color: "#666" },
                    { key: "bof", label: "Bof", color: "#aaa" },
                    { key: "non", label: "Non merci", color: "#ddd" },
                  ] as const).map(opt => (
                    <motion.button
                      key={opt.key}
                      className="cursor-pointer border-none rounded-lg px-3 py-2 flex-1"
                      style={{
                        backgroundColor: feedback.lilyVoiceOpinion === opt.key ? "rgba(146,99,166,0.1)" : "rgba(0,0,0,0.02)",
                        color: feedback.lilyVoiceOpinion === opt.key ? opt.color : "#bbb",
                        fontSize: 10,
                        fontWeight: feedback.lilyVoiceOpinion === opt.key ? 500 : 400,
                        border: `1px solid ${feedback.lilyVoiceOpinion === opt.key ? "rgba(146,99,166,0.2)" : "rgba(0,0,0,0.04)"}`,
                        minWidth: 70,
                      }}
                      onClick={() => updateFeedback("lilyVoiceOpinion", opt.key)}
                      whileTap={{ scale: 0.95 }}
                    >
                      {opt.label}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Would pay? */}
              <div style={{ ...cardStyle, padding: 20 }}>
                <label style={labelStyle}>Paierais-tu un abonnement pour StitchDock + Lily IA ?</label>
                <div className="flex gap-3 mb-4">
                  {[
                    { val: true, label: "Oui, si c'est bien fait" },
                    { val: false, label: "Non, gratuit seulement" },
                  ].map(opt => (
                    <motion.button
                      key={String(opt.val)}
                      className="flex-1 cursor-pointer border-none rounded-lg py-2.5"
                      style={{
                        backgroundColor: feedback.wouldPay === opt.val ? "rgba(146,99,166,0.1)" : "rgba(0,0,0,0.02)",
                        color: feedback.wouldPay === opt.val ? "#9263A6" : "#bbb",
                        fontSize: 11,
                        fontWeight: feedback.wouldPay === opt.val ? 500 : 400,
                        border: `1px solid ${feedback.wouldPay === opt.val ? "rgba(146,99,166,0.2)" : "rgba(0,0,0,0.04)"}`,
                      }}
                      onClick={() => updateFeedback("wouldPay", opt.val)}
                      whileTap={{ scale: 0.97 }}
                    >
                      {opt.label}
                    </motion.button>
                  ))}
                </div>

                {feedback.wouldPay && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
                    transition={{ duration: 0.3 }}
                  >
                    <label style={labelStyle}>Prix maximum acceptable ?</label>
                    <div className="flex flex-col gap-1.5">
                      {PRICE_OPTIONS.map(price => (
                        <motion.button
                          key={price}
                          className="cursor-pointer border-none rounded-lg py-2 px-3 text-left"
                          style={{
                            backgroundColor: feedback.maxPrice === price ? "rgba(146,99,166,0.1)" : "rgba(0,0,0,0.02)",
                            color: feedback.maxPrice === price ? "#9263A6" : "#999",
                            fontSize: 11,
                            border: `1px solid ${feedback.maxPrice === price ? "rgba(146,99,166,0.2)" : "rgba(0,0,0,0.04)"}`,
                          }}
                          onClick={() => updateFeedback("maxPrice", price)}
                          whileTap={{ scale: 0.98 }}
                        >
                          {price.startsWith("0") ? price : `$${price}`}
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Free text */}
              <div style={{ ...cardStyle, padding: 20 }}>
                <label style={labelStyle}>Un mot, une idee, un truc qui manque ?</label>
                <textarea
                  className="w-full border-none outline-none resize-none"
                  style={{
                    backgroundColor: "rgba(0,0,0,0.02)",
                    borderRadius: 10,
                    padding: "10px 14px",
                    fontSize: 12,
                    color: "#1a1a1a",
                    minHeight: 80,
                    lineHeight: 1.6,
                  }}
                  placeholder="Dis-nous tout..."
                  value={feedback.freeText || ""}
                  onChange={e => updateFeedback("freeText", e.target.value)}
                />
              </div>

              {/* Submit */}
              <motion.button
                className="w-full cursor-pointer border-none py-3.5 rounded-xl flex items-center justify-center gap-2"
                style={{
                  backgroundColor: submitted ? "#42A350" : "#9263A6",
                  color: "#fff",
                  fontSize: 12,
                  fontWeight: 500,
                  letterSpacing: "0.06em",
                }}
                onClick={submitFeedback}
                whileHover={{ scale: submitted ? 1 : 1.02 }}
                whileTap={{ scale: submitted ? 1 : 0.98 }}
                disabled={submitted}
              >
                {submitted ? (
                  <><CheckCircle size={14} /> Merci !</>
                ) : (
                  <>Envoyer mon feedback <Send size={12} /></>
                )}
              </motion.button>
            </motion.div>
          )}

          {/* ═══ STEP 5: RESULTS / THANK YOU ═══ */}
          {step === "results" && (
            <motion.div
              key="results"
              className="flex flex-col items-center gap-8 pt-12"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.6 }}
            >
              <motion.div
                className="w-16 h-16 rounded-2xl flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, #9263A6, #6B3F7F)", boxShadow: "0 8px 32px rgba(146,99,166,0.3)" }}
                animate={{ scale: [1, 1.06, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Heart size={24} color="#fff" fill="#fff" />
              </motion.div>

              <div className="flex flex-col items-center gap-3">
                <h2 style={{ fontSize: 24, fontWeight: 300, color: "#1a1a1a" }}>
                  Merci{feedback.testerName ? `, ${feedback.testerName}` : ""} !
                </h2>
                <p className="text-center" style={{ fontSize: 12, color: "#999", lineHeight: 1.7, maxWidth: 340 }}>
                  Ton avis va nous aider a construire le meilleur
                  compagnon de broderie possible.
                </p>
              </div>

              {/* Summary card */}
              <div className="w-full" style={{ ...cardStyle, padding: 20 }}>
                <span style={{ ...labelStyle, marginBottom: 12, display: "block" }}>Ton recapitulatif</span>
                <div className="flex flex-col gap-2.5">
                  <SummaryRow label="Niveau" value={feedback.stitchingLevel === "debutante" ? "Debutante" : feedback.stitchingLevel === "intermediaire" ? "Intermediaire" : "Experte"} />
                  <SummaryRow label="StitchDock" value={`${"★".repeat(feedback.dockRating || 0)}${"☆".repeat(5 - (feedback.dockRating || 0))}`} />
                  <SummaryRow label="Facilite" value={`${feedback.dockEaseOfUse || 0}/5`} />
                  <SummaryRow label="Outils preferes" value={(feedback.dockFavoriteTools || []).join(", ") || "—"} />
                  <SummaryRow label="Lily IA" value={`${"★".repeat(feedback.lilyRating || 0)}${"☆".repeat(5 - (feedback.lilyRating || 0))}`} />
                  <SummaryRow label="Voix" value={feedback.lilyVoiceOpinion === "adore" ? "J'adorerais !" : feedback.lilyVoiceOpinion === "bien" ? "Pourquoi pas" : feedback.lilyVoiceOpinion === "bof" ? "Bof" : "Non"} />
                  <SummaryRow label="Paierait ?" value={feedback.wouldPay ? `Oui — max ${feedback.maxPrice}` : "Non"} />
                </div>
              </div>

              {/* Share / App Store teaser */}
              <div className="w-full" style={{ ...cardStyle, padding: 20 }}>
                <div className="flex items-center gap-3">
                  <Smartphone size={20} color="#9263A6" strokeWidth={1.5} />
                  <div className="flex-1">
                    <div style={{ fontSize: 12, color: "#1a1a1a", fontWeight: 400 }}>
                      StitchLab arrive bientot sur iOS
                    </div>
                    <div style={{ fontSize: 9, color: "#bbb", marginTop: 2 }}>
                      Ajoute cette page a ton ecran d'accueil en attendant
                    </div>
                  </div>
                </div>
              </div>

              <motion.button
                className="w-full cursor-pointer border-none py-3 rounded-xl"
                style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#999", fontSize: 11, letterSpacing: "0.06em" }}
                onClick={onBack}
                whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              >
                Retour a StitchLab
              </motion.button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span style={{ fontSize: 10, color: "#aaa" }}>{label}</span>
      <span style={{ fontSize: 10, color: "#666", fontWeight: 400, maxWidth: 200, textAlign: "right" }}>{value}</span>
    </div>
  );
}