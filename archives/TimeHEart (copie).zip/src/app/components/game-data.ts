// ═══════════════════════════════════════════
// STITCHLAB — Where stitchers connect
// Game Data & Constants
// ═══════════════════════════════════════════

// DMC Thread Colors — Curated palette
export interface DMCColor {
  code: string;
  name: string;
  hex: string;
  rare?: boolean;
}

export const DMC_COLORS: DMCColor[] = [
  { code: "Blanc", name: "Blanc", hex: "#FFFFFF" },
  { code: "310", name: "Noir", hex: "#000000" },
  { code: "321", name: "Rouge Noël", hex: "#C72B3B" },
  { code: "666", name: "Rouge Vif", hex: "#E3243B" },
  { code: "498", name: "Rouge Foncé", hex: "#8B1A2B" },
  { code: "815", name: "Grenat", hex: "#7B2033" },
  { code: "304", name: "Rouge Moyen", hex: "#B52B3B" },
  { code: "444", name: "Citron Foncé", hex: "#F2C200" },
  { code: "307", name: "Citron", hex: "#FDD831" },
  { code: "972", name: "Canari", hex: "#FFB515" },
  { code: "741", name: "Mandarine", hex: "#FFA230" },
  { code: "947", name: "Orange Brûlé", hex: "#FF6533" },
  { code: "946", name: "Orange Moyen", hex: "#EB5B2E" },
  { code: "700", name: "Vert Noël", hex: "#007B43" },
  { code: "699", name: "Vert Foncé", hex: "#005B31" },
  { code: "702", name: "Vert Kelly", hex: "#42A350" },
  { code: "704", name: "Vert Chartreuse", hex: "#84C44E" },
  { code: "906", name: "Vert Perroquet", hex: "#6DB54A" },
  { code: "796", name: "Bleu Royal", hex: "#0F3F8C" },
  { code: "797", name: "Bleu Royal Clair", hex: "#1D5DA5" },
  { code: "798", name: "Bleu Delft", hex: "#4685B7" },
  { code: "3846", name: "Turquoise Vif", hex: "#00B5C4" },
  { code: "807", name: "Bleu Paon", hex: "#6BA7B0" },
  { code: "553", name: "Violet", hex: "#9263A6" },
  { code: "550", name: "Violet Foncé", hex: "#5B1D6E" },
  { code: "554", name: "Violet Clair", hex: "#B48DC4" },
  { code: "3607", name: "Prune Claire", hex: "#C44B7A" },
  { code: "3608", name: "Rose Prune", hex: "#E87DA5" },
  { code: "3609", name: "Rose Pâle", hex: "#F5A3C0" },
  { code: "3713", name: "Rose Saumon", hex: "#F7C8C8" },
  { code: "3326", name: "Rose Tendre", hex: "#F5A0A5" },
  { code: "844", name: "Gris Castor", hex: "#5A5A5A" },
  { code: "414", name: "Gris Acier", hex: "#8C8C8C" },
  { code: "762", name: "Gris Perle", hex: "#D8D8D8" },
  { code: "738", name: "Beige", hex: "#D6BD9A" },
  { code: "436", name: "Brun Doré", hex: "#A67D4B" },
  { code: "801", name: "Brun Café", hex: "#5B3919" },
  { code: "838", name: "Brun Très Foncé", hex: "#3A2010" },
  // Rare colors — discovered by exploration
  { code: "E168", name: "Or Clair", hex: "#E8D06A", rare: true },
  { code: "E3852", name: "Argent", hex: "#C0C0C0", rare: true },
  { code: "E316", name: "Or Antique", hex: "#C9A84C", rare: true },
  { code: "E825", name: "Cuivre", hex: "#B87333", rare: true },
  { code: "E5200", name: "Blanc Nacré", hex: "#F0EAD6", rare: true },
];

// ─── SHAPES / SYMBOLS ───
// Primary geometric forms
export const PRIMARY_SHAPES = [
  { char: "■", name: "Carré" },
  { char: "▲", name: "Triangle" },
  { char: "●", name: "Cercle" },
  { char: "✳", name: "Étoile" },
  { char: "◆", name: "Losange" },
  { char: "✚", name: "Croix" },
  { char: "∞", name: "Fil" },
];

// Extended artistic symbols
export const EXTENDED_SYMBOLS = [
  "✦", "✧", "◇", "○", "□", "△", "▼", "▽",
  "★", "☆", "♦", "♢", "✿", "❀", "❃", "✻",
  "✴", "❋", "❊", "♡", "♥", "⬡", "⬢", "◉",
  "◎", "✕", "✖",
];

// All available symbols (flat list for convenience)
export const ALL_SYMBOLS = [
  ...PRIMARY_SHAPES.map((s) => s.char),
  ...EXTENDED_SYMBOLS,
];

// Legacy compat
export const SYMBOLS = ALL_SYMBOLS;

// Special symbols unlocked as bonus
export const SPECIAL_SYMBOLS = [
  "🌱", "✨", "🌸", "🦋", "🌿", "🌊", "🔮", "🍀",
];

export type AccessibilityMode = "default" | "child" | "senior" | "accessibility";

export interface PlayerData {
  id: string;
  pseudo: string;
  city: string;
  intention: string;
  colorHex: string;
  colorCode: string;
  symbol: string;
  symbol2?: string; // superposition: optional second symbol
  symbolSize: number;
  symbolRotation: number;
  symbolContrast: number;
  x: number;
  y: number;
}

export interface BonusSquare {
  x: number;
  y: number;
  type: "rare_color" | "special_symbol" | "seed" | "glow";
  value: string;
  colorHex?: string;
}

// ─── HEARTBEAT / SORTIE SYSTEM ───
export type HeartbeatWhen = "maintenant" | "aujourdhui" | "weekend" | string;
export type HeartbeatWhere = "ici" | "autour" | string;
export type HeartbeatIntention = "marcher" | "écouter" | "créer" | "partager" | "célébrer" | "silence";
export type HeartbeatOpenness = "seul" | "quelques" | "ouvert";

export interface Heartbeat {
  id: string;
  creatorId: string;
  creatorPseudo: string;
  creatorColor: string;
  creatorSymbol: string;
  x: number;
  y: number;
  when: HeartbeatWhen;
  where: HeartbeatWhere;
  whereName?: string; // symbolic place name
  intention: HeartbeatIntention;
  openness: HeartbeatOpenness;
  createdAt: number;
}

export const HEARTBEAT_INTENTIONS: { key: HeartbeatIntention; label: string; emoji: string }[] = [
  { key: "marcher", label: "Marcher", emoji: "🚶" },
  { key: "écouter", label: "Écouter", emoji: "👂" },
  { key: "créer", label: "Créer", emoji: "🎨" },
  { key: "partager", label: "Partager", emoji: "🤲" },
  { key: "célébrer", label: "Célébrer", emoji: "✨" },
  { key: "silence", label: "Silence", emoji: "🤫" },
];

export const HEARTBEAT_OPENNESS: { key: HeartbeatOpenness; label: string }[] = [
  { key: "seul", label: "Seul·e" },
  { key: "quelques", label: "Quelques-uns" },
  { key: "ouvert", label: "Ouvert" },
];

export const HEARTBEAT_WHEN_OPTIONS: { key: HeartbeatWhen; label: string }[] = [
  { key: "maintenant", label: "Maintenant" },
  { key: "aujourdhui", label: "Aujourd'hui" },
  { key: "weekend", label: "Ce week-end" },
];

export const HEARTBEAT_WHERE_OPTIONS: { key: HeartbeatWhere; label: string }[] = [
  { key: "ici", label: "Ici" },
  { key: "autour", label: "Autour de moi" },
];

export const SYMBOLIC_PLACES = [
  "Un parc", "Un café", "Une rivière", "Une forêt",
  "Un toit", "Une place", "Un jardin", "Un pont",
];

// ─── SORTIE / EVENT SYSTEM ───
export type SortieCategory = "marche" | "atelier" | "meditation" | "celebration" | "ecoute" | "decouverte";
export type SortieDuration = "1h" | "2h" | "demi-journee" | "journee";
export type SortieStatus = "upcoming" | "happening" | "past";

export interface SortieEvent {
  id: string;
  creatorId: string;
  creatorPseudo: string;
  creatorColor: string;
  creatorSymbol: string;
  x: number;
  y: number;

  title: string;
  description?: string;
  date: string; // ISO date
  time?: string; // HH:MM
  duration: SortieDuration;

  category: SortieCategory;
  placeName?: string;
  openness: HeartbeatOpenness;
  maxParticipants?: number;
  participants: { id: string; pseudo: string; color: string; symbol: string }[];

  createdAt: number;
}

export const SORTIE_CATEGORIES: { key: SortieCategory; label: string }[] = [
  { key: "marche", label: "Marche" },
  { key: "atelier", label: "Atelier" },
  { key: "meditation", label: "Méditation" },
  { key: "celebration", label: "Clébration" },
  { key: "ecoute", label: "Écoute" },
  { key: "decouverte", label: "Découverte" },
];

export const SORTIE_DURATIONS: { key: SortieDuration; label: string }[] = [
  { key: "1h", label: "1 heure" },
  { key: "2h", label: "2 heures" },
  { key: "demi-journee", label: "Demi-journée" },
  { key: "journee", label: "Journée" },
];

export const SORTIE_COLOR = "#D4A060"; // warm amber for events

// Mock sorties scattered on grid
export const MOCK_SORTIES: SortieEvent[] = [
  {
    id: "s1", creatorId: "p1", creatorPseudo: "Luna", creatorColor: "#C72B3B", creatorSymbol: "✦",
    x: 3, y: -2, title: "Marche silencieuse", description: "Observer les arbres sans parler",
    date: "2026-02-08", time: "10:00", duration: "2h", category: "marche",
    placeName: "Un parc", openness: "ouvert", maxParticipants: 8,
    participants: [{ id: "p4", pseudo: "Soleil", color: "#F2C200", symbol: "★" }],
    createdAt: Date.now() - 3600000,
  },
  {
    id: "s2", creatorId: "p3", creatorPseudo: "Iris", creatorColor: "#9263A6", creatorSymbol: "✿",
    x: -3, y: -1, title: "Atelier broderie", description: "Broder ensemble, chacun son motif",
    date: "2026-02-09", time: "14:00", duration: "demi-journee", category: "atelier",
    placeName: "Un café", openness: "quelques", maxParticipants: 5,
    participants: [],
    createdAt: Date.now() - 7200000,
  },
  {
    id: "s3", creatorId: "p8", creatorPseudo: "Aiko", creatorColor: "#FF6533", creatorSymbol: "▲",
    x: -4, y: 3, title: "Méditation du matin", description: "15 minutes de silence partagé",
    date: "2026-02-07", time: "07:30", duration: "1h", category: "meditation",
    openness: "ouvert",
    participants: [
      { id: "p5", pseudo: "Miko", color: "#E87DA5", symbol: "♡" },
      { id: "p12", pseudo: "Yuki", color: "#F5A3C0", symbol: "☆" },
    ],
    createdAt: Date.now() - 14400000,
  },
  {
    id: "s4", creatorId: "p13", creatorPseudo: "Nara", creatorColor: "#42A350", creatorSymbol: "∞",
    x: 6, y: 2, title: "Écoute de la rivière",
    date: "2026-02-10", time: "16:00", duration: "1h", category: "ecoute",
    placeName: "Une rivière", openness: "ouvert",
    participants: [],
    createdAt: Date.now() - 21600000,
  },
];

// Mock heartbeats scattered on the grid
export const MOCK_HEARTBEATS: Heartbeat[] = [
  { id: "hb1", creatorId: "p1", creatorPseudo: "Luna", creatorColor: "#C72B3B", creatorSymbol: "✦", x: 2, y: -1, when: "aujourdhui", where: "ici", intention: "marcher", openness: "ouvert", createdAt: Date.now() - 3600000 },
  { id: "hb2", creatorId: "p4", creatorPseudo: "Soleil", creatorColor: "#F2C200", creatorSymbol: "★", x: -1, y: -2, when: "weekend", where: "autour", whereName: "Un parc", intention: "partager", openness: "quelques", createdAt: Date.now() - 7200000 },
  { id: "hb3", creatorId: "p8", creatorPseudo: "Aiko", creatorColor: "#FF6533", creatorSymbol: "▲", x: -5, y: 5, when: "maintenant", where: "ici", intention: "silence", openness: "seul", createdAt: Date.now() - 900000 },
  { id: "hb4", creatorId: "p12", creatorPseudo: "Yuki", creatorColor: "#F5A3C0", creatorSymbol: "☆", x: -6, y: 3, when: "aujourdhui", where: "Un café", intention: "écouter", openness: "ouvert", createdAt: Date.now() - 5400000 },
  { id: "hb5", creatorId: "p3", creatorPseudo: "Iris", creatorColor: "#9263A6", creatorSymbol: "✿", x: 1, y: 3, when: "weekend", where: "Un jardin", intention: "créer", openness: "quelques", createdAt: Date.now() - 10800000 },
];

// Points system — gentle gamification
export interface PointEvent {
  type: "move" | "discover" | "stillness" | "encounter" | "heartbeat";
  points: number;
  timestamp: number;
}

export const POINT_VALUES = {
  move: 1,
  discover: 2,
  stillness: 3,
  encounter: 2,
  heartbeat: 5,
} as const;

export const STILLNESS_THRESHOLD = 5000;

// ─── WORLD CITIES ───
// Cities scattered across the infinite grid as ambient labels
export interface WorldCity {
  x: number;
  y: number;
  name: string;
  size: "sm" | "md" | "lg";
}

export const WORLD_CITIES: WorldCity[] = [
  // Core cluster
  { x: 0, y: 0, name: "Le Cœur", size: "lg" },
  { x: 6, y: -3, name: "Paris", size: "lg" },
  { x: -8, y: 2, name: "Tokyo", size: "lg" },
  { x: 12, y: 5, name: "New York", size: "lg" },
  { x: -14, y: -6, name: "São Paulo", size: "md" },
  { x: 10, y: -10, name: "London", size: "lg" },
  { x: -5, y: 10, name: "Dakar", size: "md" },
  { x: 15, y: -2, name: "Montréal", size: "md" },
  { x: -12, y: -12, name: "Sydney", size: "md" },
  { x: 20, y: 8, name: "Berlin", size: "md" },
  { x: -18, y: 7, name: "Séoul", size: "md" },
  { x: 8, y: 14, name: "Mumbai", size: "md" },
  { x: -10, y: -18, name: "Buenos Aires", size: "md" },
  { x: 22, y: -8, name: "Amsterdam", size: "sm" },
  { x: -20, y: 14, name: "Lagos", size: "md" },
  { x: 16, y: 16, name: "Istanbul", size: "md" },
  { x: -16, y: -16, name: "Melbourne", size: "sm" },
  { x: 25, y: 0, name: "Lisbonne", size: "sm" },
  { x: -25, y: 0, name: "Kyoto", size: "sm" },
  { x: 0, y: 20, name: "Nairobi", size: "sm" },
  { x: 0, y: -20, name: "Reykjavik", size: "sm" },
  { x: 18, y: -15, name: "Oslo", size: "sm" },
  { x: -22, y: -10, name: "Auckland", size: "sm" },
  { x: 14, y: 22, name: "Marrakech", size: "sm" },
  { x: -14, y: 20, name: "Bangkok", size: "sm" },
  { x: 28, y: 12, name: "Zurich", size: "sm" },
  { x: -28, y: 6, name: "Osaka", size: "sm" },
  { x: 30, y: -5, name: "Dublin", size: "sm" },
  { x: -30, y: -5, name: "Wellington", size: "sm" },
  { x: 10, y: -25, name: "Stockholm", size: "sm" },
  { x: -10, y: 25, name: "Casablanca", size: "sm" },
  { x: 35, y: 3, name: "Lyon", size: "sm" },
  { x: -35, y: -3, name: "Hanoi", size: "sm" },
  { x: 5, y: 30, name: "Addis-Abeba", size: "sm" },
  { x: -5, y: -30, name: "Santiago", size: "sm" },
];

// ─── RADIAL MENU CONFIG ───
export type RadialAction = "battement" | "sortie" | "medias" | "agent" | "profil" | "agenda" | "messages" | "explorer";

export interface RadialMenuItem {
  key: RadialAction;
  label: string;
  position: number; // 0=N, 1=NE, 2=E, 3=SE, 4=S, 5=SW, 6=W, 7=NW
}

export const DEFAULT_RADIAL_ITEMS: RadialMenuItem[] = [
  { key: "battement", label: "Battement", position: 0 },
  { key: "sortie", label: "Sortie", position: 1 },
  { key: "medias", label: "Médias", position: 2 },
  { key: "agent", label: "Lily", position: 3 },
  { key: "profil", label: "Profil", position: 4 },
  { key: "agenda", label: "Agenda", position: 5 },
  { key: "messages", label: "Messages", position: 6 },
  { key: "explorer", label: "Explorer", position: 7 },
];

// ─── LILY — Player interest profiles for matching ───
export type InterestTag =
  | "nature" | "art" | "musique" | "meditation" | "social"
  | "mouvement" | "cuisine" | "lecture" | "voyage" | "photographie"
  | "ecriture" | "silence" | "broderie" | "jardinage" | "creation"
  | "contemplation" | "partage" | "tradition" | "mystere" | "lumiere";

export interface PlayerInterestProfile {
  playerId: string;
  interests: InterestTag[];
  lilyNote: string; // What Lily says about this person (poetic, no name leak)
}

export const PLAYER_INTERESTS: PlayerInterestProfile[] = [
  { playerId: "p1", interests: ["lumiere", "photographie", "art"], lilyNote: "Quelqu'un qui cherche la lumière dans chaque recoin. Vous pourriez éclairer le même chemin." },
  { playerId: "p2", interests: ["contemplation", "meditation", "voyage"], lilyNote: "Un regard posé sur le monde, qui observe sans juger. Un miroir calme." },
  { playerId: "p3", interests: ["art", "broderie", "creation"], lilyNote: "Des mains qui créent, point par point. Votre art pourrait se croiser." },
  { playerId: "p4", interests: ["social", "partage", "musique"], lilyNote: "Un fil doré qui relie les gens. Quelqu'un qui tisse des liens avec joie." },
  { playerId: "p5", interests: ["silence", "contemplation", "art"], lilyNote: "Un cœur discret mais attentif. La beauté dans la simplicité." },
  { playerId: "p6", interests: ["nature", "jardinage", "mouvement"], lilyNote: "Quelqu'un qui grandit avec les plantes, pas à pas, racine après racine." },
  { playerId: "p7", interests: ["lecture", "ecriture", "contemplation"], lilyNote: "Un esprit curieux, toujours entre deux pages. Les mots sont son refuge." },
  { playerId: "p8", interests: ["meditation", "silence", "lumiere"], lilyNote: "Une présence pure, ancrée dans l'instant. Juste être, rien de plus." },
  { playerId: "p9", interests: ["voyage", "cuisine", "tradition"], lilyNote: "Un voyageur des saveurs et des routes. Chaque lieu a une histoire à goûter." },
  { playerId: "p10", interests: ["nature", "contemplation", "silence"], lilyNote: "Comme un arbre qui écoute le vent. La nature est son langage." },
  { playerId: "p11", interests: ["musique", "ecriture", "mystere"], lilyNote: "Des mélodies cachées et des mots secrets. Un univers intérieur riche." },
  { playerId: "p12", interests: ["art", "photographie", "lumiere"], lilyNote: "Un regard qui capture l'éphémère. La beauté fragile des instants." },
  { playerId: "p13", interests: ["nature", "mouvement", "meditation"], lilyNote: "Le souffle comme boussole. Quelqu'un qui avance en respirant." },
  { playerId: "p14", interests: ["voyage", "lecture", "contemplation"], lilyNote: "Un cartographe de l'invisible. Les cartes sont ses poèmes." },
  { playerId: "p15", interests: ["broderie", "art", "tradition"], lilyNote: "Les fils se croisent dans ses mains comme des histoires anciennes." },
  { playerId: "p16", interests: ["silence", "contemplation", "nature"], lilyNote: "Le froid et le silence comme compagnons. Une sérénité nordique." },
  { playerId: "p17", interests: ["nature", "jardinage", "meditation"], lilyNote: "Ralentir est un art. Cette personne le maîtrise avec grâce." },
  { playerId: "p18", interests: ["ecriture", "mystere", "silence"], lilyNote: "Des symboles gravés dans le silence. Un langage que peu comprennent." },
];

// Interest detection keywords (user input → interest tag)
export const INTEREST_KEYWORDS: Record<InterestTag, string[]> = {
  nature: ["nature", "arbre", "forêt", "foret", "plante", "fleur", "montagne", "mer", "ocean", "rivière", "riviere", "dehors", "plein air", "vert", "terre", "animal"],
  art: ["art", "dessin", "dessiner", "peindre", "peinture", "sculpture", "beauté", "beaute", "esthétique", "esthetique", "artistique", "couleur", "créatif", "creatif", "galerie", "musée", "musee"],
  musique: ["musique", "chanson", "chanter", "instrument", "guitare", "piano", "mélodie", "melodie", "son", "écouter", "ecouter", "concert", "rythme", "jazz", "classique"],
  meditation: ["méditation", "meditation", "méditer", "mediter", "yoga", "zen", "respiration", "respirer", "calme", "paix", "intérieur", "interieur", "pleine conscience", "mindful"],
  social: ["ami", "amis", "rencontre", "rencontrer", "gens", "humain", "partage", "partager", "ensemble", "communauté", "communaute", "lien", "lien social", "collectif"],
  mouvement: ["marche", "marcher", "courir", "course", "sport", "bouger", "mouvement", "danse", "danser", "randonnée", "randonnee", "vélo", "velo", "nager"],
  cuisine: ["cuisine", "cuisiner", "manger", "nourriture", "recette", "goût", "gout", "saveur", "café", "cafe", "thé", "the", "pain", "repas", "gastronomie"],
  lecture: ["livre", "lire", "lecture", "roman", "histoire", "page", "bibliothèque", "bibliotheque", "poésie", "poesie", "conte"],
  voyage: ["voyage", "voyager", "découvrir", "decouvrir", "explorer", "ailleurs", "pays", "culture", "monde", "aventure", "destination", "route"],
  photographie: ["photo", "photographie", "photographier", "image", "cliché", "cliche", "objectif", "lumière", "lumiere", "cadre", "portrait", "paysage"],
  ecriture: ["écrire", "ecrire", "écriture", "ecriture", "texte", "mot", "phrase", "journal", "carnet", "poème", "poeme", "stylo", "plume"],
  silence: ["silence", "silencieux", "calme", "tranquille", "paix", "solitude", "seul", "introverti", "discret", "recueillement", "immobile"],
  broderie: ["broderie", "broder", "fil", "aiguille", "couture", "coudre", "tissu", "textile", "tricot", "tricoter", "crochet", "point de croix"],
  jardinage: ["jardin", "jardiner", "jardinage", "planter", "graine", "semence", "récolte", "recolte", "potager", "terrasse", "balcon"],
  creation: ["créer", "creer", "création", "creation", "fabriquer", "construire", "inventer", "imaginer", "projet", "faire", "bricoler", "atelier"],
  contemplation: ["contempler", "contemplation", "observer", "regarder", "admirer", "méditer", "rêver", "rever", "penser", "réfléchir", "reflechir"],
  partage: ["partager", "partage", "donner", "offrir", "générosité", "generosite", "aider", "soutenir", "ensemble", "commun"],
  tradition: ["tradition", "ancien", "ancestral", "héritage", "heritage", "coutume", "rituel", "racine", "origine", "artisanat"],
  mystere: ["mystère", "mystere", "secret", "inconnu", "caché", "cache", "enigme", "symbole", "cryptique", "sombre", "nuit", "rêve"],
  lumiere: ["lumière", "lumiere", "aube", "aurore", "soleil", "clarté", "clarte", "étoile", "etoile", "lueur", "briller", "rayonner", "doré", "dore"],
};

// Collective pattern zones
export interface PatternZone {
  cx: number;
  cy: number;
  radius: number;
  name: string;
  pattern: string;
}

export const PATTERN_ZONES: PatternZone[] = [
  { cx: 0, cy: 0, radius: 3, name: "Le Cœur", pattern: "♡" },
  { cx: 8, cy: 8, radius: 2, name: "L'Étoile", pattern: "★" },
  { cx: -8, cy: -8, radius: 2, name: "La Fleur", pattern: "✿" },
  { cx: 10, cy: -6, radius: 2, name: "Le Soleil", pattern: "◉" },
  { cx: -6, cy: 10, radius: 2, name: "La Graine", pattern: "◆" },
];

// Mock players
export const MOCK_PLAYERS: PlayerData[] = [
  { id: "p1", pseudo: "Luna", city: "Paris", intention: "Chercher la lumière", colorHex: "#C72B3B", colorCode: "321", symbol: "✦", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: 2, y: -1 },
  { id: "p2", pseudo: "Kael", city: "Tokyo", intention: "Observer le monde", colorHex: "#0F3F8C", colorCode: "796", symbol: "◆", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: -3, y: 2 },
  { id: "p3", pseudo: "Iris", city: "Montréal", intention: "", colorHex: "#9263A6", colorCode: "553", symbol: "✿", symbolSize: 60, symbolRotation: 45, symbolContrast: 100, x: 1, y: 3 },
  { id: "p4", pseudo: "Soleil", city: "Dakar", intention: "Tisser des liens", colorHex: "#F2C200", colorCode: "444", symbol: "★", symbolSize: 55, symbolRotation: 0, symbolContrast: 100, x: -1, y: -2 },
  { id: "p5", pseudo: "Miko", city: "Osaka", intention: "", colorHex: "#E87DA5", colorCode: "3608", symbol: "♡", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: 4, y: 1 },
  { id: "p6", pseudo: "Fern", city: "Wellington", intention: "Grandir doucement", colorHex: "#007B43", colorCode: "700", symbol: "✚", symbolSize: 45, symbolRotation: 30, symbolContrast: 100, x: -2, y: -4 },
  { id: "p7", pseudo: "Ciel", city: "Lyon", intention: "", colorHex: "#4685B7", colorCode: "798", symbol: "●", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: 5, y: -3 },
  { id: "p8", pseudo: "Aiko", city: "Séoul", intention: "Être là", colorHex: "#FF6533", colorCode: "947", symbol: "▲", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: -5, y: 5 },
  { id: "p9", pseudo: "Noor", city: "Casablanca", intention: "", colorHex: "#D6BD9A", colorCode: "738", symbol: "✴", symbolSize: 55, symbolRotation: 15, symbolContrast: 100, x: 3, y: -5 },
  { id: "p10", pseudo: "Elm", city: "Stockholm", intention: "Contempler", colorHex: "#6DB54A", colorCode: "906", symbol: "❀", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: -4, y: -1 },
  { id: "p11", pseudo: "Wren", city: "Dublin", intention: "", colorHex: "#5B1D6E", colorCode: "550", symbol: "■", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: 6, y: 4 },
  { id: "p12", pseudo: "Yuki", city: "Kyoto", intention: "Exister", colorHex: "#F5A3C0", colorCode: "3609", symbol: "☆", symbolSize: 60, symbolRotation: 0, symbolContrast: 100, x: -6, y: 3 },
  { id: "p13", pseudo: "Nara", city: "Nairobi", intention: "Respirer", colorHex: "#42A350", colorCode: "702", symbol: "∞", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: 7, y: -1 },
  { id: "p14", pseudo: "Atlas", city: "Lisbonne", intention: "", colorHex: "#FFB515", colorCode: "972", symbol: "■", symbolSize: 50, symbolRotation: 0, symbolContrast: 100, x: -7, y: -3 },
  { id: "p15", pseudo: "Zara", city: "Marrakech", intention: "Tisser", colorHex: "#EB5B2E", colorCode: "946", symbol: "◇", symbolSize: 48, symbolRotation: 0, symbolContrast: 100, x: 0, y: -6 },
  { id: "p16", pseudo: "Opal", city: "Reykjavik", intention: "", colorHex: "#6BA7B0", colorCode: "807", symbol: "△", symbolSize: 52, symbolRotation: 0, symbolContrast: 100, x: -8, y: 0 },
  { id: "p17", pseudo: "Sage", city: "Zurich", intention: "Ralentir", colorHex: "#84C44E", colorCode: "704", symbol: "✳", symbolSize: 50, symbolRotation: 20, symbolContrast: 100, x: 8, y: 7 },
  { id: "p18", pseudo: "Rune", city: "Oslo", intention: "", colorHex: "#1D5DA5", colorCode: "797", symbol: "✕", symbolSize: 45, symbolRotation: 0, symbolContrast: 100, x: -9, y: -7 },
];

export const BONUS_SQUARES: BonusSquare[] = [
  { x: 3, y: 3, type: "rare_color", value: "E168", colorHex: "#E8D06A" },
  { x: -4, y: 2, type: "special_symbol", value: "🌱" },
  { x: 2, y: -3, type: "glow", value: "✨" },
  { x: -2, y: 4, type: "seed", value: "🌿" },
  { x: 5, y: -2, type: "rare_color", value: "E3852", colorHex: "#C0C0C0" },
  { x: -3, y: -3, type: "special_symbol", value: "🦋" },
  { x: 7, y: 0, type: "glow", value: "✨" },
  { x: 0, y: 6, type: "seed", value: "🍀" },
  { x: -5, y: -5, type: "rare_color", value: "E316", colorHex: "#C9A84C" },
  { x: 4, y: -4, type: "special_symbol", value: "🌸" },
  { x: 9, y: 2, type: "glow", value: "✨" },
  { x: -7, y: 6, type: "seed", value: "🌱" },
  { x: 6, y: -6, type: "rare_color", value: "E825", colorHex: "#B87333" },
  { x: -1, y: 8, type: "special_symbol", value: "🌊" },
  { x: 10, y: -5, type: "glow", value: "🔮" },
  // Extended bonus field — spread out far to reward exploration
  { x: -9, y: -9, type: "glow", value: "✨" },
  { x: 12, y: 3, type: "seed", value: "🌿" },
  { x: -13, y: 5, type: "rare_color", value: "E168", colorHex: "#E8D06A" },
  { x: 8, y: -8, type: "special_symbol", value: "🌸" },
  { x: -6, y: -12, type: "glow", value: "🔮" },
  { x: 14, y: -3, type: "seed", value: "🍀" },
  { x: -15, y: -2, type: "special_symbol", value: "🦋" },
  { x: 11, y: 10, type: "rare_color", value: "E3852", colorHex: "#C0C0C0" },
  { x: -11, y: 8, type: "glow", value: "✨" },
  { x: 16, y: -8, type: "seed", value: "🌱" },
  { x: -17, y: 3, type: "special_symbol", value: "🌊" },
  { x: 18, y: 6, type: "rare_color", value: "E316", colorHex: "#C9A84C" },
  { x: -19, y: -7, type: "glow", value: "✨" },
  { x: 20, y: 0, type: "seed", value: "🌿" },
  { x: -21, y: 12, type: "rare_color", value: "E825", colorHex: "#B87333" },
  { x: 22, y: -12, type: "special_symbol", value: "🌸" },
  { x: -23, y: -4, type: "glow", value: "🔮" },
  { x: 25, y: 5, type: "seed", value: "🍀" },
  { x: -26, y: 0, type: "rare_color", value: "E168", colorHex: "#E8D06A" },
  { x: 28, y: -10, type: "glow", value: "✨" },
  { x: -29, y: 8, type: "special_symbol", value: "🦋" },
  { x: 30, y: 2, type: "seed", value: "🌱" },
  { x: -32, y: -6, type: "rare_color", value: "E5200", colorHex: "#F0EAD6" },
  { x: 0, y: 15, type: "glow", value: "✨" },
  { x: 0, y: -15, type: "seed", value: "🌿" },
  { x: -8, y: 18, type: "special_symbol", value: "🌊" },
  { x: 8, y: -18, type: "rare_color", value: "E3852", colorHex: "#C0C0C0" },
  { x: 13, y: 14, type: "glow", value: "🔮" },
  { x: -13, y: -14, type: "seed", value: "🍀" },
  { x: 5, y: -25, type: "glow", value: "✨" },
  { x: -5, y: 25, type: "rare_color", value: "E825", colorHex: "#B87333" },
];

// Background colors
export const BG_IVORY = "#FAF8F5";
export const BG_WARM = "#F7F5F0";
export const HEART_RED = "#E3243B";