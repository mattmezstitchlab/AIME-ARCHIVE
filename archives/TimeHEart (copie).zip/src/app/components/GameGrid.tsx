import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CalendarHeart } from "lucide-react";
import { PlayerSquare } from "./PlayerSquare";
import { ArrowControls } from "./ArrowControls";
import { PlayerInfoCard } from "./PlayerInfoCard";
import { SortieInfoCard } from "./SortieInfoCard";
import { ProfilePanel } from "./ProfilePanel";
import { PointsHUD } from "./PointsHUD";
import { HeartbeatCreator } from "./HeartbeatCreator";
import { SortieCreator } from "./SortieCreator";
import { RadialMenu } from "./RadialMenu";
import { AIAgent } from "./AIAgent";
import { MessagingPanel, AgendaPanel, MediaPanel } from "./ActionPanels";
import { LilyNotification } from "./LilyNotification";
import { StitchLabBadge } from "./StitchLabLogo";
import { ZoomControls, ZOOM_LEVELS } from "./ZoomControls";
import { Minimap } from "./Minimap";
import { useResponsive } from "./useResponsive";
import * as api from "./api";
import {
  MOCK_PLAYERS,
  BONUS_SQUARES,
  MOCK_HEARTBEATS,
  MOCK_SORTIES,
  PATTERN_ZONES,
  WORLD_CITIES,
  POINT_VALUES,
  STILLNESS_THRESHOLD,
  BG_IVORY,
  HEART_RED,
  SORTIE_COLOR,
  type PlayerData,
  type BonusSquare,
  type Heartbeat,
  type SortieEvent,
  type AccessibilityMode,
  type RadialAction,
  type InterestTag,
} from "./game-data";

interface GameGridProps {
  currentPlayer: PlayerData;
  mode: AccessibilityMode;
  onModeChange: (mode: AccessibilityMode) => void;
}

interface PointNotif {
  type: string;
  points: number;
  id: number;
}

export function GameGrid({ currentPlayer, mode, onModeChange }: GameGridProps) {
  const { isMobile, isTablet } = useResponsive();
  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0 });
  const [selectedPlayer, setSelectedPlayer] = useState<PlayerData | null>(null);
  const [selectedBonus, setSelectedBonus] = useState<BonusSquare | null>(null);
  const [selectedHeartbeat, setSelectedHeartbeat] = useState<Heartbeat | null>(null);
  const [selectedSortie, setSelectedSortie] = useState<SortieEvent | null>(null);
  const [showInfo, setShowInfo] = useState(false);
  const [showSortieInfo, setShowSortieInfo] = useState(false);

  // Heartbeats & Sorties
  const [heartbeats, setHeartbeats] = useState<Heartbeat[]>(MOCK_HEARTBEATS);
  const [sorties, setSorties] = useState<SortieEvent[]>(MOCK_SORTIES);
  const [showHeartbeatCreator, setShowHeartbeatCreator] = useState(false);
  const [showSortieCreator, setShowSortieCreator] = useState(false);

  // Trail
  const [trail, setTrail] = useState<{ x: number; y: number }[]>([{ x: 0, y: 0 }]);

  // Points
  const [points, setPoints] = useState(0);
  const [steps, setSteps] = useState(0);
  const [discoveries, setDiscoveries] = useState(0);
  const [lastEvent, setLastEvent] = useState<PointNotif | null>(null);
  const eventIdRef = useRef(0);
  const [discoveredBonuses, setDiscoveredBonuses] = useState<Set<string>>(new Set());

  // Stillness
  const stillnessTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [isStill, setIsStill] = useState(false);

  const [showHint, setShowHint] = useState(true);

  // Panels
  const [radialOpen, setRadialOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [agentOpen, setAgentOpen] = useState(false);
  const [messagesOpen, setMessagesOpen] = useState(false);
  const [agendaOpen, setAgendaOpen] = useState(false);
  const [mediaOpen, setMediaOpen] = useState(false);

  // ─── LILY STATE (shared between AIAgent & LilyNotification) ───
  const [lilyInterests, setLilyInterests] = useState<Set<InterestTag>>(new Set());
  const [lilySuggested, setLilySuggested] = useState<Set<string>>(new Set());

  // ─── ZOOM ───
  const [zoom, setZoom] = useState(1);

  const handleZoomIn = useCallback(() => {
    setZoom((prev) => {
      const idx = ZOOM_LEVELS.findIndex((z) => z >= prev);
      const nextIdx = Math.min(idx + 1, ZOOM_LEVELS.length - 1);
      return ZOOM_LEVELS[nextIdx];
    });
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoom((prev) => {
      const idx = ZOOM_LEVELS.findIndex((z) => z >= prev);
      const nextIdx = Math.max(idx - 1, 0);
      return ZOOM_LEVELS[nextIdx];
    });
  }, []);

  const handleZoomReset = useCallback(() => setZoom(1), []);

  const isSenior = mode === "senior";
  const baseCellSize = isMobile
    ? (isSenior ? 48 : 38)
    : isTablet
      ? (isSenior ? 56 : 44)
      : (isSenior ? 64 : 50);
  const cellSize = Math.round(baseCellSize * zoom);
  const gap = Math.round(2 * zoom);
  const totalCell = cellSize + gap;

  const [viewportSize, setViewportSize] = useState({ w: window.innerWidth, h: window.innerHeight });

  useEffect(() => {
    const handleResize = () => setViewportSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const visibleCols = Math.ceil(viewportSize.w / totalCell) + 4;
  const visibleRows = Math.ceil(viewportSize.h / totalCell) + 4;

  // ─── SUPABASE SYNC ───
  useEffect(() => {
    api.registerPlayer(currentPlayer).catch((e) => console.log("Failed to register player:", e));
  }, [currentPlayer]);

  const syncTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const syncPosition = useCallback((pos: { x: number; y: number }) => {
    if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    syncTimeoutRef.current = setTimeout(() => {
      api.updatePosition(currentPlayer.id, pos.x, pos.y).catch((e) => console.log("Position sync error:", e));
    }, 500);
  }, [currentPlayer.id]);

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const [hbRes, sortieRes] = await Promise.all([api.getHeartbeats(), api.getSorties()]);
        if (hbRes.heartbeats.length > 0) {
          setHeartbeats((prev) => {
            const merged = new Map<string, Heartbeat>();
            prev.forEach((h) => merged.set(h.id, h));
            hbRes.heartbeats.forEach((h: Heartbeat) => merged.set(h.id, h));
            return Array.from(merged.values());
          });
        }
        if (sortieRes.sorties.length > 0) {
          setSorties((prev) => {
            const merged = new Map<string, SortieEvent>();
            prev.forEach((s) => merged.set(s.id, s));
            sortieRes.sorties.forEach((s: SortieEvent) => merged.set(s.id, s));
            return Array.from(merged.values());
          });
        }
      } catch (_) { /* offline */ }
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  // Points
  const addPoints = useCallback((type: string, pts: number) => {
    setPoints((p) => p + pts);
    eventIdRef.current += 1;
    setLastEvent({ type, points: pts, id: eventIdRef.current });
    const id = eventIdRef.current;
    setTimeout(() => { setLastEvent((prev) => (prev && prev.id === id ? null : prev)); }, 1500);
  }, []);

  // Stillness
  const resetStillnessTimer = useCallback(() => {
    setIsStill(false);
    if (stillnessTimerRef.current) clearTimeout(stillnessTimerRef.current);
    stillnessTimerRef.current = setTimeout(() => {
      setIsStill(true);
      addPoints("stillness", POINT_VALUES.stillness);
    }, STILLNESS_THRESHOLD);
  }, [addPoints]);

  useEffect(() => {
    resetStillnessTimer();
    return () => { if (stillnessTimerRef.current) clearTimeout(stillnessTimerRef.current); };
  }, [resetStillnessTimer]);

  // Teleport
  const handleTeleport = useCallback((x: number, y: number) => {
    setPlayerPos({ x, y });
    setTrail((t) => { const n = [...t, { x, y }]; return n.length > 80 ? n.slice(-80) : n; });
    syncPosition({ x, y });
    resetStillnessTimer();
  }, [syncPosition, resetStillnessTimer]);

  // Movement
  const handleMove = useCallback(
    (dx: number, dy: number) => {
      setShowHint(false);
      setRadialOpen(false);
      resetStillnessTimer();

      setPlayerPos((prev) => {
        const newPos = { x: prev.x + dx, y: prev.y + dy };
        setTrail((t) => { const n = [...t, newPos]; return n.length > 80 ? n.slice(-80) : n; });
        setSteps((s) => s + 1);
        addPoints("move", POINT_VALUES.move);
        syncPosition(newPos);

        const landedPlayer = MOCK_PLAYERS.find((p) => p.x === newPos.x && p.y === newPos.y);
        if (landedPlayer) {
          setSelectedPlayer(landedPlayer);
          setSelectedBonus(null);
          setSelectedHeartbeat(null);
          setSelectedSortie(null);
          setShowInfo(true);
          setShowSortieInfo(false);
          addPoints("encounter", POINT_VALUES.encounter);
        } else {
          const landedBonus = BONUS_SQUARES.find((b) => b.x === newPos.x && b.y === newPos.y);
          if (landedBonus) {
            const key = `${landedBonus.x},${landedBonus.y}`;
            const isNew = !discoveredBonuses.has(key);
            setSelectedBonus(landedBonus);
            setSelectedPlayer(null);
            setSelectedHeartbeat(null);
            setSelectedSortie(null);
            setShowInfo(true);
            setShowSortieInfo(false);
            setDiscoveredBonuses((prev) => { const n = new Set(prev); n.add(key); return n; });
            if (isNew) { setDiscoveries((d) => d + 1); addPoints("discover", POINT_VALUES.discover); }
          } else {
            const landedSortie = sorties.find((s) => s.x === newPos.x && s.y === newPos.y);
            if (landedSortie) {
              setSelectedSortie(landedSortie);
              setSelectedPlayer(null);
              setSelectedBonus(null);
              setSelectedHeartbeat(null);
              setShowInfo(false);
              setShowSortieInfo(true);
            } else {
              const landedHb = heartbeats.find((h) => h.x === newPos.x && h.y === newPos.y);
              if (landedHb) {
                setSelectedHeartbeat(landedHb);
                setSelectedPlayer(null);
                setSelectedBonus(null);
                setSelectedSortie(null);
                setShowInfo(true);
                setShowSortieInfo(false);
              } else {
                setShowInfo(false);
                setShowSortieInfo(false);
                setSelectedPlayer(null);
                setSelectedBonus(null);
                setSelectedHeartbeat(null);
                setSelectedSortie(null);
              }
            }
          }
        }
        return newPos;
      });
    },
    [resetStillnessTimer, addPoints, discoveredBonuses, heartbeats, sorties, syncPosition],
  );

  // Keyboard
  useEffect(() => {
    const anyPanelOpen = showHeartbeatCreator || showSortieCreator || profileOpen || agentOpen || messagesOpen || agendaOpen || mediaOpen;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (anyPanelOpen) return;
      switch (e.key) {
        case "ArrowUp": e.preventDefault(); handleMove(0, -1); break;
        case "ArrowDown": e.preventDefault(); handleMove(0, 1); break;
        case "ArrowLeft": e.preventDefault(); handleMove(-1, 0); break;
        case "ArrowRight": e.preventDefault(); handleMove(1, 0); break;
        case "Escape":
          setShowInfo(false); setShowSortieInfo(false); setRadialOpen(false); break;
        case " ": e.preventDefault(); setRadialOpen((v) => !v); break;
      }
      if ((e.ctrlKey || e.metaKey) && (e.key === "=" || e.key === "+")) { e.preventDefault(); handleZoomIn(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "-") { e.preventDefault(); handleZoomOut(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "0") { e.preventDefault(); handleZoomReset(); }
    };

    const handleWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        if (e.deltaY < 0) handleZoomIn();
        else if (e.deltaY > 0) handleZoomOut();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("wheel", handleWheel, { passive: false });
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("wheel", handleWheel);
    };
  }, [handleMove, showHeartbeatCreator, showSortieCreator, profileOpen, agentOpen, messagesOpen, agendaOpen, mediaOpen, handleZoomIn, handleZoomOut, handleZoomReset]);

  // Create heartbeat
  const handleCreateHeartbeat = useCallback((data: Omit<Heartbeat, "id" | "creatorId" | "creatorPseudo" | "creatorColor" | "creatorSymbol" | "x" | "y" | "createdAt">) => {
    const newHb: Heartbeat = {
      ...data, id: `hb-user-${Date.now()}`,
      creatorId: currentPlayer.id, creatorPseudo: currentPlayer.pseudo,
      creatorColor: currentPlayer.colorHex, creatorSymbol: currentPlayer.symbol,
      x: playerPos.x, y: playerPos.y, createdAt: Date.now(),
    };
    setHeartbeats((prev) => [...prev, newHb]);
    addPoints("heartbeat", POINT_VALUES.heartbeat);
    api.createHeartbeat(newHb).catch((e) => console.log("Heartbeat sync error:", e));
  }, [currentPlayer, playerPos, addPoints]);

  // Create sortie
  const handleCreateSortie = useCallback((data: Omit<SortieEvent, "id" | "creatorId" | "creatorPseudo" | "creatorColor" | "creatorSymbol" | "x" | "y" | "createdAt" | "participants">) => {
    const newSortie: SortieEvent = {
      ...data, id: `sortie-${Date.now()}`,
      creatorId: currentPlayer.id, creatorPseudo: currentPlayer.pseudo,
      creatorColor: currentPlayer.colorHex, creatorSymbol: currentPlayer.symbol,
      x: playerPos.x, y: playerPos.y, participants: [], createdAt: Date.now(),
    };
    setSorties((prev) => [...prev, newSortie]);
    addPoints("sortie", POINT_VALUES.heartbeat);
    api.createSortie(newSortie).catch((e) => console.log("Sortie sync error:", e));
  }, [currentPlayer, playerPos, addPoints]);

  // Join / Leave sortie
  const handleJoinSortie = useCallback((sortieId: string) => {
    setSorties((prev) => prev.map((s) => {
      if (s.id === sortieId) {
        if (s.participants.some((p) => p.id === currentPlayer.id)) return s;
        const updated = { ...s, participants: [...s.participants, { id: currentPlayer.id, pseudo: currentPlayer.pseudo, color: currentPlayer.colorHex, symbol: currentPlayer.symbol }] };
        setSelectedSortie(updated);
        return updated;
      }
      return s;
    }));
    api.joinSortie(sortieId, { playerId: currentPlayer.id, pseudo: currentPlayer.pseudo, color: currentPlayer.colorHex, symbol: currentPlayer.symbol }).catch((e) => console.log("Join sortie error:", e));
  }, [currentPlayer]);

  const handleLeaveSortie = useCallback((sortieId: string) => {
    setSorties((prev) => prev.map((s) => {
      if (s.id === sortieId) {
        const updated = { ...s, participants: s.participants.filter((p) => p.id !== currentPlayer.id) };
        setSelectedSortie(updated);
        return updated;
      }
      return s;
    }));
    api.leaveSortie(sortieId, currentPlayer.id).catch((e) => console.log("Leave sortie error:", e));
  }, [currentPlayer]);

  // ─── RADIAL MENU ACTIONS ───
  const handleRadialAction = useCallback((action: RadialAction) => {
    setRadialOpen(false);
    switch (action) {
      case "battement": setShowHeartbeatCreator(true); break;
      case "sortie": setShowSortieCreator(true); break;
      case "profil": setProfileOpen(true); break;
      case "agent": setAgentOpen(true); break;
      case "messages": setMessagesOpen(true); break;
      case "agenda": setAgendaOpen(true); break;
      case "medias": setMediaOpen(true); break;
      case "explorer": break; // Could toggle minimap fullscreen
    }
  }, []);

  // Lookup maps
  const playerMap = useMemo(() => {
    const map = new Map<string, PlayerData>();
    MOCK_PLAYERS.forEach((p) => map.set(`${p.x},${p.y}`, p));
    return map;
  }, []);

  const bonusMap = useMemo(() => {
    const map = new Map<string, BonusSquare>();
    BONUS_SQUARES.forEach((b) => map.set(`${b.x},${b.y}`, b));
    return map;
  }, []);

  const heartbeatMap = useMemo(() => {
    const map = new Map<string, Heartbeat>();
    heartbeats.forEach((h) => map.set(`${h.x},${h.y}`, h));
    return map;
  }, [heartbeats]);

  const sortieMap = useMemo(() => {
    const map = new Map<string, SortieEvent>();
    sorties.forEach((s) => map.set(`${s.x},${s.y}`, s));
    return map;
  }, [sorties]);

  const trailSet = useMemo(() => {
    const set = new Set<string>();
    trail.forEach((t) => set.add(`${t.x},${t.y}`));
    return set;
  }, [trail]);

  const cityMap = useMemo(() => {
    const map = new Map<string, typeof WORLD_CITIES[0]>();
    WORLD_CITIES.forEach((c) => map.set(`${c.x},${c.y}`, c));
    return map;
  }, []);

  const getPatternZone = useCallback((x: number, y: number) => {
    return PATTERN_ZONES.find((z) => Math.abs(x - z.cx) + Math.abs(y - z.cy) <= z.radius);
  }, []);

  // Render grid
  const gridCells = useMemo(() => {
    const cells: React.ReactNode[] = [];
    const halfCols = Math.floor(visibleCols / 2);
    const halfRows = Math.floor(visibleRows / 2);

    for (let dy = -halfRows; dy <= halfRows; dy++) {
      for (let dx = -halfCols; dx <= halfCols; dx++) {
        const worldX = playerPos.x + dx;
        const worldY = playerPos.y + dy;
        const key = `${worldX},${worldY}`;
        const screenX = viewportSize.w / 2 + dx * totalCell - cellSize / 2;
        const screenY = viewportSize.h / 2 + dy * totalCell - cellSize / 2;

        const isCurrentPos = dx === 0 && dy === 0;
        const player = playerMap.get(key);
        const bonus = bonusMap.get(key);
        const hb = heartbeatMap.get(key);
        const sortie = sortieMap.get(key);
        const city = cityMap.get(key);
        const isOnTrail = trailSet.has(key) && !isCurrentPos;
        const isDiscovered = discoveredBonuses.has(key);
        const zone = getPatternZone(worldX, worldY);

        // ─── CITY LABEL ───
        if (city && !isCurrentPos && !player && !bonus && !hb && !sortie) {
          const cityFontSize = city.size === "lg" ? cellSize * 0.28 : city.size === "md" ? cellSize * 0.22 : cellSize * 0.18;
          cells.push(
            <div key={`city-${key}`} className="absolute pointer-events-none" style={{ left: screenX, top: screenY, zIndex: 1 }}>
              <div
                className="flex flex-col items-center justify-center"
                style={{ width: cellSize, height: cellSize }}
              >
                <span style={{
                  fontSize: cityFontSize,
                  color: city.size === "lg" ? "rgba(0,0,0,0.12)" : "rgba(0,0,0,0.07)",
                  fontWeight: city.size === "lg" ? 500 : 400,
                  letterSpacing: "0.06em",
                  lineHeight: 1,
                  whiteSpace: "nowrap",
                }}>
                  {city.name}
                </span>
              </div>
            </div>,
          );
        }

        // ─── CURRENT PLAYER (beating symbol) ───
        if (isCurrentPos) {
          cells.push(
            <div key={`me-${key}`} className="absolute" style={{ left: screenX, top: screenY, zIndex: 10 }}>
              <motion.div
                className="cursor-pointer"
                onClick={() => setRadialOpen((v) => !v)}
                animate={{ scale: [1, 1.04, 1, 1.03, 1, 1, 1] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut", times: [0, 0.1, 0.2, 0.3, 0.4, 0.6, 1] }}
              >
                <PlayerSquare
                  colorHex={currentPlayer.colorHex}
                  symbol={currentPlayer.symbol}
                  symbol2={(currentPlayer as any).symbol2}
                  symbolSize={currentPlayer.symbolSize}
                  symbolRotation={currentPlayer.symbolRotation}
                  symbolContrast={currentPlayer.symbolContrast}
                  size={cellSize}
                  isCurrentPlayer
                  mode={mode}
                />
              </motion.div>
              {isStill && (
                <motion.div
                  className="absolute inset-[-6px] rounded-[6px] pointer-events-none"
                  style={{ border: `1px solid ${currentPlayer.colorHex}40` }}
                  animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.03, 1] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                />
              )}
            </div>,
          );
        } else if (sortie && !player) {
          cells.push(
            <div key={`sortie-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <motion.div
                className="relative cursor-pointer select-none"
                style={{ width: cellSize, height: cellSize }}
                onClick={() => { setSelectedSortie(sortie); setShowSortieInfo(true); setShowInfo(false); }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.92 }}
              >
                <motion.div
                  className="absolute inset-[-8px] rounded-[8px]"
                  style={{ border: `1.5px solid ${SORTIE_COLOR}` }}
                  animate={{ opacity: [0.1, 0.35, 0.1], scale: [1, 1.06, 1] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                />
                <div className="absolute inset-0 rounded-[2px]" style={{ backgroundColor: sortie.creatorColor, border: `1.5px solid ${SORTIE_COLOR}50`, boxShadow: `0 0 16px 3px ${SORTIE_COLOR}20` }} />
                <div className="absolute inset-0 flex items-center justify-center" style={{ color: "#fff", opacity: 0.85 }}>
                  <CalendarHeart size={cellSize * 0.38} strokeWidth={1.5} />
                </div>
                {sortie.participants.length > 0 && (
                  <div className="absolute -top-1 -right-1 flex items-center justify-center rounded-full" style={{ width: cellSize * 0.35, height: cellSize * 0.35, minWidth: 14, minHeight: 14, backgroundColor: SORTIE_COLOR, color: "#fff", fontSize: Math.max(cellSize * 0.18, 8), fontWeight: 600, zIndex: 2 }}>
                    {sortie.participants.length}
                  </div>
                )}
              </motion.div>
            </div>,
          );
        } else if (player) {
          const playerHb = heartbeatMap.get(key);
          cells.push(
            <div key={`p-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <PlayerSquare
                colorHex={player.colorHex} symbol={player.symbol}
                symbolSize={player.symbolSize} symbolRotation={player.symbolRotation} symbolContrast={player.symbolContrast}
                size={cellSize} mode={mode}
                onClick={() => { setSelectedPlayer(player); setSelectedBonus(null); setSelectedHeartbeat(playerHb || null); setSelectedSortie(null); setShowInfo(true); setShowSortieInfo(false); }}
              />
              {playerHb && (
                <motion.div className="absolute inset-[-5px] rounded-[5px]" style={{ border: `1.5px solid ${HEART_RED}` }}
                  animate={{ opacity: [0.1, 0.4, 0.1], scale: [1, 1.06, 1] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                />
              )}
            </div>,
          );
        } else if (hb) {
          cells.push(
            <div key={`hb-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <PlayerSquare colorHex={hb.creatorColor} symbol={hb.creatorSymbol} size={cellSize} isPulse pulseColor={HEART_RED} mode={mode}
                onClick={() => { setSelectedHeartbeat(hb); setSelectedPlayer(null); setSelectedBonus(null); setSelectedSortie(null); setShowInfo(true); setShowSortieInfo(false); }}
              />
            </div>,
          );
        } else if (bonus && isDiscovered) {
          cells.push(
            <div key={`b-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <PlayerSquare colorHex={bonus.colorHex || "#F0EAD6"} symbol={bonus.value} size={cellSize} isBonus glowing={bonus.type === "glow"} mode={mode}
                onClick={() => { setSelectedBonus(bonus); setSelectedPlayer(null); setSelectedHeartbeat(null); setSelectedSortie(null); setShowInfo(true); setShowSortieInfo(false); }}
              />
            </div>,
          );
        } else if (bonus && !isDiscovered) {
          cells.push(
            <div key={`bh-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <motion.div className="rounded-[2px]"
                style={{ width: cellSize, height: cellSize, backgroundColor: "rgba(0,0,0,0.01)", border: "1px dashed rgba(0,0,0,0.03)" }}
                animate={{ opacity: [0.4, 0.7, 0.4] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>,
          );
        } else if (isOnTrail) {
          cells.push(
            <div key={`t-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <PlayerSquare colorHex={currentPlayer.colorHex} symbol="" size={cellSize} isTrail mode={mode} />
            </div>,
          );
        } else if (zone && !city) {
          cells.push(
            <div key={`z-${key}`} className="absolute" style={{ left: screenX, top: screenY }}>
              <div className="flex items-center justify-center" style={{ width: cellSize, height: cellSize, fontSize: cellSize * 0.25, color: "rgba(0,0,0,0.04)" }}>
                {zone.pattern}
              </div>
            </div>,
          );
        }
      }
    }
    return cells;
  }, [
    playerPos, visibleCols, visibleRows, viewportSize, totalCell, cellSize,
    currentPlayer, playerMap, bonusMap, heartbeatMap, sortieMap, cityMap, trailSet, discoveredBonuses,
    mode, isStill, getPatternZone,
  ]);

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ backgroundColor: BG_IVORY }}>
      {/* Grid lines */}
      <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
        <defs>
          <pattern id="gameGrid" width={totalCell} height={totalCell} patternUnits="userSpaceOnUse"
            patternTransform={`translate(${viewportSize.w / 2 - cellSize / 2 - 1} ${viewportSize.h / 2 - cellSize / 2 - 1})`}>
            <rect width={cellSize} height={cellSize} fill="none" stroke="#d5d0c8" strokeWidth="0.5" rx="0.5" />
          </pattern>
          <pattern id="fabricTexture" width={totalCell} height={totalCell} patternUnits="userSpaceOnUse"
            patternTransform={`translate(${viewportSize.w / 2 - cellSize / 2 - 1} ${viewportSize.h / 2 - cellSize / 2 - 1})`}>
            <line x1={cellSize * 0.35} y1={cellSize * 0.35} x2={cellSize * 0.65} y2={cellSize * 0.65} stroke="#d5d0c8" strokeWidth="0.2" opacity="0.4" />
            <line x1={cellSize * 0.65} y1={cellSize * 0.35} x2={cellSize * 0.35} y2={cellSize * 0.65} stroke="#d5d0c8" strokeWidth="0.2" opacity="0.4" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#gameGrid)" />
        <rect width="100%" height="100%" fill="url(#fabricTexture)" opacity="0.5" />
      </svg>

      {/* Grid cells */}
      {gridCells}

      {/* ─── RADIAL MENU (8 squares around player) ─── */}
      <RadialMenu
        visible={radialOpen}
        cellSize={cellSize}
        totalCell={totalCell}
        playerColor={currentPlayer.colorHex}
        onAction={handleRadialAction}
        onClose={() => setRadialOpen(false)}
      />

      {/* ─── TOP LEFT: Brand + Coords ─── */}
      <div
        className="fixed z-30 flex flex-col gap-0.5 rounded-xl"
        style={{
          top: isMobile ? 10 : 16,
          left: isMobile ? 10 : 16,
          padding: isMobile ? "6px 8px" : "8px 12px",
          backgroundColor: "rgba(255,255,255,0.65)",
          backdropFilter: "blur(12px)",
          boxShadow: "0 1px 8px rgba(0,0,0,0.03)",
        }}
      >
        <StitchLabBadge size={isMobile ? "xs" : "sm"} />
        <div className="flex items-center gap-1.5" style={{ marginTop: 3 }}>
          <span style={{ fontSize: isMobile ? 10 : 11, color: "#999", fontWeight: 400 }}>{currentPlayer.pseudo}</span>
          <span style={{ fontSize: 9, color: "#ddd" }}>·</span>
          <span style={{ fontSize: isMobile ? 9 : 10, color: "#ccc", fontVariantNumeric: "tabular-nums" }}>
            {playerPos.x}, {playerPos.y}
          </span>
        </div>
        {(() => {
          const zone = getPatternZone(playerPos.x, playerPos.y);
          const city = cityMap.get(`${playerPos.x},${playerPos.y}`);
          return (zone || city) ? (
            <motion.span
              style={{ fontSize: 9, color: "#bbb", fontStyle: "italic", fontWeight: 300 }}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            >
              {city ? city.name : zone ? `${zone.pattern} ${zone.name}` : ""}
            </motion.span>
          ) : null;
        })()}
      </div>

      {/* ─── TAP HINT ─── */}
      <AnimatePresence>
        {!radialOpen && !showInfo && !showSortieInfo && !showHeartbeatCreator && !showSortieCreator && (
          <motion.div
            className="fixed z-20 pointer-events-none"
            style={{
              left: "50%",
              top: viewportSize.h / 2 + cellSize / 2 + 10,
              transform: "translateX(-50%)",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 2, duration: 0.5 }}
          >
            <span style={{ fontSize: isMobile ? 8 : 9, color: "#ccc", fontWeight: 300, letterSpacing: "0.03em", whiteSpace: "nowrap" }}>
              {showHint ? "Touche ton carré · Flèches pour explorer" : ""}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Info cards */}
      <PlayerInfoCard player={selectedPlayer} bonus={selectedBonus} heartbeat={selectedHeartbeat}
        visible={showInfo} onClose={() => setShowInfo(false)} mode={mode} />
      <SortieInfoCard sortie={selectedSortie} visible={showSortieInfo}
        onClose={() => setShowSortieInfo(false)} onJoin={handleJoinSortie} onLeave={handleLeaveSortie}
        currentPlayerId={currentPlayer.id} mode={mode} />

      {/* Points HUD */}
      <PointsHUD points={points} lastEvent={lastEvent} steps={steps} discoveries={discoveries} mode={mode} />

      {/* Arrow controls */}
      <ArrowControls onMove={handleMove} mode={mode} />

      {/* Zoom controls — TOP */}
      <ZoomControls onZoomIn={handleZoomIn} onZoomOut={handleZoomOut} onZoomReset={handleZoomReset} zoom={zoom} mode={mode} />

      {/* Minimap */}
      <Minimap playerPos={playerPos} currentPlayer={currentPlayer} trail={trail}
        heartbeats={heartbeats} sorties={sorties} discoveredBonuses={discoveredBonuses}
        mode={mode} onTeleport={handleTeleport} />

      {/* Creators */}
      <HeartbeatCreator visible={showHeartbeatCreator} onClose={() => setShowHeartbeatCreator(false)}
        onCreateHeartbeat={handleCreateHeartbeat} mode={mode} />
      <SortieCreator visible={showSortieCreator} onClose={() => setShowSortieCreator(false)}
        onCreateSortie={handleCreateSortie} mode={mode} />

      {/* Panels */}
      <ProfilePanel visible={profileOpen} onClose={() => setProfileOpen(false)}
        player={currentPlayer} mode={mode} onModeChange={onModeChange}
        stats={{ points, steps, discoveries }} />
      <AIAgent
        visible={agentOpen}
        onClose={() => setAgentOpen(false)}
        onTeleportTo={handleTeleport}
        playerPos={playerPos}
        currentPlayer={currentPlayer}
        userInterests={lilyInterests}
        onUserInterestsChange={setLilyInterests}
        suggestedPlayers={lilySuggested}
        onSuggestedPlayersChange={setLilySuggested}
      />
      <MessagingPanel visible={messagesOpen} onClose={() => setMessagesOpen(false)} />
      <AgendaPanel visible={agendaOpen} onClose={() => setAgendaOpen(false)} />
      <MediaPanel visible={mediaOpen} onClose={() => setMediaOpen(false)} />

      {/* ─── LILY AMBIENT NOTIFICATIONS ─── */}
      <LilyNotification
        playerPos={playerPos}
        userInterests={lilyInterests}
        suggestedPlayers={lilySuggested}
        onTeleportTo={handleTeleport}
        onOpenLily={() => setAgentOpen(true)}
        onDismiss={(id) => setLilySuggested((prev) => { const n = new Set(prev); n.add(id); return n; })}
      />

      {/* Hint */}
      {showHint && (
        <motion.div
          className="fixed left-1/2 -translate-x-1/2 z-20 pointer-events-none"
          style={{ bottom: isMobile ? 130 : isSenior ? 220 : 175 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.45 }}
          transition={{ delay: 1.5, duration: 1 }}
        >
          <p style={{ fontSize: isMobile ? 8 : 9, color: "#ccc", textAlign: "center", fontWeight: 300, letterSpacing: "0.03em" }}>
            Flèches ou clavier pour explorer · Espace pour le menu radial
          </p>
        </motion.div>
      )}
    </div>
  );
}