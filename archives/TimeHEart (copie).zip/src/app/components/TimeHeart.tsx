import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, Volume2, VolumeX, Grid3x3, Circle, Eye, Heart, Zap,
  Navigation, Scissors, X,
} from "lucide-react";
import { speakWithLily } from "./api";

// ═══════════════════════════════════════════════════
// TIMEHEART — MOTEUR 5D · ORA · PLANÈTES · ÉTOILES
// Cadran 24h · Alignement planétaire · Citation Jung
// Aiguille ORA guide vers le dernier point brodé
// ═══════════════════════════════════════════════════

const HEART_RED = "#E8177F";
const LILY_PURPLE = "#9263A6";

// ─── 8 FAMILY SYMBOLS → Stars ───
const STAR_SYMBOLS = ["♥", "✚", "◆", "✳", "■", "●", "∞", "▲"];

interface StarData {
  id: number; symbol: string;
  x: number; y: number; size: number;
  delay: number; duration: number;
}

function generateStars(count: number): StarData[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i, symbol: STAR_SYMBOLS[i % 8],
    x: Math.random() * 100, y: Math.random() * 100,
    size: 5 + Math.random() * 7,
    delay: Math.random() * 8, duration: 3 + Math.random() * 5,
  }));
}

// ─── ORA — O·R·A ───
type OraPhase = "off" | "observer" | "ressentir" | "agir";

const ORA_PHASES: Record<Exclude<OraPhase, "off">, {
  label: string; letter: string; color: string;
  icon: typeof Eye; desc: string; psycho: string;
}> = {
  observer: {
    label: "Observer", letter: "O", color: "#4685B7", icon: Eye,
    desc: "Regarder, explorer, se laisser impregner. Sans obligation de decider.",
    psycho: "Je ne suis pas presse. Je comprends.",
  },
  ressentir: {
    label: "Ressentir", letter: "R", color: "#E8A838", icon: Heart,
    desc: "Ce qui resonne, ce qui attire naturellement, ce qui fait dire 'ca, oui'.",
    psycho: "Je sens que c'est juste pour moi.",
  },
  agir: {
    label: "Agir", letter: "A", color: "#42A350", icon: Zap,
    desc: "L'action arrive en dernier, naturellement. Cliquer, ajouter, confirmer.",
    psycho: "Je n'ai pas ete pousse, j'ai choisi.",
  },
};
const ORA_ORDER: Exclude<OraPhase, "off">[] = ["observer", "ressentir", "agir"];

// ─── 5 DIMENSIONS (planètes) ───
const DIMENSIONS = [
  { id: "D1", label: "Intention", color: "#E8177F", symbol: "◉", radius: 5 },
  { id: "D2", label: "Temporalite", color: "#E8A838", symbol: "◎", radius: 4 },
  { id: "D3", label: "Relation", color: "#4685B7", symbol: "●", radius: 6 },
  { id: "D4", label: "Action", color: "#42A350", symbol: "◈", radius: 3.5 },
  { id: "D5", label: "Resonance", color: "#9263A6", symbol: "✦", radius: 4.5 },
] as const;

interface TemporalSeed {
  id: string; angle: number; dimension: number;
  state: "dormant" | "recognition" | "encounter";
  intensity: number; phase: number; gx: number; gy: number;
}

function generateSeeds(count: number): TemporalSeed[] {
  return Array.from({ length: count }, (_, i) => ({
    id: `seed-${i}`,
    angle: Math.random() * 360,
    dimension: Math.floor(Math.random() * 5),
    state: (["dormant", "dormant", "dormant", "recognition", "recognition", "encounter"] as const)[Math.floor(Math.random() * 6)],
    intensity: 0.3 + Math.random() * 0.7,
    phase: Math.random() * Math.PI * 2,
    gx: Math.floor(Math.random() * 40) - 20,
    gy: Math.floor(Math.random() * 40) - 20,
  }));
}

function breathe(dimIndex: number, time: number): number {
  return Math.sin(time * 0.4 + dimIndex * 0.8) * 1.5;
}

type ViewMode = "rings" | "grid";

interface TimeHeartProps {
  onBack?: () => void;
  /** Last stitch position from StitchLab grid e.g. "4,7" */
  lastStitchKey?: string | null;
}

export function TimeHeart({ onBack, lastStitchKey }: TimeHeartProps) {
  const [time, setTime] = useState(0);
  const [seeds] = useState(() => generateSeeds(24));
  const [stars] = useState(() => generateStars(40));
  const [selectedSeed, setSelectedSeed] = useState<string | null>(null);
  const [showInfo, setShowInfo] = useState(true);
  const [hoveredDim, setHoveredDim] = useState<number | null>(null);
  const [soundOn, setSoundOn] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>("rings");

  // Planet alignment animation
  const [planetsAligned, setPlanetsAligned] = useState(false);

  // Lily greeting
  const [lilyVisible, setLilyVisible] = useState(false);
  const [lilyDismissed, setLilyDismissed] = useState(false);

  // ORA
  const [oraPhase, setOraPhase] = useState<OraPhase>("off");
  const [oraAngle, setOraAngle] = useState(0);
  const [oraTarget, setOraTarget] = useState<number | null>(null);

  // Needle pierce animation (on open, if lastStitchKey exists)
  const [needlePiercing, setNeedlePiercing] = useState(false);
  const [pierceComplete, setPierceComplete] = useState(false);

  // Lily TTS voice
  const lilySpokenRef = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Grid map
  const [cursor, setCursor] = useState({ x: 0, y: 0 });
  const GRID_CELL = 48;
  const VISIBLE_COLS = 15;
  const VISIBLE_ROWS = 11;

  // Parse last stitch position
  const lastStitch = useMemo(() => {
    if (!lastStitchKey) return null;
    const [x, y] = lastStitchKey.split(",").map(Number);
    if (isNaN(x) || isNaN(y)) return null;
    return { x, y };
  }, [lastStitchKey]);

  // Real clock
  const now = new Date();
  const hours = now.getHours() + now.getMinutes() / 60;
  const clockAngle = (hours / 24) * 360;

  // Animation loop
  useEffect(() => {
    let frame: number;
    const animate = () => {
      setTime((t) => t + 0.016);
      frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  // Planet alignment: slowly align after 2s
  useEffect(() => {
    const timer = setTimeout(() => setPlanetsAligned(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Needle pierce animation on open if lastStitch exists
  useEffect(() => {
    if (lastStitch && !pierceComplete) {
      const t1 = setTimeout(() => setNeedlePiercing(true), 1200);
      const t2 = setTimeout(() => {
        setNeedlePiercing(false);
        setPierceComplete(true);
      }, 3500);
      return () => { clearTimeout(t1); clearTimeout(t2); };
    }
  }, [lastStitch, pierceComplete]);

  // ORA needle drift
  useEffect(() => {
    if (oraPhase === "off" || oraTarget === null) return;
    const interval = setInterval(() => {
      setOraAngle((prev) => {
        const diff = oraTarget - prev;
        if (Math.abs(diff) < 0.5) return oraTarget;
        return prev + diff * 0.02;
      });
    }, 32);
    return () => clearInterval(interval);
  }, [oraPhase, oraTarget]);

  // ORA activates → point to last stitch if exists, else find encounter seed
  useEffect(() => {
    if (oraPhase === "off") return;
    if (lastStitch) {
      // Convert grid position to angle on the 24h clock
      const angle = ((Math.atan2(lastStitch.y, lastStitch.x) * 180) / Math.PI + 90 + 360) % 360;
      setOraTarget(angle);
    } else {
      const encounters = seeds.filter((s) => s.state === "encounter");
      const recognitions = seeds.filter((s) => s.state === "recognition");
      const target = encounters[0] || recognitions[0];
      if (target) setOraTarget(target.angle);
      else setOraTarget(oraAngle + 120);
    }
  }, [oraPhase, seeds, lastStitch]);

  // Auto-dismiss intro
  useEffect(() => {
    const timer = setTimeout(() => setShowInfo(false), 5000);
    return () => clearTimeout(timer);
  }, []);

  // Lily after intro
  useEffect(() => {
    if (!showInfo && !lilyDismissed) {
      const timer = setTimeout(() => setLilyVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, [showInfo, lilyDismissed]);

  useEffect(() => {
    if (lilyVisible) {
      const timer = setTimeout(() => { setLilyVisible(false); setLilyDismissed(true); }, 12000);
      return () => clearTimeout(timer);
    }
  }, [lilyVisible]);

  // Lily TTS — speak when she appears
  useEffect(() => {
    if (lilyVisible && !lilySpokenRef.current) {
      lilySpokenRef.current = true;
      const lilyText = "Vous avez vu... On est bien là.. C'est mon Créateur Matt Mez qui m'a offert cette place à côté de vous...";
      speakWithLily(lilyText).then((blob) => {
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audioRef.current = audio;
        audio.onended = () => {
          URL.revokeObjectURL(url);
          audioRef.current = null;
        };
        audio.play().catch((err) => console.log("Lily TTS autoplay blocked:", err));
      }).catch((err) => console.log("Lily TTS error (non-fatal):", err));
    }
  }, [lilyVisible]);

  // Arrow keys for grid
  useEffect(() => {
    if (viewMode !== "grid") return;
    const handler = (e: KeyboardEvent) => {
      switch (e.key) {
        case "ArrowUp":    e.preventDefault(); setCursor((c) => ({ ...c, y: c.y - 1 })); break;
        case "ArrowDown":  e.preventDefault(); setCursor((c) => ({ ...c, y: c.y + 1 })); break;
        case "ArrowLeft":  e.preventDefault(); setCursor((c) => ({ ...c, x: c.x - 1 })); break;
        case "ArrowRight": e.preventDefault(); setCursor((c) => ({ ...c, x: c.x + 1 })); break;
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [viewMode]);

  // SVG
  const cx = 250, cy = 250, svgSize = 500;
  const ringRadii = [85, 105, 125, 145, 165];
  const outerRing = 185;

  // Time needle
  const timeRad = ((clockAngle - 90) * Math.PI) / 180;
  const timeX = cx + Math.cos(timeRad) * outerRing;
  const timeY = cy + Math.sin(timeRad) * outerRing;

  // ORA needle
  const oraRad = ((oraAngle - 90) * Math.PI) / 180;
  const oraLen = 160;
  const oraX = cx + Math.cos(oraRad) * oraLen;
  const oraY = cy + Math.sin(oraRad) * oraLen;

  const handleSeedClick = useCallback((seedId: string) => {
    setSelectedSeed((prev) => (prev === seedId ? null : seedId));
  }, []);

  const selectedSeedData = seeds.find((s) => s.id === selectedSeed);

  const seedsByPos = useMemo(() => {
    const map: Record<string, TemporalSeed> = {};
    seeds.forEach((s) => { map[`${s.gx},${s.gy}`] = s; });
    return map;
  }, [seeds]);

  const halfCols = Math.floor(VISIBLE_COLS / 2);
  const halfRows = Math.floor(VISIBLE_ROWS / 2);

  // ORA toggle
  const toggleOra = () => {
    if (oraPhase === "off") {
      setOraPhase("observer");
      setOraAngle(clockAngle + 30);
    } else {
      const idx = ORA_ORDER.indexOf(oraPhase as any);
      if (idx < ORA_ORDER.length - 1) {
        setOraPhase(ORA_ORDER[idx + 1]);
        setOraTarget((oraAngle + 60 + idx * 40) % 360);
      } else {
        setOraPhase("off");
        setOraTarget(null);
      }
    }
  };

  const oraData = oraPhase !== "off" ? ORA_PHASES[oraPhase] : null;

  // ── Planets: vertical alignment positions ──
  // When aligned, planets sit on a vertical line through center (cx)
  // Spaced evenly from top to bottom of ring area
  const planetAlignedY = DIMENSIONS.map((_, i) => {
    const totalSpan = ringRadii[4] - ringRadii[0]; // 165-85=80
    const step = totalSpan / (DIMENSIONS.length - 1);
    return cy - totalSpan / 2 + i * step;
  });

  return (
    <div
      className="fixed inset-0 overflow-hidden flex flex-col"
      style={{
        background: "radial-gradient(ellipse at 50% 50%, #0a0a12 0%, #050508 50%, #000000 100%)",
        fontFamily: "'Inter', -apple-system, sans-serif",
      }}
      tabIndex={0}
    >
      {/* ═══ SYMBOL STARS ═══ */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        {stars.map((star) => (
          <motion.span
            key={star.id}
            className="absolute select-none"
            style={{
              left: `${star.x}%`, top: `${star.y}%`,
              fontSize: star.size, color: "rgba(255,255,255,0.5)",
              textShadow: "0 0 6px rgba(255,255,255,0.3)", lineHeight: 1,
            }}
            animate={{ opacity: [0.06, 0.3, 0.06], scale: [0.9, 1.1, 0.9] }}
            transition={{ duration: star.duration, delay: star.delay, repeat: Infinity, ease: "easeInOut" }}
          >
            {star.symbol}
          </motion.span>
        ))}
      </div>

      {/* Cosmic grain */}
      <div className="absolute inset-0 pointer-events-none z-[1]" style={{
        backgroundImage: `radial-gradient(circle at 30% 20%, rgba(232,23,127,0.03) 0%, rgba(0,0,0,0) 50%),
                          radial-gradient(circle at 70% 80%, rgba(146,99,166,0.03) 0%, rgba(0,0,0,0) 50%),
                          radial-gradient(circle at 50% 50%, rgba(70,133,183,0.02) 0%, rgba(0,0,0,0) 40%)`,
      }} />

      {/* ═══ CENTERED TITLE: TI M EHEART ═══ */}
      <motion.div
        className="absolute z-[5] flex flex-col items-center pointer-events-none"
        style={{ top: "clamp(16px, 3vh, 32px)", left: "50%", transform: "translateX(-50%)" }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 1.2 }}
      >
        <div className="flex items-baseline" style={{ letterSpacing: "0.12em" }}>
          <span style={{
            fontSize: "clamp(12px, 2vw, 16px)", fontWeight: 300, color: "rgba(255,255,255,0.18)",
          }}>
            TI
          </span>
          <motion.span
            style={{
              fontSize: "clamp(28px, 5vw, 42px)", fontWeight: 700, color: "#ffffff",
              lineHeight: 1, margin: "0 1px",
              textShadow: "0 0 30px rgba(255,255,255,0.3), 0 0 60px rgba(232,23,127,0.15)",
            }}
            animate={{ opacity: [0.85, 1, 0.85] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            M
          </motion.span>
          <span style={{
            fontSize: "clamp(12px, 2vw, 16px)", fontWeight: 300, color: "rgba(255,255,255,0.18)",
          }}>
            EHEART
          </span>
        </div>
        <span style={{
          fontSize: 8, color: "rgba(255,255,255,0.08)", letterSpacing: "0.25em", marginTop: 4,
        }}>
          MOTEUR 5D
        </span>
      </motion.div>

      {/* ═══ TOP BAR ═══ */}
      <motion.div
        className="relative z-20 flex items-center justify-between px-5 py-4"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        {onBack && (
          <motion.button
            className="flex items-center gap-2 border-none cursor-pointer rounded-lg px-3 py-1.5"
            style={{ backgroundColor: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.4)", fontSize: 11 }}
            onClick={onBack}
            whileTap={{ scale: 0.95 }}
            whileHover={{ backgroundColor: "rgba(255,255,255,0.08)" }}
          >
            <ArrowLeft size={14} />
            Grille
          </motion.button>
        )}

        {/* Spacer for center alignment */}
        <div />

        <div className="flex items-center gap-2">
          <motion.button
            className="flex items-center gap-1.5 border-none cursor-pointer rounded-lg px-2.5 py-1.5"
            style={{ backgroundColor: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.3)", fontSize: 10 }}
            onClick={() => setViewMode((v) => (v === "rings" ? "grid" : "rings"))}
            whileTap={{ scale: 0.95 }}
            whileHover={{ backgroundColor: "rgba(255,255,255,0.08)" }}
          >
            {viewMode === "rings" ? <Grid3x3 size={13} /> : <Circle size={13} />}
            <span>{viewMode === "rings" ? "Carte" : "Anneaux"}</span>
          </motion.button>
          <motion.button
            className="flex items-center gap-1 border-none cursor-pointer rounded-lg px-2 py-1.5"
            style={{ backgroundColor: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.3)" }}
            onClick={() => setSoundOn(!soundOn)}
            whileTap={{ scale: 0.95 }}
          >
            {soundOn ? <Volume2 size={14} /> : <VolumeX size={14} />}
          </motion.button>
        </div>
      </motion.div>

      {/* ═══ MAIN VIEW ═══ */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden z-10">

        {/* Intro overlay */}
        <AnimatePresence>
          {showInfo && (
            <motion.div
              className="absolute inset-0 z-30 flex items-center justify-center"
              style={{ background: "rgba(0,0,0,0.85)" }}
              initial={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 1.5 }}
              onClick={() => setShowInfo(false)}
            >
              <motion.div className="text-center px-8 max-w-lg" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                {/* Planetary alignment teaser */}
                <div className="flex items-center justify-center gap-3 mb-8">
                  {DIMENSIONS.map((dim, i) => (
                    <motion.div
                      key={dim.id}
                      className="rounded-full"
                      style={{
                        width: dim.radius * 3, height: dim.radius * 3,
                        backgroundColor: dim.color, boxShadow: `0 0 12px ${dim.color}50`,
                      }}
                      initial={{ opacity: 0, y: -20 - i * 10 }}
                      animate={{ opacity: [0.4, 0.8, 0.4], y: 0 }}
                      transition={{ delay: 0.5 + i * 0.2, duration: 2 + i * 0.3, repeat: Infinity, ease: "easeInOut" }}
                    />
                  ))}
                </div>
                <motion.p
                  style={{ fontSize: 11, color: "rgba(255,255,255,0.2)", letterSpacing: "0.3em", marginBottom: 20 }}
                  animate={{ opacity: [0.15, 0.35, 0.15] }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  ALIGNEMENT
                </motion.p>
                <p style={{ fontSize: "clamp(14px, 3vw, 18px)", color: "rgba(255,255,255,0.45)", fontWeight: 300, lineHeight: 1.8, fontStyle: "italic" }}>
                  Tant que vous ne rendrez pas l'inconscient conscient,
                  <br />
                  il dirigera votre vie et vous appellerez cela le destin.
                </p>
                <p className="mt-3" style={{ fontSize: 11, color: "rgba(255,255,255,0.2)", letterSpacing: "0.04em" }}>
                  — Carl Gustav Jung
                </p>
                <p className="mt-8" style={{ fontSize: 10, color: "rgba(255,255,255,0.1)", letterSpacing: "0.1em" }}>
                  touche pour entrer
                </p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══ NEEDLE PIERCE ANIMATION ═══ */}
        <AnimatePresence>
          {needlePiercing && lastStitch && (
            <motion.div
              className="absolute z-40 flex flex-col items-center pointer-events-none"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* The needle (vertical line) piercing through */}
              <motion.div
                style={{
                  width: 2, background: `linear-gradient(180deg, rgba(0,0,0,0) 0%, ${HEART_RED} 30%, ${HEART_RED} 70%, rgba(0,0,0,0) 100%)`,
                }}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 120, opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 1.2, ease: "easeInOut" }}
              />
              {/* Pierce point (the square) */}
              <motion.div
                className="flex flex-col items-center gap-2 mt-4"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8, duration: 0.6 }}
              >
                <motion.div
                  className="rounded-sm flex items-center justify-center"
                  style={{
                    width: 32, height: 32,
                    border: `2px solid ${HEART_RED}`,
                    boxShadow: `0 0 20px ${HEART_RED}40, inset 0 0 10px ${HEART_RED}15`,
                    backgroundColor: "rgba(232,23,127,0.08)",
                  }}
                  animate={{ boxShadow: [`0 0 20px ${HEART_RED}40`, `0 0 35px ${HEART_RED}60`, `0 0 20px ${HEART_RED}40`] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <span style={{ color: HEART_RED, fontSize: 14 }}>✚</span>
                </motion.div>
                <motion.span
                  style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.08em" }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.2 }}
                >
                  dernier point : ({lastStitch.x}, {lastStitch.y})
                </motion.span>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══ LILY GREETING ═══ */}
        <AnimatePresence>
          {lilyVisible && (
            <motion.div
              className="absolute z-30 flex items-end gap-3"
              style={{ bottom: "clamp(16px, 4vh, 40px)", left: "clamp(16px, 4vw, 40px)" }}
              initial={{ opacity: 0, y: 20, x: -10 }}
              animate={{ opacity: 1, y: 0, x: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <motion.div
                className="rounded-full flex items-center justify-center shrink-0"
                style={{
                  width: 40, height: 40,
                  background: `linear-gradient(135deg, ${LILY_PURPLE}, ${LILY_PURPLE}cc)`,
                  boxShadow: `0 0 20px ${LILY_PURPLE}40`,
                }}
                animate={{ scale: [1, 1.06, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              >
                <Scissors size={18} style={{ color: "#fff" }} />
              </motion.div>
              <motion.div
                className="rounded-2xl rounded-bl-md px-4 py-3"
                style={{
                  backgroundColor: "rgba(10,10,18,0.92)",
                  border: `1px solid ${LILY_PURPLE}30`,
                  backdropFilter: "blur(20px)", maxWidth: 300,
                }}
                initial={{ scale: 0.9 }} animate={{ scale: 1 }} transition={{ delay: 0.2 }}
              >
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.65)", lineHeight: 1.6 }}>
                  {lastStitch
                    ? <>Tu t'es arretee au point ({lastStitch.x}, {lastStitch.y}) — l'aiguille ORA va te guider pour reprendre{" "}<span style={{ color: HEART_RED }}>♥</span></>
                    : <>Vous avez vu... On est bien la..{" "}
                      <span style={{ color: LILY_PURPLE }}>C'est mon Createur Matt Mez</span>{" "}
                      qui m'a offert cette place a cote de vous...</>
                  }
                </p>
                <span style={{ fontSize: 9, color: LILY_PURPLE, fontWeight: 600, letterSpacing: "0.06em" }}>LILY</span>
              </motion.div>
              <motion.button
                className="border-none cursor-pointer rounded-full flex items-center justify-center shrink-0"
                style={{ width: 20, height: 20, backgroundColor: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.25)", marginBottom: 8 }}
                onClick={() => { setLilyVisible(false); setLilyDismissed(true); }}
                whileTap={{ scale: 0.9 }}
              >
                <X size={10} />
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {/* ═══ RINGS VIEW ═══ */}
          {viewMode === "rings" && (
            <motion.div
              key="rings"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="relative"
              style={{ width: "min(90vw, 90vh, 500px)", height: "min(90vw, 90vh, 500px)" }}
            >
              <svg viewBox={`0 0 ${svgSize} ${svgSize}`} className="w-full h-full" style={{ overflow: "visible" }}>
                <defs>
                  {DIMENSIONS.map((_, i) => (
                    <filter key={`glow-${i}`} id={`glow-${i}`} x="-50%" y="-50%" width="200%" height="200%">
                      <feGaussianBlur stdDeviation="3" result="blur" />
                      <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                  ))}
                  <filter id="present-glow" x="-100%" y="-100%" width="300%" height="300%">
                    <feGaussianBlur stdDeviation="8" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="seed-glow" x="-100%" y="-100%" width="300%" height="300%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="ora-glow" x="-100%" y="-100%" width="300%" height="300%">
                    <feGaussianBlur stdDeviation="6" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="planet-glow" x="-200%" y="-200%" width="500%" height="500%">
                    <feGaussianBlur stdDeviation="5" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <radialGradient id="encounter-bloom">
                    <stop offset="0%" stopColor="#E8177F" stopOpacity="0.6" />
                    <stop offset="40%" stopColor="#9263A6" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#000" stopOpacity="0" />
                  </radialGradient>
                </defs>

                {/* 24h outer ring */}
                <circle cx={cx} cy={cy} r={outerRing} fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth={0.5} />

                {/* ─── HOURS (bigger numbers, all 24) ─── */}
                {Array.from({ length: 24 }, (_, i) => {
                  const a = (i / 24) * 360 - 90;
                  const rad = (a * Math.PI) / 180;
                  const r1 = outerRing - 4;
                  const isH6 = i % 6 === 0;
                  const isH3 = i % 3 === 0;
                  const tickLen = isH6 ? 10 : isH3 ? 6 : 3;
                  const r2 = outerRing + tickLen;
                  return (
                    <g key={i}>
                      <line
                        x1={cx + Math.cos(rad) * r1} y1={cy + Math.sin(rad) * r1}
                        x2={cx + Math.cos(rad) * r2} y2={cy + Math.sin(rad) * r2}
                        stroke={isH6 ? "rgba(255,255,255,0.15)" : isH3 ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.03)"}
                        strokeWidth={isH6 ? 1.2 : 0.5}
                      />
                      {/* Show all hours, bigger for 0/6/12/18 */}
                      <text
                        x={cx + Math.cos(rad) * (outerRing + tickLen + (isH6 ? 12 : 10))}
                        y={cy + Math.sin(rad) * (outerRing + tickLen + (isH6 ? 12 : 10))}
                        fill={isH6 ? "rgba(255,255,255,0.35)" : isH3 ? "rgba(255,255,255,0.15)" : "rgba(255,255,255,0.07)"}
                        fontSize={isH6 ? 14 : isH3 ? 10 : 7}
                        fontWeight={isH6 ? 600 : 400}
                        fontFamily="Inter"
                        textAnchor="middle" dominantBaseline="central"
                      >
                        {i}
                      </text>
                    </g>
                  );
                })}

                {/* 5 dimension rings (circles) */}
                {DIMENSIONS.map((dim, i) => {
                  const r = ringRadii[i] + breathe(i, time);
                  return (
                    <g key={dim.id}>
                      <circle cx={cx} cy={cy} r={r} fill="none" stroke={dim.color}
                        strokeWidth={hoveredDim === i ? 2.5 : 1.2}
                        strokeOpacity={hoveredDim === i ? 0.5 : 0.15}
                        filter={`url(#glow-${i})`}
                      />
                      <circle cx={cx} cy={cy} r={r} fill="none" stroke={dim.color}
                        strokeWidth={hoveredDim === i ? 1.8 : 0.8}
                        strokeOpacity={hoveredDim === i ? 0.8 : 0.3}
                        style={{ transition: "stroke-width 0.5s, stroke-opacity 0.5s" }}
                      />
                    </g>
                  );
                })}

                {/* ─── PLANET ALIGNMENT (5 dots, vertical center) ─── */}
                {DIMENSIONS.map((dim, i) => {
                  // Unaligned: on their ring at a spread angle
                  const spreadAngle = ((i * 72 + 40 - 90) * Math.PI) / 180;
                  const unalignedX = cx + Math.cos(spreadAngle) * ringRadii[i];
                  const unalignedY = cy + Math.sin(spreadAngle) * ringRadii[i];
                  // Aligned: vertical column at cx
                  const alignedX = cx;
                  const alignedY = planetAlignedY[i];

                  const px = planetsAligned ? alignedX : unalignedX;
                  const py = planetsAligned ? alignedY : unalignedY;
                  const pr = dim.radius;

                  return (
                    <g key={`planet-${i}`}>
                      {/* Glow halo */}
                      <circle cx={px} cy={py} r={pr * 3}
                        fill={dim.color} opacity={0.06}
                        filter="url(#planet-glow)"
                        style={{ transition: "cx 3s ease-in-out, cy 3s ease-in-out" }}
                      />
                      {/* Planet body */}
                      <circle cx={px} cy={py} r={pr}
                        fill={dim.color} opacity={0.85}
                        style={{ transition: "cx 3s ease-in-out, cy 3s ease-in-out" }}
                      />
                      {/* Subtle inner highlight */}
                      <circle cx={px - pr * 0.25} cy={py - pr * 0.25} r={pr * 0.4}
                        fill="rgba(255,255,255,0.25)"
                        style={{ transition: "cx 3s ease-in-out, cy 3s ease-in-out" }}
                      />
                    </g>
                  );
                })}

                {/* Alignment axis line (fades in when aligned) */}
                {planetsAligned && (
                  <line
                    x1={cx} y1={planetAlignedY[0] - 15}
                    x2={cx} y2={planetAlignedY[4] + 15}
                    stroke="rgba(255,255,255,0.04)" strokeWidth={0.5}
                    strokeDasharray="4 4"
                  />
                )}

                {/* ─── TIME NEEDLE (thick) ─── */}
                <line x1={cx} y1={cy} x2={timeX} y2={timeY}
                  stroke="rgba(255,255,255,0.06)" strokeWidth={5} strokeLinecap="round"
                />
                <line x1={cx} y1={cy} x2={timeX} y2={timeY}
                  stroke="rgba(255,255,255,0.55)" strokeWidth={3} strokeLinecap="round"
                />
                <circle cx={timeX} cy={timeY} r={5}
                  fill="#fff" opacity={0.6 + Math.sin(time * 2) * 0.2}
                  filter="url(#present-glow)"
                />
                {/* Hub */}
                <circle cx={cx} cy={cy} r={7} fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.2)" strokeWidth={1} />

                {/* ─── ORA NEEDLE ─── */}
                {oraPhase !== "off" && oraData && (
                  <g>
                    <line x1={cx} y1={cy} x2={oraX} y2={oraY}
                      stroke={oraData.color} strokeWidth={6} strokeLinecap="round"
                      opacity={0.08 + Math.sin(time * 1.2) * 0.04}
                      filter="url(#ora-glow)"
                    />
                    <line x1={cx} y1={cy} x2={oraX} y2={oraY}
                      stroke={oraData.color} strokeWidth={1.8} strokeLinecap="round"
                      opacity={0.7}
                      strokeDasharray={oraPhase === "ressentir" ? "8 4" : "none"}
                    />
                    {/* Tip */}
                    <circle cx={oraX} cy={oraY} r={7 + Math.sin(time * 1.5) * 2}
                      fill="none" stroke={oraData.color} strokeWidth={1}
                      opacity={0.5 + Math.sin(time * 1.2) * 0.3}
                    />
                    <circle cx={oraX} cy={oraY} r={3} fill={oraData.color} opacity={0.8} />
                    <text x={oraX} y={oraY - 14} fill={oraData.color}
                      fontSize={9} fontWeight="700" textAnchor="middle" dominantBaseline="central"
                      opacity={0.8} letterSpacing="0.1em"
                    >
                      {oraData.letter}
                    </text>

                    {/* If lastStitch exists, show pierce indicator at target */}
                    {lastStitch && oraPhase !== "off" && (
                      <g>
                        <rect
                          x={oraX - 8} y={oraY - 8} width={16} height={16}
                          fill="none" stroke={oraData.color} strokeWidth={1}
                          opacity={0.4 + Math.sin(time * 2) * 0.2}
                          rx={2}
                        />
                        <text x={oraX} y={oraY + 24} fill={oraData.color}
                          fontSize={7} textAnchor="middle" opacity={0.5}
                        >
                          ({lastStitch.x},{lastStitch.y})
                        </text>
                      </g>
                    )}
                  </g>
                )}

                {/* Center heart */}
                <circle cx={cx} cy={cy} r={28} fill="rgba(232,23,127,0.04)" stroke="rgba(232,23,127,0.1)" strokeWidth={0.5} />
                <circle cx={cx} cy={cy} r={14} fill="rgba(232,23,127,0.06)" />
                <text x={cx} y={cy + 1} fill={HEART_RED} fontSize={16}
                  textAnchor="middle" dominantBaseline="central"
                  style={{ opacity: 0.6 + Math.sin(time * 0.8) * 0.3 }}
                >♥</text>

                {/* Seeds */}
                {seeds.map((seed) => {
                  const a = ((seed.angle - 90) * Math.PI) / 180;
                  const r = ringRadii[seed.dimension] + breathe(seed.dimension, time);
                  const sx = cx + Math.cos(a) * r;
                  const sy = cy + Math.sin(a) * r;
                  const isSelected = selectedSeed === seed.id;
                  const dimColor = DIMENSIONS[seed.dimension].color;
                  const pulse = Math.sin(time * (seed.state === "encounter" ? 1.2 : 2.5) + seed.phase);
                  const baseOp = seed.state === "dormant" ? 0.15 : seed.state === "recognition" ? 0.4 : 0.7;
                  const op = baseOp + pulse * (seed.state === "dormant" ? 0.1 : 0.2);
                  const dotR = seed.state === "encounter" ? 4 + pulse * 1.5 : seed.state === "recognition" ? 2.5 + pulse * 0.8 : 1.5;
                  const oraHighlight = oraPhase === "ressentir" && (seed.state === "encounter" || seed.state === "recognition");
                  const oraAction = oraPhase === "agir" && seed.state === "encounter";
                  return (
                    <g key={seed.id} onClick={() => handleSeedClick(seed.id)} style={{ cursor: "pointer" }}>
                      {seed.state === "encounter" && (
                        <circle cx={sx} cy={sy} r={12 + Math.sin(time * 0.8 + seed.phase) * 4} fill="url(#encounter-bloom)" opacity={0.5 + pulse * 0.3} />
                      )}
                      {oraHighlight && (
                        <circle cx={sx} cy={sy} r={18 + Math.sin(time * 0.7) * 4}
                          fill="none" stroke={ORA_PHASES.ressentir.color} strokeWidth={0.8}
                          opacity={0.3 + Math.sin(time * 1.5 + seed.phase) * 0.2}
                        />
                      )}
                      {oraAction && (
                        <circle cx={sx} cy={sy} r={20}
                          fill="none" stroke={ORA_PHASES.agir.color}
                          strokeWidth={1.5} opacity={0.6 + Math.sin(time * 2) * 0.3}
                          strokeDasharray="3 2"
                        />
                      )}
                      <circle cx={sx} cy={sy} r={isSelected ? dotR * 1.5 : dotR} fill={dimColor} opacity={op} filter="url(#seed-glow)" />
                      {seed.state === "recognition" && pulse > 0.5 && (
                        <circle cx={sx} cy={sy} r={6} fill="none" stroke={dimColor} strokeWidth={0.3} opacity={0.3} />
                      )}
                      {isSelected && (
                        <circle cx={sx} cy={sy} r={16} fill="none" stroke={dimColor} strokeWidth={0.5} opacity={0.4 + pulse * 0.2} strokeDasharray="2 3" />
                      )}
                    </g>
                  );
                })}

                {/* Signature vibratoire */}
                {DIMENSIONS.map((dim, i) => {
                  const baseAngle = i * 72 - 90;
                  const rad = (baseAngle * Math.PI) / 180;
                  const sigR = 45 + Math.sin(time * 0.4 + i * 1.3) * 5;
                  const x = cx + Math.cos(rad) * sigR;
                  const y = cy + Math.sin(rad) * sigR;
                  const sz = 2 + Math.sin(time * 0.6 + i * 0.9) * 1;
                  return <circle key={`sig-${i}`} cx={x} cy={y} r={sz} fill={dim.color} opacity={0.25 + Math.sin(time * 0.5 + i) * 0.15} />;
                })}
              </svg>
            </motion.div>
          )}

          {/* ═══ GRID MAP VIEW ═══ */}
          {viewMode === "grid" && (
            <motion.div
              key="grid" className="relative"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              style={{ width: VISIBLE_COLS * GRID_CELL, height: VISIBLE_ROWS * GRID_CELL }}
            >
              {Array.from({ length: VISIBLE_ROWS }, (_, row) =>
                Array.from({ length: VISIBLE_COLS }, (_, col) => {
                  const wx = cursor.x - halfCols + col;
                  const wy = cursor.y - halfRows + row;
                  const key = `${wx},${wy}`;
                  const seed = seedsByPos[key];
                  const isCenter = col === halfCols && row === halfRows;
                  const isOrigin = wx === 0 && wy === 0;
                  const isLastStitch = lastStitch && wx === lastStitch.x && wy === lastStitch.y;
                  return (
                    <div key={key} className="absolute" style={{
                      left: col * GRID_CELL, top: row * GRID_CELL,
                      width: GRID_CELL, height: GRID_CELL,
                      border: isLastStitch ? `2px solid ${HEART_RED}60` : "1px solid rgba(255,255,255,0.03)",
                      backgroundColor: isLastStitch ? "rgba(232,23,127,0.1)"
                        : isCenter ? "rgba(232,23,127,0.06)"
                        : seed ? `${DIMENSIONS[seed.dimension].color}08` : "rgba(0,0,0,0)",
                      transition: "background-color 0.2s",
                    }}>
                      {isOrigin && !seed && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: `${HEART_RED}30` }} />
                        </div>
                      )}
                      {isLastStitch && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span style={{ fontSize: 12, color: HEART_RED, opacity: 0.7 }}>✚</span>
                        </div>
                      )}
                      {seed && !isLastStitch && (
                        <motion.div
                          className="absolute inset-1 rounded-md flex items-center justify-center cursor-pointer"
                          style={{
                            backgroundColor: DIMENSIONS[seed.dimension].color,
                            opacity: seed.state === "encounter" ? 0.8 : seed.state === "recognition" ? 0.5 : 0.2,
                            boxShadow: seed.state === "encounter" ? `0 0 12px ${DIMENSIONS[seed.dimension].color}60` : "none",
                          }}
                          animate={seed.state === "encounter" ? { scale: [1, 1.05, 1], opacity: [0.7, 0.9, 0.7] } : {}}
                          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                          onClick={() => handleSeedClick(seed.id)}
                        >
                          <span style={{ fontSize: 14, color: "#fff", opacity: 0.9 }}>
                            {seed.state === "encounter" ? "♥" : seed.state === "recognition" ? "+" : "·"}
                          </span>
                        </motion.div>
                      )}
                      {isCenter && (
                        <motion.div
                          className="absolute inset-0 pointer-events-none rounded-sm"
                          style={{ border: `2px solid ${HEART_RED}60`, boxShadow: `0 0 16px ${HEART_RED}20, inset 0 0 8px ${HEART_RED}08` }}
                          animate={{ opacity: [0.6, 1, 0.6] }}
                          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                        />
                      )}
                      {wx % 8 === 0 && wy % 8 === 0 && (
                        <span className="absolute pointer-events-none"
                          style={{ top: 2, left: 3, fontSize: 6, color: "rgba(255,255,255,0.08)", fontVariantNumeric: "tabular-nums" }}
                        >{wx},{wy}</span>
                      )}
                    </div>
                  );
                })
              )}
              <div className="absolute pointer-events-none"
                style={{ bottom: -28, left: "50%", transform: "translateX(-50%)", fontSize: 10, color: "rgba(255,255,255,0.25)", fontVariantNumeric: "tabular-nums", letterSpacing: "0.08em" }}
              >
                ♥ {cursor.x},{cursor.y}
                {lastStitch && <span style={{ color: HEART_RED, marginLeft: 12 }}>✚ dernier : ({lastStitch.x},{lastStitch.y})</span>}
              </div>
              <div className="absolute pointer-events-none flex items-center gap-4"
                style={{ bottom: -52, left: "50%", transform: "translateX(-50%)", fontSize: 9, color: "rgba(255,255,255,0.12)", letterSpacing: "0.06em" }}
              >
                <span>fleches pour naviguer</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══ RIGHT PANEL: ORA Guide ═══ */}
        {viewMode === "rings" && (
          <motion.div
            className="absolute z-20 flex flex-col gap-2"
            style={{ top: 16, right: 16 }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }}
          >
            <motion.button
              className="flex items-center gap-2 border-none cursor-pointer rounded-xl px-4 py-2.5"
              style={{
                backgroundColor: oraPhase === "off" ? "rgba(255,255,255,0.04)" : `${oraData!.color}15`,
                color: oraPhase === "off" ? "rgba(255,255,255,0.35)" : oraData!.color,
                fontSize: 11, fontWeight: 600, letterSpacing: "0.06em",
                border: oraPhase === "off" ? "1px solid rgba(255,255,255,0.06)" : `1px solid ${oraData!.color}30`,
              }}
              onClick={toggleOra}
              whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
            >
              <Navigation size={13} style={{ transform: oraPhase !== "off" ? `rotate(${oraAngle}deg)` : undefined, transition: "transform 0.5s" }} />
              {oraPhase === "off" ? "Guide ORA" : oraData!.label}
              {lastStitch && oraPhase === "off" && <span style={{ fontSize: 8, opacity: 0.5, marginLeft: 2 }}>✚</span>}
            </motion.button>
          </motion.div>
        )}

        {/* ═══ ORA PHASE PANEL ═══ */}
        <AnimatePresence>
          {oraPhase !== "off" && oraData && viewMode === "rings" && (
            <motion.div
              className="absolute z-20 rounded-2xl px-5 py-4"
              style={{
                bottom: "clamp(70px, 10vh, 100px)", left: "50%", transform: "translateX(-50%)",
                backgroundColor: "rgba(10,10,18,0.92)",
                border: `1px solid ${oraData.color}25`,
                backdropFilter: "blur(20px)", maxWidth: 340, width: "90vw",
              }}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.5 }}
            >
              {/* O R A stepper */}
              <div className="flex items-center gap-2 mb-4">
                {ORA_ORDER.map((p) => {
                  const d = ORA_PHASES[p];
                  const active = p === oraPhase;
                  const done = ORA_ORDER.indexOf(p) < ORA_ORDER.indexOf(oraPhase as any);
                  return (
                    <div key={p} className="flex items-center gap-2">
                      <motion.div
                        className="flex items-center justify-center rounded-full"
                        style={{
                          width: 28, height: 28,
                          backgroundColor: active ? `${d.color}20` : done ? `${d.color}10` : "rgba(255,255,255,0.03)",
                          border: active ? `1.5px solid ${d.color}60` : "1px solid rgba(255,255,255,0.06)",
                        }}
                        animate={active ? { scale: [1, 1.08, 1] } : {}}
                        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      >
                        <span style={{
                          fontSize: 11, fontWeight: 700, letterSpacing: "0.05em",
                          color: active ? d.color : done ? `${d.color}60` : "rgba(255,255,255,0.15)",
                        }}>{d.letter}</span>
                      </motion.div>
                      {p !== "agir" && (
                        <div style={{
                          width: 20, height: 1,
                          backgroundColor: done ? `${ORA_PHASES[ORA_ORDER[ORA_ORDER.indexOf(p) + 1]].color}30` : "rgba(255,255,255,0.06)",
                        }} />
                      )}
                    </div>
                  );
                })}
                {/* Last stitch badge */}
                {lastStitch && (
                  <div className="ml-auto flex items-center gap-1" style={{ fontSize: 9, color: `${oraData.color}80` }}>
                    <span>✚</span>
                    <span>({lastStitch.x},{lastStitch.y})</span>
                  </div>
                )}
              </div>

              <div className="flex items-start gap-3 mb-3">
                {(() => {
                  const Icon = oraData.icon;
                  return (
                    <div className="rounded-lg flex items-center justify-center shrink-0" style={{ width: 36, height: 36, backgroundColor: `${oraData.color}12` }}>
                      <Icon size={18} style={{ color: oraData.color }} />
                    </div>
                  );
                })()}
                <div>
                  <span style={{ fontSize: 13, fontWeight: 600, color: oraData.color }}>
                    {oraData.letter} — {oraData.label}
                  </span>
                  <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 4, lineHeight: 1.5 }}>
                    {lastStitch
                      ? oraPhase === "observer"
                        ? `Observe ta toile... ton dernier point est en (${lastStitch.x}, ${lastStitch.y}).`
                        : oraPhase === "ressentir"
                        ? "Sens le fil... la couleur, la texture, la direction qui t'appelle."
                        : `Reprends ton aiguille au point (${lastStitch.x}, ${lastStitch.y}). L'action vient naturellement.`
                      : oraData.desc}
                  </p>
                </div>
              </div>

              <div className="rounded-lg px-3 py-2 mb-3" style={{ backgroundColor: `${oraData.color}06`, border: `1px solid ${oraData.color}10` }}>
                <p style={{ fontSize: 10, color: `${oraData.color}90`, fontStyle: "italic", lineHeight: 1.4 }}>
                  &laquo; {oraData.psycho} &raquo;
                </p>
              </div>

              <motion.button
                className="w-full rounded-xl border-none cursor-pointer py-2.5 flex items-center justify-center gap-2"
                style={{ backgroundColor: `${oraData.color}15`, color: oraData.color, fontSize: 11, fontWeight: 600 }}
                onClick={toggleOra}
                whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              >
                {oraPhase === "agir"
                  ? (lastStitch ? "Reprendre la broderie" : "Terminer")
                  : `Suivant : ${ORA_PHASES[ORA_ORDER[ORA_ORDER.indexOf(oraPhase as any) + 1]].label}`}
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Seed info panel (rings) */}
        <AnimatePresence>
          {selectedSeedData && oraPhase === "off" && viewMode === "rings" && (
            <motion.div
              className="absolute z-20 px-5 py-4 rounded-2xl"
              style={{
                bottom: "clamp(70px, 12vh, 100px)", left: "50%", transform: "translateX(-50%)",
                backgroundColor: "rgba(10,10,18,0.9)",
                border: `1px solid ${DIMENSIONS[selectedSeedData.dimension].color}20`,
                backdropFilter: "blur(20px)", maxWidth: 280, width: "90vw",
              }}
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: DIMENSIONS[selectedSeedData.dimension].color, boxShadow: `0 0 8px ${DIMENSIONS[selectedSeedData.dimension].color}60` }} />
                <span style={{ fontSize: 10, color: DIMENSIONS[selectedSeedData.dimension].color, fontWeight: 600, letterSpacing: "0.1em" }}>
                  {DIMENSIONS[selectedSeedData.dimension].id} {DIMENSIONS[selectedSeedData.dimension].label.toUpperCase()}
                </span>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <span style={{
                  fontSize: 9, padding: "2px 8px", borderRadius: 6,
                  backgroundColor: selectedSeedData.state === "encounter" ? "rgba(232,23,127,0.15)" : selectedSeedData.state === "recognition" ? "rgba(232,168,56,0.15)" : "rgba(255,255,255,0.05)",
                  color: selectedSeedData.state === "encounter" ? "#E8177F" : selectedSeedData.state === "recognition" ? "#E8A838" : "rgba(255,255,255,0.3)",
                  fontWeight: 500,
                }}>
                  {selectedSeedData.state === "encounter" ? "Rencontre" : selectedSeedData.state === "recognition" ? "Reconnaissance" : "Dormante"}
                </span>
              </div>
              <p style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", lineHeight: 1.6 }}>
                {selectedSeedData.state === "encounter"
                  ? "Deux signatures ont converge. Le temps se suspend."
                  : selectedSeedData.state === "recognition"
                  ? "Une presence percue. Clignotement discret."
                  : "Graine temporelle en sommeil."}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Seed info panel (grid) */}
        <AnimatePresence>
          {selectedSeedData && viewMode === "grid" && (
            <motion.div
              className="absolute z-20 px-4 py-3 rounded-xl"
              style={{
                top: 16, right: 16,
                backgroundColor: "rgba(10,10,18,0.9)",
                border: `1px solid ${DIMENSIONS[selectedSeedData.dimension].color}20`,
                backdropFilter: "blur(20px)", maxWidth: 220,
              }}
              initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: DIMENSIONS[selectedSeedData.dimension].color }} />
                <span style={{ fontSize: 9, color: DIMENSIONS[selectedSeedData.dimension].color, fontWeight: 600, letterSpacing: "0.08em" }}>
                  {DIMENSIONS[selectedSeedData.dimension].label.toUpperCase()}
                </span>
              </div>
              <span style={{
                fontSize: 8, padding: "1px 6px", borderRadius: 4,
                backgroundColor: selectedSeedData.state === "encounter" ? "rgba(232,23,127,0.15)" : "rgba(255,255,255,0.05)",
                color: selectedSeedData.state === "encounter" ? "#E8177F" : "rgba(255,255,255,0.3)",
              }}>
                {selectedSeedData.state === "encounter" ? "Rencontre" : selectedSeedData.state === "recognition" ? "Reconnaissance" : "Dormante"}
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ═══ BOTTOM ═══ */}
      <motion.div
        className="relative z-10 px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2 }}
      >
        {/* Dimension legend */}
        <div className="flex items-center justify-center gap-1 mb-3">
          {DIMENSIONS.map((dim, i) => (
            <motion.button
              key={dim.id}
              className="flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl border-none cursor-pointer"
              style={{ backgroundColor: hoveredDim === i ? `${dim.color}12` : "rgba(0,0,0,0)", minWidth: 55 }}
              onMouseEnter={() => setHoveredDim(i)}
              onMouseLeave={() => setHoveredDim(null)}
              onClick={() => setHoveredDim(hoveredDim === i ? null : i)}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div className="rounded-full"
                style={{
                  width: hoveredDim === i ? 24 : 16, height: 3,
                  backgroundColor: dim.color,
                  opacity: hoveredDim === i ? 0.9 : 0.4,
                  boxShadow: hoveredDim === i ? `0 0 8px ${dim.color}40` : "none",
                }}
                animate={{ width: hoveredDim === i ? 24 : 16, opacity: hoveredDim === i ? 0.9 : 0.4 }}
                transition={{ duration: 0.3 }}
              />
              <span style={{ fontSize: 7, color: hoveredDim === i ? dim.color : "rgba(255,255,255,0.2)", fontWeight: 500, letterSpacing: "0.06em", transition: "color 0.3s" }}>
                {dim.id}
              </span>
            </motion.button>
          ))}
        </div>

        {/* Jung quote */}
        <motion.div
          className="text-center mb-3 px-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
        >
          <p style={{ fontSize: "clamp(8px, 1.5vw, 10px)", color: "rgba(255,255,255,0.15)", fontStyle: "italic", lineHeight: 1.7, maxWidth: 400, margin: "0 auto" }}>
            « Tant que vous ne rendrez pas l'inconscient conscient,
            il dirigera votre vie et vous appellerez cela le destin. »
          </p>
          <p style={{ fontSize: 8, color: "rgba(255,255,255,0.08)", marginTop: 3, letterSpacing: "0.06em" }}>
            — Carl Gustav Jung
          </p>
        </motion.div>

        <motion.div className="flex items-center justify-center gap-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.8 }}>
          <div className="flex items-center gap-2">
            <span style={{ fontSize: 8, color: "rgba(255,255,255,0.08)", letterSpacing: "0.08em" }}>5D</span>
            <span style={{ fontSize: 7, color: "rgba(255,255,255,0.05)" }}>&times;</span>
            <span style={{ fontSize: 8, color: "rgba(255,255,255,0.08)" }}>4 choix</span>
            <span style={{ fontSize: 7, color: "rgba(255,255,255,0.05)" }}>=</span>
            <span style={{ fontSize: 9, fontWeight: 600, background: "linear-gradient(135deg, #E8177F, #9263A6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "rgba(0,0,0,0)" }}>1024</span>
            <span style={{ fontSize: 8, color: "rgba(255,255,255,0.08)" }}>signatures</span>
          </div>
          <div className="w-px h-3" style={{ backgroundColor: "rgba(255,255,255,0.04)" }} />
          <span style={{ fontSize: 7, color: "rgba(255,255,255,0.06)", letterSpacing: "0.1em" }}>
            ORA &middot; OBSERVER &middot; RESSENTIR &middot; AGIR
          </span>
        </motion.div>
        <p className="text-center mt-1" style={{ fontSize: 7, color: "rgba(255,255,255,0.04)", letterSpacing: "0.15em" }}>
          CONCEPT 2003 &middot; BREVET EN COURS D'ETUDE
        </p>
      </motion.div>
    </div>
  );
}
