import { motion } from "motion/react";
import { HEART_RED } from "./game-data";

interface PlayerSquareProps {
  colorHex: string;
  symbol: string;
  symbol2?: string; // superposed second symbol
  symbolSize?: number;
  symbolRotation?: number;
  symbolContrast?: number;
  size?: number;
  isCurrentPlayer?: boolean;
  isBonus?: boolean;
  isTrail?: boolean;
  isPulse?: boolean; // heartbeat/sortie pulse
  pulseColor?: string;
  glowing?: boolean;
  onClick?: () => void;
  mode?: "default" | "child" | "senior" | "accessibility";
}

export function PlayerSquare({
  colorHex,
  symbol,
  symbol2,
  symbolSize = 50,
  symbolRotation = 0,
  symbolContrast = 100,
  size = 48,
  isCurrentPlayer = false,
  isBonus = false,
  isTrail = false,
  isPulse = false,
  pulseColor,
  glowing = false,
  onClick,
  mode = "default",
}: PlayerSquareProps) {
  const r = parseInt(colorHex.slice(1, 3), 16);
  const g = parseInt(colorHex.slice(3, 5), 16);
  const b = parseInt(colorHex.slice(5, 7), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  const symbolColor = brightness > 128 ? "#1a1a1a" : "#ffffff";

  const fontSizeScale = symbolSize / 50;
  const actualFontSize = size * 0.45 * fontSizeScale;
  const highContrast = mode === "accessibility" || mode === "child";

  // Trail variant: faded ghost
  if (isTrail) {
    return (
      <div className="relative select-none" style={{ width: size, height: size, opacity: 0.18 }}>
        <div
          className="absolute inset-[15%] rounded-[1px]"
          style={{ backgroundColor: colorHex, border: "1px solid rgba(0,0,0,0.03)" }}
        />
      </div>
    );
  }

  // Pulse variant: heartbeat sortie on grid
  if (isPulse) {
    const pc = pulseColor || HEART_RED;
    return (
      <motion.div
        className="relative cursor-pointer select-none"
        style={{ width: size, height: size }}
        onClick={onClick}
        whileHover={onClick ? { scale: 1.12 } : {}}
        whileTap={onClick ? { scale: 0.92 } : {}}
      >
        {/* Pulse rings */}
        <motion.div
          className="absolute inset-[-6px] rounded-[6px]"
          style={{ border: `1.5px solid ${pc}` }}
          animate={{ opacity: [0.15, 0.5, 0.15], scale: [1, 1.08, 1] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute inset-[-12px] rounded-[8px]"
          style={{ border: `1px solid ${pc}` }}
          animate={{ opacity: [0.05, 0.2, 0.05], scale: [1, 1.05, 1] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
        />
        {/* Core square */}
        <div
          className="absolute inset-0 rounded-[2px]"
          style={{
            backgroundColor: colorHex,
            border: `1.5px solid ${pc}40`,
            boxShadow: `0 0 12px 2px ${pc}25`,
          }}
        />
        {/* Symbol */}
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{ fontSize: actualFontSize * 0.85, color: symbolColor, lineHeight: 1, opacity: 0.8 }}
        >
          {symbol}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      className="relative cursor-pointer select-none"
      style={{ width: size, height: size }}
      onClick={onClick}
      whileHover={onClick ? { scale: 1.08 } : {}}
      whileTap={onClick ? { scale: 0.94 } : {}}
    >
      {/* Background square */}
      <div
        className="absolute inset-0 rounded-[2px]"
        style={{
          backgroundColor: colorHex,
          border: highContrast
            ? `2px solid ${brightness > 128 ? "#000" : "#fff"}`
            : isCurrentPlayer
            ? "2px solid rgba(0,0,0,0.25)"
            : "1px solid rgba(0,0,0,0.06)",
          boxShadow: glowing
            ? `0 0 14px 4px ${colorHex}70, 0 0 28px 8px ${colorHex}30`
            : isCurrentPlayer
            ? "0 2px 12px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.04)"
            : "none",
        }}
      >
        {/* Cross-stitch texture */}
        <svg
          className="absolute inset-0 w-full h-full"
          style={{ opacity: 0.06 }}
          viewBox="0 0 4 4"
          preserveAspectRatio="none"
        >
          <line x1="0" y1="0" x2="4" y2="4" stroke={symbolColor} strokeWidth="0.12" />
          <line x1="4" y1="0" x2="0" y2="4" stroke={symbolColor} strokeWidth="0.12" />
          <line x1="2" y1="0" x2="2" y2="4" stroke={symbolColor} strokeWidth="0.06" />
          <line x1="0" y1="2" x2="4" y2="2" stroke={symbolColor} strokeWidth="0.06" />
        </svg>
      </div>

      {/* Primary symbol */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{
          fontSize: actualFontSize,
          color: symbolColor,
          opacity: symbolContrast / 100,
          transform: `rotate(${symbolRotation}deg)`,
          lineHeight: 1,
          filter: isBonus ? "drop-shadow(0 0 4px rgba(255,215,0,0.5))" : "none",
        }}
      >
        {symbol}
      </div>

      {/* Superposed second symbol */}
      {symbol2 && (
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{
            fontSize: actualFontSize * 0.55,
            color: symbolColor,
            opacity: (symbolContrast / 100) * 0.5,
            transform: `rotate(${symbolRotation + 45}deg) translate(30%, -30%)`,
            lineHeight: 1,
          }}
        >
          {symbol2}
        </div>
      )}

      {/* Current player pulse ring */}
      {isCurrentPlayer && (
        <motion.div
          className="absolute inset-[-4px] rounded-[4px]"
          style={{ border: "1px solid rgba(0,0,0,0.08)" }}
          animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.02, 1] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      {/* Glow animation */}
      {glowing && (
        <motion.div
          className="absolute inset-[-4px] rounded-[4px]"
          style={{ border: `1.5px solid ${colorHex}` }}
          animate={{ opacity: [0.2, 0.7, 0.2], scale: [1, 1.06, 1] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
      )}
    </motion.div>
  );
}
