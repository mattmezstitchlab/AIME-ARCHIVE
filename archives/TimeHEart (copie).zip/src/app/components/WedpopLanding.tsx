import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Heart, Users, Calendar, MessageCircle, DollarSign, Bell, Scissors, ChevronRight, Music, Camera, Clock, MapPin } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// ═══════════════════════════════════════════
// WEDPOP — Organisation de Mariage par Lily
// "Lily s'occupe de chaque détail pour que
//  ce jour soit parfait"
// ═══════════════════════════════════════════

const BRAND = {
  purple: "#3D2347",
  purpleLight: "#5A3668",
  gold: "#D4A574",
  goldLight: "#E8C9A0",
  rose: "#C17B8E",
  cream: "#F5EDE4",
  dark: "#1A0F20",
};

const FEATURES = [
  { icon: Users, label: "Gestion des couples", desc: "Suivi personnalisé de chaque couple, du premier contact au jour J" },
  { icon: Calendar, label: "Agenda intelligent", desc: "Lily planifie et rappelle chaque étape automatiquement" },
  { icon: DollarSign, label: "Budget en temps réel", desc: "Visualisation claire, alertes de dépassement, suggestions d'économie" },
  { icon: MessageCircle, label: "Lily Chat", desc: "Votre assistante IA disponible 24/7 pour chaque question" },
  { icon: Bell, label: "Rappels proactifs", desc: "Plus aucun oubli — Lily anticipe les échéances" },
  { icon: Scissors, label: "Prestataires libérés", desc: "Interface unique qui libère tous les prestataires, de A à Z" },
];

interface WedpopLandingProps {
  onBack?: () => void;
  onNavigate?: (screen: string) => void;
}

export function WedpopLanding({ onBack }: WedpopLandingProps) {
  const [currentSection, setCurrentSection] = useState(0);
  const [countdown, setCountdown] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  // Live countdown to April 10, 2026
  useEffect(() => {
    const target = new Date("2026-04-10T14:00:00");
    const tick = () => {
      const now = new Date();
      const diff = Math.max(0, target.getTime() - now.getTime());
      setCountdown({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      className="fixed inset-0 overflow-y-auto overflow-x-hidden"
      style={{
        background: `radial-gradient(ellipse at 30% 20%, ${BRAND.purpleLight}15 0%, rgba(0,0,0,0) 50%),
                     radial-gradient(ellipse at 70% 80%, ${BRAND.rose}10 0%, rgba(0,0,0,0) 50%),
                     linear-gradient(180deg, ${BRAND.dark} 0%, #0D0710 40%, #120A18 100%)`,
        fontFamily: "'Inter', -apple-system, sans-serif",
      }}
    >
      {/* ═══ NAV BAR ═══ */}
      <motion.nav
        className="sticky top-0 z-50 flex items-center justify-between px-6 py-4"
        style={{ backgroundColor: "rgba(26,15,32,0.85)", backdropFilter: "blur(20px)", borderBottom: `1px solid rgba(212,165,116,0.08)` }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="flex items-center gap-4">
          {onBack && (
            <motion.button
              className="flex items-center gap-2 border-none cursor-pointer rounded-lg px-3 py-1.5"
              style={{ backgroundColor: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.4)", fontSize: 11 }}
              onClick={onBack}
              whileTap={{ scale: 0.95 }}
              whileHover={{ backgroundColor: "rgba(255,255,255,0.08)" }}
            >
              <ArrowLeft size={14} />
              Retour
            </motion.button>
          )}
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ backgroundColor: BRAND.gold, color: BRAND.dark, fontSize: 14 }}
            >
              ✦
            </div>
            <div>
              <span style={{ fontSize: 13, fontWeight: 600, color: BRAND.cream, letterSpacing: "0.04em" }}>
                AI+ME
              </span>
              <span style={{ fontSize: 9, color: BRAND.gold, display: "block", letterSpacing: "0.15em", fontWeight: 300, marginTop: -2 }}>
                ✦ LILY
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6" style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
          {["Fonctionnalités", "Comment ça marche", "Témoignages"].map((item) => (
            <span key={item} className="hidden md:inline cursor-pointer hover:text-white/60 transition-colors">{item}</span>
          ))}
          <motion.button
            className="border-none cursor-pointer rounded-lg px-4 py-2 flex items-center gap-2"
            style={{ backgroundColor: BRAND.gold, color: BRAND.dark, fontSize: 11, fontWeight: 600, letterSpacing: "0.04em" }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            Accéder à l'app <ChevronRight size={12} />
          </motion.button>
        </div>
      </motion.nav>

      {/* ═══ HERO: COUNTDOWN ═══ */}
      <section className="min-h-screen flex flex-col items-center justify-center relative px-6">
        {/* Decorative lines */}
        <motion.div
          className="absolute top-1/4 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 0.15, scaleX: 1 }}
          transition={{ delay: 0.5, duration: 1.5 }}
        >
          <div className="flex items-center gap-4">
            <div className="w-16 h-px" style={{ backgroundColor: BRAND.gold }} />
            <Heart size={14} style={{ color: BRAND.gold, opacity: 0.5 }} />
            <div className="w-16 h-px" style={{ backgroundColor: BRAND.gold }} />
          </div>
        </motion.div>

        <motion.p
          style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.3em", fontWeight: 400 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 0.7, y: 0 }}
          transition={{ delay: 0.3, duration: 1 }}
        >
          PROCHAIN GRAND JOUR
        </motion.p>

        <motion.h1
          className="mt-4"
          style={{
            fontSize: "clamp(32px, 6vw, 56px)",
            fontWeight: 300,
            color: BRAND.cream,
            letterSpacing: "0.02em",
            fontStyle: "italic",
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 1 }}
        >
          Camille & Julien
        </motion.h1>

        <motion.p
          className="mt-3 flex items-center gap-2"
          style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", letterSpacing: "0.05em" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 1 }}
        >
          <span style={{ color: BRAND.gold, fontSize: 10 }}>✦</span>
          Villa Ephrussi · 10 avril 2026
          <span style={{ color: BRAND.gold, fontSize: 10 }}>✦</span>
        </motion.p>

        {/* COUNTDOWN CIRCLES */}
        <motion.div
          className="flex items-center gap-4 sm:gap-8 mt-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 1.2 }}
        >
          {[
            { value: countdown.days, label: "JOURS" },
            { value: countdown.hours, label: "HEURES" },
            { value: countdown.minutes, label: "MINUTES" },
            { value: countdown.seconds, label: "SECONDES" },
          ].map((item, i) => (
            <CountdownCircle key={item.label} value={item.value} label={item.label} delay={1 + i * 0.15} />
          ))}
        </motion.div>

        {/* Carousel dots */}
        <motion.div
          className="flex items-center gap-2 mt-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8 }}
        >
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <motion.div
              key={i}
              className="rounded-full cursor-pointer"
              style={{
                width: currentSection === i ? 16 : 6,
                height: 6,
                backgroundColor: i === 0 ? BRAND.rose : i === 1 ? BRAND.gold : "rgba(255,255,255,0.15)",
                borderRadius: 3,
                transition: "all 0.3s",
              }}
              onClick={() => setCurrentSection(i)}
            />
          ))}
        </motion.div>

        <motion.p
          className="mt-6 text-center"
          style={{ fontSize: 12, color: "rgba(255,255,255,0.2)", fontStyle: "italic", maxWidth: 400 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
        >
          Lily s'occupe de chaque détail pour que ce jour soit parfait
        </motion.p>
      </section>

      {/* ═══ SECTION 2: SHOWCASE SCREENSHOTS ═══ */}
      <section className="py-24 px-6">
        <motion.div
          className="max-w-5xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1 }}
        >
          <p className="text-center mb-3" style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.3em" }}>
            L'INTERFACE
          </p>
          <h2
            className="text-center mb-12"
            style={{ fontSize: "clamp(24px, 4vw, 40px)", fontWeight: 300, color: BRAND.cream }}
          >
            Un seul lieu pour tout organiser
          </h2>

          {/* Hero image */}
          <motion.div
            className="rounded-2xl overflow-hidden mb-8 relative"
            style={{
              border: `1px solid rgba(212,165,116,0.12)`,
              boxShadow: `0 40px 80px rgba(0,0,0,0.5), 0 0 60px rgba(212,165,116,0.05)`,
              height: 320,
            }}
            initial={{ opacity: 0, y: 20, scale: 0.98 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1753604147615-b26c00d0874e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwd2VkZGluZyUyMHZlbnVlJTIwZ29sZGVuJTIwbGlnaHRpbmd8ZW58MXx8fHwxNzcwNDc5MDU1fDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Elegant wedding venue"
              className="w-full h-full object-cover"
              style={{ opacity: 0.4 }}
            />
            <div className="absolute inset-0 flex items-center justify-center" style={{ background: "linear-gradient(180deg, rgba(26,15,32,0.3) 0%, rgba(26,15,32,0.8) 100%)" }}>
              <div className="text-center">
                <p style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.2em", marginBottom: 8 }}>TABLEAU DE BORD</p>
                <p style={{ fontSize: 22, color: BRAND.cream, fontWeight: 300, fontStyle: "italic" }}>Camille & Julien</p>
                <div className="flex items-center gap-4 mt-4 justify-center" style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
                  <span className="flex items-center gap-1"><MapPin size={11} /> Villa Ephrussi</span>
                  <span className="flex items-center gap-1"><Calendar size={11} /> 10 Avril 2026</span>
                  <span className="flex items-center gap-1"><Users size={11} /> 127 invités</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Studio & Planning cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Studio card */}
            <motion.div
              className="rounded-2xl overflow-hidden"
              style={{
                border: `1px solid rgba(212,165,116,0.08)`,
                boxShadow: `0 20px 40px rgba(0,0,0,0.4)`,
                backgroundColor: "rgba(255,255,255,0.02)",
              }}
              initial={{ opacity: 0, x: -20, scale: 0.98 }}
              whileInView={{ opacity: 1, x: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="px-4 py-3" style={{ borderBottom: "1px solid rgba(212,165,116,0.06)" }}>
                <p style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.12em", fontWeight: 500 }}>STUDIO CRÉATIF</p>
                <p style={{ fontSize: 9, color: "rgba(255,255,255,0.2)", marginTop: 2 }}>Drag & drop — Photos, vidéos, playlists</p>
              </div>
              <div className="p-4 space-y-3">
                {[
                  { icon: Camera, label: "Photos & Vidéos", count: "48 médias", color: BRAND.rose },
                  { icon: Music, label: "Playlist Soirée", count: "3h42", color: BRAND.gold },
                  { icon: Calendar, label: "Agenda partagé", count: "12 événements", color: "#5A8ED4" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-3 p-3 rounded-xl" style={{ backgroundColor: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.04)" }}>
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${item.color}15` }}>
                      <item.icon size={14} style={{ color: item.color }} />
                    </div>
                    <div className="flex-1">
                      <p style={{ fontSize: 11, color: BRAND.cream }}>{item.label}</p>
                      <p style={{ fontSize: 9, color: "rgba(255,255,255,0.25)" }}>{item.count}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Planning card */}
            <motion.div
              className="rounded-2xl overflow-hidden"
              style={{
                border: `1px solid rgba(212,165,116,0.08)`,
                boxShadow: `0 20px 40px rgba(0,0,0,0.4)`,
                backgroundColor: "rgba(255,255,255,0.02)",
              }}
              initial={{ opacity: 0, x: 20, scale: 0.98 }}
              whileInView={{ opacity: 1, x: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <div className="px-4 py-3" style={{ borderBottom: "1px solid rgba(212,165,116,0.06)" }}>
                <p style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.12em", fontWeight: 500 }}>PLANNING DU JOUR J</p>
                <p style={{ fontSize: 9, color: "rgba(255,255,255,0.2)", marginTop: 2 }}>Timeline interactive</p>
              </div>
              <div className="p-4 space-y-2">
                {[
                  { time: "09:00", label: "Préparatifs", color: BRAND.rose },
                  { time: "14:00", label: "Cérémonie Religieuse", color: BRAND.gold },
                  { time: "16:00", label: "Vin d'honneur", color: "#5A8ED4" },
                  { time: "19:30", label: "Dîner", color: BRAND.gold },
                  { time: "22:30", label: "Soirée Dansante", color: BRAND.rose },
                ].map((event) => (
                  <div key={event.time} className="flex items-center gap-3 py-2">
                    <span style={{ fontSize: 10, color: "rgba(255,255,255,0.25)", width: 42, fontFamily: "monospace" }}>{event.time}</span>
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: event.color }} />
                    <span style={{ fontSize: 11, color: BRAND.cream }}>{event.label}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* ═══ SECTION 3: FEATURES ═══ */}
      <section className="py-24 px-6">
        <motion.div
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <p className="text-center mb-3" style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.3em" }}>
            FONCTIONNALITÉS
          </p>
          <h2
            className="text-center mb-16"
            style={{ fontSize: "clamp(22px, 3.5vw, 36px)", fontWeight: 300, color: BRAND.cream }}
          >
            Lily gère tout. Vous vivez l'instant.
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((feat, i) => (
              <motion.div
                key={feat.label}
                className="rounded-2xl p-6"
                style={{
                  backgroundColor: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(212,165,116,0.06)",
                }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                whileHover={{ backgroundColor: "rgba(212,165,116,0.04)", borderColor: "rgba(212,165,116,0.12)" }}
              >
                <feat.icon size={20} style={{ color: BRAND.gold, marginBottom: 12, opacity: 0.7 }} />
                <h3 style={{ fontSize: 13, fontWeight: 500, color: BRAND.cream, marginBottom: 8 }}>{feat.label}</h3>
                <p style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", lineHeight: 1.7 }}>{feat.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ═══ SECTION 4: PHILOSOPHY ═══ */}
      <section className="py-32 px-6 flex flex-col items-center">
        <motion.div
          className="max-w-lg text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <div
            className="w-16 h-16 mx-auto mb-8 rounded-full flex items-center justify-center"
            style={{ backgroundColor: "rgba(146,99,166,0.1)", border: "1px solid rgba(146,99,166,0.15)" }}
          >
            <Scissors size={22} style={{ color: "#9263A6" }} />
          </div>
          <h2
            style={{ fontSize: "clamp(20px, 3vw, 30px)", fontWeight: 300, color: BRAND.cream, lineHeight: 1.6, marginBottom: 16 }}
          >
            Un mariage ne devrait pas
            <br />
            être un projet à gérer.
          </h2>
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.25)", lineHeight: 1.8, fontStyle: "italic" }}>
            "WEDPOP libère tous les prestataires. Lily orchestre chaque détail —
            budget, planning, invités, rappels — pour que les mariés puissent
            simplement vivre leur histoire."
          </p>
          <motion.div
            className="mt-8 flex items-center gap-2 justify-center"
            style={{ fontSize: 10, color: BRAND.gold, letterSpacing: "0.1em" }}
            animate={{ opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Heart size={10} fill={BRAND.gold} />
            GÉRÉ PAR LILY · AI+ME
          </motion.div>
        </motion.div>
      </section>

      {/* ═══ FOOTER ═══ */}
      <footer className="py-8 px-6 text-center" style={{ borderTop: "1px solid rgba(212,165,116,0.05)" }}>
        <p style={{ fontSize: 8, color: "rgba(255,255,255,0.08)", letterSpacing: "0.15em" }}>
          WEDPOP · AI+ME · LILY · CONCEPT 2025
        </p>
      </footer>
    </div>
  );
}

// ─── COUNTDOWN CIRCLE COMPONENT ───
function CountdownCircle({ value, label, delay }: { value: number; label: string; delay: number }) {
  const displayValue = String(value).padStart(2, "0");
  const circumference = 2 * Math.PI * 52;
  const maxVal = label === "JOURS" ? 365 : label === "HEURES" ? 24 : 60;
  const progress = value / maxVal;
  const strokeOffset = circumference * (1 - progress);

  return (
    <motion.div
      className="flex flex-col items-center gap-3"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.8 }}
    >
      <div className="relative" style={{ width: "clamp(80px, 18vw, 120px)", height: "clamp(80px, 18vw, 120px)" }}>
        <svg viewBox="0 0 120 120" className="w-full h-full">
          {/* Background circle */}
          <circle
            cx="60" cy="60" r="52"
            fill="none"
            stroke="rgba(212,165,116,0.08)"
            strokeWidth="1"
          />
          {/* Progress arc */}
          <motion.circle
            cx="60" cy="60" r="52"
            fill="none"
            stroke={BRAND.gold}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeOffset}
            style={{ transform: "rotate(-90deg)", transformOrigin: "60px 60px", opacity: 0.5 }}
            animate={{ strokeDashoffset: strokeOffset }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
          {/* Outer subtle ring */}
          <circle
            cx="60" cy="60" r="56"
            fill="none"
            stroke="rgba(212,165,116,0.04)"
            strokeWidth="0.5"
          />
        </svg>
        {/* Number */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span
            style={{
              fontSize: "clamp(24px, 6vw, 38px)",
              fontWeight: 300,
              color: BRAND.goldLight,
              fontStyle: "italic",
              fontFamily: "'Georgia', serif",
            }}
          >
            {displayValue}
          </span>
        </div>
      </div>
      <span style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", letterSpacing: "0.2em", fontWeight: 400 }}>
        {label}
      </span>
    </motion.div>
  );
}