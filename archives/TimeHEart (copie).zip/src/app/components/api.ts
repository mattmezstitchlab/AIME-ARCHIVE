// ═══════════════════════════════════════════
// STITCHLAB — API Client
// Communicates with Supabase Edge Functions
// ═══════════════════════════════════════════

import { projectId, publicAnonKey } from "/utils/supabase/info";
import type { PlayerData, Heartbeat, SortieEvent } from "./game-data";

const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-952ea964`;

const headers = () => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${publicAnonKey}`,
});

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: headers(),
    ...options,
  });
  const data = await res.json();
  if (!res.ok) {
    console.error(`API error ${path}:`, data);
    throw new Error(data.error || `Request failed: ${res.status}`);
  }
  return data;
}

// ─── PLAYERS ───

export async function registerPlayer(player: PlayerData) {
  return request<{ ok: boolean; player: PlayerData }>("/players", {
    method: "POST",
    body: JSON.stringify(player),
  });
}

export async function updatePosition(id: string, x: number, y: number) {
  return request<{ ok: boolean }>(`/players/${id}/position`, {
    method: "PUT",
    body: JSON.stringify({ x, y }),
  });
}

export async function getPlayers() {
  return request<{ players: PlayerData[] }>("/players");
}

// ─── HEARTBEATS ───

export async function createHeartbeat(hb: Partial<Heartbeat>) {
  return request<{ ok: boolean; heartbeat: Heartbeat }>("/heartbeats", {
    method: "POST",
    body: JSON.stringify(hb),
  });
}

export async function getHeartbeats() {
  return request<{ heartbeats: Heartbeat[] }>("/heartbeats");
}

// ─── SORTIES ───

export async function createSortie(sortie: Partial<SortieEvent>) {
  return request<{ ok: boolean; sortie: SortieEvent }>("/sorties", {
    method: "POST",
    body: JSON.stringify(sortie),
  });
}

export async function getSorties() {
  return request<{ sorties: SortieEvent[] }>("/sorties");
}

export async function joinSortie(sortieId: string, player: { playerId: string; pseudo: string; color: string; symbol: string }) {
  return request<{ ok: boolean; sortie: SortieEvent }>(`/sorties/${sortieId}/join`, {
    method: "POST",
    body: JSON.stringify(player),
  });
}

export async function leaveSortie(sortieId: string, playerId: string) {
  return request<{ ok: boolean; sortie: SortieEvent }>(`/sorties/${sortieId}/leave`, {
    method: "POST",
    body: JSON.stringify({ playerId }),
  });
}

// ─── TRAIL ───

export async function saveTrail(playerId: string, trail: { x: number; y: number }[]) {
  return request<{ ok: boolean }>(`/players/${playerId}/trail`, {
    method: "PUT",
    body: JSON.stringify({ trail }),
  });
}

// ─── LILY AI CHAT ───

export interface LilyChatMessage {
  role: "lily" | "user";
  text: string;
}

export interface LilyUserContext {
  pseudo?: string;
  city?: string;
  intention?: string;
  interests?: string[];
}

export async function chatWithLily(
  messages: LilyChatMessage[],
  userContext?: LilyUserContext,
): Promise<{ ok: boolean; text: string; usage?: { input_tokens: number; output_tokens: number } }> {
  return request<{ ok: boolean; text: string; usage?: { input_tokens: number; output_tokens: number } }>("/lily/chat", {
    method: "POST",
    body: JSON.stringify({ messages, userContext }),
  });
}

// ─── LILY TTS (OpenAI Nova) ───

export async function speakWithLily(text: string): Promise<Blob> {
  const res = await fetch(`${BASE}/lily/speak`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({ text }),
  });
  if (!res.ok) {
    const errData = await res.json().catch(() => ({ error: "Unknown TTS error" }));
    console.error("Lily TTS error:", errData);
    throw new Error(errData.error || `TTS request failed: ${res.status}`);
  }
  return res.blob();
}

// ─── LILY USAGE / COST TRACKING ───

export interface LilyUsageData {
  totalChatCalls: number;
  totalInputTokens: number;
  totalOutputTokens: number;
  totalTTSCalls: number;
  totalTTSCacheHits: number;
  totalTTSChars: number;
  estimatedCostUSD: number;
  lastUpdated: number;
}

export interface LilyUsageResponse {
  ok: boolean;
  usage: LilyUsageData;
  derived?: {
    avgTokensPerChat: number;
    ttsCacheHitRate: number;
    costBreakdown: { claudeInput: number; claudeOutput: number; tts: number };
    savedByCache: number;
  };
  prices: { claudeInputPerMTok: number; claudeOutputPerMTok: number; ttsPerKChars: number };
}

export async function getLilyUsage(): Promise<LilyUsageResponse> {
  return request<LilyUsageResponse>("/lily/usage");
}

export async function resetLilyUsage(): Promise<{ ok: boolean }> {
  return request<{ ok: boolean }>("/lily/usage", { method: "DELETE" });
}