import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { StitchLabMark } from "./StitchLabLogo";
import {
  CalendarHeart, Clock, MapPin, Users, Type,
  Footprints, Palette, Brain, Sparkles, Ear, Compass,
  User, Users2, Globe,
  TreePine, Coffee, Waves, Trees, Building2, Landmark, Flower2, BrickWall,
  Timer, AlignLeft,
} from "lucide-react";
import { useResponsive } from "./useResponsive";
import {
  SORTIE_CATEGORIES,
  SORTIE_DURATIONS,
  HEARTBEAT_OPENNESS,
  SYMBOLIC_PLACES,
  SORTIE_COLOR,
  type SortieCategory,
  type SortieDuration,
  type HeartbeatOpenness,
  type SortieEvent,
  type AccessibilityMode,
} from "./game-data";

// Icon mappings
const CATEGORY_ICONS: Record<SortieCategory, React.ReactNode> = {
  marche: <Footprints size={12} strokeWidth={1.5} />,
  atelier: <Palette size={12} strokeWidth={1.5} />,
  meditation: <Brain size={12} strokeWidth={1.5} />,
  celebration: <Sparkles size={12} strokeWidth={1.5} />,
  ecoute: <Ear size={12} strokeWidth={1.5} />,
  decouverte: <Compass size={12} strokeWidth={1.5} />,
};

const OPENNESS_ICONS: Record<HeartbeatOpenness, React.ReactNode> = {
  seul: <User size={12} strokeWidth={1.5} />,
  quelques: <Users2 size={12} strokeWidth={1.5} />,
  ouvert: <Globe size={12} strokeWidth={1.5} />,
};

const PLACE_ICONS: Record<string, React.ReactNode> = {
  "Un parc": <TreePine size={11} strokeWidth={1.5} />,
  "Un café": <Coffee size={11} strokeWidth={1.5} />,
  "Une rivière": <Waves size={11} strokeWidth={1.5} />,
  "Une forêt": <Trees size={11} strokeWidth={1.5} />,
  "Un toit": <Building2 size={11} strokeWidth={1.5} />,
  "Une place": <Landmark size={11} strokeWidth={1.5} />,
  "Un jardin": <Flower2 size={11} strokeWidth={1.5} />,
  "Un pont": <BrickWall size={11} strokeWidth={1.5} />,
};

interface SortieCreatorProps {
  visible: boolean;
  onClose: () => void;
  onCreateSortie: (
    sortie: Omit<SortieEvent, "id" | "creatorId" | "creatorPseudo" | "creatorColor" | "creatorSymbol" | "x" | "y" | "createdAt" | "participants">
  ) => void;
  mode: AccessibilityMode;
}

export function SortieCreator({ visible, onClose, onCreateSortie, mode }: SortieCreatorProps) {
  const { isMobile } = useResponsive();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split("T")[0];
  });
  const [time, setTime] = useState("10:00");
  const [duration, setDuration] = useState<SortieDuration>("2h");
  const [category, setCategory] = useState<SortieCategory>("marche");
  const [placeName, setPlaceName] = useState("");
  const [openness, setOpenness] = useState<HeartbeatOpenness>("ouvert");
  const [maxParticipants, setMaxParticipants] = useState<number | undefined>(undefined);

  const isSenior = mode === "senior";
  const fontSize = isMobile ? 12 : isSenior ? 14 : 12;

  const canCreate = title.trim().length > 0 && date;

  const handleCreate = () => {
    if (!canCreate) return;
    onCreateSortie({
      title: title.trim(),
      description: description.trim() || undefined,
      date,
      time,
      duration,
      category,
      placeName: placeName || undefined,
      openness,
      maxParticipants: maxParticipants || undefined,
    });
    // Reset
    setTitle("");
    setDescription("");
    onClose();
  };

  return (
    <AnimatePresence>
      {visible && (
        <>
          <motion.div
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(250,248,245,0.6)", backdropFilter: "blur(8px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.div
            className="fixed inset-x-4 top-1/2 z-50 max-w-[460px] mx-auto rounded-2xl flex flex-col gap-4 overflow-y-auto"
            style={{
              backgroundColor: "rgba(255,255,255,0.96)",
              backdropFilter: "blur(24px)",
              boxShadow: "0 16px 64px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.02)",
              transform: "translateY(-50%)",
              maxHeight: isMobile ? "88vh" : "85vh",
              padding: isMobile ? 16 : 24,
            }}
            initial={{ opacity: 0, y: "-46%", scale: 0.96 }}
            animate={{ opacity: 1, y: "-50%", scale: 1 }}
            exit={{ opacity: 0, y: "-46%", scale: 0.97 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            {/* Header */}
            <div className="flex items-center gap-2">
              <CalendarHeart size={16} color={SORTIE_COLOR} strokeWidth={1.5} />
              <span
                style={{
                  fontSize: 10,
                  letterSpacing: "0.15em",
                  color: SORTIE_COLOR,
                  textTransform: "uppercase",
                  fontWeight: 500,
                }}
              >
                Organiser une sortie
              </span>
            </div>

            {/* Title */}
            <Section icon={<Type size={13} strokeWidth={1.5} />} label="Titre" fontSize={fontSize}>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Marche silencieuse, Atelier dessin..."
                maxLength={60}
                className="w-full px-3 py-2 rounded-xl border-none outline-none"
                style={{
                  backgroundColor: "rgba(0,0,0,0.03)",
                  fontSize: fontSize,
                  color: "#1a1a1a",
                  fontWeight: 400,
                }}
              />
            </Section>

            {/* Description */}
            <Section icon={<AlignLeft size={13} strokeWidth={1.5} />} label="Description" fontSize={fontSize} optional>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Quelques mots pour donner envie..."
                maxLength={200}
                rows={2}
                className="w-full px-3 py-2 rounded-xl border-none outline-none resize-none"
                style={{
                  backgroundColor: "rgba(0,0,0,0.03)",
                  fontSize: fontSize - 1,
                  color: "#1a1a1a",
                  fontWeight: 300,
                }}
              />
            </Section>

            {/* Category */}
            <Section icon={<Compass size={13} strokeWidth={1.5} />} label="Type" fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {SORTIE_CATEGORIES.map((c) => (
                  <Pill
                    key={c.key}
                    label={c.label}
                    icon={CATEGORY_ICONS[c.key]}
                    active={category === c.key}
                    onClick={() => setCategory(c.key)}
                    fontSize={fontSize}
                    activeColor={SORTIE_COLOR}
                  />
                ))}
              </div>
            </Section>

            {/* Date & Time */}
            <div className="flex gap-3">
              <Section icon={<CalendarHeart size={13} strokeWidth={1.5} />} label="Date" fontSize={fontSize} flex>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border-none outline-none"
                  style={{
                    backgroundColor: "rgba(0,0,0,0.03)",
                    fontSize: fontSize - 1,
                    color: "#1a1a1a",
                  }}
                />
              </Section>
              <Section icon={<Clock size={13} strokeWidth={1.5} />} label="Heure" fontSize={fontSize} flex>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border-none outline-none"
                  style={{
                    backgroundColor: "rgba(0,0,0,0.03)",
                    fontSize: fontSize - 1,
                    color: "#1a1a1a",
                  }}
                />
              </Section>
            </div>

            {/* Duration */}
            <Section icon={<Timer size={13} strokeWidth={1.5} />} label="Durée" fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {SORTIE_DURATIONS.map((d) => (
                  <Pill
                    key={d.key}
                    label={d.label}
                    active={duration === d.key}
                    onClick={() => setDuration(d.key)}
                    fontSize={fontSize}
                    activeColor={SORTIE_COLOR}
                  />
                ))}
              </div>
            </Section>

            {/* Place */}
            <Section icon={<MapPin size={13} strokeWidth={1.5} />} label="Lieu" fontSize={fontSize} optional>
              <div className="flex flex-wrap gap-1.5">
                {SYMBOLIC_PLACES.map((p) => (
                  <Pill
                    key={p}
                    label={p}
                    icon={PLACE_ICONS[p]}
                    active={placeName === p}
                    onClick={() => setPlaceName(placeName === p ? "" : p)}
                    fontSize={fontSize}
                    subtle
                    activeColor={SORTIE_COLOR}
                  />
                ))}
              </div>
            </Section>

            {/* Openness */}
            <Section icon={<Users size={13} strokeWidth={1.5} />} label="Ouverture" fontSize={fontSize}>
              <div className="flex flex-wrap gap-1.5">
                {HEARTBEAT_OPENNESS.map((o) => (
                  <Pill
                    key={o.key}
                    label={o.label}
                    icon={OPENNESS_ICONS[o.key]}
                    active={openness === o.key}
                    onClick={() => setOpenness(o.key)}
                    fontSize={fontSize}
                    activeColor={SORTIE_COLOR}
                  />
                ))}
                {openness !== "seul" && (
                  <div className="flex items-center gap-1.5 ml-2">
                    <span style={{ fontSize: fontSize - 3, color: "#bbb" }}>Max :</span>
                    <input
                      type="number"
                      min={2}
                      max={50}
                      value={maxParticipants || ""}
                      onChange={(e) => setMaxParticipants(e.target.value ? parseInt(e.target.value) : undefined)}
                      placeholder="∞"
                      className="w-12 px-2 py-1 rounded-lg border-none outline-none text-center"
                      style={{
                        backgroundColor: "rgba(0,0,0,0.03)",
                        fontSize: fontSize - 2,
                        color: "#999",
                      }}
                    />
                  </div>
                )}
              </div>
            </Section>

            {/* Actions */}
            <div className="flex gap-3 pt-1">
              <button
                className="flex-1 py-2.5 rounded-xl cursor-pointer border-none"
                style={{ backgroundColor: "rgba(0,0,0,0.04)", color: "#aaa", fontSize: fontSize - 1 }}
                onClick={onClose}
              >
                Annuler
              </button>
              <motion.button
                className="flex-1 py-2.5 rounded-xl cursor-pointer border-none flex items-center justify-center gap-2"
                style={{
                  backgroundColor: canCreate ? "#1a1a1a" : "rgba(0,0,0,0.08)",
                  color: canCreate ? "#FAF8F5" : "#ccc",
                  fontSize: fontSize - 1,
                  letterSpacing: "0.06em",
                }}
                onClick={handleCreate}
                whileHover={canCreate ? { scale: 1.01, backgroundColor: "#333" } : {}}
                whileTap={canCreate ? { scale: 0.99 } : {}}
              >
                <CalendarHeart size={14} strokeWidth={1.5} color={canCreate ? SORTIE_COLOR : "#ccc"} />
                Créer la sortie
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function Section({
  icon,
  label,
  fontSize,
  optional,
  flex,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  fontSize: number;
  optional?: boolean;
  flex?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`flex flex-col gap-1.5 ${flex ? "flex-1 min-w-0" : ""}`}>
      <div className="flex items-center gap-1.5" style={{ color: "#999" }}>
        {icon}
        <span style={{ fontSize: fontSize - 2, color: "#999", fontWeight: 400, letterSpacing: "0.04em" }}>
          {label}
        </span>
        {optional && (
          <span style={{ fontSize: fontSize - 4, color: "#ddd", fontWeight: 300 }}>optionnel</span>
        )}
      </div>
      {children}
    </div>
  );
}

function Pill({
  label,
  icon,
  active,
  onClick,
  fontSize,
  subtle = false,
  activeColor,
}: {
  label: string;
  icon?: React.ReactNode;
  active: boolean;
  onClick: () => void;
  fontSize: number;
  subtle?: boolean;
  activeColor?: string;
}) {
  return (
    <motion.button
      className="px-3 py-1.5 rounded-full cursor-pointer border-none whitespace-nowrap flex items-center gap-1.5"
      style={{
        backgroundColor: active ? (activeColor || "#1a1a1a") : subtle ? "rgba(0,0,0,0.02)" : "rgba(0,0,0,0.04)",
        color: active ? "#fff" : subtle ? "#ccc" : "#888",
        fontSize: fontSize - 2,
        fontWeight: active ? 500 : 400,
      }}
      onClick={onClick}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
    >
      {icon && <span className="flex items-center">{icon}</span>}
      {label}
    </motion.button>
  );
}