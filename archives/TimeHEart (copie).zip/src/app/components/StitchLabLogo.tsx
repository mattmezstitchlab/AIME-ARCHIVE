import { motion } from "motion/react";

interface StitchLabLogoProps {
  size?: "sm" | "md" | "lg" | "hero";
  animate?: boolean;
}

const SIZES = {
  sm:   { fontSize: 9,  xSize: 10,  gap: 1, letterSpacing: "0.16em", px: 8,  py: 4,  radius: 6  },
  md:   { fontSize: 12, xSize: 13,  gap: 2, letterSpacing: "0.14em", px: 10, py: 5,  radius: 8  },
  lg:   { fontSize: 20, xSize: 20,  gap: 3, letterSpacing: "0.12em", px: 16, py: 8,  radius: 10 },
  hero: { fontSize: 44, xSize: 40,  gap: 5, letterSpacing: "0.10em", px: 32, py: 16, radius: 16 },
};

export function StitchLabLogo({ size = "md", animate = true }: StitchLabLogoProps) {
  const s = SIZES[size];

  return (
    <span
      className="inline-flex items-center select-none"
      style={{
        gap: s.gap,
        backgroundColor: "#1a1a1a",
        borderRadius: s.radius,
        paddingLeft: s.px,
        paddingRight: s.px,
        paddingTop: s.py,
        paddingBottom: s.py,
      }}
    >
      <span
        style={{
          fontSize: s.fontSize,
          fontWeight: 400,
          letterSpacing: s.letterSpacing,
          color: "#ffffff",
          lineHeight: 1,
        }}
      >
        STITCH
      </span>
      <motion.span
        className="inline-flex items-center justify-center"
        style={{ lineHeight: 1 }}
        animate={animate ? { rotate: [0, 90, 0] } : {}}
        transition={animate ? { duration: 8, repeat: Infinity, ease: "easeInOut" } : {}}
      >
        <svg
          width={s.xSize}
          height={s.xSize}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Cross-stitch X made of two diagonal thread lines */}
          <line x1="4" y1="4" x2="20" y2="20" stroke="#C72B3B" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="20" y1="4" x2="4" y2="20" stroke="#C72B3B" strokeWidth="2.5" strokeLinecap="round" />
          {/* Stitch dots at extremities */}
          <circle cx="4" cy="4" r="1.5" fill="#C72B3B" />
          <circle cx="20" cy="4" r="1.5" fill="#C72B3B" />
          <circle cx="4" cy="20" r="1.5" fill="#C72B3B" />
          <circle cx="20" cy="20" r="1.5" fill="#C72B3B" />
        </svg>
      </motion.span>
      <span
        style={{
          fontSize: s.fontSize,
          fontWeight: 400,
          letterSpacing: s.letterSpacing,
          color: "#ffffff",
          lineHeight: 1,
        }}
      >
        LAB
      </span>
    </span>
  );
}

// Compact mark — a small cross-stitch X
export function StitchLabMark({ size = 12, animate = true }: { size?: number; animate?: boolean }) {
  return (
    <motion.svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      animate={animate ? { rotate: [0, 90, 0] } : {}}
      transition={animate ? { duration: 8, repeat: Infinity, ease: "easeInOut" } : {}}
    >
      <line x1="4" y1="4" x2="20" y2="20" stroke="#C72B3B" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="20" y1="4" x2="4" y2="20" stroke="#C72B3B" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="4" cy="4" r="1.5" fill="#C72B3B" />
      <circle cx="20" cy="4" r="1.5" fill="#C72B3B" />
      <circle cx="4" cy="20" r="1.5" fill="#C72B3B" />
      <circle cx="20" cy="20" r="1.5" fill="#C72B3B" />
    </motion.svg>
  );
}

// Bloc noir badge for HUD
export function StitchLabBadge({ size = "sm" }: { size?: "xs" | "sm" | "md" }) {
  const conf = {
    xs: { fontSize: 7, xSize: 8,  gap: 1, px: 5, py: 2.5, radius: 4 },
    sm: { fontSize: 8, xSize: 9,  gap: 1, px: 6, py: 3, radius: 5 },
    md: { fontSize: 10, xSize: 11, gap: 1.5, px: 8, py: 4, radius: 6 },
  }[size];

  return (
    <span
      className="inline-flex items-center select-none"
      style={{
        gap: conf.gap,
        backgroundColor: "#1a1a1a",
        borderRadius: conf.radius,
        paddingLeft: conf.px,
        paddingRight: conf.px,
        paddingTop: conf.py,
        paddingBottom: conf.py,
      }}
    >
      <span style={{ fontSize: conf.fontSize, fontWeight: 500, letterSpacing: "0.14em", color: "#fff", lineHeight: 1 }}>
        STITCH
      </span>
      <motion.svg
        width={conf.xSize}
        height={conf.xSize}
        viewBox="0 0 24 24"
        fill="none"
        animate={{ rotate: [0, 90, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      >
        <line x1="5" y1="5" x2="19" y2="19" stroke="#C72B3B" strokeWidth="3" strokeLinecap="round" />
        <line x1="19" y1="5" x2="5" y2="19" stroke="#C72B3B" strokeWidth="3" strokeLinecap="round" />
      </motion.svg>
      <span style={{ fontSize: conf.fontSize, fontWeight: 500, letterSpacing: "0.14em", color: "#fff", lineHeight: 1 }}>
        LAB
      </span>
    </span>
  );
}
