import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { LILY_SYSTEM_PROMPT } from "./lily-prompt.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

app.use("*", logger(console.log));
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length", "X-Cache"],
    maxAge: 600,
  }),
);

const PREFIX = "/make-server-952ea964";
const TTS_BUCKET = "make-952ea964-lily-tts";

// ─── SUPABASE CLIENT (for Storage) ───
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// ─── IDEMPOTENT BUCKET CREATION ───
(async () => {
  try {
    const { data: buckets } = await supabase.storage.listBuckets();
    const exists = buckets?.some((b: any) => b.name === TTS_BUCKET);
    if (!exists) {
      const { error } = await supabase.storage.createBucket(TTS_BUCKET, { public: false });
      if (error) console.log(`Failed to create TTS bucket: ${error.message}`);
      else console.log(`TTS cache bucket created: ${TTS_BUCKET}`);
    } else {
      console.log(`TTS cache bucket exists: ${TTS_BUCKET}`);
    }
  } catch (err) {
    console.log(`TTS bucket init error (non-fatal): ${err}`);
  }
})();

// ─── SHA-256 HASH UTILITY ───
async function hashText(text: string): Promise<string> {
  const data = new TextEncoder().encode(text.trim().toLowerCase());
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ─── USAGE TRACKING ───
// Prices: Claude Sonnet 4 ($3/MTok in, $15/MTok out), OpenAI TTS-1 ($0.015/1K chars)
const PRICES = {
  claudeInputPerMTok: 3.0,
  claudeOutputPerMTok: 15.0,
  ttsPerKChars: 0.015,
};

interface UsageData {
  totalChatCalls: number;
  totalInputTokens: number;
  totalOutputTokens: number;
  totalTTSCalls: number;
  totalTTSCacheHits: number;
  totalTTSChars: number;
  estimatedCostUSD: number;
  lastUpdated: number;
}

const USAGE_KEY = "lily-usage:global";

async function trackChatUsage(inputTokens: number, outputTokens: number) {
  try {
    const existing: UsageData | null = await kv.get(USAGE_KEY);
    const usage: UsageData = existing || {
      totalChatCalls: 0, totalInputTokens: 0, totalOutputTokens: 0,
      totalTTSCalls: 0, totalTTSCacheHits: 0, totalTTSChars: 0,
      estimatedCostUSD: 0, lastUpdated: 0,
    };
    usage.totalChatCalls++;
    usage.totalInputTokens += inputTokens;
    usage.totalOutputTokens += outputTokens;
    const chatCost = (inputTokens / 1_000_000) * PRICES.claudeInputPerMTok
                   + (outputTokens / 1_000_000) * PRICES.claudeOutputPerMTok;
    usage.estimatedCostUSD += chatCost;
    usage.lastUpdated = Date.now();
    await kv.set(USAGE_KEY, usage);
    console.log(`Usage tracked: chat call #${usage.totalChatCalls}, +$${chatCost.toFixed(4)}, total $${usage.estimatedCostUSD.toFixed(4)}`);
  } catch (err) {
    console.log(`Usage tracking error (non-fatal): ${err}`);
  }
}

async function trackTTSUsage(chars: number, cacheHit: boolean) {
  try {
    const existing: UsageData | null = await kv.get(USAGE_KEY);
    const usage: UsageData = existing || {
      totalChatCalls: 0, totalInputTokens: 0, totalOutputTokens: 0,
      totalTTSCalls: 0, totalTTSCacheHits: 0, totalTTSChars: 0,
      estimatedCostUSD: 0, lastUpdated: 0,
    };
    usage.totalTTSCalls++;
    if (cacheHit) {
      usage.totalTTSCacheHits++;
    } else {
      usage.totalTTSChars += chars;
      const ttsCost = (chars / 1000) * PRICES.ttsPerKChars;
      usage.estimatedCostUSD += ttsCost;
    }
    usage.lastUpdated = Date.now();
    await kv.set(USAGE_KEY, usage);
  } catch (err) {
    console.log(`TTS usage tracking error (non-fatal): ${err}`);
  }
}

// ─── HEALTH ───
app.get(`${PREFIX}/health`, (c) => c.json({ status: "ok" }));

// ─── PLAYERS ───

// Register / update player
app.post(`${PREFIX}/players`, async (c) => {
  try {
    const body = await c.req.json();
    const { id, pseudo, city, intention, colorHex, colorCode, symbol, symbol2, symbolSize, symbolRotation, symbolContrast, x, y } = body;
    if (!id || !pseudo) {
      return c.json({ error: "Missing required fields: id, pseudo" }, 400);
    }
    const player = { id, pseudo, city, intention, colorHex, colorCode, symbol, symbol2, symbolSize, symbolRotation, symbolContrast, x: x || 0, y: y || 0, lastSeen: Date.now() };
    await kv.set(`player:${id}`, player);
    console.log(`Player registered/updated: ${id} (${pseudo})`);
    return c.json({ ok: true, player });
  } catch (err) {
    console.log(`Error registering player: ${err}`);
    return c.json({ error: `Error registering player: ${err}` }, 500);
  }
});

// Update player position
app.put(`${PREFIX}/players/:id/position`, async (c) => {
  try {
    const id = c.req.param("id");
    const { x, y } = await c.req.json();
    const player = await kv.get(`player:${id}`);
    if (!player) {
      return c.json({ error: `Player not found: ${id}` }, 404);
    }
    player.x = x;
    player.y = y;
    player.lastSeen = Date.now();
    await kv.set(`player:${id}`, player);
    return c.json({ ok: true });
  } catch (err) {
    console.log(`Error updating player position: ${err}`);
    return c.json({ error: `Error updating position: ${err}` }, 500);
  }
});

// Get all players (recent, last 30 min)
app.get(`${PREFIX}/players`, async (c) => {
  try {
    const players = await kv.getByPrefix("player:");
    const cutoff = Date.now() - 30 * 60 * 1000;
    const active = players.filter((p: any) => p.lastSeen > cutoff);
    return c.json({ players: active });
  } catch (err) {
    console.log(`Error fetching players: ${err}`);
    return c.json({ error: `Error fetching players: ${err}` }, 500);
  }
});

// ─── HEARTBEATS ───

app.post(`${PREFIX}/heartbeats`, async (c) => {
  try {
    const body = await c.req.json();
    const hb = { ...body, id: body.id || `hb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, createdAt: Date.now() };
    await kv.set(`heartbeat:${hb.id}`, hb);
    console.log(`Heartbeat created: ${hb.id} by ${hb.creatorPseudo}`);
    return c.json({ ok: true, heartbeat: hb });
  } catch (err) {
    console.log(`Error creating heartbeat: ${err}`);
    return c.json({ error: `Error creating heartbeat: ${err}` }, 500);
  }
});

app.get(`${PREFIX}/heartbeats`, async (c) => {
  try {
    const heartbeats = await kv.getByPrefix("heartbeat:");
    // Only return heartbeats from last 48h
    const cutoff = Date.now() - 48 * 60 * 60 * 1000;
    const recent = heartbeats.filter((h: any) => h.createdAt > cutoff);
    return c.json({ heartbeats: recent });
  } catch (err) {
    console.log(`Error fetching heartbeats: ${err}`);
    return c.json({ error: `Error fetching heartbeats: ${err}` }, 500);
  }
});

// ─── SORTIES / EVENTS ───

app.post(`${PREFIX}/sorties`, async (c) => {
  try {
    const body = await c.req.json();
    const sortie = {
      ...body,
      id: body.id || `sortie-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      participants: body.participants || [],
      createdAt: Date.now(),
    };
    await kv.set(`sortie:${sortie.id}`, sortie);
    console.log(`Sortie created: ${sortie.id} "${sortie.title}" by ${sortie.creatorPseudo}`);
    return c.json({ ok: true, sortie });
  } catch (err) {
    console.log(`Error creating sortie: ${err}`);
    return c.json({ error: `Error creating sortie: ${err}` }, 500);
  }
});

app.get(`${PREFIX}/sorties`, async (c) => {
  try {
    const sorties = await kv.getByPrefix("sortie:");
    // Only return future + today sorties
    const today = new Date().toISOString().split("T")[0];
    const upcoming = sorties.filter((s: any) => s.date >= today);
    return c.json({ sorties: upcoming });
  } catch (err) {
    console.log(`Error fetching sorties: ${err}`);
    return c.json({ error: `Error fetching sorties: ${err}` }, 500);
  }
});

// Join a sortie
app.post(`${PREFIX}/sorties/:id/join`, async (c) => {
  try {
    const id = c.req.param("id");
    const { playerId, pseudo, color, symbol } = await c.req.json();
    if (!playerId || !pseudo) {
      return c.json({ error: "Missing playerId, pseudo" }, 400);
    }
    const sortie = await kv.get(`sortie:${id}`);
    if (!sortie) {
      return c.json({ error: `Sortie not found: ${id}` }, 404);
    }
    // Check not already joined
    if (sortie.participants.some((p: any) => p.id === playerId)) {
      return c.json({ ok: true, sortie, message: "Already joined" });
    }
    // Check capacity
    if (sortie.maxParticipants && sortie.participants.length >= sortie.maxParticipants) {
      return c.json({ error: "Sortie is full" }, 400);
    }
    sortie.participants.push({ id: playerId, pseudo, color, symbol });
    await kv.set(`sortie:${id}`, sortie);
    console.log(`Player ${pseudo} joined sortie ${id}`);
    return c.json({ ok: true, sortie });
  } catch (err) {
    console.log(`Error joining sortie: ${err}`);
    return c.json({ error: `Error joining sortie: ${err}` }, 500);
  }
});

// Leave a sortie
app.post(`${PREFIX}/sorties/:id/leave`, async (c) => {
  try {
    const id = c.req.param("id");
    const { playerId } = await c.req.json();
    const sortie = await kv.get(`sortie:${id}`);
    if (!sortie) {
      return c.json({ error: `Sortie not found: ${id}` }, 404);
    }
    sortie.participants = sortie.participants.filter((p: any) => p.id !== playerId);
    await kv.set(`sortie:${id}`, sortie);
    console.log(`Player ${playerId} left sortie ${id}`);
    return c.json({ ok: true, sortie });
  } catch (err) {
    console.log(`Error leaving sortie: ${err}`);
    return c.json({ error: `Error leaving sortie: ${err}` }, 500);
  }
});

// ─── TRAIL ───

// Save trail for a player
app.put(`${PREFIX}/players/:id/trail`, async (c) => {
  try {
    const id = c.req.param("id");
    const { trail } = await c.req.json();
    await kv.set(`trail:${id}`, { trail, updatedAt: Date.now() });
    return c.json({ ok: true });
  } catch (err) {
    console.log(`Error saving trail: ${err}`);
    return c.json({ error: `Error saving trail: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════
// LILY — AI Embroidery Expert Chat
// ═══════════════════════════════════════════

app.post(`${PREFIX}/lily/chat`, async (c) => {
  try {
    const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
    if (!apiKey) {
      console.log("ANTHROPIC_API_KEY not set — Lily AI unavailable");
      return c.json({ error: "Lily AI not configured: ANTHROPIC_API_KEY missing" }, 503);
    }

    const body = await c.req.json();
    const { messages, userContext } = body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return c.json({ error: "Missing messages array in Lily chat request" }, 400);
    }

    // Build context-enriched system prompt
    let systemPrompt = LILY_SYSTEM_PROMPT;
    if (userContext) {
      systemPrompt += `\n\n## Contexte utilisateur`;
      if (userContext.pseudo) systemPrompt += `\n- Pseudo : ${userContext.pseudo}`;
      if (userContext.city) systemPrompt += `\n- Ville : ${userContext.city}`;
      if (userContext.interests && userContext.interests.length > 0) {
        systemPrompt += `\n- Passions detectees : ${userContext.interests.join(", ")}`;
      }
      if (userContext.intention) systemPrompt += `\n- Intention dans StitchLab : ${userContext.intention}`;
    }

    // Keep last 30 messages for context window management
    const trimmedMessages = messages.slice(-30).map((m: any) => ({
      role: m.role === "lily" ? "assistant" : "user",
      content: m.text,
    }));

    console.log(`Lily chat: ${trimmedMessages.length} messages, user: ${userContext?.pseudo || "anonymous"}`);

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 512,
        system: systemPrompt,
        messages: trimmedMessages,
      }),
    });

    if (!response.ok) {
      const errData = await response.text();
      console.log(`Anthropic API error (${response.status}): ${errData}`);
      return c.json({ error: `Anthropic API error: ${response.status} — ${errData}` }, 502);
    }

    const data = await response.json();
    const text = data.content?.[0]?.text || "...";

    console.log(`Lily responded: ${text.slice(0, 80)}...`);
    const inputTokens = data.usage?.input_tokens || 0;
    const outputTokens = data.usage?.output_tokens || 0;
    await trackChatUsage(inputTokens, outputTokens);
    return c.json({ ok: true, text, usage: data.usage });
  } catch (err) {
    console.log(`Error in Lily chat: ${err}`);
    return c.json({ error: `Error in Lily chat: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════
// LILY — Text-to-Speech (OpenAI TTS / Nova)
// ═══════════════════════════════════════════

app.post(`${PREFIX}/lily/speak`, async (c) => {
  try {
    const apiKey = Deno.env.get("OPENAI-API-KEY");
    if (!apiKey) {
      console.log("OPENAI-API-KEY not set — Lily TTS unavailable");
      return c.json({ error: "Lily TTS not configured: OPENAI-API-KEY missing" }, 503);
    }

    const body = await c.req.json();
    const { text } = body;

    if (!text || typeof text !== "string" || text.trim().length === 0) {
      return c.json({ error: "Missing text for TTS in Lily speak request" }, 400);
    }

    // Limit text length to avoid excessive costs
    const trimmedText = text.slice(0, 1000);
    const cacheKey = await hashText(trimmedText);
    const filePath = `${cacheKey}.mp3`;

    console.log(`Lily TTS request: "${trimmedText.slice(0, 60)}..." hash=${cacheKey.slice(0, 12)}`);

    // ─── CHECK CACHE (Supabase Storage) ───
    try {
      const { data: cachedFile } = await supabase.storage.from(TTS_BUCKET).download(filePath);
      if (cachedFile && cachedFile.size > 0) {
        console.log(`TTS CACHE HIT: ${filePath} (${cachedFile.size} bytes)`);
        const buffer = await cachedFile.arrayBuffer();
        await trackTTSUsage(trimmedText.length, true);
        return new Response(buffer, {
          status: 200,
          headers: {
            "Content-Type": "audio/mpeg",
            "Content-Length": buffer.byteLength.toString(),
            "X-Cache": "HIT",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
          },
        });
      }
    } catch {
      // Cache miss — continue to generate
    }

    console.log(`TTS CACHE MISS: generating via OpenAI Nova...`);

    const response = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "tts-1",
        voice: "nova",
        input: trimmedText,
        response_format: "mp3",
        speed: 0.95,
      }),
    });

    if (!response.ok) {
      const errData = await response.text();
      console.log(`OpenAI TTS error (${response.status}): ${errData}`);
      return c.json({ error: `OpenAI TTS error: ${response.status} — ${errData}` }, 502);
    }

    const audioBuffer = await response.arrayBuffer();
    console.log(`Lily TTS generated: ${audioBuffer.byteLength} bytes`);

    // ─── STORE IN CACHE (non-blocking) ───
    const audioUint8 = new Uint8Array(audioBuffer);
    supabase.storage.from(TTS_BUCKET).upload(filePath, audioUint8, {
      contentType: "audio/mpeg",
      upsert: true,
    }).then(({ error }) => {
      if (error) console.log(`TTS cache store error: ${error.message}`);
      else console.log(`TTS cached: ${filePath} (${audioBuffer.byteLength} bytes)`);
    });

    await trackTTSUsage(trimmedText.length, false);
    return new Response(audioBuffer, {
      status: 200,
      headers: {
        "Content-Type": "audio/mpeg",
        "Content-Length": audioBuffer.byteLength.toString(),
        "X-Cache": "MISS",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
      },
    });
  } catch (err) {
    console.log(`Error in Lily TTS: ${err}`);
    return c.json({ error: `Error in Lily TTS: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════
// LILY — Usage / Cost Admin Dashboard
// ═══════════════════════════════════════════

app.get(`${PREFIX}/lily/usage`, async (c) => {
  try {
    const usage: UsageData | null = await kv.get(USAGE_KEY);
    if (!usage) {
      return c.json({
        ok: true,
        usage: {
          totalChatCalls: 0, totalInputTokens: 0, totalOutputTokens: 0,
          totalTTSCalls: 0, totalTTSCacheHits: 0, totalTTSChars: 0,
          estimatedCostUSD: 0, lastUpdated: 0,
        },
        prices: PRICES,
      });
    }
    // Calculate derived stats
    const avgTokensPerChat = usage.totalChatCalls > 0
      ? Math.round((usage.totalInputTokens + usage.totalOutputTokens) / usage.totalChatCalls) : 0;
    const ttsCacheHitRate = usage.totalTTSCalls > 0
      ? Math.round((usage.totalTTSCacheHits / usage.totalTTSCalls) * 100) : 0;
    const costBreakdown = {
      claudeInput: (usage.totalInputTokens / 1_000_000) * PRICES.claudeInputPerMTok,
      claudeOutput: (usage.totalOutputTokens / 1_000_000) * PRICES.claudeOutputPerMTok,
      tts: (usage.totalTTSChars / 1000) * PRICES.ttsPerKChars,
    };
    const savedByCache = usage.totalTTSCacheHits > 0
      ? (usage.totalTTSChars / Math.max(1, usage.totalTTSCalls - usage.totalTTSCacheHits))
        * usage.totalTTSCacheHits / 1000 * PRICES.ttsPerKChars
      : 0;

    return c.json({
      ok: true,
      usage,
      derived: { avgTokensPerChat, ttsCacheHitRate, costBreakdown, savedByCache },
      prices: PRICES,
    });
  } catch (err) {
    console.log(`Error fetching Lily usage: ${err}`);
    return c.json({ error: `Error fetching usage: ${err}` }, 500);
  }
});

// Reset usage stats (admin only)
app.delete(`${PREFIX}/lily/usage`, async (c) => {
  try {
    await kv.del(USAGE_KEY);
    console.log("Lily usage stats reset");
    return c.json({ ok: true, message: "Usage stats reset" });
  } catch (err) {
    console.log(`Error resetting usage: ${err}`);
    return c.json({ error: `Error resetting usage: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════
// BETA TEST — Feedback Collection
// ═══════════════════════════════════════════

app.post(`${PREFIX}/beta/feedback`, async (c) => {
  try {
    const body = await c.req.json();
    const id = `beta-feedback:${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    await kv.set(id, { ...body, id, savedAt: Date.now() });
    console.log(`Beta feedback saved: ${id} from ${body.testerName || "anonymous"}`);
    return c.json({ ok: true, id });
  } catch (err) {
    console.log(`Error saving beta feedback: ${err}`);
    return c.json({ error: `Error saving beta feedback: ${err}` }, 500);
  }
});

app.get(`${PREFIX}/beta/feedback`, async (c) => {
  try {
    const results = await kv.getByPrefix("beta-feedback:");
    console.log(`Beta feedback: ${results.length} entries`);
    return c.json({ ok: true, feedback: results });
  } catch (err) {
    console.log(`Error loading beta feedback: ${err}`);
    return c.json({ error: `Error loading beta feedback: ${err}` }, 500);
  }
});

Deno.serve(app.fetch);