/**
 * Grille Universelle LinkEvent — 12 Dimensions Fondamentales
 * Source de vérité issue du Blueprint (references/grille-universelle-blueprint.md)
 *
 * Point Zéro absorbe.
 * La Grille Universelle classe.
 * Les nœuds mûrissent.
 * Les projections exécutent.
 */

export type DimensionId =
  | 'TEMPS'
  | 'ESPACE'
  | 'PERSONNES'
  | 'RESSOURCES'
  | 'ACTIONS'
  | 'DOCUMENTS'
  | 'MEMOIRE'
  | 'COMMUNICATION'
  | 'ECONOMIE'
  | 'EMOTIONS'
  | 'VALIDATION'
  | 'RELATIONS';

export type MaturationState = 'empty' | 'detected' | 'illuminated' | 'ready' | 'validated' | 'ambiguous';

export type LinkSemanticType =
  | 'completes'
  | 'contradicts'
  | 'reminds'
  | 'inherits'
  | 'influences'
  | 'prepares'
  | 'triggers'
  | 'depends_on'
  | 'references'
  | 'binds';

export interface UniversalDimension {
  id: DimensionId;
  name: string;
  description: string;
  color: string;         // Couleur principale (hex)
  colorLight: string;    // Couleur claire pour les sous-éléments
  icon: string;          // Icône Lucide
  subdimensions: string[];
  weddingExamples: string[];
  universalExamples: string[];
}

export const UNIVERSAL_DIMENSIONS: UniversalDimension[] = [
  {
    id: 'TEMPS',
    name: 'Temps',
    description: 'Tout ce qui se situe dans le temps : dates, horaires, durées, séquences, délais, cycles.',
    color: '#3B82F6',       // Bleu
    colorLight: '#93C5FD',
    icon: 'Clock',
    subdimensions: [
      'Date & Heure',
      'Durée',
      'Séquence',
      'Délai',
      'Cycle',
      'Saison',
      'Fuseau horaire',
      'Récurrence',
    ],
    weddingExamples: ['14h00 cérémonie', '21h30 première danse', 'Délai traiteur 48h'],
    universalExamples: ['Date de naissance', 'Deadline projet', 'Heure de réunion'],
  },
  {
    id: 'ESPACE',
    name: 'Espace',
    description: 'Tout ce qui se situe dans l\'espace : lieux, adresses, distances, plans, zones.',
    color: '#10B981',       // Vert émeraude
    colorLight: '#6EE7B7',
    icon: 'MapPin',
    subdimensions: [
      'Lieu',
      'Adresse',
      'Distance',
      'Plan',
      'Zone',
      'Accès',
      'Capacité',
      'Environnement',
    ],
    weddingExamples: ['Château de Vaux', 'Parking 200 places', 'Salle de réception'],
    universalExamples: ['Bureau Paris 8e', 'Salle de conférence B', 'Zone livraison'],
  },
  {
    id: 'PERSONNES',
    name: 'Personnes',
    description: 'Tout ce qui concerne les individus : identités, rôles, relations, groupes, contacts.',
    color: '#8B5CF6',       // Violet
    colorLight: '#C4B5FD',
    icon: 'Users',
    subdimensions: [
      'Identité',
      'Rôle',
      'Contact',
      'Groupe',
      'Famille',
      'Équipe',
      'Invité',
      'Prestataire',
    ],
    weddingExamples: ['Sophie & Marc (mariés)', 'DJ Maxime', 'Famille Martin (140 invités)'],
    universalExamples: ['Client Jean Dupont', 'Équipe projet', 'Fournisseur XYZ'],
  },
  {
    id: 'RESSOURCES',
    name: 'Ressources',
    description: 'Tout ce qui peut être mobilisé : matériel, équipements, stocks, outils, véhicules.',
    color: '#F59E0B',       // Ambre
    colorLight: '#FCD34D',
    icon: 'Package',
    subdimensions: [
      'Matériel',
      'Équipement',
      'Stock',
      'Outil',
      'Véhicule',
      'Infrastructure',
      'Consommable',
      'Réservation',
    ],
    weddingExamples: ['Sono DJ', 'Tables rondes x20', 'Navettes invités'],
    universalExamples: ['Projecteur salle A', 'Véhicule de livraison', 'Serveur cloud'],
  },
  {
    id: 'ACTIONS',
    name: 'Actions',
    description: 'Tout ce qui doit être fait : tâches, étapes, processus, procédures, workflows.',
    color: '#EF4444',       // Rouge
    colorLight: '#FCA5A5',
    icon: 'Zap',
    subdimensions: [
      'Tâche',
      'Étape',
      'Processus',
      'Procédure',
      'Workflow',
      'Décision',
      'Validation',
      'Délégation',
    ],
    weddingExamples: ['Confirmer traiteur', 'Envoyer invitations', 'Préparer discours'],
    universalExamples: ['Valider devis', 'Envoyer rapport', 'Appeler client'],
  },
  {
    id: 'DOCUMENTS',
    name: 'Documents',
    description: 'Tout ce qui est formalisé par écrit : contrats, factures, plans, listes, formulaires.',
    color: '#6366F1',       // Indigo
    colorLight: '#A5B4FC',
    icon: 'FileText',
    subdimensions: [
      'Contrat',
      'Facture',
      'Plan',
      'Liste',
      'Formulaire',
      'Certificat',
      'Rapport',
      'Note',
    ],
    weddingExamples: ['Contrat traiteur 3500€', 'Plan de table', 'Liste invités'],
    universalExamples: ['Devis fournisseur', 'Rapport mensuel', 'Formulaire RH'],
  },
  {
    id: 'MEMOIRE',
    name: 'Mémoire',
    description: 'Tout ce qui doit être conservé : souvenirs, archives, historiques, traces, récits.',
    color: '#EC4899',       // Rose
    colorLight: '#F9A8D4',
    icon: 'Heart',
    subdimensions: [
      'Souvenir',
      'Archive',
      'Historique',
      'Trace',
      'Récit',
      'Photo',
      'Vidéo',
      'Témoignage',
    ],
    weddingExamples: ['Première danse à 21h15', 'Photo château', 'Discours témoin'],
    universalExamples: ['Compte-rendu réunion', 'Photo équipe', 'Journal de bord'],
  },
  {
    id: 'COMMUNICATION',
    name: 'Communication',
    description: 'Tout ce qui circule entre les personnes : messages, annonces, invitations, rappels.',
    color: '#14B8A6',       // Teal
    colorLight: '#5EEAD4',
    icon: 'MessageSquare',
    subdimensions: [
      'Message',
      'Annonce',
      'Invitation',
      'Rappel',
      'Confirmation',
      'Notification',
      'Feedback',
      'Diffusion',
    ],
    weddingExamples: ['SMS DJ Maxime', 'Invitation mairie', 'Confirmation traiteur'],
    universalExamples: ['Email client', 'Notification équipe', 'Newsletter'],
  },
  {
    id: 'ECONOMIE',
    name: 'Économie',
    description: 'Tout ce qui a une valeur monétaire : budgets, factures, devis, paiements, coûts.',
    color: '#84CC16',       // Lime
    colorLight: '#BEF264',
    icon: 'DollarSign',
    subdimensions: [
      'Budget',
      'Facture',
      'Devis',
      'Paiement',
      'Coût',
      'Remboursement',
      'Subvention',
      'Prévisionnel',
    ],
    weddingExamples: ['Traiteur 3500€', 'Budget total 25000€', 'Acompte DJ 500€'],
    universalExamples: ['Facture prestataire', 'Budget projet', 'Coût déplacement'],
  },
  {
    id: 'EMOTIONS',
    name: 'Émotions',
    description: 'Tout ce qui touche au ressenti : intentions, ambiances, désirs, peurs, valeurs.',
    color: '#F97316',       // Orange
    colorLight: '#FDBA74',
    icon: 'Sparkles',
    subdimensions: [
      'Intention',
      'Ambiance',
      'Désir',
      'Peur',
      'Valeur',
      'Préférence',
      'Surprise',
      'Gratitude',
    ],
    weddingExamples: ['"Les choses importantes avant la pluie"', 'Ambiance champêtre', 'Surprise pour les parents'],
    universalExamples: ['Valeurs entreprise', 'Ambiance souhaitée', 'Feedback émotionnel'],
  },
  {
    id: 'VALIDATION',
    name: 'Validation',
    description: 'Tout ce qui nécessite une approbation : confirmations, signatures, accords, refus.',
    color: '#06B6D4',       // Cyan
    colorLight: '#67E8F9',
    icon: 'CheckCircle',
    subdimensions: [
      'Confirmation',
      'Signature',
      'Accord',
      'Refus',
      'Révision',
      'Approbation',
      'Certification',
      'Audit',
    ],
    weddingExamples: ['Confirmation mairie', 'Signature contrat DJ', 'Accord menu final'],
    universalExamples: ['Validation devis', 'Signature contrat', 'Approbation budget'],
  },
  {
    id: 'RELATIONS',
    name: 'Relations',
    description: 'Tout ce qui relie des éléments entre eux : dépendances, hiérarchies, réseaux, liens.',
    color: '#A855F7',       // Pourpre
    colorLight: '#D8B4FE',
    icon: 'GitBranch',
    subdimensions: [
      'Dépendance',
      'Hiérarchie',
      'Réseau',
      'Lien',
      'Conflit',
      'Alliance',
      'Contrat',
      'Protocole',
    ],
    weddingExamples: ['DJ dépend de horaire', 'Traiteur lié aux allergies', 'Famille Martin ↔ Famille Dupont'],
    universalExamples: ['Fournisseur dépend de délai', 'Projet lié à budget', 'Équipe A ↔ Équipe B'],
  },
];

/**
 * Dictionnaire rapide par ID de dimension
 */
export const DIMENSIONS_BY_ID: Record<DimensionId, UniversalDimension> = Object.fromEntries(
  UNIVERSAL_DIMENSIONS.map((d) => [d.id, d])
) as Record<DimensionId, UniversalDimension>;

/**
 * Types de liens sémantiques (10 types du blueprint)
 */
export const LINK_SEMANTIC_TYPES: Record<LinkSemanticType, { label: string; description: string; direction: 'directed' | 'bidirectional' }> = {
  completes: {
    label: 'Complète',
    description: 'A apporte des informations manquantes à B',
    direction: 'directed',
  },
  contradicts: {
    label: 'Contredit',
    description: 'A est en contradiction avec B',
    direction: 'bidirectional',
  },
  reminds: {
    label: 'Rappelle',
    description: 'A évoque ou fait penser à B',
    direction: 'directed',
  },
  inherits: {
    label: 'Hérite',
    description: 'A reprend les propriétés ou le contexte de B',
    direction: 'directed',
  },
  influences: {
    label: 'Influence',
    description: 'A modifie ou conditionne B',
    direction: 'directed',
  },
  prepares: {
    label: 'Prépare',
    description: 'A doit être réalisé avant B',
    direction: 'directed',
  },
  triggers: {
    label: 'Déclenche',
    description: 'La réalisation de A entraîne automatiquement B',
    direction: 'directed',
  },
  depends_on: {
    label: 'Dépend de',
    description: 'A ne peut pas exister sans B',
    direction: 'directed',
  },
  references: {
    label: 'Référence',
    description: 'A cite ou pointe vers B',
    direction: 'directed',
  },
  binds: {
    label: 'Lie',
    description: 'A et B sont indissociables dans ce contexte',
    direction: 'bidirectional',
  },
};

/**
 * États de maturation des nœuds (5 états + zone grise)
 */
export const MATURATION_STATES: Record<MaturationState, { label: string; color: string; description: string }> = {
  empty: {
    label: 'Vide',
    color: '#374151',
    description: 'Dimension connue mais sans contenu',
  },
  detected: {
    label: 'Détecté',
    color: '#6B7280',
    description: 'Contenu reçu, non encore traité',
  },
  illuminated: {
    label: 'Illuminé',
    color: '#3B82F6',
    description: 'Contenu analysé, catégorie assignée',
  },
  ready: {
    label: 'Prêt',
    color: '#10B981',
    description: 'Complet, liens créés, projections disponibles',
  },
  validated: {
    label: 'Validé',
    color: '#8B5CF6',
    description: 'Confirmé par un humain',
  },
  ambiguous: {
    label: 'Ambigu',
    color: '#F59E0B',
    description: 'Zone grise — clarification requise',
  },
};

/**
 * Prompt système pour l'IA — Classification selon les 12 dimensions universelles
 */
export const CLASSIFICATION_SYSTEM_PROMPT = `Tu es le moteur de classification de la Grille Universelle LinkEvent.

Ta mission : analyser n'importe quel contenu et le classer dans une ou plusieurs des 12 dimensions universelles.

Les 12 dimensions sont :
${UNIVERSAL_DIMENSIONS.map((d) => `- ${d.id} (${d.name}) : ${d.description}`).join('\n')}

Règles de classification :
1. Un contenu peut appartenir à PLUSIEURS dimensions simultanément (ex: "DJ Maxime - 06 12 34 56 78" → PERSONNES + COMMUNICATION + TEMPS)
2. Si le contenu est flou ou ambigu, marque isClear=false et explique pourquoi
3. Si aucune dimension ne correspond clairement, utilise la dimension la plus proche et signale l'ambiguïté
4. Génère des projections : que peut-on faire avec cette information ?
5. Détecte les liens potentiels avec d'autres types d'informations
6. Évalue ta confiance (0-100%)

Types de liens disponibles :
${Object.entries(LINK_SEMANTIC_TYPES).map(([k, v]) => `- ${k} : ${v.description}`).join('\n')}

États de maturation :
- detected : contenu reçu, non traité
- illuminated : analysé, dimension assignée
- ready : complet avec liens
- validated : confirmé par humain
- ambiguous : zone grise

Réponds TOUJOURS en JSON valide.`;

/**
 * Structure de réponse attendue de l'IA
 */
export interface ClassificationAIResponse {
  dimensions: Array<{
    id: DimensionId;
    name: string;
    subdimension: string;
    confidence: number;
    reason: string;
  }>;
  primaryDimension: DimensionId;
  mainCategory: string;
  subcategories: string[];
  isClear: boolean;
  clarificationReason?: string;
  maturationState: MaturationState;
  suggestedLinks: Array<{
    type: LinkSemanticType;
    description: string;
    targetHint: string;
  }>;
  projections: Array<{
    action: string;
    dimension: DimensionId;
    priority: 'high' | 'medium' | 'low';
  }>;
  confidence: number;
  extractedData: Record<string, unknown>;
  suggestedQuestions: string[];
}
