export const exampleWeddingVrac = `
DÉROULÉ MARIAGE SOPHIE & MARC - 14 SEPTEMBRE 2026

=== HORAIRES CLÉS ===
08:00 - Réveil des mariés, petit-déj à l'hôtel
10:00 - Maquillage Sophie (salon Beauté Plus, 3 rue de la Paix)
11:30 - Coiffure Sophie (même lieu)
12:00 - Préparation Marc à la mairie
13:00 - Apéritif des témoins au Château de Vaux
14:00 - CÉRÉMONIE MAIRIE (Mairie de Commines, 1 place de la Mairie)
14:30 - Sortie mairie, photos
15:00 - Départ pour le château
15:30 - COCKTAIL (Château de Vaux, parc)
16:30 - Jeux et animations
17:30 - Séance photos couple
18:00 - Ouverture du bal
18:30 - DÎNER (Salle principale, 140 couverts)
19:00 - Discours témoins
19:30 - Première danse
20:00 - Buffet desserts
21:00 - Soirée dansante
23:00 - Dernier verre et départ

=== PRESTATAIRES ===
- Traiteur: Delice & Cie (contact: 06 12 34 56 78, email: contact@delice.fr)
  * 140 invités confirmés
  * Menu: Entrée buffet, plat chaud, dessert
  * Service à 18:30

- Photographe: Marc Dupont (contact: 06 98 76 54 32)
  * Présent de 14:00 à 23:00
  * Vidéaste aussi (drone autorisé)

- DJ: DJ Maxime (contact: 06 11 22 33 44)
  * Arrivée 17:00
  * Musique cocktail, dîner, soirée

- Fleuriste: Fleurs & Feuilles (contact: Mme Roseline, 06 55 44 33 22)
  * Décoration château
  * Bouquets mariée et témoins

- Saxophoniste: Laurent Dubois (contact: 06 77 88 99 00)
  * Cocktail et entrée des mariés
  * Répétition 15:00 à la salle

=== PERSONNES CLÉS ===
Mariée: Sophie Leclerc (06 12 13 14 15)
Marié: Marc Dupont (06 21 22 23 24)

Témoins:
- Julie (sœur Sophie) - 06 31 32 33 34
- Thomas (ami Marc) - 06 41 42 43 44

Coordinatrice jour J: Émilie (agence Événements Pro) - 06 51 52 53 54

Parents:
- Mère Sophie: Monique - 06 61 62 63 64
- Père Sophie: Jean - 06 71 72 73 74
- Mère Marc: Catherine - 06 81 82 83 84
- Père Marc: Pierre - 06 91 92 93 94

=== LIEU ===
Château de Vaux, Commines (60)
Accès: Parking 200 places
Salle: 300 m², climatisée
Extérieur: Parc 2 hectares

=== NOTES IMPORTANTES ===
- Météo prévue: 22°C, ensoleillé (plan B intérieur si pluie)
- Allergies alimentaires: Thomas (sans gluten), Mère Marc (sans lactose)
- Musiques interdites: Aucune
- Musiques obligatoires: "Que sera sera" (entrée), "Hallelujah" (première danse)
- Enfants: 20 enfants, animation prévue 16:00-17:30
- Parking invités: Gratuit
- Navettes: Hôtel ↔ Château (départ 13:30, retour 23:30)
- Hébergement: Hôtel du Château (bloc de 30 chambres réservées)

=== CHANGEMENTS DERNIÈRE MINUTE ===
- Traiteur confirme 140 couverts (était 145)
- Saxophoniste peut rester jusqu'à 21:00 (au lieu de 18:00)
- Drone photographe: autorisation mairie OK
- Feu d'artifice: ANNULÉ (bruit pour voisins)

=== À FAIRE AVANT SAMEDI ===
☐ Confirmer nombre d'invités définitif auprès du traiteur
☐ Envoyer déroulé au DJ et saxophoniste
☐ Vérifier accès parking pour photographe
☐ Confirmer navettes avec chauffeur
☐ Rappeler allergies au traiteur
☐ Prévoir plan B météo
☐ Tester musiques avec DJ
☐ Confirmer animation enfants
☐ Vérifier électricité pour DJ et éclairage
☐ Prévoir parapluies et plaids

=== CONTACTS D'URGENCE ===
Coordinatrice: Émilie - 06 51 52 53 54
Château: 03 44 55 66 77
Mairie: 03 44 88 99 00
Hôpital: 15 (SAMU)
`;

export const exampleWeddingVracShort = `
Mariage Sophie & Marc - 14 septembre 2026

Cérémonie: 14:00 Mairie de Commines
Cocktail: 15:30 Château de Vaux
Dîner: 18:30 (140 invités)
Soirée: 21:00

Prestataires:
- Traiteur Delice: 06 12 34 56 78
- Photographe Marc: 06 98 76 54 32
- DJ Maxime: 06 11 22 33 44
- Fleuriste Roseline: 06 55 44 33 22
- Saxophoniste Laurent: 06 77 88 99 00

Témoins: Julie (sœur), Thomas (ami)
Coordinatrice: Émilie - 06 51 52 53 54

Notes: 20 enfants, navettes hôtel, allergies gluten/lactose
`;
