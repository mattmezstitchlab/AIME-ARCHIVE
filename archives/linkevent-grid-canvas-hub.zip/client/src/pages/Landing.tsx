import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background text-foreground">
      {/* Hero Section */}
      <section className="py-20 px-4 text-center">
        <h1 className="text-5xl font-bold mb-6 text-primary">LinkEvent Grid Canvas</h1>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Le canevas de planification systémique pour les mariages et événements complexes. 
          Une interface révolutionnaire qui transforme la gestion d'événements en un acte de création visuelle.
        </p>
        <div className="flex justify-center gap-4">
          <Link href="/technical-dossier">
            <Button className="neumorphic-button">Voir le Dossier Technique</Button>
          </Link>
          <Link href="/point-zero">
            <Button variant="outline" className="neumorphic-button">Accéder au Point Zéro</Button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">Caractéristiques Clés</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="neumorphic-card p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-4 text-primary">Palette de Filtres Cognitifs</h3>
            <p className="text-muted-foreground">
              Une colonne latérale interactive avec 10 catégories d'événements. 
              Filtrez instantanément pour vous concentrer sur un "fil" spécifique.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="neumorphic-card p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-4 text-primary">Grille Temporelle Élastique</h3>
            <p className="text-muted-foreground">
              Une grille bidimensionnelle où le temps s'écoule horizontalement et les catégories verticalement. 
              Déplacez, redimensionnez et organisez vos événements avec fluidité.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="neumorphic-card p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-4 text-primary">Visualisation Nodale des Connexions</h3>
            <p className="text-muted-foreground">
              Les "fils" de dépendance apparaissent au survol ou à la sélection. 
              Comprenez instantanément ce qui dépend de quoi.
            </p>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-16 px-4 max-w-4xl mx-auto bg-card rounded-lg p-8 my-12">
        <h2 className="text-3xl font-bold mb-6 text-center">La Vision</h2>
        <p className="text-lg text-muted-foreground mb-4">
          LinkEvent Grid Canvas n'est pas un simple agenda, ni un Gantt classique, ni un Kanban. 
          C'est une approche révolutionnaire de la planification événementielle basée sur trois piliers :
        </p>
        <ul className="space-y-4 text-muted-foreground">
          <li className="flex items-start gap-3">
            <span className="text-primary font-bold">1.</span>
            <span><strong>La Palette de Filtres Cognitifs :</strong> Réduisez la surcharge cognitive en isolant les catégories d'événements.</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="text-primary font-bold">2.</span>
            <span><strong>La Grille Temporelle Élastique :</strong> Organisez vos événements dans un espace spatio-temporel flexible et intuitif.</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="text-primary font-bold">3.</span>
            <span><strong>La Visualisation Nodale des Connexions :</strong> Comprenez les dépendances complexes entre les éléments de votre événement.</span>
          </li>
        </ul>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Prêt à Transformer Votre Planification ?</h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Consultez le dossier technique complet pour comprendre comment cette interface révolutionnaire 
          peut être intégrée à votre système LinkEvent.
        </p>
        <Link href="/technical-dossier">
          <Button className="neumorphic-button text-lg px-8 py-3">Consulter le Dossier Technique</Button>
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 text-center text-muted-foreground">
        <p>&copy; 2026 LinkEvent. Conçu et développé avec Manus AI.</p>
      </footer>
    </div>
  );
};

export default Landing;
