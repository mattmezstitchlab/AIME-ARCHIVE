import React from 'react';
import { Streamdown } from 'streamdown';

const TechnicalDossier: React.FC = () => {
  const auditContent = `
# Rapport d'Audit Stratégique : Interface "Grid Canvas" pour LinkEvent

**À l'attention de :** Base 44  
**De :** Manus AI  
**Date :** 25 Juin 2026  
**Objet :** Spécifications techniques et visuelles pour le développement de l'interface "Grid Canvas" de LinkEvent.

---

## 1. Introduction : La Vision du "Canevas de Planification Systémique"

Ce document a pour objectif de transférer la vision et les spécifications détaillées de la nouvelle interface "Grid Canvas" pour LinkEvent. L'ambition est de dépasser les paradigmes actuels de gestion de projet (listes, Kanban, Gantt) pour proposer une approche **spatio-temporelle et systémique** de la planification événementielle. Inspirée de l'analogie de la broderie, cette interface vise à transformer la planification en un acte de "peinture" progressive sur une grille interactive, où chaque élément est un "fil" interconnecté.

Les maquettes visuelles ci-jointes illustrent les concepts clés et doivent servir de référence pour l'implémentation. Elles ne sont pas exhaustives mais représentent les principes fondamentaux à respecter.

---

## 2. Principes Clés de l'Interface

L'interface "Grid Canvas" repose sur trois piliers ergonomiques et cognitifs :

### 2.1. La Palette de Filtres Cognitifs (La "Palette DMC")
La colonne latérale gauche n'est plus un simple menu, mais un **centre de contrôle visuel**. Chaque catégorie d'événement (Préparatifs, Cérémonie, Réception, etc.) est associée à une couleur unique et forte. Cette palette permet à l'utilisateur de filtrer dynamiquement l'affichage de la grille centrale, réduisant ainsi la surcharge cognitive et permettant de se concentrer sur un "fil" spécifique du mariage.

### 2.2. La Grille Temporelle Élastique
La zone centrale est une grille bidimensionnelle où l'axe horizontal représente le temps (chronologie) et l'axe vertical représente les catégories ou ressources. Contrairement à un tableur rigide, cette grille doit être **élastique**. Les blocs d'événements s'aimantent aux cellules de la grille (snap-to-grid) pour la propreté visuelle, mais peuvent être redimensionnés ou déplacés avec une certaine fluidité, entraînant des ajustements dynamiques des éléments dépendants.

### 2.3. La Visualisation Nodal des Connexions (Les "Fils")
Le concept le plus innovant est la matérialisation des liens entre les éléments. Lorsqu'un bloc d'événement est sélectionné, des **lignes de connexion visuelles** (similaires aux nœuds de Figma ou Unreal Engine) apparaissent pour relier cet événement à ses dépendances (ressources, autres événements, lieux). Ces "fils" doivent être contextuels et n'apparaître que sur demande pour éviter le "plat de spaghettis".

---

## 3. Composants de l'Interface et Comportements Attendus

### 3.1. Colonne Latérale Gauche : La Palette / Le Cockpit
*   **Éléments :** Logo LinkEvent, Nom du projet, Navigation principale (Tableau de bord, Tâches, Prestataires, etc.), et surtout la section **CATÉGORIES**.
*   **CATÉGORIES :** Chaque catégorie est un bouton/bloc coloré (rond plein, type picto timbre) avec son nom. La couleur de ce bloc doit être la couleur principale des événements de cette catégorie sur la grille.
*   **Interaction :** Un clic sur une catégorie dans la palette doit agir comme un filtre : seule cette catégorie est affichée sur la grille centrale, les autres étant masquées ou grisées. Un second clic désactive le filtre.
*   **Personnalisation :** La couleur principale de l'application (celle des accents et des éléments interactifs) doit être personnalisable via un clic sur le logo de l'application. Cette couleur doit être unique et appliquée de manière cohérente (principe de la palette de couleurs unique).

### 3.2. Grille Centrale : Le Canevas Interactif
*   **Axes :**  
    *   **Horizontal (Temps) :** Échelle de temps dynamique (jour, semaine, mois, année). Granularité des cellules : 15 min, 30 min, 1h, etc., ajustable par l'utilisateur.  
    *   **Vertical (Catégories/Ressources) :** Les lignes représentent les catégories d'événements ou des ressources spécifiques (Prestataires, Lieux, Équipes, etc.).
*   **Blocs d'Événements :**  
    *   Représentés par des rectangles colorés sur la grille, dont la couleur correspond à leur catégorie.  
    *   Contiennent un titre concis et une indication de durée.  
    *   **Interaction :** Glisser-déposer pour déplacer ou redimensionner. Le "snap-to-grid" doit être intelligent, permettant un alignement facile tout en autorisant des durées non standard.
*   **État Initial :** La grille doit apparaître **quasiment vide** au début d'un nouveau projet, invitant l'utilisateur à "peindre" son événement. Des "Patterns" (templates) pré-remplis pourront être proposés pour faciliter le démarrage.

### 3.3. Panneau Latéral Droit : Détails Contextuels
*   **Affichage :** Affiche les détails de l'événement sélectionné sur la grille.
*   **Contenu :** Informations générales (titre, durée, date, lieu, description), ressources associées (avec photos de profil rondes), notes, fichiers attachés, et surtout la section **CONNEXIONS**.
*   **CONNEXIONS :** Liste les dépendances de l'événement sélectionné (ex: "Traiteur précède Dîner", "Équipe de service concerne Dîner"). Ces connexions doivent être cliquables pour naviguer vers l'élément lié ou pour visualiser le "fil" correspondant sur la grille.

---

## 4. Logique des Connexions et Dépendances ("Les Fils")

La gestion des "fils" est cruciale pour la cohérence systémique.

*   **Visualisation Contextuelle :** Les lignes de connexion n'apparaissent que lorsqu'un bloc d'événement est sélectionné sur la grille. Elles doivent être visuellement distinctes (couleur lumineuse, épaisseur variable) et suivre des courbes douces pour ne pas surcharger l'interface.
*   **Types de Connexions :**  
    *   **Temporelles :** "Précède", "Succède", "Simultané".  
    *   **Ressources :** "Utilise", "Concerne", "Est responsable de".  
    *   **Lieu :** "Se déroule à".
*   **Gestion des Conflits :** Si une action de l'utilisateur (déplacement, redimensionnement) crée un conflit (ex: deux événements dépendants se chevauchent), le bloc ou le "fil" concerné doit changer de couleur (ex: rouge) ou clignoter pour alerter l'utilisateur.

---

## 5. Système de Design et Recommandations Techniques

### 5.1. Esthétique Générale
*   **Thème Sombre :** L'interface doit être construite sur un thème sombre pour un look moderne et épuré.
*   **Neumorphisme Léger :** Le fond doit être unifié avec un effet de neumorphisme subtil pour donner de la profondeur sans distraire.
*   **Palette de Couleurs Unique :** En dehors des couleurs des catégories, tous les accents et éléments interactifs doivent utiliser une seule teinte personnalisable par l'utilisateur (ex: un bleu profond, un vert forêt, un fuchsia). Pas de "Sparckles" ni de blocs roses.

### 5.2. Typographie et Icônes
*   **Typographie Moderne :** Utiliser une typographie claire et moderne, similaire à celle des boutons 'AI' et 'ME' des maquettes initiales, évitant la typographie actuelle de l'application.
*   **Icônes :** Les pictos doivent être modernes, distincts des boutons de filtre génériques. Les profils d'utilisateurs/ressources doivent être des ronds pleins, potentiellement sous forme de picto timbre.
*   **Lisibilité :** Le texte de conversation doit être en gris foncé, les textes importants en gras noir. Éviter le texte blanc sur fond presque blanc.

### 5.3. Recommandations Techniques pour Base 44
*   **Framework Frontend :** Utiliser un framework moderne (React, Vue, Angular) avec une bibliothèque de composants UI robuste.
*   **Gestion de l'État :** Prévoir une gestion d'état centralisée pour les données de la grille et les interactions.
*   **API :** L'API doit être conçue pour gérer les relations complexes entre les événements, les ressources et les dépendances.
*   **Optimisation des Performances :** La grille interactive, surtout avec la visualisation des "fils", nécessitera une optimisation des performances pour une expérience fluide (virtualisation des listes, rendu optimisé).
*   **Accessibilité :** S'assurer que l'interface est accessible aux utilisateurs ayant des besoins spécifiques.

---

## 6. Maquettes Visuelles (Référence)

Voici les maquettes générées pour illustrer les concepts clés. Elles sont fournies à titre indicatif pour guider l'implémentation.

### 6.1. Vue d'Ensemble du Cockpit
Cette maquette présente la structure générale de l'interface avec la palette latérale, la grille centrale et le panneau de détails.

![Vue d'ensemble du Cockpit](/manus-storage/cockpit_overview.png)

### 6.2. Filtrage par la Palette (Mode "Fil Traiteur")
Cette maquette illustre l'effet de filtrage lorsque seule une catégorie (ex: Réception) est sélectionnée dans la palette, n'affichant que les événements correspondants sur la grille.

![Filtrage par la Palette](/manus-storage/palette_filtering.png)

### 6.3. Visualisation des Connexions ("Les Fils")
Cette maquette montre comment les "fils" de connexion apparaissent lorsqu'un événement est sélectionné, reliant visuellement les dépendances.

![Visualisation des Connexions](/manus-storage/connections_visualization.png)

---

## Conclusion

L'interface "Grid Canvas" représente une opportunité unique pour LinkEvent de se positionner comme un leader innovant dans la gestion événementielle. En adoptant une approche systémique et visuelle, elle permettra aux utilisateurs d'organiser des projets complexes avec une clarté et une intuitivité inégalées. Nous sommes convaincus que Base 44 saura transformer cette vision en une réalité technique exceptionnelle.

---
### Références
[1] Rapport d'Audit Stratégique - LinkEvent Grid Canvas, Manus AI, 2026.
`;

  return (
    <div className="p-4">
      <Streamdown>{auditContent}</Streamdown>
    </div>
  );
};

export default TechnicalDossier;
