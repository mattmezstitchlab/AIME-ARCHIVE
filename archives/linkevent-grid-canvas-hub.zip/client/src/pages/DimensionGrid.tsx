import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import {
  Clock, MapPin, Users, Package, Zap, FileText,
  Brain, MessageSquare, DollarSign, Heart, CheckSquare,
  Link2, ChevronRight, ChevronLeft, X, AlertCircle,
  CheckCircle2, Circle, Sparkles, ArrowRight, Grid3X3,
  LayoutDashboard, Calendar, Briefcase, FileStack,
  BookOpen, Settings
} from 'lucide-react';

// ─── 12 Dimensions ────────────────────────────────────────────────────────────
const DIMENSIONS = [
  {
    id: 'TEMPS', label: 'Temps', icon: Clock,
    color: '#00e5ff', bg: 'from-cyan-900/40 to-cyan-950/20', border: 'border-cyan-500/30',
    accent: 'text-cyan-400', badge: 'bg-cyan-500/20 text-cyan-300',
    description: 'Dates, horaires, durées, délais, séquences',
  },
  {
    id: 'ESPACE', label: 'Espace', icon: MapPin,
    color: '#10b981', bg: 'from-emerald-900/40 to-emerald-950/20', border: 'border-emerald-500/30',
    accent: 'text-emerald-400', badge: 'bg-emerald-500/20 text-emerald-300',
    description: 'Lieux, adresses, distances, plans',
  },
  {
    id: 'PERSONNES', label: 'Personnes', icon: Users,
    color: '#7c3aed', bg: 'from-violet-900/40 to-violet-950/20', border: 'border-violet-500/30',
    accent: 'text-violet-400', badge: 'bg-violet-500/20 text-violet-300',
    description: 'Individus, rôles, relations, contacts',
  },
  {
    id: 'RESSOURCES', label: 'Ressources', icon: Package,
    color: '#f97316', bg: 'from-orange-900/40 to-orange-950/20', border: 'border-orange-500/30',
    accent: 'text-orange-400', badge: 'bg-orange-500/20 text-orange-300',
    description: 'Matériaux, équipements, stocks, fournitures',
  },
  {
    id: 'ACTIONS', label: 'Actions', icon: Zap,
    color: '#fbbf24', bg: 'from-yellow-900/40 to-yellow-950/20', border: 'border-yellow-500/30',
    accent: 'text-yellow-400', badge: 'bg-yellow-500/20 text-yellow-300',
    description: 'Tâches, décisions, procédures, étapes',
  },
  {
    id: 'DOCUMENTS', label: 'Documents', icon: FileText,
    color: '#64748b', bg: 'from-slate-700/40 to-slate-800/20', border: 'border-slate-500/30',
    accent: 'text-slate-300', badge: 'bg-slate-500/20 text-slate-300',
    description: 'Fichiers, contrats, formulaires, archives',
  },
  {
    id: 'MEMOIRE', label: 'Mémoire', icon: Brain,
    color: '#a78bfa', bg: 'from-purple-900/40 to-purple-950/20', border: 'border-purple-500/30',
    accent: 'text-purple-400', badge: 'bg-purple-500/20 text-purple-300',
    description: 'Souvenirs, histoires, traditions, héritages',
  },
  {
    id: 'COMMUNICATION', label: 'Communication', icon: MessageSquare,
    color: '#38bdf8', bg: 'from-sky-900/40 to-sky-950/20', border: 'border-sky-500/30',
    accent: 'text-sky-400', badge: 'bg-sky-500/20 text-sky-300',
    description: 'Messages, notifications, invitations, annonces',
  },
  {
    id: 'ECONOMIE', label: 'Économie', icon: DollarSign,
    color: '#34d399', bg: 'from-teal-900/40 to-teal-950/20', border: 'border-teal-500/30',
    accent: 'text-teal-400', badge: 'bg-teal-500/20 text-teal-300',
    description: 'Budgets, factures, paiements, coûts',
  },
  {
    id: 'EMOTIONS', label: 'Émotions', icon: Heart,
    color: '#f43f5e', bg: 'from-rose-900/40 to-rose-950/20', border: 'border-rose-500/30',
    accent: 'text-rose-400', badge: 'bg-rose-500/20 text-rose-300',
    description: 'Sentiments, intentions, ambiances, désirs',
  },
  {
    id: 'VALIDATION', label: 'Validation', icon: CheckSquare,
    color: '#22c55e', bg: 'from-green-900/40 to-green-950/20', border: 'border-green-500/30',
    accent: 'text-green-400', badge: 'bg-green-500/20 text-green-300',
    description: 'Confirmations, approbations, signatures, statuts',
  },
  {
    id: 'RELATIONS', label: 'Relations', icon: Link2,
    color: '#e879f9', bg: 'from-fuchsia-900/40 to-fuchsia-950/20', border: 'border-fuchsia-500/30',
    accent: 'text-fuchsia-400', badge: 'bg-fuchsia-500/20 text-fuchsia-300',
    description: 'Liens, dépendances, associations, connexions',
  },
];

const MATURATION_STATES = [
  { id: 'empty', label: 'Vide', color: 'text-slate-600', dot: 'bg-slate-700' },
  { id: 'detected', label: 'Détecté', color: 'text-blue-400', dot: 'bg-blue-500' },
  { id: 'illuminated', label: 'Illuminé', color: 'text-yellow-400', dot: 'bg-yellow-500' },
  { id: 'ready', label: 'Prêt', color: 'text-orange-400', dot: 'bg-orange-500' },
  { id: 'validated', label: 'Validé', color: 'text-green-400', dot: 'bg-green-500' },
  { id: 'ambiguous', label: 'Ambigu', color: 'text-red-400', dot: 'bg-red-500' },
];

const navItems = [
  { id: 'point-zero', label: 'Point Zéro', icon: Sparkles, href: '/point-zero' },
  { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard, href: '/dashboard' },
  { id: 'grid', label: 'Grille interne', icon: Grid3X3, active: true, href: '/admin/grid' },
  { id: 'families', label: 'Familles', icon: Users, href: '/families' },
  { id: 'events', label: 'Événements', icon: Calendar, href: '/events' },
  { id: 'vendors', label: 'Prestataires', icon: Briefcase, href: '/vendors' },
  { id: 'documents', label: 'Documents', icon: FileStack, href: '/documents' },
  { id: 'memories', label: 'Mémoires', icon: BookOpen, href: '/memories' },
  { id: 'settings', label: 'Paramètres', icon: Settings, href: '/settings' },
];

// ─── Node Detail Panel ────────────────────────────────────────────────────────
function NodeDetailPanel({ item, dimension, onClose }: {
  item: any;
  dimension: typeof DIMENSIONS[0];
  onClose: () => void;
}) {
  const Icon = dimension.icon;
  const matState = MATURATION_STATES.find(s => s.id === item.maturationState) ?? MATURATION_STATES[1];

  return (
    <motion.div
      initial={{ x: '100%', opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: '100%', opacity: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="fixed right-0 top-0 h-full w-[420px] bg-slate-950 border-l border-slate-800 z-50 overflow-y-auto shadow-2xl"
    >
      {/* Header */}
      <div className={`p-5 bg-gradient-to-r ${dimension.bg} border-b ${dimension.border}`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: dimension.color + '20', border: `1px solid ${dimension.color}40` }}>
              <Icon className="w-5 h-5" style={{ color: dimension.color }} />
            </div>
            <div>
              <p className="text-[10px] font-bold tracking-widest uppercase" style={{ color: dimension.color }}>
                {dimension.label}
              </p>
              <p className="text-sm font-semibold text-white mt-0.5 line-clamp-2">
                {item.content?.substring(0, 60) ?? 'Élément'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-5 space-y-5">
        {/* Maturation state */}
        <div>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">État de maturation</p>
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${matState.dot}`} />
            <span className={`text-sm font-medium ${matState.color}`}>{matState.label}</span>
          </div>
        </div>

        {/* Confidence */}
        <div>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">Confiance IA</p>
          <div className="flex items-center gap-3">
            <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${item.confidence ?? 70}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
                className="h-full rounded-full"
                style={{ backgroundColor: dimension.color }}
              />
            </div>
            <span className="text-sm font-bold" style={{ color: dimension.color }}>{item.confidence ?? 70}%</span>
          </div>
        </div>

        {/* Classification reason */}
        {item.classificationReason && (
          <div>
            <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">Raison de classification</p>
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <p className="text-xs text-slate-300 leading-relaxed">{item.classificationReason}</p>
            </div>
          </div>
        )}

        {/* Source content */}
        <div>
          <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">Contenu source</p>
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <p className="text-xs text-slate-400 leading-relaxed font-mono">{item.content ?? 'Contenu non disponible'}</p>
          </div>
        </div>

        {/* All dimensions */}
        {item.dimensions && (() => {
          const dims = typeof item.dimensions === 'string' ? JSON.parse(item.dimensions) : item.dimensions;
          if (!Array.isArray(dims) || dims.length === 0) return null;
          return (
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">Dimensions assignées</p>
              <div className="flex flex-wrap gap-2">
                {dims.map((d: string, i: number) => {
                  const dim = DIMENSIONS.find(x => x.id === d);
                  if (!dim) return null;
                  const DimIcon = dim.icon;
                  return (
                    <span key={i} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium ${dim.badge}`}>
                      <DimIcon className="w-3 h-3" />
                      {dim.label}
                    </span>
                  );
                })}
              </div>
            </div>
          );
        })()}

        {/* Projections */}
        {item.projections && (() => {
          const projs = typeof item.projections === 'string' ? JSON.parse(item.projections) : item.projections;
          if (!Array.isArray(projs) || projs.length === 0) return null;
          return (
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">Projections possibles</p>
              <div className="space-y-2">
                {projs.map((p: any, i: number) => (
                  <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <ArrowRight className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-[11px] font-medium text-slate-200">{p.action ?? p}</p>
                      {p.reason && <p className="text-[10px] text-slate-500 mt-0.5">{p.reason}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        {/* Links */}
        {item.linksCreated && (() => {
          const links = typeof item.linksCreated === 'string' ? JSON.parse(item.linksCreated) : item.linksCreated;
          if (!Array.isArray(links) || links.length === 0) return null;
          return (
            <div>
              <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">Liens détectés</p>
              <div className="space-y-2">
                {links.map((link: any, i: number) => (
                  <div key={i} className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <Link2 className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-medium text-blue-300">{link.type ?? 'related'}</p>
                      <p className="text-[10px] text-slate-400 truncate">{link.targetHint ?? link.target ?? ''}</p>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 flex-shrink-0">{link.strength ?? link.force ?? 0}%</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        {/* Ambiguity */}
        {!item.isClear && item.clarificationReason && (
          <div className="p-3 rounded-lg bg-orange-950/30 border border-orange-500/30">
            <div className="flex items-center gap-2 mb-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-orange-400" />
              <p className="text-[10px] font-bold text-orange-400 uppercase tracking-wider">Zone grise</p>
            </div>
            <p className="text-xs text-orange-200/80">{item.clarificationReason}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ─── Dimension Card ───────────────────────────────────────────────────────────
function DimensionCard({
  dimension,
  items,
  isSelected,
  onClick,
}: {
  dimension: typeof DIMENSIONS[0];
  items: any[];
  isSelected: boolean;
  onClick: () => void;
}) {
  const Icon = dimension.icon;
  const validated = items.filter(i => i.maturationState === 'validated').length;
  const ready = items.filter(i => i.maturationState === 'ready').length;
  const ambiguous = items.filter(i => !i.isClear || i.maturationState === 'ambiguous').length;
  const detected = items.filter(i => i.maturationState === 'detected' || i.maturationState === 'illuminated').length;

  return (
    <motion.div
      onClick={onClick}
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative cursor-pointer rounded-xl border p-4 transition-all ${
        isSelected
          ? `bg-gradient-to-br ${dimension.bg} ${dimension.border} shadow-lg`
          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
      }`}
      style={isSelected ? { boxShadow: `0 0 20px ${dimension.color}20` } : {}}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{
              backgroundColor: isSelected ? dimension.color + '25' : '#1e293b',
              border: `1px solid ${isSelected ? dimension.color + '50' : '#334155'}`,
            }}
          >
            <Icon className="w-4.5 h-4.5" style={{ color: isSelected ? dimension.color : '#64748b' }} />
          </div>
          <div>
            <p className="text-xs font-bold" style={{ color: isSelected ? dimension.color : '#94a3b8' }}>
              {dimension.label}
            </p>
            <p className="text-[10px] text-slate-600 leading-tight mt-0.5">{dimension.description}</p>
          </div>
        </div>
        <span
          className="text-lg font-bold"
          style={{ color: isSelected ? dimension.color : '#475569' }}
        >
          {items.length}
        </span>
      </div>

      {/* Maturation bar */}
      {items.length > 0 && (
        <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden flex gap-0.5 mb-3">
          {validated > 0 && (
            <div className="h-full bg-green-500 rounded-full" style={{ width: `${(validated / items.length) * 100}%` }} />
          )}
          {ready > 0 && (
            <div className="h-full bg-orange-500 rounded-full" style={{ width: `${(ready / items.length) * 100}%` }} />
          )}
          {detected > 0 && (
            <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(detected / items.length) * 100}%` }} />
          )}
          {ambiguous > 0 && (
            <div className="h-full bg-red-500 rounded-full" style={{ width: `${(ambiguous / items.length) * 100}%` }} />
          )}
        </div>
      )}

      {/* Stats row */}
      <div className="flex gap-2 flex-wrap">
        {validated > 0 && (
          <span className="flex items-center gap-1 text-[10px] text-green-400">
            <CheckCircle2 className="w-3 h-3" />{validated} validé{validated > 1 ? 's' : ''}
          </span>
        )}
        {ready > 0 && (
          <span className="flex items-center gap-1 text-[10px] text-orange-400">
            <Circle className="w-3 h-3" />{ready} prêt{ready > 1 ? 's' : ''}
          </span>
        )}
        {ambiguous > 0 && (
          <span className="flex items-center gap-1 text-[10px] text-red-400">
            <AlertCircle className="w-3 h-3" />{ambiguous} ambigu{ambiguous > 1 ? 's' : ''}
          </span>
        )}
        {items.length === 0 && (
          <span className="text-[10px] text-slate-700 italic">Aucun élément</span>
        )}
      </div>

      {/* Selected indicator */}
      {isSelected && (
        <motion.div
          layoutId="selectedDim"
          className="absolute bottom-0 left-0 right-0 h-0.5 rounded-b-xl"
          style={{ backgroundColor: dimension.color }}
        />
      )}
    </motion.div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function DimensionGrid() {
  const [, navigate] = useLocation();
  const [selectedDimension, setSelectedDimension] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const { data: gridData, isLoading } = trpc.classification.getInternalGrid.useQuery(
    {},
    { refetchInterval: 10000 }
  );

  const allItems: any[] = gridData?.items ?? [];
  const allCategories: any[] = gridData?.categories ?? [];

  // Group items by dimension
  const itemsByDimension = DIMENSIONS.reduce((acc, dim) => {
    acc[dim.id] = allItems.filter(item => {
      if (item.dimension === dim.id) return true;
      if (item.dimensions) {
        const dims = typeof item.dimensions === 'string' ? JSON.parse(item.dimensions) : item.dimensions;
        return Array.isArray(dims) && dims.includes(dim.id);
      }
      return false;
    });
    return acc;
  }, {} as Record<string, any[]>);

  const selectedDim = DIMENSIONS.find(d => d.id === selectedDimension);
  const selectedItems = selectedDimension ? (itemsByDimension[selectedDimension] ?? []) : [];

  const totalItems = allItems.length;
  const totalValidated = allItems.filter(i => i.maturationState === 'validated').length;
  const totalAmbiguous = allItems.filter(i => !i.isClear).length;
  const filledDimensions = DIMENSIONS.filter(d => (itemsByDimension[d.id] ?? []).length > 0).length;

  return (
    <div className="flex h-screen bg-[#060b14] text-slate-200 overflow-hidden font-[Inter,sans-serif]">

      {/* ── Sidebar ── */}
      <aside className="w-[160px] flex-shrink-0 flex flex-col bg-[#080e1a] border-r border-slate-800/60">
        <div className="p-4 border-b border-slate-800/60">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center">
              <span className="text-white text-[10px] font-black">LE</span>
            </div>
            <div>
              <p className="text-xs font-bold text-white">LinkEvent</p>
              <p className="text-[9px] text-slate-600">Grille Universelle</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-2 space-y-0.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.href)}
                className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-all ${
                  item.active
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/20'
                    : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="text-[11px] font-medium truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="p-3 border-t border-slate-800/60">
          <p className="text-[9px] text-slate-700 text-center">LinkEvent v1.0</p>
          <p className="text-[9px] text-slate-700 text-center">Moteur Fractal</p>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* Header */}
        <header className="flex-shrink-0 flex items-center justify-between px-6 py-3 border-b border-slate-800/60 bg-[#080e1a]/80 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <Grid3X3 className="w-5 h-5 text-cyan-400" />
            <div>
              <h1 className="text-base font-bold text-white tracking-wide">GRILLE INTERNE</h1>
              <p className="text-[10px] text-slate-500">12 dimensions universelles · Moteur fractal</p>
            </div>
          </div>

          {/* Global stats */}
          <div className="flex items-center gap-4">
            {[
              { label: 'Dimensions actives', value: filledDimensions, color: 'text-cyan-400' },
              { label: 'Éléments classés', value: totalItems, color: 'text-violet-400' },
              { label: 'Validés', value: totalValidated, color: 'text-green-400' },
              { label: 'Ambigus', value: totalAmbiguous, color: 'text-orange-400' },
            ].map((s, i) => (
              <div key={i} className="text-center">
                <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
                <p className="text-[9px] text-slate-600">{s.label}</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => navigate('/point-zero')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs hover:bg-cyan-500/20 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Point Zéro
          </button>
        </header>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">

          {/* ── 12 Dimensions Grid ── */}
          <div className={`transition-all duration-300 ${selectedDimension ? 'w-[55%]' : 'flex-1'} overflow-y-auto p-5`}>
            {isLoading ? (
              <div className="flex items-center justify-center h-40">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full"
                />
              </div>
            ) : (
              <>
                <div className="grid grid-cols-3 gap-3 mb-5">
                  {DIMENSIONS.map((dim, i) => (
                    <motion.div
                      key={dim.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <DimensionCard
                        dimension={dim}
                        items={itemsByDimension[dim.id] ?? []}
                        isSelected={selectedDimension === dim.id}
                        onClick={() => setSelectedDimension(
                          selectedDimension === dim.id ? null : dim.id
                        )}
                      />
                    </motion.div>
                  ))}
                </div>

                {/* Empty state */}
                {totalItems === 0 && (
                  <div className="text-center py-12">
                    <motion.div
                      animate={{ scale: [1, 1.05, 1], opacity: [0.5, 1, 0.5] }}
                      transition={{ duration: 3, repeat: Infinity }}
                      className="text-5xl mb-4"
                    >
                      🧠
                    </motion.div>
                    <p className="text-slate-400 text-sm font-medium mb-2">La grille est vide</p>
                    <p className="text-slate-600 text-xs mb-4">Déposez du contenu au Point Zéro pour voir les dimensions se remplir</p>
                    <button
                      onClick={() => navigate('/point-zero')}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs hover:bg-cyan-500/20 transition-all mx-auto"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      Aller au Point Zéro
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>

          {/* ── Dimension Detail Panel ── */}
          <AnimatePresence>
            {selectedDimension && selectedDim && (
              <motion.div
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: '45%', opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="border-l border-slate-800/60 overflow-hidden flex-shrink-0"
              >
                <div className="h-full overflow-y-auto">
                  {/* Panel header */}
                  <div className={`sticky top-0 z-10 p-4 bg-gradient-to-r ${selectedDim.bg} border-b ${selectedDim.border} backdrop-blur-sm`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: selectedDim.color + '25', border: `1px solid ${selectedDim.color}50` }}
                        >
                          <selectedDim.icon className="w-4 h-4" style={{ color: selectedDim.color }} />
                        </div>
                        <div>
                          <p className="text-xs font-bold" style={{ color: selectedDim.color }}>{selectedDim.label}</p>
                          <p className="text-[10px] text-slate-500">{selectedItems.length} nœud{selectedItems.length > 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setSelectedDimension(null)}
                        className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Nodes list */}
                  <div className="p-4 space-y-2">
                    {selectedItems.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-slate-600 text-xs italic">Aucun nœud dans cette dimension</p>
                      </div>
                    ) : (
                      selectedItems.map((item: any, i: number) => {
                        const matState = MATURATION_STATES.find(s => s.id === item.maturationState) ?? MATURATION_STATES[1];
                        return (
                          <motion.button
                            key={i}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}
                            onClick={() => setSelectedItem(item)}
                            className="w-full text-left p-3 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 transition-all group"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <p className="text-xs text-slate-300 truncate font-medium">
                                  {item.content?.substring(0, 60) ?? 'Élément'}
                                </p>
                                {item.classificationReason && (
                                  <p className="text-[10px] text-slate-600 mt-1 line-clamp-2">
                                    {item.classificationReason}
                                  </p>
                                )}
                              </div>
                              <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                                <div className="flex items-center gap-1">
                                  <span className={`w-1.5 h-1.5 rounded-full ${matState.dot}`} />
                                  <span className={`text-[10px] ${matState.color}`}>{matState.label}</span>
                                </div>
                                <span
                                  className="text-[10px] font-bold px-1.5 py-0.5 rounded"
                                  style={{
                                    backgroundColor: selectedDim.color + '20',
                                    color: selectedDim.color,
                                  }}
                                >
                                  {item.confidence ?? 70}%
                                </span>
                              </div>
                            </div>
                            {!item.isClear && (
                              <div className="flex items-center gap-1.5 mt-2 px-2 py-1 rounded-lg bg-orange-950/30 border border-orange-500/20">
                                <AlertCircle className="w-3 h-3 text-orange-400 flex-shrink-0" />
                                <p className="text-[10px] text-orange-300 truncate">{item.clarificationReason ?? 'Zone grise'}</p>
                              </div>
                            )}
                            <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <span className="text-[10px] text-slate-500">Voir détails</span>
                              <ChevronRight className="w-3 h-3 text-slate-500" />
                            </div>
                          </motion.button>
                        );
                      })
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ── Node Detail Overlay ── */}
      <AnimatePresence>
        {selectedItem && selectedDim && (
          <NodeDetailPanel
            item={selectedItem}
            dimension={selectedDim}
            onClose={() => setSelectedItem(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
