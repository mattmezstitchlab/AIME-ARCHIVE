import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Streamdown } from 'streamdown';

/**
 * Page d'accueil du Grid Canvas - Canevas de Planification Systémique
 * Cette page représentera le canevas de planification avec la grille temporelle,
 * les blocs d'événements et les connexions, en fonction des filtres de la palette latérale.
 */
export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  if (loading) {
    return (
      <div className="flex-grow w-full h-full bg-card rounded-lg shadow-inner p-4 flex items-center justify-center">
        <p className="text-muted-foreground">Chargement...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex-grow w-full h-full bg-card rounded-lg shadow-inner p-4 flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold mb-4">Bienvenue dans LinkEvent Grid Canvas</h2>
        <p className="text-muted-foreground mb-6">Connectez-vous pour commencer à planifier votre événement</p>
        <Button onClick={() => window.location.href = getLoginUrl()}>
          Se connecter
        </Button>
      </div>
    );
  }

  return (
    <div className="flex-grow w-full h-full bg-card rounded-lg shadow-inner p-4">
      {/* Placeholder pour la grille temporelle */}
      <div className="text-muted-foreground text-center py-20">
        <p className="text-lg">Canevas de Planification Systémique</p>
        <p className="text-sm">Les événements et leurs connexions apparaîtront ici.</p>
        <p className="text-xs mt-4">Connecté en tant que: {user?.name || user?.email}</p>
      </div>
      {/* Ici sera implémentée la logique de la grille, des blocs et des fils */}
    </div>
  );
}
