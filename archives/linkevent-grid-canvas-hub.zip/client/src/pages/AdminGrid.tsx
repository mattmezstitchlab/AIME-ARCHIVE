import { useAuth } from '@/_core/hooks/useAuth';
import { useLocation } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import InternalGrid from '@/components/InternalGrid';
import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';

export default function AdminGrid() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [eventId, setEventId] = useState<number | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);

  // Récupérer les événements de l'utilisateur (pour le moment, on simule)
  const [events, setEvents] = useState<any[]>([]);
  const [eventsLoading, setEventsLoading] = useState(false);

  useEffect(() => {
    // TODO: Implémenter getEvents dans weddingAnalysisRouter
    // Pour le moment, on peut récupérer depuis le cockpit
    setEvents([]);
  }, [isAuthenticated]);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  if (!user?.role || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-6 flex items-center justify-center">
        <Card className="bg-slate-800/50 border-slate-700 p-8 max-w-md text-center">
          <p className="text-slate-400 mb-4">🔒 Accès réservé aux administrateurs</p>
          <Button onClick={() => navigate('/')} className="w-full bg-blue-600 hover:bg-blue-700">
            Retour à l'accueil
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-4xl font-bold text-slate-100 mb-2">🎛️ Interface de Contrôle</h1>
          <p className="text-slate-400">Grille interne - Moteur de classement fractal</p>
        </motion.div>

        {/* Sélection d'événement */}
        {!eventId ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <Card className="bg-slate-800/50 border-slate-700 p-8">
              <h2 className="text-2xl font-bold text-slate-100 mb-6">Sélectionnez un événement</h2>

              {eventsLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin text-2xl">⚙️</div>
                  <p className="text-slate-400 ml-4">Chargement des événements...</p>
                </div>
              ) : !events || events.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-slate-400 mb-4">Aucun événement trouvé</p>
                  <Button onClick={() => navigate('/cockpit')} className="bg-blue-600 hover:bg-blue-700">
                    Créer un événement
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {events.map((event: any) => (
                    <motion.button
                      key={event.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setEventId(event.id);
                        setSelectedEvent(event);
                      }}
                      className="p-4 bg-slate-800/30 border border-slate-700 rounded-lg hover:border-blue-600/50 transition-colors text-left"
                    >
                      <p className="text-slate-100 font-semibold">{event.title}</p>
                      <p className="text-slate-400 text-sm mt-1">
                        {new Date(event.eventDate).toLocaleDateString('fr-FR')}
                      </p>
                      <p className="text-slate-500 text-xs mt-2">
                        Status: <span className="text-blue-400">{event.status}</span>
                      </p>
                    </motion.button>
                  ))}
                </div>
              )}
            </Card>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            {/* Header avec événement sélectionné */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-100">{selectedEvent?.title}</h2>
                <p className="text-slate-400 text-sm">
                  {new Date(selectedEvent?.eventDate).toLocaleDateString('fr-FR')}
                </p>
              </div>
              <Button
                onClick={() => {
                  setEventId(null);
                  setSelectedEvent(null);
                }}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-800"
              >
                ← Retour
              </Button>
            </div>

            {/* Grille interne */}
            <InternalGrid eventId={eventId} />
          </motion.div>
        )}
      </div>
    </div>
  );
}
