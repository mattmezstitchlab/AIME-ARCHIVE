import { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ClassificationCard, { type ClassificationResult as CardResult } from '@/components/ClassificationCard';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import {
  Upload, FileText, Image, FileArchive, Mic,
  Grid3X3, LayoutDashboard, Users, Calendar,
  Briefcase, FileStack, BookOpen, Settings,
  Zap, Link2, AlertCircle, CheckCircle2,
  ChevronRight, Plus, ArrowRight, Sparkles,
  Brain, Network, Layers, Eye
} from 'lucide-react';

// ─── Navigation Items ───────────────────────────────────────────────────────
const navItems = [
  { id: 'point-zero', label: 'Point Zéro', icon: Sparkles, active: true, href: '/point-zero' },
  { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard, href: '/dashboard' },
  { id: 'grid', label: 'Grille interne', icon: Grid3X3, href: '/admin/grid' },
  { id: 'families', label: 'Familles', icon: Users, href: '/families' },
  { id: 'events', label: 'Événements', icon: Calendar, href: '/events' },
  { id: 'vendors', label: 'Prestataires', icon: Briefcase, href: '/vendors' },
  { id: 'documents', label: 'Documents', icon: FileStack, href: '/documents' },
  { id: 'memories', label: 'Mémoires', icon: BookOpen, href: '/memories' },
  { id: 'settings', label: 'Paramètres', icon: Settings, href: '/settings' },
];

// ─── Fractal Grid Canvas ─────────────────────────────────────────────────────
function FractalCanvas({ isAnimating }: { isAnimating: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    if (!ctx) return;

    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight;

    // Isometric grid nodes
    const nodes: Array<{
      x: number; y: number; z: number;
      sx: number; sy: number;
      color: string; label?: string;
      brightness: number; phase: number;
    }> = [];

    const COLS = 10, ROWS = 8;
    const ISO_X = 40, ISO_Y = 20;
    const OX = W * 0.5, OY = H * 0.18;

    const palette = [
      '#00e5ff', '#7c3aed', '#f97316', '#10b981',
      '#f43f5e', '#a78bfa', '#fbbf24', '#34d399',
    ];

    const labels = [
      { col: 2, row: 2, text: 'Famille Martin', count: '8 éléments' },
      { col: 7, row: 1, text: 'Prestataires', count: '12 éléments' },
      { col: 4, row: 5, text: 'Dates & Horaires', count: '6 éléments' },
      { col: 8, row: 5, text: 'Souvenirs', count: '7 éléments' },
      { col: 7, row: 6, text: 'Budget', count: '5 éléments' },
    ];

    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const sx = OX + (c - r) * ISO_X;
        const sy = OY + (c + r) * ISO_Y;
        const isLabeled = labels.some(l => l.col === c && l.row === r);
        const colorIdx = isLabeled
          ? Math.floor(Math.random() * palette.length)
          : Math.random() > 0.6 ? Math.floor(Math.random() * palette.length) : -1;

        nodes.push({
          x: c, y: r, z: 0,
          sx, sy,
          color: colorIdx >= 0 ? palette[colorIdx] : '#1e293b',
          label: isLabeled ? labels.find(l => l.col === c && l.row === r)?.text : undefined,
          brightness: Math.random(),
          phase: Math.random() * Math.PI * 2,
        });
      }
    }

    // Connections between labeled nodes
    const connections: Array<[number, number]> = [
      [2 * COLS + 2, 1 * COLS + 7],
      [5 * COLS + 4, 6 * COLS + 7],
      [5 * COLS + 4, 5 * COLS + 8],
      [1 * COLS + 7, 5 * COLS + 8],
    ];

    function drawCube(
      ctx: CanvasRenderingContext2D,
      sx: number, sy: number,
      size: number, color: string, alpha: number
    ) {
      const h = size * 0.6;
      ctx.globalAlpha = alpha;

      // Top face
      ctx.beginPath();
      ctx.moveTo(sx, sy - h);
      ctx.lineTo(sx + size, sy - h * 0.4);
      ctx.lineTo(sx, sy);
      ctx.lineTo(sx - size, sy - h * 0.4);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();

      // Left face
      ctx.beginPath();
      ctx.moveTo(sx - size, sy - h * 0.4);
      ctx.lineTo(sx, sy);
      ctx.lineTo(sx, sy + h * 0.6);
      ctx.lineTo(sx - size, sy + h * 0.2);
      ctx.closePath();
      ctx.fillStyle = shadeColor(color, -40);
      ctx.fill();

      // Right face
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + size, sy - h * 0.4);
      ctx.lineTo(sx + size, sy + h * 0.2);
      ctx.lineTo(sx, sy + h * 0.6);
      ctx.closePath();
      ctx.fillStyle = shadeColor(color, -20);
      ctx.fill();

      ctx.globalAlpha = 1;
    }

    function shadeColor(color: string, amount: number): string {
      const num = parseInt(color.replace('#', ''), 16);
      const r = Math.min(255, Math.max(0, (num >> 16) + amount));
      const g = Math.min(255, Math.max(0, ((num >> 8) & 0xff) + amount));
      const b = Math.min(255, Math.max(0, (num & 0xff) + amount));
      return `rgb(${r},${g},${b})`;
    }

    function draw(t: number) {
      ctx.clearRect(0, 0, W, H);

      // Background gradient
      const bg = ctx.createRadialGradient(W * 0.5, H * 0.5, 0, W * 0.5, H * 0.5, W * 0.7);
      bg.addColorStop(0, 'rgba(15,23,42,0)');
      bg.addColorStop(1, 'rgba(15,23,42,0)');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // Draw connections
      connections.forEach(([a, b]) => {
        if (a >= nodes.length || b >= nodes.length) return;
        const na = nodes[a], nb = nodes[b];
        const pulse = (Math.sin(t * 0.002 + na.phase) + 1) * 0.5;
        const grad = ctx.createLinearGradient(na.sx, na.sy, nb.sx, nb.sy);
        grad.addColorStop(0, `rgba(0,229,255,${0.3 + pulse * 0.4})`);
        grad.addColorStop(0.5, `rgba(124,58,237,${0.5 + pulse * 0.3})`);
        grad.addColorStop(1, `rgba(0,229,255,${0.3 + pulse * 0.4})`);
        ctx.beginPath();
        ctx.moveTo(na.sx, na.sy);
        ctx.lineTo(nb.sx, nb.sy);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Moving particle along line
        const progress = (t * 0.0005 + na.phase) % 1;
        const px = na.sx + (nb.sx - na.sx) * progress;
        const py = na.sy + (nb.sy - na.sy) * progress;
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#00e5ff';
        ctx.fill();
      });

      // Draw nodes
      nodes.forEach((node) => {
        const pulse = isAnimating
          ? (Math.sin(t * 0.001 + node.phase) + 1) * 0.5
          : node.brightness;
        const size = 14;
        const alpha = node.color === '#1e293b' ? 0.4 : 0.6 + pulse * 0.4;

        // Glow for colored nodes
        if (node.color !== '#1e293b') {
          ctx.shadowColor = node.color;
          ctx.shadowBlur = 8 + pulse * 12;
        }

        drawCube(ctx, node.sx, node.sy, size, node.color, alpha);
        ctx.shadowBlur = 0;
      });

      // Draw labels
      labels.forEach((lbl) => {
        const node = nodes.find(n => n.x === lbl.col && n.y === lbl.row);
        if (!node) return;
        const pulse = (Math.sin(t * 0.001 + node.phase) + 1) * 0.5;
        const lx = node.sx + 20;
        const ly = node.sy - 30 - pulse * 5;

        ctx.globalAlpha = 0.85 + pulse * 0.15;

        // Label background
        const textW = ctx.measureText(lbl.text).width + 20;
        ctx.fillStyle = 'rgba(15,23,42,0.85)';
        ctx.strokeStyle = node.color;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(lx, ly - 22, textW, 40, 6);
        ctx.fill();
        ctx.stroke();

        // Label text
        ctx.fillStyle = '#e2e8f0';
        ctx.font = 'bold 11px Inter, sans-serif';
        ctx.fillText(lbl.text, lx + 10, ly - 6);
        ctx.fillStyle = node.color;
        ctx.font = '9px Inter, sans-serif';
        ctx.fillText(lbl.count, lx + 10, ly + 8);

        // Connector line
        ctx.beginPath();
        ctx.moveTo(node.sx, node.sy - 14);
        ctx.lineTo(lx, ly + 10);
        ctx.strokeStyle = `rgba(${hexToRgb(node.color)},0.5)`;
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.globalAlpha = 1;
      });

      // Center glow (Point Zéro)
      const cx = OX, cy = OY + (ROWS / 2) * ISO_Y;
      const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, 60);
      glow.addColorStop(0, `rgba(0,229,255,${0.3 + Math.sin(t * 0.002) * 0.2})`);
      glow.addColorStop(1, 'rgba(0,229,255,0)');
      ctx.fillStyle = glow;
      ctx.fillRect(cx - 60, cy - 60, 120, 120);
    }

    function hexToRgb(hex: string): string {
      const num = parseInt(hex.replace('#', ''), 16);
      return `${(num >> 16) & 255},${(num >> 8) & 255},${num & 255}`;
    }

    function loop(ts: number) {
      timeRef.current = ts;
      draw(ts);
      animFrameRef.current = requestAnimationFrame(loop);
    }

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isAnimating]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: 'block' }}
    />
  );
}

// ─── Circular Score ──────────────────────────────────────────────────────────
function CircularScore({ score }: { score: number }) {
  const r = 44;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;

  return (
    <div className="relative flex items-center justify-center w-28 h-28 mx-auto">
      <svg width="112" height="112" viewBox="0 0 112 112" className="-rotate-90">
        <circle cx="56" cy="56" r={r} fill="none" stroke="#1e293b" strokeWidth="8" />
        <motion.circle
          cx="56" cy="56" r={r}
          fill="none"
          stroke="url(#scoreGrad)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circ}`}
          initial={{ strokeDasharray: `0 ${circ}` }}
          animate={{ strokeDasharray: `${dash} ${circ}` }}
          transition={{ duration: 1.5, ease: 'easeOut' }}
        />
        <defs>
          <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00e5ff" />
            <stop offset="100%" stopColor="#7c3aed" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute text-center">
        <span className="text-2xl font-bold text-white">{score}%</span>
        <p className="text-[9px] text-slate-400 leading-tight">Confiance<br />globale</p>
      </div>
    </div>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────
export default function PointZero() {
  const [, navigate] = useLocation();
  const [textInput, setTextInput] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [classificationResult, setClassificationResult] = useState<any>(null);
  const [fractalMode, setFractalMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const analyzeVracMutation = trpc.weddingAnalysis.analyzeVrac.useMutation({
    onSuccess: (data: any) => {
      setAnalysisResult(data);
      setIsAnalyzing(false);
      toast.success('Analyse terminée ! 🎉');
      // Auto-classify
      if (data.eventId) {
        classifyMutation.mutate({ eventId: data.eventId, content: textInput, sourceType: "text" });
      }
    },
    onError: (err) => {
      setIsAnalyzing(false);
      toast.error(`Erreur : ${err.message}`);
    },
  });

  const classifyMutation = trpc.classification.classifyContent.useMutation({
    onSuccess: (data: any) => {
      setClassificationResult(data);
      toast.success('Classification terminée ! 🎛️');
    },
    onError: (err) => {
      console.error('[Classification Error]', err);
      toast.error(`Erreur de classification : ${err.message}`);
    },
  });

  const handleAnalyze = () => {
    if (!textInput.trim()) {
      toast.error('Veuillez entrer du contenu');
      return;
    }
    setIsAnalyzing(true);
    setFractalMode(true);
    analyzeVracMutation.mutate({ text: textInput, fileContents: [] });
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      const names = files.map(f => f.name).join(', ');
      setTextInput(prev => prev + `\n[Fichiers déposés: ${names}]`);
      toast.success(`${files.length} fichier(s) ajouté(s)`);
    }
  }, []);

  const handleLoadExample = () => {
    setTextInput(`Mariage Sophie & Marc - 14 septembre 2026

Cérémonie: 14:00 Mairie de Commines
Cocktail: 15:30 Château de Vaux
Dîner: 18:30 (140 invités)
Soirée: 21:00

Prestataires:
- Traiteur Delice: 06 12 34 56 78
- Photographe Marc: 06 98 76 54 32
- DJ Maxime: 06 11 22 33 44
- Fleuriste Roseline: 06 55 44 33 22
- Saxophoniste Laurent: 06 77 88 99 00

Témoins: Julie (sœur), Thomas (ami)
Coordinatrice: Émilie - 06 51 52 53 54

Notes: 20 enfants, navettes hôtel, allergies gluten/lactose
Budget total: 45 000€
Lieu de réception: Château de Vaux, 60 places parking`);
  };

  const handleLoadMessy = () => {
    setTextInput(`Date: 15 septembre 2026
Nom des mariés: Sophie & Marc
Facture: Traiteur Delice - 3500€
Souvenir: Première danse à 21h15
Horaire: 14:00 cérémonie à la mairie
Prestataire: DJ Maxime - 06 12 34 56 78
Phrase ambiguë: "Les choses importantes doivent se passer avant la pluie"
Photo: Château de Vaux
Allergies: Gluten, lactose
Invités: 140 personnes
Coordinatrice: Émilie
Note: Navettes hôtel à 13:30
Musique: Jazz pendant le cocktail
Fleuriste: Roseline - 06 55 44 33 22
Saxophone: Laurent à 21h30
Témoins: Julie (sœur), Thomas (ami)
Enfants: 20 enfants présents
Parking: 50 places disponibles`);
  };

  // Stats from real results
  const realCategories = classificationResult?.categories ?? [];
  const realItems = classificationResult?.items ?? [];
  const realLinks = classificationResult?.links ?? [];
  const realUnclarified = classificationResult?.unclarified ?? [];

  // Compute score from real data: avg confidence of classified items
  const avgConfidence = realItems.length > 0
    ? Math.round(realItems.reduce((sum: number, it: any) => sum + (it.confidence ?? 80), 0) / realItems.length)
    : (analysisResult ? 78 : 0);

  // Pending validation = items with confidence < 80
  const pendingValidation = realItems.filter((it: any) => (it.confidence ?? 80) < 80).length;

  const stats = {
    categories: realCategories.length > 0 ? realCategories.length : (analysisResult ? 5 : 0),
    items: realItems.length > 0 ? realItems.length
      : (analysisResult
          ? (analysisResult.analysis?.understood?.times?.length ?? 0) + (analysisResult.analysis?.understood?.vendors?.length ?? 0)
          : 0),
    links: realLinks.length > 0 ? realLinks.length : (analysisResult ? 0 : 0),
    grey: realUnclarified.length > 0 ? realUnclarified.length : (analysisResult ? 0 : 0),
    score: avgConfidence,
    pending: pendingValidation,
  };

  return (
    <div className="flex h-screen bg-[#080d1a] text-slate-100 overflow-hidden font-['Inter',sans-serif]">

      {/* ── Sidebar ── */}
      <aside className="w-[160px] flex-shrink-0 flex flex-col bg-[#0a1020] border-r border-slate-800/60">
        {/* Logo */}
        <div className="px-4 py-5 border-b border-slate-800/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center">
              <span className="text-white text-xs font-bold">LE</span>
            </div>
            <div>
              <p className="text-xs font-bold text-white leading-tight">LinkEvent</p>
              <p className="text-[9px] text-slate-500 leading-tight">Le fil qui nous relie</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 space-y-0.5 px-2 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => item.href && navigate(item.href)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all duration-150 ${
                  item.active
                    ? 'bg-gradient-to-r from-cyan-500/20 to-violet-500/10 text-cyan-400 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="text-[11px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-3 py-4 border-t border-slate-800/60">
          <p className="text-[9px] text-slate-600 leading-tight">LinkEvent v1.0</p>
          <p className="text-[9px] text-slate-600 leading-tight">Système de Mémoire Fractal</p>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Header */}
        <header className="flex-shrink-0 flex items-center justify-between px-6 py-3 border-b border-slate-800/60 bg-[#0a1020]/80 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            {/* Animated ring */}
            <div className="relative w-10 h-10">
              <motion.div
                className="absolute inset-0 rounded-full border-2 border-cyan-500/60"
                animate={{ scale: [1, 1.2, 1], opacity: [0.6, 0.2, 0.6] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <div className="absolute inset-1 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <Brain className="w-4 h-4 text-cyan-400" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-widest text-white">POINT ZÉRO</h1>
              <p className="text-xs text-slate-400">Déposez le chaos. Le système s'occupe du reste.</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <motion.button
              onClick={() => setFractalMode(!fractalMode)}
              whileTap={{ scale: 0.97 }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-medium transition-all ${
                fractalMode
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-cyan-500/30'
              }`}
            >
              <Network className="w-4 h-4" />
              Mode Fractal
              {fractalMode && (
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              )}
            </motion.button>

            <div className="flex items-center gap-2 px-3 py-2 bg-slate-800/60 border border-slate-700 rounded-lg">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
                <span className="text-white text-[10px] font-bold">PM</span>
              </div>
              <div className="text-right">
                <p className="text-xs font-semibold text-slate-200">Pilote de Mémoire</p>
                <p className="text-[10px] text-slate-500">Chef d'orchestre</p>
              </div>
            </div>
          </div>
        </header>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">

          {/* ── Left + Center ── */}
          <div className="flex-1 flex flex-col overflow-hidden">

            {/* Top two columns */}
            <div className="flex-1 flex gap-0 overflow-hidden">

              {/* Column 1: Drop zone */}
              <div className="w-[340px] flex-shrink-0 flex flex-col p-4 border-r border-slate-800/40 overflow-y-auto">
                <div className="mb-3">
                  <span className="text-[10px] font-bold tracking-widest text-cyan-400 uppercase">
                    1. Déposez votre chaos ici
                  </span>
                </div>

                {/* Drop zone */}
                <motion.div
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  animate={{ borderColor: isDragging ? '#00e5ff' : '#334155' }}
                  className="relative flex flex-col items-center justify-center gap-3 p-6 rounded-xl border-2 border-dashed border-slate-700 bg-slate-900/40 cursor-pointer hover:border-cyan-500/50 hover:bg-slate-900/60 transition-all min-h-[180px]"
                >
                  <input ref={fileInputRef} type="file" multiple className="hidden" />

                  {isDragging && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="absolute inset-0 rounded-xl bg-cyan-500/10 border-2 border-cyan-500"
                    />
                  )}

                  <div className="flex gap-3">
                    {[FileText, Image, FileArchive, Mic].map((Icon, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="w-9 h-9 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center"
                      >
                        <Icon className="w-4 h-4 text-slate-400" />
                      </motion.div>
                    ))}
                  </div>

                  <div className="text-center">
                    <p className="text-sm font-medium text-slate-300">Glissez tout type de contenu ici</p>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Textes, images, documents, notes vocales,<br />
                      dates, noms, factures, souvenirs…
                    </p>
                  </div>

                  <button
                    onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                    className="flex items-center gap-2 px-4 py-2 bg-violet-600/30 border border-violet-500/40 text-violet-300 text-xs rounded-lg hover:bg-violet-600/50 transition-all"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Parcourir les fichiers
                  </button>
                </motion.div>

                {/* Text input */}
                <div className="mt-4">
                  <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">
                    Ou collez votre contenu
                  </p>
                  <textarea
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="Collez ici vos notes, fragments, idées, informations..."
                    className="w-full h-28 bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-2.5 text-xs text-slate-300 placeholder-slate-600 resize-none focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/20 transition-all"
                  />
                </div>

                {/* Quick load buttons */}
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={handleLoadExample}
                    className="flex-1 text-[10px] px-2 py-1.5 bg-slate-800 border border-slate-700 text-slate-400 rounded hover:text-slate-200 hover:border-slate-600 transition-all"
                  >
                    📋 Exemple mariage
                  </button>
                  <button
                    onClick={handleLoadMessy}
                    className="flex-1 text-[10px] px-2 py-1.5 bg-slate-800 border border-slate-700 text-slate-400 rounded hover:text-slate-200 hover:border-slate-600 transition-all"
                  >
                    🎲 Contenu désordonné
                  </button>
                </div>

                {/* Analyze button */}
                <motion.button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || !textInput.trim()}
                  whileTap={{ scale: 0.97 }}
                  className="mt-4 w-full py-4 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white font-bold text-sm tracking-wider disabled:opacity-40 disabled:cursor-not-allowed hover:from-violet-500 hover:to-cyan-500 transition-all relative overflow-hidden"
                >
                  {isAnalyzing ? (
                    <span className="flex items-center justify-center gap-2">
                      <motion.span
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                        className="inline-block"
                      >
                        ⚙️
                      </motion.span>
                      Analyse en cours...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      ANALYSER ET ORGANISER
                      <ArrowRight className="w-4 h-4" />
                    </span>
                  )}
                  <p className="text-[10px] text-white/60 mt-0.5">Lancer le moteur fractal</p>
                </motion.button>
              </div>

              {/* Column 2: Fractal grid */}
              <div className="flex-1 flex flex-col p-4 overflow-hidden">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-widest text-orange-400 uppercase">
                    2. Le moteur fractal prend vie
                  </span>
                  {analysisResult && (
                    <span className="text-[10px] text-green-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Analyse complète
                    </span>
                  )}
                </div>

                {/* Status bar */}
                <div className="flex gap-3 mb-3 flex-wrap">
                  {[
                    { icon: '⚡', label: 'Analyse en cours', sub: 'IA active', color: 'text-cyan-400', active: isAnalyzing },
                    { icon: '🗂️', label: `${stats.categories} catégories`, sub: 'détectées', color: 'text-violet-400', active: !!analysisResult },
                    { icon: '📦', label: `${stats.items} éléments`, sub: 'classés', color: 'text-green-400', active: !!analysisResult },
                    { icon: '🔗', label: `${stats.links} liens`, sub: 'créés', color: 'text-orange-400', active: !!classificationResult },
                    { icon: '❓', label: `${stats.grey} zones grises`, sub: 'à clarifier', color: 'text-red-400', active: !!classificationResult },
                  ].map((s, i) => (
                    <div
                      key={i}
                      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] transition-all ${
                        s.active
                          ? 'bg-slate-800/80 border-slate-600'
                          : 'bg-slate-900/40 border-slate-800 opacity-40'
                      }`}
                    >
                      <span>{s.icon}</span>
                      <div>
                        <p className={`font-semibold ${s.color}`}>{s.label}</p>
                        <p className="text-slate-500">{s.sub}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Canvas */}
                <div className="flex-1 rounded-xl bg-slate-900/40 border border-slate-800/60 overflow-hidden relative min-h-0">
                  <FractalCanvas isAnimating={isAnalyzing || fractalMode} />

                  {/* Overlay when no content */}
                  {!analysisResult && !isAnalyzing && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <motion.div
                          animate={{ scale: [1, 1.05, 1], opacity: [0.5, 1, 0.5] }}
                          transition={{ duration: 3, repeat: Infinity }}
                          className="text-4xl mb-3"
                        >
                          🧠
                        </motion.div>
                        <p className="text-slate-500 text-xs">Déposez du contenu pour voir le moteur s'activer</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom phrase */}
                <p className="text-center text-xs text-slate-500 mt-3 italic">
                  Le chaos devient structure. La mémoire prend forme.
                </p>

                {/* ── Classification Cards — Résultats détaillés ── */}
                {classificationResult?.items && classificationResult.items.length > 0 && (
                  <div className="mt-4 flex-shrink-0">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-[10px] font-bold tracking-widest text-cyan-400 uppercase">
                        Résultats de classification
                      </p>
                      <span className="text-[10px] text-slate-500">
                        {classificationResult.items.length} élément{classificationResult.items.length > 1 ? 's' : ''} analysé{classificationResult.items.length > 1 ? 's' : ''}
                      </span>
                    </div>
                    <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
                      {classificationResult.items.map((item: any, i: number) => {
                        const cardResult: CardResult = {
                          itemId: item.id,
                          categoryId: item.categoryId,
                          isNewCategory: item.isNewCategory ?? false,
                          primaryDimension: item.dimension ?? 'DOCUMENTS',
                          dimensionColor: item.dimensionColor ?? '#64748b',
                          allDimensions: item.dimensions ? (typeof item.dimensions === 'string' ? JSON.parse(item.dimensions) : item.dimensions) : [],
                          mainCategory: item.category ?? 'Non classé',
                          subcategories: item.subcategories ?? [],
                          isClear: item.isClear ?? true,
                          clarificationReason: item.clarificationReason,
                          maturationState: item.maturationState ?? 'detected',
                          confidence: item.confidence ?? 70,
                          projections: item.projections ? (typeof item.projections === 'string' ? JSON.parse(item.projections) : item.projections) : [],
                          linksCreated: item.linksCreated ?? [],
                          suggestedQuestions: item.suggestedQuestions ?? [],
                          extractedData: item.extractedData ?? {},
                          classificationReason: item.classificationReason ?? '',
                        };
                        return (
                          <ClassificationCard
                            key={i}
                            result={cardResult}
                            content={item.content ?? item.text ?? ''}
                            index={i}
                          />
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* ── Bottom 3 cards ── */}
            <div className="flex-shrink-0 grid grid-cols-3 gap-3 p-4 border-t border-slate-800/40">

              {/* Card 1: Categories */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Catégories créées</p>
                    <p className="text-[10px] text-slate-600">5 nouvelles catégories</p>
                  </div>
                  <Layers className="w-4 h-4 text-violet-400" />
                </div>
                <div className="space-y-1.5">
                  {realCategories.length > 0 ? realCategories.slice(0, 5).map((cat: any, i: number) => {
                    const colors = ['bg-orange-500', 'bg-green-500', 'bg-blue-500', 'bg-violet-500', 'bg-cyan-500'];
                    const itemCount = realItems.filter((it: any) => it.categoryId === cat.id).length;
                    return (
                      <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-sm ${colors[i % colors.length]}`} />
                          <span className="text-[11px] text-slate-300">{cat.name}</span>
                        </div>
                        <span className="text-[10px] text-slate-500">{itemCount} éléments</span>
                      </div>
                    );
                  }) : (
                    <p className="text-[11px] text-slate-600 italic text-center py-2">
                      {analysisResult ? 'Classification en cours...' : 'Déposez du contenu pour voir les catégories'}
                    </p>
                  )}
                </div>
              </div>

              {/* Card 2: Grey zones */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Zones grises à clarifier</p>
                    <p className="text-[10px] text-slate-600">3 éléments ambigus</p>
                  </div>
                  <AlertCircle className="w-4 h-4 text-orange-400" />
                </div>
                <div className="space-y-2">
                  {realUnclarified.length > 0 ? realUnclarified.slice(0, 3).map((item: any, i: number) => (
                    <div key={i} className="flex items-start gap-2 p-2 bg-slate-800/50 rounded-lg">
                      <AlertCircle className="w-3 h-3 text-orange-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] text-slate-300 truncate">{item.content?.substring(0, 40) ?? item.text ?? 'Contenu ambigu'}</p>
                        <p className="text-[10px] text-slate-500">{item.reason ?? item.ambiguityReason ?? 'Raison inconnue'}</p>
                      </div>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        (item.confidence ?? 60) < 55 ? 'bg-red-900/50 text-red-400' :
                        (item.confidence ?? 60) < 65 ? 'bg-orange-900/50 text-orange-400' :
                        'bg-yellow-900/50 text-yellow-400'
                      }`}>{item.confidence ?? 60}%</span>
                    </div>
                  )) : (
                    <p className="text-[11px] text-slate-600 italic text-center py-2">
                      {analysisResult ? 'Aucune zone grise détectée' : 'Déposez du contenu pour voir les zones grises'}
                    </p>
                  )}
                </div>
                <button className="mt-2 w-full text-[10px] text-slate-500 hover:text-slate-300 flex items-center justify-center gap-1 py-1.5 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
                  Voir toutes les zones grises <ChevronRight className="w-3 h-3" />
                </button>
              </div>

              {/* Card 3: Links */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Liens détectés</p>
                    <p className="text-[10px] text-slate-600">8 connexions créées</p>
                  </div>
                  <Link2 className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="space-y-1.5">
                  {realLinks.length > 0 ? realLinks.slice(0, 4).map((link: any, i: number) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-300 truncate flex-1">{link.sourceContent ?? link.from ?? 'Élément A'}</span>
                      <span className="text-cyan-500 text-[10px]">↔</span>
                      <span className="text-[11px] text-slate-300 truncate flex-1">{link.targetContent ?? link.to ?? 'Élément B'}</span>
                      <span className="text-[10px] text-slate-500 flex-shrink-0">Force: {link.strength ?? link.force ?? 80}%</span>
                    </div>
                  )) : (
                    <p className="text-[11px] text-slate-600 italic text-center py-2">
                      {analysisResult ? 'Aucun lien détecté' : 'Déposez du contenu pour voir les liens'}
                    </p>
                  )}
                </div>
                <button className="mt-2 w-full text-[10px] text-slate-500 hover:text-slate-300 flex items-center justify-center gap-1 py-1.5 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
                  Voir tous les liens <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* ── Right Panel ── */}
          <aside className="w-[220px] flex-shrink-0 flex flex-col border-l border-slate-800/60 bg-[#0a1020]/60 overflow-y-auto">

            {/* Score */}
            <div className="p-4 border-b border-slate-800/60">
              <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase mb-3">
                Résumé de l'analyse
              </p>
              <CircularScore score={analysisResult ? stats.score : 0} />
            </div>

            {/* Stats */}
            <div className="p-4 border-b border-slate-800/60 space-y-2">
              {[
                { icon: CheckCircle2, label: 'Éléments classés', value: stats.items, color: 'text-green-400' },
                { icon: Layers, label: 'Catégories créées', value: stats.categories, color: 'text-violet-400' },
                { icon: Link2, label: 'Liens détectés', value: stats.links, color: 'text-cyan-400' },
                { icon: AlertCircle, label: 'Zones grises', value: stats.grey, color: 'text-orange-400' },
                { icon: Eye, label: 'En attente validation', value: stats.pending, color: 'text-slate-400' },
              ].map((stat, i) => {
                const Icon = stat.icon;
                return (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icon className={`w-3.5 h-3.5 ${stat.color}`} />
                      <span className="text-[11px] text-slate-400">{stat.label}</span>
                    </div>
                    <span className={`text-sm font-bold ${stat.color}`}>{stat.value}</span>
                  </div>
                );
              })}
              <button
                onClick={() => navigate('/admin/grid')}
                className="mt-2 w-full text-[10px] text-cyan-400 flex items-center justify-center gap-1 hover:text-cyan-300 transition-colors"
              >
                Voir détails complets <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Quick access */}
            <div className="p-4 border-b border-slate-800/60">
              <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase mb-3">
                Accès rapides
              </p>
              <div className="space-y-1.5">
                {[
                  { icon: Grid3X3, label: 'Grille interne', href: '/admin/grid', color: 'text-cyan-400' },
                  { icon: AlertCircle, label: 'Zones à clarifier', href: '/admin/grid', color: 'text-orange-400' },
                  { icon: Link2, label: 'Liens détectés', href: '/admin/grid', color: 'text-violet-400' },
                  { icon: Plus, label: 'Nouvelles catégories', href: '/admin/grid', color: 'text-green-400' },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={i}
                      onClick={() => navigate(item.href)}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg bg-slate-800/40 border border-slate-800 hover:border-slate-700 hover:bg-slate-800/70 transition-all text-left"
                    >
                      <Icon className={`w-3.5 h-3.5 ${item.color}`} />
                      <span className="text-[11px] text-slate-300">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Tip */}
            <div className="p-4 space-y-3">
              <div className="p-3 bg-slate-800/40 rounded-lg border border-slate-700/50">
                <p className="text-[10px] text-yellow-400 font-semibold mb-1">💡 Le saviez-vous ?</p>
                <p className="text-[10px] text-slate-400 leading-relaxed">
                  Le moteur fractal apprend de vos validations pour mieux organiser vos prochains dépôts.
                </p>
              </div>
              <div className="p-3 bg-slate-800/40 rounded-lg border border-slate-700/50">
                <p className="text-[10px] text-slate-400 leading-relaxed italic">
                  "Au Point Zéro, rien n'est perdu. Chaque information a sa place. Le chaos n'est que le début d'une belle organisation."
                </p>
                <p className="text-right text-[10px] text-cyan-400 mt-1 font-semibold">— LinkEvent</p>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
