import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import AnimatedGridVisualization from '@/components/AnimatedGridVisualization';
import FractalGridVisualization from '@/components/FractalGridVisualization';
import ClassificationStreamVisualization from '@/components/ClassificationStreamVisualization';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

type Phase = 'upload' | 'analyzing' | 'visualization' | 'complete';

interface ClassificationStep {
  type: 'category_created' | 'item_classified' | 'link_detected' | 'unclarified_detected' | 'complete';
  data: any;
  timestamp: number;
}

export default function CockpitVisualization() {
  const [, navigate] = useLocation();
  const [phase, setPhase] = useState<Phase>('upload');
  const [textInput, setTextInput] = useState('');
  const [eventId, setEventId] = useState<number | null>(null);
  const [classificationSteps, setClassificationSteps] = useState<ClassificationStep[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState('');

  const analyzeContentMutation = trpc.weddingAnalysis.analyzeVrac.useMutation({
    onSuccess: (result: any) => {
      if (result.success && result.eventId) {
        setEventId(result.eventId);
        setPhase('visualization');
        
        // Simuler les étapes de classification
        simulateClassificationSteps(result);
      }
    },
    onError: (error: any) => {
      setError(`Erreur d'analyse: ${error.message}`);
      setIsAnalyzing(false);
    },
  });

  const simulateClassificationSteps = (result: any) => {
    // Simuler l'apparition progressive des étapes
    const steps: ClassificationStep[] = [];
    let delay = 0;

    // Catégories créées
    if (result.categories) {
      result.categories.forEach((cat: any, index: number) => {
        setTimeout(() => {
          steps.push({
            type: 'category_created',
            data: cat,
            timestamp: Date.now(),
          });
          setClassificationSteps([...steps]);
        }, delay);
        delay += 300;
      });
    }

    // Éléments classifiés
    if (result.items) {
      result.items.forEach((item: any, index: number) => {
        setTimeout(() => {
          steps.push({
            type: 'item_classified',
            data: item,
            timestamp: Date.now(),
          });
          setClassificationSteps([...steps]);
        }, delay);
        delay += 200;
      });
    }

    // Éléments à clarifier
    if (result.unclarified) {
      result.unclarified.forEach((item: any, index: number) => {
        setTimeout(() => {
          steps.push({
            type: 'unclarified_detected',
            data: item,
            timestamp: Date.now(),
          });
          setClassificationSteps([...steps]);
        }, delay);
        delay += 250;
      });
    }

    // Analyse complète
    setTimeout(() => {
      steps.push({
        type: 'complete',
        data: result,
        timestamp: Date.now(),
      });
      setClassificationSteps([...steps]);
      setIsAnalyzing(false);
    }, delay);
  };

  const handleAnalyze = async () => {
    if (!textInput.trim()) {
      setError('Veuillez entrer du texte ou charger un exemple');
      return;
    }

    setError('');
    setIsAnalyzing(true);
    setPhase('analyzing');

    analyzeContentMutation.mutate({
      text: textInput,
    });
  };

  const exampleWeddingVrac = `Mariage Sophie & Marc - 14 septembre 2026

Cérémonie: 14:00 Mairie de Commines
Cocktail: 15:30 Château de Vaux
Dîner: 18:30 (140 invités)
Soirée: 21:00

Prestataires:
- Traiteur Delice: 06 12 34 56 78
- Photographe Marc: 06 98 76 54 32
- DJ Maxime: 06 11 22 33 44
- Fleuriste Roseline: 06 55 44 33 22
- Saxophoniste Laurent: 06 77 88 99 00

Témoins: Julie (sœur), Thomas (ami)
Coordinatrice: Émilie - 06 51 52 53 54

Notes: 20 enfants, navettes hôtel, allergies gluten/lactose`;

  const exampleMessyContent = `Date: 15 septembre 2026
Nom des mariés: Sophie & Marc
Facture: Traiteur Delice - 3500€
Souvenir: Première danse à 21h15
Horaire: 14:00 cérémonie à la mairie
Prestataire: DJ Maxime - 06 12 34 56 78
Phrase ambiguë: "Les choses importantes doivent se passer avant la pluie"
Photo: Château de Vaux
Allergies: Gluten, lactose
Invités: 140 personnes
Coordinatrice: Émilie
Note: Navettes hôtel à 13:30
Musique: Jazz pendant le cocktail
Fleuriste: Roseline - 06 55 44 33 22
Saxophone: Laurent à 21h30
Témoins: Julie (sœur), Thomas (ami)
Enfants: 20 enfants présents
Parking: 50 places disponibles`;

  const handleLoadExample = () => {
    setTextInput(exampleWeddingVrac);
  };

  const handleLoadMessyExample = () => {
    setTextInput(exampleMessyContent);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        {/* En-tête */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="text-4xl font-bold text-blue-300 mb-2">🎛️ LinkEvent Grid Canvas</h1>
          <p className="text-slate-400">Transformez votre vrac en orchestration claire</p>
        </motion.div>

        {/* Phase Upload */}
        <AnimatePresence mode="wait">
          {phase === 'upload' && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <Card className="p-8 bg-slate-900/50 border-slate-700">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-blue-300 mb-4">📋 Point Zéro</h2>
                  <p className="text-slate-400 mb-4">
                    Déposez votre contenu (déroulé, notes, idées, dates, noms, etc.) et regardez le système l'organiser
                  </p>

                  <textarea
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="Horaires, prestataires, invités, notes..."
                    className="w-full h-48 p-4 rounded-lg bg-slate-800 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />

                  {error && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="mt-4 p-3 rounded-lg bg-red-900/30 border border-red-700 text-red-300 text-sm"
                    >
                      {error}
                    </motion.div>
                  )}
                </div>

                <div className="flex flex-wrap gap-3">
                  <Button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyse en cours
                      </>
                    ) : (
                      <>⬆️ Analyser et Organiser</>
                    )}
                  </Button>
                  <Button
                    onClick={handleLoadExample}
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-800"
                  >
                    📋 Charger l'exemple
                  </Button>
                  <Button
                    onClick={handleLoadMessyExample}
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-800"
                  >
                    🎲 Contenu Désordonné
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}

          {/* Phase Analyzing */}
          {phase === 'analyzing' && (
            <motion.div
              key="analyzing"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <Card className="p-8 bg-slate-900/50 border-slate-700 text-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="inline-block mb-4"
                >
                  <div className="text-4xl">⚙️</div>
                </motion.div>
                <h2 className="text-2xl font-bold text-blue-300 mb-2">Analyse en cours...</h2>
                <p className="text-slate-400">
                  Le système détecte les catégories, crée les dossiers et identifie les connexions
                </p>
              </Card>
            </motion.div>
          )}

          {/* Phase Visualization */}
          {phase === 'visualization' && (
            <motion.div
              key="visualization"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Grille hiérarchique */}
                <Card className="p-0 bg-slate-900/50 border-slate-700 overflow-hidden h-96 lg:h-auto">
                  <FractalGridVisualization categories={[]} />
                </Card>

                {/* Visualisation de classification */}
                <Card className="p-0 bg-slate-900/50 border-slate-700 overflow-hidden h-96 lg:h-auto">
                  <ClassificationStreamVisualization
                    steps={classificationSteps}
                    isStreaming={isAnalyzing}
                    eventId={eventId || undefined}
                  />
                </Card>
              </div>

              {/* Boutons d'action */}
              <div className="mt-6 flex flex-wrap gap-3 justify-center">
                <Button
                  onClick={() => {
                    setPhase('upload');
                    setTextInput('');
                    setClassificationSteps([]);
                  }}
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:bg-slate-800"
                >
                  ↩️ Nouveau contenu
                </Button>
                {eventId && (
                  <Button
                    onClick={() => navigate(`/admin/grid`)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    🎛️ Voir la grille interne
                  </Button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
