import { useState } from 'react';
import LiveGrid from '@/components/LiveGrid';
import AnalysisReviewPanel from '@/components/AnalysisReviewPanel';
import VracUploadZone from '@/components/VracUploadZone';
import DayJTimeline from '@/components/DayJTimeline';
import QuestionsPanel from '@/components/QuestionsPanel';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface GridSquare {
  id: string;
  x: number;
  y: number;
  state: 'empty' | 'detected' | 'categorized' | 'understood' | 'ready' | 'validated' | 'conflict';
  category?: string;
  label?: string;
  color?: string;
  hasAlert?: boolean;
}

interface AnalysisData {
  understood: {
    times: Array<{ label: string; time: string; location?: string }>;
    keyMoments: string[];
    people: Array<{ name: string; role: string; contact?: string }>;
    vendors: Array<{ name: string; category: string; contact?: string; confirmed?: boolean }>;
    locations: string[];
    music: string[];
    objects: string[];
    actions: string[];
    dependencies: Array<{ from: string; to: string; reason: string }>;
  };
  missing: {
    unidentifiedPeople: string[];
    missingRoles: string[];
    missingVendors: string[];
    unclearTimes: string[];
    unspecifiedLocations: string[];
    actionsWithoutOwner: string[];
    missingContacts: string[];
    requiredValidations: string[];
  };
  suggestedQuestions: Array<{
    question: string;
    importance: 'critical' | 'high' | 'medium' | 'low';
    relatedTo: string;
  }>;
  confidence: number;
}

interface TimelineTask {
  id: string;
  time: string;
  action: string;
  responsible: string;
  location?: string;
  dependencies?: string[];
  status: 'todo' | 'inprogress' | 'done';
  category: string;
}

interface Question {
  id: string;
  question: string;
  importance: 'critical' | 'high' | 'medium' | 'low';
  relatedTo: string;
  answer?: string;
  answered: boolean;
}

type CockpitPhase = 'upload' | 'analyzing' | 'review' | 'questions' | 'dayJ';

export default function Cockpit() {
  const [phase, setPhase] = useState<CockpitPhase>('upload');
  const [gridSquares, setGridSquares] = useState<GridSquare[]>([]);
  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [tasks, setTasks] = useState<TimelineTask[]>([]);
  const [taskStatuses, setTaskStatuses] = useState<Record<string, 'todo' | 'inprogress' | 'done'>>({});

  const analyzeVracMutation = trpc.weddingAnalysis.analyzeVrac.useMutation({
    onSuccess: (result) => {
      const analysisData = result.analysis as AnalysisData;
      setAnalysis(analysisData);
      
      // Créer les carrés de la grille basés sur l'analyse
      const newSquares: GridSquare[] = [];
      let squareIndex = 0;
      
      if (analysisData.understood.times && analysisData.understood.times.length > 0) {
        analysisData.understood.times.forEach((time, idx) => {
          const x = (squareIndex % 12);
          const y = Math.floor(squareIndex / 12);
          newSquares.push({
            id: `time-${idx}`,
            x,
            y,
            state: 'validated',
            category: 'cérémonie',
            label: `${time.label}\n${time.time}`,
          });
          squareIndex++;
        });
      }

      if (analysisData.understood.vendors && analysisData.understood.vendors.length > 0) {
        analysisData.understood.vendors.forEach((vendor, idx) => {
          const x = (squareIndex % 12);
          const y = Math.floor(squareIndex / 12);
          newSquares.push({
            id: `vendor-${idx}`,
            x,
            y,
            state: vendor.confirmed ? 'validated' : 'ready',
            category: vendor.category.toLowerCase(),
            label: vendor.name,
            hasAlert: !vendor.contact,
          });
          squareIndex++;
        });
      }

      if (analysisData.understood.people && analysisData.understood.people.length > 0) {
        analysisData.understood.people.forEach((person, idx) => {
          const x = (squareIndex % 12);
          const y = Math.floor(squareIndex / 12);
          newSquares.push({
            id: `person-${idx}`,
            x,
            y,
            state: 'understood',
            category: 'communication',
            label: `${person.name}\n${person.role}`,
            hasAlert: !person.contact,
          });
          squareIndex++;
        });
      }

      if (analysisData.missing.requiredValidations && analysisData.missing.requiredValidations.length > 0) {
        analysisData.missing.requiredValidations.forEach((validation, idx) => {
          const x = (squareIndex % 12);
          const y = Math.floor(squareIndex / 12);
          newSquares.push({
            id: `missing-${idx}`,
            x,
            y,
            state: 'conflict',
            category: 'technique',
            label: validation,
            hasAlert: true,
          });
          squareIndex++;
        });
      }

      setGridSquares(newSquares);
      
      // Créer les questions
      const newQuestions: Question[] = analysisData.suggestedQuestions.map((q, idx) => ({
        id: `q-${idx}`,
        question: q.question,
        importance: q.importance,
        relatedTo: q.relatedTo,
        answered: false,
      }));
      setQuestions(newQuestions);
      
      // Créer les tâches Jour J à partir des horaires
      const newTasks: TimelineTask[] = analysisData.understood.times.map((time, idx) => ({
        id: `task-${idx}`,
        time: time.time,
        action: time.label,
        responsible: 'À définir',
        location: time.location,
        status: 'todo',
        category: 'cérémonie',
      }));
      setTasks(newTasks);
      setTaskStatuses(newTasks.reduce((acc, t) => ({ ...acc, [t.id]: 'todo' }), {}));
      
      setPhase('review');
      toast.success('Analyse terminée !');
    },
    onError: (error) => {
      toast.error('Erreur lors de l\'analyse');
      console.error(error);
    },
  });

  const handleVracSubmit = async (vrac: { text: string; files: File[] }) => {
    setPhase('analyzing');
    analyzeVracMutation.mutate({
      text: vrac.text,
      fileContents: [],
    });
  };

  const handleConfirmAnalysis = (responses: Record<string, string>) => {
    setPhase('questions');
    toast.success('Analyse confirmée !');
  };

  const handleAnswersConfirm = (answers: Record<string, string>) => {
    setPhase('dayJ');
    toast.success('Questions confirmées !');
  };

  const handleTaskStatusChange = (taskId: string, status: 'todo' | 'inprogress' | 'done') => {
    setTaskStatuses((prev) => ({ ...prev, [taskId]: status }));
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status } : t))
    );
  };

  return (
    <div className="w-full h-screen bg-slate-900 overflow-hidden">
      {/* Grille vivante */}
      {(phase === 'analyzing' || phase === 'review') && (
        <LiveGrid
          squares={gridSquares}
          isAnalyzing={phase === 'analyzing'}
          onDrop={() => {}}
        />
      )}

      {/* Zone d'upload */}
      {phase === 'upload' && (
        <div className="w-full h-screen overflow-y-auto flex items-center justify-center p-6">
          <VracUploadZone
            onVracSubmit={handleVracSubmit}
            isLoading={analyzeVracMutation.isPending}
          />
        </div>
      )}

      {/* Questions */}
      {phase === 'questions' && (
        <div className="w-full h-screen overflow-y-auto p-6">
          <QuestionsPanel
            questions={questions}
            eventId={1}
            onAnswersConfirmed={handleAnswersConfirm}
          />
        </div>
      )}

      {/* Jour J */}
      {phase === 'dayJ' && (
        <div className="w-full h-screen overflow-y-auto p-6">
          <DayJTimeline
            tasks={tasks}
            onStatusChange={handleTaskStatusChange}
          />
        </div>
      )}

      {/* Panneau latéral - Analyse & Validation */}
      <AnimatePresence>
        {(phase === 'review') && (
          <motion.div
            initial={{ x: 400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 400, opacity: 0 }}
            transition={{ type: 'spring', damping: 20 }}
            className="absolute right-0 top-0 bottom-0 w-96 bg-slate-800/95 backdrop-blur border-l border-slate-700 overflow-y-auto z-30"
          >
            <div className="p-6 space-y-6">
              {/* En-tête */}
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-white">Analyse</h2>
                <button
                  onClick={() => setPhase('upload')}
                  className="p-1 hover:bg-slate-700 rounded transition-colors"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              {/* Contenu */}
              {analysis && (
                <AnalysisReviewPanel
                  analysis={analysis}
                  onConfirm={handleConfirmAnalysis}
                  onModify={() => setPhase('upload')}
                />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation entre phases */}
      {(phase === 'questions' || phase === 'dayJ') && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-6 left-6 right-6 flex gap-3 z-20"
        >
          <Button
            variant="outline"
            onClick={() => setPhase(phase === 'dayJ' ? 'questions' : 'review')}
          >
            Retour
          </Button>
          {phase === 'questions' && (
            <Button
              onClick={() => setPhase('dayJ')}
              className="flex-1"
            >
              Voir la Timeline Jour J
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </motion.div>
      )}
    </div>
  );
}
