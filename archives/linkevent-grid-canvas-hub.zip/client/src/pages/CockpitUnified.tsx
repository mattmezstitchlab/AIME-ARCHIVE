import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Loader2, CheckCircle, AlertCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import ClassificationResult from '@/components/ClassificationResult';
import FractalGridVisualization from '@/components/FractalGridVisualization';
import AnimatedGridVisualization from '@/components/AnimatedGridVisualization';
import { useLocation } from 'wouter';

type Phase = 'upload' | 'analyzing' | 'review' | 'questions' | 'dayJ' | 'classification';

interface AnalysisData {
  understood: {
    times: Array<{ label: string; time: string; location?: string }>;
    keyMoments: string[];
    people: Array<{ name: string; role: string; contact?: string }>;
    vendors: Array<{ name: string; category: string; contact?: string }>;
    locations: string[];
    music: string[];
    objects: string[];
    actions: string[];
    dependencies: Array<{ from: string; to: string; reason: string }>;
  };
  missing: {
    unidentifiedPeople: string[];
    missingRoles: string[];
    missingVendors: string[];
    unclearTimes: string[];
    unspecifiedLocations: string[];
    actionsWithoutOwner: string[];
    missingContacts: string[];
    requiredValidations: string[];
  };
  suggestedQuestions: Array<{
    question: string;
    importance: 'critical' | 'high' | 'medium' | 'low';
    relatedTo: string;
  }>;
}

const exampleWeddingVrac = `Mariage Sophie & Marc - 14 septembre 2026

Cérémonie: 14:00 Mairie de Commines
Cocktail: 15:30 Château de Vaux
Dîner: 18:30 (140 invités)
Soirée: 21:00

Prestataires:
- Traiteur Delice: 06 12 34 56 78
- Photographe Marc: 06 98 76 54 32
- DJ Maxime: 06 11 22 33 44
- Fleuriste Roseline: 06 55 44 33 22
- Saxophoniste Laurent: 06 77 88 99 00

Témoins: Julie (sœur), Thomas (ami)
Coordinatrice: Émilie - 06 51 52 53 54

Notes: 20 enfants, navettes hôtel, allergies gluten/lactose`;

const exampleMessyContent = `Date: 15 septembre 2026
Nom des mariés: Sophie & Marc
Facture: Traiteur Delice - 3500€
Souvenir: Première danse à 21h15
Horaire: 14:00 cérémonie à la mairie
Prestataire: DJ Maxime - 06 12 34 56 78
Phrase ambiguë: "Les choses importantes doivent se passer avant la pluie"
Photo: Château de Vaux
Allergies: Gluten, lactose
Invités: 140 personnes
Coordinatrice: Émilie
Note: Navettes hôtel à 13:30
Musique: Jazz pendant le cocktail
Fleuriste: Roseline - 06 55 44 33 22
Saxophone: Laurent à 21h30
Témoins: Julie (sœur), Thomas (ami)
Enfants: 20 enfants présents
Parking: 50 places disponibles`;

export default function CockpitUnified() {
  const [, navigate] = useLocation();
  const [phase, setPhase] = useState<Phase>('upload');
  const [textInput, setTextInput] = useState('');
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [eventId, setEventId] = useState<number | null>(null);
  const [classificationResult, setClassificationResult] = useState<any>(null);

  const analyzeVracMutation = trpc.weddingAnalysis.analyzeVrac.useMutation({
    onSuccess: (data: any) => {
      setAnalysisData((data.analysis as unknown) as AnalysisData);
      setEventId(data.eventId);
      setError(null);
      setPhase('review');
      toast.success('Analyse terminée ! 🎉');
    },
    onError: (error) => {
      setError(`Erreur lors de l'analyse: ${error.message}`);
      toast.error('Erreur lors de l\'analyse');
      setPhase('upload');
    },
  });

  const classifyContentMutation = trpc.classification.classifyContent.useMutation({
    onSuccess: (data: any) => {
      setClassificationResult(data);
      setPhase('classification');
      toast.success('Classification complétée ! 🎛️');
    },
    onError: (error) => {
      setError(`Erreur lors de la classification: ${error.message}`);
      toast.error('Erreur lors de la classification');
      setPhase('review');
    },
  });

  const handleLoadExample = () => {
    setTextInput(exampleWeddingVrac);
  };

  const handleLoadMessyExample = () => {
    setTextInput(exampleMessyContent);
  };

  const handleAnalyze = async () => {
    if (!textInput.trim()) {
      setError('Veuillez entrer du texte ou charger l\'exemple');
      return;
    }
    setError(null);
    setPhase('analyzing');
    analyzeVracMutation.mutate({ text: textInput, fileContents: [] });
  };

  const handleClassify = async () => {
    if (!textInput.trim() || !eventId) {
      setError('Veuillez d\'abord analyser le contenu');
      return;
    }
    setError(null);
    setPhase('analyzing');
    classifyContentMutation.mutate({
      eventId,
      content: textInput,
      sourceType: "text",
    });
  };

  const handleViewGrid = () => {
    navigate('/admin/grid');
  };

  const handleContinue = () => {
    if (phase === 'review') {
      setPhase('questions');
    } else if (phase === 'questions') {
      setPhase('dayJ');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-4 sm:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 sm:mb-12 text-center"
        >
          <h1 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600 mb-2">
            LinkEvent Grid Canvas
          </h1>
          <p className="text-slate-400 text-sm sm:text-base">
            Transformez votre vrac en orchestration claire
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Phase 1: Upload */}
          {phase === 'upload' && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <Card className="bg-slate-800/50 border-slate-700 p-8">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-3">
                      📝 Collez votre déroulé de mariage
                    </label>
                    <Textarea
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      placeholder="Horaires, prestataires, invités, notes..."
                      className="h-48 bg-slate-900 border-slate-600 text-slate-100 placeholder-slate-500"
                    />
                  </div>

                  {error && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex items-start gap-3 p-4 bg-red-900/20 border border-red-700 rounded-lg"
                    >
                      <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="text-red-300 text-sm">{error}</p>
                    </motion.div>
                  )}

                  <div className="flex gap-3">
                    <Button
                      onClick={handleAnalyze}
                      disabled={analyzeVracMutation.isPending || !textInput.trim()}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {analyzeVracMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analyse en cours...
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4 mr-2" />
                          Analyser et Organiser
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={handleLoadExample}
                      variant="outline"
                      className="border-slate-600 text-slate-300 hover:bg-slate-800"
                    >
                      📋 Charger l'exemple
                    </Button>
                    <Button
                      onClick={handleLoadMessyExample}
                      variant="outline"
                      className="border-slate-600 text-slate-300 hover:bg-slate-800"
                    >
                      🎲 Contenu Désordonné
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          {/* Phase 2: Analyzing */}
          {phase === 'analyzing' && (
            <motion.div
              key="analyzing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-20 space-y-6"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              >
                <Loader2 className="w-16 h-16 text-blue-500" />
              </motion.div>
              <div className="text-center">
                <p className="text-xl text-slate-300 font-medium mb-2">Analyse en cours...</p>
                <p className="text-slate-400">LinkEvent détecte les horaires, prestataires et dépendances</p>
              </div>
            </motion.div>
          )}

          {/* Phase 3: Review */}
          {phase === 'review' && analysisData && (
            <motion.div
              key="review"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Ce qui est compris */}
                <Card className="bg-slate-800/50 border-slate-700 p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <h3 className="font-semibold text-slate-200">Ce qui est compris</h3>
                  </div>
                  <div className="space-y-3 text-sm">
                    <div>
                      <p className="text-slate-400">⏰ Horaires détectés</p>
                      <p className="text-slate-300 font-medium">{analysisData.understood.times.length}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">👥 Personnes</p>
                      <p className="text-slate-300 font-medium">{analysisData.understood.people.length}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">🏢 Prestataires</p>
                      <p className="text-slate-300 font-medium">{analysisData.understood.vendors.length}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">📍 Lieux</p>
                      <p className="text-slate-300 font-medium">{analysisData.understood.locations.length}</p>
                    </div>
                  </div>
                </Card>

                {/* Ce qui manque */}
                <Card className="bg-slate-800/50 border-slate-700 p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <AlertCircle className="w-5 h-5 text-yellow-500" />
                    <h3 className="font-semibold text-slate-200">Ce qui manque</h3>
                  </div>
                  <div className="space-y-2 text-sm">
                    {analysisData.missing.unclearTimes.length > 0 && (
                      <p className="text-yellow-300">⚠️ {analysisData.missing.unclearTimes.length} horaires flous</p>
                    )}
                    {analysisData.missing.missingContacts.length > 0 && (
                      <p className="text-yellow-300">⚠️ {analysisData.missing.missingContacts.length} contacts manquants</p>
                    )}
                    {analysisData.missing.actionsWithoutOwner.length > 0 && (
                      <p className="text-yellow-300">⚠️ {analysisData.missing.actionsWithoutOwner.length} actions sans responsable</p>
                    )}
                    {analysisData.missing.unspecifiedLocations.length > 0 && (
                      <p className="text-yellow-300">⚠️ {analysisData.missing.unspecifiedLocations.length} lieux non précisés</p>
                    )}
                  </div>
                </Card>

                {/* Questions critiques */}
                <Card className="bg-slate-800/50 border-slate-700 p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <AlertCircle className="w-5 h-5 text-red-500" />
                    <h3 className="font-semibold text-slate-200">Questions critiques</h3>
                  </div>
                  <div className="space-y-2 text-sm">
                    {analysisData.suggestedQuestions
                      .filter((q) => q.importance === 'critical')
                      .slice(0, 3)
                      .map((q, idx) => (
                        <p key={idx} className="text-red-300 text-xs">
                          🔴 {q.question}
                        </p>
                      ))}
                  </div>
                </Card>
              </div>

              {/* Boutons d'action */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Button
                  onClick={handleClassify}
                  disabled={classifyContentMutation.isPending}
                  className="bg-purple-600 hover:bg-purple-700 text-white py-6"
                >
                  {classifyContentMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Classification en cours...
                    </>
                  ) : (
                    <>
                      🎛️ Voir la Grille Interne
                    </>
                  )}
                </Button>
                <Button
                  onClick={handleContinue}
                  className="bg-blue-600 hover:bg-blue-700 text-white py-6"
                >
                  Continuer vers les questions
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </motion.div>
          )}

                    {/* Phase 6: Classification */}
          {phase === 'classification' && classificationResult && (
            <motion.div
              key="classification"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Grille hiérarchique */}
                <Card className="bg-slate-800/50 border-slate-700 p-0 overflow-hidden h-96 lg:h-auto">
                  <FractalGridVisualization
                    categories={classificationResult.categories || []}
                  />
                </Card>

                {/* Éléments classifiés */}
                <Card className="bg-slate-800/50 border-slate-700 p-0 overflow-hidden h-96 lg:h-auto">
                  <AnimatedGridVisualization
                    items={classificationResult.items || []}
                  />
                </Card>
              </div>

              {/* Zones grises */}
              {classificationResult.unclarified && classificationResult.unclarified.length > 0 && (
                <Card className="bg-gradient-to-r from-slate-800 to-slate-700 border-slate-600 p-6">
                  <h3 className="text-lg font-bold text-slate-300 mb-4">❓ Zones Grises à Clarifier</h3>
                  <div className="space-y-2">
                    {classificationResult.unclarified.map((item: any, index: number) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-3 bg-slate-700/50 rounded border border-slate-600 text-sm text-slate-300"
                      >
                        <p className="font-medium">{item.content?.substring(0, 50)}</p>
                        <p className="text-xs text-slate-400 mt-1">💡 {item.reason}</p>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              )}

              {/* Boutons d'action */}
              <div className="flex gap-3">
                <Button
                  onClick={handleViewGrid}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-6"
                >
                  🎛️ Voir la grille interne complète
                </Button>
                <Button
                  onClick={handleContinue}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-6"
                >
                  ✅ Continuer
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </motion.div>
          )}


          {/* Phase 4: Questions */}
          {phase === 'questions' && analysisData && (
            <motion.div
              key="questions"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <Card className="bg-slate-800/50 border-slate-700 p-8">
                <h2 className="text-2xl font-bold text-slate-100 mb-6">Questions à confirmer</h2>
                <div className="space-y-4">
                  {analysisData.suggestedQuestions.map((q, idx) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-lg border ${
                        q.importance === 'critical'
                          ? 'bg-red-900/20 border-red-700'
                          : q.importance === 'high'
                            ? 'bg-yellow-900/20 border-yellow-700'
                            : 'bg-slate-700/20 border-slate-600'
                      }`}
                    >
                      <p className="text-slate-200 font-medium">{q.question}</p>
                      <p className="text-xs text-slate-400 mt-1">Importance: {q.importance}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Button
                onClick={handleContinue}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg"
              >
                Créer la timeline Jour J
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </motion.div>
          )}

          {/* Phase 5: Day J */}
          {phase === 'dayJ' && analysisData && (
            <motion.div
              key="dayJ"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <Card className="bg-slate-800/50 border-slate-700 p-8">
                <h2 className="text-2xl font-bold text-slate-100 mb-6">Timeline Jour J</h2>
                <div className="space-y-3">
                  {analysisData.understood.times.map((time, idx) => (
                    <div key={idx} className="flex items-start gap-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                      <div className="text-lg font-bold text-blue-400 min-w-20">{time.time}</div>
                      <div className="flex-1">
                        <p className="text-slate-100 font-medium">{time.label}</p>
                        {time.location && <p className="text-slate-400 text-sm">📍 {time.location}</p>}
                      </div>
                      <div className="text-sm text-slate-400">À faire</div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
