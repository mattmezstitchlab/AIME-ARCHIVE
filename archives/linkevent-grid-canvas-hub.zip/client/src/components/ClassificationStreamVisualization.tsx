import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import AnimatedGridVisualization from './AnimatedGridVisualization';
import AnimatedLinksVisualization from './AnimatedLinksVisualization';

interface ClassificationStep {
  type: 'category_created' | 'item_classified' | 'link_detected' | 'unclarified_detected' | 'complete';
  data: any;
  timestamp: number;
}

interface ClassificationStreamVisualizationProps {
  steps: ClassificationStep[];
  isStreaming?: boolean;
  eventId?: number;
}

export default function ClassificationStreamVisualization({
  steps,
  isStreaming = false,
  eventId,
}: ClassificationStreamVisualizationProps) {
  const [gridItems, setGridItems] = useState<any[]>([]);
  const [links, setLinks] = useState<any[]>([]);
  const [unclarified, setUnclarified] = useState<any[]>([]);
  const [stats, setStats] = useState({
    categoriesCreated: 0,
    itemsClassified: 0,
    linksDetected: 0,
    unclarifiedDetected: 0,
  });

  // Traiter les étapes de classification
  useEffect(() => {
    steps.forEach((step) => {
      switch (step.type) {
        case 'category_created':
          setGridItems((prev) => [
            ...prev,
            {
              id: `cat-${step.data.id}`,
              name: step.data.name,
              color: step.data.color || '#3B82F6',
              confidence: 100,
              type: 'category',
              explanation: step.data.description,
            },
          ]);
          setStats((prev) => ({
            ...prev,
            categoriesCreated: prev.categoriesCreated + 1,
          }));
          break;

        case 'item_classified':
          setGridItems((prev) => [
            ...prev,
            {
              id: `item-${step.data.id}`,
              name: step.data.content.substring(0, 50),
              color: step.data.color || '#60A5FA',
              confidence: step.data.confidence || 75,
              type: 'category',
              explanation: `Classé avec ${step.data.confidence}% de confiance`,
            },
          ]);
          setStats((prev) => ({
            ...prev,
            itemsClassified: prev.itemsClassified + 1,
          }));
          break;

        case 'link_detected':
          setLinks((prev) => [...prev, step.data]);
          setStats((prev) => ({
            ...prev,
            linksDetected: prev.linksDetected + 1,
          }));
          break;

        case 'unclarified_detected':
          setUnclarified((prev) => [
            ...prev,
            {
              id: `unclarified-${step.data.id}`,
              name: step.data.content.substring(0, 50),
              color: '#9CA3AF',
              confidence: 0,
              type: 'unclarified',
              explanation: step.data.reason,
            },
          ]);
          setStats((prev) => ({
            ...prev,
            unclarifiedDetected: prev.unclarifiedDetected + 1,
          }));
          break;
      }
    });
  }, [steps]);

  return (
    <div className="w-full h-full space-y-6 p-6 bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 rounded-lg overflow-auto">
      {/* En-tête avec stats */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        <StatCard
          label="Catégories"
          value={stats.categoriesCreated}
          icon="📁"
          color="#3B82F6"
        />
        <StatCard
          label="Éléments"
          value={stats.itemsClassified}
          icon="📦"
          color="#60A5FA"
        />
        <StatCard
          label="Liens"
          value={stats.linksDetected}
          icon="🔗"
          color="#8B5CF6"
        />
        <StatCard
          label="À Clarifier"
          value={stats.unclarifiedDetected}
          icon="❓"
          color="#9CA3AF"
        />
      </motion.div>

      {/* Grille animée */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
      >
        <AnimatedGridVisualization
          items={gridItems}
          isLoading={isStreaming}
        />
      </motion.div>

      {/* Zone grise pour les éléments à clarifier */}
      {unclarified.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-lg p-4 border border-slate-600"
        >
          <h3 className="text-lg font-bold text-slate-300 mb-4">❓ Zones Grises à Clarifier</h3>
          <div className="space-y-2">
            <AnimatePresence>
              {unclarified.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-3 bg-slate-700/50 rounded border border-slate-600 text-sm text-slate-300"
                >
                  <p className="font-medium">{item.name}</p>
                  <p className="text-xs text-slate-400 mt-1">💡 {item.explanation}</p>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>
      )}

      {/* Indicateur de streaming */}
      {isStreaming && (
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="text-center text-slate-400 py-4"
        >
          <div className="inline-flex items-center gap-2">
            <motion.div
              className="w-2 h-2 rounded-full bg-blue-400"
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-sm">Analyse en cours...</span>
          </div>
        </motion.div>
      )}
    </div>
  );
}

// Composant StatCard pour afficher les statistiques
function StatCard({
  label,
  value,
  icon,
  color,
}: {
  label: string;
  value: number;
  icon: string;
  color: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-4 rounded-lg border-2 backdrop-blur-sm"
      style={{
        borderColor: color,
        backgroundColor: `${color}15`,
      }}
    >
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-2xl font-bold" style={{ color }}>
        {value}
      </div>
      <div className="text-xs text-slate-400 mt-1">{label}</div>
    </motion.div>
  );
}
