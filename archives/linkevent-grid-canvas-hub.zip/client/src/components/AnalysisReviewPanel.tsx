import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, AlertCircle, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface AnalysisData {
  understood: {
    times: Array<{ label: string; time: string }>;
    keyMoments: string[];
    people: Array<{ name: string; role: string }>;
    vendors: Array<{ name: string; category: string; contact?: string }>;
    locations: string[];
    music: string[];
    objects: string[];
    actions: string[];
    dependencies: Array<{ from: string; to: string; reason: string }>;
  };
  missing: {
    unidentifiedPeople: string[];
    missingRoles: string[];
    missingVendors: string[];
    unclearTimes: string[];
    unspecifiedLocations: string[];
    actionsWithoutOwner: string[];
    missingContacts: string[];
    requiredValidations: string[];
  };
  suggestedQuestions: Array<{
    question: string;
    importance: 'critical' | 'high' | 'medium' | 'low';
    relatedTo: string;
  }>;
  confidence: number;
}

interface AnalysisReviewPanelProps {
  analysis: AnalysisData;
  onConfirm?: (responses: Record<string, string>) => void;
  onModify?: () => void;
}

export default function AnalysisReviewPanel({
  analysis,
  onConfirm,
  onModify,
}: AnalysisReviewPanelProps) {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    understood: true,
    missing: true,
    questions: true,
  });
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleAnswerChange = (questionIndex: number, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [`q${questionIndex}`]: answer,
    }));
  };

  const missingCount = Object.values(analysis.missing).reduce(
    (sum, arr) => sum + arr.length,
    0
  );
  const confidencePercentage = Math.round(analysis.confidence * 100);

  return (
    <div className="w-full space-y-4">
      {/* En-tête avec confiance */}
      <Card className="p-4 bg-primary/10 border-primary/30">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Analyse de votre dossier</h3>
            <p className="text-sm text-muted-foreground">
              {missingCount} éléments à clarifier
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-primary">{confidencePercentage}%</div>
            <p className="text-xs text-muted-foreground">Confiance</p>
          </div>
        </div>
      </Card>

      {/* Section : Ce qui est compris */}
      <Card className="p-4 bg-card/50">
        <button
          onClick={() => toggleSection('understood')}
          className="w-full flex items-center justify-between hover:opacity-80 transition-opacity"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <h4 className="font-semibold">Ce qui est compris</h4>
          </div>
          {expandedSections.understood ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </button>

        {expandedSections.understood && (
          <div className="mt-4 space-y-4">
            {/* Horaires */}
            {analysis.understood.times.length > 0 && (
              <div>
                <p className="text-sm font-semibold mb-2">⏰ Horaires détectés</p>
                <div className="grid grid-cols-2 gap-2">
                  {analysis.understood.times.map((t, idx) => (
                    <div
                      key={idx}
                      className="px-3 py-2 rounded bg-muted/50 border border-border text-sm"
                    >
                      <span className="font-mono text-primary">{t.time}</span>
                      <p className="text-xs text-muted-foreground">{t.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Personnes */}
            {analysis.understood.people.length > 0 && (
              <div>
                <p className="text-sm font-semibold mb-2">👥 Personnes identifiées</p>
                <div className="space-y-1">
                  {analysis.understood.people.map((p, idx) => (
                    <div key={idx} className="text-sm px-3 py-1 rounded bg-muted/30">
                      <span className="font-medium">{p.name}</span>
                      <span className="text-muted-foreground ml-2">({p.role})</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Prestataires */}
            {analysis.understood.vendors.length > 0 && (
              <div>
                <p className="text-sm font-semibold mb-2">🎯 Prestataires</p>
                <div className="space-y-1">
                  {analysis.understood.vendors.map((v, idx) => (
                    <div key={idx} className="text-sm px-3 py-1 rounded bg-muted/30">
                      <span className="font-medium">{v.name}</span>
                      <span className="text-muted-foreground ml-2">({v.category})</span>
                      {v.contact && (
                        <p className="text-xs text-primary mt-1">{v.contact}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Dépendances */}
            {analysis.understood.dependencies.length > 0 && (
              <div>
                <p className="text-sm font-semibold mb-2">🔗 Dépendances détectées</p>
                <div className="space-y-1">
                  {analysis.understood.dependencies.map((d, idx) => (
                    <div
                      key={idx}
                      className="text-xs px-3 py-2 rounded bg-muted/30 border-l-2 border-primary"
                    >
                      <p>
                        <span className="font-medium">{d.from}</span>
                        <span className="text-muted-foreground"> → </span>
                        <span className="font-medium">{d.to}</span>
                      </p>
                      <p className="text-muted-foreground mt-1">{d.reason}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Section : Ce qui manque */}
      {missingCount > 0 && (
        <Card className="p-4 bg-yellow-500/10 border-yellow-500/30">
          <button
            onClick={() => toggleSection('missing')}
            className="w-full flex items-center justify-between hover:opacity-80 transition-opacity"
          >
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-500" />
              <h4 className="font-semibold">Ce qui manque ou est flou</h4>
            </div>
            {expandedSections.missing ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>

          {expandedSections.missing && (
            <div className="mt-4 space-y-3">
              {analysis.missing.unclearTimes.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-yellow-600 mb-1">
                    ⏰ Horaires flous
                  </p>
                  <ul className="text-sm space-y-1 ml-4">
                    {analysis.missing.unclearTimes.map((item, idx) => (
                      <li key={idx} className="text-muted-foreground">
                        • {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {analysis.missing.missingContacts.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-yellow-600 mb-1">
                    📞 Contacts manquants
                  </p>
                  <ul className="text-sm space-y-1 ml-4">
                    {analysis.missing.missingContacts.map((item, idx) => (
                      <li key={idx} className="text-muted-foreground">
                        • {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {analysis.missing.actionsWithoutOwner.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-yellow-600 mb-1">
                    👤 Actions sans responsable
                  </p>
                  <ul className="text-sm space-y-1 ml-4">
                    {analysis.missing.actionsWithoutOwner.map((item, idx) => (
                      <li key={idx} className="text-muted-foreground">
                        • {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </Card>
      )}

      {/* Section : Questions pour la mariée */}
      {analysis.suggestedQuestions.length > 0 && (
        <Card className="p-4 bg-blue-500/10 border-blue-500/30">
          <button
            onClick={() => toggleSection('questions')}
            className="w-full flex items-center justify-between hover:opacity-80 transition-opacity"
          >
            <div className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-blue-500" />
              <h4 className="font-semibold">
                Questions à clarifier ({analysis.suggestedQuestions.length})
              </h4>
            </div>
            {expandedSections.questions ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>

          {expandedSections.questions && (
            <div className="mt-4 space-y-4">
              {analysis.suggestedQuestions.map((q, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div
                      className={`px-2 py-1 rounded text-xs font-semibold flex-shrink-0 ${
                        q.importance === 'critical'
                          ? 'bg-red-500/20 text-red-600'
                          : q.importance === 'high'
                            ? 'bg-orange-500/20 text-orange-600'
                            : 'bg-blue-500/20 text-blue-600'
                      }`}
                    >
                      {q.importance.toUpperCase()}
                    </div>
                    <p className="text-sm font-medium flex-1">{q.question}</p>
                  </div>
                  <input
                    type="text"
                    placeholder="Votre réponse..."
                    value={answers[`q${idx}`] || ''}
                    onChange={(e) => handleAnswerChange(idx, e.target.value)}
                    className="w-full px-3 py-2 rounded border border-border bg-muted/30 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button
          variant="outline"
          onClick={onModify}
          className="flex-1"
        >
          Modifier
        </Button>
        <Button
          onClick={() => onConfirm?.(answers)}
          className="flex-1"
        >
          Confirmer et Continuer
        </Button>
      </div>
    </div>
  );
}
