import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, AlertCircle, Clock, Zap } from 'lucide-react';

interface ValidationRule {
  id: string;
  name: string;
  description: string;
  requiredFields: string[];
  currentProgress: number;
  isValid: boolean;
}

interface SmartValidationSystemProps {
  onValidationComplete?: (rule: ValidationRule) => void;
}

const VALIDATION_RULES: ValidationRule[] = [
  {
    id: 'venue',
    name: 'Lieu Confirmé',
    description: 'Réservation et confirmations du lieu',
    requiredFields: ['venueName', 'venueAddress', 'venueContact', 'venueConfirmation'],
    currentProgress: 75,
    isValid: false,
  },
  {
    id: 'catering',
    name: 'Traiteur Organisé',
    description: 'Menu et détails logistiques du traiteur',
    requiredFields: ['cateringName', 'menu', 'guestCount', 'dietaryRestrictions'],
    currentProgress: 50,
    isValid: false,
  },
  {
    id: 'photography',
    name: 'Photographe Réservé',
    description: 'Contrat et horaires du photographe',
    requiredFields: ['photographerName', 'startTime', 'endTime', 'contract'],
    currentProgress: 100,
    isValid: true,
  },
  {
    id: 'music',
    name: 'Musique Programmée',
    description: 'DJ/Musicien et playlist confirmés',
    requiredFields: ['musicianName', 'playlist', 'soundCheck', 'equipment'],
    currentProgress: 25,
    isValid: false,
  },
];

export default function SmartValidationSystem({
  onValidationComplete,
}: SmartValidationSystemProps) {
  const [rules, setRules] = useState<ValidationRule[]>(VALIDATION_RULES);
  const [suggestedActions, setSuggestedActions] = useState<string[]>([]);

  useEffect(() => {
    // Générer des actions suggérées basées sur les validations
    const actions: string[] = [];

    rules.forEach((rule) => {
      if (!rule.isValid && rule.currentProgress > 0) {
        actions.push(`Finaliser "${rule.name}" (${rule.currentProgress}% complété)`);
      } else if (!rule.isValid && rule.currentProgress === 0) {
        actions.push(`Commencer "${rule.name}"`);
      }
    });

    setSuggestedActions(actions);
  }, [rules]);

  const handleValidationAction = (ruleId: string) => {
    setRules((prev) =>
      prev.map((rule) => {
        if (rule.id === ruleId) {
          const updatedRule = {
            ...rule,
            currentProgress: Math.min(100, rule.currentProgress + 25),
            isValid: rule.currentProgress >= 75,
          };
          if (updatedRule.isValid) {
            onValidationComplete?.(updatedRule);
          }
          return updatedRule;
        }
        return rule;
      })
    );
  };

  const validatedCount = rules.filter((r) => r.isValid).length;
  const totalCount = rules.length;
  const completionPercentage = Math.round((validatedCount / totalCount) * 100);

  return (
    <div className="w-full space-y-4">
      <div>
        <h3 className="text-sm font-semibold mb-2">Système de Validation Intelligente</h3>
        <p className="text-xs text-muted-foreground">
          Détecte automatiquement quand une tâche a suffisamment d'informations pour être "prête"
        </p>
      </div>

      {/* Barre de progression globale */}
      <Card className="p-4 bg-card/50">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">Progression Globale</span>
            <span className="text-sm font-mono">{completionPercentage}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
            <div
              className="bg-primary h-full transition-all duration-300"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground">
            {validatedCount} de {totalCount} éléments validés
          </p>
        </div>
      </Card>

      {/* Liste des règles de validation */}
      <div className="space-y-2">
        {rules.map((rule) => (
          <Card key={rule.id} className="p-3 bg-card/50 hover:bg-card/70 transition-colors">
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-2 flex-1">
                  {rule.isValid ? (
                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  ) : rule.currentProgress > 0 ? (
                    <Clock className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold">{rule.name}</p>
                    <p className="text-xs text-muted-foreground">{rule.description}</p>
                  </div>
                </div>
                <span className="text-xs font-mono bg-primary/20 px-2 py-1 rounded flex-shrink-0">
                  {rule.currentProgress}%
                </span>
              </div>

              {/* Barre de progression */}
              <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    rule.isValid ? 'bg-green-500' : 'bg-primary'
                  }`}
                  style={{ width: `${rule.currentProgress}%` }}
                />
              </div>

              {/* Bouton d'action */}
              {!rule.isValid && (
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full text-xs"
                  onClick={() => handleValidationAction(rule.id)}
                >
                  <Zap className="w-3 h-3 mr-1" />
                  Progresser
                </Button>
              )}

              {rule.isValid && (
                <div className="text-xs text-green-600 font-semibold">✓ Validé</div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Actions suggérées */}
      {suggestedActions.length > 0 && (
        <Card className="p-4 bg-primary/10 border-primary/30">
          <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Actions Suggérées
          </h4>
          <ul className="text-xs space-y-1">
            {suggestedActions.slice(0, 3).map((action, idx) => (
              <li key={idx} className="text-muted-foreground">
                • {action}
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Notification de complétion */}
      {completionPercentage === 100 && (
        <Card className="p-4 bg-green-500/10 border-green-500/30">
          <p className="text-sm font-semibold text-green-600">
            🎉 Tous les éléments sont validés! Vous êtes prêt pour l'événement.
          </p>
        </Card>
      )}
    </div>
  );
}
