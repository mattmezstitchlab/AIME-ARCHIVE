import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Mail, MessageSquare, User, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Recipient {
  id: string;
  name: string;
  role: string;
  email?: string;
  phone?: string;
  type: 'vendor' | 'witness' | 'actor' | 'guest';
  message: string;
  sendAt?: string;
  priority: 'critical' | 'high' | 'normal';
}

interface NotificationPreviewProps {
  recipients: Recipient[];
  onConfirm?: () => void;
  onModify?: () => void;
  isLoading?: boolean;
}

const getRecipientIcon = (type: 'vendor' | 'witness' | 'actor' | 'guest') => {
  switch (type) {
    case 'vendor':
      return '🎯';
    case 'witness':
      return '👥';
    case 'actor':
      return '⭐';
    case 'guest':
      return '👤';
  }
};

const getRecipientLabel = (type: 'vendor' | 'witness' | 'actor' | 'guest') => {
  switch (type) {
    case 'vendor':
      return 'Prestataire';
    case 'witness':
      return 'Témoin';
    case 'actor':
      return 'Acteur Jour J';
    case 'guest':
      return 'Invité';
  }
};

const getPriorityColor = (priority: 'critical' | 'high' | 'normal') => {
  switch (priority) {
    case 'critical':
      return 'bg-red-500/10 border-red-500/30';
    case 'high':
      return 'bg-orange-500/10 border-orange-500/30';
    case 'normal':
      return 'bg-blue-500/10 border-blue-500/30';
  }
};

export default function NotificationPreview({
  recipients,
  onConfirm,
  onModify,
  isLoading = false,
}: NotificationPreviewProps) {
  const [expandedRecipient, setExpandedRecipient] = useState<string | null>(null);

  // Grouper par type
  const groupedByType = {
    vendor: recipients.filter((r) => r.type === 'vendor'),
    actor: recipients.filter((r) => r.type === 'actor'),
    witness: recipients.filter((r) => r.type === 'witness'),
    guest: recipients.filter((r) => r.type === 'guest'),
  };

  const totalRecipients = recipients.length;
  const withEmail = recipients.filter((r) => r.email).length;
  const withPhone = recipients.filter((r) => r.phone).length;

  return (
    <div className="w-full h-full overflow-y-auto bg-slate-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Prévisualisation des Notifications</h1>
          <p className="text-slate-400">
            {totalRecipients} destinataires • {withEmail} emails • {withPhone} SMS
          </p>
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="p-4 bg-slate-800 border-slate-700">
            <p className="text-sm text-slate-400 mb-1">Prestataires</p>
            <p className="text-2xl font-bold text-white">{groupedByType.vendor.length}</p>
          </Card>
          <Card className="p-4 bg-slate-800 border-slate-700">
            <p className="text-sm text-slate-400 mb-1">Acteurs Jour J</p>
            <p className="text-2xl font-bold text-white">{groupedByType.actor.length}</p>
          </Card>
          <Card className="p-4 bg-slate-800 border-slate-700">
            <p className="text-sm text-slate-400 mb-1">Témoins</p>
            <p className="text-2xl font-bold text-white">{groupedByType.witness.length}</p>
          </Card>
        </div>

        {/* Onglets par type */}
        <Tabs defaultValue="actor" className="mb-8">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800 border border-slate-700">
            <TabsTrigger value="actor">
              Acteurs ({groupedByType.actor.length})
            </TabsTrigger>
            <TabsTrigger value="vendor">
              Prestataires ({groupedByType.vendor.length})
            </TabsTrigger>
            <TabsTrigger value="witness">
              Témoins ({groupedByType.witness.length})
            </TabsTrigger>
            <TabsTrigger value="guest">
              Invités ({groupedByType.guest.length})
            </TabsTrigger>
          </TabsList>

          {(['actor', 'vendor', 'witness', 'guest'] as const).map((type) => (
            <TabsContent key={type} value={type} className="space-y-3">
              {groupedByType[type].length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  Aucun {getRecipientLabel(type).toLowerCase()}
                </div>
              ) : (
                groupedByType[type].map((recipient) => (
                  <motion.div
                    key={recipient.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Card
                      className={`p-4 border cursor-pointer transition-all hover:border-primary/50 ${getPriorityColor(recipient.priority)}`}
                      onClick={() =>
                        setExpandedRecipient(
                          expandedRecipient === recipient.id ? null : recipient.id
                        )
                      }
                    >
                      <div className="flex items-start gap-4">
                        {/* Icône */}
                        <div className="text-2xl flex-shrink-0">
                          {getRecipientIcon(type)}
                        </div>

                        {/* Contenu */}
                        <div className="flex-grow min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-semibold text-white">{recipient.name}</p>
                            {recipient.priority === 'critical' && (
                              <AlertCircle className="w-4 h-4 text-red-400" />
                            )}
                          </div>
                          <p className="text-sm text-slate-400 mb-2">{recipient.role}</p>
                          <div className="flex flex-wrap gap-2 text-xs">
                            {recipient.email && (
                              <span className="flex items-center gap-1 px-2 py-1 bg-slate-800 rounded">
                                <Mail className="w-3 h-3" />
                                {recipient.email}
                              </span>
                            )}
                            {recipient.phone && (
                              <span className="flex items-center gap-1 px-2 py-1 bg-slate-800 rounded">
                                <MessageSquare className="w-3 h-3" />
                                {recipient.phone}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Chevron */}
                        <motion.div
                          animate={{
                            rotate: expandedRecipient === recipient.id ? 180 : 0,
                          }}
                          className="flex-shrink-0"
                        >
                          <AlertCircle className="w-5 h-5 text-slate-400" />
                        </motion.div>
                      </div>

                      {/* Message détaillé */}
                      <AnimatePresence>
                        {expandedRecipient === recipient.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-4 pt-4 border-t border-slate-700 space-y-3"
                          >
                            <div>
                              <p className="text-xs font-semibold text-slate-400 mb-2">
                                Message à envoyer
                              </p>
                              <div className="bg-slate-800 border border-slate-700 rounded p-3 text-sm text-slate-300 whitespace-pre-wrap">
                                {recipient.message}
                              </div>
                            </div>

                            {recipient.sendAt && (
                              <div>
                                <p className="text-xs font-semibold text-slate-400 mb-1">
                                  À envoyer à
                                </p>
                                <p className="text-sm text-slate-300">{recipient.sendAt}</p>
                              </div>
                            )}

                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onModify?.();
                                }}
                                className="flex-1"
                              >
                                Modifier
                              </Button>
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  // Marquer comme confirmé
                                }}
                                className="flex-1"
                              >
                                <CheckCircle2 className="w-4 h-4 mr-2" />
                                OK
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </Card>
                  </motion.div>
                ))
              )}
            </TabsContent>
          ))}
        </Tabs>

        {/* Boutons d'action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex gap-3"
        >
          <Button
            variant="outline"
            onClick={onModify}
            className="flex-1"
          >
            Modifier
          </Button>
          <Button
            onClick={onConfirm}
            disabled={isLoading}
            className="flex-1"
          >
            {isLoading ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full"
                />
                Envoi en cours...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Confirmer et Envoyer
              </>
            )}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
