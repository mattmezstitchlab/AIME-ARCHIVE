import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: Date;
  maturationState: 'empty' | 'detected' | 'illuminated' | 'ready' | 'validated';
}

interface PointZeroDropZoneProps {
  onFilesUpload?: (files: UploadedFile[]) => void;
}

export default function PointZeroDropZone({ onFilesUpload }: PointZeroDropZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    processFiles(files);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    processFiles(files);
  };

  const processFiles = (files: File[]) => {
    const newFiles: UploadedFile[] = files.map((file) => ({
      id: `${Date.now()}-${Math.random()}`,
      name: file.name,
      type: file.type,
      size: file.size,
      uploadedAt: new Date(),
      maturationState: 'detected', // Commencer en état "détecté"
    }));

    setUploadedFiles((prev) => [...prev, ...newFiles]);
    onFilesUpload?.(newFiles);

    // Simuler la maturation progressive
    newFiles.forEach((file, index) => {
      setTimeout(() => {
        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.id === file.id ? { ...f, maturationState: 'illuminated' } : f
          )
        );
      }, 2000 + index * 1000);

      setTimeout(() => {
        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.id === file.id ? { ...f, maturationState: 'ready' } : f
          )
        );
      }, 4000 + index * 1000);
    });
  };

  const removeFile = (id: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const getMaturationColor = (state: UploadedFile['maturationState']) => {
    const colors = {
      empty: 'bg-gray-800',
      detected: 'bg-gray-700',
      illuminated: 'bg-yellow-500/50',
      ready: 'bg-blue-500/50',
      validated: 'bg-green-500/80',
    };
    return colors[state];
  };

  const getMaturationLabel = (state: UploadedFile['maturationState']) => {
    const labels = {
      empty: 'Vide',
      detected: 'Détecté',
      illuminated: 'Illuminé',
      ready: 'Prêt',
      validated: 'Validé',
    };
    return labels[state];
  };

  return (
    <div className="w-full space-y-4">
      {/* Zone de dépôt */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-lg p-8 transition-all ${
          isDragging
            ? 'border-primary bg-primary/10'
            : 'border-muted-foreground/30 hover:border-muted-foreground/50'
        }`}
      >
        <div className="flex flex-col items-center justify-center space-y-4">
          <Upload className="w-12 h-12 text-muted-foreground" />
          <div className="text-center">
            <p className="font-semibold text-foreground">Déposez vos fichiers ici</p>
            <p className="text-sm text-muted-foreground">
              ou cliquez pour parcourir
            </p>
          </div>
          <input
            type="file"
            multiple
            onChange={handleFileInput}
            className="absolute inset-0 opacity-0 cursor-pointer"
          />
        </div>
      </div>

      {/* Liste des fichiers uploadés */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-semibold">Fichiers détectés ({uploadedFiles.length})</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {uploadedFiles.map((file) => (
              <div
                key={file.id}
                className={`flex items-center justify-between p-3 rounded-lg ${getMaturationColor(
                  file.maturationState
                )} transition-all`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate text-foreground">
                    {file.name}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{(file.size / 1024).toFixed(2)} KB</span>
                    <span>•</span>
                    <span>{getMaturationLabel(file.maturationState)}</span>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(file.id)}
                  className="ml-2 p-1 hover:bg-black/20 rounded transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Bouton d'action */}
      {uploadedFiles.length > 0 && (
        <Button className="w-full">
          Analyser et Organiser ({uploadedFiles.filter((f) => f.maturationState === 'ready').length} prêts)
        </Button>
      )}
    </div>
  );
}
