/**
 * ClassificationCard — Rend visible la pensée du moteur universel
 *
 * Affiche pour chaque élément classifié :
 * - Dimension assignée (couleur + icône)
 * - Raison de classification
 * - État de maturation
 * - Niveau de confiance
 * - Projections possibles
 * - Zone grise si ambigu
 */

import { motion } from 'framer-motion';
import {
  Clock, MapPin, Users, Package, Zap, FileText,
  Brain, MessageSquare, DollarSign, Heart, CheckCircle,
  Link2, AlertTriangle, ChevronDown, ChevronUp, Lightbulb,
  ArrowRight, Star
} from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ClassificationResult {
  itemId?: number;
  categoryId?: number;
  isNewCategory?: boolean;
  primaryDimension: string;
  dimensionColor: string;
  allDimensions: Array<{
    id: string;
    name: string;
    subdimension: string;
    confidence: number;
    reason: string;
  }>;
  mainCategory: string;
  subcategories: string[];
  isClear: boolean;
  clarificationReason?: string | null;
  maturationState: string;
  confidence: number;
  projections: Array<{
    action: string;
    dimension: string;
    priority: string;
  }>;
  linksCreated: Array<{
    type: string;
    targetHint: string;
    strength: number;
  }>;
  suggestedQuestions: string[];
  extractedData: Record<string, unknown>;
  classificationReason: string;
}

interface ClassificationCardProps {
  result: ClassificationResult;
  content: string;
  index?: number;
}

// ─── Icônes par dimension ─────────────────────────────────────────────────────

const DIMENSION_ICONS: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  TEMPS: Clock,
  ESPACE: MapPin,
  PERSONNES: Users,
  RESSOURCES: Package,
  ACTIONS: Zap,
  DOCUMENTS: FileText,
  MEMOIRE: Brain,
  COMMUNICATION: MessageSquare,
  ECONOMIE: DollarSign,
  EMOTIONS: Heart,
  VALIDATION: CheckCircle,
  RELATIONS: Link2,
};

const DIMENSION_NAMES: Record<string, string> = {
  TEMPS: 'Temps',
  ESPACE: 'Espace',
  PERSONNES: 'Personnes',
  RESSOURCES: 'Ressources',
  ACTIONS: 'Actions',
  DOCUMENTS: 'Documents',
  MEMOIRE: 'Mémoire',
  COMMUNICATION: 'Communication',
  ECONOMIE: 'Économie',
  EMOTIONS: 'Émotions',
  VALIDATION: 'Validation',
  RELATIONS: 'Relations',
};

// ─── Maturation ───────────────────────────────────────────────────────────────

const MATURATION_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  empty: { label: 'Vide', color: 'text-slate-400', bg: 'bg-slate-800' },
  detected: { label: 'Détecté', color: 'text-blue-400', bg: 'bg-blue-900/30' },
  illuminated: { label: 'Illuminé', color: 'text-cyan-400', bg: 'bg-cyan-900/30' },
  ready: { label: 'Prêt', color: 'text-green-400', bg: 'bg-green-900/30' },
  validated: { label: 'Validé', color: 'text-emerald-400', bg: 'bg-emerald-900/30' },
  ambiguous: { label: 'Ambigu', color: 'text-orange-400', bg: 'bg-orange-900/30' },
};

const PRIORITY_CONFIG: Record<string, { color: string; label: string }> = {
  high: { color: 'text-red-400', label: 'Urgent' },
  medium: { color: 'text-yellow-400', label: 'Normal' },
  low: { color: 'text-slate-400', label: 'Optionnel' },
};

// ─── Composant ────────────────────────────────────────────────────────────────

export default function ClassificationCard({ result, content, index = 0 }: ClassificationCardProps) {
  const DimIcon = DIMENSION_ICONS[result.primaryDimension] ?? FileText;
  const maturation = MATURATION_CONFIG[result.maturationState] ?? MATURATION_CONFIG.detected;
  const dimName = DIMENSION_NAMES[result.primaryDimension] ?? result.primaryDimension;

  const confidenceColor =
    result.confidence >= 80 ? 'text-green-400' :
    result.confidence >= 60 ? 'text-yellow-400' :
    'text-orange-400';

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.35, delay: index * 0.08, ease: [0.23, 1, 0.32, 1] }}
      className="rounded-xl border border-slate-700/60 bg-slate-900/80 backdrop-blur-sm overflow-hidden"
    >
      {/* ── Header : dimension + confiance ── */}
      <div
        className="flex items-center justify-between px-4 py-3"
        style={{ borderLeft: `3px solid ${result.dimensionColor}` }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: result.dimensionColor + '22', border: `1px solid ${result.dimensionColor}44` }}
          >
            <DimIcon size={16} className="flex-shrink-0" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: result.dimensionColor }}>
                {dimName}
              </span>
              {result.isNewCategory && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-violet-900/40 text-violet-300 border border-violet-700/40 font-medium">
                  Nouvelle catégorie
                </span>
              )}
            </div>
            <p className="text-sm font-medium text-white mt-0.5">{result.mainCategory}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-shrink-0">
          {/* Maturation */}
          <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${maturation.bg} ${maturation.color}`}>
            {maturation.label}
          </span>
          {/* Confiance */}
          <div className="text-right">
            <span className={`text-lg font-bold ${confidenceColor}`}>{result.confidence}%</span>
            <p className="text-[10px] text-slate-500">confiance</p>
          </div>
        </div>
      </div>

      {/* ── Contenu source ── */}
      <div className="px-4 py-2 bg-slate-800/40 border-y border-slate-700/30">
        <p className="text-xs text-slate-400 font-mono leading-relaxed line-clamp-2">
          "{content.slice(0, 120)}{content.length > 120 ? '…' : ''}"
        </p>
      </div>

      {/* ── Corps ── */}
      <div className="px-4 py-3 space-y-3">

        {/* Raison de classification */}
        {result.classificationReason && (
          <div className="flex gap-2">
            <Lightbulb size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-0.5">Pourquoi classé ici</p>
              <p className="text-sm text-slate-300">{result.classificationReason}</p>
            </div>
          </div>
        )}

        {/* Zone grise */}
        {!result.isClear && result.clarificationReason && (
          <div className="flex gap-2 p-2.5 rounded-lg bg-orange-900/20 border border-orange-700/30">
            <AlertTriangle size={14} className="text-orange-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[11px] text-orange-400 uppercase tracking-wider font-medium mb-0.5">Zone grise — Clarification requise</p>
              <p className="text-sm text-orange-200/80">{result.clarificationReason}</p>
            </div>
          </div>
        )}

        {/* Sous-catégories */}
        {result.subcategories.length > 0 && (
          <div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-1.5">Sous-catégories</p>
            <div className="flex flex-wrap gap-1.5">
              {result.subcategories.map((sub, i) => (
                <span
                  key={i}
                  className="text-xs px-2 py-0.5 rounded-full border"
                  style={{
                    backgroundColor: result.dimensionColor + '11',
                    borderColor: result.dimensionColor + '33',
                    color: result.dimensionColor,
                  }}
                >
                  {sub}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Dimensions multiples */}
        {result.allDimensions.length > 1 && (
          <div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-1.5">Dimensions détectées</p>
            <div className="space-y-1">
              {result.allDimensions.map((dim, i) => {
                const Icon = DIMENSION_ICONS[dim.id] ?? FileText;
                return (
                  <div key={i} className="flex items-center gap-2">
                    <Icon size={12} className="text-slate-400" />
                    <span className="text-xs text-slate-400">{DIMENSION_NAMES[dim.id] ?? dim.id}</span>
                    <div className="flex-1 h-1 rounded-full bg-slate-700 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${dim.confidence}%`, backgroundColor: result.dimensionColor }}
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 w-8 text-right">{dim.confidence}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Données extraites */}
        {Object.keys(result.extractedData).length > 0 && (
          <div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-1.5">Données extraites</p>
            <div className="grid grid-cols-2 gap-1.5">
              {Object.entries(result.extractedData).slice(0, 6).map(([key, value]) => (
                <div key={key} className="flex flex-col p-2 rounded bg-slate-800/60 border border-slate-700/30">
                  <span className="text-[10px] text-slate-500 capitalize">{key}</span>
                  <span className="text-xs text-slate-200 font-medium truncate">{String(value)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Liens créés */}
        {result.linksCreated.length > 0 && (
          <div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-1.5">Liens créés</p>
            <div className="space-y-1">
              {result.linksCreated.map((link, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-slate-400">
                  <Link2 size={11} className="text-blue-400 flex-shrink-0" />
                  <span className="text-blue-300 font-medium">{link.type}</span>
                  <ArrowRight size={10} className="text-slate-600" />
                  <span>{link.targetHint}</span>
                  <span className="ml-auto text-slate-500">{link.strength}%</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projections */}
        {result.projections.length > 0 && (
          <div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-1.5">Projections possibles</p>
            <div className="space-y-1.5">
              {result.projections.slice(0, 3).map((proj, i) => {
                const priority = PRIORITY_CONFIG[proj.priority] ?? PRIORITY_CONFIG.medium;
                const ProjIcon = DIMENSION_ICONS[proj.dimension] ?? Zap;
                return (
                  <div key={i} className="flex items-start gap-2 p-2 rounded bg-slate-800/40 border border-slate-700/20">
                    <ProjIcon size={12} className="text-slate-400 mt-0.5 flex-shrink-0" />
                    <span className="text-xs text-slate-300 flex-1">{proj.action}</span>
                    <span className={`text-[10px] font-medium flex-shrink-0 ${priority.color}`}>{priority.label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Questions suggérées */}
        {result.suggestedQuestions.length > 0 && (
          <div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-medium mb-1.5">Questions à poser</p>
            <div className="space-y-1">
              {result.suggestedQuestions.slice(0, 2).map((q, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-400">
                  <Star size={10} className="text-yellow-500 mt-0.5 flex-shrink-0" />
                  <span>{q}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
