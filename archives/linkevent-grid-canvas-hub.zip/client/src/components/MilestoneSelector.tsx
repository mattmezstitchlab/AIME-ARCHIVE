import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export type Milestone = 'J-180' | 'J-90' | 'J-30' | 'J-7' | 'J-1' | 'J0' | 'J+1' | 'J+7';

interface MilestoneSelectorProps {
  selectedMilestone?: Milestone;
  onMilestoneChange?: (milestone: Milestone) => void;
}

const MILESTONES: { value: Milestone; label: string; description: string }[] = [
  { value: 'J-180', label: 'J-180', description: '6 mois avant' },
  { value: 'J-90', label: 'J-90', description: '3 mois avant' },
  { value: 'J-30', label: 'J-30', description: '1 mois avant' },
  { value: 'J-7', label: 'J-7', description: '1 semaine avant' },
  { value: 'J-1', label: 'J-1', description: 'Veille' },
  { value: 'J0', label: 'J0', description: 'Jour J' },
  { value: 'J+1', label: 'J+1', description: 'Lendemain' },
  { value: 'J+7', label: 'J+7', description: '1 semaine après' },
];

export default function MilestoneSelector({
  selectedMilestone = 'J-30',
  onMilestoneChange,
}: MilestoneSelectorProps) {
  const [selected, setSelected] = useState<Milestone>(selectedMilestone);

  const handleMilestoneClick = (milestone: Milestone) => {
    setSelected(milestone);
    onMilestoneChange?.(milestone);
  };

  return (
    <div className="w-full space-y-4">
      <div>
        <h3 className="text-sm font-semibold mb-3">Orchestration Temporelle</h3>
        <p className="text-xs text-muted-foreground mb-4">
          Sélectionnez un jalon pour adapter dynamiquement l'interface et les fonctionnalités disponibles
        </p>
      </div>

      {/* Sélecteur horizontal des jalons */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {MILESTONES.map((milestone) => (
          <button
            key={milestone.value}
            onClick={() => handleMilestoneClick(milestone.value)}
            className={`flex-shrink-0 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
              selected === milestone.value
                ? 'bg-primary text-primary-foreground font-semibold'
                : 'bg-muted hover:bg-muted/80 text-muted-foreground'
            }`}
          >
            {milestone.label}
          </button>
        ))}
      </div>

      {/* Affichage du jalon sélectionné */}
      <Card className="p-4 bg-card/50">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold">Jalon Actif</h4>
            <span className="text-sm font-mono bg-primary/20 px-2 py-1 rounded">
              {selected}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">
            {MILESTONES.find((m) => m.value === selected)?.description}
          </p>
        </div>
      </Card>

      {/* Informations contextuelles basées sur le jalon */}
      <Card className="p-4 bg-muted/30">
        <h4 className="text-sm font-semibold mb-2">Fonctionnalités Adaptées</h4>
        <ul className="text-xs space-y-1 text-muted-foreground">
          {selected === 'J-180' && (
            <>
              <li>✓ Planification générale</li>
              <li>✓ Recherche de prestataires</li>
              <li>✓ Définition du budget</li>
            </>
          )}
          {selected === 'J-90' && (
            <>
              <li>✓ Réservations prestataires</li>
              <li>✓ Choix du lieu</li>
              <li>✓ Gestion des invitations</li>
            </>
          )}
          {selected === 'J-30' && (
            <>
              <li>✓ Confirmations finales</li>
              <li>✓ Détails logistiques</li>
              <li>✓ Coordination équipe</li>
            </>
          )}
          {selected === 'J-7' && (
            <>
              <li>✓ Rappels prestataires</li>
              <li>✓ Vérifications finales</li>
              <li>✓ Préparation jour J</li>
            </>
          )}
          {selected === 'J-1' && (
            <>
              <li>✓ Derniers ajustements</li>
              <li>✓ Confirmations présence</li>
              <li>✓ Briefing équipe</li>
            </>
          )}
          {selected === 'J0' && (
            <>
              <li>✓ Timeline en direct</li>
              <li>✓ Coordination temps réel</li>
              <li>✓ Gestion des urgences</li>
            </>
          )}
          {selected === 'J+1' && (
            <>
              <li>✓ Remerciements</li>
              <li>✓ Collecte photos/vidéos</li>
              <li>✓ Retours prestataires</li>
            </>
          )}
          {selected === 'J+7' && (
            <>
              <li>✓ Archivage documents</li>
              <li>✓ Bilan événement</li>
              <li>✓ Paiements finaux</li>
            </>
          )}
        </ul>
      </Card>
    </div>
  );
}
