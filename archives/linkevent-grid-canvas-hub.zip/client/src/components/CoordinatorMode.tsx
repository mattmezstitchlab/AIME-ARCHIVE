import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, CheckCircle2, AlertCircle, Send, MessageSquare, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface Task {
  id: number;
  title: string;
  description?: string;
  scheduledTime: Date;
  duration?: number;
  status: 'pending' | 'in_progress' | 'completed' | 'delayed' | 'cancelled';
  actors?: string;
  dependencies?: string;
}

interface CoordinatorModeProps {
  eventId: number;
  tasks: Task[];
  onTaskUpdate?: (taskId: number, status: string) => void;
}

export default function CoordinatorMode({ eventId, tasks, onTaskUpdate }: CoordinatorModeProps) {
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [reminderMessage, setReminderMessage] = useState('');
  const [isSendingReminder, setIsSendingReminder] = useState(false);
  const [sortedTasks, setSortedTasks] = useState<Task[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'in_progress' | 'completed'>('all');

  const sendReminderMutation = trpc.notifications.sendReminder.useMutation({
    onSuccess: () => {
      toast.success('Rappel envoyé ! ✅');
      setReminderMessage('');
      setSelectedTask(null);
      setIsSendingReminder(false);
    },
    onError: (error) => {
      toast.error(`Erreur : ${error.message}`);
      setIsSendingReminder(false);
    },
  });

  useEffect(() => {
    // Trier les tâches par heure
    const sorted = [...tasks].sort((a, b) => {
      const timeA = new Date(a.scheduledTime).getTime();
      const timeB = new Date(b.scheduledTime).getTime();
      return timeA - timeB;
    });
    setSortedTasks(sorted);
  }, [tasks]);

  const filteredTasks = sortedTasks.filter((task) => {
    if (filter === 'all') return true;
    return task.status === filter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-slate-700/20 border-slate-600';
      case 'in_progress':
        return 'bg-blue-900/20 border-blue-700';
      case 'completed':
        return 'bg-green-900/20 border-green-700';
      case 'delayed':
        return 'bg-red-900/20 border-red-700';
      case 'cancelled':
        return 'bg-gray-900/20 border-gray-700';
      default:
        return 'bg-slate-700/20 border-slate-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-slate-400" />;
      case 'in_progress':
        return <AlertCircle className="w-4 h-4 text-blue-400 animate-pulse" />;
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      case 'delayed':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const handleSendReminder = async () => {
    if (!selectedTask || !reminderMessage.trim()) {
      toast.error('Veuillez sélectionner une tâche et écrire un message');
      return;
    }

    setIsSendingReminder(true);
    sendReminderMutation.mutate({
      eventId,
      recipientId: 1, // À adapter selon le contexte réel
      message: reminderMessage,
    });
  };

  const handleStatusChange = (taskId: number, newStatus: string) => {
    onTaskUpdate?.(taskId, newStatus);
    toast.success(`Statut mis à jour ✅`);
  };

  const stats = {
    total: sortedTasks.length,
    completed: sortedTasks.filter((t) => t.status === 'completed').length,
    inProgress: sortedTasks.filter((t) => t.status === 'in_progress').length,
    pending: sortedTasks.filter((t) => t.status === 'pending').length,
  };

  return (
    <div className="space-y-6">
      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-3">
        <Card className="bg-slate-800/50 border-slate-700 p-4 text-center">
          <p className="text-2xl font-bold text-blue-400">{stats.total}</p>
          <p className="text-xs text-slate-400">Total</p>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700 p-4 text-center">
          <p className="text-2xl font-bold text-yellow-400">{stats.pending}</p>
          <p className="text-xs text-slate-400">À faire</p>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700 p-4 text-center">
          <p className="text-2xl font-bold text-blue-400">{stats.inProgress}</p>
          <p className="text-xs text-slate-400">En cours</p>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700 p-4 text-center">
          <p className="text-2xl font-bold text-green-400">{stats.completed}</p>
          <p className="text-xs text-slate-400">Terminé</p>
        </Card>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2">
        {(['all', 'pending', 'in_progress', 'completed'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded text-sm font-medium transition-all ${
              filter === f
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'
            }`}
          >
            {f === 'all' ? 'Tous' : f === 'pending' ? 'À faire' : f === 'in_progress' ? 'En cours' : 'Terminé'}
          </button>
        ))}
      </div>

      {/* Tasks List */}
      <div className="space-y-3">
        <AnimatePresence mode="wait">
          {filteredTasks.length === 0 ? (
            <Card className="bg-slate-800/50 border-slate-700 p-8 text-center">
              <p className="text-slate-400">Aucune tâche pour ce filtre</p>
            </Card>
          ) : (
            filteredTasks.map((task, idx) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card
                  className={`p-4 cursor-pointer transition-all hover:border-blue-600/50 ${getStatusColor(
                    task.status
                  )}`}
                  onClick={() => setSelectedTask(task)}
                >
                  <div className="flex items-start gap-4">
                    {/* Status Icon */}
                    <div className="flex-shrink-0 mt-1">{getStatusIcon(task.status)}</div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-slate-100 font-semibold text-sm">{task.title}</p>
                          {task.description && (
                            <p className="text-slate-400 text-xs mt-1">{task.description}</p>
                          )}
                        </div>
                        <span className="text-lg font-bold text-blue-400 flex-shrink-0">
                          {new Date(task.scheduledTime).toLocaleTimeString('fr-FR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      {/* Quick Actions */}
                      <div className="flex gap-2 mt-3">
                        {task.status !== 'completed' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleStatusChange(task.id, 'completed');
                            }}
                            className="text-xs px-2 py-1 bg-green-600/20 text-green-300 rounded hover:bg-green-600/40 transition-colors"
                          >
                            ✓ Marquer comme fait
                          </button>
                        )}
                        {task.status !== 'in_progress' && task.status !== 'completed' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleStatusChange(task.id, 'in_progress');
                            }}
                            className="text-xs px-2 py-1 bg-blue-600/20 text-blue-300 rounded hover:bg-blue-600/40 transition-colors"
                          >
                            ▶ En cours
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Reminder Panel */}
      <AnimatePresence>
        {selectedTask && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="bg-blue-900/20 border-blue-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-slate-100">
                  📢 Envoyer un rappel pour : {selectedTask.title}
                </h3>
                <button
                  onClick={() => setSelectedTask(null)}
                  className="text-slate-400 hover:text-slate-300"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <Textarea
                  value={reminderMessage}
                  onChange={(e) => setReminderMessage(e.target.value)}
                  placeholder="Écrivez votre message de rappel..."
                  className="h-24 bg-slate-900/50 border-slate-600 text-slate-100 placeholder-slate-500"
                />

                <div className="flex gap-3">
                  <Button
                    onClick={handleSendReminder}
                    disabled={isSendingReminder || !reminderMessage.trim()}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {isSendingReminder ? 'Envoi...' : 'Envoyer le rappel'}
                  </Button>
                  <Button
                    onClick={() => setSelectedTask(null)}
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-800"
                  >
                    Annuler
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
