import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, AlertCircle, CheckCircle, Zap, Lock } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface InternalGridProps {
  eventId: number;
}

export default function InternalGrid({ eventId }: InternalGridProps) {
  const [expandedCategories, setExpandedCategories] = useState<number[]>([]);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [filter, setFilter] = useState<'all' | 'classified' | 'unclarified' | 'validated'>('all');

  const { data: gridData, isLoading, refetch } = trpc.classification.getInternalGrid.useQuery(
    { eventId },
    { enabled: !!eventId }
  );

  const toggleCategory = (categoryId: number) => {
    setExpandedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId]
    );
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 p-8">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin text-2xl">⚙️</div>
          <p className="text-slate-400 ml-4">Chargement de la grille interne...</p>
        </div>
      </Card>
    );
  }

  if (!gridData) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 p-8">
        <p className="text-slate-400 text-center">Aucune donnée disponible</p>
      </Card>
    );
  }

  const filteredItems = gridData.items.filter((item: any) => {
    if (filter === 'all') return true;
    return item.status === filter;
  });

  return (
    <div className="space-y-6">
      {/* Header avec stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <Card className="bg-blue-900/20 border-blue-700 p-4 text-center">
          <p className="text-2xl font-bold text-blue-400">{gridData.stats.totalCategories}</p>
          <p className="text-xs text-slate-400">Catégories</p>
        </Card>
        <Card className="bg-green-900/20 border-green-700 p-4 text-center">
          <p className="text-2xl font-bold text-green-400">{gridData.stats.classifiedItems}</p>
          <p className="text-xs text-slate-400">Classifiés</p>
        </Card>
        <Card className="bg-yellow-900/20 border-yellow-700 p-4 text-center">
          <p className="text-2xl font-bold text-yellow-400">{gridData.stats.ambiguousItems}</p>
          <p className="text-xs text-slate-400">En attente</p>
        </Card>
        <Card className="bg-purple-900/20 border-purple-700 p-4 text-center">
          <p className="text-2xl font-bold text-purple-400">{gridData.stats.totalLinks}</p>
          <p className="text-xs text-slate-400">Liés</p>
        </Card>
        <Card className="bg-red-900/20 border-red-700 p-4 text-center">
          <p className="text-2xl font-bold text-red-400">{gridData.stats.unclarifiedCount}</p>
          <p className="text-xs text-slate-400">À clarifier</p>
        </Card>
      </div>

      {/* Filtres */}
      <div className="flex gap-2 flex-wrap">
        {(['all', 'classified', 'unclarified', 'validated'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1 rounded text-xs font-medium transition-all ${
              filter === f
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'
            }`}
          >
            {f === 'all' ? '📊 Tous' : f === 'classified' ? '✓ Classifiés' : f === 'unclarified' ? '❓ À clarifier' : '✅ Validés'}
          </button>
        ))}
      </div>

      {/* Grille des catégories */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-slate-100">📁 Hiérarchie des Catégories</h3>
        <div className="space-y-2">
          {gridData.categories.map((category: any) => (
            <motion.div key={category.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <Card className="bg-slate-800/30 border-slate-700 p-4 hover:border-blue-600/50 transition-colors">
                {/* Catégorie principale */}
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full flex items-center justify-between text-left"
                >
                  <div className="flex items-center gap-3">
                    {category.subcategories.length > 0 && (
                      <div className="text-slate-400">
                        {expandedCategories.includes(category.id) ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </div>
                    )}
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: category.color }}
                    />
                    <span className="text-slate-100 font-medium">{category.name}</span>
                  </div>
                  <span className="text-xs bg-slate-700/50 px-2 py-1 rounded text-slate-300">
                    {category.itemCount} élément{category.itemCount > 1 ? 's' : ''}
                  </span>
                </button>

                {/* Sous-catégories */}
                <AnimatePresence>
                  {expandedCategories.includes(category.id) && category.subcategories.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 ml-6 space-y-2 border-l border-slate-700 pl-3"
                    >
                      {category.subcategories.map((sub: any) => (
                        <div key={sub.id} className="flex items-center justify-between text-sm">
                          <span className="text-slate-300">→ {sub.name}</span>
                          <span className="text-xs text-slate-400">
                            {sub.itemCount} élément{sub.itemCount > 1 ? 's' : ''}
                          </span>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Éléments classifiés */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-slate-100">📦 Éléments Classifiés</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {filteredItems.length === 0 ? (
            <Card className="bg-slate-800/30 border-slate-700 p-4 text-center">
              <p className="text-slate-400 text-sm">Aucun élément pour ce filtre</p>
            </Card>
          ) : (
            filteredItems.map((item: any, idx: number) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card
                  className="bg-slate-800/30 border-slate-700 p-3 cursor-pointer hover:border-blue-600/50 transition-colors"
                  onClick={() => setSelectedItem(item)}
                >
                  <div className="flex items-start gap-3">
                    {/* Status icon */}
                    <div className="flex-shrink-0 mt-1">
                      {item.status === 'classified' && (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      )}
                      {item.status === 'pending_clarification' && (
                        <AlertCircle className="w-4 h-4 text-yellow-400" />
                      )}
                      {item.status === 'validated' && (
                        <Lock className="w-4 h-4 text-blue-400" />
                      )}
                      {item.status === 'linked' && (
                        <Zap className="w-4 h-4 text-purple-400" />
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-100 text-sm truncate">{item.content}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs bg-slate-700/50 px-2 py-0.5 rounded text-slate-300">
                          {item.type}
                        </span>
                        <span className="text-xs text-slate-400">
                          Confiance: {item.confidence}%
                        </span>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))
          )}
        </div>
      </div>

      {/* Éléments à clarifier */}
      {gridData.unclarified.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-slate-100">❓ Zones Grises (À Clarifier)</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {gridData.unclarified.map((item: any, idx: number) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card className="bg-yellow-900/20 border-yellow-700 p-3">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-1" />
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-100 text-sm">{item.content}</p>
                      <p className="text-xs text-yellow-300 mt-1">Raison: {item.reason}</p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Détail de l'élément sélectionné */}
      {selectedItem && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedItem(null)}
        >
          <Card
            className="bg-slate-800 border-slate-700 p-6 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-semibold text-slate-100 mb-4">Détail de l'Élément</h3>
            <div className="space-y-3">
              <div>
                <p className="text-xs text-slate-400 uppercase">Contenu</p>
                <p className="text-slate-100 text-sm mt-1">{selectedItem.content}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Type</p>
                <p className="text-slate-100 text-sm mt-1">{selectedItem.type}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Statut</p>
                <p className="text-slate-100 text-sm mt-1">{selectedItem.status}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Confiance</p>
                <div className="w-full bg-slate-700 rounded-full h-2 mt-1">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${selectedItem.confidence}%` }}
                  />
                </div>
              </div>
            </div>
            <Button
              onClick={() => setSelectedItem(null)}
              className="w-full mt-6 bg-slate-700 hover:bg-slate-600 text-white"
            >
              Fermer
            </Button>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
