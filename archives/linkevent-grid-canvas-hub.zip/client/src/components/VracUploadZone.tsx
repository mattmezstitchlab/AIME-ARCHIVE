import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, Image, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';

interface VracUploadZoneProps {
  onVracSubmit: (vrac: { text: string; files: File[] }) => void;
  isLoading?: boolean;
  onLoadExample?: (text: string) => void;
}

const exampleWeddingVrac = `Mariage Sophie & Marc - 14 septembre 2026

Cérémonie: 14:00 Mairie de Commines
Cocktail: 15:30 Château de Vaux
Dîner: 18:30 (140 invités)
Soirée: 21:00

Prestataires:
- Traiteur Delice: 06 12 34 56 78
- Photographe Marc: 06 98 76 54 32
- DJ Maxime: 06 11 22 33 44
- Fleuriste Roseline: 06 55 44 33 22
- Saxophoniste Laurent: 06 77 88 99 00

Témoins: Julie (sœur), Thomas (ami)
Coordinatrice: Émilie - 06 51 52 53 54

Notes: 20 enfants, navettes hôtel, allergies gluten/lactose`;

export default function VracUploadZone({ onVracSubmit, isLoading = false, onLoadExample }: VracUploadZoneProps) {
  const [textInput, setTextInput] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    setUploadedFiles((prev) => [...prev, ...files]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setUploadedFiles((prev) => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    if (textInput.trim() || uploadedFiles.length > 0) {
      onVracSubmit({
        text: textInput,
        files: uploadedFiles,
      });
    }
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) {
      return <Image className="w-4 h-4" />;
    }
    if (file.type === 'application/pdf') {
      return <FileText className="w-4 h-4" />;
    }
    return <File className="w-4 h-4" />;
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 space-y-6">
      {/* Zone de texte */}
      <Card className="p-6 bg-slate-800/50 border-slate-700">
        <label className="block text-sm font-semibold text-slate-200 mb-3">
          Collez votre déroulé, notes, messages...
        </label>
        <Textarea
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          placeholder="Exemple:
14:00 - Cérémonie à la mairie
15:30 - Cocktail au jardin
19:00 - Dîner avec traiteur Delice
DJ Marc pour la soirée
Photographe: Jean Dupont (06 12 34 56 78)
Témoins: Marie et Pierre
..."
          className="min-h-40 bg-slate-900/50 border-slate-600 text-white placeholder-slate-500"
        />
        <p className="text-xs text-slate-400 mt-2">
          Horaires, noms, prestataires, musiques, lieux, tout ce que vous avez en vrac.
        </p>
      </Card>

      {/* Zone de dépôt fichiers */}
      <Card
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`p-8 border-2 border-dashed transition-all cursor-pointer ${
          dragActive
            ? 'border-primary bg-primary/10'
            : 'border-slate-600 bg-slate-800/30 hover:bg-slate-800/50'
        }`}
      >
        <div className="flex flex-col items-center justify-center text-center">
          <Upload className="w-12 h-12 text-slate-400 mb-3" />
          <p className="text-sm font-semibold text-slate-200 mb-1">
            Déposez vos fichiers ici
          </p>
          <p className="text-xs text-slate-400 mb-4">
            PDF, images, documents, captures d'écran...
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            className="text-xs"
          >
            Parcourir les fichiers
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            accept=".pdf,.jpg,.jpeg,.png,.gif,.doc,.docx,.txt"
          />
        </div>
      </Card>

      {/* Liste des fichiers uploadés */}
      {uploadedFiles.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-2"
        >
          <p className="text-sm font-semibold text-slate-300">
            {uploadedFiles.length} fichier{uploadedFiles.length > 1 ? 's' : ''} sélectionné{uploadedFiles.length > 1 ? 's' : ''}
          </p>
          <div className="space-y-2">
            {uploadedFiles.map((file, idx) => (
              <motion.div
                key={`${file.name}-${idx}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between p-3 bg-slate-800/50 border border-slate-700 rounded"
              >
                <div className="flex items-center gap-3">
                  <div className="text-slate-400">
                    {getFileIcon(file)}
                  </div>
                  <div className="text-sm">
                    <p className="text-slate-200 font-medium truncate">{file.name}</p>
                    <p className="text-xs text-slate-400">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(idx)}
                  className="text-slate-400 hover:text-red-400 transition-colors"
                >
                  ✕
                </button>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Boutons d'action */}
      <div className="flex gap-3">
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex-1"
        >
          <Button
            onClick={handleSubmit}
            disabled={(!textInput.trim() && uploadedFiles.length === 0) || isLoading}
            className="w-full py-6 text-lg font-semibold"
            size="lg"
          >
            {isLoading ? (
              <>
                <span className="inline-block animate-spin mr-2">⚡</span>
                Analyse en cours...
              </>
            ) : (
              <>
                Analyser le vrac
                <span className="ml-2">→</span>
              </>
            )}
          </Button>
        </motion.div>
        <Button
          onClick={() => {
            setTextInput(exampleWeddingVrac);
            onLoadExample?.(exampleWeddingVrac);
          }}
          variant="outline"
          disabled={isLoading}
          className="py-6"
          size="lg"
        >
          📋 Exemple
        </Button>
      </div>

      {/* Conseils */}
      <div className="bg-slate-800/30 border border-slate-700 rounded p-4">
        <p className="text-xs text-slate-400 font-semibold mb-2">💡 Conseils :</p>
        <ul className="text-xs text-slate-400 space-y-1">
          <li>• Collez tout ce que vous avez : déroulé, messages, notes, captures</li>
          <li>• Ajoutez des fichiers : PDF du déroulé, images de la décoration, etc.</li>
          <li>• Le système détectera automatiquement horaires, personnes, prestataires</li>
          <li>• Vous pourrez confirmer ou corriger avant d'envoyer</li>
        </ul>
      </div>
    </div>
  );
}
