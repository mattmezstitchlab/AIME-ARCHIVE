import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, Zap, AlertCircle, CheckCircle, Link2, Lightbulb } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

interface ClassificationResultProps {
  result: any;
  onViewGrid?: () => void;
  onClarify?: (itemId: number) => void;
}

export default function ClassificationResult({ result, onViewGrid, onClarify }: ClassificationResultProps) {
  const [expandedSections, setExpandedSections] = useState<string[]>([
    'categories',
    'items',
    'unclarified',
  ]);

  const toggleSection = (section: string) => {
    setExpandedSections((prev) =>
      prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]
    );
  };

  if (!result) return null;

  const isUnclarified = result.type === 'unclarified';
  const isClassified = result.type === 'classified';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Status Header */}
      <Card
        className={`p-6 border-l-4 ${
          isUnclarified
            ? 'bg-yellow-900/20 border-yellow-600 border-l-yellow-500'
            : 'bg-green-900/20 border-green-600 border-l-green-500'
        }`}
      >
        <div className="flex items-start gap-4">
          <div className="text-3xl flex-shrink-0">
            {isUnclarified ? '❓' : '✅'}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-slate-100 mb-1">
              {isUnclarified ? 'Élément Ambigu Détecté' : 'Élément Classifié'}
            </h3>
            <p className="text-slate-300 text-sm mb-3">
              {isUnclarified
                ? result.clarificationReason
                : `Classé dans "${result.mainCategory}" avec ${result.confidence}% de confiance`}
            </p>
            {isUnclarified && result.suggestedCategories && (
              <div className="flex gap-2 flex-wrap">
                {result.suggestedCategories.map((cat: string, idx: number) => (
                  <span
                    key={idx}
                    className="text-xs bg-yellow-700/50 text-yellow-200 px-2 py-1 rounded"
                  >
                    {cat}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Catégories Créées */}
      {isClassified && result.subcategories && result.subcategories.length > 0 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <button
            onClick={() => toggleSection('categories')}
            className="w-full flex items-center justify-between p-4 bg-slate-800/30 border border-slate-700 rounded-lg hover:border-blue-600/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              {expandedSections.includes('categories') ? (
                <ChevronDown className="w-5 h-5 text-blue-400" />
              ) : (
                <ChevronRight className="w-5 h-5 text-blue-400" />
              )}
              <Lightbulb className="w-5 h-5 text-blue-400" />
              <span className="text-slate-100 font-semibold">
                📁 Sous-catégories Créées
              </span>
              <span className="text-xs bg-blue-600/30 text-blue-300 px-2 py-1 rounded-full">
                {result.subcategories.length}
              </span>
            </div>
          </button>

          <AnimatePresence>
            {expandedSections.includes('categories') && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-2 space-y-2 ml-2"
              >
                {result.subcategories.map((subcat: string, idx: number) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex items-center gap-3 p-3 bg-slate-800/20 border border-slate-700 rounded"
                  >
                    <Zap className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                    <span className="text-slate-200 text-sm">{subcat}</span>
                    <span className="text-xs text-slate-400 ml-auto">
                      Nouvelle catégorie
                    </span>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Confiance et Métadonnées */}
      {isClassified && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <Card className="bg-slate-800/30 border-slate-700 p-4">
            <h4 className="text-sm font-semibold text-slate-100 mb-3">📊 Analyse Détaillée</h4>

            {/* Confiance */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400">Niveau de Confiance</span>
                <span className="text-sm font-bold text-blue-400">{result.confidence}%</span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${result.confidence}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                  className="bg-gradient-to-r from-blue-500 to-blue-400 h-2 rounded-full"
                />
              </div>
            </div>

            {/* Métadonnées */}
            {result.metadata && (
              <div className="space-y-2">
                {result.metadata.extractedData && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase mb-1">Données Extraites</p>
                    <p className="text-sm text-slate-300">{result.metadata.extractedData}</p>
                  </div>
                )}

                {result.metadata.suggestedQuestions && result.metadata.suggestedQuestions.length > 0 && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase mb-2">Questions Suggérées</p>
                    <div className="space-y-1">
                      {result.metadata.suggestedQuestions.map((q: string, idx: number) => (
                        <div key={idx} className="text-xs text-slate-300 flex gap-2">
                          <span className="text-blue-400">•</span>
                          <span>{q}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>
        </motion.div>
      )}

      {/* Zones Grises */}
      {isUnclarified && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <Card className="bg-yellow-900/20 border-yellow-700 p-4">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-1" />
              <div>
                <h4 className="text-sm font-semibold text-yellow-200 mb-1">Pourquoi c'est ambigu ?</h4>
                <p className="text-sm text-yellow-100">{result.clarificationReason}</p>
              </div>
            </div>

            {onClarify && (
              <Button
                onClick={() => onClarify(result.itemId)}
                className="w-full bg-yellow-600 hover:bg-yellow-700 text-white text-sm"
              >
                Clarifier Maintenant
              </Button>
            )}
          </Card>
        </motion.div>
      )}

      {/* Liens Détectés */}
      {isClassified && result.metadata?.suggestedLinks && result.metadata.suggestedLinks.length > 0 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <button
            onClick={() => toggleSection('links')}
            className="w-full flex items-center justify-between p-4 bg-slate-800/30 border border-slate-700 rounded-lg hover:border-purple-600/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              {expandedSections.includes('links') ? (
                <ChevronDown className="w-5 h-5 text-purple-400" />
              ) : (
                <ChevronRight className="w-5 h-5 text-purple-400" />
              )}
              <Link2 className="w-5 h-5 text-purple-400" />
              <span className="text-slate-100 font-semibold">
                🔗 Liens Détectés
              </span>
              <span className="text-xs bg-purple-600/30 text-purple-300 px-2 py-1 rounded-full">
                {result.metadata.suggestedLinks.length}
              </span>
            </div>
          </button>

          <AnimatePresence>
            {expandedSections.includes('links') && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-2 space-y-2 ml-2"
              >
                {result.metadata.suggestedLinks.map((link: any, idx: number) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex items-start gap-3 p-3 bg-slate-800/20 border border-slate-700 rounded"
                  >
                    <Link2 className="w-4 h-4 text-purple-400 flex-shrink-0 mt-1" />
                    <div className="flex-1">
                      <p className="text-xs font-semibold text-purple-300 uppercase">
                        {link.type.replace(/_/g, ' ')}
                      </p>
                      <p className="text-sm text-slate-200 mt-1">{link.description}</p>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Actions */}
      <div className="flex gap-3 pt-4">
        <Button
          onClick={onViewGrid}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
        >
          🎛️ Voir la Grille Interne
        </Button>
        <Button
          variant="outline"
          className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800"
        >
          📋 Continuer
        </Button>
      </div>
    </motion.div>
  );
}
