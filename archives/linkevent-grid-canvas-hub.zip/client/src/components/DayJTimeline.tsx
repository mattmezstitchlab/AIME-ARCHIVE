import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, MapPin, Users, AlertCircle, CheckCircle2, Circle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface TimelineTask {
  id: string;
  time: string;
  action: string;
  responsible: string;
  location?: string;
  dependencies?: string[];
  status: 'todo' | 'inprogress' | 'done';
  category: string;
}

interface DayJTimelineProps {
  tasks: TimelineTask[];
  onStatusChange?: (taskId: string, status: 'todo' | 'inprogress' | 'done') => void;
}

const CATEGORY_COLORS: Record<string, string> = {
  cérémonie: 'from-blue-500 to-blue-600',
  cocktail: 'from-cyan-500 to-cyan-600',
  réception: 'from-amber-500 to-amber-600',
  soirée: 'from-pink-500 to-pink-600',
  préparatifs: 'from-purple-500 to-purple-600',
  technique: 'from-indigo-500 to-indigo-600',
  logistique: 'from-teal-500 to-teal-600',
  transport: 'from-green-500 to-green-600',
  communication: 'from-orange-500 to-orange-600',
  hébergement: 'from-emerald-500 to-emerald-600',
};

const getStatusIcon = (status: 'todo' | 'inprogress' | 'done') => {
  switch (status) {
    case 'done':
      return <CheckCircle2 className="w-5 h-5 text-green-400" />;
    case 'inprogress':
      return <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 1, repeat: Infinity }} className="w-5 h-5 text-yellow-400 border-2 border-yellow-400 rounded-full" />;
    case 'todo':
      return <Circle className="w-5 h-5 text-slate-400" />;
  }
};

const getStatusLabel = (status: 'todo' | 'inprogress' | 'done') => {
  switch (status) {
    case 'done':
      return 'Terminé';
    case 'inprogress':
      return 'En cours';
    case 'todo':
      return 'À faire';
  }
};

const getStatusColor = (status: 'todo' | 'inprogress' | 'done') => {
  switch (status) {
    case 'done':
      return 'bg-green-500/10 border-green-500/30';
    case 'inprogress':
      return 'bg-yellow-500/10 border-yellow-500/30';
    case 'todo':
      return 'bg-slate-800/30 border-slate-700';
  }
};

export default function DayJTimeline({ tasks, onStatusChange }: DayJTimelineProps) {
  const [expandedTask, setExpandedTask] = useState<string | null>(null);

  // Trier les tâches par heure
  const sortedTasks = [...tasks].sort((a, b) => {
    const timeA = parseInt(a.time.split(':')[0]);
    const timeB = parseInt(b.time.split(':')[0]);
    return timeA - timeB;
  });

  // Grouper par heure
  const groupedByHour = sortedTasks.reduce(
    (acc, task) => {
      const hour = task.time.split(':')[0];
      if (!acc[hour]) acc[hour] = [];
      acc[hour].push(task);
      return acc;
    },
    {} as Record<string, TimelineTask[]>
  );

  const hours = Object.keys(groupedByHour).sort();

  const cycleStatus = (currentStatus: 'todo' | 'inprogress' | 'done') => {
    const cycle: Record<'todo' | 'inprogress' | 'done', 'todo' | 'inprogress' | 'done'> = {
      todo: 'inprogress',
      inprogress: 'done',
      done: 'todo',
    };
    return cycle[currentStatus];
  };

  return (
    <div className="w-full h-full overflow-y-auto bg-slate-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Jour J - Timeline</h1>
          <p className="text-slate-400">
            {sortedTasks.length} tâches • {sortedTasks.filter((t) => t.status === 'done').length} terminées
          </p>
        </div>

        {/* Barre de progression */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-slate-300">Progression</span>
            <span className="text-sm text-slate-400">
              {Math.round((sortedTasks.filter((t) => t.status === 'done').length / sortedTasks.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{
                width: `${(sortedTasks.filter((t) => t.status === 'done').length / sortedTasks.length) * 100}%`,
              }}
              transition={{ duration: 0.5 }}
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
            />
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-6">
          {hours.map((hour) => (
            <motion.div
              key={hour}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-3"
            >
              {/* Heure */}
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 w-16 text-right">
                  <p className="text-2xl font-bold text-white">{hour}:00</p>
                </div>
                <div className="flex-grow h-0.5 bg-gradient-to-r from-slate-700 to-transparent" />
              </div>

              {/* Tâches de cette heure */}
              <div className="ml-20 space-y-2">
                {groupedByHour[hour].map((task) => (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="group"
                  >
                    <Card
                      className={`p-4 border transition-all cursor-pointer hover:border-primary/50 ${getStatusColor(task.status)}`}
                      onClick={() => setExpandedTask(expandedTask === task.id ? null : task.id)}
                    >
                      <div className="flex items-start gap-4">
                        {/* Statut */}
                        <div className="flex-shrink-0 pt-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onStatusChange?.(task.id, cycleStatus(task.status));
                            }}
                            className="hover:scale-110 transition-transform"
                          >
                            {getStatusIcon(task.status)}
                          </button>
                        </div>

                        {/* Contenu */}
                        <div className="flex-grow min-w-0">
                          <p className="font-semibold text-white mb-1">{task.action}</p>
                          <div className="flex flex-wrap gap-2 text-xs text-slate-400">
                            {task.responsible && (
                              <span className="flex items-center gap-1">
                                <Users className="w-3 h-3" />
                                {task.responsible}
                              </span>
                            )}
                            {task.location && (
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {task.location}
                              </span>
                            )}
                            <span className={`px-2 py-0.5 rounded-full text-white font-medium bg-gradient-to-r ${CATEGORY_COLORS[task.category] || 'from-slate-600 to-slate-700'}`}>
                              {task.category}
                            </span>
                          </div>
                        </div>

                        {/* Statut label */}
                        <div className="flex-shrink-0 text-right">
                          <p className="text-xs font-semibold text-slate-400">
                            {getStatusLabel(task.status)}
                          </p>
                        </div>
                      </div>

                      {/* Détails étendus */}
                      {expandedTask === task.id && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="mt-4 pt-4 border-t border-slate-700 space-y-3"
                        >
                          {task.dependencies && task.dependencies.length > 0 && (
                            <div>
                              <p className="text-xs font-semibold text-slate-400 mb-2">Dépendances</p>
                              <div className="flex flex-wrap gap-2">
                                {task.dependencies.map((dep, idx) => (
                                  <span key={idx} className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs text-slate-300 flex items-center gap-1">
                                    <AlertCircle className="w-3 h-3" />
                                    {dep}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                onStatusChange?.(task.id, 'inprogress');
                              }}
                              className="flex-1"
                            >
                              Démarrer
                            </Button>
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                onStatusChange?.(task.id, 'done');
                              }}
                              className="flex-1"
                            >
                              Terminer
                            </Button>
                          </div>
                        </motion.div>
                      )}
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Message si vide */}
        {sortedTasks.length === 0 && (
          <div className="text-center py-12">
            <Clock className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">Aucune tâche pour le Jour J</p>
          </div>
        )}
      </div>
    </div>
  );
}
