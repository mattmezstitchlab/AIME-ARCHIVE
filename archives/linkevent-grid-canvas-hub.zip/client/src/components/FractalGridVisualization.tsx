import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, Folder, FolderOpen } from 'lucide-react';

interface FractalCategory {
  id: number;
  name: string;
  description?: string;
  color: string;
  itemCount: number;
  isSystem: boolean;
  children?: FractalCategory[];
  depth?: number;
  confidence?: number;
  createdAt?: string;
}

interface FractalGridVisualizationProps {
  categories: FractalCategory[];
  onCategoryClick?: (category: FractalCategory) => void;
  onCategoryExpand?: (categoryId: number) => void;
}

export default function FractalGridVisualization({
  categories,
  onCategoryClick,
  onCategoryExpand,
}: FractalGridVisualizationProps) {
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const toggleExpanded = (id: number) => {
    setExpandedIds((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
    if (onCategoryExpand) {
      onCategoryExpand(id);
    }
  };

  const handleCategoryClick = (category: FractalCategory) => {
    setSelectedId(category.id);
    if (onCategoryClick) {
      onCategoryClick(category);
    }
  };

  const renderCategory = (
    category: FractalCategory,
    depth: number = 0,
    index: number = 0
  ) => {
    const isExpanded = expandedIds.has(category.id);
    const isSelected = selectedId === category.id;
    const hasChildren = category.children && category.children.length > 0;

    // Calcul de la taille basée sur la profondeur et le nombre d'éléments
    const sizeMultiplier = Math.max(0.7, 1 - depth * 0.15);
    const itemCountDisplay = category.itemCount > 0 ? category.itemCount : '∅';

    return (
      <motion.div
        key={category.id}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{
          duration: 0.4,
          delay: depth * 0.05 + index * 0.03,
          ease: 'easeOut',
        }}
        className="mb-2"
        style={{ marginLeft: `${depth * 24}px` }}
      >
        {/* Conteneur de la catégorie */}
        <motion.div
          onClick={() => handleCategoryClick(category)}
          className="group relative"
          whileHover={{ x: 4 }}
          whileTap={{ scale: 0.98 }}
        >
          {/* Ligne de connexion visuelle (pour les sous-catégories) */}
          {depth > 0 && (
            <div
              className="absolute left-0 top-1/2 w-6 h-0.5 -translate-x-6 -translate-y-1/2"
              style={{
                backgroundColor: `${categories[0]?.color || '#3B82F6'}40`,
              }}
            />
          )}

          {/* Contenu de la catégorie */}
          <div
            className={`relative p-3 rounded-lg border-2 backdrop-blur-sm transition-all cursor-pointer ${
              isSelected ? 'ring-2 ring-offset-2' : ''
            }`}
            style={{
              borderColor: category.color,
              backgroundColor: isSelected ? `${category.color}25` : `${category.color}15`,
              outlineColor: category.color,
              transform: `scale(${sizeMultiplier})`,
              transformOrigin: 'left center',
            } as React.CSSProperties}
          >
            <div className="flex items-start justify-between gap-2">
              {/* Icône et contenu */}
              <div className="flex items-start gap-2 flex-1 min-w-0">
                {/* Bouton d'expansion */}
                {hasChildren && (
                  <motion.button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleExpanded(category.id);
                    }}
                    className="p-0.5 rounded hover:bg-slate-700 transition-colors flex-shrink-0"
                    animate={{ rotate: isExpanded ? 90 : 0 }}
                  >
                    <ChevronRight size={16} style={{ color: category.color }} />
                  </motion.button>
                )}

                {/* Icône de dossier */}
                {!hasChildren && (
                  <div className="p-0.5 flex-shrink-0">
                    {isExpanded ? (
                      <FolderOpen size={16} style={{ color: category.color }} />
                    ) : (
                      <Folder size={16} style={{ color: category.color }} />
                    )}
                  </div>
                )}

                {/* Texte */}
                <div className="flex-1 min-w-0">
                  <h4
                    className="font-semibold text-sm truncate"
                    style={{ color: category.color }}
                  >
                    {category.name}
                  </h4>

                  {category.description && (
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {category.description}
                    </p>
                  )}
                </div>
              </div>

              {/* Badge de comptage */}
              <motion.div
                className="px-2 py-1 rounded-full text-xs font-semibold flex-shrink-0"
                style={{
                  backgroundColor: `${category.color}40`,
                  color: category.color,
                }}
                animate={{
                  scale: isSelected ? 1.1 : 1,
                }}
              >
                {itemCountDisplay}
              </motion.div>
            </div>

            {/* Barre de progression */}
            {category.confidence && category.confidence > 0 && (
              <motion.div
                className="h-0.5 rounded-full mt-2 overflow-hidden bg-slate-700"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
              >
                <motion.div
                  className="h-full rounded-full"
                  style={{ backgroundColor: category.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${category.confidence}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
                />
              </motion.div>
            )}

            {/* Badge système */}
            {category.isSystem && (
              <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-400" />
            )}
          </div>

          {/* Enfants (sous-catégories) */}
          <AnimatePresence>
            {isExpanded && hasChildren && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-1 space-y-1"
              >
                {category.children!.map((child, childIndex) =>
                  renderCategory(
                    { ...child, depth: depth + 1 },
                    depth + 1,
                    childIndex
                  )
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>
    );
  };

  return (
    <div className="w-full h-full overflow-auto p-6 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 rounded-lg">
      {/* En-tête */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 sticky top-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-4 z-10"
      >
        <h2 className="text-2xl font-bold text-blue-300 mb-2">🗂️ Grille Hiérarchique</h2>
        <p className="text-sm text-slate-400">
          {categories.length} catégories • Cliquez pour explorer • Déployer pour voir les sous-catégories
        </p>
      </motion.div>

      {/* Grille de catégories */}
      {categories.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-64 text-slate-400"
        >
          <div className="text-5xl mb-4">📭</div>
          <p className="text-lg font-semibold">Aucune catégorie</p>
          <p className="text-sm mt-2">Lancez une analyse pour voir la grille se construire</p>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ staggerChildren: 0.05 }}
          className="space-y-1"
        >
          <AnimatePresence mode="popLayout">
            {categories.map((category, index) => renderCategory(category, 0, index))}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Légende */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-8 pt-6 border-t border-slate-700 text-xs text-slate-500"
      >
        <p className="mb-3 font-semibold text-slate-400">Légende :</p>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <ChevronRight size={14} />
            <span>Cliquez pour déployer les sous-catégories</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-400" />
            <span>Catégorie système</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-4 rounded bg-slate-700" />
            <span>Barre de confiance</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
