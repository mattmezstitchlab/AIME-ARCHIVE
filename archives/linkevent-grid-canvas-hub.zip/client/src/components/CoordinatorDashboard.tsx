import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, CheckCircle, AlertCircle, Send, Phone, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';

interface Task {
  id: number;
  time: string;
  title: string;
  responsible: string;
  status: 'todo' | 'in_progress' | 'done';
  dependencies?: string[];
  contact?: string;
}

interface CoordinatorDashboardProps {
  tasks: Task[];
  eventName: string;
  eventDate: string;
  onTaskUpdate?: (taskId: number, status: 'todo' | 'in_progress' | 'done') => void;
  onSendReminder?: (taskId: number, message: string) => void;
}

export default function CoordinatorDashboard({
  tasks,
  eventName,
  eventDate,
  onTaskUpdate,
  onSendReminder,
}: CoordinatorDashboardProps) {
  const [selectedTask, setSelectedTask] = useState<number | null>(null);
  const [reminderMessage, setReminderMessage] = useState('');
  const [sendingReminder, setSendingReminder] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'done':
        return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'in_progress':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      default:
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'done':
        return <CheckCircle className="w-4 h-4" />;
      case 'in_progress':
        return <Clock className="w-4 h-4 animate-spin" />;
      default:
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'done':
        return 'Terminé';
      case 'in_progress':
        return 'En cours';
      default:
        return 'À faire';
    }
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    const timeA = parseInt(a.time.split(':')[0]);
    const timeB = parseInt(b.time.split(':')[0]);
    return timeA - timeB;
  });

  const handleSendReminder = async () => {
    if (!selectedTask || !reminderMessage.trim()) return;

    setSendingReminder(true);
    try {
      await onSendReminder?.(selectedTask, reminderMessage);
      setReminderMessage('');
      setSelectedTask(null);
    } finally {
      setSendingReminder(false);
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* En-tête */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 p-6 rounded-lg border border-slate-700">
        <h2 className="text-2xl font-bold text-white mb-2">{eventName}</h2>
        <p className="text-slate-400">{eventDate}</p>
        <p className="text-sm text-slate-500 mt-2">
          {tasks.filter(t => t.status === 'done').length} / {tasks.length} tâches complétées
        </p>
      </div>

      {/* Barre de progression */}
      <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
        <div className="flex justify-between items-center mb-2">
          <p className="text-sm font-semibold text-slate-300">Progression globale</p>
          <p className="text-sm font-bold text-blue-400">
            {Math.round((tasks.filter(t => t.status === 'done').length / tasks.length) * 100)}%
          </p>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2">
          <motion.div
            initial={{ width: 0 }}
            animate={{
              width: `${(tasks.filter(t => t.status === 'done').length / tasks.length) * 100}%`,
            }}
            transition={{ duration: 0.5 }}
            className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full"
          />
        </div>
      </div>

      {/* Timeline des tâches */}
      <div className="space-y-3">
        {sortedTasks.map((task, idx) => (
          <motion.div
            key={task.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
          >
            <Card
              onClick={() => setSelectedTask(selectedTask === task.id ? null : task.id)}
              className={`p-4 cursor-pointer transition-all border-l-4 ${
                task.status === 'done'
                  ? 'border-l-green-500 bg-slate-800/30'
                  : task.status === 'in_progress'
                  ? 'border-l-blue-500 bg-slate-800/50'
                  : 'border-l-yellow-500 bg-slate-800/30'
              } hover:bg-slate-800/60`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-lg font-bold text-slate-300 min-w-fit">
                      {task.time}
                    </span>
                    <h3 className="text-white font-semibold">{task.title}</h3>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="text-xs">
                      {task.responsible}
                    </Badge>
                    {task.contact && (
                      <span className="text-xs text-slate-400">{task.contact}</span>
                    )}
                  </div>
                  {task.dependencies && task.dependencies.length > 0 && (
                    <p className="text-xs text-slate-400">
                      Dépend de: {task.dependencies.join(', ')}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`${getStatusColor(task.status)} flex items-center gap-1`}>
                    {getStatusIcon(task.status)}
                    {getStatusLabel(task.status)}
                  </Badge>
                </div>
              </div>

              {/* Actions rapides */}
              {selectedTask === task.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-4 pt-4 border-t border-slate-700 space-y-3"
                >
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={task.status === 'todo' ? 'default' : 'outline'}
                      onClick={() => onTaskUpdate?.(task.id, 'todo')}
                      className="text-xs"
                    >
                      À faire
                    </Button>
                    <Button
                      size="sm"
                      variant={task.status === 'in_progress' ? 'default' : 'outline'}
                      onClick={() => onTaskUpdate?.(task.id, 'in_progress')}
                      className="text-xs"
                    >
                      En cours
                    </Button>
                    <Button
                      size="sm"
                      variant={task.status === 'done' ? 'default' : 'outline'}
                      onClick={() => onTaskUpdate?.(task.id, 'done')}
                      className="text-xs"
                    >
                      Terminé
                    </Button>
                  </div>

                  {/* Envoi de rappel */}
                  {task.contact && (
                    <div className="space-y-2">
                      <Textarea
                        placeholder="Message de rappel..."
                        value={reminderMessage}
                        onChange={(e) => setReminderMessage(e.target.value)}
                        className="text-xs min-h-20 bg-slate-900/50 border-slate-600"
                      />
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={handleSendReminder}
                          disabled={!reminderMessage.trim() || sendingReminder}
                          className="text-xs flex-1"
                        >
                          <Send className="w-3 h-3 mr-1" />
                          {sendingReminder ? 'Envoi...' : 'Envoyer rappel'}
                        </Button>
                        {task.contact.includes('@') ? (
                          <Mail className="w-4 h-4 text-slate-400" />
                        ) : (
                          <Phone className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Statistiques */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-4 bg-slate-800/30 border-slate-700">
          <p className="text-xs text-slate-400 mb-1">À faire</p>
          <p className="text-2xl font-bold text-yellow-400">
            {tasks.filter(t => t.status === 'todo').length}
          </p>
        </Card>
        <Card className="p-4 bg-slate-800/30 border-slate-700">
          <p className="text-xs text-slate-400 mb-1">En cours</p>
          <p className="text-2xl font-bold text-blue-400">
            {tasks.filter(t => t.status === 'in_progress').length}
          </p>
        </Card>
        <Card className="p-4 bg-slate-800/30 border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Terminé</p>
          <p className="text-2xl font-bold text-green-400">
            {tasks.filter(t => t.status === 'done').length}
          </p>
        </Card>
      </div>
    </div>
  );
}
