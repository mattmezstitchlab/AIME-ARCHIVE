import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface Link {
  id: string;
  fromItemId: number;
  toItemId: number;
  linkType: 'related' | 'depends_on' | 'references' | 'contradicts' | 'completes';
  reason: string;
  strength: number;
}

interface AnimatedLinksVisualizationProps {
  links: Link[];
  itemPositions: Map<number, { x: number; y: number }>;
}

export default function AnimatedLinksVisualization({
  links,
  itemPositions,
}: AnimatedLinksVisualizationProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  // Couleurs pour les types de liens
  const linkColors: Record<Link['linkType'], string> = {
    related: '#60A5FA', // Bleu
    depends_on: '#F59E0B', // Orange
    references: '#8B5CF6', // Violet
    contradicts: '#EF4444', // Rouge
    completes: '#10B981', // Vert
  };

  const linkLabels: Record<Link['linkType'], string> = {
    related: 'Lié à',
    depends_on: 'Dépend de',
    references: 'Référence',
    contradicts: 'Contredit',
    completes: 'Complète',
  };

  useEffect(() => {
    if (!svgRef.current || links.length === 0) return;

    const svg = svgRef.current;
    const width = svg.clientWidth;
    const height = svg.clientHeight;

    // Redimensionner le SVG
    svg.setAttribute('width', String(width));
    svg.setAttribute('height', String(height));
  }, [links]);

  const renderLink = (link: Link, index: number) => {
    const fromPos = itemPositions.get(link.fromItemId);
    const toPos = itemPositions.get(link.toItemId);

    if (!fromPos || !toPos) return null;

    const color = linkColors[link.linkType];
    const opacity = link.strength / 100;

    // Créer un chemin courbe (Bézier)
    const dx = toPos.x - fromPos.x;
    const dy = toPos.y - fromPos.y;
    const controlX = fromPos.x + dx / 2;
    const controlY = fromPos.y + dy / 2 + 30;

    const pathData = `M ${fromPos.x} ${fromPos.y} Q ${controlX} ${controlY} ${toPos.x} ${toPos.y}`;

    return (
      <motion.g key={link.id}>
        {/* Ligne du lien */}
        <motion.path
          d={pathData}
          stroke={color}
          strokeWidth={2}
          fill="none"
          opacity={opacity}
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: opacity }}
          transition={{
            duration: 0.8,
            ease: 'easeOut',
            delay: index * 0.1,
          }}
          className="drop-shadow-lg"
        />

        {/* Point de départ */}
        <motion.circle
          cx={fromPos.x}
          cy={fromPos.y}
          r={4}
          fill={color}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        />

        {/* Point d'arrivée */}
        <motion.circle
          cx={toPos.x}
          cy={toPos.y}
          r={4}
          fill={color}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
        />

        {/* Flèche de direction */}
        <motion.polygon
          points={`${toPos.x},${toPos.y} ${toPos.x - 8},${toPos.y - 6} ${toPos.x - 6},${toPos.y}`}
          fill={color}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.4 }}
        />

        {/* Label du lien (optionnel) */}
        <motion.text
          x={controlX}
          y={controlY - 10}
          textAnchor="middle"
          fontSize="11"
          fill={color}
          opacity={0.7}
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
        >
          {linkLabels[link.linkType]}
        </motion.text>
      </motion.g>
    );
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 rounded-lg p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-4"
      >
        <h3 className="text-lg font-bold text-blue-300">🔗 Connexions</h3>
        <p className="text-sm text-slate-400">{links.length} liens détectés</p>
      </motion.div>

      <svg
        ref={svgRef}
        className="w-full border border-slate-700 rounded-lg bg-slate-800/50"
        style={{ minHeight: '300px' }}
      >
        {links.map((link, index) => renderLink(link, index))}
      </svg>

      {/* Légende */}
      <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
        {Object.entries(linkLabels).map(([type, label]) => (
          <div key={type} className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: linkColors[type as Link['linkType']] }}
            />
            <span className="text-slate-400">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
