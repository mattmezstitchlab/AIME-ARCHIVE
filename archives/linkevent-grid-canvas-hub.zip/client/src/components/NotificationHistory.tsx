import { motion } from 'framer-motion';
import { Mail, MessageCircle, Bell, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { trpc } from '@/lib/trpc';
import { useEffect, useState } from 'react';

interface NotificationHistoryProps {
  eventId: number;
}

export default function NotificationHistory({ eventId }: NotificationHistoryProps) {
  const [notifications, setNotifications] = useState<any[]>([]);
  const { data: historyData, isLoading } = trpc.notifications.getNotificationHistory.useQuery(
    { eventId },
    { enabled: !!eventId }
  );

  useEffect(() => {
    if (historyData) {
      setNotifications(historyData);
    }
  }, [historyData]);

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'email':
        return <Mail className="w-4 h-4" />;
      case 'sms':
        return <MessageCircle className="w-4 h-4" />;
      case 'in_app':
        return <Bell className="w-4 h-4" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'scheduled':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      default:
        return <Clock className="w-4 h-4 text-slate-500" />;
    }
  };

  const getChannelLabel = (channel: string) => {
    const labels: Record<string, string> = {
      email: '📧 Email',
      sms: '📱 SMS',
      in_app: '🔔 In-App',
    };
    return labels[channel] || channel;
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin">⏳</div>
          <p className="text-slate-400 ml-3">Chargement de l'historique...</p>
        </div>
      </Card>
    );
  }

  if (!notifications || notifications.length === 0) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <p className="text-slate-400 text-center py-8">Aucune notification envoyée pour le moment</p>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <h3 className="text-lg font-semibold text-slate-100 mb-4">📬 Historique des Notifications</h3>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {notifications.map((notif, idx) => (
          <motion.div
            key={notif.id || idx}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="flex items-start gap-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700 hover:border-blue-600/50 transition-colors"
          >
            {/* Channel Icon */}
            <div className="flex-shrink-0 mt-1 text-slate-400">
              {getChannelIcon(notif.channel)}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-slate-100 font-medium text-sm">{notif.subject}</p>
                  <p className="text-slate-400 text-xs mt-1 line-clamp-2">{notif.message}</p>
                </div>
                <div className="flex-shrink-0">
                  {getStatusIcon(notif.status)}
                </div>
              </div>

              {/* Metadata */}
              <div className="flex items-center gap-3 mt-2 text-xs text-slate-400">
                <span className="bg-slate-800/50 px-2 py-1 rounded">
                  {getChannelLabel(notif.channel)}
                </span>
                {notif.sentAt && (
                  <span>
                    {new Date(notif.sentAt).toLocaleTimeString('fr-FR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Summary */}
      <div className="mt-4 pt-4 border-t border-slate-700">
        <p className="text-xs text-slate-400">
          Total : <span className="font-semibold text-slate-300">{notifications.length}</span> notification(s)
        </p>
      </div>
    </Card>
  );
}
