import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus } from 'lucide-react';

interface GridItem {
  id: string;
  name: string;
  color: string;
  confidence: number;
  type: 'category' | 'unclarified' | 'link';
  explanation?: string;
  parentId?: string;
  children?: GridItem[];
  position?: { x: number; y: number };
}

interface AnimatedGridVisualizationProps {
  items: GridItem[];
  isLoading?: boolean;
  onItemClick?: (item: GridItem) => void;
}

export default function AnimatedGridVisualization({
  items,
  isLoading = false,
  onItemClick,
}: AnimatedGridVisualizationProps) {
  const [displayedItems, setDisplayedItems] = useState<GridItem[]>([]);
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  // Animer l'apparition progressive des items
  useEffect(() => {
    if (items.length === 0) return;

    let index = 0;
    const interval = setInterval(() => {
      if (index < items.length) {
        setDisplayedItems((prev) => [...prev, items[index]]);
        index++;
      } else {
        clearInterval(interval);
      }
    }, 150); // Délai entre chaque item

    return () => clearInterval(interval);
  }, [items]);

  const toggleExpanded = (itemId: string) => {
    setExpandedItems((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) {
        newSet.delete(itemId);
      } else {
        newSet.add(itemId);
      }
      return newSet;
    });
  };

  const renderGridItem = (item: GridItem, depth: number = 0) => {
    const isExpanded = expandedItems.has(item.id);
    const hasChildren = item.children && item.children.length > 0;

    return (
      <motion.div
        key={item.id}
        initial={{ opacity: 0, scale: 0.8, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8 }}
        transition={{
          duration: 0.4,
          ease: 'easeOut',
          delay: depth * 0.05,
        }}
        className="mb-3"
        style={{ marginLeft: `${depth * 20}px` }}
      >
        {/* Conteneur de la case */}
        <motion.div
          onClick={() => {
            if (hasChildren) toggleExpanded(item.id);
            if (onItemClick) onItemClick(item);
          }}
          className="relative group cursor-pointer"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {/* Arrière-plan avec gradient */}
          <motion.div
            className="absolute inset-0 rounded-lg blur-lg opacity-0 group-hover:opacity-100 transition-opacity"
            style={{
              backgroundColor: item.color,
              opacity: 0.3,
            }}
            animate={{
              opacity: [0.2, 0.4, 0.2],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          />

          {/* Contenu de la case */}
          <div
            className="relative p-4 rounded-lg border-2 backdrop-blur-sm transition-all"
            style={{
              borderColor: item.color,
              backgroundColor: `${item.color}15`,
              borderWidth: '2px',
            }}
          >
            {/* En-tête */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <h3
                  className="font-semibold text-sm transition-colors"
                  style={{ color: item.color }}
                >
                  {item.name}
                </h3>

                {/* Badge de type */}
                <div className="flex gap-2 mt-2">
                  <span
                    className="text-xs px-2 py-1 rounded-full font-medium"
                    style={{
                      backgroundColor: `${item.color}30`,
                      color: item.color,
                    }}
                  >
                    {item.type === 'category' && '📁 Catégorie'}
                    {item.type === 'unclarified' && '❓ À Clarifier'}
                    {item.type === 'link' && '🔗 Lien'}
                  </span>

                  {/* Confiance */}
                  {item.confidence > 0 && (
                    <span className="text-xs px-2 py-1 rounded-full bg-slate-700 text-slate-300">
                      {item.confidence}% confiance
                    </span>
                  )}
                </div>
              </div>

              {/* Bouton d'expansion */}
              {hasChildren && (
                <motion.button
                  animate={{ rotate: isExpanded ? 180 : 0 }}
                  className="p-1 rounded hover:bg-slate-700 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleExpanded(item.id);
                  }}
                >
                  <Plus size={16} style={{ color: item.color }} />
                </motion.button>
              )}
            </div>

            {/* Explication */}
            {item.explanation && (
              <motion.p
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="text-xs text-slate-400 mt-2 italic"
              >
                💡 {item.explanation}
              </motion.p>
            )}

            {/* Barre de progression pour la confiance */}
            {item.confidence > 0 && (
              <motion.div
                className="h-1 rounded-full mt-3 overflow-hidden bg-slate-700"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
              >
                <motion.div
                  className="h-full rounded-full"
                  style={{ backgroundColor: item.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${item.confidence}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
                />
              </motion.div>
            )}
          </div>

          {/* Enfants (sous-catégories) */}
          <AnimatePresence>
            {isExpanded && hasChildren && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-3 space-y-2"
              >
                {item.children!.map((child) => renderGridItem(child, depth + 1))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>
    );
  };

  return (
    <div className="w-full h-full overflow-auto p-6 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 rounded-lg">
      {/* Titre avec animation */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h2 className="text-2xl font-bold text-blue-300 mb-2">🎛️ Grille de Classement</h2>
        <p className="text-sm text-slate-400">
          {isLoading ? '⏳ Analyse en cours...' : `${displayedItems.length} éléments classés`}
        </p>
      </motion.div>

      {/* État vide */}
      {displayedItems.length === 0 && !isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-64 text-slate-400"
        >
          <div className="text-4xl mb-4">📭</div>
          <p>Aucun élément à afficher</p>
          <p className="text-sm mt-2">Lancez une analyse pour voir la grille se construire</p>
        </motion.div>
      )}

      {/* Grille d'items */}
      <AnimatePresence mode="popLayout">
        <div className="space-y-3">
          {displayedItems.map((item) => renderGridItem(item))}
        </div>
      </AnimatePresence>

      {/* Indicateur de chargement */}
      {isLoading && (
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="mt-8 text-center text-slate-500"
        >
          <div className="inline-flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span className="text-sm">Analyse en cours...</span>
          </div>
        </motion.div>
      )}
    </div>
  );
}
