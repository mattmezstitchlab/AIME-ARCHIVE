import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, AlertTriangle, HelpCircle, ChevronDown, Save, Loader } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface Question {
  id: string;
  question: string;
  importance: 'critical' | 'high' | 'medium' | 'low';
  relatedTo: string;
  answer?: string;
  answered: boolean;
}

interface QuestionsPanelProps {
  questions: Question[];
  eventId?: number;
  onAnswersConfirmed?: (answers: Record<string, string>) => void;
}

const getImportanceIcon = (importance: 'critical' | 'high' | 'medium' | 'low') => {
  switch (importance) {
    case 'critical':
      return <AlertCircle className="w-5 h-5 text-red-400" />;
    case 'high':
      return <AlertTriangle className="w-5 h-5 text-orange-400" />;
    case 'medium':
      return <HelpCircle className="w-5 h-5 text-yellow-400" />;
    case 'low':
      return <HelpCircle className="w-5 h-5 text-slate-400" />;
  }
};

const getImportanceColor = (importance: 'critical' | 'high' | 'medium' | 'low') => {
  switch (importance) {
    case 'critical':
      return 'bg-red-500/10 border-red-500/30';
    case 'high':
      return 'bg-orange-500/10 border-orange-500/30';
    case 'medium':
      return 'bg-yellow-500/10 border-yellow-500/30';
    case 'low':
      return 'bg-slate-800/30 border-slate-700';
  }
};

const getImportanceLabel = (importance: 'critical' | 'high' | 'medium' | 'low') => {
  switch (importance) {
    case 'critical':
      return 'Critique';
    case 'high':
      return 'Important';
    case 'medium':
      return 'Utile';
    case 'low':
      return 'Optionnel';
  }
};

export default function QuestionsPanel({
  questions,
  eventId,
  onAnswersConfirmed,
}: QuestionsPanelProps) {
  const [answers, setAnswers] = useState<Record<string, string>>(
    questions.reduce((acc, q) => ({ ...acc, [q.id]: q.answer || '' }), {})
  );
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const saveAnswersMutation = trpc.questions.saveAnswers.useMutation();

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }));
  };

  const handleSaveAnswers = async () => {
    if (!eventId) {
      toast.error('Event ID manquant');
      return;
    }

    setIsSaving(true);
    try {
      await saveAnswersMutation.mutateAsync({
        eventId,
        answers,
      });

      toast.success('Réponses sauvegardées avec succès');
      onAnswersConfirmed?.(answers);
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde des réponses');
      console.error('Error saving answers:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const criticalQuestions = questions.filter((q) => q.importance === 'critical');
  const highQuestions = questions.filter((q) => q.importance === 'high');
  const mediumQuestions = questions.filter((q) => q.importance === 'medium');
  const lowQuestions = questions.filter((q) => q.importance === 'low');

  const answeredCount = Object.values(answers).filter((a) => a.trim().length > 0).length;
  const totalCount = questions.length;

  const renderQuestionGroup = (
    title: string,
    groupQuestions: Question[],
    icon: React.ReactNode
  ) => {
    if (groupQuestions.length === 0) return null;

    return (
      <div key={title} className="space-y-3">
        <div className="flex items-center gap-2 mb-3">
          {icon}
          <h3 className="font-semibold text-slate-200">
            {title} ({groupQuestions.length})
          </h3>
        </div>

        <div className="space-y-2">
          {groupQuestions.map((question) => (
            <motion.div
              key={question.id}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card
                className={`p-4 cursor-pointer transition-all border ${getImportanceColor(
                  question.importance
                )}`}
                onClick={() =>
                  setExpandedQuestion(
                    expandedQuestion === question.id ? null : question.id
                  )
                }
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-200">
                      {question.question}
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Concerne: {question.relatedTo}
                    </p>
                  </div>
                  <motion.div
                    animate={{ rotate: expandedQuestion === question.id ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  </motion.div>
                </div>

                <AnimatePresence>
                  {expandedQuestion === question.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 pt-4 border-t border-slate-700"
                    >
                      {question.importance === 'critical' ||
                      question.importance === 'high' ? (
                        <Textarea
                          value={answers[question.id] || ''}
                          onChange={(e) =>
                            handleAnswerChange(question.id, e.target.value)
                          }
                          placeholder="Votre réponse..."
                          className="min-h-24 bg-slate-900/50 border-slate-600 text-white"
                        />
                      ) : (
                        <Input
                          type="text"
                          value={answers[question.id] || ''}
                          onChange={(e) =>
                            handleAnswerChange(question.id, e.target.value)
                          }
                          placeholder="Votre réponse..."
                          className="bg-slate-900/50 border-slate-600 text-white"
                        />
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full space-y-6">
      {/* En-tête */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 p-6 rounded-lg border border-slate-700">
        <h2 className="text-2xl font-bold text-white mb-2">
          Questions à Confirmer
        </h2>
        <div className="flex items-center justify-between">
          <p className="text-slate-400">
            {answeredCount} / {totalCount} réponses
          </p>
          <div className="w-32 bg-slate-700 rounded-full h-2">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(answeredCount / totalCount) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full"
            />
          </div>
        </div>
      </div>

      {/* Groupes de questions */}
      <div className="space-y-6">
        {renderQuestionGroup(
          'Critique',
          criticalQuestions,
          <AlertCircle className="w-5 h-5 text-red-400" />
        )}
        {renderQuestionGroup(
          'Important',
          highQuestions,
          <AlertTriangle className="w-5 h-5 text-orange-400" />
        )}
        {renderQuestionGroup(
          'Utile',
          mediumQuestions,
          <HelpCircle className="w-5 h-5 text-yellow-400" />
        )}
        {renderQuestionGroup(
          'Optionnel',
          lowQuestions,
          <HelpCircle className="w-5 h-5 text-slate-400" />
        )}
      </div>

      {/* Bouton de sauvegarde */}
      <motion.div
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <Button
          onClick={handleSaveAnswers}
          disabled={isSaving || answeredCount === 0}
          className="w-full py-6 text-lg font-semibold flex items-center justify-center gap-2"
          size="lg"
        >
          {isSaving ? (
            <>
              <Loader className="w-5 h-5 animate-spin" />
              Sauvegarde en cours...
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              Confirmer les Réponses
            </>
          )}
        </Button>
      </motion.div>

      {/* Conseils */}
      <div className="bg-slate-800/30 border border-slate-700 rounded p-4">
        <p className="text-xs text-slate-400 font-semibold mb-2">💡 Conseils :</p>
        <ul className="text-xs text-slate-400 space-y-1">
          <li>• Les questions critiques doivent être répondues en priorité</li>
          <li>• Vos réponses mettront à jour automatiquement la timeline Jour J</li>
          <li>• Vous pourrez modifier vos réponses à tout moment</li>
          <li>• Une fois confirmées, les réponses seront envoyées aux prestataires</li>
        </ul>
      </div>
    </div>
  );
}
