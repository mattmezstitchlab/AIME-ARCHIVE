import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Zap } from 'lucide-react';

interface GridSquare {
  id: string;
  x: number;
  y: number;
  state: 'empty' | 'detected' | 'categorized' | 'understood' | 'ready' | 'validated' | 'conflict';
  category?: string;
  label?: string;
  color?: string;
  hasAlert?: boolean;
}

interface LiveGridProps {
  squares?: GridSquare[];
  isAnalyzing?: boolean;
  onDrop?: (files: File[]) => void;
}

const GRID_SIZE = 12; // 12x12 grille
const SQUARE_SIZE = 60;
const COLORS = {
  préparatifs: '#8B5CF6',
  cérémonie: '#3B82F6',
  cocktail: '#06B6D4',
  réception: '#F59E0B',
  soirée: '#EC4899',
  hébergement: '#10B981',
  transport: '#6366F1',
  logistique: '#14B8A6',
  technique: '#8B5CF6',
  communication: '#F97316',
};

const getStateColor = (state: GridSquare['state'], category?: string) => {
  switch (state) {
    case 'empty':
      return '#E5E7EB';
    case 'detected':
      return '#D1D5DB';
    case 'categorized':
      return COLORS[category as keyof typeof COLORS] || '#9CA3AF';
    case 'understood':
      return COLORS[category as keyof typeof COLORS] || '#6B7280';
    case 'ready':
      return COLORS[category as keyof typeof COLORS] || '#374151';
    case 'validated':
      return COLORS[category as keyof typeof COLORS] || '#1F2937';
    case 'conflict':
      return '#EF4444';
    default:
      return '#E5E7EB';
  }
};

const getStateOpacity = (state: GridSquare['state']) => {
  switch (state) {
    case 'empty':
      return 0.3;
    case 'detected':
      return 0.5;
    case 'categorized':
      return 0.6;
    case 'understood':
      return 0.8;
    case 'ready':
      return 0.9;
    case 'validated':
      return 1;
    case 'conflict':
      return 1;
    default:
      return 0.3;
  }
};

export default function LiveGrid({ squares = [], isAnalyzing = false, onDrop }: LiveGridProps) {
  const [dragActive, setDragActive] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    onDrop?.(files);
  };

  // Générer les carrés vides de la grille
  const gridSquares = Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, idx) => {
    const x = idx % GRID_SIZE;
    const y = Math.floor(idx / GRID_SIZE);
    const existingSquare = squares.find((s) => s.x === x && s.y === y);
    return (
      existingSquare || {
        id: `grid-${x}-${y}`,
        x,
        y,
        state: 'empty' as const,
      }
    );
  });

  // Point Zéro au centre
  const centerX = Math.floor(GRID_SIZE / 2);
  const centerY = Math.floor(GRID_SIZE / 2);

  return (
    <div
      ref={gridRef}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      className={`relative w-full h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 overflow-hidden transition-all duration-300 ${
        dragActive ? 'ring-4 ring-primary/50' : ''
      }`}
    >
      {/* Grille de fond */}
      <svg
        className="absolute inset-0 w-full h-full opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(0deg, transparent 24%, rgba(255,255,255,.05) 25%, rgba(255,255,255,.05) 26%, transparent 27%, transparent 74%, rgba(255,255,255,.05) 75%, rgba(255,255,255,.05) 76%, transparent 77%, transparent),
            linear-gradient(90deg, transparent 24%, rgba(255,255,255,.05) 25%, rgba(255,255,255,.05) 26%, transparent 27%, transparent 74%, rgba(255,255,255,.05) 75%, rgba(255,255,255,.05) 76%, transparent 77%, transparent)
          `,
          backgroundSize: `${SQUARE_SIZE}px ${SQUARE_SIZE}px`,
        }}
      />

      {/* Carrés de la grille */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{
          width: GRID_SIZE * SQUARE_SIZE,
          height: GRID_SIZE * SQUARE_SIZE,
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%)',
        }}
      >
        {gridSquares.map((square) => {
          const isCenter = square.x === centerX && square.y === centerY;
          const stateColor = getStateColor(square.state, square.category);
          const stateOpacity = getStateOpacity(square.state);

          return (
            <motion.div
              key={square.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: (square.x + square.y) * 0.02 }}
              className={`absolute transition-all duration-300 ${
                isCenter ? 'z-50' : 'z-10'
              }`}
              style={{
                left: square.x * SQUARE_SIZE,
                top: square.y * SQUARE_SIZE,
                width: SQUARE_SIZE,
                height: SQUARE_SIZE,
              }}
            >
              {isCenter ? (
                // Point Zéro - Croix rouge au centre
                <motion.div
                  animate={{
                    scale: isAnalyzing ? [1, 1.1, 1] : 1,
                    opacity: isAnalyzing ? [0.8, 1, 0.8] : 1,
                  }}
                  transition={{ duration: 2, repeat: isAnalyzing ? Infinity : 0 }}
                  className="w-full h-full flex items-center justify-center"
                >
                  <div className="relative w-full h-full">
                    {/* Croix rouge */}
                    <svg
                      className="w-full h-full"
                      viewBox="0 0 60 60"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      {/* Ligne horizontale */}
                      <line
                        x1="10"
                        y1="30"
                        x2="50"
                        y2="30"
                        stroke="#EF4444"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                      {/* Ligne verticale */}
                      <line
                        x1="30"
                        y1="10"
                        x2="30"
                        y2="50"
                        stroke="#EF4444"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                      {/* Cercle autour */}
                      <circle
                        cx="30"
                        cy="30"
                        r="25"
                        fill="none"
                        stroke="#EF4444"
                        strokeWidth="2"
                        opacity="0.5"
                      />
                    </svg>

                    {/* Halo pulsant */}
                    {isAnalyzing && (
                      <motion.div
                        animate={{ scale: [1, 1.3], opacity: [1, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                        className="absolute inset-0 border-2 border-red-500 rounded"
                      />
                    )}
                  </div>
                </motion.div>
              ) : (
                // Carrés normaux
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="w-full h-full rounded border border-slate-600/30 cursor-pointer overflow-hidden group"
                  style={{
                    backgroundColor: stateColor,
                    opacity: stateOpacity,
                  }}
                >
                  {/* Contenu du carré */}
                  <div className="w-full h-full flex flex-col items-center justify-center p-1">
                    {/* Symbole selon l'état */}
                    {square.state === 'detected' && (
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                        className="w-2 h-2 bg-yellow-300 rounded-full"
                      />
                    )}
                    {square.state === 'ready' && (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="w-3 h-3 border-2 border-white rounded-full"
                      />
                    )}
                    {square.state === 'validated' && (
                      <div className="text-white text-lg">✓</div>
                    )}
                    {square.hasAlert && (
                      <div className="text-white text-xs font-bold">!</div>
                    )}

                    {/* Label */}
                    {square.label && (
                      <p className="text-xs text-white font-semibold mt-1 text-center line-clamp-2">
                        {square.label}
                      </p>
                    )}
                  </div>

                  {/* Halo au survol */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 border-2 border-white/50 rounded" />
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Zone de dépôt - Overlay au centre */}
      <AnimatePresence>
        {dragActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-primary/20 backdrop-blur-sm flex items-center justify-center z-40"
          >
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-center"
            >
              <Upload className="w-16 h-16 text-primary mx-auto mb-4" />
              <p className="text-xl font-semibold text-white">Déposez votre vrac ici</p>
              <p className="text-sm text-slate-300 mt-2">
                Déroulé, horaires, documents, messages...
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Indicateur d'analyse */}
      {isAnalyzing && (
        <motion.div
          className="absolute bottom-8 left-8 flex items-center gap-3 bg-slate-800/80 backdrop-blur px-4 py-3 rounded-lg border border-primary/30"
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Zap className="w-5 h-5 text-primary animate-pulse" />
          <span className="text-sm font-medium text-white">Analyse en cours...</span>
        </motion.div>
      )}

      {/* Instructions */}
      {squares.length === 0 && !isAnalyzing && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Point Zéro</h2>
            <p className="text-lg text-slate-300 mb-8">
              Déposez votre vrac au centre
            </p>
            <p className="text-sm text-slate-400">
              Déroulé • Horaires • Documents • Messages • Captures
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
