import React, { useState } from 'react';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { Link } from "wouter"; // Import Link from wouter
import PointZeroDropZone from './PointZeroDropZone';
import MilestoneSelector, { Milestone } from './MilestoneSelector';
import SmartValidationSystem from './SmartValidationSystem';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'cockpit' | 'pointzero' | 'timeline' | 'validation'>('cockpit');
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone>('J-30');

  return (
    <div className="flex h-screen bg-background text-foreground font-[var(--font-inter)]">
      <ResizablePanelGroup direction="horizontal">
        {/* Left Sidebar - Palette de filtres cognitifs */}
        <ResizablePanel defaultSize={20} minSize={15} maxSize={25} className="neumorphic-card p-4 rounded-none border-r border-border">
          <div className="flex flex-col h-full">
            <h1 className="text-2xl font-bold mb-6 text-primary">LinkEvent</h1>
            <nav className="flex-grow">
              {/* Navigation principale */}
              <ul className="space-y-2 mb-8">
                <li><Link href="/" className="block p-2 rounded-md hover:bg-muted transition-colors">Tableau de bord</Link></li>
                <li><Link href="#" className="block p-2 rounded-md hover:bg-muted transition-colors">Tâches</Link></li>
                <li><Link href="#" className="block p-2 rounded-md hover:bg-muted transition-colors">Prestataires</Link></li>
                <li><Link href="#" className="block p-2 rounded-md hover:bg-muted transition-colors">Budget</Link></li>
                <li><Link href="#" className="block p-2 rounded-md hover:bg-muted transition-colors">Invités</Link></li>
                <li><Link href="#" className="block p-2 rounded-md hover:bg-muted transition-colors">Documents</Link></li>
                <li><Link href="/technical-dossier" className="block p-2 rounded-md hover:bg-muted transition-colors">Dossier Technique</Link></li> {/* Added link to TechnicalDossier */}
              </ul>
              {/* Catégories / Palette de filtres */}
              <h2 className="text-lg font-semibold mb-4">CATÉGORIES</h2>
              <div className="space-y-2">
                {/* Exemple de catégories - à dynamiser plus tard */}
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-green-500 mr-3 shadow-inner"></div>
                  <span>Préparatifs</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-blue-500 mr-3 shadow-inner"></div>
                  <span>Cérémonie</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-yellow-500 mr-3 shadow-inner"></div>
                  <span>Cocktail</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-purple-500 mr-3 shadow-inner"></div>
                  <span>Réception</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-red-500 mr-3 shadow-inner"></div>
                  <span>Soirée</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-teal-500 mr-3 shadow-inner"></div>
                  <span>Hébergement</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-orange-500 mr-3 shadow-inner"></div>
                  <span>Transport</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-gray-500 mr-3 shadow-inner"></div>
                  <span>Logistique</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-pink-500 mr-3 shadow-inner"></div>
                  <span>Technique</span>
                </div>
                <div className="flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
                  <div className="w-4 h-4 rounded-full bg-lime-500 mr-3 shadow-inner"></div>
                  <span>Communication</span>
                </div>
              </div>
            </nav>
            {/* User Profile / Footer */}
            <div className="mt-auto flex items-center p-2 rounded-md hover:bg-muted cursor-pointer transition-colors">
              <div className="w-8 h-8 rounded-full bg-gray-700 mr-3 shadow-inner"></div>
              <span>Martin Dupont</span>
            </div>
          </div>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Main Content Area - Grille centrale */}
        <ResizablePanel defaultSize={60} minSize={40} className="flex flex-col">
          <header className="flex items-center justify-between p-4 border-b border-border bg-card">
            <h2 className="text-xl font-semibold">Planning</h2>
            {/* Placeholder for controls like date picker, zoom, etc. */}
            <div className="flex items-center space-x-2">
              <span className="text-muted-foreground">Aujourd'hui</span>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">&lt;</button>
              <span className="font-medium">23 - 25 août 2025</span>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">&gt;</button>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">Jour</button>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">3 jours</button>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">Semaine</button>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">+</button>
              <button className="neumorphic-button p-2 rounded-md hover:bg-muted transition-colors">Ajouter un événement</button>
            </div>
          </header>
          {/* Onglets de navigation */}
          <div className="flex gap-4 px-4 border-b border-border bg-card">
            {[
              { id: 'cockpit', label: 'Cockpit' },
              { id: 'pointzero', label: 'Point Zéro' },
              { id: 'timeline', label: 'Timeline' },
              { id: 'validation', label: 'Validation' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <main className="flex-grow p-4 overflow-auto bg-background">
            {activeTab === 'cockpit' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Cockpit Principal</h3>
                {/* Maturation Grid Demo */}
                <div className="mb-6">
                  <h4 className="text-md font-semibold mb-4">Point Zéro - Maturation Progressive</h4>
                  <div className="grid grid-cols-8 gap-2 mb-4">
                    {[...Array(24)].map((_, i) => {
                      const states: Array<'empty' | 'detected' | 'illuminated' | 'ready' | 'validated'> = [
                        'empty', 'empty', 'detected', 'detected', 'illuminated', 'illuminated', 'ready', 'ready',
                        'ready', 'validated', 'validated', 'validated', 'empty', 'empty', 'detected', 'illuminated',
                        'illuminated', 'ready', 'ready', 'validated', 'validated', 'empty', 'detected', 'illuminated'
                      ];
                      const state = states[i];
                      const colors: Record<string, string> = {
                        empty: 'bg-gray-800',
                        detected: 'bg-gray-700',
                        illuminated: 'bg-yellow-500/50',
                        ready: 'bg-blue-500/50',
                        validated: 'bg-green-500/80',
                      };
                      return (
                        <div
                          key={i}
                          className={`w-12 h-12 rounded-md ${colors[state]} border border-border transition-all hover:scale-110 cursor-pointer`}
                          title={state}
                        />
                      );
                    })}
                  </div>
                  <p className="text-sm text-muted-foreground">Gris foncé: vide | Gris: détecté | Jaune: illuminé | Bleu: prêt | Vert: validé</p>
                </div>
                {children}
              </div>
            )}

            {activeTab === 'pointzero' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Point Zéro - Détection d'Informations</h3>
                <p className="text-sm text-muted-foreground">
                  Déposez vos fichiers, SMS, images et documents. Le système analysera et catégorisera automatiquement les informations.
                </p>
                <PointZeroDropZone />
              </div>
            )}

            {activeTab === 'timeline' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Orchestration Temporelle</h3>
                <MilestoneSelector
                  selectedMilestone={selectedMilestone}
                  onMilestoneChange={setSelectedMilestone}
                />
              </div>
            )}

            {activeTab === 'validation' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Validation Intelligente</h3>
                <p className="text-sm text-muted-foreground">
                  Le système détecte automatiquement quand une tâche a suffisamment d'informations pour être "prête" et propose des actions automatisées.
                </p>
                <SmartValidationSystem />
              </div>
            )}
          </main>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Right Sidebar - Panneau de détails */}
        <ResizablePanel defaultSize={20} minSize={15} maxSize={25} className="neumorphic-card p-4 rounded-none border-l border-border">
          <div className="flex flex-col h-full">
            <h2 className="text-xl font-semibold mb-6">Détails de l'événement</h2>
            {/* Placeholder for event details */}
            <div className="space-y-4 text-muted-foreground">
              <p>Informations de l'événement sélectionné</p>
              <p>Responsables</p>
              <p>Ressources</p>
              <p>Documents</p>
              <p>Notes</p>
              <p>Tâches</p>
              <p>Connexions</p>
              <p>Conflits éventuels</p>
            </div>
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
};

export default Layout;
