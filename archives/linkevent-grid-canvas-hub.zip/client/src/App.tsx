import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Layout from "@/components/Layout";
import Home from "./pages/Home";
import TechnicalDossier from "./pages/TechnicalDossier";
import Landing from "./pages/Landing";
import Cockpit from "./pages/Cockpit";
import CockpitUnified from './pages/CockpitUnified';
import CockpitVisualization from './pages/CockpitVisualization';
import PointZero from './pages/PointZero';
import AdminGrid from "./pages/AdminGrid";
import DimensionGrid from './pages/DimensionGrid';

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      {/* Routes without Layout */}
      <Route path={"/"} component={Landing} />
      <Route path={"/landing"} component={Landing} />
      
      {/* Routes with Layout */}
      <Route path="/cockpit" component={CockpitUnified} />
      <Route path="/point-zero" component={PointZero} />
      <Route path="/visualization" component={CockpitVisualization} />
      <Route path={"/admin/grid"} component={DimensionGrid} />
      <Route path={"/admin/grid-legacy"} component={AdminGrid} />
      <Route path={"/home"} component={() => <Layout><Home /></Layout>} />
      <Route path={"/technical-dossier"} component={() => <Layout><TechnicalDossier /></Layout>} />
      
      {/* 404 */}
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
