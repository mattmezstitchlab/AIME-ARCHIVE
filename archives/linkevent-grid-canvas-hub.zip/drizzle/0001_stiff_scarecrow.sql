CREATE TABLE `aiAnalysis` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fileId` int NOT NULL,
	`eventId` int NOT NULL,
	`extractedData` text,
	`detectedIssues` text,
	`suggestedQuestions` text,
	`confidence` varchar(10),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiAnalysis_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dayJOrchestration` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`sequenceNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`scheduledTime` timestamp NOT NULL,
	`duration` int,
	`actors` text,
	`dependencies` text,
	`status` enum('pending','in_progress','completed','delayed','cancelled') NOT NULL DEFAULT 'pending',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dayJOrchestration_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`eventDate` timestamp NOT NULL,
	`location` varchar(255),
	`status` enum('planning','confirmed','in_progress','completed') NOT NULL DEFAULT 'planning',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`recipientId` int NOT NULL,
	`taskId` int,
	`type` enum('info','reminder','action_required','confirmation','update') NOT NULL,
	`subject` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`scheduledAt` timestamp,
	`sentAt` timestamp,
	`status` enum('draft','scheduled','sent','failed','cancelled') NOT NULL DEFAULT 'draft',
	`channel` enum('email','sms','in_app') NOT NULL DEFAULT 'email',
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `participants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`role` enum('bride','groom','vendor','guest','team','coordinator') NOT NULL,
	`category` varchar(100),
	`status` enum('pending','confirmed','notified','completed') NOT NULL DEFAULT 'pending',
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `participants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100),
	`startTime` timestamp,
	`endTime` timestamp,
	`assignedTo` int,
	`status` enum('pending','in_progress','completed','blocked') NOT NULL DEFAULT 'pending',
	`priority` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`dependencies` text,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `uploadedFiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileType` varchar(50),
	`fileUrl` varchar(500),
	`fileSize` int,
	`maturationState` enum('empty','detected','illuminated','ready','validated') NOT NULL DEFAULT 'detected',
	`analysisResult` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `uploadedFiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `validations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`fileId` int,
	`analysisId` int,
	`validationType` enum('analysis_review','question_answer','notification_preview','task_confirmation') NOT NULL,
	`status` enum('pending','approved','rejected','modified') NOT NULL DEFAULT 'pending',
	`brideResponse` text,
	`modifications` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `validations_id` PRIMARY KEY(`id`)
);
