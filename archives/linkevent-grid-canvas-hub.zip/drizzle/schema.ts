import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, tinyint } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Événements (mariages, événements complexes)
 */
export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  eventDate: timestamp("eventDate").notNull(),
  location: varchar("location", { length: 255 }),
  status: mysqlEnum("status", ["planning", "confirmed", "in_progress", "completed"]).default("planning").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;

/**
 * Participants (mariés, prestataires, invités, équipe)
 */
export const participants = mysqlTable("participants", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  role: mysqlEnum("role", ["bride", "groom", "vendor", "guest", "team", "coordinator"]).notNull(),
  category: varchar("category", { length: 100 }),
  status: mysqlEnum("status", ["pending", "confirmed", "notified", "completed"]).default("pending").notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Participant = typeof participants.$inferSelect;
export type InsertParticipant = typeof participants.$inferInsert;

/**
 * Tâches et étapes de l'événement
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  startTime: timestamp("startTime"),
  endTime: timestamp("endTime"),
  assignedTo: int("assignedTo"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "blocked"]).default("pending").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  dependencies: text("dependencies"),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Fichiers uploadés et analysés
 */
export const uploadedFiles = mysqlTable("uploadedFiles", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileType: varchar("fileType", { length: 50 }),
  fileUrl: varchar("fileUrl", { length: 500 }),
  fileSize: int("fileSize"),
  maturationState: mysqlEnum("maturationState", ["empty", "detected", "illuminated", "ready", "validated"]).default("detected").notNull(),
  analysisResult: text("analysisResult"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UploadedFile = typeof uploadedFiles.$inferSelect;
export type InsertUploadedFile = typeof uploadedFiles.$inferInsert;

/**
 * Analyse IA des fichiers
 */
export const aiAnalysis = mysqlTable("aiAnalysis", {
  id: int("id").autoincrement().primaryKey(),
  fileId: int("fileId").notNull(),
  eventId: int("eventId").notNull(),
  extractedData: text("extractedData"),
  detectedIssues: text("detectedIssues"),
  suggestedQuestions: text("suggestedQuestions"),
  confidence: varchar("confidence", { length: 10 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AIAnalysis = typeof aiAnalysis.$inferSelect;
export type InsertAIAnalysis = typeof aiAnalysis.$inferInsert;

/**
 * Notifications programmées
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  recipientId: int("recipientId").notNull(),
  taskId: int("taskId"),
  type: mysqlEnum("type", ["info", "reminder", "action_required", "confirmation", "update"]).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  scheduledAt: timestamp("scheduledAt"),
  sentAt: timestamp("sentAt"),
  status: mysqlEnum("status", ["draft", "scheduled", "sent", "failed", "cancelled"]).default("draft").notNull(),
  channel: mysqlEnum("channel", ["email", "sms", "in_app"]).default("email").notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Validations et confirmations
 */
export const validations = mysqlTable("validations", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  fileId: int("fileId"),
  analysisId: int("analysisId"),
  validationType: mysqlEnum("validationType", ["analysis_review", "question_answer", "notification_preview", "task_confirmation"]).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "modified"]).default("pending").notNull(),
  brideResponse: text("brideResponse"),
  modifications: text("modifications"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Validation = typeof validations.$inferSelect;
export type InsertValidation = typeof validations.$inferInsert;

/**
 * Orchestration du Jour J
 */
export const dayJOrchestration = mysqlTable("dayJOrchestration", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  sequenceNumber: int("sequenceNumber").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  scheduledTime: timestamp("scheduledTime").notNull(),
  duration: int("duration"),
  actors: text("actors"),
  dependencies: text("dependencies"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "delayed", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DayJOrchestration = typeof dayJOrchestration.$inferSelect;
export type InsertDayJOrchestration = typeof dayJOrchestration.$inferInsert;

/**
 * Questions générées par l'IA
 */
export const weddingQuestions = mysqlTable("weddingQuestions", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  question: text("question").notNull(),
  importance: mysqlEnum("importance", ["critical", "high", "medium", "low"]).default("medium").notNull(),
  relatedTo: varchar("relatedTo", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WeddingQuestion = typeof weddingQuestions.$inferSelect;
export type InsertWeddingQuestion = typeof weddingQuestions.$inferInsert;

/**
 * Réponses aux questions
 */
export const weddingAnswers = mysqlTable("weddingAnswers", {
  id: int("id").autoincrement().primaryKey(),
  questionId: int("questionId").notNull(),
  eventId: int("eventId").notNull(),
  answer: text("answer").notNull(),
  answeredBy: int("answeredBy").notNull(),
  answeredAt: timestamp("answeredAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WeddingAnswer = typeof weddingAnswers.$inferSelect;
export type InsertWeddingAnswer = typeof weddingAnswers.$inferInsert;

/**
 * Catégories dynamiques pour la grille interne
 */
export const contentCategories = mysqlTable('contentCategories', {
  id: int('id').autoincrement().primaryKey(),
  eventId: int('eventId').notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  parentCategoryId: int('parentCategoryId'), // Pour les sous-catégories
  icon: varchar('icon', { length: 50 }),
  color: varchar('color', { length: 7 }), // Hex color
  order: int('order').default(0),
  isSystem: tinyint('isSystem').default(0), // Catégories prédéfinies (0=false, 1=true)
  // Grille Universelle : dimension fondamentale
  dimension: varchar('dimension', { length: 20 }), // DimensionId : TEMPS, ESPACE, PERSONNES...
  subdimension: varchar('subdimension', { length: 100 }), // Sous-dimension
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export type ContentCategory = typeof contentCategories.$inferSelect;
export type InsertContentCategory = typeof contentCategories.$inferInsert;

/**
 * Éléments classés dans la grille
 */
export const classifiedItems = mysqlTable('classifiedItems', {
  id: int('id').autoincrement().primaryKey(),
  eventId: int('eventId').notNull(),
  categoryId: int('categoryId').notNull(),
  content: text('content').notNull(),
  contentType: mysqlEnum('contentType', ['text', 'image', 'document', 'date', 'name', 'link', 'unknown']).notNull(),
  sourceFileId: int('sourceFileId'), // Référence au fichier source
  status: mysqlEnum('status', ['classified', 'pending_clarification', 'validated', 'linked']).default('classified').notNull(),
  confidence: int('confidence').default(100), // Pourcentage de confiance (0-100)
  metadata: text('metadata'), // JSON avec infos supplémentaires
  // Grille Universelle
  dimensions: text('dimensions'), // JSON : liste des DimensionId assignées
  primaryDimension: varchar('primaryDimension', { length: 20 }), // Dimension principale
  maturationState: varchar('maturationState', { length: 20 }).default('detected'), // État de maturation
  projections: text('projections'), // JSON : actions possibles détectées
  classificationReason: text('classificationReason'), // Pourquoi classé ici
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export type ClassifiedItem = typeof classifiedItems.$inferSelect;
export type InsertClassifiedItem = typeof classifiedItems.$inferInsert;

/**
 * Liens entre éléments
 */
export const itemLinks = mysqlTable('itemLinks', {
  id: int('id').autoincrement().primaryKey(),
  eventId: int('eventId').notNull(),
  sourceItemId: int('sourceItemId').notNull(),
  targetItemId: int('targetItemId').notNull(),
  // 10 types sémantiques du blueprint Grille Universelle
  linkType: mysqlEnum('linkType', ['related', 'depends_on', 'references', 'contradicts', 'completes', 'reminds', 'inherits', 'influences', 'prepares', 'triggers', 'binds']).notNull(),
  strength: int('strength').default(50), // Force du lien (0-100)
  reason: text('reason'), // Raison du lien
  createdAt: timestamp('createdAt').defaultNow().notNull(),
});

export type ItemLink = typeof itemLinks.$inferSelect;
export type InsertItemLink = typeof itemLinks.$inferInsert;

/**
 * Zones grises - éléments à clarifier
 */
export const unclarifiedItems = mysqlTable('unclarifiedItems', {
  id: int('id').autoincrement().primaryKey(),
  eventId: int('eventId').notNull(),
  content: text('content').notNull(),
  reason: text('reason').notNull(), // Pourquoi c'est flou
  suggestedCategories: text('suggestedCategories'), // JSON array de suggestions
  status: mysqlEnum('status', ['pending', 'clarified', 'discarded']).default('pending').notNull(),
  clarifiedBy: int('clarifiedBy'), // ID du user qui a clarifié
  clarification: text('clarification'), // La clarification fournie
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export type UnclarifiedItem = typeof unclarifiedItems.$inferSelect;
export type InsertUnclarifiedItem = typeof unclarifiedItems.$inferInsert;