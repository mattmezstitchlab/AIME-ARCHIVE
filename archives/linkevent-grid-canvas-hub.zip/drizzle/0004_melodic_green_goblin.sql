ALTER TABLE `itemLinks` MODIFY COLUMN `linkType` enum('related','depends_on','references','contradicts','completes','reminds','inherits','influences','prepares','triggers','binds') NOT NULL;--> statement-breakpoint
ALTER TABLE `classifiedItems` ADD `dimensions` text;--> statement-breakpoint
ALTER TABLE `classifiedItems` ADD `primaryDimension` varchar(20);--> statement-breakpoint
ALTER TABLE `classifiedItems` ADD `maturationState` varchar(20) DEFAULT 'detected';--> statement-breakpoint
ALTER TABLE `classifiedItems` ADD `projections` text;--> statement-breakpoint
ALTER TABLE `classifiedItems` ADD `classificationReason` text;--> statement-breakpoint
ALTER TABLE `contentCategories` ADD `dimension` varchar(20);--> statement-breakpoint
ALTER TABLE `contentCategories` ADD `subdimension` varchar(100);