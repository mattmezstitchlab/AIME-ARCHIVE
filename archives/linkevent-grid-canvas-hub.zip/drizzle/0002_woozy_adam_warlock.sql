CREATE TABLE `weddingAnswers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`questionId` int NOT NULL,
	`eventId` int NOT NULL,
	`answer` text NOT NULL,
	`answeredBy` int NOT NULL,
	`answeredAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `weddingAnswers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weddingQuestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`question` text NOT NULL,
	`importance` enum('critical','high','medium','low') NOT NULL DEFAULT 'medium',
	`relatedTo` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `weddingQuestions_id` PRIMARY KEY(`id`)
);
