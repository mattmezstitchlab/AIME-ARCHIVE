CREATE TABLE `classifiedItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`categoryId` int NOT NULL,
	`content` text NOT NULL,
	`contentType` enum('text','image','document','date','name','link','unknown') NOT NULL,
	`sourceFileId` int,
	`status` enum('classified','pending_clarification','validated','linked') NOT NULL DEFAULT 'classified',
	`confidence` int DEFAULT 100,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `classifiedItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contentCategories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`parentCategoryId` int,
	`icon` varchar(50),
	`color` varchar(7),
	`order` int DEFAULT 0,
	`isSystem` tinyint DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contentCategories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `itemLinks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`sourceItemId` int NOT NULL,
	`targetItemId` int NOT NULL,
	`linkType` enum('related','depends_on','references','contradicts','completes') NOT NULL,
	`strength` int DEFAULT 50,
	`reason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `itemLinks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `unclarifiedItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`content` text NOT NULL,
	`reason` text NOT NULL,
	`suggestedCategories` text,
	`status` enum('pending','clarified','discarded') NOT NULL DEFAULT 'pending',
	`clarifiedBy` int,
	`clarification` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `unclarifiedItems_id` PRIMARY KEY(`id`)
);
