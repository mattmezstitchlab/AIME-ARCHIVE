import { z } from 'zod';
import { protectedProcedure, publicProcedure, router } from '../_core/trpc';
import { invokeLLM } from '../_core/llm';
import { getDb } from '../db';
import { events, weddingQuestions } from '../../drizzle/schema';

const analyzeWeddingVracSchema = z.object({
  text: z.string().optional(),
  fileContents: z.array(z.object({
    filename: z.string(),
    content: z.string(),
  })).optional(),
});

export const weddingAnalysisRouter = router({
  analyzeVrac: protectedProcedure
    .input(analyzeWeddingVracSchema)
    .mutation(async ({ input, ctx }) => {
      const { text, fileContents } = input;

      // Préparer le contenu pour l'IA
      let combinedContent = '';
      if (text) {
        combinedContent += `TEXTE FOURNI:\n${text}\n\n`;
      }
      if (fileContents && fileContents.length > 0) {
        combinedContent += `FICHIERS UPLOADÉS:\n`;
        fileContents.forEach((file) => {
          combinedContent += `\n--- ${file.filename} ---\n${file.content}\n`;
        });
      }

      // Appel à l'IA pour analyser le vrac
      const systemPrompt = `Tu es un expert en planification de mariages et d'événements. 
Analyse le contenu fourni (déroulé, notes, messages, documents) et extrais les informations structurées.

Réponds UNIQUEMENT en JSON valide, sans texte supplémentaire. Voici le format attendu:

{
  "understood": {
    "times": [{"label": "Cérémonie", "time": "14:00", "location": "Mairie"}],
    "keyMoments": ["Échange des vœux", "Première danse"],
    "people": [{"name": "Sophie", "role": "Mariée", "contact": "06..."}],
    "vendors": [{"name": "Traiteur Delice", "category": "Catering", "contact": "06...", "confirmed": true}],
    "locations": ["Mairie", "Salle de réception"],
    "music": ["DJ Marc", "Saxophoniste"],
    "objects": ["Gâteau", "Fleurs"],
    "actions": ["Confirmer les invités", "Envoyer le déroulé"],
    "dependencies": [{"from": "Traiteur", "to": "Nombre invités", "reason": "Le traiteur a besoin du nombre final"}]
  },
  "missing": {
    "unidentifiedPeople": [],
    "missingRoles": ["Coordinateur jour J"],
    "missingVendors": [],
    "unclearTimes": ["Heure de fin de soirée"],
    "unspecifiedLocations": [],
    "actionsWithoutOwner": ["Préparer les discours"],
    "missingContacts": ["Coordinateur"],
    "requiredValidations": ["Nombre final d'invités", "Menu final"]
  },
  "suggestedQuestions": [
    {"question": "Qui doit recevoir le déroulé de la cérémonie?", "importance": "critical", "relatedTo": "Cérémonie"},
    {"question": "Le traiteur doit-il être notifié du nombre d'invités?", "importance": "high", "relatedTo": "Traiteur"}
  ],
  "confidence": 0.85
}`;

      try {
        const response = await invokeLLM({
          model: 'gpt-4o-mini', // Utiliser un modèle rapide
          messages: [
            {
              role: 'system',
              content: systemPrompt,
            },
            {
              role: 'user',
              content: combinedContent || 'Pas de contenu fourni',
            },
          ],
        });

        // Extraire le contenu JSON de la réponse
        const responseContent = response.choices[0]?.message?.content;
        const responseText = typeof responseContent === 'string' ? responseContent : '';
        
        // Chercher le JSON dans la réponse
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
          throw new Error('Impossible de parser la réponse IA');
        }

        const analysisData = JSON.parse(jsonMatch?.[0] || '{}');

        // Créer un événement en base de données
        const db = await getDb();
        if (!db) throw new Error('Database not available');

        // Créer l'événement
        const eventResult = await db.insert(events).values({
          userId: ctx.user.id,
          title: 'Mariage - ' + new Date().toLocaleDateString('fr-FR'),
          description: 'Événement créé depuis l\'analyse du vrac',
          eventDate: new Date(),
          status: 'planning',
        });

        const eventId = (eventResult as any).insertId || 1;

        // Créer les questions en base de données
        if (analysisData.suggestedQuestions && Array.isArray(analysisData.suggestedQuestions)) {
          for (const q of analysisData.suggestedQuestions) {
            await db.insert(weddingQuestions).values({
              eventId: eventId,
              question: q.question,
              importance: q.importance || 'medium',
              relatedTo: q.relatedTo || '',
            });
          }
        }

        return {
          success: true,
          eventId: eventId,
          analysis: analysisData,
          rawResponse: responseText || '',
        };
      } catch (error) {
        console.error('Erreur lors de l\'analyse IA:', error);
        throw new Error(`Erreur lors de l'analyse: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
      }
    }),

  // Procédure pour extraire le texte des fichiers uploadés
  extractFileContent: publicProcedure
    .input(z.object({
      fileKey: z.string(),
      mimeType: z.string(),
    }))
    .mutation(async ({ input }) => {
      // Cette procédure serait appelée après un upload S3
      // Pour l'instant, retourner un placeholder
      return {
        success: true,
        content: 'Contenu du fichier extrait',
      };
    }),
});
