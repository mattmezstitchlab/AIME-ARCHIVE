import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { getDb } from '../db';
import { notifications, participants } from '../../drizzle/schema';
import { eq, and } from 'drizzle-orm';
import { notifyOwner } from '../_core/notification';

export const notificationsRouter = router({
  // Envoyer les notifications confirmées
  sendNotifications: protectedProcedure
    .input(
      z.object({
        eventId: z.number(),
        notifications: z.array(
          z.object({
            recipientId: z.number(),
            subject: z.string(),
            message: z.string(),
            channel: z.enum(['email', 'sms', 'in_app']),
            taskId: z.number().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      try {
        const sentNotifications = [];

        // Envoyer chaque notification
        for (const notif of input.notifications) {
          // Récupérer les informations du destinataire
          const recipient = await db
            .select()
            .from(participants)
            .where(eq(participants.id, notif.recipientId))
            .limit(1);

          if (!recipient || recipient.length === 0) {
            console.warn(`Recipient ${notif.recipientId} not found`);
            continue;
          }

          const recipientData = recipient[0];

          // Sauvegarder la notification en base de données
          const savedNotif = await db.insert(notifications).values({
            eventId: input.eventId,
            recipientId: notif.recipientId,
            taskId: notif.taskId,
            type: 'info',
            subject: notif.subject,
            message: notif.message,
            channel: notif.channel,
            status: 'sent',
            sentAt: new Date(),
          });

          // Simuler l'envoi (en production, intégrer avec un service d'email/SMS)
          const recipient_contact = notif.channel === 'email' ? recipientData.email : (notif.channel === 'sms' ? recipientData.phone : 'in-app');
          console.log(`[NOTIFICATION] Simulé - ${notif.channel.toUpperCase()} à ${recipientData.name} (${recipient_contact}):`, {
            subject: notif.subject,
            message: notif.message,
          });

          // Notifier le propriétaire du projet
          await notifyOwner({
            title: `Notification envoyée à ${recipientData.name}`,
            content: `${notif.subject}\n\n${notif.message.substring(0, 100)}...`,
          });

          sentNotifications.push({
            recipientId: notif.recipientId,
            recipientName: recipientData.name,
            channel: notif.channel,
            contact: notif.channel === 'email' ? recipientData.email : (notif.channel === 'sms' ? recipientData.phone : 'in-app'),
            status: 'sent',
            timestamp: new Date().toISOString(),
          });
        }

        return {
          success: true,
          totalSent: sentNotifications.length,
          notifications: sentNotifications,
          message: `${sentNotifications.length} notification(s) envoyée(s) avec succès`,
        };
      } catch (error) {
        console.error('Error sending notifications:', error);
        throw new Error('Failed to send notifications');
      }
    }),

  // Récupérer l'historique des notifications
  getNotificationHistory: protectedProcedure
    .input(z.object({ eventId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      try {
        const notifHistory = await db
          .select()
          .from(notifications)
          .where(eq(notifications.eventId, input.eventId));

        return notifHistory;
      } catch (error) {
        console.error('Error fetching notification history:', error);
        throw new Error('Failed to fetch notification history');
      }
    }),

  // Envoyer un rappel à un prestataire
  sendReminder: protectedProcedure
    .input(
      z.object({
        eventId: z.number(),
        recipientId: z.number(),
        message: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      try {
        // Récupérer les informations du destinataire
        const recipient = await db
          .select()
          .from(participants)
          .where(eq(participants.id, input.recipientId))
          .limit(1);

        if (!recipient || recipient.length === 0) {
          throw new Error('Recipient not found');
        }

        const recipientData = recipient[0];

        // Sauvegarder le rappel
        await db.insert(notifications).values({
          eventId: input.eventId,
          recipientId: input.recipientId,
          type: 'reminder',
          subject: `Rappel pour ${recipientData.name}`,
          message: input.message,
          channel: recipientData.email ? 'email' : 'sms',
          status: 'sent',
          sentAt: new Date(),
        });

        // Notifier le propriétaire
        await notifyOwner({
          title: `Rappel envoyé à ${recipientData.name}`,
          content: input.message.substring(0, 100),
        });

        return {
          success: true,
          message: `Rappel envoyé à ${recipientData.name}`,
        };
      } catch (error) {
        console.error('Error sending reminder:', error);
        throw new Error('Failed to send reminder');
      }
    }),
});
