/**
 * Classification Router — Moteur Universel Grille LinkEvent
 *
 * Point Zéro absorbe.
 * La Grille Universelle classe.
 * Les nœuds mûrissent.
 * Les projections exécutent.
 */

import { z } from 'zod';
import { router, protectedProcedure, publicProcedure } from '../_core/trpc';
import { getDb } from '../db';
import { contentCategories, classifiedItems, itemLinks, unclarifiedItems } from '../../drizzle/schema';
import { eq, and } from 'drizzle-orm';
import { invokeLLM } from '../_core/llm';
import {
  UNIVERSAL_DIMENSIONS,
  DIMENSIONS_BY_ID,
  CLASSIFICATION_SYSTEM_PROMPT,
  type DimensionId,
  type MaturationState,
  type LinkSemanticType,
} from '../../shared/universalDimensions';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getDimensionColor(dimensionId: string): string {
  const dim = DIMENSIONS_BY_ID[dimensionId as DimensionId];
  return dim?.color ?? '#6B7280';
}

function getDimensionIcon(dimensionId: string): string {
  const dim = DIMENSIONS_BY_ID[dimensionId as DimensionId];
  return dim?.icon ?? 'Box';
}

function buildClassificationPrompt(content: string): string {
  return `${CLASSIFICATION_SYSTEM_PROMPT}

Contenu à classifier :
"""
${content}
"""

Réponds en JSON valide avec cette structure exacte :
{
  "dimensions": [
    {
      "id": "TEMPS",
      "name": "Temps",
      "subdimension": "Date & Heure",
      "confidence": 95,
      "reason": "Contient une date précise"
    }
  ],
  "primaryDimension": "TEMPS",
  "mainCategory": "Horaires de la cérémonie",
  "subcategories": ["Cérémonie", "Mairie"],
  "isClear": true,
  "clarificationReason": null,
  "maturationState": "illuminated",
  "suggestedLinks": [
    {
      "type": "prepares",
      "description": "Cet horaire prépare l'organisation du transport",
      "targetHint": "Transport"
    }
  ],
  "projections": [
    {
      "action": "Confirmer la disponibilité de la salle",
      "dimension": "VALIDATION",
      "priority": "high"
    }
  ],
  "confidence": 92,
  "extractedData": {
    "date": "15 septembre 2026",
    "time": "14:00"
  },
  "suggestedQuestions": [
    "Quelle est la durée prévue de la cérémonie ?"
  ]
}`;
}

// ─── Router ──────────────────────────────────────────────────────────────────

export const classificationRouter = router({
  /**
   * Classifier un contenu selon les 12 dimensions universelles
   */
  classifyContent: publicProcedure
    .input(z.object({
      content: z.string().min(1).max(50000),
      eventId: z.number().optional(),
      sourceType: z.enum(['text', 'image', 'document', 'date', 'name', 'link', 'unknown']).default('text'),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      const eventId = input.eventId ?? 1;

      // 1. Appel IA avec le prompt universel
      let aiResponse: {
        dimensions: Array<{ id: string; name: string; subdimension: string; confidence: number; reason: string }>;
        primaryDimension: string;
        mainCategory: string;
        subcategories: string[];
        isClear: boolean;
        clarificationReason?: string | null;
        maturationState: string;
        suggestedLinks: Array<{ type: string; description: string; targetHint: string }>;
        projections: Array<{ action: string; dimension: string; priority: string }>;
        confidence: number;
        extractedData: Record<string, unknown>;
        suggestedQuestions: string[];
      };

      try {
        const llmResult = await invokeLLM({
          messages: [
            {
              role: 'user',
              content: buildClassificationPrompt(input.content),
            },
          ],
        });

        const rawContent = llmResult.choices[0]?.message?.content ?? '{}';
        const jsonMatch = (typeof rawContent === 'string' ? rawContent : '{}').match(/\{[\s\S]*\}/);
        aiResponse = JSON.parse(jsonMatch?.[0] ?? '{}');

        // Valeurs par défaut si l'IA retourne un JSON incomplet
        if (!aiResponse.primaryDimension) aiResponse.primaryDimension = 'MEMOIRE';
        if (!aiResponse.mainCategory) aiResponse.mainCategory = 'Contenu non classifié';
        if (!aiResponse.dimensions) aiResponse.dimensions = [];
        if (!aiResponse.subcategories) aiResponse.subcategories = [];
        if (aiResponse.isClear === undefined) aiResponse.isClear = true;
        if (!aiResponse.maturationState) aiResponse.maturationState = 'illuminated';
        if (!aiResponse.suggestedLinks) aiResponse.suggestedLinks = [];
        if (!aiResponse.projections) aiResponse.projections = [];
        if (!aiResponse.confidence) aiResponse.confidence = 70;
        if (!aiResponse.extractedData) aiResponse.extractedData = {};
        if (!aiResponse.suggestedQuestions) aiResponse.suggestedQuestions = [];
      } catch {
        // Fallback si l'IA échoue
        aiResponse = {
          dimensions: [{ id: 'MEMOIRE', name: 'Mémoire', subdimension: 'Note', confidence: 50, reason: 'Classification par défaut' }],
          primaryDimension: 'MEMOIRE',
          mainCategory: 'Contenu non classifié',
          subcategories: [],
          isClear: false,
          clarificationReason: 'Impossible de classifier automatiquement',
          maturationState: 'ambiguous',
          suggestedLinks: [],
          projections: [],
          confidence: 30,
          extractedData: {},
          suggestedQuestions: ['Pouvez-vous préciser le type de ce contenu ?'],
        };
      }

      const primaryDim = aiResponse.primaryDimension as DimensionId;
      const dimColor = getDimensionColor(primaryDim);
      const dimIcon = getDimensionIcon(primaryDim);

      // 2. Créer ou récupérer la catégorie principale
      const existingCats = await db
        .select()
        .from(contentCategories)
        .where(and(
          eq(contentCategories.eventId, eventId),
          eq(contentCategories.name, aiResponse.mainCategory)
        ))
        .limit(1);

      const isNewCategory = existingCats.length === 0;
      let categoryId: number;

      if (existingCats.length > 0) {
        categoryId = existingCats[0].id;
      } else {
        const [inserted] = await db.insert(contentCategories).values({
          eventId,
          name: aiResponse.mainCategory,
          description: `Créé par le moteur universel — Dimension : ${primaryDim}`,
          icon: dimIcon,
          color: dimColor,
          isSystem: 0,
          dimension: primaryDim,
          subdimension: aiResponse.dimensions[0]?.subdimension ?? '',
        });
        categoryId = (inserted as { insertId: number }).insertId;
      }

      // 3. Créer les sous-catégories
      for (const subName of (aiResponse.subcategories ?? []).slice(0, 4)) {
        const existingSub = await db
          .select()
          .from(contentCategories)
          .where(and(
            eq(contentCategories.eventId, eventId),
            eq(contentCategories.name, subName)
          ))
          .limit(1);

        if (existingSub.length === 0) {
          await db.insert(contentCategories).values({
            eventId,
            name: subName,
            parentCategoryId: categoryId,
            icon: dimIcon,
            color: dimColor,
            isSystem: 0,
            dimension: primaryDim,
          });
        }
      }

      // 4. Insérer l'élément classifié
      const [itemResult] = await db.insert(classifiedItems).values({
        eventId,
        categoryId,
        content: input.content.slice(0, 2000),
        contentType: input.sourceType,
        status: aiResponse.isClear ? 'classified' : 'pending_clarification',
        confidence: aiResponse.confidence,
        dimensions: JSON.stringify((aiResponse.dimensions ?? []).map((d: { id: string }) => d.id)),
        primaryDimension: primaryDim,
        maturationState: aiResponse.maturationState,
        projections: JSON.stringify(aiResponse.projections ?? []),
        classificationReason: aiResponse.dimensions[0]?.reason ?? '',
        metadata: JSON.stringify(aiResponse.extractedData ?? {}),
      });
      const newItemId = (itemResult as { insertId: number }).insertId;

      // 5. Gérer les zones grises
      if (!aiResponse.isClear) {
        await db.insert(unclarifiedItems).values({
          eventId,
          content: input.content.slice(0, 1000),
          reason: aiResponse.clarificationReason ?? 'Contenu ambigu',
          suggestedCategories: JSON.stringify(aiResponse.subcategories ?? []),
          status: 'pending',
        });
      }

      // 6. Créer les liens avec éléments existants
      const existingItems = await db
        .select()
        .from(classifiedItems)
        .where(eq(classifiedItems.eventId, eventId));

      const linksCreated: Array<{ type: string; targetHint: string; strength: number }> = [];

      for (const suggestedLink of (aiResponse.suggestedLinks ?? []).slice(0, 5)) {
        const hint = suggestedLink.targetHint?.toLowerCase().split(' ')[0] ?? '';
        if (!hint) continue;

        const targetItem = existingItems.find(item =>
          item.id !== newItemId &&
          (
            item.content.toLowerCase().includes(hint) ||
            (item.classificationReason ?? '').toLowerCase().includes(hint)
          )
        );

        if (targetItem) {
          await db.insert(itemLinks).values({
            eventId,
            sourceItemId: newItemId,
            targetItemId: targetItem.id,
            linkType: (suggestedLink.type as LinkSemanticType) ?? 'related',
            strength: 75,
            reason: suggestedLink.description,
          });
          linksCreated.push({ type: suggestedLink.type, targetHint: suggestedLink.targetHint, strength: 75 });
        }
      }

      return {
        success: true,
        itemId: newItemId,
        categoryId,
        isNewCategory,
        primaryDimension: primaryDim,
        dimensionColor: dimColor,
        allDimensions: aiResponse.dimensions ?? [],
        mainCategory: aiResponse.mainCategory,
        subcategories: aiResponse.subcategories ?? [],
        isClear: aiResponse.isClear,
        clarificationReason: aiResponse.clarificationReason,
        maturationState: aiResponse.maturationState as MaturationState,
        confidence: aiResponse.confidence,
        projections: aiResponse.projections ?? [],
        linksCreated,
        suggestedQuestions: aiResponse.suggestedQuestions ?? [],
        extractedData: aiResponse.extractedData ?? {},
        classificationReason: aiResponse.dimensions[0]?.reason ?? '',
      };
    }),

  /**
   * Récupérer la grille interne organisée par dimensions universelles
   */
  getInternalGrid: publicProcedure
    .input(z.object({ eventId: z.number().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      const eventId = input.eventId ?? 1;

      const [categories, items, links, unclarified] = await Promise.all([
        db.select().from(contentCategories).where(eq(contentCategories.eventId, eventId)),
        db.select().from(classifiedItems).where(eq(classifiedItems.eventId, eventId)),
        db.select().from(itemLinks).where(eq(itemLinks.eventId, eventId)),
        db.select().from(unclarifiedItems).where(eq(unclarifiedItems.eventId, eventId)),
      ]);

      // Organiser par dimension universelle
      const byDimension = UNIVERSAL_DIMENSIONS.map(dim => {
        const dimCategories = categories.filter(c => c.dimension === dim.id);
        const dimCategoryIds = dimCategories.map(c => c.id);
        const dimItems = items.filter(i =>
          dimCategoryIds.includes(i.categoryId) ||
          i.primaryDimension === dim.id
        );

        return {
          dimension: {
            id: dim.id,
            name: dim.name,
            description: dim.description,
            color: dim.color,
            colorLight: dim.colorLight,
            icon: dim.icon,
            subdimensions: dim.subdimensions,
          },
          categories: dimCategories.map(c => ({
            ...c,
            itemCount: items.filter(i => i.categoryId === c.id).length,
          })),
          items: dimItems.map(i => ({
            id: i.id,
            content: i.content.slice(0, 150),
            confidence: i.confidence,
            maturationState: i.maturationState,
            status: i.status,
            classificationReason: i.classificationReason,
            projections: i.projections ? JSON.parse(i.projections) : [],
          })),
          itemCount: dimItems.length,
          validatedCount: dimItems.filter(i => i.maturationState === 'validated').length,
          ambiguousCount: dimItems.filter(i => i.maturationState === 'ambiguous').length,
        };
      });

      const stats = {
        totalItems: items.length,
        classifiedItems: items.filter(i => i.status === 'classified').length,
        validatedItems: items.filter(i => i.maturationState === 'validated').length,
        ambiguousItems: items.filter(i => i.status === 'pending_clarification').length,
        totalCategories: categories.length,
        newCategories: categories.filter(c => !c.isSystem).length,
        totalLinks: links.length,
        unclarifiedCount: unclarified.length,
        confidenceAvg: items.length > 0
          ? Math.round(items.reduce((sum, i) => sum + (i.confidence ?? 0), 0) / items.length)
          : 0,
        dimensionsUsed: Array.from(new Set(items.map(i => i.primaryDimension).filter(Boolean))).length,
      };

      return {
        byDimension,
        categories,
        items: items.map(i => ({
          id: i.id,
          content: i.content.slice(0, 150),
          categoryId: i.categoryId,
          status: i.status,
          confidence: i.confidence,
          contentType: i.contentType,
          primaryDimension: i.primaryDimension,
          maturationState: i.maturationState,
          classificationReason: i.classificationReason,
        })),
        links,
        unclarified: unclarified.map(u => ({
          id: u.id,
          content: u.content.slice(0, 150),
          reason: u.reason,
          status: u.status,
        })),
        stats,
        dimensions: UNIVERSAL_DIMENSIONS.map(d => ({
          id: d.id,
          name: d.name,
          color: d.color,
          icon: d.icon,
        })),
      };
    }),

  /**
   * Clarifier un élément ambigu
   */
  clarifyItem: publicProcedure
    .input(z.object({
      unclarifiedItemId: z.number(),
      clarification: z.string(),
      selectedCategory: z.string(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      const unclarified = await db
        .select()
        .from(unclarifiedItems)
        .where(eq(unclarifiedItems.id, input.unclarifiedItemId))
        .limit(1);

      if (!unclarified.length) throw new Error('Élément non trouvé');

      await db
        .update(unclarifiedItems)
        .set({ status: 'clarified', clarification: input.clarification })
        .where(eq(unclarifiedItems.id, input.unclarifiedItemId));

      return { success: true, message: 'Élément clarifié' };
    }),

  /**
   * Exporter la grille en JSON
   */
  exportGridAsJSON: publicProcedure
    .input(z.object({ eventId: z.number().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      const eventId = input.eventId ?? 1;

      const [cats, items, links] = await Promise.all([
        db.select().from(contentCategories).where(eq(contentCategories.eventId, eventId)),
        db.select().from(classifiedItems).where(eq(classifiedItems.eventId, eventId)),
        db.select().from(itemLinks).where(eq(itemLinks.eventId, eventId)),
      ]);

      return {
        exportedAt: new Date().toISOString(),
        eventId,
        schema: 'LinkEvent Universal Grid v1.0',
        dimensions: UNIVERSAL_DIMENSIONS.map(d => ({ id: d.id, name: d.name, color: d.color })),
        categories: cats,
        items: items.map(i => ({
          ...i,
          dimensionsParsed: i.dimensions ? JSON.parse(i.dimensions) : [],
          projectionsParsed: i.projections ? JSON.parse(i.projections) : [],
        })),
        links,
        stats: {
          totalItems: items.length,
          totalCategories: cats.length,
          totalLinks: links.length,
        },
      };
    }),

  /**
   * Retourner les 12 dimensions universelles (pour l'UI)
   */
  getDimensions: publicProcedure.query(() => {
    return UNIVERSAL_DIMENSIONS.map(d => ({
      id: d.id,
      name: d.name,
      description: d.description,
      color: d.color,
      colorLight: d.colorLight,
      icon: d.icon,
      subdimensions: d.subdimensions,
      weddingExamples: d.weddingExamples,
    }));
  }),
});
