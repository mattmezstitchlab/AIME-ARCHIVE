import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { getDb } from "../db";
import { uploadedFiles, aiAnalysis, InsertAIAnalysis } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * Schéma pour l'analyse IA structurée
 */
const AnalysisSchema = z.object({
  understood: z.object({
    times: z.array(z.object({ label: z.string(), time: z.string() })),
    keyMoments: z.array(z.string()),
    people: z.array(z.object({ name: z.string(), role: z.string() })),
    vendors: z.array(z.object({ name: z.string(), category: z.string(), contact: z.string().optional() })),
    locations: z.array(z.string()),
    music: z.array(z.string()),
    objects: z.array(z.string()),
    actions: z.array(z.string()),
    dependencies: z.array(z.object({ from: z.string(), to: z.string(), reason: z.string() })),
  }),
  missing: z.object({
    unidentifiedPeople: z.array(z.string()),
    missingRoles: z.array(z.string()),
    missingVendors: z.array(z.string()),
    unclearTimes: z.array(z.string()),
    unspecifiedLocations: z.array(z.string()),
    actionsWithoutOwner: z.array(z.string()),
    missingContacts: z.array(z.string()),
    requiredValidations: z.array(z.string()),
  }),
  suggestedQuestions: z.array(z.object({
    question: z.string(),
    importance: z.enum(["critical", "high", "medium", "low"]),
    relatedTo: z.string(),
  })),
  confidence: z.number().min(0).max(1),
});

export type AnalysisResult = z.infer<typeof AnalysisSchema>;

export const analysisRouter = router({
  /**
   * Analyser un fichier uploadé avec l'IA
   */
  analyzeFile: protectedProcedure
    .input(z.object({
      fileId: z.number(),
      eventId: z.number(),
      fileContent: z.string(), // Contenu du fichier (texte, OCR d'image, etc.)
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      try {
        // Construire le prompt pour l'IA
        const prompt = `Tu es un assistant expert en planification de mariage. Analyse le contenu fourni et extrais les informations structurées.

CONTENU À ANALYSER:
${input.fileContent}

INSTRUCTIONS:
1. Extrais TOUS les horaires, moments clés, personnes, prestataires, lieux, musiques, objets et actions
2. Identifie les dépendances entre les tâches (ex: "le traiteur doit arriver avant la réception")
3. Détecte ce qui manque ou est flou
4. Génère des questions courtes et pertinentes pour clarifier les ambiguïtés
5. Évalue ta confiance dans l'extraction (0.0 à 1.0)

Réponds en JSON structuré avec la structure suivante:
{
  "understood": {
    "times": [{"label": "Cérémonie", "time": "14:00"}],
    "keyMoments": ["Arrivée des invités", "Échange des vœux"],
    "people": [{"name": "Sophie", "role": "Mariée"}],
    "vendors": [{"name": "Traiteur ABC", "category": "Traiteur", "contact": "06..."}],
    "locations": ["Mairie", "Château de Vaux"],
    "music": ["Marche de Mendelssohn", "DJ pour la soirée"],
    "objects": ["Bagues", "Bouquet"],
    "actions": ["Préparer la salle", "Accueillir les invités"],
    "dependencies": [{"from": "Arrivée traiteur", "to": "Service apéritif", "reason": "Le traiteur doit être présent"}]
  },
  "missing": {
    "unidentifiedPeople": ["Personne X mentionnée sans nom"],
    "missingRoles": ["Qui gère la musique?"],
    "missingVendors": ["Pas de photographe mentionné"],
    "unclearTimes": ["Horaire du brunch flou"],
    "unspecifiedLocations": ["Lieu de la réception non précisé"],
    "actionsWithoutOwner": ["Accueil des invités - pas de responsable"],
    "missingContacts": ["Pas de numéro pour le DJ"],
    "requiredValidations": ["Nombre exact d'invités"]
  },
  "suggestedQuestions": [
    {"question": "Qui doit recevoir le déroulé de la cérémonie?", "importance": "high", "relatedTo": "Communication"},
    {"question": "Le traiteur a-t-il l'horaire exact d'arrivée?", "importance": "critical", "relatedTo": "Traiteur"}
  ],
  "confidence": 0.85
}`;

        // Appeler l'IA
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "Tu es un expert en planification de mariage. Réponds toujours en JSON valide.",
            } as any,
            {
              role: "user",
              content: prompt,
            } as any,
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "wedding_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  understood: {
                    type: "object",
                    properties: {
                      times: { type: "array" },
                      keyMoments: { type: "array" },
                      people: { type: "array" },
                      vendors: { type: "array" },
                      locations: { type: "array" },
                      music: { type: "array" },
                      objects: { type: "array" },
                      actions: { type: "array" },
                      dependencies: { type: "array" },
                    },
                    required: ["times", "keyMoments", "people", "vendors", "locations", "music", "objects", "actions", "dependencies"],
                  },
                  missing: {
                    type: "object",
                    properties: {
                      unidentifiedPeople: { type: "array" },
                      missingRoles: { type: "array" },
                      missingVendors: { type: "array" },
                      unclearTimes: { type: "array" },
                      unspecifiedLocations: { type: "array" },
                      actionsWithoutOwner: { type: "array" },
                      missingContacts: { type: "array" },
                      requiredValidations: { type: "array" },
                    },
                    required: ["unidentifiedPeople", "missingRoles", "missingVendors", "unclearTimes", "unspecifiedLocations", "actionsWithoutOwner", "missingContacts", "requiredValidations"],
                  },
                  suggestedQuestions: { type: "array" },
                  confidence: { type: "number" },
                },
                required: ["understood", "missing", "suggestedQuestions", "confidence"],
                additionalProperties: false,
              },
            },
          } as any,
        });

        // Parser la réponse
        const content = response.choices[0]?.message.content;
        if (!content) throw new Error("No response from LLM");

        const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
        const analysisData = JSON.parse(contentStr) as AnalysisResult;

        // Sauvegarder l'analyse en base de données
        const analysis: InsertAIAnalysis = {
          fileId: input.fileId,
          eventId: input.eventId,
          extractedData: JSON.stringify(analysisData.understood),
          detectedIssues: JSON.stringify(analysisData.missing),
          suggestedQuestions: JSON.stringify(analysisData.suggestedQuestions),
          confidence: analysisData.confidence.toString(),
        };

        await db.insert(aiAnalysis).values(analysis);

        // Mettre à jour l'état du fichier
        await db
          .update(uploadedFiles)
          .set({ maturationState: "illuminated" })
          .where(eq(uploadedFiles.id, input.fileId));

        return {
          success: true,
          analysis: analysisData,
        };
      } catch (error) {
        console.error("[Analysis Error]", error);
        throw error;
      }
    }),

  /**
   * Récupérer l'analyse d'un fichier
   */
  getAnalysis: protectedProcedure
    .input(z.object({
      fileId: z.number(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const analysis = await db
        .select()
        .from(aiAnalysis)
        .where(eq(aiAnalysis.fileId, input.fileId))
        .limit(1);

      if (analysis.length === 0) return null;

      const record = analysis[0];
      return {
        id: record.id,
        fileId: record.fileId,
        eventId: record.eventId,
        extractedData: record.extractedData ? JSON.parse(record.extractedData) : null,
        detectedIssues: record.detectedIssues ? JSON.parse(record.detectedIssues) : null,
        suggestedQuestions: record.suggestedQuestions ? JSON.parse(record.suggestedQuestions) : null,
        confidence: parseFloat(record.confidence || "0"),
        createdAt: record.createdAt,
      };
    }),
});
