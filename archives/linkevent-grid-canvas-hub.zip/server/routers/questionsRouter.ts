import { z } from 'zod';
import { protectedProcedure, publicProcedure, router } from '../_core/trpc';
import { getDb } from '../db';
import { weddingAnswers, weddingQuestions } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

export const questionsRouter = router({
  // Sauvegarder les réponses aux questions
  saveAnswers: protectedProcedure
    .input(
      z.object({
        eventId: z.number(),
        answers: z.record(z.string(), z.string()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      try {
        // Sauvegarder chaque réponse
        for (const [questionId, answer] of Object.entries(input.answers)) {
          await db.insert(weddingAnswers).values({
            eventId: input.eventId,
            questionId: parseInt(questionId),
            answer,
            answeredBy: ctx.user.id,
            answeredAt: new Date(),
          }).onDuplicateKeyUpdate({
            set: {
              answer,
              answeredAt: new Date(),
            },
          });
        }

        return {
          success: true,
          message: 'Réponses sauvegardées avec succès',
        };
      } catch (error) {
        console.error('Error saving answers:', error);
        throw new Error('Failed to save answers');
      }
    }),

  // Récupérer les réponses pour un mariage
  getAnswers: protectedProcedure
    .input(z.object({ eventId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      try {
        const answers = await db
          .select()
          .from(weddingAnswers)
          .where(eq(weddingAnswers.eventId, input.eventId));

        return answers;
      } catch (error) {
        console.error('Error fetching answers:', error);
        throw new Error('Failed to fetch answers');
      }
    }),

  // Récupérer les questions pour un mariage
  getQuestions: protectedProcedure
    .input(z.object({ eventId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      try {
        const questions = await db
          .select()
          .from(weddingQuestions)
          .where(eq(weddingQuestions.eventId, input.eventId));

        return questions;
      } catch (error) {
        console.error('Error fetching questions:', error);
        throw new Error('Failed to fetch questions');
      }
    }),
});
