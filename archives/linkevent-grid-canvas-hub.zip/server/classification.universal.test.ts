/**
 * Test du moteur universel de classification
 * Vérifie que le router classifie correctement selon les 12 dimensions
 */
import { describe, it, expect } from 'vitest';
import { UNIVERSAL_DIMENSIONS, DIMENSIONS_BY_ID, CLASSIFICATION_SYSTEM_PROMPT } from '../shared/universalDimensions';

describe('Grille Universelle — 12 Dimensions', () => {
  it('doit avoir exactement 12 dimensions', () => {
    expect(UNIVERSAL_DIMENSIONS).toHaveLength(12);
  });

  it('doit avoir toutes les dimensions fondamentales', () => {
    const ids = UNIVERSAL_DIMENSIONS.map(d => d.id);
    expect(ids).toContain('TEMPS');
    expect(ids).toContain('ESPACE');
    expect(ids).toContain('PERSONNES');
    expect(ids).toContain('RESSOURCES');
    expect(ids).toContain('ACTIONS');
    expect(ids).toContain('DOCUMENTS');
    expect(ids).toContain('MEMOIRE');
    expect(ids).toContain('COMMUNICATION');
    expect(ids).toContain('ECONOMIE');
    expect(ids).toContain('EMOTIONS');
    expect(ids).toContain('VALIDATION');
    expect(ids).toContain('RELATIONS');
  });

  it('chaque dimension doit avoir une couleur, une icône et des sous-dimensions', () => {
    for (const dim of UNIVERSAL_DIMENSIONS) {
      expect(dim.color).toBeTruthy();
      expect(dim.icon).toBeTruthy();
      expect(dim.subdimensions.length).toBeGreaterThan(0);
      expect(dim.weddingExamples.length).toBeGreaterThan(0);
    }
  });

  it('DIMENSIONS_BY_ID doit permettre un accès direct par ID', () => {
    expect(DIMENSIONS_BY_ID['TEMPS']).toBeDefined();
    expect(DIMENSIONS_BY_ID['TEMPS'].name).toBe('Temps');
    expect(DIMENSIONS_BY_ID['ECONOMIE'].name).toBe('Économie');
  });

  it('le prompt de classification doit mentionner les 12 dimensions', () => {
    for (const dim of UNIVERSAL_DIMENSIONS) {
      expect(CLASSIFICATION_SYSTEM_PROMPT).toContain(dim.id);
    }
  });

  it('les couleurs doivent être des codes hex valides', () => {
    const hexRegex = /^#[0-9A-Fa-f]{6}$/;
    for (const dim of UNIVERSAL_DIMENSIONS) {
      expect(dim.color).toMatch(hexRegex);
      expect(dim.colorLight).toMatch(hexRegex);
    }
  });
});

describe('Logique de classification — Mariage vs Générique', () => {
  it('un horaire de cérémonie doit appartenir à TEMPS', () => {
    const tempsExamples = DIMENSIONS_BY_ID['TEMPS'].weddingExamples;
    expect(tempsExamples.some(e => e.toLowerCase().includes('horaire') || e.toLowerCase().includes('cérémonie'))).toBe(true);
  });

  it('un prestataire doit appartenir à PERSONNES ou RELATIONS', () => {
    const personnesExamples = DIMENSIONS_BY_ID['PERSONNES'].weddingExamples;
    const relationsExamples = DIMENSIONS_BY_ID['RELATIONS'].weddingExamples;
    const allExamples = [...personnesExamples, ...relationsExamples].map(e => e.toLowerCase());
    expect(allExamples.some(e => e.includes('prestataire') || e.includes('traiteur') || e.includes('dj'))).toBe(true);
  });

  it('une facture doit appartenir à ECONOMIE', () => {
    const economieExamples = DIMENSIONS_BY_ID['ECONOMIE'].weddingExamples;
    expect(economieExamples.some(e => e.toLowerCase().includes('facture') || e.toLowerCase().includes('budget') || e.toLowerCase().includes('devis'))).toBe(true);
  });

  it('un souvenir doit appartenir à MEMOIRE', () => {
    const memoireExamples = DIMENSIONS_BY_ID['MEMOIRE'].weddingExamples;
    expect(memoireExamples.some(e => e.toLowerCase().includes('souvenir') || e.toLowerCase().includes('photo') || e.toLowerCase().includes('mémoire'))).toBe(true);
  });
});
