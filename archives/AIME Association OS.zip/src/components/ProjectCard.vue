<script setup lang="ts">
defineProps<{
  project: { id: string; name: string; status: string; progress: number }
}>()
</script>

<template>
  <div class="project-card">
    <h3>{{ project.name }}</h3>
    <div class="project-status">{{ project.status }}</div>
    <div class="progress-bar">
      <div class="progress-fill" :style="{ width: project.progress + '%' }" />
    </div>
  </div>
</template>

<style scoped>
.project-card { background: white; border-radius: 12px; padding: 20px; }
.project-card h3 { font-size: 1.125rem; margin-bottom: 12px; }
.project-status { color: #888; font-size: 0.8125rem; margin-bottom: 16px; }
.progress-bar { height: 6px; background: #f0f0f0; border-radius: 3px; }
.progress-fill { height: 100%; background: #2d5bff; border-radius: 3px; }
</style>