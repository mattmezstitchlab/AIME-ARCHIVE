<script setup lang="ts">
import { ref } from 'vue'

const messages = ref<{ role: string; content: string }[]>([])
const input = ref('')

function send() {
  if (!input.value.trim()) return
  messages.value.push({ role: 'user', content: input.value })
  input.value = ''
}
</script>

<template>
  <div class="aime-agent">
    <div class="agent-messages">
      <div v-for="msg in messages" :key="msg.content" :class="['msg', msg.role]">
        {{ msg.content }}
      </div>
    </div>
    <div class="agent-input">
      <input v-model="input" @keyup.enter="send" placeholder="Demander à AIME..." />
      <button @click="send">Envoyer</button>
    </div>
  </div>
</template>

<style scoped>
.aime-agent { display: flex; flex-direction: column; height: 100%; }
.agent-messages { flex: 1; overflow-y: auto; }
.msg { padding: 12px; border-radius: 8px; margin-bottom: 8px; }
.msg.user { background: #ebf0ff; }
.msg.agent { background: #f4f4f1; }
</style>