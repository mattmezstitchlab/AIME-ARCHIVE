<script setup lang="ts">
import { RouterLink } from 'vue-router'

const links = [
  { to: '/', label: 'Accueil' },
  { to: '/projects', label: 'Projets' },
  { to: '/documents', label: 'Documents' },
  { to: '/vigilance', label: 'Vigilance' },
]
</script>

<template>
  <nav class="nav">
    <div class="nav-logo">AIME</div>
    <div class="nav-links">
      <RouterLink v-for="link in links" :key="link.to" :to="link.to">
        {{ link.label }}
      </RouterLink>
    </div>
  </nav>
</template>

<style scoped>
.nav { display: flex; align-items: center; gap: 32px; padding: 16px 32px; background: white; border-bottom: 1px solid #e8e6e1; }
.nav-logo { font-weight: 600; font-size: 1.25rem; }
.nav-links { display: flex; gap: 24px; }
.nav-links a { color: #555; text-decoration: none; }
.nav-links a.router-link-active { color: #2d5bff; }
</style>