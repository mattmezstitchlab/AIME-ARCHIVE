export interface Project {
  id: string
  name: string
  status: string
  progress: number
}

export async function fetchProjects(): Promise<Project[]> {
  return [
    { id: '1', name: 'Festival Printemps', status: 'En cours', progress: 65 },
    { id: '2', name: 'Atelier Numérique', status: 'Planifié', progress: 20 },
    { id: '3', name: 'Exposition Photos', status: 'Terminé', progress: 100 },
  ]
}