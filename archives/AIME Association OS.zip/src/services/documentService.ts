export interface Document {
  id: string
  name: string
  type: string
  url?: string
}

export async function fetchDocuments(): Promise<Document[]> {
  return []
}