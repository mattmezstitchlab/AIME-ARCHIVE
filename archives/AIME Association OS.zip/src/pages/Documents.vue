<script setup lang="ts">
import { ref } from 'vue'

const documents = ref([
  { id: 1, name: 'Rapport annuel 2024', type: 'PDF', size: '2.4 Mo' },
  { id: 2, name: 'Budget prévisionnel', type: 'XLSX', size: '340 Ko' },
  { id: 3, name: 'Procès-verbal AG', type: 'PDF', size: '1.1 Mo' },
])
</script>

<template>
  <div class="documents-page">
    <h1>Documents</h1>
    <div class="docs-list">
      <div v-for="doc in documents" :key="doc.id" class="doc-item">
        <span class="doc-name">{{ doc.name }}</span>
        <span class="doc-meta">{{ doc.type }} · {{ doc.size }}</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.documents-page h1 { font-size: 2rem; margin-bottom: 24px; }
.docs-list { display: flex; flex-direction: column; gap: 8px; }
.doc-item { background: white; padding: 16px; border-radius: 8px; display: flex; justify-content: space-between; }
.doc-meta { color: #888; font-size: 0.875rem; }
</style>