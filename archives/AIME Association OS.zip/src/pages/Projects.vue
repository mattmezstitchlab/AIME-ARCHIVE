<script setup lang="ts">
import { ref, onMounted } from 'vue'
import ProjectCard from '../components/ProjectCard.vue'
import { fetchProjects } from '../services/projectService'

const projects = ref([])
const loading = ref(true)

onMounted(async () => {
  projects.value = await fetchProjects()
  loading.value = false
})
</script>

<template>
  <div class="projects-page">
    <div class="page-header">
      <h1>Projets</h1>
      <p>Gérez les projets de l'association</p>
    </div>
    <div v-if="loading" class="loading">Chargement...</div>
    <div v-else class="projects-grid">
      <ProjectCard
        v-for="project in projects"
        :key="project.id"
        :project="project"
      />
    </div>
  </div>
</template>

<style scoped>
.page-header { margin-bottom: 32px; }
.page-header h1 { font-size: 2rem; }
.projects-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.loading { color: #888; padding: 40px; text-align: center; }
</style>