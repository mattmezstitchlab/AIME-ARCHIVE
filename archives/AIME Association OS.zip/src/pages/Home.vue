<script setup lang="ts">
import { ref } from 'vue'
import ProjectCard from '../components/ProjectCard.vue'

const stats = ref([
  { label: 'Projets actifs', value: 12 },
  { label: 'Documents', value: 248 },
  { label: 'Membres', value: 34 },
  { label: 'Vigilances', value: 3 },
])
</script>

<template>
  <div class="home">
    <h1>Tableau de bord</h1>
    <p>Bienvenue dans AIME Association OS</p>
    <div class="stats-grid">
      <div v-for="s in stats" :key="s.label" class="stat-card">
        <span class="stat-value">{{ s.value }}</span>
        <span class="stat-label">{{ s.label }}</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.home h1 { font-size: 2rem; margin-bottom: 8px; }
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-top: 32px; }
.stat-card { background: white; border-radius: 12px; padding: 24px; }
.stat-value { font-size: 2rem; font-weight: 600; display: block; }
.stat-label { color: #888; font-size: 0.875rem; }
</style>