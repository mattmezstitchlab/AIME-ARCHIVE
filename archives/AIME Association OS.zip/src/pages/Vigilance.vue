<script setup lang="ts">
import { ref } from 'vue'

const alerts = ref([
  { id: 1, level: 'high', message: 'Date limite subvention dépassée', date: '2024-03-15' },
  { id: 2, level: 'medium', message: 'Relance facture en attente', date: '2024-03-20' },
])
</script>

<template>
  <div class="vigilance-page">
    <h1>Vigilance</h1>
    <div class="alerts-list">
      <div v-for="alert in alerts" :key="alert.id" :class="['alert', alert.level]">
        <span class="alert-message">{{ alert.message }}</span>
        <span class="alert-date">{{ alert.date }}</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.vigilance-page h1 { font-size: 2rem; margin-bottom: 24px; }
.alerts-list { display: flex; flex-direction: column; gap: 12px; }
.alert { background: white; padding: 16px; border-radius: 8px; border-left: 4px solid; }
.alert.high { border-color: #e74c3c; }
.alert.medium { border-color: #f39c12; }
.alert-date { color: #888; font-size: 0.8125rem; }
</style>