# AIME Association OS

Application de gestion pour associations.

## Stack
- Vue 3 + TypeScript
- Vite
- Vue Router
- Pinia

## Démarrage
```bash
npm install
npm run dev
```