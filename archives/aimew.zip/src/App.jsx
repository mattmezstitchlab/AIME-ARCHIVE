import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import Home from './pages/Home';
import ProjectDetail from './pages/ProjectDetail';
import AdminLogin from './pages/AdminLogin';
import AdminProjects from './pages/AdminProjects';
import AdminProjectForm from './pages/AdminProjectForm';
import Contact from './pages/Contact';
import RegistreAime from './pages/RegistreAime';
import APropos from './pages/APropos';
import LeCreateur from './pages/LeCreateur';
import MonEspace from './pages/MonEspace';
import Magazine from './pages/Magazine';
import StampStudio from './pages/StampStudio';
import AimeGardien from './pages/AimeGardien';
import AdminMessages from './pages/AdminMessages';
import AdminCommercialDocument from './pages/AdminCommercialDocument';
import AdminFounder from './pages/AdminFounder';
import SiteAssistant from '@/components/assistant/SiteAssistant';
import AimeGlobalCapsule from '@/components/AimeGlobalCapsule';
import AnnotationLayer from '@/components/annotations/AnnotationLayer';
import SystemeAime from '@/pages/SystemeAime';
import PasseportVivant from '@/pages/PasseportVivant';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      {/* Add your page Route elements here */}
      <Route path="/" element={<Home />} />
      <Route path="/projects/:slug" element={<ProjectDetail />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/registre-aime" element={<RegistreAime />} />
      <Route path="/a-propos" element={<APropos />} />
      <Route path="/archives" element={<APropos />} />
      <Route path="/systeme-aime" element={<SystemeAime />} />
      <Route path="/passeports" element={<PasseportVivant />} />
      <Route path="/passeports/:slug" element={<PasseportVivant />} />
      <Route path="/+matt-mez" element={<PasseportVivant />} />
      <Route path="/APropos" element={<Navigate to="/a-propos" replace />} />
      <Route path="/le-createur" element={<LeCreateur />} />
      <Route path="/mon-espace" element={<MonEspace />} />
      <Route path="/magazine" element={<Magazine />} />
      <Route path="/stamp-studio" element={<StampStudio />} />
      <Route path="/aime-gardien" element={<AimeGardien />} />
      <Route path="/admin" element={<AdminLogin />} />
      <Route path="/admin/projects" element={<AdminProjects />} />
      <Route path="/admin/projects/new" element={<AdminProjectForm />} />
      <Route path="/admin/projects/:id/edit" element={<AdminProjectForm />} />
      <Route path="/admin/messages" element={<AdminMessages />} />
      <Route path="/admin/biographie" element={<AdminFounder />} />
      <Route path="/admin/documents/:id" element={<AdminCommercialDocument />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AimeGlobalCapsule currentApp="lab" />
          <AnnotationLayer />
          <AuthenticatedApp />
          <SiteAssistant />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
