const MEDIA = "https://media.base44.com/images/public/6a5eeb63433486457d5b747c";

export const livingPassportProfiles = [
  {
    id: "matt-mez",
    slug: "+matt-mez",
    name: "Matt Mez",
    kind: "Personne",
    subtitle: "Créateur · musicien · transmetteur",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/81f9ecc7e_ChatGPTImage9juin202603_05_32.png",
    access: "Propriétaire",
    signal: "calm",
    chapters: ["Identité", "Œuvres", "Musique", "Documents", "Transmissions"],
  },
  {
    id: "camille-noe",
    slug: "+camille-noe",
    name: "Camille & Noé",
    kind: "Événement",
    subtitle: "Mariage · édition vivante",
    image: `${MEDIA}/c6aaa1b48_01-hero-couple.png`,
    access: "Organisateur",
    signal: "time",
    chapters: ["Moments", "Invités", "Lieux", "Playlist", "Preuves"],
  },
  {
    id: "collecte-aime",
    slug: "+collecte-aime",
    name: "Collecte AIME",
    kind: "Relais",
    subtitle: "Chaussures · Lille → association",
    image: "https://media.base44.com/images/public/6a5405ca27db93d02981b7ed/42718147b_generated_image.png",
    access: "Coordinateur",
    signal: "watch",
    chapters: ["Départs", "Relais", "Associations", "Documents", "Impact"],
  },
];

export const livingPassportStamps = [
  { id: "s-1", code: "AIME-FJV-WPQ", title: "Présence fondatrice", kind: "Identité", issuer: "Registre AIME", color: "gold", status: "Vérifié", date: "27.04.2026", portrait: livingPassportProfiles[0].image },
  { id: "s-2", code: "AIME-I7Y-Y4C", title: "Le Petit Prince", kind: "Transmission", issuer: "AIME Stamp", color: "blue", status: "Vérifié", date: "27.04.2026", portrait: `${MEDIA}/0539748d5_01-hero-couple.png` },
  { id: "s-3", code: "AIME-AID-104", title: "Relais solidaire", kind: "Aide", issuer: "Collecte AIME", color: "rose", status: "À confirmer", date: "22.07.2026", portrait: livingPassportProfiles[2].image },
  { id: "s-4", code: "AIME-MEM-622", title: "Mémoire musicale", kind: "Mémoire", issuer: "AIME Édition", color: "violet", status: "Privé", date: "22.08.2026", portrait: `${MEDIA}/ec2e5cdc1_15-hero-role-invite-invite.png` },
];

export const passportCausalLinks = [
  { id: "event", label: "Mariage Camille & Noé", detail: "Événement relié", state: "Actif" },
  { id: "place", label: "Maison privée", detail: "Lieu · 18 km", state: "Confirmé" },
  { id: "people", label: "86 participants", detail: "7 rôles · 12 équipes", state: "Synchronisé" },
  { id: "music", label: "Playlist du moment", detail: "43 titres · 6 intentions", state: "Partagé" },
  { id: "proof", label: "2 preuves à valider", detail: "Consentement humain requis", state: "Surveillance" },
];

