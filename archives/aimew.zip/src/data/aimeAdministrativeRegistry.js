export const ADMINISTRATIVE_IDENTITY_EVENTS = [
  { year: "1987", label: "Naissance", source: "État civil", state: "verified", detail: "Acte et identité concordants" },
  { year: "2011", label: "Mariage 01", source: "Acte de mariage", state: "verified", detail: "Mention consolidée" },
  { year: "2016", label: "Dissolution", source: "Mention marginale", state: "verified", detail: "Décision rapprochée" },
  { year: "2019", label: "Mariage 02", source: "Pièce absente", state: "missing", detail: "Rupture dans la chaîne de preuves" },
  { year: "2021", label: "Dissolution", source: "Déclaration", state: "review", detail: "À confirmer par une pièce opposable" },
  { year: "2024", label: "Mariage 03", source: "Acte transmis", state: "review", detail: "Impossible à consolider avant résolution du trou" },
];

export const INTERMITTENT_FLOW = [
  { id: "engagement", short: "01", title: "Engagement", detail: "Rôle, date, lieu, cachet ou heures", owner: "Production", status: "ready" },
  { id: "contract", short: "02", title: "CDDU · contrat", detail: "Clauses, convention et signatures", owner: "Employeur + artiste", status: "ready" },
  { id: "declaration", short: "03", title: "DPAE · GUSO", detail: "Canal choisi selon l’activité de l’employeur", owner: "Employeur", status: "attention" },
  { id: "aem", short: "04", title: "AEM · DUS", detail: "Période, heures, cachets et rémunération concordants", owner: "Employeur", status: "attention" },
  { id: "payroll", short: "05", title: "Paie · cotisations", detail: "Bulletin, paiement et preuves", owner: "Paie", status: "planned" },
  { id: "actualisation", short: "06", title: "Actualisation", detail: "Données alignées avec France Travail", owner: "Intermittent", status: "planned" },
];

export const ADMINISTRATIVE_ROLES = [
  "Président·e",
  "Trésorier·ère",
  "Employeur",
  "Organisateur·rice",
  "Intermittent·e",
  "Salarié·e",
  "Prestataire",
  "Bénévole",
];

export const ADMINISTRATIVE_DOCUMENTS = [
  { id: "quote", family: "Commercial", label: "Devis", roles: ["Président·e", "Trésorier·ère", "Prestataire"], fields: ["Émetteur", "Client", "Objet", "Lignes", "TVA", "Validité"] },
  { id: "invoice", family: "Commercial", label: "Facture · avoir", roles: ["Président·e", "Trésorier·ère", "Prestataire"], fields: ["Mentions légales", "Numérotation", "Échéance", "TVA", "Paiement"] },
  { id: "order", family: "Commercial", label: "Bon de commande · livraison", roles: ["Trésorier·ère", "Organisateur·rice"], fields: ["Référence", "Fournisseur", "Livraison", "Validation"] },
  { id: "employment", family: "Emploi", label: "DPAE · contrat de travail", roles: ["Président·e", "Employeur"], fields: ["Employeur", "Salarié", "Emploi", "Convention", "Durée", "Rémunération"] },
  { id: "work-certificate", family: "Emploi", label: "Certificat de travail", roles: ["Employeur", "Salarié·e"], fields: ["Identité", "Dates", "Emploi", "Maintien des garanties", "Signature"] },
  { id: "france-travail", family: "Emploi", label: "Attestation employeur France Travail", roles: ["Employeur", "Salarié·e"], fields: ["Contrat", "Périodes", "Salaires", "Fin de contrat", "Transmission"] },
  { id: "payroll", family: "Emploi", label: "Bulletin · solde de tout compte", roles: ["Employeur", "Salarié·e"], fields: ["Brut", "Cotisations", "Net", "Congés", "Versement"] },
  { id: "cddu", family: "Spectacle", label: "CDDU spectacle", roles: ["Employeur", "Intermittent·e"], fields: ["Fonction", "Numéro d’objet", "Dates", "Cachets ou heures", "Convention"] },
  { id: "aem", family: "Spectacle", label: "AEM · DUS GUSO", roles: ["Employeur", "Intermittent·e", "Organisateur·rice"], fields: ["Période", "Heures", "Cachets", "Brut", "Employeur", "Envoi"] },
  { id: "tour-sheet", family: "Spectacle", label: "Feuille de route · ordre de mission", roles: ["Organisateur·rice", "Intermittent·e", "Bénévole"], fields: ["Date", "Lieu", "Transport", "Hébergement", "Contacts", "Appel"] },
  { id: "minutes", family: "Association", label: "PV · délibération · procuration", roles: ["Président·e", "Trésorier·ère"], fields: ["Organe", "Convocation", "Quorum", "Décision", "Signatures"] },
  { id: "agreement", family: "Association", label: "Convention · attestation bénévole", roles: ["Président·e", "Organisateur·rice", "Bénévole"], fields: ["Parties", "Objet", "Durée", "Engagements", "Assurance"] },
  { id: "expense", family: "Association", label: "Note de frais · abandon de frais", roles: ["Trésorier·ère", "Bénévole", "Salarié·e"], fields: ["Mission", "Dépense", "Justificatifs", "Barème", "Validation"] },
  { id: "donation", family: "Association", label: "Reçu fiscal de don", roles: ["Président·e", "Trésorier·ère"], fields: ["Organisme", "Donateur", "Nature", "Montant", "Éligibilité", "Signature"] },
];

export const PENNYLANE_COMPARISON = [
  { subject: "Comptabilité, trésorerie, achats et ventes", pennylane: "Cœur de produit", aime: "Connexion et vue contextuelle", strategy: "Intégrer" },
  { subject: "Facturation électronique et plateforme agréée", pennylane: "Opérationnel", aime: "Préparation, contexte et suivi", strategy: "Ne pas réinventer" },
  { subject: "Rôles, événements, lieux et causalité", pennylane: "Périphérique", aime: "Cœur de produit", strategy: "Différencier" },
  { subject: "Chaîne de preuves administratives", pennylane: "Pièces financières", aime: "Chronologie multi-organismes", strategy: "Construire" },
  { subject: "Intermittents, associations et relais", pennylane: "Gestion générique", aime: "Parcours métier vivant", strategy: "Spécialiser" },
  { subject: "Agent qui prépare l’action au bon écran", pennylane: "Assistant financier", aime: "Agent orchestrateur global", strategy: "Étendre" },
];

export const DOCUMENT_REGISTRY_NOTICE = "Le registre est versionné par date, rôle, organisme et statut juridique. Il ne prétend pas figer tous les documents français : un modèle n’est publiable qu’après validation de sa source et de sa version.";
