import React from "react";

const heroImageUrl = "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/b82b1e20e_Gemini_Generated_Image_xkvvf8xkvvf8xkvv.png";
const heroVideoUrl = "https://media.base44.com/videos/public/6a5eeb63433486457d5b747c/4ba70fcd2_le_couple_de_maries_en_apesant.mp4";

export default function MagazineHero() {
  return (
    <section className="relative flex h-[100svh] min-h-[36rem] w-full items-center justify-center overflow-hidden bg-black px-5 text-center text-white sm:px-8 lg:px-12">
      <video src={heroVideoUrl} poster={heroImageUrl} autoPlay muted loop playsInline preload="metadata" aria-label="Film d’une célébration AIME" className="absolute inset-0 h-full w-full object-cover object-center" />
      <div className="absolute inset-0 bg-black/25" aria-hidden="true" />
      <div className="relative z-10 w-full max-w-[96rem]">
        <p className="text-xs font-semibold uppercase tracking-[0.34em] text-white/75">Une œuvre fusionnelle</p>
        <h1 className="mt-5 whitespace-nowrap font-display text-[clamp(3.1rem,10.8vw,12rem)] font-semibold leading-[0.78] tracking-[-0.085em] drop-shadow-2xl">LE MONDE AIME</h1>
        <p className="mx-auto mt-10 max-w-3xl text-balance font-display text-2xl font-medium leading-tight tracking-[-0.035em] drop-shadow-xl sm:text-4xl">Une architecture intelligente pour comprendre, relier et agir ensemble.</p>
      </div>
    </section>
  );
}
