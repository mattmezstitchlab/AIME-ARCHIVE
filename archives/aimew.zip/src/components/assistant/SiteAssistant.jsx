import React, { useEffect, useState } from "react";
import { Plus, Send } from "lucide-react";
import { useLocation } from "react-router-dom";
import AimeConcierge from "@/components/assistant/AimeConcierge";

export default function SiteAssistant() {
  const [open, setOpen] = useState(false);
  const [context, setContext] = useState(null);
  const { pathname, search } = useLocation();
  const projectTitle = new URLSearchParams(search).get("project") || "";
  const starter = projectTitle ? `Bonjour, j’aimerais parler d’un projet similaire à ${projectTitle}.` : "";
  const isAboutPage = pathname === "/a-propos" || pathname === "/APropos";
  useEffect(() => {
    const handleOpen = (event) => {
      setContext(event.detail || null);
      setOpen(true);
    };
    window.addEventListener("aime-agent-open", handleOpen);
    return () => window.removeEventListener("aime-agent-open", handleOpen);
  }, []);
  if (pathname.startsWith("/admin")) return null;
  return (
    <aside className={`fixed bottom-4 z-50 sm:bottom-6 ${isAboutPage ? "right-4 sm:right-6" : "left-1/2 -translate-x-1/2"} ${open ? "w-[calc(100vw-2rem)] sm:w-[34rem]" : "w-[min(30rem,calc(100vw-2rem))]"}`}>
      {open ? <AimeConcierge starter={starter} context={context} onClose={() => setOpen(false)} /> : <div className="flex h-[4.35rem] items-center gap-2 rounded-[1.6rem] border border-[#2b2b2b] bg-black/95 p-1.5 text-white shadow-2xl backdrop-blur-xl"><button onClick={() => setOpen(true)} className="aime-launcher grid size-14 shrink-0 place-items-center rounded-full text-white" aria-label="Ouvrir AIME Concierge"><Plus className="h-6 w-6" /></button><button onClick={() => setOpen(true)} className="min-w-0 flex-1 rounded-full bg-white/[.08] px-4 py-3 text-left text-sm text-white/48">Parler à AIME…</button><button onClick={() => setOpen(true)} className="grid size-12 shrink-0 place-items-center rounded-full bg-white text-black" aria-label="Écrire à AIME"><Send size={17} /></button></div>}
    </aside>
  );
}
