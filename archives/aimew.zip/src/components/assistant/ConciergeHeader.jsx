import React from "react";
import { Link } from "react-router-dom";
import { RotateCcw } from "lucide-react";

export default function ConciergeHeader({ onClose, onRestart, sending }) {
  return (
    <div className="border-b border-[#2b2b2b]">
      <header className="flex h-[4.25rem] items-center justify-between px-5">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-full border border-[#343434] text-[0.62rem] font-medium tracking-tight text-white">AIME</span>
          <h2 className="text-[0.95rem] font-medium text-white">AIME Concierge</h2>
        </div>
        {onClose && <button type="button" onClick={onClose} className="min-h-9 px-1 text-xs text-white/70 hover:text-white">Fermer</button>}
      </header>
      <nav className="flex h-12 items-end gap-6 overflow-x-auto px-5 text-xs text-white/50" aria-label="Navigation de la discussion">
        <span className="flex h-full items-center border-b border-white text-white">Projets</span>
        <span className="flex h-full items-center">Musique</span>
        <span className="flex h-full items-center">Informations</span>
        <Link to="/contact" className="flex h-full items-center hover:text-white">Contact</Link>
      </nav>
      <button type="button" onClick={onRestart} disabled={sending} className="flex h-[3.2rem] w-full items-center gap-3 border-t border-[#2b2b2b] px-5 text-left text-xs text-white/80 hover:bg-white/[0.04] disabled:opacity-40">
        <RotateCcw className="h-4 w-4" /> Recommencer
      </button>
    </div>
  );
}
