import React, { useEffect, useRef, useState } from "react";
import { ArrowUpRight, MapPin, Plus, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AssistantMessage from "@/components/assistant/AssistantMessage";
import ConciergeHeader from "@/components/assistant/ConciergeHeader";
import MapLocationRefiner from "@/components/assistant/MapLocationRefiner";

const STORAGE_KEY = "aime_concierge_conversation";
const suggestions = ["Parler d’un projet numérique", "Réserver une prestation musicale", "Post-it : noter une idée ici"];

export default function AimeConcierge({ embedded = false, starter = "", context, onClose }) {
  const [conversationId, setConversationId] = useState("");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState(starter);
  const [sending, setSending] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [validatedPlace, setValidatedPlace] = useState(null);
  const conversationRef = useRef(null);
  const endRef = useRef(null);
  const sentContextRef = useRef("");

  useEffect(() => {
    let active = true;
    const start = async () => {
      const savedId = localStorage.getItem(STORAGE_KEY);
      let conversation;
      try { conversation = savedId ? await base44.agents.getConversation(savedId) : null; } catch { conversation = null; }
      if (!conversation) {
        conversation = await base44.agents.createConversation({ agent_name: "aime_concierge", metadata: { name: "Conversation site", description: "Accueil et demande client" } });
        localStorage.setItem(STORAGE_KEY, conversation.id);
      }
      if (active) { conversationRef.current = conversation; setConversationId(conversation.id); setMessages(conversation.messages || []); }
    };
    start();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!conversationId) return undefined;
    return base44.agents.subscribeToConversation(conversationId, (data) => {
      conversationRef.current = data;
      setMessages(data.messages || []);
      if (data.messages?.at(-1)?.role === "assistant") setSending(false);
    });
  }, [conversationId]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  useEffect(() => {
    if (!context?.requestId || !conversationId || !conversationRef.current || sentContextRef.current === context.requestId) return;
    sentContextRef.current = context.requestId;
    setShowMap(false);
    setValidatedPlace(null);
    if (!context.autoSend || !context.prompt) return;
    setSending(true);
    base44.agents.addMessage(conversationRef.current, {
      role: "user",
      content: `Contexte vérifiable — page active : ${window.location.pathname}. Carte de parcours sélectionnée : ${context.card?.title || "non précisée"}; intention : ${context.card?.subtitle || "découverte"}. Demande utilisateur : ${context.prompt}`,
    }).catch(() => setSending(false));
  }, [context, conversationId]);

  const send = async (text = input) => {
    const content = text.trim();
    if (!content || !conversationRef.current || sending) return;
    const annotation = content.match(/^(?:post[- ]?it|note)\s*:\s*(.*)$/i);
    if (annotation) window.dispatchEvent(new CustomEvent("aime:create-annotation", { detail: { text: annotation[1].trim() } }));
    setInput("");
    setSending(true);
    await base44.agents.addMessage(conversationRef.current, { role: "user", content });
  };

  const restart = async () => {
    if (sending) return;
    setSending(true);
    const conversation = await base44.agents.createConversation({ agent_name: "aime_concierge", metadata: { name: "Conversation site", description: "Accueil et demande client" } });
    localStorage.setItem(STORAGE_KEY, conversation.id);
    conversationRef.current = conversation;
    setConversationId(conversation.id);
    setMessages([]);
    setInput(starter);
    setSending(false);
  };

  return (
    <section className={embedded ? "flex h-[min(72vh,46rem)] flex-col overflow-hidden rounded-[1.6rem] border border-[#2b2b2b] bg-black text-white shadow-2xl" : "flex h-[min(76vh,43rem)] flex-col overflow-hidden rounded-[1.6rem] border border-[#2b2b2b] bg-black text-white shadow-2xl"} aria-label="Assistant AIME Concierge">
      <ConciergeHeader onClose={onClose} onRestart={restart} sending={sending} />
      <div className="flex-1 space-y-4 overflow-y-auto px-4 py-5" aria-live="polite">
        {context?.card && <article className="grid grid-cols-[5rem_1fr] gap-3 rounded-[1.35rem] border border-[#303030] bg-white/[.035] p-2"><img src={context.card.imageUrl} alt="" className="size-20 rounded-[1rem] object-cover" /><div className="self-center"><p className="text-[9px] uppercase tracking-[.18em] text-white/40">Votre rôle</p><b className="mt-1 block text-xl">{context.card.title}</b><span className="text-xs text-white/52">{context.card.subtitle}</span></div></article>}
        {context?.response && <div className="flex items-end gap-2"><span className="mb-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-[#343434] text-[0.55rem] text-white/80">AIME</span><div className="max-w-[84%] rounded-[1.2rem] rounded-bl-none bg-[#202020] px-3 py-2.5 text-[0.8rem] leading-[1.5] text-white/90">{context.response}</div></div>}
        {context?.card && <div className="grid grid-cols-2 gap-2"><a href="/systeme-aime#passeport-vivant" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-[#303030] bg-white/[.035] px-3 text-xs text-white/75 hover:border-[#454545] hover:bg-white/[.07] hover:text-white">Ouvrir mon parcours <ArrowUpRight size={13} /></a><button type="button" onClick={() => setShowMap((value) => !value)} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-[#303030] bg-white/[.035] px-3 text-xs text-white/75 hover:border-[#454545] hover:bg-white/[.07] hover:text-white"><MapPin size={13} />Préciser un lieu</button></div>}
        {showMap && <MapLocationRefiner onValidate={(location) => { setValidatedPlace(location); setShowMap(false); }} />}
        {validatedPlace && <div className="flex items-end gap-2"><span className="mb-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-[#343434] text-[0.55rem] text-white/80">AIME</span><div className="max-w-[84%] rounded-[1.2rem] rounded-bl-none bg-[#202020] px-3 py-2.5 text-[0.8rem] leading-[1.5] text-white/90">Position précisée. Je peux maintenant la relier au moment, au trajet et aux personnes autorisées — après votre confirmation.</div></div>}
        {!messages.length && !context?.card && <div className="flex items-end gap-2"><span className="mb-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-[#343434] text-[0.55rem] text-white/80">AIME</span><div className="max-w-[78%] rounded-[1.2rem] rounded-bl-none bg-[#202020] px-3 py-2.5 text-[0.8rem] leading-[1.45] text-white/90">Bonjour, je suis l’assistant de Matthieu. Je peux répondre à vos questions ou préparer votre demande avec vous, jusqu’à sa confirmation.</div></div>}
        {!messages.length && !context?.card && <div className="flex flex-col items-end gap-2">{suggestions.map((label) => <button key={label} onClick={() => send(label)} className="rounded-full bg-white px-3.5 py-2 text-xs text-black hover:bg-white/85">{label}</button>)}</div>}
        {messages.map((message, index) => <AssistantMessage key={`${message.role}-${index}`} message={message} />)}
        {sending && <div className="flex items-center gap-2 pl-10 text-xs text-white/60"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#242424] text-base tracking-[0.12em]">•••</span>AIME Concierge écrit…</div>}
        <div ref={endRef} />
      </div>
      <form onSubmit={(event) => { event.preventDefault(); send(); }} className="flex min-h-[4.6rem] items-center gap-2 border-t border-[#2b2b2b] p-1.5"><span className="aime-launcher grid size-14 shrink-0 place-items-center rounded-full text-white"><Plus className="h-6 w-6" /></span><label className="sr-only" htmlFor="aime-assistant-message">Votre message</label><textarea id="aime-assistant-message" rows="1" value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }} placeholder="Parler à AIME…" className="min-h-12 flex-1 resize-none rounded-full border border-[#303030] bg-white/[.05] px-4 py-3.5 text-xs text-white outline-none placeholder:text-white/35 focus:border-[#484848]" /><button type="submit" disabled={sending || !input.trim()} className="grid size-12 shrink-0 place-items-center rounded-full bg-white text-black disabled:opacity-40" aria-label="Envoyer"><Send className="h-4 w-4" /></button></form>
    </section>
  );
}
