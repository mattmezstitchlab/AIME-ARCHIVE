import React, { useMemo, useRef, useState } from "react";
import { Check, LocateFixed, MapPin, RotateCcw } from "lucide-react";

const INITIAL_OFFSET = { x: -18, y: 12 };

export default function MapLocationRefiner({ onValidate }) {
  const [offset, setOffset] = useState(INITIAL_OFFSET);
  const [dragging, setDragging] = useState(false);
  const dragRef = useRef(null);
  const location = useMemo(() => ({
    latitude: 50.63261 - offset.y * 0.000018,
    longitude: 3.05858 - offset.x * 0.000021,
  }), [offset]);

  const startDrag = (event) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = { x: event.clientX, y: event.clientY, offset };
    setDragging(true);
  };
  const moveDrag = (event) => {
    if (!dragRef.current) return;
    setOffset({
      x: dragRef.current.offset.x + event.clientX - dragRef.current.x,
      y: dragRef.current.offset.y + event.clientY - dragRef.current.y,
    });
  };
  const stopDrag = () => {
    dragRef.current = null;
    setDragging(false);
  };

  return (
    <section className="overflow-hidden rounded-[1.35rem] border border-[#303030] bg-[#101010]" aria-label="Préciser le lieu sur la carte">
      <div className="flex items-center justify-between gap-4 border-b border-[#2b2b2b] px-4 py-3">
        <div><p className="text-[9px] uppercase tracking-[.2em] text-white/40">Position du moment</p><p className="mt-1 text-xs text-white/80">Faites glisser la carte sous le pointeur.</p></div>
        <button type="button" onClick={() => setOffset(INITIAL_OFFSET)} className="grid size-9 place-items-center rounded-full border border-[#303030] text-white/60 hover:border-[#454545] hover:text-white" aria-label="Recentrer la carte"><RotateCcw size={14} /></button>
      </div>
      <div
        className={`relative h-52 touch-none overflow-hidden bg-[#171717] ${dragging ? "cursor-grabbing" : "cursor-grab"}`}
        onPointerDown={startDrag}
        onPointerMove={moveDrag}
        onPointerUp={stopDrag}
        onPointerCancel={stopDrag}
      >
        <div className="absolute inset-[-8rem] transition-[filter] duration-200" style={{ transform: `translate3d(${offset.x}px, ${offset.y}px, 0)` }}>
          <div className="absolute inset-0 opacity-80 [background-image:linear-gradient(rgba(255,255,255,.075)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.075)_1px,transparent_1px)] [background-size:44px_44px]" />
          <div className="absolute left-[8%] top-[42%] h-5 w-[84%] -rotate-6 rounded-full border-y border-cyan-300/20 bg-cyan-300/[.06]" />
          <div className="absolute left-[48%] top-[5%] h-[90%] w-7 rotate-[16deg] rounded-full border-x border-fuchsia-300/20 bg-fuchsia-300/[.05]" />
          <div className="absolute left-[28%] top-[25%] size-28 rounded-[2rem] border border-white/10 bg-white/[.035]" />
          <div className="absolute bottom-[22%] right-[19%] h-20 w-36 rounded-[1.6rem] border border-white/10 bg-white/[.035]" />
          <span className="absolute left-[24%] top-[34%] text-[9px] uppercase tracking-[.16em] text-white/30">Jardin nord</span>
          <span className="absolute bottom-[28%] right-[26%] text-[9px] uppercase tracking-[.16em] text-white/30">Maison privée</span>
        </div>
        <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-full text-fuchsia-300 drop-shadow-[0_4px_12px_rgba(244,114,182,.55)]"><MapPin size={38} fill="currentColor" strokeWidth={1.4} /></div>
        <div className="pointer-events-none absolute left-1/2 top-1/2 size-5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/70 bg-white/15 shadow-[0_0_0_10px_rgba(255,255,255,.04)]" />
        <div className="pointer-events-none absolute bottom-3 left-3 inline-flex items-center gap-2 rounded-full bg-black/75 px-3 py-2 text-[9px] uppercase tracking-[.12em] text-white/60 backdrop-blur"><LocateFixed size={12} /> Pointeur fixe · précision libre</div>
      </div>
      <div className="grid gap-3 p-3 sm:grid-cols-[1fr_auto] sm:items-center">
        <div className="min-w-0 rounded-2xl bg-white/[.055] px-4 py-3"><p className="truncate text-xs text-white/85">Jardin nord · emplacement précisé</p><p className="mt-1 font-mono text-[9px] text-white/35">{location.latitude.toFixed(5)}, {location.longitude.toFixed(5)}</p></div>
        <button type="button" onClick={() => onValidate?.(location)} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-white px-5 text-xs font-semibold text-black"><Check size={14} />Valider ce point</button>
      </div>
    </section>
  );
}
