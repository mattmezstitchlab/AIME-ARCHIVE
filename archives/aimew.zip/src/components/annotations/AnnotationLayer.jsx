import { createPortal } from "react-dom";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Check, Eye, EyeOff, Grip, MessageCircle, PenLine, Plus, Sparkles, Trash2, X } from "lucide-react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

const COLORS = {
  yellow: "bg-[#f6e36a] text-[#211f12]",
  pink: "bg-[#ff9dcb] text-[#2d1320]",
  blue: "bg-[#91dcff] text-[#10232d]",
  green: "bg-[#9ee6ad] text-[#102819]",
  violet: "bg-[#c2a7ff] text-[#201631]",
};

const colorNames = { yellow: "Jaune", pink: "Rose", blue: "Bleu", green: "Vert", violet: "Violet" };
const storageKey = (path) => `aime-annotations:${path}`;

export default function AnnotationLayer() {
  const { pathname } = useLocation();
  const { isAuthenticated, user } = useAuth();
  const [notes, setNotes] = useState([]);
  const [active, setActive] = useState(false);
  const [visible, setVisible] = useState(true);
  const [draft, setDraft] = useState(null);
  const [selected, setSelected] = useState(null);
  const [reply, setReply] = useState("");
  const [pageHeight, setPageHeight] = useState(() => document.documentElement.scrollHeight);
  const dragRef = useRef(null);
  const suppressClickRef = useRef(null);
  const hidden = pathname.startsWith("/admin");

  const storeLocal = useCallback((items) => {
    localStorage.setItem(storageKey(pathname), JSON.stringify(items));
    setNotes(items);
  }, [pathname]);

  const load = useCallback(async () => {
    if (!isAuthenticated) {
      try { setNotes(JSON.parse(localStorage.getItem(storageKey(pathname)) || "[]")); } catch { setNotes([]); }
      return;
    }
    try {
      setNotes(await base44.entities.Annotation.filter({ page_path: pathname }, "created_date", 300));
    } catch {
      try { setNotes(JSON.parse(localStorage.getItem(storageKey(pathname)) || "[]")); } catch { setNotes([]); }
    }
  }, [isAuthenticated, pathname]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!isAuthenticated) return undefined;
    return base44.entities.Annotation.subscribe((event) => {
      if (event.data?.page_path && event.data.page_path !== pathname) return;
      setNotes((current) => {
        if (event.type === "delete") return current.filter((note) => note.id !== event.id);
        const incoming = { ...event.data, id: event.id || event.data?.id };
        const exists = current.some((note) => note.id === incoming.id);
        return exists ? current.map((note) => note.id === incoming.id ? { ...note, ...incoming } : note) : [...current, incoming];
      });
    });
  }, [isAuthenticated, pathname]);

  useEffect(() => {
    const updateHeight = () => setPageHeight(document.documentElement.scrollHeight);
    updateHeight();
    const observer = new ResizeObserver(updateHeight);
    observer.observe(document.documentElement);
    window.addEventListener("resize", updateHeight);
    return () => { observer.disconnect(); window.removeEventListener("resize", updateHeight); };
  }, [pathname]);

  const beginDraft = useCallback(({ xPercent, yPercent, text = "", source = "manual", sectionId = "" }) => {
    setDraft({ page_path: pathname, section_id: sectionId, x_percent: xPercent, y_percent: yPercent, text, color: source === "agent" ? "violet" : "yellow", source, status: "open", author_name: user?.full_name || user?.email || "Moi", replies: [] });
    setActive(false);
    setVisible(true);
  }, [pathname, user]);

  useEffect(() => {
    const fromAgent = (event) => beginDraft({ xPercent: 72, yPercent: Math.min(96, ((window.scrollY + window.innerHeight * .48) / Math.max(1, document.documentElement.scrollHeight)) * 100), text: event.detail?.text || "", source: "agent", sectionId: event.detail?.sectionId || "" });
    window.addEventListener("aime:create-annotation", fromAgent);
    return () => window.removeEventListener("aime:create-annotation", fromAgent);
  }, [beginDraft]);

  useEffect(() => {
    if (!active) return undefined;
    const place = (event) => {
      if (event.target.closest?.("[data-annotation-ui]")) return;
      event.preventDefault();
      event.stopPropagation();
      const section = event.target.closest?.("[id]");
      beginDraft({ xPercent: Math.max(6, Math.min(94, (event.clientX / window.innerWidth) * 100)), yPercent: Math.max(1, Math.min(99, ((event.clientY + window.scrollY) / Math.max(1, document.documentElement.scrollHeight)) * 100)), sectionId: section?.id || "" });
    };
    document.addEventListener("click", place, true);
    return () => document.removeEventListener("click", place, true);
  }, [active, beginDraft]);

  const saveDraft = async () => {
    const text = draft?.text?.trim();
    if (!text) return;
    const payload = { ...draft, text };
    delete payload.id;
    if (isAuthenticated) {
      try {
        const saved = draft.id ? await base44.entities.Annotation.update(draft.id, payload) : await base44.entities.Annotation.create(payload);
        setNotes((current) => draft.id ? current.map((note) => note.id === draft.id ? saved : note) : [...current, saved]);
        setDraft(null);
        return;
      } catch { /* local fallback below */ }
    }
    const local = { ...payload, id: draft.id || `local-${Date.now()}`, created_date: draft.created_date || new Date().toISOString() };
    storeLocal(draft.id ? notes.map((note) => note.id === draft.id ? local : note) : [...notes, local]);
    setDraft(null);
  };

  const remove = async (note) => {
    if (isAuthenticated && !String(note.id).startsWith("local-")) {
      try { await base44.entities.Annotation.delete(note.id); } catch { return; }
      setNotes((current) => current.filter((item) => item.id !== note.id));
    } else storeLocal(notes.filter((item) => item.id !== note.id));
    setSelected(null);
  };

  const addReply = async () => {
    if (!reply.trim() || !selected) return;
    const replies = [...(selected.replies || []), { text: reply.trim(), author: user?.full_name || user?.email || "Moi", created_at: new Date().toISOString() }];
    const updated = { ...selected, replies };
    if (isAuthenticated && !String(selected.id).startsWith("local-")) {
      try { await base44.entities.Annotation.update(selected.id, { replies }); } catch { return; }
      setNotes((current) => current.map((item) => item.id === selected.id ? updated : item));
    } else storeLocal(notes.map((item) => item.id === selected.id ? updated : item));
    setSelected(updated);
    setReply("");
  };

  const persistPosition = useCallback(async (note, xPercent, yPercent) => {
    const updated = { ...note, x_percent: xPercent, y_percent: yPercent };
    setNotes((current) => {
      const next = current.map((item) => item.id === note.id ? updated : item);
      if (!isAuthenticated || String(note.id).startsWith("local-")) localStorage.setItem(storageKey(pathname), JSON.stringify(next));
      return next;
    });
    if (isAuthenticated && !String(note.id).startsWith("local-")) {
      try { await base44.entities.Annotation.update(note.id, { x_percent: xPercent, y_percent: yPercent }); } catch { /* La position optimiste reste visible. */ }
    }
  }, [isAuthenticated, pathname]);

  const beginDrag = (event, note) => {
    if (event.button !== 0) return;
    event.currentTarget.setPointerCapture?.(event.pointerId);
    dragRef.current = { pointerId: event.pointerId, note, startX: event.clientX, startY: event.clientY, xPercent: note.x_percent, yPercent: note.y_percent, moved: false };
  };

  const moveDrag = (event) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (!drag.moved && Math.hypot(dx, dy) < 5) return;
    event.preventDefault();
    drag.moved = true;
    drag.xPercent = Math.max(5, Math.min(95, drag.note.x_percent + (dx / window.innerWidth) * 100));
    drag.yPercent = Math.max(.5, Math.min(99.5, drag.note.y_percent + (dy / Math.max(1, pageHeight)) * 100));
    setNotes((current) => current.map((item) => item.id === drag.note.id ? { ...item, x_percent: drag.xPercent, y_percent: drag.yPercent } : item));
  };

  const endDrag = (event) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    if (drag.moved) {
      suppressClickRef.current = drag.note.id;
      persistPosition(drag.note, drag.xPercent, drag.yPercent);
    }
    dragRef.current = null;
  };

  const openNotes = useMemo(() => notes.filter((note) => note.status !== "resolved"), [notes]);
  if (hidden || typeof document === "undefined") return null;

  return createPortal(<>
    {visible && openNotes.map((note, index) => <button key={note.id} type="button" data-annotation-ui onPointerDown={(event) => beginDrag(event, note)} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag} onClick={() => { if (suppressClickRef.current === note.id) { suppressClickRef.current = null; return; } setSelected(note); }} className={`absolute z-[1800] w-44 origin-top-left -translate-x-1/2 cursor-grab select-none p-4 text-left shadow-2xl transition-[transform,box-shadow] hover:z-[1850] hover:scale-105 active:cursor-grabbing ${COLORS[note.color] || COLORS.yellow}`} style={{ top: `${(note.y_percent / 100) * pageHeight}px`, left: `${note.x_percent}%`, transform: `translateX(-50%) rotate(${index % 2 ? 1.5 : -1.5}deg)`, fontFamily: '"Bradley Hand", "Comic Sans MS", cursive', touchAction: "none" }} aria-label={`Annotation : ${note.text}. Déplaçable par glisser-déposer.`}><span className="flex items-center justify-between gap-2 text-[10px] font-sans font-bold uppercase tracking-widest opacity-45"><span>{note.source === "agent" ? "AIME agent" : note.author_name || "Post-it"}</span><Grip size={13} aria-hidden="true" /></span><span className="mt-3 block text-lg leading-6">{note.text}</span>{note.replies?.length > 0 && <span className="mt-3 flex items-center gap-1 font-sans text-[10px] opacity-50"><MessageCircle size={11} />{note.replies.length}</span>}</button>)}

    <div data-annotation-ui className="fixed bottom-5 right-4 z-[2600] flex items-center gap-2 sm:bottom-7 sm:right-7">
      <button type="button" onClick={() => setVisible((value) => !value)} className="grid size-11 place-items-center rounded-full border border-black/10 bg-white text-black shadow-xl" aria-label={visible ? "Masquer les annotations" : "Afficher les annotations"}>{visible ? <Eye size={17} /> : <EyeOff size={17} />}</button>
      <button type="button" onClick={() => setActive((value) => !value)} className={`flex min-h-12 items-center gap-2 rounded-full px-5 text-sm font-semibold shadow-2xl ${active ? "bg-[#f6e36a] text-black" : "bg-white text-black"}`} aria-pressed={active}><PenLine size={17} />{active ? "Cliquez sur la page" : "Annoter"}<span className="rounded-full bg-black/8 px-2 py-0.5 text-[10px]">{openNotes.length}</span></button>
    </div>

    {(draft || selected) && <div data-annotation-ui className="fixed inset-0 z-[2700] flex items-end justify-center bg-black/45 p-4 backdrop-blur-sm sm:items-center" onMouseDown={(event) => { if (event.target === event.currentTarget) { setDraft(null); setSelected(null); } }}>
      {draft ? <section className={`w-full max-w-md p-6 shadow-2xl ${COLORS[draft.color]}`} style={{ fontFamily: '"Bradley Hand", "Comic Sans MS", cursive' }}><header className="flex items-center justify-between font-sans"><p className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest"><Sparkles size={14} />{draft.source === "agent" ? "Post-it proposé par l’agent" : "Nouveau post-it"}</p><button onClick={() => setDraft(null)} aria-label="Fermer"><X size={18} /></button></header><textarea autoFocus value={draft.text} onChange={(event) => setDraft({ ...draft, text: event.target.value })} placeholder="Écrivez comme au marqueur…" rows="5" className="mt-6 w-full resize-none border-0 bg-transparent text-2xl leading-8 outline-none placeholder:text-current/35" /><div className="mt-5 flex items-center justify-between gap-4 font-sans"><div className="flex gap-2">{Object.keys(COLORS).map((color) => <button key={color} type="button" onClick={() => setDraft({ ...draft, color })} aria-label={colorNames[color]} className={`size-7 rounded-full border-2 ${COLORS[color]} ${draft.color === color ? "border-black" : "border-black/10"}`} />)}</div><button type="button" onClick={saveDraft} disabled={!draft.text.trim()} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-black px-5 text-sm font-semibold text-white disabled:opacity-35"><Check size={15} />Poser</button></div></section> : <section className={`w-full max-w-md p-6 shadow-2xl ${COLORS[selected.color]}`}><header className="flex items-start justify-between gap-4"><div><p className="text-[10px] font-bold uppercase tracking-widest opacity-45">{selected.source === "agent" ? "AIME agent" : selected.author_name || "Annotation"}</p><p className="mt-3 text-2xl leading-8" style={{ fontFamily: '"Bradley Hand", "Comic Sans MS", cursive' }}>{selected.text}</p></div><button onClick={() => setSelected(null)} aria-label="Fermer"><X size={18} /></button></header><div className="mt-6 space-y-2 border-t border-black/15 pt-4">{(selected.replies || []).map((item, index) => <div key={`${item.created_at}-${index}`} className="rounded-2xl bg-white/35 px-4 py-3"><p className="text-xs leading-5">{item.text}</p><span className="mt-1 block text-[9px] uppercase tracking-wider opacity-45">{item.author}</span></div>)}<div className="flex gap-2"><input value={reply} onChange={(event) => setReply(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") addReply(); }} placeholder="Ajouter un commentaire…" className="min-w-0 flex-1 rounded-full border border-black/15 bg-white/35 px-4 text-sm outline-none" /><button onClick={addReply} className="grid size-11 shrink-0 place-items-center rounded-full bg-black text-white" aria-label="Ajouter"><Plus size={16} /></button></div></div><footer className="mt-5 flex justify-between"><button onClick={() => { setDraft(selected); setSelected(null); }} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-black/15 px-4 text-xs"><PenLine size={14} />Modifier</button><button onClick={() => remove(selected)} className="grid size-10 place-items-center rounded-full border border-black/15" aria-label="Supprimer"><Trash2 size={14} /></button></footer></section>}
    </div>}
  </>, document.body);
}
