import { useEffect } from "react";
import { useLocation, useNavigationType } from "react-router-dom";

const getHashId = (hash) => {
  const rawId = hash.slice(1);

  try {
    return decodeURIComponent(rawId);
  } catch {
    return rawId;
  }
};

export default function ScrollToTop() {
  const { pathname, hash } = useLocation();
  const navigationType = useNavigationType();

  useEffect(() => {
    if (hash) {
      const id = getHashId(hash);
      let attempts = 0;
      const scrollWhenReady = () => {
        const target = document.getElementById(id);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          window.clearInterval(timer);
        } else if (attempts >= 40) {
          window.clearInterval(timer);
        }
        attempts += 1;
      };
      const timer = window.setInterval(scrollWhenReady, 100);
      scrollWhenReady();
      return () => window.clearInterval(timer);
    }

    if (navigationType === "POP") return;

    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }, [pathname, hash, navigationType]);

  return null;
}
