import React from "react";
import AtlasCategoryBrowser from "@/components/portfolio/AtlasCategoryBrowser";
import HomeEditorialFeatures from "@/components/home-magazine/HomeEditorialFeatures";
import PortfolioLabSections from "@/components/portfolio/PortfolioLabSections";
import useEcosystemProjects from "@/hooks/useEcosystemProjects";
import { innovationSlugs } from "@/components/portfolio/InnovationVerticality";

export default function AtlasExperience() {
  const { projects, loading } = useEcosystemProjects();
  const archivedProjects = projects.filter((project) => !innovationSlugs.includes(project.slug));

  return (
    <div className="bg-background text-foreground">
      <HomeEditorialFeatures projects={archivedProjects} />
      <section id="atlas-complet" className="relative z-10 scroll-mt-24 py-20">
        <div className="mx-auto max-w-none">
          <div className="mb-8 flex flex-col justify-between gap-5 px-5 sm:flex-row sm:items-end sm:px-8 lg:px-12">
            <div>
              <p className="mb-4 text-xs uppercase tracking-[0.28em] text-white/55">Archives · portfolio · laboratoire</p>
              <h2 className="font-display text-4xl font-semibold tracking-[-0.05em] text-foreground sm:text-5xl">Atlas des {archivedProjects.length} recherches visibles</h2>
            </div>
            <p className="max-w-md text-sm leading-6 text-white/70">
              Les recherches, les intentions et les prototypes qui ont conduit à l’œuvre fusionnelle AIME.
            </p>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 gap-px bg-white/10 sm:grid-cols-3 lg:grid-cols-4">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => <div key={item} className="h-32 animate-pulse bg-white/[0.04]" />)}
            </div>
          ) : <AtlasCategoryBrowser projects={archivedProjects} />}
        </div>
      </section>
      <PortfolioLabSections />
    </div>
  );
}
