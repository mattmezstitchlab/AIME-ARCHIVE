import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export default function ProjectHero() {
  return (
    <header className="absolute inset-x-0 top-0 z-20 overflow-visible px-5 pb-5 pt-20 sm:px-8 lg:px-12">
      <nav className="mx-auto flex max-w-7xl flex-col gap-4" aria-label="Navigation principale">
        <div className="flex items-start justify-end gap-5">
          <Link to="/archives" className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border border-white/20 bg-black/25 px-4 text-xs font-medium text-white backdrop-blur-xl transition-colors hover:bg-white hover:text-black">Archives <ArrowUpRight className="h-4 w-4" /></Link>
        </div>
      </nav>
    </header>
  );
}
