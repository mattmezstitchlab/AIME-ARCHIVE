import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export const innovationSlugs = [
  "innovation-mariage",
  "innovation-associations",
  "innovation-marche-sport",
  "innovation-spectacle",
  "innovation-passeport-universel",
];

export default function InnovationVerticality({ projects }) {
  const innovations = innovationSlugs.map((slug) => projects.find((project) => project.slug === slug)).filter(Boolean);
  if (!innovations.length) return null;

  return (
    <section id="grandes-innovations" className="bg-white text-black">
      <header className="border-y border-black/10 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.65fr_1.35fr] lg:items-end">
          <p className="text-xs font-bold uppercase tracking-[0.28em] text-black/45">Les cinq grandes innovations · {String(innovations.length).padStart(2, "0")}</p>
          <div><h2 className="font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl lg:text-8xl">Une même architecture.<br />Cinq preuves concrètes.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-black/60">Le mariage en révèle l’ensemble le plus complet. Associations, sport, spectacle et passeport démontrent ensuite que le même moteur peut changer d’échelle et de contexte sans perdre sa logique.</p></div>
        </div>
      </header>

      {innovations.map((project, index) => (
        <article key={project.slug} id={project.slug} className="border-b border-black/10">
          <div className="relative min-h-[70svh] overflow-hidden bg-black text-white">
            {project.video_url ? <video src={project.video_url} poster={project.main_screenshot_url} autoPlay muted loop playsInline preload="metadata" aria-label={`Film ${project.title}`} className="absolute inset-0 h-full w-full object-cover" /> : project.main_screenshot_url && <img src={project.main_screenshot_url} alt={`Univers ${project.title}`} className="absolute inset-0 h-full w-full object-cover" loading="lazy" />}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/25 to-black/15" />
            <div className="relative mx-auto flex min-h-[70svh] max-w-7xl flex-col justify-between px-5 py-9 sm:px-8 lg:px-12 lg:py-12">
              <div className="flex items-center justify-between gap-5 text-xs uppercase tracking-[0.24em] text-white/65"><span>Innovation {String(index + 1).padStart(2, "0")}</span><span>{project.category}</span></div>
              <div className="max-w-5xl"><p className="text-sm uppercase tracking-[0.24em] text-white/70">{project.short_description}</p><h3 className="mt-6 font-display text-5xl font-semibold leading-[0.88] tracking-[-0.065em] sm:text-7xl lg:text-8xl">{project.title}</h3></div>
            </div>
          </div>

          <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:px-12 lg:py-24">
            <div><p className="text-xs font-bold uppercase tracking-[0.24em] text-black/45">Ce que cela change</p><p className="mt-6 font-display text-3xl font-semibold leading-tight tracking-[-0.04em] sm:text-4xl">{project.long_description}</p></div>
            <div className="grid gap-px overflow-hidden rounded-[1.5rem] border border-black/10 bg-black/10 sm:grid-cols-2">
              <div className="bg-white p-6"><p className="text-xs font-bold uppercase tracking-[0.22em] text-black/40">Avant</p><p className="mt-5 text-base leading-7 text-black/65">{project.problem}</p></div>
              <div className="bg-black p-6 text-white"><p className="text-xs font-bold uppercase tracking-[0.22em] text-white/45">Avec AIME</p><p className="mt-5 text-base leading-7 text-white/75">{project.solution}</p></div>
            </div>
          </div>

          <div className="border-t border-black/10 px-5 pb-16 sm:px-8 lg:px-12 lg:pb-24">
            <div className="mx-auto max-w-7xl">
              <div className="grid gap-px overflow-hidden border-x border-b border-black/10 bg-black/10 sm:grid-cols-2 lg:grid-cols-3">
                {(project.features || []).map((feature, featureIndex) => <div key={feature} className="min-h-36 bg-[#f5f5f2] p-6"><span className="text-xs text-black/35">{String(featureIndex + 1).padStart(2, "0")}</span><p className="mt-8 font-display text-2xl font-semibold tracking-[-0.04em]">{feature}</p></div>)}
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to={`/projects/${project.slug}`} className="inline-flex min-h-12 items-center gap-2 rounded-full bg-black px-6 text-sm text-white">Comprendre l’innovation <ArrowUpRight className="h-4 w-4" /></Link>
                {project.url && <a href={project.url} className="inline-flex min-h-12 items-center gap-2 rounded-full border border-black/15 px-6 text-sm" target="_blank" rel="noreferrer">Ouvrir la démonstration <ArrowUpRight className="h-4 w-4" /></a>}
              </div>
            </div>
          </div>
        </article>
      ))}
    </section>
  );
}
