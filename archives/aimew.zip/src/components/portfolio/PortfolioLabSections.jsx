import React from "react";

const badges = [
  "Mémoire protégée",
  "Validation humaine",
  "Présences scellées",
  "Projets reliés",
  "Accessibilité intégrée"
];

const whyCards = [
  ["Écosystème AIME", "Un même point d’entrée pour circuler entre les projets sans perdre son compte, son contexte ni ses autorisations."],
  ["Stamp Studio", "Un atelier pour créer des timbres de présence, d’intention ou d’orientation avec validation humaine."],
  ["Magazine AIME", "Une forme éditoriale pour raconter les agents, l’architecture et les futurs projets."],
  ["Access Layer", "Une couche de lisibilité, d’accessibilité et d’assistance pour rendre chaque projet plus compréhensible."]
];

export default function PortfolioLabSections() {
  return (
    <section className="relative z-10 border-y border-white/10 px-5 py-20 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl space-y-16">
        <div className="p-0 sm:p-0 lg:p-0">
          <p className="text-xs uppercase tracking-[0.28em] text-white/55">Portfolio-laboratoire AIME</p>
          <h2 className="mt-5 max-w-5xl font-display text-4xl font-semibold leading-tight tracking-[-0.05em] text-white sm:text-6xl">
            AIME — une architecture de projets pour protéger, transmettre et rendre lisible.
          </h2>
          <p className="mt-7 max-w-4xl text-base leading-8 text-white/75 sm:text-lg">
            Chaque projet AIME est pensé comme un espace : un registre, un atelier, un magazine, une interface ou un outil capable de relier mémoire, présence, protection, accessibilité et transmission.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            {badges.map((badge) => (
              <span key={badge} className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs uppercase tracking-[0.16em] text-white/75">
                {badge}
              </span>
            ))}
          </div>
          <a href="#atlas-complet" className="mt-10 inline-flex min-h-12 items-center rounded-full bg-white px-6 text-sm font-medium text-black transition-colors hover:bg-white/85">
            Explorer les projets AIME
          </a>
        </div>

        <div>
          <div className="max-w-4xl">
            <p className="text-xs uppercase tracking-[0.28em] text-white/55">Pourquoi maintenant ?</p>
            <p className="mt-5 text-2xl leading-10 text-white/85 sm:text-3xl">
              AIME avance comme un système éditorial et sensible : chaque nouvelle page doit pouvoir expliquer, protéger, orienter ou transmettre. Le numérique n’est pas seulement un support ; c’est une manière de donner une forme stable aux choses humaines.
            </p>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {whyCards.map(([title, text]) => (
              <article key={title} className="rounded-[1.6rem] border border-white/10 bg-white/[0.035] p-5 backdrop-blur-xl">
                <h3 className="font-display text-2xl font-semibold tracking-[-0.04em] text-white">{title}</h3>
                <p className="mt-4 text-sm leading-6 text-white/70">{text}</p>
              </article>
            ))}
          </div>
        </div>

        <div className="grid gap-8 rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 backdrop-blur-xl sm:p-10 lg:grid-cols-[0.8fr_1.2fr] lg:p-12">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/55">AIME Access Layer</p>
            <h2 className="mt-5 font-display text-4xl font-semibold tracking-[-0.05em] text-white sm:text-5xl">Une couche de clarté et d’accessibilité.</h2>
          </div>
          <div className="space-y-5 text-base leading-8 text-white/75">
            <p>Chaque création peut inclure une couche d’accessibilité : contraste, taille de texte, lecture simplifiée, résumé des informations essentielles, aide à la navigation et assistance à la compréhension.</p>
            <p className="rounded-2xl border border-white/10 bg-black/30 p-5 text-white/85">La technologie peut aider à clarifier, mais les décisions importantes restent humaines.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
