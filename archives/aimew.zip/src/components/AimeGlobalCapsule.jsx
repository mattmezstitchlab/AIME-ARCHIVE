import { BookOpen, CalendarDays, LayoutGrid, Map, Network, PanelsTopLeft, Plus, Settings, ShieldCheck, UserRound, WalletCards } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import EcosystemSwitcher from "@/components/EcosystemSwitcher";
import AimeNotificationPulse from "@/components/AimeNotificationPulse";
import { AIME_SHELL_CONTEXTS, aimeAccountHref } from "@/lib/aime-shell";

const ICONS = { system: PanelsTopLeft, passport: WalletCards, atlas: LayoutGrid, events: CalendarDays, registry: BookOpen, map: Map, network: Network };

function InternalLink({ href, label, icon: Icon, active = false, primary = false }) {
  return <Link to={href} aria-label={label} aria-current={active ? "page" : undefined} className={`grid size-10 shrink-0 place-items-center rounded-full transition-colors ${primary ? "bg-black text-white" : active ? "bg-black/10" : "hover:bg-black/5"}`}><Icon size={17} /></Link>;
}

export default function AimeGlobalCapsule({ currentApp, showAdmin = false, notifications = [], notificationsOpen = false, onNotifications, embedded = false }) {
  const { pathname } = useLocation();
  const context = AIME_SHELL_CONTEXTS[currentApp];
  return <header className={embedded ? "relative z-20 mx-auto w-fit max-w-[calc(100vw-1rem)]" : "fixed left-1/2 top-3 z-[2000] w-fit max-w-[calc(100vw-1rem)] -translate-x-1/2"}>
    <nav aria-label="Navigation AIME commune" className="flex items-center gap-0.5 rounded-full border border-black/10 bg-white/95 p-1.5 text-black shadow-2xl backdrop-blur-xl">
      <EcosystemSwitcher currentApp={currentApp} />
      {context.actions.map((action) => <InternalLink key={action.href} {...action} icon={ICONS[action.icon]} active={pathname === action.href.split("#")[0]} />)}
      <a href={aimeAccountHref(currentApp)} aria-label="Compte AIME commun" className="grid size-10 shrink-0 place-items-center rounded-full hover:bg-black/5"><UserRound size={17} /></a>
      <a href={aimeAccountHref(currentApp, "reglages")} aria-label="Paramètres AIME communs" className="hidden size-10 shrink-0 place-items-center rounded-full hover:bg-black/5 min-[390px]:grid"><Settings size={17} /></a>
      {showAdmin && <InternalLink href="/admin" label="Studio Admin" icon={ShieldCheck} active={pathname === "/admin"} />}
      <InternalLink {...context.create} icon={Plus} primary />
      {onNotifications && <AimeNotificationPulse signals={notifications} active={notificationsOpen} onClick={onNotifications} />}
    </nav>
  </header>;
}
