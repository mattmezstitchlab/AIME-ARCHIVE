import { ArrowRight, ChevronDown, ExternalLink } from "lucide-react";
import { AIME_MENU_GROUPS } from "@/lib/aime-ecosystem";

export default function EcosystemSwitcher({ currentApp, className = "" }) {
  return (
    <details className={`group relative ${className}`}>
      <summary
        className="flex min-h-10 cursor-pointer list-none items-center gap-1 rounded-full px-3 text-sm font-semibold tracking-[-.03em] hover:bg-white/10 [&::-webkit-details-marker]:hidden"
        aria-label="Ouvrir les applications AIME"
      >
        AIME<sup className="ml-0.5 text-[7px]">®</sup>
        <ChevronDown className="ml-0.5 size-3.5 transition-transform group-open:rotate-180" aria-hidden="true" />
      </summary>
      <nav
        aria-label="Écosystème AIME"
        className="fixed left-1/2 top-[4.5rem] max-h-[calc(100vh-6rem)] w-[min(94vw,66rem)] -translate-x-1/2 overflow-y-auto rounded-[2rem] border border-[#292929] bg-black/95 p-3 text-white shadow-2xl backdrop-blur-2xl sm:p-5"
      >
        <div className="flex items-end justify-between gap-6 border-b border-[#252525] px-2 pb-5 pt-2">
          <div><p className="text-[9px] font-semibold uppercase tracking-[.22em] text-white/38">Le Monde AIME</p><strong className="mt-2 block text-2xl tracking-[-.045em]">Tout voir en un clin d’œil.</strong></div>
          <a href={currentApp === "lab" ? "/" : "https://app.lemondeaime.com"} className="hidden items-center gap-2 text-[10px] text-white/45 hover:text-white sm:inline-flex">Accueil <ArrowRight className="size-3"/></a>
        </div>
        <div className="grid gap-3 pt-3 lg:grid-cols-3">
          {AIME_MENU_GROUPS.map((group) => <section key={group.title} className="rounded-[1.5rem] bg-white/[.035] p-3">
            <div className="px-2 py-2"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-white/72">{group.title}</p><p className="mt-1 text-[10px] leading-4 text-white/35">{group.description}</p></div>
            <div className="mt-2 space-y-1">{group.items.map((item) => <a key={item.label} href={item.href} target={item.external ? "_blank" : undefined} rel={item.external ? "noreferrer" : undefined} className="group/item flex items-start gap-3 rounded-2xl px-2 py-2.5 transition-colors hover:bg-white/[.075]">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-white/22 transition-colors group-hover/item:bg-cyan-200"/>
              <span className="min-w-0 flex-1"><strong className="flex items-center gap-1.5 text-[12px] font-medium text-white/88">{item.label}{item.external && <ExternalLink className="size-2.5 text-white/28"/>}</strong><span className="mt-1 block text-[10px] leading-4 text-white/38">{item.description}</span></span>
            </a>)}</div>
          </section>)}
        </div>
      </nav>
    </details>
  );
}
