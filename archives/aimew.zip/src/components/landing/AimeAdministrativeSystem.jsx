import { useMemo, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  Check,
  ChevronRight,
  CircleAlert,
  Clock3,
  FileCheck2,
  FileText,
  Fingerprint,
  Link2,
  Search,
  ShieldCheck,
  Sparkles,
  UserRoundCheck,
} from "lucide-react";
import {
  ADMINISTRATIVE_DOCUMENTS,
  ADMINISTRATIVE_IDENTITY_EVENTS,
  ADMINISTRATIVE_ROLES,
  DOCUMENT_REGISTRY_NOTICE,
  INTERMITTENT_FLOW,
  PENNYLANE_COMPARISON,
} from "@/data/aimeAdministrativeRegistry";
import AimeAdministrativeDesk from "@/components/landing/AimeAdministrativeDesk";

const identityState = {
  verified: { label: "Consolidé", className: "bg-emerald-300 text-black", icon: Check },
  missing: { label: "Rupture", className: "bg-orange-400 text-black", icon: CircleAlert },
  review: { label: "À confirmer", className: "bg-violet-400 text-black", icon: Clock3 },
};

const flowState = {
  ready: { label: "Prêt", dot: "bg-emerald-300" },
  attention: { label: "À sécuriser", dot: "bg-orange-400" },
  planned: { label: "À produire", dot: "bg-white/25" },
};

function AdministrativeAudit() {
  const [activeEvent, setActiveEvent] = useState(ADMINISTRATIVE_IDENTITY_EVENTS[3]);

  return <section id="administration-vivante" className="border-y border-[#242424] bg-[#090909] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-9 lg:grid-cols-[.72fr_1.28fr]">
        <div>
          <p className="text-xs uppercase tracking-[.28em] text-white/40">07 · Administration vivante</p>
          <span className="mt-7 inline-flex items-center gap-2 rounded-full border border-[#303030] px-4 py-2 text-[10px] uppercase tracking-[.16em] text-white/55"><ShieldCheck size={13} /> Validation humaine obligatoire</span>
        </div>
        <div>
          <h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Retrouver la preuve.<br />Pas inventer l’histoire.</h2>
          <p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Quand un deuxième mariage, une dissolution ou une ancienne identité manque, AIME matérialise le trou, retrouve les pièces autorisées et prépare la demande au bon organisme. Le dossier reste bloqué tant qu’un agent habilité n’a pas confirmé la continuité.</p>
        </div>
      </div>

      <div className="mt-16 overflow-hidden rounded-[2rem] border border-[#242424] bg-[#0d0d0d]">
        <div className="grid lg:grid-cols-[1.25fr_.75fr]">
          <div className="border-b border-[#242424] p-6 sm:p-9 lg:border-b-0 lg:border-r">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div><p className="text-[10px] uppercase tracking-[.24em] text-white/35">Ligne de preuves · cas simulé</p><h3 className="mt-3 font-display text-3xl font-semibold tracking-[-.04em]">Trois mariages, une rupture documentaire</h3></div>
              <span className="rounded-full bg-orange-400/10 px-4 py-2 text-[10px] font-bold uppercase tracking-[.16em] text-orange-300">1 incohérence structurante</span>
            </div>

            <div className="mt-10 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {ADMINISTRATIVE_IDENTITY_EVENTS.map((event) => {
                const state = identityState[event.state];
                const Icon = state.icon;
                const selected = activeEvent.label === event.label;
                return <button key={`${event.year}-${event.label}`} type="button" onClick={() => setActiveEvent(event)} className={`min-h-44 rounded-[1.4rem] border p-5 text-left transition-colors ${selected ? "border-[#555] bg-[#171717]" : "border-[#272727] bg-black hover:border-[#3a3a3a]"}`}>
                  <div className="flex items-center justify-between gap-3"><span className="font-mono text-xs text-white/35">{event.year}</span><span className={`inline-flex size-7 items-center justify-center rounded-full ${state.className}`}><Icon size={13} /></span></div>
                  <h4 className="mt-6 text-lg font-semibold">{event.label}</h4>
                  <p className="mt-2 text-xs text-white/40">{event.source}</p>
                  <p className="mt-4 text-[10px] uppercase tracking-[.13em] text-white/30">{state.label}</p>
                </button>;
              })}
            </div>
          </div>

          <aside className="flex min-h-[32rem] flex-col p-6 sm:p-9">
            <div className="flex size-12 items-center justify-center rounded-full bg-gradient-to-br from-orange-400 via-fuchsia-500 to-blue-500 text-black"><Fingerprint size={18} /></div>
            <p className="mt-8 text-[10px] uppercase tracking-[.24em] text-white/35">Événement sélectionné</p>
            <h3 className="mt-3 font-display text-4xl font-semibold tracking-[-.05em]">{activeEvent.label}</h3>
            <p className="mt-4 text-sm leading-7 text-white/55">{activeEvent.detail}</p>

            <div className="mt-8 space-y-3 border-t border-[#2b2b2b] pt-6 text-xs text-white/55">
              <p className="flex items-center justify-between gap-4"><span>Source attendue</span><strong className="text-right font-medium text-white/80">Acte · mention · décision</strong></p>
              <p className="flex items-center justify-between gap-4"><span>Accès</span><strong className="text-right font-medium text-white/80">Agent habilité</strong></p>
              <p className="flex items-center justify-between gap-4"><span>Décision</span><strong className="text-right font-medium text-white/80">Jamais automatique</strong></p>
            </div>

            <div className="mt-auto rounded-[1.4rem] border border-[#2b2b2b] bg-black p-5">
              <p className="flex items-center gap-2 text-xs font-semibold"><Link2 size={14} /> Prochaine action proposée</p>
              <p className="mt-3 text-xs leading-6 text-white/45">Préparer une demande de pièce, tracer son origine, puis rapprocher les événements sans exposer le NIR dans l’interface.</p>
              <button type="button" className="mt-5 inline-flex min-h-11 w-full items-center justify-between rounded-full bg-white px-5 text-xs font-semibold text-black">Préparer la demande <ArrowRight size={14} /></button>
            </div>
          </aside>
        </div>
      </div>

      <div className="mt-5 grid gap-px overflow-hidden rounded-[1.6rem] bg-[#242424] sm:grid-cols-2 lg:grid-cols-4">
        {["MSA · protection sociale agricole", "CAF · droits et composition familiale", "Urssaf · emploi et cotisations", "État civil · actes et mentions"].map((item) => <div key={item} className="bg-[#101010] p-5 text-xs leading-6 text-white/50">{item}</div>)}
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["01", "Chronologie fragmentée", "Un état courant ne remplace pas les actes, mentions et décisions qui prouvent chaque transition."],
          ["02", "Référentiels distribués", "État civil, protection sociale et emploi portent des fragments différents, avec leurs propres dates de mise à jour."],
          ["03", "Accès réglementé", "Le NIR et les données d’état civil ne deviennent jamais un moteur de recherche ouvert : chaque accès dépend d’une finalité et d’une habilitation."],
          ["04", "Décision humaine", "AIME rapproche et prépare. L’agent compétent confirme la continuité, la pièce opposable et l’effet sur les droits."],
        ].map(([number, title, text]) => <article key={number} className="rounded-[1.4rem] border border-[#282828] bg-[#0d0d0d] p-5">
          <span className="font-mono text-[10px] text-white/25">{number}</span>
          <h3 className="mt-5 text-sm font-semibold">{title}</h3>
          <p className="mt-3 text-xs leading-6 text-white/42">{text}</p>
        </article>)}
      </div>

      <p className="mt-5 max-w-5xl text-[11px] leading-6 text-white/35">« Grid / GDE 44 » est conservé comme signal terrain rapporté, faute de documentation publique identifiable. L’audit de production devra confirmer le nom, l’éditeur, les interfaces et les habilitations réelles avant toute intégration.</p>
    </div>
  </section>;
}

function IntermittentWorkspace() {
  const [activeStep, setActiveStep] = useState(INTERMITTENT_FLOW[2]);

  return <section id="intermittent-spectacle" className="bg-[#efefeb] px-5 py-20 text-black sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.65fr_1.35fr]">
        <p className="text-xs font-bold uppercase tracking-[.28em] text-black/40">Intermittent du spectacle</p>
        <div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Une date produit enfin<br />toute sa chaîne.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-black/55">La fiche du spectacle relie l’engagement, le contrat, la déclaration, la paie et l’actualisation. Une donnée saisie une fois reste visible au bon rôle, avec un contrôle de concordance avant chaque transmission.</p></div>
      </div>

      <div className="mt-14 grid overflow-hidden rounded-[2rem] border border-black/10 bg-white lg:grid-cols-[.85fr_1.15fr]">
        <div className="border-b border-black/10 p-6 sm:p-9 lg:border-b-0 lg:border-r">
          <div className="flex items-center justify-between gap-5"><div><p className="text-[10px] font-bold uppercase tracking-[.22em] text-black/35">Épinal · 10 octobre 2026</p><h3 className="mt-3 font-display text-4xl font-semibold tracking-[-.05em]">Du spectacle au dossier</h3></div><span className="grid size-12 place-items-center rounded-full bg-black text-white"><FileCheck2 size={18} /></span></div>
          <div className="mt-8 divide-y divide-black/10 border-y border-black/10">
            {INTERMITTENT_FLOW.map((step) => {
              const state = flowState[step.status];
              const selected = activeStep.id === step.id;
              return <button key={step.id} type="button" onClick={() => setActiveStep(step)} className={`grid w-full grid-cols-[2.5rem_1fr_auto] items-center gap-3 py-5 text-left transition-opacity ${selected ? "opacity-100" : "opacity-55 hover:opacity-80"}`}>
                <span className="font-mono text-xs">{step.short}</span>
                <span><strong className="block text-sm">{step.title}</strong><small className="mt-1 block text-[10px] uppercase tracking-[.12em] text-black/45">{step.owner}</small></span>
                <span className={`size-2 rounded-full ${state.dot}`} title={state.label} />
              </button>;
            })}
          </div>
        </div>

        <div className="flex min-h-[35rem] flex-col bg-black p-6 text-white sm:p-9">
          <div className="flex items-center justify-between gap-5"><p className="text-[10px] uppercase tracking-[.22em] text-white/35">Étape {activeStep.short}</p><span className={`rounded-full border border-[#303030] px-3 py-2 text-[9px] uppercase tracking-[.14em] ${activeStep.status === "attention" ? "text-orange-300" : "text-white/55"}`}>{flowState[activeStep.status].label}</span></div>
          <h3 className="mt-8 font-display text-5xl font-semibold tracking-[-.06em]">{activeStep.title}</h3>
          <p className="mt-5 max-w-xl text-base leading-8 text-white/55">{activeStep.detail}</p>
          <div className="mt-9 grid gap-3 sm:grid-cols-2">
            {["Réutiliser les données du spectacle", "Comparer heures · cachets · brut", "Afficher la version et la source", "Faire confirmer avant envoi"].map((item) => <p key={item} className="flex min-h-24 items-start gap-3 rounded-[1.25rem] border border-[#292929] p-4 text-xs leading-6 text-white/60"><Check className="mt-1 shrink-0 text-emerald-300" size={14} />{item}</p>)}
          </div>
          <div className="mt-auto flex flex-wrap items-center justify-between gap-4 border-t border-[#2a2a2a] pt-6"><p className="text-xs text-white/40">Responsable : {activeStep.owner}</p><button type="button" className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-5 text-xs font-semibold text-black">Ouvrir la pièce <ChevronRight size={14} /></button></div>
        </div>
      </div>
    </div>
  </section>;
}

function DocumentFactory() {
  const [query, setQuery] = useState("Relais AIME");
  const [resolvedName, setResolvedName] = useState("Association Les Relais AIME");
  const [role, setRole] = useState("Président·e");
  const availableDocuments = useMemo(() => ADMINISTRATIVE_DOCUMENTS.filter((document) => document.roles.includes(role)), [role]);
  const [selectedId, setSelectedId] = useState("quote");
  const selectedDocument = availableDocuments.find((document) => document.id === selectedId) || availableDocuments[0];

  const resolveOrganization = () => {
    const normalized = query.trim();
    setResolvedName(normalized ? `Association ${normalized.replace(/^association\s+/i, "")}` : "Association à identifier");
  };

  return <section id="fabrique-documentaire" className="bg-white px-5 py-20 text-black sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.75fr_1.25fr]"><div><p className="text-xs font-bold uppercase tracking-[.28em] text-black/40">Fabrique documentaire</p><span className="mt-6 inline-flex items-center gap-2 rounded-full bg-black px-4 py-2 text-[10px] font-bold uppercase tracking-[.15em] text-white"><Sparkles size={13} /> Démonstrateur interactif</span></div><div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Un nom, un rôle,<br />le bon document.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-black/55">AIME retrouve l’identité déclarée de l’association, filtre les documents par rôle, préremplit les données fiables et demande uniquement ce qui manque. Les modèles restent datés, sourcés et validés avant émission.</p></div></div>

      <div className="mt-14 overflow-hidden rounded-[2rem] border border-black/10 bg-[#f3f3ef]">
        <div className="grid lg:grid-cols-[.9fr_1.1fr]">
          <div className="border-b border-black/10 p-6 sm:p-9 lg:border-b-0 lg:border-r">
            <label className="text-[10px] font-bold uppercase tracking-[.2em] text-black/40" htmlFor="organization-search">Nom ou identifiant de l’association</label>
            <div className="mt-3 flex gap-2"><input id="organization-search" value={query} onChange={(event) => setQuery(event.target.value)} className="min-h-12 min-w-0 flex-1 rounded-full border border-black/10 bg-white px-5 text-sm outline-none focus:border-black/30" /><button type="button" onClick={resolveOrganization} aria-label="Rechercher l’association" className="grid size-12 shrink-0 place-items-center rounded-full bg-black text-white"><Search size={17} /></button></div>

            <div className="mt-6 rounded-[1.4rem] border border-black/10 bg-white p-5">
              <div className="flex items-start justify-between gap-4"><span className="grid size-11 shrink-0 place-items-center rounded-full bg-black text-white"><Building2 size={17} /></span><span className="inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-[.14em] text-emerald-700"><BadgeCheck size={12} /> Démo rapprochée</span></div>
              <h3 className="mt-6 text-xl font-semibold">{resolvedName}</h3>
              <div className="mt-5 grid gap-2 text-xs text-black/50 sm:grid-cols-2"><p>RNA · W751000000</p><p>SIREN · 000 000 000</p><p>Objet · relais solidaires</p><p>Siège · Paris</p></div>
              <p className="mt-5 border-t border-black/10 pt-4 text-[10px] leading-5 text-black/40">Valeurs de démonstration. En production, chaque champ indiquera sa source, sa date et son niveau de confiance.</p>
            </div>

            <label className="mt-7 block text-[10px] font-bold uppercase tracking-[.2em] text-black/40" htmlFor="administrative-role">J’agis comme</label>
            <select id="administrative-role" value={role} onChange={(event) => { setRole(event.target.value); setSelectedId(""); }} className="mt-3 min-h-12 w-full rounded-full border border-black/10 bg-white px-5 text-sm outline-none">
              {ADMINISTRATIVE_ROLES.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>

            <div className="mt-7 flex flex-wrap gap-2">
              {availableDocuments.map((document) => <button type="button" key={document.id} onClick={() => setSelectedId(document.id)} className={`rounded-full border px-4 py-2 text-[10px] font-bold uppercase tracking-[.11em] transition-colors ${selectedDocument?.id === document.id ? "border-black bg-black text-white" : "border-black/10 bg-white text-black/55 hover:border-black/30"}`}>{document.label}</button>)}
            </div>
          </div>

          <div className="flex min-h-[43rem] flex-col bg-black p-6 text-white sm:p-9">
            <div className="flex items-center justify-between gap-4"><div><p className="text-[10px] uppercase tracking-[.22em] text-white/35">Document proposé</p><h3 className="mt-3 font-display text-4xl font-semibold tracking-[-.05em]">{selectedDocument?.label}</h3></div><FileText size={22} /></div>
            <div className="mt-9 grid gap-px overflow-hidden rounded-[1.4rem] bg-[#2b2b2b] sm:grid-cols-2">
              {selectedDocument?.fields.map((field, index) => <div key={field} className="min-h-24 bg-[#101010] p-4"><span className="font-mono text-[10px] text-white/25">{String(index + 1).padStart(2, "0")}</span><p className="mt-3 text-xs text-white/65">{field}</p></div>)}
            </div>
            <div className="mt-8 space-y-3">
              <p className="flex items-center gap-3 text-xs text-white/55"><UserRoundCheck size={14} className="text-emerald-300" /> Rôle autorisé : {role}</p>
              <p className="flex items-center gap-3 text-xs text-white/55"><Link2 size={14} className="text-cyan-300" /> Organisation rapprochée, sources à confirmer</p>
              <p className="flex items-center gap-3 text-xs text-white/55"><ShieldCheck size={14} className="text-violet-300" /> Version du modèle et journal de validation conservés</p>
            </div>
            <div className="mt-auto rounded-[1.4rem] border border-[#2b2b2b] p-5"><p className="text-[10px] font-bold uppercase tracking-[.18em] text-white/35">Ce que fait AIME</p><p className="mt-3 text-sm leading-7 text-white/55">Préremplir, signaler les champs non prouvés, générer un brouillon et router la validation. Une transmission réglementée n’est jamais simulée.</p><button type="button" className="mt-5 inline-flex min-h-12 w-full items-center justify-between rounded-full bg-white px-5 text-sm font-semibold text-black">Générer le brouillon <ArrowRight size={15} /></button></div>
          </div>
        </div>
      </div>
      <p className="mt-5 max-w-5xl text-xs leading-6 text-black/45">{DOCUMENT_REGISTRY_NOTICE}</p>
    </div>
  </section>;
}

function PennylanePositioning() {
  return <section className="bg-[#090909] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.7fr_1.3fr]"><p className="text-xs uppercase tracking-[.28em] text-white/40">AIME × Pennylane</p><div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Aller plus loin<br />sans refaire la comptabilité.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Pennylane garde la profondeur financière, comptable et réglementaire. AIME devient la couche située avant et autour : qui agit, dans quel rôle, pour quel événement, avec quelles preuves et quelle conséquence.</p></div></div>
      <div className="mt-14 overflow-hidden rounded-[2rem] border border-[#242424]">
        <div className="hidden grid-cols-[1.35fr_.75fr_.75fr_.55fr] border-b border-[#242424] bg-[#101010] px-6 py-4 text-[9px] uppercase tracking-[.15em] text-white/35 md:grid"><span>Capacité</span><span>Pennylane</span><span>AIME</span><span>Choix</span></div>
        <div className="divide-y divide-[#242424]">{PENNYLANE_COMPARISON.map((row) => <article key={row.subject} className="grid gap-4 bg-[#0d0d0d] px-6 py-6 md:grid-cols-[1.35fr_.75fr_.75fr_.55fr] md:items-center"><h3 className="text-sm font-semibold">{row.subject}</h3><p className="text-xs text-white/45"><span className="mr-2 text-[9px] uppercase tracking-wider text-white/25 md:hidden">Pennylane</span>{row.pennylane}</p><p className="text-xs text-white/60"><span className="mr-2 text-[9px] uppercase tracking-wider text-white/25 md:hidden">AIME</span>{row.aime}</p><span className="w-fit rounded-full border border-[#303030] px-3 py-2 text-[9px] uppercase tracking-[.12em] text-white/60">{row.strategy}</span></article>)}</div>
      </div>
      <div className="mt-6 grid gap-3 sm:grid-cols-3">{[["01", "Pennylane", "Livre, paie partenaire, trésorerie et e-facturation"], ["02", "AIME", "Contexte, rôles, événements, preuves et orchestration"], ["03", "Connecteur", "Synchronisation contrôlée, sans double saisie"]].map(([number, title, text]) => <div key={number} className="rounded-[1.4rem] border border-[#282828] p-5"><span className="font-mono text-[10px] text-white/25">{number}</span><h3 className="mt-5 text-lg font-semibold">{title}</h3><p className="mt-2 text-xs leading-6 text-white/40">{text}</p></div>)}</div>
    </div>
  </section>;
}

export default function AimeAdministrativeSystem() {
  return <>
    <AdministrativeAudit />
    <IntermittentWorkspace />
    <DocumentFactory />
    <AimeAdministrativeDesk />
    <PennylanePositioning />
  </>;
}
