import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Activity, ArrowUpRight, Bot, Check, CircleAlert, Code2, Link2, Network, Play, RotateCcw, Sparkles, Wrench } from "lucide-react";
import { AIME_SYSTEM_EDGES, AIME_SYSTEM_FLOWS, AIME_SYSTEM_NODES, getSystemNode } from "@/data/aimeSystemGraph";

const statusMeta = {
  live: { label: "Actif", dot: "bg-emerald-300", text: "text-emerald-200", border: "border-emerald-300/25" },
  partial: { label: "Partiel", dot: "bg-amber-300", text: "text-amber-200", border: "border-amber-300/25" },
  todo: { label: "À relier", dot: "bg-fuchsia-400", text: "text-fuchsia-200", border: "border-fuchsia-400/30" },
};

const nodeMap = Object.fromEntries(AIME_SYSTEM_NODES.map((node) => [node.id, node]));
const edgeKey = (from, to) => `${from}:${to}`;

function findPath(startId, targetId) {
  if (startId === targetId) return [startId];
  const queue = [[startId]];
  const visited = new Set([startId]);
  while (queue.length) {
    const currentPath = queue.shift();
    const current = currentPath[currentPath.length - 1];
    const neighbours = AIME_SYSTEM_EDGES.filter(([from]) => from === current).map(([,to]) => to);
    for (const neighbour of neighbours) {
      if (visited.has(neighbour)) continue;
      const nextPath = [...currentPath, neighbour];
      if (neighbour === targetId) return nextPath;
      visited.add(neighbour);
      queue.push(nextPath);
    }
  }
  return [targetId];
}

function curve(from, to) {
  const middle = (from.x + to.x) / 2;
  return `M ${from.x} ${from.y} C ${middle} ${from.y}, ${middle} ${to.y}, ${to.x} ${to.y}`;
}

function SystemNode({ node, selected, active, onClick }) {
  const meta = statusMeta[node.status];
  return <button type="button" onClick={onClick} className={`absolute z-10 w-36 -translate-x-1/2 -translate-y-1/2 rounded-2xl border bg-[#0b0b0b]/95 p-3 text-left shadow-2xl backdrop-blur-xl transition-all ${selected ? "scale-105 border-white/45" : meta.border} ${active ? "ring-2 ring-violet-400/70" : ""}`} style={{ left: `${(node.x / 1200) * 100}%`, top: `${(node.y / 720) * 100}%` }}>
    <span className="flex items-center justify-between gap-2"><small className="truncate text-[8px] uppercase tracking-[.16em] text-white/35">{node.family}</small><i className={`size-2 shrink-0 rounded-full ${meta.dot}`}/></span>
    <b className="mt-2 block text-xs leading-4 text-white/88">{node.label}</b>
    <small className="mt-2 block truncate font-mono text-[8px] text-white/32">{node.route}</small>
  </button>;
}

export default function AimeNervousSystem() {
  const [flowId, setFlowId] = useState(AIME_SYSTEM_FLOWS[0].id);
  const [runKey, setRunKey] = useState(0);
  const [selectedId, setSelectedId] = useState("system");
  const [manualPath, setManualPath] = useState(null);
  const [repairing, setRepairing] = useState(false);
  const [repairReady, setRepairReady] = useState(false);

  const flow = AIME_SYSTEM_FLOWS.find((item) => item.id === flowId) || AIME_SYSTEM_FLOWS[0];
  const selected = getSystemNode(selectedId) || AIME_SYSTEM_NODES[0];
  const activePath = manualPath || flow.path;
  const pathEdges = useMemo(() => new Set(activePath.slice(0, -1).map((id, index) => edgeKey(id, activePath[index + 1]))), [activePath]);
  const points = activePath.map((id) => nodeMap[id]).filter(Boolean);

  const selectNode = (nodeId) => {
    setSelectedId(nodeId);
    setManualPath(findPath("shell", nodeId));
    setRepairReady(false);
    setRunKey((value) => value + 1);
  };

  const startRepair = () => {
    setRepairing(true);
    setRepairReady(false);
    window.setTimeout(() => {
      setRepairing(false);
      setRepairReady(true);
    }, 1500);
  };

  const counts = AIME_SYSTEM_NODES.reduce((result, node) => ({ ...result, [node.status]: (result[node.status] || 0) + 1 }), {});

  return <section id="systeme-nerveux" className="overflow-hidden bg-[#050505] py-20 text-white lg:py-28">
    <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <div className="grid gap-8 lg:grid-cols-[.7fr_1.3fr] lg:items-end"><div><p className="text-xs uppercase tracking-[.28em] text-white/40">Maintenance · architecture</p><span className="mt-6 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/[.07] px-4 py-2 text-[9px] uppercase tracking-[.16em] text-cyan-100"><Activity size={13}/> Schéma nerveux</span></div><div><h2 className="font-display text-5xl font-semibold leading-[.88] tracking-[-.065em] sm:text-7xl">Voir le point circuler.<br/>Comprendre la conséquence.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Choisissez une action : le signal traverse les pages et les composants concernés. Les connexions incomplètes apparaissent immédiatement, avec une proposition de réparation.</p></div></div>

    </div>

      <div className="mt-14 border-y border-[#202020] bg-[#070707]">
        <div className="bg-[#080808]">
          <div className="mx-auto flex max-w-[100rem] flex-wrap items-center justify-between gap-4 border-b border-[#202020] p-5 sm:p-6"><div className="flex min-w-0 flex-wrap gap-2">{AIME_SYSTEM_FLOWS.map((item) => <button type="button" key={item.id} onClick={() => { setFlowId(item.id); setManualPath(null); setRunKey((value) => value + 1); }} className={`rounded-full px-4 py-3 text-[9px] font-bold uppercase tracking-[.12em] transition-colors ${!manualPath && flowId === item.id ? "bg-white text-black" : "border border-[#303030] text-white/48 hover:text-white"}`}>{item.label}</button>)}</div><button type="button" onClick={() => setRunKey((value) => value + 1)} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-gradient-to-r from-cyan-300 via-violet-400 to-fuchsia-400 px-5 text-xs font-semibold text-black"><Play size={14}/>Tester le circuit</button></div>

          <div className="relative overflow-x-auto">
            <div className="relative h-[43rem] min-w-[62rem] overflow-hidden bg-[radial-gradient(circle_at_52%_45%,rgba(100,116,255,.1),transparent_32%)]">
              <div className="absolute inset-0 opacity-35 [background-image:linear-gradient(rgba(255,255,255,.045)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.045)_1px,transparent_1px)] [background-size:40px_40px]"/>
              <svg viewBox="0 0 1200 720" className="absolute inset-0 size-full" preserveAspectRatio="none" aria-label="Connexions entre les modules AIME">
                <defs><linearGradient id="nervous-active" x1="0" x2="1"><stop stopColor="#67e8f9"/><stop offset=".5" stopColor="#a78bfa"/><stop offset="1" stopColor="#f472b6"/></linearGradient></defs>
                {AIME_SYSTEM_EDGES.map(([fromId,toId,status]) => {
                  const from = nodeMap[fromId];
                  const to = nodeMap[toId];
                  const highlighted = pathEdges.has(edgeKey(fromId,toId));
                  return <path key={edgeKey(fromId,toId)} d={curve(from,to)} fill="none" stroke={highlighted ? "url(#nervous-active)" : status === "todo" ? "rgba(244,114,182,.3)" : "rgba(255,255,255,.10)"} strokeWidth={highlighted ? 4 : 1.5} strokeDasharray={status === "todo" ? "8 9" : undefined} strokeLinecap="round" className={highlighted ? "aime-system-path" : ""}/>;
                })}
                {points.length > 1 && <motion.circle key={`${flow.id}-${selectedId}-${runKey}`} r="7" fill="#fff" stroke="#a78bfa" strokeWidth="4" initial={{ cx: points[0].x, cy: points[0].y, opacity: 0 }} animate={{ cx: points.map((point) => point.x), cy: points.map((point) => point.y), opacity: points.map((_, index) => index === 0 ? .25 : 1) }} transition={{ duration: Math.max(3.4, points.length * 1.05), ease: "easeInOut", times: points.map((_,index) => index / (points.length - 1)) }} />}
              </svg>
              {AIME_SYSTEM_NODES.map((node) => <SystemNode key={node.id} node={node} selected={selectedId === node.id} active={activePath.includes(node.id)} onClick={() => selectNode(node.id)} />)}
              <div className="absolute bottom-5 left-5 max-w-sm rounded-2xl border border-[#2a2a2a] bg-black/80 p-4 backdrop-blur-xl"><p className="text-[8px] uppercase tracking-[.2em] text-white/35">Circuit actif</p><b className="mt-2 block text-sm">{manualPath ? `Accès à ${selected.label}` : flow.label}</b><p className="mt-2 text-[10px] leading-5 text-white/42">{manualPath ? "Le point suit le chemin connu depuis la coquille commune jusqu’à l’élément sélectionné." : flow.description}</p></div>
            </div>
          </div>
        </div>

        <aside className="mx-auto flex max-w-7xl flex-col border-t border-[#202020] bg-[#0b0b0b] p-6 sm:p-8 lg:min-h-[28rem]">
          <div className="flex items-start justify-between gap-4"><span className="grid size-12 place-items-center rounded-full bg-white text-black"><Network size={18}/></span><span className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-[8px] uppercase tracking-[.14em] ${statusMeta[selected.status].border} ${statusMeta[selected.status].text}`}><i className={`size-2 rounded-full ${statusMeta[selected.status].dot}`}/>{statusMeta[selected.status].label}</span></div>
          <p className="mt-8 text-[9px] uppercase tracking-[.22em] text-white/35">{selected.family}</p><h3 className="mt-3 font-display text-4xl font-semibold leading-[.92] tracking-[-.055em]">{selected.label}</h3><p className="mt-5 text-sm leading-7 text-white/52">{selected.description}</p>
          <div className="mt-7 space-y-3 border-y border-[#282828] py-5"><div className="flex items-start gap-3"><Link2 size={14} className="mt-1 text-white/35"/><div><small className="block text-[8px] uppercase tracking-[.16em] text-white/30">Destination</small><b className="mt-1 block text-xs text-white/68">{selected.route}</b></div></div><div className="flex items-start gap-3"><Code2 size={14} className="mt-1 text-white/35"/><div className="min-w-0"><small className="block text-[8px] uppercase tracking-[.16em] text-white/30">Source</small><b className="mt-1 block break-words text-xs text-white/68">{selected.source}</b></div></div></div>

          {selected.status !== "live" ? <div className="mt-6"><div className="flex gap-3 rounded-2xl border border-amber-300/15 bg-amber-300/[.05] p-4"><CircleAlert size={17} className="mt-0.5 shrink-0 text-amber-200"/><p className="text-[10px] leading-5 text-white/48">Cette liaison existe partiellement ou reste à connecter au registre commun.</p></div><button type="button" onClick={startRepair} disabled={repairing} className="mt-3 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-white text-xs font-semibold text-black disabled:opacity-60">{repairing ? <RotateCcw size={15} className="animate-spin"/> : <Sparkles size={15}/>} {repairing ? "Analyse du circuit…" : "Préparer la réparation IA"}</button></div> : <div className="mt-6 flex gap-3 rounded-2xl border border-emerald-300/15 bg-emerald-300/[.05] p-4"><Check size={17} className="mt-0.5 shrink-0 text-emerald-200"/><p className="text-[10px] leading-5 text-white/48">Le composant et sa destination sont présents dans le code actuel.</p></div>}

          <AnimatePresence>{repairReady && <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4 rounded-2xl border border-violet-300/20 bg-violet-300/[.06] p-4"><div className="flex items-center gap-2"><Bot size={15} className="text-violet-200"/><b className="text-xs">Proposition prête</b></div><ol className="mt-3 space-y-2 text-[10px] leading-5 text-white/48"><li>1. Vérifier la destination et ses droits.</li><li>2. Brancher le registre de données commun.</li><li>3. Tester le parcours puis rescanner.</li></ol><p className="mt-3 border-t border-white/10 pt-3 text-[9px] leading-4 text-white/32">Aucun fichier n’est modifié depuis cette démonstration. La réparation réelle exigera la connexion sécurisée à l’agent de maintenance.</p></motion.div>}</AnimatePresence>

          <div className="mt-auto pt-7"><p className="text-[9px] uppercase tracking-[.2em] text-white/30">État du système</p><div className="mt-4 grid grid-cols-3 gap-2">{[["live","Actifs"],["partial","Partiels"],["todo","À relier"]].map(([status,label]) => <div key={status} className="rounded-2xl border border-[#282828] p-3"><i className={`block size-2 rounded-full ${statusMeta[status].dot}`}/><b className="mt-3 block font-mono text-xl">{counts[status] || 0}</b><small className="mt-1 block text-[8px] uppercase tracking-[.12em] text-white/30">{label}</small></div>)}</div><a href="#reste-a-faire" className="mt-4 inline-flex items-center gap-2 text-[10px] text-white/45 hover:text-white">Voir les travaux restants <ArrowUpRight size={13}/></a></div>
        </aside>
      </div>

      <div id="reste-a-faire" className="mx-auto mt-5 grid max-w-7xl gap-3 px-5 sm:px-8 md:grid-cols-3 lg:px-12">{[
        ["01","Registre commun","Faire de ce graphe un inventaire généré depuis les routes, entités et composants réels."],
        ["02","Réparation contrôlée","Connecter le bouton à un agent qui prépare un patch, lance les tests et demande une validation humaine."],
        ["03","Observabilité EAA","Brancher le scanner, les preuves et les résultats manuels au Passeport d’accessibilité."],
      ].map(([number,title,text]) => <article key={number} className="rounded-[1.6rem] border border-[#282828] bg-[#0a0a0a] p-6"><span className="font-mono text-xs text-white/25">{number}</span><h3 className="mt-7 text-lg font-semibold">{title}</h3><p className="mt-3 text-xs leading-6 text-white/42">{text}</p><span className="mt-6 inline-flex items-center gap-2 text-[9px] uppercase tracking-[.14em] text-white/32"><Wrench size={13}/> chantier identifié</span></article>)}</div>
  </section>;
}
