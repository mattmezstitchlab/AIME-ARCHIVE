import { useMemo, useState } from "react";
import {
  Archive,
  ArrowRight,
  Bot,
  BriefcaseBusiness,
  Calculator,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  FileClock,
  Folder,
  FolderOpen,
  Layers3,
  LockKeyhole,
  Scale,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

const AGENTS = [
  {
    id: "administrative",
    label: "Agent administratif",
    short: "Administratif",
    icon: BriefcaseBusiness,
    tone: "from-cyan-300 via-blue-400 to-violet-500",
    mission: "Reçoit, identifie, classe et prépare le bon circuit pour chaque organisme.",
    action: "Classement de 3 nouvelles pièces dans le dossier Association",
    safeguards: ["Finalité et habilitation vérifiées", "Sources et dates conservées", "Envoi soumis à validation"],
  },
  {
    id: "accounting",
    label: "Assistant comptable",
    short: "Comptabilité",
    icon: Calculator,
    tone: "from-emerald-300 via-cyan-300 to-blue-500",
    mission: "Prépare devis, factures, dépenses et rapprochements avant transmission au système comptable.",
    action: "Rapprochement du devis Épinal avec le contrat et les dépenses",
    safeguards: ["Aucune écriture inventée", "Écart signalé, jamais masqué", "Paiement toujours autorisé par un humain"],
  },
  {
    id: "legal",
    label: "Copilote juridique",
    short: "Juridique",
    icon: Scale,
    tone: "from-orange-300 via-fuchsia-400 to-violet-500",
    mission: "Repère les clauses, pièces et risques afin de préparer un dossier pour le juriste ou l’avocat référent.",
    action: "Préparation d’une note de contrôle — aucune décision juridique automatique",
    safeguards: ["Ne se présente jamais comme avocat", "Secret et confidentialité par dossier", "Validation par le professionnel compétent"],
  },
];

const FOLDERS = [
  {
    id: "identity",
    label: "Identité & état civil",
    meta: "12 pièces · 1 rupture",
    color: "bg-orange-400",
    status: "À sécuriser",
    contents: ["01 · Actes sources", "02 · Mentions marginales", "03 · Chronologie consolidée", "04 · À valider"],
  },
  {
    id: "association",
    label: "Association Les Relais AIME",
    meta: "28 pièces · 4 workflows",
    color: "bg-cyan-300",
    status: "En préparation",
    contents: ["01 · Identité RNA & SIREN", "02 · Gouvernance", "03 · Événements", "04 · Factures & justificatifs"],
  },
  {
    id: "show",
    label: "Spectacle · Épinal",
    meta: "19 pièces · 2 validations",
    color: "bg-fuchsia-400",
    status: "À faire signer",
    contents: ["01 · Engagement", "02 · CDDU & annexes", "03 · Paie & déclarations", "04 · Actualisation"],
  },
  {
    id: "wedding",
    label: "Mariage · Camille & Noé",
    meta: "47 pièces · 9 acteurs",
    color: "bg-violet-400",
    status: "Stable",
    contents: ["01 · Prestataires", "02 · Contrats", "03 · Paiements", "04 · Preuves du moment"],
  },
  {
    id: "archives",
    label: "Archives & preuves",
    meta: "128 pièces versionnées",
    color: "bg-emerald-300",
    status: "Consolidé",
    contents: ["01 · Originaux", "02 · Versions signées", "03 · Journaux de validation", "04 · Durées de conservation"],
  },
];

const WALLETS = [
  { label: "À traiter", count: 7, tone: "from-orange-400 to-fuchsia-500", icon: CircleAlert },
  { label: "À faire signer", count: 3, tone: "from-fuchsia-500 to-violet-500", icon: FileClock },
  { label: "En attente d’un tiers", count: 4, tone: "from-violet-500 to-blue-500", icon: Layers3 },
  { label: "Prêts à transmettre", count: 6, tone: "from-cyan-300 to-emerald-300", icon: CheckCircle2 },
];

export default function AimeAdministrativeDesk() {
  const [activeAgentId, setActiveAgentId] = useState("administrative");
  const [activeFolderId, setActiveFolderId] = useState("association");
  const [activityIndex, setActivityIndex] = useState(0);

  const activeAgent = useMemo(() => AGENTS.find((agent) => agent.id === activeAgentId) || AGENTS[0], [activeAgentId]);
  const activeFolder = useMemo(() => FOLDERS.find((folder) => folder.id === activeFolderId) || FOLDERS[0], [activeFolderId]);
  const AgentIcon = activeAgent.icon;

  const simulateClassification = () => setActivityIndex((value) => (value + 1) % activeFolder.contents.length);

  return <section id="bureau-aime" className="border-y border-[#242424] bg-[#080808] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.72fr_1.28fr]">
        <div>
          <p className="text-xs uppercase tracking-[.28em] text-white/40">Bureau AIME · multi-agents</p>
          <span className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#303030] bg-[#111] px-4 py-2 text-[10px] uppercase tracking-[.16em] text-white/55"><LockKeyhole size={13} /> Cloisonné par dossier</span>
        </div>
        <div>
          <h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Un bureau qui se range<br />autour de la situation.</h2>
          <p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Les agents spécialisés ne remplacent pas les métiers : ils reçoivent les pièces, créent les dossiers et sous-dossiers, préparent les brouillons puis placent chaque action dans le bon wallet de validation.</p>
        </div>
      </div>

      <div className="mt-14 overflow-hidden rounded-[2rem] border border-[#242424] bg-[#0d0d0d]">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#242424] px-5 py-5 sm:px-7">
          <div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-full bg-white text-black"><Bot size={17} /></span><div><p className="text-[9px] uppercase tracking-[.2em] text-white/32">Bureau numérique</p><h3 className="mt-1 text-sm font-semibold">AIME Desk · Matt Mez</h3></div></div>
          <div className="flex items-center gap-2 text-[9px] uppercase tracking-[.13em] text-emerald-200"><i className="size-2 rounded-full bg-emerald-300" /> Dossiers synchronisés</div>
        </div>

        <div className="grid xl:grid-cols-[15rem_minmax(0,1fr)_19rem]">
          <nav className="border-b border-[#242424] bg-[#0a0a0a] p-4 xl:border-b-0 xl:border-r">
            <p className="px-2 text-[9px] uppercase tracking-[.2em] text-white/30">Équipe agentique</p>
            <div className="mt-4 space-y-2">
              {AGENTS.map((agent) => {
                const Icon = agent.icon;
                const active = activeAgent.id === agent.id;
                return <button key={agent.id} type="button" onClick={() => setActiveAgentId(agent.id)} className={`flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition-colors ${active ? "border-[#3d3d3d] bg-[#171717]" : "border-transparent hover:border-[#292929] hover:bg-[#111]"}`}>
                  <span className={`grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br ${agent.tone} text-black`}><Icon size={15} /></span>
                  <span className="min-w-0"><strong className="block truncate text-xs">{agent.short}</strong><small className="mt-1 block text-[9px] text-white/32">{active ? "Agent actif" : "Disponible"}</small></span>
                </button>;
              })}
            </div>
            <div className="mt-6 border-t border-[#242424] px-2 pt-5">
              <p className="text-[9px] uppercase tracking-[.18em] text-white/28">Supervision</p>
              <p className="mt-3 flex items-center gap-2 text-[10px] text-white/52"><ShieldCheck size={13} className="text-emerald-300" /> Utilisateur habilité</p>
              <p className="mt-2 flex items-center gap-2 text-[10px] text-white/52"><Scale size={13} className="text-violet-300" /> Expert externe si requis</p>
            </div>
          </nav>

          <div className="min-w-0 p-5 sm:p-7">
            <div className="flex flex-wrap items-start justify-between gap-5">
              <div><p className="text-[9px] uppercase tracking-[.2em] text-white/30">Bureau · dossiers vivants</p><h3 className="mt-3 font-display text-4xl font-semibold tracking-[-.05em]">{activeAgent.label}</h3><p className="mt-3 max-w-2xl text-xs leading-6 text-white/45">{activeAgent.mission}</p></div>
              <span className={`grid size-12 place-items-center rounded-full bg-gradient-to-br ${activeAgent.tone} text-black`}><AgentIcon size={19} /></span>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {FOLDERS.map((folder) => {
                const active = activeFolder.id === folder.id;
                return <button key={folder.id} type="button" onClick={() => { setActiveFolderId(folder.id); setActivityIndex(0); }} className={`min-h-36 rounded-[1.35rem] border p-4 text-left transition-colors ${active ? "border-[#4a4a4a] bg-[#181818]" : "border-[#252525] bg-[#101010] hover:border-[#353535]"}`}>
                  <div className="flex items-start justify-between gap-3"><span className={`grid size-10 place-items-center rounded-xl ${folder.color} text-black`}>{active ? <FolderOpen size={17} /> : <Folder size={17} />}</span><span className="text-[8px] uppercase tracking-[.12em] text-white/28">{folder.status}</span></div>
                  <strong className="mt-5 block text-sm leading-5">{folder.label}</strong><small className="mt-2 block text-[9px] text-white/34">{folder.meta}</small>
                </button>;
              })}
            </div>

            <div className="mt-5 overflow-hidden rounded-[1.4rem] border border-[#292929] bg-black">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#272727] p-5"><div className="flex items-center gap-3"><span className={`grid size-10 place-items-center rounded-xl ${activeFolder.color} text-black`}><FolderOpen size={17} /></span><div><p className="text-[9px] uppercase tracking-[.16em] text-white/30">Dossier ouvert</p><h4 className="mt-1 text-sm font-semibold">{activeFolder.label}</h4></div></div><span className="rounded-full border border-[#303030] px-3 py-2 text-[8px] uppercase tracking-[.12em] text-white/50">{activeFolder.status}</span></div>
              <div className="grid gap-px bg-[#252525] sm:grid-cols-2">
                {activeFolder.contents.map((item, index) => <button type="button" key={item} onClick={() => setActivityIndex(index)} className={`flex min-h-20 items-center justify-between gap-3 p-4 text-left transition-colors ${activityIndex === index ? "bg-[#191919] text-white" : "bg-[#101010] text-white/46 hover:bg-[#151515]"}`}><span className="flex items-center gap-3 text-xs"><Archive size={14} />{item}</span><ChevronRight size={13} /></button>)}
              </div>
            </div>

            <div className="mt-5 flex flex-col gap-4 rounded-[1.35rem] border border-[#292929] bg-[#111] p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex min-w-0 items-start gap-3"><Sparkles size={16} className="mt-0.5 shrink-0 text-violet-300" /><div><p className="text-xs font-semibold">{activeAgent.action}</p><p className="mt-2 text-[10px] leading-5 text-white/38">Destination proposée : {activeFolder.contents[activityIndex]}</p></div></div>
              <button type="button" onClick={simulateClassification} className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-full bg-white px-5 text-xs font-semibold text-black">Simuler le classement <ArrowRight size={14} /></button>
            </div>
          </div>

          <aside className="border-t border-[#242424] bg-[#0a0a0a] p-5 xl:border-l xl:border-t-0">
            <div className="flex items-center justify-between gap-3"><div><p className="text-[9px] uppercase tracking-[.2em] text-white/30">Wallets</p><h3 className="mt-2 text-lg font-semibold">Prochaines actions</h3></div><Layers3 size={18} /></div>
            <div className="mt-6 space-y-3">
              {WALLETS.map((wallet) => {
                const Icon = wallet.icon;
                return <article key={wallet.label} className="rounded-[1.25rem] border border-[#282828] bg-[#101010] p-4">
                  <div className="flex items-center justify-between gap-4"><span className={`grid size-9 place-items-center rounded-xl bg-gradient-to-br ${wallet.tone} text-black`}><Icon size={15} /></span><strong className="font-mono text-2xl">{wallet.count}</strong></div>
                  <p className="mt-4 text-xs font-semibold">{wallet.label}</p><p className="mt-2 text-[9px] leading-4 text-white/32">Toutes les pièces liées restent groupées comme une seule carte d’action.</p>
                </article>;
              })}
            </div>
          </aside>
        </div>
      </div>

      <div className="mt-5 grid gap-3 lg:grid-cols-3">
        {activeAgent.safeguards.map((item, index) => <div key={item} className="flex min-h-24 items-start gap-4 rounded-[1.35rem] border border-[#282828] bg-[#0d0d0d] p-5"><span className="font-mono text-[10px] text-white/25">0{index + 1}</span><p className="text-xs leading-6 text-white/52">{item}</p></div>)}
      </div>
      <p className="mt-5 max-w-5xl text-[11px] leading-6 text-white/34">Démonstrateur d’interface : aucune donnée sensible n’est traitée ici. En production, chaque dossier devra appliquer les habilitations, durées de conservation et journaux d’accès adaptés. Aucun envoi, paiement, signature ou décision juridique n’est exécuté sans validation autorisée.</p>
    </div>
  </section>;
}
