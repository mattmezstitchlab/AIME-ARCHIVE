import { useEffect, useMemo, useState } from "react";
import { Check, Edit3, RotateCcw, Save, Settings2, SlidersHorizontal, Type } from "lucide-react";

const STORAGE_KEY = "aime-design-system-draft-v1";

const DEFAULTS = {
  kicker: "UNE ARCHITECTURE VIVANTE",
  headline: "Relier ce qui existe déjà.",
  body: "AIME transforme les personnes, les lieux, les contenus et les contraintes en un système lisible, partageable et réparable.",
  font: "Inter",
  headlineSize: 86,
  bodySize: 18,
  radius: 32,
  spacing: 24,
  accent: "aurora",
};

const accentOptions = {
  aurora: "linear-gradient(135deg,#67e8f9 0%,#a78bfa 48%,#f472b6 100%)",
  signal: "linear-gradient(135deg,#facc15 0%,#fb923c 52%,#ec4899 100%)",
  calm: "linear-gradient(135deg,#5eead4 0%,#38bdf8 55%,#818cf8 100%)",
};

function NumberControl({ label, value, min, max, suffix, onChange }) {
  return <label className="block rounded-2xl border border-[#2b2b2b] bg-[#111] p-4">
    <span className="flex items-center justify-between text-[9px] font-bold uppercase tracking-[.18em] text-white/40"><span>{label}</span><b className="font-mono text-white/75">{value}{suffix}</b></span>
    <input type="range" min={min} max={max} value={value} onChange={(event) => onChange(Number(event.target.value))} className="mt-4 w-full accent-white" />
  </label>;
}

export default function AimeDesignSystemEditor() {
  const [settings, setSettings] = useState(DEFAULTS);
  const [editing, setEditing] = useState(true);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) setSettings({ ...DEFAULTS, ...JSON.parse(stored) });
    } catch {
      // Le brouillon local reste facultatif.
    }
  }, []);

  const update = (key, value) => setSettings((current) => ({ ...current, [key]: value }));

  const save = () => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1800);
  };

  const reset = () => {
    setSettings(DEFAULTS);
    window.localStorage.removeItem(STORAGE_KEY);
  };

  const previewStyle = useMemo(() => ({
    "--aime-preview-radius": `${settings.radius}px`,
    "--aime-preview-gap": `${settings.spacing}px`,
    "--aime-preview-accent": accentOptions[settings.accent],
    fontFamily: settings.font === "Inter" ? 'Inter, "Helvetica Neue", Arial, sans-serif' : '"Helvetica Neue", Arial, sans-serif',
  }), [settings]);

  return <section id="reglages-systeme" className="border-y border-[#242424] bg-[#090909] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.66fr_1.34fr] lg:items-end">
        <div><p className="text-xs uppercase tracking-[.28em] text-white/40">Réglages · design system</p><span className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#303030] bg-white/[.04] px-4 py-2 text-[9px] uppercase tracking-[.16em] text-white/55"><Settings2 size={13}/> Brouillon local</span></div>
        <div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Modifier la règle.<br/>Voir l’effet immédiatement.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Cette table de réglages préfigure l’administration du système. Les valeurs sont éditables et mémorisées dans ce navigateur ; la publication globale dans Base44 viendra ensuite.</p></div>
      </div>

      <div className="mt-14 overflow-hidden rounded-[2rem] border border-[#292929] bg-[#0c0c0c] lg:grid lg:grid-cols-[23rem_minmax(0,1fr)]">
        <aside className="border-b border-[#292929] p-5 lg:border-b-0 lg:border-r lg:p-6">
          <div className="flex items-center justify-between"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-full bg-white text-black"><SlidersHorizontal size={16}/></span><div><b className="block text-sm">Fondations</b><small className="text-[9px] uppercase tracking-[.15em] text-white/35">Version de travail</small></div></div><button type="button" onClick={() => setEditing((value) => !value)} className={`grid size-10 place-items-center rounded-full border ${editing ? "border-white bg-white text-black" : "border-[#303030] text-white/60"}`} aria-label="Activer ou désactiver le mode édition"><Edit3 size={15}/></button></div>

          <div className="mt-7 space-y-3">
            <label className="block rounded-2xl border border-[#2b2b2b] bg-[#111] p-4"><span className="text-[9px] font-bold uppercase tracking-[.18em] text-white/40">Typographie</span><select value={settings.font} onChange={(event) => update("font", event.target.value)} className="mt-3 w-full bg-transparent text-sm outline-none"><option className="bg-black">Inter</option><option className="bg-black">Helvetica</option></select></label>
            <NumberControl label="Titre H1" value={settings.headlineSize} min={52} max={126} suffix=" px" onChange={(value) => update("headlineSize", value)} />
            <NumberControl label="Corps" value={settings.bodySize} min={14} max={26} suffix=" px" onChange={(value) => update("bodySize", value)} />
            <NumberControl label="Rayon" value={settings.radius} min={0} max={56} suffix=" px" onChange={(value) => update("radius", value)} />
            <NumberControl label="Espacement" value={settings.spacing} min={12} max={48} suffix=" px" onChange={(value) => update("spacing", value)} />
            <div className="rounded-2xl border border-[#2b2b2b] bg-[#111] p-4"><span className="text-[9px] font-bold uppercase tracking-[.18em] text-white/40">Signal</span><div className="mt-4 flex gap-2">{Object.entries(accentOptions).map(([id,gradient]) => <button key={id} type="button" onClick={() => update("accent", id)} className={`size-10 rounded-full border-2 ${settings.accent === id ? "border-white" : "border-transparent"}`} style={{ background: gradient }} aria-label={`Choisir le signal ${id}`} />)}</div></div>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-2"><button type="button" onClick={reset} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-[#303030] text-xs text-white/60"><RotateCcw size={14}/>Réinitialiser</button><button type="button" onClick={save} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-white text-xs font-semibold text-black">{saved ? <Check size={14}/> : <Save size={14}/>} {saved ? "Enregistré" : "Enregistrer"}</button></div>
        </aside>

        <div className="min-w-0 p-5 sm:p-8 lg:p-10" style={previewStyle}>
          <div className="relative flex min-h-[40rem] flex-col justify-between overflow-hidden border border-[#2a2a2a] bg-[#070707] p-6 sm:p-10" style={{ borderRadius: "var(--aime-preview-radius)" }}>
            <div className="absolute inset-0 opacity-35 [background-image:linear-gradient(rgba(255,255,255,.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.06)_1px,transparent_1px)] [background-size:44px_44px]"/>
            <div className="absolute -right-24 -top-24 size-80 rounded-full opacity-25 blur-[90px]" style={{ background: "var(--aime-preview-accent)" }}/>
            <div className="relative flex items-center justify-between"><span className="inline-flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.22em] text-white/38"><Type size={14}/>{editing ? "Cliquez dans les textes" : "Aperçu verrouillé"}</span><span className="rounded-full border border-[#2f2f2f] px-3 py-2 text-[8px] uppercase tracking-[.15em] text-white/40">H1 · Editorial</span></div>
            <div className="relative max-w-5xl" style={{ display: "grid", gap: "var(--aime-preview-gap)" }}>
              <p contentEditable={editing} suppressContentEditableWarning onBlur={(event) => update("kicker", event.currentTarget.textContent || DEFAULTS.kicker)} className={`w-fit text-[10px] font-bold uppercase tracking-[.3em] text-white/45 outline-none ${editing ? "rounded px-1 ring-1 ring-dashed ring-white/20 focus:ring-cyan-300/70" : ""}`}>{settings.kicker}</p>
              <h3 contentEditable={editing} suppressContentEditableWarning onBlur={(event) => update("headline", event.currentTarget.textContent || DEFAULTS.headline)} className={`max-w-5xl font-semibold leading-[.82] tracking-[-.075em] outline-none ${editing ? "rounded px-1 ring-1 ring-dashed ring-white/20 focus:ring-fuchsia-300/70" : ""}`} style={{ fontSize: `clamp(3.2rem,8vw,${settings.headlineSize}px)` }}>{settings.headline}</h3>
              <p contentEditable={editing} suppressContentEditableWarning onBlur={(event) => update("body", event.currentTarget.textContent || DEFAULTS.body)} className={`max-w-3xl leading-[1.55] text-white/55 outline-none ${editing ? "rounded px-1 ring-1 ring-dashed ring-white/20 focus:ring-violet-300/70" : ""}`} style={{ fontSize: `${settings.bodySize}px` }}>{settings.body}</p>
            </div>
            <div className="relative grid gap-3 border-t border-[#252525] pt-6 sm:grid-cols-4">{[["H1","86 / 0.82"],["H2","64 / 0.90"],["Corps","18 / 1.55"],["Label","10 / 0.30"]].map(([label,value]) => <div key={label}><span className="block text-[8px] uppercase tracking-[.2em] text-white/30">{label}</span><b className="mt-2 block font-mono text-sm text-white/65">{value}</b></div>)}</div>
          </div>
        </div>
      </div>
    </div>
  </section>;
}

