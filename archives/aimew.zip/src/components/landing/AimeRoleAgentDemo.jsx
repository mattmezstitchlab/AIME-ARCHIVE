import React from "react";
import { ArrowDown } from "lucide-react";

const roles = [
  ["Couple", "Construire notre édition", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/0539748d5_01-hero-couple.png", "Je rassemble les décisions, les proches et les lieux pour construire votre édition sans vous faire recommencer."],
  ["Témoin", "Accompagner les moments clés", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/1a4946310_13-hero-role-temoin-temoin.png", "Je vous montre uniquement les moments où votre présence et vos actions sont utiles."],
  ["Famille", "Trouver sa juste place", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/f17478051_14-hero-role-famille-famille.png", "Je réunis les informations familiales utiles, la table, les horaires et les contributions autorisées."],
  ["Invité", "Vivre et contribuer", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/ec2e5cdc1_15-hero-role-invite-invite.png", "Je vous conduis vers votre invitation vivante, le lieu, votre musique et les informations qui vous concernent."],
  ["Coordinateur", "Orchestrer toute l’édition", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/76c9e2147_16-hero-role-coordinateur-coordinateur.png", "J’ouvre le cockpit, le cadran causal et les points à sécuriser maintenant."],
  ["Prestataire", "Recevoir un briefing clair", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/502fb14e8_17-hero-role-prestataire-prestataire.png", "Je transforme le déroulé en briefing métier, mission, discussion et paiement au même endroit."],
  ["Lieu", "Accueillir chaque moment", "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/c24b2d3d5_18-hero-role-lieu-lieu.png", "Je relie les accès, horaires, plans de repli et positions exactes de chaque moment."],
];

export default function AimeRoleAgentDemo() {
  const openRole = ([title, subtitle, imageUrl, response]) => {
    window.dispatchEvent(new CustomEvent("aime-agent-open", {
      detail: {
        requestId: `${title}-${Date.now()}`,
        card: { title, subtitle, imageUrl },
        response,
        autoSend: true,
        prompt: `Je découvre LE MONDE AIME comme ${title}. Explique-moi mon parcours avec des mots simples, puis propose une seule prochaine action utile. Ne crée aucune donnée avant mon accord.`,
      },
    }));
  };

  return (
    <section id="agent-orchestrateur" className="scroll-mt-24 border-b border-white/10 bg-black py-20 text-white lg:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <p className="text-xs uppercase tracking-[.28em] text-white/45">Entrez par votre rôle</p>
        <div className="mt-5 grid gap-7 lg:grid-cols-[1fr_auto] lg:items-end">
          <div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">AIME vous reconnaît.</h2><p className="mt-6 max-w-2xl text-base leading-8 text-white/58">La personne reste la même. Son rôle donne à l’agent le bon contexte, les bonnes autorisations et la prochaine action utile.</p></div>
          <a href="#cartes-roles" className="inline-flex items-center gap-2 text-xs uppercase tracking-[.18em] text-white/45">Choisir une carte <ArrowDown size={14} /></a>
        </div>
      </div>
      <div id="cartes-roles" className="mt-12 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-4 [scrollbar-width:none] sm:px-8 lg:px-[max(3rem,calc((100vw-80rem)/2))]">
        {roles.map((role) => (
          <button key={role[0]} type="button" onClick={() => openRole(role)} className="group relative aspect-[4/5] w-[72vw] max-w-[20rem] shrink-0 snap-start overflow-hidden rounded-[2rem] bg-[#141414] text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-fuchsia-300">
            <img src={role[2]} alt="" className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.025]" loading="lazy" />
            <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/5" />
            <span className="absolute inset-x-0 bottom-0 p-6 text-white"><b className="block font-display text-3xl font-semibold tracking-[-.04em]">{role[0]}</b><small className="mt-2 block text-sm text-white/72">{role[1]}</small><span className="mt-5 inline-flex rounded-full border border-white/20 bg-black/25 px-3 py-2 text-[9px] uppercase tracking-[.16em] opacity-0 backdrop-blur transition-opacity group-hover:opacity-100">Ouvrir avec l’agent</span></span>
          </button>
        ))}
      </div>
      <p className="mx-auto mt-6 max-w-7xl px-5 text-[10px] uppercase tracking-[.18em] text-white/35 sm:px-8 lg:px-12">Cliquez sur une carte : elle entre dans la conversation et l’agent adapte immédiatement le parcours.</p>
    </section>
  );
}
