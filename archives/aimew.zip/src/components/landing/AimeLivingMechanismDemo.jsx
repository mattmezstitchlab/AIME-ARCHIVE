import { useEffect, useState } from "react";
import { ArrowUpRight, CalendarCheck2, Check, CloudRain, MessageCircle, Minus, Music2, Pause, Play, Plus, Radio, Search, Send, Timer, UsersRound, WalletCards } from "lucide-react";
import { AIME_ORIGINS } from "@/lib/aime-ecosystem";

const moments = [
  ["06:30", "La maison s’éveille", "Maison privée"],
  ["07:00", "Miroirs & pinceaux", "Maison privée"],
  ["07:30", "Les détails qui comptent", "Maison privée"],
  ["08:00", "Fleurs, alliances, tenues", "Maison privée"],
  ["08:30", "Premières images", "Maison privée"],
  ["09:00", "La famille arrive", "Maison privée"],
];

const people = [
  ["Camille", "Coordination", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=160&q=80"],
  ["Antoine", "Invité", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80"],
  ["Clara", "Invitée", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80"],
  ["Maxime", "Ami proche", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=160&q=80"],
  ["Zoé", "Famille", "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=160&q=80"],
];

const profileTabs = ["Profil", "Organisation", "Musique", "Paiements", "Discussion"];

function CausalDial() {
  const [minutes, setMinutes] = useState(17 * 60 + 55);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (!playing) return undefined;
    const timer = window.setInterval(() => setMinutes((value) => (value + 1) % 1440), 900);
    return () => window.clearInterval(timer);
  }, [playing]);

  const hour = Math.floor(minutes / 60);
  const minute = minutes % 60;
  const time = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;

  return <div className="mx-auto mt-5 min-w-0 w-full max-w-[34rem]">
    <div className="flex items-center justify-center gap-3" aria-label="Lecture du cadran causal">
      <button type="button" className="grid size-12 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 text-white shadow-[0_0_30px_rgba(99,102,241,.25)]" aria-label="Déroulé prévu"><CalendarCheck2 size={19}/></button>
      <button type="button" className="grid size-12 place-items-center rounded-full bg-[#191919] text-white/55" aria-label="Horaires"><Timer size={19}/></button>
      <button type="button" className="grid size-12 place-items-center rounded-full bg-[#191919] text-white/55" aria-label="Météo"><CloudRain size={19}/></button>
    </div>
    <div className="relative mx-auto mt-3 aspect-square w-full max-w-[31rem] overflow-hidden">
      <svg viewBox="0 0 400 400" className="absolute inset-0 size-full" aria-hidden="true">
        <defs>
          <linearGradient id="aimeDialMorning" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#2dd4bf"/><stop offset="1" stopColor="#38bdf8"/></linearGradient>
          <linearGradient id="aimeDialEvening" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fb923c"/><stop offset=".55" stopColor="#f43f5e"/><stop offset="1" stopColor="#d946ef"/></linearGradient>
        </defs>
        {Array.from({ length: 24 }, (_, index) => <line key={index} x1="200" y1={index % 6 === 0 ? "11" : "18"} x2="200" y2={index % 6 === 0 ? "25" : "28"} stroke={index % 6 === 0 ? "#777" : "#4a4a4a"} strokeWidth={index % 6 === 0 ? "2" : "1.5"} transform={`rotate(${index * 15} 200 200)`}/>)}
        <circle cx="200" cy="200" r="155" fill="none" stroke="#171717" strokeWidth="12"/>
        <circle cx="200" cy="200" r="155" fill="none" stroke="url(#aimeDialMorning)" strokeWidth="10" strokeLinecap="round" strokeDasharray="210 764" strokeDashoffset="-548" transform="rotate(-90 200 200)"/>
        <circle cx="200" cy="200" r="155" fill="none" stroke="url(#aimeDialEvening)" strokeWidth="10" strokeLinecap="round" strokeDasharray="225 749" strokeDashoffset="-190" transform="rotate(-90 200 200)"/>
        <circle cx="200" cy="200" r="155" fill="none" stroke="#22d3ee" strokeWidth="10" strokeLinecap="round" strokeDasharray="38 936" strokeDashoffset="-445" transform="rotate(-90 200 200)"/>
        <circle cx="200" cy="355" r="5" fill="#080808" stroke="#d946ef" strokeWidth="3"/>
        <line x1="37" y1="200" x2="76" y2="200" stroke="#fb3f58" strokeWidth="4" strokeLinecap="round"/>
        <circle cx="37" cy="200" r="5" fill="#fb3f58"/>
      </svg>
      <span className="absolute left-1/2 top-[1%] -translate-x-1/2 font-mono text-[10px] text-white/40">00</span>
      <span className="absolute right-[1%] top-1/2 -translate-y-1/2 font-mono text-[10px] text-white/40">06</span>
      <span className="absolute bottom-[1%] left-1/2 -translate-x-1/2 font-mono text-[10px] text-white/40">12</span>
      <span className="absolute left-[1%] top-1/2 -translate-y-1/2 font-mono text-[10px] text-white/40">18</span>
      <div className="absolute inset-[27%] grid place-items-center text-center"><div><strong className="block font-mono text-4xl tracking-[-.05em] sm:text-5xl">{time}</strong><button type="button" onClick={() => setPlaying((value) => !value)} className="mx-auto mt-5 grid size-16 place-items-center rounded-full bg-white/55 text-black transition-colors hover:bg-white" aria-label={playing ? "Mettre la simulation en pause" : "Lancer la simulation"}>{playing ? <Pause size={22}/> : <Plus size={24}/>}</button><p className="mt-5 text-[9px] font-bold uppercase tracking-[.25em] text-white/35">Entre deux moments</p></div></div>
    </div>
    <div className="mx-auto -mt-2 flex w-fit items-center rounded-full border border-[#282828] bg-[#111] p-1.5 shadow-2xl"><button type="button" onClick={() => setMinutes((value) => (value - 5 + 1440) % 1440)} className="grid size-11 place-items-center rounded-full bg-[#1a1a1a] text-white/55 hover:text-white" aria-label="Reculer de cinq minutes"><Minus size={17}/></button><button type="button" onClick={() => setPlaying((value) => !value)} className="mx-1 grid size-11 place-items-center rounded-full border border-violet-500 text-white shadow-[0_0_18px_rgba(168,85,247,.2)]" aria-label={playing ? "Pause" : "Lire"}>{playing ? <Pause size={16}/> : <Play size={16}/>}</button><button type="button" onClick={() => setMinutes((value) => (value + 5) % 1440)} className="grid size-11 place-items-center rounded-full bg-[#1a1a1a] text-white/55 hover:text-white" aria-label="Avancer de cinq minutes"><Plus size={17}/></button></div>
    <p className="mx-auto mt-5 max-w-md text-center text-xs leading-6 text-white/40">Tout est en place — chaque acteur autorisé voit le même cadran.</p>
  </div>;
}

function MusicWave() {
  return <div className="flex h-12 items-center gap-1" aria-label="Onde musicale animée">{[.35,.65,.9,.48,.75,.32,.92,.58,.4,.8,.52,.95,.44,.68,.3,.76,.55,.88].map((scale,index) => <span key={index} className="aime-wave-bar w-1 rounded-full bg-gradient-to-t from-cyan-300 via-violet-400 to-fuchsia-400" style={{ height: `${scale * 100}%`, animationDelay: `${index * -90}ms` }} />)}</div>;
}

function ProfileTabContent({ activeTab }) {
  if (activeTab === "Organisation") return <div className="grid gap-4 sm:grid-cols-3">
    {[['RSVP','Confirmé'],['Table','Table 11'],['Mission','Accueil des proches']].map(([label,value]) => <div key={label} className="rounded-2xl border border-black/10 p-4"><p className="text-[9px] font-bold uppercase tracking-[.2em] text-black/40">{label}</p><div className="mt-4 flex items-center justify-between text-sm font-semibold"><span>{value}</span><span>⌄</span></div></div>)}
    <div className="sm:col-span-3 flex items-center justify-between border-t border-black/10 pt-5"><p className="text-sm text-black/50">Les changements sont transmis à toutes les vues autorisées.</p><button className="rounded-full bg-black px-5 py-3 text-xs font-bold uppercase tracking-[.12em] text-white">Enregistrer</button></div>
  </div>;

  if (activeTab === "Musique") return <div>
    <p className="text-[9px] font-bold uppercase tracking-[.23em] text-black/45">Morceau signature</p>
    <div className="mt-5 grid items-center gap-4 rounded-2xl bg-[#e9e9e6] p-5 sm:grid-cols-[3.5rem_1fr_auto]"><span className="grid size-14 place-items-center rounded-full bg-black text-white"><Music2 size={18} /></span><div><strong className="text-base">I Wanna Dance with Somebody</strong><p className="mt-1 text-xs text-black/45">Whitney Houston · partagé avec le DJ</p></div><MusicWave /></div>
    <div className="mt-5 flex items-center gap-3 rounded-full border border-black/10 px-5 py-3 text-black/40"><span className="flex-1 text-sm">Titre ou artiste…</span><Search size={18} /></div>
  </div>;

  if (activeTab === "Paiements") return <div>
    <div className="flex items-center justify-between"><p className="text-[9px] font-bold uppercase tracking-[.23em] text-black/45">Paiements du profil</p><WalletCards size={18} /></div>
    <div className="mt-6 grid gap-3 sm:grid-cols-[1fr_1fr_auto]"><button className="rounded-2xl border border-black/10 px-5 py-4 text-left text-sm">Participation commune <span className="float-right">⌄</span></button><div className="rounded-2xl border border-black/10 px-5 py-4 text-sm text-black/35">Montant <b className="float-right text-black">€</b></div><button className="rounded-2xl bg-black px-6 py-4 text-xs font-bold uppercase tracking-[.12em] text-white">Payer</button></div>
    <p className="mt-5 text-xs leading-5 text-black/45">Un même geste de paiement, selon les droits : prestataire, invité, association ou relais.</p>
  </div>;

  if (activeTab === "Discussion") return <div>
    <div className="flex items-center gap-2"><MessageCircle size={17} /><p className="text-[9px] font-bold uppercase tracking-[.23em] text-black/45">Fil de discussion · 2</p></div>
    <div className="mt-5 space-y-3"><p className="max-w-[80%] rounded-2xl bg-[#e9e9e6] px-4 py-3 text-sm">J’arrive au lieu dans 12 minutes.</p><p className="ml-auto max-w-[80%] rounded-2xl bg-black px-4 py-3 text-sm text-white">Parfait, le relais est prêt.</p></div>
    <div className="mt-5 flex items-center gap-3 rounded-full border border-black/10 p-2 pl-5 text-black/40"><span className="flex-1 text-sm">Écrire un commentaire…</span><span className="grid size-10 place-items-center rounded-full bg-black text-white"><Send size={16} /></span></div>
  </div>;

  return <div className="grid gap-7 sm:grid-cols-2">
    <div><p className="text-[9px] font-bold uppercase tracking-[.23em] text-black/45">Mission · 05:30</p><p className="mt-5 text-lg leading-7">Accueillir les proches et confirmer le premier relais.</p></div>
    <div><p className="text-[9px] font-bold uppercase tracking-[.23em] text-black/45">RSVP · Table</p><p className="mt-5 text-lg leading-7">Présence confirmée · Table 11</p></div>
  </div>;
}

function ProfileFunctionScreen() {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setActiveIndex((index) => (index + 1) % profileTabs.length), 5200);
    return () => window.clearInterval(timer);
  }, []);

  const activeTab = profileTabs[activeIndex];

  return <div className="mt-5 overflow-hidden rounded-[2rem] border border-[#242424] bg-[#f2f2ef] text-black">
    <div className="border-b border-black/10 px-6 py-5 sm:px-8"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-[9px] font-bold uppercase tracking-[.25em] text-black/40">Passeport vivant · Démonstration interactive</p><h3 className="mt-2 font-display text-3xl font-semibold tracking-[-.04em] sm:text-4xl">Un moment. Toutes ses dimensions.</h3></div><p className="max-w-sm text-xs leading-5 text-black/45">Le contenu, les personnes et les droits restent reliés. Les onglets ne changent que la lecture utile.</p></div></div>
    <div className="grid min-h-[42rem] lg:grid-cols-[18rem_minmax(0,1fr)_19rem]">
      <aside className="relative min-h-[24rem] overflow-hidden border-b border-black/10 bg-[#d8d8d4] lg:border-b-0 lg:border-r">
        <img src={people[4][2]} alt="Portrait de Zoé" className="absolute inset-0 size-full object-cover grayscale" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/10" />
        <div className="absolute inset-x-0 bottom-0 p-6 text-white"><p className="text-[9px] font-bold uppercase tracking-[.22em] text-white/60">Réseau proche</p><strong className="mt-2 block font-display text-4xl tracking-[-.05em]">Zoé Richard</strong><p className="mt-2 text-xs text-white/60">Famille · Table 11</p></div>
      </aside>

      <article className="min-w-0 p-6 sm:p-9 lg:p-10"><div className="flex items-start justify-between gap-5"><div><p className="text-[9px] font-bold uppercase tracking-[.24em] text-black/45">Famille</p><h4 className="mt-3 font-display text-5xl font-semibold tracking-[-.06em] sm:text-6xl">Zoé Richard</h4></div><img src={people[0][2]} alt="" className="size-12 rounded-full object-cover" /></div>
        <div className="mt-8 flex gap-1 overflow-x-auto border-b border-black/10 pb-4">{profileTabs.map((tab,index) => <button key={tab} onClick={() => setActiveIndex(index)} className={`shrink-0 rounded-full px-4 py-3 text-[10px] font-bold uppercase tracking-[.12em] transition-colors ${activeIndex === index ? "bg-black text-white" : "text-black/45 hover:bg-black/[.05] hover:text-black"}`}>{tab}</button>)}</div>
        <div className="min-h-[19rem] py-8"><ProfileTabContent activeTab={activeTab} /></div>
        <div className="flex items-center justify-between border-t border-black/10 pt-5"><p className="text-[9px] font-bold uppercase tracking-[.2em] text-black/35">Écran {String(activeIndex + 1).padStart(2,'0')} / {String(profileTabs.length).padStart(2,'0')}</p><div className="flex gap-2">{profileTabs.map((tab,index) => <button key={tab} aria-label={`Afficher ${tab}`} onClick={() => setActiveIndex(index)} className={`h-1.5 rounded-full transition-all ${activeIndex === index ? "w-8 bg-black" : "w-2 bg-black/20"}`} />)}</div></div>
      </article>

      <aside className="relative max-h-[48rem] overflow-hidden border-t border-[#3a3a3a] bg-[#282828] p-6 text-white lg:border-l lg:border-t-0"><div className="relative z-10 -mx-6 -mt-6 flex items-center justify-between border-b border-[#3a3a3a] bg-[#282828] px-6 pb-5 pt-6"><div className="flex items-center gap-2"><UsersRound size={17} /><p className="text-xs font-bold uppercase tracking-[.16em]">Invités du moment</p></div><span className="text-[9px] text-white/35">86/100</span></div><div className="aime-people-rail mt-3">{[...people,...people].map(([name,role,image],index) => <a href={`${AIME_ORIGINS.edition}/e/edition-demo-aime`} key={`${name}-${index}`} className="flex items-center gap-3 border-b border-[#3a3a3a] py-4"><img src={image} alt="" className="size-11 rounded-full object-cover grayscale" /><span className="min-w-0 flex-1"><b className="block truncate text-sm">{name}</b><small className="text-[9px] uppercase tracking-[.12em] text-white/40">{role}</small></span><Check size={14} className="text-emerald-300" /></a>)}</div></aside>
    </div>
  </div>;
}

export default function AimeLivingMechanismDemo() {
  return <section id="passeport-vivant" className="scroll-mt-24 border-y border-[#242424] bg-[#050505] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.7fr_1.3fr] lg:items-end"><p className="text-xs uppercase tracking-[.28em] text-white/40">Démonstration vivante</p><div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Le passeport du moment.<br />Sans quitter la page.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Horaires, causalité, personnes, musique et droits ne sont pas des pages isolées : ce sont des lectures synchronisées d’un même passeport vivant.</p></div></div>

      <div className="mt-14 grid min-w-0 overflow-hidden rounded-[2rem] border border-[#242424] xl:grid-cols-[1.08fr_.92fr]">
        <article className="min-h-[42rem] min-w-0 bg-black p-6 sm:p-8"><div className="flex items-start justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.25em] text-white/35">Édition en direct</p><h3 className="mt-4 text-3xl">Tous les horaires</h3></div><Radio className="text-emerald-300" size={18} /></div>
          <div className="mt-7 overflow-hidden bg-[#1c1c1c] py-3 text-[9px] uppercase tracking-[.22em] text-white/45"><div className="aime-context-ticker flex w-max items-center gap-16 whitespace-nowrap"><span>Moment actif · Le jour se lève</span><span>Météo stable · 24°</span><span>86 invités confirmés</span><span>Plan B prêt</span><span>Budget aligné</span><span>Moment actif · Le jour se lève</span></div></div>
          <div className="mt-2 divide-y divide-[#202020]">{moments.map(([time,title,place],index) => <div key={time} className={`group grid grid-cols-[5.4rem_1fr_auto] items-center gap-3 py-5 transition-all ${index === 0 ? "bg-white/[.035] px-3" : "px-3 hover:bg-white/[.025]"}`}><strong className="font-mono text-xl">{time}</strong><span><b className="block text-sm uppercase tracking-[.03em]">{title}</b><small className="mt-1 block text-[9px] uppercase tracking-[.12em] text-white/35">{place}</small></span><ArrowUpRight size={14} className="text-white/30 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></div>)}</div>
        </article>
        <article className="min-h-[42rem] min-w-0 overflow-hidden border-t border-[#242424] bg-black p-6 sm:p-8 xl:border-l xl:border-t-0"><div className="flex items-start justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.25em] text-white/35">Cadran causal</p><p className="mt-2 text-xs text-white/35">État opérationnel en direct</p></div><span className="rounded-full bg-[#1a1a1a] px-3 py-2 text-[10px]"><i className="mr-2 inline-block size-2 rounded-full bg-emerald-400" />Stable</span></div><CausalDial /></article>
      </div>

      <ProfileFunctionScreen />

      <div className="mt-5 grid items-center gap-6 rounded-[2rem] border border-[#242424] bg-black p-6 sm:grid-cols-[auto_1fr_auto] sm:p-8"><span className="grid size-16 place-items-center rounded-full bg-gradient-to-br from-cyan-300 via-violet-400 to-fuchsia-400 text-black"><Music2 size={21} /></span><div><p className="text-[9px] uppercase tracking-[.24em] text-white/35">Morceau du moment</p><h3 className="mt-2 text-2xl font-semibold">A Thousand Years</h3><p className="mt-1 text-xs text-white/35">Choix partagé · transmis à la playlist DJ</p></div><MusicWave /></div>
    </div>
  </section>;
}
