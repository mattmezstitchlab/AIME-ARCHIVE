import React from "react";
import { ArrowDown, ArrowUpRight, BellRing, Bot, CircleDot, Compass, MapPinned, Network, Route, Sparkles, UserRound } from "lucide-react";
import { AIME_ORIGINS } from "@/lib/aime-ecosystem";
import AimeSystemShowcase from "@/components/landing/AimeSystemShowcase";
import AimeRoleAgentDemo from "@/components/landing/AimeRoleAgentDemo";

const universes = [
  {
    title: "Édition",
    eyebrow: "Organiser ce qui arrive",
    description: "Un événement vivant où personnes, rôles, moments, musique, budget et plans de repli restent reliés.",
    href: AIME_ORIGINS.edition,
  },
  {
    title: "Passeport",
    eyebrow: "Relier ce qui existe déjà",
    description: "Une identité contrôlée, une carte de relais et les bonnes informations accessibles au bon moment.",
    href: AIME_ORIGINS.passport,
  },
  {
    title: "Archives",
    eyebrow: "Comprendre d’où vient l’œuvre",
    description: "Les recherches, les univers et les prototypes qui ont permis de faire émerger l’architecture fusionnelle AIME.",
    href: "/archives#atlas-complet",
  },
  {
    title: "Chroma",
    eyebrow: "Transformer une image en matière",
    description: "Une chromathèque et une grille vivante pour composer, broder, reprendre et transmettre un patron DMC.",
    href: `${AIME_ORIGINS.chroma}/broderie`,
  },
];

const mechanisms = [
  {
    icon: Compass,
    number: "01",
    title: "La capsule de navigation",
    text: "Le repère commun de tout AIME. Elle permet de changer d’univers sans perdre son compte, son contexte ni l’action en cours.",
    detail: "Édition · Passeport · Archives · Compte · Création",
  },
  {
    icon: Bot,
    number: "02",
    title: "La capsule agent",
    text: "L’agent sait sur quelle page, dans quel événement et auprès de quelle personne il intervient. Il accompagne sans imposer.",
    detail: "Contexte · Dialogue · Proposition · Validation humaine",
  },
  {
    icon: BellRing,
    number: "03",
    title: "Le centre de signaux",
    text: "Météo, budget, délai, distance ou urgence apparaissent dans un seul signal vivant dont la couleur exprime immédiatement l’état.",
    detail: "Calme · Surveillance · Urgence · J-x · Compte à rebours",
  },
  {
    icon: Network,
    number: "04",
    title: "Le moteur causal",
    text: "Une modification ne reste pas isolée : le moteur révèle les personnes, horaires, lieux, documents et plans qu’elle peut affecter.",
    detail: "Cause · Conséquences · Relais · Décision",
  },
  {
    icon: MapPinned,
    number: "05",
    title: "La carte et les relais",
    text: "Les lieux deviennent des étapes reliées. Un trajet, une collecte ou une tournée peut être lu sur la carte et suivi comme une chaîne vivante.",
    detail: "Points · Itinéraire · GPS · Passage de relais · Preuve",
  },
  {
    icon: UserRound,
    number: "06",
    title: "La fiche universelle",
    text: "Une personne n’est jamais enfermée dans un rôle. Sa même fiche propose la bonne vue selon qu’elle est invitée, proche, professionnelle ou organisatrice.",
    detail: "Profil · Rôle · Autorisation · Mission · Paiement · Musique",
  },
];

export default function AimeLandingSections() {
  return (
    <div className="relative z-10 bg-black text-white">
      <section className="border-y border-white/10 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.75fr_1.25fr] lg:items-start">
          <div className="lg:sticky lg:top-28">
            <p className="text-xs uppercase tracking-[0.28em] text-white/50">Le concept AIME</p>
            <h2 className="mt-6 font-display text-4xl font-semibold leading-[0.95] tracking-[-0.055em] sm:text-6xl">Un seul monde.<br />Plusieurs façons d’agir.</h2>
          </div>
          <div className="space-y-10 text-xl leading-9 text-white/76 sm:text-2xl sm:leading-10">
            <p>AIME ne fusionne pas simplement trois sites. Il crée une continuité : une même personne peut préparer, vivre, transmettre ou relayer sans recommencer son parcours.</p>
            <p>Le contexte change l’interface, les droits et les outils. Le compte, les liens et la mémoire utile restent les mêmes.</p>
            <a href="#moteur-aime" className="inline-flex min-h-12 items-center gap-3 rounded-full border border-white/20 px-5 text-sm text-white transition-colors hover:bg-white hover:text-black">Comprendre le fonctionnement <ArrowDown className="h-4 w-4" /></a>
          </div>
        </div>
      </section>

      <section id="moteur-aime" className="scroll-mt-24 border-b border-white/10 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-8 lg:grid-cols-[0.55fr_1.45fr] lg:items-end">
            <p className="text-xs uppercase tracking-[0.28em] text-white/50">Anatomie de l’œuvre finale</p>
            <div><h2 className="font-display text-5xl font-semibold leading-[0.88] tracking-[-0.065em] sm:text-7xl lg:text-8xl">Un moteur commun.<br />Six organes vivants.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/62">L’innovation n’est pas une accumulation de fonctions. Chaque élément transmet son contexte au suivant pour former une seule expérience continue.</p></div>
          </div>
          <div className="mt-14 grid gap-px overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 md:grid-cols-2 lg:grid-cols-3">
            {mechanisms.map(({ icon: Icon, number, title, text, detail }) => (
              <article key={number} className="group flex min-h-[25rem] flex-col bg-black p-7 transition-colors hover:bg-[#f3f3ef] hover:text-black sm:p-8">
                <div className="flex items-center justify-between"><span className="text-xs tracking-[0.22em] opacity-40">{number}</span><span className="grid size-11 place-items-center rounded-full border border-current/15"><Icon className="h-5 w-5" /></span></div>
                <div className="mt-auto"><h3 className="font-display text-3xl font-semibold leading-none tracking-[-0.045em] sm:text-4xl">{title}</h3><p className="mt-5 text-sm leading-7 opacity-65">{text}</p><p className="mt-7 border-t border-current/15 pt-5 text-[10px] uppercase leading-5 tracking-[0.18em] opacity-45">{detail}</p></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <AimeSystemShowcase />
      <AimeRoleAgentDemo />

      <section id="univers-aime" className="scroll-mt-24 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <div className="mb-12 grid gap-6 lg:grid-cols-2 lg:items-end">
            <h2 className="font-display text-4xl font-semibold tracking-[-0.05em] sm:text-6xl">Quatre portes.<br />Un même système.</h2>
            <p className="max-w-xl text-base leading-8 text-white/65">Chaque univers garde sa personnalité. La capsule commune permet de passer de l’un à l’autre avec les mêmes repères.</p>
          </div>
          <div className="grid gap-px overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
            {universes.map((universe, index) => (
              <a key={universe.title} href={universe.href} className="group flex min-h-[23rem] flex-col justify-between bg-black p-7 transition-colors hover:bg-white hover:text-black sm:p-9">
                <div className="flex items-center justify-between"><span className="text-xs uppercase tracking-[0.24em] opacity-50">0{index + 1}</span><ArrowUpRight className="h-5 w-5 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></div>
                <div><p className="text-xs uppercase tracking-[0.22em] opacity-55">{universe.eyebrow}</p><h3 className="mt-4 font-display text-4xl font-semibold tracking-[-0.05em]">{universe.title}</h3><p className="mt-5 text-sm leading-7 opacity-70">{universe.description}</p></div>
              </a>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-white/10 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <p className="text-xs uppercase tracking-[0.28em] text-white/50">Ce que le système accomplit</p>
          <div className="mt-10 grid gap-5 lg:grid-cols-3">
            {[
              [CircleDot, "Comprendre", "Le système reconnaît le contexte, le rôle, le moment et ce qui mérite l’attention."],
              [Route, "Relier", "Personnes, lieux, documents, paiements et relais deviennent une chaîne lisible plutôt que des pages isolées."],
              [Sparkles, "Agir", "L’agent propose la prochaine action utile tout en laissant les décisions sensibles aux humains."],
            ].map(([Icon, title, text]) => <article key={title} className="rounded-[1.7rem] border border-white/10 bg-white/[0.035] p-7"><Icon className="h-6 w-6" /><h3 className="mt-10 font-display text-3xl font-semibold tracking-[-0.04em]">{title}</h3><p className="mt-4 text-sm leading-7 text-white/65">{text}</p></article>)}
          </div>
        </div>
      </section>
    </div>
  );
}
