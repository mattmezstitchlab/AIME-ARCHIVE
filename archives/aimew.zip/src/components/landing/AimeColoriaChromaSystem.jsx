import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, CircleDot, Download, Grid3X3, Layers3, Magnet, MousePointer2, Palette, ScanLine, Sparkles, UsersRound } from "lucide-react";
import { AIME_ORIGINS } from "@/lib/aime-ecosystem";

const THREADS = [
  { code: "DMC 3846", name: "Turquoise clair", color: "#06b6d4", symbol: "●" },
  { code: "DMC 907", name: "Perroquet clair", color: "#84cc16", symbol: "×" },
  { code: "DMC 743", name: "Jaune moyen", color: "#facc15", symbol: "+" },
  { code: "DMC 741", name: "Mandarine", color: "#fb923c", symbol: "◆" },
  { code: "DMC 603", name: "Canneberge", color: "#f472b6", symbol: "■" },
  { code: "DMC 208", name: "Lavande foncé", color: "#8b5cf6", symbol: "▲" },
];

const MODES = [
  { id: "stitch", label: "Points", icon: Grid3X3 },
  { id: "backstitch", label: "Backstitch", icon: ScanLine },
  { id: "progress", label: "Progression", icon: Check },
  { id: "together", label: "À distance", icon: UsersRound },
];

const STITCH_TYPES = ["Croix entière", "Demi-point", "¼ et ¾", "Petite", "Point arrière", "Nœud français"];

function hexToRgb(hex) {
  const value = hex.replace("#", "");
  return {
    r: Number.parseInt(value.slice(0, 2), 16),
    g: Number.parseInt(value.slice(2, 4), 16),
    b: Number.parseInt(value.slice(4, 6), 16),
  };
}

function rgbToLab({ r, g, b }) {
  const linear = [r, g, b].map((value) => {
    const channel = value / 255;
    return channel > 0.04045 ? ((channel + 0.055) / 1.055) ** 2.4 : channel / 12.92;
  });
  const x = (linear[0] * 0.4124 + linear[1] * 0.3576 + linear[2] * 0.1805) / 0.95047;
  const y = linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
  const z = (linear[0] * 0.0193 + linear[1] * 0.1192 + linear[2] * 0.9505) / 1.08883;
  const pivot = (value) => value > 0.008856 ? Math.cbrt(value) : (7.787 * value) + (16 / 116);
  const [fx, fy, fz] = [pivot(x), pivot(y), pivot(z)];
  return { l: (116 * fy) - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) };
}

function nearestThread(hex) {
  const source = rgbToLab(hexToRgb(hex));
  return THREADS.reduce((best, thread) => {
    const target = rgbToLab(hexToRgb(thread.color));
    const distance = Math.sqrt((source.l - target.l) ** 2 + (source.a - target.a) ** 2 + (source.b - target.b) ** 2);
    return distance < best.distance ? { ...thread, distance } : best;
  }, { ...THREADS[0], distance: Number.POSITIVE_INFINITY });
}

function createGrid() {
  return Array.from({ length: 140 }, (_, index) => {
    const x = index % 14;
    const y = Math.floor(index / 14);
    const wave = Math.sin(x * 0.72) + Math.cos(y * 0.83) + Math.sin((x + y) * 0.38);
    const threadIndex = Math.max(0, Math.min(THREADS.length - 1, Math.floor(((wave + 3) / 6) * THREADS.length)));
    return { id: index, x, y, thread: THREADS[threadIndex] };
  });
}

function UniversalGrid({ mode, selectedThread, completed, setCompleted }) {
  const cells = useMemo(createGrid, []);
  const toggleCell = (cell) => {
    const next = new Set(completed);
    if (next.has(cell.id)) next.delete(cell.id);
    else next.add(cell.id);
    setCompleted(next);
  };

  return <div className="relative overflow-hidden rounded-[1.75rem] border border-[#272727] bg-[#090909]">
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#262626] px-5 py-4">
      <div><p className="text-[9px] uppercase tracking-[.2em] text-white/35">Grille magnétique · 14 × 10</p><p className="mt-1 text-xs text-white/65">Zoom 240 % · repère 30 / 40</p></div>
      <div className="flex items-center gap-2 rounded-full border border-[#2b2b2b] px-3 py-2 text-[9px] uppercase tracking-[.12em] text-white/55"><Magnet size={12} className="text-cyan-300"/> Accrochage actif</div>
    </div>
    <div className="relative overflow-x-auto p-5 sm:p-7">
      <div className="relative mx-auto aspect-[14/10] min-w-[42rem] max-w-[56rem]">
        <div className="absolute inset-0 grid border-l border-t border-white/15" style={{ gridTemplateColumns: "repeat(14, minmax(0, 1fr))", gridTemplateRows: "repeat(10, minmax(0, 1fr))" }}>
          {cells.map((cell) => {
            const isDone = completed.has(cell.id);
            const isSelectedColor = cell.thread.code === selectedThread.code;
            return <button key={cell.id} type="button" aria-label={`Case ${cell.x + 1}, ${cell.y + 1}, ${cell.thread.code}`} onClick={() => toggleCell(cell)} className={`relative grid place-items-center border-b border-r text-[10px] transition-all sm:text-xs ${cell.x % 5 === 4 ? "border-r-white/25" : "border-r-white/10"} ${cell.y % 5 === 4 ? "border-b-white/25" : "border-b-white/10"} ${isSelectedColor ? "z-[1] ring-1 ring-inset ring-white/70" : ""} ${mode === "progress" && !isDone ? "opacity-20 grayscale" : ""}`} style={{ backgroundColor: `${cell.thread.color}${isDone ? "d9" : "66"}` }}>
              <span className="font-mono text-white drop-shadow-[0_1px_2px_rgba(0,0,0,.85)]">{isDone && mode === "progress" ? "✓" : cell.thread.symbol}</span>
              {isSelectedColor && cell.id === 73 && <motion.span layoutId="magnetic-cursor" className="pointer-events-none absolute inset-[-4px] border border-cyan-200 shadow-[0_0_18px_rgba(103,232,249,.6)]"/>}
            </button>;
          })}
        </div>
        <svg viewBox="0 0 700 500" className={`pointer-events-none absolute inset-0 size-full transition-opacity ${mode === "backstitch" ? "opacity-100" : "opacity-35"}`} aria-hidden="true">
          <path d="M 72 395 C 145 315, 186 352, 255 262 S 370 218, 429 142 S 535 92, 632 124" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M 72 395 C 145 315, 186 352, 255 262 S 370 218, 429 142 S 535 92, 632 124" fill="none" stroke="#f472b6" strokeWidth="2" strokeDasharray="9 9" strokeLinecap="round"/>
        </svg>
        <AnimatePresence>{mode === "together" && <>
          <motion.div initial={{ opacity: 0, scale: .7 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="absolute left-[18%] top-[24%]"><MousePointer2 size={21} className="fill-cyan-300 text-cyan-300"/><span className="ml-4 rounded-full bg-cyan-300 px-2 py-1 text-[8px] font-bold text-black">Lina</span></motion.div>
          <motion.div initial={{ opacity: 0, scale: .7 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ delay: .12 }} className="absolute bottom-[18%] right-[21%]"><MousePointer2 size={21} className="fill-fuchsia-400 text-fuchsia-400"/><span className="ml-4 rounded-full bg-fuchsia-400 px-2 py-1 text-[8px] font-bold text-black">Maya</span></motion.div>
        </>}</AnimatePresence>
      </div>
    </div>
    <div className="grid gap-px border-t border-[#262626] bg-[#262626] sm:grid-cols-3">
      {[['Tissu','Aïda 16 ct'],['Dimension','21,6 × 15,4 cm'],['Progression',`${completed.size} / 140 points`]].map(([label,value]) => <div key={label} className="bg-[#0d0d0d] px-5 py-4"><small className="text-[8px] uppercase tracking-[.16em] text-white/30">{label}</small><b className="mt-1 block text-xs text-white/72">{value}</b></div>)}
    </div>
  </div>;
}

export default function AimeColoriaChromaSystem() {
  const [mode, setMode] = useState("stitch");
  const [sourceColor, setSourceColor] = useState("#7c3aed");
  const [selectedCode, setSelectedCode] = useState(THREADS[5].code);
  const [completed, setCompleted] = useState(new Set([17, 18, 31, 32, 45, 46, 59, 60, 73]));
  const suggestedThread = nearestThread(sourceColor);
  const selectedThread = THREADS.find((thread) => thread.code === selectedCode) || THREADS[0];
  const sourceRgb = hexToRgb(sourceColor);

  return <section id="grille-universelle" className="overflow-hidden border-y border-[#242424] bg-[#050505] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[.68fr_1.32fr] lg:items-end">
        <div><p className="text-xs uppercase tracking-[.28em] text-white/40">08 · Coloria × Chroma</p><span className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#2b2b2b] bg-white/[.025] px-4 py-2 text-[9px] uppercase tracking-[.16em] text-white/60"><Sparkles size={13} className="text-fuchsia-300"/> Matière créative</span></div>
        <div><h2 className="font-display text-5xl font-semibold leading-[.88] tracking-[-.065em] sm:text-7xl">La couleur devient<br/>une grille vivante.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Colorier ensemble à distance, transformer une image en patron, retrouver chaque fil et reprendre exactement au dernier point. Le document n’est plus une page figée : c’est un espace de fabrication partagé.</p></div>
      </div>

      <div className="mt-14 grid gap-5 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <div>
          <div className="mb-3 flex gap-2 overflow-x-auto pb-1">{MODES.map(({ id,label,icon:Icon }) => <button key={id} type="button" onClick={() => setMode(id)} className={`inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full px-4 text-[9px] font-bold uppercase tracking-[.12em] transition-colors ${mode === id ? "bg-white text-black" : "border border-[#2c2c2c] text-white/48 hover:text-white"}`}><Icon size={13}/>{label}</button>)}</div>
          <UniversalGrid mode={mode} selectedThread={selectedThread} completed={completed} setCompleted={setCompleted}/>
        </div>

        <aside className="rounded-[1.75rem] border border-[#272727] bg-[#0b0b0b] p-5 sm:p-6">
          <div className="flex items-start justify-between"><span className="grid size-11 place-items-center rounded-full bg-gradient-to-br from-cyan-300 via-violet-400 to-fuchsia-400 text-black"><Palette size={17}/></span><span className="font-mono text-[9px] text-white/28">16 777 216</span></div>
          <p className="mt-7 text-[9px] uppercase tracking-[.2em] text-white/35">Chromathèque source</p><h3 className="mt-3 font-display text-3xl font-semibold leading-[.95] tracking-[-.05em]">Toute couleur numérique.<br/>Un fil possible.</h3>
          <label className="mt-6 flex items-center gap-3 rounded-2xl border border-[#292929] p-3"><input type="color" value={sourceColor} onChange={(event) => setSourceColor(event.target.value)} className="size-11 cursor-pointer overflow-hidden rounded-xl border-0 bg-transparent" aria-label="Choisir une couleur source"/><span><small className="block text-[8px] uppercase tracking-[.16em] text-white/30">Couleur source</small><b className="mt-1 block font-mono text-xs uppercase">{sourceColor} · {sourceRgb.r}/{sourceRgb.g}/{sourceRgb.b}</b></span></label>
          <div className="mt-3 rounded-2xl border border-[#292929] p-4"><small className="text-[8px] uppercase tracking-[.16em] text-white/30">Correspondance perceptuelle proposée</small><div className="mt-3 flex items-center gap-3"><i className="size-9 rounded-full border border-white/10" style={{ backgroundColor: suggestedThread.color }}/><div><b className="block text-xs">{suggestedThread.code}</b><span className="mt-1 block text-[9px] text-white/40">{suggestedThread.name} · ΔE {suggestedThread.distance.toFixed(1)} · à valider</span></div></div></div>
          <p className="mt-5 text-[9px] leading-5 text-white/35">La chromathèque conserve la couleur exacte. La palette physique propose ensuite le fil le plus proche sans prétendre que l’écran et le coton sont identiques.</p>
          <div className="mt-6 border-t border-[#292929] pt-5"><div className="flex items-center justify-between"><p className="text-[9px] uppercase tracking-[.2em] text-white/35">Fils du patron</p><span className="text-[8px] text-white/30">6 actifs</span></div><div className="mt-3 space-y-2">{THREADS.map((thread) => <button type="button" key={thread.code} onClick={() => setSelectedCode(thread.code)} className={`flex w-full items-center gap-3 rounded-xl border p-2.5 text-left transition-colors ${selectedCode === thread.code ? "border-white/35 bg-white/[.07]" : "border-[#242424] hover:border-[#383838]"}`}><i className="grid size-8 place-items-center rounded-lg font-mono text-[10px] text-white" style={{ backgroundColor: thread.color }}>{thread.symbol}</i><span className="min-w-0"><b className="block text-[10px]">{thread.code}</b><small className="block truncate text-[8px] text-white/35">{thread.name}</small></span></button>)}</div></div>
        </aside>
      </div>

      <div className="mt-5 grid gap-px overflow-hidden rounded-[1.75rem] bg-[#272727] md:grid-cols-3">
        <article className="bg-[#0b0b0b] p-6"><UsersRound size={19}/><p className="mt-8 text-[9px] uppercase tracking-[.2em] text-white/35">Coloria</p><h3 className="mt-3 text-xl font-semibold">Atelier partagé</h3><p className="mt-3 text-xs leading-6 text-white/45">Code privé, participants, messages, coloriage par numéros et reprise créative à distance.</p></article>
        <article className="bg-[#0b0b0b] p-6"><Layers3 size={19}/><p className="mt-8 text-[9px] uppercase tracking-[.2em] text-white/35">Chroma</p><h3 className="mt-3 text-xl font-semibold">Patron multi-calques</h3><p className="mt-3 text-xs leading-6 text-white/45">Référence, points entiers ou fractionnés, backstitch libre, nœuds, notes et mémoire des versions.</p></article>
        <article className="bg-[#0b0b0b] p-6"><CircleDot size={19}/><p className="mt-8 text-[9px] uppercase tracking-[.2em] text-white/35">AIME</p><h3 className="mt-3 text-xl font-semibold">Guide de fabrication</h3><p className="mt-3 text-xs leading-6 text-white/45">L’agent retrouve la zone, annonce la couleur, compte les points et synchronise l’avancement du groupe.</p></article>
      </div>

      <div className="mt-14 grid gap-8 border-t border-[#282828] pt-10 lg:grid-cols-[.72fr_1.28fr]"><div><p className="text-xs uppercase tracking-[.26em] text-white/35">Au-delà du PDF</p><h3 className="mt-5 font-display text-4xl font-semibold leading-[.92] tracking-[-.055em]">Le patron reste vivant jusqu’au dernier point.</h3></div><div className="grid gap-3 sm:grid-cols-2">{[
        ["Grille magnétique","Zoom, coordonnées, repères 10 × 10, surbrillance par symbole et sélection de zone."],
        ["Matière exacte","Tissu, count, nombre de brins, dimensions, métrage et liste d’achat calculés."],
        ["Tous les gestes",STITCH_TYPES.join(" · ")],
        ["Sorties multiples","Web interactif, grand format, PDF paginé, SVG, liste de fils et lien partagé."],
      ].map(([title,text],index) => <article key={title} className="rounded-[1.4rem] border border-[#292929] p-5"><span className="font-mono text-[9px] text-white/25">0{index + 1}</span><h4 className="mt-5 text-sm font-semibold">{title}</h4><p className="mt-2 text-[10px] leading-5 text-white/42">{text}</p></article>)}</div></div>

      <div className="mt-10 flex flex-wrap items-center justify-between gap-5 rounded-[1.5rem] border border-[#292929] bg-white/[.025] p-5"><div className="flex items-start gap-3"><Download size={16} className="mt-1 text-white/45"/><p className="max-w-3xl text-[10px] leading-5 text-white/42"><b className="text-white/70">Principe de sûreté :</b> l’original, les droits d’usage, la palette de fils et les modifications restent traçables. Les formats machine nécessiteront un adaptateur validé par marque ; ils ne seront jamais simulés par un simple renommage de fichier.</p></div><a href={`${AIME_ORIGINS.chroma}/broderie`} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center rounded-full border border-[#303030] px-5 text-[9px] font-bold uppercase tracking-[.14em] text-white/70 transition hover:border-white/40 hover:bg-white hover:text-black">Ouvrir l’atelier réel →</a></div>
    </div>
  </section>;
}
