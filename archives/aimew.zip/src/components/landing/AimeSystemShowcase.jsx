import { ArrowUpRight, BellRing, Bot, Clock3, MapPin, Navigation, Network, Plus, UserRound } from "lucide-react";
import { AIME_ORIGINS } from "@/lib/aime-ecosystem";

const PROFILE_IMAGE = "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/502fb14e8_17-hero-role-prestataire-prestataire.png";
const WEDDING_IMAGE = "https://media.base44.com/images/public/6a5eeb63433486457d5b747c/c6aaa1b48_01-hero-couple.png";
const WEDDING_VIDEO = "https://media.base44.com/videos/public/6a5eeb63433486457d5b747c/4ba70fcd2_le_couple_de_maries_en_apesant.mp4";

function CapsulePreview() {
  return <div className="flex items-center gap-1 rounded-full border border-black/10 bg-white p-1.5 text-black shadow-2xl"><span className="px-3 text-xs font-bold">AIME<sup>®</sup></span><span className="grid size-9 place-items-center rounded-full bg-black/5"><Network size={15} /></span><span className="grid size-9 place-items-center rounded-full"><UserRound size={15} /></span><span className="grid size-9 place-items-center rounded-full bg-black text-white"><Plus size={16} /></span><span className="grid size-9 place-items-center rounded-full bg-gradient-to-br from-cyan-300 via-violet-400 to-fuchsia-400 text-black"><BellRing size={14} /></span></div>;
}

export default function AimeSystemShowcase() {
  return <section id="ecrans-systeme" className="border-b border-white/10 bg-[#090909] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
    <div className="mx-auto max-w-7xl">
      <div className="grid gap-8 lg:grid-cols-[0.65fr_1.35fr] lg:items-end"><p className="text-xs uppercase tracking-[0.28em] text-white/45">Le système à l’écran</p><div><h2 className="font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Les mêmes composants.<br />Des vues infinies.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/60">Ces extraits reprennent les véritables interfaces d’Édition et de Passeport. Ils montrent comment navigation, agent, fiche, causalité et carte vivent ensemble.</p></div></div>

      <div className="mt-14 overflow-hidden rounded-[2rem] border border-[#242424] bg-black">
        <div className="relative min-h-[48rem] lg:grid lg:grid-cols-[0.72fr_1.28fr]">
          <div className="relative min-h-[28rem] overflow-hidden"><img src={PROFILE_IMAGE} alt="Vue profil issue d’AIME Édition" className="absolute inset-0 h-full w-full object-cover" loading="lazy" /><div className="absolute inset-0 bg-gradient-to-t from-black/55 to-transparent" /><p className="absolute bottom-7 left-7 text-xs uppercase tracking-[0.24em]">Une personne · plusieurs rôles</p></div>
          <div className="relative bg-[#f4f4f0] p-6 text-black sm:p-10 lg:p-14">
            <div className="absolute right-5 top-5"><CapsulePreview /></div>
            <p className="mt-20 text-[10px] font-bold uppercase tracking-[0.25em] text-black/40 lg:mt-10">Fiche universelle · contexte mariage</p>
            <h3 className="mt-5 font-display text-5xl font-semibold tracking-[-0.055em] sm:text-7xl">Camille Renaud</h3>
            <div className="mt-8 flex flex-wrap gap-2 text-[10px] font-bold uppercase tracking-[0.14em]"><span className="rounded-full bg-black px-4 py-3 text-white">Mission</span><span className="rounded-full border border-black/12 px-4 py-3">Paiements</span><span className="rounded-full border border-black/12 px-4 py-3">Musique</span><span className="rounded-full border border-black/12 px-4 py-3">Discussion</span></div>
            <div className="mt-10 grid gap-px overflow-hidden rounded-3xl border border-black/10 bg-black/10 sm:grid-cols-2"><div className="bg-white p-6"><p className="text-[10px] uppercase tracking-widest text-black/40">Intervention</p><p className="mt-5 text-2xl">Vérifier le premier point de situation</p></div><div className="bg-black p-6 text-white"><p className="text-[10px] uppercase tracking-widest text-white/45">Heure d’appel</p><p className="mt-5 font-mono text-5xl">05:30</p></div></div>
            <p className="mt-8 max-w-2xl text-sm leading-7 text-black/55">La photo, les informations et les actions restent sur une seule fiche. Les onglets changent avec les droits de la personne qui la consulte.</p>
          </div>
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <article className="relative min-h-[38rem] overflow-hidden rounded-[2rem] border border-[#242424] bg-[#050505] p-6 sm:p-9">
          <div className="absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(255,255,255,.07)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.07)_1px,transparent_1px)] [background-size:44px_44px]" />
          <div className="relative flex items-start justify-between"><div><p className="text-[10px] uppercase tracking-[0.24em] text-violet-300">Moteur causal</p><h3 className="mt-4 font-display text-4xl font-semibold tracking-[-0.05em]">Voir avant d’agir.</h3></div><span className="grid size-12 place-items-center rounded-full bg-gradient-to-br from-cyan-300 via-violet-400 to-fuchsia-400 text-black"><Clock3 size={18} /></span></div>
          <div className="relative mx-auto mt-16 grid aspect-square max-w-[24rem] place-items-center rounded-full border border-white/10"><div className="absolute inset-[12%] rounded-full border border-dashed border-violet-300/30" /><div className="grid size-32 place-items-center rounded-full border border-white/15 bg-white/[.06] text-center"><div><strong className="font-mono text-3xl">05:30</strong><span className="mt-1 block text-[9px] uppercase tracking-widest text-white/45">Moment actif</span></div></div>{[["Météo","32°"],["Budget","850 €"],["Plan B","Prêt"],["Relais","3 actifs"]].map(([label,value], index) => <div key={label} className={`absolute rounded-2xl border border-white/10 bg-black/80 px-4 py-3 ${index===0?"left-0 top-8":index===1?"right-0 top-8":index===2?"bottom-8 left-0":"bottom-8 right-0"}`}><span className="block text-[8px] uppercase tracking-widest text-white/35">{label}</span><strong className="mt-1 block text-sm">{value}</strong></div>)}</div>
          <div className="relative mt-10 flex items-center gap-3 rounded-full border border-white/10 bg-white/[.05] p-2"><span className="grid size-10 place-items-center rounded-full bg-gradient-to-br from-cyan-300 to-fuchsia-400 text-black"><Bot size={16} /></span><span className="text-sm text-white/45">Que faut-il sécuriser maintenant ?</span></div>
        </article>

        <article className="relative min-h-[38rem] overflow-hidden rounded-[2rem] border border-[#242424] bg-black p-6 sm:p-9">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(59,130,246,.2),transparent_28%),radial-gradient(circle_at_75%_65%,rgba(236,72,153,.18),transparent_30%)]" />
          <div className="relative flex items-start justify-between"><div><p className="text-[10px] uppercase tracking-[0.24em] text-cyan-300">Carte et relais</p><h3 className="mt-4 font-display text-4xl font-semibold tracking-[-0.05em]">Du point A au point B.</h3></div><MapPin className="text-fuchsia-300" /></div>
          <svg viewBox="0 0 100 100" className="relative mt-10 h-[22rem] w-full overflow-visible"><defs><linearGradient id="landing-route" x1="0" x2="1"><stop offset="0" stopColor="#67e8f9" /><stop offset=".5" stopColor="#a78bfa" /><stop offset="1" stopColor="#f472b6" /></linearGradient></defs><path d="M12 78 C 25 15, 54 88, 88 22" fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="4" strokeLinecap="round" /><path d="M12 78 C 25 15, 54 88, 88 22" fill="none" stroke="url(#landing-route)" strokeWidth="1.8" strokeLinecap="round" strokeDasharray="4 3" /><circle cx="12" cy="78" r="3" fill="#67e8f9" stroke="white" /><circle cx="88" cy="22" r="3" fill="#f472b6" stroke="white" /></svg>
          <div className="relative grid grid-cols-3 gap-2"><div className="rounded-2xl border border-white/10 p-4"><span className="text-[8px] uppercase tracking-widest text-white/35">Distance</span><strong className="mt-2 block">684,8 km</strong></div><div className="rounded-2xl border border-white/10 p-4"><span className="text-[8px] uppercase tracking-widest text-white/35">Durée</span><strong className="mt-2 block">7 h 23</strong></div><div className="rounded-2xl border border-violet-300/20 bg-violet-400/10 p-4"><span className="text-[8px] uppercase tracking-widest text-violet-200">Temps</span><strong className="mt-2 block">J-80</strong></div></div>
          <div className="relative mt-5 flex gap-2"><span className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full bg-white text-sm font-semibold text-black"><Navigation size={15} />Suivre le trajet</span><span className="grid size-11 place-items-center rounded-full border border-white/15"><ArrowUpRight size={15} /></span></div>
        </article>
      </div>

      <a href={AIME_ORIGINS.edition} target="_blank" rel="noreferrer" className="group relative mt-5 block min-h-[34rem] overflow-hidden rounded-[2rem] border border-[#242424]"><video src={WEDDING_VIDEO} poster={WEDDING_IMAGE} autoPlay muted loop playsInline preload="metadata" aria-label="Film de la verticalité mariage AIME" className="absolute inset-0 h-full w-full object-cover" /><div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/25 to-transparent" /><div className="relative flex min-h-[34rem] max-w-2xl flex-col justify-between p-7 sm:p-12"><p className="text-xs uppercase tracking-[0.25em] text-white/65">La démonstration totale</p><div><h3 className="font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Le mariage réunit tout.</h3><p className="mt-6 max-w-xl text-base leading-8 text-white/72">Rôles, personnes, lieux, musique, paiements, météo, causalité et plans de repli se rencontrent dans une seule édition vivante.</p><span className="mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-white px-6 text-sm font-semibold text-black">Ouvrir la démonstration <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></span></div></div></a>
    </div>
  </section>;
}
