import { useState } from "react";
import { Check, ChevronLeft, ChevronRight, Clock3, LockKeyhole, MapPin, Music2, Navigation, Pause, Play, Share2, UsersRound } from "lucide-react";

const WEDDING_VIDEO = "https://media.base44.com/videos/public/6a5eeb63433486457d5b747c/4ba70fcd2_le_couple_de_maries_en_apesant.mp4";

const guests = [
  ["Camille", "Témoin", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=140&q=80"],
  ["Noé", "Famille", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=140&q=80"],
  ["Zoé", "Amie proche", "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=140&q=80"],
  ["Léa", "Invitée", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=140&q=80"],
];

const tracks = [
  { title: "Arrival in Light", artist: "AIME Session", notes: [261.63, 329.63, 392] },
  { title: "Golden Hour", artist: "Cocktail Edit", notes: [293.66, 369.99, 440] },
  { title: "Together", artist: "Shared Memory", notes: [329.63, 415.3, 493.88] },
];

function playPreview(notes) {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  const context = new AudioContext();
  const master = context.createGain();
  master.gain.setValueAtTime(0.0001, context.currentTime);
  master.gain.exponentialRampToValueAtTime(0.055, context.currentTime + 0.04);
  master.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 2.2);
  master.connect(context.destination);
  notes.forEach((frequency, index) => {
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = index === 0 ? "sine" : "triangle";
    oscillator.frequency.value = frequency;
    gain.gain.value = 0.35 / notes.length;
    oscillator.connect(gain);
    gain.connect(master);
    oscillator.start(context.currentTime + index * 0.12);
    oscillator.stop(context.currentTime + 2.25);
  });
  window.setTimeout(() => context.close(), 2400);
}

function MiniWave({ active = false }) {
  return <div className="flex h-8 items-center gap-[3px]" aria-label={active ? "Extrait sonore en lecture" : "Extrait sonore arrêté"}>{[.35,.8,.48,.92,.6,.3,.72,.52,.88,.4,.68,.95,.44].map((height,index) => <span key={index} className={`w-[3px] rounded-full bg-gradient-to-t from-cyan-300 via-violet-400 to-fuchsia-400 ${active ? "aime-wave-bar" : "opacity-45"}`} style={{ height: `${height * 100}%`, animationDelay: `${index * -80}ms` }} />)}</div>;
}

function PlaceView() {
  return <div className="grid min-h-[23rem] gap-5 lg:grid-cols-[1fr_.72fr]">
    <div className="relative overflow-hidden rounded-[1.6rem] bg-[#0a0a0a] text-white">
      <div className="absolute inset-0 opacity-25 [background-image:linear-gradient(rgba(255,255,255,.08)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.08)_1px,transparent_1px)] [background-size:42px_42px]" />
      <div className="absolute left-[18%] top-[67%] size-4 rounded-full border-2 border-white bg-cyan-300 shadow-[0_0_28px_rgba(103,232,249,.8)]" />
      <div className="absolute right-[20%] top-[25%] size-4 rounded-full border-2 border-white bg-fuchsia-400 shadow-[0_0_28px_rgba(232,121,249,.8)]" />
      <svg className="absolute inset-0 size-full" viewBox="0 0 600 360" preserveAspectRatio="none" aria-hidden="true"><path d="M120 255 C190 210 180 130 270 165 S380 245 480 90" fill="none" stroke="url(#routeGradient)" strokeWidth="6" strokeDasharray="13 11" strokeLinecap="round"/><defs><linearGradient id="routeGradient"><stop stopColor="#67e8f9"/><stop offset=".5" stopColor="#a78bfa"/><stop offset="1" stopColor="#f472b6"/></linearGradient></defs></svg>
      <div className="absolute bottom-6 left-6"><p className="text-[9px] uppercase tracking-[.23em] text-white/45">Trajet partagé</p><strong className="mt-2 block text-lg">Entrée → Jardin du cocktail</strong></div>
    </div>
    <div className="flex flex-col justify-between rounded-[1.6rem] bg-[#e8e8e4] p-6"><div><MapPin size={20} /><p className="mt-7 text-[9px] font-bold uppercase tracking-[.22em] text-black/40">Lieu de cette section</p><h4 className="mt-3 font-display text-3xl font-semibold tracking-[-.04em]">Maison privée<br />Jardin nord</h4><p className="mt-4 text-sm leading-6 text-black/50">L’adresse exacte reste visible uniquement pour les invités de cette carte.</p></div><button className="mt-8 inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-black px-5 text-sm font-semibold text-white"><Navigation size={15} /> Ouvrir l’itinéraire</button></div>
  </div>;
}

function MusicView({ activeTrack, onPlay }) {
  return <div><div className="flex items-end justify-between gap-5"><div><p className="text-[9px] font-bold uppercase tracking-[.22em] text-black/40">Playlist de la section</p><h4 className="mt-3 font-display text-4xl font-semibold tracking-[-.05em]">La bande-son du cocktail.</h4></div><Music2 size={22} /></div><div className="mt-7 divide-y divide-black/10 border-y border-black/10">{tracks.map((track,index) => <button key={track.title} onClick={() => onPlay(index)} className="grid w-full grid-cols-[3rem_1fr_auto] items-center gap-4 py-4 text-left"><span className={`grid size-11 place-items-center rounded-full ${activeTrack === index ? "bg-black text-white" : "bg-black/[.06]"}`}>{activeTrack === index ? <Pause size={15} /> : <Play size={15} />}</span><span><b className="block text-sm">{track.title}</b><small className="mt-1 block text-[10px] text-black/40">{track.artist}</small></span><MiniWave active={activeTrack === index} /></button>)}</div><p className="mt-5 text-xs leading-5 text-black/45">Dans la démonstration, les extraits sont des signatures sonores synthétiques. La carte finale accueillera les morceaux autorisés de l’événement.</p></div>;
}

function GuestView() {
  return <div><div className="flex items-end justify-between gap-5"><div><p className="text-[9px] font-bold uppercase tracking-[.22em] text-black/40">Accès à cette section</p><h4 className="mt-3 font-display text-4xl font-semibold tracking-[-.05em]">42 invités concernés.</h4></div><UsersRound size={22} /></div><div className="mt-7 grid gap-3 sm:grid-cols-2">{guests.map(([name,role,image]) => <div key={name} className="flex items-center gap-3 rounded-2xl bg-[#e8e8e4] p-4"><img src={image} alt="" className="size-12 rounded-full object-cover grayscale"/><span className="min-w-0 flex-1"><b className="block">{name}</b><small className="text-[9px] uppercase tracking-[.14em] text-black/40">{role}</small></span><Check size={15} className="text-emerald-600" /></div>)}</div><div className="mt-5 flex items-center gap-3 rounded-2xl border border-black/10 p-4 text-xs text-black/50"><LockKeyhole size={16} /> Ces personnes voient uniquement le vin d’honneur et ses informations utiles.</div></div>;
}

function OverviewView() {
  return <div className="grid min-h-[23rem] gap-7 sm:grid-cols-2"><div><p className="text-[9px] font-bold uppercase tracking-[.22em] text-black/40">Le moment partagé</p><h4 className="mt-4 font-display text-5xl font-semibold leading-[.9] tracking-[-.06em]">Se retrouver.<br />Avant la fête.</h4><p className="mt-6 max-w-md text-sm leading-7 text-black/55">Une carte suffit pour recevoir l’heure, le lieu, les personnes concernées et la musique de ce moment — sans ouvrir le reste du mariage.</p></div><div className="grid content-start gap-3">{[[Clock3,"18:30","Début du cocktail"],[MapPin,"Jardin nord","Lieu autorisé"],[Music2,"3 morceaux","Playlist partagée"],[UsersRound,"42 personnes","Invités concernés"]].map(([Icon,value,label]) => <div key={label} className="flex items-center gap-4 rounded-2xl bg-[#e8e8e4] p-4"><span className="grid size-11 place-items-center rounded-full bg-white"><Icon size={16}/></span><span><b className="block text-sm">{value}</b><small className="mt-1 block text-[9px] uppercase tracking-[.14em] text-black/40">{label}</small></span></div>)}</div></div>;
}

export default function AimeSharedLivingCard() {
  const [view, setView] = useState("apercu");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTrack, setActiveTrack] = useState(null);
  const [shared, setShared] = useState(false);

  const handlePlay = (index) => {
    setActiveTrack(index);
    playPreview(tracks[index].notes);
    window.setTimeout(() => setActiveTrack((current) => current === index ? null : current), 2300);
  };

  const handleShare = async () => {
    const shareData = { title: "Vin d’honneur · Camille & Noé", text: "Votre carte vivante AIME", url: `${window.location.origin}/systeme-aime#carte-vivante` };
    try {
      if (navigator.share) await navigator.share(shareData);
      else await navigator.clipboard.writeText(shareData.url);
      setShared(true);
      window.setTimeout(() => setShared(false), 2400);
    } catch {
      // Le partage natif peut être fermé sans modifier la carte.
    }
  };

  const railTitle = view === "musique" ? "Playlist du moment" : "Personnes de cette carte";

  return <section id="carte-vivante" className="border-y border-[#242424] bg-[#080808] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto max-w-7xl"><div className="grid gap-8 lg:grid-cols-[.72fr_1.28fr] lg:items-end"><p className="text-xs uppercase tracking-[.28em] text-white/40">Nouvel objet AIME</p><div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Partager un moment.<br />Pas tout l’événement.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">La carte vivante musicale AIME s’ouvre comme une invitation. Elle ne révèle que la section choisie, avec ses propres accès, son lieu, sa playlist et ses participants.</p></div></div>

    <div className="mt-14 overflow-hidden rounded-[2rem] border border-[#242424] bg-black shadow-[0_35px_100px_rgba(0,0,0,.45)]">
      <div className="relative min-h-[31rem] overflow-hidden"><video src={WEDDING_VIDEO} autoPlay muted loop playsInline className="absolute inset-0 size-full object-cover"/><div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/15 to-black/40"/><div className="absolute inset-x-0 top-0 flex items-center justify-between p-6 sm:p-8"><span className="rounded-full border border-white/20 bg-black/20 px-4 py-2 text-[9px] uppercase tracking-[.2em] backdrop-blur-md">Section 08 / 49</span><button onClick={handleShare} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-5 text-sm font-semibold text-black"><Share2 size={15}/>{shared ? "Lien copié" : "Partager cette carte"}</button></div><div className="absolute inset-x-0 bottom-0 p-7 sm:p-10"><p className="text-[10px] uppercase tracking-[.28em] text-white/60">Camille & Noé · 22 août 2026</p><div className="mt-5 flex flex-wrap items-end justify-between gap-5"><div><strong className="font-mono text-6xl sm:text-8xl">18:30</strong><h3 className="mt-3 font-display text-4xl font-semibold tracking-[-.055em] sm:text-6xl">Vin d’honneur · Cocktail</h3></div><span className="rounded-full bg-black/45 px-4 py-3 text-xs backdrop-blur-md">Carte reçue par invitation</span></div></div></div>

      <div className="grid bg-[#f2f2ef] text-black lg:grid-cols-[20rem_minmax(0,1fr)]">
        <div className="relative min-h-[31rem] overflow-hidden border-b border-black/10 bg-[#171717] text-white lg:border-b-0 lg:border-r">
          <div className="absolute inset-0 overflow-y-auto p-5 pr-4">
            <p className="text-[9px] uppercase tracking-[.2em] text-white/45">{railTitle}</p>
            <button onClick={() => setDrawerOpen(false)} className="absolute right-4 top-4 z-20 grid size-11 place-items-center rounded-full bg-white text-black" aria-label="Refermer le volet média"><ChevronRight size={17}/></button>
            {view === "musique" ? <div className="mt-14 space-y-1">{tracks.map((track,index) => <button key={track.title} onClick={() => handlePlay(index)} className="grid w-full grid-cols-[2.5rem_minmax(0,1fr)_auto] items-center gap-3 border-b border-white/10 py-4 text-left"><span className={`grid size-9 place-items-center rounded-full ${activeTrack === index ? "bg-white text-black" : "bg-white/10 text-white"}`}>{activeTrack === index ? <Pause size={12}/> : <Play size={12}/>}</span><span className="min-w-0"><b className="block truncate text-sm">{track.title}</b><small className="mt-1 block truncate text-[9px] uppercase tracking-[.1em] text-white/35">{track.artist}</small></span><MiniWave active={activeTrack === index}/></button>)}</div> : <div className="mt-14 space-y-3">{guests.map(([name,role,image]) => <div key={name} className="flex items-center gap-3 border-b border-white/10 pb-3"><img src={image} alt="" className="size-10 rounded-full object-cover grayscale"/><span className="min-w-0"><b className="block truncate text-sm">{name}</b><small className="text-[9px] uppercase tracking-[.12em] text-white/35">{role}</small></span></div>)}</div>}
          </div>
          <div className={`absolute inset-0 z-10 transition-transform duration-700 [transition-timing-function:cubic-bezier(.22,1,.36,1)] ${drawerOpen ? "-translate-x-full" : "translate-x-0"}`}>
            <img src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1000&q=88" alt="Jardin du vin d’honneur" className="size-full object-cover"/>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/5 to-black/20"/>
            <button onClick={() => setDrawerOpen(true)} className="absolute inset-x-5 bottom-5 flex items-center justify-between rounded-full bg-black/60 px-5 py-4 text-left text-sm backdrop-blur-md"><span><small className="block text-[8px] uppercase tracking-[.2em] text-white/45">Faire coulisser</small><b className="mt-1 block">{view === "musique" ? "Déplier toute la playlist" : "Voir qui partage ce moment"}</b></span><ChevronLeft size={17}/></button>
            {view === "musique" && <div className="absolute inset-x-5 top-20 rounded-[1.4rem] bg-black/70 p-5 backdrop-blur-xl"><p className="text-[9px] uppercase tracking-[.2em] text-white/45">Playlist sur le volet</p>{tracks.map((track,index) => <button key={track.title} onClick={() => handlePlay(index)} className="mt-3 flex w-full items-center gap-3 border-t border-white/10 pt-3 text-left"><span className="grid size-8 place-items-center rounded-full bg-white text-black">{activeTrack === index ? <Pause size={12}/> : <Play size={12}/>}</span><span className="min-w-0"><b className="block truncate text-xs">{track.title}</b><small className="text-[9px] text-white/40">{track.artist}</small></span></button>)}</div>}
          </div>
        </div>

        <article className="min-w-0 p-6 sm:p-9"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-black/10 pb-5"><div className="flex gap-1 overflow-x-auto">{[["apercu","Aperçu"],["lieu","Lieu"],["musique","Musique"],["invites","Invités"]].map(([id,label]) => <button key={id} onClick={() => setView(id)} className={`rounded-full px-4 py-3 text-[10px] font-bold uppercase tracking-[.13em] transition-colors ${view === id ? "bg-black text-white" : "text-black/45 hover:bg-black/[.05]"}`}>{label}</button>)}</div><span className="inline-flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.16em] text-black/35"><LockKeyhole size={13}/> Fragment autorisé</span></div><div className="py-8">{view === "lieu" ? <PlaceView/> : view === "musique" ? <MusicView activeTrack={activeTrack} onPlay={handlePlay}/> : view === "invites" ? <GuestView/> : <OverviewView/>}</div></article>
      </div>
    </div>
  </div></section>;
}
