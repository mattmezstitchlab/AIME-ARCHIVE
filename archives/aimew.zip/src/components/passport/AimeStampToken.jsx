import { BadgeCheck, Grip } from "lucide-react";

const palettes = {
  gold: "from-[#e9d49a] via-[#b39142] to-[#6f5420] text-[#171006]",
  blue: "from-cyan-200 via-blue-400 to-indigo-800 text-[#050812]",
  rose: "from-rose-200 via-fuchsia-400 to-violet-800 text-[#130510]",
  violet: "from-violet-200 via-violet-500 to-indigo-950 text-[#080612]",
};

export default function AimeStampToken({ stamp, compact = false, draggable = false, selected = false, onClick }) {
  return <button type="button" draggable={draggable} onDragStart={(event) => event.dataTransfer.setData("application/aime-stamp", stamp.id)} onClick={onClick} className={`aime-passport-stamp group relative block shrink-0 overflow-hidden bg-gradient-to-br ${palettes[stamp.color] || palettes.violet} text-left shadow-2xl transition ${compact ? "h-44 w-36" : "h-64 w-52"} ${selected ? "-translate-y-2 ring-2 ring-white/70" : "hover:-translate-y-1"}`} aria-label={`${stamp.title}, ${stamp.code}`}>
    <img src={stamp.portrait} alt="" className="absolute inset-0 size-full object-cover opacity-55 grayscale contrast-125 mix-blend-multiply" />
    <span className="aime-engraving-lines absolute inset-0 opacity-45" />
    <span className="absolute inset-3 flex flex-col border border-current/45 p-3">
      <span className="flex items-start justify-between gap-2 text-[7px] font-black uppercase tracking-[.18em]"><span>AIME®</span>{draggable ? <Grip size={12}/> : <BadgeCheck size={12}/>}</span>
      <span className="mt-auto"><b className={`block font-display font-semibold leading-[.88] tracking-[-.055em] ${compact ? "text-xl" : "text-3xl"}`}>{stamp.title}</b><small className="mt-2 block text-[7px] font-bold uppercase tracking-[.14em]">{stamp.kind} · {stamp.date}</small><code className="mt-2 block text-[7px] font-black tracking-[.12em]">{stamp.code}</code></span>
    </span>
  </button>;
}

