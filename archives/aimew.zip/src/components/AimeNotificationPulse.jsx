import { useEffect, useMemo, useState } from 'react';
import { Bell } from 'lucide-react';

const PALETTES = {
  calm: { gradient: 'conic-gradient(from 210deg, #34d399, #22d3ee, #3b82f6, #34d399)', glow: 'rgba(34, 211, 238, .3)', label: 'calme' },
  watch: { gradient: 'conic-gradient(from 210deg, #fb923c, #fde047, #f59e0b, #fb923c)', glow: 'rgba(251, 146, 60, .34)', label: 'à surveiller' },
  urgent: { gradient: 'conic-gradient(from 210deg, #fb2c94, #ef4444, #be123c, #fb2c94)', glow: 'rgba(239, 68, 68, .4)', label: 'urgent' },
  timing: { gradient: 'conic-gradient(from 210deg, #8b5cf6, #6366f1, #38bdf8, #8b5cf6)', glow: 'rgba(99, 102, 241, .38)', label: 'temps' },
  info: { gradient: 'conic-gradient(from 210deg, #ffd85a, #ff7d8f, #c58cff, #6fdcff, #ffd85a)', glow: 'rgba(255, 125, 173, .28)', label: 'information' }
};
const PRIORITY = { urgent: 0, watch: 1, timing: 2, info: 3, calm: 4 };

function countdown(targetAt, now) {
  const difference = new Date(targetAt).getTime() - now;
  const absolute = Math.abs(difference);
  const future = difference >= 0;
  const days = Math.floor(absolute / 86400000);
  const hours = Math.floor(absolute / 3600000);
  const minutes = Math.floor(absolute / 60000);
  const seconds = Math.floor(absolute / 1000);
  if (days) return `${future ? 'J−' : 'J+'}${days}`;
  if (hours) return `${future ? '−' : '+'}${hours}h`;
  if (minutes) return `${future ? '−' : '+'}${minutes}m`;
  return `${future ? '−' : '+'}${seconds}s`;
}

export default function AimeNotificationPulse({ signals = [], onClick, active = false }) {
  const visibleSignals = useMemo(() => [...signals.filter(Boolean)].sort((a, b) => (PRIORITY[a.tone] ?? 2) - (PRIORITY[b.tone] ?? 2)), [signals]);
  const [index, setIndex] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { setIndex(0); }, [visibleSignals.length]);
  useEffect(() => {
    if (visibleSignals.length < 2) return undefined;
    const timer = window.setInterval(() => setIndex(value => (value + 1) % visibleSignals.length), 3200);
    return () => window.clearInterval(timer);
  }, [visibleSignals.length]);
  const signal = visibleSignals[index];
  const Icon = signal?.icon || Bell;
  useEffect(() => {
    if (!visibleSignals.some(item => item.targetAt)) return undefined;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [visibleSignals]);
  const countdownValue = signal?.targetAt ? countdown(signal.targetAt, now) : null;
  const overdue = signal?.targetAt && new Date(signal.targetAt).getTime() < now;
  const palette = overdue ? PALETTES.urgent : PALETTES[signal?.tone] || PALETTES.info;
  const displayValue = countdownValue || signal?.value;
  const summary = signal ? `${signal.label} : ${displayValue}` : 'Aucune alerte nouvelle';
  return <button type="button" onClick={() => onClick?.(signal)} aria-label={`Centre de notifications AIME · ${summary} · état ${palette.label}`} aria-expanded={active} data-tone={overdue ? 'urgent' : signal?.tone || 'info'} title={`${summary} · ${palette.label}`} className="relative grid size-11 shrink-0 place-items-center rounded-full transition-[filter,box-shadow] duration-500" style={{ background: palette.gradient, boxShadow: `0 0 18px ${palette.glow}` }}>
    <span className={`grid size-9 place-items-center rounded-full transition-colors ${active ? 'bg-white text-black' : 'bg-black text-white'}`}>{countdownValue ? <strong key={`${signal?.id}-${countdownValue}`} className="animate-[pulse_650ms_ease-out_1] text-[10px] font-bold tabular-nums tracking-[-.04em]">{countdownValue}</strong> : <Icon key={signal?.id || 'empty'} size={18} className="animate-[pulse_650ms_ease-out_1]" />}</span>
    {visibleSignals.length > 0 && <span className="absolute -right-0.5 -top-0.5 grid min-h-4 min-w-4 place-items-center rounded-full border border-black bg-white px-1 text-[8px] font-bold text-black">{visibleSignals.length}</span>}
  </button>;
}
