import { ArrowDown, ArrowUpRight, BellRing, Bot, Check, Clock3, FileCheck2, Grid3X3, Layers3, MapPin, MessageSquareText, Network, PanelsTopLeft, UserRound, WalletCards } from "lucide-react";
import { Link } from "react-router-dom";
import AimeSystemShowcase from "@/components/landing/AimeSystemShowcase";
import AimeLivingMechanismDemo from "@/components/landing/AimeLivingMechanismDemo";
import AimeSharedLivingCard from "@/components/landing/AimeSharedLivingCard";
import AimeDesignSystemEditor from "@/components/landing/AimeDesignSystemEditor";
import AimeNervousSystem from "@/components/landing/AimeNervousSystem";
import AimeAdministrativeSystem from "@/components/landing/AimeAdministrativeSystem";
import AimeColoriaChromaSystem from "@/components/landing/AimeColoriaChromaSystem";
import AimeLivingPassportSystem from "@/components/landing/AimeLivingPassportSystem";
import { AIME_ORIGINS } from "@/lib/aime-ecosystem";

const families = [
  { number: "01", title: "Coquille AIME", origin: "Commun", icon: PanelsTopLeft, description: "Capsule de navigation, sélecteur d’univers, compte commun, création et centre de signaux.", screens: ["Navigation commune", "Sélecteur AIME", "Compte et accessibilité", "Centre de notifications"] },
  { number: "02", title: "Personnes & rôles", origin: "Édition", icon: UserRound, description: "Une seule personne peut être invitée, proche, prestataire, membre d’équipe ou organisatrice selon le contexte.", screens: ["Fiche universelle", "Profil public", "Réseau proche", "Autorisations par vue"] },
  { number: "03", title: "Événement vivant", origin: "Édition", icon: Clock3, description: "Verticalité, moments, équipes, registre, missions et orchestration en temps réel sur une même ligne narrative.", screens: ["Accueil événement", "Verticalité des moments", "Carte vivante partagée", "Cockpit mariage", "Tournée spectacle"] },
  { number: "04", title: "Actions contextuelles", origin: "Édition", icon: WalletCards, description: "Mission, paiement, discussion, musique, budget, météo et plan B apparaissent dans la fiche au bon moment.", screens: ["Mission", "Paiements", "Discussion", "Musique", "Budget · météo · plan B"] },
  { number: "05", title: "Territoire & relais", origin: "Passeport", icon: MapPin, description: "Carte, lieux, associations, relais humains, distance et suivi d’un trajet du point A au point B.", screens: ["Carte du réseau", "Fiche lieu", "Relais associatif", "Suivi GPS", "Mode sport"] },
  { number: "06", title: "Mémoire & création", origin: "Lab + Passeport", icon: Layers3, description: "Onboarding par chapitres, génération documentaire, passeports, archives et studio de création reliés au même moteur.", screens: ["Création de passeport", "Documents automatiques", "Chapitres conditionnels", "Archives", "Administration"] },
  { number: "07", title: "Administration vivante", origin: "Commun", icon: FileCheck2, description: "Chronologie de preuves, dossiers imbriqués, parcours intermittents et modèles versionnés restent reliés au rôle et à leur source.", screens: ["Ligne de preuves", "Dossier multi-organismes", "Espace intermittent", "Fabrique documentaire", "Bureau AIME", "Wallets de validation"] },
  { number: "08", title: "Couleur & grille universelle", origin: "Coloria + Chroma", icon: Grid3X3, description: "Coloriage partagé, chromathèque numérique, fils physiques et patron de broderie restent réunis dans une grille magnétique vivante.", screens: ["Atelier à distance", "Chromathèque 16,7 M", "Grille magnétique", "Points et backstitch", "Progression partagée", "Exports"] },
];

const signals = [
  ["Calme", "Tout est aligné", "from-cyan-300 to-emerald-300"],
  ["Temps", "J-3 · 2 h · 14 min", "from-blue-400 via-violet-400 to-fuchsia-400"],
  ["Surveillance", "Une condition évolue", "from-yellow-300 to-orange-400"],
  ["Urgent", "Une action immédiate", "from-orange-500 to-fuchsia-600"],
];

const contracts = [
  ["Navigation commune", "Composant partagé", "Même capsule, mêmes destinations et mêmes états dans les pages fusionnées."],
  ["Agent orchestrateur", "Composant partagé", "Même conversation contextuelle, même carte injectée et mêmes validations humaines."],
  ["Passeport du moment", "Référence interactive", "Les vraies fiches réutilisent cette structure : personnes, droits, musique, paiements et discussion."],
  ["Carte vivante", "Référence interactive", "Le fragment partagé conserve exactement ce volet média, sa playlist, son lieu et ses participants."],
  ["Annotations", "Couche globale", "Les post-it restent attachés à la page et peuvent maintenant être déplacés par glisser-déposer."],
];

function StickyDemo() {
  return <div className="relative min-h-[28rem] overflow-hidden rounded-[2rem] border border-black/10 bg-[#ecece8] p-7 text-black sm:p-10">
    <div className="absolute inset-0 opacity-55 [background-image:linear-gradient(rgba(0,0,0,.08)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,.08)_1px,transparent_1px)] [background-size:42px_42px]" />
    <div className="relative max-w-xl"><p className="text-[10px] font-bold uppercase tracking-[0.24em] text-black/40">Couche de collaboration</p><h3 className="mt-5 font-display text-5xl font-semibold leading-[0.92] tracking-[-0.06em]">Commenter directement dans la verticalité.</h3><p className="mt-6 max-w-lg text-sm leading-7 text-black/60">Cliquez sur « Annoter », puis n’importe où dans la page. Le post-it mémorise sa position et son écran. Ouvrez-le pour répondre, modifier sa couleur ou le supprimer.</p></div>
    <div className="absolute bottom-10 left-[10%] rotate-[-3deg] bg-[#f6e36a] p-5 shadow-2xl" style={{ fontFamily: '"Bradley Hand", "Comic Sans MS", cursive' }}><p className="text-xl">Et si ce lieu devenait<br />un point de relais ?</p><span className="mt-4 flex items-center gap-1 font-sans text-[9px] uppercase tracking-widest opacity-45"><MessageSquareText size={11} /> 2 réponses</span></div>
    <div className="absolute bottom-16 right-[8%] rotate-2 bg-[#ff9dcb] p-5 shadow-2xl" style={{ fontFamily: '"Bradley Hand", "Comic Sans MS", cursive' }}><p className="text-xl">Demander à AIME<br />de créer le post-it.</p><span className="mt-4 block font-sans text-[9px] uppercase tracking-widest opacity-45">AIME agent</span></div>
  </div>;
}

export default function SystemeAime() {
  return <main className="min-h-screen overflow-x-hidden bg-[#080808] text-white">
    <section className="relative flex min-h-[92svh] flex-col justify-between overflow-hidden px-5 pb-12 pt-28 sm:px-8 lg:px-12">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_15%,rgba(98,224,255,.18),transparent_28%),radial-gradient(circle_at_75%_55%,rgba(232,102,255,.16),transparent_30%)]" />
      <div className="relative mx-auto w-full max-w-7xl"><p className="text-xs uppercase tracking-[0.34em] text-white/50">Bibliothèque vivante · version 01</p><h1 className="mt-7 font-display text-[15vw] font-semibold leading-[0.72] tracking-[-0.085em] sm:text-[11vw]">SYSTÈME<br />AIME</h1></div>
      <div className="relative mx-auto grid w-full max-w-7xl gap-7 border-t border-[#242424] pt-8 lg:grid-cols-[1fr_1fr]"><p className="max-w-2xl font-display text-2xl font-medium leading-tight tracking-[-0.035em] sm:text-4xl">Tous les écrans, les règles et les mécanismes de l’univers AIME dans une seule référence annotable.</p><div className="flex items-end justify-between gap-5"><p className="max-w-lg text-sm leading-7 text-white/55">Ce n’est pas une collection figée. Chaque composant garde le contexte, les droits, le temps, le lieu et les personnes qui l’utilisent.</p><a href="#fondations" aria-label="Voir les fondations" className="grid size-12 shrink-0 place-items-center rounded-full border border-[#2d2d2d]"><ArrowDown size={17} /></a></div></div>
    </section>

    <section id="fondations" className="bg-[#f3f3ef] px-5 py-20 text-black sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto max-w-7xl"><div className="grid gap-8 lg:grid-cols-[.7fr_1.3fr]"><p className="text-xs font-bold uppercase tracking-[0.28em] text-black/40">Fondations visuelles</p><div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Une grammaire unique.<br />Pas un uniforme.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-black/55">Inter reste la typographie commune. Le noir, le blanc, les grands espaces et les capsules donnent la structure ; les couleurs n’apparaissent que pour transmettre un état ou une causalité.</p></div></div>
      <div className="mt-14 grid gap-px overflow-hidden rounded-[2rem] bg-black/10 md:grid-cols-2 lg:grid-cols-4">{[["Typographie","Inter · nette et humaine","Aa"],["Rayon","Capsule · fiche · panneau","32"],["Contraste","Noir / blanc d’abord","100"],["Signal","La couleur a un sens","●"]].map(([title,text,value]) => <article key={title} className="min-h-64 bg-white p-7"><p className="text-[10px] font-bold uppercase tracking-[.22em] text-black/35">{title}</p><strong className="mt-10 block font-display text-7xl font-semibold tracking-[-.08em]">{value}</strong><p className="mt-7 text-sm text-black/55">{text}</p></article>)}</div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{signals.map(([title,text,gradient]) => <article key={title} className="rounded-[1.5rem] border border-black/10 bg-white p-5"><span className={`grid size-12 place-items-center rounded-full bg-gradient-to-br ${gradient}`}><BellRing size={16} /></span><h3 className="mt-5 text-lg font-semibold">{title}</h3><p className="mt-1 text-xs text-black/45">{text}</p></article>)}</div>
    </div></section>

    <AimeDesignSystemEditor />

    <AimeNervousSystem />

    <AimeAdministrativeSystem />

    <AimeLivingPassportSystem />

    <AimeColoriaChromaSystem />

    <section className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto max-w-7xl"><p className="text-xs uppercase tracking-[.28em] text-white/40">Inventaire des écrans</p><h2 className="mt-5 max-w-5xl font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Huit familles couvrent désormais l’écosystème.</h2><div className="mt-14 grid gap-px overflow-hidden rounded-[2rem] bg-[#242424] lg:grid-cols-2">{families.map(({ number,title,origin,icon:Icon,description,screens }) => <article key={number} className="flex min-h-[30rem] flex-col bg-[#0d0d0d] p-7 sm:p-9"><div className="flex items-start justify-between"><span className="font-mono text-sm text-white/35">{number}</span><Icon size={20} /></div><div className="mt-auto"><p className="text-[10px] uppercase tracking-[.22em] text-white/35">{origin}</p><h3 className="mt-4 font-display text-4xl font-semibold tracking-[-.055em] sm:text-5xl">{title}</h3><p className="mt-5 max-w-xl text-sm leading-7 text-white/55">{description}</p><div className="mt-7 flex flex-wrap gap-2">{screens.map((screen) => <span key={screen} className="rounded-full border border-[#2d2d2d] px-3 py-2 text-[10px] uppercase tracking-[.12em] text-white/65">{screen}</span>)}</div></div></article>)}</div></div></section>

    <section className="border-y border-[#242424] bg-[#0c0c0c] px-5 py-20 sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto max-w-7xl"><div className="grid gap-8 lg:grid-cols-[.72fr_1.28fr]"><div><p className="text-xs uppercase tracking-[.28em] text-white/40">Contrat du design system</p><span className="mt-6 inline-flex items-center gap-2 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-4 py-2 text-[10px] font-bold uppercase tracking-[.16em] text-emerald-200"><Check size={13}/> Source de vérité</span></div><div><h2 className="font-display text-5xl font-semibold leading-[.9] tracking-[-.06em] sm:text-7xl">Ce que vous validez ici devient la règle.</h2><p className="mt-7 max-w-3xl text-lg leading-8 text-white/55">Cette page n’est pas une maquette décorative : ses démonstrations sont des composants React exécutables. Les pages fusionnées réutiliseront ces mêmes composants et leurs états, au lieu de les redessiner séparément.</p></div></div><div className="mt-14 divide-y divide-[#2a2a2a] border-y border-[#2a2a2a]">{contracts.map(([name,status,description],index) => <article key={name} className="grid gap-4 py-6 sm:grid-cols-[3rem_1fr_auto] sm:items-center"><span className="font-mono text-xs text-white/30">{String(index + 1).padStart(2,"0")}</span><div><h3 className="text-lg font-semibold">{name}</h3><p className="mt-2 max-w-3xl text-xs leading-6 text-white/45">{description}</p></div><span className="w-fit rounded-full border border-[#303030] px-3 py-2 text-[9px] uppercase tracking-[.14em] text-white/55">{status}</span></article>)}</div></div></section>

    <AimeSystemShowcase />
    <AimeLivingMechanismDemo />
    <AimeSharedLivingCard />

    <section className="bg-white px-5 py-20 text-black sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto grid max-w-7xl gap-5 lg:grid-cols-[1fr_.72fr]"><StickyDemo /><div className="flex flex-col justify-between rounded-[2rem] bg-black p-8 text-white sm:p-10"><div><Bot size={24} /><p className="mt-8 text-[10px] uppercase tracking-[.25em] text-white/40">Depuis l’agent</p><h2 className="mt-5 font-display text-4xl font-semibold leading-[.95] tracking-[-.055em] sm:text-5xl">« Post-it : vérifier ce point avec l’équipe »</h2><p className="mt-7 text-sm leading-7 text-white/55">L’agent ouvre le post-it violet exactement dans la zone consultée. La personne confirme le texte, puis la note reste attachée à cette page et peut être déplacée par glisser-déposer.</p></div><div className="mt-12 space-y-3 text-xs text-white/65">{["Position relative dans la verticalité", "Glisser-déposer sur ordinateur et mobile", "Couleur et source mémorisées", "Fil de réponses", "Visibilité propriétaire / administrateur"].map((item) => <p key={item} className="flex items-center gap-3 border-t border-white/10 pt-3"><Check size={13} />{item}</p>)}</div></div></div></section>

    <section className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto max-w-7xl"><div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{[["Lab",AIME_ORIGINS.lab,"Concept, système, archives"],["Édition",AIME_ORIGINS.edition,"Événements, personnes, cockpit"],["Passeport",AIME_ORIGINS.passport,"Carte, relais, mémoire"],["Chroma",`${AIME_ORIGINS.chroma}/broderie`,"Couleur, grille, broderie"]].map(([name,url,text]) => <a key={name} href={url} className="group flex min-h-64 flex-col justify-between rounded-[2rem] border border-[#242424] p-7"><Network size={20} /><div><p className="text-xs uppercase tracking-[.22em] text-white/35">{text}</p><h3 className="mt-4 font-display text-5xl font-semibold tracking-[-.06em]">{name}</h3><ArrowUpRight className="mt-5 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></div></a>)}</div><div className="mt-16 flex flex-wrap items-center justify-between gap-6 border-t border-[#242424] pt-8"><p className="max-w-2xl text-sm leading-7 text-white/45">La bibliothèque grandira avec les prochains écrans. Les Archives gardent les recherches ; le Système AIME décrit l’œuvre fusionnelle.</p><Link to="/archives" className="inline-flex min-h-12 items-center gap-2 rounded-full bg-white px-6 text-sm font-semibold text-black">Ouvrir les Archives <ArrowUpRight size={15} /></Link></div></div></section>
  </main>;
}
