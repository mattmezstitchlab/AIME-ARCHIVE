import React from "react";
import ProjectHero from "@/components/portfolio/ProjectHero";
import MagazineHero from "@/components/magazine/MagazineHero";
import AimeLandingSections from "@/components/landing/AimeLandingSections";
import InnovationVerticality from "@/components/portfolio/InnovationVerticality";
import useEcosystemProjects from "@/hooks/useEcosystemProjects";

export default function Home() {
  const { projects } = useEcosystemProjects();
  return (
    <main className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <ProjectHero />
      <MagazineHero />
      <AimeLandingSections />
      <InnovationVerticality projects={projects} />
    </main>
  );
}
