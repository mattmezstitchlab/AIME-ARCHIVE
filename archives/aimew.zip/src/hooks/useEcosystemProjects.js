import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { sortProjects } from "@/components/portfolio/projectConstants";
import { dedupeProjects } from "@/components/portfolio/projectCoherence";
import { ecosystemProjects, mergeEcosystemProjects } from "@/data/ecosystemProjects";

const normalize = (projects) => dedupeProjects(sortProjects(mergeEcosystemProjects(projects)));

export default function useEcosystemProjects() {
  const [projects, setProjects] = useState(() => normalize(ecosystemProjects));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const refresh = async () => {
      try {
        const data = await base44.entities.Project.filter({ visible: true }, "display_order", 1000);
        setProjects(normalize(data));
      } catch (error) {
        console.warn("Projets distants indisponibles, affichage du socle AIME.", error);
      } finally {
        setLoading(false);
      }
    };

    refresh();
    const unsubscribe = base44.entities.Project.subscribe((event) => {
      setProjects((current) => {
        const remoteLike = current.filter((project) => !String(project.id || "").startsWith("fallback-"));
        if (event.type === "delete" || event.data?.visible === false) return normalize(remoteLike.filter((project) => project.id !== event.id));
        const exists = remoteLike.some((project) => project.id === event.id);
        const next = exists
          ? remoteLike.map((project) => project.id === event.id ? { ...project, ...event.data } : project)
          : event.data?.visible ? [...remoteLike, event.data] : remoteLike;
        return normalize(next);
      });
    });
    window.addEventListener("atlas-projects-updated", refresh);
    return () => {
      unsubscribe?.();
      window.removeEventListener("atlas-projects-updated", refresh);
    };
  }, []);

  return { projects, loading };
}
