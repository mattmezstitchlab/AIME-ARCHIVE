import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { contractId, signatureData, signerType } = await req.json();

    if (!contractId || !signatureData || !signerType) {
      return Response.json({ 
        error: 'Contract ID, signature data, and signer type are required' 
      }, { status: 400 });
    }

    // Récupérer le contrat
    const contract = await base44.entities.Contract.get(contractId);
    
    if (!contract) {
      return Response.json({ error: 'Contract not found' }, { status: 404 });
    }

    // Vérifier que l'utilisateur est autorisé à signer
    const isClient = signerType === 'client' && user.email === contract.clientId;
    const isDJ = signerType === 'dj' && user.email === contract.djId;

    if (!isClient && !isDJ) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Mettre à jour la signature
    const signatureUpdate = {
      signed: true,
      signedAt: new Date().toISOString(),
      signatureData: signatureData,
      ipAddress: req.headers.get('x-forwarded-for') || 'unknown'
    };

    const updateData = signerType === 'client' 
      ? { clientSignature: signatureUpdate }
      : { djSignature: signatureUpdate };

    // Vérifier si les deux parties ont signé
    const willBeFullySigned = 
      (signerType === 'client' && contract.djSignature?.signed) ||
      (signerType === 'dj' && contract.clientSignature?.signed);

    if (willBeFullySigned) {
      updateData.status = 'signe';
      updateData.signedAt = new Date().toISOString();
    } else {
      updateData.status = 'partiellement_signe';
    }

    await base44.entities.Contract.update(contractId, updateData);

    return Response.json({ 
      success: true,
      message: 'Signature enregistrée avec succès',
      status: updateData.status
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});