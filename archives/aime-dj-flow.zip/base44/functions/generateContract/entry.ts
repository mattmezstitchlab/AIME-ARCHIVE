import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { contractId } = await req.json();

    if (!contractId) {
      return Response.json({ error: 'Contract ID required' }, { status: 400 });
    }

    // Récupérer le contrat
    const contract = await base44.entities.Contract.get(contractId);
    
    if (!contract) {
      return Response.json({ error: 'Contract not found' }, { status: 404 });
    }

    // Vérifier que l'utilisateur est autorisé
    if (user.email !== contract.clientId && user.email !== contract.djId) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Récupérer les données de l'événement
    const event = await base44.entities.Event.get(contract.eventId);

    // Générer le contenu du contrat
    const contractContent = generateContractContent(contract, event, user);

    return Response.json({ 
      success: true,
      content: contractContent,
      contract: contract
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function generateContractContent(contract, event, user) {
  const clientName = user.role === 'admin' ? 'Client' : user.full_name;
  
  return {
    header: {
      title: 'CONTRAT DE PRESTATION DE SERVICES DJ',
      subtitle: 'Prestation musicale événementielle',
      contractNumber: `AIME-${contract.eventId}-${contract.id}`,
      generatedAt: new Date().toLocaleDateString('fr-FR', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric' 
      })
    },
    parties: {
      provider: {
        name: 'DJ Prestataire',
        role: 'Le Prestataire'
      },
      client: {
        name: clientName,
        email: user.email,
        role: 'Le Client'
      }
    },
    event: {
      date: new Date(contract.eventDate).toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      }),
      startTime: contract.eventStartTime,
      endTime: contract.eventEndTime,
      location: contract.eventLocation,
      type: event?.type || 'Événement privé'
    },
    services: {
      items: contract.services || [],
      totalAmount: contract.totalAmount,
      currency: 'EUR',
      deposit: {
        amount: contract.depositAmount,
        percentage: contract.depositPercentage,
        dueDate: 'À la signature du contrat'
      }
    },
    terms: {
      cancellation: 'En cas d\'annulation, l\'acompte reste acquis au Prestataire.',
      modification: 'Toute modification doit être validée par écrit par les deux parties.',
      forceMajeure: 'Le Prestataire ne saurait être tenu responsable en cas de force majeure.',
      equipment: 'Le matériel fourni est conforme aux standards professionnels.',
      insurance: 'Le Prestataire dispose d\'une assurance responsabilité civile professionnelle.'
    },
    signatures: {
      client: {
        signed: contract.clientSignature?.signed || false,
        signedAt: contract.clientSignature?.signedAt,
        name: clientName
      },
      provider: {
        signed: contract.djSignature?.signed || false,
        signedAt: contract.djSignature?.signedAt,
        name: 'DJ Prestataire'
      }
    }
  };
}