import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { jsPDF } from 'npm:jspdf@4.2.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { eventId } = await req.json();

    if (!eventId) {
      return Response.json({ error: 'Event ID required' }, { status: 400 });
    }

    // Récupérer les données de l'événement
    const events = await base44.entities.Event.filter({ id: eventId });
    const event = events[0];

    if (!event) {
      return Response.json({ error: 'Event not found' }, { status: 404 });
    }

    // Récupérer le brief musical
    const briefs = await base44.entities.MusicBrief.filter({ eventId: eventId });
    const brief = briefs[0];

    // Récupérer la timeline
    const timelines = await base44.entities.TimelineMoment.filter({ eventId: eventId });

    // Créer le PDF
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // En-tête
    doc.setFillColor(220, 38, 78); // Rouge cerise
    doc.rect(0, 0, pageWidth, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.text('AIME DJ', 20, 25);
    
    doc.setFontSize(14);
    doc.setFont('helvetica', 'normal');
    doc.text('Récapitulatif de l\'événement', 20, 35);

    // Informations événement
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text(event.title || 'Événement', 20, 60);

    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    let y = 70;
    
    const eventDetails = [
      `Type : ${event.type || 'N/A'}`,
      `Date : ${event.date ? new Date(event.date).toLocaleDateString('fr-FR') : 'N/A'}`,
      `Lieu : ${event.venue || 'N/A'} - ${event.city || 'N/A'}`,
      `Horaires : ${event.startTime || 'N/A'} - ${event.endTime || 'N/A'}`,
      `Nombre d'invités : ${event.guestCount || 'N/A'}`,
      `Ambiance : ${(event.mood || []).join(', ') || 'N/A'}`
    ];

    eventDetails.forEach(detail => {
      doc.text(detail, 20, y);
      y += 7;
    });

    // Brief musical
    y += 10;
    doc.setFillColor(240, 240, 240);
    doc.rect(20, y - 5, pageWidth - 40, 8, 'F');
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Brief Musical', 25, y);
    y += 15;

    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    
    if (brief) {
      const briefDetails = [
        `Ambiance souhaitée : ${brief.desiredMood || 'N/A'}`,
        `Ambiance à éviter : ${brief.avoidMood || 'N/A'}`,
        `Niveau d'animation : ${brief.animationLevel || 'N/A'}`,
        `Public : ${brief.audience || 'N/A'}`,
        `Moyenne d'âge : ${brief.averageAge || 'N/A'}`
      ];

      briefDetails.forEach(detail => {
        doc.text(detail, 20, y);
        y += 6;
      });

      // Playlist
      if (brief.playlist && brief.playlist.length > 0) {
        y += 10;
        doc.setFont('helvetica', 'bold');
        doc.text('Playlist souhaitée :', 20, y);
        y += 8;
        doc.setFont('helvetica', 'normal');
        
        brief.playlist.slice(0, 10).forEach((song, index) => {
          const line = `${index + 1}. ${song.title || 'N/A'} - ${song.artist || 'N/A'} (${song.importance || 'N/A'})`;
          doc.text(line, 25, y);
          y += 6;
        });
      }

      // blacklist
      if (brief.blacklist && brief.blacklist.length > 0) {
        y += 10;
        doc.setFont('helvetica', 'bold');
        doc.text('Musiques interdites :', 20, y);
        y += 8;
        doc.setFont('helvetica', 'normal');
        brief.blacklist.slice(0, 5).forEach((song, index) => {
          doc.text(`${index + 1}. ${song}`, 25, y);
          y += 6;
        });
      }
    } else {
      doc.text('Brief musical non renseigné', 20, y);
      y += 7;
    }

    // Timeline
    y += 15;
    doc.setFillColor(240, 240, 240);
    doc.rect(20, y - 5, pageWidth - 40, 8, 'F');
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Déroulé de l\'événement', 25, y);
    y += 15;

    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');

    if (timelines && timelines.length > 0) {
      timelines.forEach((moment, index) => {
        const line = `${moment.time || 'N/A'} - ${moment.title || 'N/A'} (${moment.responsible || 'N/A'})`;
        doc.text(line, 20, y);
        y += 6;
        
        // Nouvelle page si nécessaire
        if (y > pageHeight - 30) {
          doc.addPage();
          y = 30;
        }
      });
    } else {
      doc.text('Timeline non renseignée', 20, y);
      y += 7;
    }

    // Pied de page
    doc.setFontSize(9);
    doc.setTextColor(150, 150, 150);
    doc.text(`Généré le ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}`, 20, pageHeight - 20);
    doc.text('Document préparatoire - À valider par les parties', 20, pageHeight - 15);

    // Convertir en blob
    const pdfBytes = doc.output('arraybuffer');

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="recapitulatif-${event.title?.replace(/\s+/g, '-') || 'evenement'}.pdf"`
      }
    });
  } catch (error) {
    console.error('PDF generation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});