import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

// Page imports
import LandingPage from './pages/LandingPage';
import CreateEvent from './pages/CreateEvent';
import DJDashboard from './pages/DJDashboard';

import EventTimeline from './pages/EventTimeline';

import Contracts from './pages/Contracts';

import DJProfileEditor from './pages/DJProfileEditor';
import AdminDashboard from './pages/AdminDashboard';
import LegalInfo from './pages/LegalInfo';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/create-event" element={<CreateEvent />} />
      <Route path="/legal" element={<LegalInfo />} />
      
      {/* Client dashboard routes */}
      <Route path="/dashboard" element={<EventTimeline />} />
      <Route path="/dashboard/event" element={<CreateEvent />} />

      <Route path="/dashboard/timeline" element={<EventTimeline />} />

      <Route path="/dashboard/contracts" element={<Contracts />} />

      
      {/* DJ dashboard routes */}
      <Route path="/dj-dashboard" element={<DJDashboard />} />
      <Route path="/dj/profile" element={<DJProfileEditor />} />
      <Route path="/dj/requests" element={<DJDashboard />} />

      
      {/* Admin routes */}
      <Route path="/admin/dashboard" element={<AdminDashboard />} />
      <Route path="/admin/djs" element={<AdminDashboard />} />
      <Route path="/admin/events" element={<AdminDashboard />} />
      <Route path="/admin/settings" element={<AdminDashboard />} />
      
      {/* 404 */}
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App