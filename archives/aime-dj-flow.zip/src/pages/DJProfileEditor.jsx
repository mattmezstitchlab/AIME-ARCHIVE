import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Save, Upload } from 'lucide-react';
import AppShell from '@/components/layout/AppShell';

export default function DJProfileEditor() {
  return (
    <AppShell role="dj">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-3xl font-bold">Mon profil</h1>
            <p className="text-muted-foreground">Gérez votre profil professionnel</p>
          </div>
          <Button>
            <Save className="w-4 h-4 mr-2" />
            Enregistrer
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <h2 className="font-semibold text-xl">Informations générales</h2>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nom artistique</Label>
                    <Input placeholder="DJ Noam" />
                  </div>
                  <div className="space-y-2">
                    <Label>Ville</Label>
                    <Input placeholder="Lille" />
                  </div>
                  <div className="space-y-2">
                    <Label>Rayon de déplacement (km)</Label>
                    <Input type="number" placeholder="100" />
                  </div>
                  <div className="space-y-2">
                    <Label>Années d'expérience</Label>
                    <Input type="number" placeholder="8" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Biographie</Label>
                  <Textarea rows={4} placeholder="Décrivez votre expérience..." />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="font-semibold text-xl">Styles musicaux</h2>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {['Généraliste', 'Pop', 'Disco', 'Funk', 'House', 'Rock', 'Rap', 'Électro'].map((style) => (
                    <Badge key={style} variant="secondary" className="cursor-pointer">
                      {style}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="font-semibold text-xl">Tarification</h2>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Tarif de base (€)</Label>
                  <Input type="number" placeholder="1200" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <h2 className="font-semibold text-xl">Photo</h2>
              </CardHeader>
              <CardContent className="text-center">
                <div className="w-32 h-32 rounded-full bg-secondary mx-auto mb-4 flex items-center justify-center">
                  <Upload className="w-8 h-8 text-muted-foreground" />
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Télécharger
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  );
}