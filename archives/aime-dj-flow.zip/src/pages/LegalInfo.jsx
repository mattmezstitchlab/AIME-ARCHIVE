import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function LegalInfo() {
  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <Button variant="ghost" asChild>
          <Link to="/">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour à l'accueil
          </Link>
        </Button>

        <div>
          <h1 className="font-heading text-4xl font-bold mb-4">Cadre d'utilisation</h1>
          <p className="text-muted-foreground text-lg">
            Informations importantes sur l'utilisation d'AIME DJ
          </p>
        </div>

        <Card>
          <CardContent className="pt-6 space-y-6">
            <div className="nm-inset rounded-2xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <p className="font-medium text-foreground">Documents préparatoires</p>
                <p className="text-sm text-muted-foreground mt-1">
                  AIME DJ est un outil de mise en relation, de préparation et d'orchestration documentaire. 
                  Les informations, devis, contrats, fiches techniques et documents générés dans l'application 
                  sont préparatoires tant qu'ils ne sont pas validés par les parties concernées.
                </p>
              </div>
            </div>

            <div>
              <h2 className="font-semibold text-xl mb-3">Responsabilité du client</h2>
              <p className="text-muted-foreground">
                Le client est responsable de la véracité des informations fournies dans son événement et son brief musical. 
                Il appartient au client de valider tous les éléments avec le DJ avant l'événement. 
                AIME DJ ne peut être tenu responsable des erreurs ou omissions dans les informations transmises.
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-xl mb-3">Responsabilité du DJ</h2>
              <p className="text-muted-foreground">
                Le DJ reste seul responsable de la confirmation des contraintes techniques et contractuelles. 
                Les documents générés via AIME DJ ne remplacent pas les obligations légales, contractuelles, 
                fiscales, sociales ou assurantielles des prestataires.
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-xl mb-3">Validation humaine obligatoire</h2>
              <p className="text-muted-foreground">
                Aucun document généré dans AIME DJ n'a de valeur officielle sans validation explicite des parties concernées. 
                L'IA Cerise propose, structure et reformule, mais l'humain doit toujours valider les informations importantes.
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-xl mb-3">Paiements</h2>
              <p className="text-muted-foreground">
                Les paiements réels ne sont possibles que si une intégration de paiement (Stripe ou autre) est activée. 
                En l'absence de telle intégration, tous les montants affichés sont indicatifs et les transactions 
                doivent être gérées directement entre le client et le prestataire.
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-xl mb-3">Données personnelles (RGPD)</h2>
              <p className="text-muted-foreground">
                AIME DJ respecte le Règlement Général sur la Protection des Données. 
                Les données personnelles collectées sont utilisées uniquement pour la mise en relation 
                et la préparation des événements. Vous disposez d'un droit d'accès, de modification et de suppression 
                de vos données.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}