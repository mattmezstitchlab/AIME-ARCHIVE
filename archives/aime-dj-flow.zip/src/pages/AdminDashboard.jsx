import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Calendar, TrendingUp, DollarSign, CheckCircle2, AlertCircle } from 'lucide-react';
import AppShell from '@/components/layout/AppShell';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const mockDJs = [
  { id: '1', name: 'DJ Noam', city: 'Lille', rating: 4.9, requests: 12, verified: true },
  { id: '2', name: 'Clara Sound', city: 'Paris', rating: 4.8, requests: 8, verified: true },
  { id: '3', name: 'DJ Malik', city: 'Lyon', rating: 4.7, requests: 15, verified: false }
];

const mockEvents = [
  { id: '1', type: 'Mariage', date: '2026-09-14', city: 'Lille', dj: 'DJ Noam', status: 'actif' },
  { id: '2', type: 'Anniversaire', date: '2026-10-05', city: 'Paris', dj: 'Clara Sound', status: 'actif' },
  { id: '3', type: 'Séminaire', date: '2026-11-20', city: 'Lyon', dj: '-', status: 'brouillon' }
];

export default function AdminDashboard() {
  return (
    <AppShell role="admin">
      <div className="space-y-8">
        <div>
          <h1 className="font-heading text-3xl font-bold">Administration</h1>
          <p className="text-muted-foreground">Vue d'ensemble de la plateforme</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">24</p>
                  <p className="text-sm text-muted-foreground">DJs inscrits</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl nm-inset flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">18</p>
                  <p className="text-sm text-muted-foreground">Événements actifs</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl nm-inset flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">12</p>
                  <p className="text-sm text-muted-foreground">Réservations</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl nm-inset flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-yellow-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">3</p>
                  <p className="text-sm text-muted-foreground">À vérifier</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* DJs table */}
        <div>
          <h2 className="font-heading text-2xl font-bold mb-4">DJs inscrits</h2>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nom</TableHead>
                  <TableHead>Ville</TableHead>
                  <TableHead>Note</TableHead>
                  <TableHead>Demandes</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockDJs.map((dj) => (
                  <TableRow key={dj.id}>
                    <TableCell className="font-medium">{dj.name}</TableCell>
                    <TableCell>{dj.city}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{dj.rating}</span>
                        <span className="text-muted-foreground text-sm">/ 5</span>
                      </div>
                    </TableCell>
                    <TableCell>{dj.requests}</TableCell>
                    <TableCell>
                      {dj.verified ? (
                        <Badge className="bg-green-100 text-green-700">Vérifié</Badge>
                      ) : (
                        <Badge variant="outline">En attente</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">Voir</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </div>

        {/* Events table */}
        <div>
          <h2 className="font-heading text-2xl font-bold mb-4">Événements récents</h2>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Ville</TableHead>
                  <TableHead>DJ</TableHead>
                  <TableHead>Statut</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockEvents.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>{event.type}</TableCell>
                    <TableCell>{event.date}</TableCell>
                    <TableCell>{event.city}</TableCell>
                    <TableCell>{event.dj}</TableCell>
                    <TableCell>
                      <Badge variant={event.status === 'actif' ? 'default' : 'secondary'}>
                        {event.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}