import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Music, Calendar, CheckCircle, ArrowRight, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-20 bg-background/90 backdrop-blur-xl border-b border-border">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <span className="font-bold text-lg tracking-tight">AIME DJ</span>
          <div className="flex items-center gap-6">
            <Button asChild size="sm" className="rounded-full bg-black text-white hover:bg-gray-800 text-sm px-5">
              <Link to="/create-event">Commencer</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* — SECTION 1 : HERO — */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=1920')" }}
        />
        <div className="absolute inset-0 bg-black/50" />

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: 'easeOut' }}
          className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto"
        >
          <h1 className="text-6xl sm:text-7xl md:text-8xl font-bold leading-none tracking-tight mb-6">
            La musique<br />parfaite, préparée.
          </h1>
          <p className="text-xl text-white/70 mb-10 max-w-xl mx-auto">
            Trouvez votre DJ, construisez votre brief, coordonnez votre Jour J.
          </p>
          <Button asChild size="lg" className="rounded-full bg-white text-black hover:bg-gray-100 text-base px-8 py-6 shadow-2xl">
            <Link to="/create-event">
              Créer mon événement
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </motion.div>
      </section>

      {/* — SECTION 2 : COMMENT ÇA MARCHE — */}
      <section className="py-32 bg-background px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Simple. Clair. Efficace.</h2>
          <p className="text-gray-400 text-lg mb-20">Trois étapes pour une soirée parfaitement orchestrée.</p>

          <div className="grid md:grid-cols-3 gap-12">
            {[
              { icon: Music, label: "Choisissez votre DJ", sub: "Compatible avec votre style et budget" },
              { icon: Calendar, label: "Préparez le brief", sub: "Playlist, timeline et fiche technique" },
              { icon: CheckCircle, label: "Profitez du Jour J", sub: "Le DJ arrive avec le bon contexte" },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12 }}
                className="flex flex-col items-center gap-4"
              >
                <div className="w-16 h-16 rounded-full nm-card flex items-center justify-center">
                  <item.icon className="w-7 h-7 text-primary" />
                </div>
                <p className="font-semibold text-lg">{item.label}</p>
                <p className="text-gray-400 text-sm leading-relaxed">{item.sub}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* — SECTION 3 : CTA — */}
      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1514525253440-b393452e8d26?w=1920')" }}
        />
        <div className="absolute inset-0 bg-black/65" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative z-10 text-center text-white px-6"
        >
          <h2 className="text-5xl sm:text-6xl font-bold tracking-tight mb-6">Prêt à orchestrer ?</h2>
          <Button asChild size="lg" className="rounded-full bg-white text-black hover:bg-gray-100 text-base px-8 py-6 shadow-2xl">
            <Link to="/create-event">
              Créer mon événement
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-10 bg-background border-t border-border text-center text-sm text-muted-foreground">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Sparkles className="w-4 h-4" />
          <span className="font-semibold text-black">AIME DJ</span>
        </div>
        <div className="flex justify-center gap-6 mb-4">
          <Link to="/dj-dashboard" className="hover:text-black transition-colors">Espace DJ</Link>
          <Link to="/legal" className="hover:text-black transition-colors">Mentions légales</Link>
        </div>
        <p>© 2026 AIME DJ</p>
      </footer>
    </div>
  );
}