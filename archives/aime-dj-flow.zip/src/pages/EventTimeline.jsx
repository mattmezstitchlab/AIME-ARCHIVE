import React, { useEffect, useState } from 'react';
import WeddingWorkspaceHeader from '@/components/wedding/WeddingWorkspaceHeader';
import WorkspaceLeftPanel from '@/components/wedding/WorkspaceLeftPanel';
import TimelineStage from '@/components/wedding/TimelineStage';
import WorkspaceToolDock from '@/components/wedding/WorkspaceToolDock';
import AddMomentDialog from '@/components/wedding/AddMomentDialog';
import ProviderPickerDialog from '@/components/wedding/ProviderPickerDialog';
import CausalSimulatorDialog from '@/components/wedding/CausalSimulatorDialog';
import { applyCausalDecision } from '@/components/wedding/causalEngine';
import { getReadiness } from '@/components/wedding/readiness';
import { initialMoments } from '@/components/wedding/workspaceData';
import { createTimelineForEvent } from '@/components/event/eventTaxonomies';
import { getSuggestedAssignments } from '@/components/wedding/providerData';
import { base44 } from '@/api/base44Client';

export default function EventTimeline() {
  const [moments, setMoments] = useState(initialMoments);
  const [selected, setSelected] = useState(initialMoments[3]);
  const [view, setView] = useState('vertical');
  const [section, setSection] = useState('all');
  const [leftOpen, setLeftOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const [zoom, setZoom] = useState(75);
  const [dayMode, setDayMode] = useState(false);
  const [pickerType, setPickerType] = useState(null);
  const [providerAssignments, setProviderAssignments] = useState({});
  const [simulatorOpen, setSimulatorOpen] = useState(false);
  const [eventMetrics, setEventMetrics] = useState({ guests:96, budget:18000, ceremonyDelay:0 });
  const [messages, setMessages] = useState([{ id: 1, from: 'DJ Noam', text: 'Quelle chanson souhaitez-vous pour cette entrée ?', time: '09:12' }]);
  const [event, setEvent] = useState(null);
  const [isLoadingEvent, setIsLoadingEvent] = useState(false);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    const eventId = new URLSearchParams(window.location.search).get('eventId');
    if (!eventId) return;
    setIsLoadingEvent(true);
    base44.entities.Event.get(eventId).then(savedEvent => {
      const adaptedMoments = createTimelineForEvent(savedEvent);
      setEvent(savedEvent);
      setMoments(adaptedMoments);
      setSelected(adaptedMoments[0]);
      setProviderAssignments(getSuggestedAssignments(savedEvent, adaptedMoments));
      setEventMetrics({ guests:savedEvent.guestCount || 0, budget:savedEvent.budget || 0, ceremonyDelay:0 });
      setMessages([{ id:1, from:'Cerise', text:`La Timeline ${savedEvent.title} et ses prestataires recommandés sont prêts.`, time:new Date().toLocaleTimeString('fr-FR', { hour:'2-digit', minute:'2-digit' }) }]);
      setIsLoadingEvent(false);
    }).catch(() => { setLoadError('Cet événement ne peut pas être chargé.'); setIsLoadingEvent(false); });
  }, []);

  const addMoment = form => {
    const hour = Number(form.time?.split(':')[0] || 12);
    const moment = { ...form, id: String(Date.now()), day: hour < 6 ? 1 : 0, duration: 'À définir', location: 'À définir', coordination: 'À compléter', technical: 'À compléter', phase: 'Nouveau moment', status: 'attention' };
    const position = item => item.day * 1440 + Number(item.time.split(':')[0]) * 60 + Number(item.time.split(':')[1]);
    setMoments(current => [...current, moment].sort((a, b) => position(a) - position(b)));
    setSection('all'); setSelected(moment); setAdding(false);
  };

  const applySimulation = decision => {
    const nextMoments = applyCausalDecision(moments, decision);
    setMoments(nextMoments);
    setSelected(current => nextMoments.find(moment => moment.id === current?.id) || current);
    setEventMetrics(decision.nextMetrics);
    setSimulatorOpen(false);
  };

  const visibleMoments = section === 'music' ? moments.filter(moment => moment.tracks?.length)
    : section === 'technical' ? moments.filter(moment => moment.phase === 'Technique' || moment.phase === 'Production' || moment.providerTypes?.includes('sound_light') || moment.providerTypes?.includes('production'))
    : section === 'attention' ? moments.filter(moment => moment.status === 'attention')
    : moments;

  if (isLoadingEvent) return <div className="h-screen bg-background text-foreground grid place-items-center"><div className="text-center"><div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-border border-t-primary" /><p className="mt-3 text-sm text-muted-foreground">Création de votre Timeline…</p></div></div>;
  if (loadError) return <div className="h-screen bg-background text-foreground grid place-items-center"><p className="text-sm text-destructive">{loadError}</p></div>;

  return <div className="h-screen bg-background text-foreground flex flex-col overflow-hidden">
    <WeddingWorkspaceHeader onOpenLeft={() => setLeftOpen(true)} event={event} />
    <div className="flex flex-1 min-h-0 relative">
      <div className="hidden lg:block"><WorkspaceLeftPanel active={section} onChange={setSection} moments={moments} moment={selected} event={event} messages={messages} onSend={text => setMessages(current => [...current, { id: Date.now(), from: 'Vous', text, time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) }])} /></div>
      <TimelineStage moments={visibleMoments} selected={selected} onSelect={setSelected} view={view} zoom={zoom} dayMode={dayMode} providerAssignments={providerAssignments} onAddProvider={setPickerType} eventMetrics={eventMetrics} readiness={getReadiness(moments)} event={event} />
      <WorkspaceToolDock
        view={view}
        onView={setView}
        onCausal={() => setSimulatorOpen(true)}
        onAdd={() => setAdding(true)}
        zoom={zoom}
        onZoom={delta => setZoom(current => Math.min(125, Math.max(50, current + delta)))}
        dayMode={dayMode}
        onDayMode={() => setDayMode(current => !current)}
      />
    </div>
    {leftOpen && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setLeftOpen(false)}><div className="h-full w-[360px] max-w-[90vw]" onClick={e => e.stopPropagation()}><WorkspaceLeftPanel active={section} onChange={value => { setSection(value); setLeftOpen(false); }} moments={moments} moment={selected} event={event} messages={messages} onSend={text => setMessages(current => [...current, { id: Date.now(), from: 'Vous', text, time: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) }])} onClose={() => setLeftOpen(false)} /></div></div>}
    {adding && <AddMomentDialog onAdd={addMoment} onClose={() => setAdding(false)} />}
    {pickerType && <ProviderPickerDialog typeId={pickerType} event={event} onClose={() => setPickerType(null)} onSelect={provider => { setProviderAssignments(current => ({ ...current, [pickerType]:provider })); setPickerType(null); }} />}
    {simulatorOpen && <CausalSimulatorDialog metrics={eventMetrics} onApply={applySimulation} onClose={() => setSimulatorOpen(false)} />}
  </div>;
}