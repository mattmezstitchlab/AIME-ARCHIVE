import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Calendar, MessageSquare, Music2, Clock,
  CheckCircle2, TrendingUp, Users, MapPin
} from 'lucide-react';
import AppShell from '@/components/layout/AppShell';
import { cn } from '@/lib/utils';

const mockRequests = [
  { id: '1', eventName: 'Mariage de Camille et Hugo', date: '2026-09-14', city: 'Lille', guestCount: 120, mood: ['Chic', 'Festif'],    budget: 1500, compatibility: 94, status: 'envoye',       clientName: 'Camille D.' },
  { id: '2', eventName: 'Anniversaire 40 ans',        date: '2026-10-05', city: 'Paris', guestCount: 80,  mood: ['Disco', 'House'],    budget: 1200, compatibility: 87, status: 'en_discussion', clientName: 'Marc L.' },
  { id: '3', eventName: 'Séminaire entreprise',       date: '2026-11-20', city: 'Lyon',  guestCount: 150, mood: ['Lounge', 'Élégant'], budget: 1800, compatibility: 91, status: 'devis_recu',   clientName: 'Sophie M.' },
];

const mockEvents = [
  { id: '1', name: 'Mariage - Julie & Thomas',   date: '2026-06-15', city: 'Lille' },
  { id: '2', name: 'Soirée privée - Entreprise', date: '2026-06-28', city: 'Paris' },
  { id: '3', name: 'Anniversaire - 50 ans',      date: '2026-07-12', city: 'Lyon' },
  { id: '4', name: 'Mariage - Sophie & Marc',    date: '2026-07-20', city: 'Bordeaux' },
  { id: '5', name: 'Festival musique',            date: '2026-08-05', city: 'Marseille' },
  { id: '6', name: 'Séminaire team building',    date: '2026-09-10', city: 'Nice' },
];

const STATUS_STYLES = {
  envoye:        { bg: 'bg-white/10',  text: 'text-gray-200', label: 'Nouvelle demande' },
  en_discussion: { bg: 'bg-yellow-500/15', text: 'text-yellow-400', label: 'En discussion' },
  devis_recu:    { bg: 'bg-white/10',  text: 'text-gray-200', label: 'Devis envoyé' },
};

export default function DJDashboard() {
  const [tab, setTab] = useState('demandes');

  const stats = [
    { label: 'Demandes',   value: '3',   icon: Calendar,    bg: 'bg-white/10' },
    { label: 'Réservés',   value: '12',  icon: CheckCircle2, bg: 'bg-white/10' },
    { label: 'Note moy.',  value: '4.9', icon: Music2,       bg: 'bg-white/10' },
    { label: 'Taux rép.',  value: '94%', icon: TrendingUp,   bg: 'bg-white/10' },
  ];

  return (
    <AppShell role="dj">
      <div className="min-h-[calc(100vh-90px)] md:min-h-[calc(100vh-56px)] bg-background rounded-3xl overflow-hidden -m-4 md:-m-6 lg:-m-8 overflow-y-auto nm-inset">

        {/* Header */}
        <div className="border-b border-white/10 px-6 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-white font-bold text-xl">Tableau de bord</h1>
            <p className="text-gray-500 text-sm mt-0.5">Gérez vos demandes et événements</p>
          </div>
          <Link to="/dj/profile" className="px-4 py-2 rounded-full bg-white text-black text-sm font-medium hover:bg-gray-100 transition-colors">
            Mon profil
          </Link>
        </div>

        <div className="p-6 space-y-6">

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {stats.map(s => {
              const Icon = s.icon;
              return (
                <div key={s.label} className="rounded-2xl p-4 nm-card">
                  <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center mb-3", s.bg)}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <p className="text-2xl font-bold text-white">{s.value}</p>
                  <p className="text-gray-500 text-xs mt-0.5">{s.label}</p>
                </div>
              );
            })}
          </div>

          {/* Tabs */}
          <div className="flex border-b border-white/10">
            {[{ key: 'demandes', label: 'Demandes de devis' }, { key: 'agenda', label: 'Agenda confirmé' }].map(t => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={cn(
                  "px-5 py-3 text-sm font-medium transition-colors border-b-2",
                  tab === t.key ? "text-white border-white" : "text-gray-500 border-transparent hover:text-white"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Requests */}
          {tab === 'demandes' && (
            <div className="space-y-3">
              {mockRequests.map(req => {
                const st = STATUS_STYLES[req.status] || STATUS_STYLES.envoye;
                return (
                  <div key={req.id} className="rounded-2xl p-5 nm-card hover:bg-muted transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2.5 mb-2">
                          <h3 className="text-white font-semibold text-sm truncate">{req.eventName}</h3>
                          <span className={cn("text-[11px] px-2 py-0.5 rounded-full font-medium flex-shrink-0", st.bg, st.text)}>
                            {st.label}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-gray-500 mb-3">
                          <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {req.date}</span>
                          <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {req.city}</span>
                          <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {req.guestCount} inv.</span>
                          <span className="text-white font-medium">{req.compatibility}% compatible</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5 mb-3">
                          {req.mood.map((m, i) => (
                            <span key={i} className="text-[11px] bg-white/8 text-gray-400 border border-white/10 rounded-full px-2 py-0.5">{m}</span>
                          ))}
                        </div>
                        <div className="text-xs text-gray-500">
                          Budget : <span className="text-white font-medium">{req.budget} €</span>
                          <span className="mx-2">·</span>
                          Client : <span className="text-gray-300">{req.clientName}</span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 flex-shrink-0">
                        <button className="px-4 py-1.5 rounded-full bg-white text-black text-xs font-medium hover:bg-gray-100 transition-colors">
                          Voir
                        </button>
                        <button className="w-8 h-8 rounded-full bg-white/8 border border-white/15 flex items-center justify-center hover:bg-white/15 transition-colors">
                          <MessageSquare className="w-3.5 h-3.5 text-gray-400" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Agenda */}
          {tab === 'agenda' && (
            <div className="space-y-2">
              {mockEvents.map(ev => (
                <div key={ev.id} className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/8 transition-all">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                    <Calendar className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium text-sm truncate">{ev.name}</p>
                    <p className="text-gray-500 text-xs mt-0.5 flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {ev.city}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-white text-sm font-medium">
                      {new Date(ev.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                    </p>
                    <span className="text-[11px] bg-white/10 text-gray-300 rounded-full px-2 py-0.5">Confirmé</span>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      </div>
    </AppShell>
  );
}