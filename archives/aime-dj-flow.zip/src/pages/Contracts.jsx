import React, { useState } from 'react';
import { FileText, Plus, Eye, Download, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import AppShell from '@/components/layout/AppShell';
import ContractSignatureModal from '@/components/contracts/ContractSignatureModal';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { cn } from '@/lib/utils';

const STATUS_MAP = {
  brouillon:             { bg: 'bg-white/8',    text: 'text-gray-400',   icon: FileText,     label: 'Brouillon' },
  envoye:                { bg: 'bg-white/10',   text: 'text-gray-200',   icon: Clock,        label: 'Envoyé' },
  en_attente_signature:  { bg: 'bg-yellow-500/15', text: 'text-yellow-400', icon: Clock,     label: 'En attente' },
  partiellement_signe:   { bg: 'bg-white/10',   text: 'text-gray-200',   icon: CheckCircle2, label: 'Partiellement signé' },
  signe:                 { bg: 'bg-white/15',   text: 'text-white',      icon: CheckCircle2, label: 'Signé' },
  refuse:                { bg: 'bg-red-500/15', text: 'text-red-400',    icon: AlertCircle,  label: 'Refusé' },
  annule:                { bg: 'bg-white/8',    text: 'text-gray-500',   icon: AlertCircle,  label: 'Annulé' },
};

export default function Contracts() {
  const queryClient = useQueryClient();
  const [selectedContract, setSelectedContract] = useState(null);
  const [showSignatureModal, setShowSignatureModal] = useState(false);

  const { data: contracts = [], isLoading } = useQuery({
    queryKey: ['contracts'],
    queryFn: () => base44.entities.Contract.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Contract.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['contracts'] }),
  });

  const handleCreate = () => {
    createMutation.mutate({
      eventId: '1', djId: 'dj1', clientId: 'client@example.com',
      contractType: 'prestation_dj', status: 'brouillon',
      totalAmount: 1500, depositAmount: 450, depositPercentage: 30,
      eventDate: '2026-09-14', eventStartTime: '18:00', eventEndTime: '02:00',
      eventLocation: 'Château de la Loire, Lille',
      services: [
        { name: 'Prestation DJ', description: 'Animation musicale complète', quantity: 1, unitPrice: 1200, total: 1200 },
        { name: 'Matériel sonore', description: 'Sonorisation complète + micros', quantity: 1, unitPrice: 300, total: 300 },
      ],
      notes: 'Prestation pour mariage. Matériel installé à partir de 14h.',
    });
  };

  const stats = [
    { label: 'En attente',   value: contracts.filter(c => c.status === 'en_attente_signature').length },
    { label: 'Part. signés', value: contracts.filter(c => c.status === 'partiellement_signe').length },
    { label: 'Signés',       value: contracts.filter(c => c.status === 'signe').length },
    { label: 'Total',        value: contracts.length },
  ];

  return (
    <AppShell role="client">
      <div className="min-h-[calc(100vh-90px)] md:min-h-[calc(100vh-56px)] bg-background rounded-3xl overflow-hidden -m-4 md:-m-6 lg:-m-8 overflow-y-auto nm-inset">

        {/* Header */}
        <div className="border-b border-white/10 px-6 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-white font-bold text-xl">Contrats</h1>
            <p className="text-gray-500 text-sm mt-0.5">Gérez et signez vos contrats de prestation</p>
          </div>
          <button
            onClick={handleCreate}
            disabled={createMutation.isPending}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-white text-black text-sm font-medium hover:bg-gray-100 transition-colors disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Créer un contrat</span>
          </button>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
        ) : (
          <div className="p-6 space-y-6">

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {stats.map(s => (
                <div key={s.label} className="rounded-2xl p-4 nm-card">
                  <p className="text-2xl font-bold text-white">{s.value}</p>
                  <p className="text-gray-500 text-xs mt-1">{s.label}</p>
                </div>
              ))}
            </div>

            {/* List */}
            {contracts.length > 0 ? (
              <div className="space-y-3">
                {contracts.map(contract => {
                  const st = STATUS_MAP[contract.status] || STATUS_MAP.brouillon;
                  const Icon = st.icon;
                  return (
                    <div key={contract.id} className="rounded-2xl p-5 nm-card hover:bg-muted transition-colors">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                              <FileText className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <h3 className="text-white font-semibold text-sm">
                                Contrat {contract.contractType === 'prestation_dj' ? 'de prestation DJ' : contract.contractType}
                              </h3>
                              <p className="text-gray-600 text-xs">n° AIME-{contract.eventId}-{contract.id?.slice(-6)}</p>
                            </div>
                          </div>
                          <div className="grid md:grid-cols-3 gap-3 mb-3">
                            <div>
                              <p className="text-gray-600 text-xs">Date de l'événement</p>
                              <p className="text-white text-sm font-medium">
                                {contract.eventDate ? new Date(contract.eventDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }) : '—'}
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-600 text-xs">Montant total</p>
                              <p className="text-white text-lg font-bold">{contract.totalAmount} €</p>
                            </div>
                            <div>
                              <p className="text-gray-600 text-xs">Acompte</p>
                              <p className="text-white text-sm font-medium">{contract.depositAmount} € ({contract.depositPercentage}%)</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span className="flex items-center gap-1.5">
                              {contract.clientSignature?.signed ? <CheckCircle2 className="w-3.5 h-3.5 text-white" /> : <Clock className="w-3.5 h-3.5" />}
                              Client : {contract.clientSignature?.signed ? 'Signé' : 'En attente'}
                            </span>
                            <span className="flex items-center gap-1.5">
                              {contract.djSignature?.signed ? <CheckCircle2 className="w-3.5 h-3.5 text-white" /> : <Clock className="w-3.5 h-3.5" />}
                              DJ : {contract.djSignature?.signed ? 'Signé' : 'En attente'}
                            </span>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2 flex-shrink-0">
                          <span className={cn("text-[11px] px-2.5 py-1 rounded-full font-medium flex items-center gap-1", st.bg, st.text)}>
                            <Icon className="w-3 h-3" />
                            {st.label}
                          </span>
                          <div className="flex gap-2 mt-1">
                            <button
                              onClick={() => { setSelectedContract(contract); setShowSignatureModal(true); }}
                              className="w-8 h-8 rounded-full bg-white/8 border border-white/15 flex items-center justify-center hover:bg-white/15 transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5 text-gray-400" />
                            </button>
                            {contract.pdfUrl && (
                              <button className="w-8 h-8 rounded-full bg-white/8 border border-white/15 flex items-center justify-center hover:bg-white/15 transition-colors">
                                <Download className="w-3.5 h-3.5 text-gray-400" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                  <FileText className="w-8 h-8 text-gray-600" />
                </div>
                <p className="text-white font-semibold mb-1">Aucun contrat</p>
                <p className="text-gray-500 text-sm mb-5">Créez votre premier contrat de prestation</p>
                <button onClick={handleCreate} className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-black text-sm font-medium hover:bg-gray-100 transition-colors">
                  <Plus className="w-4 h-4" />
                  Créer un contrat
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {selectedContract && (
        <ContractSignatureModal
          contract={selectedContract}
          isOpen={showSignatureModal}
          onClose={() => { setShowSignatureModal(false); setSelectedContract(null); }}
          onSigned={() => { queryClient.invalidateQueries({ queryKey: ['contracts'] }); setShowSignatureModal(false); setSelectedContract(null); }}
        />
      )}
    </AppShell>
  );
}