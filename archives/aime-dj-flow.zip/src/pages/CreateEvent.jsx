import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowRight, ArrowLeft, Calendar, MapPin, Users, Clock, 
  Music, Sparkles, CheckCircle2, Home, Wine, PartyPopper,
  Briefcase, Film, Building2, Heart
} from 'lucide-react';
import AppShell from '@/components/layout/AppShell';
import CerisePanel from '@/components/ui/CerisePanel';
import EventSpecificFields from '@/components/event/EventSpecificFields';
import { getMomentChoices, getTaxonomy } from '@/components/event/eventTaxonomies';
import { base44 } from '@/api/base44Client';

const EVENT_TYPES = [
  { value: 'mariage', label: 'Mariage', icon: Heart },
  { value: 'anniversaire', label: 'Anniversaire', icon: PartyPopper },
  { value: 'soiree_privee', label: 'Soirée privée', icon: Wine },
  { value: 'seminaire', label: 'Séminaire', icon: Briefcase },
  { value: 'festival', label: 'Festival', icon: Film },
  { value: 'bar_club', label: 'Bar / Club', icon: Building2 },
  { value: 'associatif', label: 'Événement associatif', icon: Users },
  { value: 'autre', label: 'Autre', icon: Home }
];

const AMBIANCES = [
  'Chic', 'Festif', 'Élégant', 'Familial', 'Club', 'Lounge',
  'Généraliste', 'Afro / Latino', 'Années 80/90/2000', 'Électro',
  'Pop / variétés', 'Rap / RnB', 'Rock', 'Mix culturel'
];

const MOMENTS = [
  'Cérémonie', 'Vin d\'honneur / Cocktail', 'Entrée des mariés',
  'Repas', 'Discours', 'Ouverture de bal', 'Soirée dansante',
  'Brunch', 'Surprise témoins', 'Fin de soirée'
];

export default function CreateEvent() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    type: '',
    title: '',
    date: '',
    city: '',
    venue: '',
    guestCount: '',
    budget: '',
    startTime: '',
    endTime: '',
    indoorOutdoor: 'indoor',
    timeConstraint: false,
    mood: [],
    momentsASonoriser: [],
    typeSpecificDetails: {}
  });

  const [savedEvents, setSavedEvents] = useState([]);
  const [memoryEvent, setMemoryEvent] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const totalSteps = 5;
  const progress = (step / totalSteps) * 100;
  const taxonomy = getTaxonomy(formData.type);
  const momentChoices = getMomentChoices(formData.type);

  useEffect(() => {
    const loadMemory = async () => {
      const user = await base44.auth.me();
      const events = await base44.entities.Event.filter({ created_by_id:user.id }, '-created_date', 100);
      setSavedEvents(events);
    };
    loadMemory().catch(() => setSavedEvents([]));
  }, []);

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const selectEventType = type => {
    const sameType = savedEvents.find(event => event.type === type);
    const previous = sameType || savedEvents[0];
    setMemoryEvent(previous || null);
    setFormData(current => previous ? {
      ...current, type, city:previous.city || '', venue:previous.venue || '', guestCount:previous.guestCount || '',
      budget:previous.budget || '', startTime:previous.startTime || '', endTime:previous.endTime || '',
      indoorOutdoor:previous.indoorOutdoor || 'indoor', timeConstraint:Boolean(previous.timeConstraint),
      mood:previous.mood || [], momentsASonoriser:sameType?.momentsASonoriser || [],
      typeSpecificDetails:sameType?.typeSpecificDetails || {}, memorySourceEventId:previous.id,
    } : { ...current, type, typeSpecificDetails:{}, momentsASonoriser:[], memorySourceEventId:'' });
  };

  const updateSpecificField = (field, value) => setFormData(current => ({ ...current, typeSpecificDetails:{ ...current.typeSpecificDetails, [field]:value } }));

  const toggleArrayValue = (field, value) => {
    setFormData(prev => {
      const exists = prev[field].includes(value);
      return {
        ...prev,
        [field]: exists
          ? prev[field].filter(v => v !== value)
          : [...prev[field], value]
      };
    });
  };

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = async () => {
    setIsSaving(true);
    setSubmitError('');
    try {
      const user = await base44.auth.me();
      const event = await base44.entities.Event.create({
        ...formData, guestCount:Number(formData.guestCount) || 0, budget:Number(formData.budget) || 0,
        preparationScore:calculateCompleteness(), status:'actif', clientId:user.id,
      });
      navigate(`/dashboard?eventId=${event.id}`);
    } catch (error) {
      setSubmitError("L’événement n’a pas pu être enregistré. Vérifiez les informations puis réessayez.");
      setIsSaving(false);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-heading text-3xl font-bold mb-2">
                Quel événement préparez-vous ?
              </h2>
              <p className="text-muted-foreground">
                Sélectionnez le type d'événement que vous organisez
              </p>
            </div>
            {memoryEvent && <div className="rounded-xl border border-primary/30 bg-primary/5 px-4 py-3 text-sm text-primary">Informations réutilisables chargées depuis « {memoryEvent.title || taxonomy.label} ». La date et le titre restent à définir.</div>}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {EVENT_TYPES.map((type) => {
                const Icon = type.icon;
                const isSelected = formData.type === type.value;
                return (
                  <button
                    key={type.value}
                    onClick={() => selectEventType(type.value)}
                    className={`p-6 rounded-xl border-2 transition-all duration-200 ${
                      isSelected
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50 hover:bg-secondary/50'
                    }`}
                  >
                    <Icon className={`w-8 h-8 mx-auto mb-3 ${
                      isSelected ? 'text-primary' : 'text-muted-foreground'
                    }`} />
                    <p className={`font-medium text-sm ${
                      isSelected ? 'text-primary' : 'text-foreground'
                    }`}>
                      {type.label}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-heading text-3xl font-bold mb-2">
                Quand et où ?
              </h2>
              <p className="text-muted-foreground">
                Les informations essentielles sur votre événement
              </p>
            </div>
            
            <Card>
              <CardContent className="pt-6 space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Titre de l'événement</Label>
                    <Input
                      id="title"
                      placeholder="Ex: Mariage de Camille et Hugo"
                      value={formData.title}
                      onChange={(e) => updateField('title', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.date}
                      onChange={(e) => updateField('date', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="city">Ville</Label>
                    <Input
                      id="city"
                      placeholder="Ex: Lille"
                      value={formData.city}
                      onChange={(e) => updateField('city', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="venue">Lieu</Label>
                    <Input
                      id="venue"
                      placeholder="Nom du lieu"
                      value={formData.venue}
                      onChange={(e) => updateField('venue', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="guestCount">Nombre de {taxonomy.audienceLabel.toLowerCase()}</Label>
                    <Input
                      id="guestCount"
                      type="number"
                      placeholder="Ex: 120"
                      value={formData.guestCount}
                      onChange={(e) => updateField('guestCount', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="budget">Budget indicatif</Label>
                    <Input id="budget" type="number" placeholder="Ex: 5000" value={formData.budget} onChange={(e) => updateField('budget', e.target.value)} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="indoorOutdoor">Type de lieu</Label>
                    <select
                      id="indoorOutdoor"
                      className="w-full rounded-lg border border-input bg-background px-3 py-2"
                      value={formData.indoorOutdoor}
                      onChange={(e) => updateField('indoorOutdoor', e.target.value)}
                    >
                      <option value="indoor">Intérieur</option>
                      <option value="outdoor">Extérieur</option>
                      <option value="mixte">Mixte</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="startTime">Horaire de début</Label>
                    <Input
                      id="startTime"
                      type="time"
                      value={formData.startTime}
                      onChange={(e) => updateField('startTime', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="endTime">Horaire de fin</Label>
                    <Input
                      id="endTime"
                      type="time"
                      value={formData.endTime}
                      onChange={(e) => updateField('endTime', e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="flex items-center gap-2 pt-4 border-t">
                  <input
                    type="checkbox"
                    id="timeConstraint"
                    checked={formData.timeConstraint}
                    onChange={(e) => updateField('timeConstraint', e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                  <Label htmlFor="timeConstraint" className="cursor-pointer">
                    Le lieu impose-t-il une limite horaire ?
                  </Label>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-heading text-3xl font-bold mb-2">
                Précisons votre {taxonomy.label.toLowerCase()}
              </h2>
              <p className="text-muted-foreground">
                Ces réponses adaptent la Timeline, les responsabilités et les prestataires
                </p>
                </div>

                <EventSpecificFields questions={taxonomy.questions} values={formData.typeSpecificDetails} onChange={updateSpecificField} />
                <p className="text-sm font-medium text-foreground">Ambiances souhaitées</p>
                <div className="flex flex-wrap gap-2">
              {AMBIANCES.map((ambiance) => {
                const isSelected = formData.mood.includes(ambiance);
                return (
                  <button
                    key={ambiance}
                    onClick={() => toggleArrayValue('mood', ambiance)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                      isSelected
                        ? 'bg-primary text-white shadow-md'
                        : 'bg-secondary text-secondary-foreground hover:bg-primary/10'
                    }`}
                  >
                    {ambiance}
                  </button>
                );
              })}
            </div>
            
            {formData.mood.length > 0 && (
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                <p className="text-sm text-muted-foreground">
                  <span className="font-medium">{formData.mood.length}</span> ambiance(s) sélectionnée(s)
                </p>
              </div>
            )}
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-heading text-3xl font-bold mb-2">
                Quels moments faut-il sonoriser ?
              </h2>
              <p className="text-muted-foreground">
                Sélectionnez tous les moments de votre événement
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-3">
              {momentChoices.map((moment) => {
                const isSelected = formData.momentsASonoriser.includes(moment);
                return (
                  <label
                    key={moment}
                    className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                      isSelected
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/30'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleArrayValue('momentsASonoriser', moment)}
                      className="w-4 h-4 rounded border-gray-300 text-primary"
                    />
                    <span className="font-medium">{moment}</span>
                  </label>
                );
              })}
            </div>
          </div>
        );

      case 5:
        const typeLabel = EVENT_TYPES.find(t => t.value === formData.type)?.label;
        const completenessScore = calculateCompleteness();
        
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-heading text-3xl font-bold mb-2">
                Ce que Cerise a compris
              </h2>
              <p className="text-muted-foreground">
                Vérifiez les informations avant de continuer
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardDescription>Résumé de l'événement</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium">{formData.title || 'Non défini'}</p>
                      <p className="text-sm text-muted-foreground">{typeLabel || 'Type non sélectionné'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium">{formData.city || 'Ville non définie'}</p>
                      <p className="text-sm text-muted-foreground">{formData.venue || 'Lieu non défini'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium">{formData.date || 'Date non définie'}</p>
                      <p className="text-sm text-muted-foreground">
                        {formData.startTime || '...'} - {formData.endTime || '...'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Users className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium">{formData.guestCount || '...'} invités</p>
                      <p className="text-sm text-muted-foreground">
                        {formData.indoorOutdoor === 'indoor' ? 'Intérieur' : 
                         formData.indoorOutdoor === 'outdoor' ? 'Extérieur' : 'Mixte'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardDescription>Ambiance et moments</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-2">Ambiances</p>
                    <div className="flex flex-wrap gap-1.5">
                      {formData.mood.map((m, i) => (
                        <Badge key={i} variant="secondary">{m}</Badge>
                      ))}
                      {formData.mood.length === 0 && (
                        <span className="text-sm text-muted-foreground">Non défini</span>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium mb-2">Moments à sonoriser</p>
                    <div className="flex flex-wrap gap-1.5">
                      {formData.momentsASonoriser.map((m, i) => (
                        <Badge key={i} variant="outline">{m}</Badge>
                      ))}
                      {formData.momentsASonoriser.length === 0 && (
                        <span className="text-sm text-muted-foreground">Non défini</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <CerisePanel
              suggestions={[
                {
                  message: `Votre événement est complété à ${completenessScore}%. Les informations semblent cohérentes. La Timeline va maintenant vous guider moment par moment, y compris pour le choix des prestataires.`
                }
              ]}
            />
          </div>
        );

      default:
        return null;
    }
  };

  const calculateCompleteness = () => {
    let score = 0;
    if (formData.type) score += 15;
    if (formData.title) score += 10;
    if (formData.date) score += 15;
    if (formData.city) score += 10;
    if (formData.venue) score += 10;
    if (formData.guestCount) score += 10;
    if (formData.startTime) score += 10;
    if (formData.endTime) score += 10;
    if (formData.mood.length > 0) score += 5;
    if (formData.momentsASonoriser.length > 0) score += 5;
    if (Object.values(formData.typeSpecificDetails || {}).some(Boolean)) score += 5;
    return Math.min(score, 100);
  };

  return (
    <AppShell role="client">
      <div className="max-w-4xl mx-auto">
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Étape {step} sur {totalSteps}</span>
            <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        
        {/* Step content */}
        {renderStep()}
        
        {/* Navigation buttons */}
        {submitError && <p role="alert" className="mt-6 text-sm text-destructive">{submitError}</p>}
        <div className="flex items-center justify-between mt-8 pt-6 border-t">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 1}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          
          {step < totalSteps ? (
            <Button
              onClick={handleNext}
              disabled={
                (step === 1 && !formData.type) ||
                (step === 2 && (!formData.date || !formData.city))
              }
            >
              Suivant
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isSaving} className="bg-primary hover:bg-primary/90">
              {isSaving ? 'Création de la Timeline…' : 'Valider et ouvrir la Timeline'}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </div>
    </AppShell>
  );
}