import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { CheckCircle2, Clock, AlertCircle, FileText, XCircle } from 'lucide-react';

const statusConfig = {
  brouillon: {
    label: 'Brouillon',
    color: 'bg-slate-100 text-slate-700 border-slate-200',
    icon: FileText
  },
  a_completer: {
    label: 'À compléter',
    color: 'bg-orange-100 text-orange-700 border-orange-200',
    icon: AlertCircle
  },
  a_generer: {
    label: 'À générer',
    color: 'bg-slate-100 text-slate-700 border-slate-200',
    icon: FileText
  },
  pret_a_valider: {
    label: 'Prêt à valider',
    color: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    icon: Clock
  },
  valide: {
    label: 'Validé',
    color: 'bg-green-100 text-green-700 border-green-200',
    icon: CheckCircle2
  },
  confirme: {
    label: 'Confirmé',
    color: 'bg-green-100 text-green-700 border-green-200',
    icon: CheckCircle2
  },
  en_attente: {
    label: 'En attente',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    icon: Clock
  },
  envoye: {
    label: 'Envoyé',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    icon: Clock
  },
  vu: {
    label: 'Vu',
    color: 'bg-indigo-100 text-indigo-700 border-indigo-200',
    icon: Clock
  },
  devis_recu: {
    label: 'Devis reçu',
    color: 'bg-purple-100 text-purple-700 border-purple-200',
    icon: FileText
  },
  en_discussion: {
    label: 'En discussion',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    icon: Clock
  },
  reserve: {
    label: 'Réservé',
    color: 'bg-green-100 text-green-700 border-green-200',
    icon: CheckCircle2
  },
  refuse: {
    label: 'Refusé',
    color: 'bg-red-100 text-red-700 border-red-200',
    icon: XCircle
  },
  annule: {
    label: 'Annulé',
    color: 'bg-slate-100 text-slate-500 border-slate-200',
    icon: XCircle
  },
  incomplet: {
    label: 'Incomplet',
    color: 'bg-orange-100 text-orange-700 border-orange-200',
    icon: AlertCircle
  },
  pret: {
    label: 'Prêt',
    color: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    icon: Clock
  },
  actif: {
    label: 'Actif',
    color: 'bg-green-100 text-green-700 border-green-200',
    icon: CheckCircle2
  },
  termine: {
    label: 'Terminé',
    color: 'bg-slate-100 text-slate-600 border-slate-200',
    icon: CheckCircle2
  },
  archive: {
    label: 'Archivé',
    color: 'bg-slate-100 text-slate-500 border-slate-200',
    icon: FileText
  }
};

export default function StatusBadge({ status, variant = "default" }) {
  const config = statusConfig[status] || statusConfig.brouillon;
  const Icon = config.icon;

  return (
    <Badge
      variant={variant}
      className={cn(
        "flex items-center gap-1.5 px-3 py-1 font-medium",
        config.color
      )}
    >
      <Icon className="w-3.5 h-3.5" />
      {config.label}
    </Badge>
  );
}