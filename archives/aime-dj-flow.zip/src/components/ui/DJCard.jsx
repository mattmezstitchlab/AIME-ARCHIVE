import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, MapPin, CheckCircle } from 'lucide-react';

const DJ_PHOTOS = [
  'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80',
  'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&q=80',
  'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&q=80',
  'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600&q=80',
  'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=600&q=80',
];

export default function DJCard({ dj, compatibility, onViewProfile, onRequestQuote }) {
  const photoUrl = dj.photo || DJ_PHOTOS[Math.abs((dj.artistName || '').charCodeAt(0) || 0) % DJ_PHOTOS.length];

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 group border-0 shadow-md">
      <div className="relative">
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={photoUrl}
            alt={dj.artistName}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        </div>

        {compatibility && (
          <div className="absolute top-3 right-3">
            <div className="bg-[hsl(var(--primary))]/90 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-lg">
              <span className="text-xs font-bold text-white">{compatibility}%</span>
            </div>
          </div>
        )}

        {dj.verified && (
          <div className="absolute top-3 left-3">
            <Badge className="bg-[hsl(var(--primary))] text-white border-0 text-xs">
              <CheckCircle className="w-3 h-3 mr-1" />
              Vérifié
            </Badge>
          </div>
        )}

        <div className="absolute bottom-3 left-3 right-3">
          <h3 className="font-bold text-white text-lg drop-shadow-lg">{dj.artistName}</h3>
          <div className="flex items-center gap-1 text-white/80 text-sm">
            <MapPin className="w-3.5 h-3.5" />
            {dj.city}
          </div>
        </div>
      </div>

      <CardContent className="p-4 space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {dj.styles?.slice(0, 3).map((style, index) => (
            <Badge key={index} className="text-xs bg-[hsl(var(--accent))] text-[hsl(var(--primary))] border-[hsl(var(--primary))]/20">
              {style}
            </Badge>
          ))}
          {dj.badges?.map((badge, index) => (
            <Badge key={index} className="text-xs bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))] border-[hsl(var(--primary))]/20">
              {badge}
            </Badge>
          ))}
        </div>

        {dj.rating > 0 && (
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-[hsl(var(--primary))] text-[hsl(var(--primary))]" />
            <span className="font-medium">{dj.rating}</span>
            <span className="text-muted-foreground text-sm">({dj.reviewCount} avis)</span>
          </div>
        )}

        <div className="flex items-center justify-between pt-2 border-t border-[hsl(var(--primary))]/10">
          <div>
            <span className="text-xs text-muted-foreground">À partir de</span>
            <p className="font-bold text-lg text-[hsl(var(--primary))]">{dj.basePrice} €</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewProfile?.(dj)}
              className="border-[hsl(var(--primary))]/30 text-[hsl(var(--primary))] hover:bg-[hsl(var(--accent))]"
            >
              Profil
            </Button>
            <Button size="sm" onClick={() => onRequestQuote?.(dj)}>
              Devis
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}