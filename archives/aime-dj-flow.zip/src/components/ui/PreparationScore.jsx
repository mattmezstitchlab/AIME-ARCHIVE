import React from 'react';
import { cn } from '@/lib/utils';

export default function PreparationScore({ score, label = "Préparation", size = "md", showLabel = true }) {
  const getScoreColor = (score) => {
    if (score < 30) return 'text-destructive';
    if (score < 60) return 'text-orange-500';
    if (score < 80) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getScoreBg = (score) => {
    if (score < 30) return 'bg-destructive';
    if (score < 60) return 'bg-orange-500';
    if (score < 80) return 'bg-yellow-500';
    return 'bg-green-600';
  };

  const sizes = {
    sm: { ring: 'w-12 h-12', text: 'text-xs', number: 'text-sm' },
    md: { ring: 'w-16 h-16', text: 'text-sm', number: 'text-lg' },
    lg: { ring: 'w-24 h-24', text: 'text-base', number: 'text-2xl' },
    xl: { ring: 'w-32 h-32', text: 'text-lg', number: 'text-3xl' }
  };

  const circumference = 2 * Math.PI * 40;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative">
        <svg className={sizes[size].ring} viewBox="0 0 100 100">
          <circle
            className="text-muted stroke-current"
            strokeWidth="8"
            fill="transparent"
            r="40"
            cx="50"
            cy="50"
          />
          <circle
            className={cn("stroke-current transition-all duration-500", getScoreColor(score))}
            strokeWidth="8"
            strokeLinecap="round"
            fill="transparent"
            r="40"
            cx="50"
            cy="50"
            style={{
              strokeDasharray: circumference,
              strokeDashoffset: offset,
              transform: 'rotate(-90deg)',
              transformOrigin: '50% 50%'
            }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={cn("font-bold", sizes[size].number)}>{score}%</span>
        </div>
      </div>
      {showLabel && (
        <span className={cn("text-muted-foreground", sizes[size].text)}>{label}</span>
      )}
    </div>
  );
}