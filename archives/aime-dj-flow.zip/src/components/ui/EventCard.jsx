import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, Users, Music, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import PreparationScore from './PreparationScore';
import StatusBadge from './StatusBadge';

export default function EventCard({ event, onView, onEdit }) {
  const typeLabels = {
    mariage: 'Mariage',
    anniversaire: 'Anniversaire',
    soiree_privee: 'Soirée privée',
    seminaire: 'Séminaire',
    festival: 'Festival',
    bar_club: 'Bar / Club',
    associatif: 'Événement associatif',
    autre: 'Autre'
  };

  return (
    <Card className="hover:shadow-md transition-all duration-300">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-lg">{event.title}</h3>
            <Badge variant="secondary" className="mt-2">
              {typeLabels[event.type]}
            </Badge>
          </div>
          <StatusBadge status={event.status} />
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>{format(new Date(event.date), 'd MMM yyyy', { locale: fr })}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span className="truncate">{event.city}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="w-4 h-4" />
            <span>{event.guestCount} invités</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{event.startTime} - {event.endTime}</span>
          </div>
        </div>

        {event.mood && event.mood.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {event.mood.slice(0, 4).map((m, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                <Music className="w-3 h-3 mr-1" />
                {m}
              </Badge>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between pt-3 border-t">
          <PreparationScore score={event.preparationScore || 0} size="sm" />
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit?.(event)}
            >
              Modifier
            </Button>
            <Button
              size="sm"
              onClick={() => onView?.(event)}
              className="bg-primary hover:bg-primary/90"
            >
              Voir
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}