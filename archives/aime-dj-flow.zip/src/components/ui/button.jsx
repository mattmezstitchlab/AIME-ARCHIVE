import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority"
import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-all duration-200 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "nm-btn-accent text-white px-6 py-2.5 rounded-full",
        destructive: "bg-red-600 text-white rounded-full px-6 py-2.5 shadow-[5px_5px_10px_#161616,-5px_-5px_10px_#2e2e2e] hover:bg-red-500",
        outline: "nm-btn text-[#e0e0e0] px-6 py-2.5 rounded-full",
        secondary: "nm-btn text-[#aaaaaa] px-6 py-2.5 rounded-full",
        ghost: "text-[#aaaaaa] hover:text-[#e0e0e0] hover:nm-btn px-4 py-2 rounded-full",
        link: "text-[#e8570a] underline-offset-4 hover:underline",
        glass: "nm-btn text-[#e0e0e0] px-6 py-2.5 rounded-full",
      },
      size: {
        default: "h-11 px-6 py-2.5 text-sm",
        sm: "h-9 px-4 text-xs rounded-full",
        lg: "h-12 px-8 text-base rounded-full",
        icon: "h-10 w-10 rounded-full",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
)

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"
  return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
})
Button.displayName = "Button"

export { Button, buttonVariants }