import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Music, User, Package, AlertCircle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import StatusBadge from './StatusBadge';

const phaseIcons = {
  avant_evenement: '📋',
  installation: '🔧',
  ceremonie: '💒',
  cocktail: '🥂',
  repas: '🍽️',
  discours: '🎤',
  ouverture_bal: '💃',
  soiree: '🎉',
  fin: '🌙',
  apres_evenement: '✨'
};

const phaseLabels = {
  avant_evenement: 'Avant événement',
  installation: 'Installation',
  ceremonie: 'Cérémonie',
  cocktail: 'Cocktail / Vin d\'honneur',
  repas: 'Repas',
  discours: 'Discours',
  ouverture_bal: 'Ouverture de bal',
  soiree: 'Soirée dansante',
  fin: 'Fin',
  apres_evenement: 'Après événement'
};

export default function TimelineItem({ moment, isLast = false }) {
  return (
    <div className="relative flex gap-4 pb-8">
      {!isLast && (
        <div className="absolute left-4 top-12 bottom-0 w-px bg-border" />
      )}
      
      <div className="relative z-10 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 border-2 border-primary/20">
        <span className="text-sm">{phaseIcons[moment.phase]}</span>
      </div>
      
      <Card className="flex-1 p-4 hover:shadow-md transition-all duration-300">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Badge variant="outline" className="text-xs">
                {phaseLabels[moment.phase]}
              </Badge>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                <span className="text-sm font-medium">{moment.time}</span>
              </div>
            </div>
            
            <h4 className="font-semibold text-lg mb-2">{moment.title}</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              {moment.responsible && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <User className="w-4 h-4" />
                  <span>Responsable : {moment.responsible}</span>
                </div>
              )}
              {moment.music && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Music className="w-4 h-4" />
                  <span className="truncate">{moment.music}</span>
                </div>
              )}
              {moment.equipment && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Package className="w-4 h-4" />
                  <span>{moment.equipment}</span>
                </div>
              )}
            </div>
            
            {moment.notes && (
              <p className="text-sm text-muted-foreground mt-3 italic">
                {moment.notes}
              </p>
            )}
          </div>
          
          <div className="flex-shrink-0">
            <StatusBadge status={moment.status} />
          </div>
        </div>
      </Card>
    </div>
  );
}