import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';

const allStyles = [
  'Généraliste', 'Pop', 'Disco', 'House', 'Lounge', 'Afro', 'Latino',
  'Années 90/2000', 'Funk', 'Soul', 'Électro', 'Club', 'Rock', 'Jazz',
  'Variété', 'R&B', 'Reggaeton', 'Techno'
];

const cities = [
  'Paris', 'Lille', 'Lyon', 'Bordeaux', 'Nantes', 'Marseille', 
  'Toulouse', 'Nice', 'Strasbourg', 'Montpellier', 'Rennes', 'Grenoble'
];

export default function AdvancedFilters({ 
  selectedStyles, 
  setSelectedStyles, 
  selectedCities, 
  setSelectedCities,
  onClearFilters 
}) {
  const toggleStyle = (style) => {
    if (selectedStyles.includes(style)) {
      setSelectedStyles(selectedStyles.filter(s => s !== style));
    } else {
      setSelectedStyles([...selectedStyles, style]);
    }
  };

  const toggleCity = (city) => {
    if (selectedCities.includes(city)) {
      setSelectedCities(selectedCities.filter(c => c !== city));
    } else {
      setSelectedCities([...selectedCities, city]);
    }
  };

  const hasActiveFilters = selectedStyles.length > 0 || selectedCities.length > 0;

  return (
    <div className="space-y-6">
      {/* Styles musicaux */}
      <div>
        <h3 className="font-semibold text-lg mb-4 text-white">Styles musicaux</h3>
        <div className="flex flex-wrap gap-2">
          {allStyles.map((style) => (
            <Badge
              key={style}
              onClick={() => toggleStyle(style)}
              className={`cursor-pointer transition-all ${
                selectedStyles.includes(style)
                  ? 'bg-white text-black font-medium'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {style}
            </Badge>
          ))}
        </div>
      </div>

      {/* Disponibilités géographiques */}
      <div>
        <h3 className="font-semibold text-lg mb-4 text-white">Disponibilités géographiques</h3>
        <div className="flex flex-wrap gap-2">
          {cities.map((city) => (
            <Badge
              key={city}
              onClick={() => toggleCity(city)}
              className={`cursor-pointer transition-all ${
                selectedCities.includes(city)
                  ? 'bg-white text-black font-medium'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {city}
            </Badge>
          ))}
        </div>
      </div>

      {/* Filtres actifs */}
      {hasActiveFilters && (
        <div className="flex items-center justify-between pt-4 border-t border-gray-800">
          <div className="flex flex-wrap gap-2">
            {selectedStyles.map((style) => (
              <Badge
                key={style}
                className="bg-white text-black gap-1"
              >
                {style}
                <X 
                  className="w-3 h-3 cursor-pointer" 
                  onClick={() => toggleStyle(style)}
                />
              </Badge>
            ))}
            {selectedCities.map((city) => (
              <Badge
                key={city}
                className="bg-gray-700 text-white gap-1"
              >
                {city}
                <X 
                  className="w-3 h-3 cursor-pointer" 
                  onClick={() => toggleCity(city)}
                />
              </Badge>
            ))}
          </div>
          <Button
            variant="outline"
            onClick={onClearFilters}
            className="border-gray-700 text-gray-400 hover:bg-gray-800"
          >
            Effacer les filtres
          </Button>
        </div>
      )}
    </div>
  );
}