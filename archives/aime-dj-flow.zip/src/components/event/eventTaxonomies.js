import { initialMoments } from '@/components/wedding/workspaceData';
import { momentProviderMap } from '@/components/wedding/providerData';

const moment = (time, title, phase, responsible, providers, duration = '1 h') => ({ time, title, phase, responsible, providers, duration });

export const eventTaxonomies = {
  mariage: {
    label: 'Mariage', audienceLabel: 'Invités',
    questions: [
      { key:'ceremonyType', label:'Type de cérémonie', options:['Civile','Laïque','Religieuse','Plusieurs cérémonies'] },
      { key:'coupleNames', label:'Noms des mariés', placeholder:'Camille & Hugo' },
      { key:'mealFormat', label:'Format du repas', options:['Dîner assis','Buffet','Cocktail dînatoire','À définir'] },
    ],
    moments: initialMoments.map(item => item.title),
  },
  anniversaire: {
    label:'Anniversaire', audienceLabel:'Invités', questions:[
      { key:'celebratedAge', label:'Âge célébré', placeholder:'Ex. 40 ans' },
      { key:'surpriseLevel', label:'Organisation', options:['Surprise complète','Partiellement surprise','Sans surprise'] },
      { key:'mealFormat', label:'Format', options:['Dîner assis','Buffet','Cocktail','Soirée dansante'] },
    ], moments:[
      moment('16:00','Installation & décoration','Préparation','Organisateur',['decor','rentals']), moment('18:00','Accueil des invités','Accueil','Hôte',['venue','caterer']), moment('19:00','Cocktail & retrouvailles','Cocktail','Traiteur',['caterer','live_music']), moment('20:30','Repas d’anniversaire','Repas','Traiteur',['caterer','dj']), moment('22:00','Gâteau & discours','Moment clé','Proches',['pastry','dj','photographer']), moment('22:30','Soirée dansante','Soirée','DJ',['dj','sound_light','photo_booth']), moment('02:00','Clôture','Fin','Organisateur',['transport','security']),
    ]
  },
  soiree_privee: {
    label:'Soirée privée', audienceLabel:'Invités', questions:[
      { key:'partyPurpose', label:'Occasion', placeholder:'Ex. retrouvailles, lancement privé' },
      { key:'dressCode', label:'Dress code', placeholder:'Ex. cocktail, blanc, libre' },
      { key:'accessMode', label:'Accès', options:['Sur invitation','Liste nominative','Billetterie','Libre'] },
    ], moments:[
      moment('17:00','Montage technique','Technique','Régisseur',['sound_light','decor']), moment('19:00','Accueil & contrôle d’accès','Accueil','Hôte',['security','venue']), moment('20:00','Cocktail','Hospitalité','Traiteur',['caterer','bar_staff']), moment('21:30','Temps fort','Animation','Animateur',['host','dj']), moment('22:00','Dancefloor','Soirée','DJ',['dj','sound_light','security']), moment('02:00','Sortie des invités','Clôture','Organisation',['transport','security']),
    ]
  },
  seminaire: {
    label:'Séminaire', audienceLabel:'Participants', questions:[
      { key:'companyName', label:'Entreprise', placeholder:'Nom de l’entreprise' },
      { key:'seminarGoal', label:'Objectif principal', options:['Cohésion','Formation','Stratégie','Lancement'] },
      { key:'roomFormat', label:'Disposition', options:['Théâtre','Classe','Tables rondes','Hybride'] },
    ], moments:[
      moment('07:30','Installation audiovisuelle','Technique','Régisseur',['sound_light','production']), moment('08:30','Accueil café','Accueil','Organisation',['venue','caterer']), moment('09:00','Plénière d’ouverture','Conférence','Direction',['speaker','sound_light']), moment('10:30','Ateliers','Travail','Facilitateurs',['host','rentals']), moment('12:30','Déjeuner networking','Restauration','Traiteur',['caterer','venue']), moment('14:00','Sessions de travail','Programme','Intervenants',['speaker','production']), moment('17:00','Synthèse & clôture','Clôture','Direction',['sound_light']), moment('18:00','Cocktail de networking','Convivialité','Organisation',['caterer','live_music']),
    ]
  },
  festival: {
    label:'Festival', audienceLabel:'Public', questions:[
      { key:'festivalFormat', label:'Format artistique', options:['Musique','Cinéma','Arts de rue','Pluridisciplinaire'] },
      { key:'publicAccess', label:'Accès public', options:['Billetterie','Gratuit','Invitation','Mixte'] },
      { key:'stageCount', label:'Nombre de scènes ou espaces', placeholder:'Ex. 3' },
    ], moments:[
      moment('06:00','Ouverture du site & montage','Production','Direction technique',['production','security','sound_light'],'4 h'), moment('10:00','Balances & répétitions','Technique','Régie',['sound_light','live_music'],'3 h'), moment('13:00','Brief équipes & sécurité','Coordination','Production',['security','first_aid']), moment('14:00','Ouverture des portes','Accueil','Billetterie',['ticketing','security']), moment('15:00','Programmation après-midi','Programmation','Régie',['production','sound_light','caterer'],'4 h'), moment('19:00','Tête d’affiche','Programmation','Production',['live_music','sound_light','security'],'2 h'), moment('21:00','Programmation nocturne','Soirée','Régie',['dj','sound_light','security'],'4 h'), moment('01:00','Évacuation du public','Clôture','Sécurité',['security','first_aid']), moment('02:00','Fermeture technique','Démontage','Production',['production','cleaning'],'2 h'),
    ]
  },
  bar_club: {
    label:'Bar / Club', audienceLabel:'Clients', questions:[
      { key:'venueConcept', label:'Concept de la soirée', placeholder:'Ex. afro house, années 2000' },
      { key:'entryPolicy', label:'Politique d’entrée', options:['Entrée libre','Prévente','Sur liste','Réservation'] },
      { key:'musicFormat', label:'Format musical', options:['DJ set','Live','DJ + live','Open format'] },
    ], moments:[
      moment('18:00','Mise en place salle & bar','Préparation','Manager',['bar_staff','sound_light']), moment('20:00','Ouverture','Accueil','Équipe accueil',['security','ticketing']), moment('21:00','Warm-up','Musique','DJ',['dj','sound_light']), moment('23:00','Peak time','Musique','DJ',['dj','sound_light','security'],'3 h'), moment('02:00','Dernier service','Clôture','Manager',['bar_staff','security']), moment('03:00','Fermeture & nettoyage','Fin','Équipe',['cleaning','security']),
    ]
  },
  associatif: {
    label:'Événement associatif', audienceLabel:'Participants', questions:[
      { key:'associationName', label:'Association', placeholder:'Nom de l’association' },
      { key:'eventGoal', label:'Objectif', options:['Collecte de fonds','Sensibilisation','Célébration','Rencontre'] },
      { key:'volunteerCount', label:'Nombre de bénévoles', placeholder:'Ex. 25' },
    ], moments:[
      moment('08:00','Installation bénévoles','Préparation','Coordination',['rentals','sound_light']), moment('10:00','Accueil du public','Accueil','Bénévoles',['ticketing','security']), moment('11:00','Présentation du projet','Prise de parole','Association',['host','sound_light']), moment('12:00','Temps convivial','Restauration','Bénévoles',['caterer']), moment('14:00','Animations & ateliers','Programme','Équipes',['host','production']), moment('17:00','Remerciements & bilan','Clôture','Association',['sound_light']), moment('18:00','Rangement','Fin','Bénévoles',['cleaning','rentals']),
    ]
  },
  autre: {
    label:'Autre événement', audienceLabel:'Participants', questions:[
      { key:'eventPurpose', label:'Objectif de l’événement', placeholder:'Décrivez le résultat attendu' },
      { key:'eventFormat', label:'Format', options:['Privé','Professionnel','Public','Hybride'] },
      { key:'keyConstraint', label:'Contrainte principale', placeholder:'Accès, horaire, technique…' },
    ], moments:[
      moment('08:00','Installation','Préparation','Organisation',['venue','production']), moment('10:00','Accueil','Accueil','Organisation',['security','caterer']), moment('11:00','Ouverture','Programme','Responsable',['host','sound_light']), moment('12:30','Temps principal','Programme','Organisation',['production']), moment('17:00','Clôture','Fin','Responsable',['sound_light']), moment('18:00','Démontage','Logistique','Équipe technique',['production','cleaning']),
    ]
  },
};

export const getTaxonomy = type => eventTaxonomies[type] || eventTaxonomies.autre;
export const getMomentChoices = type => getTaxonomy(type).moments.map(item => typeof item === 'string' ? item : item.title);

export function createTimelineForEvent(event) {
  const taxonomy = getTaxonomy(event?.type);
  if (event?.type === 'mariage') return initialMoments.map(item => ({ ...item, location:event.venue || event.city || item.location, providerTypes:momentProviderMap[item.id] || [] }));
  return taxonomy.moments.map((item, index) => ({
    id:`${event?.type || 'event'}-${index + 1}`, day:Number(item.time.split(':')[0]) < 6 ? 1 : 0,
    time:item.time, duration:item.duration, title:item.title, phase:item.phase, responsible:item.responsible,
    location:event?.venue || event?.city || 'Lieu à définir', detail:`${taxonomy.label} · ${event?.city || 'lieu à confirmer'}`,
    coordination:'À confirmer avec les équipes', technical:'Configuration à valider', status:index < 2 ? 'ready' : 'attention', providerTypes:item.providers,
  }));
}