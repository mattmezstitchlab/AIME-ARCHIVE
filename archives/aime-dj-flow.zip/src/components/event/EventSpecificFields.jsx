import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function EventSpecificFields({ questions, values, onChange }) {
  return <div className="grid gap-4 rounded-2xl border border-border p-5 md:grid-cols-2">
    {questions.map(question => <div key={question.key} className="space-y-2">
      <Label htmlFor={question.key}>{question.label}</Label>
      {question.options ? <select id={question.key} className="nm-input h-11 w-full px-3 text-sm" value={values[question.key] || ''} onChange={event => onChange(question.key, event.target.value)}>
        <option value="">Sélectionner</option>
        {question.options.map(option => <option key={option} value={option}>{option}</option>)}
      </select> : <Input id={question.key} placeholder={question.placeholder} value={values[question.key] || ''} onChange={event => onChange(question.key, event.target.value)} />}
    </div>)}
  </div>;
}