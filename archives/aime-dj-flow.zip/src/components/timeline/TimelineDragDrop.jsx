import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { GripVertical, Clock, Music, User, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';

const phaseColors = {
  avant_evenement: 'bg-slate-100 text-slate-700',
  installation: 'bg-blue-100 text-blue-700',
  ceremonie: 'bg-purple-100 text-purple-700',
  cocktail: 'bg-amber-100 text-amber-700',
  repas: 'bg-orange-100 text-orange-700',
  discours: 'bg-red-100 text-red-700',
  ouverture_bal: 'bg-pink-100 text-pink-700',
  soiree: 'bg-indigo-100 text-indigo-700',
  fin: 'bg-slate-100 text-slate-700',
  apres_evenement: 'bg-slate-100 text-slate-700'
};

const phaseLabels = {
  avant_evenement: 'Avant événement',
  installation: 'Installation',
  ceremonie: 'Cérémonie',
  cocktail: 'Cocktail',
  repas: 'Repas',
  discours: 'Discours',
  ouverture_bal: 'Ouverture de bal',
  soiree: 'Soirée',
  fin: 'Fin',
  apres_evenement: 'Après événement'
};

export default function TimelineDragDrop({ moments, onReorder }) {
  const [sortedMoments, setSortedMoments] = useState(moments || []);

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(sortedMoments);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setSortedMoments(items);
    
    // Mettre à jour l'ordre avec les indexes
    const updatedMoments = items.map((moment, index) => ({
      ...moment,
      order: index
    }));
    
    if (onReorder) {
      onReorder(updatedMoments);
    }
  };

  return (
    <Card className="border-2 border-dashed border-border">
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-lg">Déroulé de l'événement</h3>
            <p className="text-sm text-muted-foreground">
              Glissez-déposez les moments pour réorganiser la timeline
            </p>
          </div>
          <Badge variant="outline" className="text-sm">
            {sortedMoments.length} moments
          </Badge>
        </div>

        {sortedMoments.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Aucun moment à afficher</p>
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="timeline">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="space-y-3"
                >
                  {sortedMoments.map((moment, index) => (
                    <Draggable
                      key={moment.id || `moment-${index}`}
                      draggableId={moment.id || `moment-${index}`}
                      index={index}
                    >
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={cn(
                            'bg-white border rounded-lg p-4 transition-all duration-200',
                            snapshot.isDragging ? 'shadow-lg rotate-1 scale-105' : 'hover:shadow-md',
                            'flex items-start gap-4'
                          )}
                        >
                          {/* Drag handle */}
                          <div
                            {...provided.dragHandleProps}
                            className="mt-1 cursor-grab active:cursor-grabbing"
                          >
                            <GripVertical className="w-5 h-5 text-muted-foreground hover:text-primary transition-colors" />
                          </div>

                          {/* Phase indicator */}
                          <div className={cn(
                            'w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0',
                            phaseColors[moment.phase] || 'bg-slate-100'
                          )}>
                            <Clock className="w-6 h-6" />
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div>
                                <h4 className="font-semibold text-base">{moment.title}</h4>
                                <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Clock className="w-3 h-3" />
                                    {moment.time || 'Horaire non défini'}
                                  </span>
                                  {moment.responsible && (
                                    <span className="flex items-center gap-1">
                                      <User className="w-3 h-3" />
                                      {moment.responsible}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <Badge className={cn(
                                'text-xs',
                                phaseColors[moment.phase] || 'bg-slate-100'
                              )}>
                                {phaseLabels[moment.phase] || moment.phase}
                              </Badge>
                            </div>

                            {/* Additional details */}
                            {(moment.music || moment.equipment || moment.notes) && (
                              <div className="mt-3 pt-3 border-t border-border/50 space-y-1">
                                {moment.music && (
                                  <p className="text-sm flex items-center gap-2 text-muted-foreground">
                                    <Music className="w-3 h-3" />
                                    {moment.music}
                                  </p>
                                )}
                                {moment.equipment && (
                                  <p className="text-sm flex items-center gap-2 text-muted-foreground">
                                    <MapPin className="w-3 h-3" />
                                    {moment.equipment}
                                  </p>
                                )}
                                {moment.notes && (
                                  <p className="text-sm text-muted-foreground italic">
                                    {moment.notes}
                                  </p>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Order number */}
                          <div className="text-right flex-shrink-0">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="text-sm font-semibold text-primary">
                                {index + 1}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </CardContent>
    </Card>
  );
}