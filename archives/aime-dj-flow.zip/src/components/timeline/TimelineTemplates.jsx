import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Music, Mic, Utensils, Wine, Sparkles, Briefcase } from 'lucide-react';

const timelineTemplates = {
  mariage: [
    { title: 'Installation matériel', time: '14:00', phase: 'installation', responsible: 'DJ', music: '', equipment: 'Sonorisation, lumières' },
    { title: 'Arrivée des invités', time: '16:00', phase: 'avant_evenement', responsible: 'Mariés', music: "Fond sonore d'ambiance", equipment: '' },
    { title: 'Cérémonie laïque', time: '16:30', phase: 'ceremonie', responsible: 'Mariés', music: 'Musique choisie par les mariés', equipment: 'Micro' },
    { title: 'Vin d\'honneur', time: '17:30', phase: 'cocktail', responsible: 'Traiteur', music: 'Fond sonore jazzy', equipment: '' },
    { title: 'Entrée en salle', time: '20:00', phase: 'repas', responsible: 'Mariés', music: "Musique d'entrée", equipment: '' },
    { title: 'Discours', time: '22:00', phase: 'discours', responsible: 'Témoins', music: '', equipment: 'Micro' },
    { title: 'Ouverture de bal', time: '22:30', phase: 'ouverture_bal', responsible: 'Mariés', music: 'Danse des mariés', equipment: '' },
    { title: 'Soirée dansante', time: '23:00', phase: 'soiree', responsible: 'DJ', music: 'Playlist soirée', equipment: '' },
    { title: 'Fin de soirée', time: '01:00', phase: 'fin', responsible: 'DJ', music: '', equipment: '' }
  ],
  seminaire: [
    { title: 'Installation', time: '08:00', phase: 'installation', responsible: 'DJ', music: '', equipment: 'Sonorisation, micros, projecteur' },
    { title: 'Accueil participants', time: '09:00', phase: 'avant_evenement', responsible: 'Organisateur', music: 'Fond sonore', equipment: '' },
    { title: 'Présentations', time: '09:30', phase: 'ceremonie', responsible: 'Direction', music: '', equipment: 'Micro, projecteur' },
    { title: 'Pause café', time: '10:30', phase: 'cocktail', responsible: 'Traiteur', music: '', equipment: '' },
    { title: 'Ateliers', time: '11:00', phase: 'repas', responsible: 'Animateurs', music: '', equipment: '' },
    { title: 'Déjeuner', time: '12:30', phase: 'repas', responsible: 'Traiteur', music: 'Fond sonore', equipment: '' },
    { title: 'Conférences', time: '14:00', phase: 'ceremonie', responsible: 'Intervenants', music: '', equipment: 'Micro, projecteur' },
    { title: 'Pause après-midi', time: '16:00', phase: 'cocktail', responsible: 'Traiteur', music: '', equipment: '' },
    { title: 'Clôture', time: '17:00', phase: 'fin', responsible: 'Direction', music: '', equipment: 'Micro' },
    { title: 'Cocktail dînatoire', time: '19:00', phase: 'soiree', responsible: 'Traiteur', music: 'Ambiance lounge', equipment: '' }
  ],
  cocktail: [
    { title: 'Installation', time: '17:00', phase: 'installation', responsible: 'DJ', music: '', equipment: 'Sonorisation d\'ambiance' },
    { title: 'Arrivée invités', time: '18:00', phase: 'avant_evenement', responsible: 'Hôte', music: 'Jazz manouche', equipment: '' },
    { title: 'Mot de bienvenue', time: '18:30', phase: 'ceremonie', responsible: 'Hôte', music: '', equipment: 'Micro' },
    { title: 'Dégustation', time: '19:00', phase: 'cocktail', responsible: 'Traiteur', music: 'Ambiance lounge', equipment: '' },
    { title: 'Animation musicale', time: '20:00', phase: 'soiree', responsible: 'DJ', music: 'Set live', equipment: '' },
    { title: 'Clôture', time: '22:00', phase: 'fin', responsible: 'Hôte', music: '', equipment: '' }
  ],
  anniversaire: [
    { title: 'Installation', time: '19:00', phase: 'installation', responsible: 'DJ', music: '', equipment: 'Sonorisation, lumières' },
    { title: 'Arrivée invités', time: '20:00', phase: 'avant_evenement', responsible: 'Organisateur', music: 'Fond sonore', equipment: '' },
    { title: 'Apéritif', time: '20:30', phase: 'cocktail', responsible: 'Traiteur', music: 'Ambiance festive', equipment: '' },
    { title: 'Repas', time: '21:30', phase: 'repas', responsible: 'Traiteur', music: 'Fond sonore', equipment: '' },
    { title: 'Discours & gâteau', time: '23:00', phase: 'discours', responsible: 'Organisateur', music: "Joyeux anniversaire", equipment: 'Micro' },
    { title: 'Soirée dansante', time: '23:30', phase: 'soiree', responsible: 'DJ', music: 'Playlist anniversaire', equipment: '' },
    { title: 'Fin', time: '02:00', phase: 'fin', responsible: 'DJ', music: '', equipment: '' }
  ],
  festival: [
    { title: 'Soundcheck', time: '10:00', phase: 'installation', responsible: 'DJ', music: '', equipment: 'Sonorisation complète' },
    { title: 'Ouverture portes', time: '14:00', phase: 'avant_evenement', responsible: 'Organisation', music: 'DJ set 1', equipment: '' },
    { title: 'Première partie', time: '15:00', phase: 'soiree', responsible: 'Artiste 1', music: 'Live', equipment: 'Backline' },
    { title: 'Deuxième partie', time: '17:00', phase: 'soiree', responsible: 'Artiste 2', music: 'Live', equipment: 'Backline' },
    { title: 'Tête d\'affiche', time: '20:00', phase: 'soiree', responsible: 'Artiste principal', music: 'Live', equipment: 'Backline complète' },
    { title: 'After', time: '23:00', phase: 'soiree', responsible: 'DJ', music: 'DJ set 2', equipment: '' },
    { title: 'Fin', time: '01:00', phase: 'fin', responsible: 'DJ', music: '', equipment: '' }
  ]
};

const phaseIcons = {
  installation: Clock,
  avant_evenement: Sparkles,
  ceremonie: Music,
  cocktail: Wine,
  repas: Utensils,
  discours: Mic,
  ouverture_bal: Music,
  soiree: Music,
  fin: Clock
};

const templateInfo = {
  mariage: {
    label: 'Mariage',
    icon: Sparkles,
    description: 'Déroulé complet de 9h',
    color: 'bg-pink-100 text-pink-800 border-pink-200'
  },
  seminaire: {
    label: 'Séminaire entreprise',
    icon: Briefcase,
    description: 'Journée professionnelle de 9h',
    color: 'bg-blue-100 text-blue-800 border-blue-200'
  },
  cocktail: {
    label: 'Cocktail dînatoire',
    icon: Wine,
    description: 'Soirée de 5h',
    color: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  anniversaire: {
    label: 'Anniversaire',
    icon: Music,
    description: 'Soirée festive de 7h',
    color: 'bg-purple-100 text-purple-800 border-purple-200'
  },
  festival: {
    label: 'Festival / Concert',
    icon: Music,
    description: 'Événement musical de 15h',
    color: 'bg-orange-100 text-orange-800 border-orange-200'
  }
};

export default function TimelineTemplates({ onSelect, eventType }) {
  const availableTemplates = eventType ? 
    (timelineTemplates[eventType] ? [eventType] : Object.keys(timelineTemplates)) : 
    Object.keys(timelineTemplates);

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-heading text-lg font-semibold mb-2">Modèles de timeline</h3>
        <p className="text-sm text-muted-foreground">
          Sélectionnez un modèle prédéfini pour créer rapidement votre déroulé
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {availableTemplates.map((type) => {
          const template = timelineTemplates[type];
          const info = templateInfo[type];
          const Icon = info?.icon || Clock;

          if (!template) return null;

          return (
            <Card 
              key={type} 
              className={`cursor-pointer hover:shadow-lg transition-all duration-300 border-2 ${
                eventType === type ? 'border-primary' : 'border-transparent'
              }`}
              onClick={() => template && onSelect(template, type)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${info?.color || 'bg-primary/10'}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm">{info?.label || type}</h4>
                    <p className="text-xs text-muted-foreground">{info?.description}</p>
                  </div>
                </div>

                <div className="space-y-1 mb-3">
                  {template.slice(0, 3).map((moment, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      <span>{moment.time} - {moment.title}</span>
                    </div>
                  ))}
                  {template.length > 3 && (
                    <p className="text-xs text-muted-foreground pl-5">
                      +{template.length - 3} autres moments
                    </p>
                  )}
                </div>

                <Button size="sm" className="w-full" variant={eventType === type ? 'default' : 'outline'}>
                  Utiliser ce modèle
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export { timelineTemplates };