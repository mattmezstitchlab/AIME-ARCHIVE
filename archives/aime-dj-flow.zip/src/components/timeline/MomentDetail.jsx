import React, { useState } from 'react';
import { X, Music, User, Wrench, StickyNote, CheckCircle2, HelpCircle, AlertCircle, Send, MessageSquare, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

const STATUS_CONFIG = {
  valide:      { label: 'Validé',      color: 'text-[#e91e8c]',  icon: CheckCircle2 },
  pret:        { label: 'Prêt',        color: 'text-green-400',   icon: CheckCircle2 },
  a_confirmer: { label: 'À confirmer', color: 'text-yellow-400',  icon: HelpCircle },
  incomplet:   { label: 'Incomplet',   color: 'text-gray-500',    icon: AlertCircle },
};

export default function MomentDetail({ moment, messages = [], onSendMessage, onClose }) {
  const [tab, setTab] = useState('detail');
  const [newMsg, setNewMsg] = useState('');

  if (!moment) return null;

  const st = STATUS_CONFIG[moment.status] || STATUS_CONFIG.incomplet;
  const StatusIcon = st.icon;

  const send = () => {
    if (!newMsg.trim()) return;
    onSendMessage?.(newMsg.trim());
    setNewMsg('');
  };

  const details = [
    moment.responsible && { label: 'Responsable', value: moment.responsible, icon: User },
    moment.music       && { label: 'Musique',      value: moment.music,       icon: Music },
    moment.equipment   && { label: 'Matériel',     value: moment.equipment,   icon: Wrench },
    moment.notes       && { label: 'Notes',         value: moment.notes,       icon: StickyNote },
  ].filter(Boolean);

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a]">
      {/* Header */}
      <div className="flex items-start justify-between px-6 py-5 border-b border-white/10">
        <div>
          <p className="text-xs text-gray-600 font-mono mb-1">{moment.time}</p>
          <h2 className="text-white font-bold text-base">{moment.title}</h2>
          <div className={cn("flex items-center gap-1.5 mt-1.5 text-xs", st.color)}>
            <StatusIcon className="w-3.5 h-3.5" />
            {st.label}
          </div>
        </div>
        <button onClick={onClose} className="text-gray-600 hover:text-white transition-colors p-1 mt-0.5">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Sub-tabs */}
      <div className="flex border-b border-white/8">
        {[
          { key: 'detail',   label: 'Détails',  icon: Clock },
          { key: 'messages', label: 'Messages', icon: MessageSquare },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-medium transition-colors",
              tab === t.key ? "text-[#e91e8c] border-b-2 border-[#e91e8c]" : "text-gray-600 hover:text-white"
            )}
          >
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
            {t.key === 'messages' && messages.filter(m => m.from !== 'Vous').length > 0 && (
              <span className="w-3.5 h-3.5 rounded-full bg-[#e91e8c] text-white text-[9px] flex items-center justify-center">
                {messages.filter(m => m.from !== 'Vous').length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto">
        {tab === 'detail' && (
          <div className="p-5 space-y-3">
            {details.length === 0 && (
              <p className="text-gray-600 text-sm text-center py-10">Aucun détail renseigné.</p>
            )}
            {details.map((d, i) => (
              <div key={i} className="flex items-start gap-3 p-4 rounded-xl bg-white/5 border border-white/8">
                <d.icon className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500 mb-0.5 uppercase tracking-wide">{d.label}</p>
                  <p className="text-white text-sm">{d.value}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'messages' && (
          <div className="px-5 py-4 space-y-3">
            {messages.length === 0 && (
              <p className="text-gray-600 text-sm text-center py-10">Aucun message pour ce moment.</p>
            )}
            {messages.map(m => (
              <div key={m.id} className={cn("flex gap-2", m.from === 'Vous' ? "flex-row-reverse" : "flex-row")}>
                <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-[11px] text-gray-300 font-bold flex-shrink-0">
                  {m.avatar}
                </div>
                <div className={cn("flex flex-col gap-0.5 max-w-[80%]", m.from === 'Vous' ? "items-end" : "items-start")}>
                  <span className="text-[11px] text-gray-600">{m.time}</span>
                  <div className={cn(
                    "px-3 py-2 rounded-xl text-sm",
                    m.from === 'Vous' ? "bg-[#e91e8c] text-white rounded-tr-sm" : "bg-white/10 text-white rounded-tl-sm"
                  )}>
                    {m.text}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Message input (only on messages tab) */}
      {tab === 'messages' && (
        <div className="p-4 border-t border-white/8 flex gap-2">
          <input
            value={newMsg}
            onChange={e => setNewMsg(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && send()}
            placeholder="Message…"
            className="flex-1 bg-white/8 border border-white/10 rounded-full px-4 py-2 text-sm text-white placeholder-gray-600 outline-none focus:border-[#e91e8c]/50"
          />
          <button onClick={send} className="w-8 h-8 rounded-full bg-[#e91e8c] flex items-center justify-center hover:bg-[#c91578] transition-colors flex-shrink-0">
            <Send className="w-3.5 h-3.5 text-white" />
          </button>
        </div>
      )}
    </div>
  );
}