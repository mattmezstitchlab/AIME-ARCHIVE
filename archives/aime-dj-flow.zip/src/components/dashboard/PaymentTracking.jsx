import React, { useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Clock, CreditCard } from 'lucide-react';

export default function PaymentTracking({ totalAmount = 2500, depositAmount = 750, balanceAmount = 1750 }) {
  const [paymentState, setPaymentState] = React.useState({
    depositPaid: false,
    balancePaid: false
  });

  const handleDepositToggle = () => {
    setPaymentState(prev => ({ ...prev, depositPaid: !prev.depositPaid }));
  };

  const handleBalanceToggle = () => {
    setPaymentState(prev => ({ ...prev, balancePaid: !prev.balancePaid }));
  };

  const depositPercentage = Math.round((depositAmount / totalAmount) * 100);

  return (
    <Card className="border-gray-800 bg-gray-900/50 backdrop-blur-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-gray-400" />
            <h3 className="font-semibold text-white">Suivi des paiements</h3>
          </div>
          <Badge variant="outline" className="border-gray-700 text-gray-400">
            Total: {totalAmount} €
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Progression</span>
            <span className="text-white font-medium">
              {paymentState.depositPaid && paymentState.balancePaid ? '100%' : 
               paymentState.depositPaid ? `${depositPercentage}%` : '0%'}
            </span>
          </div>
          <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-500 ${
                paymentState.depositPaid && paymentState.balancePaid 
                  ? 'bg-green-600 w-full' 
                  : paymentState.depositPaid 
                    ? 'bg-gray-600' 
                    : 'w-0'
              }`}
              style={{ width: paymentState.depositPaid ? `${depositPercentage}%` : '0%' }}
            />
          </div>
        </div>

        {/* Payment states */}
        <div className="grid md:grid-cols-2 gap-4">
          {/* Deposit */}
          <div 
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              paymentState.depositPaid 
                ? 'bg-green-900/20 border-green-800' 
                : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
            }`}
            onClick={handleDepositToggle}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                {paymentState.depositPaid ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <Clock className="w-5 h-5 text-gray-500" />
                )}
                <span className={`font-medium ${
                  paymentState.depositPaid ? 'text-green-400' : 'text-gray-400'
                }`}>
                  Acompte versé
                </span>
              </div>
              <Badge className={
                paymentState.depositPaid 
                  ? 'bg-green-900/50 text-green-400 border-green-800' 
                  : 'bg-gray-800 text-gray-500 border-gray-700'
              }>
                {paymentState.depositPaid ? 'Payé' : 'En attente'}
              </Badge>
            </div>
            <div className="mt-3">
              <div className="text-2xl font-bold text-white">{depositAmount} €</div>
              <p className="text-xs text-gray-500 mt-1">
                {depositPercentage}% du total
              </p>
            </div>
            <Button
              size="sm"
              className={`w-full mt-3 ${
                paymentState.depositPaid
                  ? 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  : 'bg-white text-black hover:bg-gray-200'
              }`}
              variant={paymentState.depositPaid ? 'outline' : 'default'}
            >
              {paymentState.depositPaid ? 'Marquer comme non payé' : 'Marquer comme payé'}
            </Button>
          </div>

          {/* Balance */}
          <div 
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              paymentState.balancePaid 
                ? 'bg-green-900/20 border-green-800' 
                : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
            } ${!paymentState.depositPaid ? 'opacity-50 pointer-events-none' : ''}`}
            onClick={handleBalanceToggle}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                {paymentState.balancePaid ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <Clock className="w-5 h-5 text-gray-500" />
                )}
                <span className={`font-medium ${
                  paymentState.balancePaid ? 'text-green-400' : 'text-gray-400'
                }`}>
                  Solde réglé
                </span>
              </div>
              <Badge className={
                paymentState.balancePaid 
                  ? 'bg-green-900/50 text-green-400 border-green-800' 
                  : 'bg-gray-800 text-gray-500 border-gray-700'
              }>
                {paymentState.balancePaid ? 'Payé' : 'En attente'}
              </Badge>
            </div>
            <div className="mt-3">
              <div className="text-2xl font-bold text-white">{balanceAmount} €</div>
              <p className="text-xs text-gray-500 mt-1">
                {100 - depositPercentage}% du total
              </p>
            </div>
            <Button
              size="sm"
              className={`w-full mt-3 ${
                paymentState.balancePaid
                  ? 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  : 'bg-white text-black hover:bg-gray-200'
              }`}
              variant={paymentState.balancePaid ? 'outline' : 'default'}
              disabled={!paymentState.depositPaid}
            >
              {paymentState.balancePaid ? 'Marquer comme non payé' : 'Marquer comme payé'}
            </Button>
          </div>
        </div>

        {/* Summary */}
        {paymentState.depositPaid && (
          <div className="p-4 rounded-xl bg-gray-800/30 border border-gray-700">
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">Reste à payer</span>
              <span className={`text-xl font-bold ${
                paymentState.balancePaid ? 'text-green-400' : 'text-white'
              }`}>
                {paymentState.balancePaid ? '0 €' : `${balanceAmount} €`}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}