import React, { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, Clock, FileText, PenTool } from 'lucide-react';

export default function ContractSignatureModal({ contract, isOpen, onClose, onSigned }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);
  const [signerType, setSignerType] = useState('client');
  const [isSigning, setIsSigning] = useState(false);

  const currentUserEmail = 'client@example.com'; // À remplacer par l'authentification réelle
  const canSign = signerType === 'client' && currentUserEmail === contract.clientId;

  const startDrawing = (e) => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    setIsDrawing(true);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.lineTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    ctx.stroke();
    setHasSignature(true);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  const handleSign = async () => {
    if (!hasSignature) return;

    setIsSigning(true);
    try {
      const canvas = canvasRef.current;
      const signatureData = canvas.toDataURL('image/png');

      const response = await fetch('/api/signContract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contractId: contract.id,
          signatureData,
          signerType
        })
      });

      const result = await response.json();
      
      if (result.success) {
        onSigned(result.status);
        onClose();
      }
    } catch (error) {
      console.error('Erreur signature:', error);
    } finally {
      setIsSigning(false);
    }
  };

  const getStatusBadge = () => {
    const statusConfig = {
      brouillon: { color: 'bg-gray-100 text-gray-700', icon: FileText, label: 'Brouillon' },
      envoye: { color: 'bg-blue-100 text-blue-700', icon: Clock, label: 'Envoyé' },
      en_attente_signature: { color: 'bg-yellow-100 text-yellow-700', icon: Clock, label: 'En attente' },
      partiellement_signe: { color: 'bg-orange-100 text-orange-700', icon: PenTool, label: 'Partiellement signé' },
      signe: { color: 'bg-green-100 text-green-700', icon: CheckCircle2, label: 'Signé' },
      refuse: { color: 'bg-red-100 text-red-700', icon: XCircle, label: 'Refusé' },
      annule: { color: 'bg-gray-100 text-gray-700', icon: XCircle, label: 'Annulé' }
    };

    const config = statusConfig[contract.status];
    const Icon = config.icon;

    return (
      <Badge className={`${config.color} border-0`}>
        <Icon className="w-3.5 h-3.5 mr-1" />
        {config.label}
      </Badge>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl">Contrat de prestation</DialogTitle>
            {getStatusBadge()}
          </div>
          <DialogDescription>
            Contrat n° AIME-{contract.eventId}-{contract.id}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informations du contrat */}
          <Card>
            <CardHeader>
              <h3 className="font-semibold text-lg">Informations de la prestation</h3>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Date</p>
                  <p className="font-medium">
                    {new Date(contract.eventDate).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Horaires</p>
                  <p className="font-medium">{contract.eventStartTime} - {contract.eventEndTime}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Lieu</p>
                  <p className="font-medium">{contract.eventLocation}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Montant total</p>
                  <p className="font-medium text-lg text-[hsl(var(--cherry))]">{contract.totalAmount} €</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Services */}
          {contract.services && contract.services.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="font-semibold text-lg">Prestations incluses</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {contract.services.map((service, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b last:border-0">
                      <div>
                        <p className="font-medium">{service.name}</p>
                        {service.description && (
                          <p className="text-sm text-muted-foreground">{service.description}</p>
                        )}
                      </div>
                      <p className="font-medium">{service.total} €</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Signatures */}
          <Card>
            <CardHeader>
              <h3 className="font-semibold text-lg">Signatures</h3>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-[hsl(var(--muted))]">
                  <div className="flex items-center gap-2 mb-2">
                    {contract.clientSignature?.signed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    ) : (
                      <Clock className="w-5 h-5 text-muted-foreground" />
                    )}
                    <p className="font-medium">Client</p>
                  </div>
                  {contract.clientSignature?.signed ? (
                    <p className="text-sm text-muted-foreground">
                      Signé le {new Date(contract.clientSignature.signedAt).toLocaleDateString('fr-FR')}
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground">En attente de signature</p>
                  )}
                </div>

                <div className="p-4 rounded-lg bg-[hsl(var(--muted))]">
                  <div className="flex items-center gap-2 mb-2">
                    {contract.djSignature?.signed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    ) : (
                      <Clock className="w-5 h-5 text-muted-foreground" />
                    )}
                    <p className="font-medium">DJ Prestataire</p>
                  </div>
                  {contract.djSignature?.signed ? (
                    <p className="text-sm text-muted-foreground">
                      Signé le {new Date(contract.djSignature.signedAt).toLocaleDateString('fr-FR')}
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground">En attente de signature</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Zone de signature */}
          {canSign && !contract.clientSignature?.signed && contract.status !== 'signe' && (
            <Card className="border-2 border-[hsl(var(--cherry))]">
              <CardHeader>
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <PenTool className="w-5 h-5 text-[hsl(var(--cherry))]" />
                  Signer le contrat
                </h3>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-[hsl(var(--border))] rounded-lg p-4 bg-white">
                  <canvas
                    ref={canvasRef}
                    width={600}
                    height={200}
                    className="w-full cursor-crosshair touch-none"
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={clearSignature}
                    disabled={!hasSignature}
                  >
                    Effacer
                  </Button>
                  <Button
                    onClick={handleSign}
                    disabled={!hasSignature || isSigning}
                    className="flex-1"
                  >
                    {isSigning ? 'Signature en cours...' : 'Signer le contrat'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Message si déjà signé */}
          {contract.clientSignature?.signed && (
            <Card className="bg-green-50 border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-medium text-green-800">Contrat signé</p>
                    <p className="text-sm text-green-700">
                      Vous avez signé ce contrat le {new Date(contract.clientSignature.signedAt).toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}