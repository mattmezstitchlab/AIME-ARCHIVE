import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardDescription } from '@/components/ui/card';
import { Eye, Music, Calendar, FileText, Mic, Lightbulb, Zap, Truck, AlertTriangle } from 'lucide-react';

export default function DJPreviewMode({ isOpen, onClose, eventType = 'Mariage', briefData = {}, timelineData = [] }) {
  const phaseIcons = {
    avant_evenement: Calendar,
    installation: Truck,
    ceremonie: Music,
    cocktail: Music,
    repas: Music,
    discours: Mic,
    ouverture_bal: Music,
    soiree: Music,
    fin: Music,
    apres_evenement: Calendar
  };

  const phaseLabels = {
    avant_evenement: 'Avant l evenement',
    installation: 'Installation',
    ceremonie: 'Ceremonie',
    cocktail: 'Cocktail',
    repas: 'Repas',
    discours: 'Discours',
    ouverture_bal: 'Ouverture de bal',
    soiree: 'Soiree',
    fin: 'Fin',
    apres_evenement: 'Apres l evenement'
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-primary" />
                Apercu DJ - {eventType}
              </DialogTitle>
              <DialogDescription>
                Voici comment le DJ verra votre brief et timeline
              </DialogDescription>
            </div>
            <Badge variant="outline" className="bg-primary/10 text-primary">
              Mode previsualisation
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 text-primary" />
                <h3 className="font-heading text-lg font-semibold">Brief Musical</h3>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Ambiance souhaitee</p>
                  <p className="text-foreground">{briefData.desiredMood || 'Non specifie'}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">A eviter</p>
                  <p className="text-foreground">{briefData.avoidMood || 'Non specifie'}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Public attendu</p>
                <p className="text-foreground">{briefData.audience || 'Non specifie'}</p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Moyenne d age</p>
                  <p className="text-foreground">{briefData.averageAge || 'Non specifie'}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Origines culturelles</p>
                  <p className="text-foreground">{briefData.culturalOrigins || 'Non specifie'}</p>
                </div>
              </div>

              {briefData.playlist && briefData.playlist.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">Playlist souhaitee</p>
                  <div className="space-y-2">
                    {briefData.playlist.map((song, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-secondary rounded-lg">
                        <div>
                          <p className="font-medium">{song.title}</p>
                          <p className="text-sm text-muted-foreground">{song.artist}</p>
                        </div>
                        <Badge variant={song.importance === 'obligatoire' ? 'default' : 'outline'}>
                          {song.importance}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {briefData.blacklist && briefData.blacklist.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">A ne pas passer</p>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {briefData.blacklist.map((item, idx) => (
                      <Badge key={idx} variant="destructive">
                        {item}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {briefData.keyMoments && briefData.keyMoments.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  <h3 className="font-heading text-lg font-semibold">Moments Cles</h3>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {briefData.keyMoments.map((moment, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className="w-16 text-right">
                        <p className="font-semibold text-primary">{moment.time}</p>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{moment.name}</p>
                        {moment.music && (
                          <p className="text-sm text-muted-foreground">♫ {moment.music}</p>
                        )}
                      </div>
                      <Badge variant={moment.status === 'valide' ? 'default' : 'outline'}>
                        {moment.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {briefData.speeches && briefData.speeches.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Mic className="w-5 h-5 text-primary" />
                  <h3 className="font-heading text-lg font-semibold">Discours</h3>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {briefData.speeches.map((speech, idx) => (
                    <div key={idx} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">{speech.who}</p>
                        <Badge variant="outline">{speech.duration || 'Non specifie'}</Badge>
                      </div>
                      <div className="flex gap-4 text-sm">
                        {speech.microphoneNeeded && (
                          <span className="flex items-center gap-1">
                            <Mic className="w-3 h-3" /> Micro necessaire
                          </span>
                        )}
                        {speech.backgroundMusic && (
                          <span className="flex items-center gap-1">
                            <Music className="w-3 h-3" /> Musique de fond
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {briefData.constraints && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-primary" />
                  <h3 className="font-heading text-lg font-semibold">Contraintes et Contacts</h3>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {briefData.constraints.soundLimit && (
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-primary" />
                    <span>Limite sonore: {briefData.constraints.soundLimit}</span>
                  </div>
                )}
                {briefData.constraints.cutoffTime && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>Coupure: {briefData.constraints.cutoffTime}</span>
                  </div>
                )}
                {briefData.constraints.djAccess && (
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-primary" />
                    <span>Acces DJ: {briefData.constraints.djAccess}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {timelineData && timelineData.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  <h3 className="font-heading text-lg font-semibold">Timeline Detaillee</h3>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {timelineData.map((moment, idx) => {
                    const Icon = phaseIcons[moment.phase] || Calendar;
                    return (
                      <div key={idx} className="flex items-start gap-3 p-3 border rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <p className="font-semibold">{moment.title}</p>
                            <p className="text-sm font-medium text-primary">{moment.time}</p>
                          </div>
                          <div className="flex flex-wrap gap-2 text-sm">
                            {moment.responsible && (
                              <Badge variant="outline">
                                {moment.responsible}
                              </Badge>
                            )}
                            {moment.phase && (
                              <Badge variant="secondary">
                                {phaseLabels[moment.phase]}
                              </Badge>
                            )}
                          </div>
                          {moment.music && (
                            <p className="text-sm text-muted-foreground mt-1">
                              ♫ {moment.music}
                            </p>
                          )}
                          {moment.equipment && (
                            <p className="text-sm text-muted-foreground">
                              Materiel: {moment.equipment}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="flex justify-end mt-6 pt-4 border-t">
          <Button onClick={onClose}>
            Fermer l apercu
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}