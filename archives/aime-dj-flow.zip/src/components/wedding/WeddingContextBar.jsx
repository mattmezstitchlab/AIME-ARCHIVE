import React from 'react';
import { CalendarDays, MapPin } from 'lucide-react';

export default function WeddingContextBar({ moment, count, dayMode, metrics, readiness, event }) {
  return <div className="sticky top-0 z-10 min-h-14 px-4 py-2 border-b border-border bg-background/95 backdrop-blur grid grid-cols-[1fr_auto_1fr] items-center gap-3">
    <div className="min-w-0"><p className="text-sm font-semibold text-foreground">Timeline adaptative</p><p className="text-[11px] text-muted-foreground">{metrics?.guests || 0} participants · {(metrics?.budget || 0).toLocaleString('fr-FR')} € · {count} moments</p></div>
    <div className="min-w-0 text-center"><p className="flex items-center justify-center gap-1.5 text-xs font-semibold text-foreground"><CalendarDays className="h-3.5 w-3.5 text-primary" />{event?.date ? new Date(`${event.date}T12:00:00`).toLocaleDateString('fr-FR', { day:'numeric', month:'long', year:'numeric' }) : '14–15 septembre 2026'}</p><p className="mt-0.5 flex items-center justify-center gap-1 text-[11px] text-primary"><MapPin className="h-3 w-3" /><span className="max-w-[220px] truncate">{event?.venue || event?.city || moment?.location || 'Lieu à définir'}</span></p></div>
    <div className="flex justify-end gap-2"><span className="rounded-full nm-inset px-3 py-1.5 text-[10px] text-muted-foreground"><strong className="text-primary">{readiness}%</strong> prêt</span>{dayMode && <span className="rounded-full bg-primary px-2 py-1 text-[10px] font-semibold text-primary-foreground">EN DIRECT</span>}</div>
  </div>;
}