import React from 'react';
import VerticalTimeline from '@/components/wedding/VerticalTimeline';
import HorizontalTimeline from '@/components/wedding/HorizontalTimeline';
import WeddingContextBar from '@/components/wedding/WeddingContextBar';
import { momentProviderMap } from '@/components/wedding/providerData';

export default function TimelineStage({ moments, selected, onSelect, view, zoom, dayMode, providerAssignments, onAddProvider, eventMetrics, readiness, event }) {
  const providerTypesFor = moment => moment.providerTypes || momentProviderMap[moment.id] || [];
  return (
    <main className="flex-1 min-w-0 min-h-0 bg-background relative overflow-auto">
      <WeddingContextBar moment={selected} count={moments.length} dayMode={dayMode} metrics={eventMetrics} readiness={readiness} event={event} />
      <div style={{ zoom: zoom / 100 }}>
        {view === 'vertical' && <VerticalTimeline moments={moments} selectedId={selected?.id} onSelect={onSelect} providerTypesFor={providerTypesFor} providerAssignments={providerAssignments} onAddProvider={onAddProvider} />}
        {view === 'horizontal' && <HorizontalTimeline moments={moments} selectedId={selected?.id} onSelect={onSelect} providerAssignments={providerAssignments} onAddProvider={onAddProvider} guestCount={eventMetrics.guests} eventType={event?.type || 'mariage'} />}
      </div>
    </main>
  );
}