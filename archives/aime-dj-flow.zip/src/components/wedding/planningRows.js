import { momentProviderMap, providerTypes } from '@/components/wedding/providerData';
import { momentPeople, weddingPeople } from '@/components/wedding/peopleData';

const guestDetails = {
  1:'Les mariés', 2:'4 proches', 3:'Équipe prestataires', 4:'Équipe technique', 5:'8 prestataires',
  6:'Les mariés · témoins en attente', 7:'Tous les invités', 8:'Tous les invités', 9:'12 groupes photo',
  10:'Tous les invités', 11:'Tous les invités', 12:'Tous les invités', 13:'Tous les invités',
  14:'Tous les invités', 15:'Tous les invités', 16:'Tous les invités', 17:'Invités encore présents',
  18:'Invités encore présents', 19:'Équipe technique', 20:'60 invités', 21:'Mariés + équipe lieu',
};
const value = (title, detail) => title ? { title, detail } : null;

export function getPlanningSections(moments, providerAssignments, guestCount, eventType = 'mariage') {
  const coreRows = [
    { id:'moment', label:'Moment', value:m=>value(m.title, m.detail) },
    { id:'phase', label:'Phase & statut', value:m=>value(m.phase, `${m.duration} · ${m.status === 'validated' ? 'Validé' : m.status === 'ready' ? 'Prêt' : 'À confirmer'}`) },
    { id:'responsible', label:'Responsable', value:m=>value(m.responsible, m.time) },
    { id:'guests', label:eventType === 'mariage' ? 'Invités' : 'Participants', value:m=>value(eventType === 'mariage' ? guestDetails[m.id] : `${guestCount} personnes`, eventType === 'mariage' && ['7','8','10','11','12','13','14','15','16'].includes(m.id) ? `${guestCount} personnes attendues` : m.phase) },
    { id:'people', label:eventType === 'mariage' ? 'Famille & témoins' : 'Participants clés', value:m=>{ if (eventType !== 'mariage') return value(m.responsible, m.phase); const items = momentPeople[m.id] || []; return value(items.map(item=>weddingPeople[item.person].name).join(' · '), items.map(item=>`${item.kind}: ${item.task}`).join(' · ')); } },
    { id:'venue', label:'Lieu', value:m=>value(providerAssignments.venue?.name || m.location || 'Lieu à définir', m.location) },
    { id:'music', label:'Musiques', value:m=>value(m.tracks?.map(track=>track.title).join(' · '), m.tracks?.map(track=>track.artist).join(' · ')) },
    { id:'coordination', label:'Coordination', value:m=>value(m.coordination, m.responsible) },
    { id:'technical', label:'Technique', value:m=>value(m.technical, m.location) },
  ];
  const activeTypes = Object.keys(providerTypes).filter(type => type !== 'venue' && moments.some(moment => (moment.providerTypes || momentProviderMap[moment.id] || []).includes(type)));
  const providerRows = activeTypes.map(type => ({
    id:`provider-${type}`, label:providerTypes[type].label, providerType:type,
    value:moment=>(moment.providerTypes || momentProviderMap[moment.id] || []).includes(type) ? value(providerAssignments[type]?.name || 'À affecter', providerAssignments[type]?.recommendation || providerTypes[type].domain) : null,
  }));
  return [{ label:'Déroulé complet', rows:coreRows }, { label:'Prestataires', rows:providerRows }];
}