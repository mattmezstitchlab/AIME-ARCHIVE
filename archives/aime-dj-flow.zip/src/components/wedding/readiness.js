export const getReadiness = moments => {
  if (!moments.length) return 0;
  const prepared = moments.filter(moment => moment.status === 'ready' || moment.status === 'validated').length;
  return Math.round((prepared / moments.length) * 100);
};