import React from 'react';
import { Link } from 'react-router-dom';
import { Menu } from 'lucide-react';

export default function WeddingWorkspaceHeader({ onOpenLeft, event }) {
  return (
    <header className="h-14 shrink-0 border-b border-border bg-background px-3 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
      <div className="flex items-center gap-2 min-w-0">
        <button onClick={onOpenLeft} aria-label="Ouvrir la navigation" className="lg:hidden h-11 w-11 grid place-items-center rounded-xl nm-btn"><Menu className="h-4 w-4" /></button>
        <Link to="/dashboard" className="font-bold tracking-tight text-foreground px-2">AIME DJ</Link>
      </div>
      <div className="max-w-[45vw] truncate text-center text-sm font-semibold text-foreground">{event?.title || 'Camille & Hugo'}</div>
      <div className="flex items-center justify-end gap-3">
        <span className="hidden md:flex items-center gap-2 text-xs text-muted-foreground"><span className="h-2 w-2 rounded-full bg-primary" />Synchronisé</span>
      </div>
    </header>
  );
}