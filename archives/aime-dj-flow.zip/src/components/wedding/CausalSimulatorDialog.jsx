import React, { useMemo, useState } from 'react';
import { Clock3, CloudRain, GitBranch, Users, Wallet, X } from 'lucide-react';
import CausalImpactList from '@/components/wedding/CausalImpactList';
import { causalScenarios, simulateDecision } from '@/components/wedding/causalEngine';

const icons = { guests:Users, ceremony:Clock3, weather:CloudRain, budget:Wallet };
export default function CausalSimulatorDialog({ metrics, onApply, onClose }) {
  const [type,setType] = useState('guests'); const [value,setValue] = useState(causalScenarios.guests.defaultValue);
  const preview = useMemo(() => simulateDecision(type,value,metrics),[type,value,metrics]);
  const choose = next => { setType(next); setValue(causalScenarios[next].defaultValue); };
  return <div className="fixed inset-0 z-50 grid place-items-center bg-black/75 p-4" onClick={onClose}><div role="dialog" aria-modal="true" aria-labelledby="causal-title" onClick={event => event.stopPropagation()} className="nm-card w-full max-w-3xl max-h-[90vh] overflow-y-auto p-5">
    <div className="flex items-start justify-between"><div><p className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-primary"><GitBranch className="h-3.5 w-3.5" />Moteur causal</p><h2 id="causal-title" className="mt-1 text-xl text-foreground">Simuler avant de décider</h2><p className="mt-1 text-sm text-muted-foreground">Aucune modification n’est appliquée avant votre confirmation.</p></div><button onClick={onClose} aria-label="Fermer" className="grid h-10 w-10 place-items-center rounded-full nm-btn"><X className="h-4 w-4" /></button></div>
    <div className="mt-5 grid gap-2 sm:grid-cols-4">{Object.entries(causalScenarios).map(([id,scenario]) => { const Icon=icons[id]; return <button key={id} onClick={() => choose(id)} className={`rounded-xl p-3 text-left ${type === id ? 'nm-inset ring-1 ring-primary' : 'nm-card'}`}><Icon className="h-4 w-4 text-primary" /><p className="mt-2 text-sm font-semibold text-foreground">{scenario.label}</p></button>; })}</div>
    <div className="mt-5 flex items-end gap-3 rounded-2xl nm-inset p-4"><label className="flex-1 text-xs text-muted-foreground">Variation<input type="number" min="1" value={value} onChange={event => setValue(event.target.value)} className="nm-input mt-2 w-full px-3 py-2 text-base" /></label><span className="pb-2 text-sm text-muted-foreground">{causalScenarios[type].unit}</span></div>
    <div className="my-5 rounded-2xl nm-inset p-4"><p className="text-[10px] uppercase tracking-widest text-muted-foreground">Décision → impacts directs → cascade</p><p className="mt-1 text-lg font-semibold text-foreground">{preview.summary}</p></div>
    <CausalImpactList impacts={preview.impacts} />
    <div className="mt-5 flex justify-end gap-2"><button onClick={onClose} className="nm-btn rounded-full px-5 py-2.5 text-sm text-muted-foreground">Annuler</button><button onClick={() => onApply(preview)} className="nm-btn-accent rounded-full px-5 py-2.5 text-sm font-semibold">Appliquer la décision</button></div>
  </div></div>;
}