import React from 'react';
import PlanningRow from '@/components/wedding/PlanningRow';
import { getPlanningSections } from '@/components/wedding/planningRows';

export default function HorizontalTimeline({ moments, selectedId, onSelect, providerAssignments, onAddProvider, guestCount, eventType = 'mariage' }) {
  const columns = { gridTemplateColumns: `repeat(${moments.length}, minmax(180px, 1fr))` };
  const sections = getPlanningSections(moments, providerAssignments, guestCount, eventType);
  return <div className="min-w-max pb-12">
    <div className="sticky top-0 z-10 flex border-b border-border bg-background/95 backdrop-blur">
      <div className="sticky left-0 z-[3] w-36 shrink-0 border-r border-border bg-background px-4 py-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Couches</div>
      <div className="grid flex-1" style={columns}>{moments.map(moment => <button key={moment.id} onClick={() => onSelect(moment)} className={moment.id === selectedId ? 'border-r border-primary bg-primary px-3 py-3 text-left text-primary-foreground' : 'border-r border-border/60 px-3 py-3 text-left'}><span className="text-xs font-semibold tabular-nums">{moment.time}</span><span className={moment.id === selectedId ? 'mt-0.5 block text-[10px] text-primary-foreground/75' : 'mt-0.5 block text-[10px] text-muted-foreground'}>{moment.day === 0 ? 'Jour J' : 'J+1'} · {moment.duration}</span></button>)}</div>
    </div>
    {sections.map(section => <section key={section.label}><div className="sticky left-0 z-[3] w-36 border-r border-border bg-muted px-4 py-2 text-[10px] font-semibold uppercase tracking-widest text-primary">{section.label}</div>{section.rows.map(row => <PlanningRow key={row.id} row={row} moments={moments} selectedId={selectedId} onSelect={onSelect} onAddProvider={onAddProvider} columns={columns} />)}</section>)}
  </div>;
}