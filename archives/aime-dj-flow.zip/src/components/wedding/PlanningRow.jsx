import React from 'react';
import { Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PlanningRow({ row, moments, selectedId, onSelect, onAddProvider, columns }) {
  const openCell = moment => {
    const cell = row.value(moment);
    onSelect(moment);
    if (row.providerType && !cell?.title?.includes('À affecter') && !cell?.detail?.startsWith('Aligné')) return;
    if (row.providerType) onAddProvider(row.providerType);
  };
  return <div className="flex min-h-[88px] border-b border-border/70">
    <div className="sticky left-0 z-[2] w-36 shrink-0 border-r border-border bg-background px-4 py-4 text-xs font-semibold text-foreground">{row.label}</div>
    <div className="grid flex-1" style={columns}>{moments.map(moment => { const cell = row.value(moment); return <div key={moment.id} className={cn('border-r border-border/60 p-1.5 transition-colors', selectedId === moment.id && 'bg-primary/15')}>{cell && <button onClick={() => openCell(moment)} className={cn('h-full w-full rounded-xl p-2.5 text-left transition-colors', selectedId === moment.id ? 'bg-primary text-primary-foreground' : 'hover:bg-muted')}><span className="flex items-start gap-1.5"><strong className="line-clamp-2 flex-1 text-xs leading-snug">{cell.title}</strong>{row.providerType && cell.title === 'À affecter' && <Plus className="h-3.5 w-3.5 shrink-0" />}</span>{cell.detail && <span className={cn('mt-1.5 line-clamp-3 block text-[10px] leading-relaxed', selectedId === moment.id ? 'text-primary-foreground/75' : 'text-muted-foreground')}>{cell.detail}</span>}</button>}</div>; })}</div>
  </div>;
}