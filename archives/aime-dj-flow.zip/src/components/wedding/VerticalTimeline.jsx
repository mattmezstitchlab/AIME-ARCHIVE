import React from 'react';
import { Check, Clock3, GitBranch, MapPin, Radio, Users, Wrench } from 'lucide-react';
import { cn } from '@/lib/utils';
import MusicTrackCard from '@/components/wedding/MusicTrackCard';
import ProviderSlots from '@/components/wedding/ProviderSlots';
import MomentPeople from '@/components/wedding/MomentPeople';

export default function VerticalTimeline({ moments, selectedId, onSelect, providerTypesFor, providerAssignments, onAddProvider }) {
  return <div className="max-w-4xl mx-auto px-3 sm:px-8 py-10">
    {moments.map((moment, index) => { const selected = selectedId === moment.id; const newDay = index === 0 || moments[index - 1].day !== moment.day; return <React.Fragment key={moment.id}>
      {newDay && <div className="sticky top-12 z-[5] my-5 flex items-center gap-3 bg-background/90 py-2 backdrop-blur"><span className="h-px flex-1 bg-border" /><span className="rounded-full nm-inset px-4 py-1.5 text-xs font-semibold text-primary">{moment.day === 0 ? 'JOUR DE L’ÉVÉNEMENT' : 'SUITE DE L’ÉVÉNEMENT'}</span><span className="h-px flex-1 bg-border" /></div>}
      <article className="relative flex gap-3 sm:gap-5 min-h-[126px] group">
        <div className="w-14 sm:w-20 pt-5 text-right"><p className="text-base font-semibold tabular-nums text-foreground">{moment.time}</p><p className="text-[10px] text-muted-foreground mt-0.5">{moment.duration}</p></div>
        <div className="relative flex flex-col items-center"><span className={cn('mt-5 h-7 w-7 rounded-full border grid place-items-center z-[1]', moment.status === 'validated' ? 'bg-primary border-primary text-primary-foreground' : 'bg-background border-border text-muted-foreground')}>{moment.status === 'validated' ? <Check className="h-3.5 w-3.5" /> : <Clock3 className="h-3.5 w-3.5" />}</span>{index < moments.length - 1 && <span className="w-px flex-1 bg-border" />}</div>
        <div role="button" tabIndex={0} onClick={() => onSelect(moment)} onKeyDown={event => (event.key === 'Enter' || event.key === ' ') && onSelect(moment)} className={cn('flex-1 min-w-0 mb-4 p-4 rounded-2xl text-left transition-colors focus-visible:ring-2 focus-visible:ring-ring', moment.causalImpact ? 'nm-card ring-1 ring-primary/60' : selected ? 'nm-inset ring-1 ring-primary/40' : 'nm-card group-hover:bg-muted')}>
          <div className="flex items-start justify-between gap-3"><div className="min-w-0 flex-1"><p className="font-semibold text-foreground">{moment.title}</p><p className="text-sm text-muted-foreground mt-1">{moment.detail}</p><span className="mt-2 inline-block text-[11px] rounded-full px-2 py-1 bg-muted text-muted-foreground">{moment.phase}</span></div><MomentPeople momentId={moment.id} expanded={selected} /></div>
          {moment.causalImpact && <div className="mt-3 flex items-center gap-1.5 rounded-lg bg-primary/10 px-2.5 py-2 text-xs text-primary"><GitBranch className="h-3.5 w-3.5" />{moment.causalImpact}</div>}
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground"><span className="flex items-center gap-1"><MapPin className="h-3 w-3 text-primary" />{moment.location}</span><span className="flex items-center gap-1"><Users className="h-3 w-3 text-primary" />{moment.responsible}</span></div>
          {selected && <div className="mt-3 grid gap-2 sm:grid-cols-2"><div className="rounded-xl bg-background/40 p-3"><p className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground"><Radio className="h-3 w-3" />Coordination</p><p className="mt-1 text-xs text-foreground">{moment.coordination}</p></div><div className="rounded-xl bg-background/40 p-3"><p className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground"><Wrench className="h-3 w-3" />Technique</p><p className="mt-1 text-xs text-foreground">{moment.technical}</p></div></div>}
          <ProviderSlots types={providerTypesFor(moment)} assignments={providerAssignments} onAdd={onAddProvider} compact={!selected} />
          {moment.tracks?.length > 0 && <div className="mt-3 grid gap-2 lg:grid-cols-2">{moment.tracks.map(track => <MusicTrackCard key={track.title} track={track} compact={!selected} />)}</div>}
        </div>
      </article>
    </React.Fragment>; })}
  </div>;
}