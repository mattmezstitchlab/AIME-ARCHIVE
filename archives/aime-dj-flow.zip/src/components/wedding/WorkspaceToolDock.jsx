import React from 'react';
import { Columns3, GitBranch, List, Minus, Plus, Radio } from 'lucide-react';
import { cn } from '@/lib/utils';

const views = [{ id: 'vertical', label: 'Chronologie', icon: List }, { id: 'causal', label: 'Causalité', icon: GitBranch, causal:true }, { id: 'horizontal', label: 'Planning', icon: Columns3 }];

export default function WorkspaceToolDock({ view, onView, onCausal, onAdd, zoom, onZoom, dayMode, onDayMode }) {
  return <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 max-w-[calc(100%-24px)] overflow-x-auto rounded-2xl bg-background p-1.5 flex items-center gap-1 shadow-2xl border border-border" role="toolbar" aria-label="Outils de la Timeline">
    {views.map(item => <button key={item.id} onClick={() => item.causal ? onCausal() : onView(item.id)} aria-label={item.label} title={item.label} className={cn('h-10 w-10 shrink-0 rounded-xl grid place-items-center transition-colors', view === item.id ? 'nm-inset text-primary' : item.causal ? 'text-primary hover:bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted')}><item.icon className="h-4 w-4" /></button>)}
    <span className="h-6 w-px bg-border mx-1 shrink-0" />
    <button onClick={() => onZoom(-10)} aria-label="Réduire le zoom" className="hidden sm:grid h-10 w-10 shrink-0 rounded-xl place-items-center text-muted-foreground hover:bg-muted"><Minus className="h-4 w-4" /></button>
    <span className="hidden sm:block w-12 text-center text-xs tabular-nums text-muted-foreground">{zoom} %</span>
    <button onClick={() => onZoom(10)} aria-label="Augmenter le zoom" className="hidden sm:grid h-10 w-10 shrink-0 rounded-xl place-items-center text-muted-foreground hover:bg-muted"><Plus className="h-4 w-4" /></button>
    <span className="h-6 w-px bg-border mx-1 shrink-0" />
    <button onClick={onAdd} aria-label="Ajouter un moment" className="h-10 w-10 shrink-0 rounded-xl nm-btn-accent grid place-items-center"><Plus className="h-4 w-4" /></button>
    <button onClick={onDayMode} aria-label="Activer le mode Jour J" className={cn('h-10 px-3 shrink-0 rounded-xl flex items-center gap-2 text-xs font-medium', dayMode ? 'bg-primary text-primary-foreground' : 'nm-btn text-muted-foreground')}><Radio className="h-4 w-4" /><span className="hidden md:inline">Jour J</span></button>
  </div>;
}