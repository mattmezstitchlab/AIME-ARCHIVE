import React from 'react';
import { BellRing, MessageSquareText } from 'lucide-react';
import { momentPeople, weddingPeople } from '@/components/wedding/peopleData';

export default function MomentPeople({ momentId, expanded }) {
  const assignments = momentPeople[momentId] || [];
  if (!assignments.length) return null;
  return <div className="shrink-0 text-right">
    <div className="flex justify-end -space-x-2">{assignments.map(item => { const person = weddingPeople[item.person]; return <img key={`${item.person}-${item.kind}`} src={person.photo} alt={person.name} title={`${person.name} · ${person.role} · ${item.kind} : ${item.task}`} className="h-9 w-9 rounded-full border-2 border-background object-cover shadow-md" />; })}</div>
    {expanded && <div className="mt-2 max-w-[250px] space-y-1.5">{assignments.map(item => { const person = weddingPeople[item.person]; const Icon = item.kind === 'Discours' ? MessageSquareText : BellRing; return <div key={`${item.person}-${item.task}`} className="flex items-start justify-end gap-2 text-left"><Icon className="mt-0.5 h-3 w-3 shrink-0 text-primary" /><p className="text-[11px] leading-snug text-muted-foreground"><strong className="text-foreground">{person.name}</strong> · {person.role}<br />{item.kind} : {item.task}</p></div>; })}</div>}
  </div>;
}