import React from 'react';
import { Check, Plus, Sparkles } from 'lucide-react';
import { providerTypes } from '@/components/wedding/providerData';

export default function ProviderSlots({ types = [], assignments, onAdd, compact = false }) {
  if (!types.length) return null;
  return <div className="mt-3 flex flex-wrap gap-1.5" aria-label="Prestataires associés">
    {types.map(typeId => { const provider = assignments[typeId]; const type = providerTypes[typeId]; const StatusIcon = provider?.suggested ? Sparkles : Check; return provider ? <button key={typeId} onClick={event => { event.stopPropagation(); onAdd(typeId); }} className="flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-[11px] text-primary" title={provider.suggested ? `${type.label} recommandé selon le brief` : `${type.label} affecté à tous les moments associés`}><StatusIcon className="h-3 w-3" />{compact ? provider.name : `${provider.suggested ? 'Recommandé' : type.label} · ${provider.name}`}</button> : <button key={typeId} onClick={event => { event.stopPropagation(); onAdd(typeId); }} className="flex items-center gap-1 rounded-full border border-dashed border-border px-2.5 py-1 text-[11px] text-muted-foreground hover:border-primary hover:text-primary"><Plus className="h-3 w-3" />{type.label}</button>; })}
  </div>;
}