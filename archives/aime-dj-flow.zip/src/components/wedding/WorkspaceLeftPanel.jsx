import React from 'react';
import { AlertCircle, CheckCircle2, ListFilter, Music2, Wrench, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getReadiness } from '@/components/wedding/readiness';
import WorkspaceInspector from '@/components/wedding/WorkspaceInspector';

const filters = [
  { id:'all', label:'Tous les moments', icon:ListFilter, count:m=>m.length },
  { id:'music', label:'Avec musique', icon:Music2, count:m=>m.filter(x=>x.tracks?.length).length },
  { id:'technical', label:'Technique', icon:Wrench, count:m=>m.filter(x=>x.phase === 'Technique' || x.phase === 'Production' || x.providerTypes?.includes('sound_light') || x.providerTypes?.includes('production')).length },
  { id:'attention', label:'À confirmer', icon:AlertCircle, count:m=>m.filter(x=>x.status === 'attention').length },
];

export default function WorkspaceLeftPanel({ active, onChange, onClose, moments = [], moment, messages, onSend, event }) {
  const prepared = moments.filter(moment => moment.status === 'ready' || moment.status === 'validated').length;
  const progress = getReadiness(moments);
  return <aside className="h-full w-[360px] max-w-[90vw] overflow-y-auto bg-background border-r border-border flex flex-col shrink-0">
    <div className="h-12 px-4 flex items-center justify-between border-b border-border"><span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Couches de lecture</span>{onClose && <button onClick={onClose} aria-label="Fermer" className="h-9 w-9 grid place-items-center rounded-lg hover:bg-muted"><X className="h-4 w-4" /></button>}</div>
    <div className="p-3 space-y-1">{filters.map(item => <button key={item.id} onClick={() => onChange(item.id)} className={cn('w-full min-h-11 px-3 flex items-center gap-3 rounded-xl text-sm text-left transition-colors', active === item.id ? 'nm-inset text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-muted')}><item.icon className="h-4 w-4" /><span className="flex-1">{item.label}</span><span className="text-xs tabular-nums opacity-70">{item.count(moments)}</span></button>)}</div>
    <div className="border-t border-border p-4"><div className="flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Préparation</p><p className="mt-1 text-sm text-foreground">Conducteur global</p></div><span className="text-xl font-bold text-primary">{progress}%</span></div><div className="mt-3 h-2 rounded-full nm-inset overflow-hidden"><div className="h-full rounded-full bg-primary" style={{ width: `${progress}%` }} /></div><p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground"><CheckCircle2 className="h-3.5 w-3.5 text-primary" />{prepared} moments prêts sur {moments.length}</p></div>
    <div className="border-t border-border"><WorkspaceInspector embedded moment={moment} messages={messages} onSend={onSend} event={event} /></div>
  </aside>;
}