export const causalScenarios = {
  guests:{ label:'Nombre d’invités', unit:'invités', defaultValue:10 },
  ceremony:{ label:'Retard de cérémonie', unit:'minutes', defaultValue:20 },
  weather:{ label:'Météo & Plan B', unit:'% de pluie', defaultValue:70 },
  budget:{ label:'Réduction du budget', unit:'%', defaultValue:20 },
};

const impact = (id, role, title, detail, level, momentIds) => ({ id, role, title, detail, level, momentIds });
export function simulateDecision(type, value, metrics) {
  const amount = Math.max(1, Number(value) || 1);
  if (type === 'guests') return { type, value:amount, summary:`${metrics.guests} → ${metrics.guests + amount} invités`, nextMetrics:{ ...metrics, guests:metrics.guests + amount, budget:metrics.budget + amount * 175 }, impacts:[
    impact('catering','Traiteur','Quantités et service à recalculer',`Surcoût estimé entre ${(amount*135).toLocaleString('fr-FR')} € et ${(amount*215).toLocaleString('fr-FR')} €.`, 'critical',[10,13,20]),
    impact('venue','Lieu','Capacité à revérifier','Assises, circulation, cuisine et sécurité doivent absorber le nouveau volume.', 'warning',[3,7,13]),
    impact('seating','Coordination','Plan de table à reprendre','Mobilier, régimes alimentaires et répartition des tables sont affectés.', 'warning',[13]),
    impact('hospitality','Hospitalité','Transport et hébergement à ajuster','Les besoins logistiques augmentent pour les invités supplémentaires.', 'info',[18,20,21]),
  ]};
  if (type === 'ceremony') return { type, value:amount, summary:`Cérémonie prolongée de ${amount} minutes`, nextMetrics:{ ...metrics, ceremonyDelay:(metrics.ceremonyDelay || 0) + amount }, impacts:[
    impact('cocktail','Coordination','Cocktail décalé',`Le départ vers le cocktail glisse de ${amount} minutes.`, 'critical',[9,10]),
    impact('photo','Photographe','Séance photo comprimée','Le temps disponible avant le cocktail et le dîner diminue.', 'warning',[9,10,11]),
    impact('catering','Traiteur','Service à resynchroniser','Les températures, équipes et heures d’envoi doivent être recalées.', 'critical',[12,13,14]),
    impact('venue','Lieu','Horaire de fin sous tension','Le retard se propage jusqu’au couvre-feu si aucune marge n’est récupérée.', 'warning',[16,17,18,19]),
  ]};
  if (type === 'weather') return { type, value:amount, summary:`Risque de pluie porté à ${amount} % · Plan B à activer`, nextMetrics:{ ...metrics, weatherRisk:amount, planB:true }, impacts:[
    impact('ceremony-plan-b','Cérémonie','Repli vers l’orangerie',`À ${amount} % de risque, le montage intérieur doit être confirmé avant l’arrivée des invités.`, 'critical',[7,8,9]),
    impact('venue-weather','Lieu','Bascule des espaces et accès','Signalétique, circulation, mobilier et accès techniques sont réorganisés en intérieur.', 'critical',[3,7,8,10]),
    impact('technical-weather','DJ & technique','Installation à déplacer et sécuriser','Les systèmes extérieurs, câbles et alimentations doivent rejoindre les zones protégées.', 'warning',[4,8,10]),
    impact('catering-weather','Traiteur','Cocktail intérieur à recomposer','Bars, buffets et flux de service doivent être redistribués sans bloquer la salle.', 'warning',[10,11,13]),
    impact('photo-weather','Photographe','Parcours photo alternatif','Le first look et les groupes basculent vers les spots couverts validés.', 'info',[6,9]),
  ]};
  const reduction = Math.round(metrics.budget * amount / 100);
  return { type, value:amount, summary:`Budget ${metrics.budget.toLocaleString('fr-FR')} € → ${(metrics.budget-reduction).toLocaleString('fr-FR')} €`, nextMetrics:{ ...metrics, budget:metrics.budget - reduction }, impacts:[
    impact('catering','Traiteur','Menu et service à arbitrer','Le premier poste de dépense représente généralement 30 à 40 % du budget.', 'critical',[10,13,20]),
    impact('venue','Lieu','Format du lieu à réévaluer','Capacité, durée de location ou espaces inclus peuvent être affectés.', 'warning',[3,7,13]),
    impact('providers','Prestataires','Périmètres de prestation à revoir','Durées, options et renforts doivent être priorisés avant renégociation.', 'warning',[8,10,12,16]),
    impact('experience','Couple','Expérience globale à prioriser','AIME recommande de protéger trois moments non négociables avant arbitrage.', 'info',[8,10,15]),
  ]};
}

const shiftTime = (time, minutes) => { const [h,m] = time.split(':').map(Number); const total = h*60+m+minutes; return `${String(Math.floor(total/60)%24).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`; };
export function applyCausalDecision(moments, decision) {
  const ceremonyIndex = moments.findIndex(moment => moment.phase === 'Cérémonie');
  return moments.map((moment,index) => { const found = decision.impacts.find(item => item.momentIds.some(id => String(id) === String(moment.id))); return { ...moment, time:decision.type === 'ceremony' && index > ceremonyIndex && moment.day === 0 ? shiftTime(moment.time, decision.value) : moment.time, causalImpact:found?.title || null, causalLevel:found?.level || null }; });
}