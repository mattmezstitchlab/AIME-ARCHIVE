import React, { useRef, useState } from 'react';
import { ExternalLink, Loader2, Music2, Pause, Play } from 'lucide-react';
import useTrackPreview from '@/hooks/useTrackPreview';

let activeAudio = null;

export default function MusicTrackCard({ track, compact = false }) {
  const audioRef = useRef(null); const [playing, setPlaying] = useState(false);
  const { previewUrl, artwork, loading } = useTrackPreview(track);
  const toggle = event => {
    event.stopPropagation();
    const audio = audioRef.current;
    if (!audio || !previewUrl) return;
    if (playing) { audio.pause(); if (activeAudio === audio) activeAudio = null; return; }
    if (activeAudio && activeAudio !== audio) activeAudio.pause();
    activeAudio = audio;
    audio.play();
  };
  return <div className="flex items-center gap-3 rounded-xl p-2.5 nm-inset min-w-0">
    <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-muted">
      {artwork ? <img src={artwork} alt={`Pochette de ${track.title}`} className="h-full w-full object-cover" /> : <Music2 className="m-3 h-6 w-6 text-primary" />}
      <button onClick={toggle} disabled={!previewUrl || loading} aria-label={playing ? 'Mettre en pause' : `Écouter un extrait de ${track.title}`} className="absolute inset-0 grid place-items-center bg-black/45 text-white opacity-0 hover:opacity-100 focus:opacity-100 disabled:opacity-60 transition-opacity"><span className="grid h-8 w-8 place-items-center rounded-full bg-primary">{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-current" />}</span></button>
    </div>
    <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{track.title}</p><p className="truncate text-xs text-muted-foreground">{track.artist}</p>{!compact && <div className="mt-1.5 flex flex-wrap gap-1.5"><span className="rounded-full bg-background px-2 py-0.5 text-[10px] text-primary">{track.source}</span><span className="rounded-full bg-background px-2 py-0.5 text-[10px] text-muted-foreground">{track.genre}</span></div>}</div>
    {!compact && <div className="flex gap-1"><a href={track.spotifyUrl} target="_blank" rel="noreferrer" onClick={event => event.stopPropagation()} aria-label={`Ouvrir ${track.title} sur Spotify`} className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted text-muted-foreground hover:text-[#1DB954]"><Music2 className="h-3.5 w-3.5" /></a><a href={track.appleUrl} target="_blank" rel="noreferrer" onClick={event => event.stopPropagation()} aria-label={`Ouvrir ${track.title} sur Apple Music`} className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted text-muted-foreground hover:text-primary"><ExternalLink className="h-3.5 w-3.5" /></a></div>}
    <audio ref={audioRef} src={previewUrl || undefined} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => { setPlaying(false); if (activeAudio === audioRef.current) activeAudio = null; }} preload="none" />
  </div>;
}