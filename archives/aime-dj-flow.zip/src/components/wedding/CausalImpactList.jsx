import React from 'react';
import { AlertTriangle, ArrowRight, Info } from 'lucide-react';
export default function CausalImpactList({ impacts }) {
  return <div className="space-y-2">{impacts.map(item => { const Icon = item.level === 'info' ? Info : AlertTriangle; return <div key={item.id} className="rounded-xl border border-border bg-background/30 p-3">
    <div className="flex items-start gap-2.5"><Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" /><div className="min-w-0"><p className="text-xs text-muted-foreground">{item.role}</p><p className="text-sm font-semibold text-foreground">{item.title}</p><p className="mt-1 text-xs leading-relaxed text-muted-foreground">{item.detail}</p><p className="mt-1.5 flex items-center gap-1 text-[10px] text-muted-foreground">Décision <ArrowRight className="h-3 w-3" /> {item.momentIds.length} moments impactés</p></div></div>
  </div>; })}</div>;
}