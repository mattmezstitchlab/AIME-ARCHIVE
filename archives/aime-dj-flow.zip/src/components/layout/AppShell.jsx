import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Home, Calendar, User, LogOut, BarChart3, Settings, Users } from 'lucide-react';

const clientNavItems = [
  { label: 'Timeline', href: '/dashboard', icon: Calendar },
];

const djNavItems = [
  { label: 'Accueil', href: '/dj-dashboard', icon: Home },
  { label: 'Profil', href: '/dj/profile', icon: User },
];

const adminNavItems = [
  { label: 'Vue d\'ensemble', href: '/admin/dashboard', icon: BarChart3 },
  { label: 'DJs', href: '/admin/djs', icon: Users },
  { label: 'Événements', href: '/admin/events', icon: Calendar },
  { label: 'Paramètres', href: '/admin/settings', icon: Settings },
];

export default function AppShell({ children, role = 'client' }) {
  const location = useLocation();
  const navItems = role === 'dj' ? djNavItems : role === 'admin' ? adminNavItems : clientNavItems;

  return (
    <div className="min-h-screen" style={{ background: '#222222' }}>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50" style={{ background: '#222222' }}>
        <div
          className="mx-4 mt-3 mb-0 px-5 py-3 rounded-2xl"
          style={{
            background: '#222222',
            boxShadow: '6px 6px 14px #161616, -6px -6px 14px #2e2e2e',
          }}
        >
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="font-bold text-base tracking-tight text-[#e0e0e0]">
              AIME DJ
            </Link>

            {/* Nav — desktop */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    to={item.href}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200",
                      isActive
                        ? "text-[#e8570a]"
                        : "text-[#888888] hover:text-[#e0e0e0]"
                    )}
                    style={isActive ? {
                      background: '#222222',
                      boxShadow: 'inset 3px 3px 7px #161616, inset -3px -3px 7px #2e2e2e',
                    } : {}}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            {/* Logout */}
            <button
              onClick={() => { window.location.href = '/'; }}
              className="flex items-center gap-2 px-3 py-2 rounded-full text-sm text-[#888888] hover:text-[#e0e0e0] transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Déco</span>
            </button>
          </div>

          {/* Mobile nav */}
          <div className="flex md:hidden overflow-x-auto gap-1 pt-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all flex-shrink-0",
                    isActive ? "text-[#e8570a]" : "text-[#888888] hover:text-[#e0e0e0]"
                  )}
                  style={isActive ? {
                    background: '#222222',
                    boxShadow: 'inset 3px 3px 7px #161616, inset -3px -3px 7px #2e2e2e',
                  } : {}}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="pt-[90px] md:pt-[80px] min-h-screen" style={{ background: '#222222' }}>
        <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}