import { useEffect, useState } from 'react';

export default function useTrackPreview(track) {
  const [media, setMedia] = useState({ previewUrl:null, artwork:null, loading:true });

  useEffect(() => {
    let active = true;
    const term = encodeURIComponent(`${track.title} ${track.artist}`);
    fetch(`https://itunes.apple.com/search?term=${term}&entity=song&limit=1&country=FR`)
      .then(response => response.json())
      .then(data => {
        if (!active) return;
        const result = data.results?.[0];
        setMedia({ previewUrl:result?.previewUrl || null, artwork:result?.artworkUrl100?.replace('100x100', '300x300') || null, loading:false });
      })
      .catch(() => active && setMedia({ previewUrl:null, artwork:null, loading:false }));
    return () => { active = false; };
  }, [track.artist, track.title]);

  return media;
}