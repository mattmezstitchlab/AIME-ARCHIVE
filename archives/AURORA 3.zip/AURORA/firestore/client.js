/* =====================================================================
   AIME / AURORA — Client de synchronisation Firebase (Firestore)
   ---------------------------------------------------------------------
   Remplace le localStorage par une synchronisation multi-utilisateurs
   temps réel. Même API que supabase/client.js pour un branchement simple.

   Chargement (avant ce fichier) :
     <script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-auth-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore-compat.js"></script>

   Puis dans index.html/app.html, remplacer la config par la vôtre :
     AimeCloud.init({ apiKey, authDomain, projectId, ... });
   ===================================================================== */

const AimeCloud = (function () {

    let db = null;
    let auth = null;
    let worldId = null;
    let unsub = null;
    let onRemoteChange = null;

    /* ---------- Initialisation ---------- */
    function init(firebaseConfig) {
        firebase.initializeApp(firebaseConfig);
        db = firebase.firestore();
        auth = firebase.auth();
        return { db, auth };
    }

    /* ---------- Authentification (magic link) ---------- */
    async function signInWithMagicLink(email) {
        const actionCodeSettings = {
            url: window.location.origin + window.location.pathname,
            handleCodeInApp: true
        };
        return auth.sendSignInLinkToEmail(email, actionCodeSettings);
    }
    async function completeMagicLink() {
        if (auth.isSignInWithEmailLink(window.location.href)) {
            let email = window.localStorage.getItem('emailForSignIn');
            if (!email) {
                email = window.prompt('Confirmez votre email pour finaliser la connexion :');
            }
            return auth.signInWithEmailLink(email, window.location.href);
        }
        return null;
    }
    async function signOut() {
        if (unsub) { unsub(); unsub = null; }
        return auth.signOut();
    }
    function user() {
        const u = auth.currentUser;
        return u ? { id: u.uid, email: u.email } : null;
    }
    function onAuth(cb) { return auth.onAuthStateChanged(u => cb(u ? { id: u.uid, email: u.email } : null)); }

    /* ---------- Mondes ---------- */
    async function listWorlds() {
        const u = user();
        if (!u) return [];
        const snap = await db.collection('worlds').where('members', 'array-contains', u.uid).get();
        return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    }
    async function createWorld(name) {
        const u = user();
        if (!u) throw new Error('Non connecté');
        const ref = await db.collection('worlds').add({
            name: name || 'Mon monde',
            ownerId: u.uid,
            members: [u.uid],
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return { id: ref.id, name: name };
    }

    /* ---------- État (versionné → time machine) ---------- */
    async function loadState(worldIdArg) {
        const snap = await db.collection('worlds').doc(worldIdArg)
            .collection('states').orderBy('updatedAt', 'desc').limit(1).get();
        if (snap.empty) return null;
        return snap.docs[0].data().state;
    }
    async function saveState(state) {
        const u = user();
        if (!u || !worldId) return;
        await db.collection('worlds').doc(worldId).collection('states').add({
            state,
            updatedBy: u.uid,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    }

    /* ---------- Temps réel ---------- */
    function startRealtime(callback) {
        stopRealtime();
        onRemoteChange = callback;
        unsub = db.collection('worlds').doc(worldId).collection('states')
            .orderBy('updatedAt', 'desc').limit(1)
            .onSnapshot(snap => {
                if (!snap.empty && onRemoteChange) {
                    onRemoteChange(snap.docs[0].data().state);
                }
            });
    }
    function stopRealtime() {
        if (unsub) { unsub(); unsub = null; }
        onRemoteChange = null;
    }

    /* ---------- Invitations ---------- */
    async function invite(worldIdArg, email) {
        const ref = await db.collection('worlds').doc(worldIdArg).collection('invitations').add({
            email, accepted: false,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return { id: ref.id, email };
    }
    async function joinWorld(worldIdArg) {
        const u = user();
        if (!u) throw new Error('Non connecté');
        await db.collection('worlds').doc(worldIdArg).update({
            members: firebase.firestore.FieldValue.arrayUnion(u.uid)
        });
    }

    return {
        init, signInWithMagicLink, completeMagicLink, signOut, user, onAuth,
        listWorlds, createWorld, loadState, saveState,
        startRealtime, stopRealtime, invite, joinWorld,
        set world(id) { worldId = id; },
        get world() { return worldId; }
    };
})();

if (typeof window !== 'undefined') window.AimeCloud = AimeCloud;
