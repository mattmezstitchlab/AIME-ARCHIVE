-- =====================================================================
-- AIME / AURORA — Schéma Supabase (multi-utilisateurs + temps réel)
-- ---------------------------------------------------------------------
-- Un « monde » = un mariage / projet = l'état AIME complet (JSON).
-- Plusieurs personnes collaborent sur le même monde, en temps réel.
-- À exécuter dans : Supabase Dashboard → SQL Editor → New query.
-- =====================================================================

-- 1. Profils (lié à auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now()
);

-- 2. Mondes (un monde = l'état AIME complet)
create table if not exists public.worlds (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null default 'Mon monde',
  created_at timestamptz not null default now()
);

-- 3. Membres (collaborateurs) — role : owner | editor | viewer
create table if not exists public.world_members (
  world_id uuid not null references public.worlds(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'editor',
  joined_at timestamptz not null default now(),
  primary key (world_id, user_id)
);

-- 4. État du monde (versionné → historique / time machine)
create table if not exists public.world_states (
  id uuid primary key default gen_random_uuid(),
  world_id uuid not null references public.worlds(id) on delete cascade,
  state jsonb not null,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);

-- 5. Invitations (partage par email)
create table if not exists public.world_invitations (
  id uuid primary key default gen_random_uuid(),
  world_id uuid not null references public.worlds(id) on delete cascade,
  email text not null,
  role text not null default 'editor',
  token text not null default gen_random_uuid()::text,
  accepted boolean not null default false,
  created_at timestamptz not null default now()
);

-- =====================================================================
-- Index
-- =====================================================================
create index if not exists idx_world_members_user on public.world_members(user_id);
create index if not exists idx_world_states_world on public.world_states(world_id, updated_at desc);
create index if not exists idx_worlds_owner on public.worlds(owner_id);

-- =====================================================================
-- Trigger : créer un profil à l'inscription
-- =====================================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =====================================================================
-- Helper : un utilisateur est-il membre (et quel rôle) d'un monde ?
-- =====================================================================
create or replace function public.world_role(p_world_id uuid)
returns text
language sql
security definer set search_path = public
as $$
  select coalesce(
    (select wm.role from public.world_members wm
      where wm.world_id = p_world_id and wm.user_id = auth.uid()),
    (select 'owner' from public.worlds w where w.id = p_world_id and w.owner_id = auth.uid()),
    null
  );
$$;

-- =====================================================================
-- RLS (Row Level Security) — n'autorise que les membres
-- =====================================================================
alter table public.profiles          enable row level security;
alter table public.worlds            enable row level security;
alter table public.world_members     enable row level security;
alter table public.world_states      enable row level security;
alter table public.world_invitations enable row level security;

-- Profils : chacun lit les profils publics, écrit le sien
create policy "profiles_select" on public.profiles for select using (true);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- Mondes : lisibles par les membres ; créés par le propriétaire
create policy "worlds_select" on public.worlds for select
  using (public.world_role(id) is not null);
create policy "worlds_insert" on public.worlds for insert
  with check (auth.uid() = owner_id);
create policy "worlds_update" on public.worlds for update
  using (public.world_role(id) in ('owner'));

-- Membres : visibles par les membres ; gérés par le owner
create policy "members_select" on public.world_members for select
  using (public.world_role(world_id) is not null);
create policy "members_insert" on public.world_members for insert
  with check (public.world_role(world_id) = 'owner');
create policy "members_delete" on public.world_members for delete
  using (public.world_role(world_id) = 'owner');

-- États : lisibles/écrits par les membres
create policy "states_select" on public.world_states for select
  using (public.world_role(world_id) is not null);
create policy "states_insert" on public.world_states for insert
  with check (public.world_role(world_id) in ('owner', 'editor'));

-- Invitations : gérées par le owner
create policy "inv_select" on public.world_invitations for select
  using (public.world_role(world_id) = 'owner');
create policy "inv_insert" on public.world_invitations for insert
  with check (public.world_role(world_id) = 'owner');

-- =====================================================================
-- Temps réel : broadcast des nouveaux états par monde
-- =====================================================================
alter publication supabase_realtime add table public.world_states;

-- =====================================================================
-- Fonctions pratiques
-- =====================================================================

-- Récupérer l'état courant d'un monde (le plus récent)
create or replace function public.latest_world_state(p_world_id uuid)
returns jsonb
language sql
security definer set search_path = public
as $$
  select ws.state from public.world_states ws
  where ws.world_id = p_world_id
  order by ws.updated_at desc limit 1;
$$;

-- Lister les mondes auxquels l'utilisateur a accès
create or replace function public.my_worlds()
returns table (id uuid, name text, role text)
language sql
security definer set search_path = public
as $$
  select w.id, w.name, coalesce(
    (select wm.role from public.world_members wm where wm.world_id = w.id and wm.user_id = auth.uid()),
    'owner'
  ) as role
  from public.worlds w
  where w.owner_id = auth.uid()
     or exists (select 1 from public.world_members wm where wm.world_id = w.id and wm.user_id = auth.uid());
$$;
