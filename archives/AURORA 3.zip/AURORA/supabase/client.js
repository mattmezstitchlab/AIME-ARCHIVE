/* =====================================================================
   AIME / AURORA — Client de synchronisation Supabase
   ---------------------------------------------------------------------
   Remplace le localStorage par une synchronisation multi-utilisateurs
   temps réel. Conçu pour être branché dans index.html avec un minimum
   de changements (voir SUPABASE.md).

   Chargement : <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
   ===================================================================== */

const AimeCloud = (function () {

    let sb = null;          // client Supabase
    let worldId = null;     // monde courant
    let channel = null;     // abonnement temps réel
    let onRemoteChange = null; // callback(appelé quand un autre membre modifie)

    /* ---------- Initialisation ---------- */
    function init(url, anonKey) {
        sb = window.supabase.createClient(url, anonKey);
        return sb;
    }

    /* ---------- Authentification ---------- */
    async function signInWithMagicLink(email) {
        return sb.auth.signInWithOtp({ email });
    }
    async function signOut() {
        await sb.auth.signOut();
        stopRealtime();
    }
    function user() {
        return sb.auth.getUser().then(r => r.data.user);
    }

    /* ---------- Mondes ---------- */
    async function listWorlds() {
        const { data, error } = await sb.rpc('my_worlds');
        if (error) throw error;
        return data;
    }
    async function createWorld(name) {
        const u = await user();
        const { data, error } = await sb
            .from('worlds')
            .insert({ owner_id: u.id, name })
            .select()
            .single();
        if (error) throw error;
        // le propriétaire est membre
        await sb.from('world_members').insert({ world_id: data.id, user_id: u.id, role: 'owner' });
        return data;
    }

    /* ---------- État ---------- */
    async function loadState(worldIdArg) {
        const { data, error } = await sb.rpc('latest_world_state', { p_world_id: worldIdArg });
        if (error) throw error;
        return data; // jsonb (null si aucun état encore)
    }
    async function saveState(state) {
        const u = await user();
        const { error } = await sb
            .from('world_states')
            .insert({ world_id: worldId, state, updated_by: u.id });
        if (error) throw error;
    }

    /* ---------- Temps réel ---------- */
    function startRealtime(callback) {
        stopRealtime();
        onRemoteChange = callback;
        channel = sb
            .channel('world-' + worldId)
            .on('postgres_changes',
                { event: 'INSERT', schema: 'public', table: 'world_states', filter: 'world_id=eq.' + worldId },
                (payload) => {
                    // ignore nos propres envois (comparaison simple par horodatage)
                    if (onRemoteChange && payload.new && payload.new.state) {
                        onRemoteChange(payload.new.state);
                    }
                })
            .subscribe();
    }
    function stopRealtime() {
        if (channel) { sb.removeChannel(channel); channel = null; }
        onRemoteChange = null;
    }

    /* ---------- Invitations ---------- */
    async function invite(worldIdArg, email, role) {
        const { data, error } = await sb
            .from('world_invitations')
            .insert({ world_id: worldIdArg, email, role })
            .select()
            .single();
        if (error) throw error;
        return data;
    }

    return {
        init, signInWithMagicLink, signOut, user,
        listWorlds, createWorld, loadState, saveState,
        startRealtime, stopRealtime, invite,
        set world(id) { worldId = id; },
        get world() { return worldId; }
    };
})();

// Expose globalement pour un usage direct dans index.html
if (typeof window !== 'undefined') window.AimeCloud = AimeCloud;
