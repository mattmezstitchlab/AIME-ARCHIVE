import { projectId, publicAnonKey } from '/utils/supabase/info';
import { getToken } from './adminApi';

export const PIPELINE_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-1d8f84c4/admin/pipeline`;
export const CLIENT_BASE   = `https://${projectId}.supabase.co/functions/v1/make-server-1d8f84c4/client`;

// ── Types ─────────────────────────────────────────────────────────────────────

export type PipelineStage =
  | 'quoted' | 'accepted' | 'contract' | 'signed' | 'payment' | 'confirmed' | 'cancelled';

export type PipelineDossier = {
  id: string;
  stage: PipelineStage;
  quoteId: string;
  contractId?: string;
  paymentId?: string;
  clientName: string;
  clientEmail: string;
  clientToken: string;
  createdBy: 'admin' | 'cerise';
  createdAt: string;
  updatedAt: string;
  quote?: PipelineQuote; // enriched in list view
};

export type PipelineQuote = {
  id: string;
  dossierId: string;
  version: number;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  eventDate: string;
  eventVenue: string;
  service: string;
  duration: number;
  amount: number;
  deposit: number;
  depositPercent: number;
  notes?: string;
  status: 'sent' | 'accepted' | 'refused' | 'expired';
  acceptedAt?: string;
  createdAt: string;
  updatedAt: string;
};

export type ContractSignature = {
  signedAt: string;
  ip?: string;
  name: string;
};

export type PipelineContract = {
  id: string;
  dossierId: string;
  quoteId: string;
  version: string;
  client: { name: string; email: string; phone?: string };
  prestataire: { name: string; email: string };
  service: string;
  eventDate: string;
  eventVenue: string;
  duration: number;
  amount: number;
  deposit: number;
  depositPercent: number;
  conditions: string[];
  status: 'sent' | 'client_signed' | 'fully_signed';
  signatures: { client?: ContractSignature; vendor?: ContractSignature };
  sentAt: string;
  createdAt: string;
  updatedAt: string;
};

export type PipelinePayment = {
  id: string;
  dossierId: string;
  contractId: string;
  amountEur: number;
  currency: 'eur';
  status: 'pending' | 'checkout_created' | 'paid' | 'failed';
  stripeCheckoutSessionId?: string;
  checkoutUrl?: string;
  paidAt?: string;
  createdAt: string;
  updatedAt: string;
};

export type PipelineLog = {
  id: string;
  dossierId: string;
  actor: 'cerise' | 'admin' | 'client' | 'stripe' | 'system';
  action: string;
  detail?: string;
  auto: boolean;
  timestamp: string;
};

export type FullDossier = {
  dossier: PipelineDossier;
  quote:    PipelineQuote | null;
  contract: PipelineContract | null;
  payment:  PipelinePayment | null;
  logs:     PipelineLog[];
};

// ── Fetch helpers ─────────────────────────────────────────────────────────────

const authHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${getToken()}`,
});

const pubHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${publicAnonKey}`,
});

// ── Admin API ─────────────────────────────────────────────────────────────────

export const pipelineList = async (): Promise<PipelineDossier[]> => {
  const res  = await fetch(`${PIPELINE_BASE}/dossiers`, { headers: authHeaders() });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data.dossiers;
};

export const pipelineGet = async (id: string): Promise<FullDossier> => {
  const res  = await fetch(`${PIPELINE_BASE}/dossier/${id}`, { headers: authHeaders() });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const pipelineCreate = async (form: {
  clientName: string; clientEmail: string; clientPhone?: string;
  eventDate: string; eventVenue: string; service: string;
  duration: number; amount: number; deposit?: number; notes?: string;
  createdBy?: 'admin' | 'cerise';
}): Promise<{ dossier: PipelineDossier; quote: PipelineQuote; clientToken: string }> => {
  const res  = await fetch(`${PIPELINE_BASE}/dossier`, {
    method: 'POST', headers: authHeaders(), body: JSON.stringify(form),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const pipelineAcceptQuote = async (quoteId: string): Promise<FullDossier> => {
  const res  = await fetch(`${PIPELINE_BASE}/quote/${quoteId}/accept`, {
    method: 'POST', headers: authHeaders(), body: '{}',
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const pipelineRefuseQuote = async (quoteId: string): Promise<void> => {
  const res = await fetch(`${PIPELINE_BASE}/quote/${quoteId}/refuse`, {
    method: 'POST', headers: authHeaders(), body: '{}',
  });
  if (!res.ok) { const d = await res.json(); throw new Error(d.error); }
};

export const pipelineSign = async (
  contractId: string, party: 'client' | 'vendor', name?: string,
): Promise<FullDossier> => {
  const res  = await fetch(`${PIPELINE_BASE}/contract/${contractId}/sign`, {
    method: 'POST', headers: authHeaders(), body: JSON.stringify({ party, name }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const pipelineConfirmPayment = async (paymentId: string): Promise<FullDossier> => {
  const res  = await fetch(`${PIPELINE_BASE}/payment/${paymentId}/confirm`, {
    method: 'POST', headers: authHeaders(), body: '{}',
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const pipelineDelete = async (dossierId: string): Promise<void> => {
  const res = await fetch(`${PIPELINE_BASE}/dossier/${dossierId}`, {
    method: 'DELETE', headers: authHeaders(),
  });
  if (!res.ok) { const d = await res.json(); throw new Error(d.error); }
};

// ── Client Portal API ─────────────────────────────────────────────────────────

export const clientPortalGet = async (token: string) => {
  const res  = await fetch(`${CLIENT_BASE}/portal/${token}`, { headers: pubHeaders() });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const clientPortalAccept = async (token: string) => {
  const res  = await fetch(`${CLIENT_BASE}/portal/${token}/accept`, {
    method: 'POST', headers: pubHeaders(), body: '{}',
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

export const clientPortalSign = async (token: string, name: string) => {
  const res  = await fetch(`${CLIENT_BASE}/portal/${token}/sign`, {
    method: 'POST', headers: pubHeaders(), body: JSON.stringify({ name }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error);
  return data;
};

// ── Helpers ───────────────────────────────────────────────────────────────────

export const STAGE_CONFIG: Record<PipelineStage, { label: string; color: string; step: number }> = {
  quoted:    { label: 'Devis envoyé',   color: 'bg-blue-100 text-blue-700',    step: 1 },
  accepted:  { label: 'Accepté',        color: 'bg-violet-100 text-violet-700', step: 2 },
  contract:  { label: 'Contrat',        color: 'bg-amber-100 text-amber-700',   step: 3 },
  signed:    { label: 'Signé ×2',       color: 'bg-teal-100 text-teal-700',     step: 4 },
  payment:   { label: 'Paiement',       color: 'bg-indigo-100 text-indigo-700', step: 5 },
  confirmed: { label: '✓ Confirmé',     color: 'bg-green-100 text-green-700',   step: 6 },
  cancelled: { label: 'Annulé',         color: 'bg-red-100 text-red-600',       step: 0 },
};

export const ACTOR_CONFIG = {
  cerise: { label: 'Cerise IA', color: 'bg-violet-100 text-violet-700', emoji: '✦' },
  admin:  { label: 'Admin',     color: 'bg-gray-100 text-gray-600',     emoji: '◎' },
  client: { label: 'Client',    color: 'bg-blue-100 text-blue-700',     emoji: '◉' },
  stripe: { label: 'Stripe',    color: 'bg-teal-100 text-teal-700',     emoji: '◈' },
  system: { label: 'Système',   color: 'bg-amber-100 text-amber-700',   emoji: '⚡' },
};

export const fmtEur = (n: number) =>
  new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n);

export const fmtDate = (s?: string) =>
  s ? new Date(s).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

export const fmtTs = (s: string) =>
  new Date(s).toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

export const clientPortalUrl = (token: string) =>
  `${window.location.origin}/client/${token}`;
