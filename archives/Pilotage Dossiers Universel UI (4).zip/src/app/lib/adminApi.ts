import { projectId, publicAnonKey } from '/utils/supabase/info';

export const ADMIN_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-1d8f84c4/admin`;

export const TOKEN_KEY = 'aime_admin_token';

export const getToken = () => localStorage.getItem(TOKEN_KEY) ?? '';

export const adminFetch = (path: string, options?: RequestInit) =>
  fetch(`${ADMIN_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getToken()}`,
      ...(options?.headers ?? {}),
    },
  });

// Shorthand helpers
export const adminGet  = (path: string) => adminFetch(path);
export const adminPost = (path: string, body: unknown) =>
  adminFetch(path, { method: 'POST', body: JSON.stringify(body) });
export const adminPut  = (path: string, body: unknown) =>
  adminFetch(path, { method: 'PUT',  body: JSON.stringify(body) });
export const adminDel  = (path: string) =>
  adminFetch(path, { method: 'DELETE' });

// ── Types shared across admin pages ──────────────────────────────────────────

export type AdminQuote = {
  id: string; clientName: string; clientEmail: string; clientPhone?: string;
  eventDate: string; eventVenue: string; service: string;
  duration: number; amount: number; deposit: number;
  status: 'draft' | 'sent' | 'accepted' | 'refused';
  notes?: string; contractId?: string; createdAt: string; updatedAt: string;
};

export type AdminContract = {
  id: string; quoteId: string; clientName: string; clientEmail: string;
  eventDate: string; eventVenue: string; service: string;
  amount: number; deposit: number;
  clientSignedAt?: string; vendorSignedAt?: string; depositPaidAt?: string;
  status: 'draft' | 'sent' | 'client_signed' | 'fully_signed' | 'deposit_paid' | 'confirmed';
  notes?: string; createdAt: string; updatedAt: string;
};

export type AdminProfile = {
  name: string; tagline: string; bio: string;
  phone?: string; email?: string; website?: string;
  services: { id: string; title: string; description: string; price: number }[];
  tarifs:   { id: string; label: string; price: number; details: string }[];
  gallery:  { id: string; type: 'image' | 'video' | 'audio'; url: string; caption?: string }[];
  published: boolean;
};

export type SiteContent = {
  heroTitle: string; heroSubtitle: string; heroCta: string;
  videoUrl: string; hymneUrl: string;
  taglines: string[];
  philosophie: string; footerTagline: string;
};

export type CeriseConfig = {
  systemPrompt: string; temperature: number;
  rules: string[];
  examples: { user: string; assistant: string }[];
};

// ── Status labels & colors ────────────────────────────────────────────────────

export const QUOTE_STATUS = {
  draft:    { label: 'Brouillon', color: 'bg-gray-100 text-gray-600' },
  sent:     { label: 'Envoyé',    color: 'bg-blue-100 text-blue-700' },
  accepted: { label: 'Accepté',  color: 'bg-green-100 text-green-700' },
  refused:  { label: 'Refusé',   color: 'bg-red-100 text-red-600' },
} as const;

export const CONTRACT_STATUS = {
  draft:         { label: 'Brouillon',    color: 'bg-gray-100 text-gray-600' },
  sent:          { label: 'Envoyé',       color: 'bg-blue-100 text-blue-700' },
  client_signed: { label: 'Signé client', color: 'bg-yellow-100 text-yellow-700' },
  fully_signed:  { label: 'Signé ×2',    color: 'bg-purple-100 text-purple-700' },
  deposit_paid:  { label: 'Acompte OK',  color: 'bg-teal-100 text-teal-700' },
  confirmed:     { label: 'Confirmé',    color: 'bg-green-100 text-green-700' },
} as const;

export const fmtEur = (n: number) =>
  new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n);

export const fmtDate = (s: string) =>
  s ? new Date(s).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
