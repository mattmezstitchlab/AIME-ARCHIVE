import { createBrowserRouter } from 'react-router';
import WeddingOS from './pages/WeddingOS';
import ClientPortal from './pages/ClientPortal';

// Admin pages
import AdminLogin     from './pages/admin/AdminLogin';
import AdminRoot      from './pages/admin/AdminRoot';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminProfile   from './pages/admin/AdminProfile';
import AdminQuotes    from './pages/admin/AdminQuotes';
import AdminPipeline  from './pages/admin/AdminPipeline';
import AdminContent   from './pages/admin/AdminContent';
import AdminCerise    from './pages/admin/AdminCerise';

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F9F8F6] text-black">
      <div className="text-center">
        <p className="text-8xl font-bold text-gray-100 mb-4">404</p>
        <h1 className="text-2xl font-bold mb-2">Page introuvable</h1>
        <a href="/" className="text-gray-500 underline hover:text-black transition-colors">
          Retour à l'accueil
        </a>
      </div>
    </div>
  );
}

export const router = createBrowserRouter([
  // ── Site principal ─────────────────────────────────────────────────────────
  { path: '/', Component: WeddingOS },

  // ── Portail client (public) ────────────────────────────────────────────────
  { path: '/client/:token', Component: ClientPortal },

  // ── Admin ──────────────────────────────────────────────────────────────────
  {
    path: '/admin',
    children: [
      { path: 'login', Component: AdminLogin },
      {
        Component: AdminRoot,
        children: [
          { index: true,       Component: AdminDashboard },
          { path: 'profile',   Component: AdminProfile   },
          { path: 'quotes',    Component: AdminQuotes    },
          { path: 'pipeline',  Component: AdminPipeline  },
          { path: 'content',   Component: AdminContent   },
          { path: 'cerise',    Component: AdminCerise    },
        ],
      },
    ],
  },

  // ── 404 ────────────────────────────────────────────────────────────────────
  { path: '*', Component: NotFound },
]);