import {
  useEffect,
  useRef,
  useState,
  type ComponentType,
  type KeyboardEvent,
} from 'react';
import {
  MessageCircle,
  X,
  Send,
  Star,
  MapPin,
  Sparkles,
  Camera,
  Music,
  Utensils,
  Flower2,
  Building2,
  Heart,
  Mic2,
  Shirt,
  Scissors,
  Cake,
  Car,
  Palette,
  Loader2,
  Bookmark,
  Eye,
  PlusCircle,
  WalletCards,
  CheckCircle2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { ChatMessage } from './WeddingEngine';
import { AimeLogoIcon } from '../AimeLogoIcon';

type ProviderCategory =
  | 'venue'
  | 'planner'
  | 'photo'
  | 'catering'
  | 'music'
  | 'dj'
  | 'flowers'
  | 'dress'
  | 'beauty'
  | 'decor'
  | 'cake'
  | 'transport';

export type CeriseProviderSuggestion = {
  id: string;
  name: string;
  category: ProviderCategory;
  location: string;
  description: string;
  priceFrom: string;
  rating: number;
  tags?: string[];
  available?: boolean;
  image: string;
};

export type ProviderAction =
  | 'view'
  | 'remember'
  | 'interested'
  | 'no_budget'
  | 'add_to_timeline';

export type CeriseTimelinePayload = {
  source: 'cerise_provider_card';
  action: ProviderAction;
  providerId: string;
  title: string;
  time: string;
  category: string;
  vendor: string;
  location: string;
  description: string;
  rawPriceFrom: string;
  estimatedBudget?: number;
  rating: number;
  available: boolean;
  tags: string[];
  status: 'pending';
  timelineCommand: string;
};

interface CeriseChatProps {
  messages: ChatMessage[];
  onSend: (text: string) => void;
  disabled?: boolean;

  providerSuggestions?: CeriseProviderSuggestion[];
  providerLoading?: boolean;
  hasTimeline?: boolean;

  /**
   * Nouveau :
   * Le 3e argument contient toutes les infos prêtes à être injectées dans WeddingTimeline.
   */
  onProviderAction?: (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => void;

  /**
   * Optionnel :
   * Permet de calculer les budgets "par invité".
   */
  guestCount?: number;
}

const SUGGESTIONS = [
  "Qu'est-ce qui manque encore à mon organisation ?",
  'Ajoute un DJ pour la soirée',
  'Quel est mon budget estimé ?',
  'Mes préparatifs sont à quelle heure ?',
  'Décale le dîner à 20h30',
  'Je cherche un saxophoniste pour le cocktail',
  'Trouve-moi un photographe naturel à Lille',
];

const CATEGORY_ICONS: Record<
  ProviderCategory,
  ComponentType<{ className?: string }>
> = {
  venue: Building2,
  planner: Heart,
  photo: Camera,
  catering: Utensils,
  music: Music,
  dj: Mic2,
  flowers: Flower2,
  dress: Shirt,
  beauty: Scissors,
  decor: Palette,
  cake: Cake,
  transport: Car,
};

const CATEGORY_LABELS: Record<ProviderCategory, string> = {
  venue: 'Lieu',
  planner: 'Wedding planner',
  photo: 'Photographe',
  catering: 'Traiteur',
  music: 'Musicien',
  dj: 'DJ',
  flowers: 'Fleuriste',
  dress: 'Tenue',
  beauty: 'Beauté',
  decor: 'Décoration',
  cake: 'Pâtisserie',
  transport: 'Transport',
};

function timelineCategoryForProvider(category: ProviderCategory) {
  switch (category) {
    case 'photo':
      return 'photo';
    case 'catering':
    case 'cake':
      return 'catering';
    case 'music':
    case 'dj':
      return 'music';
    case 'transport':
      return 'transport';
    case 'venue':
    case 'flowers':
    case 'decor':
      return 'reception';
    case 'dress':
    case 'beauty':
      return 'preparation';
    case 'planner':
    default:
      return 'other';
  }
}

function suggestedTimeForProvider(category: ProviderCategory) {
  switch (category) {
    case 'beauty':
    case 'dress':
      return '10:00';
    case 'flowers':
    case 'decor':
      return '11:00';
    case 'photo':
      return '14:00';
    case 'venue':
      return '15:00';
    case 'music':
      return '16:30';
    case 'dj':
      return '22:00';
    case 'catering':
    case 'cake':
      return '19:30';
    case 'transport':
      return '13:30';
    case 'planner':
    default:
      return '18:00';
  }
}

function parseBudget(priceFrom: string, guestCount = 80): number | undefined {
  const value = parseInt(priceFrom.replace(/\D/g, ''), 10);

  if (!Number.isFinite(value)) return undefined;

  const lower = priceFrom.toLowerCase();
  const isPerGuest =
    lower.includes('invité') ||
    lower.includes('invite') ||
    lower.includes('personne') ||
    lower.includes('part') ||
    lower.includes('/ invité') ||
    lower.includes('/ personne');

  if (isPerGuest) return value * guestCount;

  return value;
}

function buildTimelineCommand(
  provider: CeriseProviderSuggestion,
  payload: CeriseTimelinePayload
) {
  return [
    `Ajoute ce prestataire à ma timeline : ${provider.name}.`,
    `Catégorie : ${CATEGORY_LABELS[provider.category]}.`,
    `Horaire suggéré : ${payload.time}.`,
    `Lieu : ${provider.location}.`,
    `Budget estimé : ${
      payload.estimatedBudget ? `${payload.estimatedBudget} €` : provider.priceFrom
    }.`,
    `Prix affiché : ${provider.priceFrom}.`,
    `Description : ${provider.description}.`,
    provider.tags?.length ? `Tags : ${provider.tags.join(', ')}.` : '',
    `Statut : à confirmer.`,
  ]
    .filter(Boolean)
    .join(' ');
}

function buildTimelinePayload(
  action: ProviderAction,
  provider: CeriseProviderSuggestion,
  guestCount = 80
): CeriseTimelinePayload {
  const estimatedBudget = parseBudget(provider.priceFrom, guestCount);
  const time = suggestedTimeForProvider(provider.category);
  const category = timelineCategoryForProvider(provider.category);
  const tags = provider.tags ?? [];

  const payload: CeriseTimelinePayload = {
    source: 'cerise_provider_card',
    action,
    providerId: provider.id,
    title: provider.name,
    time,
    category,
    vendor: provider.name,
    location: provider.location,
    description: [
      provider.description,
      `Lieu : ${provider.location}`,
      `Prix : ${provider.priceFrom}`,
      tags.length ? `Tags : ${tags.join(', ')}` : '',
      `Note : ${provider.rating.toFixed(1)}/5`,
      provider.available === false ? 'Disponibilité : à vérifier' : 'Disponibilité : à confirmer',
    ]
      .filter(Boolean)
      .join(' · '),
    rawPriceFrom: provider.priceFrom,
    estimatedBudget,
    rating: provider.rating,
    available: provider.available ?? true,
    tags,
    status: 'pending',
    timelineCommand: '',
  };

  payload.timelineCommand = buildTimelineCommand(provider, payload);

  return payload;
}

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-3 py-2.5">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-gray-400"
          animate={{ y: [0, -4, 0] }}
          transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.12 }}
        />
      ))}
    </div>
  );
}

function ProviderLoadingCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl bg-gray-50 border border-gray-100 p-3"
    >
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        Cerise cherche les bonnes cartes…
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-20 rounded-xl bg-gradient-to-br from-gray-100 to-gray-200 animate-pulse"
          />
        ))}
      </div>
    </motion.div>
  );
}

function ProviderSuggestionCard({
  provider,
  hasTimeline,
  guestCount,
  onAction,
}: {
  provider: CeriseProviderSuggestion;
  hasTimeline: boolean;
  guestCount: number;
  onAction?: (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => void;
}) {
  const Icon = CATEGORY_ICONS[provider.category] ?? Sparkles;
  const [feedback, setFeedback] = useState('');

  const runAction = (action: ProviderAction) => {
    const payload = buildTimelinePayload(action, provider, guestCount);

    onAction?.(action, provider, payload);

    if (action === 'add_to_timeline') {
      setFeedback('Ajouté à la timeline');
    }

    if (action === 'remember') {
      setFeedback('Gardé en mémoire');
    }

    if (action === 'interested') {
      setFeedback('Piste marquée intéressante');
    }

    if (action === 'no_budget') {
      setFeedback('Budget refusé');
    }

    if (action !== 'view') {
      window.setTimeout(() => setFeedback(''), 1800);
    }
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.28 }}
      className="w-[235px] flex-shrink-0 rounded-2xl overflow-hidden bg-white border border-gray-200 shadow-sm"
    >
      <div className="relative h-28 overflow-hidden bg-black">
        <img
          src={provider.image}
          alt={provider.name}
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-black/5" />

        <div className="absolute top-2.5 left-2.5 w-8 h-8 rounded-xl bg-white/18 backdrop-blur-md border border-white/20 flex items-center justify-center text-white">
          <Icon className="w-3.5 h-3.5" />
        </div>

        <div className="absolute top-2.5 right-2.5 flex items-center gap-1 text-[10px] text-white bg-black/28 backdrop-blur-md px-2 py-1 rounded-full">
          <Star className="w-3 h-3 fill-current" />
          {provider.rating.toFixed(1)}
        </div>

        <div className="absolute left-3 right-3 bottom-3">
          <p className="text-[9px] uppercase tracking-[0.18em] text-white/55 mb-1">
            {CATEGORY_LABELS[provider.category]}
          </p>

          <h3 className="text-white text-sm font-semibold leading-tight truncate">
            {provider.name}
          </h3>

          <div className="flex items-center gap-1 text-white/70 text-[10px] mt-1">
            <MapPin className="w-3 h-3 flex-shrink-0" />
            <span className="truncate">{provider.location}</span>
          </div>
        </div>
      </div>

      <div className="p-3">
        <p className="text-xs text-gray-600 leading-relaxed h-[48px] overflow-hidden">
          {provider.description}
        </p>

        <div className="mt-3 flex items-end justify-between gap-2">
          <div>
            <p className="text-[8px] text-gray-400 uppercase tracking-[0.18em]">
              À partir de
            </p>
            <p className="text-sm font-bold text-black">{provider.priceFrom}</p>
          </div>

          <span className="text-[9px] bg-gray-100 text-gray-500 px-2 py-1 rounded-full">
            {provider.available ? 'Disponible' : 'À vérifier'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-1.5 mt-3">
          <button
            type="button"
            onClick={() => runAction('interested')}
            className="px-2 py-2 rounded-xl bg-black text-white text-[10px] font-semibold hover:bg-gray-800 transition-colors"
          >
            Intéressé
          </button>

          <button
            type="button"
            onClick={() => runAction('view')}
            className="px-2 py-2 rounded-xl bg-gray-100 text-black text-[10px] font-semibold hover:bg-gray-200 transition-colors flex items-center justify-center gap-1"
          >
            <Eye className="w-3 h-3" />
            Voir
          </button>

          <button
            type="button"
            onClick={() => runAction('remember')}
            className="px-2 py-2 rounded-xl bg-gray-100 text-gray-600 text-[10px] font-semibold hover:bg-gray-200 transition-colors flex items-center justify-center gap-1"
          >
            <Bookmark className="w-3 h-3" />
            Garder
          </button>

          <button
            type="button"
            onClick={() => runAction('no_budget')}
            className="px-2 py-2 rounded-xl bg-gray-100 text-gray-600 text-[10px] font-semibold hover:bg-gray-200 transition-colors"
          >
            Pas budget
          </button>
        </div>

        {hasTimeline && (
          <button
            type="button"
            onClick={() => runAction('add_to_timeline')}
            className="mt-1.5 w-full px-2 py-2 rounded-xl bg-black text-white text-[10px] font-semibold hover:bg-gray-800 transition-colors flex items-center justify-center gap-1"
          >
            <PlusCircle className="w-3 h-3" />
            Ajouter à la timeline
          </button>
        )}

        <AnimatePresence>
          {feedback && (
            <motion.div
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              className="mt-2 flex items-center justify-center gap-1.5 text-[10px] text-gray-500"
            >
              <CheckCircle2 className="w-3 h-3" />
              {feedback}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.article>
  );
}

function ProviderSuggestionsStrip({
  providers,
  providerLoading,
  hasTimeline,
  guestCount,
  onProviderAction,
}: {
  providers: CeriseProviderSuggestion[];
  providerLoading?: boolean;
  hasTimeline?: boolean;
  guestCount: number;
  onProviderAction?: (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => void;
}) {
  if (providerLoading) {
    return <ProviderLoadingCard />;
  }

  if (!providers.length) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-gray-100 bg-gray-50/70 p-3"
    >
      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <WalletCards className="w-3.5 h-3.5 text-gray-400" />
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-gray-400">
            Cartes trouvées
          </p>
        </div>

        <span className="text-[10px] text-gray-400">
          {providers.length} piste{providers.length > 1 ? 's' : ''}
        </span>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-1">
        {providers.map((provider) => (
          <ProviderSuggestionCard
            key={provider.id}
            provider={provider}
            hasTimeline={!!hasTimeline}
            guestCount={guestCount}
            onAction={onProviderAction}
          />
        ))}
      </div>
    </motion.div>
  );
}

export function CeriseChat({
  messages,
  onSend,
  disabled,
  providerSuggestions = [],
  providerLoading = false,
  hasTimeline = false,
  onProviderAction,
  guestCount = 80,
}: CeriseChatProps) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const ceriseMessagesCount = messages.filter(
    (m) => m.role === 'cerise' && !m.typing
  ).length;

  useEffect(() => {
    if (open) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [open, messages, providerSuggestions, providerLoading]);

  const handleSend = () => {
    const text = input.trim();

    if (!text || disabled) return;

    setInput('');
    onSend(text);
  };

  const handleKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestion = (suggestion: string) => {
    if (disabled) return;
    onSend(suggestion);
  };

  const handleProviderAction = (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => {
    onProviderAction?.(action, provider, timelinePayload);

    /**
     * Sécurité :
     * Si le parent n’a pas encore branché onProviderAction,
     * Cerise envoie une commande texte structurée au moteur existant.
     */
    if (!onProviderAction && timelinePayload && action === 'add_to_timeline') {
      onSend(timelinePayload.timelineCommand);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.96 }}
            transition={{ duration: 0.25, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="w-[92vw] sm:w-[380px] md:w-[420px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden"
            style={{ maxHeight: '620px' }}
          >
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-gray-100 bg-black">
              <div className="flex items-center gap-2.5">
                <AimeLogoIcon size={16} color="white" />

                <div>
                  <p className="text-xs font-bold text-white leading-none">
                    Cerise
                  </p>

                  <p className="text-[9px] text-white/50 mt-0.5">
                    Assistante IA · AIME® Wedding
                  </p>
                </div>
              </div>

              <button
                onClick={() => setOpen(false)}
                className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                aria-label="Fermer Cerise"
              >
                <X className="w-3.5 h-3.5 text-white/70" />
              </button>
            </div>

            <div
              className="flex-1 overflow-y-auto p-4 space-y-3"
              style={{ minHeight: 0 }}
            >
              {messages.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-xs text-gray-500 leading-relaxed mb-1">
                    Parlez-moi librement de votre mariage.
                  </p>

                  <p className="text-[10px] text-gray-400 mb-4">
                    Je peux modifier votre planning, répondre à vos questions,
                    trouver des prestataires et détecter ce qui manque.
                  </p>

                  <div className="space-y-1.5">
                    {SUGGESTIONS.map((suggestion) => (
                      <button
                        key={suggestion}
                        onClick={() => handleSuggestion(suggestion)}
                        disabled={disabled}
                        className="block w-full text-left text-xs text-gray-500 hover:text-black hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors border border-gray-100 hover:border-gray-300 disabled:opacity-40"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    msg.role === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  {msg.typing ? (
                    <div className="bg-gray-100 rounded-2xl rounded-tl-sm">
                      <TypingDots />
                    </div>
                  ) : (
                    <>
                      <div
                        className={`max-w-[88%] rounded-2xl text-xs leading-relaxed px-3.5 py-2.5 ${
                          msg.role === 'user'
                            ? 'bg-black text-white rounded-tr-sm'
                            : 'bg-gray-100 text-gray-800 rounded-tl-sm'
                        }`}
                      >
                        {msg.text}
                      </div>

                      {msg.role === 'cerise' && msg.suggestion && (
                        <button
                          onClick={() => handleSuggestion(msg.suggestion!)}
                          disabled={disabled}
                          className="mt-1.5 flex items-center gap-1.5 text-[10px] font-semibold text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 bg-white hover:bg-gray-50 px-3 py-1.5 rounded-full transition-all disabled:opacity-40"
                        >
                          <span className="text-gray-400">↳</span>
                          {msg.suggestion}
                        </button>
                      )}
                    </>
                  )}
                </div>
              ))}

              {(providerLoading || providerSuggestions.length > 0) && (
                <ProviderSuggestionsStrip
                  providers={providerSuggestions}
                  providerLoading={providerLoading}
                  hasTimeline={hasTimeline}
                  guestCount={guestCount}
                  onProviderAction={handleProviderAction}
                />
              )}

              <div ref={bottomRef} />
            </div>

            <div className="px-3 py-3 border-t border-gray-100 flex gap-2">
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKey}
                placeholder="Tapez votre demande…"
                disabled={disabled}
                className="flex-1 text-sm px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-400 transition-colors placeholder:text-gray-400 disabled:opacity-50"
              />

              <button
                onClick={handleSend}
                disabled={!input.trim() || disabled}
                className="w-9 h-9 bg-black text-white rounded-xl flex items-center justify-center hover:bg-gray-800 disabled:opacity-30 transition-all active:scale-95 flex-shrink-0"
                aria-label="Envoyer"
              >
                {disabled ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Send className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen((v) => !v)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={`relative w-14 h-14 rounded-2xl shadow-xl flex items-center justify-center transition-all ${
          open ? 'bg-gray-800' : 'bg-black'
        }`}
        aria-label={open ? 'Fermer Cerise' : 'Ouvrir Cerise'}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div
              key="x"
              initial={{ opacity: 0, rotate: -90 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0 }}
            >
              <X className="w-5 h-5 text-white" />
            </motion.div>
          ) : (
            <motion.div
              key="chat"
              initial={{ opacity: 0, rotate: 90 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0 }}
            >
              <MessageCircle className="w-5 h-5 text-white" />
            </motion.div>
          )}
        </AnimatePresence>

        {!open && ceriseMessagesCount > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-white border-2 border-black rounded-full flex items-center justify-center">
            <span className="text-[7px] font-bold text-black">
              {Math.min(ceriseMessagesCount, 9)}
            </span>
          </span>
        )}
      </motion.button>
    </div>
  );
}