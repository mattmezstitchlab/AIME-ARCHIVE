import { NavLink, Outlet, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import {
  LayoutDashboard, Music2, FileText, Palette,
  Bot, LogOut, ChevronRight, ExternalLink, Zap,
} from 'lucide-react';
import { adminFetch, TOKEN_KEY } from '../../lib/adminApi';
import { AimeLogoIcon } from '../AimeLogoIcon';

const NAV = [
  { to: '/admin',          icon: LayoutDashboard, label: 'Dashboard',        end: true  },
  { to: '/admin/profile',  icon: Music2,           label: 'Prestations',      end: false },
  { to: '/admin/pipeline', icon: Zap,              label: 'Pipeline',         end: false },
  { to: '/admin/quotes',   icon: FileText,         label: 'Devis (legacy)',   end: false },
  { to: '/admin/content',  icon: Palette,          label: 'Contenu site',     end: false },
  { to: '/admin/cerise',   icon: Bot,              label: 'Cerise IA',        end: false },
];

export function AdminLayout() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try { await adminFetch('/logout', { method: 'POST' }); } catch {}
    localStorage.removeItem(TOKEN_KEY);
    navigate('/admin/login', { replace: true });
  };

  return (
    <div className="flex h-screen bg-[#F9F8F6] overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── Sidebar ─────────────���──────────────────────────────────────── */}
      <aside className="w-60 flex-shrink-0 bg-[#0A0A0A] flex flex-col">

        {/* Logo */}
        <div className="px-5 py-5 border-b border-white/8">
          <div className="flex items-center gap-2.5">
            <AimeLogoIcon size={14} color="white" />
            <div>
              <span
                style={{ fontFamily: "'Helvetica Neue', Helvetica, sans-serif", fontWeight: 700, fontSize: '13px' }}
                className="text-white tracking-tight"
              >
                AIME<sup style={{ fontSize: '0.5em', fontWeight: 700 }}>®</sup>
              </span>
              <span className="text-white/35 text-xs ml-1.5">Admin</span>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV.map(({ to, icon: Icon, label, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all group ${
                  isActive
                    ? 'bg-white text-black font-semibold'
                    : 'text-white/50 hover:text-white hover:bg-white/8'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-black' : 'text-white/40 group-hover:text-white/70'}`} />
                  <span className="flex-1">{label}</span>
                  {isActive && <ChevronRight className="w-3.5 h-3.5 text-black/40" />}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Bottom */}
        <div className="px-3 pb-4 space-y-1 border-t border-white/8 pt-3">
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/40 hover:text-white hover:bg-white/8 transition-all"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Voir le site</span>
          </a>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/40 hover:text-red-400 hover:bg-red-500/10 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span>Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* ── Main content ────────────────────────────────────────────────── */}
      <main className="flex-1 overflow-y-auto">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="min-h-full"
        >
          <Outlet />
        </motion.div>
      </main>
    </div>
  );
}