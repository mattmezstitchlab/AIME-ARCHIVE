import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Eye, EyeOff, LogIn, AlertCircle } from 'lucide-react';
import { ADMIN_BASE, TOKEN_KEY } from '../../lib/adminApi';

export default function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('admin@aime.fr');
  const [password, setPassword] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    console.log('LOGIN CLICKED');
    console.log('ADMIN_BASE:', ADMIN_BASE);

    if (!email || !password) {
      setError('Remplissez tous les champs');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const res = await fetch(`${ADMIN_BASE}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      console.log('RESPONSE STATUS:', res.status);

      const data = await res.json();
      console.log('RESPONSE DATA:', data);

      if (!res.ok) {
        setError(data.error || 'Erreur de connexion');
        setLoading(false);
        return;
      }

      localStorage.setItem(TOKEN_KEY, data.token);
      navigate('/admin', { replace: true });

    } catch (err) {
      console.error(err);
      setError('Erreur réseau — vérifiez votre connexion');
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <form onSubmit={handleSubmit} className="bg-white/5 p-6 rounded-xl w-[320px] space-y-4">
        
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="admin@aime.fr"
          className="w-full p-3 rounded bg-black border border-white/10 text-white"
        />

        <div className="relative">
          <input
            type={showPwd ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="mot de passe"
            className="w-full p-3 rounded bg-black border border-white/10 text-white"
          />
          <button
            type="button"
            onClick={() => setShowPwd(!showPwd)}
            className="absolute right-3 top-3 text-white/40"
          >
            {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>

        {error && (
          <div className="text-red-400 text-sm flex gap-2 items-center">
            <AlertCircle size={14} />
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-white text-black py-3 rounded font-semibold"
        >
          {loading ? 'Connexion…' : 'Accéder'}
        </button>
      </form>
    </div>
  );
}