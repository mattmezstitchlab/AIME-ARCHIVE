export const ADMIN_BASE =
  'https://YOUR_SUPABASE_PROJECT.supabase.co/functions/v1/admin';

export const TOKEN_KEY = 'aime_admin_token';