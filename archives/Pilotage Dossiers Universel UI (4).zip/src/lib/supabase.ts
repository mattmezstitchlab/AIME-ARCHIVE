import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// Singleton — une seule instance dans toute l'application
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey,
);
