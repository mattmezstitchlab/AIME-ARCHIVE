import React, { useCallback, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { SITE_CANVAS_PAGES, CANVAS_DEVICES } from "@/lib/siteCanvasPages";
import { useSiteEngineOverride } from "@/lib/useSiteEngineOverride";
import EngineTopBar from "@/components/engine/EngineTopBar";
import EngineBottomBar from "@/components/engine/EngineBottomBar";
import EngineLeftPanel from "@/components/engine/EngineLeftPanel";
import EngineInspector from "@/components/engine/EngineInspector";
import EngineBreadcrumb from "@/components/engine/EngineBreadcrumb";
import EngineFrame from "@/components/engine/EngineFrame";

export default function SiteEngine() {
  const { data: user, isLoading } = useQuery({ queryKey: ["currentUser"], queryFn: () => base44.auth.me() });
  const [page, setPage] = useState(SITE_CANVAS_PAGES[0]);
  const [device, setDevice] = useState("desktop");
  const [mode, setMode] = useState("edit");
  const [zoom, setZoom] = useState(0.62);
  const [reloadKey, setReloadKey] = useState(0);
  const [tree, setTree] = useState(null);
  const [overflow, setOverflow] = useState(0);
  const [selection, setSelection] = useState(null);
  const [hoverId, setHoverId] = useState(null);
  const [dirty, setDirty] = useState(false);
  const frameRef = useRef(null);
  const { saving, error, save } = useSiteEngineOverride(page.path);

  const send = useCallback((type, payload) => {
    frameRef.current?.contentWindow?.postMessage({ type, payload }, window.location.origin);
  }, []);

  const handleMessage = useCallback((message) => {
    if (message.type === "engine-tree") { setTree(message.payload.tree); setOverflow(message.payload.overflow); }
    if (message.type === "engine-select") setSelection(message.payload);
  }, []);

  const openPage = (next) => { setPage(next); setSelection(null); setTree(null); setDirty(false); };
  const selectFromLayer = (id) => send("engine-select-request", { id });
  const hoverFromLayer = (id) => { setHoverId(id); send("engine-hover-request", { id }); };
  const preview = (id, values) => { setDirty(true); send("engine-apply", { id, values }); };
  const persist = async (id, payload) => { await save(id, payload); setDirty(false); setSelection((current) => (current ? { ...current, values: payload.style, content: payload.content } : current)); };
  const fit = () => {
    const available = window.innerWidth - 700;
    setZoom(Math.min(1, Math.max(0.2, available / CANVAS_DEVICES[device].width)));
  };
  const changeZoom = (next) => setZoom(Math.min(1.5, Math.max(0.2, Number(next.toFixed(2)))));
  const changeDevice = (next) => { setDevice(next); setZoom(next === "mobile" ? 1 : next === "tablet" ? 0.8 : 0.62); setSelection(null); setTree(null); };
  const changeMode = (next) => { setMode(next); setSelection(null); };

  const breadcrumbPath = useMemo(() => selection?.path || [], [selection]);

  if (isLoading) return <div className="flex min-h-screen items-center justify-center bg-background"><span className="h-6 w-6 animate-spin rounded-full border-2 border-white/20 border-t-white" /></div>;
  if (user?.role !== "admin") return <div className="flex min-h-screen items-center justify-center bg-background px-6"><p className="text-sm text-muted-foreground">Accès réservé aux administrateurs.</p></div>;

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background text-foreground">
      <EngineTopBar pageLabel={page.label} pagePath={page.path} mode={mode} onModeChange={changeMode} saving={saving} dirty={dirty} onRefresh={() => { setReloadKey((key) => key + 1); setTree(null); setSelection(null); }} />
      <div className="flex min-h-0 flex-1">
        <EngineLeftPanel page={page} tree={tree} selectedId={selection?.id} hoverId={hoverId} loading={!tree} onOpenPage={openPage} onSelect={selectFromLayer} onHover={hoverFromLayer} />
        <div className="relative flex min-w-0 flex-1 flex-col">
          <EngineBreadcrumb pageLabel={page.label} path={breadcrumbPath} onSelect={selectFromLayer} />
          <div className="min-h-0 flex-1 overflow-auto p-8 editor-canvas-grid">
            <div className="flex justify-center">
              <EngineFrame frameRef={frameRef} page={page} device={device} mode={mode} zoom={zoom} reloadKey={reloadKey} onMessage={handleMessage} />
            </div>
          </div>
          <div className="pointer-events-none absolute inset-x-0 bottom-4 flex justify-center">
            <EngineBottomBar device={device} onDeviceChange={changeDevice} zoom={zoom} onZoomChange={changeZoom} onFit={fit} overflow={overflow} />
          </div>
        </div>
        <EngineInspector selection={selection} device={CANVAS_DEVICES[device].label} saving={saving} error={error} onPreview={preview} onSave={persist} />
      </div>
    </div>
  );
}