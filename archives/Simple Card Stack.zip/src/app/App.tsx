import React, { useState, useCallback, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast, Toaster } from 'sonner';
import { InfiniteCanvas } from './components/InfiniteCanvas';
import { Toolbar } from './components/Toolbar';
import { LotGroup } from './components/LotGroup';
import { BackgroundPanel } from './components/BackgroundPanel';
import { TexturePanel } from './components/TexturePanel';
import { TimelineView } from './components/TimelineView';
import { MiniSitePanel } from './components/MiniSitePanel';
import { MusicPlayerBar } from './components/MusicPlayerBar';
import { MiniSite } from './components/MiniSite';
import { AIAgent } from './components/AIAgent';
import { LogoMenu } from './components/LogoMenu';
import { AgentDotButton } from './components/AgentDotButton';
import type { AgentState } from './components/AgentDotButton';
import { RightNotch } from './components/RightNotch';
import { UniversalCard } from './components/UniversalCard';
import type { SetupData } from './components/UniversalCard';
import CommandPalette from './components/CommandPalette';
import MiniMap from './components/MiniMap';
import KioskMode from './components/KioskMode';
import OnboardingWizard from './components/OnboardingWizard';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { lots } from './data/lots';
import { exportToICS } from './utils/icsExport';
import type { CanvasTransform, Tool, BgSettings, TextSettings } from './types';
import type { AnimationSettings } from './components/SettingsPanel';
import { LayoutGrid, Clock, Globe, Command, X } from 'lucide-react';

const DEFAULT_ANIM: AnimationSettings = {
  springDuration: 0.35, springBounce: 0.25,
  xSpringDuration: 0.5, xSpringBounce: 0.1,
  dragElastic: 0.7, swipeConfidenceThreshold: 10000, zIndexDelay: 0.05,
};

type ViewMode = 'canvas' | 'timeline' | 'minisite';
type Snapshot = Record<string, Record<string, any>>;

const DEFAULT_SETUP: SetupData = {
  brideFirstName: '', groomFirstName: '', date: '', ceremonyTime: '',
  ceremonyVenue: '', receptionVenue: '', receptionCity: '',
  guestCount: 0, childCount: 0, diet: [], style: '',
  colorA: '#C4956A', colorB: '#A8B8C8', budget: 0,
  witnessA: '', witnessB: '',
};

function AppInner() {
  const { isDark } = useTheme();

  const [transform, setTransform] = useState<CanvasTransform>(() => {
    // Center the universal card (at canvas 200,120, 260px wide, 360px tall) on screen
    const cx = window.innerWidth / 2 - 130 - 200;
    const cy = window.innerHeight / 2 - 180 - 120;
    return { x: cx, y: cy, scale: 1 };
  });
  const [activeTool, setActiveTool] = useState<Tool>('hand');
  const [bgSettings, setBgSettings] = useState<BgSettings>({
    type: 'gradient',
    value: 'linear-gradient(135deg,#1A1A2E,#16213E,#0F3460)',
  });
  const [textSettings, setTextSettings] = useState<TextSettings>({ size: 14, color: '#ffffff' });
  const [panelOpen, setPanelOpen] = useState(false);
  const [cardSettings, setCardSettings] = useState<Snapshot>({});
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);

  // Setup data from universal card
  const [setupData, setSetupData] = useState<SetupData>(() => {
    const saved = localStorage.getItem('lma_setup');
    return saved ? { ...DEFAULT_SETUP, ...JSON.parse(saved) } : DEFAULT_SETUP;
  });
  const [setupComplete, setSetupComplete] = useState(() => !!localStorage.getItem('lma_setup_complete'));

  const coupleName = setupData.brideFirstName && setupData.groomFirstName
    ? `${setupData.brideFirstName} & ${setupData.groomFirstName}`
    : 'Sophie & Antoine';
  const weddingDate = setupData.date || '14 Septembre 2025';

  // View modes — now overlay-based, canvas always rendered
  const [viewMode, setViewMode] = useState<ViewMode>('canvas');
  const [textureOpen, setTextureOpen] = useState(false);
  const [globalTexture, setGlobalTexture] = useState('');
  const [miniSitePanelOpen, setMiniSitePanelOpen] = useState(false);
  const [selectedCards, setSelectedCards] = useState<Set<string>>(new Set());

  const [commandOpen, setCommandOpen] = useState(false);
  const [kioskOpen, setKioskOpen] = useState(false);
  const [onboardingDone, setOnboardingDone] = useState(() => !!localStorage.getItem('lma_onboarded'));
  const [checklistOpen, setChecklistOpen] = useState(false);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [totalBudget, setTotalBudget] = useState(() => Number(localStorage.getItem('lma_budget') || setupData.budget || 25000));
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [agentOpen, setAgentOpen] = useState(false);
  const [agentThinking, setAgentThinking] = useState(false);
  const [agentHasMessage, setAgentHasMessage] = useState(false);
  const [activeLotId, setActiveLotId] = useState<number | null>(null);

  const agentState: AgentState = agentOpen
    ? (agentThinking ? 'thinking' : 'open')
    : agentHasMessage
    ? 'notification'
    : 'idle';

  // Hero settings
  const [heroPhoto, setHeroPhoto] = useState('');
  const [heroVenue, setHeroVenue] = useState('');
  const handleHeroChange = useCallback((field: string, value: string) => {
    if (field === 'photo') setHeroPhoto(value);
    else if (field === 'venue') setHeroVenue(value);
  }, []);

  const history = useRef<Snapshot[]>([{}]);
  const historyIndex = useRef(0);

  const [ChecklistPanel, setChecklistPanel] = useState<React.ComponentType<any> | null>(null);
  const [BudgetDashboard, setBudgetDashboard] = useState<React.ComponentType<any> | null>(null);
  const [TemplatesPanel, setTemplatesPanel] = useState<React.ComponentType<any> | null>(null);

  useEffect(() => {
    if (checklistOpen && !ChecklistPanel)
      import('./components/ChecklistPanel').then((m) => setChecklistPanel(() => m.ChecklistPanel));
  }, [checklistOpen]);
  useEffect(() => {
    if (budgetOpen && !BudgetDashboard)
      import('./components/BudgetDashboard').then((m) => setBudgetDashboard(() => m.BudgetDashboard));
  }, [budgetOpen]);
  useEffect(() => {
    if (templatesOpen && !TemplatesPanel)
      import('./components/TemplatesPanel').then((m) => setTemplatesPanel(() => m.TemplatesPanel));
  }, [templatesOpen]);

  useEffect(() => { localStorage.setItem('lma_budget', String(totalBudget)); }, [totalBudget]);

  const pushHistory = useCallback((snap: Snapshot) => {
    const next = history.current.slice(0, historyIndex.current + 1);
    next.push(snap);
    if (next.length > 80) next.shift();
    history.current = next;
    historyIndex.current = next.length - 1;
  }, []);

  const handleCardSettingChange = useCallback(
    (cardId: string, key: string, value: unknown) => {
      setCardSettings((prev) => {
        const next = { ...prev, [cardId]: { ...(prev[cardId] || {}), [key]: value } };
        pushHistory(next);
        return next;
      });
    },
    [pushHistory]
  );

  const undo = useCallback(() => {
    if (historyIndex.current > 0) {
      historyIndex.current--;
      setCardSettings(history.current[historyIndex.current]);
      toast.success('Annulé');
    }
  }, []);

  const redo = useCallback(() => {
    if (historyIndex.current < history.current.length - 1) {
      historyIndex.current++;
      setCardSettings(history.current[historyIndex.current]);
      toast.success('Rétabli');
    }
  }, []);

  const handleTogglePlay = useCallback((cardId: string) => {
    setPlayingTrackId((prev) => (prev === cardId ? null : cardId));
  }, []);

  const handleZoomChange = useCallback((delta: number) => {
    setTransform((t) => {
      const newScale = Math.max(0.15, Math.min(3, t.scale + delta));
      const cx = window.innerWidth / 2;
      const cy = window.innerHeight / 2;
      const ratio = newScale / t.scale;
      return { x: cx - (cx - t.x) * ratio, y: cy - (cy - t.y) * ratio, scale: newScale };
    });
  }, []);

  const handleToggleCard = useCallback((id: string) => {
    setSelectedCards((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const handleToggleLot = useCallback((lotId: number) => {
    const lot = lots.find((l) => l.id === lotId);
    if (!lot) return;
    const ids = lot.cards.map((c) => c.id);
    setSelectedCards((prev) => {
      const allSelected = ids.every((id) => prev.has(id));
      const next = new Set(prev);
      if (allSelected) ids.forEach((id) => next.delete(id));
      else ids.forEach((id) => next.add(id));
      return next;
    });
  }, []);

  const handleGenerateMiniSite = useCallback(() => {
    setMiniSitePanelOpen(false);
    setViewMode('minisite');
  }, []);

  const navigateToLot = useCallback((lot: typeof lots[0]) => {
    setViewMode('canvas');
    setTransform({
      x: -lot.position.x * 0.9 + window.innerWidth / 2 - 160,
      y: -lot.position.y * 0.9 + window.innerHeight / 2 - 240,
      scale: 0.9,
    });
  }, []);

  const handleSetupComplete = useCallback((data: SetupData) => {
    setSetupData(data);
    localStorage.setItem('lma_setup', JSON.stringify(data));
    localStorage.setItem('lma_setup_complete', '1');
    setSetupComplete(true);
    if (data.budget > 0) setTotalBudget(data.budget);
    toast.success('Votre mariage est configuré ! Sélectionnez un lot dans le menu ▾');
  }, []);

  const handleAction = useCallback(
    (action: string) => {
      switch (action) {
        case 'ics': case 'export-ics': exportToICS(coupleName, weddingDate, lots, cardSettings); break;
        case 'checklist': setChecklistOpen(true); break;
        case 'budget': setBudgetOpen(true); break;
        case 'kiosk': setKioskOpen(true); break;
        case 'templates': setTemplatesOpen(true); break;
        case 'qr': case 'qr-code': toast.info('QR Code — disponible depuis le mini-site généré'); break;
      }
    },
    [coupleName, weddingDate, cardSettings]
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const meta = e.metaKey || e.ctrlKey;
      if (meta && e.key === 'k') { e.preventDefault(); setCommandOpen(true); return; }
      if (meta && e.key === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
      if (meta && e.key === '1') { e.preventDefault(); setViewMode('canvas'); return; }
      if (meta && e.key === '2') { e.preventDefault(); setViewMode('timeline'); return; }
      if (meta && e.key === '3') { e.preventDefault(); setViewMode('minisite'); return; }
      if (e.key === 'Escape') {
        if (viewMode !== 'canvas') { setViewMode('canvas'); return; }
        setCommandOpen(false); setKioskOpen(false);
        setChecklistOpen(false); setBudgetOpen(false); setTemplatesOpen(false);
        setMiniSitePanelOpen(false);
        return;
      }
      if (!meta && !e.altKey && !e.shiftKey && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        if (e.key === 'g' || e.key === 'G') setActiveTool('hand');
        if (e.key === 'v' || e.key === 'V') setActiveTool('select');
        if (e.key === '+') handleZoomChange(0.2);
        if (e.key === '-') handleZoomChange(-0.2);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [undo, redo, handleZoomChange, viewMode]);

  /* ── Theme tokens ── */
  const headerBg     = isDark ? 'rgba(10,9,20,0.97)'    : 'rgba(255,255,255,0.98)';
  const headerBorder = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.08)';
  const textPrimary  = isDark ? '#F0EEF8'                : '#0F0F12';
  const textMuted    = isDark ? 'rgba(240,238,248,0.4)'  : 'rgba(15,15,18,0.4)';
  const tabBg        = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)';
  const tabActiveBg  = isDark ? 'rgba(255,255,255,0.11)' : '#fff';
  const tabShadow    = isDark ? '0 1px 4px rgba(0,0,0,0.5)' : '0 1px 4px rgba(0,0,0,0.1)';

  /* ── Canvas always rendered ── */
  return (
    <div
      data-theme={isDark ? 'dark' : 'light'}
      style={{ width: '100vw', height: '100vh', overflow: 'hidden', fontFamily: 'Inter, sans-serif', fontSize: textSettings.size, color: textPrimary, background: 'var(--lma-bg)', transition: 'background 0.3s' }}
    >
      <Toaster position="bottom-right" theme={isDark ? 'dark' : 'light'} />

      {!onboardingDone && (
        <OnboardingWizard
          onComplete={(data) => {
            localStorage.setItem('lma_onboarded', '1');
            setOnboardingDone(true);
            toast.success('Bienvenue ! Votre espace mariage est prêt.');
          }}
          onSkip={() => { localStorage.setItem('lma_onboarded', '1'); setOnboardingDone(true); }}
        />
      )}

      {/* ── Canvas — always rendered beneath everything ── */}
      <InfiniteCanvas transform={transform} onTransformChange={setTransform} activeTool={activeTool} bgSettings={bgSettings}>
        {/* Universal card — positioned at canvas coordinate 200,120 */}
        <div style={{ position: 'absolute', left: '200px', top: '120px' }}>
          <UniversalCard
            data={setupData}
            onChange={setSetupData}
            onComplete={handleSetupComplete}
            isComplete={setupComplete}
          />
        </div>

        {/* Active lot — only one displayed at a time, chosen from logo dropdown */}
        <AnimatePresence mode="wait">
          {activeLotId != null && (() => {
            const lot = lots.find((l) => l.id === activeLotId);
            if (!lot) return null;
            return (
              <motion.div
                key={lot.id}
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ type: 'spring', damping: 26, stiffness: 220 }}
              >
                <LotGroup
                  lot={lot} cardSettings={cardSettings}
                  onCardSettingChange={handleCardSettingChange}
                  animSettings={DEFAULT_ANIM} playingTrackId={playingTrackId}
                  onTogglePlay={handleTogglePlay} globalTexture={globalTexture}
                />
              </motion.div>
            );
          })()}
        </AnimatePresence>
      </InfiniteCanvas>

      {/* ── Toolbar — always visible ── */}
      <Toolbar
        activeTool={activeTool} onToolChange={setActiveTool}
        scale={transform.scale} onZoomChange={handleZoomChange}
        onBgOpen={() => setPanelOpen((v) => !v)}
        onTextOpen={() => setPanelOpen((v) => !v)}
        onTextureOpen={() => setTextureOpen((v) => !v)}
        textureActive={textureOpen || globalTexture !== ''}
        onMiniSite={() => setMiniSitePanelOpen((v) => !v)}
        miniSiteActive={miniSitePanelOpen}
        onBudget={() => setBudgetOpen(true)}
        onChecklist={() => setChecklistOpen(true)}
        onKiosk={() => setKioskOpen(true)}
        onTemplates={() => setTemplatesOpen(true)}
      />

      <MiniMap lots={lots} transform={transform} onNavigate={(x, y) => setTransform((t) => ({ ...t, x, y }))} />

      {panelOpen && (
        <BackgroundPanel bg={bgSettings} onBgChange={setBgSettings}
          text={textSettings} onTextChange={setTextSettings}
          onClose={() => setPanelOpen(false)} />
      )}
      {textureOpen && (
        <TexturePanel current={globalTexture}
          onSelect={(id) => { setGlobalTexture(id); setTextureOpen(false); }}
          onClose={() => setTextureOpen(false)} />
      )}

      {/* ── Header ── */}
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0, height: '50px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        paddingLeft: '62px', paddingRight: '14px', gap: '10px',
        background: headerBg, backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
        borderBottom: `1px solid ${headerBorder}`, zIndex: 200,
        transition: 'background 0.3s, border-color 0.3s',
      }}>
        {/* Left: logo dropdown */}
        <LogoMenu
          lots={lots} coupleName={coupleName} weddingDate={weddingDate}
          onNavigateLot={navigateToLot} onAction={handleAction}
          cardSettings={cardSettings}
          activeLotId={activeLotId}
          onSelectLot={(id) => {
            setActiveLotId(id);
            if (id != null) setViewMode('canvas');
          }}
        />

        {/* Center: view mode tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '2px', background: tabBg, borderRadius: '9px', padding: '3px', flexShrink: 0 }}>
          {([
            { id: 'canvas',   label: 'Canevas',   icon: <LayoutGrid size={12} />, shortcut: '⌘1' },
            { id: 'timeline', label: 'Timeline',  icon: <Clock size={12} />,      shortcut: '⌘2' },
            { id: 'minisite', label: 'Mini-site', icon: <Globe size={12} />,      shortcut: '⌘3' },
          ] as const).map(({ id, label, icon, shortcut }) => (
            <button
              key={id} onClick={() => setViewMode(id)} title={shortcut}
              style={{
                display: 'flex', alignItems: 'center', gap: '5px', padding: '4px 10px',
                borderRadius: '6px', border: 'none', cursor: 'pointer',
                fontFamily: 'Inter', fontSize: '11px', whiteSpace: 'nowrap', transition: 'all 0.15s',
                background: viewMode === id ? tabActiveBg : 'transparent',
                color: viewMode === id ? textPrimary : textMuted,
                fontWeight: viewMode === id ? 600 : 400,
                boxShadow: viewMode === id ? tabShadow : 'none',
              }}
            >
              {icon}{label}
            </button>
          ))}
        </div>

        {/* Right: ⌘K + AI agent */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <HeaderBtn onClick={() => setCommandOpen(true)} title="⌘K — Commandes" isDark={isDark} textPrimary={textPrimary} textMuted={textMuted}>
            <Command size={13} />
          </HeaderBtn>
          <AgentDotButton
            onClick={() => { setAgentOpen((v) => !v); setAgentHasMessage(false); }}
            agentState={agentState}
            title="Assistant IA mariage"
          />
        </div>
      </div>

      {/* ── Timeline overlay — on top of canvas ── */}
      <AnimatePresence>
        {viewMode === 'timeline' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            style={{
              position: 'fixed', top: '50px', left: '52px', right: 0, bottom: 0,
              zIndex: 110, background: 'var(--lma-bg)', overflow: 'hidden',
            }}
          >
            <TimelineView lots={lots} cardSettings={cardSettings} coupleName={coupleName} weddingDate={weddingDate} />
            <OverlayCloseBtn onClick={() => setViewMode('canvas')} isDark={isDark} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Mini-site overlay ── */}
      <AnimatePresence>
        {viewMode === 'minisite' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            style={{
              position: 'fixed', top: '50px', left: '52px', right: 0, bottom: 0,
              zIndex: 110, overflow: 'hidden',
            }}
          >
            <MiniSite lots={lots} cardSettings={cardSettings} selectedCards={selectedCards} coupleName={coupleName} weddingDate={weddingDate} />
            <OverlayCloseBtn onClick={() => setViewMode('canvas')} isDark={isDark} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Right notch for MiniSitePanel ── */}
      <RightNotch
        isOpen={miniSitePanelOpen && viewMode === 'canvas'}
        onClick={() => setMiniSitePanelOpen((v) => !v)}
        selectedCount={selectedCards.size}
      />

      {/* ── MiniSite editor panel ── */}
      <AnimatePresence>
        {miniSitePanelOpen && viewMode === 'canvas' && (
          <MiniSitePanel
            lots={lots} selected={selectedCards}
            onToggleCard={handleToggleCard} onToggleLot={handleToggleLot}
            onGenerate={handleGenerateMiniSite} onClose={() => setMiniSitePanelOpen(false)}
            cardSettings={cardSettings}
            heroPhoto={heroPhoto}
            heroCoupleName={coupleName}
            heroDate={weddingDate}
            heroVenue={heroVenue}
            onHeroChange={handleHeroChange}
          />
        )}
      </AnimatePresence>

      {/* ── Music bar ── */}
      <MusicPlayerBar lots={lots} cardSettings={cardSettings} />

      {/* ── AI Agent — controlled by header button ── */}
      <AIAgent
        lots={lots} cardSettings={cardSettings} viewMode={viewMode}
        onNavigateLot={navigateToLot}
        externalOpen={agentOpen}
        onOpenChange={setAgentOpen}
        onThinkingChange={setAgentThinking}
        onNewMessage={() => setAgentHasMessage(true)}
      />

      {/* ── Command palette ── */}
      <CommandPalette
        open={commandOpen} onClose={() => setCommandOpen(false)}
        lots={lots} cardSettings={cardSettings}
        onViewMode={(m) => { setViewMode(m as ViewMode); setCommandOpen(false); }}
        onNavigateLot={(lot) => { navigateToLot(lot); setCommandOpen(false); }}
        onAction={(a) => { handleAction(a); setCommandOpen(false); }}
      />

      {/* ── Kiosk ── */}
      <AnimatePresence>
        {kioskOpen && (
          <KioskMode lots={lots} cardSettings={cardSettings} coupleName={coupleName} weddingDate={weddingDate} onClose={() => setKioskOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Checklist ── */}
      <AnimatePresence>
        {checklistOpen && ChecklistPanel && (
          <ChecklistPanel lots={lots} cardSettings={cardSettings} weddingDate={weddingDate} onClose={() => setChecklistOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Budget ── */}
      <AnimatePresence>
        {budgetOpen && BudgetDashboard && (
          <BudgetDashboard lots={lots} cardSettings={cardSettings}
            totalBudget={totalBudget} onTotalBudgetChange={setTotalBudget}
            onClose={() => setBudgetOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Templates ── */}
      <AnimatePresence>
        {templatesOpen && TemplatesPanel && (
          <TemplatesPanel
            onApplyTemplate={(tpl: any) => {
              setCardSettings((prev) => {
                const next = { ...prev };
                Object.entries(tpl.cardDefaults).forEach(([id, defaults]) => {
                  next[id] = { ...(next[id] || {}), ...(defaults as Record<string, any>) };
                });
                pushHistory(next);
                return next;
              });
              setTemplatesOpen(false);
              toast.success(`Template "${tpl.name}" appliqué !`);
            }}
            onClose={() => setTemplatesOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* ── Hint bar (canvas only) ── */}
      {viewMode === 'canvas' && (
        <div style={{
          position: 'fixed', bottom: '12px', left: '50%', transform: 'translateX(-50%)',
          fontFamily: 'Inter', fontSize: '10px',
          color: isDark ? 'rgba(240,238,248,0.22)' : 'rgba(15,15,18,0.32)',
          zIndex: 90, pointerEvents: 'none',
          background: isDark ? 'rgba(0,0,0,0.28)' : 'rgba(255,255,255,0.7)',
          backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
          borderRadius: '50px', padding: '5px 14px', whiteSpace: 'nowrap',
          border: `1px solid ${isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)'}`,
        }}>
          ⌘K Commandes · ⌘Z Annuler · G Pan · V Sélect · +/- Zoom · Échap Retour
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppInner />
    </ThemeProvider>
  );
}

/* ── Shared primitives ───────────────────────────────────────────────────────── */

const HeaderBtn: React.FC<{
  onClick: () => void; title: string; children: React.ReactNode;
  isDark: boolean; textPrimary: string; textMuted: string;
}> = ({ onClick, title, children, isDark, textPrimary, textMuted }) => {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} title={title}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        width: '30px', height: '30px', borderRadius: '7px', border: 'none',
        background: hov ? (isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)') : 'transparent',
        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: hov ? textPrimary : textMuted, transition: 'all 0.15s', flexShrink: 0,
      }}
    >
      {children}
    </button>
  );
};

const OverlayCloseBtn: React.FC<{ onClick: () => void; isDark: boolean }> = ({ onClick, isDark }) => (
  <button
    onClick={onClick}
    title="Retour au canevas (Échap)"
    style={{
      position: 'absolute', top: '14px', right: '14px',
      width: '32px', height: '32px', borderRadius: '8px', border: 'none',
      background: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)',
      cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: isDark ? 'rgba(240,238,248,0.6)' : 'rgba(15,15,18,0.5)',
      zIndex: 10, transition: 'all 0.15s',
    }}
    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = isDark ? 'rgba(255,255,255,0.14)' : 'rgba(0,0,0,0.1)'; }}
    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)'; }}
  >
    <X size={14} />
  </button>
);
