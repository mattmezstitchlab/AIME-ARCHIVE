import type { WeddingLot } from '../types';

const COL = 440;
const ROW = 700;
const OX = 80;
const OY = 80;
const pos = (c: number, r: number) => ({ x: OX + c * COL, y: OY + r * ROW });

export const lots: WeddingLot[] = [
  // ── ROW 0 ────────────────────────────────────────────────────────────────
  {
    id: 1,
    title: 'Programme',
    subtitle: 'Jour J',
    icon: 'Sparkles',
    accentColor: '#C4956A',
    position: pos(0, 0),
    cards: [
      { id: 'prog-1', name: 'Préparatifs Mariée', subtitle: 'La mise en beauté', icon: 'Sparkles', type: 'programme', image: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=800&q=80' },
      { id: 'prog-2', name: 'Préparatifs Marié', subtitle: 'L\'habillage', icon: 'Sparkles', type: 'programme', image: 'https://images.unsplash.com/photo-1606490208247-b65be3d94cd1?w=800&q=80' },
      { id: 'prog-3', name: 'Premier Regard', subtitle: 'Le first look', icon: 'Heart', type: 'programme', gradient: 'linear-gradient(135deg,#FFF5EE,#FFECD2)' },
      { id: 'prog-4', name: 'Cérémonie Civile', subtitle: 'À la mairie', icon: 'Scale', type: 'programme', gradient: 'linear-gradient(135deg,#E8D5F0,#D4B8E0)' },
      { id: 'prog-5', name: 'Cérémonie', subtitle: 'L\'échange des vœux', icon: 'Heart', type: 'programme', image: 'https://images.unsplash.com/photo-1576694667642-6f289dd54187?w=800&q=80' },
      { id: 'prog-6', name: 'Séance Photo', subtitle: 'Le couple seul', icon: 'Camera', type: 'programme', gradient: 'linear-gradient(135deg,#F0E8E0,#D8C0B0)' },
      { id: 'prog-7', name: 'Cocktail', subtitle: 'Le temps de la joie', icon: 'Wine', type: 'programme', image: 'https://images.unsplash.com/photo-1780432478362-96fac052084a?w=800&q=80' },
      { id: 'prog-8', name: 'Vin d\'honneur', subtitle: 'La célébration', icon: 'Wine', type: 'programme', image: 'https://images.unsplash.com/photo-1527529482837-4698179dc6ce?w=800&q=80' },
      { id: 'prog-9', name: 'Dîner de Noces', subtitle: 'Le banquet', icon: 'UtensilsCrossed', type: 'programme', image: 'https://images.unsplash.com/photo-1782038522729-47b97948ab11?w=800&q=80' },
      { id: 'prog-10', name: 'Pièce Montée', subtitle: 'Le croquembouche', icon: 'Cake', type: 'programme', gradient: 'linear-gradient(135deg,#F5E6C8,#E8C97E)' },
      { id: 'prog-11', name: 'Soirée Dansante', subtitle: 'L\'ouverture du bal', icon: 'Music2', type: 'programme', image: 'https://images.unsplash.com/photo-1624067056935-593eb6595294?w=800&q=80' },
      { id: 'prog-12', name: 'Brunch Lendemain', subtitle: 'Le jour d\'après', icon: 'Sun', type: 'programme', gradient: 'linear-gradient(135deg,#D8E8F5,#B0C8E8)' },
    ],
  },

  {
    id: 2,
    title: 'Lieu & Réception',
    subtitle: 'Prestataires',
    icon: 'Building2',
    accentColor: '#8B6F5E',
    position: pos(1, 0),
    cards: [
      { id: 'lieu-1', name: 'Château / Domaine', subtitle: 'Lieu principal', icon: 'Building2', type: 'venue', gradient: 'linear-gradient(135deg,#E8D5C4,#C8A882)' },
      { id: 'lieu-2', name: 'Salle de Réception', subtitle: 'Intérieur', icon: 'Building2', type: 'venue', gradient: 'linear-gradient(135deg,#F0E8D8,#D8C0A0)' },
      { id: 'lieu-3', name: 'Domaine Viticole', subtitle: 'Vignes & terroir', icon: 'Building2', type: 'venue', gradient: 'linear-gradient(135deg,#D4E8D0,#90B080)' },
      { id: 'lieu-4', name: 'Lieu Insolite', subtitle: 'Musée, péniche…', icon: 'MapPin', type: 'venue', gradient: 'linear-gradient(135deg,#E8D0E0,#C0A0C8)' },
      { id: 'lieu-5', name: 'Tente / Chapiteau', subtitle: 'Plein air', icon: 'Tent', type: 'venue', gradient: 'linear-gradient(135deg,#D8EEF5,#90C0D8)' },
      { id: 'lieu-6', name: 'Hébergements Invités', subtitle: 'Gîte, hôtel', icon: 'BedDouble', type: 'venue', gradient: 'linear-gradient(135deg,#F5E8E0,#E0C0A8)' },
    ],
  },

  {
    id: 3,
    title: 'Photo & Vidéo',
    subtitle: 'Prestataires',
    icon: 'Camera',
    accentColor: '#5E7A8B',
    position: pos(2, 0),
    cards: [
      { id: 'pv-1', name: 'Photographe', subtitle: 'Reportage complet', icon: 'Camera', type: 'photo-video', gradient: 'linear-gradient(135deg,#2C3E50,#4CA1AF)' },
      { id: 'pv-2', name: 'Vidéaste', subtitle: 'Film de mariage', icon: 'Video', type: 'photo-video', gradient: 'linear-gradient(135deg,#373B44,#4286f4)' },
      { id: 'pv-3', name: 'Drone', subtitle: 'Prises aériennes', icon: 'Plane', type: 'photo-video', gradient: 'linear-gradient(135deg,#0F2027,#203A43,#2C5364)' },
      { id: 'pv-4', name: 'Photo Booth 360°', subtitle: 'Animation invités', icon: 'ScanLine', type: 'photo-video', gradient: 'linear-gradient(135deg,#6A3093,#A044FF)' },
      { id: 'pv-5', name: 'Peintre Live', subtitle: 'Tableau en direct', icon: 'Palette', type: 'photo-video', gradient: 'linear-gradient(135deg,#B24592,#F15F79)' },
      { id: 'pv-6', name: 'Photo Booth Ouvert', subtitle: 'Backdrop & props', icon: 'ImagePlus', type: 'photo-video', gradient: 'linear-gradient(135deg,#4A00E0,#8E2DE2)' },
    ],
  },

  {
    id: 4,
    title: 'Beauté & Mode',
    subtitle: 'Prestataires',
    icon: 'Scissors',
    accentColor: '#C4789A',
    position: pos(3, 0),
    cards: [
      { id: 'bm-1', name: 'Coiffeuse', subtitle: 'Coiffure mariée', icon: 'Scissors', type: 'beauty', gradient: 'linear-gradient(135deg,#F0D9E8,#D8A8C0)' },
      { id: 'bm-2', name: 'Maquilleuse', subtitle: 'Maquillage mariée', icon: 'Sparkles', type: 'beauty', gradient: 'linear-gradient(135deg,#F5E0E8,#E8B8CC)' },
      { id: 'bm-3', name: 'Robe de Mariée', subtitle: 'Couturier / boutique', icon: 'Heart', type: 'beauty', gradient: 'linear-gradient(135deg,#FFF5EE,#FFECD2)' },
      { id: 'bm-4', name: 'Costume Marié', subtitle: 'Sur mesure', icon: 'Shirt', type: 'beauty', gradient: 'linear-gradient(135deg,#2C3E50,#4CA1AF)' },
      { id: 'bm-5', name: 'Bijoutier / Alliances', subtitle: 'Gravure & créations', icon: 'Gem', type: 'beauty', gradient: 'linear-gradient(135deg,#F5D878,#E8A820)' },
      { id: 'bm-6', name: 'Robes Demoiselles', subtitle: 'Cortège', icon: 'Users', type: 'beauty', gradient: 'linear-gradient(135deg,#D4B8E0,#A880C0)' },
    ],
  },

  {
    id: 5,
    title: 'Traiteur',
    subtitle: 'Gastronomie',
    icon: 'UtensilsCrossed',
    accentColor: '#7A8B5E',
    position: pos(4, 0),
    cards: [
      { id: 'tr-1', name: 'Traiteur Principal', subtitle: 'Menu complet', icon: 'UtensilsCrossed', type: 'catering', gradient: 'linear-gradient(135deg,#D4E8D0,#90B080)' },
      { id: 'tr-2', name: 'Pièce Montée', subtitle: 'Croquembouche', icon: 'Cake', type: 'catering', gradient: 'linear-gradient(135deg,#F5E6C8,#E8C97E)' },
      { id: 'tr-3', name: 'Wedding Cake', subtitle: 'Gâteau américain', icon: 'Cake', type: 'catering', gradient: 'linear-gradient(135deg,#FFF0F5,#FFD0E0)' },
      { id: 'tr-4', name: 'Barman / Mixologue', subtitle: 'Bar à cocktails', icon: 'Wine', type: 'catering', gradient: 'linear-gradient(135deg,#1A1A2E,#16213E,#0F3460)' },
      { id: 'tr-5', name: 'Food Truck Nuit', subtitle: 'Soupe à l\'oignon…', icon: 'Truck', type: 'catering', gradient: 'linear-gradient(135deg,#C33764,#1D2671)' },
      { id: 'tr-6', name: 'Sommelier / Cave', subtitle: 'Sélection des vins', icon: 'Wine', type: 'catering', gradient: 'linear-gradient(135deg,#6B2D30,#A05060)' },
    ],
  },

  // ── ROW 1 ────────────────────────────────────────────────────────────────
  {
    id: 6,
    title: 'Fleurs & Décoration',
    subtitle: 'Prestataires',
    icon: 'Flower2',
    accentColor: '#8B9A5E',
    position: pos(0, 1),
    cards: [
      { id: 'fl-1', name: 'Fleuriste', subtitle: 'Compositions florales', icon: 'Flower2', type: 'flowers', image: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=800&q=80' },
      { id: 'fl-2', name: 'Décorateur', subtitle: 'Scénographie', icon: 'Layers', type: 'flowers', gradient: 'linear-gradient(135deg,#C8D8C0,#88A878)' },
      { id: 'fl-3', name: 'Arche de Cérémonie', subtitle: 'Structure florale', icon: 'Flower2', type: 'flowers', gradient: 'linear-gradient(135deg,#E8EDD8,#C0C888)' },
      { id: 'fl-4', name: 'Papeterie', subtitle: 'Faire-part & menus', icon: 'FileText', type: 'flowers', gradient: 'linear-gradient(135deg,#F5F0E8,#E0D8C0)' },
      { id: 'fl-5', name: 'Éclairage', subtitle: 'Guirlandes & spots', icon: 'Lightbulb', type: 'flowers', gradient: 'linear-gradient(135deg,#F5E878,#E8B820)' },
      { id: 'fl-6', name: 'Calligraphe', subtitle: 'Plan de table & noms', icon: 'PenLine', type: 'flowers', gradient: 'linear-gradient(135deg,#F0ECE0,#D8D0B0)' },
    ],
  },

  {
    id: 7,
    title: 'Artistes',
    subtitle: 'Intermittents du spectacle',
    icon: 'Music',
    accentColor: '#5E6A8B',
    position: pos(1, 1),
    cards: [
      { id: 'art-1', name: 'Quatuor à Cordes', subtitle: 'Cérémonie', icon: 'Music', type: 'artist', gradient: 'linear-gradient(135deg,#232526,#414345)' },
      { id: 'art-2', name: 'Organiste', subtitle: 'Cérémonie religieuse', icon: 'Music', type: 'artist', gradient: 'linear-gradient(135deg,#2C3E50,#3498DB)' },
      { id: 'art-3', name: 'Harpiste', subtitle: 'Cérémonie & cocktail', icon: 'Music', type: 'artist', gradient: 'linear-gradient(135deg,#4A00E0,#8E2DE2)' },
      { id: 'art-4', name: 'Chanteur / Soprano', subtitle: 'Soliste cérémonie', icon: 'Mic', type: 'artist', gradient: 'linear-gradient(135deg,#B24592,#F15F79)' },
      { id: 'art-5', name: 'Chorale Gospel', subtitle: 'Cérémonie ou bal', icon: 'Users', type: 'artist', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
      { id: 'art-6', name: 'Groupe Jazz', subtitle: 'Jazz manouche cocktail', icon: 'Music2', type: 'artist', gradient: 'linear-gradient(135deg,#1A1A2E,#4A3060)' },
      { id: 'art-7', name: 'Groupe Live', subtitle: 'Pop / Rock soirée', icon: 'Zap', type: 'artist', gradient: 'linear-gradient(135deg,#C33764,#1D2671)' },
      { id: 'art-8', name: 'Danseurs', subtitle: 'Show & initiation', icon: 'Activity', type: 'artist', gradient: 'linear-gradient(135deg,#11998E,#38EF7D)' },
    ],
  },

  {
    id: 8,
    title: 'Animation & Spectacle',
    subtitle: 'Prestataires',
    icon: 'Zap',
    accentColor: '#8B5E7A',
    position: pos(2, 1),
    cards: [
      { id: 'anim-1', name: 'DJ', subtitle: 'Soirée dansante', icon: 'Disc3', type: 'animation', gradient: 'linear-gradient(135deg,#0F0C29,#302B63,#24243E)' },
      { id: 'anim-2', name: 'Magicien Close-Up', subtitle: 'Table en table', icon: 'Wand2', type: 'animation', gradient: 'linear-gradient(135deg,#232526,#414345)' },
      { id: 'anim-3', name: 'Caricaturiste', subtitle: 'Dessins en live', icon: 'PenLine', type: 'animation', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
      { id: 'anim-4', name: 'Photo Booth', subtitle: '360° ou classique', icon: 'Camera', type: 'animation', gradient: 'linear-gradient(135deg,#6A3093,#A044FF)' },
      { id: 'anim-5', name: 'Feux d\'Artifice', subtitle: 'Pyrotechnie', icon: 'Zap', type: 'animation', gradient: 'linear-gradient(135deg,#F53844,#42378F)' },
      { id: 'anim-6', name: 'Animation Enfants', subtitle: 'Atelier & jeux', icon: 'Smile', type: 'animation', gradient: 'linear-gradient(135deg,#43E97B,#38F9D7)' },
      { id: 'anim-7', name: 'Jeux Géants', subtitle: 'Pétanque, Jenga…', icon: 'Gamepad2', type: 'animation', gradient: 'linear-gradient(135deg,#56CCF2,#2F80ED)' },
      { id: 'anim-8', name: 'Casino de Mariage', subtitle: 'Tables de jeux', icon: 'Trophy', type: 'animation', gradient: 'linear-gradient(135deg,#1A1A2E,#16213E)' },
    ],
  },

  {
    id: 9,
    title: 'Musique Cérémonie',
    subtitle: 'Par moment',
    icon: 'Music2',
    accentColor: '#6A5E8B',
    position: pos(3, 1),
    cards: [
      { id: 'mc-1', name: 'Prélude', subtitle: 'Accueil des invités', icon: 'Music2', type: 'music-ceremony', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
      { id: 'mc-2', name: 'Cortège d\'Honneur', subtitle: 'Entrée du cortège', icon: 'Music2', type: 'music-ceremony', gradient: 'linear-gradient(135deg,#F093FB,#F5576C)' },
      { id: 'mc-3', name: 'Entrée de la Mariée', subtitle: 'Le grand moment', icon: 'Music2', type: 'music-ceremony', gradient: 'linear-gradient(135deg,#4FACFE,#00F2FE)' },
      { id: 'mc-4', name: 'Échange des Vœux', subtitle: 'Musique de fond', icon: 'Music2', type: 'music-ceremony', gradient: 'linear-gradient(135deg,#2C3E50,#4CA1AF)' },
      { id: 'mc-5', name: 'Sortie des Mariés', subtitle: 'L\'apothéose', icon: 'Music2', type: 'music-ceremony', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
    ],
  },

  {
    id: 10,
    title: 'Musique Soirée',
    subtitle: 'Par style',
    icon: 'Disc3',
    accentColor: '#8B5E6A',
    position: pos(4, 1),
    cards: [
      { id: 'ms-1', name: 'Jazz & Swing', subtitle: 'Cocktail & Dîner', icon: 'Disc3', type: 'music-soiree', gradient: 'linear-gradient(135deg,#2C3E50,#4CA1AF)' },
      { id: 'ms-2', name: 'Classique & Lounge', subtitle: 'Ambiance raffinée', icon: 'Disc3', type: 'music-soiree', gradient: 'linear-gradient(135deg,#E0C3FC,#8EC5FC)' },
      { id: 'ms-3', name: 'Variété Française', subtitle: 'Pour chanter ensemble', icon: 'Disc3', type: 'music-soiree', gradient: 'linear-gradient(135deg,#F5576C,#F093FB)' },
      { id: 'ms-4', name: 'Pop & Hits', subtitle: 'La piste de danse', icon: 'Disc3', type: 'music-soiree', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
      { id: 'ms-5', name: 'Électronique & Dance', subtitle: 'Montée en puissance', icon: 'Disc3', type: 'music-soiree', gradient: 'linear-gradient(135deg,#0F0C29,#302B63)' },
    ],
  },

  // ── ROW 2 ────────────────────────────────────────────────────────────────
  {
    id: 11,
    title: 'Invités',
    subtitle: 'Plan de table',
    icon: 'Users',
    accentColor: '#5E8B7A',
    position: pos(0, 2),
    cards: [
      { id: 'inv-1', name: 'Table Honneur', subtitle: 'Mariés & familles', icon: 'Crown', type: 'guest', gradient: 'linear-gradient(135deg,#C4956A,#F5D878)' },
      { id: 'inv-2', name: 'Table Famille', subtitle: 'Parents & frères', icon: 'Users', type: 'guest', gradient: 'linear-gradient(135deg,#D4B8E0,#A880C0)' },
      { id: 'inv-3', name: 'Table Amis Proches', subtitle: 'Témoins & cortège', icon: 'UserCheck', type: 'guest', gradient: 'linear-gradient(135deg,#4FACFE,#00F2FE)' },
      { id: 'inv-4', name: 'Table Collègues', subtitle: 'Professionnels', icon: 'Briefcase', type: 'guest', gradient: 'linear-gradient(135deg,#43E97B,#38F9D7)' },
      { id: 'inv-5', name: 'Table Enfants', subtitle: 'Kids corner', icon: 'Baby', type: 'guest', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
      { id: 'inv-6', name: 'Table Invités Distance', subtitle: 'Venant de loin', icon: 'MapPin', type: 'guest', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
    ],
  },

  {
    id: 12,
    title: 'Budget',
    subtitle: 'Suivi financier',
    icon: 'Euro',
    accentColor: '#6A8B5E',
    position: pos(1, 2),
    cards: [
      { id: 'bud-1', name: 'Lieu & Réception', subtitle: 'Location salle', icon: 'Building2', type: 'budget', gradient: 'linear-gradient(135deg,#D4E8D0,#90B080)' },
      { id: 'bud-2', name: 'Traiteur', subtitle: 'Repas & boissons', icon: 'UtensilsCrossed', type: 'budget', gradient: 'linear-gradient(135deg,#F5E6C8,#E8C97E)' },
      { id: 'bud-3', name: 'Photo & Vidéo', subtitle: 'Photographe + vidéaste', icon: 'Camera', type: 'budget', gradient: 'linear-gradient(135deg,#4FACFE,#00F2FE)' },
      { id: 'bud-4', name: 'Fleurs & Déco', subtitle: 'Florale & scénographie', icon: 'Flower2', type: 'budget', gradient: 'linear-gradient(135deg,#C8D8C0,#88A878)' },
      { id: 'bud-5', name: 'Musique & Animation', subtitle: 'DJ, artistes, shows', icon: 'Music', type: 'budget', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
      { id: 'bud-6', name: 'Tenues & Beauté', subtitle: 'Robe, costume, coiff.', icon: 'Scissors', type: 'budget', gradient: 'linear-gradient(135deg,#F0D9E8,#D8A8C0)' },
      { id: 'bud-7', name: 'Transport', subtitle: 'Voiture, navettes', icon: 'Car', type: 'budget', gradient: 'linear-gradient(135deg,#2C3E50,#4CA1AF)' },
      { id: 'bud-8', name: 'Divers', subtitle: 'Imprévus & cadeaux', icon: 'Gift', type: 'budget', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
    ],
  },

  {
    id: 13,
    title: 'Administratif',
    subtitle: 'Juridique & documents',
    icon: 'Scale',
    accentColor: '#5E6A8B',
    position: pos(2, 2),
    cards: [
      { id: 'adm-1', name: 'Dossier Mairie', subtitle: 'Publication des bans', icon: 'FileText', type: 'admin', gradient: 'linear-gradient(135deg,#2C3E50,#4CA1AF)' },
      { id: 'adm-2', name: 'Contrat de Mariage', subtitle: 'Régime matrimonial', icon: 'Scale', type: 'admin', gradient: 'linear-gradient(135deg,#232526,#414345)' },
      { id: 'adm-3', name: 'Assurance Mariage', subtitle: 'Annulation & RC', icon: 'ShieldCheck', type: 'admin', gradient: 'linear-gradient(135deg,#43E97B,#38F9D7)' },
      { id: 'adm-4', name: 'Changement de Nom', subtitle: 'Démarches post-mariage', icon: 'UserCog', type: 'admin', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
      { id: 'adm-5', name: 'GUSO / Contrats Artistes', subtitle: 'Intermittents', icon: 'ClipboardList', type: 'admin', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
      { id: 'adm-6', name: 'Documents Invités', subtitle: 'RSVP & convocations', icon: 'Mail', type: 'admin', gradient: 'linear-gradient(135deg,#F093FB,#F5576C)' },
    ],
  },

  {
    id: 14,
    title: 'Lune de Miel',
    subtitle: 'Voyage & post-mariage',
    icon: 'Sun',
    accentColor: '#8B7A5E',
    position: pos(3, 2),
    cards: [
      { id: 'lm-1', name: 'Destination', subtitle: 'Le voyage de noces', icon: 'MapPin', type: 'honeymoon', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
      { id: 'lm-2', name: 'Vols & Transport', subtitle: 'Billets d\'avion', icon: 'Plane', type: 'honeymoon', gradient: 'linear-gradient(135deg,#4FACFE,#00F2FE)' },
      { id: 'lm-3', name: 'Hébergement', subtitle: 'Hôtel & villa', icon: 'BedDouble', type: 'honeymoon', gradient: 'linear-gradient(135deg,#43E97B,#38F9D7)' },
      { id: 'lm-4', name: 'Activités', subtitle: 'Expériences & sorties', icon: 'Compass', type: 'honeymoon', gradient: 'linear-gradient(135deg,#C33764,#1D2671)' },
      { id: 'lm-5', name: 'Remerciements', subtitle: 'Lettres & cadeaux', icon: 'Gift', type: 'honeymoon', gradient: 'linear-gradient(135deg,#F5D878,#E8A820)' },
      { id: 'lm-6', name: 'Album Photo', subtitle: 'Livre & tirages', icon: 'BookImage', type: 'honeymoon', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
    ],
  },

  {
    id: 15,
    title: 'Retroplanning',
    subtitle: '18 mois avant le Jour J',
    icon: 'CalendarClock',
    accentColor: '#8B5E5E',
    position: pos(4, 2),
    cards: [
      { id: 'rp-1', name: '18–12 Mois', subtitle: 'Lieu, date, budget', icon: 'CalendarClock', type: 'retroplanning', gradient: 'linear-gradient(135deg,#F53844,#42378F)' },
      { id: 'rp-2', name: '12–9 Mois', subtitle: 'Prestataires clés', icon: 'CalendarClock', type: 'retroplanning', gradient: 'linear-gradient(135deg,#C33764,#1D2671)' },
      { id: 'rp-3', name: '9–6 Mois', subtitle: 'Tenues & faire-part', icon: 'CalendarClock', type: 'retroplanning', gradient: 'linear-gradient(135deg,#667EEA,#764BA2)' },
      { id: 'rp-4', name: '6–3 Mois', subtitle: 'Menus, musique, déco', icon: 'CalendarClock', type: 'retroplanning', gradient: 'linear-gradient(135deg,#4FACFE,#00F2FE)' },
      { id: 'rp-5', name: '3–1 Mois', subtitle: 'Confirmations & RSVP', icon: 'CalendarClock', type: 'retroplanning', gradient: 'linear-gradient(135deg,#43E97B,#38F9D7)' },
      { id: 'rp-6', name: '1 Mois – J-7', subtitle: 'Répétition & finalisation', icon: 'CalendarCheck', type: 'retroplanning', gradient: 'linear-gradient(135deg,#F7971E,#FFD200)' },
      { id: 'rp-7', name: 'J-1', subtitle: 'Déco, livraisons, brief', icon: 'AlertCircle', type: 'retroplanning', gradient: 'linear-gradient(135deg,#F5576C,#F093FB)' },
      { id: 'rp-8', name: 'Jour J', subtitle: 'Check-list ultime', icon: 'CheckCircle2', type: 'retroplanning', gradient: 'linear-gradient(135deg,#F5D878,#E8A820)' },
    ],
  },
];
