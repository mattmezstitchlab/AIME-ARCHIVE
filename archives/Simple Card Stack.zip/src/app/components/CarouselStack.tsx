import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { WeddingCardBack } from "./WeddingCardBack";
import { weddingMoments, defaultSettings, MomentSettings } from "./weddingMoments";
import { AnimationSettings } from "./SettingsPanel";

const createCardVariants = (settings: AnimationSettings) => ({
  visible: (i: number) => ({
    opacity: 1,
    zIndex: [4, 3, 2, 1][i],
    scale: [1, 0.9, 0.85, 0.8][i],
    y: [0, -12, 0, 12][i],
    rotate: [0, 2, 4, 7][i],
    x: [0, 32, 48, 62][i],
    transition: {
      zIndex: { delay: settings.zIndexDelay },
      scale: { type: "spring", duration: settings.springDuration, bounce: settings.springBounce },
      y: { type: "spring", duration: settings.springDuration, bounce: settings.springBounce },
      x: { type: "spring", duration: settings.xSpringDuration, bounce: settings.xSpringBounce },
    },
  }),
  exit: { opacity: 0, scale: 0.5, y: 50 },
});

const swipePower = (offset: number, velocity: number) => Math.abs(offset) * velocity;

interface CarouselStackProps {
  settings: AnimationSettings;
  momentSettings: Record<number, MomentSettings>;
  onMomentSettingChange: (momentId: number, key: keyof MomentSettings, value: string | number | boolean) => void;
  onTopMomentChange?: (momentId: number) => void;
}

const NUM_VISIBLE = 4;

export const CarouselStack: React.FC<CarouselStackProps> = ({
  settings,
  momentSettings,
  onMomentSettingChange,
  onTopMomentChange,
}) => {
  const [startIndex, setStartIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const hasDragged = useRef(false);
  const numItems = weddingMoments.length;

  const visibleIndices = Array.from({ length: NUM_VISIBLE }, (_, i) =>
    (startIndex + i) % numItems
  );

  const paginate = () => {
    const nextStart = (startIndex + 1) % numItems;
    setStartIndex(nextStart);
    setIsFlipped(false);
    onTopMomentChange?.(weddingMoments[nextStart % numItems].id);
  };

  const cardVariants = createCardVariants(settings);

  return (
    <div className="content-container">
      <AnimatePresence initial={false}>
        {visibleIndices.map((momentIndex, i) => {
          const moment = weddingMoments[momentIndex];
          const isTop = i === 0;
          const currentSettings = momentSettings[moment.id] || defaultSettings(moment);

          return (
            <motion.div
              key={moment.id}
              custom={i}
              variants={cardVariants}
              initial="exit"
              animate="visible"
              exit="exit"
              drag={isTop && !isFlipped}
              dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
              dragElastic={settings.dragElastic}
              onDragStart={() => {
                hasDragged.current = true;
              }}
              onDragEnd={(_, { offset, velocity }) => {
                const swipe = swipePower(offset.x, velocity.x);
                if (
                  swipe < -settings.swipeConfidenceThreshold ||
                  swipe > settings.swipeConfidenceThreshold
                ) {
                  paginate();
                }
                setTimeout(() => {
                  hasDragged.current = false;
                }, 60);
              }}
              onClick={() => {
                if (!hasDragged.current && isTop) {
                  setIsFlipped((f) => !f);
                }
              }}
              className={`card card-${i}`}
              style={{ perspective: "1200px", cursor: isTop ? "pointer" : "default" }}
            >
              {/* Flip wrapper */}
              <motion.div
                animate={{ rotateY: isTop && isFlipped ? 180 : 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 32 }}
                style={{
                  transformStyle: "preserve-3d",
                  width: "100%",
                  height: "100%",
                  position: "relative",
                }}
              >
                {/* FRONT */}
                <div
                  style={{
                    backfaceVisibility: "hidden",
                    WebkitBackfaceVisibility: "hidden",
                    width: "100%",
                    height: "100%",
                    borderRadius: "24px",
                    overflow: "hidden",
                    position: "absolute",
                    inset: 0,
                  }}
                >
                  <ImageWithFallback
                    src={moment.image}
                    alt={moment.name}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                      display: "block",
                    }}
                  />
                  {/* Gradient overlay */}
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      background:
                        "linear-gradient(180deg, rgba(0,0,0,0) 40%, rgba(0,0,0,0.55) 100%)",
                      borderRadius: "24px",
                    }}
                  />
                  {/* Moment label */}
                  <div
                    style={{
                      position: "absolute",
                      bottom: "20px",
                      left: "20px",
                      right: "20px",
                    }}
                  >
                    <div
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "7px",
                        background: "rgba(255,255,255,0.15)",
                        backdropFilter: "blur(16px)",
                        WebkitBackdropFilter: "blur(16px)",
                        borderRadius: "50px",
                        padding: "7px 14px",
                        marginBottom: "6px",
                      }}
                    >
                      <span
                        style={{
                          color: "rgba(255,255,255,0.7)",
                          fontSize: "10px",
                        }}
                      >
                        {moment.icon}
                      </span>
                      <span
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "12px",
                          fontWeight: 400,
                          color: "rgba(255,255,255,0.7)",
                          letterSpacing: "0.04em",
                        }}
                      >
                        {currentSettings.time}
                      </span>
                    </div>
                    <div>
                      <p
                        style={{
                          fontFamily: "Cormorant Garamond, serif",
                          fontSize: "26px",
                          fontWeight: 400,
                          color: "#fff",
                          letterSpacing: "-0.01em",
                          lineHeight: 1.1,
                          margin: 0,
                        }}
                      >
                        {moment.name}
                      </p>
                      <p
                        style={{
                          fontFamily: "Cormorant Garamond, serif",
                          fontSize: "15px",
                          fontStyle: "italic",
                          fontWeight: 300,
                          color: "rgba(255,255,255,0.75)",
                          margin: "2px 0 0",
                        }}
                      >
                        {moment.subtitle}
                      </p>
                    </div>
                  </div>
                  {/* Tap hint for top card */}
                  {isTop && !isFlipped && (
                    <div
                      style={{
                        position: "absolute",
                        top: "16px",
                        right: "16px",
                        background: "rgba(255,255,255,0.15)",
                        backdropFilter: "blur(12px)",
                        WebkitBackdropFilter: "blur(12px)",
                        borderRadius: "50px",
                        padding: "5px 10px",
                        fontFamily: "Inter, sans-serif",
                        fontSize: "10px",
                        color: "rgba(255,255,255,0.8)",
                        letterSpacing: "0.03em",
                      }}
                    >
                      Configurer
                    </div>
                  )}
                </div>

                {/* BACK */}
                <div
                  style={{
                    backfaceVisibility: "hidden",
                    WebkitBackfaceVisibility: "hidden",
                    transform: "rotateY(180deg)",
                    position: "absolute",
                    inset: 0,
                    borderRadius: "24px",
                    overflow: "hidden",
                  }}
                >
                  <WeddingCardBack
                    moment={moment}
                    settings={currentSettings}
                    onChange={(key, value) =>
                      onMomentSettingChange(moment.id, key, value)
                    }
                    onClose={() => setIsFlipped(false)}
                  />
                </div>
              </motion.div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};

export default CarouselStack;
