import React, { useState } from 'react';
import type { Tool } from '../types';
import {
  MousePointer2, Hand, ZoomIn, ZoomOut, StickyNote,
  Wallpaper, Type, Paintbrush, Minus, Plus,
  Globe, Wallet, ListChecks, Tv2, LayoutTemplate,
  Sun, Moon,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface ToolbarProps {
  activeTool: Tool;
  onToolChange: (t: Tool) => void;
  scale: number;
  onZoomChange: (delta: number) => void;
  onBgOpen: () => void;
  onTextOpen: () => void;
  onTextureOpen: () => void;
  textureActive: boolean;
  onMiniSite: () => void;
  miniSiteActive: boolean;
  onBudget: () => void;
  onChecklist: () => void;
  onKiosk: () => void;
  onTemplates: () => void;
}

const drawTools: { id: Tool; icon: React.ReactNode; label: string }[] = [
  { id: 'select',   icon: <MousePointer2 size={15} />, label: 'Sélectionner (V)' },
  { id: 'hand',     icon: <Hand size={15} />,          label: 'Déplacer (G)' },
  { id: 'zoom-in',  icon: <ZoomIn size={15} />,        label: 'Zoom +' },
  { id: 'zoom-out', icon: <ZoomOut size={15} />,       label: 'Zoom −' },
  { id: 'note',     icon: <StickyNote size={15} />,    label: 'Note' },
];

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTool, onToolChange, scale, onZoomChange,
  onBgOpen, onTextOpen, onTextureOpen, textureActive,
  onMiniSite, miniSiteActive, onBudget, onChecklist, onKiosk, onTemplates,
}) => {
  const { isDark, toggle } = useTheme();

  return (
    <div style={{
      position: 'fixed', left: '10px', top: '60px', bottom: '16px',
      zIndex: 100, width: '42px',
      display: 'flex', flexDirection: 'column',
      background: isDark ? 'rgba(13,12,24,0.96)' : 'rgba(255,255,255,0.97)',
      backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
      borderRadius: '13px', padding: '8px 5px',
      boxShadow: isDark
        ? '0 4px 24px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.06)'
        : '0 2px 20px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.06)',
      transition: 'background 0.3s, box-shadow 0.3s',
    }}>
      {/* Drawing tools */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
        {drawTools.map((t) => (
          <ToolBtn key={t.id} active={activeTool === t.id} label={t.label}
            onClick={() => onToolChange(t.id)} isDark={isDark}>
            {t.icon}
          </ToolBtn>
        ))}
      </div>

      <Divider isDark={isDark} />

      {/* Canvas style tools */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
        <ToolBtn label="Fond du canvas" onClick={onBgOpen} isDark={isDark}><Wallpaper size={15} /></ToolBtn>
        <ToolBtn label="Texte" onClick={onTextOpen} isDark={isDark}><Type size={15} /></ToolBtn>
        <ToolBtn label="Textures & Motifs" onClick={onTextureOpen} active={textureActive} isDark={isDark}><Paintbrush size={15} /></ToolBtn>
      </div>

      <Divider isDark={isDark} />

      {/* Panel shortcuts */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
        <ToolBtn label="Éditeur Mini-site" onClick={onMiniSite} active={miniSiteActive} accent isDark={isDark}>
          <Globe size={15} />
        </ToolBtn>
        <ToolBtn label="Budget" onClick={onBudget} isDark={isDark}><Wallet size={15} /></ToolBtn>
        <ToolBtn label="Checklist IA" onClick={onChecklist} isDark={isDark}><ListChecks size={15} /></ToolBtn>
        <ToolBtn label="Mode Kiosque — Jour J" onClick={onKiosk} isDark={isDark}><Tv2 size={15} /></ToolBtn>
        <ToolBtn label="Templates de mariage" onClick={onTemplates} isDark={isDark}><LayoutTemplate size={15} /></ToolBtn>
      </div>

      <Divider isDark={isDark} />

      {/* Zoom controls */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1px' }}>
        <ZoomBtn onClick={() => onZoomChange(0.25)} title="Zoom +" isDark={isDark}><Plus size={12} /></ZoomBtn>
        <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '8px', color: isDark ? 'rgba(240,238,248,0.3)' : 'rgba(15,15,18,0.35)', letterSpacing: '0.03em', padding: '1px 0', userSelect: 'none' }}>
          {Math.round(scale * 100)}%
        </span>
        <ZoomBtn onClick={() => onZoomChange(-0.25)} title="Zoom −" isDark={isDark}><Minus size={12} /></ZoomBtn>
      </div>

      {/* Push theme toggle to bottom */}
      <div style={{ flex: 1 }} />

      <Divider isDark={isDark} />

      <ToolBtn label={isDark ? 'Passer en mode jour' : 'Passer en mode nuit'} onClick={toggle} isDark={isDark}>
        {isDark ? <Sun size={15} /> : <Moon size={15} />}
      </ToolBtn>
    </div>
  );
};

/* ── Primitives ─────────────────────────────────────────────────────────────── */

const ToolBtn: React.FC<{
  children: React.ReactNode;
  active?: boolean;
  label: string;
  onClick: () => void;
  isDark: boolean;
  accent?: boolean;
}> = ({ children, active = false, label, onClick, isDark, accent }) => {
  const [hov, setHov] = useState(false);

  const color = (() => {
    if (active) return accent ? '#C4956A' : (isDark ? '#F0EEF8' : '#0F0F12');
    if (hov)   return isDark ? 'rgba(240,238,248,0.85)' : 'rgba(15,15,18,0.85)';
    return isDark ? 'rgba(240,238,248,0.45)' : 'rgba(15,15,18,0.45)';
  })();

  const bg = (() => {
    if (active) return accent ? 'rgba(196,149,106,0.15)' : (isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)');
    if (hov)    return isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)';
    return 'transparent';
  })();

  return (
    <button
      onClick={onClick} title={label}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: '32px', height: '32px', borderRadius: '8px', border: 'none',
        background: bg, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color, transition: 'all 0.12s', outline: 'none', flexShrink: 0,
      }}
    >
      {children}
    </button>
  );
};

const ZoomBtn: React.FC<{ children: React.ReactNode; onClick: () => void; title: string; isDark: boolean }> = ({ children, onClick, title, isDark }) => (
  <button onClick={onClick} title={title} style={{
    width: '32px', height: '22px', borderRadius: '6px', border: 'none', background: 'transparent',
    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
    color: isDark ? 'rgba(240,238,248,0.4)' : 'rgba(15,15,18,0.4)', transition: 'color 0.12s',
  }}>
    {children}
  </button>
);

const Divider: React.FC<{ isDark: boolean }> = ({ isDark }) => (
  <div style={{ height: '1px', background: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.07)', margin: '5px 4px' }} />
);
