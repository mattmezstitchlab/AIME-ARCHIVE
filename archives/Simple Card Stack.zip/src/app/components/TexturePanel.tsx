import React from 'react';
import { X } from 'lucide-react';

interface TexturePanelProps {
  current: string;
  onSelect: (id: string) => void;
  onClose: () => void;
}

const TEXTURES = [
  { id: '', name: 'Aucune', preview: { background: '#FAF8F4', border: '1.5px dashed rgba(0,0,0,0.15)' }, overlay: {} },
  {
    id: 'glow-violet',
    name: 'Glow\nViolet',
    preview: { background: 'radial-gradient(ellipse at 40% 50%, rgba(168,85,247,0.8) 0%, rgba(99,102,241,0.6) 50%, #1a0a2e 100%)' },
    overlay: { background: 'radial-gradient(ellipse at 40% 40%, rgba(168,85,247,0.45) 0%, transparent 65%), radial-gradient(ellipse at 70% 70%, rgba(99,102,241,0.35) 0%, transparent 60%)' },
  },
  {
    id: 'glow-rose',
    name: 'Glow\nRose',
    preview: { background: 'radial-gradient(ellipse at 60% 40%, rgba(244,63,94,0.9) 0%, rgba(251,113,133,0.6) 50%, #2a0010 100%)' },
    overlay: { background: 'radial-gradient(ellipse at 60% 40%, rgba(244,63,94,0.4) 0%, transparent 60%), radial-gradient(ellipse at 30% 70%, rgba(251,113,133,0.3) 0%, transparent 55%)' },
  },
  {
    id: 'aurora',
    name: 'Aurora',
    preview: { background: 'radial-gradient(ellipse at 20% 60%, rgba(52,211,153,0.8) 0%, transparent 45%), radial-gradient(ellipse at 80% 40%, rgba(139,92,246,0.8) 0%, transparent 45%), radial-gradient(ellipse at 50% 90%, rgba(59,130,246,0.6) 0%, transparent 50%), #050e1a' },
    overlay: { background: 'radial-gradient(ellipse at 20% 60%, rgba(52,211,153,0.35) 0%, transparent 50%), radial-gradient(ellipse at 80% 40%, rgba(139,92,246,0.35) 0%, transparent 50%), radial-gradient(ellipse at 50% 90%, rgba(59,130,246,0.25) 0%, transparent 50%)' },
  },
  {
    id: 'metamorphism',
    name: 'Méta-\nmorphisme',
    preview: { background: 'linear-gradient(135deg, rgba(255,255,255,0.3) 0%, rgba(200,200,255,0.5) 50%, rgba(180,200,240,0.3) 100%)', backdropFilter: 'blur(10px)' },
    overlay: { background: 'radial-gradient(ellipse at 30% 30%, rgba(255,255,255,0.6) 0%, transparent 40%), radial-gradient(ellipse at 70% 60%, rgba(200,200,255,0.4) 0%, transparent 40%), linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 100%)' },
  },
  {
    id: 'marble',
    name: 'Marbre',
    preview: { background: 'linear-gradient(135deg, #e8e0d8 0%, #f5f0eb 30%, #d8d0c8 60%, #ece8e0 100%)' },
    overlay: { background: 'linear-gradient(115deg, rgba(255,255,255,0.25) 0%, rgba(220,220,235,0.35) 35%, rgba(255,255,255,0.1) 65%, rgba(210,210,230,0.3) 100%)' },
  },
  {
    id: 'linen',
    name: 'Lin',
    preview: { background: 'repeating-linear-gradient(90deg, #e8e0d5 0px, #e8e0d5 2px, #f0e8de 2px, #f0e8de 4px)' },
    overlay: { background: 'repeating-linear-gradient(90deg, transparent 0px, transparent 3px, rgba(0,0,0,0.04) 3px, rgba(0,0,0,0.04) 4px), repeating-linear-gradient(0deg, transparent 0px, transparent 3px, rgba(0,0,0,0.03) 3px, rgba(0,0,0,0.03) 4px)' },
  },
  {
    id: 'gold',
    name: 'Or',
    preview: { background: 'linear-gradient(135deg, #b8860b 0%, #ffd700 30%, #daa520 55%, #ffeaa7 75%, #b8860b 100%)' },
    overlay: { background: 'linear-gradient(135deg, rgba(212,175,55,0.55) 0%, rgba(255,215,0,0.35) 30%, rgba(184,134,11,0.45) 60%, rgba(255,220,50,0.55) 100%)' },
  },
  {
    id: 'velvet',
    name: 'Velours',
    preview: { background: 'radial-gradient(ellipse at center, #4a1464 0%, #200830 100%)' },
    overlay: { background: 'radial-gradient(ellipse at center, rgba(80,20,100,0.75) 0%, rgba(20,5,40,0.9) 100%)' },
  },
  {
    id: 'neon',
    name: 'Néon',
    preview: { background: 'radial-gradient(ellipse at 50% 50%, rgba(0,255,170,0.5) 0%, transparent 40%), radial-gradient(ellipse at 20% 80%, rgba(0,100,255,0.5) 0%, transparent 40%), radial-gradient(ellipse at 80% 20%, rgba(255,0,150,0.5) 0%, transparent 40%), #040408' },
    overlay: { background: 'radial-gradient(ellipse at 50% 50%, rgba(0,255,170,0.3) 0%, transparent 50%), radial-gradient(ellipse at 20% 80%, rgba(0,100,255,0.3) 0%, transparent 45%), radial-gradient(ellipse at 80% 20%, rgba(255,0,150,0.3) 0%, transparent 45%)' },
  },
  {
    id: 'dark-glass',
    name: 'Verre\nSombre',
    preview: { background: 'linear-gradient(135deg, #1e2030 0%, rgba(80,80,120,0.9) 50%, #1e2030 100%)' },
    overlay: { background: 'linear-gradient(135deg, rgba(30,30,50,0.65) 0%, rgba(50,50,80,0.55) 100%)' },
  },
  {
    id: 'sunrise',
    name: 'Aurore',
    preview: { background: 'linear-gradient(135deg, #ff6b35 0%, #f7c59f 30%, #ffe66d 60%, #4ecdc4 100%)' },
    overlay: { background: 'linear-gradient(135deg, rgba(255,107,53,0.4) 0%, rgba(247,197,159,0.3) 35%, rgba(255,230,109,0.35) 65%, rgba(78,205,196,0.3) 100%)' },
  },
];

export const TEXTURE_OVERLAYS: Record<string, React.CSSProperties> = Object.fromEntries(
  TEXTURES.map(t => [t.id, t.overlay])
);

export const TexturePanel: React.FC<TexturePanelProps> = ({ current, onSelect, onClose }) => (
  <div
    style={{
      position: 'fixed',
      left: '72px',
      top: '50%',
      transform: 'translateY(-50%)',
      width: '218px',
      background: 'rgba(255,255,255,0.98)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      borderRadius: '16px',
      boxShadow: '0 4px 32px rgba(0,0,0,0.16), 0 0 0 1px rgba(0,0,0,0.06)',
      zIndex: 200,
      overflow: 'hidden',
    }}
  >
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px 8px' }}>
      <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(0,0,0,0.55)' }}>
        Textures & Motifs
      </span>
      <button onClick={onClose} style={{ border: 'none', background: 'none', cursor: 'pointer', padding: '4px', color: 'rgba(0,0,0,0.4)' }}>
        <X size={13} />
      </button>
    </div>

    <div style={{ padding: '4px 12px 14px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '5px' }}>
      {TEXTURES.map((t) => (
        <button
          key={t.id}
          onClick={() => onSelect(t.id)}
          style={{
            aspectRatio: '1',
            borderRadius: '8px',
            border: current === t.id ? '2.5px solid rgba(0,0,0,0.8)' : '1.5px solid rgba(0,0,0,0.1)',
            cursor: 'pointer',
            padding: 0,
            overflow: 'hidden',
            position: 'relative',
            ...t.preview,
          }}
          title={t.name.replace('\n', ' ')}
        >
          <span
            style={{
              position: 'absolute', bottom: '2px', left: 0, right: 0,
              fontFamily: 'Inter', fontSize: '6.5px', fontWeight: 700,
              color: 'rgba(255,255,255,0.92)',
              textAlign: 'center',
              textShadow: '0 1px 3px rgba(0,0,0,0.7)',
              lineHeight: 1.2,
              whiteSpace: 'pre-line',
              padding: '0 2px',
            }}
          >
            {t.name}
          </span>
        </button>
      ))}
    </div>
  </div>
);
