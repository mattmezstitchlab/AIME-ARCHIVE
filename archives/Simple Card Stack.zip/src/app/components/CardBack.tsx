import React, { useRef } from 'react';
import { ChevronLeft, Upload, X, Plus, Trash2, Circle, Clock3, CheckCircle2, CreditCard } from 'lucide-react';
import { Switch } from './ui/switch';
import type { WeddingCard } from '../types';
import { TEXTURE_OVERLAYS } from './TexturePanel';

interface CardBackProps {
  card: WeddingCard;
  settings: Record<string, any>;
  onChange: (key: string, value: unknown) => void;
  onClose: () => void;
  globalTexture?: string;
}

// ─── shared primitives ────────────────────────────────────────────────────────

const LABEL: React.CSSProperties = {
  display: 'block',
  fontFamily: 'Inter, sans-serif',
  fontSize: '10px',
  letterSpacing: '0.07em',
  textTransform: 'uppercase',
  color: 'rgba(0,0,0,0.4)',
  marginBottom: '4px',
};
const INPUT: React.CSSProperties = {
  fontFamily: 'Inter, sans-serif',
  fontSize: '12.5px',
  color: 'rgba(0,0,0,0.8)',
  background: 'rgba(0,0,0,0.05)',
  border: 'none',
  borderRadius: '8px',
  padding: '7px 10px',
  width: '100%',
  outline: 'none',
};
const ROW: React.CSSProperties = { display: 'flex', gap: '10px' };
const FIELD: React.CSSProperties = { flex: 1 };
const SECTION: React.CSSProperties = { display: 'flex', flexDirection: 'column', gap: '10px' };

const Field: React.FC<{
  label: string;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ label, style, children }) => (
  <div style={style ?? FIELD}>
    <label style={LABEL}>{label}</label>
    {children}
  </div>
);

const TextInput: React.FC<{
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  style?: React.CSSProperties;
}> = ({ value, onChange, placeholder, type = 'text', style }) => (
  <input
    type={type}
    value={value || ''}
    placeholder={placeholder}
    onChange={(e) => onChange(e.target.value)}
    style={{ ...INPUT, ...style }}
    onClick={(e) => e.stopPropagation()}
  />
);

const SelectInput: React.FC<{
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}> = ({ value, onChange, options }) => (
  <select
    value={value || ''}
    onChange={(e) => onChange(e.target.value)}
    style={{ ...INPUT, cursor: 'pointer' }}
    onClick={(e) => e.stopPropagation()}
  >
    {options.map((o) => (
      <option key={o.value} value={o.value}>{o.label}</option>
    ))}
  </select>
);

const TextArea: React.FC<{
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  rows?: number;
}> = ({ value, onChange, placeholder, rows = 3 }) => (
  <textarea
    value={value || ''}
    placeholder={placeholder}
    rows={rows}
    onChange={(e) => onChange(e.target.value)}
    style={{ ...INPUT, resize: 'none', lineHeight: 1.5 }}
    onClick={(e) => e.stopPropagation()}
  />
);

const ToggleRow: React.FC<{
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}> = ({ label, value, onChange }) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '7px 10px',
      background: 'rgba(0,0,0,0.04)',
      borderRadius: '8px',
    }}
    onClick={(e) => e.stopPropagation()}
  >
    <span style={{ fontFamily: 'Inter', fontSize: '12.5px', color: 'rgba(0,0,0,0.7)' }}>{label}</span>
    <Switch checked={!!value} onCheckedChange={onChange} />
  </div>
);

// ─── photo / video import ─────────────────────────────────────────────────────

const MediaImport: React.FC<{
  value: string;
  onChange: (v: string) => void;
}> = ({ value, onChange }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    onChange(url);
  };

  return (
    <div onClick={(e) => e.stopPropagation()}>
      <input
        ref={inputRef}
        type="file"
        accept="image/*,video/*"
        style={{ display: 'none' }}
        onChange={handleFile}
      />
      {value ? (
        <div style={{ position: 'relative', borderRadius: '8px', overflow: 'hidden' }}>
          {value.includes('video') || value.startsWith('blob:') ? (
            <video
              src={value}
              controls
              style={{ width: '100%', borderRadius: '8px', maxHeight: '100px', objectFit: 'cover' }}
            />
          ) : (
            <img
              src={value}
              alt="import"
              style={{ width: '100%', borderRadius: '8px', maxHeight: '100px', objectFit: 'cover' }}
            />
          )}
          <button
            onClick={() => onChange('')}
            style={{
              position: 'absolute', top: 4, right: 4,
              background: 'rgba(0,0,0,0.5)', border: 'none', borderRadius: '50%',
              width: 20, height: 20, cursor: 'pointer', display: 'flex',
              alignItems: 'center', justifyContent: 'center',
            }}
          >
            <X size={12} color="#fff" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => inputRef.current?.click()}
          style={{
            width: '100%', padding: '8px', background: 'rgba(0,0,0,0.04)',
            border: '1.5px dashed rgba(0,0,0,0.15)', borderRadius: '8px',
            cursor: 'pointer', display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: '6px',
            fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.4)',
          }}
        >
          <Upload size={12} /> Importer photo / vidéo
        </button>
      )}
    </div>
  );
};

// ─── status system ───────────────────────────────────────────────────────────

const STATUS_OPTIONS = [
  { id: 'todo',      label: 'À faire',    bg: 'rgba(0,0,0,0.07)',          color: 'rgba(0,0,0,0.5)',  Icon: Circle },
  { id: 'waiting',   label: 'En attente', bg: 'rgba(245,158,11,0.18)',      color: '#D97706',           Icon: Clock3 },
  { id: 'confirmed', label: 'Confirmé',   bg: 'rgba(34,197,94,0.18)',       color: '#16A34A',           Icon: CheckCircle2 },
  { id: 'paid',      label: 'Payé',       bg: 'rgba(59,130,246,0.18)',      color: '#2563EB',           Icon: CreditCard },
] as const;

export const STATUS_DOT_COLOR: Record<string, string> = {
  todo:      'rgba(255,255,255,0.25)',
  waiting:   '#F59E0B',
  confirmed: '#22C55E',
  paid:      '#3B82F6',
};

// ─── card type forms ──────────────────────────────────────────────────────────

const DRESS_CODES = [
  { value: '', label: 'Non défini' },
  { value: 'chic', label: 'Chic' },
  { value: 'elegant', label: 'Élégant' },
  { value: 'casual', label: 'Décontracté' },
  { value: 'blacktie', label: 'Tenue de soirée' },
  { value: 'blanc', label: 'Blanc & Ivoire' },
];

const ProgrammeBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <div style={ROW}>
      <Field label="Heure"><TextInput value={s.time} onChange={(v) => set('time', v)} type="time" /></Field>
      <Field label="Invités"><TextInput value={s.invites} onChange={(v) => set('invites', v)} type="number" placeholder="0" /></Field>
    </div>
    <Field label="Lieu" style={undefined}><TextInput value={s.lieu} onChange={(v) => set('lieu', v)} placeholder="Nom du lieu..." /></Field>
    <Field label="Dress code" style={undefined}><SelectInput value={s.dresscode} onChange={(v) => set('dresscode', v)} options={DRESS_CODES} /></Field>
    <ToggleRow label="Musique live" value={s.musique} onChange={(v) => set('musique', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Détails, prestataires..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const VenueBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <Field label="Nom du lieu" style={undefined}><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="Château de..." /></Field>
    <Field label="Adresse" style={undefined}><TextInput value={s.adresse} onChange={(v) => set('adresse', v)} placeholder="Adresse complète..." /></Field>
    <div style={ROW}>
      <Field label="Capacité"><TextInput value={s.capacite} onChange={(v) => set('capacite', v)} type="number" placeholder="200" /></Field>
      <Field label="Tarif (€)"><TextInput value={s.tarif} onChange={(v) => set('tarif', v)} type="number" placeholder="0" /></Field>
    </div>
    <div style={ROW}>
      <Field label="Contact"><TextInput value={s.contact} onChange={(v) => set('contact', v)} placeholder="Nom..." /></Field>
      <Field label="Tél."><TextInput value={s.tel} onChange={(v) => set('tel', v)} type="tel" placeholder="+33..." /></Field>
    </div>
    <div style={ROW}>
      <Field label="Acompte (€)"><TextInput value={s.acompte} onChange={(v) => set('acompte', v)} type="number" placeholder="0" /></Field>
      <Field label="Solde (€)"><TextInput value={s.solde} onChange={(v) => set('solde', v)} type="number" placeholder="0" /></Field>
    </div>
    <ToggleRow label="Contrat signé" value={s.contrat_signe} onChange={(v) => set('contrat_signe', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Conditions, inclus..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const PhotoVideoBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <div style={ROW}>
      <Field label="Prénom / Nom"><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="..." /></Field>
    </div>
    <div style={ROW}>
      <Field label="Email"><TextInput value={s.email} onChange={(v) => set('email', v)} type="email" placeholder="..." /></Field>
      <Field label="Tél."><TextInput value={s.tel} onChange={(v) => set('tel', v)} type="tel" placeholder="+33..." /></Field>
    </div>
    <Field label="Forfait" style={undefined}>
      <SelectInput value={s.forfait} onChange={(v) => set('forfait', v)} options={[
        { value: '', label: 'Choisir...' },
        { value: 'demi', label: 'Demi-journée' },
        { value: 'journee', label: 'Journée complète' },
        { value: 'weekend', label: 'Week-end' },
      ]} />
    </Field>
    <div style={ROW}>
      <Field label="Tarif (€)"><TextInput value={s.tarif} onChange={(v) => set('tarif', v)} type="number" placeholder="0" /></Field>
      <Field label="Livraison"><TextInput value={s.livraison} onChange={(v) => set('livraison', v)} placeholder="6 semaines..." /></Field>
    </div>
    <div style={ROW}>
      <Field label="Acompte (€)"><TextInput value={s.acompte} onChange={(v) => set('acompte', v)} type="number" placeholder="0" /></Field>
      <Field label="Date règlement"><TextInput value={s.date_reglement} onChange={(v) => set('date_reglement', v)} type="date" /></Field>
    </div>
    <ToggleRow label="Contrat signé" value={s.contrat_signe} onChange={(v) => set('contrat_signe', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Listes de shots, instructions..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const BeautyBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <div style={ROW}>
      <Field label="Prestataire"><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="Nom..." /></Field>
      <Field label="Tél."><TextInput value={s.tel} onChange={(v) => set('tel', v)} type="tel" placeholder="+33..." /></Field>
    </div>
    <div style={ROW}>
      <Field label="Heure RDV"><TextInput value={s.heure_rdv} onChange={(v) => set('heure_rdv', v)} type="time" /></Field>
      <Field label="Tarif (€)"><TextInput value={s.tarif} onChange={(v) => set('tarif', v)} type="number" placeholder="0" /></Field>
    </div>
    <Field label="Lieu du RDV" style={undefined}><TextInput value={s.lieu_rdv} onChange={(v) => set('lieu_rdv', v)} placeholder="À domicile / salon..." /></Field>
    <div style={ROW}>
      <Field label="Essayage 1"><TextInput value={s.essayage1} onChange={(v) => set('essayage1', v)} type="date" /></Field>
      <Field label="Essayage 2"><TextInput value={s.essayage2} onChange={(v) => set('essayage2', v)} type="date" /></Field>
    </div>
    <ToggleRow label="Contrat / Devis signé" value={s.contrat_signe} onChange={(v) => set('contrat_signe', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Inspirations, demandes spécifiques..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const CateringBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <Field label="Traiteur / Prestataire" style={undefined}><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="Nom..." /></Field>
    <Field label="Service" style={undefined}>
      <SelectInput value={s.service} onChange={(v) => set('service', v)} options={[
        { value: '', label: 'Choisir...' },
        { value: 'assis', label: 'Assis au menu' },
        { value: 'buffet', label: 'Buffet' },
        { value: 'cocktail', label: 'Cocktail dinatoire' },
        { value: 'mixte', label: 'Mixte' },
      ]} />
    </Field>
    <div style={ROW}>
      <Field label="Couverts"><TextInput value={s.couverts} onChange={(v) => set('couverts', v)} type="number" placeholder="0" /></Field>
      <Field label="Prix / tête (€)"><TextInput value={s.prix_tete} onChange={(v) => set('prix_tete', v)} type="number" placeholder="0" /></Field>
    </div>
    <Field label="Allergènes / régimes" style={undefined}><TextInput value={s.allergenes} onChange={(v) => set('allergenes', v)} placeholder="Végé, sans gluten..." /></Field>
    <div style={ROW}>
      <Field label="Acompte (€)"><TextInput value={s.acompte} onChange={(v) => set('acompte', v)} type="number" placeholder="0" /></Field>
      <Field label="Solde (€)"><TextInput value={s.solde} onChange={(v) => set('solde', v)} type="number" placeholder="0" /></Field>
    </div>
    <ToggleRow label="Contrat signé" value={s.contrat_signe} onChange={(v) => set('contrat_signe', v)} />
    <Field label="Menu / Notes" style={undefined}><TextArea value={s.menu} onChange={(v) => set('menu', v)} placeholder="Entrées, plats, desserts..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const FlowersBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <div style={ROW}>
      <Field label="Prestataire"><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="Fleuriste..." /></Field>
      <Field label="Tél."><TextInput value={s.tel} onChange={(v) => set('tel', v)} type="tel" placeholder="+33..." /></Field>
    </div>
    <Field label="Thème / Style" style={undefined}><TextInput value={s.theme} onChange={(v) => set('theme', v)} placeholder="Champêtre, baroque..." /></Field>
    <Field label="Couleurs" style={undefined}><TextInput value={s.couleurs} onChange={(v) => set('couleurs', v)} placeholder="Blanc, nude, terracotta..." /></Field>
    <div style={ROW}>
      <Field label="Budget (€)"><TextInput value={s.budget} onChange={(v) => set('budget', v)} type="number" placeholder="0" /></Field>
      <Field label="Livraison"><TextInput value={s.livraison} onChange={(v) => set('livraison', v)} type="date" /></Field>
    </div>
    <ToggleRow label="Devis signé" value={s.devis_signe} onChange={(v) => set('devis_signe', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Bouquet, arche, centre de table..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

// Full GUSO form for intermittents du spectacle
const ArtistBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => {
  const chargesPatronales = s.montant_cachet ? Math.round(Number(s.montant_cachet) * (Number(s.nb_cachets) || 1) * 0.35) : 0;
  const chargesSalariales = s.montant_cachet ? Math.round(Number(s.montant_cachet) * (Number(s.nb_cachets) || 1) * 0.22) : 0;

  return (
    <div style={SECTION}>
      <div style={{ padding: '6px 8px', background: 'rgba(102,126,234,0.1)', borderRadius: '8px', marginBottom: '2px' }}>
        <span style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(102,126,234,0.9)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          Identité artiste
        </span>
      </div>
      <div style={ROW}>
        <Field label="Prénom"><TextInput value={s.prenom} onChange={(v) => set('prenom', v)} placeholder="Prénom..." /></Field>
        <Field label="Nom"><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="Nom..." /></Field>
      </div>
      <div style={ROW}>
        <Field label="Date de naissance"><TextInput value={s.ddn} onChange={(v) => set('ddn', v)} type="date" /></Field>
        <Field label="Lieu de naissance"><TextInput value={s.lieu_naissance} onChange={(v) => set('lieu_naissance', v)} placeholder="Ville..." /></Field>
      </div>
      <div style={ROW}>
        <Field label="N° Sécurité Sociale"><TextInput value={s.nss} onChange={(v) => set('nss', v)} placeholder="1 XX XX XX XXX XXX XX" /></Field>
      </div>
      <Field label="IBAN" style={undefined}><TextInput value={s.iban} onChange={(v) => set('iban', v)} placeholder="FR76..." /></Field>

      <div style={{ height: '1px', background: 'rgba(0,0,0,0.08)', margin: '2px 0' }} />

      <div style={{ padding: '6px 8px', background: 'rgba(102,126,234,0.1)', borderRadius: '8px' }}>
        <span style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(102,126,234,0.9)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          Contrat GUSO
        </span>
      </div>
      <Field label="Qualité / Rôle" style={undefined}>
        <SelectInput value={s.qualite} onChange={(v) => set('qualite', v)} options={[
          { value: '', label: 'Choisir...' },
          { value: 'musicien', label: 'Musicien' },
          { value: 'chanteur', label: 'Chanteur / Chanteuse' },
          { value: 'dj', label: 'DJ' },
          { value: 'danseur', label: 'Danseur / Danseuse' },
          { value: 'comedien', label: 'Comédien / Comédienne' },
          { value: 'magicien', label: 'Magicien' },
          { value: 'circassien', label: 'Artiste de cirque' },
          { value: 'technicien', label: 'Technicien (annexe 8)' },
        ]} />
      </Field>
      <Field label="Annexe" style={undefined}>
        <SelectInput value={s.annexe} onChange={(v) => set('annexe', v)} options={[
          { value: '', label: 'Choisir...' },
          { value: 'annexe10', label: 'Annexe 10 — Artiste' },
          { value: 'annexe8', label: 'Annexe 8 — Technicien' },
        ]} />
      </Field>
      <Field label="Nature de la prestation" style={undefined}>
        <SelectInput value={s.nature} onChange={(v) => set('nature', v)} options={[
          { value: '', label: 'Choisir...' },
          { value: 'representation', label: 'Représentation' },
          { value: 'repetition', label: 'Répétition' },
          { value: 'enregistrement', label: 'Enregistrement' },
        ]} />
      </Field>
      <Field label="Date de prestation" style={undefined}><TextInput value={s.date_prestation} onChange={(v) => set('date_prestation', v)} type="date" /></Field>
      <div style={ROW}>
        <Field label="Nb cachets">
          <TextInput value={s.nb_cachets} onChange={(v) => set('nb_cachets', v)} type="number" placeholder="1" />
          <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(0,0,0,0.4)', marginTop: '2px', display: 'block' }}>1 cachet = 12h</span>
        </Field>
        <Field label="Montant / cachet (€ brut)"><TextInput value={s.montant_cachet} onChange={(v) => set('montant_cachet', v)} type="number" placeholder="0" /></Field>
      </div>

      {/* Computed charges */}
      {(s.montant_cachet > 0) && (
        <div style={{ background: 'rgba(0,0,0,0.03)', borderRadius: '8px', padding: '8px 10px' }}>
          <div style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(0,0,0,0.4)', marginBottom: '4px', letterSpacing: '0.04em', textTransform: 'uppercase' }}>Charges estimées</div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.6)' }}>Patronales (~35%)</span>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.8)' }}>{chargesPatronales} €</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '2px' }}>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.6)' }}>Salariales (~22%)</span>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.8)' }}>{chargesSalariales} €</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '4px', borderTop: '1px solid rgba(0,0,0,0.08)', paddingTop: '4px' }}>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 500, color: 'rgba(0,0,0,0.7)' }}>Coût total</span>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 500, color: 'rgba(0,0,0,0.85)' }}>
              {Number(s.montant_cachet) * (Number(s.nb_cachets) || 1) + chargesPatronales} €
            </span>
          </div>
        </div>
      )}

      <ToggleRow label="GUSO généré (contrat + bulletin)" value={s.guso_genere} onChange={(v) => set('guso_genere', v)} />
      <ToggleRow label="Contrat signé" value={s.contrat_signe} onChange={(v) => set('contrat_signe', v)} />
      <ToggleRow label="Cachet versé" value={s.cachet_verse} onChange={(v) => set('cachet_verse', v)} />
      <Field label="Notes / Rider technique" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Matériel requis, repas, transport..." /></Field>
      <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
    </div>
  );
};

const AnimationBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <div style={ROW}>
      <Field label="Prestataire"><TextInput value={s.nom} onChange={(v) => set('nom', v)} placeholder="Nom..." /></Field>
      <Field label="Tél."><TextInput value={s.tel} onChange={(v) => set('tel', v)} type="tel" placeholder="+33..." /></Field>
    </div>
    <div style={ROW}>
      <Field label="Durée"><TextInput value={s.duree} onChange={(v) => set('duree', v)} placeholder="2h..." /></Field>
      <Field label="Tarif (€)"><TextInput value={s.tarif} onChange={(v) => set('tarif', v)} type="number" placeholder="0" /></Field>
    </div>
    <div style={ROW}>
      <Field label="Heure début"><TextInput value={s.heure_debut} onChange={(v) => set('heure_debut', v)} type="time" /></Field>
      <Field label="Acompte (€)"><TextInput value={s.acompte} onChange={(v) => set('acompte', v)} type="number" placeholder="0" /></Field>
    </div>
    <ToggleRow label="Contrat signé" value={s.contrat_signe} onChange={(v) => set('contrat_signe', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Conditions scène, matériel, setup..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const MusicBack: React.FC<{ s: any; set: (k: string, v: unknown) => void; isCeremony: boolean }> = ({ s, set, isCeremony }) => {
  const playlist: Array<{ title: string; artist: string; duration: string }> = s.playlist || [];

  const addTrack = () => {
    set('playlist', [...playlist, { title: '', artist: '', duration: '' }]);
  };

  const removeTrack = (idx: number) => {
    set('playlist', playlist.filter((_, i) => i !== idx));
  };

  const updateTrack = (idx: number, field: string, value: string) => {
    set('playlist', playlist.map((t, i) => i === idx ? { ...t, [field]: value } : t));
  };

  return (
    <div style={SECTION}>
      {/* Playlist header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <label style={LABEL}>Playlist — {playlist.length} morceau{playlist.length > 1 ? 'x' : ''}</label>
        <button
          onClick={(e) => { e.stopPropagation(); addTrack(); }}
          style={{
            display: 'flex', alignItems: 'center', gap: '4px',
            background: 'rgba(0,0,0,0.07)', border: 'none', borderRadius: '6px',
            padding: '4px 9px', cursor: 'pointer',
            fontFamily: 'Inter', fontSize: '10px', fontWeight: 600, color: 'rgba(0,0,0,0.6)',
          }}
        >
          <Plus size={11} /> Ajouter
        </button>
      </div>

      {playlist.length === 0 && (
        <div style={{ textAlign: 'center', padding: '16px 0', fontFamily: 'Cormorant Garamond, serif', fontSize: '13px', fontStyle: 'italic', color: 'rgba(0,0,0,0.3)' }}>
          Aucun morceau — cliquez "Ajouter"
        </div>
      )}

      {playlist.map((track, idx) => (
        <div key={idx} style={{ display: 'flex', gap: '6px', alignItems: 'center' }} onClick={(e) => e.stopPropagation()}>
          <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(0,0,0,0.3)', width: '14px', flexShrink: 0, textAlign: 'right' }}>{idx + 1}</span>
          <input
            type="text"
            value={track.title}
            onChange={(e) => updateTrack(idx, 'title', e.target.value)}
            placeholder="Titre..."
            style={{ ...INPUT, flex: 2, minWidth: 0 }}
            onClick={(e) => e.stopPropagation()}
          />
          <input
            type="text"
            value={track.artist}
            onChange={(e) => updateTrack(idx, 'artist', e.target.value)}
            placeholder="Artiste..."
            style={{ ...INPUT, flex: 1.5, minWidth: 0 }}
            onClick={(e) => e.stopPropagation()}
          />
          <input
            type="text"
            value={track.duration}
            onChange={(e) => updateTrack(idx, 'duration', e.target.value)}
            placeholder="3:45"
            style={{ ...INPUT, width: '40px', flexShrink: 0, padding: '7px 6px', textAlign: 'center' }}
            onClick={(e) => e.stopPropagation()}
          />
          <button
            onClick={(e) => { e.stopPropagation(); removeTrack(idx); }}
            style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'rgba(0,0,0,0.3)', padding: '4px', flexShrink: 0 }}
          >
            <Trash2 size={11} />
          </button>
        </div>
      ))}

      <Field label={isCeremony ? 'Moment de la cérémonie' : 'Style / Phase'} style={undefined}>
        <SelectInput value={s.moment} onChange={(v) => set('moment', v)} options={isCeremony ? [
          { value: '', label: 'Choisir...' },
          { value: 'prelude', label: 'Prélude (accueil invités)' },
          { value: 'cortege', label: 'Cortège d\'honneur' },
          { value: 'entree', label: 'Entrée de la mariée' },
          { value: 'alliances', label: 'Échange des alliances' },
          { value: 'sortie', label: 'Sortie des mariés' },
        ] : [
          { value: '', label: 'Choisir...' },
          { value: 'jazz', label: 'Jazz & Swing' },
          { value: 'classique', label: 'Classique & Lounge' },
          { value: 'variete', label: 'Variété Française' },
          { value: 'pop', label: 'Pop & Hits' },
          { value: 'electro', label: 'Électronique & Dance' },
        ]} />
      </Field>
      <Field label="Notes pour le DJ / musicien" style={undefined}>
        <TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Fondu, version live, instructions…" />
      </Field>
    </div>
  );
};

const GuestBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <div style={ROW}>
      <Field label="Nom de la table"><TextInput value={s.table_nom} onChange={(v) => set('table_nom', v)} placeholder="Table des Roses..." /></Field>
      <Field label="Couverts"><TextInput value={s.couverts} onChange={(v) => set('couverts', v)} type="number" placeholder="8" /></Field>
    </div>
    <Field label="Noms des invités" style={undefined}><TextArea value={s.noms} onChange={(v) => set('noms', v)} placeholder="Un invité par ligne..." rows={4} /></Field>
    <Field label="Allergènes / régimes" style={undefined}><TextInput value={s.allergenes} onChange={(v) => set('allergenes', v)} placeholder="Sans gluten, végétarien..." /></Field>
    <ToggleRow label="RSVP confirmé" value={s.rsvp} onChange={(v) => set('rsvp', v)} />
    <ToggleRow label="Hébergement prévu" value={s.hebergement} onChange={(v) => set('hebergement', v)} />
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Mobilité réduite, bébé, prise de vue..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const BudgetBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => {
  const estime = Number(s.estime) || 0;
  const reel = Number(s.reel) || 0;
  const acompte = Number(s.acompte) || 0;
  const solde = reel - acompte;
  const diff = reel - estime;

  return (
    <div style={SECTION}>
      <div style={ROW}>
        <Field label="Estimé (€)"><TextInput value={s.estime} onChange={(v) => set('estime', v)} type="number" placeholder="0" /></Field>
        <Field label="Réel (€)"><TextInput value={s.reel} onChange={(v) => set('reel', v)} type="number" placeholder="0" /></Field>
      </div>
      <div style={ROW}>
        <Field label="Acompte versé (€)"><TextInput value={s.acompte} onChange={(v) => set('acompte', v)} type="number" placeholder="0" /></Field>
        <Field label="Date règlement"><TextInput value={s.date_reglement} onChange={(v) => set('date_reglement', v)} type="date" /></Field>
      </div>
      {/* Computed balance */}
      <div style={{ background: 'rgba(0,0,0,0.03)', borderRadius: '8px', padding: '8px 10px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
          <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.6)' }}>Solde restant</span>
          <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 500, color: solde > 0 ? '#C33764' : '#38A169' }}>{solde} €</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.6)' }}>Écart estimé/réel</span>
          <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 500, color: diff > 0 ? '#C33764' : '#38A169' }}>
            {diff > 0 ? '+' : ''}{diff} €
          </span>
        </div>
      </div>
      <ToggleRow label="Payé intégralement" value={s.paye} onChange={(v) => set('paye', v)} />
      <Field label="Prestataire" style={undefined}><TextInput value={s.prestataire} onChange={(v) => set('prestataire', v)} placeholder="Nom..." /></Field>
      <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="N° facture, conditions..." /></Field>
      <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
    </div>
  );
};

const AdminBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <Field label="Type de document" style={undefined}>
      <SelectInput value={s.type_doc} onChange={(v) => set('type_doc', v)} options={[
        { value: '', label: 'Choisir...' },
        { value: 'bans', label: 'Publication des bans' },
        { value: 'contrat_mariage', label: 'Contrat de mariage' },
        { value: 'assurance', label: 'Assurance mariage' },
        { value: 'guso', label: 'Contrats GUSO artistes' },
        { value: 'rsvp', label: 'RSVP / Convocations' },
        { value: 'changement_nom', label: 'Changement de nom' },
        { value: 'livret_famille', label: 'Livret de famille' },
        { value: 'regime', label: 'Régime matrimonial' },
      ]} />
    </Field>
    <Field label="Statut" style={undefined}>
      <SelectInput value={s.statut} onChange={(v) => set('statut', v)} options={[
        { value: '', label: 'Choisir...' },
        { value: 'todo', label: '🔲 À faire' },
        { value: 'inprogress', label: '🔄 En cours' },
        { value: 'done', label: '✅ Complété' },
      ]} />
    </Field>
    <Field label="Date limite" style={undefined}><TextInput value={s.date_limite} onChange={(v) => set('date_limite', v)} type="date" /></Field>
    <Field label="Organisme / Contact" style={undefined}><TextInput value={s.organisme} onChange={(v) => set('organisme', v)} placeholder="Mairie, notaire, GUSO..." /></Field>
    <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Démarches, documents requis..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const HoneymoonBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => (
  <div style={SECTION}>
    <Field label="Destination" style={undefined}><TextInput value={s.destination} onChange={(v) => set('destination', v)} placeholder="Maldives, Japon..." /></Field>
    <div style={ROW}>
      <Field label="Départ"><TextInput value={s.date_depart} onChange={(v) => set('date_depart', v)} type="date" /></Field>
      <Field label="Retour"><TextInput value={s.date_retour} onChange={(v) => set('date_retour', v)} type="date" /></Field>
    </div>
    <Field label="Hébergement" style={undefined}><TextInput value={s.hotel} onChange={(v) => set('hotel', v)} placeholder="Nom de l'hôtel..." /></Field>
    <div style={ROW}>
      <Field label="Budget (€)"><TextInput value={s.budget} onChange={(v) => set('budget', v)} type="number" placeholder="0" /></Field>
      <Field label="Réservation"><TextInput value={s.reference} onChange={(v) => set('reference', v)} placeholder="Référence..." /></Field>
    </div>
    <ToggleRow label="Réservation confirmée" value={s.confirme} onChange={(v) => set('confirme', v)} />
    <Field label="Activités / Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Excursions, restaurants, spa..." /></Field>
    <MediaImport value={s.media || ''} onChange={(v) => set('media', v)} />
  </div>
);

const RetroPlanningBack: React.FC<{ s: any; set: (k: string, v: unknown) => void }> = ({ s, set }) => {
  const tasks: string[] = s.tasks || [];
  const done: boolean[] = s.done || [];

  const toggleTask = (i: number) => {
    const newDone = [...done];
    newDone[i] = !newDone[i];
    set('done', newDone);
  };

  const addTask = () => {
    set('tasks', [...tasks, '']);
    set('done', [...done, false]);
  };

  const updateTask = (i: number, v: string) => {
    const newTasks = [...tasks];
    newTasks[i] = v;
    set('tasks', newTasks);
  };

  return (
    <div style={SECTION} onClick={(e) => e.stopPropagation()}>
      <Field label="Période" style={undefined}><TextInput value={s.periode} onChange={(v) => set('periode', v)} placeholder="Ex: 12-9 mois avant" /></Field>
      <Field label="Responsable" style={undefined}><TextInput value={s.responsable} onChange={(v) => set('responsable', v)} placeholder="Marie, Antoine, les deux..." /></Field>

      <div>
        <label style={LABEL}>Tâches ({tasks.filter((_, i) => done[i]).length}/{tasks.length} complétées)</label>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', maxHeight: '160px', overflowY: 'auto' }}>
          {tasks.map((task, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <input
                type="checkbox"
                checked={!!done[i]}
                onChange={() => toggleTask(i)}
                style={{ flexShrink: 0, width: '14px', height: '14px', cursor: 'pointer' }}
              />
              <input
                type="text"
                value={task}
                onChange={(e) => updateTask(i, e.target.value)}
                style={{ ...INPUT, padding: '5px 8px', fontSize: '12px', textDecoration: done[i] ? 'line-through' : 'none', opacity: done[i] ? 0.5 : 1 }}
                placeholder="Tâche..."
              />
            </div>
          ))}
        </div>
        <button
          onClick={addTask}
          style={{
            marginTop: '6px', width: '100%', padding: '6px',
            background: 'rgba(0,0,0,0.04)', border: '1.5px dashed rgba(0,0,0,0.12)',
            borderRadius: '8px', cursor: 'pointer', fontFamily: 'Inter', fontSize: '11px',
            color: 'rgba(0,0,0,0.4)',
          }}
        >
          + Ajouter une tâche
        </button>
      </div>

      <Field label="Notes" style={undefined}><TextArea value={s.notes} onChange={(v) => set('notes', v)} placeholder="Priorités, blocages..." /></Field>
    </div>
  );
};

// ─── main export ──────────────────────────────────────────────────────────────

export const CardBack: React.FC<CardBackProps> = ({ card, settings, onChange, onClose, globalTexture }) => {
  const s = settings || {};
  const set = (k: string, v: unknown) => onChange(k, v);
  const activeTexture = s.texture ?? globalTexture ?? '';
  const textureStyle = TEXTURE_OVERLAYS[activeTexture] ?? {};

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        background: '#FAF8F4',
        borderRadius: '24px',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        position: 'relative',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Texture overlay */}
      {activeTexture && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: '24px',
            pointerEvents: 'none',
            zIndex: 0,
            ...textureStyle,
          }}
        />
      )}
      {/* Header */}
      <div
        style={{
          padding: '12px 14px 10px',
          borderBottom: '1px solid rgba(0,0,0,0.07)',
          flexShrink: 0,
          position: 'relative',
          zIndex: 1,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '8px' }}>
          <div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '-0.01em', color: '#000', margin: 0, lineHeight: 1.1 }}>
              {card.name}
            </p>
            <p style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(0,0,0,0.35)', margin: '2px 0 0', letterSpacing: '0.04em' }}>
              {card.subtitle}
            </p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onClose(); }}
            style={{ display: 'flex', alignItems: 'center', gap: '3px', background: 'rgba(0,0,0,0.06)', border: 'none', cursor: 'pointer', fontFamily: 'Inter', fontSize: '10px', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'rgba(0,0,0,0.5)', padding: '5px 9px', borderRadius: '50px' }}
          >
            <ChevronLeft size={11} /> Recto
          </button>
        </div>
        {/* Status selector */}
        <div style={{ display: 'flex', gap: '4px' }} onClick={(e) => e.stopPropagation()}>
          {STATUS_OPTIONS.map((opt) => {
            const active = (s.status || 'todo') === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => set('status', opt.id)}
                style={{
                  display: 'flex', alignItems: 'center', gap: '4px',
                  padding: '3px 8px', borderRadius: '50px', border: 'none', cursor: 'pointer',
                  fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, letterSpacing: '0.04em',
                  background: active ? opt.bg : 'rgba(0,0,0,0.04)',
                  color: active ? opt.color : 'rgba(0,0,0,0.3)',
                  transition: 'all 0.15s',
                }}
              >
                <opt.Icon size={8} />
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable form */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 20px', position: 'relative', zIndex: 1 }}>
        {card.type === 'programme' && <ProgrammeBack s={s} set={set} />}
        {card.type === 'venue' && <VenueBack s={s} set={set} />}
        {card.type === 'photo-video' && <PhotoVideoBack s={s} set={set} />}
        {card.type === 'beauty' && <BeautyBack s={s} set={set} />}
        {card.type === 'catering' && <CateringBack s={s} set={set} />}
        {card.type === 'flowers' && <FlowersBack s={s} set={set} />}
        {card.type === 'artist' && <ArtistBack s={s} set={set} />}
        {card.type === 'animation' && <AnimationBack s={s} set={set} />}
        {card.type === 'music-ceremony' && <MusicBack s={s} set={set} isCeremony />}
        {card.type === 'music-soiree' && <MusicBack s={s} set={set} isCeremony={false} />}
        {card.type === 'guest' && <GuestBack s={s} set={set} />}
        {card.type === 'budget' && <BudgetBack s={s} set={set} />}
        {card.type === 'admin' && <AdminBack s={s} set={set} />}
        {card.type === 'honeymoon' && <HoneymoonBack s={s} set={set} />}
        {card.type === 'retroplanning' && <RetroPlanningBack s={s} set={set} />}
      </div>
    </div>
  );
};
