import React, { useEffect, useRef } from 'react';
import { Play, Pause, Disc3 } from 'lucide-react';
import type { WeddingCard } from '../types';

interface MusicFrontProps {
  card: WeddingCard;
  isPlaying: boolean;
  onTogglePlay: (e: React.MouseEvent) => void;
  settings: Record<string, any>;
}

const BAR_COUNT = 24;

export const MusicFront: React.FC<MusicFrontProps> = ({ card, isPlaying, onTogglePlay, settings }) => {
  const barsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!barsRef.current) return;
    const bars = barsRef.current.querySelectorAll<HTMLDivElement>('.wave-bar');
    bars.forEach((bar, i) => {
      const dur = 0.4 + Math.random() * 0.6;
      const delay = (i / BAR_COUNT) * 0.4;
      bar.style.animationDuration = `${dur}s`;
      bar.style.animationDelay = `${delay}s`;
    });
  }, []);

  const title = settings?.title || card.name;
  const artist = settings?.artist || card.subtitle;
  const duration = settings?.duration || '3:30';
  const moment = settings?.moment || '';

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        borderRadius: '24px',
        overflow: 'hidden',
        position: 'relative',
        background: card.gradient || '#1a1a2e',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        padding: '20px',
      }}
    >
      {/* Spinning disc icon */}
      <div
        style={{
          position: 'absolute',
          top: '28px',
          right: '24px',
          opacity: 0.15,
        }}
      >
        <Disc3
          size={120}
          color="#fff"
          style={{
            animation: isPlaying ? 'spin 4s linear infinite' : 'none',
          }}
        />
      </div>

      {/* Subtle gradient overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, transparent 30%, rgba(0,0,0,0.6) 100%)',
          borderRadius: '24px',
        }}
      />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 2 }}>
        {/* Waveform bars */}
        <div
          ref={barsRef}
          style={{
            display: 'flex',
            alignItems: 'flex-end',
            gap: '2px',
            height: '32px',
            marginBottom: '14px',
          }}
        >
          {Array.from({ length: BAR_COUNT }).map((_, i) => {
            const baseHeight = 4 + Math.random() * 20;
            return (
              <div
                key={i}
                className="wave-bar"
                style={{
                  flex: 1,
                  borderRadius: '2px',
                  background: 'rgba(255,255,255,0.7)',
                  height: isPlaying ? undefined : `${baseHeight}px`,
                  minHeight: '3px',
                  maxHeight: '28px',
                  animation: isPlaying ? `waveBar 0.5s ease-in-out infinite alternate` : 'none',
                  transform: `scaleY(${isPlaying ? 1 : baseHeight / 28})`,
                  transformOrigin: 'bottom',
                  transition: 'transform 0.3s ease',
                }}
              />
            );
          })}
        </div>

        {/* Track info */}
        <div style={{ marginBottom: '12px' }}>
          {moment && (
            <span
              style={{
                display: 'inline-block',
                fontFamily: 'Inter, sans-serif',
                fontSize: '10px',
                color: 'rgba(255,255,255,0.6)',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                marginBottom: '4px',
              }}
            >
              {moment}
            </span>
          )}
          <p
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: '22px',
              fontWeight: 400,
              color: '#fff',
              margin: 0,
              lineHeight: 1.1,
              letterSpacing: '-0.01em',
            }}
          >
            {title}
          </p>
          <p
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: '12px',
              color: 'rgba(255,255,255,0.65)',
              margin: '3px 0 0',
            }}
          >
            {artist}
          </p>
        </div>

        {/* Controls row */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <button
            onClick={onTogglePlay}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              border: 'none',
              background: 'rgba(255,255,255,0.9)',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'transform 0.15s, background 0.15s',
              flexShrink: 0,
            }}
            onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.08)')}
            onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
          >
            {isPlaying
              ? <Pause size={16} fill="rgba(0,0,0,0.8)" color="rgba(0,0,0,0.8)" />
              : <Play size={16} fill="rgba(0,0,0,0.8)" color="rgba(0,0,0,0.8)" style={{ marginLeft: '2px' }} />
            }
          </button>

          <span
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: '11px',
              color: 'rgba(255,255,255,0.5)',
            }}
          >
            {duration}
          </span>
        </div>
      </div>

      {/* CSS for spin + wave */}
      <style>{`
        @keyframes waveBar {
          from { transform: scaleY(0.15); }
          to { transform: scaleY(1); }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
