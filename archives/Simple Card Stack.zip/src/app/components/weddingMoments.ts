export type MomentSettings = {
  time: string;
  lieu: string;
  invites: number;
  musique: boolean;
  dresscode: string;
  notes: string;
};

export type WeddingMoment = {
  id: number;
  name: string;
  subtitle: string;
  defaultTime: string;
  image: string;
  icon: string;
  notesPlaceholder: string;
  lieuPlaceholder: string;
};

export const weddingMoments: WeddingMoment[] = [
  {
    id: 1,
    name: "Préparatifs",
    subtitle: "La mise en beauté",
    defaultTime: "09:00",
    image: "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=800&q=80",
    icon: "✦",
    notesPlaceholder: "Coiffeur, maquilleur, accessoires...",
    lieuPlaceholder: "Hôtel, domicile...",
  },
  {
    id: 2,
    name: "Cérémonie",
    subtitle: "L'échange des vœux",
    defaultTime: "14:30",
    image: "https://images.unsplash.com/photo-1576694667642-6f289dd54187?w=800&q=80",
    icon: "♡",
    notesPlaceholder: "Type de cérémonie, officiant, vœux...",
    lieuPlaceholder: "Église, salle, jardin...",
  },
  {
    id: 3,
    name: "Cocktail",
    subtitle: "Le temps de la joie",
    defaultTime: "16:30",
    image: "https://images.unsplash.com/photo-1780432478362-96fac052084a?w=800&q=80",
    icon: "◇",
    notesPlaceholder: "Animations, décoration, thème...",
    lieuPlaceholder: "Terrasse, jardin...",
  },
  {
    id: 4,
    name: "Vin d'honneur",
    subtitle: "La célébration",
    defaultTime: "17:30",
    image: "https://images.unsplash.com/photo-1527529482837-4698179dc6ce?w=800&q=80",
    icon: "✿",
    notesPlaceholder: "Signature cocktail, canapés, discours...",
    lieuPlaceholder: "Château, domaine...",
  },
  {
    id: 5,
    name: "Dîner",
    subtitle: "Le banquet de noces",
    defaultTime: "20:00",
    image: "https://images.unsplash.com/photo-1782038522729-47b97948ab11?w=800&q=80",
    icon: "◈",
    notesPlaceholder: "Menu, placement, discours, animation...",
    lieuPlaceholder: "Grande salle, salle des fêtes...",
  },
  {
    id: 6,
    name: "Soirée",
    subtitle: "La fête",
    defaultTime: "23:00",
    image: "https://images.unsplash.com/photo-1624067056935-593eb6595294?w=800&q=80",
    icon: "★",
    notesPlaceholder: "DJ, live band, feux d'artifice...",
    lieuPlaceholder: "Salle de réception...",
  },
];

export const defaultSettings = (moment: WeddingMoment): MomentSettings => ({
  time: moment.defaultTime,
  lieu: "",
  invites: 0,
  musique: false,
  dresscode: "",
  notes: "",
});
