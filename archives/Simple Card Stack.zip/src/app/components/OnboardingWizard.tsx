import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Check, Heart } from 'lucide-react';

export interface OnboardingData {
  coupleName: string;
  weddingDate: string;
  style: 'classique' | 'boheme' | 'champetre' | 'urbain' | 'luxe';
  guestCount: number;
  venue: string;
  hasReligiousCeremony: boolean;
}

interface OnboardingWizardProps {
  onComplete: (data: OnboardingData) => void;
  onSkip: () => void;
}

const STYLES: { key: OnboardingData['style']; label: string; gradient: string }[] = [
  { key: 'classique', label: 'Classique', gradient: 'linear-gradient(135deg, #f5f0e8, #e8d5b0)' },
  { key: 'boheme', label: 'Bohème', gradient: 'linear-gradient(135deg, #f0e8d8, #d4a882)' },
  { key: 'champetre', label: 'Champêtre', gradient: 'linear-gradient(135deg, #d4e8c2, #8ab87a)' },
  { key: 'urbain', label: 'Urbain', gradient: 'linear-gradient(135deg, #c8c8d4, #5a5a6e)' },
  { key: 'luxe', label: 'Luxe', gradient: 'linear-gradient(135deg, #f0d080, #c4956a)' },
];

function formatCountdown(dateStr: string): string {
  if (!dateStr) return '';
  const target = new Date(dateStr);
  if (isNaN(target.getTime())) return '';
  const now = new Date();
  const diffMs = target.getTime() - now.getTime();
  if (diffMs < 0) return 'Cette date est passée';
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  if (days === 0) return "C'est aujourd'hui !";
  if (days === 1) return 'Demain !';
  if (days < 30) return `Dans ${days} jours`;
  const months = Math.floor(days / 30);
  if (months < 12) return `Dans ${months} mois`;
  const years = Math.floor(months / 12);
  const remMonths = months % 12;
  if (remMonths === 0) return `Dans ${years} an${years > 1 ? 's' : ''}`;
  return `Dans ${years} an${years > 1 ? 's' : ''} et ${remMonths} mois`;
}

export default function OnboardingWizard({ onComplete, onSkip }: OnboardingWizardProps) {
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [firstName1, setFirstName1] = useState('');
  const [firstName2, setFirstName2] = useState('');
  const [weddingDate, setWeddingDate] = useState('');
  const [style, setStyle] = useState<OnboardingData['style']>('classique');
  const [guestCount, setGuestCount] = useState(100);
  const [venue, setVenue] = useState('');
  const [hasReligiousCeremony, setHasReligiousCeremony] = useState(false);

  const totalSteps = 5;

  const goNext = () => {
    if (step < totalSteps - 1) {
      setDirection(1);
      setStep((s) => s + 1);
    }
  };

  const goPrev = () => {
    if (step > 0) {
      setDirection(-1);
      setStep((s) => s - 1);
    }
  };

  const handleComplete = () => {
    const coupleName =
      firstName1 && firstName2
        ? `${firstName1} & ${firstName2}`
        : firstName1 || firstName2 || 'Nos Amoureux';
    onComplete({
      coupleName,
      weddingDate,
      style,
      guestCount,
      venue,
      hasReligiousCeremony,
    });
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '12px 16px',
    border: '1px solid rgba(0,0,0,0.12)',
    borderRadius: 10,
    fontSize: 16,
    fontFamily: 'Inter, sans-serif',
    outline: 'none',
    background: '#fafafa',
    color: '#1a1a2e',
    boxSizing: 'border-box',
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 13,
    fontWeight: 600,
    color: 'rgba(0,0,0,0.45)',
    marginBottom: 6,
    display: 'block',
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
  };

  const steps = [
    <div
      key="welcome"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 20,
        textAlign: 'center',
        paddingTop: 16,
      }}
    >
      <div
        style={{
          width: 72,
          height: 72,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #C4956A, #e8b887)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 8,
        }}
      >
        <Heart size={32} color="#fff" fill="#fff" />
      </div>
      <div>
        <h1
          style={{
            fontSize: 36,
            fontWeight: 800,
            color: '#1a1a2e',
            margin: 0,
            lineHeight: 1.1,
            fontFamily: 'Inter, sans-serif',
          }}
        >
          Le Monde Aime
        </h1>
        <p
          style={{
            fontSize: 16,
            color: 'rgba(0,0,0,0.5)',
            marginTop: 12,
            lineHeight: 1.6,
            maxWidth: 340,
          }}
        >
          Votre compagnon de mariage pour organiser le plus beau jour de votre vie.
        </p>
      </div>
      <button
        onClick={goNext}
        style={{
          marginTop: 8,
          padding: '14px 40px',
          background: 'linear-gradient(135deg, #C4956A, #e8b887)',
          border: 'none',
          borderRadius: 12,
          fontSize: 16,
          fontWeight: 700,
          color: '#fff',
          cursor: 'pointer',
          fontFamily: 'Inter, sans-serif',
          letterSpacing: '0.02em',
        }}
      >
        Commencer
      </button>
    </div>,

    <div key="names" style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ textAlign: 'center' }}>
        <h2
          style={{
            fontSize: 26,
            fontWeight: 800,
            color: '#1a1a2e',
            margin: 0,
            fontFamily: 'Inter, sans-serif',
          }}
        >
          Vos noms
        </h2>
        <p style={{ fontSize: 14, color: 'rgba(0,0,0,0.45)', marginTop: 6 }}>
          Comment vous appelez-vous ?
        </p>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <label style={labelStyle}>Prénom 1</label>
          <input
            style={inputStyle}
            type="text"
            placeholder="Alice"
            value={firstName1}
            onChange={(e) => setFirstName1(e.target.value)}
          />
        </div>
        <div>
          <label style={labelStyle}>Prénom 2</label>
          <input
            style={inputStyle}
            type="text"
            placeholder="Baptiste"
            value={firstName2}
            onChange={(e) => setFirstName2(e.target.value)}
          />
        </div>
        {(firstName1 || firstName2) && (
          <div
            style={{
              textAlign: 'center',
              fontSize: 22,
              fontWeight: 800,
              color: '#C4956A',
              fontFamily: "'Cormorant Garamond', serif",
              paddingTop: 4,
            }}
          >
            {[firstName1, firstName2].filter(Boolean).join(' & ')}
          </div>
        )}
      </div>
    </div>,

    <div key="date" style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ textAlign: 'center' }}>
        <h2
          style={{
            fontSize: 26,
            fontWeight: 800,
            color: '#1a1a2e',
            margin: 0,
            fontFamily: 'Inter, sans-serif',
          }}
        >
          La date
        </h2>
        <p style={{ fontSize: 14, color: 'rgba(0,0,0,0.45)', marginTop: 6 }}>
          Quand célébrez-vous votre union ?
        </p>
      </div>
      <div>
        <label style={labelStyle}>Date du mariage</label>
        <input
          style={{ ...inputStyle, fontSize: 18, textAlign: 'center', fontWeight: 600 }}
          type="date"
          value={weddingDate}
          onChange={(e) => setWeddingDate(e.target.value)}
        />
      </div>
      {weddingDate && (
        <div
          style={{
            background: 'linear-gradient(135deg, rgba(196,149,106,0.1), rgba(232,184,135,0.08))',
            border: '1px solid rgba(196,149,106,0.25)',
            borderRadius: 12,
            padding: '16px 20px',
            textAlign: 'center',
          }}
        >
          <div style={{ fontSize: 13, color: 'rgba(0,0,0,0.4)', marginBottom: 4 }}>
            Compte à rebours
          </div>
          <div
            style={{
              fontSize: 22,
              fontWeight: 800,
              color: '#C4956A',
              fontFamily: 'Inter, sans-serif',
            }}
          >
            {formatCountdown(weddingDate)}
          </div>
        </div>
      )}
    </div>,

    <div key="style" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ textAlign: 'center' }}>
        <h2
          style={{
            fontSize: 26,
            fontWeight: 800,
            color: '#1a1a2e',
            margin: 0,
            fontFamily: 'Inter, sans-serif',
          }}
        >
          Le style
        </h2>
        <p style={{ fontSize: 14, color: 'rgba(0,0,0,0.45)', marginTop: 6 }}>
          Quelle ambiance vous correspond ?
        </p>
      </div>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'center' }}>
        {STYLES.map((s) => (
          <button
            key={s.key}
            onClick={() => setStyle(s.key)}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 8,
              background: 'none',
              border: style === s.key ? '2px solid #C4956A' : '2px solid transparent',
              borderRadius: 12,
              padding: '10px 8px',
              cursor: 'pointer',
              outline: 'none',
              transition: 'border-color 0.2s',
            }}
          >
            <div
              style={{
                width: 64,
                height: 64,
                borderRadius: 10,
                background: s.gradient,
                boxShadow:
                  style === s.key
                    ? '0 0 0 3px rgba(196,149,106,0.3)'
                    : '0 2px 8px rgba(0,0,0,0.1)',
                transition: 'box-shadow 0.2s',
              }}
            />
            <span
              style={{
                fontSize: 12,
                fontWeight: style === s.key ? 700 : 500,
                color: style === s.key ? '#C4956A' : 'rgba(0,0,0,0.6)',
                fontFamily: 'Inter, sans-serif',
              }}
            >
              {s.label}
            </span>
          </button>
        ))}
      </div>
    </div>,

    <div key="infos" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ textAlign: 'center' }}>
        <h2
          style={{
            fontSize: 26,
            fontWeight: 800,
            color: '#1a1a2e',
            margin: 0,
            fontFamily: 'Inter, sans-serif',
          }}
        >
          Infos pratiques
        </h2>
        <p style={{ fontSize: 14, color: 'rgba(0,0,0,0.45)', marginTop: 6 }}>
          Quelques détails supplémentaires
        </p>
      </div>
      <div>
        <label style={labelStyle}>
          Nombre d'invités — <span style={{ color: '#C4956A' }}>{guestCount}</span>
        </label>
        <input
          type="range"
          min={10}
          max={500}
          value={guestCount}
          onChange={(e) => setGuestCount(Number(e.target.value))}
          style={{ width: '100%', accentColor: '#C4956A' }}
        />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: 12,
            color: 'rgba(0,0,0,0.35)',
            marginTop: 4,
          }}
        >
          <span>10</span>
          <span>500</span>
        </div>
      </div>
      <div>
        <label style={labelStyle}>Lieu de réception</label>
        <input
          style={inputStyle}
          type="text"
          placeholder="Château de Versailles..."
          value={venue}
          onChange={(e) => setVenue(e.target.value)}
        />
      </div>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: '#fafafa',
          border: '1px solid rgba(0,0,0,0.12)',
          borderRadius: 10,
          padding: '14px 16px',
          cursor: 'pointer',
        }}
        onClick={() => setHasReligiousCeremony((v) => !v)}
      >
        <span style={{ fontSize: 15, fontWeight: 500, color: '#1a1a2e' }}>
          Cérémonie religieuse
        </span>
        <div
          style={{
            width: 44,
            height: 24,
            borderRadius: 12,
            background: hasReligiousCeremony ? '#C4956A' : 'rgba(0,0,0,0.15)',
            position: 'relative',
            transition: 'background 0.25s',
            flexShrink: 0,
          }}
        >
          <div
            style={{
              position: 'absolute',
              top: 2,
              left: hasReligiousCeremony ? 22 : 2,
              width: 20,
              height: 20,
              borderRadius: '50%',
              background: '#fff',
              transition: 'left 0.25s',
              boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
            }}
          />
        </div>
      </div>
    </div>,
  ];

  const isFirst = step === 0;
  const isLast = step === totalSteps - 1;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(12,8,24,0.92)',
        zIndex: 9998,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      <div
        style={{
          background: '#ffffff',
          borderRadius: 24,
          padding: 40,
          width: 560,
          maxWidth: '95vw',
          maxHeight: 520,
          display: 'flex',
          flexDirection: 'column',
          gap: 28,
          boxShadow: '0 32px 80px rgba(0,0,0,0.4)',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8 }}>
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              style={{
                width: i === step ? 24 : 8,
                height: 8,
                borderRadius: 4,
                background: i === step ? '#C4956A' : i < step ? 'rgba(196,149,106,0.4)' : 'rgba(0,0,0,0.1)',
                transition: 'all 0.3s',
              }}
            />
          ))}
        </div>

        <div style={{ flex: 1, overflow: 'hidden', position: 'relative', minHeight: 320 }}>
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={step}
              custom={direction}
              initial={{ x: direction * 40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: direction * -40, opacity: 0 }}
              transition={{ duration: 0.28, ease: 'easeInOut' }}
              style={{ position: 'absolute', inset: 0, overflowY: 'auto' }}
            >
              {steps[step]}
            </motion.div>
          </AnimatePresence>
        </div>

        {!isFirst && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
            <button
              onClick={goPrev}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '11px 20px',
                background: 'rgba(0,0,0,0.06)',
                border: 'none',
                borderRadius: 10,
                fontSize: 14,
                fontWeight: 600,
                color: 'rgba(0,0,0,0.5)',
                cursor: 'pointer',
                fontFamily: 'Inter, sans-serif',
              }}
            >
              <ChevronLeft size={16} />
              Précédent
            </button>

            <button
              onClick={onSkip}
              style={{
                background: 'none',
                border: 'none',
                fontSize: 13,
                color: 'rgba(0,0,0,0.3)',
                cursor: 'pointer',
                padding: '4px 8px',
                fontFamily: 'Inter, sans-serif',
              }}
            >
              Passer
            </button>

            {isLast ? (
              <button
                onClick={handleComplete}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '11px 24px',
                  background: 'linear-gradient(135deg, #C4956A, #e8b887)',
                  border: 'none',
                  borderRadius: 10,
                  fontSize: 14,
                  fontWeight: 700,
                  color: '#fff',
                  cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                <Check size={16} />
                Terminer
              </button>
            ) : (
              <button
                onClick={goNext}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '11px 24px',
                  background: 'linear-gradient(135deg, #C4956A, #e8b887)',
                  border: 'none',
                  borderRadius: 10,
                  fontSize: 14,
                  fontWeight: 700,
                  color: '#fff',
                  cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                }}
              >
                Suivant
                <ChevronRight size={16} />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
