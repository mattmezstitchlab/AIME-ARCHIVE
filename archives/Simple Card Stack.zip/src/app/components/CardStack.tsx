import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { RotateCcw } from 'lucide-react';
import { ICON_MAP } from '../utils/iconMap';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CardBack, STATUS_DOT_COLOR } from './CardBack';
import { MusicFront } from './MusicFront';
import type { WeddingCard } from '../types';
import type { AnimationSettings } from './SettingsPanel';

const NUM_VISIBLE = 4;

const swipePower = (offset: number, velocity: number) => Math.abs(offset) * velocity;

const cardVariants = (settings: AnimationSettings) => ({
  visible: (i: number) => ({
    opacity: 1,
    zIndex: [4, 3, 2, 1][i] ?? 0,
    scale: [1, 0.91, 0.85, 0.79][i] ?? 0.75,
    y: [0, -10, 0, 10][i] ?? 16,
    rotate: [0, 2, 4, 6][i] ?? 8,
    x: [0, 28, 44, 58][i] ?? 70,
    transition: {
      zIndex: { delay: settings.zIndexDelay },
      scale: { type: 'spring', duration: settings.springDuration, bounce: settings.springBounce },
      y: { type: 'spring', duration: settings.springDuration, bounce: settings.springBounce },
      x: { type: 'spring', duration: settings.xSpringDuration, bounce: settings.xSpringBounce },
    },
  }),
  exit: { opacity: 0, scale: 0.5, y: 50, transition: { duration: 0.2 } },
});

interface CardStackProps {
  cards: WeddingCard[];
  cardSettings: Record<string, Record<string, any>>;
  onCardSettingChange: (cardId: string, key: string, value: unknown) => void;
  animSettings: AnimationSettings;
  playingTrackId: string | null;
  onTogglePlay: (cardId: string) => void;
  globalTexture?: string;
}

export const CardStack: React.FC<CardStackProps> = ({
  cards,
  cardSettings,
  onCardSettingChange,
  animSettings,
  playingTrackId,
  onTogglePlay,
  globalTexture,
}) => {
  const [startIndex, setStartIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const hasDragged = useRef(false);
  const numItems = cards.length;

  const visibleIndices = Array.from({ length: Math.min(NUM_VISIBLE, numItems) }, (_, i) =>
    (startIndex + i) % numItems
  );

  const paginate = () => {
    setStartIndex((prev) => (prev + 1) % numItems);
    setIsFlipped(false);
  };

  const variants = cardVariants(animSettings);
  const isMusic = (c: WeddingCard) => c.type === 'music-ceremony' || c.type === 'music-soiree';

  return (
    <div
      style={{ width: '323px', height: '484px', position: 'relative' }}
      onMouseDown={(e) => e.stopPropagation()}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <AnimatePresence initial={false}>
        {visibleIndices.map((cardIndex, i) => {
          const card = cards[cardIndex];
          const isTop = i === 0;
          const settings = cardSettings[card.id] || {};
          const flipped = isTop && isFlipped;

          return (
            <motion.div
              key={card.id}
              custom={i}
              variants={variants}
              initial="exit"
              animate="visible"
              exit="exit"
              drag={isTop && !isFlipped}
              dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
              dragElastic={animSettings.dragElastic}
              onDragStart={() => { hasDragged.current = true; }}
              onDragEnd={(_, { offset, velocity }) => {
                const swipe = swipePower(offset.x, velocity.x);
                if (swipe < -animSettings.swipeConfidenceThreshold || swipe > animSettings.swipeConfidenceThreshold) {
                  paginate();
                }
                setTimeout(() => { hasDragged.current = false; }, 80);
              }}
              onClick={() => {
                if (!hasDragged.current && isTop && !isMusic(card)) {
                  setIsFlipped((f) => !f);
                }
              }}
              style={{
                position: 'absolute',
                width: '323px',
                height: '484px',
                borderRadius: '24px',
                cursor: isTop ? (isFlipped ? 'default' : 'pointer') : 'default',
                perspective: '1200px',
                boxShadow: '0px 20px 12px rgba(0,0,0,0.05),0px 9px 9px rgba(0,0,0,0.09),0px 2px 5px rgba(0,0,0,0.1)',
              }}
            >
              {/* Flip wrapper */}
              <motion.div
                animate={{ rotateY: flipped ? 180 : 0 }}
                transition={{ type: 'spring', stiffness: 260, damping: 32 }}
                style={{
                  transformStyle: 'preserve-3d',
                  width: '100%',
                  height: '100%',
                  position: 'relative',
                }}
              >
                {/* ── FRONT ── */}
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    backfaceVisibility: 'hidden',
                    WebkitBackfaceVisibility: 'hidden',
                    borderRadius: '24px',
                    overflow: 'hidden',
                  }}
                >
                  {isMusic(card) ? (
                    <MusicFront
                      card={card}
                      isPlaying={playingTrackId === card.id}
                      onTogglePlay={(e) => { e.stopPropagation(); onTogglePlay(card.id); }}
                      settings={settings}
                    />
                  ) : (
                    <CardFront card={card} settings={settings} isTop={isTop} isFlipped={isFlipped} cardIndex={cardIndex} />
                  )}
                </div>

                {/* ── BACK ── */}
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    backfaceVisibility: 'hidden',
                    WebkitBackfaceVisibility: 'hidden',
                    transform: 'rotateY(180deg)',
                    borderRadius: '24px',
                    overflow: 'hidden',
                  }}
                >
                  <CardBack
                    card={card}
                    settings={settings}
                    onChange={(key, value) => onCardSettingChange(card.id, key, value)}
                    onClose={() => setIsFlipped(false)}
                    globalTexture={globalTexture}
                  />
                </div>
              </motion.div>
            </motion.div>
          );
        })}
      </AnimatePresence>

      {/* Card counter */}
      {numItems > 1 && (
        <div
          style={{
            position: 'absolute',
            bottom: '-28px',
            left: 0,
            right: 0,
            display: 'flex',
            justifyContent: 'center',
            gap: '5px',
          }}
        >
          {cards.map((_, i) => (
            <div
              key={i}
              onClick={() => { setStartIndex(i); setIsFlipped(false); }}
              style={{
                width: i === startIndex ? '18px' : '5px',
                height: '5px',
                borderRadius: '50px',
                background: i === startIndex ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.35)',
                cursor: 'pointer',
                transition: 'all 0.25s ease',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// ── Card front ───────────────────────────────────────────────────────────────

const CardFront: React.FC<{
  card: WeddingCard;
  settings: Record<string, any>;
  isTop: boolean;
  isFlipped: boolean;
  cardIndex: number;
}> = ({ card, settings, isTop, isFlipped, cardIndex }) => {
  const CardIcon = ICON_MAP[card.icon] ?? ICON_MAP['Sparkles'];
  const statusColor = STATUS_DOT_COLOR[settings.status || 'todo'];
  return (
    <div style={{ width: '100%', height: '100%', borderRadius: '24px', overflow: 'hidden', position: 'relative' }}>
      {/* Background */}
      {card.image ? (
        <ImageWithFallback
          src={card.image}
          alt={card.name}
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
        />
      ) : (
        <div style={{ width: '100%', height: '100%', background: card.gradient }} />
      )}

      {/* Gradient overlay — stronger at bottom for legibility */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg,rgba(0,0,0,0.12) 0%,rgba(0,0,0,0) 30%,rgba(0,0,0,0.55) 70%,rgba(0,0,0,0.82) 100%)',
          borderRadius: '24px',
        }}
      />

      {/* Status dot */}
      {settings.status && settings.status !== 'todo' && (
        <div style={{ position: 'absolute', top: '13px', left: '13px', width: '8px', height: '8px', borderRadius: '50%', background: statusColor, zIndex: 3, boxShadow: `0 0 8px ${statusColor}88` }} />
      )}

      {/* Top row: index + flip hint */}
      <div style={{ position: 'absolute', top: '16px', left: '28px', right: '14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: '10px',
            fontWeight: 600,
            color: 'rgba(255,255,255,0.45)',
            letterSpacing: '0.04em',
          }}
        >
          {String(cardIndex + 1).padStart(2, '0')}
        </span>

        {isTop && !isFlipped && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              background: 'rgba(255,255,255,0.12)',
              backdropFilter: 'blur(12px)',
              WebkitBackdropFilter: 'blur(12px)',
              borderRadius: '50px',
              padding: '4px 9px',
            }}
          >
            <RotateCcw size={9} color="rgba(255,255,255,0.7)" />
            <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(255,255,255,0.7)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Configurer
            </span>
          </div>
        )}
      </div>

      {/* Bottom content */}
      <div style={{ position: 'absolute', bottom: '20px', left: '20px', right: '20px' }}>
        {/* Time pill */}
        {settings.time && (
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              background: 'rgba(255,255,255,0.13)',
              backdropFilter: 'blur(16px)',
              WebkitBackdropFilter: 'blur(16px)',
              borderRadius: '50px',
              padding: '5px 11px',
              marginBottom: '10px',
            }}
          >
            <CardIcon size={10} color="rgba(255,255,255,0.8)" />
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.85)', letterSpacing: '0.02em' }}>
              {settings.time}
            </span>
            {settings.lieu && (
              <>
                <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: '9px' }}>·</span>
                <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.65)', maxWidth: '90px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {settings.lieu}
                </span>
              </>
            )}
          </div>
        )}

        {!settings.time && (
          <div style={{ marginBottom: '8px', display: 'flex', alignItems: 'center' }}>
            <CardIcon size={13} color="rgba(255,255,255,0.4)" />
          </div>
        )}

        <p
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: '22px',
            fontWeight: 800,
            color: '#fff',
            textTransform: 'uppercase',
            letterSpacing: '-0.01em',
            lineHeight: 1.05,
            margin: 0,
          }}
        >
          {card.name}
        </p>
        <p
          style={{
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: '13px',
            fontStyle: 'italic',
            fontWeight: 300,
            color: 'rgba(255,255,255,0.65)',
            margin: '5px 0 0',
            letterSpacing: '0.01em',
          }}
        >
          {card.subtitle}
        </p>
      </div>
    </div>
  );
};
