import React from "react";
import { Switch } from "./ui/switch";
import { WeddingMoment, MomentSettings } from "./weddingMoments";
import { ChevronLeft } from "lucide-react";

interface WeddingCardBackProps {
  moment: WeddingMoment;
  settings: MomentSettings;
  onChange: (key: keyof MomentSettings, value: string | number | boolean) => void;
  onClose: () => void;
}

const dresscodes = [
  { value: "", label: "Non défini" },
  { value: "chic", label: "Chic" },
  { value: "elegant", label: "Élégant" },
  { value: "casual", label: "Décontracté" },
  { value: "blacktie", label: "Tenue de soirée" },
  { value: "blanc", label: "Blanc & Ivoire" },
];

const fieldBase: React.CSSProperties = {
  fontFamily: "Inter, sans-serif",
  fontSize: "13px",
  fontWeight: 400,
  color: "rgba(0,0,0,0.8)",
  background: "rgba(0,0,0,0.04)",
  border: "none",
  borderRadius: "8px",
  padding: "8px 10px",
  width: "100%",
  outline: "none",
};

export const WeddingCardBack: React.FC<WeddingCardBackProps> = ({
  moment,
  settings,
  onChange,
  onClose,
}) => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        padding: "16px 20px 20px",
        background: "#FAF8F4",
        borderRadius: "24px",
        overflowY: "auto",
        fontFamily: "Inter, sans-serif",
      }}
    >
      {/* Top bar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginBottom: "16px",
          gap: "6px",
        }}
      >
        <button
          onClick={onClose}
          style={{
            background: "none",
            border: "none",
            padding: "0",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "2px",
            color: "rgba(0,0,0,0.4)",
            fontSize: "12px",
            fontFamily: "Inter, sans-serif",
            fontWeight: 400,
          }}
        >
          <ChevronLeft size={14} />
          Retourner
        </button>
      </div>

      {/* Moment header */}
      <div style={{ marginBottom: "18px" }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
          <span
            style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "22px",
              fontWeight: 400,
              color: "rgba(0,0,0,0.85)",
              letterSpacing: "-0.01em",
            }}
          >
            {moment.name}
          </span>
          <span
            style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "13px",
              fontStyle: "italic",
              color: "rgba(0,0,0,0.4)",
            }}
          >
            {moment.subtitle}
          </span>
        </div>
        <div
          style={{
            height: "1px",
            background: "rgba(0,0,0,0.08)",
            marginTop: "12px",
          }}
        />
      </div>

      {/* Fields */}
      <div style={{ display: "flex", flexDirection: "column", gap: "12px", flex: 1 }}>

        {/* Time + Guests (side by side) */}
        <div style={{ display: "flex", gap: "10px" }}>
          <div style={{ flex: 1 }}>
            <label
              style={{
                display: "block",
                fontSize: "11px",
                color: "rgba(0,0,0,0.4)",
                marginBottom: "5px",
                letterSpacing: "0.06em",
                textTransform: "uppercase",
              }}
            >
              Heure
            </label>
            <input
              type="time"
              value={settings.time}
              onChange={(e) => onChange("time", e.target.value)}
              style={fieldBase}
            />
          </div>
          <div style={{ flex: 1 }}>
            <label
              style={{
                display: "block",
                fontSize: "11px",
                color: "rgba(0,0,0,0.4)",
                marginBottom: "5px",
                letterSpacing: "0.06em",
                textTransform: "uppercase",
              }}
            >
              Invités
            </label>
            <input
              type="number"
              min={0}
              value={settings.invites || ""}
              onChange={(e) => onChange("invites", parseInt(e.target.value) || 0)}
              placeholder="0"
              style={fieldBase}
            />
          </div>
        </div>

        {/* Venue */}
        <div>
          <label
            style={{
              display: "block",
              fontSize: "11px",
              color: "rgba(0,0,0,0.4)",
              marginBottom: "5px",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            Lieu
          </label>
          <input
            type="text"
            value={settings.lieu}
            onChange={(e) => onChange("lieu", e.target.value)}
            placeholder={moment.lieuPlaceholder}
            style={fieldBase}
          />
        </div>

        {/* Dress code */}
        <div>
          <label
            style={{
              display: "block",
              fontSize: "11px",
              color: "rgba(0,0,0,0.4)",
              marginBottom: "5px",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            Dress code
          </label>
          <select
            value={settings.dresscode}
            onChange={(e) => onChange("dresscode", e.target.value)}
            style={{ ...fieldBase, cursor: "pointer" }}
          >
            {dresscodes.map((dc) => (
              <option key={dc.value} value={dc.value}>
                {dc.label}
              </option>
            ))}
          </select>
        </div>

        {/* Music toggle */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "8px 10px",
            background: "rgba(0,0,0,0.04)",
            borderRadius: "8px",
          }}
        >
          <span
            style={{
              fontSize: "13px",
              color: "rgba(0,0,0,0.7)",
            }}
          >
            Musique
          </span>
          <Switch
            checked={settings.musique}
            onCheckedChange={(v) => onChange("musique", v)}
          />
        </div>

        {/* Notes */}
        <div style={{ flex: 1 }}>
          <label
            style={{
              display: "block",
              fontSize: "11px",
              color: "rgba(0,0,0,0.4)",
              marginBottom: "5px",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            Notes
          </label>
          <textarea
            value={settings.notes}
            onChange={(e) => onChange("notes", e.target.value)}
            placeholder={moment.notesPlaceholder}
            rows={3}
            style={{
              ...fieldBase,
              resize: "none",
              lineHeight: "1.5",
            }}
          />
        </div>
      </div>
    </div>
  );
};
