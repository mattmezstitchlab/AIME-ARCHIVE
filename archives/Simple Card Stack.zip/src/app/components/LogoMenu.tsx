import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Heart, Calendar, Download, LayoutTemplate, CheckSquare, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTheme } from '../contexts/ThemeContext';
import { ICON_MAP } from '../utils/iconMap';
import type { WeddingLot } from '../types';

interface LogoMenuProps {
  lots: WeddingLot[];
  coupleName: string;
  weddingDate: string;
  onNavigateLot: (lot: WeddingLot) => void;
  onAction: (action: string) => void;
  cardSettings: Record<string, Record<string, any>>;
  activeLotId?: number | null;
  onSelectLot?: (id: number | null) => void;
}

export const LogoMenu: React.FC<LogoMenuProps> = ({
  lots, coupleName, weddingDate, onNavigateLot, onAction, cardSettings,
  activeLotId, onSelectLot,
}) => {
  const { isDark } = useTheme();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const surf    = isDark ? '#111020' : '#FFFFFF';
  const surf2   = isDark ? '#1A1830' : '#F5F5F7';
  const border  = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.08)';
  const tp      = isDark ? '#F0EEF8' : '#0F0F12';
  const ts      = isDark ? 'rgba(240,238,248,0.5)' : '#6B6B7B';
  const tm      = isDark ? 'rgba(240,238,248,0.28)' : 'rgba(15,15,18,0.3)';
  const hoverBg = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)';
  const activeBg = isDark ? 'rgba(196,149,106,0.12)' : 'rgba(196,149,106,0.09)';

  const activeLot = activeLotId != null ? lots.find((l) => l.id === activeLotId) : null;

  return (
    <div ref={ref} style={{ position: 'relative', flexShrink: 0, marginLeft: '-8px' }}>
      {/* Trigger — pulled to the very left */}
      <button
        onClick={() => setOpen((v) => !v)}
        style={{
          display: 'flex', alignItems: 'center', gap: '4px',
          background: open ? (isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.05)') : 'transparent',
          border: 'none', borderRadius: '8px', padding: '5px 7px 5px 8px',
          cursor: 'pointer', transition: 'background 0.15s',
        }}
        onMouseEnter={(e) => { if (!open) (e.currentTarget as HTMLElement).style.background = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)'; }}
        onMouseLeave={(e) => { if (!open) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
      >
        <span style={{
          fontFamily: 'Inter', fontSize: '11px', fontWeight: 800,
          letterSpacing: '0.14em', textTransform: 'uppercase', color: tp,
        }}>
          Le Monde Aime
        </span>
        <motion.div
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}
        >
          {/* More prominent arrow */}
          <ChevronDown size={14} color={open ? '#C4956A' : ts} strokeWidth={2.5} />
        </motion.div>
      </button>

      {/* Dropdown */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ type: 'spring', damping: 28, stiffness: 380 }}
            style={{
              position: 'absolute', top: 'calc(100% + 8px)', left: 0,
              width: '270px', background: surf,
              borderRadius: '13px', border: `1px solid ${border}`,
              boxShadow: isDark ? '0 8px 32px rgba(0,0,0,0.5)' : '0 8px 32px rgba(0,0,0,0.1)',
              zIndex: 500, overflow: 'hidden',
            }}
          >
            {/* Couple info */}
            <div style={{ padding: '14px 16px 10px', borderBottom: `1px solid ${border}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: 'linear-gradient(135deg,#C4956A,#D4A878)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Heart size={13} color="#fff" />
                </div>
                <div>
                  <div style={{ fontFamily: 'Inter', fontSize: '12px', fontWeight: 700, color: tp }}>{coupleName}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontFamily: 'Inter', fontSize: '10px', color: ts }}>
                    <Calendar size={9} /> {weddingDate}
                  </div>
                </div>
              </div>
            </div>

            {/* Lots navigation */}
            <div style={{ padding: '8px 0' }}>
              <div style={{ padding: '4px 16px 6px', fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: tm }}>
                Lots de cartes
              </div>

              {/* "Aucun lot" option to clear selection */}
              {activeLotId != null && (
                <button
                  onClick={() => { onSelectLot?.(null); setOpen(false); }}
                  style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: '9px',
                    padding: '5px 16px', border: 'none', background: 'transparent',
                    cursor: 'pointer', transition: 'background 0.1s', textAlign: 'left',
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = hoverBg; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
                >
                  <span style={{ width: '12px', height: '12px', flexShrink: 0 }} />
                  <span style={{ fontFamily: 'Inter', fontSize: '11px', color: ts, fontStyle: 'italic' }}>Masquer les lots</span>
                </button>
              )}

              {lots.map((lot) => {
                const LotIcon = ICON_MAP[lot.icon] ?? ICON_MAP['Wand2'];
                const configured = lot.cards.filter((c) => {
                  const v = cardSettings[c.id];
                  return v && Object.keys(v).some((k) => v[k] && v[k] !== '' && v[k] !== false);
                }).length;
                const pct = Math.round((configured / lot.cards.length) * 100);
                const isActive = lot.id === activeLotId;

                return (
                  <button
                    key={lot.id}
                    onClick={() => {
                      onSelectLot?.(lot.id);
                      onNavigateLot(lot);
                      setOpen(false);
                    }}
                    style={{
                      width: '100%', display: 'flex', alignItems: 'center', gap: '9px',
                      padding: '6px 16px', border: 'none',
                      background: isActive ? activeBg : 'transparent',
                      cursor: 'pointer', transition: 'background 0.1s', textAlign: 'left',
                    }}
                    onMouseEnter={(e) => { if (!isActive) (e.currentTarget as HTMLElement).style.background = hoverBg; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = isActive ? activeBg : 'transparent'; }}
                  >
                    {LotIcon && <LotIcon size={12} color={isActive ? lot.accentColor : lot.accentColor} strokeWidth={isActive ? 2.5 : 2} style={{ flexShrink: 0, opacity: isActive ? 1 : 0.75 }} />}
                    <span style={{ fontFamily: 'Inter', fontSize: '11px', color: isActive ? tp : tp, flex: 1, fontWeight: isActive ? 600 : 400 }}>{lot.title}</span>
                    {isActive && <Check size={11} color="#C4956A" strokeWidth={2.5} />}
                    {!isActive && pct > 0 && (
                      <span style={{ fontFamily: 'Inter', fontSize: '9px', color: pct === 100 ? '#4CAF50' : ts, background: pct === 100 ? 'rgba(76,175,80,0.1)' : surf2, borderRadius: '4px', padding: '1px 5px' }}>
                        {pct}%
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Actions */}
            <div style={{ padding: '8px 0', borderTop: `1px solid ${border}` }}>
              <div style={{ padding: '4px 16px 6px', fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: tm }}>
                Actions
              </div>
              {[
                { icon: <Download size={12} />, label: 'Exporter en ICS', action: 'export-ics' },
                { icon: <CheckSquare size={12} />, label: 'Checklist IA', action: 'checklist' },
                { icon: <LayoutTemplate size={12} />, label: 'Templates', action: 'templates' },
              ].map(({ icon, label, action }) => (
                <button
                  key={action}
                  onClick={() => { onAction(action); setOpen(false); }}
                  style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: '9px',
                    padding: '6px 16px', border: 'none', background: 'transparent',
                    cursor: 'pointer', transition: 'background 0.1s', textAlign: 'left',
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = hoverBg; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
                >
                  <span style={{ color: ts, display: 'flex' }}>{icon}</span>
                  <span style={{ fontFamily: 'Inter', fontSize: '11px', color: tp }}>{label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
