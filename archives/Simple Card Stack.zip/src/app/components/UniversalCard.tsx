import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart, Calendar, MapPin, Users, Palette, Euro,
  Shield, ChevronRight, Check, RotateCcw,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

// ── Types ─────────────────────────────────────────────────────────────────────

export interface SetupData {
  brideFirstName: string;
  groomFirstName: string;
  date: string;
  ceremonyTime: string;
  ceremonyVenue: string;
  receptionVenue: string;
  receptionCity: string;
  guestCount: number;
  childCount: number;
  diet: string[];
  style: string;
  colorA: string;
  colorB: string;
  budget: number;
  witnessA: string;
  witnessB: string;
}

interface UniversalCardProps {
  data: SetupData;
  onChange: (data: SetupData) => void;
  onComplete: (data: SetupData) => void;
  isComplete: boolean;
}

const STYLES = ['Champêtre', 'Bohème', 'Chic', 'Luxe', 'Moderne', 'Vintage'];
const DIETS  = ['Végétarien', 'Végétalien', 'Halal', 'Casher', 'Sans gluten', 'Sans lactose'];

const SECTIONS = [
  { id: 'identity', label: 'Qui êtes-vous ?',  icon: <Heart size={13} /> },
  { id: 'venue',    label: 'Où ?',              icon: <MapPin size={13} /> },
  { id: 'guests',   label: 'Vos invités',       icon: <Users size={13} /> },
  { id: 'style',    label: 'Votre style',       icon: <Palette size={13} /> },
  { id: 'budget',   label: 'Budget global',     icon: <Euro size={13} /> },
  { id: 'contacts', label: 'Contacts clés',     icon: <Shield size={13} /> },
];

// ── Helpers ───────────────────────────────────────────────────────────────────

function pct(data: SetupData): number {
  const checks = [
    data.brideFirstName, data.groomFirstName, data.date, data.ceremonyVenue,
    data.receptionVenue, data.guestCount > 0, data.style, data.budget > 0,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

// ── Component ─────────────────────────────────────────────────────────────────

export const UniversalCard: React.FC<UniversalCardProps> = ({ data, onChange, onComplete, isComplete }) => {
  const { isDark } = useTheme();
  const [flipped, setFlipped] = useState(false);
  const [section, setSection] = useState(0);
  const completion = pct(data);

  const set = (field: keyof SetupData, value: any) => onChange({ ...data, [field]: value });
  const toggleDiet = (d: string) => {
    const next = data.diet.includes(d) ? data.diet.filter((x) => x !== d) : [...data.diet, d];
    set('diet', next);
  };

  const surf  = isDark ? '#18152E' : '#FFFFFF';
  const surf2 = isDark ? '#221F38' : '#F5F5F7';
  const border = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
  const tp    = isDark ? '#F0EEF8' : '#0F0F12';
  const ts    = isDark ? 'rgba(240,238,248,0.5)' : '#6B6B7B';
  const tm    = isDark ? 'rgba(240,238,248,0.28)' : 'rgba(15,15,18,0.3)';

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '8px 11px', borderRadius: '8px',
    border: `1px solid ${border}`, background: surf2,
    fontFamily: 'Inter', fontSize: '12px', color: tp, outline: 'none',
    transition: 'border-color 0.15s',
  };

  return (
    <div
      style={{ width: '260px', height: '360px', perspective: '1200px', cursor: 'default', flexShrink: 0 }}
      onClick={(e) => e.stopPropagation()}
    >
      <motion.div
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ type: 'spring', damping: 26, stiffness: 220 }}
        style={{ width: '100%', height: '100%', transformStyle: 'preserve-3d', position: 'relative' }}
      >
        {/* ── FRONT ── */}
        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden',
          borderRadius: '18px', overflow: 'hidden',
          background: 'linear-gradient(135deg,#C4956A 0%,#D4A878 40%,#E8C4A0 70%,#F0D8C0 100%)',
          boxShadow: isDark ? '0 12px 48px rgba(0,0,0,0.5)' : '0 8px 32px rgba(0,0,0,0.12)',
        }}>
          {/* Decorative circles */}
          <div style={{ position: 'absolute', top: '-40px', right: '-40px', width: '160px', height: '160px', borderRadius: '50%', background: 'rgba(255,255,255,0.12)' }} />
          <div style={{ position: 'absolute', bottom: '-30px', left: '-30px', width: '120px', height: '120px', borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />

          <div style={{ position: 'relative', padding: '28px 24px', height: '100%', display: 'flex', flexDirection: 'column' }}>
            {/* Icon */}
            <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: 'rgba(255,255,255,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <Heart size={22} color="#fff" fill="rgba(255,255,255,0.5)" />
            </div>

            <div style={{ fontFamily: 'Inter', fontSize: '20px', fontWeight: 800, color: '#fff', letterSpacing: '-0.01em', marginBottom: '6px' }}>
              Notre Mariage
            </div>
            <div style={{ fontFamily: 'Inter', fontSize: '12px', color: 'rgba(255,255,255,0.75)', lineHeight: 1.5, marginBottom: 'auto' }}>
              {data.brideFirstName && data.groomFirstName
                ? `${data.brideFirstName} & ${data.groomFirstName}`
                : 'Configurez votre journée parfaite'}
            </div>

            {data.date && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '12px' }}>
                <Calendar size={11} color="rgba(255,255,255,0.7)" />
                <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.7)' }}>{data.date}</span>
              </div>
            )}

            {/* Progress ring */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <svg width="36" height="36">
                <circle cx="18" cy="18" r="14" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
                <circle
                  cx="18" cy="18" r="14" fill="none" stroke="rgba(255,255,255,0.85)" strokeWidth="3"
                  strokeDasharray={`${2 * Math.PI * 14}`}
                  strokeDashoffset={`${2 * Math.PI * 14 * (1 - completion / 100)}`}
                  strokeLinecap="round"
                  transform="rotate(-90 18 18)"
                  style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                />
                <text x="18" y="22" textAnchor="middle" style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, fill: '#fff' }}>
                  {completion}%
                </text>
              </svg>
              <button
                onClick={() => setFlipped(true)}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px',
                  padding: '8px 14px', borderRadius: '9px',
                  background: 'rgba(255,255,255,0.25)', border: '1px solid rgba(255,255,255,0.3)',
                  color: '#fff', fontFamily: 'Inter', fontSize: '11px', fontWeight: 700,
                  cursor: 'pointer', backdropFilter: 'blur(8px)',
                }}
              >
                {completion === 100 ? <Check size={12} /> : null}
                {completion === 0 ? 'Commencer' : completion === 100 ? 'Complet' : 'Continuer'}
                <ChevronRight size={11} />
              </button>
            </div>
          </div>
        </div>

        {/* ── BACK ── */}
        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden',
          transform: 'rotateY(180deg)', borderRadius: '18px', overflow: 'hidden',
          background: surf,
          boxShadow: isDark ? '0 12px 48px rgba(0,0,0,0.5)' : '0 8px 32px rgba(0,0,0,0.12)',
          display: 'flex', flexDirection: 'column',
          border: `1px solid ${border}`,
        }}>
          {/* Back header */}
          <div style={{ padding: '14px 16px 10px', borderBottom: `1px solid ${border}`, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', gap: '6px' }}>
              {SECTIONS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setSection(i)}
                  title={s.label}
                  style={{
                    width: '22px', height: '22px', borderRadius: '6px', border: 'none',
                    background: section === i ? 'rgba(196,149,106,0.2)' : 'transparent',
                    color: section === i ? '#C4956A' : tm,
                    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    transition: 'all 0.12s',
                  }}
                >
                  {React.cloneElement(s.icon as React.ReactElement, { size: 11 })}
                </button>
              ))}
            </div>
            <button
              onClick={() => setFlipped(false)}
              style={{ width: '22px', height: '22px', borderRadius: '6px', border: 'none', background: 'transparent', cursor: 'pointer', color: tm, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            >
              <RotateCcw size={11} />
            </button>
          </div>

          {/* Section label */}
          <div style={{ padding: '8px 16px 4px', flexShrink: 0 }}>
            <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#C4956A' }}>
              {SECTIONS[section].label}
            </span>
          </div>

          {/* Section content */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '4px 16px 14px', scrollbarWidth: 'none' }}>
            <AnimatePresence mode="wait">
              <motion.div key={section} initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }} transition={{ duration: 0.15 }}>

                {section === 0 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <Field label="Prénom mariée" value={data.brideFirstName} onChange={(v) => set('brideFirstName', v)} inputStyle={inputStyle} border={border} ts={ts} />
                    <Field label="Prénom marié" value={data.groomFirstName} onChange={(v) => set('groomFirstName', v)} inputStyle={inputStyle} border={border} ts={ts} />
                    <Field label="Date du mariage" value={data.date} onChange={(v) => set('date', v)} placeholder="14 Septembre 2025" inputStyle={inputStyle} border={border} ts={ts} />
                    <Field label="Heure cérémonie" value={data.ceremonyTime} onChange={(v) => set('ceremonyTime', v)} placeholder="14:00" inputStyle={inputStyle} border={border} ts={ts} />
                  </div>
                )}

                {section === 1 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <Field label="Lieu de cérémonie" value={data.ceremonyVenue} onChange={(v) => set('ceremonyVenue', v)} placeholder="Mairie de…" inputStyle={inputStyle} border={border} ts={ts} />
                    <Field label="Lieu de réception" value={data.receptionVenue} onChange={(v) => set('receptionVenue', v)} placeholder="Domaine de…" inputStyle={inputStyle} border={border} ts={ts} />
                    <Field label="Ville" value={data.receptionCity} onChange={(v) => set('receptionCity', v)} placeholder="Paris, Lyon…" inputStyle={inputStyle} border={border} ts={ts} />
                  </div>
                )}

                {section === 2 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <Field label="Invités adultes" value={String(data.guestCount || '')} onChange={(v) => set('guestCount', Number(v) || 0)} type="number" inputStyle={{ ...inputStyle, flex: 1 }} border={border} ts={ts} />
                      <Field label="Enfants" value={String(data.childCount || '')} onChange={(v) => set('childCount', Number(v) || 0)} type="number" inputStyle={{ ...inputStyle, flex: 1 }} border={border} ts={ts} />
                    </div>
                    <div>
                      <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '6px' }}>Régimes alimentaires</span>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                        {DIETS.map((d) => (
                          <Chip key={d} label={d} active={data.diet.includes(d)} onClick={() => toggleDiet(d)} />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {section === 3 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div>
                      <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '6px' }}>Style du mariage</span>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                        {STYLES.map((s) => (
                          <Chip key={s} label={s} active={data.style === s} onClick={() => set('style', data.style === s ? '' : s)} />
                        ))}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <ColorField label="Couleur principale" value={data.colorA} onChange={(v) => set('colorA', v)} ts={ts} />
                      <ColorField label="Couleur secondaire" value={data.colorB} onChange={(v) => set('colorB', v)} ts={ts} />
                    </div>
                  </div>
                )}

                {section === 4 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts }}>Budget global</span>
                        <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, color: '#C4956A' }}>
                          {(data.budget || 0).toLocaleString('fr-FR')} €
                        </span>
                      </div>
                      <input
                        type="range" min={5000} max={100000} step={1000}
                        value={data.budget || 15000}
                        onChange={(e) => set('budget', Number(e.target.value))}
                        style={{ width: '100%', accentColor: '#C4956A' }}
                      />
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '2px' }}>
                        <span style={{ fontFamily: 'Inter', fontSize: '8px', color: tm }}>5 000 €</span>
                        <span style={{ fontFamily: 'Inter', fontSize: '8px', color: tm }}>100 000 €</span>
                      </div>
                    </div>
                  </div>
                )}

                {section === 5 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <Field label="Témoin de la mariée" value={data.witnessA} onChange={(v) => set('witnessA', v)} placeholder="Prénom + tel" inputStyle={inputStyle} border={border} ts={ts} />
                    <Field label="Témoin du marié" value={data.witnessB} onChange={(v) => set('witnessB', v)} placeholder="Prénom + tel" inputStyle={inputStyle} border={border} ts={ts} />
                  </div>
                )}

              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div style={{ padding: '10px 16px', borderTop: `1px solid ${border}`, flexShrink: 0, display: 'flex', gap: '6px' }}>
            {section < SECTIONS.length - 1 ? (
              <button
                onClick={() => setSection((s) => s + 1)}
                style={{ flex: 1, padding: '8px', borderRadius: '8px', border: 'none', background: '#C4956A', color: '#fff', fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}
              >
                Suivant <ChevronRight size={12} />
              </button>
            ) : (
              <button
                onClick={() => { onComplete(data); setFlipped(false); }}
                style={{ flex: 1, padding: '8px', borderRadius: '8px', border: 'none', background: completion >= 50 ? '#C4956A' : 'rgba(196,149,106,0.3)', color: '#fff', fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}
              >
                <Check size={12} /> Enregistrer
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

/* ── Sub-components ──────────────────────────────────────────────────────────── */

const Field: React.FC<{
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; type?: string; inputStyle: React.CSSProperties; border: string; ts: string;
}> = ({ label, value, onChange, placeholder, type = 'text', inputStyle, border, ts }) => (
  <div>
    <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '4px' }}>{label}</span>
    <input
      type={type} value={value} placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      style={inputStyle}
      onFocus={(e) => { (e.target as HTMLInputElement).style.borderColor = '#C4956A'; }}
      onBlur={(e) => { (e.target as HTMLInputElement).style.borderColor = border; }}
    />
  </div>
);

const Chip: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    style={{
      padding: '4px 9px', borderRadius: '50px', border: 'none', cursor: 'pointer',
      fontFamily: 'Inter', fontSize: '10px', fontWeight: active ? 700 : 400,
      background: active ? 'rgba(196,149,106,0.2)' : 'transparent',
      color: active ? '#C4956A' : '#9B9BAA',
      outline: `1px solid ${active ? 'rgba(196,149,106,0.4)' : 'rgba(0,0,0,0.1)'}`,
      transition: 'all 0.12s',
    }}
  >
    {label}
  </button>
);

const ColorField: React.FC<{ label: string; value: string; onChange: (v: string) => void; ts: string }> = ({ label, value, onChange, ts }) => (
  <div style={{ flex: 1 }}>
    <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '4px' }}>{label}</span>
    <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
      <input type="color" value={value || '#C4956A'} onChange={(e) => onChange(e.target.value)} style={{ width: '28px', height: '28px', borderRadius: '6px', border: 'none', cursor: 'pointer', padding: 0 }} />
      <span style={{ fontFamily: 'Inter', fontSize: '10px', color: ts }}>{value || '#C4956A'}</span>
    </div>
  </div>
);
