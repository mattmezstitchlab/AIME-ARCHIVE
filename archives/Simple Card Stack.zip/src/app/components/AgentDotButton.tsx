import React, { useState, useEffect, useRef } from 'react';
import { useTheme } from '../contexts/ThemeContext';

const DOT_COLORS = ['#C4956A', '#E8A598', '#A8B8C8', '#D4B896', '#9BB5A0', '#C8A8C0'];
const RADIUS = 10;
const DOT_SIZE = 3.4;
const N = DOT_COLORS.length;

// Speed in degrees/second for each state
const SPEEDS = {
  idle:         18,   // very slow — barely drifting, like breathing
  open:         55,   // gentle cruise while chat is open
  notification: 90,   // noticeable — agent wants attention
  thinking:     280,  // fast spin — processing
};

export type AgentState = 'idle' | 'open' | 'notification' | 'thinking';

interface AgentDotButtonProps {
  onClick: () => void;
  agentState: AgentState;
  title?: string;
}

export const AgentDotButton: React.FC<AgentDotButtonProps> = ({ onClick, agentState, title }) => {
  const { isDark } = useTheme();
  const [angle, setAngle] = useState(0);
  const [hov, setHov] = useState(false);
  const speedRef = useRef(SPEEDS.idle);
  const size = 34;
  const cx = size / 2;
  const cy = size / 2;

  // Smoothly interpolate speed toward target
  useEffect(() => {
    const target = SPEEDS[agentState];
    let raf: number;
    let last = performance.now();

    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05); // cap dt to avoid jumps
      last = now;

      // Lerp toward target speed (fast when accelerating, slow when decelerating)
      const lerpRate = speedRef.current < target ? 4 : 1.5;
      speedRef.current += (target - speedRef.current) * lerpRate * dt;

      setAngle((a) => (a + speedRef.current * dt) % 360);
      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [agentState]);

  const isThinking = agentState === 'thinking';
  const hasNotif   = agentState === 'notification';
  const isOpen     = agentState === 'open';

  return (
    <button
      onClick={onClick}
      title={title ?? 'Assistant IA — Le Monde Aime'}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: `${size}px`, height: `${size}px`,
        borderRadius: '50%', border: 'none', cursor: 'pointer', padding: 0,
        background: hov || isOpen
          ? (isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)')
          : 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'background 0.2s',
        flexShrink: 0,
        position: 'relative',
      }}
    >
      {/* Notification ring — glows when agent has something to say */}
      {hasNotif && (
        <div style={{
          position: 'absolute', inset: '-3px', borderRadius: '50%',
          border: '1.5px solid rgba(196,149,106,0.5)',
          animation: 'agentPulse 1.8s ease-in-out infinite',
        }} />
      )}

      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block' }}>
        {DOT_COLORS.map((color, i) => {
          const theta = ((angle + (i * 360) / N) * Math.PI) / 180;
          const x = cx + RADIUS * Math.cos(theta);
          const y = cy + RADIUS * Math.sin(theta);

          // Trailing fade — leading dots brighter
          const trailFactor = (i / (N - 1));
          const opacity = isThinking
            ? 0.45 + 0.55 * trailFactor
            : hasNotif
            ? 0.5 + 0.5 * trailFactor
            : isOpen
            ? 0.5 + 0.5 * trailFactor
            : 0.25 + 0.55 * trailFactor;  // idle: subtler

          // Dot size: pulsing when thinking, uniform otherwise
          const r = isThinking
            ? DOT_SIZE * (0.75 + 0.35 * Math.sin((angle * 0.04 + (i / N) * Math.PI * 2)))
            : hasNotif
            ? DOT_SIZE * (0.85 + 0.2 * Math.sin((angle * 0.02 + (i / N) * Math.PI * 2)))
            : DOT_SIZE;

          return (
            <circle key={i} cx={x} cy={y} r={r} fill={color} opacity={opacity} />
          );
        })}

        {/* Center dot when open */}
        {(isOpen || isThinking) && (
          <circle cx={cx} cy={cy} r={2.2} fill="#C4956A"
            opacity={isThinking ? 0.6 + 0.4 * Math.sin(angle * 0.05) : 0.7} />
        )}
      </svg>

      <style>{`
        @keyframes agentPulse {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50%       { opacity: 0.9; transform: scale(1.08); }
        }
      `}</style>
    </button>
  );
};
