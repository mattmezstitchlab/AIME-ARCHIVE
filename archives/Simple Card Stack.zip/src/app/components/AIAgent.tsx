import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Send, ChevronDown, MapPin, Loader2, ArrowRight, Clock, Check } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import type { WeddingLot } from '../types';

// ── Wedding knowledge engine ───────────────────────────────────────────────────

function getAgentResponse(
  input: string,
  _lots: WeddingLot[],
  _cardSettings: Record<string, any>
): { text: string; action?: { type: 'navigate'; lotId: number; label: string } } {
  const q = input.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

  if (q.match(/budget|cout|prix|depense|€|eur/)) {
    return {
      text: `**Budget mariage en France**\n\nMoyenne nationale : **18 000 – 25 000 €** (80-100 invités).\n\n• Réception/salle : 30-40 %\n• Traiteur : 25-35 % (45–90 €/pers.)\n• Photo/Vidéo : 8-12 %\n• Fleurs & décoration : 8-10 %\n• Tenue mariée + costume : 5-8 %\n• DJ/Musique : 3-5 %\n• Imprimés (invitations, menus) : 1-2 %\n\n💡 Réservez 5 % du budget pour les imprévus. Consultez votre tableau Budget dans l'app.`,
      action: { type: 'navigate', lotId: 11, label: 'Ouvrir le Budget' },
    };
  }

  if (q.match(/traiteur|repas|menu|nourriture|cocktail|diner|buffet/)) {
    return {
      text: `**Choisir son traiteur**\n\n• Réservez **12-18 mois** à l'avance\n• Exigez une dégustation gratuite\n• Vérifiez l'assurance responsabilité civile\n• Demandez: est-ce maison ou sous-traité ?\n\n**Tarifs indicatifs :**\n• Cocktail seul : 25-45 €/pers.\n• Dîner assis servi : 70-130 €/pers.\n• Brunch lendemain : 30-55 €/pers.\n\n🌿 Tendance 2025 : menus végétaux, produits locaux, fromages AOP.`,
    };
  }

  if (q.match(/photo|photographe|video|film|reportage/)) {
    return {
      text: `**Photo & Vidéo**\n\n• Bookez **avant** le traiteur (les meilleurs : 18-24 mois à l'avance)\n• Vérifiez les droits d'image dans le contrat\n• Demandez livraison RAW + retouchées\n• Délai de livraison : 6-12 semaines\n\n**Budget :**\n• Photographe seul : 1 500 – 4 000 €\n• Vidéaste seul : 1 200 – 3 500 €\n• Duo photo+vidéo : 3 000 – 6 500 €\n\n📋 Préparez une liste de 20-30 photos indispensables à remettre au photographe J-1.`,
    };
  }

  if (q.match(/programme|planning|horaire|deroul|jour j|ceremonie/)) {
    return {
      text: `**Déroulé type d'une journée**\n\n🕘 **09h00** — Préparatifs mariée\n🕙 **10h30** — Préparatifs marié\n🕛 **12h00** — Cocktail déjeunatoire (optionnel)\n🕑 **14h00** — Cérémonie (civile ou laïque)\n🕓 **15h30** — Cocktail & photos\n🕖 **19h30** — Entrée en salle\n🕗 **20h00** — Dîner\n🕙 **22h30** — Pièce montée + ouverture de bal\n🕛 **00h00** — Soirée dansante\n\n⚠️ Prévoyez 30 min de marge entre chaque moment clé.`,
      action: { type: 'navigate', lotId: 1, label: 'Voir le programme' },
    };
  }

  if (q.match(/invite|rsvp|liste|invitation|convive|table/)) {
    return {
      text: `**Gestion des invités**\n\n📅 **Calendrier :**\n• J-12 mois : liste A + B\n• J-8 mois : faire-parts en précommande\n• J-6 mois : envoi des invitations\n• J-2 mois : deadline RSVP\n• J-3 sem : plan de table définitif\n\n📊 **Taux de présence moyen :** 85-90 %\n\n💡 Prévoyez toujours +10 % de désistements last minute. Votre mini-site peut collecter les RSVP en ligne !`,
    };
  }

  if (q.match(/fleur|deco|decoration|bouquet|arrangement/)) {
    return {
      text: `**Fleurs & Décoration**\n\n✅ Éléments essentiels :\n• Bouquet mariée + boutonnière\n• Centres de table (frais ou séchés)\n• Arche / backdrop cérémonie\n• Pétales & chemin de fleurs\n\n💰 **Budget moyen :** 1 500 – 4 500 €\n\n🌿 **Tendances 2025 :** fleurs séchées (pampas, gypsophile), eucalyptus, palette terracotta & sage. Marché de Rungis (IdF) : -40 % vs fleuriste traditionnel.`,
    };
  }

  if (q.match(/musique|dj|playlist|groupe|son|ambiance|orchestre/)) {
    return {
      text: `**Musique & Animation**\n\n🎵 **Options :**\n• DJ : 800-2 500 € (versatile, catalogue illimité)\n• Groupe live : 1 500-5 000 €\n• Quartet/Pianiste : idéal cérémonie laïque\n• Formule hybride DJ + musiciens live\n\n**5 moments à musicaliser :**\n1. Entrée cortège\n2. Entrée mariée\n3. Cocktail (fond musical)\n4. Entrée en salle\n5. Ouverture de bal\n\nConfigurez vos playlists dans l'app !`,
      action: { type: 'navigate', lotId: 9, label: 'Musique cérémonie' },
    };
  }

  if (q.match(/lieu|salle|chateau|domaine|venue|reception|espace/)) {
    return {
      text: `**Choisir son lieu**\n\n📋 **Critères clés :**\n• Capacité = invités + 20 %\n• Hébergement sur place ?\n• Exclusivité totale de la date ?\n• Traiteur imposé ou libre ?\n• Heure de fin de fête ?\n• Plan B intérieur si pluie ?\n\n💰 **Fourchettes :**\n• Château/Manoir : 3 000-15 000 €/j\n• Domaine rural : 2 000-8 000 €/j\n• Salle communale : 500-1 500 €/j\n\n📅 Réservez **12-24 mois** à l'avance pour les beaux domaines.`,
      action: { type: 'navigate', lotId: 2, label: 'Voir les lieux' },
    };
  }

  if (q.match(/temoin|honneur|evjf|evg|garcon|demoiselle/)) {
    return {
      text: `**Les Témoins**\n\n📜 **Rôle légal :** signature de l'acte de mariage. Max 2 par marié (4 au total).\n\n🎉 **Rôle traditionnel :**\n• Organisation EVJF/EVG (1-3 mois avant)\n• Discours/toast lors du dîner\n• Coordination logistique Jour J\n• Référent pour les invités\n\n💡 Donnez leur accès au mode **Témoins** du mini-site pour leur briefing personnalisé !`,
    };
  }

  if (q.match(/legalement|mairie|etat civil|dossier|administratif|bans/)) {
    return {
      text: `**Démarches administratives**\n\n📋 **Pièces mairie (J-30 jours min.) :**\n• Acte de naissance de moins de 3 mois\n• Pièce d'identité\n• Justificatif de domicile\n• Informations sur les témoins\n• Contrat de mariage (si régime choisi)\n\n⚖️ **Régimes matrimoniaux :**\n• Communauté réduite aux acquêts (défaut)\n• Séparation de biens\n• Communauté universelle\n\n💡 Consultez un notaire pour le contrat de mariage — acte à faire **avant** le mariage.`,
    };
  }

  if (q.match(/surprise|cacher|secret|dissimuler/)) {
    return {
      text: `**Mode Surprise**\n\nLe mode Surprise dans votre mini-site masque automatiquement les moments confidentiels aux mariés.\n\n✅ Activez-le pour :\n• Organiser les surprises entre témoins\n• Cacher des prestations spéciales\n• Bloquer les créneaux réservés aux surprises\n\n⚠️ Si les mariés tentent de placer un événement sur un créneau "Surprise", l'app les avertira de choisir un autre horaire.`,
    };
  }

  if (q.match(/bonjour|salut|aide|help|commencer|debut|start|bienvenue/)) {
    return {
      text: `Bonjour ! Je suis votre assistant **Le Monde Aime** 💍\n\nSpécialisé en organisation de mariages en France, je peux vous conseiller sur :\n\n• 💰 Budget & coûts\n• 📋 Programme de la journée\n• 🍽️ Traiteur & menu\n• 📸 Photo & vidéo\n• 🌸 Fleurs & décoration\n• 🎵 Musique & animation\n• 🏛️ Lieu de réception\n• 💌 Invités & RSVP\n• ⚖️ Démarches administratives\n• 💎 Témoins & surprises\n\nPar quoi commençons-nous ?`,
    };
  }

  if (q.match(/merci|super|parfait|genial|excellent|bravo|top/)) {
    return { text: `Avec plaisir ! 🎊 Je suis là pour vous aider à construire la journée parfaite. N'hésitez pas si vous avez d'autres questions.` };
  }

  return {
    text: `Je suis votre assistant mariage spécialisé. Posez-moi vos questions sur :\n\n💰 Budget · 📋 Programme · 🍽️ Traiteur · 📸 Photo · 🌸 Fleurs · 🎵 Musique · 🏛️ Lieu · 💌 Invités · ⚖️ Administratif · 💎 Témoins & Surprises\n\nQue souhaitez-vous savoir ?`,
  };
}

// ── T&C Modal ─────────────────────────────────────────────────────────────────

const TermsModal: React.FC<{ onAccept: () => void; onDecline: () => void; isDark: boolean }> = ({ onAccept, onDecline, isDark }) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}
  >
    <motion.div
      initial={{ scale: 0.95, y: 16 }}
      animate={{ scale: 1, y: 0 }}
      exit={{ scale: 0.95, y: 16 }}
      style={{ background: isDark ? '#111020' : '#fff', borderRadius: '16px', padding: '32px', maxWidth: '440px', width: '100%', boxShadow: '0 24px 64px rgba(0,0,0,0.3)', border: `1px solid ${isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'}` }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
        <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'linear-gradient(135deg,#C4956A,#D4A878)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Bot size={20} color="#fff" />
        </div>
        <div>
          <div style={{ fontFamily: 'Inter', fontSize: '15px', fontWeight: 700, color: isDark ? '#F0EEF8' : '#0F0F12' }}>Assistant IA</div>
          <div style={{ fontFamily: 'Inter', fontSize: '11px', color: isDark ? 'rgba(240,238,248,0.5)' : '#6B6B7B' }}>Le Monde Aime · Expert mariage</div>
        </div>
      </div>

      <div style={{ fontFamily: 'Inter', fontSize: '13px', color: isDark ? 'rgba(240,238,248,0.7)' : '#4A4A5A', lineHeight: 1.7, marginBottom: '20px' }}>
        <p style={{ marginBottom: '12px', fontWeight: 600, color: isDark ? '#F0EEF8' : '#0F0F12' }}>Conditions d'utilisation de l'assistant</p>
        <p style={{ marginBottom: '10px' }}>Cet assistant est alimenté par une base de connaissances experte en organisation de mariages en France. Il peut vous conseiller, guider vos actions dans l'app, et rédiger des messages à destination de vos prestataires.</p>
        <p style={{ marginBottom: '10px' }}>Toutes vos conversations sont enregistrées localement avec horodatage dans votre espace de compte pour consultation ultérieure.</p>
        <p>L'assistant n'a pas accès à des données personnelles extérieures à votre configuration dans l'app. Il ne peut pas envoyer de messages sans votre confirmation explicite.</p>
      </div>

      <div style={{ display: 'flex', gap: '10px' }}>
        <button
          onClick={onDecline}
          style={{ flex: 1, padding: '10px', borderRadius: '9px', border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}`, background: 'transparent', cursor: 'pointer', fontFamily: 'Inter', fontSize: '13px', fontWeight: 500, color: isDark ? 'rgba(240,238,248,0.6)' : '#6B6B7B' }}
        >
          Refuser
        </button>
        <button
          onClick={onAccept}
          style={{ flex: 2, padding: '10px', borderRadius: '9px', border: 'none', background: 'linear-gradient(135deg,#C4956A,#D4A878)', cursor: 'pointer', fontFamily: 'Inter', fontSize: '13px', fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
        >
          <Check size={14} /> Accepter & Continuer
        </button>
      </div>
    </motion.div>
  </motion.div>
);

// ── Message renderer ───────────────────────────────────────────────────────────

const MsgText: React.FC<{ text: string; isDark: boolean }> = ({ text, isDark }) => {
  const lines = text.split('\n');
  return (
    <div style={{ fontFamily: 'Inter', fontSize: '12.5px', lineHeight: 1.65, color: isDark ? 'rgba(240,238,248,0.9)' : '#2A2A3A' }}>
      {lines.map((line, i) => {
        const bold = line.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
        if (line.startsWith('• ') || line.startsWith('✅ ') || line.startsWith('📋 ') || line.match(/^[🕘🕙🕛🕑🕓🕖🕗🕙🕛💡⚠️📅📊💰🎵📸🌿⚖️🎉📜💎💍👋]/)) {
          return <div key={i} style={{ marginBottom: '3px' }} dangerouslySetInnerHTML={{ __html: bold }} />;
        }
        if (line === '') return <div key={i} style={{ height: '6px' }} />;
        return <div key={i} dangerouslySetInnerHTML={{ __html: bold }} />;
      })}
    </div>
  );
};

// ── Guided dot ────────────────────────────────────────────────────────────────

const GuidedDot: React.FC<{ visible: boolean; targetEl?: string }> = ({ visible }) => (
  <AnimatePresence>
    {visible && (
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [1, 1.3, 1], opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
        transition={{ repeat: Infinity, duration: 1.4 }}
        style={{ position: 'fixed', bottom: '90px', right: '80px', width: '14px', height: '14px', borderRadius: '50%', background: '#C4956A', boxShadow: '0 0 0 4px rgba(196,149,106,0.3)', zIndex: 1200, pointerEvents: 'none' }}
      />
    )}
  </AnimatePresence>
);

// ── Main component ─────────────────────────────────────────────────────────────

export interface AIAgentProps {
  lots: WeddingLot[];
  cardSettings: Record<string, any>;
  viewMode: string;
  onNavigateLot?: (lot: WeddingLot) => void;
  onAction?: (action: string) => void;
  externalOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  onThinkingChange?: (thinking: boolean) => void;
  onNewMessage?: () => void;
}

export const AIAgent: React.FC<AIAgentProps> = ({ lots, cardSettings, viewMode, onNavigateLot, externalOpen, onOpenChange, onThinkingChange, onNewMessage }) => {
  const { isDark } = useTheme();
  const [internalOpen, setInternalOpen] = useState(false);
  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = (v: boolean) => { setInternalOpen(v); onOpenChange?.(v); };
  const [showTerms, setShowTerms] = useState(false);
  const [termsAccepted] = useState(() => !!localStorage.getItem('lma_agent_accepted'));
  const [accepted, setAccepted] = useState(termsAccepted);
  const [messages, setMessages] = useState<{ id: string; role: 'user' | 'agent'; text: string; ts: Date; action?: any }[]>([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [guidedDot, setGuidedDot] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const surf = isDark ? '#111020' : '#FFFFFF';
  const surf2 = isDark ? '#1A1830' : '#F5F5F7';
  const border = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.08)';
  const textPrimary = isDark ? '#F0EEF8' : '#0F0F12';
  const textSecondary = isDark ? 'rgba(240,238,248,0.5)' : '#6B6B7B';

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking]);

  // When external trigger opens the agent, check T&C first
  useEffect(() => {
    if (externalOpen && !accepted) {
      setShowTerms(true);
      onOpenChange?.(false);
    } else if (externalOpen && accepted && messages.length === 0) {
      setTimeout(() => {
        setMessages([{ id: '0', role: 'agent', text: `Bonjour ! Je suis votre assistant **Le Monde Aime** 💍\n\nSpécialisé en organisation de mariages, je connais les prestataires, les budgets, le déroulé, le droit matrimonial français et tout ce qui va avec.\n\nQue souhaitez-vous savoir ?`, ts: new Date() }]);
      }, 300);
      setTimeout(() => inputRef.current?.focus(), 400);
    }
  }, [externalOpen]);

  const handleOpen = useCallback(() => {
    if (!accepted) {
      setShowTerms(true);
    } else {
      setOpen(true);
      if (messages.length === 0) {
        setTimeout(() => {
          setMessages([{ id: '0', role: 'agent', text: `Bonjour ! Je suis votre assistant **Le Monde Aime** 💍\n\nSpécialisé en organisation de mariages, je connais les prestataires, les budgets, le déroulé, le droit matrimonial français et tout ce qui va avec.\n\nQue souhaitez-vous savoir ?`, ts: new Date() }]);
        }, 300);
      }
      setTimeout(() => inputRef.current?.focus(), 400);
    }
  }, [accepted, messages.length]);

  const handleAccept = useCallback(() => {
    localStorage.setItem('lma_agent_accepted', '1');
    setAccepted(true);
    setShowTerms(false);
    setOpen(true);
    setTimeout(() => {
      setMessages([{ id: '0', role: 'agent', text: `Bonjour ! Je suis votre assistant **Le Monde Aime** 💍\n\nSpécialisé en organisation de mariages, je connais les prestataires, les budgets, le déroulé, le droit matrimonial français et tout ce qui va avec.\n\nQue souhaitez-vous savoir ?`, ts: new Date() }]);
    }, 400);
  }, []);

  const handleSend = useCallback(() => {
    const text = input.trim();
    if (!text || thinking) return;
    const uid = Date.now().toString();
    setInput('');
    setMessages((prev) => [...prev, { id: uid, role: 'user', text, ts: new Date() }]);
    setThinking(true);
    onThinkingChange?.(true);

    // Save to localStorage log
    const log = JSON.parse(localStorage.getItem('lma_agent_log') || '[]');
    log.push({ role: 'user', text, ts: new Date().toISOString(), view: viewMode });
    localStorage.setItem('lma_agent_log', JSON.stringify(log.slice(-200)));

    setTimeout(() => {
      const { text: agentText, action } = getAgentResponse(text, lots, cardSettings);
      const aid = (Date.now() + 1).toString();
      setMessages((prev) => [...prev, { id: aid, role: 'agent', text: agentText, ts: new Date(), action }]);
      setThinking(false);
      onThinkingChange?.(false);
      // Notify parent that there's a new agent message (for notification state when chat is closed)
      if (!externalOpen) onNewMessage?.();

      // Save agent response
      const log2 = JSON.parse(localStorage.getItem('lma_agent_log') || '[]');
      log2.push({ role: 'agent', text: agentText, ts: new Date().toISOString(), action });
      localStorage.setItem('lma_agent_log', JSON.stringify(log2.slice(-200)));

      // Show guided dot if action
      if (action?.type === 'navigate') {
        setGuidedDot(true);
        setTimeout(() => setGuidedDot(false), 4000);
      }
    }, 700 + Math.random() * 600);
  }, [input, thinking, lots, cardSettings, viewMode]);

  const handleNavigate = useCallback((lotId: number) => {
    const lot = lots.find((l) => l.id === lotId);
    if (lot && onNavigateLot) {
      onNavigateLot(lot);
      setOpen(false);
    }
  }, [lots, onNavigateLot]);

  const formatTime = (d: Date) => d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

  return (
    <>
      <GuidedDot visible={guidedDot} />

      <AnimatePresence>{showTerms && <TermsModal isDark={isDark} onAccept={handleAccept} onDecline={() => setShowTerms(false)} />}</AnimatePresence>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.96 }}
            transition={{ type: 'spring', damping: 28, stiffness: 340 }}
            style={{
              position: 'fixed', top: '58px', right: '16px', width: '340px', height: '480px',
              background: surf, borderRadius: '16px',
              boxShadow: isDark ? '0 8px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.07)' : '0 8px 40px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.08)',
              zIndex: 500, display: 'flex', flexDirection: 'column', overflow: 'hidden',
            }}
          >
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '14px 16px', borderBottom: `1px solid ${border}`, background: surf, flexShrink: 0 }}>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: 'linear-gradient(135deg,#C4956A,#D4A878)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Bot size={16} color="#fff" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 700, color: textPrimary }}>Assistant LMA</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontFamily: 'Inter', fontSize: '10px', color: '#4CAF50' }}>
                  <div style={{ width: '5px', height: '5px', borderRadius: '50%', background: '#4CAF50' }} />
                  Expert mariage · En ligne
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                style={{ width: '28px', height: '28px', borderRadius: '7px', border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: textSecondary, flexShrink: 0 }}
              >
                <ChevronDown size={16} />
              </button>
            </div>

            {/* Messages */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '14px 14px 8px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {messages.map((msg) => (
                <div key={msg.id} style={{ display: 'flex', flexDirection: 'column', alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                  <div
                    style={{
                      maxWidth: '90%', padding: '10px 13px', borderRadius: msg.role === 'user' ? '12px 12px 4px 12px' : '12px 12px 12px 4px',
                      background: msg.role === 'user' ? 'linear-gradient(135deg,#C4956A,#D4A878)' : surf2,
                      border: msg.role === 'user' ? 'none' : `1px solid ${border}`,
                    }}
                  >
                    {msg.role === 'user' ? (
                      <div style={{ fontFamily: 'Inter', fontSize: '12.5px', color: '#fff', lineHeight: 1.5 }}>{msg.text}</div>
                    ) : (
                      <MsgText text={msg.text} isDark={isDark} />
                    )}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '3px', padding: '0 4px' }}>
                    <Clock size={9} color={textSecondary} />
                    <span style={{ fontFamily: 'Inter', fontSize: '9px', color: textSecondary }}>{formatTime(msg.ts)}</span>
                  </div>
                  {msg.action?.type === 'navigate' && (
                    <button
                      onClick={() => handleNavigate(msg.action.lotId)}
                      style={{ marginTop: '6px', display: 'flex', alignItems: 'center', gap: '5px', background: isDark ? 'rgba(196,149,106,0.15)' : 'rgba(196,149,106,0.1)', border: `1px solid rgba(196,149,106,0.3)`, borderRadius: '8px', padding: '5px 10px', cursor: 'pointer', fontFamily: 'Inter', fontSize: '11px', fontWeight: 600, color: '#C4956A' }}
                    >
                      <MapPin size={11} /> {msg.action.label} <ArrowRight size={11} />
                    </button>
                  )}
                </div>
              ))}
              {thinking && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '10px 13px', background: surf2, borderRadius: '12px 12px 12px 4px', width: 'fit-content', border: `1px solid ${border}` }}>
                  <Loader2 size={12} color={textSecondary} style={{ animation: 'spin 1s linear infinite' }} />
                  <span style={{ fontFamily: 'Inter', fontSize: '11px', color: textSecondary }}>En réflexion…</span>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div style={{ padding: '10px', borderTop: `1px solid ${border}`, display: 'flex', gap: '8px', flexShrink: 0, background: surf }}>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
                placeholder="Posez votre question…"
                style={{
                  flex: 1, padding: '9px 13px', borderRadius: '9px', border: `1px solid ${border}`,
                  background: surf2, fontFamily: 'Inter', fontSize: '12px', color: textPrimary, outline: 'none',
                }}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || thinking}
                style={{
                  width: '38px', height: '38px', borderRadius: '9px', border: 'none', flexShrink: 0,
                  background: input.trim() && !thinking ? 'linear-gradient(135deg,#C4956A,#D4A878)' : (isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)'),
                  cursor: input.trim() && !thinking ? 'pointer' : 'default',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: input.trim() && !thinking ? '#fff' : textSecondary, transition: 'all 0.15s',
                }}
              >
                <Send size={14} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </>
  );
};
