import React from 'react';
import { ICON_MAP } from '../utils/iconMap';
import { CardStack } from './CardStack';
import type { WeddingLot } from '../types';
import type { AnimationSettings } from './SettingsPanel';

interface LotGroupProps {
  lot: WeddingLot;
  cardSettings: Record<string, Record<string, any>>;
  onCardSettingChange: (cardId: string, key: string, value: unknown) => void;
  animSettings: AnimationSettings;
  playingTrackId: string | null;
  onTogglePlay: (cardId: string) => void;
  globalTexture?: string;
}

export const LotGroup: React.FC<LotGroupProps> = ({
  lot,
  cardSettings,
  onCardSettingChange,
  animSettings,
  playingTrackId,
  onTogglePlay,
  globalTexture,
}) => {
  const configuredCount = lot.cards.filter(
    (c) => Object.keys(cardSettings[c.id] || {}).some((k) => {
      const v = cardSettings[c.id][k];
      return v && v !== '' && v !== false && v !== 0;
    })
  ).length;

  const LotIcon = ICON_MAP[lot.icon] ?? ICON_MAP['Sparkles'];

  return (
    <div style={{ position: 'absolute', left: lot.position.x, top: lot.position.y, width: '360px' }}>
      {/* Lot header */}
      <div style={{ marginBottom: '20px', paddingLeft: '4px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
          <LotIcon size={13} color={lot.accentColor} strokeWidth={1.8} />
          <h2
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: '11px',
              fontWeight: 700,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: 'rgba(255,255,255,0.92)',
              margin: 0,
              lineHeight: 1,
            }}
          >
            {lot.title}
          </h2>
          {configuredCount > 0 && (
            <span
              style={{
                fontFamily: 'Inter',
                fontSize: '10px',
                color: lot.accentColor,
                background: `${lot.accentColor}22`,
                borderRadius: '50px',
                padding: '2px 7px',
                marginLeft: 'auto',
              }}
            >
              {configuredCount}/{lot.cards.length}
            </span>
          )}
        </div>
        <p
          style={{
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: '13px',
            fontStyle: 'italic',
            color: 'rgba(255,255,255,0.35)',
            margin: 0,
            letterSpacing: '0.02em',
            paddingLeft: '21px',
          }}
        >
          {lot.subtitle}
        </p>
      </div>

      {/* Card stack */}
      <CardStack
        cards={lot.cards}
        cardSettings={cardSettings}
        onCardSettingChange={onCardSettingChange}
        animSettings={animSettings}
        playingTrackId={playingTrackId}
        onTogglePlay={onTogglePlay}
        globalTexture={globalTexture}
      />
    </div>
  );
};
