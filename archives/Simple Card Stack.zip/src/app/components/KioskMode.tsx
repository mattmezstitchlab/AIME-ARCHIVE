import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Clock } from 'lucide-react';
import { WeddingLot } from '../types';
import { ICON_MAP } from '../utils/iconMap';

interface KioskModeProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  coupleName: string;
  weddingDate: string;
  onClose: () => void;
}

function parseFrenchDate(dateStr: string): Date | null {
  const frenchMonths: Record<string, number> = {
    janvier: 0, février: 1, mars: 2, avril: 3, mai: 4, juin: 5,
    juillet: 6, août: 7, septembre: 8, octobre: 9, novembre: 10, décembre: 11,
  };
  const lower = dateStr.toLowerCase().trim();
  const parts = lower.split(/\s+/);
  if (parts.length === 3) {
    const day = parseInt(parts[0], 10);
    const month = frenchMonths[parts[1]];
    const year = parseInt(parts[2], 10);
    if (!isNaN(day) && month !== undefined && !isNaN(year)) {
      return new Date(year, month, day);
    }
  }
  return null;
}

function parseTimeFromSubtitle(subtitle: string): { hours: number; minutes: number } | null {
  const match = subtitle.match(/(\d{1,2})[h:](\d{2})/i);
  if (match) {
    return { hours: parseInt(match[1], 10), minutes: parseInt(match[2], 10) };
  }
  const matchHOnly = subtitle.match(/(\d{1,2})h/i);
  if (matchHOnly) {
    return { hours: parseInt(matchHOnly[1], 10), minutes: 0 };
  }
  return null;
}

function formatCountdown(diffMs: number): string {
  if (diffMs <= 0) return '';
  const totalMinutes = Math.floor(diffMs / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours > 0) return `Dans ${hours}h ${minutes}m`;
  return `Dans ${minutes}m`;
}

export default function KioskMode({ lots, cardSettings, coupleName, weddingDate, onClose }: KioskModeProps) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const programmeLot = lots.find(
    (l) => l.cards.some((c) => c.type === 'programme') || l.title.toLowerCase().includes('programme')
  );

  const timedCards = (programmeLot?.cards ?? [])
    .map((card) => {
      const time = parseTimeFromSubtitle(card.subtitle);
      return { card, time };
    })
    .filter((item) => item.time !== null)
    .sort((a, b) => {
      const aMin = a.time!.hours * 60 + a.time!.minutes;
      const bMin = b.time!.hours * 60 + b.time!.minutes;
      return aMin - bMin;
    });

  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  let currentIndex = -1;
  for (let i = 0; i < timedCards.length; i++) {
    const t = timedCards[i].time!;
    const cardMin = t.hours * 60 + t.minutes;
    if (cardMin <= nowMinutes) {
      currentIndex = i;
    }
  }

  const currentEntry = currentIndex >= 0 ? timedCards[currentIndex] : null;
  const nextEntry = currentIndex + 1 < timedCards.length ? timedCards[currentIndex + 1] : null;

  let countdownMs = 0;
  if (nextEntry) {
    const t = nextEntry.time!;
    const nextDate = new Date(now);
    nextDate.setHours(t.hours, t.minutes, 0, 0);
    if (nextDate < now) nextDate.setDate(nextDate.getDate() + 1);
    countdownMs = nextDate.getTime() - now.getTime();
  }

  const timeStr = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const dateStr = now.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const dateCapitalized = dateStr.charAt(0).toUpperCase() + dateStr.slice(1);

  const renderIcon = (iconName: string, size: number, color: string) => {
    const Icon = ICON_MAP[iconName];
    if (!Icon) return null;
    return <Icon size={size} color={color} />;
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'linear-gradient(135deg, #0a0010, #1a0530, #0d1a2e)',
        zIndex: 9999,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      <button
        onClick={onClose}
        style={{
          position: 'absolute',
          top: 24,
          right: 24,
          background: 'rgba(255,255,255,0.1)',
          border: 'none',
          borderRadius: '50%',
          width: 44,
          height: 44,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          color: '#fff',
          zIndex: 1,
        }}
      >
        <X size={20} />
      </button>

      <div
        style={{
          position: 'absolute',
          left: 40,
          top: '50%',
          transform: 'translateY(-50%)',
          display: 'flex',
          flexDirection: 'column',
          gap: 8,
          maxWidth: 220,
        }}
      >
        {timedCards.map((item, idx) => {
          const isPast = idx < currentIndex;
          const isCurrent = idx === currentIndex;
          const t = item.time!;
          const timeLabel = `${String(t.hours).padStart(2, '0')}h${String(t.minutes).padStart(2, '0')}`;
          return (
            <div
              key={item.card.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                opacity: isPast ? 0.3 : 1,
                transition: 'opacity 0.5s',
              }}
            >
              <div
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: '50%',
                  background: isCurrent ? '#C4956A' : isPast ? '#666' : '#fff',
                  flexShrink: 0,
                  boxShadow: isCurrent ? '0 0 8px #C4956A' : 'none',
                }}
              />
              <div>
                <div
                  style={{
                    fontSize: 11,
                    color: isCurrent ? '#C4956A' : isPast ? '#666' : 'rgba(255,255,255,0.5)',
                    fontWeight: 600,
                    letterSpacing: '0.05em',
                  }}
                >
                  {timeLabel}
                </div>
                <div
                  style={{
                    fontSize: 13,
                    color: isCurrent ? '#fff' : isPast ? '#555' : 'rgba(255,255,255,0.75)',
                    fontWeight: isCurrent ? 700 : 400,
                  }}
                >
                  {item.card.name}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div
        style={{
          position: 'absolute',
          right: 48,
          top: '50%',
          transform: 'translateY(-50%)',
          textAlign: 'right',
          display: 'flex',
          flexDirection: 'column',
          gap: 8,
          maxWidth: 200,
        }}
      >
        <div
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 32,
            color: '#fff',
            fontWeight: 600,
            lineHeight: 1.2,
          }}
        >
          {coupleName}
        </div>
        <div
          style={{
            fontSize: 14,
            color: 'rgba(255,255,255,0.5)',
            letterSpacing: '0.08em',
          }}
        >
          {weddingDate}
        </div>
      </div>

      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <div
          style={{
            fontSize: 96,
            fontWeight: 800,
            color: '#fff',
            letterSpacing: '-0.02em',
            lineHeight: 1,
            fontVariantNumeric: 'tabular-nums',
          }}
        >
          {timeStr}
        </div>
        <div
          style={{
            fontSize: 18,
            color: 'rgba(255,255,255,0.5)',
            letterSpacing: '0.06em',
          }}
        >
          {dateCapitalized}
        </div>
      </div>

      <div
        style={{
          marginTop: 56,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 32,
        }}
      >
        <AnimatePresence mode="wait">
          {currentEntry && (
            <motion.div
              key={currentEntry.card.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 16,
              }}
            >
              <div
                style={{
                  width: 80,
                  height: 80,
                  borderRadius: '50%',
                  background: 'rgba(255,255,255,0.12)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '1px solid rgba(255,255,255,0.2)',
                }}
              >
                {renderIcon(currentEntry.card.icon, 36, '#fff')}
              </div>
              <div
                style={{
                  fontSize: 48,
                  fontWeight: 800,
                  color: '#fff',
                  textTransform: 'uppercase',
                  letterSpacing: '0.06em',
                  textAlign: 'center',
                }}
              >
                {currentEntry.card.name}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {nextEntry && (
            <motion.div
              key={nextEntry.card.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 8,
              }}
            >
              <div
                style={{
                  fontSize: 14,
                  color: '#C4956A',
                  fontWeight: 600,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                }}
              >
                {formatCountdown(countdownMs)}
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  opacity: 0.6,
                }}
              >
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    background: 'rgba(255,255,255,0.08)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {renderIcon(nextEntry.card.icon, 16, '#fff')}
                </div>
                <div
                  style={{
                    fontSize: 22,
                    fontWeight: 600,
                    color: '#fff',
                  }}
                >
                  {nextEntry.card.name}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!currentEntry && timedCards.length === 0 && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              color: 'rgba(255,255,255,0.4)',
              fontSize: 18,
            }}
          >
            <Clock size={24} />
            <span>Aucun programme configuré</span>
          </div>
        )}
      </div>
    </div>
  );
}
