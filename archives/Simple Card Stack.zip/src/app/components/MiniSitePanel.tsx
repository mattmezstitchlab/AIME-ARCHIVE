import React, { useState } from 'react';
import {
  X, Globe, Square, CheckSquare, ChevronRight, ChevronDown,
  Eye, EyeOff, GripVertical, Users, Briefcase, Heart,
  Shield, AlertTriangle, ImagePlus, Upload, MapPin,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTheme } from '../contexts/ThemeContext';
import { ICON_MAP } from '../utils/iconMap';
import type { WeddingLot } from '../types';

// ── View modes ────────────────────────────────────────────────────────────────

type PanelMode = 'maries' | 'invite' | 'prestataire' | 'temoins' | 'surprise';

const PANEL_MODES: { id: PanelMode; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'maries',      label: 'Mariés',    icon: <Heart size={10} />,         desc: 'Vue complète — organisation & suivi' },
  { id: 'invite',      label: 'Invités',   icon: <Users size={10} />,         desc: 'RSVP, allergènes, programme' },
  { id: 'prestataire', label: 'Presta.',   icon: <Briefcase size={10} />,     desc: 'Brief prestataires & contacts' },
  { id: 'temoins',     label: 'Témoins',   icon: <Shield size={10} />,        desc: 'Coordination & surprises' },
  { id: 'surprise',    label: 'Surprise',  icon: <AlertTriangle size={10} />, desc: 'Masquage des surprises' },
];

const FIELD_VISIBILITY: Record<PanelMode, Set<string>> = {
  maries:      new Set(['all']),
  invite:      new Set(['time', 'lieu', 'dresscode', 'notes', 'menu', 'allergen', 'rsvp']),
  prestataire: new Set(['nom', 'tel', 'email', 'tarif', 'acompte', 'notes', 'contrat']),
  temoins:     new Set(['time', 'lieu', 'notes', 'budget', 'playlist']),
  surprise:    new Set(['nom', 'notes']),
};

const LOT_FILTER: Record<PanelMode, (lot: WeddingLot) => boolean> = {
  maries:      () => true,
  invite:      (l) => [1, 2, 5, 9, 10].includes(l.id),
  prestataire: (l) => [2, 3, 4, 5, 6, 7, 8, 9, 10].includes(l.id),
  temoins:     (l) => [1, 7, 8, 9, 10, 11].includes(l.id),
  surprise:    () => true,
};

const FIELD_LABELS: Record<string, string> = {
  time: 'Heure', lieu: 'Lieu', dresscode: 'Dress code', notes: 'Notes',
  nom: 'Prestataire', tel: 'Téléphone', email: 'Email',
  tarif: 'Tarif (€)', acompte: 'Acompte (€)', contrat_signe: 'Contrat signé',
  menu: 'Menu', allergen: 'Allergènes', invites: 'Invités', capacite: 'Capacité',
  adresse: 'Adresse', forfait: 'Forfait', livraison: 'Livraison',
  playlist: 'Playlist', moment: 'Moment', status: 'Statut',
  budget: 'Budget', destination: 'Destination',
};

// ── Props ─────────────────────────────────────────────────────────────────────

export interface MiniSitePanelProps {
  lots: WeddingLot[];
  selected: Set<string>;
  onToggleCard: (id: string) => void;
  onToggleLot: (lotId: number) => void;
  onGenerate: () => void;
  onClose: () => void;
  cardSettings: Record<string, Record<string, any>>;
  heroPhoto?: string;
  heroCoupleName?: string;
  heroDate?: string;
  heroVenue?: string;
  onHeroChange?: (field: string, value: string) => void;
}

// ── Component ─────────────────────────────────────────────────────────────────

export const MiniSitePanel: React.FC<MiniSitePanelProps> = ({
  lots, selected, onToggleCard, onToggleLot, onGenerate, onClose,
  cardSettings, heroPhoto = '', heroCoupleName = '', heroDate = '', heroVenue = '',
  onHeroChange,
}) => {
  const { isDark } = useTheme();

  const [mode, setMode] = useState<PanelMode>('maries');
  const [expandedLots, setExpandedLots] = useState<Set<number>>(new Set());
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const [hiddenFields, setHiddenFields] = useState<Set<string>>(new Set());
  const [lotOrder, setLotOrder] = useState<number[]>(lots.map((l) => l.id));
  const [dragOver, setDragOver] = useState<number | null>(null);
  const [dragLot, setDragLot] = useState<number | null>(null);
  const fileRef = React.useRef<HTMLInputElement>(null);

  /* ── Theme tokens ── */
  const surf     = isDark ? '#111020' : '#FFFFFF';
  const surf2    = isDark ? '#1A1830' : '#F5F5F7';
  const surf3    = isDark ? '#221F38' : '#EEEEEF';
  const border   = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.08)';
  const border2  = isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.05)';
  const tp       = isDark ? '#F0EEF8' : '#0F0F12';
  const ts       = isDark ? 'rgba(240,238,248,0.5)' : '#6B6B7B';
  const tm       = isDark ? 'rgba(240,238,248,0.28)' : 'rgba(15,15,18,0.3)';
  const accent   = '#C4956A';

  /* ── Helpers ── */
  const filteredLots = lotOrder
    .map((id) => lots.find((l) => l.id === id))
    .filter((l): l is WeddingLot => !!l && LOT_FILTER[mode](l));

  const toggleLotExpand  = (id: number) => setExpandedLots((p) => toggle(p, id));
  const toggleCardExpand = (id: string) => setExpandedCards((p) => toggle(p, id));
  const toggleField      = (k: string)  => setHiddenFields((p) => toggle(p, k));

  function toggle<T>(set: Set<T>, item: T): Set<T> {
    const next = new Set(set);
    if (next.has(item)) next.delete(item); else next.add(item);
    return next;
  }

  const isFieldVisible = (fieldKey: string) => {
    if (hiddenFields.has(fieldKey)) return false;
    if (mode === 'maries' || mode === 'surprise') return true;
    const allowed = FIELD_VISIBILITY[mode];
    if (allowed.has('all')) return true;
    return allowed.has(fieldKey.split(':')[0]);
  };

  const handleDragStart = (id: number) => setDragLot(id);
  const handleDragOver  = (e: React.DragEvent, id: number) => { e.preventDefault(); setDragOver(id); };
  const handleDrop      = (targetId: number) => {
    if (dragLot === null || dragLot === targetId) { setDragLot(null); setDragOver(null); return; }
    setLotOrder((prev) => {
      const next = [...prev];
      const fi = next.indexOf(dragLot), ti = next.indexOf(targetId);
      next.splice(fi, 1); next.splice(ti, 0, dragLot);
      return next;
    });
    setDragLot(null); setDragOver(null);
  };

  const handleHeroFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f && onHeroChange) onHeroChange('photo', URL.createObjectURL(f));
  };

  const total = selected.size;

  /* ── Render ── */
  return (
    <motion.div
      initial={{ x: 360, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 360, opacity: 0 }}
      transition={{ type: 'spring', damping: 30, stiffness: 320 }}
      style={{
        position: 'fixed', top: '50px', right: 0, bottom: 0, width: '340px',
        background: surf, borderLeft: `1px solid ${border}`,
        boxShadow: isDark ? '-8px 0 32px rgba(0,0,0,0.5)' : '-4px 0 24px rgba(0,0,0,0.06)',
        zIndex: 150, display: 'flex', flexDirection: 'column',
        transition: 'background 0.3s',
      }}
    >
      {/* ── Panel header ── */}
      <div style={{ padding: '14px 18px 12px', borderBottom: `1px solid ${border}`, flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
            <Globe size={13} color={tp} />
            <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 800, letterSpacing: '0.12em', textTransform: 'uppercase', color: tp }}>
              Mini-site
            </span>
          </div>
          <button
            onClick={onClose}
            style={{ width: '26px', height: '26px', borderRadius: '6px', border: 'none', background: 'transparent', cursor: 'pointer', color: tm, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.12s' }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = surf2; (e.currentTarget as HTMLElement).style.color = tp; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.color = tm; }}
          >
            <X size={13} />
          </button>
        </div>

        {/* Mode tabs */}
        <div style={{ display: 'flex', gap: '2px', background: surf2, borderRadius: '9px', padding: '3px' }}>
          {PANEL_MODES.map((m) => {
            const isActive = mode === m.id;
            const isSurprise = m.id === 'surprise';
            return (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                title={m.desc}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '3px',
                  padding: '5px 2px', borderRadius: '6px', border: 'none', cursor: 'pointer',
                  transition: 'all 0.15s', whiteSpace: 'nowrap',
                  fontFamily: 'Inter', fontSize: '9px', letterSpacing: '0.04em',
                  fontWeight: isActive ? 700 : 400,
                  background: isActive
                    ? (isSurprise ? (isDark ? '#2D1A4A' : '#1A0530') : (isDark ? 'rgba(255,255,255,0.12)' : '#FFFFFF'))
                    : 'transparent',
                  color: isActive
                    ? (isSurprise ? '#C084FC' : tp)
                    : tm,
                  boxShadow: isActive && !isSurprise
                    ? (isDark ? '0 1px 4px rgba(0,0,0,0.4)' : '0 1px 4px rgba(0,0,0,0.08)')
                    : 'none',
                }}
              >
                {m.icon}
                {m.label}
              </button>
            );
          })}
        </div>

        {/* Mode description */}
        <p style={{ fontFamily: 'Inter', fontSize: '9px', color: tm, margin: '7px 0 0', letterSpacing: '0.02em' }}>
          {PANEL_MODES.find((m) => m.id === mode)?.desc}
          {mode === 'surprise' && (
            <span style={{ color: '#C084FC', fontWeight: 600 }}> — les mariés ne verront pas ces éléments</span>
          )}
        </p>
      </div>

      {/* ── Hero section ── */}
      <div style={{ padding: '12px 18px', borderBottom: `1px solid ${border}`, flexShrink: 0 }}>
        <SectionLabel icon={<ImagePlus size={10} />} label="Section Hero" color={ts} />

        {/* Photo upload */}
        <div
          onClick={() => fileRef.current?.click()}
          style={{
            height: '68px', borderRadius: '10px', cursor: 'pointer', overflow: 'hidden',
            background: heroPhoto ? 'transparent' : surf2,
            border: `1.5px dashed ${border}`,
            marginBottom: '8px', marginTop: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative', transition: 'border-color 0.15s',
          }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = accent; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = border; }}
        >
          {heroPhoto ? (
            <img src={heroPhoto} alt="hero" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
              <Upload size={15} color={tm} />
              <span style={{ fontFamily: 'Inter', fontSize: '9px', color: tm }}>Photo de fond du Hero</span>
            </div>
          )}
        </div>
        <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleHeroFile} />

        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <HeroInput value={heroCoupleName} onChange={(v) => onHeroChange?.('coupleName', v)} placeholder="Noms des mariés…" icon={<Heart size={9} />} isDark={isDark} surf2={surf2} border={border} tp={tp} ts={ts} />
          <HeroInput value={heroDate}       onChange={(v) => onHeroChange?.('date', v)}       placeholder="Date du mariage…"  icon={<MapPin size={9} />} isDark={isDark} surf2={surf2} border={border} tp={tp} ts={ts} />
          <HeroInput value={heroVenue}      onChange={(v) => onHeroChange?.('venue', v)}      placeholder="Lieu de réception…" icon={<MapPin size={9} />} isDark={isDark} surf2={surf2} border={border} tp={tp} ts={ts} />
        </div>
      </div>

      {/* ── Lots list ── */}
      <div style={{ flex: 1, overflowY: 'auto', scrollbarWidth: 'none' }}>
        {filteredLots.length === 0 && (
          <div style={{ padding: '32px 18px', textAlign: 'center' }}>
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: tm }}>Aucun lot pour ce mode</span>
          </div>
        )}

        {filteredLots.map((lot) => {
          const LotIcon = ICON_MAP[lot.icon] ?? ICON_MAP['Wand2'];
          const allSelected = lot.cards.every((c) => selected.has(c.id));
          const someSelected = lot.cards.some((c) => selected.has(c.id));
          const isExpanded = expandedLots.has(lot.id);
          const isDragTarget = dragOver === lot.id;

          return (
            <div
              key={lot.id}
              draggable
              onDragStart={() => handleDragStart(lot.id)}
              onDragOver={(e) => handleDragOver(e, lot.id)}
              onDrop={() => handleDrop(lot.id)}
              onDragEnd={() => { setDragLot(null); setDragOver(null); }}
              style={{
                borderBottom: `1px solid ${border2}`,
                background: isDragTarget ? (isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.03)') : 'transparent',
                transition: 'background 0.12s',
              }}
            >
              {/* Lot header row */}
              <div style={{ display: 'flex', alignItems: 'center', padding: '9px 18px 5px', gap: '6px', userSelect: 'none' }}>
                <GripVertical size={11} color={tm} style={{ cursor: 'grab', flexShrink: 0 }} />

                <button
                  onClick={() => onToggleLot(lot.id)}
                  style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 0, flexShrink: 0, color: allSelected ? tp : someSelected ? ts : tm, display: 'flex' }}
                >
                  {allSelected ? <CheckSquare size={11} /> : <Square size={11} />}
                </button>

                {LotIcon && (
                  <LotIcon size={11} color={lot.accentColor} strokeWidth={2} style={{ flexShrink: 0 }} />
                )}

                <span
                  onClick={() => toggleLotExpand(lot.id)}
                  style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, color: tp, flex: 1, cursor: 'pointer', letterSpacing: '0.01em' }}
                >
                  {lot.title}
                </span>

                <span style={{ fontFamily: 'Inter', fontSize: '9px', color: tm, marginRight: '3px' }}>
                  {lot.cards.filter((c) => selected.has(c.id)).length}/{lot.cards.length}
                </span>

                <button
                  onClick={() => toggleLotExpand(lot.id)}
                  style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 0, color: tm, display: 'flex' }}
                >
                  {isExpanded ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
                </button>
              </div>

              {/* Cards + details */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.18 }}
                    style={{ overflow: 'hidden' }}
                  >
                    <div style={{ paddingBottom: '6px' }}>
                      {lot.cards.map((card) => {
                        const isCardExpanded = expandedCards.has(card.id);
                        const isSelected = selected.has(card.id);
                        const settings = cardSettings[card.id] || {};
                        const settingEntries = Object.entries(settings).filter(
                          ([k, v]) => v !== undefined && v !== null && v !== '' && v !== false && FIELD_LABELS[k]
                        );

                        return (
                          <div key={card.id} style={{ paddingLeft: '38px', paddingRight: '18px' }}>
                            {/* Card row */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '3px 0', userSelect: 'none' }}>
                              <button
                                onClick={() => onToggleCard(card.id)}
                                style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 0, flexShrink: 0, color: isSelected ? tp : tm, display: 'flex' }}
                              >
                                {isSelected ? <CheckSquare size={10} /> : <Square size={10} />}
                              </button>

                              <span
                                onClick={() => toggleCardExpand(card.id)}
                                style={{ fontFamily: 'Inter', fontSize: '11px', color: isSelected ? tp : ts, flex: 1, cursor: 'pointer' }}
                              >
                                {card.name}
                              </span>

                              {settingEntries.length > 0 && (
                                <button
                                  onClick={() => toggleCardExpand(card.id)}
                                  style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 0, color: tm, display: 'flex' }}
                                >
                                  {isCardExpanded ? <ChevronDown size={10} /> : <ChevronRight size={10} />}
                                </button>
                              )}
                            </div>

                            {/* Field sub-items */}
                            <AnimatePresence>
                              {isCardExpanded && settingEntries.length > 0 && (
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: 'auto', opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  transition={{ duration: 0.15 }}
                                  style={{ overflow: 'hidden' }}
                                >
                                  <div style={{ paddingLeft: '16px', paddingBottom: '6px', paddingTop: '2px', display: 'flex', flexDirection: 'column', gap: '1px' }}>
                                    {settingEntries.map(([key, value]) => {
                                      const fieldKey = `${card.id}:${key}`;
                                      const visible = isFieldVisible(fieldKey);
                                      const label = FIELD_LABELS[key] || key;
                                      const displayVal = typeof value === 'boolean' ? (value ? 'Oui' : 'Non') : String(value).slice(0, 32);
                                      if (!displayVal || displayVal === 'undefined') return null;

                                      return (
                                        <div
                                          key={key}
                                          style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '2px 6px', borderRadius: '5px', opacity: visible ? 1 : 0.38, background: 'transparent', transition: 'all 0.12s' }}
                                          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.03)'; }}
                                          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
                                        >
                                          <button
                                            onClick={() => toggleField(fieldKey)}
                                            title={visible ? 'Masquer dans le mini-site' : 'Afficher dans le mini-site'}
                                            style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 0, flexShrink: 0, color: visible ? accent : tm, display: 'flex', transition: 'color 0.12s' }}
                                          >
                                            {visible ? <Eye size={9} /> : <EyeOff size={9} />}
                                          </button>

                                          <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: tm, letterSpacing: '0.05em', textTransform: 'uppercase', flexShrink: 0, width: '54px' }}>
                                            {label}
                                          </span>

                                          <span style={{ fontFamily: 'Inter', fontSize: '10px', color: ts, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
                                            {displayVal}
                                          </span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* ── Generate footer ── */}
      <div style={{ padding: '12px 18px 16px', borderTop: `1px solid ${border}`, flexShrink: 0, background: surf }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
          <span style={{ fontFamily: 'Inter', fontSize: '10px', color: tm }}>
            {total} carte{total !== 1 ? 's' : ''} sélectionnée{total !== 1 ? 's' : ''}
          </span>
          {hiddenFields.size > 0 && (
            <span style={{ fontFamily: 'Inter', fontSize: '9px', color: accent, fontWeight: 600 }}>
              {hiddenFields.size} champ{hiddenFields.size > 1 ? 's' : ''} masqué{hiddenFields.size > 1 ? 's' : ''}
            </span>
          )}
        </div>

        <button
          onClick={onGenerate}
          disabled={total === 0}
          style={{
            width: '100%', padding: '10px 16px',
            background: total > 0
              ? (isDark ? 'rgba(255,255,255,0.95)' : '#0F0F12')
              : surf3,
            color: total > 0
              ? (isDark ? '#0F0F12' : '#FFFFFF')
              : tm,
            border: 'none', borderRadius: '10px',
            cursor: total > 0 ? 'pointer' : 'default',
            fontFamily: 'Inter', fontSize: '11px', fontWeight: 700,
            letterSpacing: '0.08em', textTransform: 'uppercase',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            transition: 'all 0.15s',
          }}
        >
          <Globe size={13} />
          Générer le Mini-site
          <ChevronRight size={13} />
        </button>
      </div>
    </motion.div>
  );
};

/* ── Primitives ─────────────────────────────────────────────────────────────── */

const SectionLabel: React.FC<{ icon: React.ReactNode; label: string; color: string }> = ({ icon, label, color }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
    <span style={{ color }}>{icon}</span>
    <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color }}>
      {label}
    </span>
  </div>
);

const HeroInput: React.FC<{
  value: string; onChange: (v: string) => void; placeholder: string; icon: React.ReactNode;
  isDark: boolean; surf2: string; border: string; tp: string; ts: string;
}> = ({ value, onChange, placeholder, icon, isDark, surf2, border, tp, ts }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: '7px', background: surf2, borderRadius: '7px', padding: '6px 9px', border: `1px solid ${border}`, transition: 'border-color 0.12s' }}>
    <span style={{ color: ts, flexShrink: 0 }}>{icon}</span>
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        fontFamily: 'Inter', fontSize: '11px', color: tp,
        background: 'transparent', border: 'none', outline: 'none', flex: 1,
      }}
      onFocus={(e) => { (e.target.parentElement as HTMLElement).style.borderColor = '#C4956A'; }}
      onBlur={(e) => { (e.target.parentElement as HTMLElement).style.borderColor = border; }}
    />
    {value && (
      <span style={{ fontFamily: 'Inter', fontSize: '8px', color: isDark ? 'rgba(240,238,248,0.3)' : 'rgba(15,15,18,0.3)', flexShrink: 0, background: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)', borderRadius: '4px', padding: '1px 4px' }}>
        {value.length}
      </span>
    )}
  </div>
);
