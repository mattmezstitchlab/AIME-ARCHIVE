import React, { useState, useMemo } from 'react';
import { X, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { WeddingLot } from '../types';
import { ICON_MAP } from '../utils/iconMap';

interface ChecklistPanelProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  weddingDate: string;
  onClose: () => void;
}

type Priority = 'urgent' | 'important' | 'a-prevoir' | 'fait';

const FRENCH_MONTHS: Record<string, number> = {
  janvier: 0, février: 1, mars: 2, avril: 3, mai: 4, juin: 5,
  juillet: 6, août: 7, septembre: 8, octobre: 9, novembre: 10, décembre: 11,
};

function parseFrenchDate(dateStr: string): Date | null {
  const parts = dateStr.toLowerCase().trim().split(/\s+/);
  if (parts.length < 3) return null;
  const day = parseInt(parts[0], 10);
  const month = FRENCH_MONTHS[parts[1]];
  const year = parseInt(parts[2], 10);
  if (isNaN(day) || month === undefined || isNaN(year)) return null;
  return new Date(year, month, day);
}

const PRIORITY_ORDER: Record<Priority, number> = { urgent: 0, important: 1, 'a-prevoir': 2, fait: 3 };

const PRIORITY_LABELS: Record<Priority, string> = {
  urgent: 'URGENT',
  important: 'IMPORTANT',
  'a-prevoir': 'À PRÉVOIR',
  fait: 'FAIT',
};

const PRIORITY_COLORS: Record<Priority, { bg: string; text: string }> = {
  urgent: { bg: 'rgba(239,68,68,0.2)', text: 'rgb(239,68,68)' },
  important: { bg: 'rgba(249,115,22,0.2)', text: 'rgb(249,115,22)' },
  'a-prevoir': { bg: 'rgba(234,179,8,0.2)', text: 'rgb(234,179,8)' },
  fait: { bg: 'rgba(34,197,94,0.2)', text: 'rgb(34,197,94)' },
};

const AI_MOCK_REPORT = `Analyse IA de votre préparation

Sur la base de l'état actuel de vos prestataires, voici mes recommandations prioritaires :

1. Délais critiques : Plusieurs postes clés (traiteur, photographe, DJ) doivent être confirmés dans les 30 prochains jours pour éviter les indisponibilités.

2. Budget : Vous avez engagé environ 60% de votre enveloppe. Il reste de la marge, mais anticipez les imprévus (+10% conseillé).

3. Logistique invités : La collecte des régimes alimentaires et des hébergements devrait démarrer maintenant.

4. Rétro-planning : Envoi des faire-parts recommandé au moins 3 mois avant la date.

5. Beauté & coiffure : Réservez vos essais dès maintenant — les meilleurs créneaux partent vite.

Bon courage pour la suite de vos préparatifs !`;

export const ChecklistPanel: React.FC<ChecklistPanelProps> = ({
  lots,
  cardSettings,
  weddingDate,
  onClose,
}) => {
  const [aiLoading, setAiLoading] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);

  const weddingDateParsed = useMemo(() => parseFrenchDate(weddingDate), [weddingDate]);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const daysUntil = useMemo(() => {
    if (!weddingDateParsed) return null;
    const diff = weddingDateParsed.getTime() - today.getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }, [weddingDateParsed]);

  const items = useMemo(() => {
    const result: Array<{
      cardId: string;
      cardName: string;
      cardIcon: string;
      lotTitle: string;
      priority: Priority;
    }> = [];

    for (const lot of lots) {
      for (const card of lot.cards) {
        const s = cardSettings[card.id] || {};
        const status = s.status as string | undefined;
        const isDone = status === 'confirmed' || status === 'paid';

        if (isDone) {
          result.push({ cardId: card.id, cardName: card.name, cardIcon: card.icon, lotTitle: lot.title, priority: 'fait' });
          continue;
        }

        let priority: Priority = 'a-prevoir';
        if (daysUntil !== null && daysUntil < 90) priority = 'urgent';
        else if (daysUntil !== null && daysUntil < 180) priority = 'important';

        result.push({ cardId: card.id, cardName: card.name, cardIcon: card.icon, lotTitle: lot.title, priority });
      }
    }

    result.sort((a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority]);
    return result;
  }, [lots, cardSettings, daysUntil]);

  const total = items.length;
  const done = items.filter(i => i.priority === 'fait').length;
  const progress = total > 0 ? (done / total) * 100 : 0;

  const handleGenerateReport = () => {
    setAiLoading(true);
    setAiReport(null);
    setTimeout(() => {
      setAiLoading(false);
      setAiReport(AI_MOCK_REPORT);
    }, 1500);
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 52,
        right: 0,
        width: 380,
        bottom: 0,
        background: '#0c0814',
        borderLeft: '1px solid rgba(255,255,255,0.08)',
        zIndex: 50,
        display: 'flex',
        flexDirection: 'column',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '16px 20px',
        borderBottom: '1px solid rgba(255,255,255,0.08)',
        flexShrink: 0,
      }}>
        <div>
          <div style={{ color: 'white', fontSize: 16, fontWeight: 600, letterSpacing: '-0.02em' }}>Checklist</div>
          {daysUntil !== null && (
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, marginTop: 2 }}>
              {daysUntil > 0 ? `J-${daysUntil} avant le grand jour` : daysUntil === 0 ? "C'est aujourd'hui !" : `J+${Math.abs(daysUntil)}`}
            </div>
          )}
        </div>
        <button
          onClick={onClose}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.5)', display: 'flex', alignItems: 'center' }}
        >
          <X size={18} />
        </button>
      </div>

      {/* Progress bar */}
      <div style={{ padding: '12px 20px', borderBottom: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11 }}>Progression</span>
          <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: 600 }}>{done} / {total}</span>
        </div>
        <div style={{ height: 6, background: 'rgba(255,255,255,0.08)', borderRadius: 99, overflow: 'hidden' }}>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            style={{ height: '100%', background: 'linear-gradient(90deg, rgb(168,85,247), rgb(59,130,246))', borderRadius: 99 }}
          />
        </div>
      </div>

      {/* Scrollable list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px' }}>
        {items.map((item, idx) => {
          const IconComp = ICON_MAP[item.cardIcon];
          const colors = PRIORITY_COLORS[item.priority];
          const isFait = item.priority === 'fait';
          return (
            <motion.div
              key={item.cardId}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.03, duration: 0.3 }}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '10px 12px',
                borderRadius: 8,
                marginBottom: 4,
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.05)',
                opacity: isFait ? 0.5 : 1,
              }}
            >
              <span style={{
                fontSize: 9,
                fontWeight: 700,
                letterSpacing: '0.05em',
                padding: '3px 6px',
                borderRadius: 4,
                background: colors.bg,
                color: colors.text,
                flexShrink: 0,
                whiteSpace: 'nowrap',
              }}>
                {PRIORITY_LABELS[item.priority]}
              </span>
              {IconComp && <IconComp size={14} color="rgba(255,255,255,0.4)" style={{ flexShrink: 0 }} />}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  color: 'rgba(255,255,255,0.85)',
                  fontSize: 12,
                  fontWeight: 500,
                  textDecoration: isFait ? 'line-through' : 'none',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}>
                  {item.cardName}
                </div>
                <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 10, marginTop: 1 }}>{item.lotTitle}</div>
              </div>
              {!isFait && (
                <button style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: 'rgba(255,255,255,0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 2,
                  fontSize: 10,
                  whiteSpace: 'nowrap',
                  padding: 0,
                }}>
                  Configurer <ChevronRight size={10} />
                </button>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* AI Report section */}
      <div style={{ padding: '12px 16px 16px', borderTop: '1px solid rgba(255,255,255,0.08)', flexShrink: 0 }}>
        {aiReport ? (
          <div style={{
            background: 'rgba(168,85,247,0.08)',
            border: '1px solid rgba(168,85,247,0.2)',
            borderRadius: 10,
            padding: '12px',
            marginBottom: 10,
            maxHeight: 180,
            overflowY: 'auto',
          }}>
            <div style={{ color: 'rgba(168,85,247,0.9)', fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>
              Rapport IA
            </div>
            <pre style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11, lineHeight: 1.6, whiteSpace: 'pre-wrap', margin: 0, fontFamily: 'Inter, sans-serif' }}>
              {aiReport}
            </pre>
          </div>
        ) : null}
        <button
          onClick={handleGenerateReport}
          disabled={aiLoading}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: 8,
            background: aiLoading ? 'rgba(168,85,247,0.15)' : 'rgba(168,85,247,0.2)',
            border: '1px solid rgba(168,85,247,0.3)',
            color: aiLoading ? 'rgba(168,85,247,0.5)' : 'rgb(168,85,247)',
            fontSize: 13,
            fontWeight: 600,
            cursor: aiLoading ? 'not-allowed' : 'pointer',
            transition: 'all 0.2s',
            fontFamily: 'Inter, sans-serif',
          }}
        >
          {aiLoading ? 'Analyse en cours...' : 'Générer rapport IA'}
        </button>
      </div>
    </div>
  );
};
