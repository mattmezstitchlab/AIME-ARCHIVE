import React, { useRef } from 'react';
import { WeddingLot, CanvasTransform } from '../types';
import { ICON_MAP } from '../utils/iconMap';

interface MiniMapProps {
  lots: WeddingLot[];
  transform: CanvasTransform;
  onNavigate: (x: number, y: number) => void;
}

const CANVAS_MIN_X = 80;
const CANVAS_MIN_Y = 80;
const CANVAS_MAX_X = 2400;
const CANVAS_MAX_Y = 2400;
const CANVAS_W = CANVAS_MAX_X - CANVAS_MIN_X;
const CANVAS_H = CANVAS_MAX_Y - CANVAS_MIN_Y;

const MAP_W = 180;
const MAP_H = 120;

const LOT_W = 320;
const LOT_H = 200;

function toMapX(canvasX: number) {
  return ((canvasX - CANVAS_MIN_X) / CANVAS_W) * MAP_W;
}

function toMapY(canvasY: number) {
  return ((canvasY - CANVAS_MIN_Y) / CANVAS_H) * MAP_H;
}

export default function MiniMap({ lots, transform, onNavigate }: MiniMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);

  const viewportW = (typeof window !== 'undefined' ? window.innerWidth : 1280) / transform.scale;
  const viewportH = (typeof window !== 'undefined' ? window.innerHeight : 800) / transform.scale;

  const vpCanvasX = -transform.x / transform.scale;
  const vpCanvasY = -transform.y / transform.scale;

  const vpMapX = toMapX(vpCanvasX);
  const vpMapY = toMapY(vpCanvasY);
  const vpMapW = (viewportW / CANVAS_W) * MAP_W;
  const vpMapH = (viewportH / CANVAS_H) * MAP_H;

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mapRef.current) return;
    const rect = mapRef.current.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    const relY = e.clientY - rect.top;
    const canvasX = CANVAS_MIN_X + (relX / MAP_W) * CANVAS_W;
    const canvasY = CANVAS_MIN_Y + (relY / MAP_H) * CANVAS_H;
    onNavigate(canvasX, canvasY);
  };

  const zoomPct = Math.round(transform.scale * 100);

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 24,
        right: 24,
        zIndex: 30,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-end',
        gap: 6,
        pointerEvents: 'auto',
      }}
    >
      

      <div
        style={{
          fontSize: 11,
          fontWeight: 600,
          color: 'rgba(255,255,255,0.5)',
          letterSpacing: '0.04em',
          paddingRight: 2,
        }}
      >
        {zoomPct}%
      </div>
    </div>
  );
}
