import React, { useRef, useCallback, useEffect } from 'react';
import type { CanvasTransform, BgSettings, Tool } from '../types';

interface InfiniteCanvasProps {
  transform: CanvasTransform;
  onTransformChange: (t: CanvasTransform) => void;
  activeTool: Tool;
  bgSettings: BgSettings;
  children: React.ReactNode;
}

const MIN_SCALE = 0.12;
const MAX_SCALE = 3;
const ZOOM_SPEED = 0.0008;

export const InfiniteCanvas: React.FC<InfiniteCanvasProps> = ({
  transform,
  onTransformChange,
  activeTool,
  bgSettings,
  children,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isPanning = useRef(false);
  const lastMouse = useRef({ x: 0, y: 0 });
  const transformRef = useRef(transform);
  transformRef.current = transform;

  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    const rect = containerRef.current!.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const t = transformRef.current;
    const rawDelta = e.deltaMode === 1 ? e.deltaY * 20 : e.deltaY;
    const factor = Math.pow(2, -rawDelta * ZOOM_SPEED);
    const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, t.scale * factor));
    const ratio = newScale / t.scale;
    onTransformChange({
      x: mx - (mx - t.x) * ratio,
      y: my - (my - t.y) * ratio,
      scale: newScale,
    });
  }, [onTransformChange]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (activeTool !== 'hand') return;
    isPanning.current = true;
    lastMouse.current = { x: e.clientX, y: e.clientY };
    e.preventDefault();
  }, [activeTool]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isPanning.current) return;
    const dx = e.clientX - lastMouse.current.x;
    const dy = e.clientY - lastMouse.current.y;
    lastMouse.current = { x: e.clientX, y: e.clientY };
    const t = transformRef.current;
    onTransformChange({ ...t, x: t.x + dx, y: t.y + dy });
  }, [onTransformChange]);

  const stopPan = useCallback(() => { isPanning.current = false; }, []);

  const handleClick = useCallback((e: React.MouseEvent) => {
    if (activeTool !== 'zoom-in' && activeTool !== 'zoom-out') return;
    const rect = containerRef.current!.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const t = transformRef.current;
    const factor = activeTool === 'zoom-in' ? 1.4 : 0.7;
    const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, t.scale * factor));
    const ratio = newScale / t.scale;
    onTransformChange({ x: mx - (mx - t.x) * ratio, y: my - (my - t.y) * ratio, scale: newScale });
  }, [activeTool, onTransformChange]);

  // Touch
  const touchRef = useRef<{ x: number; y: number; dist: number } | null>(null);
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      touchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, dist: 0 };
    } else if (e.touches.length === 2) {
      const dx = e.touches[1].clientX - e.touches[0].clientX;
      const dy = e.touches[1].clientY - e.touches[0].clientY;
      touchRef.current = {
        x: (e.touches[0].clientX + e.touches[1].clientX) / 2,
        y: (e.touches[0].clientY + e.touches[1].clientY) / 2,
        dist: Math.sqrt(dx * dx + dy * dy),
      };
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (!touchRef.current) return;
    const t = transformRef.current;
    if (e.touches.length === 1) {
      const dx = e.touches[0].clientX - touchRef.current.x;
      const dy = e.touches[0].clientY - touchRef.current.y;
      touchRef.current = { ...touchRef.current, x: e.touches[0].clientX, y: e.touches[0].clientY };
      onTransformChange({ ...t, x: t.x + dx, y: t.y + dy });
    } else if (e.touches.length === 2) {
      const dx = e.touches[1].clientX - e.touches[0].clientX;
      const dy = e.touches[1].clientY - e.touches[0].clientY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      const rect = containerRef.current!.getBoundingClientRect();
      const mx = cx - rect.left;
      const my = cy - rect.top;
      const factor = dist / (touchRef.current.dist || dist);
      const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, t.scale * factor));
      const ratio = newScale / t.scale;
      touchRef.current = { x: cx, y: cy, dist };
      onTransformChange({ x: mx - (mx - t.x) * ratio, y: my - (my - t.y) * ratio, scale: newScale });
    }
  }, [onTransformChange]);

  const cursor =
    activeTool === 'hand' ? (isPanning.current ? 'grabbing' : 'grab')
    : activeTool === 'zoom-in' ? 'zoom-in'
    : activeTool === 'zoom-out' ? 'zoom-out'
    : 'default';

  // Dot grid — use CSS transform (GPU-composited, no repaint during pan)
  const dotSpacing = 28 * transform.scale;
  const dotRadius = Math.max(0.6, transform.scale * 0.9);
  const ox = ((transform.x % dotSpacing) + dotSpacing) % dotSpacing;
  const oy = ((transform.y % dotSpacing) + dotSpacing) % dotSpacing;

  let bgCSS: React.CSSProperties = {};
  if (bgSettings.type === 'color') bgCSS.backgroundColor = bgSettings.value;
  else if (bgSettings.type === 'gradient') bgCSS.background = bgSettings.value;

  const dotAlpha = bgSettings.type === 'video' ? 0.3 : 0.16;

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        inset: 0,
        overflow: 'hidden',
        cursor,
        userSelect: 'none',
        // force GPU layer on container to avoid gradient banding artifacts
        transform: 'translateZ(0)',
        ...bgCSS,
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={stopPan}
      onMouseLeave={stopPan}
      onClick={handleClick}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={() => { touchRef.current = null; }}
    >
      {/* Background video */}
      {bgSettings.type === 'video' && bgSettings.value && (
        <video
          key={bgSettings.value}
          autoPlay loop muted playsInline
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 }}
        >
          <source src={bgSettings.value} />
        </video>
      )}

      {/* ── Dot grid — GPU-composited via CSS transform, zero repaint on pan ── */}
      <div
        aria-hidden
        style={{
          position: 'absolute',
          // Extend slightly beyond viewport so offset doesn't show edge
          top: '-40px', left: '-40px', right: '-40px', bottom: '-40px',
          pointerEvents: 'none',
          zIndex: 1,
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `radial-gradient(circle, rgba(255,255,255,${dotAlpha}) ${dotRadius}px, transparent ${dotRadius}px)`,
            backgroundSize: `${dotSpacing}px ${dotSpacing}px`,
            // Use transform instead of background-position → GPU-composited
            transform: `translate(${ox}px, ${oy}px)`,
            willChange: 'transform',
          }}
        />
      </div>

      {/* ── Canvas content ── */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transformOrigin: '0 0',
          transform: `translate(${transform.x}px,${transform.y}px) scale(${transform.scale})`,
          willChange: 'transform',
          zIndex: 2,
          // Isolate compositing so canvas children don't bleed into background
          isolation: 'isolate',
        }}
      >
        {children}
      </div>
    </div>
  );
};
