import React, { useState } from 'react';
import { X, ChevronDown, ChevronRight } from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { WeddingLot, CardStatus } from '../types';
import { ICON_MAP } from '../utils/iconMap';

interface BudgetDashboardProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  totalBudget: number;
  onTotalBudgetChange: (v: number) => void;
  onClose: () => void;
}

const STATUS_LABELS: Record<CardStatus, string> = {
  todo: 'À faire',
  waiting: 'En attente',
  confirmed: 'Confirmé',
  paid: 'Payé',
};

const STATUS_COLORS: Record<CardStatus, string> = {
  todo: 'rgba(255,255,255,0.15)',
  waiting: 'rgba(245,158,11,0.25)',
  confirmed: 'rgba(34,197,94,0.25)',
  paid: 'rgba(59,130,246,0.25)',
};

const STATUS_TEXT: Record<CardStatus, string> = {
  todo: 'rgba(255,255,255,0.6)',
  waiting: 'rgb(245,158,11)',
  confirmed: 'rgb(34,197,94)',
  paid: 'rgb(59,130,246)',
};

function formatEur(n: number) {
  return n.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
}

export const BudgetDashboard: React.FC<BudgetDashboardProps> = ({
  lots,
  cardSettings,
  totalBudget,
  onTotalBudgetChange,
  onClose,
}) => {
  const [expandedLots, setExpandedLots] = useState<Set<number>>(new Set());
  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetInput, setBudgetInput] = useState(String(totalBudget));

  const toggleLot = (id: number) => {
    setExpandedLots(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  let totalEngaged = 0;
  let totalAcomptes = 0;

  const lotStats = lots.map(lot => {
    let lotBudget = 0;
    let lotAcompte = 0;
    const cardItems = lot.cards.map(card => {
      const s = cardSettings[card.id] || {};
      const budget = Number(s.budget) || 0;
      const acompte = Number(s.acompte) || 0;
      lotBudget += budget;
      lotAcompte += acompte;
      return { card, budget, acompte, status: (s.status as CardStatus) || 'todo' };
    });
    totalEngaged += lotBudget;
    totalAcomptes += lotAcompte;
    return { lot, lotBudget, lotAcompte, cardItems };
  });

  const restant = totalBudget - totalEngaged;
  const pieData = [
    { name: 'Engagé', value: Math.max(totalEngaged - totalAcomptes, 0), color: 'rgb(168,85,247)' },
    { name: 'Acomptes', value: totalAcomptes, color: 'rgb(59,130,246)' },
    { name: 'Restant', value: Math.max(restant, 0), color: 'rgba(255,255,255,0.1)' },
  ];

  return (
    <div
      style={{
        position: 'fixed',
        top: 52,
        right: 0,
        width: 420,
        bottom: 0,
        background: '#0c0814',
        borderLeft: '1px solid rgba(255,255,255,0.08)',
        zIndex: 50,
        display: 'flex',
        flexDirection: 'column',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '16px 20px',
        borderBottom: '1px solid rgba(255,255,255,0.08)',
        flexShrink: 0,
      }}>
        <span style={{ color: 'white', fontSize: 16, fontWeight: 600, letterSpacing: '-0.02em' }}>Budget</span>
        <button
          onClick={onClose}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.5)', display: 'flex', alignItems: 'center' }}
        >
          <X size={18} />
        </button>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>

        {/* Enveloppe totale */}
        <div style={{
          background: 'rgba(255,255,255,0.04)',
          borderRadius: 12,
          padding: '16px',
          marginBottom: 20,
          border: '1px solid rgba(255,255,255,0.07)',
        }}>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
            Enveloppe totale
          </div>
          {editingBudget ? (
            <input
              autoFocus
              type="number"
              value={budgetInput}
              onChange={e => setBudgetInput(e.target.value)}
              onBlur={() => {
                const val = Number(budgetInput);
                if (!isNaN(val) && val >= 0) onTotalBudgetChange(val);
                setEditingBudget(false);
              }}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  const val = Number(budgetInput);
                  if (!isNaN(val) && val >= 0) onTotalBudgetChange(val);
                  setEditingBudget(false);
                }
              }}
              style={{
                background: 'transparent',
                border: 'none',
                outline: 'none',
                color: 'white',
                fontSize: 28,
                fontWeight: 700,
                width: '100%',
                letterSpacing: '-0.03em',
              }}
            />
          ) : (
            <div
              onClick={() => { setEditingBudget(true); setBudgetInput(String(totalBudget)); }}
              style={{ color: 'white', fontSize: 28, fontWeight: 700, letterSpacing: '-0.03em', cursor: 'text' }}
            >
              {formatEur(totalBudget)}
            </div>
          )}
        </div>

        {/* Donut + summary */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 16,
          marginBottom: 20,
          background: 'rgba(255,255,255,0.04)',
          borderRadius: 12,
          padding: '16px',
          border: '1px solid rgba(255,255,255,0.07)',
        }}>
          <div style={{ width: 120, height: 120, flexShrink: 0 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={38}
                  outerRadius={56}
                  paddingAngle={2}
                  dataKey="value"
                  strokeWidth={0}
                >
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: '#1a1025', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => formatEur(v)}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Engagé</div>
              <div style={{ color: 'rgb(168,85,247)', fontSize: 18, fontWeight: 700 }}>{formatEur(totalEngaged)}</div>
            </div>
            <div>
              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Acomptes versés</div>
              <div style={{ color: 'rgb(59,130,246)', fontSize: 18, fontWeight: 700 }}>{formatEur(totalAcomptes)}</div>
            </div>
            <div>
              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Restant</div>
              <div style={{ color: restant < 0 ? 'rgb(239,68,68)' : 'rgba(255,255,255,0.9)', fontSize: 18, fontWeight: 700 }}>{formatEur(restant)}</div>
            </div>
          </div>
        </div>

        {/* Lots list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {lotStats.map(({ lot, lotBudget, cardItems }) => {
            const isExpanded = expandedLots.has(lot.id);
            const cardsWithBudget = cardItems.filter(ci => ci.budget > 0);
            return (
              <div
                key={lot.id}
                style={{
                  background: 'rgba(255,255,255,0.04)',
                  borderRadius: 10,
                  border: '1px solid rgba(255,255,255,0.07)',
                  overflow: 'hidden',
                }}
              >
                <button
                  onClick={() => toggleLot(lot.id)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    padding: '12px 14px',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    textAlign: 'left',
                  }}
                >
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: lot.accentColor, flexShrink: 0 }} />
                  <span style={{ flex: 1, color: 'rgba(255,255,255,0.9)', fontSize: 13, fontWeight: 500 }}>{lot.title}</span>
                  <span style={{ color: lot.accentColor, fontSize: 13, fontWeight: 700, marginRight: 6 }}>{formatEur(lotBudget)}</span>
                  {isExpanded ? <ChevronDown size={14} color="rgba(255,255,255,0.4)" /> : <ChevronRight size={14} color="rgba(255,255,255,0.4)" />}
                </button>

                {isExpanded && (
                  <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', padding: '8px 14px 12px' }}>
                    {cardsWithBudget.length === 0 ? (
                      <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 12, padding: '6px 0' }}>Aucun budget renseigné</div>
                    ) : (
                      cardsWithBudget.map(({ card, budget, status }) => {
                        const IconComp = ICON_MAP[card.icon];
                        return (
                          <div key={card.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                            {IconComp && <IconComp size={13} color="rgba(255,255,255,0.4)" />}
                            <span style={{ flex: 1, color: 'rgba(255,255,255,0.7)', fontSize: 12 }}>{card.name}</span>
                            <span style={{ color: 'white', fontSize: 12, fontWeight: 600, marginRight: 8 }}>{formatEur(budget)}</span>
                            <span style={{
                              fontSize: 10,
                              padding: '2px 6px',
                              borderRadius: 4,
                              background: STATUS_COLORS[status],
                              color: STATUS_TEXT[status],
                              fontWeight: 500,
                            }}>
                              {STATUS_LABELS[status]}
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div style={{
          marginTop: 20,
          padding: '14px',
          background: 'rgba(255,255,255,0.03)',
          borderRadius: 10,
          border: '1px solid rgba(255,255,255,0.06)',
        }}>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Légende</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {(Object.keys(STATUS_LABELS) as CardStatus[]).map(s => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 8, height: 8, borderRadius: 2, background: STATUS_COLORS[s] }} />
                <span style={{ color: STATUS_TEXT[s], fontSize: 11 }}>{STATUS_LABELS[s]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
