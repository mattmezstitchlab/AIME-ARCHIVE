import { WeddingLot } from '../types';

const FRENCH_MONTHS: Record<string, number> = {
  janvier: 0, février: 1, mars: 2, avril: 3, mai: 4, juin: 5,
  juillet: 6, août: 7, septembre: 8, octobre: 9, novembre: 10, décembre: 11,
};

function parseFrenchDate(dateStr: string): Date | null {
  const parts = dateStr.trim().toLowerCase().split(/\s+/);
  if (parts.length < 3) return null;
  const day = parseInt(parts[0], 10);
  const month = FRENCH_MONTHS[parts[1]];
  const year = parseInt(parts[2], 10);
  if (isNaN(day) || month === undefined || isNaN(year)) return null;
  return new Date(year, month, day);
}

function toICSDate(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return (
    `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`
  );
}

function toICSDateTime(date: Date, timeStr: string): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  const [hours, minutes] = timeStr.split(':').map((s) => parseInt(s, 10));
  const d = new Date(date);
  d.setHours(isNaN(hours) ? 10 : hours, isNaN(minutes) ? 0 : minutes, 0, 0);
  return (
    `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}` +
    `T${pad(d.getHours())}${pad(d.getMinutes())}00`
  );
}

function escapeICS(str: string): string {
  return str.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
}

function uid(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}@wedding-planner`;
}

export function exportToICS(
  coupleName: string,
  weddingDate: string,
  lots: WeddingLot[],
  cardSettings: Record<string, Record<string, any>>,
): void {
  const baseDate = parseFrenchDate(weddingDate);

  const lines: string[] = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Wedding Planner//FR',
    `X-WR-CALNAME:${escapeICS(coupleName)}`,
    'X-WR-TIMEZONE:Europe/Paris',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
  ];

  if (baseDate) {
    lines.push(
      'BEGIN:VEVENT',
      `UID:wedding-day-${uid()}`,
      `DTSTART;VALUE=DATE:${toICSDate(baseDate)}`,
      `DTEND;VALUE=DATE:${toICSDate(new Date(baseDate.getTime() + 86400000))}`,
      `SUMMARY:${escapeICS(`Mariage — ${coupleName}`)}`,
      'END:VEVENT',
    );
  }

  for (const lot of lots) {
    for (const card of lot.cards) {
      const settings = cardSettings[card.id] ?? {};
      const time: string | undefined = settings.time;
      if (!time || !baseDate) continue;

      const dtstart = toICSDateTime(baseDate, time);
      const duration: string = settings.duree ? `PT${settings.duree}` : 'PT1H';
      const description = escapeICS(settings.notes ?? card.subtitle ?? '');
      const location = settings.lieu ? escapeICS(settings.lieu) : '';

      lines.push(
        'BEGIN:VEVENT',
        `UID:${uid()}`,
        `DTSTART:${dtstart}`,
        `DURATION:${duration}`,
        `SUMMARY:${escapeICS(card.name)}`,
        ...(description ? [`DESCRIPTION:${description}`] : []),
        ...(location ? [`LOCATION:${location}`] : []),
        'END:VEVENT',
      );
    }
  }

  lines.push('END:VCALENDAR');

  const icsString = lines.join('\r\n');
  const blob = new Blob([icsString], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${coupleName.replace(/\s+/g, '_')}_mariage.ics`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
