import {
  Wand2, Building2, Camera, Scissors, UtensilsCrossed, Flower2, Music, Zap,
  Music2, Disc3, Users, Euro, Scale, Sun, CalendarClock, Heart, Wine, Cake,
  Truck, Layers, FileText, Lightbulb, PenLine, Mic, Activity, Smile,
  Gamepad2, Trophy, Crown, UserCheck, Briefcase, Baby, MapPin, Plane, Video,
  ScanLine, Palette, ImagePlus, Shirt, Gem, ShieldCheck, UserCog, ClipboardList,
  Mail, Compass, Gift, BookImage, CalendarCheck, AlertCircle, CheckCircle2,
  BedDouble, Tent, Car, type LucideIcon,
} from 'lucide-react';

export const ICON_MAP: Record<string, LucideIcon> = {
  // 'Sparkles' key maps to Wand2 for backward compat with existing card data
  Sparkles: Wand2,
  Wand2, Building2, Camera, Scissors, UtensilsCrossed, Flower2, Music, Zap,
  Music2, Disc3, Users, Euro, Scale, Sun, CalendarClock, Heart, Wine, Cake,
  Truck, Layers, FileText, Lightbulb, PenLine, Mic, Activity, Smile,
  Gamepad2, Trophy, Crown, UserCheck, Briefcase, Baby, MapPin, Plane, Video,
  ScanLine, Palette, ImagePlus, Shirt, Gem, ShieldCheck, UserCog, ClipboardList,
  Mail, Compass, Gift, BookImage, CalendarCheck, AlertCircle, CheckCircle2,
  BedDouble, Tent, Car,
};
