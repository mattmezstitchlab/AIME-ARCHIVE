export type Tool =
  | 'select'
  | 'hand'
  | 'zoom-in'
  | 'zoom-out'
  | 'note'
  | 'background'
  | 'text';

export type CardStatus = 'todo' | 'waiting' | 'confirmed' | 'paid';

export type CardType =
  | 'programme'
  | 'venue'
  | 'photo-video'
  | 'beauty'
  | 'catering'
  | 'flowers'
  | 'artist'
  | 'animation'
  | 'music-ceremony'
  | 'music-soiree'
  | 'guest'
  | 'budget'
  | 'admin'
  | 'honeymoon'
  | 'retroplanning';

export interface WeddingCard {
  id: string;
  name: string;
  subtitle: string;
  image?: string;
  gradient?: string;
  type: CardType;
  icon: string;
}

export interface WeddingLot {
  id: number;
  title: string;
  subtitle: string;
  icon: string;
  accentColor: string;
  position: { x: number; y: number };
  cards: WeddingCard[];
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  duration: string;
  bpm?: number;
  moment: string;
  gradient: string;
  category: 'ceremony' | 'soiree';
  phase?: string;
}

export interface CanvasTransform {
  x: number;
  y: number;
  scale: number;
}

export interface BgSettings {
  type: 'color' | 'gradient' | 'video';
  value: string;
}

export interface TextSettings {
  size: number;
  color: string;
}
