# PROMPT D'EXTENSION AIME — Page `/decouvrir`

> À coller dans votre outil IA (Lovable, Bolt, Cursor, Base44, etc.) avec accès au code source d'AIME.

---

## CONTEXTE — Ce qui existe déjà

AIME est une plateforme événementielle française premium déployée sur `espacepublic.netlify.app` avec :
- Pages publiques éditoriales par profil et par type d'événement
- Registre public à `/registre` (liste éditoriale mais sans recherche/filtres avancés)
- Pages par type d'événement `/event/[type]`
- Profils publics riches `/profile/[slug]`

**Le problème actuel :** un visiteur qui arrive sur AIME sans connaître un artiste précis n'a aucun moyen simple de découvrir **les événements près de chez lui**, **dans la période qui l'intéresse**, **du type qui l'attire**. Le registre est éditorial mais pas opérationnel.

**Charte AIME à respecter :**
- Typographie : titres serif éditoriaux, corps sans serif
- Sections numérotées, kickers en majuscules, bandeaux défilants
- Mentions juridiques : "Démonstration non officielle", "À valider"
- Palette : fond clair, noir profond, accents discrets
- Ton : éditorial, transparent, jamais corporate cliché

---

## MISSION — Créer une page de découverte premium

Construire `/decouvrir` — la page qui transforme AIME en moteur de découverte d'événements vivants en France. Elle doit être **belle comme un magazine**, **utile comme Mappy**, **rapide comme Google Maps**. Cible : 70% mobile, 30% desktop.

---

## STRUCTURE DE LA PAGE — Route `/decouvrir`

### 1. Header AIME standard
Identique au reste du site — pas de modification.

### 2. Hero éditorial compact (40vh max)

```
KICKER : "MOTEUR DE DÉCOUVERTE · MIS À JOUR EN CONTINU"

H1 SERIF GÉANT :
Trouvez la scène
qui vous ressemble.

SOUS-TITRE :
2 847 événements à venir partout en France.
Du spectacle vivant au mariage privé, du festival
à la conférence — tout ce qui se passe ce mois-ci.
```

Petit bandeau défilant en dessous (style AIME) :
`SPECTACLES · CONCERTS · FESTIVALS · CONFÉRENCES · MARIAGES · EXPOSITIONS · ATELIERS · SOIRÉES PRIVÉES · ÉVÉNEMENTS ASSOCIATIFS · SÉMINAIRES`

### 3. Barre de recherche + géolocalisation

Sticky en haut quand on scroll. Trois éléments :

1. **Champ recherche libre** : "Artiste, lieu, mot-clé…" avec autocomplete (suggestions basées sur les profils et événements existants)
2. **Bouton géolocalisation** : "Près de moi" avec icône — utilise l'API Geolocation du navigateur, demande permission, centre la carte
3. **Bouton "Filtres"** : ouvre un panneau latéral (voir section 6)

### 4. Toggle Vue Carte / Vue Liste

Pill toggle sticky sous la barre de recherche :
`◉ Carte    ○ Liste`

Par défaut sur mobile : **Liste**. Par défaut sur desktop : **Carte + Liste côte à côte** (split-view 60/40).

### 5. Vue Carte (Leaflet + OpenStreetMap)

- Hauteur : `calc(100vh - 200px)` sur desktop, `60vh` sur mobile
- Tuiles OpenStreetMap (gratuites, pas de clé API)
- Marqueurs colorés par type d'événement (voir palette plus bas)
- Marqueurs avec cluster automatique au-dezoom (utiliser `leaflet.markercluster`)
- Au clic sur un marqueur : popup éditorial AIME avec :
  - Image de l'événement
  - Type (kicker majuscules)
  - Titre
  - Date + lieu
  - Bouton "Voir la page"
- Au scroll de la carte : la liste de droite se met à jour pour ne montrer que les événements visibles dans la vue carte

**Palette par type d'événement :**
- Spectacle : noir profond `#0B0B0B`
- Concert : violet `#5B21B6`
- Festival : orange chaud `#EA580C`
- Conférence : bleu marine `#1E3A8A`
- Mariage : rose poudré `#BE185D`
- Exposition : ocre `#A16207`
- Atelier : vert sapin `#15803D`
- Soirée privée : prune `#7C2D12`
- Événement associatif : rouge brique `#B91C1C`
- Séminaire : gris anthracite `#374151`

### 6. Panneau Filtres (slide-in depuis la droite ou modal sur mobile)

```
FILTRES

──────────────────────────
QUAND ?
[ Ce week-end ]  [ Cette semaine ]
[ Ce mois-ci ]  [ Date personnalisée → ]

QUOI ?
□ Spectacle vivant
□ Concert
□ Festival
□ Conférence
□ Mariage
□ Exposition
□ Atelier
□ Soirée privée
□ Événement associatif
□ Séminaire

OÙ ?
[ Rayon : ___ km ] (slider 5 → 200)
[ Ville / code postal : _________ ]

PRIX ?
[ ✓ ] Inclure les événements gratuits
[ Prix max : ___ € ] (slider 0 → 200)

ACCESSIBILITÉ ?
□ PMR
□ Garderie
□ Langue des signes
□ Audiodescription

──────────────────────────
[ Effacer tout ]   [ Appliquer (147 résultats) ]
```

Les filtres mettent à jour les résultats en temps réel (compteur "X résultats" sur le bouton "Appliquer").

### 7. Vue Liste

Cards d'événements en grille (3 colonnes desktop, 2 tablette, 1 mobile). Chaque card AIME :

```
┌─────────────────────────────┐
│                             │
│   [Image/affiche événement] │
│   16:9                      │
│                             │
├─────────────────────────────┤
│                             │
│ CONCERT · LILLE             │
│                             │
│ Saison 2 — Captation Live   │
│ Sandrine Sarroche           │
│                             │
│ ━━━━━━━                     │
│                             │
│ 16 juin 2026 · 20h30        │
│ Théâtre Sébastopol          │
│                             │
│ À partir de 28 €            │
│ ● 91 places restantes       │
│                             │
└─────────────────────────────┘
```

Au hover : légère élévation, le bouton "Voir" apparaît.

Au clic : redirection vers `/profile/[slug]` (page du profil organisateur, avec sections événement actives).

### 8. Section "Coup de cœur AIME" (avant la grille principale)

Avant la liste générale, mettre en avant **3 événements éditorialement sélectionnés** par AIME. Cards plus grandes, badge "COUP DE CŒUR AIME" en haut, texte de présentation éditorial rédigé.

Cette section donne le ton éditorial premium qui différencie AIME d'Eventbrite.

### 9. Section "À l'agenda près de chez vous"

Si géolocalisation activée : section spécifique avec les 5 prochains événements dans un rayon de 30 km. Affichage timeline horizontale style AIME.

### 10. Pagination / Scroll infini

Sur la vue Liste : scroll infini (chargement de 12 cards à chaque seuil). Sur mobile : préférer scroll infini ; sur desktop : pagination classique en option.

### 11. Footer AIME standard

Aucune modification.

---

## ROUTE COMPLÉMENTAIRE — Pages SEO ciblées

Créer une logique de routes dynamiques pour le SEO local :

### Route : `/decouvrir/[ville]`
Exemple : `/decouvrir/lille`, `/decouvrir/paris`, `/decouvrir/arras`
→ Page `/decouvrir` pré-filtrée sur la ville, avec H1 adapté "Événements à [Ville]" et meta-tags spécifiques.

### Route : `/decouvrir/[type]/[ville]`
Exemple : `/decouvrir/concert/lille`, `/decouvrir/mariage/arras`
→ Double filtre type + ville, H1 "[Type] à [Ville]", meta-tags optimisés.

### Route : `/decouvrir/[type]`
Exemple : `/decouvrir/spectacle`, `/decouvrir/festival`
→ Filtre type uniquement, "Tous les [type] en France".

**Génération statique** : générer ces pages à la build pour SEO maximal (Next.js `getStaticPaths`, Astro, Nuxt — selon stack).

---

## CARTE INTERACTIVE — Spécifications techniques

### Bibliothèques à utiliser
- **Leaflet** 1.9+ (carte)
- **leaflet.markercluster** (regroupement automatique)
- **leaflet.locatecontrol** (bouton géolocalisation natif Leaflet)

### Tuiles
- Provider par défaut : OpenStreetMap classique
- Style : `https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`
- Alternative premium si budget : Mapbox style "Light" ou "Outdoors" (mais payant — laisser OpenStreetMap par défaut)

### Initialisation
- Centre par défaut : France entière (47.0, 2.0, zoom 6)
- Si géolocalisation activée : centrer sur position utilisateur, zoom 11
- Si recherche ville : centrer sur ville, zoom 12

### Performance
- Pas afficher plus de **200 marqueurs simultanés** — au-delà, forcer le clustering
- Lazy load des popups : ne charger le contenu HTML qu'au clic
- Code-split de Leaflet (chargé uniquement sur `/decouvrir`)

---

## DESIGN — Détails AIME spécifiques

### Hero
- Hauteur : `40vh` desktop, `auto` mobile
- Fond : blanc cassé ou très légère vidéo en arrière-plan (réutiliser une vidéo `/media/*.mp4` existante avec opacity réduite)
- H1 serif éditorial très grand (clamp 48px → 96px)

### Mentions juridiques
- Bandeau discret en bas : "Démonstration AIME — Les événements affichés sont des données de test. Les informations doivent être validées avant tout achat ou déplacement."
- Sur chaque card : si l'événement est une démo, badge "BROUILLON" en haut à droite

### Bandeau défilant types d'événements
- Style identique à l'existant AIME (majuscules, défilement infini)
- Cliquable : chaque type est un lien vers `/decouvrir/[type]`

### Cards
- Bordures fines (1px ou 0.5px), pas d'ombre lourde
- Coins : `border-radius: 12px`
- Hover : translation Y -2px, bordure légèrement plus marquée
- Mobile : pleine largeur, padding latéral 16px

---

## ÉTAT VIDE & ÉTATS PARTICULIERS

### Aucun résultat
```
KICKER : "AUCUN ÉVÉNEMENT TROUVÉ"
H2 : "Personne ne joue ici en ce moment.
      Ça ne durera pas."
P : "Essayez d'élargir le rayon de recherche, 
    de changer les dates ou de retirer un filtre."
[ Effacer mes filtres ]
```

### Géolocalisation refusée
```
P : "La géolocalisation n'est pas autorisée.
    Vous pouvez entrer une ville à la main 
    dans la barre de recherche."
```

### Erreur de chargement
```
P : "Impossible de charger la carte. 
    Vérifiez votre connexion ou rechargez la page."
[ Recharger ]
```

---

## INSTRUCTIONS TECHNIQUES PRÉCISES

### Données
- Source : tous les événements actifs (statut "publié" et date_début > maintenant)
- Joindre les données du profil organisateur (nom, image, slug)
- Indexer pour recherche full-text sur : titre, description, lieu, nom organisateur, type
- Cache : 5 minutes côté serveur, revalidation à la demande quand un événement est modifié

### Performance
- **Pas plus de 12 cards chargées initialement** en vue Liste
- Images en `loading="lazy"` + format WebP avec fallback JPG
- Carte Leaflet code-splittée (charge uniquement sur `/decouvrir`)
- Page critique CSS inline, reste asynchrone
- Score Lighthouse cible : Performance > 85, SEO > 95

### SEO
- Meta-title dynamique : `Événements à [Ville/France] · AIME`
- Meta-description dynamique avec mots-clés contextuels
- Schema.org `Event` pour chaque card (rich snippets Google)
- Sitemap.xml généré avec toutes les routes `/decouvrir/[type]/[ville]`
- OpenGraph image dynamique (peut être l'image du premier événement du filtre)

### Accessibilité
- Carte alternative : un tableau accessible des événements en dessous, masqué visuellement mais lu par les lecteurs d'écran (`sr-only`)
- Navigation clavier complète : Tab sur les cards, Enter pour ouvrir
- Focus visible sur tous les éléments interactifs
- ARIA labels sur le toggle Carte/Liste, sur la carte Leaflet
- Contrastes WCAG AA minimum

---

## DONNÉES DE TEST À CRÉER

Créer **15 événements de démonstration** répartis dans toute la France pour rendre la carte vivante :

```yaml
- titre: "Saison 2 — Captation Live"
  type: "spectacle"
  organisateur_slug: "sandrine-sarroche"
  date_debut: "2026-06-16T20:30:00"
  lieu: "Théâtre Sébastopol, Lille"
  lat: 50.6292
  lng: 3.0573
  prix_min: 28

- titre: "Festival des Cultures Urbaines"
  type: "festival"
  date_debut: "2026-07-04T18:00:00"
  lieu: "Parc des Princes, Paris"
  lat: 48.8417
  lng: 2.2531
  prix_min: 35

- titre: "Concert symphonique d'été"
  type: "concert"
  date_debut: "2026-07-12T21:00:00"
  lieu: "Théâtre Antique, Orange"
  lat: 44.1372
  lng: 4.8088
  prix_min: 45

- titre: "Conférence : L'IA et le droit"
  type: "conférence"
  date_debut: "2026-06-25T18:00:00"
  lieu: "Sciences Po, Paris"
  lat: 48.8534
  lng: 2.3286
  prix_min: 0

- titre: "Mariage civil et fête"
  type: "mariage"
  date_debut: "2026-09-12T15:00:00"
  lieu: "Château de Bréauté, Bréauté"
  lat: 49.6358
  lng: 0.4669
  prix_min: null
  status: "privé"

- titre: "Exposition Rétrospective Niki de Saint Phalle"
  type: "exposition"
  date_debut: "2026-05-15T10:00:00"
  lieu: "MAMAC, Nice"
  lat: 43.7015
  lng: 7.2752
  prix_min: 12

- titre: "Atelier d'écriture comique"
  type: "atelier"
  date_debut: "2026-06-08T14:00:00"
  lieu: "Le Splendid, Lille"
  lat: 50.6371
  lng: 3.0625
  prix_min: 80

- titre: "Séminaire annuel Pennylane × Facila"
  type: "séminaire"
  date_debut: "2026-09-18T17:30:00"
  lieu: "Centre des Congrès, Arras"
  lat: 50.291
  lng: 2.777
  prix_min: 0

- titre: "Soirée de gala Croix-Rouge"
  type: "événement associatif"
  date_debut: "2026-11-22T20:00:00"
  lieu: "Hôtel Marriott, Lyon"
  lat: 45.7640
  lng: 4.8357
  prix_min: 150

- titre: "Concert de Jazz au Sunset"
  type: "concert"
  date_debut: "2026-05-30T21:30:00"
  lieu: "Le Sunset, Paris"
  lat: 48.8580
  lng: 2.3458
  prix_min: 22

- titre: "Festival Off Avignon"
  type: "festival"
  date_debut: "2026-07-05T11:00:00"
  lieu: "Centre-ville, Avignon"
  lat: 43.9493
  lng: 4.8055
  prix_min: 15

- titre: "Spectacle One-Man-Show"
  type: "spectacle"
  date_debut: "2026-06-21T20:30:00"
  lieu: "Le Splendid, Bordeaux"
  lat: 44.8378
  lng: -0.5792
  prix_min: 25

- titre: "Atelier cuisine du Nord"
  type: "atelier"
  date_debut: "2026-06-14T10:00:00"
  lieu: "Halle de Wazemmes, Lille"
  lat: 50.6276
  lng: 3.0497
  prix_min: 45

- titre: "Conférence : Climat et entreprises"
  type: "conférence"
  date_debut: "2026-10-08T09:00:00"
  lieu: "Palais des Congrès, Strasbourg"
  lat: 48.5860
  lng: 7.7466
  prix_min: 0

- titre: "Exposition de photo contemporaine"
  type: "exposition"
  date_debut: "2026-05-25T11:00:00"
  lieu: "Le Bal, Paris"
  lat: 48.8842
  lng: 2.3296
  prix_min: 8
```

---

## LIVRABLE ATTENDU

1. **Route `/decouvrir`** complète avec hero, recherche, filtres, vue Carte/Liste
2. **Routes SEO** `/decouvrir/[ville]`, `/decouvrir/[type]`, `/decouvrir/[type]/[ville]`
3. **Carte Leaflet** interactive avec marqueurs colorés, clustering, popups
4. **15 événements de démo** répartis en France
5. **Lien depuis la home AIME** : remplacer "Événements" du menu principal par "Découvrir" ou ajouter une entrée
6. **Section "Coup de cœur AIME"** éditorialement mise en avant
7. **Mobile-first** entièrement fonctionnel
8. **SEO optimisé** : meta-tags, Schema.org, sitemap

---

## RAPPEL FINAL

Cette page va devenir **la porte d'entrée principale d'AIME pour le grand public**. Tout le SEO local de la plateforme va passer par elle. Elle doit être :
- **Belle** comme une page magazine
- **Rapide** comme un moteur de recherche
- **Utile** comme une carte de transport
- **Éditoriale** comme le reste d'AIME — pas un copier-coller d'Eventbrite

Si tu hésites entre l'utile et le beau : choisis les deux. C'est ce qui définit AIME.

Bon build.
