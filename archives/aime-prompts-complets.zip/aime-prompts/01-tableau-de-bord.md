# PROMPT D'EXTENSION AIME — Tableau de bord organisateur & Profil public événementiel

> À coller dans votre outil IA (Lovable, Bolt, Cursor, Base44, etc.) avec accès au code source d'AIME.

---

## CONTEXTE — Ce qui existe déjà sur AIME

AIME est une plateforme événementielle française déployée sur `espacepublic.netlify.app`. Elle combine :

- **Page d'accueil éditoriale** avec vidéos d'arrière-plan, typographie premium, sections numérotées (01, 02, 03), bandeaux en majuscules défilants (style "SANS TABOU · SANS FILTRE · SANS CONCESSION")
- **Registre public** (`/registre`) qui relie toutes les pages
- **Pages par type d'événement** (`/event/spectacle`, `/event/concert`, `/event/festival`, `/event/conférence`, `/event/mariage`, `/event/exposition`, `/event/atelier`, `/event/soirée-privée`, `/event/événement-associatif`, `/event/séminaire`)
- **Profils publics** (`/profile/[slug]`) — exemple existant : `/profile/sandrine-sarroche` avec hero vidéo, parcours numéroté, concept artistique, portrait, kit presse, agenda dates, contact booking
- **Espace personnel** (`/espace`) — modules listés mais peu développés : Mes événements, Mon profil public, Agenda, Participants, Documents, Devis, Factures, Messages, Paramètres de publication
- **Mentions juridiques rigoureuses** : "Démonstration publique non officielle", "À valider avant publication", "Brouillon éditorial"

**Charte graphique AIME à respecter impérativement :**
- Typographie : titres serif éditoriaux très grands (style Playfair Display ou équivalent), corps de texte sans serif clean
- Hierarchie visuelle marquée : kickers en majuscules au-dessus des titres
- Sections numérotées en gros chiffres (01, 02, 03, 04…)
- Bandeaux défilants horizontaux en majuscules type "PAGES PUBLIQUES · INSCRIPTIONS · DOCUMENTS · AGENDA"
- Boutons CTA arrondis, style éditorial premium
- Vidéos `.mp4` en arrière-plan ou en accent visuel
- Palette : fond clair dominant, noir profond pour texte, accents discrets

**Stack technique présumée :** site statique généré (Next.js, Astro, ou équivalent), déployé sur Netlify, avec routes dynamiques.

---

## MISSION — Deux ajouts majeurs à AIME

### Ajout n°1 : Tableau de bord organisateur dans `/espace`

Le module "Mes événements" doit s'ouvrir sur un **vrai tableau de bord opérationnel** quand on clique sur un événement en cours d'organisation. Aujourd'hui, les modules existent en façade mais pas le pilotage. À construire :

**Route :** `/espace/event/[event-id]` ou `/espace/pilotage/[event-id]`

**Structure (de haut en bas) :**

1. **Topbar** avec titre événement, sous-titre (X dates · Y invités · localisation), boutons "Voir la page publique" + "Relancer les invités"

2. **4 cartes de métriques** sur une ligne :
   - Inscrits confirmés (X / Y) avec tendance hebdo
   - Prestataires confirmés (X / Y) avec statut
   - Budget engagé (X € sur Y €) avec %
   - Date la plus proche (J-X jours)

3. **Bloc Agent IA "Cléo"** — fond sombre dégradé navy ou noir profond, occupe toute la largeur. À gauche : message contextuel de l'IA en français qui analyse le dossier ("Bonjour [Prénom]. J'ai identifié 3 points urgents cette semaine. Le lieu n'est toujours pas verrouillé pour la session du [date]. J'ai pré-sélectionné 4 lieux disponibles…"). À droite : 4 actions cliquables suggérées (Réserver le lieu, Valider le traiteur, Relancer X invités, Exporter le dossier). En bas : champ texte "Demandez à Cléo…"

4. **Deux colonnes côte à côte :**
   - **Checklist J-X** interactive, cochable, organisée par catégories (Stratégie, Comms, Logistique, Contenu)
   - **Budget par poste** avec barre de progression colorée segmentée, liste des postes avec montant et % du total

5. **Bloc Prestataires** pleine largeur :
   - En-tête avec filtres par catégorie (Tous, Lieu, Traiteur, Sono, Vidéo, Photo, Hôtesses, Déco, Sécurité)
   - **Carte interactive Leaflet** avec marqueurs colorés par catégorie autour de la géolocalisation de l'événement (utiliser tuiles OpenStreetMap gratuites)
   - Liste des prestataires en dessous avec : icône catégorie colorée, nom, distance (km), note étoile, capacité ou spécialité, statut (Disponible / Confirmé / En attente / Devis reçu), prix indicatif, bouton d'action (Demander un devis / Ajouté / À valider / Relancer)

**Sidebar gauche persistante :**
- Logo AIME en haut
- Pill "Événement actif" avec nom et statut "En préparation · J-X"
- Section "Pilotage" : Tableau de bord (actif), Prestataires, Sessions & dates, Inscrits (avec badge nombre), Budget
- Section "Communication" : Emails & relances, Page d'inscription
- Avatar utilisateur en bas

**Contraintes de design AIME pour ce tableau de bord :**
- Garder la rigueur éditoriale AIME (typo, hiérarchie)
- Sidebar en fond sombre style "scène" cohérent avec la charte
- Métriques en cartes blanches discrètes, bordures fines
- Le bloc IA Cléo est le seul élément avec fond foncé large — c'est l'élément de pilotage central
- Mentions "Brouillon" ou "À valider" partout où l'utilisateur entre des données qui ne sont pas confirmées
- Cohérent avec le ton AIME : sérieux, premium, juridiquement précautionneux

---

### Ajout n°2 : Page profil public enrichie en mode "événement"

Actuellement `/profile/sandrine-sarroche` est très éditorial mais ne propose pas de **mécanique d'inscription événementielle riche**. Il faut enrichir le template profil pour qu'il fonctionne aussi comme **page d'inscription événementielle premium** quand le profil organise un événement actif.

**Route :** `/profile/[slug]` (template à enrichir, pas à remplacer)

**Ajouter au template existant, après le bloc Parcours, AVANT le kit presse :**

1. **Section "Prochain événement en vedette"** (si applicable) :
   - Kicker en majuscules : "PROCHAINE DATE · INSCRIPTION OUVERTE"
   - Grand titre serif éditorial type "Découvrez [Nom événement]"
   - Sous-titre descriptif
   - 3 cartes de session côte à côte (si multi-dates) avec :
     - Date en gros chiffre (style numérotation AIME)
     - Mois en majuscules
     - Heure et durée
     - Lieu (ou "Lieu à confirmer")
     - Barre de progression places restantes
     - Compteur "X inscrits · Y places restantes"
     - Bouton CTA "Réserver le [date]"

2. **Section "Programme"** (timeline éditoriale) :
   - Reprend le style numéroté AIME mais avec horaires
   - Timeline verticale avec dots colorés
   - Pour chaque étape : heure, titre, description courte

3. **Section "Pourquoi y assister"** (4 raisons) :
   - 4 cards avec icône, titre court, description 1-2 lignes
   - Style cohérent avec les sections "Concept" existantes

4. **Formulaire RSVP intégré** :
   - Fond contrasté (peut être noir profond pour rappeler la "scène")
   - Champs : prénom, nom, email, entreprise (optionnel), téléphone (optionnel), choix de la session (radio cards), régime alimentaire, message optionnel
   - Mention RGPD obligatoire avec checkbox
   - Bouton soumission "Confirmer mon inscription"
   - Confirmation visuelle après envoi

5. **FAQ événement** (5-6 questions cliquables type accordéon) :
   - L'événement est-il gratuit ?
   - Suis-je engagé après ?
   - Puis-je amener quelqu'un ?
   - Comment je reçois l'adresse exacte ?
   - Puis-je annuler ?
   - Style cohérent avec le ton AIME (rigoureux, transparent)

**Logique d'affichage :**
- Si le profil n'a pas d'événement actif : ces sections sont masquées, le profil reste un simple profil artistique comme aujourd'hui
- Si le profil a 1+ événements actifs (avec date future et inscriptions ouvertes) : les sections RSVP s'affichent
- Les données viennent du module "Mes événements" de l'espace personnel
- Conserver les mentions "Démonstration non officielle" et "À valider"

---

## INSTRUCTIONS TECHNIQUES PRÉCISES POUR L'IA

### Ce que tu DOIS faire
1. **Étudier le code existant** avant tout changement — comprendre la structure des composants, le système de routing, la convention de nommage
2. **Réutiliser les composants AIME existants** (boutons, cards, sections numérotées, kickers, bandeaux défilants) — ne pas créer de nouveaux composants si un équivalent existe
3. **Respecter la charte graphique** : mêmes polices, mêmes couleurs, mêmes espacements, mêmes patterns visuels
4. **Maintenir les mentions juridiques** "Démonstration non officielle", "À valider", "Brouillon" partout où c'est pertinent
5. **Garder l'accessibilité** : sémantique HTML correcte, alt text sur images, contraste, focus visible
6. **Mobile-first** : tout doit fonctionner sur mobile (les profils AIME ont du trafic mobile)
7. **Utiliser Leaflet + OpenStreetMap** pour la carte (gratuit, pas de clé API) avec marqueurs colorés par catégorie de prestataire

### Ce que tu NE DOIS PAS faire
- ❌ Refaire le design de pages existantes — uniquement ajouter ce qui est demandé
- ❌ Changer les routes existantes (`/`, `/registre`, `/event/*`, `/profile/[slug]`, `/espace`)
- ❌ Casser le template profil Sandrine Sarroche existant — l'enrichir uniquement
- ❌ Introduire de nouvelles polices, dépendances lourdes ou frameworks
- ❌ Inventer des données factices sans les marquer "Démonstration"
- ❌ Faire un design générique SaaS — AIME a une identité éditoriale forte, à conserver

---

## DONNÉES DE TEST À CRÉER

Pour valider la fonctionnalité, créer **un événement de démonstration** rattaché au profil Sandrine Sarroche :

```yaml
event_id: "demo-saison2-lille"
profile_slug: "sandrine-sarroche"
titre: "Saison 2 — Captation Live"
type: "spectacle"
description: "Captation publique du spectacle Saison 2 au Théâtre Sébastopol de Lille."
sessions:
  - date: "2026-06-16"
    heure_debut: "20:30"
    heure_fin: "22:30"
    lieu: "Théâtre Sébastopol, Lille"
    capacite: 1700
    inscrits: 1234
  - date: "2026-06-17"
    heure_debut: "20:30"
    heure_fin: "22:30"
    lieu: "Théâtre Sébastopol, Lille"
    capacite: 1700
    inscrits: 856
budget_total: 45000
budget_engage: 28500
prestataires_confirmes: 5
prestataires_total: 8
checklist_done: 14
checklist_total: 22
geolocation:
  lat: 50.6292
  lng: 3.0573
prestataires_demo:
  - { nom: "Théâtre Sébastopol", categorie: "lieu", lat: 50.629, lng: 3.057, statut: "confirmé" }
  - { nom: "Sono Events Nord", categorie: "sono", lat: 50.296, lng: 2.766, statut: "confirmé" }
  - { nom: "L'Atelier du Goût", categorie: "traiteur", lat: 50.305, lng: 2.802, statut: "confirmé" }
  - { nom: "AV Solutions Nord", categorie: "video", lat: 50.432, lng: 2.831, statut: "devis_reçu" }
  - { nom: "Thomas Lefebvre Photo", categorie: "photo", lat: 50.745, lng: 2.252, statut: "en_attente" }
  - { nom: "Agence Prestige Nord", categorie: "hotesses", lat: 50.629, lng: 3.057, statut: "confirmé" }
```

**Message initial de l'agent IA Cléo pour cette démo :**

> Bonjour Sandrine. J'ai analysé le dossier Saison 2 ce matin. 3 points à traiter cette semaine.
>
> La **deuxième session du 17 juin** n'a que 856 inscrits sur 1700 places. Je suggère une relance ciblée — texte rédigé prêt à valider.
>
> Côté **photographe**, Thomas Lefebvre n'a pas encore répondu depuis 5 jours. J'ai 2 alternatives disponibles dans un rayon de 30 km autour de Lille.
>
> Le **devis AV Solutions** est arrivé hier : 1 850 € pour les deux sessions. C'est dans votre fourchette. Validation possible en 1 clic.

---

## LIVRABLE ATTENDU

1. **Route fonctionnelle** `/espace/event/[event-id]` avec le tableau de bord complet
2. **Template profil enrichi** sur `/profile/sandrine-sarroche` avec les nouvelles sections (Prochain événement, Programme, Pourquoi venir, RSVP, FAQ)
3. **Lien depuis l'espace personnel** vers le tableau de bord pilotage (clic sur un événement dans "Mes événements")
4. **Lien depuis la page profil** vers la page d'inscription (clic sur "Réserver" amène au formulaire RSVP intégré)
5. **Aucune régression** sur les pages existantes
6. **Documentation rapide** dans un commentaire en haut des nouveaux fichiers expliquant ce qui a été ajouté

---

## RAPPEL FINAL

AIME est une **plateforme éditoriale premium**, pas un SaaS générique. Chaque ajout doit renforcer cette identité — pas la diluer. Si tu hésites entre un design tech "Stripe/Linear" et un design éditorial "magazine premium" : choisis l'éditorial. Toujours.

Quand tu rédiges du texte d'interface : ton AIME = sérieux, transparent, juridiquement précautionneux, légèrement littéraire. Jamais corporate cliché. Jamais "Welcome aboard!" ou "Let's get started!".

Préfère : "Préparer la fiche", "Ouvrir le pilotage", "Valider le devis", "À publier après relecture humaine".

Bon build.
