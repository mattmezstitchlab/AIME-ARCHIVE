# PROMPT D'EXTENSION AIME — Billetterie & Billet QR

> À coller dans votre outil IA (Lovable, Bolt, Cursor, Base44, etc.) avec accès au code source d'AIME.
> Ce prompt suppose que le **tableau de bord organisateur** (prompt précédent) est déjà implémenté.

---

## CONTEXTE — Ce qui existe déjà

AIME est une plateforme événementielle française premium déployée sur `espacepublic.netlify.app` avec :
- Pages publiques éditoriales par profil et par type d'événement
- Espace personnel `/espace` avec modules : Mes événements, Agenda, Participants, Documents, Devis, Factures, Messages, Paramètres
- Tableau de bord organisateur `/espace/event/[event-id]` (déjà construit) avec agent IA Cléo, checklist, budget, prestataires géolocalisés
- Profil public enrichi `/profile/[slug]` avec sections événement (sessions, programme, RSVP, FAQ)

**Charte AIME à respecter :**
- Typographie : titres serif éditoriaux, corps sans serif
- Sections numérotées (01, 02, 03), kickers en majuscules
- Mentions juridiques : "Démonstration non officielle", "À valider", "Brouillon"
- Palette : fond clair, noir profond, accents discrets
- Ton : éditorial, transparent, juridiquement précautionneux, jamais corporate cliché

---

## MISSION — Brancher une billetterie professionnelle

AIME doit pouvoir vendre des billets et générer des billets PDF avec QR code, comme Eventbrite/Weezevent/BilletWeb, mais dans l'esthétique éditoriale AIME.

---

## AJOUT 1 — Module "Tarifs & billetterie" dans le pilotage

### Route : `/espace/event/[event-id]/billetterie`

Accessible depuis le tableau de bord organisateur, dans la sidebar gauche, section "Pilotage" → nouvelle entrée "Tarifs & billetterie".

### Contenu de la page

1. **Topbar identique au tableau de bord** avec titre événement et sous-titre adapté ("X tarifs · Y billets vendus · Z € de revenus")

2. **4 cartes de métriques** spécifiques billetterie :
   - Billets vendus (X / Y capacité totale)
   - Revenus encaissés (X € HT / Y € TTC)
   - Taux de remplissage (%)
   - Date de fin des ventes (J-X jours avant l'événement)

3. **Section "Tarifs proposés"** :
   - Bouton "+ Créer un tarif"
   - Tableau / liste des tarifs créés avec : nom, prix TTC, TVA appliquée, quota disponible, vendus, statut (Actif / Pause / Épuisé / Expiré), actions (Modifier / Pause / Supprimer)
   - Chaque tarif a un éditeur modal complet (voir ci-dessous)

4. **Section "Code de réduction"** :
   - Liste des codes promo créés
   - Bouton "+ Créer un code"
   - Pour chaque code : libellé, type (% ou €), montant, quota d'utilisation, dates de validité, utilisé X fois

5. **Section "Configuration Stripe"** :
   - Statut compte Stripe connecté ou bouton "Connecter mon compte Stripe"
   - Mention claire : "AIME utilise Stripe Connect — vos fonds sont versés directement sur votre compte bancaire. AIME ne stocke aucune donnée bancaire."
   - Lien vers documentation

6. **Section "Mentions légales billetterie"** (obligatoire en France) :
   - SIRET de l'organisateur (champ requis)
   - Nom commercial
   - Adresse du siège
   - Numéro de TVA intracommunautaire (si assujetti)
   - Politique de remboursement (textarea)
   - CGV billetterie (lien upload PDF ou éditeur intégré)
   - Mention "Conformément à l'article L. 121-21 du Code de la consommation, les billets pour des prestations de loisirs à date fixe ne bénéficient pas du droit de rétractation de 14 jours."

---

## AJOUT 2 — Éditeur de tarif (modal)

Quand l'organisateur clique "+ Créer un tarif" ou "Modifier", ouvrir une modal pleine hauteur avec :

```
TARIF · BROUILLON

Nom du tarif *
[ Plein tarif / Réduit / Étudiant / Abonné / etc. ]

Description publique (affichée à l'inscrit)
[ textarea ]

Prix TTC *
[ champ nombre ] €

TVA appliquée *
[ select : Exonéré (0%) / Réduit spectacle vivant (5,5%) / Normal (20%) ]

Mention : "Le taux de TVA dépend de votre statut et du type d'événement. 
Les spectacles vivants bénéficient en général du taux réduit à 5,5% (art. 281 quater CGI). 
À valider avec votre expert-comptable."

Quota disponible *
[ champ nombre ]

Limite par commande
[ champ nombre, défaut 10 ]

Disponibilité
[ x ] Toujours disponible (jusqu'à épuisement)
[   ] Disponible entre [ date début ] et [ date fin ]

Sessions concernées (si multi-dates)
[ checkbox liste des sessions de l'événement ]

Conditions spécifiques (affichées à l'achat)
[ textarea — ex : "Sur présentation d'un justificatif étudiant le jour J" ]

[ Enregistrer brouillon ]  [ Activer la vente ]
```

---

## AJOUT 3 — Parcours d'achat public

### Route : `/profile/[slug]/billetterie/[event-id]` (page d'achat dédiée)

Quand un visiteur clique "Réserver" sur un profil public et que l'événement a une billetterie active, l'amener sur cette page (au lieu du simple formulaire RSVP du prompt précédent).

### Structure de la page

1. **Header AIME standard** identique au reste du site

2. **Hero compact** :
   - Visuel/affiche de l'événement à gauche
   - À droite : nom événement, date(s), lieu, durée, mention "Billetterie ouverte"

3. **Étape 1 — Choix de la session** (si multi-dates) :
   - 3 cartes session côte à côte, style AIME (gros chiffre date + mois en majuscules)
   - Sélection radio
   - Cards désactivées si épuisé

4. **Étape 2 — Choix des tarifs** :
   - Liste de tous les tarifs actifs sur la session sélectionnée
   - Pour chaque tarif : nom, description, prix TTC, sélecteur quantité (− / nb / +) limité par le quota par commande et la dispo restante
   - Sous-total mis à jour en temps réel
   - Mention "Frais de gestion AIME : 0,50 € par billet" (séparé du sous-total)

5. **Étape 3 — Code promo** :
   - Champ "Vous avez un code ?" avec bouton "Appliquer"
   - Si valide : affichage de la réduction et nouveau total

6. **Étape 4 — Vos informations** :
   - Prénom, nom, email (requis)
   - Téléphone (optionnel)
   - **Pour chaque billet** : prénom, nom du porteur (pour le check-in nominatif)
   - Case à cocher RGPD obligatoire
   - Case à cocher CGV obligatoire (avec lien vers les CGV de l'organisateur)
   - Case à cocher acceptation absence de droit de rétractation (obligatoire en France pour les billets à date fixe)

7. **Étape 5 — Récapitulatif & paiement** :
   - Récapitulatif complet (session, billets, total HT, TVA, total TTC, frais AIME)
   - Bouton "Payer X € avec Stripe" qui ouvre Stripe Checkout en redirection

8. **Footer AIME** avec mentions légales standard

### Logique de paiement

- Utiliser **Stripe Checkout** (pas Stripe Elements personnalisé — Checkout est plus rapide et plus conforme PCI)
- Mode : `payment` (paiement unique)
- Application_fee_amount : 0,50 € × nombre de billets (commission AIME)
- Transfer_data.destination : compte Stripe Connect de l'organisateur
- Metadata : event_id, session_id, ticket_ids, customer_email
- Success_url : `/profile/[slug]/billetterie/[event-id]/merci?session_id={CHECKOUT_SESSION_ID}`
- Cancel_url : `/profile/[slug]/billetterie/[event-id]?cancelled=1`
- Webhook obligatoire pour confirmer la commande : `checkout.session.completed`

### Page "Merci" `/profile/[slug]/billetterie/[event-id]/merci`

- Grand titre éditorial : "Votre place est réservée"
- Sous-titre : "Vos billets sont arrivés dans votre boîte mail"
- Récapitulatif de la commande
- Lien pour télécharger directement les billets PDF
- Lien "Ajouter à mon calendrier" (Google, iCal, Outlook)
- CTA "Voir mes billets" (vers `/espace/mes-billets`)

---

## AJOUT 4 — Génération du billet PDF avec QR code

### Format du billet

Format A5 paysage (148 × 210 mm), une page par billet, design éditorial AIME premium :

```
┌──────────────────────────────────────────────────┐
│                                                  │
│  AIME           [event-type label]               │
│  ────────────────────────────────────────        │
│                                                  │
│  [TITRE ÉVÉNEMENT]                               │
│  serif éditorial très grand                      │
│                                                  │
│  [Date complète]                  ┌─────────┐    │
│  [Heure]                          │   QR    │    │
│  [Lieu / Adresse complète]        │  CODE   │    │
│                                   │         │    │
│  Porteur :                        └─────────┘    │
│  [Prénom Nom]                                    │
│                                                  │
│  Tarif : [Nom du tarif]                          │
│  Référence : AIME-2025-XXXX-001                  │
│                                                  │
│  ──────────────────────────────                  │
│  Démonstration · Aucune valeur officielle        │
│  avant validation de l'organisateur              │
│                                                  │
└──────────────────────────────────────────────────┘
```

### Spécifications techniques

- Bibliothèque PDF : **react-pdf** (`@react-pdf/renderer`) pour génération côté serveur ou client
- QR code : **qrcode** npm, contenu du QR = URL signée `https://espacepublic.netlify.app/checkin/[ticket-token]`
- Le ticket-token est un JWT signé contenant ticket_id, event_id, expires_at
- Le PDF est :
  - Joint en pièce attachée dans l'email de confirmation
  - Stocké côté serveur dans le compte de l'acheteur (`/espace/mes-billets`)
  - Téléchargeable depuis le lien dans l'email à tout moment

### Email de confirmation

Sujet : `Vos billets pour [Nom événement] — [Date]`

Corps (rédigé en français, ton AIME) :

```
Bonjour [Prénom],

Vos billets pour [Nom événement] sont confirmés.

📅 [Date complète]
🕐 [Heure de début]
📍 [Lieu — Adresse]

Vos billets sont en pièce jointe (PDF). Présentez-les sur votre téléphone 
ou imprimés le jour de l'événement — le QR code sera scanné à l'entrée.

Vous pouvez aussi retrouver vos billets à tout moment dans votre espace 
personnel AIME : [lien]

[Bouton CTA : "Ajouter à mon calendrier"]

À très bientôt,
[Nom de l'organisateur]

—
Référence commande : AIME-2025-XXXX
Aide & remboursement : [lien]
```

---

## AJOUT 5 — Espace acheteur "Mes billets"

### Route : `/espace/mes-billets`

Pour les visiteurs qui ont acheté des billets (création de compte automatique avec l'email d'achat) :

- Liste des commandes passées
- Pour chaque commande : événement, date, nombre de billets, montant, statut
- Boutons : "Télécharger les billets", "Ajouter au calendrier", "Demander un remboursement" (si fenêtre encore ouverte)
- Section "Billets à venir" en haut, "Billets passés" en dessous

---

## AJOUT 6 — Check-in jour J (organisateur)

### Route : `/espace/event/[event-id]/checkin`

Page mobile-first à utiliser le jour de l'événement à l'entrée. À l'écran :

1. **Caméra QR** plein écran (utiliser `html5-qrcode` ou équivalent)
2. **Feedback visuel** immédiat :
   - Vert + son court : billet valide → afficher prénom/nom + tarif + horodatage
   - Orange + son : billet déjà scanné → avertissement
   - Rouge + son : billet invalide ou pour autre session
3. **Bouton "Saisir manuellement"** pour entrer une référence si le QR ne scanne pas
4. **Compteur** "X / Y entrées" en haut
5. **Historique** des derniers check-ins en bas (5 dernières entrées)

### Logique

- Endpoint API : `POST /api/checkin/[token]` qui valide le JWT, vérifie que le billet n'a pas déjà été scanné, marque comme utilisé avec horodatage
- Mode "hors ligne possible" : sauvegarder localement et synchroniser quand le réseau revient (PWA)

---

## INSTRUCTIONS TECHNIQUES PRÉCISES

### Stack à utiliser
- **Stripe Connect** (compte Express) — gestion KYC déléguée par Stripe
- **Stripe Checkout** pour le parcours d'achat (jamais Stripe Elements custom)
- **Webhook obligatoire** sur `checkout.session.completed` pour confirmer les commandes
- **react-pdf** pour génération PDF
- **qrcode** npm pour QR
- **JWT** pour signer les tickets-tokens (clé secrète serveur)
- **html5-qrcode** ou **@zxing/library** pour la lecture QR au check-in

### Variables d'environnement à prévoir
```
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_CONNECT_CLIENT_ID=ca_...
JWT_TICKET_SECRET=...
AIME_FEE_PER_TICKET_EUR=0.50
RESEND_API_KEY=...   # ou SendGrid, ou SMTP
```

### Ce que tu DOIS faire
1. **Réutiliser les composants AIME** (cards, boutons, kickers, mentions juridiques) — pas de nouveau design system
2. **Mode démo activable** : si Stripe n'est pas configuré, simuler les paiements avec un faux flow pour tests
3. **Tout est en français** : labels, emails, billets, mentions
4. **Cohérence des mentions juridiques** : "Démonstration non officielle", "À valider", "Brouillon" partout où c'est pertinent en mode démo
5. **Mobile-first** sur le parcours d'achat et le check-in
6. **Accessibilité** : focus visible, ARIA, contraste

### Ce que tu NE DOIS PAS faire
- ❌ Stocker des numéros de cartes ou CVV — Stripe Checkout gère tout
- ❌ Inventer un système de paiement maison
- ❌ Permettre l'achat sans CGV cochées
- ❌ Oublier la mention de non-rétractation (obligation légale française)
- ❌ Casser les routes existantes
- ❌ Faire un design SaaS générique — rester éditorial AIME

---

## DONNÉES DE TEST À CRÉER

Pour l'événement de démo "demo-saison2-lille" déjà créé (Sandrine Sarroche, 16 juin 2026, Théâtre Sébastopol Lille), créer **3 tarifs** :

```yaml
tarifs:
  - id: "tarif-plein"
    nom: "Plein tarif"
    description: "Accès au spectacle complet en placement libre dans la salle."
    prix_ttc: 38.00
    tva: 5.5
    quota: 1200
    vendus: 856
    statut: "actif"
  
  - id: "tarif-reduit"
    nom: "Tarif réduit"
    description: "Demandeurs d'emploi, étudiants -26 ans, +65 ans. Justificatif demandé à l'entrée."
    prix_ttc: 28.00
    tva: 5.5
    quota: 400
    vendus: 287
    statut: "actif"
  
  - id: "tarif-carre-or"
    nom: "Carré Or"
    description: "Placement privilégié sur les 5 premiers rangs + verre de bienvenue."
    prix_ttc: 68.00
    tva: 5.5
    quota: 100
    vendus: 91
    statut: "actif"

codes_promo:
  - code: "AIME10"
    libelle: "Lancement AIME"
    type: "pourcentage"
    montant: 10
    quota_utilisation: 50
    utilise: 12
    valide_jusqua: "2026-05-31"
```

---

## LIVRABLE ATTENDU

1. **Module Tarifs & billetterie** opérationnel dans le pilotage
2. **Parcours d'achat complet** sur `/profile/[slug]/billetterie/[event-id]`
3. **Webhook Stripe** fonctionnel qui confirme la commande
4. **Génération billet PDF** avec QR code, design éditorial AIME
5. **Email de confirmation** avec billets en pièce jointe
6. **Espace "Mes billets"** pour les acheteurs
7. **Page check-in** mobile pour l'organisateur le jour J
8. **Mode démo** activable si Stripe pas configuré

---

## RAPPEL FINAL

La billetterie est l'élément qui transforme AIME d'une jolie maquette en outil monétisable. Mais elle doit rester **éditoriale, premium, transparente** — pas un copier-coller d'Eventbrite. Le billet PDF doit être beau au point qu'on ait envie de le partager.

Bon build.
