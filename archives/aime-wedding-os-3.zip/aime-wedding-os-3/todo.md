# AIME® Wedding OS — TODO

## Phase 1 — Schéma DB + Design System
- [x] Schéma DB complet (weddings, actors, causal_nodes, causal_waves, budget_items, vendors, rsvp, plan_b, proof_log, chat_messages)
- [x] Design system AIME® : CSS variables, typographies Inter/JetBrains Mono/Caveat, palette fond #0A0A0B / or #C9A96E
- [x] Layout principal avec navigation par onglets (Chat, Cadran, Budget, Prestataires, RSVP, Plan B, Journal)

## Phase 2 — Onboarding + Cartes Uniques
- [x] Page onboarding : choix du rôle (marié, témoin, prestataire, DJ, traiteur, officiant, invité, logistique, photographe, lieu)
- [x] Création du profil mariage (nom, date, lieu, budget max)
- [x] Carte Unique par acteur (recto : identité/rôle/statut, verso : agent/responsabilités/dépendances)
- [x] Vue filtrée par rôle (isolation stricte des informations)

## Phase 3 — Bureau Chat + Agent Ripple
- [x] Interface Bureau Chat : layout sidebar + chat central
- [x] Agent Ripple (LLM) avec mémoire longue par mariage et par rôle
- [x] Suggestions contextuelles dans le chat
- [x] Extraction structurée des intentions depuis le chat → opérations sur le graphe causal
- [x] Affichage des réponses Ripple avec explications SI→ALORS→PARCE QUE
- [x] Validation humaine avant actions sensibles (paiement, envoi, modification budget)

## Phase 4 — Cadran Causal
- [x] Page Cadran Causal (/cadran)
- [x] Visualisation des ondes causales (SI→ALORS→PARCE QUE)
- [x] Filtres par statut (En attente, Validées, Rejetées)
- [x] Interface d'arbitrage humain (valider/rejeter une onde)
- [x] Création manuelle d'onde depuis le Cadran

## Phase 5 — Modules complémentaires
- [x] Module Budget causal (plafond strict, alertes de dépassement propagées, simulation)
- [x] Module Prestataires (cartes comparables, statuts, paiements, dépendances temporelles)
- [x] Module RSVP (invitations, confirmations, allergies, plan de table, signaux causaux)
- [x] Module Plan B (scénarios météo/annulation, activation depuis chat ou Cadran)
- [x] Journal de preuve rejouable (log immuable des ondes causales, replay)

## Phase 6 — Polish + Tests
- [x] Tests Vitest (9 tests : auth, causal, budget, RSVP, Plan B, rôles, journal)
- [x] Responsive mobile-first (sidebar + layout adaptatif)
- [x] Animations et micro-interactions premium (wave-enter, transitions)
- [x] Checkpoint final et livraison

## Refonte Design System — Apple Vision Pro
- [x] Nouveau CSS : glassmorphism, backdrop-blur, dégradés bleu/violet/rose lumineux, fond noir profond
- [x] Surfaces translucides (glass cards) pour toutes les cartes et panneaux
- [x] Typographie SF Pro-like (Inter) avec poids et tailles Vision Pro
- [x] Refonte Landing Page en style Vision Pro (pas de démo, tout réel)
- [x] Refonte Onboarding en style Vision Pro
- [x] Refonte AppLayout + sidebar en glass
- [x] Refonte Bureau Chat en style Vision Pro
- [x] Refonte Cadran Causal en style Vision Pro
- [x] Refonte Budget, Prestataires, RSVP, Plan B, Journal, Cartes Uniques
- [x] Vérification visuelle complète et checkpoint final

## Phase 7 — Données de test + Notifications + Graphe + Landing éditoriale

- [x] Seed données de test : mariage "Sophie & Thomas", prestataires, invités RSVP, ondes causales
- [x] Notifications push temps réel pour les ondes causales (Owner Notifications)
- [x] Graphe visuel interactif du Wedding Causal Memory Graph (@xyflow/react avec nœuds typés et arêtes causales)
- [x] Refonte landing page style éditorial blanc/rose (fond crème, serif, countdown, galerie, RSVP public)
- [x] Page publique invité (RSVP public accessible sans login, route /rsvp/:weddingId)
- [x] Tests et checkpoint final v3.0 — 9/9 tests passants, 0 erreur TypeScript

## Phase 8 — Sécurité, LLM Streaming, Export PDF

- [x] Token UUID dans rsvp_entries + route /rsvp/:token (non prédictible)
- [x] Procédure backend rsvp.getByToken (publique, sans login)
- [x] Mise à jour RSVPPublic.tsx pour utiliser le token
- [x] Affichage du lien d'invitation dans le module RSVP (copier/partager)
- [x] Connexion LLM streaming dans le Bureau Chat (agent Ripple)
- [x] Export PDF du Journal de preuve (génération côté serveur, téléchargement)
- [x] Tests et checkpoint final v4.0 — 9/9 tests passants, 0 erreur TypeScript
