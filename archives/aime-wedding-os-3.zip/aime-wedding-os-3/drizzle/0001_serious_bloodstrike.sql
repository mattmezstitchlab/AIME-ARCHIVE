CREATE TABLE `actor_cards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`userId` int,
	`name` varchar(255) NOT NULL,
	`role` enum('couple','witness','parent','guest','vendor','venue','photographer','dj_musician','caterer','officiant','logistics','planner','security','other') NOT NULL,
	`color` varchar(7) DEFAULT '#C9A96E',
	`status` enum('invited','confirmed','active','unavailable') DEFAULT 'invited',
	`email` varchar(320),
	`phone` varchar(50),
	`responsibilities` json DEFAULT ('[]'),
	`dependencies` json DEFAULT ('[]'),
	`alertThreshold` enum('low','medium','high') DEFAULT 'medium',
	`agentEnabled` boolean DEFAULT true,
	`inviteToken` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `actor_cards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `budget_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`category` varchar(100) NOT NULL,
	`label` varchar(255) NOT NULL,
	`estimatedAmount` decimal(12,2) DEFAULT '0',
	`actualAmount` decimal(12,2) DEFAULT '0',
	`paidAmount` decimal(12,2) DEFAULT '0',
	`isLocked` boolean DEFAULT false,
	`vendorId` int,
	`status` enum('planned','quoted','confirmed','paid','cancelled') DEFAULT 'planned',
	`dueDate` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `budget_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `causal_nodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`type` enum('actor','resource','moment','dependency','constraint','margin','risk','signal','budget','vendor','rsvp','document') NOT NULL,
	`label` varchar(255) NOT NULL,
	`value` json,
	`status` enum('stable','warning','critical','resolved') DEFAULT 'stable',
	`linkedEntityId` int,
	`linkedEntityType` varchar(64),
	`posX` decimal(8,2) DEFAULT '0',
	`posY` decimal(8,2) DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `causal_nodes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `causal_waves` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`sourceNodeId` int NOT NULL,
	`triggerDescription` text NOT NULL,
	`ifCondition` text NOT NULL,
	`thenEffect` text NOT NULL,
	`becauseReason` text NOT NULL,
	`impactedNodeIds` json DEFAULT ('[]'),
	`impactedActorIds` json DEFAULT ('[]'),
	`severity` enum('info','warning','critical') DEFAULT 'warning',
	`status` enum('pending','validated','rejected','auto_applied') DEFAULT 'pending',
	`humanDecision` text,
	`decidedByUserId` int,
	`decidedAt` timestamp,
	`replayData` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `causal_waves_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`actorCardId` int,
	`userId` int,
	`role` enum('user','assistant','system') NOT NULL,
	`content` text NOT NULL,
	`metadata` json,
	`waveId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `plan_b_scenarios` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`trigger` enum('rain','vendor_cancel','health','transport','other') NOT NULL,
	`description` text,
	`actions` json DEFAULT ('[]'),
	`isActive` boolean DEFAULT false,
	`activatedAt` timestamp,
	`activatedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `plan_b_scenarios_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `proof_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`eventType` varchar(100) NOT NULL,
	`description` text NOT NULL,
	`source` enum('chat','cadran','agent','system','user','vendor','rsvp','weather') NOT NULL,
	`actorId` int,
	`waveId` int,
	`snapshotBefore` json,
	`snapshotAfter` json,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `proof_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rsvp_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`actorCardId` int,
	`guestName` varchar(255) NOT NULL,
	`email` varchar(320),
	`status` enum('pending','confirmed','declined','maybe') DEFAULT 'pending',
	`plusOne` boolean DEFAULT false,
	`plusOneName` varchar(255),
	`dietaryRestrictions` text,
	`allergies` json DEFAULT ('[]'),
	`tableNumber` int,
	`accommodationNeeded` boolean DEFAULT false,
	`transportNeeded` boolean DEFAULT false,
	`notes` text,
	`respondedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rsvp_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vendors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`actorCardId` int,
	`name` varchar(255) NOT NULL,
	`category` varchar(100) NOT NULL,
	`style` varchar(255),
	`zone` varchar(255),
	`estimatedPrice` decimal(12,2),
	`availability` enum('available','tentative','booked','unavailable') DEFAULT 'tentative',
	`contractStatus` enum('none','requested','signed','cancelled') DEFAULT 'none',
	`depositPaid` boolean DEFAULT false,
	`depositAmount` decimal(12,2),
	`arrivalTime` timestamp,
	`departureTime` timestamp,
	`contactEmail` varchar(320),
	`contactPhone` varchar(50),
	`notes` text,
	`causalDependencies` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vendors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weddings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`weddingDate` timestamp,
	`venue` varchar(500),
	`budgetMax` decimal(12,2) DEFAULT '0',
	`budgetSpent` decimal(12,2) DEFAULT '0',
	`guestCount` int DEFAULT 0,
	`stabilityScore` int DEFAULT 100,
	`status` enum('planning','confirmed','day_of','completed') DEFAULT 'planning',
	`weatherRisk` enum('low','medium','high') DEFAULT 'low',
	`planBActive` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weddings_id` PRIMARY KEY(`id`)
);
