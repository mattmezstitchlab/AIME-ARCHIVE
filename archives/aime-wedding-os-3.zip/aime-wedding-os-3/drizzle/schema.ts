import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
} from "drizzle-orm/mysql-core";

// ─── USERS ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

// ─── WEDDINGS ─────────────────────────────────────────────────────────────────
export const weddings = mysqlTable("weddings", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  weddingDate: timestamp("weddingDate"),
  venue: varchar("venue", { length: 500 }),
  budgetMax: decimal("budgetMax", { precision: 12, scale: 2 }).default("0"),
  budgetSpent: decimal("budgetSpent", { precision: 12, scale: 2 }).default("0"),
  guestCount: int("guestCount").default(0),
  stabilityScore: int("stabilityScore").default(100), // 0-100
  status: mysqlEnum("status", ["planning", "confirmed", "day_of", "completed"]).default("planning"),
  weatherRisk: mysqlEnum("weatherRisk", ["low", "medium", "high"]).default("low"),
  planBActive: boolean("planBActive").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── ACTOR CARDS (Cartes Uniques) ─────────────────────────────────────────────
export const actorCards = mysqlTable("actor_cards", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  userId: int("userId"),
  name: varchar("name", { length: 255 }).notNull(),
  role: mysqlEnum("role", [
    "couple", "witness", "parent", "guest", "vendor",
    "venue", "photographer", "dj_musician", "caterer",
    "officiant", "logistics", "planner", "security", "other"
  ]).notNull(),
  color: varchar("color", { length: 7 }).default("#C9A96E"),
  status: mysqlEnum("status", ["invited", "confirmed", "active", "unavailable"]).default("invited"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  responsibilities: json("responsibilities").$type<string[]>(),
  dependencies: json("dependencies").$type<number[]>(),
  alertThreshold: mysqlEnum("alertThreshold", ["low", "medium", "high"]).default("medium"),
  agentEnabled: boolean("agentEnabled").default(true),
  inviteToken: varchar("inviteToken", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── CAUSAL NODES (Wedding Causal Memory Graph) ───────────────────────────────
export const causalNodes = mysqlTable("causal_nodes", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  type: mysqlEnum("type", [
    "actor", "resource", "moment", "dependency",
    "constraint", "margin", "risk", "signal",
    "budget", "vendor", "rsvp", "document"
  ]).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  value: json("value"), // flexible payload per type
  status: mysqlEnum("status", ["stable", "warning", "critical", "resolved"]).default("stable"),
  linkedEntityId: int("linkedEntityId"), // FK to actor, vendor, etc.
  linkedEntityType: varchar("linkedEntityType", { length: 64 }),
  posX: decimal("posX", { precision: 8, scale: 2 }).default("0"),
  posY: decimal("posY", { precision: 8, scale: 2 }).default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── CAUSAL WAVES (Ondes de propagation) ──────────────────────────────────────
export const causalWaves = mysqlTable("causal_waves", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  sourceNodeId: int("sourceNodeId").notNull(),
  triggerDescription: text("triggerDescription").notNull(), // "Cortège +8 min"
  ifCondition: text("ifCondition").notNull(),    // SI
  thenEffect: text("thenEffect").notNull(),       // ALORS
  becauseReason: text("becauseReason").notNull(), // PARCE QUE
  impactedNodeIds: json("impactedNodeIds").$type<number[]>(),
  impactedActorIds: json("impactedActorIds").$type<number[]>(),
  severity: mysqlEnum("severity", ["info", "warning", "critical"]).default("warning"),
  status: mysqlEnum("status", ["pending", "validated", "rejected", "auto_applied"]).default("pending"),
  humanDecision: text("humanDecision"),
  decidedByUserId: int("decidedByUserId"),
  decidedAt: timestamp("decidedAt"),
  replayData: json("replayData"), // full snapshot for replay
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ─── BUDGET ITEMS ─────────────────────────────────────────────────────────────
export const budgetItems = mysqlTable("budget_items", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  estimatedAmount: decimal("estimatedAmount", { precision: 12, scale: 2 }).default("0"),
  actualAmount: decimal("actualAmount", { precision: 12, scale: 2 }).default("0"),
  paidAmount: decimal("paidAmount", { precision: 12, scale: 2 }).default("0"),
  isLocked: boolean("isLocked").default(false),
  vendorId: int("vendorId"),
  status: mysqlEnum("status", ["planned", "quoted", "confirmed", "paid", "cancelled"]).default("planned"),
  dueDate: timestamp("dueDate"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── VENDORS (Prestataires) ───────────────────────────────────────────────────
export const vendors = mysqlTable("vendors", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  actorCardId: int("actorCardId"),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  style: varchar("style", { length: 255 }),
  zone: varchar("zone", { length: 255 }),
  estimatedPrice: decimal("estimatedPrice", { precision: 12, scale: 2 }),
  availability: mysqlEnum("availability", ["available", "tentative", "booked", "unavailable"]).default("tentative"),
  contractStatus: mysqlEnum("contractStatus", ["none", "requested", "signed", "cancelled"]).default("none"),
  depositPaid: boolean("depositPaid").default(false),
  depositAmount: decimal("depositAmount", { precision: 12, scale: 2 }),
  arrivalTime: timestamp("arrivalTime"),
  departureTime: timestamp("departureTime"),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  notes: text("notes"),
  causalDependencies: json("causalDependencies").$type<number[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── RSVP ─────────────────────────────────────────────────────────────────────
export const rsvpEntries = mysqlTable("rsvp_entries", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  actorCardId: int("actorCardId"),
  guestName: varchar("guestName", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  status: mysqlEnum("status", ["pending", "confirmed", "declined", "maybe"]).default("pending"),
  plusOne: boolean("plusOne").default(false),
  plusOneName: varchar("plusOneName", { length: 255 }),
  dietaryRestrictions: text("dietaryRestrictions"),
  allergies: json("allergies").$type<string[]>(),
  tableNumber: int("tableNumber"),
  accommodationNeeded: boolean("accommodationNeeded").default(false),
  transportNeeded: boolean("transportNeeded").default(false),
  notes: text("notes"),
  inviteToken: varchar("inviteToken", { length: 64 }).unique(),
  respondedAt: timestamp("respondedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── PLAN B SCENARIOS ─────────────────────────────────────────────────────────
export const planBScenarios = mysqlTable("plan_b_scenarios", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  trigger: mysqlEnum("trigger", ["rain", "vendor_cancel", "health", "transport", "other"]).notNull(),
  description: text("description"),
  actions: json("actions").$type<{ actorId: number; message: string; newTime?: string }[]>(),
  isActive: boolean("isActive").default(false),
  activatedAt: timestamp("activatedAt"),
  activatedByUserId: int("activatedByUserId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ─── PROOF LOG (Journal de preuve rejouable) ──────────────────────────────────
export const proofLog = mysqlTable("proof_log", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  eventType: varchar("eventType", { length: 100 }).notNull(),
  description: text("description").notNull(),
  source: mysqlEnum("source", ["chat", "cadran", "agent", "system", "user", "vendor", "rsvp", "weather"]).notNull(),
  actorId: int("actorId"),
  waveId: int("waveId"),
  snapshotBefore: json("snapshotBefore"),
  snapshotAfter: json("snapshotAfter"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ─── CHAT MESSAGES ────────────────────────────────────────────────────────────
export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  actorCardId: int("actorCardId"),
  userId: int("userId"),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  metadata: json("metadata"), // extracted intents, causal refs, etc.
  waveId: int("waveId"), // linked causal wave if any
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ─── TYPES ────────────────────────────────────────────────────────────────────
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Wedding = typeof weddings.$inferSelect;
export type InsertWedding = typeof weddings.$inferInsert;
export type ActorCard = typeof actorCards.$inferSelect;
export type InsertActorCard = typeof actorCards.$inferInsert;
export type CausalNode = typeof causalNodes.$inferSelect;
export type CausalWave = typeof causalWaves.$inferSelect;
export type BudgetItem = typeof budgetItems.$inferSelect;
export type Vendor = typeof vendors.$inferSelect;
export type RsvpEntry = typeof rsvpEntries.$inferSelect;
export type PlanBScenario = typeof planBScenarios.$inferSelect;
export type ProofLogEntry = typeof proofLog.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
