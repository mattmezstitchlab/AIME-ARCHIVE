ALTER TABLE `actor_cards` MODIFY COLUMN `responsibilities` json;--> statement-breakpoint
ALTER TABLE `actor_cards` MODIFY COLUMN `dependencies` json;--> statement-breakpoint
ALTER TABLE `causal_waves` MODIFY COLUMN `impactedNodeIds` json;--> statement-breakpoint
ALTER TABLE `causal_waves` MODIFY COLUMN `impactedActorIds` json;--> statement-breakpoint
ALTER TABLE `plan_b_scenarios` MODIFY COLUMN `actions` json;--> statement-breakpoint
ALTER TABLE `rsvp_entries` MODIFY COLUMN `allergies` json;--> statement-breakpoint
ALTER TABLE `vendors` MODIFY COLUMN `causalDependencies` json;