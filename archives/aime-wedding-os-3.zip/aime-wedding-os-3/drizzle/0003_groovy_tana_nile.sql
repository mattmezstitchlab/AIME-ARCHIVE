ALTER TABLE `rsvp_entries` ADD `inviteToken` varchar(64);--> statement-breakpoint
ALTER TABLE `rsvp_entries` ADD CONSTRAINT `rsvp_entries_inviteToken_unique` UNIQUE(`inviteToken`);