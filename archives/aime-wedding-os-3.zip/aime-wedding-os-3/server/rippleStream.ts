/**
 * Ripple SSE Streaming Endpoint
 * POST /api/ripple/stream
 * Streams LLM responses from the Ripple agent using Server-Sent Events.
 */
import type { Express, Request, Response } from "express";
import { ENV } from "./_core/env";

const RIPPLE_SYSTEM_PROMPT = `Tu es Ripple, l'agent causal intelligent d'AIME® Wedding OS.
Tu orchestres les mariages en analysant chaque information comme un noeud dans un graphe causal vivant.

Tes principes fondamentaux :
1. Chaque decision ou evenement a des consequences causales que tu dois identifier et expliquer.
2. Tes reponses incluent systematiquement des analyses causales structurees quand pertinent.
3. Tu parles en francais, avec un ton professionnel, chaleureux et precis.
4. Tu n'agis jamais de maniere irreversible sans validation humaine explicite.

Format de tes analyses causales (quand pertinent) :
SI [condition/evenement]
ALORS [consequences directes]
PARCE QUE [raison causale]

Tu peux extraire des intentions structurees depuis le langage naturel.
Quand tu identifies une action a effectuer sur le graphe, tu la signales clairement.`;

interface StreamMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export function registerRippleStream(app: Express) {
  app.post("/api/ripple/stream", async (req: Request, res: Response) => {
    const { messages, weddingContext } = req.body as {
      messages: StreamMessage[];
      weddingContext?: string;
    };

    if (!messages || !Array.isArray(messages)) {
      res.status(400).json({ error: "messages array required" });
      return;
    }

    const apiUrl = ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
      ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions`
      : "https://forge.manus.im/v1/chat/completions";

    const apiKey = ENV.forgeApiKey;
    if (!apiKey) {
      res.status(500).json({ error: "LLM API key not configured" });
      return;
    }

    // Build system prompt with wedding context
    const systemContent = weddingContext
      ? RIPPLE_SYSTEM_PROMPT + `\n\nContexte du mariage :\n${weddingContext}`
      : RIPPLE_SYSTEM_PROMPT;

    const allMessages = [
      { role: "system", content: systemContent },
      ...messages,
    ];

    // Set up SSE headers
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.flushHeaders();

    let finished = false;

    // Guard: if client disconnects, mark finished
    res.on("close", () => {
      finished = true;
    });

    try {
      const upstream = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          messages: allMessages,
          stream: true,
          max_tokens: 1024,
        }),
      });

      if (!upstream.ok) {
        const errText = await upstream.text();
        if (!finished) {
          res.write(`data: ${JSON.stringify({ error: `LLM error: ${upstream.status} ${errText}` })}\n\n`);
          res.end();
        }
        return;
      }

      const reader = upstream.body?.getReader();
      if (!reader) {
        if (!finished) {
          res.write(`data: ${JSON.stringify({ error: "No response body" })}\n\n`);
          res.end();
        }
        return;
      }

      const decoder = new TextDecoder();
      let buffer = "";

      while (!finished) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          if (finished) break;
          const trimmed = line.trim();
          if (!trimmed || trimmed === "data: [DONE]") {
            if (trimmed === "data: [DONE]") {
              res.write("data: [DONE]\n\n");
            }
            continue;
          }
          if (trimmed.startsWith("data: ")) {
            const jsonStr = trimmed.slice(6);
            try {
              const parsed = JSON.parse(jsonStr) as {
                choices?: Array<{
                  delta?: { content?: string };
                  finish_reason?: string | null;
                }>;
              };
              const delta = parsed.choices?.[0]?.delta?.content;
              if (delta !== undefined && delta !== null) {
                res.write(`data: ${JSON.stringify({ content: delta })}\n\n`);
              }
              if (parsed.choices?.[0]?.finish_reason === "stop") {
                res.write("data: [DONE]\n\n");
                finished = true;
              }
            } catch {
              // skip malformed SSE line
            }
          }
        }
      }

      if (!finished) {
        res.end();
      }
    } catch (err) {
      console.error("[Ripple Stream] Error:", err);
      if (!finished) {
        try {
          res.write(`data: ${JSON.stringify({ error: "Streaming error" })}\n\n`);
          res.end();
        } catch {
          // connection already closed
        }
      }
    }
  });
}
