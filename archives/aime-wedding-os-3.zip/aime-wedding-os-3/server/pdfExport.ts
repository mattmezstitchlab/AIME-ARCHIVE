/**
 * PDF Export Endpoint for Journal de Preuve Rejouable
 * GET /api/journal/:weddingId/export-pdf
 * Generates a real PDF binary using pdfkit.
 */
import type { Express, Request, Response } from "express";
import PDFDocument from "pdfkit";
import { getDb } from "./db";
import { proofLog, weddings } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

function formatDate(d: Date | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleString("fr-FR", {
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

const EVENT_LABELS: Record<string, string> = {
  wave_created: "Onde causale créée",
  wave_validated: "Onde validée",
  wave_rejected: "Onde rejetée",
  vendor_added: "Prestataire ajouté",
  budget_updated: "Budget mis à jour",
  rsvp_confirmed: "RSVP confirmé",
  plan_b_activated: "Plan B activé",
  chat_ripple: "Message Ripple",
  wedding_created: "Mariage créé",
  budget_alert: "Alerte budget",
  rsvp_received: "RSVP reçu",
};

export function registerPdfExport(app: Express) {
  app.get("/api/journal/:weddingId/export-pdf", async (req: Request, res: Response) => {
    const weddingId = parseInt(req.params.weddingId || "0");
    if (!weddingId) {
      res.status(400).json({ error: "Invalid weddingId" });
      return;
    }

    try {
      const db = await getDb();
      if (!db) {
        res.status(503).json({ error: "Database unavailable" });
        return;
      }

      const [weddingRows, entries] = await Promise.all([
        db.select().from(weddings).where(eq(weddings.id, weddingId)).limit(1),
        db.select().from(proofLog)
          .where(eq(proofLog.weddingId, weddingId))
          .orderBy(desc(proofLog.createdAt))
          .limit(500),
      ]);

      const wedding = weddingRows[0];
      if (!wedding) {
        res.status(404).json({ error: "Wedding not found" });
        return;
      }

      const weddingName = wedding.name || "Mariage";
      const weddingDate = wedding.weddingDate
        ? new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })
        : "Date non définie";
      const exportDate = new Date().toLocaleString("fr-FR");

      // Create PDF
      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 50, bottom: 50, left: 50, right: 50 },
        info: {
          Title: `Journal de Preuve — ${weddingName}`,
          Author: "AIME® Wedding OS",
          Subject: "Journal de preuve rejouable",
          Creator: "AIME® Wedding OS — Moteur causal SI→ALORS→PARCE QUE",
        },
      });

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="journal-preuve-${weddingId}-${Date.now()}.pdf"`
      );
      doc.pipe(res);

      // ─── HEADER ────────────────────────────────────────────────────────────
      // Background header bar
      doc.rect(0, 0, doc.page.width, 90).fill("#1a1a2e");

      // AIME® badge
      doc.roundedRect(50, 18, 80, 18, 9).fill("#667eea");
      doc.fontSize(8).fillColor("#ffffff").font("Helvetica-Bold")
        .text("AIME® Wedding OS", 54, 23, { width: 72, align: "center" });

      // Title
      doc.fontSize(20).fillColor("#ffffff").font("Helvetica-Bold")
        .text("Journal de Preuve Rejouable", 145, 15, { width: 350 });

      doc.fontSize(10).fillColor("rgba(255,255,255,0.7)").font("Helvetica")
        .text(`${weddingName}  ·  ${weddingDate}`, 145, 40);

      doc.fontSize(8).fillColor("rgba(255,255,255,0.5)")
        .text(`Exporté le ${exportDate}  ·  Score de stabilité : ${wedding.stabilityScore || 100}/100`, 145, 58);

      // ─── STATS BAR ─────────────────────────────────────────────────────────
      const statsY = 105;
      doc.rect(50, statsY, doc.page.width - 100, 55).fill("#f0f4ff").stroke("#e5e7eb");

      const totalWaves = entries.filter(e => e.eventType.startsWith("wave")).length;
      const validated = entries.filter(e => e.eventType === "wave_validated").length;
      const vendors = entries.filter(e => e.eventType === "vendor_added").length;
      const rsvps = entries.filter(e => e.eventType === "rsvp_confirmed" || e.eventType === "rsvp_received").length;

      const stats = [
        { value: String(entries.length), label: "Entrées totales" },
        { value: String(totalWaves), label: "Ondes causales" },
        { value: String(validated), label: "Validées" },
        { value: String(vendors), label: "Prestataires" },
        { value: String(rsvps), label: "RSVP" },
      ];

      const statWidth = (doc.page.width - 100) / stats.length;
      stats.forEach((s, i) => {
        const x = 50 + i * statWidth;
        doc.fontSize(18).fillColor("#667eea").font("Helvetica-Bold")
          .text(s.value, x, statsY + 8, { width: statWidth, align: "center" });
        doc.fontSize(7).fillColor("#9ca3af").font("Helvetica")
          .text(s.label.toUpperCase(), x, statsY + 34, { width: statWidth, align: "center" });
      });

      // ─── SECTION TITLE ─────────────────────────────────────────────────────
      doc.moveDown(0.5);
      const sectionY = statsY + 70;
      doc.fontSize(11).fillColor("#1a1a2e").font("Helvetica-Bold")
        .text("Historique complet des événements causaux", 50, sectionY);
      doc.moveTo(50, sectionY + 16).lineTo(doc.page.width - 50, sectionY + 16)
        .strokeColor("#e5e7eb").lineWidth(1).stroke();

      // ─── TABLE HEADER ──────────────────────────────────────────────────────
      const tableTop = sectionY + 24;
      const colWidths = [30, 90, 110, 240, 55];
      const colX = [50, 80, 170, 280, 520];
      const headers = ["#", "Date & Heure", "Action", "Description", "Source"];

      doc.rect(50, tableTop, doc.page.width - 100, 18).fill("#1a1a2e");
      headers.forEach((h, i) => {
        doc.fontSize(7).fillColor("#ffffff").font("Helvetica-Bold")
          .text(h, colX[i]! + 3, tableTop + 5, { width: colWidths[i]! - 6 });
      });

      // ─── TABLE ROWS ────────────────────────────────────────────────────────
      let y = tableTop + 18;
      const rowHeight = 22;
      const pageBottom = doc.page.height - 60;

      entries.forEach((entry, i) => {
        // New page if needed
        if (y + rowHeight > pageBottom) {
          doc.addPage();
          y = 50;
          // Repeat header
          doc.rect(50, y, doc.page.width - 100, 18).fill("#1a1a2e");
          headers.forEach((h, hi) => {
            doc.fontSize(7).fillColor("#ffffff").font("Helvetica-Bold")
              .text(h, colX[hi]! + 3, y + 5, { width: colWidths[hi]! - 6 });
          });
          y += 18;
        }

        // Row background
        const bgColor = i % 2 === 0 ? "#ffffff" : "#f9fafb";
        doc.rect(50, y, doc.page.width - 100, rowHeight).fill(bgColor);

        // Row border
        doc.rect(50, y, doc.page.width - 100, rowHeight)
          .strokeColor("#f3f4f6").lineWidth(0.5).stroke();

        const rowNum = entries.length - i;
        const dateStr = formatDate(entry.createdAt);
        const eventLabel = EVENT_LABELS[entry.eventType] || entry.eventType;
        const description = (entry.description || "").substring(0, 80);
        const source = entry.source || "—";

        doc.fontSize(7).fillColor("#9ca3af").font("Helvetica")
          .text(String(rowNum), colX[0]! + 3, y + 7, { width: colWidths[0]! - 6, align: "center" });

        doc.fontSize(7).fillColor("#6b7280").font("Helvetica")
          .text(dateStr, colX[1]! + 3, y + 7, { width: colWidths[1]! - 6 });

        // Action badge color
        const badgeColors: Record<string, string> = {
          wave_created: "#92400e",
          wave_validated: "#065f46",
          wave_rejected: "#991b1b",
          vendor_added: "#3730a3",
          budget_updated: "#9d174d",
          budget_alert: "#9a3412",
          rsvp_confirmed: "#065f46",
          rsvp_received: "#065f46",
          plan_b_activated: "#9a3412",
          chat_ripple: "#5b21b6",
          wedding_created: "#075985",
        };
        const badgeBgColors: Record<string, string> = {
          wave_created: "#fef3c7",
          wave_validated: "#d1fae5",
          wave_rejected: "#fee2e2",
          vendor_added: "#e0e7ff",
          budget_updated: "#fce7f3",
          budget_alert: "#fed7aa",
          rsvp_confirmed: "#d1fae5",
          rsvp_received: "#d1fae5",
          plan_b_activated: "#fed7aa",
          chat_ripple: "#ede9fe",
          wedding_created: "#e0f2fe",
        };
        const badgeBg = badgeBgColors[entry.eventType] || "#f3f4f6";
        const badgeFg = badgeColors[entry.eventType] || "#374151";

        const badgeW = Math.min(colWidths[2]! - 6, eventLabel.length * 5 + 10);
        doc.roundedRect(colX[2]! + 3, y + 5, badgeW, 12, 6).fill(badgeBg);
        doc.fontSize(6.5).fillColor(badgeFg).font("Helvetica-Bold")
          .text(eventLabel, colX[2]! + 5, y + 8, { width: badgeW - 4 });

        doc.fontSize(7).fillColor("#374151").font("Helvetica")
          .text(description, colX[3]! + 3, y + 7, { width: colWidths[3]! - 6, lineBreak: false });

        doc.fontSize(7).fillColor("#6b7280").font("Helvetica")
          .text(source, colX[4]! + 3, y + 7, { width: colWidths[4]! - 6 });

        y += rowHeight;
      });

      // ─── FOOTER ────────────────────────────────────────────────────────────
      const footerY = doc.page.height - 50;
      doc.moveTo(50, footerY - 10).lineTo(doc.page.width - 50, footerY - 10)
        .strokeColor("#e5e7eb").lineWidth(0.5).stroke();

      doc.fontSize(7).fillColor("#9ca3af").font("Helvetica")
        .text("AIME® Wedding OS — Moteur causal SI→ALORS→PARCE QUE — Document de traçabilité officiel", 50, footerY, { width: 350 })
        .text(`Généré le ${exportDate}`, doc.page.width - 200, footerY, { width: 150, align: "right" });

      doc.end();
    } catch (err) {
      console.error("[PDF Export] Error:", err);
      if (!res.headersSent) {
        res.status(500).json({ error: "Export failed" });
      }
    }
  });
}
