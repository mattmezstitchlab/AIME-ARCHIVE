import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function makeCtx(role: "admin" | "user" = "user"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@aime.wedding",
      name: "Test User",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("retourne l'utilisateur connecté", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();
    expect(user).toBeDefined();
    expect(user?.email).toBe("test@aime.wedding");
  });
});

describe("auth.logout", () => {
  it("efface le cookie de session et retourne success", async () => {
    const cleared: string[] = [];
    const ctx: TrpcContext = {
      ...makeCtx(),
      res: {
        clearCookie: (name: string) => cleared.push(name),
      } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(cleared.length).toBe(1);
  });
});

// ─── Moteur causal — structure SI→ALORS→PARCE QUE ────────────────────────────

describe("causal.waves — structure d'onde causale", () => {
  it("une onde possède les champs cause, impact et reason (SI→ALORS→PARCE QUE)", () => {
    // Vérifie que le type CausalWave contient bien les trois champs sémantiques
    type WaveShape = {
      cause: string;
      impact: string;
      reason: string;
      status: string;
    };

    const wave: WaveShape = {
      cause: "Le traiteur annule",
      impact: "Le repas du soir est compromis",
      reason: "Contrat non signé avant J-30",
      status: "pending",
    };

    expect(wave.cause).toBeTruthy();
    expect(wave.impact).toBeTruthy();
    expect(wave.reason).toBeTruthy();
    expect(["pending", "validated", "rejected", "propagating", "resolved"]).toContain(wave.status);
  });
});

// ─── Budget causal ────────────────────────────────────────────────────────────

describe("budget — structure d'un poste budgétaire", () => {
  it("un poste budgétaire a un montant estimé et un montant réel", () => {
    type BudgetItem = {
      label: string;
      estimatedAmount: number;
      actualAmount: number | null;
      category: string;
      isPaid: boolean;
    };

    const item: BudgetItem = {
      label: "Traiteur",
      estimatedAmount: 8000,
      actualAmount: null,
      category: "catering",
      isPaid: false,
    };

    expect(item.estimatedAmount).toBeGreaterThan(0);
    expect(item.actualAmount).toBeNull();
    expect(item.isPaid).toBe(false);
  });
});

// ─── RSVP ─────────────────────────────────────────────────────────────────────

describe("rsvp — statuts valides", () => {
  it("les statuts RSVP couvrent tous les cas de réponse", () => {
    const validStatuses = ["pending", "confirmed", "declined", "maybe"];
    expect(validStatuses).toContain("confirmed");
    expect(validStatuses).toContain("declined");
    expect(validStatuses).toContain("pending");
    expect(validStatuses).toContain("maybe");
    expect(validStatuses.length).toBe(4);
  });
});

// ─── Plan B ───────────────────────────────────────────────────────────────────

describe("planB — déclencheurs valides", () => {
  it("les déclencheurs Plan B couvrent les risques principaux", () => {
    const triggers = ["rain", "vendor_cancel", "health", "transport", "other"];
    expect(triggers).toContain("rain");
    expect(triggers).toContain("vendor_cancel");
    expect(triggers.length).toBeGreaterThanOrEqual(4);
  });
});

// ─── Cartes Uniques — rôles ───────────────────────────────────────────────────

describe("actorCards — rôles valides", () => {
  it("les rôles couvrent tous les acteurs d'un mariage", () => {
    const roles = [
      "couple", "witness", "parent", "guest", "vendor",
      "venue", "photographer", "dj_musician", "caterer",
      "officiant", "logistics", "planner", "security", "other"
    ];
    expect(roles).toContain("couple");
    expect(roles).toContain("witness");
    expect(roles).toContain("photographer");
    expect(roles).toContain("caterer");
    expect(roles.length).toBe(14);
  });
});

// ─── Journal de preuve — sources ─────────────────────────────────────────────

describe("proofLog — sources valides", () => {
  it("les sources du journal couvrent tous les points d'entrée causaux", () => {
    const sources = ["chat", "cadran", "agent", "system", "user", "vendor", "rsvp", "weather"];
    expect(sources).toContain("chat");
    expect(sources).toContain("cadran");
    expect(sources).toContain("agent");
    expect(sources).toContain("weather");
    expect(sources.length).toBe(8);
  });
});
