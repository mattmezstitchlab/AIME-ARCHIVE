import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { weddings, actorCards, causalNodes, causalWaves, chatMessages, budgetItems, vendors, rsvpEntries, planBScenarios, proofLog } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import type { ResultSetHeader } from "mysql2";

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function getInsertId(result: unknown): number {
  const r = result as [ResultSetHeader, unknown];
  return Number(r[0]?.insertId ?? 0);
}

async function logProof(
  weddingId: number,
  eventType: string,
  description: string,
  source: "chat" | "cadran" | "agent" | "system" | "user" | "vendor" | "rsvp" | "weather",
  extra?: Record<string, unknown>
) {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(proofLog).values({
      weddingId,
      eventType,
      description,
      source,
      actorId: extra?.actorId as number | undefined,
      waveId: extra?.waveId as number | undefined,
      metadata: extra ? JSON.stringify(extra) : undefined,
    });
  } catch { /* non-blocking */ }
}

// ─── RIPPLE SYSTEM PROMPT ─────────────────────────────────────────────────────
const RIPPLE_SYSTEM_PROMPT = `Tu es Ripple, l'agent causal intelligent d'AIME® Wedding OS.
Tu orchestres les mariages en analysant chaque information comme un nœud dans un graphe causal vivant.

Tes principes fondamentaux :
1. Chaque décision ou événement a des conséquences causales que tu dois identifier et expliquer.
2. Tes réponses incluent systématiquement des analyses causales structurées quand pertinent.
3. Tu parles en français, avec un ton professionnel, chaleureux et précis.
4. Tu n'agis jamais de manière irréversible sans validation humaine explicite.

Format de tes analyses causales (quand pertinent) :
🔵 SI [condition/événement]
🟡 ALORS [conséquences directes]
🔴 PARCE QUE [raison causale]

Tu peux extraire des intentions structurées depuis le langage naturel.
Quand tu identifies une action à effectuer sur le graphe, tu la signales clairement.

Contexte du mariage : {WEDDING_CONTEXT}`;

export const appRouter = router({
  system: systemRouter,

  // ─── AUTH ────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── WEDDINGS ────────────────────────────────────────────────────────────
  weddings: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(weddings).where(eq(weddings.ownerId, ctx.user.id)).orderBy(desc(weddings.createdAt));
    }),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;
      const rows = await db.select().from(weddings).where(and(eq(weddings.id, input.id), eq(weddings.ownerId, ctx.user.id))).limit(1);
      return rows[0] ?? null;
    }),

    create: protectedProcedure.input(z.object({
      name: z.string().min(1),
      weddingDate: z.string().optional(),
      venue: z.string().optional(),
      budgetMax: z.number().optional(),
      guestCount: z.number().optional(),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const result = await db.insert(weddings).values({
        ownerId: ctx.user.id,
        name: input.name,
        weddingDate: input.weddingDate ? new Date(input.weddingDate) : undefined,
        venue: input.venue,
        budgetMax: input.budgetMax?.toString(),
        guestCount: input.guestCount,
      });
      const id = getInsertId(result);
      await logProof(id, "wedding_created", `Mariage "${input.name}" créé`, "system");
      return { id };
    }),

    update: protectedProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      weddingDate: z.string().optional(),
      venue: z.string().optional(),
      budgetMax: z.number().optional(),
      guestCount: z.number().optional(),
      stabilityScore: z.number().optional(),
      planBActive: z.boolean().optional(),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { id, ...rest } = input;
      const updateData: Record<string, unknown> = {};
      if (rest.name) updateData.name = rest.name;
      if (rest.weddingDate) updateData.weddingDate = new Date(rest.weddingDate);
      if (rest.venue !== undefined) updateData.venue = rest.venue;
      if (rest.budgetMax !== undefined) updateData.budgetMax = rest.budgetMax.toString();
      if (rest.guestCount !== undefined) updateData.guestCount = rest.guestCount;
      if (rest.stabilityScore !== undefined) updateData.stabilityScore = rest.stabilityScore;
      if (rest.planBActive !== undefined) updateData.planBActive = rest.planBActive;
      await db.update(weddings).set(updateData).where(and(eq(weddings.id, id), eq(weddings.ownerId, ctx.user.id)));
      return { success: true };
    }),
  }),

  // ─── ACTOR CARDS (Cartes Uniques) ────────────────────────────────────────
  actorCards: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(actorCards).where(eq(actorCards.weddingId, input.weddingId)).orderBy(actorCards.role);
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      name: z.string().min(1),
      role: z.enum(['couple','witness','parent','guest','vendor','venue','photographer','dj_musician','caterer','officiant','logistics','planner','security','other']),
      email: z.string().optional(),
      phone: z.string().optional(),
      color: z.string().optional(),
      responsibilities: z.array(z.string()).optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const result = await db.insert(actorCards).values({
        weddingId: input.weddingId,
        name: input.name,
        role: input.role,
        email: input.email,
        phone: input.phone,
        color: input.color,
        inviteToken: token,
        responsibilities: input.responsibilities ? JSON.stringify(input.responsibilities) as unknown as string[] : undefined,
      });
      const id = getInsertId(result);
      await logProof(input.weddingId, "actor_added", `Acteur "${input.name}" (${input.role}) ajouté`, "system", { actorId: id });
      return { id, inviteToken: token };
    }),

    update: protectedProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      status: z.enum(['invited','confirmed','active','unavailable']).optional(),
      email: z.string().optional(),
      phone: z.string().optional(),
      responsibilities: z.array(z.string()).optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { id, ...rest } = input;
      const updateData: Record<string, unknown> = {};
      if (rest.name) updateData.name = rest.name;
      if (rest.status) updateData.status = rest.status;
      if (rest.email !== undefined) updateData.email = rest.email;
      if (rest.phone !== undefined) updateData.phone = rest.phone;
      if (rest.responsibilities) updateData.responsibilities = JSON.stringify(rest.responsibilities);
      await db.update(actorCards).set(updateData).where(eq(actorCards.id, id));
      return { success: true };
    }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.delete(actorCards).where(eq(actorCards.id, input.id));
      return { success: true };
    }),
  }),

  // ─── CHAT (Agent Ripple) ─────────────────────────────────────────────────
  chat: router({
    messages: protectedProcedure.input(z.object({ weddingId: z.number(), limit: z.number().default(50) })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(chatMessages)
        .where(eq(chatMessages.weddingId, input.weddingId))
        .orderBy(chatMessages.createdAt)
        .limit(input.limit);
    }),

    saveMessage: protectedProcedure.input(z.object({
      weddingId: z.number(),
      role: z.enum(["user", "assistant"]),
      content: z.string().min(1),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const result = await db.insert(chatMessages).values({
        weddingId: input.weddingId,
        userId: input.role === "user" ? ctx.user.id : undefined,
        role: input.role,
        content: input.content,
      });
      return { id: getInsertId(result) };
    }),

    sendMessage: protectedProcedure.input(z.object({
      weddingId: z.number(),
      content: z.string().min(1),
      actorCardId: z.number().optional(),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      await db.insert(chatMessages).values({
        weddingId: input.weddingId,
        userId: ctx.user.id,
        actorCardId: input.actorCardId,
        role: "user",
        content: input.content,
      });

      const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
      const wedding = weddingRows[0];

      const history = await db.select().from(chatMessages)
        .where(eq(chatMessages.weddingId, input.weddingId))
        .orderBy(desc(chatMessages.createdAt))
        .limit(20);

      const weddingContext = wedding
        ? `Mariage: "${wedding.name}", Date: ${wedding.weddingDate ? new Date(wedding.weddingDate).toLocaleDateString('fr-FR') : 'non définie'}, Lieu: ${wedding.venue || 'non défini'}, Budget max: ${wedding.budgetMax || 0}€, Score de stabilité: ${wedding.stabilityScore}/100, Plan B actif: ${wedding.planBActive ? 'OUI' : 'non'}`
        : "Mariage non trouvé";

      const systemPrompt = RIPPLE_SYSTEM_PROMPT.replace("{WEDDING_CONTEXT}", weddingContext);

      const llmMessages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
        { role: "system", content: systemPrompt },
        ...history.reverse().slice(-10).map(m => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        })),
        { role: "user", content: input.content },
      ];

      let rippleResponse = "Je rencontre une difficulté technique. Veuillez réessayer.";
      let waveData: { ifCondition: string; thenEffect: string; becauseReason: string; severity: string } | null = null;

      try {
        const llmResult = await invokeLLM({ messages: llmMessages });
        rippleResponse = (llmResult as { choices?: Array<{ message?: { content?: string } }> }).choices?.[0]?.message?.content || rippleResponse;

        if (rippleResponse.includes("SI ") && rippleResponse.includes("ALORS")) {
          const ifMatch = rippleResponse.match(/(?:🔵\s*)?SI\s+([\s\S]+?)(?=\n|🟡|ALORS)/);
          const thenMatch = rippleResponse.match(/(?:🟡\s*)?ALORS\s+([\s\S]+?)(?=\n|🔴|PARCE QUE)/);
          const becauseMatch = rippleResponse.match(/(?:🔴\s*)?PARCE QUE\s+([\s\S]+?)(?=\n|$)/);

          if (ifMatch && thenMatch) {
            waveData = {
              ifCondition: ifMatch[1].trim(),
              thenEffect: thenMatch[1].trim(),
              becauseReason: becauseMatch ? becauseMatch[1].trim() : "Dépendance causale identifiée",
              severity: rippleResponse.toLowerCase().includes("urgent") || rippleResponse.toLowerCase().includes("critique") ? "critical" : "warning",
            };
          }
        }
      } catch (e) {
        console.error("[Ripple] LLM error:", e);
      }

      let waveId: number | undefined;
      if (waveData) {
        const nodes = await db.select().from(causalNodes).where(eq(causalNodes.weddingId, input.weddingId)).limit(1);
        const sourceNodeId = nodes[0]?.id || 1;
        const waveResult = await db.insert(causalWaves).values({
          weddingId: input.weddingId,
          sourceNodeId,
          triggerDescription: input.content.substring(0, 200),
          ifCondition: waveData.ifCondition,
          thenEffect: waveData.thenEffect,
          becauseReason: waveData.becauseReason,
          severity: waveData.severity as "info" | "warning" | "critical",
          status: "pending",
        });
        waveId = getInsertId(waveResult);

        const newScore = Math.max(0, (wedding?.stabilityScore || 100) - (waveData.severity === "critical" ? 15 : 5));
        await db.update(weddings).set({ stabilityScore: newScore }).where(eq(weddings.id, input.weddingId));
      }

      const msgResult = await db.insert(chatMessages).values({
        weddingId: input.weddingId,
        role: "assistant",
        content: rippleResponse,
        waveId,
        metadata: waveData ? JSON.stringify({ causalWave: true, waveId }) : undefined,
      });

      await logProof(input.weddingId, "chat_ripple", `Ripple a répondu à: "${input.content.substring(0, 80)}..."`, "chat");

      return {
        response: rippleResponse,
        waveId,
        hasWave: !!waveData,
        messageId: getInsertId(msgResult),
      };
    }),
  }),

  // ─── CAUSAL WAVES ────────────────────────────────────────────────────────
  causalWaves: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number(), limit: z.number().default(20) })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(causalWaves)
        .where(eq(causalWaves.weddingId, input.weddingId))
        .orderBy(desc(causalWaves.createdAt))
        .limit(input.limit);
    }),

    decide: protectedProcedure.input(z.object({
      waveId: z.number(),
      decision: z.enum(["validated", "rejected"]),
      humanDecision: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.update(causalWaves).set({
        status: input.decision,
        humanDecision: input.humanDecision,
        decidedByUserId: ctx.user.id,
        decidedAt: new Date(),
      }).where(eq(causalWaves.id, input.waveId));

      const waveRows = await db.select().from(causalWaves).where(eq(causalWaves.id, input.waveId)).limit(1);
      const wave = waveRows[0];
      if (wave) {
        await logProof(wave.weddingId, `wave_${input.decision}`, `Onde causale ${input.decision === "validated" ? "validée" : "rejetée"}: ${wave.triggerDescription}`, "cadran", { waveId: input.waveId });
        // Notification push au propriétaire
        const emoji = input.decision === "validated" ? "✅" : "❌";
        await notifyOwner({
          title: `${emoji} Onde causale ${input.decision === "validated" ? "validée" : "rejetée"}`,
          content: `${wave.triggerDescription}\n\nSI : ${wave.ifCondition}\nALORS : ${wave.thenEffect}`,
        }).catch(() => {});
      }
      return { success: true };
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      triggerDescription: z.string(),
      ifCondition: z.string(),
      thenEffect: z.string(),
      becauseReason: z.string(),
      severity: z.enum(["info", "warning", "critical"]).default("warning"),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const nodes = await db.select().from(causalNodes).where(eq(causalNodes.weddingId, input.weddingId)).limit(1);
      const sourceNodeId = nodes[0]?.id || 1;
      const result = await db.insert(causalWaves).values({ ...input, sourceNodeId, status: "pending" });
      const id = getInsertId(result);
      await logProof(input.weddingId, "wave_created", `Onde causale créée: ${input.triggerDescription}`, "cadran", { waveId: id });
      // Notification push au propriétaire pour les ondes critiques
      if (input.severity === "critical" || input.severity === "warning") {
        const emoji = input.severity === "critical" ? "🔴" : "🟡";
        await notifyOwner({
          title: `${emoji} Nouvelle onde causale — ${input.severity === "critical" ? "CRITIQUE" : "ATTENTION"}`,
          content: `${input.triggerDescription}\n\nSI : ${input.ifCondition}\nALORS : ${input.thenEffect}\nPARCE QUE : ${input.becauseReason}`,
        }).catch(() => {});
      }
      return { id };
    }),
  }),

  // ─── CAUSAL NODES ────────────────────────────────────────────────────────
  causalNodes: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(causalNodes).where(eq(causalNodes.weddingId, input.weddingId));
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      type: z.enum(['actor','resource','moment','dependency','constraint','margin','risk','signal','budget','vendor','rsvp','document']),
      label: z.string(),
      value: z.any().optional(),
      linkedEntityId: z.number().optional(),
      linkedEntityType: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const result = await db.insert(causalNodes).values({
        weddingId: input.weddingId,
        type: input.type,
        label: input.label,
        linkedEntityId: input.linkedEntityId,
        linkedEntityType: input.linkedEntityType,
        value: input.value ? JSON.stringify(input.value) : undefined,
      });
      return { id: getInsertId(result) };
    }),
  }),

  // ─── BUDGET ──────────────────────────────────────────────────────────────
  budget: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(budgetItems).where(eq(budgetItems.weddingId, input.weddingId)).orderBy(budgetItems.category);
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      category: z.string(),
      label: z.string(),
      estimatedAmount: z.number().default(0),
      vendorId: z.number().optional(),
      dueDate: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const result = await db.insert(budgetItems).values({
        weddingId: input.weddingId,
        category: input.category,
        label: input.label,
        estimatedAmount: input.estimatedAmount.toString(),
        vendorId: input.vendorId,
        dueDate: input.dueDate ? new Date(input.dueDate) : undefined,
        notes: input.notes,
      });
      const id = getInsertId(result);
      await logProof(input.weddingId, "budget_item_added", `Poste budget "${input.label}" (${input.estimatedAmount}€) ajouté`, "user");
      return { id };
    }),

    update: protectedProcedure.input(z.object({
      id: z.number(),
      weddingId: z.number(),
      estimatedAmount: z.number().optional(),
      actualAmount: z.number().optional(),
      paidAmount: z.number().optional(),
      status: z.enum(['planned','quoted','confirmed','paid','cancelled']).optional(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { id, weddingId, ...rest } = input;
      const updateData: Record<string, unknown> = {};
      if (rest.estimatedAmount !== undefined) updateData.estimatedAmount = rest.estimatedAmount.toString();
      if (rest.actualAmount !== undefined) updateData.actualAmount = rest.actualAmount.toString();
      if (rest.paidAmount !== undefined) updateData.paidAmount = rest.paidAmount.toString();
      if (rest.status) updateData.status = rest.status;
      if (rest.notes !== undefined) updateData.notes = rest.notes;
      await db.update(budgetItems).set(updateData).where(eq(budgetItems.id, id));

      const items = await db.select().from(budgetItems).where(eq(budgetItems.weddingId, weddingId));
      const totalSpent = items.reduce((acc, item) => acc + parseFloat(String(item.actualAmount || 0)), 0);
      await db.update(weddings).set({ budgetSpent: totalSpent.toString() }).where(eq(weddings.id, weddingId));

      return { success: true };
    }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.delete(budgetItems).where(eq(budgetItems.id, input.id));
      return { success: true };
    }),

    summary: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { total: 0, estimated: 0, spent: 0, paid: 0, remaining: 0, overBudget: false, byCategory: [] };
      const items = await db.select().from(budgetItems).where(eq(budgetItems.weddingId, input.weddingId));
      const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
      const wedding = weddingRows[0];
      const total = parseFloat(String(wedding?.budgetMax || 0));
      const spent = items.reduce((a, i) => a + parseFloat(String(i.actualAmount || 0)), 0);
      const paid = items.reduce((a, i) => a + parseFloat(String(i.paidAmount || 0)), 0);
      const estimated = items.reduce((a, i) => a + parseFloat(String(i.estimatedAmount || 0)), 0);

      const byCategoryMap: Record<string, { estimated: number; actual: number; paid: number }> = {};
      for (const item of items) {
        if (!byCategoryMap[item.category]) byCategoryMap[item.category] = { estimated: 0, actual: 0, paid: 0 };
        byCategoryMap[item.category].estimated += parseFloat(String(item.estimatedAmount || 0));
        byCategoryMap[item.category].actual += parseFloat(String(item.actualAmount || 0));
        byCategoryMap[item.category].paid += parseFloat(String(item.paidAmount || 0));
      }

      return {
        total, estimated, spent, paid,
        remaining: total - spent,
        overBudget: spent > total,
        byCategory: Object.entries(byCategoryMap).map(([cat, vals]) => ({ category: cat, ...vals })),
      };
    }),
  }),

  // ─── VENDORS (Prestataires) ──────────────────────────────────────────────
  vendors: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(vendors).where(eq(vendors.weddingId, input.weddingId)).orderBy(vendors.category);
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      name: z.string(),
      category: z.string(),
      style: z.string().optional(),
      zone: z.string().optional(),
      estimatedPrice: z.number().optional(),
      contactEmail: z.string().optional(),
      contactPhone: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const result = await db.insert(vendors).values({
        weddingId: input.weddingId,
        name: input.name,
        category: input.category,
        style: input.style,
        zone: input.zone,
        estimatedPrice: input.estimatedPrice?.toString(),
        contactEmail: input.contactEmail,
        contactPhone: input.contactPhone,
        notes: input.notes,
      });
      const id = getInsertId(result);
      await logProof(input.weddingId, "vendor_added", `Prestataire "${input.name}" (${input.category}) ajouté`, "user");
      return { id };
    }),

    update: protectedProcedure.input(z.object({
      id: z.number(),
      availability: z.enum(['available','tentative','booked','unavailable']).optional(),
      contractStatus: z.enum(['none','requested','signed','cancelled']).optional(),
      depositPaid: z.boolean().optional(),
      depositAmount: z.number().optional(),
      arrivalTime: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { id, ...rest } = input;
      const updateData: Record<string, unknown> = {};
      if (rest.availability) updateData.availability = rest.availability;
      if (rest.contractStatus) updateData.contractStatus = rest.contractStatus;
      if (rest.depositPaid !== undefined) updateData.depositPaid = rest.depositPaid;
      if (rest.depositAmount !== undefined) updateData.depositAmount = rest.depositAmount.toString();
      if (rest.arrivalTime) updateData.arrivalTime = new Date(rest.arrivalTime);
      if (rest.notes !== undefined) updateData.notes = rest.notes;
      await db.update(vendors).set(updateData).where(eq(vendors.id, id));
      return { success: true };
    }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.delete(vendors).where(eq(vendors.id, input.id));
      return { success: true };
    }),
  }),

  // ─── RSVP ────────────────────────────────────────────────────────────────
  rsvp: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(rsvpEntries).where(eq(rsvpEntries.weddingId, input.weddingId)).orderBy(rsvpEntries.guestName);
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      guestName: z.string(),
      email: z.string().optional(),
      status: z.enum(['pending','confirmed','declined','maybe']).default('pending'),
      plusOne: z.boolean().default(false),
      plusOneName: z.string().optional(),
      dietaryRestrictions: z.string().optional(),
      allergies: z.array(z.string()).optional(),
      tableNumber: z.number().optional(),
      accommodationNeeded: z.boolean().default(false),
      transportNeeded: z.boolean().default(false),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      // Generate a secure non-predictable invite token
      const { nanoid } = await import('nanoid');
      const inviteToken = nanoid(32);
      const result = await db.insert(rsvpEntries).values({
        weddingId: input.weddingId,
        guestName: input.guestName,
        email: input.email,
        status: input.status,
        plusOne: input.plusOne,
        plusOneName: input.plusOneName,
        dietaryRestrictions: input.dietaryRestrictions,
        allergies: input.allergies ? JSON.stringify(input.allergies) as unknown as string[] : undefined,
        tableNumber: input.tableNumber,
        accommodationNeeded: input.accommodationNeeded,
        transportNeeded: input.transportNeeded,
        notes: input.notes,
        inviteToken,
        respondedAt: input.status !== 'pending' ? new Date() : undefined,
      });
      const id = getInsertId(result);
      await logProof(input.weddingId, "rsvp_added", `Invité "${input.guestName}" ajouté (${input.status})`, "rsvp");
      return { id, inviteToken };
    }),

    // ─── PUBLIC: get RSVP entry by invite token (no login required) ───────
    getByToken: publicProcedure.input(z.object({ token: z.string() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const entries = await db.select({
        id: rsvpEntries.id,
        weddingId: rsvpEntries.weddingId,
        guestName: rsvpEntries.guestName,
        status: rsvpEntries.status,
        plusOne: rsvpEntries.plusOne,
        dietaryRestrictions: rsvpEntries.dietaryRestrictions,
        respondedAt: rsvpEntries.respondedAt,
      }).from(rsvpEntries).where(eq(rsvpEntries.inviteToken, input.token)).limit(1);
      if (!entries[0]) return null;
      // Also fetch wedding info for display
      const weddingRows = await db.select({
        id: weddings.id,
        name: weddings.name,
        weddingDate: weddings.weddingDate,
        venue: weddings.venue,
      }).from(weddings).where(eq(weddings.id, entries[0].weddingId)).limit(1);
      return { entry: entries[0], wedding: weddingRows[0] ?? null };
    }),

    // ─── PUBLIC: submit RSVP response via invite token (no login required) ─
    submitByToken: publicProcedure.input(z.object({
      token: z.string(),
      status: z.enum(['confirmed','declined','maybe']),
      guestName: z.string(),
      email: z.string().optional(),
      plusOne: z.boolean().default(false),
      guestCount: z.number().default(1),
      dietaryRestrictions: z.string().optional(),
      message: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const entries = await db.select().from(rsvpEntries).where(eq(rsvpEntries.inviteToken, input.token)).limit(1);
      if (!entries[0]) throw new Error("Token invalide ou expiré");
      const entry = entries[0];
      await db.update(rsvpEntries).set({
        status: input.status,
        guestName: input.guestName,
        email: input.email,
        plusOne: input.plusOne || input.guestCount > 1,
        dietaryRestrictions: input.dietaryRestrictions,
        notes: input.message,
        respondedAt: new Date(),
      }).where(eq(rsvpEntries.id, entry.id));
      await logProof(entry.weddingId, "rsvp_responded", `${input.guestName} a répondu : ${input.status}`, "rsvp");
      return { success: true };
    }),

    update: protectedProcedure.input(z.object({
      id: z.number(),
      status: z.enum(['pending','confirmed','declined','maybe']).optional(),
      tableNumber: z.number().optional(),
      notes: z.string().optional(),
      plusOne: z.boolean().optional(),
      plusOneName: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { id, ...rest } = input;
      const updateData: Record<string, unknown> = { ...rest };
      if (rest.status && rest.status !== 'pending') updateData.respondedAt = new Date();
      await db.update(rsvpEntries).set(updateData).where(eq(rsvpEntries.id, id));
      return { success: true };
    }),

    stats: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { total: 0, confirmed: 0, declined: 0, pending: 0, maybe: 0, withPlusOne: 0, withAllergies: 0 };
      const entries = await db.select().from(rsvpEntries).where(eq(rsvpEntries.weddingId, input.weddingId));
      return {
        total: entries.length,
        confirmed: entries.filter(e => e.status === 'confirmed').length,
        declined: entries.filter(e => e.status === 'declined').length,
        pending: entries.filter(e => e.status === 'pending').length,
        maybe: entries.filter(e => e.status === 'maybe').length,
        withPlusOne: entries.filter(e => e.plusOne).length,
        withAllergies: entries.filter(e => {
          try { return (JSON.parse(String(e.allergies || '[]')) as string[]).length > 0; } catch { return false; }
        }).length,
      };
    }),
  }),

  // ─── PLAN B ──────────────────────────────────────────────────────────────
  planB: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(planBScenarios).where(eq(planBScenarios.weddingId, input.weddingId));
    }),

    create: protectedProcedure.input(z.object({
      weddingId: z.number(),
      name: z.string(),
      trigger: z.enum(['rain','vendor_cancel','health','transport','other']),
      description: z.string().optional(),
      actions: z.array(z.object({ actorId: z.number(), message: z.string(), newTime: z.string().optional() })).optional(),
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const result = await db.insert(planBScenarios).values({
        weddingId: input.weddingId,
        name: input.name,
        trigger: input.trigger,
        description: input.description,
        actions: input.actions ? JSON.stringify(input.actions) as unknown as Array<{ actorId: number; message: string; newTime?: string }> : undefined,
      });
      return { id: getInsertId(result) };
    }),

    activate: protectedProcedure.input(z.object({ id: z.number(), weddingId: z.number() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.update(planBScenarios).set({
        isActive: true,
        activatedAt: new Date(),
        activatedByUserId: ctx.user.id,
      }).where(eq(planBScenarios.id, input.id));
      await db.update(weddings).set({ planBActive: true }).where(eq(weddings.id, input.weddingId));
      await logProof(input.weddingId, "plan_b_activated", "Plan B activé", "cadran", { waveId: input.id });
      return { success: true };
    }),

    deactivate: protectedProcedure.input(z.object({ id: z.number(), weddingId: z.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.update(planBScenarios).set({ isActive: false }).where(eq(planBScenarios.id, input.id));
      await db.update(weddings).set({ planBActive: false }).where(eq(weddings.id, input.weddingId));
      return { success: true };
    }),
  }),

  // ─── PROOF LOG ───────────────────────────────────────────────────────────
  proofLog: router({
    list: protectedProcedure.input(z.object({ weddingId: z.number(), limit: z.number().default(50) })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(proofLog)
        .where(eq(proofLog.weddingId, input.weddingId))
        .orderBy(desc(proofLog.createdAt))
        .limit(input.limit);
    }),
  }),

  // ─── DASHBOARD ───────────────────────────────────────────────────────────
  dashboard: router({
    overview: protectedProcedure.input(z.object({ weddingId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;

      const [weddingRows, actorRows, waveRows, rsvpRows, vendorRows, budgetRows, planBRows] = await Promise.all([
        db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1),
        db.select().from(actorCards).where(eq(actorCards.weddingId, input.weddingId)),
        db.select().from(causalWaves).where(and(eq(causalWaves.weddingId, input.weddingId), eq(causalWaves.status, "pending"))).orderBy(desc(causalWaves.createdAt)).limit(5),
        db.select().from(rsvpEntries).where(eq(rsvpEntries.weddingId, input.weddingId)),
        db.select().from(vendors).where(eq(vendors.weddingId, input.weddingId)),
        db.select().from(budgetItems).where(eq(budgetItems.weddingId, input.weddingId)),
        db.select().from(planBScenarios).where(eq(planBScenarios.weddingId, input.weddingId)),
      ]);

      const wedding = weddingRows[0];
      if (!wedding) return null;

      const budgetTotal = parseFloat(String(wedding.budgetMax || 0));
      const budgetSpent = budgetRows.reduce((a, i) => a + parseFloat(String(i.actualAmount || 0)), 0);
      const rsvpConfirmed = rsvpRows.filter(r => r.status === 'confirmed').length;

      const daysUntil = wedding.weddingDate
        ? Math.ceil((new Date(wedding.weddingDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
        : null;

      return {
        wedding,
        daysUntil,
        stabilityScore: wedding.stabilityScore,
        planBActive: wedding.planBActive,
        pendingWaves: waveRows,
        stats: {
          actors: actorRows.length,
          actorsConfirmed: actorRows.filter(a => a.status === 'confirmed' || a.status === 'active').length,
          rsvpTotal: rsvpRows.length,
          rsvpConfirmed,
          vendors: vendorRows.length,
          vendorsBooked: vendorRows.filter(v => v.contractStatus === 'signed').length,
          budgetTotal,
          budgetSpent,
          budgetPercent: budgetTotal > 0 ? Math.round((budgetSpent / budgetTotal) * 100) : 0,
          planBCount: planBRows.length,
          planBActive: planBRows.filter(p => p.isActive).length,
        },
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
