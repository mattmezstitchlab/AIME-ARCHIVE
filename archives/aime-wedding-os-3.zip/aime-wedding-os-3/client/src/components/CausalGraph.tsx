import { useCallback, useMemo } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  addEdge,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  type NodeTypes,
  Handle,
  Position,
  BackgroundVariant,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { trpc } from "@/lib/trpc";

// ─── NODE TYPE CONFIGS ────────────────────────────────────────────────────────
const NODE_TYPE_CONFIG: Record<string, { color: string; icon: string; label: string }> = {
  moment:     { color: "#6366f1", icon: "◆", label: "Moment" },
  vendor:     { color: "#f59e0b", icon: "◉", label: "Prestataire" },
  budget:     { color: "#10b981", icon: "◈", label: "Budget" },
  risk:       { color: "#ef4444", icon: "⚠", label: "Risque" },
  constraint: { color: "#8b5cf6", icon: "⬡", label: "Contrainte" },
  signal:     { color: "#06b6d4", icon: "◎", label: "Signal" },
  actor:      { color: "#ec4899", icon: "◑", label: "Acteur" },
  rsvp:       { color: "#84cc16", icon: "◐", label: "RSVP" },
  document:   { color: "#64748b", icon: "▣", label: "Document" },
  dependency: { color: "#f97316", icon: "⟳", label: "Dépendance" },
};

const STATUS_COLORS: Record<string, string> = {
  stable:   "#10b981",
  warning:  "#f59e0b",
  critical: "#ef4444",
  resolved: "#6366f1",
};

// ─── CUSTOM NODE ─────────────────────────────────────────────────────────────
function CausalNode({ data }: { data: {
  label: string;
  type: string;
  status: string;
  waveCount?: number;
} }) {
  const config = NODE_TYPE_CONFIG[data.type] || NODE_TYPE_CONFIG.moment;
  const statusColor = STATUS_COLORS[data.status] || "#6366f1";

  return (
    <div
      style={{
        background: "rgba(10, 10, 30, 0.85)",
        backdropFilter: "blur(20px)",
        border: `1.5px solid ${statusColor}40`,
        borderRadius: "14px",
        padding: "10px 14px",
        minWidth: "130px",
        maxWidth: "180px",
        boxShadow: `0 0 18px ${statusColor}30, 0 4px 20px rgba(0,0,0,0.5)`,
        position: "relative",
        transition: "all 0.2s ease",
      }}
    >
      <Handle type="target" position={Position.Top} style={{ background: statusColor, border: "none", width: 8, height: 8 }} />

      {/* Status indicator */}
      <div style={{
        position: "absolute",
        top: -4,
        right: -4,
        width: 10,
        height: 10,
        borderRadius: "50%",
        background: statusColor,
        boxShadow: `0 0 8px ${statusColor}`,
      }} />

      {/* Icon + type */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
        <span style={{ color: config.color, fontSize: 14, fontWeight: 700 }}>{config.icon}</span>
        <span style={{ color: `${config.color}99`, fontSize: 9, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          {config.label}
        </span>
      </div>

      {/* Label */}
      <div style={{ color: "#e2e8f0", fontSize: 11, fontWeight: 600, lineHeight: 1.3, wordBreak: "break-word" }}>
        {data.label}
      </div>

      {/* Wave badge */}
      {data.waveCount && data.waveCount > 0 ? (
        <div style={{
          marginTop: 6,
          display: "inline-flex",
          alignItems: "center",
          gap: 3,
          background: `${statusColor}20`,
          border: `1px solid ${statusColor}40`,
          borderRadius: 6,
          padding: "2px 6px",
        }}>
          <span style={{ color: statusColor, fontSize: 9, fontWeight: 700 }}>
            {data.waveCount} onde{data.waveCount > 1 ? "s" : ""}
          </span>
        </div>
      ) : null}

      <Handle type="source" position={Position.Bottom} style={{ background: statusColor, border: "none", width: 8, height: 8 }} />
    </div>
  );
}

const nodeTypes: NodeTypes = { causal: CausalNode };

// ─── EDGE STYLES ─────────────────────────────────────────────────────────────
const edgeDefaults = {
  style: { stroke: "rgba(99,102,241,0.4)", strokeWidth: 1.5 },
  animated: true,
};

// ─── MAIN COMPONENT ──────────────────────────────────────────────────────────
interface CausalGraphProps {
  weddingId: number;
}

export default function CausalGraph({ weddingId }: CausalGraphProps) {
  const { data: rawNodes = [] } = trpc.causalNodes.list.useQuery({ weddingId });
  const { data: waves = [] } = trpc.causalWaves.list.useQuery({ weddingId, limit: 50 });

  // Build wave count per node
  const waveCountByNode = useMemo(() => {
    const counts: Record<number, number> = {};
    for (const wave of waves) {
      if (wave.sourceNodeId) {
        counts[wave.sourceNodeId] = (counts[wave.sourceNodeId] || 0) + 1;
      }
      // Also count impacted nodes
      try {
        const impacted = JSON.parse(wave.impactedNodeIds as unknown as string || "[]") as number[];
        for (const nid of impacted) {
          counts[nid] = (counts[nid] || 0) + 1;
        }
      } catch { /* ignore */ }
    }
    return counts;
  }, [waves]);

  // Convert DB nodes to ReactFlow nodes
  const initialNodes: Node[] = useMemo(() => {
    if (!rawNodes.length) return [];
    return rawNodes.map((n, i) => ({
      id: String(n.id),
      type: "causal",
      position: {
        x: Number(n.posX ?? (200 + (i % 4) * 220)),
        y: Number(n.posY ?? (100 + Math.floor(i / 4) * 160)),
      },
      data: {
        label: n.label,
        type: n.type,
        status: n.status || "stable",
        waveCount: waveCountByNode[n.id] || 0,
      },
    }));
  }, [rawNodes, waveCountByNode]);

  // Build edges from wave relationships
  const initialEdges: Edge[] = useMemo(() => {
    const edges: Edge[] = [];
    const seen = new Set<string>();

    for (const wave of waves) {
      if (!wave.sourceNodeId) continue;
      try {
        const impacted = JSON.parse(wave.impactedNodeIds as unknown as string || "[]") as number[];
        for (const targetId of impacted) {
          const edgeId = `${wave.sourceNodeId}-${targetId}`;
          if (seen.has(edgeId)) continue;
          seen.add(edgeId);

          const severityColor = wave.severity === "critical" ? "#ef4444"
            : wave.severity === "warning" ? "#f59e0b"
            : "#6366f1";

          edges.push({
            id: edgeId,
            source: String(wave.sourceNodeId),
            target: String(targetId),
            ...edgeDefaults,
            style: { stroke: severityColor + "60", strokeWidth: wave.severity === "critical" ? 2 : 1.5 },
            label: wave.severity === "critical" ? "⚠ critique" : undefined,
            labelStyle: { fill: "#ef4444", fontSize: 9, fontWeight: 700 },
            labelBgStyle: { fill: "rgba(10,10,30,0.8)" },
          });
        }
      } catch { /* ignore */ }
    }
    return edges;
  }, [waves]);

  const [nodes, , onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Parameters<typeof addEdge>[0]) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  if (!rawNodes.length) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
        <div style={{ fontSize: 48, opacity: 0.3 }}>◈</div>
        <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 14 }}>
          Aucun nœud causal trouvé.<br />
          Créez des nœuds via le Cadran Causal.
        </p>
      </div>
    );
  }

  return (
    <div style={{ width: "100%", height: "100%", background: "transparent" }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.3}
        maxZoom={2}
        defaultEdgeOptions={edgeDefaults}
        proOptions={{ hideAttribution: true }}
      >
        <Background
          variant={BackgroundVariant.Dots}
          gap={24}
          size={1}
          color="rgba(99,102,241,0.15)"
        />
        <Controls
          style={{
            background: "rgba(10,10,30,0.8)",
            border: "1px solid rgba(99,102,241,0.3)",
            borderRadius: 10,
          }}
        />
        <MiniMap
          style={{
            background: "rgba(10,10,30,0.8)",
            border: "1px solid rgba(99,102,241,0.3)",
            borderRadius: 10,
          }}
          nodeColor={(n) => {
            const status = (n.data as { status?: string }).status || "stable";
            return STATUS_COLORS[status] || "#6366f1";
          }}
          maskColor="rgba(0,0,0,0.5)"
        />
      </ReactFlow>

      {/* Legend */}
      <div style={{
        position: "absolute",
        top: 12,
        right: 12,
        background: "rgba(10,10,30,0.85)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(99,102,241,0.3)",
        borderRadius: 12,
        padding: "10px 14px",
        zIndex: 10,
      }}>
        <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 9, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}>
          Statut
        </div>
        {Object.entries(STATUS_COLORS).map(([status, color]) => (
          <div key={status} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: color, boxShadow: `0 0 6px ${color}` }} />
            <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 10, textTransform: "capitalize" }}>{status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
