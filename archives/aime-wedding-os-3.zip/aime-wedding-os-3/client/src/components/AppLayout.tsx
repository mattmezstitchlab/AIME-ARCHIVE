import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  LayoutDashboard, MessageCircle, Compass, Wallet, Users,
  ClipboardList, ShieldAlert, ScrollText, UserCircle2, LogOut,
  Menu, X, AlertTriangle
} from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

const NAV_ITEMS = [
  { path: "", label: "Tableau de bord", icon: LayoutDashboard },
  { path: "/chat", label: "Bureau Chat", icon: MessageCircle },
  { path: "/cadran", label: "Cadran Causal", icon: Compass },
  { path: "/acteurs", label: "Cartes Uniques", icon: UserCircle2 },
  { path: "/budget", label: "Budget", icon: Wallet },
  { path: "/prestataires", label: "Prestataires", icon: Users },
  { path: "/rsvp", label: "RSVP", icon: ClipboardList },
  { path: "/planb", label: "Plan B", icon: ShieldAlert },
  { path: "/journal", label: "Journal de preuve", icon: ScrollText },
];

interface AppLayoutProps {
  children: React.ReactNode;
  weddingId: number;
}

export default function AppLayout({ children, weddingId }: AppLayoutProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const { data: wedding } = trpc.weddings.get.useQuery({ id: weddingId });
  const { data: overview } = trpc.dashboard.overview.useQuery({ weddingId });

  const pendingWaves = overview?.pendingWaves?.length ?? 0;
  const planBActive = overview?.planBActive ?? false;

  return (
    <div className="flex h-screen overflow-hidden bg-background relative">
      {/* Ambient orbs */}
      <div className="ambient-orb orb-1" />
      <div className="ambient-orb orb-2" />
      <div className="ambient-orb orb-3" />

      {/* Overlay mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/60 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:relative z-30 flex flex-col h-full transition-all duration-300 ease-out
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        w-64 glass-strong
      `}>
        {/* Logo */}
        <div className="flex items-center justify-between px-5 py-5 border-b border-border">
          <Link href="/">
            <div className="flex items-center gap-2.5 cursor-pointer">
              <div className="w-8 h-8 rounded-xl gradient-accent flex items-center justify-center">
                <span className="text-white font-bold text-sm">A</span>
              </div>
              <div>
                <div className="text-foreground font-semibold text-sm leading-none">AIME&reg;</div>
                <div className="text-muted-foreground text-xs mt-0.5">Wedding OS</div>
              </div>
            </div>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-muted-foreground hover:text-foreground transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Wedding info */}
        {wedding && (
          <div className="px-4 py-3 mx-3 mt-3 rounded-xl glass-subtle">
            <div className="text-primary text-xs font-semibold uppercase tracking-wider mb-1">Mariage actif</div>
            <div className="text-foreground text-sm font-medium truncate">{wedding.name}</div>
            {wedding.weddingDate && (
              <div className="text-muted-foreground text-xs mt-0.5">
                {new Date(wedding.weddingDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
              </div>
            )}
            {/* Stability score */}
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${wedding.stabilityScore ?? 100}%`,
                    background: (wedding.stabilityScore ?? 100) > 70
                      ? 'oklch(0.68 0.14 145)'
                      : (wedding.stabilityScore ?? 100) > 40
                        ? 'oklch(0.78 0.14 75)'
                        : 'oklch(0.62 0.20 25)'
                  }}
                />
              </div>
              <span className="text-xs text-muted-foreground">{wedding.stabilityScore ?? 100}%</span>
            </div>
            {planBActive && (
              <div className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-orange-400">
                <AlertTriangle size={12} /> Plan B actif
              </div>
            )}
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(({ path, label, icon: Icon }) => {
            const href = `/w/${weddingId}${path}`;
            const isActive = location === href;
            const hasBadge = path === "/cadran" && pendingWaves > 0;
            const isPlanB = path === "/planb" && planBActive;

            return (
              <Link key={path} href={href}>
                <div
                  className={`
                    flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium cursor-pointer
                    transition-all duration-200
                    ${isActive ? "glass-subtle text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-white/5"}
                    ${isPlanB ? "text-orange-400" : ""}
                  `}
                  onClick={() => setSidebarOpen(false)}
                >
                  <Icon size={16} className={`shrink-0 ${isActive ? "text-primary" : ""}`} />
                  <span className="flex-1">{label}</span>
                  {hasBadge && (
                    <span className="ml-auto w-5 h-5 rounded-full bg-destructive text-white text-xs flex items-center justify-center font-bold animate-glow-pulse">
                      {pendingWaves}
                    </span>
                  )}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User */}
        <div className="px-3 py-3 border-t border-border">
          {user ? (
            <div className="flex items-center gap-3 px-3 py-2">
              <div className="w-8 h-8 rounded-full gradient-accent flex items-center justify-center text-white text-sm font-semibold shrink-0">
                {(user.name || user.email || "U")[0].toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-foreground truncate">{user.name || user.email}</div>
                <div className="text-xs text-muted-foreground">Organisateur</div>
              </div>
              <button onClick={logout} className="text-muted-foreground hover:text-foreground transition-colors" title="Déconnexion">
                <LogOut size={15} />
              </button>
            </div>
          ) : (
            <button onClick={() => startLogin()} className="btn-vision-primary w-full text-sm">Se connecter</button>
          )}
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border glass-subtle">
          <button onClick={() => setSidebarOpen(true)} className="text-muted-foreground hover:text-foreground transition-colors">
            <Menu size={20} />
          </button>
          <div className="text-foreground font-semibold text-sm">AIME&reg; Wedding OS</div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
