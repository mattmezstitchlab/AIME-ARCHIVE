import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import RSVPPublic from "./pages/RSVPPublic";
import Onboarding from "./pages/Onboarding";
import Dashboard from "./pages/Dashboard";
import BureauChat from "./pages/BureauChat";
import CadranCausal from "./pages/CadranCausal";
import Budget from "./pages/Budget";
import Prestataires from "./pages/Prestataires";
import RSVP from "./pages/RSVP";
import PlanB from "./pages/PlanB";
import JournalPreuve from "./pages/JournalPreuve";
import CartesUniques from "./pages/CartesUniques";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/rsvp/:token"} component={RSVPPublic} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/w/:weddingId" component={Dashboard} />
      <Route path="/w/:weddingId/chat" component={BureauChat} />
      <Route path="/w/:weddingId/cadran" component={CadranCausal} />
      <Route path="/w/:weddingId/budget" component={Budget} />
      <Route path="/w/:weddingId/prestataires" component={Prestataires} />
      <Route path="/w/:weddingId/rsvp" component={RSVP} />
      <Route path="/w/:weddingId/planb" component={PlanB} />
      <Route path="/w/:weddingId/journal" component={JournalPreuve} />
      <Route path="/w/:weddingId/acteurs" component={CartesUniques} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
