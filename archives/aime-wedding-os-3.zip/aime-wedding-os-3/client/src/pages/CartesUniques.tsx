import { useState } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Plus, UserCircle2, Trash2, CheckCircle2, X } from "lucide-react";
import { toast } from "sonner";

const ROLE_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  bride: { label: "Mariée", color: "text-pink-400", bg: "bg-pink-400/10 border-pink-400/30" },
  groom: { label: "Marié", color: "text-blue-400", bg: "bg-blue-400/10 border-blue-400/30" },
  witness: { label: "Témoin", color: "text-purple-400", bg: "bg-purple-400/10 border-purple-400/30" },
  photographer: { label: "Photographe", color: "text-yellow-400", bg: "bg-yellow-400/10 border-yellow-400/30" },
  caterer: { label: "Traiteur", color: "text-orange-400", bg: "bg-orange-400/10 border-orange-400/30" },
  dj: { label: "DJ / Musique", color: "text-green-400", bg: "bg-green-400/10 border-green-400/30" },
  officiant: { label: "Officiant", color: "text-primary", bg: "bg-primary/10 border-primary/30" },
  family: { label: "Famille", color: "text-blue-400", bg: "bg-blue-400/10 border-blue-400/30" },
  planner: { label: "Wedding Planner", color: "text-green-400", bg: "bg-green-400/10 border-green-400/30" },
  couple: { label: "Couple", color: "text-pink-400", bg: "bg-pink-400/10 border-pink-400/30" },
  parent: { label: "Parent", color: "text-orange-400", bg: "bg-orange-400/10 border-orange-400/30" },
  guest: { label: "Invité", color: "text-muted-foreground", bg: "bg-muted/50 border-border" },
  vendor: { label: "Prestataire", color: "text-yellow-400", bg: "bg-yellow-400/10 border-yellow-400/30" },
  venue: { label: "Lieu", color: "text-blue-400", bg: "bg-blue-400/10 border-blue-400/30" },
  dj_musician: { label: "DJ / Musicien", color: "text-green-400", bg: "bg-green-400/10 border-green-400/30" },
  logistics: { label: "Logistique", color: "text-orange-400", bg: "bg-orange-400/10 border-orange-400/30" },
  security: { label: "Sécurité", color: "text-red-400", bg: "bg-red-400/10 border-red-400/30" },
  other: { label: "Autre", color: "text-muted-foreground", bg: "bg-muted/50 border-border" },
};

const STATUS_LABELS: Record<string, string> = { invited: "Invité", confirmed: "Confirmé", active: "Actif", unavailable: "Indisponible" };

export default function CartesUniques() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [selectedActor, setSelectedActor] = useState<number | null>(null);
  type ActorRole = "couple" | "witness" | "parent" | "guest" | "vendor" | "venue" | "photographer" | "dj_musician" | "caterer" | "officiant" | "logistics" | "planner" | "security" | "other";
  const [form, setForm] = useState({ name: "", role: "witness" as ActorRole, email: "", phone: "" });

  const utils = trpc.useUtils();
  const { data: actors = [] } = trpc.actorCards.list.useQuery({ weddingId }, { enabled: isAuthenticated && weddingId > 0 });
  const create = trpc.actorCards.create.useMutation({ onSuccess: () => { utils.actorCards.list.invalidate({ weddingId }); setShowForm(false); setForm({ name: "", role: "witness", email: "", phone: "" }); toast.success("Carte Unique créée"); } });
  const update = trpc.actorCards.update.useMutation({ onSuccess: () => utils.actorCards.list.invalidate({ weddingId }) });
  const del = trpc.actorCards.delete.useMutation({ onSuccess: () => { utils.actorCards.list.invalidate({ weddingId }); setSelectedActor(null); toast.success("Acteur supprimé"); } });

  if (!isAuthenticated) return <div className="min-h-screen bg-background flex items-center justify-center"><button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button></div>;

  const selectedActorData = actors.find((a: any) => a.id === selectedActor);

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Cartes Uniques</h1>
            <p className="text-muted-foreground text-sm mt-1">Chaque acteur voit uniquement ce qui le concerne</p>
          </div>
          <button onClick={() => setShowForm(!showForm)} className="btn-vision-primary flex items-center gap-2 text-sm"><Plus size={16} />Ajouter un acteur</button>
        </div>

        {/* Form */}
        {showForm && (
          <div className="glass-strong rounded-2xl p-5 animate-float-in">
            <h3 className="text-foreground font-semibold mb-4">Nouvelle Carte Unique</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <input className="input-vision text-sm" placeholder="Nom de l'acteur" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              <select className="input-vision text-sm" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value as ActorRole }))}>
                {Object.entries(ROLE_CONFIG).map(([v, { label }]) => <option key={v} value={v}>{label}</option>)}
              </select>
              <input className="input-vision text-sm" placeholder="Email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Téléphone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              <button onClick={() => create.mutate({ weddingId, name: form.name, role: form.role, email: form.email || undefined, phone: form.phone || undefined })} disabled={!form.name || create.isPending} className="btn-vision-primary text-sm disabled:opacity-50">Créer la Carte Unique</button>
              <button onClick={() => setShowForm(false)} className="btn-vision-ghost text-sm">Annuler</button>
            </div>
          </div>
        )}

        <div className="flex gap-6">
          {/* Grid */}
          <div className="flex-1 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {actors.length === 0 ? (
              <div className="col-span-full text-center py-16">
                <UserCircle2 size={48} className="mx-auto mb-4 text-muted-foreground opacity-30" />
                <p className="text-muted-foreground font-medium">Aucun acteur</p>
                <p className="text-muted-foreground text-xs mt-1">Créez les Cartes Uniques de chaque participant</p>
              </div>
            ) : actors.map((actor: any) => {
              const roleConf = ROLE_CONFIG[actor.role] || ROLE_CONFIG.other;
              const isSelected = selectedActor === actor.id;
              return (
                <div key={actor.id} onClick={() => setSelectedActor(isSelected ? null : actor.id)} className={`glass-card p-4 text-center cursor-pointer transition-all duration-200 hover:bg-white/5 ${isSelected ? "glow-primary border-primary/40" : ""}`}>
                  <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center mb-3 mx-auto ${roleConf.bg}`}>
                    <span className={`text-lg font-bold ${roleConf.color}`}>{(actor.name?.[0] || "?").toUpperCase()}</span>
                  </div>
                  <div className="text-foreground text-sm font-semibold truncate mb-1">{actor.name}</div>
                  <div className={`text-xs font-medium ${roleConf.color}`}>{roleConf.label}</div>
                  <div className="mt-2 flex items-center justify-center gap-1.5">
                    <div className={`w-1.5 h-1.5 rounded-full ${actor.status === 'active' || actor.status === 'confirmed' ? 'bg-green-400' : 'bg-yellow-400'}`} />
                    <span className="text-xs text-muted-foreground">{STATUS_LABELS[actor.status || "invited"]}</span>
                  </div>
                  {actor.inviteToken && <div className="mt-2 text-center text-xs text-muted-foreground/60 font-mono">{actor.inviteToken.slice(0, 8).toUpperCase()}</div>}
                </div>
              );
            })}
          </div>

          {/* Detail panel */}
          {selectedActorData && (
            <div className="w-72 shrink-0 glass-strong p-5 rounded-2xl h-fit sticky top-6 animate-float-in">
              <div className="flex items-center justify-between mb-4">
                <div className="text-primary text-xs font-semibold uppercase tracking-wider">Carte Unique</div>
                <button onClick={() => setSelectedActor(null)} className="text-muted-foreground hover:text-foreground transition-colors"><X size={16} /></button>
              </div>
              {(() => {
                const roleConf = ROLE_CONFIG[selectedActorData.role] || ROLE_CONFIG.other;
                return (
                  <>
                    <div className={`w-16 h-16 rounded-full border-2 flex items-center justify-center mb-3 mx-auto ${roleConf.bg}`}>
                      <span className={`text-2xl font-bold ${roleConf.color}`}>{(selectedActorData.name?.[0] || "?").toUpperCase()}</span>
                    </div>
                    <div className="text-foreground text-lg font-semibold text-center mb-1">{selectedActorData.name}</div>
                    <div className={`text-sm text-center font-medium mb-4 ${roleConf.color}`}>{roleConf.label}</div>
                  </>
                );
              })()}
              <div className="space-y-2 mb-4">
                {selectedActorData.email && <div className="flex items-center gap-2 text-xs"><span className="text-muted-foreground w-16 shrink-0">Email</span><span className="text-foreground/80 truncate">{selectedActorData.email}</span></div>}
                {selectedActorData.phone && <div className="flex items-center gap-2 text-xs"><span className="text-muted-foreground w-16 shrink-0">Tél.</span><span className="text-foreground/80">{selectedActorData.phone}</span></div>}
                {selectedActorData.inviteToken && <div className="flex items-center gap-2 text-xs"><span className="text-muted-foreground w-16 shrink-0">Token</span><span className="text-primary font-mono">{selectedActorData.inviteToken.slice(0, 8).toUpperCase()}</span></div>}
              </div>
              <div className="mb-4">
                <div className="text-xs text-muted-foreground mb-2">Statut</div>
                <select className="input-vision text-xs w-full" value={selectedActorData.status || "invited"} onChange={e => update.mutate({ id: selectedActorData.id, status: e.target.value as any })}>
                  {Object.entries(STATUS_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              </div>
              {selectedActorData.responsibilities && (() => {
                try {
                  const resp = JSON.parse(String(selectedActorData.responsibilities)) as string[];
                  return resp.length > 0 ? (
                    <div className="mb-4">
                      <div className="text-xs text-muted-foreground mb-2">Responsabilités</div>
                      <div className="space-y-1">
                        {resp.map((r, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-foreground/70">
                            <CheckCircle2 size={11} className="text-green-400 shrink-0 mt-0.5" /><span>{r}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : null;
                } catch { return null; }
              })()}
              <button onClick={() => del.mutate({ id: selectedActorData.id })} className="w-full flex items-center justify-center gap-2 text-xs text-red-400 hover:bg-red-400/10 transition-all py-2 rounded-xl border border-red-400/20">
                <Trash2 size={13} /> Supprimer cet acteur
              </button>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
