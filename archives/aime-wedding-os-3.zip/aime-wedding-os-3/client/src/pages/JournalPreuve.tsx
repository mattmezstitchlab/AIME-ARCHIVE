import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { ScrollText, MessageCircle, Compass, User, Bot, Zap, Cloud, Download } from "lucide-react";

const SOURCE_CONFIG: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  chat: { label: "Chat Ripple", icon: MessageCircle, color: "text-blue-400" },
  cadran: { label: "Cadran Causal", icon: Compass, color: "text-primary" },
  agent: { label: "Agent", icon: Bot, color: "text-green-400" },
  system: { label: "Système", icon: Zap, color: "text-muted-foreground" },
  user: { label: "Utilisateur", icon: User, color: "text-foreground" },
  vendor: { label: "Prestataire", icon: User, color: "text-yellow-400" },
  rsvp: { label: "RSVP", icon: User, color: "text-green-400" },
  weather: { label: "Météo", icon: Cloud, color: "text-blue-400" },
};

const EVENT_LABELS: Record<string, string> = {
  wedding_created: "Mariage créé",
  message_sent: "Message envoyé",
  wave_created: "Onde causale créée",
  wave_validated: "Onde validée",
  wave_rejected: "Onde rejetée",
  budget_added: "Poste budgétaire ajouté",
  vendor_added: "Prestataire ajouté",
  rsvp_added: "Invité ajouté",
  plan_b_activated: "Plan B activé",
  actor_added: "Acteur ajouté",
};

export default function JournalPreuve() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();

  const { data: entries = [], isLoading } = trpc.proofLog.list.useQuery(
    { weddingId, limit: 100 },
    { enabled: isAuthenticated && weddingId > 0, refetchInterval: 30000 }
  );

  if (!isAuthenticated) return <div className="min-h-screen bg-background flex items-center justify-center"><button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button></div>;

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground mb-1">Journal de preuve rejouable</h1>
            <p className="text-muted-foreground text-sm">Enregistrement immuable de chaque onde causale — {entries.length} entrées</p>
          </div>
          <a
            href={`/api/journal/${weddingId}/export-pdf`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-vision-primary flex items-center gap-2 text-sm px-4 py-2 shrink-0"
          >
            <Download size={15} />
            Exporter PDF
          </a>
        </div>

        {/* Legend */}
        <div className="glass-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Sources</div>
          <div className="flex flex-wrap gap-3">
            {Object.entries(SOURCE_CONFIG).map(([key, { label, icon: Icon, color }]) => (
              <div key={key} className={`flex items-center gap-1.5 text-xs ${color}`}>
                <Icon size={12} /><span>{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline */}
        {isLoading ? (
          <div className="text-muted-foreground text-center py-12">Chargement du journal...</div>
        ) : entries.length === 0 ? (
          <div className="text-center py-16">
            <ScrollText size={48} className="mx-auto mb-4 text-muted-foreground opacity-30" />
            <p className="text-muted-foreground font-medium">Journal vide</p>
            <p className="text-muted-foreground text-xs mt-1">Les événements causaux seront enregistrés ici</p>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute left-5 top-0 bottom-0 w-px bg-border" />
            <div className="space-y-4">
              {entries.map((entry: any) => {
                const src = SOURCE_CONFIG[entry.source] || SOURCE_CONFIG.system;
                const SrcIcon = src.icon;
                const label = EVENT_LABELS[entry.eventType] || entry.eventType;
                return (
                  <div key={entry.id} className="relative flex gap-4 pl-12">
                    <div className={`absolute left-3.5 top-3 w-3 h-3 rounded-full border-2 border-background ${
                      entry.source === "cadran" ? "bg-primary" : entry.source === "chat" ? "bg-blue-400" : entry.source === "agent" ? "bg-green-400" : "bg-muted"
                    }`} />
                    <div className="flex-1 glass-card p-4">
                      <div className="flex items-start justify-between gap-3 flex-wrap mb-2">
                        <div className="flex items-center gap-2">
                          <SrcIcon size={13} className={src.color} />
                          <span className={`text-xs font-semibold ${src.color}`}>{src.label}</span>
                          <span className="text-xs text-muted-foreground">·</span>
                          <span className="text-xs text-foreground/80 font-medium">{label}</span>
                        </div>
                        <span className="text-xs text-muted-foreground shrink-0">
                          {new Date(entry.createdAt).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-foreground/80 text-sm leading-relaxed">{String(entry.description)}</p>
                      {typeof entry.waveId === 'number' && (
                        <div className="mt-2 flex items-center gap-1.5 text-xs text-yellow-400">
                          <Zap size={11} /><span>Onde #{entry.waveId}</span>
                        </div>
                      )}
                      {(entry.snapshotBefore != null || entry.snapshotAfter != null) && (
                        <div className="mt-3 grid grid-cols-2 gap-2">
                          {entry.snapshotBefore != null && (
                            <div className="p-2 rounded-lg glass-subtle">
                              <div className="text-xs text-muted-foreground mb-1">Avant</div>
                              <pre className="text-xs text-foreground/60 overflow-hidden text-ellipsis whitespace-nowrap">{JSON.stringify(entry.snapshotBefore ?? {}).slice(0, 80)}</pre>
                            </div>
                          )}
                          {entry.snapshotAfter != null && (
                            <div className="p-2 rounded-lg glass-subtle">
                              <div className="text-xs text-muted-foreground mb-1">Après</div>
                              <pre className="text-xs text-foreground/60 overflow-hidden text-ellipsis whitespace-nowrap">{JSON.stringify(entry.snapshotAfter ?? {}).slice(0, 80)}</pre>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
