import { useState } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Plus, ClipboardList, Trash2, Link2, ExternalLink } from "lucide-react";
import { toast } from "sonner";

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  pending: { label: "En attente", color: "text-yellow-400" },
  confirmed: { label: "Confirmé", color: "text-green-400" },
  declined: { label: "Décliné", color: "text-red-400" },
  maybe: { label: "Peut-être", color: "text-muted-foreground" },
};

export default function RSVP() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ guestName: "", email: "", tableNumber: "", dietaryRestrictions: "" });
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const utils = trpc.useUtils();
  const { data: guests = [] } = trpc.rsvp.list.useQuery({ weddingId }, { enabled: isAuthenticated && weddingId > 0 });
  const create = trpc.rsvp.create.useMutation({
    onSuccess: () => { utils.rsvp.list.invalidate({ weddingId }); setShowForm(false); setForm({ guestName: "", email: "", tableNumber: "", dietaryRestrictions: "" }); toast.success("Invité ajouté"); },
    onError: () => toast.error("Erreur lors de l'ajout"),
  });
  const update = trpc.rsvp.update.useMutation({ onSuccess: () => utils.rsvp.list.invalidate({ weddingId }) });

  if (!isAuthenticated) return <div className="min-h-screen bg-background flex items-center justify-center"><button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button></div>;

  const filtered = filterStatus === "all" ? guests : guests.filter((g: any) => (g.status || "pending") === filterStatus);
  const confirmed = guests.filter((g: any) => g.status === "confirmed").length;
  const declined = guests.filter((g: any) => g.status === "declined").length;
  const pending = guests.filter((g: any) => !g.status || g.status === "pending").length;

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">RSVP & Invités</h1>
            <p className="text-muted-foreground text-sm mt-1">Les confirmations alimentent le graphe causal</p>
          </div>
          <button onClick={() => setShowForm(!showForm)} className="btn-vision-primary flex items-center gap-2 text-sm"><Plus size={16} />Ajouter un invité</button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Total", value: guests.length, color: "text-foreground" },
            { label: "Confirmés", value: confirmed, color: "text-green-400" },
            { label: "Déclinés", value: declined, color: "text-red-400" },
            { label: "En attente", value: pending, color: "text-yellow-400" },
          ].map(({ label, value, color }) => (
            <div key={label} className="glass-card p-4 text-center">
              <div className={`text-3xl font-bold ${color}`}>{value}</div>
              <div className="text-xs text-muted-foreground mt-1">{label}</div>
            </div>
          ))}
        </div>

        {/* Form */}
        {showForm && (
          <div className="glass-strong rounded-2xl p-5 animate-float-in">
            <h3 className="text-foreground font-semibold mb-4">Nouvel invité</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <input className="input-vision text-sm" placeholder="Nom complet" value={form.guestName} onChange={e => setForm(f => ({ ...f, guestName: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
              <input type="number" className="input-vision text-sm" placeholder="Numéro de table" value={form.tableNumber} onChange={e => setForm(f => ({ ...f, tableNumber: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Régime alimentaire / allergies..." value={form.dietaryRestrictions} onChange={e => setForm(f => ({ ...f, dietaryRestrictions: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              <button onClick={() => create.mutate({ weddingId, guestName: form.guestName, email: form.email || undefined, tableNumber: form.tableNumber ? parseInt(form.tableNumber) : undefined, dietaryRestrictions: form.dietaryRestrictions || undefined })} disabled={!form.guestName || create.isPending} className="btn-vision-primary text-sm disabled:opacity-50">Ajouter</button>
              <button onClick={() => setShowForm(false)} className="btn-vision-ghost text-sm">Annuler</button>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          {["all", "pending", "confirmed", "declined", "maybe"].map(s => (
            <button key={s} onClick={() => setFilterStatus(s)} className={`rounded-full px-4 py-1.5 text-xs font-medium transition-all ${filterStatus === s ? "glass-strong text-foreground glow-primary" : "glass-subtle text-muted-foreground hover:text-foreground"}`}>
              {s === "all" ? "Tous" : STATUS_CONFIG[s]?.label || s}
            </button>
          ))}
        </div>

        {/* List */}
        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="text-center py-12"><ClipboardList size={40} className="mx-auto mb-4 text-muted-foreground opacity-30" /><p className="text-muted-foreground">Aucun invité</p></div>
          ) : filtered.map((guest: any) => (
            <div key={guest.id} className="glass-card p-4 flex items-center gap-4 flex-wrap">
              <div className="w-9 h-9 rounded-full gradient-accent flex items-center justify-center text-white font-semibold text-sm shrink-0">
                {(guest.guestName?.[0] || "?").toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-foreground font-medium">{guest.guestName}</div>
                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                  {guest.email && <span className="text-muted-foreground text-xs">{guest.email}</span>}
                  {guest.tableNumber && <span className="text-xs px-2 py-0.5 rounded-full glass-subtle text-muted-foreground">Table {guest.tableNumber}</span>}
                  {guest.dietaryRestrictions && <span className="text-xs text-yellow-400">{guest.dietaryRestrictions}</span>}
                  {guest.plusOne && <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">+1</span>}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {guest.inviteToken && (
                  <>
                    <button
                      title="Copier le lien d'invitation"
                      onClick={() => {
                        const url = `${window.location.origin}/rsvp/${guest.inviteToken}`;
                        navigator.clipboard.writeText(url).then(() => toast.success("Lien copié !")).catch(() => toast.error("Impossible de copier"));
                      }}
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      <Link2 size={15} />
                    </button>
                    <a
                      href={`/rsvp/${guest.inviteToken}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="Ouvrir la page RSVP"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      <ExternalLink size={15} />
                    </a>
                  </>
                )}
                <select className="text-xs glass-subtle border border-border rounded-lg px-2 py-1 text-muted-foreground focus:border-primary outline-none" value={guest.status || "pending"} onChange={e => update.mutate({ id: guest.id, status: e.target.value as any })}>
                  {Object.entries(STATUS_CONFIG).map(([v, { label }]) => <option key={v} value={v}>{label}</option>)}
                </select>
                <button onClick={() => update.mutate({ id: guest.id, status: 'declined' })} title="Marquer comme décliné" className="text-muted-foreground hover:text-red-400 transition-colors"><Trash2 size={15} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
