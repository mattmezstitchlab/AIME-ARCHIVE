import { useState } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Plus, ShieldAlert, Play, Square, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

const TRIGGER_LABELS: Record<string, string> = { rain: "Pluie / Météo", vendor_cancel: "Annulation prestataire", health: "Santé", transport: "Transport", other: "Autre" };

export default function PlanB() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", trigger: "rain" as "rain" | "vendor_cancel" | "health" | "transport" | "other", actionsText: "" });

  const utils = trpc.useUtils();
  const { data: scenarios = [] } = trpc.planB.list.useQuery({ weddingId }, { enabled: isAuthenticated && weddingId > 0 });
  const create = trpc.planB.create.useMutation({ onSuccess: () => { utils.planB.list.invalidate({ weddingId }); setShowForm(false); setForm({ name: "", description: "", trigger: "rain", actionsText: "" }); toast.success("Scénario Plan B créé"); } });
  const activate = trpc.planB.activate.useMutation({ onSuccess: () => { utils.planB.list.invalidate({ weddingId }); utils.dashboard.overview.invalidate({ weddingId }); toast.warning("Plan B activé — onde causale propagée"); } });
  const deactivate = trpc.planB.deactivate.useMutation({ onSuccess: () => { utils.planB.list.invalidate({ weddingId }); utils.dashboard.overview.invalidate({ weddingId }); toast.success("Plan B désactivé"); } });

  if (!isAuthenticated) return <div className="min-h-screen bg-background flex items-center justify-center"><button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button></div>;

  const activeScenario = scenarios.find((s: any) => s.isActive);

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Plan B & Gestion des risques</h1>
            <p className="text-muted-foreground text-sm mt-1">Scénarios alternatifs activables en un clic</p>
          </div>
          <button onClick={() => setShowForm(!showForm)} className="btn-vision-primary flex items-center gap-2 text-sm"><Plus size={16} />Nouveau scénario</button>
        </div>

        {/* Active alert */}
        {activeScenario && (
          <div className="p-4 rounded-2xl border border-orange-500/30 bg-orange-500/5 backdrop-blur-sm flex items-start gap-3">
            <AlertTriangle size={20} className="text-orange-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="text-orange-400 font-semibold mb-1">Plan B actif : {activeScenario.name}</div>
              <p className="text-foreground/70 text-sm">{activeScenario.description}</p>
            </div>
            <button onClick={() => deactivate.mutate({ id: activeScenario.id, weddingId })} className="btn-vision-ghost text-xs border-orange-500/40 text-orange-400 hover:bg-orange-500/10">
              <Square size={12} className="mr-1 inline" />Désactiver
            </button>
          </div>
        )}

        {/* Form */}
        {showForm && (
          <div className="glass-strong rounded-2xl p-5 animate-float-in">
            <h3 className="text-foreground font-semibold mb-4">Nouveau scénario Plan B</h3>
            <div className="space-y-3 mb-3">
              <input className="input-vision text-sm" placeholder="Nom du scénario (ex: Pluie le jour J)" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              <textarea className="input-vision text-sm resize-none" rows={2} placeholder="Description du scénario..." value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              <select className="input-vision text-sm" value={form.trigger} onChange={e => setForm(f => ({ ...f, trigger: e.target.value as typeof form.trigger }))}>
                {Object.entries(TRIGGER_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
              <textarea className="input-vision text-sm resize-none" rows={3} placeholder="Actions à prendre (une par ligne)..." value={form.actionsText} onChange={e => setForm(f => ({ ...f, actionsText: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              <button onClick={() => { const actionLines = form.actionsText.split('\n').filter(Boolean); const actions = actionLines.map((msg, i) => ({ actorId: i + 1, message: msg })); create.mutate({ weddingId, name: form.name, trigger: form.trigger, description: form.description || undefined, actions: actions.length > 0 ? actions : undefined }); }} disabled={!form.name || create.isPending} className="btn-vision-primary text-sm disabled:opacity-50">Créer</button>
              <button onClick={() => setShowForm(false)} className="btn-vision-ghost text-sm">Annuler</button>
            </div>
          </div>
        )}

        {/* List */}
        <div className="space-y-4">
          {scenarios.length === 0 ? (
            <div className="text-center py-16">
              <ShieldAlert size={48} className="mx-auto mb-4 text-muted-foreground opacity-30" />
              <p className="text-muted-foreground font-medium">Aucun scénario Plan B</p>
              <p className="text-muted-foreground text-xs mt-1">Créez des scénarios de contingence pour chaque risque identifié</p>
            </div>
          ) : scenarios.map((scenario: any) => {
            const actions = (() => { try { const a = scenario.actions; if (!a) return []; if (Array.isArray(a)) return a; return JSON.parse(String(a)); } catch { return []; } })() as { actorId: number; message: string; newTime?: string }[];
            return (
              <div key={scenario.id} className={`glass-card p-5 ${scenario.isActive ? "border-orange-500/30 glow-primary" : ""}`}>
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-foreground font-semibold">{scenario.name}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full glass-subtle text-muted-foreground">{TRIGGER_LABELS[scenario.trigger || "other"]}</span>
                      {scenario.isActive && <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 font-semibold">ACTIF</span>}
                    </div>
                    {scenario.description && <p className="text-foreground/70 text-sm mb-3">{scenario.description}</p>}
                    {actions.length > 0 && (
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Actions</div>
                        {actions.map((a, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-foreground/70">
                            <span className="text-primary shrink-0">{i + 1}.</span>
                            <span>{a.message}</span>
                            {a.newTime && <span className="text-blue-400 ml-1">→ {a.newTime}</span>}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div>
                    {scenario.isActive ? (
                      <button onClick={() => deactivate.mutate({ id: scenario.id, weddingId })} className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-xl border border-orange-500/30 text-orange-400 hover:bg-orange-500/10 transition-all">
                        <Square size={12} />Désactiver
                      </button>
                    ) : (
                      <button onClick={() => activate.mutate({ id: scenario.id, weddingId })} className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-xl glass-subtle text-yellow-400 border border-yellow-500/20 hover:bg-yellow-500/10 transition-all">
                        <Play size={12} />Activer
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AppLayout>
  );
}
