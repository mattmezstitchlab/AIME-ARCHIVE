import { useState } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Plus, Trash2, TrendingUp, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = ["Lieu", "Traiteur", "Fleurs", "Photographie", "Musique", "Tenue", "Transport", "Hébergement", "Papeterie", "Divers"];
const STATUS_COLORS: Record<string, string> = { planned: "text-muted-foreground", quoted: "text-blue-400", confirmed: "text-yellow-400", paid: "text-green-400", cancelled: "text-red-400" };
const STATUS_LABELS: Record<string, string> = { planned: "Planifié", quoted: "Devis reçu", confirmed: "Confirmé", paid: "Payé", cancelled: "Annulé" };

export default function Budget() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ category: "Lieu", label: "", estimatedAmount: "", notes: "" });

  const utils = trpc.useUtils();
  const { data: items = [] } = trpc.budget.list.useQuery({ weddingId }, { enabled: isAuthenticated && weddingId > 0 });
  const { data: summary } = trpc.budget.summary.useQuery({ weddingId }, { enabled: isAuthenticated && weddingId > 0 });

  const create = trpc.budget.create.useMutation({
    onSuccess: () => { utils.budget.list.invalidate({ weddingId }); utils.budget.summary.invalidate({ weddingId }); setShowForm(false); setForm({ category: "Lieu", label: "", estimatedAmount: "", notes: "" }); toast.success("Poste budgétaire ajouté"); },
    onError: () => toast.error("Erreur lors de l'ajout"),
  });

  const update = trpc.budget.update.useMutation({
    onSuccess: () => { utils.budget.list.invalidate({ weddingId }); utils.budget.summary.invalidate({ weddingId }); },
  });

  const del = trpc.budget.delete.useMutation({
    onSuccess: () => { utils.budget.list.invalidate({ weddingId }); utils.budget.summary.invalidate({ weddingId }); toast.success("Poste supprimé"); },
  });

  if (!isAuthenticated) return <div className="min-h-screen bg-background flex items-center justify-center"><button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button></div>;

  const budgetPercent = summary?.total ? Math.round((summary.spent / summary.total) * 100) : 0;

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Budget causal</h1>
            <p className="text-muted-foreground text-sm mt-1">Chaque dépassement propage une onde dans le graphe</p>
          </div>
          <button onClick={() => setShowForm(!showForm)} className="btn-vision-primary flex items-center gap-2 text-sm"><Plus size={16} />Ajouter un poste</button>
        </div>

        {/* Summary */}
        {summary && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Budget total", value: `${summary.total.toLocaleString('fr-FR')}\u20ac`, color: "text-foreground" },
              { label: "Estimé", value: `${summary.estimated.toLocaleString('fr-FR')}\u20ac`, color: "text-blue-400" },
              { label: "Dépensé", value: `${summary.spent.toLocaleString('fr-FR')}\u20ac`, color: summary.overBudget ? "text-red-400" : "text-yellow-400" },
              { label: "Payé", value: `${summary.paid.toLocaleString('fr-FR')}\u20ac`, color: "text-green-400" },
            ].map(({ label, value, color }) => (
              <div key={label} className="glass-card p-4">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-2">{label}</div>
                <div className={`text-xl font-bold ${color}`}>{value}</div>
              </div>
            ))}
          </div>
        )}

        {/* Progress bar */}
        {summary && summary.total > 0 && (
          <div className="glass-card p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-foreground font-medium">Progression budgétaire</span>
              <span className={`text-sm font-bold ${summary.overBudget ? "text-red-400" : "text-primary"}`}>{budgetPercent}%</span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${Math.min(100, budgetPercent)}%`, background: summary.overBudget ? 'oklch(0.62 0.20 25)' : budgetPercent > 80 ? 'oklch(0.78 0.14 75)' : 'oklch(0.68 0.14 145)' }} />
            </div>
            {summary.overBudget && (
              <div className="mt-2 flex items-center gap-2 text-xs text-red-400 font-semibold">
                <AlertTriangle size={12} /> Dépassement budgétaire — onde causale générée
              </div>
            )}
          </div>
        )}

        {/* Create form */}
        {showForm && (
          <div className="glass-strong rounded-2xl p-5 animate-float-in">
            <h3 className="text-foreground font-semibold mb-4">Nouveau poste budgétaire</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <select className="input-vision text-sm" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <input className="input-vision text-sm" placeholder="Label du poste" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} />
              <input type="number" className="input-vision text-sm" placeholder="Montant estimé (\u20ac)" value={form.estimatedAmount} onChange={e => setForm(f => ({ ...f, estimatedAmount: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              <button onClick={() => create.mutate({ weddingId, category: form.category, label: form.label, estimatedAmount: parseFloat(form.estimatedAmount) || 0, notes: form.notes || undefined })} disabled={!form.label || create.isPending} className="btn-vision-primary text-sm disabled:opacity-50">Ajouter</button>
              <button onClick={() => setShowForm(false)} className="btn-vision-ghost text-sm">Annuler</button>
            </div>
          </div>
        )}

        {/* Items list */}
        <div className="space-y-2">
          {items.length === 0 ? (
            <div className="text-center py-12">
              <TrendingUp size={40} className="mx-auto mb-4 text-muted-foreground opacity-30" />
              <p className="text-muted-foreground">Aucun poste budgétaire</p>
            </div>
          ) : items.map((item: any) => (
            <div key={item.id} className="glass-card p-4 flex items-center gap-4 flex-wrap">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs px-2 py-0.5 rounded-full glass-subtle text-muted-foreground">{item.category}</span>
                  <span className={`text-xs font-semibold ${STATUS_COLORS[item.status || "planned"]}`}>{STATUS_LABELS[item.status || "planned"]}</span>
                </div>
                <div className="text-foreground text-sm font-medium">{item.label}</div>
                {item.notes && <div className="text-muted-foreground text-xs mt-0.5">{item.notes}</div>}
              </div>
              <div className="flex items-center gap-4 text-sm">
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-0.5">Estimé</div>
                  <div className="text-foreground font-medium">{parseFloat(String(item.estimatedAmount || 0)).toLocaleString('fr-FR')}\u20ac</div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-0.5">Réel</div>
                  <input type="number" className="w-20 text-center text-sm glass-subtle border border-border rounded-lg px-2 py-1 text-foreground focus:border-primary outline-none" defaultValue={parseFloat(String(item.actualAmount || 0))} onBlur={e => update.mutate({ id: item.id, weddingId, actualAmount: parseFloat(e.target.value) || 0 })} />
                </div>
                <select className="text-xs glass-subtle border border-border rounded-lg px-2 py-1 text-muted-foreground focus:border-primary outline-none" value={item.status || "planned"} onChange={e => update.mutate({ id: item.id, weddingId, status: e.target.value as any })}>
                  {Object.entries(STATUS_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
                <button onClick={() => del.mutate({ id: item.id })} className="text-muted-foreground hover:text-red-400 transition-colors"><Trash2 size={15} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
