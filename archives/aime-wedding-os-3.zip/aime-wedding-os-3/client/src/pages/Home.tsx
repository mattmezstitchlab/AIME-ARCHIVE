import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Heart, ArrowRight, Sparkles, ChevronDown, Users, Calendar, DollarSign, Shield, Zap, Star } from "lucide-react";

// ─── COUNTDOWN ────────────────────────────────────────────────────────────────
function Countdown({ targetDate }: { targetDate: Date }) {
  const [time, setTime] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const tick = () => {
      const now = new Date().getTime();
      const diff = targetDate.getTime() - now;
      if (diff <= 0) { setTime({ days: 0, hours: 0, minutes: 0, seconds: 0 }); return; }
      setTime({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [targetDate]);

  return (
    <div className="flex gap-4 justify-center">
      {[
        { value: time.days, label: "Jours" },
        { value: time.hours, label: "Heures" },
        { value: time.minutes, label: "Minutes" },
        { value: time.seconds, label: "Secondes" },
      ].map(({ value, label }) => (
        <div key={label} className="text-center">
          <div style={{
            background: "rgba(255,255,255,0.9)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(220,180,180,0.3)",
            borderRadius: 16,
            padding: "16px 20px",
            minWidth: 72,
            boxShadow: "0 4px 20px rgba(180,100,100,0.1)",
          }}>
            <div style={{ fontSize: 32, fontWeight: 700, color: "#1a1a2e", fontFamily: "'Cormorant Garamond', serif", lineHeight: 1 }}>
              {String(value).padStart(2, "0")}
            </div>
          </div>
          <div style={{ fontSize: 11, color: "#9b7b7b", marginTop: 6, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase" }}>
            {label}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── FEATURE CARD ─────────────────────────────────────────────────────────────
function FeatureCard({ icon: Icon, title, desc, accent }: { icon: React.ElementType; title: string; desc: string; accent: string }) {
  return (
    <div style={{
      background: "rgba(255,255,255,0.7)",
      backdropFilter: "blur(10px)",
      border: `1px solid ${accent}30`,
      borderRadius: 20,
      padding: "28px 24px",
      transition: "all 0.3s ease",
      cursor: "default",
    }}
      onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.transform = "translateY(-4px)"; (e.currentTarget as HTMLDivElement).style.boxShadow = `0 12px 40px ${accent}20`; }}
      onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.transform = ""; (e.currentTarget as HTMLDivElement).style.boxShadow = ""; }}
    >
      <div style={{
        width: 48, height: 48, borderRadius: 14,
        background: `${accent}15`,
        display: "flex", alignItems: "center", justifyContent: "center",
        marginBottom: 16,
      }}>
        <Icon size={22} style={{ color: accent }} />
      </div>
      <h3 style={{ fontSize: 17, fontWeight: 700, color: "#1a1a2e", marginBottom: 8, fontFamily: "'Cormorant Garamond', serif" }}>{title}</h3>
      <p style={{ fontSize: 14, color: "#6b5b5b", lineHeight: 1.6 }}>{desc}</p>
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function Home() {
  const [, navigate] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { data: weddings = [] } = trpc.weddings.list.useQuery(undefined, { enabled: isAuthenticated });
  const heroRef = useRef<HTMLDivElement>(null);

  // Demo wedding date for countdown
  const demoDate = new Date("2025-06-14T14:00:00");

  const handleCTA = () => {
    if (!isAuthenticated) { startLogin(); return; }
    if (weddings.length > 0) { navigate(`/w/${weddings[0].id}`); }
    else { navigate("/onboarding"); }
  };

  const scrollToFeatures = () => {
    document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div style={{ background: "#faf8f5", minHeight: "100vh", fontFamily: "'Inter', sans-serif", overflowX: "hidden" }}>

      {/* ── NAV ── */}
      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: "rgba(250,248,245,0.92)",
        backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(180,140,140,0.15)",
        padding: "0 40px",
        height: 64,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: "50%",
            background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Heart size={14} fill="white" color="white" />
          </div>
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, fontWeight: 700, color: "#1a1a2e" }}>
            AIME<span style={{ color: "#e91e8c" }}>®</span>
          </span>
        </div>

        <div style={{ display: "flex", gap: 32, alignItems: "center" }}>
          {["Fonctionnalités", "Ripple", "Tarifs"].map(item => (
            <a key={item} href="#features" style={{ color: "#6b5b5b", fontSize: 14, fontWeight: 500, textDecoration: "none", transition: "color 0.2s" }}
              onMouseEnter={e => (e.target as HTMLAnchorElement).style.color = "#e91e8c"}
              onMouseLeave={e => (e.target as HTMLAnchorElement).style.color = "#6b5b5b"}
            >{item}</a>
          ))}
        </div>

        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          {isAuthenticated ? (
            <button onClick={handleCTA} style={{
              background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
              color: "white", border: "none", borderRadius: 24, padding: "10px 22px",
              fontSize: 14, fontWeight: 600, cursor: "pointer",
              boxShadow: "0 4px 20px rgba(233,30,140,0.3)",
            }}>
              Mon mariage
            </button>
          ) : (
            <>
              <button onClick={() => startLogin()} style={{ background: "none", border: "none", color: "#6b5b5b", fontSize: 14, fontWeight: 500, cursor: "pointer" }}>
                Se connecter
              </button>
              <button onClick={handleCTA} style={{
                background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
                color: "white", border: "none", borderRadius: 24, padding: "10px 22px",
                fontSize: 14, fontWeight: 600, cursor: "pointer",
                boxShadow: "0 4px 20px rgba(233,30,140,0.3)",
              }}>
                Commencer
              </button>
            </>
          )}
        </div>
      </nav>

      {/* ── HERO ── */}
      <section ref={heroRef} style={{
        minHeight: "100vh",
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        paddingTop: 64,
        position: "relative",
        overflow: "hidden",
      }}>
        {/* Background gradient blobs */}
        <div style={{
          position: "absolute", top: "10%", left: "5%",
          width: 500, height: 500, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(233,30,140,0.08) 0%, transparent 70%)",
          pointerEvents: "none",
        }} />
        <div style={{
          position: "absolute", bottom: "10%", right: "5%",
          width: 400, height: 400, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,107,107,0.08) 0%, transparent 70%)",
          pointerEvents: "none",
        }} />

        {/* Badge */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          background: "rgba(233,30,140,0.08)",
          border: "1px solid rgba(233,30,140,0.2)",
          borderRadius: 24, padding: "6px 16px",
          marginBottom: 32,
        }}>
          <Sparkles size={12} style={{ color: "#e91e8c" }} />
          <span style={{ fontSize: 12, color: "#e91e8c", fontWeight: 600, letterSpacing: "0.05em" }}>
            Moteur causal IA — Première mondiale
          </span>
        </div>

        {/* Title */}
        <h1 style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontSize: "clamp(52px, 8vw, 96px)",
          fontWeight: 700,
          color: "#1a1a2e",
          textAlign: "center",
          lineHeight: 1.05,
          marginBottom: 8,
          maxWidth: 800,
          padding: "0 20px",
        }}>
          Votre mariage,<br />
          <span style={{ color: "#e91e8c" }}>orchestré</span> par l'IA
        </h1>

        <p style={{
          fontSize: "clamp(16px, 2vw, 20px)",
          color: "#6b5b5b",
          textAlign: "center",
          maxWidth: 560,
          lineHeight: 1.7,
          marginBottom: 40,
          padding: "0 20px",
        }}>
          AIME® Wedding OS est le premier système d'orchestration causale pour mariages.
          Chaque décision révèle ses conséquences. Chaque risque est anticipé.
        </p>

        {/* CTA buttons */}
        <div style={{ display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center", marginBottom: 64 }}>
          <button onClick={handleCTA} style={{
            background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
            color: "white", border: "none", borderRadius: 32, padding: "16px 36px",
            fontSize: 16, fontWeight: 600, cursor: "pointer",
            boxShadow: "0 8px 32px rgba(233,30,140,0.35)",
            display: "flex", alignItems: "center", gap: 8,
            transition: "all 0.2s ease",
          }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-2px)"; (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 12px 40px rgba(233,30,140,0.45)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.transform = ""; (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 8px 32px rgba(233,30,140,0.35)"; }}
          >
            {isAuthenticated ? "Accéder à mon mariage" : "Créer mon mariage"} <ArrowRight size={18} />
          </button>
          <button onClick={scrollToFeatures} style={{
            background: "rgba(255,255,255,0.8)",
            color: "#1a1a2e", border: "1px solid rgba(180,140,140,0.3)", borderRadius: 32, padding: "16px 36px",
            fontSize: 16, fontWeight: 600, cursor: "pointer",
            backdropFilter: "blur(10px)",
          }}>
            Découvrir Ripple
          </button>
        </div>

        {/* Countdown demo */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <p style={{ fontSize: 12, color: "#9b7b7b", marginBottom: 16, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase" }}>
            Exemple — Sophie & Thomas · 14 juin 2025
          </p>
          <Countdown targetDate={demoDate} />
        </div>

        {/* Scroll cue */}
        <button onClick={scrollToFeatures} style={{ background: "none", border: "none", cursor: "pointer", marginTop: 24, color: "#9b7b7b", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase" }}>Découvrir</span>
          <ChevronDown size={20} style={{ animation: "bounce 2s infinite" }} />
        </button>
      </section>

      {/* ── COUPLE SECTION ── */}
      <section style={{ background: "white", padding: "80px 40px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 64 }}>
            <div style={{ fontSize: 12, color: "#e91e8c", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 12 }}>
              Mariage de démonstration
            </div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(36px, 5vw, 56px)", fontWeight: 700, color: "#1a1a2e", marginBottom: 8 }}>
              Sophie <span style={{ color: "#e91e8c" }}>♥</span> Thomas
            </h2>
            <p style={{ color: "#6b5b5b", fontSize: 16 }}>Château de Vaux-le-Vicomte · 14 juin 2025</p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 32, alignItems: "start" }}>
            {/* La mariée */}
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 11, color: "#e91e8c", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 16 }}>La mariée</div>
              <div style={{
                width: 120, height: 120, borderRadius: "50%", margin: "0 auto 16px",
                background: "linear-gradient(135deg, #fce4ec, #f8bbd9)",
                display: "flex", alignItems: "center", justifyContent: "center",
                border: "3px solid rgba(233,30,140,0.2)",
                fontSize: 40,
              }}>
                👰
              </div>
              <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 24, fontWeight: 700, color: "#1a1a2e", marginBottom: 4 }}>Sophie Moreau</h3>
              <p style={{ color: "#9b7b7b", fontSize: 13 }}>Architecte d'intérieur · Paris</p>
            </div>

            {/* Centre */}
            <div style={{ textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
              <div style={{
                width: 80, height: 80, borderRadius: "50%",
                background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
                display: "flex", alignItems: "center", justifyContent: "center",
                marginBottom: 16,
                boxShadow: "0 8px 32px rgba(233,30,140,0.3)",
              }}>
                <Heart size={32} fill="white" color="white" />
              </div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, color: "#9b7b7b", fontStyle: "italic" }}>
                se marient le
              </div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 700, color: "#1a1a2e", marginTop: 4 }}>
                14 juin 2025
              </div>
            </div>

            {/* Le marié */}
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 11, color: "#3b82f6", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 16 }}>Le marié</div>
              <div style={{
                width: 120, height: 120, borderRadius: "50%", margin: "0 auto 16px",
                background: "linear-gradient(135deg, #e3f2fd, #bbdefb)",
                display: "flex", alignItems: "center", justifyContent: "center",
                border: "3px solid rgba(59,130,246,0.2)",
                fontSize: 40,
              }}>
                🤵
              </div>
              <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 24, fontWeight: 700, color: "#1a1a2e", marginBottom: 4 }}>Thomas Leclerc</h3>
              <p style={{ color: "#9b7b7b", fontSize: 13 }}>Ingénieur logiciel · Paris</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" style={{ padding: "80px 40px", background: "#faf8f5" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 64 }}>
            <div style={{ fontSize: 12, color: "#e91e8c", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 12 }}>
              Fonctionnalités
            </div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(32px, 4vw, 48px)", fontWeight: 700, color: "#1a1a2e", marginBottom: 16 }}>
              L'intelligence causale au service de votre mariage
            </h2>
            <p style={{ color: "#6b5b5b", fontSize: 16, maxWidth: 560, margin: "0 auto" }}>
              Chaque décision révèle ses conséquences. Chaque risque est anticipé. Chaque acteur est informé.
            </p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 24 }}>
            <FeatureCard icon={Zap} title="Agent Ripple" desc="Votre chef d'orchestre IA. Parlez en langage naturel, Ripple traduit vos intentions en opérations causales et propage les impacts en temps réel." accent="#e91e8c" />
            <FeatureCard icon={Shield} title="Cadran Causal" desc="Vue opérationnelle SI → ALORS → PARCE QUE. Chaque risque est expliqué, chaque décision est tracée dans le Journal de preuve rejouable." accent="#6366f1" />
            <FeatureCard icon={Users} title="Cartes Uniques" desc="14 rôles distincts. Chaque acteur (témoin, DJ, traiteur) ne voit que ce qui le concerne. Isolation totale des vues par rôle." accent="#10b981" />
            <FeatureCard icon={DollarSign} title="Budget causal" desc="Suivi des dépenses avec propagation automatique. Un dépassement chez le traiteur déclenche une onde sur le budget global." accent="#f59e0b" />
            <FeatureCard icon={Calendar} title="Plan B intelligent" desc="3 scénarios de secours pré-configurés (météo, annulation DJ, traiteur). Activation en un clic depuis le Cadran ou le chat." accent="#ef4444" />
            <FeatureCard icon={Star} title="Journal de preuve" desc="Enregistrement immuable de chaque onde de propagation. Audit complet post-événement. Traçabilité totale de toutes les décisions." accent="#8b5cf6" />
          </div>
        </div>
      </section>

      {/* ── RIPPLE SECTION ── */}
      <section style={{ background: "white", padding: "80px 40px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 12, color: "#e91e8c", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 16 }}>
              Agent Ripple
            </div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(32px, 4vw, 48px)", fontWeight: 700, color: "#1a1a2e", marginBottom: 20, lineHeight: 1.2 }}>
              Parlez à Ripple,<br />il orchestre tout
            </h2>
            <p style={{ color: "#6b5b5b", fontSize: 16, lineHeight: 1.7, marginBottom: 32 }}>
              Ripple est le premier agent causal pour mariages. Il comprend le langage naturel, identifie les dépendances cachées et explique chaque conséquence avec la structure SI → ALORS → PARCE QUE.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {[
                { if: "SI le DJ annule à J-30", then: "ALORS activer la playlist de secours", because: "PARCE QUE le contrat prévoit 3 semaines de préavis" },
                { if: "SI 85 invités confirmés", then: "ALORS le budget traiteur augmente de 2 400€", because: "PARCE QUE le tarif unitaire est de 28€ au-delà de 80" },
              ].map((wave, i) => (
                <div key={i} style={{
                  background: "#faf8f5",
                  border: "1px solid rgba(180,140,140,0.2)",
                  borderRadius: 16, padding: "16px 20px",
                  borderLeft: "3px solid #e91e8c",
                }}>
                  <div style={{ fontSize: 13, color: "#6366f1", fontWeight: 600, marginBottom: 4 }}>🔵 {wave.if}</div>
                  <div style={{ fontSize: 13, color: "#f59e0b", fontWeight: 600, marginBottom: 4 }}>🟡 {wave.then}</div>
                  <div style={{ fontSize: 13, color: "#ef4444", fontWeight: 600 }}>🔴 {wave.because}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            background: "linear-gradient(135deg, #1a1a2e, #0d0d1a)",
            borderRadius: 24, padding: 32,
            boxShadow: "0 20px 60px rgba(0,0,0,0.2)",
            minHeight: 400,
            display: "flex", flexDirection: "column", justifyContent: "space-between",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 24 }}>
              <div style={{
                width: 36, height: 36, borderRadius: "50%",
                background: "linear-gradient(135deg, #e91e8c, #6366f1)",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <Zap size={16} color="white" />
              </div>
              <div>
                <div style={{ color: "white", fontSize: 14, fontWeight: 600 }}>Ripple</div>
                <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 11 }}>Agent causal · En ligne</div>
              </div>
              <div style={{ marginLeft: "auto", width: 8, height: 8, borderRadius: "50%", background: "#10b981", boxShadow: "0 0 8px #10b981" }} />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1 }}>
              <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: "12px 16px", maxWidth: "85%" }}>
                <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, lineHeight: 1.5, margin: 0 }}>
                  Bonjour ! Je suis Ripple, votre agent causal. J'ai analysé votre mariage Sophie & Thomas et détecté 2 ondes actives.
                </p>
              </div>
              <div style={{ background: "rgba(233,30,140,0.15)", border: "1px solid rgba(233,30,140,0.3)", borderRadius: 12, padding: "12px 16px", maxWidth: "90%" }}>
                <p style={{ color: "rgba(255,255,255,0.9)", fontSize: 13, lineHeight: 1.5, margin: 0 }}>
                  🔴 <strong>CRITIQUE :</strong> DJ Marco n'a pas confirmé son contrat à J-90. SI aucune réponse avant le 15 mars, ALORS activer le Plan B musique.
                </p>
              </div>
              <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: "12px 16px", maxWidth: "85%" }}>
                <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, lineHeight: 1.5, margin: 0 }}>
                  Voulez-vous que je contacte DJ Marco et prépare le Plan B en mode veille ?
                </p>
              </div>
            </div>

            <div style={{
              marginTop: 20,
              background: "rgba(255,255,255,0.08)",
              borderRadius: 12, padding: "12px 16px",
              display: "flex", alignItems: "center", gap: 10,
              border: "1px solid rgba(255,255,255,0.1)",
            }}>
              <input
                readOnly
                placeholder="Parlez à Ripple..."
                style={{ flex: 1, background: "none", border: "none", outline: "none", color: "rgba(255,255,255,0.5)", fontSize: 13 }}
              />
              <button onClick={handleCTA} style={{
                background: "linear-gradient(135deg, #e91e8c, #6366f1)",
                border: "none", borderRadius: 8, padding: "8px 16px",
                color: "white", fontSize: 12, fontWeight: 600, cursor: "pointer",
              }}>
                Essayer
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section style={{ background: "linear-gradient(135deg, #e91e8c, #ff6b6b)", padding: "60px 40px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 32, textAlign: "center" }}>
          {[
            { value: "14", label: "Rôles distincts" },
            { value: "SI→ALORS", label: "Logique causale" },
            { value: "100%", label: "Traçabilité" },
            { value: "Temps réel", label: "Propagation" },
          ].map(({ value, label }) => (
            <div key={label}>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 36, fontWeight: 700, color: "white", marginBottom: 4 }}>{value}</div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", fontWeight: 500 }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA FINAL ── */}
      <section style={{ padding: "80px 40px", background: "#faf8f5", textAlign: "center" }}>
        <div style={{ maxWidth: 600, margin: "0 auto" }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(32px, 4vw, 48px)", fontWeight: 700, color: "#1a1a2e", marginBottom: 16 }}>
            Prêt à orchestrer votre mariage ?
          </h2>
          <p style={{ color: "#6b5b5b", fontSize: 16, lineHeight: 1.7, marginBottom: 40 }}>
            Rejoignez les premiers mariés à bénéficier de l'intelligence causale. Gratuit pour commencer.
          </p>
          <button onClick={handleCTA} style={{
            background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
            color: "white", border: "none", borderRadius: 32, padding: "18px 48px",
            fontSize: 18, fontWeight: 600, cursor: "pointer",
            boxShadow: "0 8px 32px rgba(233,30,140,0.35)",
            display: "inline-flex", alignItems: "center", gap: 10,
          }}>
            {isAuthenticated ? "Accéder à mon mariage" : "Créer mon mariage gratuitement"} <Heart size={18} fill="white" />
          </button>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ background: "#1a1a2e", padding: "40px 40px", textAlign: "center" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 16 }}>
          <div style={{
            width: 28, height: 28, borderRadius: "50%",
            background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Heart size={12} fill="white" color="white" />
          </div>
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, fontWeight: 700, color: "white" }}>
            AIME<span style={{ color: "#e91e8c" }}>®</span> Wedding OS
          </span>
        </div>
        <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 12 }}>
          © 2025 AIME® — Système d'orchestration causale d'événements — Innovation mondiale
        </p>
      </footer>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(6px); }
        }
      `}</style>
    </div>
  );
}
