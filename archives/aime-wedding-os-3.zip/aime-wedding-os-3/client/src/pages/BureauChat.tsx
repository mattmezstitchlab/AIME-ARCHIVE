import { useState, useRef, useEffect, useCallback } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Send, Zap } from "lucide-react";
import { toast } from "sonner";

const QUICK_ACTIONS = [
  "Quel est l'état de mon mariage ?",
  "Ajoute un prestataire photographe",
  "Analyse les risques actuels",
  "Que se passe-t-il si le traiteur annule ?",
  "Montre-moi les ondes causales en attente",
];

export default function BureauChat() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const utils = trpc.useUtils();

  const { data: messages = [], isLoading } = trpc.chat.messages.useQuery(
    { weddingId, limit: 100 },
    { enabled: isAuthenticated && weddingId > 0 }
  );

  const { data: weddingData } = trpc.weddings.get.useQuery(
    { id: weddingId },
    { enabled: isAuthenticated && weddingId > 0 }
  );

  const saveMessage = trpc.chat.saveMessage.useMutation({
    onSuccess: () => {
      utils.chat.messages.invalidate({ weddingId });
      utils.causalWaves.list.invalidate({ weddingId });
      utils.dashboard.overview.invalidate({ weddingId });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping, streamingContent]);

  const handleSend = useCallback(async () => {
    const content = input.trim();
    if (!content || isSending) return;
    setInput("");
    setIsSending(true);
    setIsTyping(true);
    setStreamingContent("");

    // Save user message first
    await saveMessage.mutateAsync({ weddingId, role: "user", content }).catch(() => {});

    // Build conversation history for context
    const history = messages.slice(-10).map(m => ({ role: m.role as "user" | "assistant", content: m.content }));
    history.push({ role: "user", content });

    const weddingContext = weddingData
      ? `Mariage : ${weddingData.name}, Date : ${weddingData.weddingDate ? new Date(weddingData.weddingDate).toLocaleDateString('fr-FR') : 'non definie'}, Lieu : ${weddingData.venue || 'non defini'}, Budget : ${weddingData.budgetMax || 0}€`
      : undefined;

    abortRef.current = new AbortController();
    let fullResponse = "";

    try {
      const res = await fetch("/api/ripple/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history, weddingContext }),
        signal: abortRef.current.signal,
      });

      if (!res.ok || !res.body) throw new Error("Stream error");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      setIsTyping(false);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          const t = line.trim();
          if (t === "data: [DONE]") break;
          if (t.startsWith("data: ")) {
            try {
              const parsed = JSON.parse(t.slice(6)) as { content?: string; error?: string };
              if (parsed.error) throw new Error(parsed.error);
              if (parsed.content) {
                fullResponse += parsed.content;
                setStreamingContent(fullResponse);
              }
            } catch { /* skip */ }
          }
        }
      }

      // Save assistant response
      if (fullResponse) {
        await saveMessage.mutateAsync({ weddingId, role: "assistant", content: fullResponse }).catch(() => {});
      }
    } catch (err: unknown) {
      if (err instanceof Error && err.name !== "AbortError") {
        toast.error("Erreur de communication avec Ripple");
        // Fallback to tRPC non-streaming
        try {
          await (trpc as unknown as { chat: { sendMessage: { mutate: (args: { weddingId: number; content: string }) => Promise<{ hasWave?: boolean }> } } }).chat.sendMessage.mutate({ weddingId, content });
        } catch { /* ignore */ }
      }
    } finally {
      setIsTyping(false);
      setStreamingContent("");
      setIsSending(false);
      utils.chat.messages.invalidate({ weddingId });
    }
  }, [input, isSending, messages, weddingData, weddingId, saveMessage, utils]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button>
      </div>
    );
  }

  return (
    <AppLayout weddingId={weddingId}>
      <div className="flex flex-col h-[calc(100vh-0px)] lg:h-screen">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border glass-subtle shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl gradient-accent flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-background" />
            </div>
            <div>
              <div className="text-foreground font-semibold">Ripple</div>
              <div className="text-muted-foreground text-xs">Agent causal AIME&reg; &mdash; En ligne</div>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">{messages.length} messages</div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6 space-y-4">
          {!isLoading && messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="w-16 h-16 rounded-2xl gradient-accent flex items-center justify-center mb-4 animate-glow-pulse">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-foreground font-semibold text-lg mb-2">Bonjour, je suis Ripple</h3>
              <p className="text-muted-foreground text-sm max-w-sm mb-6 leading-relaxed">
                Votre agent causal AIME&reg;. Parlez-moi de votre mariage en langage naturel &mdash;
                je traduis chaque information en op&eacute;rations sur le graphe causal.
              </p>
              <div className="grid grid-cols-1 gap-2 w-full max-w-sm">
                {QUICK_ACTIONS.map(action => (
                  <button
                    key={action}
                    onClick={() => { setInput(action); inputRef.current?.focus(); }}
                    className="glass-card text-left text-sm py-3 px-4 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {action}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} gap-3`}>
              {msg.role === "assistant" && (
                <div className="w-8 h-8 rounded-lg gradient-accent flex items-center justify-center shrink-0 mt-1">
                  <Zap className="w-3.5 h-3.5 text-white" />
                </div>
              )}
              <div className={`max-w-[75%] rounded-2xl px-4 py-3 ${
                msg.role === "user"
                  ? "bg-primary/15 border border-primary/20 text-foreground"
                  : "glass-card text-foreground"
              }`}>
                <div className="text-sm leading-relaxed whitespace-pre-wrap">
                  {msg.content.split('\n').map((line: string, li: number) => {
                    if (line.match(/^(🔵\s*)?SI\s/)) return <div key={li} className="flex gap-2 my-1"><span className="wave-si shrink-0 text-xs">SI</span><span className="text-foreground/80">{line.replace(/^(🔵\s*)?SI\s/, '')}</span></div>;
                    if (line.match(/^(🟡\s*)?ALORS\s/)) return <div key={li} className="flex gap-2 my-1"><span className="wave-alors shrink-0 text-xs">ALORS</span><span className="text-foreground/80">{line.replace(/^(🟡\s*)?ALORS\s/, '')}</span></div>;
                    if (line.match(/^(🔴\s*)?PARCE QUE\s/)) return <div key={li} className="flex gap-2 my-1"><span className="wave-parce-que shrink-0 text-xs">PARCE QUE</span><span className="text-foreground/70">{line.replace(/^(🔴\s*)?PARCE QUE\s/, '')}</span></div>;
                    return <span key={li}>{line}{li < msg.content.split('\n').length - 1 ? '\n' : ''}</span>;
                  })}
                </div>
                {msg.waveId && (
                  <div className="mt-3 flex items-center gap-1.5 text-xs text-accent">
                    <Zap size={11} /> Onde causale #{msg.waveId} g&eacute;n&eacute;r&eacute;e
                  </div>
                )}
                <div className="mt-2 text-xs text-muted-foreground/60">
                  {new Date(msg.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg gradient-accent flex items-center justify-center shrink-0">
                <Zap className="w-3.5 h-3.5 text-white" />
              </div>
              <div className="glass-card px-4 py-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick actions */}
        {messages.length > 0 && (
          <div className="px-4 py-2 flex gap-2 overflow-x-auto shrink-0 border-t border-border/50">
            {QUICK_ACTIONS.slice(0, 3).map(action => (
              <button
                key={action}
                onClick={() => { setInput(action); inputRef.current?.focus(); }}
                className="shrink-0 text-xs px-3 py-1.5 rounded-full glass-subtle text-muted-foreground hover:text-foreground transition-all"
              >
                {action}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="px-4 py-4 border-t border-border glass-subtle shrink-0">
          <div className="flex items-end gap-3 max-w-4xl mx-auto">
            <div className="flex-1">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Parlez à Ripple en langage naturel..."
                className="input-vision resize-none min-h-[48px] max-h-[160px] py-3 leading-relaxed"
                rows={1}
                onInput={e => {
                  const t = e.target as HTMLTextAreaElement;
                  t.style.height = 'auto';
                  t.style.height = Math.min(t.scrollHeight, 160) + 'px';
                }}
              />
            </div>
            <button
              onClick={handleSend}
              disabled={!input.trim() || isSending}
              className="btn-vision-primary p-3 shrink-0 disabled:opacity-40"
            >
              <Send size={18} />
            </button>
          </div>
          <p className="text-center text-xs text-muted-foreground/50 mt-2">
            Entr&eacute;e pour envoyer &middot; Shift+Entr&eacute;e pour nouvelle ligne
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
