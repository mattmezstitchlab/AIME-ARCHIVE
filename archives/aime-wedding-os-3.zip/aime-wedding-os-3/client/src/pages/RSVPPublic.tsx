import { useState } from "react";
import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Heart, CheckCircle2, AlertCircle, Loader2, Users } from "lucide-react";

type Step = "form" | "submitting" | "success" | "error";

export default function RSVPPublic() {
  const params = useParams<{ token: string }>();
  const token = params.token || "";

  const [step, setStep] = useState<Step>("form");
  const [form, setForm] = useState({
    guestName: "",
    email: "",
    attending: "confirmed" as "confirmed" | "declined" | "maybe",
    guestCount: 1,
    dietaryRestrictions: "",
    message: "",
  });

  const { data, isLoading, error: loadError } = trpc.rsvp.getByToken.useQuery(
    { token },
    { enabled: token.length > 0 }
  );

  const submitRSVP = trpc.rsvp.submitByToken.useMutation({
    onSuccess: () => setStep("success"),
    onError: () => setStep("error"),
  });

  // Pre-fill guest name from token lookup
  const guestNameFromToken = data?.entry?.guestName;
  const displayName = form.guestName || guestNameFromToken || "";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) return;
    setStep("submitting");
    submitRSVP.mutate({
      token,
      status: form.attending,
      guestName: displayName,
      email: form.email || undefined,
      plusOne: form.guestCount > 1,
      guestCount: form.guestCount,
      dietaryRestrictions: form.dietaryRestrictions || undefined,
      message: form.message || undefined,
    });
  };

  const wedding = data?.wedding;
  const weddingDate = wedding?.weddingDate ? new Date(wedding.weddingDate) : null;

  if (isLoading) {
    return (
      <div style={{ minHeight: "100vh", background: "#faf8f5", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16 }}>
        <Loader2 size={32} style={{ color: "#e91e8c", animation: "spin 1s linear infinite" }} />
        <p style={{ color: "#9b7b7b", fontSize: 14 }}>Chargement de votre invitation...</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!token || loadError || (!isLoading && !data)) {
    return (
      <div style={{ minHeight: "100vh", background: "#faf8f5", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16, padding: 20 }}>
        <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(239,68,68,0.1)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <AlertCircle size={40} style={{ color: "#ef4444" }} />
        </div>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 700, color: "#1a1a2e", textAlign: "center" }}>
          Invitation introuvable
        </h2>
        <p style={{ color: "#6b5b5b", fontSize: 15, textAlign: "center", maxWidth: 400 }}>
          Ce lien d'invitation est invalide ou a expiré. Veuillez contacter les mariés pour obtenir un nouveau lien.
        </p>
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Inter:wght@400;500;600;700&display=swap');`}</style>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#faf8f5", fontFamily: "'Inter', sans-serif" }}>

      {/* Header */}
      <div style={{
        background: "white",
        borderBottom: "1px solid rgba(180,140,140,0.15)",
        padding: "16px 40px",
        display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: "50%",
          background: "linear-gradient(135deg, #e91e8c, #ff6b6b)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Heart size={12} fill="white" color="white" />
        </div>
        <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, fontWeight: 700, color: "#1a1a2e" }}>
          AIME<span style={{ color: "#e91e8c" }}>®</span> Wedding OS
        </span>
      </div>

      {/* Hero */}
      <div style={{
        background: "linear-gradient(180deg, white 0%, #faf8f5 100%)",
        padding: "60px 40px 40px",
        textAlign: "center",
        borderBottom: "1px solid rgba(180,140,140,0.1)",
      }}>
        <div style={{ fontSize: 12, color: "#e91e8c", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 12 }}>
          Invitation personnelle
        </div>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(32px, 5vw, 56px)", fontWeight: 700, color: "#1a1a2e", marginBottom: 8 }}>
          {wedding?.name || "Mariage"}
        </h1>
        {weddingDate && (
          <p style={{ color: "#6b5b5b", fontSize: 16, marginBottom: 4 }}>
            {weddingDate.toLocaleDateString("fr-FR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
        )}
        {wedding?.venue && (
          <p style={{ color: "#9b7b7b", fontSize: 14 }}>{wedding.venue}</p>
        )}
        {guestNameFromToken && (
          <div style={{ marginTop: 20, display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(233,30,140,0.06)", border: "1px solid rgba(233,30,140,0.15)", borderRadius: 24, padding: "8px 20px" }}>
            <Users size={13} style={{ color: "#e91e8c" }} />
            <span style={{ fontSize: 13, color: "#e91e8c", fontWeight: 600 }}>
              Invitation pour {guestNameFromToken}
            </span>
          </div>
        )}
        {data?.entry?.respondedAt && (
          <div style={{ marginTop: 12, display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(16,185,129,0.06)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 24, padding: "6px 16px" }}>
            <CheckCircle2 size={12} style={{ color: "#10b981" }} />
            <span style={{ fontSize: 12, color: "#10b981", fontWeight: 600 }}>
              Vous avez déjà répondu — vous pouvez modifier votre réponse
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div style={{ maxWidth: 560, margin: "0 auto", padding: "40px 20px" }}>

        {step === "success" && (
          <div style={{
            background: "white", borderRadius: 24, padding: 48, textAlign: "center",
            boxShadow: "0 4px 40px rgba(0,0,0,0.06)", border: "1px solid rgba(180,140,140,0.15)",
          }}>
            <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(16,185,129,0.1)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
              <CheckCircle2 size={40} style={{ color: "#10b981" }} />
            </div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 32, fontWeight: 700, color: "#1a1a2e", marginBottom: 12 }}>
              {form.attending === "confirmed" ? "A bientot !" : form.attending === "declined" ? "Merci pour votre reponse" : "Reponse enregistree"}
            </h2>
            <p style={{ color: "#6b5b5b", fontSize: 15, lineHeight: 1.6, marginBottom: 24 }}>
              {form.attending === "confirmed"
                ? `Nous sommes ravis de vous compter parmi nous, ${displayName}. Votre presence a ete confirmee et transmise aux maries.`
                : form.attending === "declined"
                ? `Merci ${displayName} pour votre reponse. Nous esperons vous retrouver prochainement.`
                : `Merci ${displayName}. Nous attendons votre confirmation definitive.`
              }
            </p>
            <div style={{ padding: "16px 20px", background: "#faf8f5", borderRadius: 12, border: "1px solid rgba(180,140,140,0.15)" }}>
              <p style={{ fontSize: 12, color: "#9b7b7b", margin: 0 }}>
                Votre reponse a ete transmise aux maries via le moteur causal AIME®.
              </p>
            </div>
          </div>
        )}

        {step === "error" && (
          <div style={{
            background: "white", borderRadius: 24, padding: 48, textAlign: "center",
            boxShadow: "0 4px 40px rgba(0,0,0,0.06)", border: "1px solid rgba(239,68,68,0.2)",
          }}>
            <AlertCircle size={48} style={{ color: "#ef4444", margin: "0 auto 16px", display: "block" }} />
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 700, color: "#1a1a2e", marginBottom: 12 }}>
              Une erreur est survenue
            </h2>
            <p style={{ color: "#6b5b5b", fontSize: 15, marginBottom: 24 }}>Veuillez reessayer ou contacter les maries directement.</p>
            <button onClick={() => setStep("form")} style={{
              background: "linear-gradient(135deg, #e91e8c, #ff6b6b)", color: "white",
              border: "none", borderRadius: 24, padding: "12px 28px", fontSize: 14, fontWeight: 600, cursor: "pointer",
            }}>
              Reessayer
            </button>
          </div>
        )}

        {(step === "form" || step === "submitting") && (
          <form onSubmit={handleSubmit} style={{
            background: "white", borderRadius: 24, padding: "40px 36px",
            boxShadow: "0 4px 40px rgba(0,0,0,0.06)", border: "1px solid rgba(180,140,140,0.15)",
          }}>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, fontWeight: 700, color: "#1a1a2e", marginBottom: 28, textAlign: "center" }}>
              Votre reponse
            </h2>

            {/* Attending choice */}
            <div style={{ marginBottom: 24 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: "#1a1a2e", display: "block", marginBottom: 10 }}>
                Serez-vous present(e) ? *
              </label>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
                {[
                  { value: "confirmed", label: "Oui, avec joie !", emoji: "🎉" },
                  { value: "declined", label: "Non, desole(e)", emoji: "😔" },
                  { value: "maybe", label: "Peut-etre", emoji: "🤔" },
                ].map(({ value, label, emoji }) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setForm(f => ({ ...f, attending: value as "confirmed" | "declined" | "maybe" }))}
                    style={{
                      padding: "12px 8px", borderRadius: 12,
                      border: `2px solid ${form.attending === value ? "#e91e8c" : "rgba(180,140,140,0.2)"}`,
                      background: form.attending === value ? "rgba(233,30,140,0.06)" : "white",
                      cursor: "pointer", textAlign: "center", transition: "all 0.2s",
                    }}
                  >
                    <div style={{ fontSize: 20, marginBottom: 4 }}>{emoji}</div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: form.attending === value ? "#e91e8c" : "#6b5b5b" }}>{label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Name */}
            <div style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: "#1a1a2e", display: "block", marginBottom: 6 }}>
                Votre nom complet *
              </label>
              <input
                required
                value={form.guestName || guestNameFromToken || ""}
                onChange={e => setForm(f => ({ ...f, guestName: e.target.value }))}
                placeholder={guestNameFromToken || "Prenom Nom"}
                style={{
                  width: "100%", padding: "12px 16px", borderRadius: 12,
                  border: "1px solid rgba(180,140,140,0.3)", fontSize: 14, outline: "none",
                  background: "#faf8f5", boxSizing: "border-box", transition: "border-color 0.2s",
                }}
                onFocus={e => (e.target.style.borderColor = "#e91e8c")}
                onBlur={e => (e.target.style.borderColor = "rgba(180,140,140,0.3)")}
              />
            </div>

            {/* Email */}
            <div style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: "#1a1a2e", display: "block", marginBottom: 6 }}>
                Email (optionnel)
              </label>
              <input
                type="email"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="votre@email.com"
                style={{
                  width: "100%", padding: "12px 16px", borderRadius: 12,
                  border: "1px solid rgba(180,140,140,0.3)", fontSize: 14, outline: "none",
                  background: "#faf8f5", boxSizing: "border-box",
                }}
                onFocus={e => (e.target.style.borderColor = "#e91e8c")}
                onBlur={e => (e.target.style.borderColor = "rgba(180,140,140,0.3)")}
              />
            </div>

            {/* Guest count */}
            {form.attending !== "declined" && (
              <div style={{ marginBottom: 18 }}>
                <label style={{ fontSize: 13, fontWeight: 600, color: "#1a1a2e", display: "block", marginBottom: 6 }}>
                  Nombre de personnes (vous inclus)
                </label>
                <div style={{ display: "flex", gap: 8 }}>
                  {[1, 2, 3, 4].map(n => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, guestCount: n }))}
                      style={{
                        width: 44, height: 44, borderRadius: 10,
                        border: `2px solid ${form.guestCount === n ? "#e91e8c" : "rgba(180,140,140,0.2)"}`,
                        background: form.guestCount === n ? "rgba(233,30,140,0.06)" : "white",
                        color: form.guestCount === n ? "#e91e8c" : "#6b5b5b",
                        fontSize: 15, fontWeight: 700, cursor: "pointer", transition: "all 0.2s",
                      }}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Dietary */}
            <div style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: "#1a1a2e", display: "block", marginBottom: 6 }}>
                Regimes alimentaires / allergies
              </label>
              <input
                value={form.dietaryRestrictions}
                onChange={e => setForm(f => ({ ...f, dietaryRestrictions: e.target.value }))}
                placeholder="Vegetarien, sans gluten, allergie aux noix..."
                style={{
                  width: "100%", padding: "12px 16px", borderRadius: 12,
                  border: "1px solid rgba(180,140,140,0.3)", fontSize: 14, outline: "none",
                  background: "#faf8f5", boxSizing: "border-box",
                }}
                onFocus={e => (e.target.style.borderColor = "#e91e8c")}
                onBlur={e => (e.target.style.borderColor = "rgba(180,140,140,0.3)")}
              />
            </div>

            {/* Message */}
            <div style={{ marginBottom: 28 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: "#1a1a2e", display: "block", marginBottom: 6 }}>
                Message aux maries (optionnel)
              </label>
              <textarea
                value={form.message}
                onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                placeholder="Un mot pour les maries..."
                rows={3}
                style={{
                  width: "100%", padding: "12px 16px", borderRadius: 12,
                  border: "1px solid rgba(180,140,140,0.3)", fontSize: 14, outline: "none",
                  background: "#faf8f5", boxSizing: "border-box", resize: "vertical",
                  fontFamily: "'Inter', sans-serif",
                }}
                onFocus={e => (e.target.style.borderColor = "#e91e8c")}
                onBlur={e => (e.target.style.borderColor = "rgba(180,140,140,0.3)")}
              />
            </div>

            <button
              type="submit"
              disabled={step === "submitting" || !displayName.trim()}
              style={{
                width: "100%",
                background: step === "submitting" || !displayName.trim()
                  ? "rgba(233,30,140,0.4)"
                  : "linear-gradient(135deg, #e91e8c, #ff6b6b)",
                color: "white", border: "none", borderRadius: 24, padding: "16px",
                fontSize: 16, fontWeight: 600, cursor: step === "submitting" ? "not-allowed" : "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                boxShadow: "0 8px 24px rgba(233,30,140,0.25)", transition: "all 0.2s",
              }}
            >
              {step === "submitting" ? (
                <><Loader2 size={18} style={{ animation: "spin 1s linear infinite" }} /> Envoi en cours...</>
              ) : (
                <><Heart size={18} fill="white" /> Envoyer ma reponse</>
              )}
            </button>

            <p style={{ textAlign: "center", fontSize: 11, color: "#9b7b7b", marginTop: 16 }}>
              Votre reponse sera transmise aux maries via le moteur causal AIME®.
            </p>
          </form>
        )}
      </div>

      {/* Footer */}
      <div style={{ textAlign: "center", padding: "32px 20px", borderTop: "1px solid rgba(180,140,140,0.1)" }}>
        <p style={{ fontSize: 11, color: "#c4a4a4" }}>
          Propulse par <strong style={{ color: "#e91e8c" }}>AIME® Wedding OS</strong> — Moteur causal d'orchestration d'evenements
        </p>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Inter:wght@400;500;600;700&display=swap');
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
