import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { ArrowRight, ArrowLeft, Calendar, MapPin, Wallet, Users, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function Onboarding() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: "",
    weddingDate: "",
    venue: "",
    budgetMax: "",
    guestCount: "",
  });

  const createWedding = trpc.weddings.create.useMutation({
    onSuccess: ({ id }) => {
      toast.success("Mariage créé ! Bienvenue dans AIME\u00ae Wedding OS.");
      navigate(`/w/${id}/chat`);
    },
    onError: () => toast.error("Erreur lors de la création du mariage."),
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen gradient-hero flex items-center justify-center px-6 relative overflow-hidden">
        <div className="ambient-orb orb-1" />
        <div className="ambient-orb orb-2" />
        <div className="glass-strong rounded-3xl p-12 text-center max-w-md animate-float-in">
          <div className="w-16 h-16 rounded-2xl gradient-accent flex items-center justify-center mx-auto mb-6">
            <span className="text-white font-bold text-2xl">A</span>
          </div>
          <h1 className="text-3xl font-semibold text-foreground mb-4">Bienvenue dans AIME&reg;</h1>
          <p className="text-muted-foreground mb-8">Connectez-vous pour créer votre mariage et accéder au moteur causal.</p>
          <button onClick={() => startLogin()} className="btn-vision-primary text-base px-8 py-3">Se connecter</button>
        </div>
      </div>
    );
  }

  const steps = [
    { title: "Quel est le nom de votre mariage ?", subtitle: "Ce nom identifiera votre mariage dans AIME\u00ae Wedding OS.", icon: Sparkles, valid: form.name.trim().length > 0 },
    { title: "Quelle est la date de votre mariage ?", subtitle: "Le moteur causal calculera les jours restants et les délais critiques.", icon: Calendar, valid: true },
    { title: "Où se déroulera votre mariage ?", subtitle: "Le lieu est un n\u0153ud clé dans le graphe causal.", icon: MapPin, valid: true },
    { title: "Quel est votre budget total ?", subtitle: "Le moteur causal surveillera les dépassements et propagera les alertes.", icon: Wallet, valid: true },
    { title: "Combien d'invités attendez-vous ?", subtitle: "Le RSVP et le plan de table seront calibrés sur ce nombre.", icon: Users, valid: true },
  ];

  const currentStep = steps[step];
  const Icon = currentStep.icon;

  const handleNext = () => {
    if (step < steps.length - 1) setStep(s => s + 1);
    else {
      createWedding.mutate({
        name: form.name,
        weddingDate: form.weddingDate || undefined,
        venue: form.venue || undefined,
        budgetMax: form.budgetMax ? parseFloat(form.budgetMax) : undefined,
        guestCount: form.guestCount ? parseInt(form.guestCount) : undefined,
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && currentStep.valid) handleNext();
  };

  return (
    <div className="min-h-screen gradient-hero flex flex-col items-center justify-center px-6 relative overflow-hidden">
      <div className="ambient-orb orb-1" />
      <div className="ambient-orb orb-2" />

      <div className="relative z-10 w-full max-w-xl">
        {/* Progress */}
        <div className="flex items-center gap-2 mb-10">
          {steps.map((_, i) => (
            <div key={i} className={`flex-1 h-1 rounded-full transition-all duration-500 ${i <= step ? "bg-primary glow-primary" : "bg-muted"}`} />
          ))}
        </div>

        {/* Step Card */}
        <div className="glass-strong rounded-3xl p-8 md:p-12 animate-float-in" key={step}>
          <div className="w-12 h-12 rounded-2xl glass-subtle flex items-center justify-center mb-6">
            <Icon className="w-6 h-6 text-primary" />
          </div>

          <h2 className="text-2xl font-semibold text-foreground mb-2">{currentStep.title}</h2>
          <p className="text-muted-foreground text-sm mb-8">{currentStep.subtitle}</p>

          <div onKeyDown={handleKeyDown}>
            {step === 0 && (
              <input className="input-vision text-lg" placeholder="Ex: Mariage de Sophie & Thomas" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} autoFocus />
            )}
            {step === 1 && (
              <input type="date" className="input-vision text-lg" value={form.weddingDate} onChange={e => setForm(f => ({ ...f, weddingDate: e.target.value }))} autoFocus />
            )}
            {step === 2 && (
              <input className="input-vision text-lg" placeholder="Ex: Château de Versailles, Paris" value={form.venue} onChange={e => setForm(f => ({ ...f, venue: e.target.value }))} autoFocus />
            )}
            {step === 3 && (
              <div className="relative">
                <input type="number" className="input-vision text-lg pr-10" placeholder="25000" value={form.budgetMax} onChange={e => setForm(f => ({ ...f, budgetMax: e.target.value }))} autoFocus />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground font-semibold">&euro;</span>
              </div>
            )}
            {step === 4 && (
              <input type="number" className="input-vision text-lg" placeholder="80" value={form.guestCount} onChange={e => setForm(f => ({ ...f, guestCount: e.target.value }))} autoFocus />
            )}
          </div>

          <div className="flex items-center justify-between mt-8">
            <button onClick={() => setStep(s => Math.max(0, s - 1))} className={`btn-vision-ghost flex items-center gap-1 ${step === 0 ? "opacity-0 pointer-events-none" : ""}`}>
              <ArrowLeft className="w-4 h-4" /> Retour
            </button>
            <button onClick={handleNext} disabled={!currentStep.valid || createWedding.isPending} className="btn-vision-primary flex items-center gap-2 disabled:opacity-50">
              {step === steps.length - 1 ? (createWedding.isPending ? "Création..." : "Lancer AIME\u00ae") : "Continuer"}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <p className="text-center text-muted-foreground text-xs mt-6">&Eacute;tape {step + 1} sur {steps.length} &mdash; Vous pourrez tout modifier ensuite</p>
      </div>
    </div>
  );
}
