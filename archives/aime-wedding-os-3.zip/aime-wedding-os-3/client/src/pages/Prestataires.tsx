import { useState } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Plus, Users, Trash2 } from "lucide-react";
import { toast } from "sonner";

const AVAIL_COLORS: Record<string, string> = { available: "text-green-400", tentative: "text-yellow-400", booked: "text-blue-400", unavailable: "text-red-400" };
const AVAIL_LABELS: Record<string, string> = { available: "Disponible", tentative: "Tentative", booked: "Réservé", unavailable: "Indisponible" };
const CONTRACT_LABELS: Record<string, string> = { none: "Aucun", requested: "Demandé", signed: "Signé", cancelled: "Annulé" };

export default function Prestataires() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", category: "", estimatedPrice: "", contactEmail: "", contactPhone: "", notes: "" });

  const utils = trpc.useUtils();
  const { data: items = [] } = trpc.vendors.list.useQuery({ weddingId }, { enabled: isAuthenticated && weddingId > 0 });
  const create = trpc.vendors.create.useMutation({ onSuccess: () => { utils.vendors.list.invalidate({ weddingId }); setShowForm(false); setForm({ name: "", category: "", estimatedPrice: "", contactEmail: "", contactPhone: "", notes: "" }); toast.success("Prestataire ajouté"); } });
  const update = trpc.vendors.update.useMutation({ onSuccess: () => utils.vendors.list.invalidate({ weddingId }) });
  const del = trpc.vendors.delete.useMutation({ onSuccess: () => { utils.vendors.list.invalidate({ weddingId }); toast.success("Prestataire supprimé"); } });

  if (!isAuthenticated) return <div className="min-h-screen bg-background flex items-center justify-center"><button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button></div>;

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Prestataires</h1>
            <p className="text-muted-foreground text-sm mt-1">Chaque retard ou annulation propage une onde causale</p>
          </div>
          <button onClick={() => setShowForm(!showForm)} className="btn-vision-primary flex items-center gap-2 text-sm"><Plus size={16} />Ajouter</button>
        </div>

        {showForm && (
          <div className="glass-strong rounded-2xl p-5 animate-float-in">
            <h3 className="text-foreground font-semibold mb-4">Nouveau prestataire</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <input className="input-vision text-sm" placeholder="Nom du prestataire" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Catégorie (ex: Photographe)" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} />
              <input type="number" className="input-vision text-sm" placeholder="Prix estimé (\u20ac)" value={form.estimatedPrice} onChange={e => setForm(f => ({ ...f, estimatedPrice: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Email de contact" value={form.contactEmail} onChange={e => setForm(f => ({ ...f, contactEmail: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Téléphone" value={form.contactPhone} onChange={e => setForm(f => ({ ...f, contactPhone: e.target.value }))} />
              <input className="input-vision text-sm" placeholder="Notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              <button onClick={() => create.mutate({ weddingId, name: form.name, category: form.category, estimatedPrice: parseFloat(form.estimatedPrice) || undefined, contactEmail: form.contactEmail || undefined, contactPhone: form.contactPhone || undefined, notes: form.notes || undefined })} disabled={!form.name || !form.category || create.isPending} className="btn-vision-primary text-sm disabled:opacity-50">Ajouter</button>
              <button onClick={() => setShowForm(false)} className="btn-vision-ghost text-sm">Annuler</button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {items.length === 0 ? (
            <div className="text-center py-12"><Users size={40} className="mx-auto mb-4 text-muted-foreground opacity-30" /><p className="text-muted-foreground">Aucun prestataire</p></div>
          ) : items.map((item: any) => (
            <div key={item.id} className="glass-card p-4">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-foreground font-semibold">{item.name}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full glass-subtle text-muted-foreground">{item.category}</span>
                    <span className={`text-xs font-semibold ${AVAIL_COLORS[item.availability || "tentative"]}`}>{AVAIL_LABELS[item.availability || "tentative"]}</span>
                  </div>
                  {item.contactEmail && <div className="text-muted-foreground text-xs">{item.contactEmail}</div>}
                  {item.contactPhone && <div className="text-muted-foreground text-xs">{item.contactPhone}</div>}
                  {item.notes && <div className="text-muted-foreground text-xs mt-1 italic">{item.notes}</div>}
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  {item.estimatedPrice && <span className="text-primary text-sm font-semibold">{parseFloat(String(item.estimatedPrice)).toLocaleString('fr-FR')}\u20ac</span>}
                  <select className="text-xs glass-subtle border border-border rounded-lg px-2 py-1 text-muted-foreground focus:border-primary outline-none" value={item.availability || "tentative"} onChange={e => update.mutate({ id: item.id, availability: e.target.value as any })}>
                    {Object.entries(AVAIL_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </select>
                  <select className="text-xs glass-subtle border border-border rounded-lg px-2 py-1 text-muted-foreground focus:border-primary outline-none" value={item.contractStatus || "none"} onChange={e => update.mutate({ id: item.id, contractStatus: e.target.value as any })}>
                    {Object.entries(CONTRACT_LABELS).map(([v, l]) => <option key={v} value={v}>Contrat: {l}</option>)}
                  </select>
                  <button onClick={() => del.mutate({ id: item.id })} className="text-muted-foreground hover:text-red-400 transition-colors"><Trash2 size={15} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
