import { AlertCircle, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background */}
      <div className="fixed inset-0 bg-[oklch(0.05_0.02_270)]">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-[oklch(0.25_0.15_280/0.15)] blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-[oklch(0.3_0.12_320/0.1)] blur-[100px]" />
      </div>

      <div className="relative z-10 text-center glass-card p-12 max-w-md mx-4">
        <div className="w-16 h-16 rounded-full bg-[oklch(0.35_0.15_25/0.2)] flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="w-8 h-8 text-[oklch(0.7_0.15_25)]" />
        </div>
        <h1 className="text-5xl font-bold text-white mb-3">404</h1>
        <p className="text-lg text-[oklch(0.7_0.03_270)] mb-2">Page introuvable</p>
        <p className="text-sm text-[oklch(0.5_0.03_270)] mb-8">
          Cette page n'existe pas ou a été déplacée.
        </p>
        <Link href="/">
          <button className="btn-vision-primary inline-flex items-center gap-2">
            <Home className="w-4 h-4" />
            Retour à l'accueil
          </button>
        </Link>
      </div>
    </div>
  );
}
