import { useState, lazy, Suspense } from "react";
import { useParams } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { CheckCircle2, XCircle, AlertTriangle, Info, Zap, Plus, Clock, Network } from "lucide-react";
import { toast } from "sonner";
const CausalGraph = lazy(() => import("@/components/CausalGraph"));

const SEVERITY_CONFIG = {
  critical: { label: "Critique", icon: AlertTriangle, cls: "bg-red-500/10 text-red-400 border-red-500/20" },
  warning: { label: "Attention", icon: Zap, cls: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  info: { label: "Info", icon: Info, cls: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
};

export default function CadranCausal() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"waves" | "graph">("waves");
  const [filter, setFilter] = useState<"all" | "pending" | "validated" | "rejected">("all");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newWave, setNewWave] = useState({ triggerDescription: "", ifCondition: "", thenEffect: "", becauseReason: "", severity: "warning" as "info" | "warning" | "critical" });
  const [decidingId, setDecidingId] = useState<number | null>(null);
  const [decisionNote, setDecisionNote] = useState("");

  const utils = trpc.useUtils();

  const { data: waves = [], isLoading } = trpc.causalWaves.list.useQuery(
    { weddingId, limit: 50 },
    { enabled: isAuthenticated && weddingId > 0, refetchInterval: 15000 }
  );

  const { data: overview } = trpc.dashboard.overview.useQuery(
    { weddingId },
    { enabled: isAuthenticated && weddingId > 0 }
  );

  const decide = trpc.causalWaves.decide.useMutation({
    onSuccess: () => {
      utils.causalWaves.list.invalidate({ weddingId });
      utils.dashboard.overview.invalidate({ weddingId });
      setDecidingId(null);
      setDecisionNote("");
      toast.success("Décision enregistrée dans le Journal de preuve");
    },
    onError: () => toast.error("Erreur lors de l'arbitrage"),
  });

  const createWave = trpc.causalWaves.create.useMutation({
    onSuccess: () => {
      utils.causalWaves.list.invalidate({ weddingId });
      setShowCreateForm(false);
      setNewWave({ triggerDescription: "", ifCondition: "", thenEffect: "", becauseReason: "", severity: "warning" });
      toast.success("Onde causale créée");
    },
  });

  const filteredWaves = waves.filter((w: any) => filter === "all" || w.status === filter);
  const pendingCount = waves.filter((w: any) => w.status === "pending").length;

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button>
      </div>
    );
  }

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Cadran Causal</h1>
            <p className="text-muted-foreground text-sm mt-1">Vue opérationnelle du graphe causal en temps réel</p>
          </div>
          <div className="flex items-center gap-3">
            {pendingCount > 0 && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-500/10 text-yellow-400 text-xs font-semibold border border-yellow-500/20">
                <AlertTriangle size={12} /> {pendingCount} en attente
              </div>
            )}
            <button onClick={() => setShowCreateForm(!showCreateForm)} className="btn-vision-primary flex items-center gap-2 text-sm">
              <Plus size={16} /> Nouvelle onde
            </button>
          </div>
        </div>

        {/* Tabs: Ondes / Graphe */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab("waves")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              activeTab === "waves"
                ? "bg-primary/20 text-primary border border-primary/30"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Zap size={14} /> Ondes causales
          </button>
          <button
            onClick={() => setActiveTab("graph")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              activeTab === "graph"
                ? "bg-primary/20 text-primary border border-primary/30"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Network size={14} /> Graphe causal
          </button>
        </div>

        {/* Graph view */}
        {activeTab === "graph" && (
          <div className="glass-card rounded-2xl overflow-hidden" style={{ height: 520, position: "relative" }}>
            <Suspense fallback={
              <div className="flex items-center justify-center h-full">
                <div className="text-muted-foreground text-sm">Chargement du graphe...</div>
              </div>
            }>
              <CausalGraph weddingId={weddingId} />
            </Suspense>
          </div>
        )}

        {activeTab === "waves" && <>

        {/* Stability score */}
        {overview && (
          <div className="glass-card p-5 flex items-center gap-6 flex-wrap">
            <div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Stabilité globale</div>
              <div className="flex items-center gap-3">
                <div className="text-3xl font-bold" style={{
                  color: (overview.stabilityScore ?? 100) > 70 ? 'oklch(0.68 0.14 145)' :
                    (overview.stabilityScore ?? 100) > 40 ? 'oklch(0.78 0.14 75)' : 'oklch(0.62 0.20 25)'
                }}>
                  {overview.stabilityScore ?? 100}%
                </div>
                <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-1000" style={{
                    width: `${overview.stabilityScore ?? 100}%`,
                    background: (overview.stabilityScore ?? 100) > 70 ? 'oklch(0.68 0.14 145)' :
                      (overview.stabilityScore ?? 100) > 40 ? 'oklch(0.78 0.14 75)' : 'oklch(0.62 0.20 25)'
                  }} />
                </div>
              </div>
            </div>
            <div className="w-px h-10 bg-border hidden md:block" />
            <div className="flex gap-6">
              {[
                { label: "Total", value: waves.length },
                { label: "En attente", value: pendingCount, alert: pendingCount > 0 },
                { label: "Validées", value: waves.filter((w: any) => w.status === "validated").length },
                { label: "Rejetées", value: waves.filter((w: any) => w.status === "rejected").length },
              ].map(({ label, value, alert }) => (
                <div key={label} className="text-center">
                  <div className={`text-xl font-bold ${alert ? "text-yellow-400" : "text-foreground"}`}>{value}</div>
                  <div className="text-xs text-muted-foreground">{label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Create form */}
        {showCreateForm && (
          <div className="glass-strong rounded-2xl p-6 space-y-4 animate-float-in">
            <h3 className="text-foreground font-semibold">Créer une onde causale manuellement</h3>
            <input className="input-vision" placeholder="Description du déclencheur..." value={newWave.triggerDescription} onChange={e => setNewWave(w => ({ ...w, triggerDescription: e.target.value }))} />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-semibold wave-si mb-1 block">SI (condition)</label>
                <textarea className="input-vision resize-none text-sm" rows={2} placeholder="Condition causale..." value={newWave.ifCondition} onChange={e => setNewWave(w => ({ ...w, ifCondition: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs font-semibold wave-alors mb-1 block">ALORS (effet)</label>
                <textarea className="input-vision resize-none text-sm" rows={2} placeholder="Conséquences directes..." value={newWave.thenEffect} onChange={e => setNewWave(w => ({ ...w, thenEffect: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs font-semibold wave-parce-que mb-1 block">PARCE QUE (raison)</label>
                <textarea className="input-vision resize-none text-sm" rows={2} placeholder="Raison causale..." value={newWave.becauseReason} onChange={e => setNewWave(w => ({ ...w, becauseReason: e.target.value }))} />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <select className="input-vision w-auto text-sm" value={newWave.severity} onChange={e => setNewWave(w => ({ ...w, severity: e.target.value as any }))}>
                <option value="info">Info</option>
                <option value="warning">Attention</option>
                <option value="critical">Critique</option>
              </select>
              <button onClick={() => createWave.mutate({ weddingId, ...newWave })} disabled={!newWave.triggerDescription || !newWave.ifCondition || !newWave.thenEffect || createWave.isPending} className="btn-vision-primary text-sm disabled:opacity-50">
                {createWave.isPending ? "Création..." : "Créer l'onde"}
              </button>
              <button onClick={() => setShowCreateForm(false)} className="btn-vision-ghost text-sm">Annuler</button>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          {(["all", "pending", "validated", "rejected"] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`rounded-full px-4 py-1.5 text-xs font-medium transition-all ${filter === f ? "glass-strong text-foreground glow-primary" : "glass-subtle text-muted-foreground hover:text-foreground"}`}>
              {f === "all" ? "Toutes" : f === "pending" ? "En attente" : f === "validated" ? "Validées" : "Rejetées"}
              {f === "pending" && pendingCount > 0 && <span className="ml-1.5 w-4 h-4 rounded-full bg-yellow-500 text-black text-xs inline-flex items-center justify-center font-bold">{pendingCount}</span>}
            </button>
          ))}
        </div>

        {/* Waves list */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredWaves.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-2xl glass-subtle flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">Aucune onde causale {filter !== "all" ? `(${filter})` : ""}</p>
            <p className="text-muted-foreground text-xs mt-1">Parlez à Ripple pour générer des analyses causales</p>
          </div>
        ) : (
          <div className="space-y-4 stagger-children">
            {filteredWaves.map((wave: any) => {
              const sev = SEVERITY_CONFIG[wave.severity as keyof typeof SEVERITY_CONFIG] || SEVERITY_CONFIG.warning;
              const SevIcon = sev.icon;
              const isPending = wave.status === "pending";
              const isDeciding = decidingId === wave.id;

              return (
                <div key={wave.id} className="wave-card">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold flex items-center gap-1 border ${sev.cls}`}>
                        <SevIcon size={10} /> {sev.label}
                      </span>
                      <span className={`text-xs font-medium ${
                        wave.status === "pending" ? "text-yellow-400" :
                        wave.status === "validated" ? "text-green-400" :
                        wave.status === "rejected" ? "text-red-400" : "text-muted-foreground"
                      }`}>
                        {wave.status === "pending" ? "En attente" : wave.status === "validated" ? "Validée" : wave.status === "rejected" ? "Rejetée" : wave.status}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock size={10} />
                        {new Date(wave.createdAt).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0">#{wave.id}</span>
                  </div>

                  {/* Trigger */}
                  <p className="text-foreground text-sm font-medium mb-3">{wave.triggerDescription}</p>

                  {/* SI ALORS PARCE QUE */}
                  <div className="space-y-2 mb-4 p-3 rounded-xl glass-subtle">
                    <div className="flex gap-3">
                      <span className="wave-si text-xs font-bold shrink-0 w-24">SI</span>
                      <span className="text-foreground/80 text-xs leading-relaxed">{wave.ifCondition}</span>
                    </div>
                    <div className="flex gap-3">
                      <span className="wave-alors text-xs font-bold shrink-0 w-24">ALORS</span>
                      <span className="text-foreground/80 text-xs leading-relaxed">{wave.thenEffect}</span>
                    </div>
                    <div className="flex gap-3">
                      <span className="wave-parce-que text-xs font-bold shrink-0 w-24">PARCE QUE</span>
                      <span className="text-foreground/70 text-xs leading-relaxed italic">{wave.becauseReason}</span>
                    </div>
                  </div>

                  {/* Human decision */}
                  {wave.humanDecision && (
                    <div className="mb-3 p-2 rounded-lg glass-subtle text-xs text-muted-foreground">
                      <span className="font-semibold text-foreground">Décision : </span>{wave.humanDecision}
                    </div>
                  )}

                  {/* Arbitration */}
                  {isPending && (
                    <div>
                      {isDeciding ? (
                        <div className="space-y-2">
                          <input className="input-vision text-xs" placeholder="Note de décision (optionnel)..." value={decisionNote} onChange={e => setDecisionNote(e.target.value)} autoFocus />
                          <div className="flex gap-2">
                            <button onClick={() => decide.mutate({ waveId: wave.id, decision: "validated", humanDecision: decisionNote || undefined })} disabled={decide.isPending} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl bg-green-500/10 text-green-400 border border-green-500/20 hover:bg-green-500/20 transition-all">
                              <CheckCircle2 size={13} /> Valider
                            </button>
                            <button onClick={() => decide.mutate({ waveId: wave.id, decision: "rejected", humanDecision: decisionNote || undefined })} disabled={decide.isPending} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-all">
                              <XCircle size={13} /> Rejeter
                            </button>
                            <button onClick={() => { setDecidingId(null); setDecisionNote(""); }} className="btn-vision-ghost text-xs">Annuler</button>
                          </div>
                        </div>
                      ) : (
                        <button onClick={() => setDecidingId(wave.id)} className="btn-vision text-xs flex items-center gap-1.5">
                          Arbitrer cette onde
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
        </> /* end activeTab === waves */}
      </div>
    </AppLayout>
  );
}
