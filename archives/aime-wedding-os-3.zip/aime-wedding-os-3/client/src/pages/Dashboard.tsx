import { useParams, useLocation, Link } from "wouter";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { MessageCircle, Compass, AlertTriangle, Users, Wallet, ClipboardList, ShieldAlert, TrendingUp, Zap } from "lucide-react";

export default function Dashboard() {
  const params = useParams<{ weddingId: string }>();
  const weddingId = parseInt(params.weddingId || "0");
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const { data: overview, isLoading } = trpc.dashboard.overview.useQuery(
    { weddingId },
    { enabled: isAuthenticated && weddingId > 0, refetchInterval: 30000 }
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <button onClick={() => startLogin()} className="btn-vision-primary">Se connecter</button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <AppLayout weddingId={weddingId}>
        <div className="flex items-center justify-center h-full">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </AppLayout>
    );
  }

  if (!overview) {
    return (
      <AppLayout weddingId={weddingId}>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">Mariage introuvable</p>
            <button onClick={() => navigate("/")} className="btn-vision-ghost">Retour</button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const { wedding, daysUntil, stats, pendingWaves } = overview;

  const stabilityColor = (score: number) => {
    if (score > 70) return "oklch(0.68 0.14 145)";
    if (score > 40) return "oklch(0.78 0.14 75)";
    return "oklch(0.62 0.20 25)";
  };

  return (
    <AppLayout weddingId={weddingId}>
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">{wedding.name}</h1>
            {wedding.venue && <p className="text-muted-foreground text-sm mt-1">{wedding.venue}</p>}
            {wedding.weddingDate && (
              <p className="text-primary text-sm mt-1 font-medium">
                {new Date(wedding.weddingDate).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
            )}
          </div>
          <div className="flex gap-3">
            <button onClick={() => navigate(`/w/${weddingId}/chat`)} className="btn-vision-primary flex items-center gap-2 text-sm">
              <MessageCircle size={16} /> Parler à Ripple
            </button>
            <button onClick={() => navigate(`/w/${weddingId}/cadran`)} className="btn-vision-ghost flex items-center gap-2 text-sm">
              <Compass size={16} /> Cadran Causal
            </button>
          </div>
        </div>

        {/* Stability + Countdown + Waves */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-card p-5 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{ background: `radial-gradient(circle at 30% 50%, ${stabilityColor(overview.stabilityScore ?? 100)}, transparent 70%)` }} />
            <div className="relative">
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Score de stabilité</div>
              <div className="flex items-end gap-3">
                <div className="text-5xl font-bold" style={{ color: stabilityColor(overview.stabilityScore ?? 100) }}>
                  {overview.stabilityScore ?? 100}
                </div>
                <div className="text-muted-foreground text-sm mb-1">/ 100</div>
              </div>
              <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${overview.stabilityScore ?? 100}%`, background: stabilityColor(overview.stabilityScore ?? 100) }} />
              </div>
              {overview.planBActive && (
                <div className="mt-3 flex items-center gap-2 text-orange-400 text-xs font-semibold">
                  <AlertTriangle size={12} /> Plan B activé
                </div>
              )}
            </div>
          </div>

          <div className="glass-card p-5">
            <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Jours restants</div>
            {daysUntil !== null ? (
              <>
                <div className="text-5xl font-bold text-primary">{Math.max(0, daysUntil)}</div>
                <div className="text-muted-foreground text-sm mt-1">
                  {daysUntil > 0 ? "jours avant le grand jour" : daysUntil === 0 ? "C'est aujourd'hui !" : "Mariage passé"}
                </div>
              </>
            ) : (
              <div className="text-muted-foreground text-sm">Date non définie</div>
            )}
          </div>

          <div className={`glass-card p-5 cursor-pointer transition-all ${pendingWaves.length > 0 ? "glow-primary" : ""}`} onClick={() => navigate(`/w/${weddingId}/cadran`)}>
            <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Ondes causales</div>
            <div className="flex items-end gap-2">
              <div className={`text-5xl font-bold ${pendingWaves.length > 0 ? "text-yellow-400" : "text-green-400"}`}>
                {pendingWaves.length}
              </div>
              <div className="text-muted-foreground text-sm mb-1">en attente</div>
            </div>
            {pendingWaves.length > 0 && (
              <div className="mt-2 text-xs text-yellow-400 font-medium flex items-center gap-1">
                <AlertTriangle size={11} /> Arbitrage requis
              </div>
            )}
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Acteurs", value: stats.actors, sub: `${stats.actorsConfirmed} confirmés`, icon: Users, path: "/acteurs", color: "text-purple-400" },
            { label: "Invités RSVP", value: stats.rsvpTotal, sub: `${stats.rsvpConfirmed} confirmés`, icon: ClipboardList, path: "/rsvp", color: "text-green-400" },
            { label: "Prestataires", value: stats.vendors, sub: `${stats.vendorsBooked} sous contrat`, icon: Users, path: "/prestataires", color: "text-primary" },
            { label: "Budget", value: `${stats.budgetPercent}%`, sub: `${stats.budgetSpent.toLocaleString('fr-FR')}\u20ac / ${stats.budgetTotal.toLocaleString('fr-FR')}\u20ac`, icon: Wallet, path: "/budget", color: stats.budgetPercent > 90 ? "text-red-400" : "text-primary" },
          ].map(({ label, value, sub, icon: Icon, path, color }) => (
            <div key={label} className="glass-card p-4 cursor-pointer hover:bg-white/5 transition-all" onClick={() => navigate(`/w/${weddingId}${path}`)}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground uppercase tracking-wider">{label}</span>
                <Icon size={14} className={color} />
              </div>
              <div className={`text-2xl font-bold ${color}`}>{value}</div>
              <div className="text-xs text-muted-foreground mt-1">{sub}</div>
            </div>
          ))}
        </div>

        {/* Pending waves */}
        {pendingWaves.length > 0 && (
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-foreground font-semibold flex items-center gap-2">
                <Zap size={16} className="text-yellow-400" /> Ondes en attente d'arbitrage
              </h2>
              <button onClick={() => navigate(`/w/${weddingId}/cadran`)} className="text-primary text-xs hover:underline">Voir toutes</button>
            </div>
            <div className="space-y-3">
              {pendingWaves.slice(0, 3).map((wave: any) => (
                <div key={wave.id} className="wave-card">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-semibold border ${
                          wave.severity === "critical" ? "bg-red-500/10 text-red-400 border-red-500/20" :
                          wave.severity === "info" ? "bg-blue-500/10 text-blue-400 border-blue-500/20" :
                          "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                        }`}>
                          {wave.severity === "critical" ? "Critique" : wave.severity === "info" ? "Info" : "Attention"}
                        </span>
                      </div>
                      <p className="text-foreground text-sm font-medium mb-2 truncate">{wave.triggerDescription}</p>
                      <div className="space-y-1">
                        <div className="flex gap-2 text-xs"><span className="wave-si shrink-0">SI</span><span className="text-foreground/70 truncate">{wave.ifCondition}</span></div>
                        <div className="flex gap-2 text-xs"><span className="wave-alors shrink-0">ALORS</span><span className="text-foreground/70 truncate">{wave.thenEffect}</span></div>
                      </div>
                    </div>
                    <button onClick={() => navigate(`/w/${weddingId}/cadran`)} className="btn-vision-ghost text-xs shrink-0">Arbitrer</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick access */}
        <div className="glass-card p-5">
          <h2 className="text-foreground font-semibold mb-4">Accès rapide</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Bureau Chat", icon: MessageCircle, path: "/chat", desc: "Agent Ripple" },
              { label: "Cadran Causal", icon: Compass, path: "/cadran", desc: "Vue opérationnelle" },
              { label: "Plan B", icon: ShieldAlert, path: "/planb", desc: "Scénarios de risque" },
              { label: "Journal", icon: TrendingUp, path: "/journal", desc: "Historique rejouable" },
            ].map(({ label, icon: Icon, path, desc }) => (
              <button key={path} onClick={() => navigate(`/w/${weddingId}${path}`)} className="glass-subtle rounded-xl p-4 text-left hover:bg-white/5 transition-all group">
                <Icon size={20} className="text-primary mb-3 group-hover:scale-110 transition-transform" />
                <div className="text-foreground text-sm font-medium">{label}</div>
                <div className="text-muted-foreground text-xs mt-0.5">{desc}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
