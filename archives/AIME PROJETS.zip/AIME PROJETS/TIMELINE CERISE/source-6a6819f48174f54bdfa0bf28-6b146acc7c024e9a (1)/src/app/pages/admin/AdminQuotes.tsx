import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plus, FileSignature, Send, CheckCheck, CreditCard,
  Trash2, ChevronRight, X, PenLine, User, Calendar, MapPin, Clock, StickyNote,
} from 'lucide-react';
import {
  adminGet, adminPost, adminPut, adminDel,
  fmtEur, fmtDate, QUOTE_STATUS, CONTRACT_STATUS,
  type AdminQuote, type AdminContract,
} from '../../lib/adminApi';

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
const inp = 'w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors';

// ── Pipeline step indicator ───────────────────────────────────────────────────
const PIPELINE = ['Brouillon', 'Envoyé', 'Accepté', 'Contrat', 'Signé', 'Acompte', 'Confirmé'];

function PipelineBar({ step }: { step: number }) {
  return (
    <div className="flex items-center gap-1 mb-6">
      {PIPELINE.map((label, i) => (
        <div key={label} className="flex items-center gap-1 flex-1 min-w-0">
          <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
            i < step ? 'bg-black text-white' : i === step ? 'bg-black text-white ring-2 ring-black ring-offset-2' : 'bg-gray-100 text-gray-400'
          }`}>
            {i < step ? '✓' : i + 1}
          </div>
          <span className={`text-[9px] font-medium truncate ${i <= step ? 'text-black' : 'text-gray-400'}`}>{label}</span>
          {i < PIPELINE.length - 1 && (
            <div className={`h-px flex-1 min-w-2 transition-colors ${i < step ? 'bg-black' : 'bg-gray-200'}`} />
          )}
        </div>
      ))}
    </div>
  );
}

function quoteStep(q: AdminQuote, c?: AdminContract | null): number {
  if (q.status === 'draft')    return 0;
  if (q.status === 'sent')     return 1;
  if (!c)                      return q.status === 'accepted' ? 2 : 0;
  if (c.status === 'draft' || c.status === 'sent') return 3;
  if (c.status === 'client_signed') return 4;
  if (c.status === 'fully_signed')  return 4;
  if (c.status === 'deposit_paid' || c.status === 'confirmed') return 6;
  return 3;
}

// ── Empty form ────────────────────────────────────────────────────────────────
const EMPTY_FORM = {
  clientName: '', clientEmail: '', clientPhone: '',
  eventDate: '', eventVenue: '', service: 'Matt Mez Sax',
  duration: 3, amount: 0, deposit: 0, notes: '',
};

export default function AdminQuotes() {
  const [quotes,    setQuotes]    = useState<AdminQuote[]>([]);
  const [contracts, setContracts] = useState<AdminContract[]>([]);
  const [selected,  setSelected]  = useState<AdminQuote | null>(null);
  const [contract,  setContract]  = useState<AdminContract | null>(null);
  const [showForm,  setShowForm]  = useState(false);
  const [form,      setForm]      = useState(EMPTY_FORM);
  const [loading,   setLoading]   = useState(true);
  const [saving,    setSaving]    = useState(false);
  const [tab,       setTab]       = useState<'quotes' | 'contracts'>('quotes');

  const load = async () => {
    const [qRes, cRes] = await Promise.all([adminGet('/quotes'), adminGet('/contracts')]);
    const [qData, cData] = await Promise.all([qRes.json(), cRes.json()]);
    setQuotes(qData.quotes ?? []);
    setContracts(cData.contracts ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  // Auto-calc deposit (30%)
  const updForm = (patch: Partial<typeof EMPTY_FORM>) => {
    setForm(f => {
      const next = { ...f, ...patch };
      if ('amount' in patch && !('deposit' in patch))
        next.deposit = Math.round(next.amount * 0.3);
      return next;
    });
  };

  const selectQuote = (q: AdminQuote) => {
    setSelected(q);
    const c = contracts.find(ct => ct.quoteId === q.id) ?? null;
    setContract(c);
    setShowForm(false);
  };

  const createQuote = async () => {
    setSaving(true);
    const res = await adminPost('/quotes', form);
    const data = await res.json();
    setQuotes(p => [data.quote, ...p]);
    setSelected(data.quote);
    setContract(null);
    setShowForm(false);
    setForm(EMPTY_FORM);
    setSaving(false);
  };

  const updateQuoteStatus = async (status: AdminQuote['status']) => {
    if (!selected) return;
    const res  = await adminPut(`/quotes/${selected.id}`, { status });
    const data = await res.json();
    setQuotes(p => p.map(q => q.id === selected.id ? data.quote : q));
    setSelected(data.quote);
  };

  const generateContract = async () => {
    if (!selected) return;
    setSaving(true);
    const res  = await adminPost(`/quotes/${selected.id}/contract`, {});
    const data = await res.json();
    setContracts(p => [data.contract, ...p]);
    setContract(data.contract);
    setQuotes(p => p.map(q => q.id === selected.id ? { ...q, contractId: data.contract.id, status: 'accepted' } : q));
    setSelected(q => q ? { ...q, contractId: data.contract.id, status: 'accepted' } : q);
    setSaving(false);
  };

  const signContract = async (party: 'client' | 'vendor') => {
    if (!contract) return;
    const res  = await adminPost(`/contracts/${contract.id}/sign`, { party });
    const data = await res.json();
    setContract(data.contract);
    setContracts(p => p.map(c => c.id === contract.id ? data.contract : c));
  };

  const markDeposit = async () => {
    if (!contract) return;
    const res  = await adminPost(`/contracts/${contract.id}/deposit`, {});
    const data = await res.json();
    setContract(data.contract);
    setContracts(p => p.map(c => c.id === contract.id ? data.contract : c));
  };

  const deleteQuote = async (id: string) => {
    await adminDel(`/quotes/${id}`);
    setQuotes(p => p.filter(q => q.id !== id));
    if (selected?.id === id) { setSelected(null); setContract(null); }
  };

  const step = selected ? quoteStep(selected, contract) : 0;

  return (
    <div className="flex h-full">

      {/* ── LEFT: List ─────────────────────────────────────────────────────── */}
      <div className="w-72 flex-shrink-0 bg-white border-r border-gray-100 flex flex-col">

        {/* Header */}
        <div className="px-4 py-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h1 className="font-semibold text-sm text-black">Devis & Contrats</h1>
            <button
              onClick={() => { setShowForm(true); setSelected(null); setForm(EMPTY_FORM); }}
              className="w-7 h-7 bg-black rounded-lg flex items-center justify-center hover:bg-gray-800 transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
          {/* Tabs */}
          <div className="flex bg-gray-100 rounded-xl p-0.5">
            {(['quotes', 'contracts'] as const).map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-1 text-xs py-1.5 rounded-[10px] font-medium transition-all ${tab === t ? 'bg-white text-black shadow-sm' : 'text-gray-400'}`}>
                {t === 'quotes' ? `Devis (${quotes.length})` : `Contrats (${contracts.length})`}
              </button>
            ))}
          </div>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="p-4 space-y-2">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-50 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : tab === 'quotes' ? (
            quotes.length === 0 ? (
              <div className="p-6 text-center text-xs text-gray-400">
                Aucun devis.<br />
                <button onClick={() => setShowForm(true)} className="mt-2 text-black font-medium hover:underline">
                  Créer le premier →
                </button>
              </div>
            ) : (
              quotes.map(q => (
                <button
                  key={q.id}
                  onClick={() => selectQuote(q)}
                  className={`w-full text-left px-4 py-3.5 border-b border-gray-50 hover:bg-gray-50/70 transition-colors ${selected?.id === q.id ? 'bg-gray-50 border-l-2 border-l-black' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-black truncate">{q.clientName || 'Sans nom'}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full flex-shrink-0 ml-2 ${QUOTE_STATUS[q.status].color}`}>
                      {QUOTE_STATUS[q.status].label}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 truncate">{fmtDate(q.eventDate)} · {q.service}</p>
                  <p className="text-xs font-semibold text-black mt-0.5">{fmtEur(q.amount)}</p>
                </button>
              ))
            )
          ) : (
            contracts.length === 0 ? (
              <div className="p-6 text-center text-xs text-gray-400">Aucun contrat.</div>
            ) : (
              contracts.map(c => (
                <button
                  key={c.id}
                  onClick={() => {
                    const q = quotes.find(q => q.id === c.quoteId);
                    if (q) selectQuote(q);
                  }}
                  className={`w-full text-left px-4 py-3.5 border-b border-gray-50 hover:bg-gray-50/70 transition-colors ${contract?.id === c.id ? 'bg-gray-50' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-black truncate">{c.clientName}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full flex-shrink-0 ml-2 ${CONTRACT_STATUS[c.status].color}`}>
                      {CONTRACT_STATUS[c.status].label}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">{fmtDate(c.eventDate)} · {c.eventVenue}</p>
                  <p className="text-xs font-semibold text-black mt-0.5">{fmtEur(c.amount)}</p>
                </button>
              ))
            )
          )}
        </div>
      </div>

      {/* ── RIGHT: Detail / Form ──────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto bg-[#F9F8F6]">
        <AnimatePresence mode="wait">

          {/* New quote form */}
          {showForm && (
            <motion.div key="form" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
              className="p-8 max-w-2xl mx-auto">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black" style={{ fontFamily: "'Inter', sans-serif" }}>Nouveau devis</h2>
                <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                  <X className="w-4 h-4 text-gray-500" />
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  {/* Client */}
                  <div className="sm:col-span-2">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <User className="w-3 h-3" /> Client
                    </p>
                    <div className="grid sm:grid-cols-3 gap-3">
                      <input className={inp} placeholder="Nom complet" value={form.clientName} onChange={e => updForm({ clientName: e.target.value })} />
                      <input className={inp} placeholder="Email" type="email" value={form.clientEmail} onChange={e => updForm({ clientEmail: e.target.value })} />
                      <input className={inp} placeholder="Téléphone" value={form.clientPhone} onChange={e => updForm({ clientPhone: e.target.value })} />
                    </div>
                  </div>
                  {/* Event */}
                  <div className="sm:col-span-2">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Calendar className="w-3 h-3" /> Événement
                    </p>
                    <div className="grid sm:grid-cols-3 gap-3">
                      <input className={inp} type="date" value={form.eventDate} onChange={e => updForm({ eventDate: e.target.value })} />
                      <input className={inp} placeholder="Lieu / Domaine" value={form.eventVenue} onChange={e => updForm({ eventVenue: e.target.value })} />
                      <input className={inp} placeholder="Service" value={form.service} onChange={e => updForm({ service: e.target.value })} />
                    </div>
                  </div>
                  {/* Financier */}
                  <div className="sm:col-span-2">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Clock className="w-3 h-3" /> Prestation & Tarifs
                    </p>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="relative">
                        <input className={`${inp} pr-8`} type="number" placeholder="Durée" value={form.duration} onChange={e => updForm({ duration: +e.target.value })} />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">h</span>
                      </div>
                      <div className="relative">
                        <input className={`${inp} pr-7`} type="number" placeholder="Montant HT" value={form.amount || ''} onChange={e => updForm({ amount: +e.target.value })} />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">€</span>
                      </div>
                      <div className="relative">
                        <input className={`${inp} pr-7`} type="number" placeholder="Acompte (30%)" value={form.deposit || ''} onChange={e => updForm({ deposit: +e.target.value })} />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">€</span>
                      </div>
                    </div>
                  </div>
                  {/* Notes */}
                  <div className="sm:col-span-2">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <StickyNote className="w-3 h-3" /> Notes internes
                    </p>
                    <textarea rows={3} className={`${inp} resize-none`} placeholder="Informations supplémentaires…"
                      value={form.notes} onChange={e => updForm({ notes: e.target.value })} />
                  </div>
                </div>
                <div className="flex justify-end pt-2">
                  <button
                    onClick={createQuote}
                    disabled={!form.clientName || !form.eventDate || saving}
                    className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:bg-gray-800 disabled:opacity-40 transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    {saving ? 'Création…' : 'Créer le devis'}
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Quote detail */}
          {selected && !showForm && (
            <motion.div key={selected.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
              className="p-8 max-w-2xl mx-auto">

              {/* Pipeline */}
              <PipelineBar step={step} />

              {/* Header */}
              <div className="flex items-start justify-between mb-5">
                <div>
                  <h2 className="text-2xl font-semibold text-black" style={{ fontFamily: "'Inter', sans-serif" }}>
                    {selected.clientName || 'Client sans nom'}
                  </h2>
                  <p className="text-sm text-gray-500 mt-0.5">{selected.service} · {fmtDate(selected.eventDate)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2.5 py-1.5 rounded-xl font-semibold ${QUOTE_STATUS[selected.status].color}`}>
                    {QUOTE_STATUS[selected.status].label}
                  </span>
                  <button onClick={() => deleteQuote(selected.id)}
                    className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Info cards */}
              <div className="grid grid-cols-2 gap-3 mb-5">
                {[
                  { icon: User,    label: 'Email',    value: selected.clientEmail },
                  { icon: User,    label: 'Téléphone', value: selected.clientPhone || '—' },
                  { icon: Calendar, label: 'Date',    value: fmtDate(selected.eventDate) },
                  { icon: MapPin,  label: 'Lieu',     value: selected.eventVenue || '—' },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="bg-white rounded-xl border border-gray-100 p-3.5">
                    <p className="text-xs text-gray-400 mb-0.5">{label}</p>
                    <p className="text-sm font-medium text-black truncate">{value}</p>
                  </div>
                ))}
              </div>

              {/* Amount */}
              <div className="bg-black text-white rounded-2xl p-5 mb-5 flex items-center justify-between">
                <div>
                  <p className="text-xs text-white/50 mb-1">Montant total</p>
                  <p className="text-3xl font-bold">{fmtEur(selected.amount)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-white/50 mb-1">Acompte (30%)</p>
                  <p className="text-xl font-semibold">{fmtEur(selected.deposit)}</p>
                </div>
              </div>

              {/* Notes */}
              {selected.notes && (
                <div className="bg-white rounded-xl border border-gray-100 p-4 mb-5">
                  <p className="text-xs text-gray-400 mb-1">Notes</p>
                  <p className="text-sm text-gray-700">{selected.notes}</p>
                </div>
              )}

              {/* ── Actions pipeline ──────────────────────────────────── */}
              <div className="space-y-3">

                {/* Step 1: Envoyer devis */}
                {selected.status === 'draft' && (
                  <button onClick={() => updateQuoteStatus('sent')}
                    className="w-full flex items-center justify-between px-5 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl transition-colors font-semibold">
                    <div className="flex items-center gap-3">
                      <Send className="w-5 h-5" />
                      <div className="text-left">
                        <p className="font-semibold">Marquer comme envoyé</p>
                        <p className="text-xs text-blue-100">Devis transmis au client</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}

                {/* Step 2: Générer contrat */}
                {(selected.status === 'sent' || selected.status === 'accepted') && !selected.contractId && (
                  <button onClick={generateContract} disabled={saving}
                    className="w-full flex items-center justify-between px-5 py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-2xl transition-colors disabled:opacity-60">
                    <div className="flex items-center gap-3">
                      <FileSignature className="w-5 h-5" />
                      <div className="text-left">
                        <p className="font-semibold">Générer le contrat</p>
                        <p className="text-xs text-purple-100">Créer le contrat à partir du devis</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}

                {/* Refused */}
                {selected.status === 'sent' && (
                  <button onClick={() => updateQuoteStatus('refused')}
                    className="w-full flex items-center gap-3 px-5 py-3 border border-red-200 text-red-500 hover:bg-red-50 rounded-2xl transition-colors text-sm">
                    <X className="w-4 h-4" /> Marquer comme refusé
                  </button>
                )}

                {/* Contract section */}
                {contract && (
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
                      <div>
                        <p className="text-xs text-gray-400 mb-0.5">Contrat généré</p>
                        <p className="text-sm font-semibold text-black">{contract.clientName}</p>
                      </div>
                      <span className={`text-xs px-2.5 py-1 rounded-xl font-semibold ${CONTRACT_STATUS[contract.status].color}`}>
                        {CONTRACT_STATUS[contract.status].label}
                      </span>
                    </div>

                    {/* Signing */}
                    <div className="p-4 space-y-2.5">
                      <div className={`flex items-center justify-between p-3 rounded-xl border ${contract.clientSignedAt ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                        <div className="flex items-center gap-2.5">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${contract.clientSignedAt ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                            {contract.clientSignedAt ? '✓' : '1'}
                          </div>
                          <div>
                            <p className="text-xs font-medium text-black">Signature client</p>
                            {contract.clientSignedAt && <p className="text-[10px] text-gray-400">{fmtDate(contract.clientSignedAt)}</p>}
                          </div>
                        </div>
                        {!contract.clientSignedAt && (
                          <button onClick={() => signContract('client')}
                            className="text-xs font-semibold bg-black text-white px-3 py-1.5 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-1">
                            <PenLine className="w-3 h-3" /> Signer
                          </button>
                        )}
                      </div>

                      <div className={`flex items-center justify-between p-3 rounded-xl border ${contract.vendorSignedAt ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                        <div className="flex items-center gap-2.5">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${contract.vendorSignedAt ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                            {contract.vendorSignedAt ? '✓' : '2'}
                          </div>
                          <div>
                            <p className="text-xs font-medium text-black">Ma signature (Matt)</p>
                            {contract.vendorSignedAt && <p className="text-[10px] text-gray-400">{fmtDate(contract.vendorSignedAt)}</p>}
                          </div>
                        </div>
                        {!contract.vendorSignedAt && (
                          <button onClick={() => signContract('vendor')}
                            className="text-xs font-semibold bg-black text-white px-3 py-1.5 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-1">
                            <CheckCheck className="w-3 h-3" /> Signer
                          </button>
                        )}
                      </div>

                      {/* Deposit */}
                      {contract.status === 'fully_signed' && !contract.depositPaidAt && (
                        <button onClick={markDeposit}
                          className="w-full flex items-center justify-between px-4 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl transition-colors">
                          <div className="flex items-center gap-2.5">
                            <CreditCard className="w-4 h-4" />
                            <div>
                              <p className="text-xs font-semibold">Acompte reçu</p>
                              <p className="text-[10px] text-teal-100">{fmtEur(contract.deposit)}</p>
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      )}

                      {contract.status === 'confirmed' && (
                        <div className="flex items-center gap-2.5 px-4 py-3 bg-green-50 border border-green-200 rounded-xl">
                          <CheckCheck className="w-4 h-4 text-green-600" />
                          <div>
                            <p className="text-xs font-semibold text-green-700">Prestation confirmée</p>
                            <p className="text-[10px] text-green-500">Acompte reçu le {fmtDate(contract.depositPaidAt!)}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* Empty state */}
          {!selected && !showForm && (
            <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center h-full min-h-96 text-center p-8">
              <div className="w-14 h-14 bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
                <FileSignature className="w-7 h-7 text-gray-400" />
              </div>
              <p className="text-base font-semibold text-black mb-1">Sélectionnez un devis</p>
              <p className="text-sm text-gray-400 mb-4">ou créez-en un nouveau pour démarrer</p>
              <button
                onClick={() => setShowForm(true)}
                className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-800 transition-colors"
              >
                <Plus className="w-4 h-4" /> Nouveau devis
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
