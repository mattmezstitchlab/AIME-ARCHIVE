import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Save, Check, Plus, Trash2, Send, Bot, Zap, RefreshCw } from 'lucide-react';
import { adminGet, adminPut, adminPost, type CeriseConfig } from '../../lib/adminApi';
import { AimeLogoIcon } from '../../components/AimeLogoIcon';

const inp = 'w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors';

type TestMsg = { role: 'user' | 'cerise'; text: string; loading?: boolean };

const DEFAULT: CeriseConfig = {
  systemPrompt: 'Tu es Cerise, l\'assistante mariage de AIME.',
  temperature: 0.7,
  rules: [],
  examples: [],
};

export default function AdminCerise() {
  const [config,  setConfig]  = useState<CeriseConfig>(DEFAULT);
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [saved,   setSaved]   = useState(false);
  const [tab,     setTab]     = useState<'prompt' | 'rules' | 'examples' | 'test'>('prompt');

  // Live test state
  const [msgs,     setMsgs]     = useState<TestMsg[]>([]);
  const [testInput, setTestInput] = useState('');
  const [testing,   setTesting]   = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    adminGet('/cerise-config')
      .then(r => r.json())
      .then(d => setConfig({ ...DEFAULT, ...d.config }))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs]);

  const save = async () => {
    setSaving(true);
    await adminPut('/cerise-config', config);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    setSaving(false);
  };

  const upd = (patch: Partial<CeriseConfig>) => setConfig(c => ({ ...c, ...patch }));

  const updRule = (i: number, val: string) => {
    const r = [...config.rules]; r[i] = val; upd({ rules: r });
  };

  const sendTest = async () => {
    if (!testInput.trim() || testing) return;
    const userText = testInput.trim();
    setTestInput('');
    setTesting(true);
    setMsgs(m => [...m, { role: 'user', text: userText }, { role: 'cerise', text: '', loading: true }]);

    try {
      const res  = await adminPost('/cerise-test', { message: userText, systemPrompt: config.systemPrompt });
      const data = await res.json();
      setMsgs(m => [...m.filter(x => !x.loading), { role: 'cerise', text: data.response || data.error || '…' }]);
    } catch (e) {
      setMsgs(m => [...m.filter(x => !x.loading), { role: 'cerise', text: `Erreur: ${e}` }]);
    }
    setTesting(false);
  };

  if (loading) return (
    <div className="p-8 flex items-center justify-center min-h-64">
      <div className="w-6 h-6 border-2 border-gray-200 border-t-gray-500 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="p-8 max-w-4xl mx-auto">

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-xs font-bold text-gray-400 tracking-[0.2em] uppercase mb-1">Intelligence artificielle</p>
          <h1 style={{ fontFamily: "'Inter', sans-serif" }} className="text-3xl font-semibold text-black">
            Paramètres Cerise
          </h1>
          <p className="text-sm text-gray-500 mt-1">Prompt système · Règles · Comportement · Test live</p>
        </div>
        <button
          onClick={save} disabled={saving}
          className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-800 disabled:opacity-50 transition-all"
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          {saving ? 'Sauvegarde…' : saved ? 'Sauvegardé !' : 'Sauvegarder'}
        </button>
      </div>

      {/* Status card */}
      <div className="bg-black rounded-2xl p-4 mb-6 flex items-center gap-4">
        <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
          <AimeLogoIcon size={14} color="white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white">Cerise · Claude Sonnet 4.5</p>
          <p className="text-xs text-white/40">Modèle actif · Température : {config.temperature}</p>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-xs text-green-400">En ligne</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-white border border-gray-100 rounded-2xl p-1 mb-6 shadow-sm">
        {(['prompt', 'rules', 'examples', 'test'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 text-xs py-2 rounded-xl font-medium transition-all capitalize ${
              tab === t ? 'bg-black text-white shadow-sm' : 'text-gray-400 hover:text-black'
            }`}
          >
            {t === 'prompt' ? '📝 Prompt' : t === 'rules' ? '📋 Règles' : t === 'examples' ? '💬 Exemples' : '⚡ Test live'}
          </button>
        ))}
      </div>

      <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>

        {/* ── Prompt ──────────────────────────────────────────────────── */}
        {tab === 'prompt' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <Bot className="w-4 h-4 text-gray-400" />
                <h2 className="text-sm font-semibold text-black">System Prompt</h2>
              </div>
              <textarea
                rows={16}
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors resize-none font-mono leading-relaxed"
                value={config.systemPrompt}
                onChange={e => upd({ systemPrompt: e.target.value })}
                placeholder="Tu es Cerise, l'assistante mariage de AIME…"
              />
              <div className="flex items-center justify-between mt-3">
                <p className="text-xs text-gray-400">{config.systemPrompt.length} caractères</p>
                <div className="flex items-center gap-2">
                  <label className="text-xs text-gray-500 font-medium">Température :</label>
                  <input
                    type="range" min="0" max="1" step="0.05"
                    value={config.temperature}
                    onChange={e => upd({ temperature: +e.target.value })}
                    className="w-24 accent-black"
                  />
                  <span className="text-xs font-semibold text-black w-8">{config.temperature}</span>
                </div>
              </div>
            </div>

            {/* Temperature guide */}
            <div className="grid grid-cols-3 gap-3 text-xs text-gray-500">
              <div className={`rounded-xl border p-3 ${config.temperature <= 0.3 ? 'border-black bg-black text-white' : 'border-gray-100 bg-white'}`}>
                <p className="font-semibold mb-1">0 – 0.3 · Précis</p>
                <p className={config.temperature <= 0.3 ? 'text-white/70' : ''}>Réponses déterministes, répétables.</p>
              </div>
              <div className={`rounded-xl border p-3 ${config.temperature > 0.3 && config.temperature <= 0.7 ? 'border-black bg-black text-white' : 'border-gray-100 bg-white'}`}>
                <p className="font-semibold mb-1">0.4 – 0.7 · Équilibré ✓</p>
                <p className={config.temperature > 0.3 && config.temperature <= 0.7 ? 'text-white/70' : ''}>Recommandé pour Cerise.</p>
              </div>
              <div className={`rounded-xl border p-3 ${config.temperature > 0.7 ? 'border-black bg-black text-white' : 'border-gray-100 bg-white'}`}>
                <p className="font-semibold mb-1">0.8 – 1 · Créatif</p>
                <p className={config.temperature > 0.7 ? 'text-white/70' : ''}>Plus varié, moins prévisible.</p>
              </div>
            </div>
          </div>
        )}

        {/* ── Rules ───────────────────────────────────────────────────── */}
        {tab === 'rules' && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-sm font-semibold text-black">Règles de comportement</h2>
                <p className="text-xs text-gray-400 mt-0.5">Instructions qui guident les réponses de Cerise</p>
              </div>
              <button
                onClick={() => upd({ rules: [...config.rules, ''] })}
                className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 px-3 py-1.5 rounded-lg transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> Ajouter
              </button>
            </div>
            <div className="space-y-2.5">
              {config.rules.map((rule, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                  className="flex gap-2 items-center">
                  <div className="w-5 h-5 bg-black text-white rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                    {i + 1}
                  </div>
                  <input className={`${inp} flex-1`} value={rule}
                    onChange={e => updRule(i, e.target.value)}
                    placeholder="Réponses courtes (2 phrases max)…" />
                  <button onClick={() => upd({ rules: config.rules.filter((_, j) => j !== i) })}
                    className="p-1.5 text-gray-300 hover:text-red-500 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </motion.div>
              ))}
              {!config.rules.length && (
                <p className="text-sm text-gray-400 text-center py-6">Aucune règle. Ajoutez-en une.</p>
              )}
            </div>
          </div>
        )}

        {/* ── Examples ────────────────────────────────────────────────── */}
        {tab === 'examples' && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-sm font-semibold text-black">Exemples de réponses</h2>
                <p className="text-xs text-gray-400 mt-0.5">Few-shot examples pour calibrer le ton</p>
              </div>
              <button
                onClick={() => upd({ examples: [...config.examples, { user: '', assistant: '' }] })}
                className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 px-3 py-1.5 rounded-lg transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> Ajouter
              </button>
            </div>
            <div className="space-y-4">
              {config.examples.map((ex, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                  className="bg-gray-50 rounded-xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Exemple {i + 1}</span>
                    <button onClick={() => upd({ examples: config.examples.filter((_, j) => j !== i) })}
                      className="p-1 text-gray-300 hover:text-red-500 transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 mb-1">👤 Utilisateur</p>
                    <input className={inp} value={ex.user} placeholder="Ajoute un DJ pour la soirée"
                      onChange={e => { const a = [...config.examples]; a[i] = { ...a[i], user: e.target.value }; upd({ examples: a }); }} />
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 mb-1">🍒 Cerise répond</p>
                    <textarea rows={2} className={`${inp} resize-none`} value={ex.assistant}
                      placeholder="DJ ajouté à 21h30. On lui attribue 4h ?"
                      onChange={e => { const a = [...config.examples]; a[i] = { ...a[i], assistant: e.target.value }; upd({ examples: a }); }} />
                  </div>
                </motion.div>
              ))}
              {!config.examples.length && (
                <p className="text-sm text-gray-400 text-center py-6">Aucun exemple.</p>
              )}
            </div>
          </div>
        )}

        {/* ── Test Live ───────────────────────────────────────────────── */}
        {tab === 'test' && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden" style={{ height: '520px', display: 'flex', flexDirection: 'column' }}>
            {/* Header */}
            <div className="px-5 py-4 border-b border-gray-100 bg-black flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <AimeLogoIcon size={14} color="white" />
                <div>
                  <p className="text-xs font-bold text-white">Cerise — Test live</p>
                  <p className="text-[10px] text-white/40">Prompt actuel (non sauvegardé si modifié)</p>
                </div>
              </div>
              <button onClick={() => setMsgs([])} className="text-white/40 hover:text-white transition-colors">
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {msgs.length === 0 && (
                <div className="text-center py-8">
                  <Zap className="w-8 h-8 text-gray-200 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">Testez Cerise avec votre prompt actuel.</p>
                  <p className="text-xs text-gray-300 mt-1">Les modifications non sauvegardées sont prises en compte.</p>
                </div>
              )}
              <AnimatePresence>
                {msgs.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.loading ? (
                      <div className="bg-gray-100 rounded-2xl rounded-tl-sm px-4 py-3 flex gap-1 items-center">
                        {[0,1,2].map(j => (
                          <motion.div key={j} className="w-1.5 h-1.5 bg-gray-400 rounded-full"
                            animate={{ y: [0, -4, 0] }}
                            transition={{ duration: 0.6, repeat: Infinity, delay: j * 0.12 }} />
                        ))}
                      </div>
                    ) : (
                      <div className={`max-w-[80%] text-sm px-4 py-2.5 rounded-2xl leading-relaxed whitespace-pre-wrap ${
                        msg.role === 'user'
                          ? 'bg-black text-white rounded-tr-sm'
                          : 'bg-gray-100 text-gray-800 rounded-tl-sm'
                      }`}>
                        {msg.text}
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className="px-4 py-3 border-t border-gray-100 flex gap-2">
              <input
                className="flex-1 border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-400 transition-colors"
                placeholder="Ajoute un DJ pour la soirée…"
                value={testInput}
                onChange={e => setTestInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendTest()}
                disabled={testing}
              />
              <button
                onClick={sendTest}
                disabled={!testInput.trim() || testing}
                className="w-10 h-10 bg-black rounded-xl flex items-center justify-center hover:bg-gray-800 disabled:opacity-40 transition-all flex-shrink-0"
              >
                <Send className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
