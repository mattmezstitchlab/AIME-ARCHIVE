import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Save, Check, Plus, Trash2, Play, Music2 } from 'lucide-react';
import { adminGet, adminPut, type SiteContent } from '../../lib/adminApi';

const inp  = 'w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors';
const ta   = 'w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors resize-none';

const DEFAULT: SiteContent = {
  heroTitle: 'Décrivez votre mariage.\nOn s\'occupe du reste.',
  heroSubtitle: 'Cerise organise, structure et guide chaque étape.',
  heroCta: 'Créer mon organisation',
  videoUrl: '',
  hymneUrl: '',
  taglines: [],
  philosophie: '"Comprendre. Structurer. Vérifier. Avancer."',
  footerTagline: 'Comprendre. Structurer. Vérifier. Avancer.',
};

const TABS = ['Hero', 'Vidéo & Médias', 'Paroles', 'Footer'] as const;
type Tab = typeof TABS[number];

export default function AdminContent() {
  const [content, setContent] = useState<SiteContent>(DEFAULT);
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [saved,   setSaved]   = useState(false);
  const [tab,     setTab]     = useState<Tab>('Hero');

  useEffect(() => {
    adminGet('/content')
      .then(r => r.json())
      .then(d => setContent({ ...DEFAULT, ...d.content }))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    setSaving(true);
    await adminPut('/content', content);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    setSaving(false);
  };

  const upd = (patch: Partial<SiteContent>) => setContent(c => ({ ...c, ...patch }));

  const updTagline = (i: number, val: string) => {
    const t = [...content.taglines]; t[i] = val; upd({ taglines: t });
  };

  if (loading) return (
    <div className="p-8 flex items-center justify-center min-h-64">
      <div className="w-6 h-6 border-2 border-gray-200 border-t-gray-500 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="p-8 max-w-3xl mx-auto">

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-xs font-bold text-gray-400 tracking-[0.2em] uppercase mb-1">Site public</p>
          <h1 style={{ fontFamily: "'Inter', sans-serif" }} className="text-3xl font-semibold text-black">
            Contenu du site
          </h1>
          <p className="text-sm text-gray-500 mt-1">Éditez les textes et médias affichés sur aime.fr</p>
        </div>
        <button
          onClick={save} disabled={saving}
          className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-800 disabled:opacity-50 transition-all"
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          {saving ? 'Sauvegarde…' : saved ? 'Sauvegardé !' : 'Sauvegarder'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex bg-white border border-gray-100 rounded-2xl p-1 mb-6 shadow-sm">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 text-xs py-2 rounded-xl font-medium transition-all ${
              tab === t ? 'bg-black text-white shadow-sm' : 'text-gray-400 hover:text-black'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Content */}
      <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>

        {/* ── Hero ─────────────────────────────────────────────────────── */}
        {tab === 'Hero' && (
          <div className="space-y-5">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4">
              <h2 className="text-sm font-semibold text-black mb-4">Section Hero</h2>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Titre principal</label>
                <textarea rows={2} className={ta} value={content.heroTitle}
                  onChange={e => upd({ heroTitle: e.target.value })}
                  placeholder="Décrivez votre mariage…" />
                <p className="text-xs text-gray-400 mt-1">Utilisez \n pour les sauts de ligne.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Sous-titre</label>
                <textarea rows={2} className={ta} value={content.heroSubtitle}
                  onChange={e => upd({ heroSubtitle: e.target.value })} />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Texte bouton CTA</label>
                <input className={inp} value={content.heroCta}
                  onChange={e => upd({ heroCta: e.target.value })} />
              </div>
            </div>

            {/* Preview */}
            <div className="bg-black rounded-2xl p-8 text-center">
              <p className="text-xs text-white/40 mb-4 uppercase tracking-widest">Aperçu hero</p>
              <p
                style={{ fontFamily: "'Inter', sans-serif" }}
                className="text-2xl font-semibold text-white leading-tight mb-3 whitespace-pre-line"
              >
                {content.heroTitle || 'Titre principal'}
              </p>
              <p className="text-white/60 text-sm mb-5">{content.heroSubtitle}</p>
              <button className="bg-white text-black text-sm font-semibold px-5 py-2.5 rounded-xl">
                {content.heroCta}
              </button>
            </div>
          </div>
        )}

        {/* ── Vidéo & Médias ──────────────────────────────────────────── */}
        {tab === 'Vidéo & Médias' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4">
              <h2 className="text-sm font-semibold text-black mb-2">Médias hero</h2>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <Play className="w-3 h-3" /> URL Vidéo (Cloudinary MP4)
                </label>
                <input className={inp} value={content.videoUrl}
                  onChange={e => upd({ videoUrl: e.target.value })}
                  placeholder="https://res.cloudinary.com/…/video.mp4" />
                {content.videoUrl && (
                  <video src={content.videoUrl} className="mt-3 w-full rounded-xl h-40 object-cover" muted playsInline />
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <Music2 className="w-3 h-3" /> URL Hymne (MP3)
                </label>
                <input className={inp} value={content.hymneUrl}
                  onChange={e => upd({ hymneUrl: e.target.value })}
                  placeholder="https://res.cloudinary.com/…/hymne.mp3" />
                {content.hymneUrl && (
                  <audio src={content.hymneUrl} controls className="mt-3 w-full h-10" />
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── Paroles ─────────────────────────────────────────────────── */}
        {tab === 'Paroles' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h2 className="text-sm font-semibold text-black">Paroles rotatives</h2>
                  <p className="text-xs text-gray-400 mt-0.5">S'affichent en boucle sur le hero vidéo</p>
                </div>
                <button
                  onClick={() => upd({ taglines: [...content.taglines, ''] })}
                  className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 px-3 py-1.5 rounded-lg transition-all"
                >
                  <Plus className="w-3.5 h-3.5" /> Ajouter
                </button>
              </div>

              <div className="space-y-2.5">
                {content.taglines.map((line, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                    className="flex gap-2 items-center">
                    <span className="text-xs text-gray-400 w-5 text-right flex-shrink-0">{i + 1}</span>
                    <input
                      className={`${inp} flex-1 italic`}
                      style={{ fontFamily: "'Inter', sans-serif" }}
                      value={line}
                      onChange={e => updTagline(i, e.target.value)}
                      placeholder="Il y a des matins qui goûtent différemment…"
                    />
                    <button onClick={() => upd({ taglines: content.taglines.filter((_, j) => j !== i) })}
                      className="p-1.5 text-gray-300 hover:text-red-500 transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </motion.div>
                ))}
                {!content.taglines.length && (
                  <p className="text-sm text-gray-400 text-center py-4">Aucune parole. Ajoutez-en une.</p>
                )}
              </div>
            </div>

            {/* Preview carousel */}
            {content.taglines.filter(Boolean).length > 0 && (
              <div className="bg-black rounded-2xl p-8 text-center overflow-hidden">
                <p className="text-xs text-white/40 mb-4 uppercase tracking-widest">Aperçu rotation</p>
                {content.taglines.filter(Boolean).slice(0, 3).map((line, i) => (
                  <p key={i} style={{ fontFamily: "'Inter', sans-serif" }}
                    className={`text-xl italic leading-snug mb-2 ${i === 0 ? 'text-white' : i === 1 ? 'text-white/50' : 'text-white/25'}`}>
                    "{line}"
                  </p>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── Footer ──────────────────────────────────────────────────── */}
        {tab === 'Footer' && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4">
            <h2 className="text-sm font-semibold text-black mb-2">Footer & Philosophie</h2>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">
                Citation philosophie (section mid)
              </label>
              <input className={`${inp} italic`} style={{ fontFamily: "'Inter', sans-serif" }}
                value={content.philosophie}
                onChange={e => upd({ philosophie: e.target.value })}
                placeholder='"Comprendre. Structurer. Vérifier. Avancer."' />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">
                Tagline footer
              </label>
              <input className={inp} value={content.footerTagline}
                onChange={e => upd({ footerTagline: e.target.value })} />
            </div>

            {/* Preview */}
            <div className="bg-gray-50 rounded-xl p-5 mt-2 border border-gray-100">
              <p className="text-xs text-gray-400 mb-3">Aperçu footer</p>
              <div className="flex items-center justify-between">
                <span style={{ fontFamily: "'Inter', sans-serif" }} className="text-gray-400 text-sm italic">
                  {content.footerTagline}
                </span>
                <span className="text-gray-300 text-xs">AIME Wedding OS</span>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
