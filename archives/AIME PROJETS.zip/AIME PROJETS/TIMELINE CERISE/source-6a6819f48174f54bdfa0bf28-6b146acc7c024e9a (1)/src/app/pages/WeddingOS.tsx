import {
  useState,
  useCallback,
  useRef,
  useEffect,
  useMemo,
  type ComponentType,
} from 'react';
import {
  ArrowRight,
  Sparkles,
  RotateCcw,
  Loader2,
  X,
  Undo2,
  Redo2,
  Cloud,
  CloudOff,
  LogIn,
  LogOut,
  User,
  MapPin,
  Star,
  Camera,
  Music,
  Utensils,
  Flower2,
  Building2,
  Heart,
  Mic2,
  Shirt,
  Scissors,
  Cake,
  Car,
  Palette,
  ReceiptText,
  MessageCircle,
  Check,
  ExternalLink,
  Waves,
} from 'lucide-react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import {
  cuid,
  sortByTime,
  makeTasks,
  parseWeddingInput,
  analyzeWedding,
  parseChatCommand,
} from '../components/wedding/WeddingEngine';
import type {
  WeddingEvent,
  WeddingConfig,
  WeddingAnalysis,
  ChatMessage,
  EventCategory,
  AlertSeverity,
  WeddingAlert,
} from '../components/wedding/WeddingEngine';
import { WeddingTimeline } from '../components/wedding/WeddingTimeline';
import { OrbitPanel } from '../components/wedding/OrbitPanel';
import { CeriseChat } from '../components/wedding/CeriseChat';
import { AimeLogoIcon } from '../components/AimeLogoIcon';
import { VideoHero } from '../components/wedding/VideoHero';
import { ParallaxTimelineSection } from '../components/wedding/ParallaxTimelineSection';

// ─── Supabase ─────────────────────────────────────────────────────────────────

const API = '/api';

// ─── Constants ───────────────────────────────────────────────────────────────

type Phase = 'initial' | 'generating' | 'active';

const STORAGE_KEY = 'aime_wedding_v1';
const SAVED_PROVIDERS_KEY = 'aime_saved_providers';
const VIDEO_INTRO_KEY = 'aime_video_intro_closed';

const PHOTOS = {
  hero: 'https://res.cloudinary.com/divou1vcx/image/upload/v1772852294/meteo_uhnmy5.jpg',
  transition: 'https://res.cloudinary.com/divou1vcx/image/upload/v1772854224/robe_skilvp.jpg',
  mid: 'https://res.cloudinary.com/divou1vcx/image/upload/v1772852042/pleinairmer_viqhyr.jpg',
  footer: 'https://res.cloudinary.com/divou1vcx/image/upload/v1772843090/mainpiano_mjh543.jpg',
};

const EXAMPLES = [
  'Mariage à Lille le 14 juin, 80 invités, cérémonie dehors, cocktail avec saxophone, dîner au château, photographe naturel',
  'Mariage intime 30 personnes, château, photographe, dîner élégant',
  '200 invités, luxe, groupe de musique live, traiteur, fleurs, transport',
  'Wedding 60 guests, garden, outdoor, saxophone cocktail, photographer',
];

const FEATURES = [
  {
    icon: '✦',
    title: 'Cerise comprend votre intention',
    desc: 'Ville, date, invités, ambiance, lieux et prestataires : chaque mot devient une information utile.',
  },
  {
    icon: '◈',
    title: 'Les résultats apparaissent dans le fil',
    desc: 'Les cartes prestataires, les tickets budget et la timeline pressentie s’affichent dans la conversation.',
  },
  {
    icon: '◉',
    title: 'Vous validez au bon moment',
    desc: 'Rien n’est figé. Cerise garde vos choix, puis génère la timeline quand vous dites que c’est ok.',
  },
];

// ─── Marketplace data ─────────────────────────────────────────────────────────

type ProviderCategory =
  | 'all'
  | 'venue'
  | 'planner'
  | 'photo'
  | 'catering'
  | 'music'
  | 'dj'
  | 'flowers'
  | 'dress'
  | 'beauty'
  | 'decor'
  | 'cake'
  | 'transport';

type ProviderCategoryItem = {
  key: ProviderCategory;
  label: string;
  icon: ComponentType<{ className?: string }>;
};

type ProviderCard = {
  id: string;
  name: string;
  category: Exclude<ProviderCategory, 'all'>;
  location: string;
  description: string;
  priceFrom: string;
  rating: number;
  tags: string[];
  available: boolean;
  image: string;
};

type BudgetItem = {
  label: string;
  amount: number;
};

type TimelinePreviewItem = {
  title: string;
  time: string;
};

type CeriseAction =
  | { type: 'continue'; label: string }
  | { type: 'budget_low'; label: string }
  | { type: 'generate'; label: string }
  | { type: 'provider_interested'; label: string; providerId: string }
  | { type: 'provider_reject'; label: string; providerId: string }
  | { type: 'provider_remember'; label: string; providerId: string }
  | { type: 'provider_view'; label: string; providerId: string };

type CeriseMessage = {
  id: string;
  role: 'cerise' | 'user';
  text?: string;
  providers?: ProviderCard[];
  budgetItems?: BudgetItem[];
  timelineItems?: TimelinePreviewItem[];
  actions?: CeriseAction[];
};

type ConversationMemory = {
  city?: string;
  dateText?: string;
  guestCount?: number;
  moments: TimelinePreviewItem[];
  detectedProviders: ProviderCard[];
  selectedProviders: ProviderCard[];
  rejectedProviderIds: string[];
  budgetItems: BudgetItem[];
  notes: string[];
};

const PROVIDER_CATEGORIES: ProviderCategoryItem[] = [
  { key: 'all', label: 'Tous', icon: Sparkles },
  { key: 'venue', label: 'Lieux', icon: Building2 },
  { key: 'planner', label: 'Wedding planners', icon: Heart },
  { key: 'photo', label: 'Photographes', icon: Camera },
  { key: 'catering', label: 'Traiteurs', icon: Utensils },
  { key: 'music', label: 'Musiciens', icon: Music },
  { key: 'dj', label: 'DJ', icon: Mic2 },
  { key: 'flowers', label: 'Fleuristes', icon: Flower2 },
  { key: 'dress', label: 'Robes & costumes', icon: Shirt },
  { key: 'beauty', label: 'Beauté', icon: Scissors },
  { key: 'decor', label: 'Décoration', icon: Palette },
  { key: 'cake', label: 'Pâtisserie', icon: Cake },
  { key: 'transport', label: 'Transport', icon: Car },
];

const PROVIDERS: ProviderCard[] = [
  {
    id: 'p1',
    name: 'Domaine des Lys',
    category: 'venue',
    location: 'Hauts-de-France',
    description: 'Lieu de réception avec jardin, salle principale et espace cérémonie extérieure.',
    priceFrom: '3 500 €',
    rating: 4.9,
    tags: ['Domaine', 'Jardin', 'Cérémonie'],
    available: true,
    image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p2',
    name: 'Maison Alba',
    category: 'planner',
    location: 'Paris',
    description: 'Organisation complète, coordination Jour J, scénographie et suivi prestataires.',
    priceFrom: '1 800 €',
    rating: 4.8,
    tags: ['Coordination', 'Premium', 'Jour J'],
    available: true,
    image: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p3',
    name: 'Claire Martin Photo',
    category: 'photo',
    location: 'Lille',
    description: 'Reportage naturel et éditorial, portraits de couple et moments spontanés.',
    priceFrom: '1 200 €',
    rating: 4.9,
    tags: ['Éditorial', 'Naturel', 'Portraits'],
    available: false,
    image: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p4',
    name: "L'Atelier du Goût",
    category: 'catering',
    location: 'Nord',
    description: 'Traiteur cocktail, repas assis, brunch du lendemain et menus personnalisés.',
    priceFrom: '85 € / invité',
    rating: 4.8,
    tags: ['Cocktail', 'Repas', 'Brunch'],
    available: true,
    image: 'https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p5',
    name: 'Matt Mez Sax',
    category: 'music',
    location: 'France / Belgique',
    description: 'Saxophoniste live pour cérémonie, cocktail, entrée des mariés et soirée.',
    priceFrom: '450 €',
    rating: 5.0,
    tags: ['Saxophone', 'Live', 'Cocktail'],
    available: true,
    image: 'https://images.unsplash.com/photo-1507838153414-b4b713384a76?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p6',
    name: 'Blue Night DJ',
    category: 'dj',
    location: 'Lille',
    description: 'DJ généraliste chic, ambiance dancefloor, matériel son et lumière inclus.',
    priceFrom: '900 €',
    rating: 4.6,
    tags: ['Dancefloor', 'Son', 'Lumière'],
    available: true,
    image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p7',
    name: "Fleurs d'Aube",
    category: 'flowers',
    location: 'Arras',
    description: 'Bouquets, arches florales, centres de table et scénographies végétales.',
    priceFrom: '600 €',
    rating: 4.8,
    tags: ['Arche', 'Bouquet', 'Tables'],
    available: true,
    image: 'https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p8',
    name: 'Maison Étoffe',
    category: 'dress',
    location: 'Paris',
    description: 'Robes de mariée, costumes, retouches, essayages privés et accessoires.',
    priceFrom: '1 200 €',
    rating: 4.7,
    tags: ['Robe', 'Costume', 'Retouches'],
    available: true,
    image: 'https://images.unsplash.com/photo-1525258946800-98cfd641d0de?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p9',
    name: 'Belle Âme Beauty',
    category: 'beauty',
    location: 'Lille',
    description: 'Coiffure, maquillage, essais beauté et préparation des mariés.',
    priceFrom: '280 €',
    rating: 4.9,
    tags: ['Coiffure', 'Maquillage', 'Essais'],
    available: true,
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p10',
    name: 'Scène Blanche',
    category: 'decor',
    location: 'France entière',
    description: 'Décoration de salle, mobilier, scénographie, papeterie et signalétique.',
    priceFrom: '750 €',
    rating: 4.6,
    tags: ['Scénographie', 'Mobilier', 'Papeterie'],
    available: true,
    image: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p11',
    name: 'Sucre Cérémonie',
    category: 'cake',
    location: 'Lyon',
    description: 'Wedding cakes, pièces montées, desserts individuels et buffet sucré.',
    priceFrom: '6 € / part',
    rating: 4.8,
    tags: ['Wedding cake', 'Dessert', 'Buffet'],
    available: true,
    image: 'https://images.unsplash.com/photo-1535254973040-607b474cb50d?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'p12',
    name: 'Route Blanche',
    category: 'transport',
    location: 'France',
    description: 'Véhicules de cérémonie, navettes invités, chauffeurs et coordination transport.',
    priceFrom: '390 €',
    rating: 4.7,
    tags: ['Navettes', 'Chauffeur', 'Cérémonie'],
    available: true,
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function computeDaysLeft(dateStr?: string): number | null {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return null;
  return Math.ceil((d.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
}

function safeReadSavedProviders(): ProviderCard[] {
  try {
    const saved = localStorage.getItem(SAVED_PROVIDERS_KEY);
    return saved ? (JSON.parse(saved) as ProviderCard[]) : [];
  } catch {
    return [];
  }
}

function safeWriteSavedProviders(providers: ProviderCard[]) {
  try {
    localStorage.setItem(SAVED_PROVIDERS_KEY, JSON.stringify(providers));
  } catch {}
}

function saveProviderToMemory(provider: ProviderCard) {
  const current = safeReadSavedProviders();
  const exists = current.some((p) => p.id === provider.id);
  const next = exists ? current : [...current, provider];
  safeWriteSavedProviders(next);
}

function providerCategoryToEventCategory(category: ProviderCard['category']): EventCategory {
  switch (category) {
    case 'photo':
      return 'photo';
    case 'catering':
    case 'cake':
      return 'catering';
    case 'music':
    case 'dj':
      return 'music';
    case 'transport':
      return 'transport';
    case 'venue':
    case 'flowers':
    case 'decor':
      return 'reception';
    case 'dress':
    case 'beauty':
      return 'preparation';
    case 'planner':
    default:
      return 'other';
  }
}

function parseProviderBudget(priceFrom: string): number | undefined {
  const parsed = parseInt(priceFrom.replace(/\D/g, ''), 10);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function uniqueProviders(providers: ProviderCard[]): ProviderCard[] {
  const seen = new Set<string>();
  return providers.filter((provider) => {
    if (seen.has(provider.id)) return false;
    seen.add(provider.id);
    return true;
  });
}

function currency(amount: number) {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(amount);
}

function normalizeText(text: string) {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function detectGuestCount(text: string): number | undefined {
  const match = normalizeText(text).match(/(\d{1,4})\s*(invites|personnes|guests|convives)/);
  return match ? parseInt(match[1], 10) : undefined;
}

function detectCity(text: string): string | undefined {
  const direct = text.match(/(?:à|a|sur|près de|proche de)\s+([A-ZÀ-Ÿ][A-Za-zÀ-ÿ'\- ]{2,24})/);
  if (direct?.[1]) return direct[1].trim().replace(/[,.].*$/, '');

  const n = normalizeText(text);
  if (n.includes('lille')) return 'Lille';
  if (n.includes('paris')) return 'Paris';
  if (n.includes('arras')) return 'Arras';
  if (n.includes('lyon')) return 'Lyon';
  if (n.includes('hauts-de-france') || n.includes('nord')) return 'Hauts-de-France';

  return undefined;
}

function detectDateText(text: string): string | undefined {
  const simple = text.match(/(?:le\s+)?(\d{1,2}\s+(?:janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)(?:\s+\d{4})?)/i);
  if (simple?.[1]) return simple[1];

  const numeric = text.match(/(\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)/);
  if (numeric?.[1]) return numeric[1];

  return undefined;
}

function detectProviders(text: string): ProviderCard[] {
  const n = normalizeText(text);
  const matches: ProviderCard[] = [];

  const add = (id: string) => {
    const provider = PROVIDERS.find((p) => p.id === id);
    if (provider) matches.push(provider);
  };

  if (/saxo|saxophone|musicien|live|cocktail/.test(n)) add('p5');
  if (/dj|dancefloor|soiree|musique/.test(n)) add('p6');
  if (/photo|photographe|portrait|reportage/.test(n)) add('p3');
  if (/traiteur|diner|repas|cocktail|brunch|menu/.test(n)) add('p4');
  if (/lieu|chateau|domaine|salle|jardin|reception/.test(n)) add('p1');
  if (/fleur|bouquet|arche|floral/.test(n)) add('p7');
  if (/robe|costume|tenue|retouche/.test(n)) add('p8');
  if (/beaute|coiffure|maquillage/.test(n)) add('p9');
  if (/decor|decoration|scenographie|mobilier/.test(n)) add('p10');
  if (/gateau|cake|piece montee|dessert/.test(n)) add('p11');
  if (/transport|navette|voiture|chauffeur/.test(n)) add('p12');
  if (/planner|coordination|organisatrice/.test(n)) add('p2');

  return uniqueProviders(matches);
}

function buildTimelinePreview(text: string, providers: ProviderCard[]): TimelinePreviewItem[] {
  const n = normalizeText(text);
  const items: TimelinePreviewItem[] = [];

  items.push({ title: 'Préparatifs', time: '10:00' });

  if (/ceremonie|eglise|mairie|dehors|exterieur|jardin/.test(n)) {
    items.push({ title: 'Cérémonie', time: '15:00' });
  }

  if (/saxo|saxophone|cocktail/.test(n)) {
    items.push({ title: 'Saxophone — ambiance cocktail', time: '16:00' });
  }

  if (/vin|honneur|cocktail/.test(n)) {
    items.push({ title: "Vin d'honneur", time: '16:30' });
  }

  if (/diner|repas|traiteur|chateau|table/.test(n)) {
    items.push({ title: 'Dîner', time: '19:30' });
  }

  if (/dj|soiree|dancefloor|musique/.test(n)) {
    items.push({ title: 'Soirée dansante', time: '22:00' });
  }

  providers.forEach((provider) => {
    if (!items.some((item) => item.title === provider.name)) {
      const time = provider.category === 'photo' ? '14:00' : provider.category === 'music' ? '18:00' : '17:00';
      items.push({ title: provider.name, time });
    }
  });

  return items.length ? items : [
    { title: 'Préparatifs', time: '10:00' },
    { title: 'Cérémonie', time: '15:00' },
    { title: "Vin d'honneur", time: '16:30' },
    { title: 'Dîner', time: '19:30' },
  ];
}

function estimateMomentBudget(item: TimelinePreviewItem, guestCount = 80): number {
  const n = normalizeText(item.title);

  if (/preparatifs|beaute|coiffure|maquillage/.test(n)) return 700;
  if (/ceremonie/.test(n)) return 600;
  if (/saxophone|saxo/.test(n)) return 700;
  if (/vin|cocktail/.test(n)) return Math.max(1200, guestCount * 22);
  if (/diner|repas/.test(n)) return Math.max(2400, guestCount * 80);
  if (/soiree|dj/.test(n)) return 900;
  return 450;
}

function buildBudgetItems(
  timelineItems: TimelinePreviewItem[],
  providers: ProviderCard[],
  guestCount?: number
): BudgetItem[] {
  const base: BudgetItem[] = timelineItems.slice(0, 6).map((item) => ({
    label: item.title,
    amount: estimateMomentBudget(item, guestCount),
  }));

  const providerItems = providers.map((provider) => ({
    label: provider.name,
    amount: parseProviderBudget(provider.priceFrom) ?? 500,
  }));

  const merged = [...base, ...providerItems];
  const seen = new Set<string>();

  return merged.filter((item) => {
    const key = normalizeText(item.label);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function providerToWeddingEvent(provider: ProviderCard, index = 0): WeddingEvent {
  const category = providerCategoryToEventCategory(provider.category);
  const timeByCategory: Record<ProviderCard['category'], string> = {
    venue: '17:00',
    planner: '09:30',
    photo: '14:00',
    catering: '19:30',
    music: '18:00',
    dj: '22:00',
    flowers: '11:00',
    dress: '10:00',
    beauty: '09:00',
    decor: '12:00',
    cake: '21:00',
    transport: '13:30',
  };

  return {
    id: cuid(),
    title: provider.name,
    time: timeByCategory[provider.category] ?? `${18 + index}:00`,
    category,
    description: `${provider.description} · ${provider.location} · À partir de ${provider.priceFrom}`,
    status: 'pending',
    vendor: provider.name,
    budget: parseProviderBudget(provider.priceFrom),
    tasks: makeTasks(category),
    isNew: true,
    music:
      provider.category === 'music' || provider.category === 'dj'
        ? { title: provider.name, artist: provider.location }
        : undefined,
  };
}

function buildPromptFromMemory(memory: ConversationMemory, fallback: string) {
  const parts = [fallback];

  if (memory.city) parts.push(`Ville : ${memory.city}`);
  if (memory.dateText) parts.push(`Date : ${memory.dateText}`);
  if (memory.guestCount) parts.push(`${memory.guestCount} invités`);
  if (memory.moments.length) {
    parts.push(`Moments souhaités : ${memory.moments.map((item) => item.title).join(', ')}`);
  }
  if (memory.selectedProviders.length || memory.detectedProviders.length) {
    const providers = memory.selectedProviders.length ? memory.selectedProviders : memory.detectedProviders;
    parts.push(`Prestataires pressentis : ${providers.map((provider) => provider.name).join(', ')}`);
  }
  if (memory.notes.length) parts.push(memory.notes.join(' '));

  return parts.filter(Boolean).join('. ');
}

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const media = window.matchMedia('(max-width: 767px)');
    const update = () => setIsMobile(media.matches);
    update();

    if (media.addEventListener) {
      media.addEventListener('change', update);
      return () => media.removeEventListener('change', update);
    }

    media.addListener(update);
    return () => media.removeListener(update);
  }, []);

  return isMobile;
}

function ParallaxBg({
  src,
  overlay = 'bg-black/40',
  position = 'center center',
  mobilePosition = 'center center',
  speed = 90,
  mobileSpeed = 38,
  scale = 1.14,
  mobileScale = 1.08,
}: {
  src: string;
  overlay?: string;
  position?: string;
  mobilePosition?: string;
  speed?: number;
  mobileSpeed?: number;
  scale?: number;
  mobileScale?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(
    scrollYProgress,
    [0, 1],
    isMobile
      ? [`-${mobileSpeed}px`, `${mobileSpeed}px`]
      : [`-${speed}px`, `${speed}px`]
  );

  return (
    <div ref={ref} className="absolute inset-0 overflow-hidden pointer-events-none">
      <motion.img
        src={src}
        alt=""
        draggable={false}
        className="absolute inset-0 w-full h-full object-cover select-none"
        style={{
          y,
          scale: isMobile ? mobileScale : scale,
          objectPosition: isMobile ? mobilePosition : position,
          willChange: 'transform',
        }}
      />

      <div className={`absolute inset-0 pointer-events-none ${overlay}`} />
    </div>
  );
}

// ─── Video intro ─────────────────────────────────────────────────────────────

function DismissibleVideoIntro({ onClose }: { onClose: () => void }) {
  return (
    <motion.section
      key="video-intro"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.45 }}
      className="relative min-h-screen overflow-hidden bg-black"
    >
      <VideoHero />

      <button
        type="button"
        onClick={onClose}
        className="fixed right-5 top-20 z-[65] w-11 h-11 rounded-full bg-white/12 hover:bg-white/20 backdrop-blur-xl border border-white/20 text-white flex items-center justify-center shadow-2xl transition-all"
        aria-label="Fermer la vidéo"
      >
        <X className="w-5 h-5" />
      </button>

      <div className="absolute bottom-7 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 pointer-events-none">
        <span className="text-white/45 text-[10px] tracking-[0.22em] uppercase">
          Fermer ou défiler vers Cerise
        </span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.6, repeat: Infinity }}
          className="w-px h-8 bg-gradient-to-b from-white/40 to-transparent"
        />
      </div>
    </motion.section>
  );
}

// ─── Auth Modal ───────────────────────────────────────────────────────────────

interface AuthState {
  userId: string;
  email: string;
  token: string;
  name: string;
  invitationCode?: string;
}

function AuthModal({
  mode = 'default',
  onClose,
  onAuth,
}: {
  mode?: 'default' | 'guest';
  onClose: () => void;
  onAuth: (state: AuthState) => void;
}) {
  const [tab, setTab] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [invitationCode, setInvitationCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    setError('');
    setLoading(true);

    try {
      if (tab === 'signup') {
        const res = await fetch(`${API}/auth/signup`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer public',
          },
          body: JSON.stringify({ email, password, name, invitationCode }),
        });

        const data = await res.json();

        if (!res.ok) {
          setError(data.error || 'Erreur lors de la création');
          setLoading(false);
          return;
        }
      }

      const loginRes = await fetch(`${API}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer public',
        },
        body: JSON.stringify({ email, password }),
      });
      const data = await loginRes.json();

      if (!loginRes.ok || !data.session) {
        setError(data.error || 'Email ou mot de passe incorrect');
        setLoading(false);
        return;
      }

      const { session, user } = data;

      onAuth({
        userId: user.id,
        email: user.email || email,
        token: session.access_token,
        name: (user.user_metadata?.name as string) || name || email.split('@')[0],
        invitationCode: invitationCode.trim() || undefined,
      });
    } catch (e) {
      setError(`Erreur réseau: ${e}`);
    }

    setLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 12 }}
        className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden"
      >
        <div className="px-6 pt-6 pb-5 border-b border-gray-100 flex items-start justify-between">
          <div>
            <div className="w-8 h-8 bg-black rounded-xl flex items-center justify-center mb-3">
              {mode === 'guest' ? <User className="w-4 h-4 text-white" /> : <Sparkles className="w-4 h-4 text-white" />}
            </div>

            <h2
              style={{ fontFamily: "'Inter', sans-serif" }}
              className="text-xl font-semibold text-white"
            >
              {mode === 'guest'
                ? 'Accès invités'
                : tab === 'login'
                  ? 'Se connecter'
                  : 'Créer un compte'}
            </h2>

            <p className="text-xs text-gray-400 mt-1">
              {mode === 'guest'
                ? 'Entrez votre code d’invitation pour accéder au mini-site.'
                : 'Retrouvez votre mariage sur tous vos appareils.'}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        <div className="flex mx-6 mt-5 bg-gray-100 rounded-xl p-0.5">
          {(['login', 'signup'] as const).map((t) => (
            <button
              key={t}
              onClick={() => {
                setTab(t);
                setError('');
              }}
              className={`flex-1 text-xs py-2 rounded-[10px] font-medium transition-all ${
                tab === t ? 'bg-white text-black shadow-sm' : 'text-gray-500'
              }`}
            >
              {t === 'login' ? 'Connexion' : 'Inscription'}
            </button>
          ))}
        </div>

        <div className="px-6 py-5 space-y-3">
          {mode === 'guest' && (
            <input
              value={invitationCode}
              onChange={(e) => setInvitationCode(e.target.value.toUpperCase())}
              placeholder="Code d’invitation"
              className="w-full px-4 py-3 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-400 transition-colors tracking-[0.12em] uppercase"
            />
          )}

          {tab === 'signup' && (
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Votre prénom"
              className="w-full px-4 py-3 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-400 transition-colors"
            />
          )}

          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full px-4 py-3 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-400 transition-colors"
          />

          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Mot de passe"
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            className="w-full px-4 py-3 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-400 transition-colors"
          />

          {error && (
            <p className="text-xs text-red-500 bg-red-50 px-3 py-2 rounded-xl">
              {error}
            </p>
          )}

          <button
            onClick={handleSubmit}
            disabled={loading || !email || !password || (mode === 'guest' && !invitationCode.trim())}
            className="w-full py-3 bg-black text-white text-sm font-semibold rounded-xl hover:bg-gray-800 disabled:opacity-40 transition-all"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                Chargement
              </span>
            ) : mode === 'guest' ? (
              'Entrer avec mon code'
            ) : tab === 'login' ? (
              'Se connecter'
            ) : (
              'Créer mon compte'
            )}
          </button>
        </div>

        <p className="text-center text-[10px] text-gray-400 pb-5">
          Vos données restent privées et peuvent être modifiées.
        </p>
      </motion.div>
    </motion.div>
  );
}

// ─── Conversation UI ─────────────────────────────────────────────────────────

function ProviderInlineCard({
  provider,
  onAction,
}: {
  provider: ProviderCard;
  onAction: (action: CeriseAction) => void;
}) {
  const Icon = PROVIDER_CATEGORIES.find((c) => c.key === provider.category)?.icon ?? Sparkles;

  return (
    <div className="min-w-[240px] max-w-[260px] bg-[#121215] rounded-2xl border border-[#2b2b2b] overflow-hidden shadow-lg text-white">
      <div className="relative h-32 bg-black overflow-hidden">
        <img
          src={provider.image}
          alt={provider.name}
          className="absolute inset-0 w-full h-full object-cover opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#121215] via-black/20 to-black/20" />
        <div className="absolute top-3 left-3 w-9 h-9 rounded-xl bg-black/40 backdrop-blur-md border border-white/20 flex items-center justify-center text-white">
          <Icon className="w-4 h-4" />
        </div>
        <div className="absolute top-3 right-3 flex items-center gap-1 text-[11px] text-white bg-black/50 backdrop-blur-md rounded-full px-2 py-1 border border-white/10">
          <Star className="w-3 h-3 fill-current text-amber-400" />
          {provider.rating.toFixed(1)}
        </div>
        <div className="absolute bottom-3 left-3 right-3">
          <p className="text-white font-semibold leading-tight">{provider.name}</p>
          <p className="text-white/70 text-xs flex items-center gap-1 mt-1">
            <MapPin className="w-3 h-3" />
            {provider.location}
          </p>
        </div>
      </div>

      <div className="p-3">
        <p className="text-xs text-white/70 leading-relaxed min-h-[48px]">
          {provider.description}
        </p>
        <div className="mt-3 flex items-end justify-between gap-2">
          <div>
            <p className="text-[9px] text-white/40 uppercase tracking-[0.16em]">
              À partir de
            </p>
            <p className="text-sm font-bold text-white">{provider.priceFrom}</p>
          </div>
          <span className="text-[10px] px-2 py-1 rounded-full bg-[#202025] border border-[#303038] text-white/70">
            {provider.available ? 'Disponible' : 'À vérifier'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3">
          <button
            type="button"
            onClick={() => onAction({ type: 'provider_interested', providerId: provider.id, label: 'Intéressé' })}
            className="px-3 py-2 rounded-xl bg-white text-black text-[11px] font-bold hover:bg-gray-200 transition-colors"
          >
            Intéressé
          </button>
          <button
            type="button"
            onClick={() => onAction({ type: 'provider_view', providerId: provider.id, label: 'Voir' })}
            className="px-3 py-2 rounded-xl bg-[#202025] text-white text-[11px] font-semibold border border-[#34343c] hover:bg-[#282830] transition-colors"
          >
            Voir
          </button>
          <button
            type="button"
            onClick={() => onAction({ type: 'provider_remember', providerId: provider.id, label: 'Garder' })}
            className="px-3 py-2 rounded-xl bg-[#202025] text-white/80 text-[11px] font-semibold border border-[#34343c] hover:bg-[#282830] transition-colors"
          >
            Garder
          </button>
          <button
            type="button"
            onClick={() => onAction({ type: 'provider_reject', providerId: provider.id, label: 'Pas budget' })}
            className="px-3 py-2 rounded-xl bg-[#202025] text-white/50 text-[11px] font-semibold border border-[#34343c] hover:bg-[#282830] transition-colors"
          >
            Pas budget
          </button>
        </div>
      </div>
    </div>
  );
}

function BudgetTicket({
  items,
  onAction,
}: {
  items: BudgetItem[];
  onAction: (action: CeriseAction) => void;
}) {
  const total = items.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="bg-[#121215] rounded-2xl border border-[#2b2b2b] shadow-lg p-4 max-w-xl text-white">
      <div className="flex items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-white text-black flex items-center justify-center font-bold">
            <ReceiptText className="w-4 h-4" />
          </div>
          <div>
            <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-white/40">
              Budget vivant
            </p>
            <p className="text-sm font-semibold text-white">Première estimation</p>
          </div>
        </div>
        <span className="text-[10px] text-white/40 uppercase tracking-[0.16em]">indicatif</span>
      </div>

      <div className="space-y-2">
        {items.slice(0, 6).map((item) => (
          <div key={item.label} className="flex items-baseline justify-between gap-4 text-sm">
            <span className="text-white/70 truncate">{item.label}</span>
            <span className="font-semibold text-white whitespace-nowrap">~{currency(item.amount)}</span>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-[#2b2b2b] flex items-end justify-between">
        <div>
          <p className="text-xs text-white/50">Total indicatif</p>
          <p className="text-[10px] text-white/30 mt-1">Non contractuel · ajustable</p>
        </div>
        <p className="text-2xl font-bold text-white">~{currency(total)}</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
        <button
          type="button"
          onClick={() => onAction({ type: 'continue', label: 'Continuer' })}
          className="px-3 py-2 rounded-xl bg-white text-black text-[11px] font-bold hover:bg-gray-200 transition-colors"
        >
          Continuer
        </button>
        <button
          type="button"
          onClick={() => onAction({ type: 'budget_low', label: 'Ce n’est pas dans mon budget' })}
          className="px-3 py-2 rounded-xl bg-[#202025] text-white/80 text-[11px] font-semibold border border-[#34343c] hover:bg-[#282830] transition-colors"
        >
          Trop haut
        </button>
        <button
          type="button"
          onClick={() => onAction({ type: 'continue', label: 'Ajuster' })}
          className="px-3 py-2 rounded-xl bg-[#202025] text-white/80 text-[11px] font-semibold border border-[#34343c] hover:bg-[#282830] transition-colors"
        >
          Ajuster
        </button>
        <button
          type="button"
          onClick={() => onAction({ type: 'generate', label: 'Créer la timeline' })}
          className="px-3 py-2 rounded-xl bg-[#202025] text-white text-[11px] font-bold border border-[#34343c] hover:bg-[#282830] transition-colors"
        >
          Timeline
        </button>
      </div>
    </div>
  );
}

function TimelineHintCard({ items }: { items: TimelinePreviewItem[] }) {
  return (
    <div className="bg-[#121215] rounded-2xl border border-[#2b2b2b] shadow-lg p-4 max-w-xl text-white">
      <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-white/40 mb-3">
        Timeline pressentie
      </p>
      <div className="space-y-3">
        {items.slice(0, 6).map((item) => (
          <div key={`${item.title}-${item.time}`} className="flex items-start gap-3">
            <span className="mt-1.5 w-2 h-2 rounded-full bg-white flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-white">{item.title}</p>
              <p className="text-xs text-white/50">{item.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ConversationMessageView({
  message,
  onAction,
}: {
  message: CeriseMessage;
  onAction: (action: CeriseAction) => void;
}) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[92%] ${isUser ? 'items-end' : 'items-start'} flex flex-col gap-3`}>
        {message.text && (
          <div
            className={`rounded-3xl px-4 py-3 text-sm leading-relaxed ${
              isUser
                ? 'bg-white text-black rounded-br-lg font-medium shadow-md'
                : 'bg-[#1c1c21] text-white/90 border border-[#2f2f36] rounded-bl-lg shadow-md'
            }`}
          >
            {!isUser && (
              <p className="text-[9px] font-bold text-white/40 tracking-[0.2em] uppercase mb-1">
                Cerise
              </p>
            )}
            {message.text}
          </div>
        )}

        {message.providers && message.providers.length > 0 && (
          <div className="w-full overflow-x-auto pb-2">
            <div className="flex gap-3 min-w-max">
              {message.providers.map((provider) => (
                <ProviderInlineCard key={provider.id} provider={provider} onAction={onAction} />
              ))}
            </div>
          </div>
        )}

        {message.timelineItems && message.timelineItems.length > 0 && (
          <TimelineHintCard items={message.timelineItems} />
        )}

        {message.budgetItems && message.budgetItems.length > 0 && (
          <BudgetTicket items={message.budgetItems} onAction={onAction} />
        )}

        {message.actions && message.actions.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {message.actions.map((action) => (
              <button
                key={`${message.id}-${action.label}`}
                type="button"
                onClick={() => onAction(action)}
                className={`px-3.5 py-2 rounded-full text-[11px] font-semibold transition-all ${
                  action.type === 'generate'
                    ? 'bg-white text-black hover:bg-gray-200 shadow-md font-bold'
                    : 'bg-[#18181c] border border-[#343438] text-white/80 hover:text-white hover:bg-[#222228]'
                }`}
              >
                {action.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function CeriseConversationSection({
  value,
  onChange,
  loading,
  onGenerateFromConversation,
  onProviderClick,
}: {
  value: string;
  onChange: (value: string) => void;
  loading: boolean;
  onGenerateFromConversation: (prompt: string, providers: ProviderCard[]) => void;
  onProviderClick: (provider: ProviderCard) => void;
}) {
  const conversationRef = useRef<HTMLDivElement>(null);

  const [memory, setMemory] = useState<ConversationMemory>({
    moments: [],
    detectedProviders: [],
    selectedProviders: [],
    rejectedProviderIds: [],
    budgetItems: [],
    notes: [],
  });

  const [messages, setMessages] = useState<CeriseMessage[]>([
    {
      id: cuid(),
      role: 'cerise',
      text:
        'Alors vous allez voir, c’est très simple. Au fil de la discussion, je vais vous proposer ici même des résultats, des prestataires, des estimations et des choix possibles. Vous restez libre à chaque étape : je garde vos préférences en mémoire, et quand vous me direz “c’est ok pour la Timeline”, je transformerai tout ça en organisation claire. On y va à la cool.',
      actions: [
        { type: 'continue', label: 'Commencer doucement' },
        { type: 'generate', label: 'Créer une base de timeline' },
      ],
    },
  ]);

  useEffect(() => {
    conversationRef.current?.scrollTo({
      top: conversationRef.current.scrollHeight,
      behavior: 'smooth',
    });
  }, [messages.length]);

  const draftDetectedProviders = useMemo(() => detectProviders(value), [value]);

  const createResponse = (text: string, currentMemory: ConversationMemory): CeriseMessage[] => {
    const detected = detectProviders(text);
    const city = detectCity(text) ?? currentMemory.city;
    const dateText = detectDateText(text) ?? currentMemory.dateText;
    const guestCount = detectGuestCount(text) ?? currentMemory.guestCount;

    const detectedProviders = uniqueProviders([
      ...currentMemory.detectedProviders,
      ...detected,
    ]).filter((provider) => !currentMemory.rejectedProviderIds.includes(provider.id));

    const timelineItems = buildTimelinePreview(text, detectedProviders);
    const budgetItems = buildBudgetItems(timelineItems, detectedProviders, guestCount);

    const nextMemory: ConversationMemory = {
      ...currentMemory,
      city,
      dateText,
      guestCount,
      moments: timelineItems,
      detectedProviders,
      budgetItems,
      notes: [...currentMemory.notes, text],
    };

    setMemory(nextMemory);

    const introBits = [];
    if (city) introBits.push(city);
    if (dateText) introBits.push(dateText);
    if (guestCount) introBits.push(`${guestCount} invités`);

    const ceriseText = detected.length
      ? `Tiens, regardez comme par magie les cartes qui ont été tirées${introBits.length ? ` pour ${introBits.join(' · ')}` : ''}. Je peux déjà les préparer pour votre timeline.`
      : introBits.length
        ? `Parfait, je garde ${introBits.join(' · ')} en mémoire. Donnez-moi maintenant les grands moments ou les prestataires que vous imaginez.`
        : 'Je vous écoute. Vous pouvez me parler de la ville, de la date, du nombre d’invités, du lieu, de l’ambiance ou des prestataires rêvés.';

    const responses: CeriseMessage[] = [
      {
        id: cuid(),
        role: 'cerise',
        text: ceriseText,
        actions: [
          { type: 'continue', label: 'Continuer' },
          { type: 'budget_low', label: 'Budget plus doux' },
          { type: 'generate', label: 'C’est ok pour la Timeline' },
        ],
      },
    ];

    if (detected.length) {
      responses.push({
        id: cuid(),
        role: 'cerise',
        providers: detected,
      });
    }

    if (timelineItems.length >= 3) {
      responses.push({
        id: cuid(),
        role: 'cerise',
        text: 'Je dessine déjà une première lecture de votre journée. Rien n’est encore figé.',
        timelineItems,
      });
    }

    if (budgetItems.length >= 3) {
      responses.push({
        id: cuid(),
        role: 'cerise',
        text: 'Je vous pose aussi un premier ticket budget. On pourra l’ajuster sans pression.',
        budgetItems,
      });
    }

    return responses;
  };

  const handleSend = () => {
    const text = value.trim();
    if (!text || loading) return;

    const normalized = normalizeText(text);

    if (/ok.*timeline|timeline|genere|generer|cree|creer/.test(normalized) && memory.notes.length > 0) {
      const providers = memory.selectedProviders.length ? memory.selectedProviders : memory.detectedProviders;
      onGenerateFromConversation(buildPromptFromMemory(memory, text), providers);
      return;
    }

    const userMessage: CeriseMessage = {
      id: cuid(),
      role: 'user',
      text,
    };

    const responses = createResponse(text, memory);
    setMessages((prev) => [...prev, userMessage, ...responses]);
    onChange('');
  };

  const handleAction = (action: CeriseAction) => {
    if (action.type === 'generate') {
      const providers = memory.selectedProviders.length ? memory.selectedProviders : memory.detectedProviders;
      onGenerateFromConversation(buildPromptFromMemory(memory, value || 'Timeline mariage'), providers);
      return;
    }

    if (action.type === 'continue') {
      setMessages((prev) => [
        ...prev,
        {
          id: cuid(),
          role: 'cerise',
          text: 'Très bien. Donnez-moi un autre élément : lieu, repas, musique, photo, transport, budget ou ambiance. Je range chaque réponse au bon endroit.',
        },
      ]);
      return;
    }

    if (action.type === 'budget_low') {
      setMemory((prev) => ({
        ...prev,
        notes: [...prev.notes, 'Budget à adoucir'],
      }));
      setMessages((prev) => [
        ...prev,
        {
          id: cuid(),
          role: 'cerise',
          text: 'C’est noté. Je vais privilégier des options plus douces, réduire les postes non essentiels et garder une marge de sécurité.',
        },
      ]);
      return;
    }

    const provider = PROVIDERS.find((p) => p.id === action.providerId);
    if (!provider) return;

    if (action.type === 'provider_view') {
      onProviderClick(provider);
      return;
    }

    if (action.type === 'provider_remember') {
      saveProviderToMemory(provider);
      setMessages((prev) => [
        ...prev,
        {
          id: cuid(),
          role: 'cerise',
          text: `${provider.name} est gardé en mémoire. Je pourrai le ressortir quand on préparera la timeline ou le budget.`,
        },
      ]);
      return;
    }

    if (action.type === 'provider_interested') {
      saveProviderToMemory(provider);
      setMemory((prev) => ({
        ...prev,
        selectedProviders: uniqueProviders([...prev.selectedProviders, provider]),
        detectedProviders: uniqueProviders([...prev.detectedProviders, provider]),
      }));
      setMessages((prev) => [
        ...prev,
        {
          id: cuid(),
          role: 'cerise',
          text: `Parfait, je marque ${provider.name} comme piste intéressante. Je pourrai l’intégrer dans la timeline quand vous validerez.`,
          actions: [{ type: 'generate', label: 'Créer la timeline avec cette piste' }],
        },
      ]);
      return;
    }

    if (action.type === 'provider_reject') {
      setMemory((prev) => ({
        ...prev,
        rejectedProviderIds: [...prev.rejectedProviderIds, provider.id],
        selectedProviders: prev.selectedProviders.filter((p) => p.id !== provider.id),
        detectedProviders: prev.detectedProviders.filter((p) => p.id !== provider.id),
      }));
      setMessages((prev) => [
        ...prev,
        {
          id: cuid(),
          role: 'cerise',
          text: `Compris. Je retire ${provider.name} de cette piste et je chercherai une option plus adaptée.`,
        },
      ]);
    }
  };

  return (
    <section
      id="cerise-start"
      className="relative min-h-screen bg-[#050507] text-white flex flex-col justify-center items-center overflow-hidden px-4 sm:px-6 pt-24 pb-16"
    >
      <ParallaxBg
        src={PHOTOS.hero}
        overlay="bg-gradient-to-b from-black/60 via-black/80 to-[#050507]"
        position="center center"
        mobilePosition="center center"
        speed={105}
        mobileSpeed={36}
        scale={1.14}
        mobileScale={1.07}
      />

      <div className="relative z-10 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-4xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white/5 backdrop-blur-md border border-white/12 rounded-full text-xs font-semibold text-white/80 mb-6 tracking-widest uppercase shadow-inner">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
            Cerise · AI Wedding Architect
          </div>

          <h1
            style={{ fontFamily: "'Inter', sans-serif" }}
            className="text-4xl sm:text-5xl md:text-7xl font-semibold text-white leading-[0.96] tracking-tight mb-4"
          >
            Parlez à Cerise.
            <br />
            <span className="italic text-white/60">La timeline apparaît.</span>
          </h1>

          <p className="text-white/65 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
            Ville, date, invités, ambiance, prestataires — Cerise comprend votre intention et construit votre mariage.
          </p>
        </div>

        <div className="grid lg:grid-cols-[minmax(0,1fr)_380px] gap-6 items-stretch">
          <div className="bg-[#000000] rounded-[1.8rem] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] border border-[#2b2b2b] overflow-hidden min-h-[520px] flex flex-col">
            <div className="px-5 sm:px-6 py-4 bg-[#09090b] border-b border-[#2b2b2b] flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#18181b] border border-[#343438] text-white flex items-center justify-center flex-shrink-0 shadow-inner">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-[10px] font-bold text-white/50 tracking-[0.22em] uppercase">
                    Cerise
                  </p>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <p className="text-xs text-white/70 truncate font-medium">
                  Discussion fluide · mémoire active · choix libres
                </p>
              </div>
            </div>

            <div
              ref={conversationRef}
              className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-5 bg-[#000000] min-h-[380px] max-h-[520px]"
            >
              {messages.map((message) => (
                <ConversationMessageView
                  key={message.id}
                  message={message}
                  onAction={handleAction}
                />
              ))}
            </div>

            {draftDetectedProviders.length > 0 && (
              <div className="px-4 sm:px-6 pt-3 bg-[#09090b] border-t border-[#2b2b2b]">
                <div className="flex items-center gap-2 overflow-x-auto pb-2">
                  <span className="text-[10px] text-white/40 uppercase tracking-[0.16em] whitespace-nowrap">
                    Détecté
                  </span>
                  {draftDetectedProviders.map((provider) => (
                    <button
                      key={provider.id}
                      type="button"
                      onClick={() => onProviderClick(provider)}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#18181c] border border-[#2d2d34] hover:bg-[#222228] text-xs text-white/80 whitespace-nowrap transition-colors"
                    >
                      <img src={provider.image} alt="" className="w-5 h-5 rounded-full object-cover" />
                      {provider.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="p-4 sm:p-5 bg-[#09090b] border-t border-[#2b2b2b]">
              <div className="flex flex-col sm:flex-row gap-3 items-center">
                <textarea
                  value={value}
                  onChange={(e) => onChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  rows={2}
                  placeholder="Écrivez à Cerise : ville, date, invités, ambiance, prestataires…"
                  disabled={loading}
                  className="flex-1 w-full min-h-[56px] max-h-32 resize-none rounded-2xl bg-[#141418] border border-[#2d2d34] px-4 py-3 text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-[#42424b] disabled:opacity-60"
                />
                <button
                  type="button"
                  onClick={handleSend}
                  disabled={!value.trim() || loading}
                  className="w-full sm:w-36 flex items-center justify-center gap-2 rounded-2xl bg-white text-black px-5 py-3.5 text-sm font-bold hover:bg-gray-200 disabled:opacity-40 transition-all active:scale-[0.98] shadow-lg flex-shrink-0"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                  Envoyer
                </button>
              </div>

              <div className="mt-4 flex flex-wrap gap-2 justify-center sm:justify-start">
                {EXAMPLES.map((ex) => (
                  <button
                    key={ex}
                    type="button"
                    onClick={() => onChange(ex)}
                    className="text-xs text-white/60 hover:text-white border border-[#2a2a30] hover:border-[#40404a] bg-[#121215] px-3 py-1.5 rounded-full transition-all"
                  >
                    {ex.length > 54 ? `${ex.slice(0, 54)}…` : ex}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <aside className="bg-[#09090b] border border-[#2b2b2b] rounded-[1.8rem] p-6 text-white shadow-2xl hidden lg:flex flex-col">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-2xl bg-white text-black flex items-center justify-center font-bold">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-white/40">
                  Lecture instantanée
                </p>
                <p className="text-sm font-semibold text-white">Ce que Cerise comprend déjà</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-2xl bg-[#121216] border border-[#25252a] p-4">
                <p className="text-[10px] uppercase tracking-[0.18em] text-white/40 mb-2 font-bold">
                  Informations
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between gap-3">
                    <span className="text-white/50">Ville</span>
                    <span className="font-medium text-white">{memory.city ?? 'à préciser'}</span>
                  </div>
                  <div className="flex justify-between gap-3">
                    <span className="text-white/50">Date</span>
                    <span className="font-medium text-white">{memory.dateText ?? 'à préciser'}</span>
                  </div>
                  <div className="flex justify-between gap-3">
                    <span className="text-white/50">Invités</span>
                    <span className="font-medium text-white">{memory.guestCount ? `${memory.guestCount}` : 'à préciser'}</span>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-[#121216] border border-[#25252a] p-4">
                <p className="text-[10px] uppercase tracking-[0.18em] text-white/40 mb-3 font-bold">
                  Prestataires pressentis
                </p>
                {memory.detectedProviders.length ? (
                  <div className="space-y-2">
                    {memory.detectedProviders.slice(0, 4).map((provider) => (
                      <div key={provider.id} className="flex items-center gap-2">
                        <img src={provider.image} alt="" className="w-8 h-8 rounded-xl object-cover" />
                        <div className="min-w-0">
                          <p className="text-sm font-semibold truncate text-white">{provider.name}</p>
                          <p className="text-[11px] text-white/50">{provider.priceFrom}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-white/40 leading-relaxed">
                    Parlez d’un saxophoniste, photographe, château, traiteur ou DJ.
                  </p>
                )}
              </div>

              <div className="rounded-2xl bg-[#121216] border border-[#25252a] p-4">
                <p className="text-[10px] uppercase tracking-[0.18em] text-white/40 mb-3 font-bold">
                  Budget aperçu
                </p>
                {memory.budgetItems.length ? (
                  <>
                    <div className="space-y-2 text-sm">
                      {memory.budgetItems.slice(0, 4).map((item) => (
                        <div key={item.label} className="flex justify-between gap-3">
                          <span className="text-white/60 truncate">{item.label}</span>
                          <span className="font-semibold text-white whitespace-nowrap">~{currency(item.amount)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 pt-3 border-t border-[#25252a] flex justify-between">
                      <span className="text-white/50 text-sm">Total</span>
                      <span className="font-bold text-white">
                        ~{currency(memory.budgetItems.reduce((sum, item) => sum + item.amount, 0))}
                      </span>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-white/40 leading-relaxed">
                    Le ticket apparaît après quelques informations.
                  </p>
                )}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

// ─── Calm provider strip ─────────────────────────────────────────────────────

function CalmProviderStrip({ onProviderClick }: { onProviderClick: (provider: ProviderCard) => void }) {
  const loopProviders = [...PROVIDERS, ...PROVIDERS];

  return (
    <section id="prestataires" className="relative bg-[#F9F8F6] py-20 sm:py-24 overflow-hidden">
      <style>{`
        @keyframes calm-provider-marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
        .calm-provider-track {
          animation: calm-provider-marquee 90s linear infinite;
          width: max-content;
        }
        .calm-provider-track:hover { animation-play-state: paused; }
      `}</style>

      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 18% 12%, rgba(255,111,199,0.12), transparent 32%), radial-gradient(circle at 84% 20%, rgba(96,165,250,0.14), transparent 34%), radial-gradient(ellipse at 50% 100%, rgba(251,191,36,0.08), transparent 48%)',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 mb-9">
        <p className="text-xs font-bold text-gray-400 tracking-[0.2em] uppercase mb-3">
          Prestataires en douceur
        </p>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <h2
            style={{ fontFamily: "'Inter', sans-serif" }}
            className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white leading-tight max-w-2xl"
          >
            Les cartes restent tranquilles.
            <br />
            Cerise fait le tri dans la discussion.
          </h2>
          <p className="text-sm text-gray-500 max-w-sm leading-relaxed">
            Une bande vivante pour sentir l’écosystème. Les vrais choix apparaissent dans le bloc Cerise, au bon moment.
          </p>
        </div>
      </div>

      <div className="relative overflow-hidden">
        <div className="calm-provider-track flex gap-5 px-4 sm:px-6">
          {loopProviders.map((provider, index) => {
            const Icon = PROVIDER_CATEGORIES.find((c) => c.key === provider.category)?.icon ?? Sparkles;

            return (
              <article
                key={`${provider.id}-${index}`}
                className="group relative w-[280px] sm:w-[330px] h-[390px] rounded-[28px] overflow-hidden shadow-[0_10px_30px_rgba(0,0,0,0.10)] flex-shrink-0 bg-black"
              >
                <img
                  src={provider.image}
                  alt={provider.name}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/82 via-black/28 to-black/10" />

                <div className="absolute top-4 left-4 right-4 flex items-start justify-between gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-white/16 backdrop-blur-md border border-white/20 flex items-center justify-center text-white">
                    <Icon className="w-5 h-5" />
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-white bg-black/25 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-full">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    {provider.rating.toFixed(1)}
                  </div>
                </div>

                <div className="absolute left-0 right-0 bottom-0 p-5">
                  <p className="text-[10px] font-bold tracking-[0.22em] uppercase text-white/65 mb-2">
                    {PROVIDER_CATEGORIES.find((c) => c.key === provider.category)?.label}
                  </p>

                  <h3 className="text-2xl font-semibold text-white tracking-tight leading-tight">
                    {provider.name}
                  </h3>

                  <div className="flex items-center gap-1.5 text-sm text-white/70 mt-2">
                    <MapPin className="w-4 h-4" />
                    {provider.location}
                  </div>

                  <p className="text-sm text-white/80 leading-relaxed mt-4 min-h-[58px]">
                    {provider.description}
                  </p>

                  <div className="mt-5 pt-4 border-t border-white/15 flex items-end justify-between gap-3">
                    <div>
                      <p className="text-[10px] text-white/50 uppercase tracking-[0.18em]">
                        À partir de
                      </p>
                      <p className="text-xl font-semibold text-white mt-1">
                        {provider.priceFrom}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onProviderClick(provider)}
                      className="text-xs font-semibold text-black bg-white hover:bg-gray-100 px-4 py-2.5 rounded-xl transition-colors shadow-sm"
                    >
                      Voir
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ─── AIME ecosystem bridge ──────────────────────────────────────────────────

const RIPPLE_STEPS = [
  {
    index: '01',
    label: 'Intention',
    title: 'Vous formulez ce qui compte',
    description: 'Une date, une sensation, une contrainte ou une envie devient le point de départ.',
  },
  {
    index: '02',
    label: 'Propagation',
    title: 'Cerise mesure les conséquences',
    description: 'Chaque choix se propage vers les lieux, les prestataires, le budget et le rythme de la journée.',
  },
  {
    index: '03',
    label: 'Composition',
    title: 'La timeline prend forme',
    description: 'Les décisions compatibles se rejoignent dans un déroulé vivant, clair et modifiable.',
  },
];

function AimeRippleBridge() {
  return (
    <section
      id="aime-system"
      className="relative overflow-hidden bg-[#11100f] px-4 py-24 text-[#f3efe7] sm:px-6 sm:py-32"
    >
      <div className="pointer-events-none absolute inset-0 opacity-70">
        <div className="absolute left-[-10rem] top-[-12rem] h-[34rem] w-[34rem] rounded-full border border-[#d7a6a0]/20" />
        <div className="absolute left-[-5rem] top-[-7rem] h-[24rem] w-[24rem] rounded-full border border-[#d7a6a0]/15" />
        <div className="absolute right-[-12rem] bottom-[-14rem] h-[38rem] w-[38rem] rounded-full border border-[#8ca99d]/15" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_18%,rgba(215,166,160,0.12),transparent_34%),radial-gradient(circle_at_82%_76%,rgba(140,169,157,0.09),transparent_32%)]" />
      </div>

      <div className="relative mx-auto max-w-6xl">
        <div className="grid gap-12 lg:grid-cols-[0.82fr_1.18fr] lg:gap-20">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.65 }}
            className="lg:sticky lg:top-28 lg:self-start"
          >
            <div className="mb-8 flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-white/[0.04]">
                <Waves className="h-4 w-4 text-[#d7a6a0]" />
              </span>
              <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-white/45">
                Le système AIME
              </p>
            </div>

            <h2
              style={{ fontFamily: "'Inter', sans-serif" }}
              className="max-w-lg text-4xl font-medium leading-[1.02] tracking-[-0.03em] sm:text-5xl lg:text-[64px]"
            >
              Une intention.
              <br />
              <span className="italic text-[#d7a6a0]">Toute une onde.</span>
            </h2>

            <p className="mt-7 max-w-md text-sm leading-7 text-white/55 sm:text-base">
              AIME Wedding applique la logique causale d’AIME Ripple au mariage : rien n’est une carte isolée. Chaque décision transforme la suite.
            </p>

            <a
              href="https://aimeripple.netlify.app/"
              target="_blank"
              rel="noreferrer"
              className="group mt-9 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.05] px-5 py-3 text-xs font-semibold text-white transition-all hover:border-[#d7a6a0]/55 hover:bg-[#d7a6a0] hover:text-[#191514] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d7a6a0] focus-visible:ring-offset-4 focus-visible:ring-offset-[#11100f]"
            >
              Explorer AIME Ripple
              <ExternalLink className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </motion.div>

          <div className="relative">
            <div className="absolute bottom-10 left-[19px] top-10 w-px bg-gradient-to-b from-[#d7a6a0]/70 via-white/15 to-[#8ca99d]/60 sm:left-[27px]" />

            <div className="space-y-5 sm:space-y-6">
              {RIPPLE_STEPS.map((step, index) => (
                <motion.article
                  key={step.index}
                  initial={{ opacity: 0, x: 18 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-70px' }}
                  transition={{ duration: 0.55, delay: index * 0.1 }}
                  className="group relative grid grid-cols-[40px_1fr] gap-4 sm:grid-cols-[56px_1fr] sm:gap-6"
                >
                  <div className="relative z-10 mt-7 flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-[#11100f] font-mono text-[10px] tracking-[0.12em] text-white/45 transition-colors group-hover:border-[#d7a6a0]/60 group-hover:text-[#d7a6a0] sm:h-14 sm:w-14">
                    {step.index}
                  </div>

                  <div className="rounded-[28px] border border-white/10 bg-white/[0.045] p-6 backdrop-blur-sm transition-all duration-300 group-hover:-translate-y-1 group-hover:border-white/20 group-hover:bg-white/[0.065] sm:p-8">
                    <p className="mb-4 text-[10px] font-semibold uppercase tracking-[0.28em] text-[#d7a6a0]">
                      {step.label}
                    </p>
                    <h3 className="text-xl font-semibold tracking-[-0.02em] text-white sm:text-2xl">
                      {step.title}
                    </h3>
                    <p className="mt-3 max-w-xl text-sm leading-6 text-white/50 sm:text-[15px]">
                      {step.description}
                    </p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Cerise Provider Modal ────────────────────────────────────────────────────

function ProviderCeriseModal({
  provider,
  hasTimeline,
  onClose,
  onRemember,
  onAddToTimeline,
}: {
  provider: ProviderCard;
  hasTimeline: boolean;
  onClose: () => void;
  onRemember: () => void;
  onAddToTimeline: () => void;
}) {
  const Icon = PROVIDER_CATEGORIES.find((c) => c.key === provider.category)?.icon ?? Sparkles;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[80] bg-black/55 backdrop-blur-md flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 12, scale: 0.98 }}
        transition={{ duration: 0.25 }}
        className="relative w-full max-w-xl overflow-hidden rounded-[32px] bg-black shadow-2xl"
      >
        <img
          src={provider.image}
          alt={provider.name}
          className="absolute inset-0 w-full h-full object-cover"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/55 to-black/20" />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/15 flex items-center justify-center text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="relative z-10 p-5 sm:p-7 min-h-[560px] flex flex-col justify-end">
          <div className="absolute top-5 left-5 flex items-center gap-2">
            <div className="w-11 h-11 rounded-2xl bg-white/16 backdrop-blur-md border border-white/20 flex items-center justify-center text-white">
              <Icon className="w-5 h-5" />
            </div>

            <div className="flex items-center gap-1.5 text-xs text-white bg-black/25 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-full">
              <Star className="w-3.5 h-3.5 fill-current" />
              {provider.rating.toFixed(1)}
            </div>
          </div>

          <div className="mb-5">
            <p className="text-[10px] font-bold tracking-[0.22em] uppercase text-white/60 mb-2">
              {PROVIDER_CATEGORIES.find((c) => c.key === provider.category)?.label}
            </p>

            <h3 className="text-3xl sm:text-4xl font-semibold text-white tracking-tight leading-tight">
              {provider.name}
            </h3>

            <div className="flex items-center gap-1.5 text-sm text-white/70 mt-2">
              <MapPin className="w-4 h-4" />
              {provider.location}
            </div>

            <p className="text-sm text-white/82 leading-relaxed mt-4">
              {provider.description}
            </p>
          </div>

          <div className="bg-white/12 backdrop-blur-xl border border-white/18 rounded-3xl p-4 sm:p-5 text-white shadow-2xl">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-white text-black flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>

              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/50 mb-1">
                  Cerise
                </p>

                <p className="text-sm sm:text-base leading-relaxed font-medium">
                  Voulez-vous que je garde en mémoire ce prestataire et que je le rajoute à votre timeline ?
                </p>

                {!hasTimeline && (
                  <p className="text-xs text-white/55 leading-relaxed mt-2">
                    La timeline n’est pas encore créée. Je peux déjà préparer ce prestataire pour la génération.
                  </p>
                )}
              </div>
            </div>

            <div className="mt-5 flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={onRemember}
                className="flex-1 px-4 py-3 rounded-2xl bg-white/12 hover:bg-white/18 border border-white/15 text-white text-sm font-semibold transition-colors"
              >
                Garder en mémoire
              </button>

              <button
                type="button"
                onClick={onAddToTimeline}
                className="flex-1 px-4 py-3 rounded-2xl bg-white text-black hover:bg-gray-100 text-sm font-semibold transition-colors"
              >
                {hasTimeline ? 'Ajouter à la timeline' : 'Préparer pour la timeline'}
              </button>
            </div>

            <div className="mt-3 flex items-center justify-between gap-3 text-xs text-white/50">
              <span>À partir de {provider.priceFrom}</span>
              <span>{provider.available ? 'Disponible à vérifier' : 'Disponibilité à confirmer'}</span>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── App ─────────────────────────────────────────────────────────────────────

export default function WeddingOS() {
  const [phase, setPhase] = useState<Phase>('initial');
  const [inputVal, setInputVal] = useState('');
  const [weddingDate, setWeddingDate] = useState('');
  const [events, setEvents] = useState<WeddingEvent[]>([]);
  const [config, setConfig] = useState<WeddingConfig | null>(null);
  const [analysis, setAnalysis] = useState<WeddingAnalysis | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatBusy, setChatBusy] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hasRestore, setHasRestore] = useState(false);
  const [prevScore, setPrevScore] = useState<number | null>(null);
  const [showMilestone, setShowMilestone] = useState(false);
  const [showVideoIntro, setShowVideoIntro] = useState(false);

  const [ceriseAlerts, setCeriseAlerts] = useState<WeddingAlert[]>([]);
  const [selectedProvider, setSelectedProvider] = useState<ProviderCard | null>(null);
  const [preparedProviders, setPreparedProviders] = useState<ProviderCard[]>([]);

  const [undoStack, setUndoStack] = useState<WeddingEvent[][]>([]);
  const [redoStack, setRedoStack] = useState<WeddingEvent[][]>([]);

  const [auth, setAuth] = useState<AuthState | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'default' | 'guest'>('default');
  const [cloudSaving, setCloudSaving] = useState(false);
  const [cloudSaved, setCloudSaved] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  useEffect(() => {
    const savedAuth = localStorage.getItem('aime_auth');
    if (savedAuth) {
      try {
        setAuth(JSON.parse(savedAuth));
      } catch {}
    }

    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        JSON.parse(saved);
        setHasRestore(true);
      } catch {}
    }
  }, []);

  useEffect(() => {
    if (phase === 'active' && config) {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ events, config, inputVal, weddingDate })
      );
    }
  }, [phase, events, config, inputVal, weddingDate]);

  useEffect(() => {
    if (!auth || phase !== 'active' || !config) return;

    const t = setTimeout(() => cloudSave(events, config), 2000);
    return () => clearTimeout(t);
  }, [events, config, auth, phase]);

  const cloudSave = async (evts: WeddingEvent[], cfg: WeddingConfig) => {
    if (!auth) return;

    setCloudSaving(true);

    try {
      await fetch(`${API}/wedding/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${auth.token}`,
        },
        body: JSON.stringify({
          events: evts,
          config: cfg,
          inputVal,
          weddingDate,
        }),
      });

      setCloudSaved(true);
      setTimeout(() => setCloudSaved(false), 3000);
    } catch (e) {
      console.error('Cloud save error:', e);
    }

    setCloudSaving(false);
  };

  const cloudLoad = async (
    token: string
  ): Promise<{
    events: WeddingEvent[];
    config: WeddingConfig;
    inputVal: string;
    weddingDate: string;
  } | null> => {
    try {
      const res = await fetch(`${API}/wedding/load`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) return null;

      const data = await res.json();
      return data.wedding || null;
    } catch {
      return null;
    }
  };

  useEffect(() => {
    if (analysis) {
      if (prevScore !== null && prevScore < 80 && analysis.score >= 80) {
        setShowMilestone(true);
        setTimeout(() => setShowMilestone(false), 5000);
      }

      setPrevScore(analysis.score);
    }
  }, [analysis?.score]);

  const pushUndo = useCallback((before: WeddingEvent[]) => {
    setUndoStack((s) => [...s.slice(-29), before]);
    setRedoStack([]);
  }, []);

  const handleUndo = useCallback(() => {
    setUndoStack((stack) => {
      if (!stack.length) return stack;

      const prev = stack[stack.length - 1];

      setRedoStack((r) => [events, ...r.slice(0, 29)]);
      setEvents(prev);

      if (config) setAnalysis(analyzeWedding(prev, config));

      return stack.slice(0, -1);
    });
  }, [events, config]);

  const handleRedo = useCallback(() => {
    setRedoStack((stack) => {
      if (!stack.length) return stack;

      const next = stack[0];

      setUndoStack((u) => [...u.slice(-29), events]);
      setEvents(next);

      if (config) setAnalysis(analyzeWedding(next, config));

      return stack.slice(1);
    });
  }, [events, config]);

  const handleRestore = () => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return;

      const {
        events: evts,
        config: cfg,
        inputVal: inp,
        weddingDate: wd,
      } = JSON.parse(saved);

      const sorted = sortByTime(evts);

      setEvents(sorted);
      setConfig(cfg);
      setInputVal(inp || '');
      setWeddingDate(wd || '');
      setAnalysis(analyzeWedding(sorted, cfg));
      setPhase('active');
      setHasRestore(false);
    } catch {}
  };

  const handleAuth = async (state: AuthState) => {
    setAuth(state);
    localStorage.setItem('aime_auth', JSON.stringify(state));
    setShowAuthModal(false);

    const cloud = await cloudLoad(state.token);

    if (cloud) {
      const sorted = sortByTime(cloud.events);

      setEvents(sorted);
      setConfig(cloud.config);
      setInputVal(cloud.inputVal || '');
      setWeddingDate(cloud.weddingDate || '');
      setAnalysis(analyzeWedding(sorted, cloud.config));
      setPhase('active');
      setHasRestore(false);
    }
  };

  const handleLogout = () => {
    setAuth(null);
    localStorage.removeItem('aime_auth');
  };

  const generateWedding = useCallback(
    async (prompt: string, providerList: ProviderCard[] = []) => {
      if (!prompt.trim() && providerList.length === 0) return;

      setPhase('generating');
      await new Promise((r) => setTimeout(r, 1100));

      const { events: evts, config: cfg } = parseWeddingInput(prompt || 'Mariage à organiser');
      const cfgWithDate: WeddingConfig = {
        ...cfg,
        weddingDate: weddingDate || undefined,
      };

      const providerEvents = uniqueProviders([...preparedProviders, ...providerList]).map((provider, index) =>
        providerToWeddingEvent(provider, index)
      );

      const sortedEvents = sortByTime([...evts, ...providerEvents]);
      const ana = analyzeWedding(sortedEvents, cfgWithDate);

      setEvents(sortedEvents);
      setConfig(cfgWithDate);
      setAnalysis(ana);
      setPrevScore(ana.score);
      setMessages([]);
      setUndoStack([]);
      setRedoStack([]);
      setCeriseAlerts([]);
      setPhase('active');
      setInputVal(prompt);

      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [preparedProviders, weddingDate]
  );

  const handleChatSend = useCallback(
    async (text: string) => {
      if (!config || chatBusy) return;

      setChatBusy(true);

      const userMsgId = cuid();
      const ceriseTypId = cuid();

      setMessages((p) => [
        ...p,
        { id: userMsgId, role: 'user', text },
        { id: ceriseTypId, role: 'cerise', text: '', typing: true },
      ]);

      let replyText = '';
      let replySugg = '';
      let updatedEvts = events;

      try {
        const historyForAPI = messages
          .filter((m) => !m.typing && m.text)
          .slice(-12)
          .map((m) => ({ role: m.role, text: m.text }));

        const res = await fetch(`${API}/cerise/chat`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer public',
          },
          body: JSON.stringify({
            message: text,
            events,
            config,
            history: historyForAPI,
          }),
        });

        if (res.ok) {
          const data = await res.json();

          replyText = data.message || 'Réponse reçue.';
          replySugg = data.suggestion || '';

          if (data.actions?.length) {
            pushUndo(events);

            let current = [...events];
            const newCeriseAlerts: typeof ceriseAlerts = [];

            for (const action of data.actions as {
              type: string;
              data: Record<string, unknown>;
            }[]) {
              switch (action.type) {
                case 'add_event': {
                  const d = action.data;

                  current = [
                    ...current,
                    {
                      id: cuid(),
                      title: (d.title as string) || 'Nouvel événement',
                      time: (d.time as string) || '18:00',
                      category: (d.category as EventCategory) || 'other',
                      description: (d.description as string) || '',
                      status: 'pending' as const,
                      tasks: makeTasks((d.category as EventCategory) || 'other'),
                      isNew: true,
                    },
                  ];

                  break;
                }

                case 'update_event': {
                  const d = action.data;
                  const eid = d.eventId as string;

                  if (eid) {
                    current = current.map((e) =>
                      e.id === eid ? { ...e, ...d, id: e.id } : e
                    );
                  }

                  break;
                }

                case 'delete_event': {
                  const eid = action.data.eventId as string;
                  if (eid) current = current.filter((e) => e.id !== eid);
                  break;
                }

                case 'add_alert': {
                  const d = action.data;

                  newCeriseAlerts.push({
                    id: cuid(),
                    severity: (d.severity as AlertSeverity) || 'warning',
                    message: (d.message as string) || '',
                    action: (d.action as string) || undefined,
                  });

                  break;
                }

                case 'suggest_action': {
                  if (!replySugg && action.data.label) {
                    replySugg = action.data.label as string;
                  }

                  break;
                }
              }
            }

            updatedEvts = sortByTime(current);

            if (newCeriseAlerts.length) {
              setCeriseAlerts((prev) => [...prev, ...newCeriseAlerts]);
            }
          }
        } else {
          console.warn('Cerise API unavailable offline fallback');

          const { updatedEvents, response } = parseChatCommand(text, events, config);

          updatedEvts = updatedEvents;
          replyText = response;

          pushUndo(events);
        }
      } catch (e) {
        console.error('Chat error:', e);

        const { updatedEvents, response } = parseChatCommand(text, events, config);

        updatedEvts = updatedEvents;
        replyText = response;

        pushUndo(events);
      }

      setEvents(updatedEvts);

      if (config) setAnalysis(analyzeWedding(updatedEvts, config));

      setMessages((p) => [
        ...p.filter((m) => !m.typing),
        {
          id: ceriseTypId,
          role: 'cerise',
          text: replyText,
          suggestion: replySugg || undefined,
        },
      ]);

      setChatBusy(false);
    },
    [config, events, chatBusy, pushUndo, messages, ceriseAlerts]
  );

  const handleActionClick = (action: string) => handleChatSend(action);

  const handleProviderClick = (provider: ProviderCard) => {
    setSelectedProvider(provider);
  };

  const handleRememberProviderOnly = (provider: ProviderCard) => {
    saveProviderToMemory(provider);
    setSelectedProvider(null);
  };

  const handleAddProviderToTimeline = (provider: ProviderCard) => {
    saveProviderToMemory(provider);

    if (!config) {
      setPreparedProviders((prev) => uniqueProviders([...prev, provider]));
      setSelectedProvider(null);
      return;
    }

    pushUndo(events);

    const newEvent = providerToWeddingEvent(provider);
    const updatedEvents = sortByTime([...events, newEvent]);

    setEvents(updatedEvents);
    setAnalysis(analyzeWedding(updatedEvents, config));
    setSelectedProvider(null);
  };

  const handleDeleteEvent = useCallback(
    (id: string) => {
      pushUndo(events);

      setEvents((p) => {
        const upd = p.filter((e) => e.id !== id);

        if (config) setAnalysis(analyzeWedding(upd, config));

        return upd;
      });
    },
    [events, config, pushUndo]
  );

  const handleUpdateEvent = useCallback(
    (id: string, fields: Partial<WeddingEvent>) => {
      if (!('tasks' in fields)) pushUndo(events);

      setEvents((p) => {
        const upd = sortByTime(
          p.map((e) => (e.id === id ? { ...e, ...fields } : e))
        );

        if (config) setAnalysis(analyzeWedding(upd, config));

        return upd;
      });
    },
    [events, config, pushUndo]
  );

  const handleReset = () => {
    setPhase('initial');
    setEvents([]);
    setConfig(null);
    setAnalysis(null);
    setMessages([]);
    setPrevScore(null);
    setUndoStack([]);
    setRedoStack([]);
    window.scrollTo({ top: 0 });
  };

  const openGuestAccess = () => {
    setAuthModalMode('guest');
    setShowAuthModal(true);
  };

  const closeVideoIntro = () => {
    localStorage.setItem(VIDEO_INTRO_KEY, '1');
    setShowVideoIntro(false);
    requestAnimationFrame(() => {
      document.getElementById('cerise-start')?.scrollIntoView({ behavior: 'smooth' });
    });
  };

  const daysLeft = computeDaysLeft(config?.weddingDate || weddingDate || undefined);
  const navDark = phase !== 'active' && !scrolled;

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* ── Navbar ────────────────────────────────────────────────────────── */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          navDark
            ? 'bg-transparent'
            : 'aime-system-nav'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <AimeLogoIcon size={16} color="white" />

            <span
              style={{
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                fontWeight: 700,
                letterSpacing: '-0.01em',
              }}
              className={`text-base transition-colors truncate ${
                navDark ? 'text-white' : 'text-black'
              }`}
            >
              AIME
              <sup
                style={{
                  fontSize: '0.55em',
                  verticalAlign: 'super',
                  fontWeight: 700,
                }}
              >
                ®
              </sup>

              <span
                style={{ fontWeight: 400, marginLeft: '0.3em' }}
                className={`text-sm transition-colors ${
                  navDark ? 'text-white/70' : 'text-gray-500'
                }`}
              >
                Wedding
              </span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            {phase !== 'active' && (
              <>
                <a
                  href="#prestataires"
                  className={`hidden sm:flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-xl transition-all ${
                    navDark
                      ? 'text-white/80 hover:text-white border border-white/20 hover:bg-white/10'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-black'
                  }`}
                >
                  Prestataires
                </a>

                <a
                  href="#cerise-start"
                  className={`hidden sm:flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-xl transition-all ${
                    navDark
                      ? 'text-white/80 hover:text-white border border-white/20 hover:bg-white/10'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-black'
                  }`}
                >
                  Timeline
                </a>

                <a
                  href="#aime-system"
                  className={`hidden md:flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-xl transition-all ${
                    navDark
                      ? 'text-white/80 hover:text-white border border-white/20 hover:bg-white/10'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-black'
                  }`}
                >
                  Système AIME
                </a>

                <a
                  href="#cerise-start"
                  className={`flex sm:hidden items-center gap-1.5 text-xs font-medium px-2 py-1.5 rounded-xl transition-all ${
                    navDark
                      ? 'text-white/80 hover:text-white border border-white/20 hover:bg-white/10'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-black'
                  }`}
                >
                  Timeline
                </a>
              </>
            )}

            <button
              type="button"
              onClick={openGuestAccess}
              className={`hidden sm:flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-xl transition-all ${
                navDark
                  ? 'text-white/80 hover:text-white border border-white/20 hover:bg-white/10'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-black'
              }`}
            >
              Accès invités
            </button>

            {phase === 'active' && config && (
              <>
                {daysLeft !== null && daysLeft > 0 && (
                  <span className="text-xs font-bold text-black bg-gray-100 px-3 py-1 rounded-full hidden sm:block">
                    J-{daysLeft}
                  </span>
                )}

                <button
                  onClick={handleUndo}
                  disabled={!undoStack.length}
                  className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30"
                  title="Annuler"
                >
                  <Undo2 className="w-4 h-4 text-gray-600" />
                </button>

                <button
                  onClick={handleRedo}
                  disabled={!redoStack.length}
                  className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30"
                  title="Rétablir"
                >
                  <Redo2 className="w-4 h-4 text-gray-600" />
                </button>

                {auth && (
                  <span
                    className={`hidden sm:flex items-center gap-1.5 text-[10px] px-2.5 py-1.5 rounded-full transition-all ${
                      cloudSaving
                        ? 'text-gray-400'
                        : cloudSaved
                          ? 'text-black bg-gray-100'
                          : 'text-gray-400'
                    }`}
                  >
                    <Cloud className="w-3 h-3" />
                    {cloudSaving ? 'Sauvegarde…' : cloudSaved ? 'Sauvegardé' : 'Cloud'}
                  </span>
                )}
              </>
            )}

            {auth ? (
              <div className="flex items-center gap-2">
                <span className={`text-xs hidden sm:block ${navDark ? 'text-white/70' : 'text-gray-500'}`}>
                  {auth.name}
                </span>

                <button
                  onClick={handleLogout}
                  className={`flex items-center gap-1.5 text-xs px-2 sm:px-3 py-1.5 rounded-xl transition-all ${
                    navDark
                      ? 'text-white/70 hover:text-white'
                      : 'text-gray-500 hover:bg-gray-100 hover:text-black'
                  }`}
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setAuthModalMode('default');
                  setShowAuthModal(true);
                }}
                className={`flex items-center gap-1.5 text-xs font-medium px-2 sm:px-3 py-1.5 rounded-xl transition-all ${
                  navDark
                    ? 'text-white/80 hover:text-white border border-white/20 hover:bg-white/10'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-black'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span className="hidden sm:block">Connexion</span>
              </button>
            )}

            {phase === 'active' && (
              <button
                onClick={handleReset}
                className={`flex items-center gap-1.5 text-xs px-2 sm:px-3 py-1.5 rounded-xl transition-all ${
                  navDark
                    ? 'text-white/70 hover:text-white'
                    : 'text-gray-500 hover:bg-gray-100 hover:text-black'
                }`}
              >
                <RotateCcw className="w-3 h-3" />
                <span className="hidden sm:block">Recommencer</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {showMilestone && (
          <motion.div
            initial={{ opacity: 0, y: -60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -60 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-[60] bg-black text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3"
          >
            <span className="text-xl">🎉</span>
            <p className="text-sm font-semibold">
              Votre mariage est prêt à plus de 80 % !
            </p>

            <button
              onClick={() => setShowMilestone(false)}
              className="ml-2 text-white/50 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAuthModal && (
          <AuthModal
            mode={authModalMode}
            onClose={() => setShowAuthModal(false)}
            onAuth={handleAuth}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedProvider && (
          <ProviderCeriseModal
            provider={selectedProvider}
            hasTimeline={phase === 'active' && !!config}
            onClose={() => setSelectedProvider(null)}
            onRemember={() => handleRememberProviderOnly(selectedProvider)}
            onAddToTimeline={() => handleAddProviderToTimeline(selectedProvider)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {phase !== 'active' && (
          <motion.div
            key="landing"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
          >
            <CeriseConversationSection
              value={inputVal}
              onChange={setInputVal}
              loading={phase === 'generating'}
              onGenerateFromConversation={(prompt, providers) => generateWedding(prompt, providers)}
              onProviderClick={handleProviderClick}
            />

            <AimeRippleBridge />

            {hasRestore && (
              null
            )}

            <CalmProviderStrip onProviderClick={handleProviderClick} />

            <section className="bg-black py-20 sm:py-24 px-4 sm:px-6 border-t border-white/10">
              <div className="max-w-5xl mx-auto">
                <div className="text-center mb-14">
                  <p className="text-xs font-bold text-neutral-400 tracking-[0.2em] uppercase mb-3">
                    Ce que fait AIME
                  </p>

                  <h2
                    style={{ fontFamily: "'Inter', sans-serif" }}
                    className="text-3xl font-semibold text-white tracking-tight"
                  >
                    Un système qui pense avec vous
                  </h2>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  {FEATURES.map((f, i) => (
                    <motion.div
                      key={f.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1, duration: 0.5 }}
                      className="bg-[#0b0b0d] rounded-2xl border border-white/10 p-8 hover:border-white/20 transition-all text-white"
                    >
                      <div className="text-2xl text-cyan-400 mb-5 font-light">
                        {f.icon}
                      </div>

                      <h3 className="text-base font-semibold text-white mb-3 leading-snug">
                        {f.title}
                      </h3>

                      <p className="text-sm text-neutral-400 leading-relaxed">
                        {f.desc}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            <section className="relative h-[420px] overflow-hidden flex items-center justify-center">
              <ParallaxBg
                src={PHOTOS.mid}
                overlay="bg-black/50"
                position="center center"
                mobilePosition="center center"
                speed={100}
                mobileSpeed={40}
                scale={1.14}
                mobileScale={1.08}
              />

              <div className="relative z-10 text-center px-6 max-w-2xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.7 }}
                >
                  <p
                    style={{ fontFamily: "'Inter', sans-serif" }}
                    className="text-3xl md:text-4xl text-white font-medium leading-snug italic"
                  >
                    &quot;La plus belle journée de votre vie,
                    <br />
                    organisée à la perfection.&quot;
                  </p>
                </motion.div>
              </div>
            </section>

            <section className="relative overflow-hidden bg-black">
              <ParallaxBg
                src={PHOTOS.footer}
                overlay="bg-black/60"
                position="center center"
                mobilePosition="center center"
                speed={95}
                mobileSpeed={38}
                scale={1.14}
                mobileScale={1.08}
              />

              <div className="relative z-10 py-24 sm:py-28 px-4 sm:px-6 flex flex-col items-center text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="mb-8"
                >
                  <h2
                    style={{ fontFamily: "'Inter', sans-serif" }}
                    className="text-3xl sm:text-4xl font-semibold text-white mb-4"
                  >
                    Reprendre avec Cerise ?
                  </h2>

                  <p className="text-white/60 text-base max-w-xl mx-auto">
                    Revenez à la conversation. Cerise garde le fil, les idées, les cartes et la future timeline.
                  </p>
                </motion.div>

                <a
                  href="#cerise-start"
                  className="inline-flex items-center gap-2 bg-white text-black px-6 py-3 rounded-2xl text-sm font-semibold hover:bg-neutral-200 transition-colors"
                >
                  Continuer avec Cerise
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>

              <div className="relative z-10 border-t border-white/10 px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 max-w-6xl mx-auto w-full">
                <span
                  style={{ fontFamily: "'Inter', sans-serif" }}
                  className="text-white/50 text-sm italic"
                >
                  Comprendre. Structurer. Vérifier. Avancer.
                </span>

                <span className="text-white/30 text-xs">
                  AIME — Wedding OS · Propulsé par Cerise
                </span>
              </div>
            </section>
          </motion.div>
        )}

        {phase === 'active' && analysis && config && (
          <motion.div
            key="dashboard"
            id="timeline-dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.45 }}
            className="min-h-screen bg-black text-white overflow-x-hidden"
          >
            {/* Top Vue d'ensemble Header replacing old banner */}
            <div className="relative pt-20 sm:pt-24 pb-6 px-4 sm:px-6 bg-black border-b border-white/10">
              <div className="max-w-6xl mx-auto">
                <OrbitPanel
                  analysis={{
                    ...analysis,
                    alerts: [
                      ...analysis.alerts,
                      ...ceriseAlerts.filter(
                        (ca) => !analysis.alerts.some((a) => a.message === ca.message)
                      ),
                    ],
                  }}
                  guestCount={config.guestCount}
                  venue={config.venue}
                  daysLeft={daysLeft}
                  onActionClick={handleActionClick}
                />
              </div>
            </div>

            <ParallaxTimelineSection>
              <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 pb-20 sm:pb-24">
                {!auth && phase === 'active' && (
                  <motion.div
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 px-4 py-3 bg-neutral-900/90 border border-white/10 text-white rounded-2xl shadow-lg mb-6"
                  >
                    <div className="flex items-start sm:items-center gap-2.5">
                      <CloudOff className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5 sm:mt-0" />

                      <p className="text-xs text-neutral-300 leading-relaxed">
                        Organisation sauvegardée localement.{' '}
                        <span className="text-white font-medium">
                          Connectez-vous pour y accéder partout.
                        </span>
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setAuthModalMode('default');
                        setShowAuthModal(true);
                      }}
                      className="w-full sm:w-auto flex items-center justify-center gap-1.5 text-xs font-semibold text-black bg-white hover:bg-neutral-200 px-3.5 py-2 sm:py-1.5 rounded-xl transition-colors flex-shrink-0"
                    >
                      <User className="w-3 h-3" />
                      Connexion
                    </button>
                  </motion.div>
                )}

                <div className="w-full">
                  <motion.div
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="mb-6 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2 border-b border-white/10 pb-4"
                  >
                    <div>
                      <p className="text-xs font-bold text-neutral-400 uppercase tracking-[0.2em] mb-1">
                        Déroulé de la journée
                      </p>
                      <p className="text-xs text-neutral-400 leading-relaxed">
                        {events.length} moment{events.length > 1 ? 's' : ''} · Cliquez sur le statut pour le mettre à jour
                      </p>
                    </div>

                    {undoStack.length > 0 && (
                      <button
                        onClick={handleUndo}
                        className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors self-start sm:self-auto bg-white/5 border border-white/10 px-3 py-1.5 rounded-xl"
                      >
                        <Undo2 className="w-3 h-3" />
                        Annuler
                      </button>
                    )}
                  </motion.div>

                  <WeddingTimeline
                    events={events}
                    onDeleteEvent={handleDeleteEvent}
                    onUpdateEvent={handleUpdateEvent}
                  />
                </div>
              </div>
            </ParallaxTimelineSection>

            <div className="border-t border-white/10 py-6 px-4 sm:px-6 bg-black">
              <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <span className="text-neutral-400 text-sm tracking-wide">
                  Comprendre. Structurer. Vérifier. Avancer.
                </span>

                <span className="text-neutral-500 text-xs">
                  AIME Wedding OS
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {phase === 'active' && (
        <CeriseChat
          messages={messages}
          onSend={handleChatSend}
          disabled={chatBusy}
        />
      )}
    </div>
  );
}
