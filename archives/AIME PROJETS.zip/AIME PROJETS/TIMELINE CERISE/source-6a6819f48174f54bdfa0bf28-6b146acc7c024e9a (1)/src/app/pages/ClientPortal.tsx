import { useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check, ChevronRight, FileText, PenLine, CreditCard,
  Loader2, AlertCircle, CheckCheck, ExternalLink,
} from 'lucide-react';
import {
  clientPortalGet, clientPortalAccept, clientPortalSign,
  fmtEur, fmtDate,
  type PipelineQuote, type PipelineContract,
} from '../lib/pipelineApi';
import { AimeLogoIcon } from '../components/AimeLogoIcon';

// ── Types (portal-scoped) ─────────────────────────────────────────────────────

type PortalData = {
  stage: string;
  quote:    PipelineQuote | null;
  contract: (PipelineContract & { prestataire: { name: string } }) | null;
  payment:  { status: string; amountEur: number; checkoutUrl?: string } | null;
};

// ── Step indicator ────────────────────────────────────────────────────────────

const STEPS = [
  { key: 'quote',    label: 'Devis',    icon: FileText    },
  { key: 'contract', label: 'Contrat',  icon: PenLine     },
  { key: 'payment',  label: 'Acompte',  icon: CreditCard  },
  { key: 'done',     label: 'Confirmé', icon: CheckCheck  },
];

function stageToStep(stage: string): number {
  if (stage === 'quoted')    return 0;
  if (stage === 'accepted')  return 0;
  if (stage === 'contract')  return 1;
  if (stage === 'signed')    return 2;
  if (stage === 'payment')   return 2;
  if (stage === 'confirmed') return 3;
  return 0;
}

function StepBar({ step }: { step: number }) {
  return (
    <div className="flex items-center justify-center gap-0 mb-10">
      {STEPS.map(({ label, icon: Icon }, i) => {
        const done   = i < step;
        const active = i === step;
        return (
          <div key={label} className="flex items-center">
            <div className="flex flex-col items-center gap-1.5">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                done   ? 'bg-black text-white' :
                active ? 'bg-black text-white ring-4 ring-black/10' :
                         'bg-gray-100 text-gray-300'
              }`}>
                {done ? <Check className="w-4 h-4" /> : <Icon className="w-3.5 h-3.5" />}
              </div>
              <span className={`text-[10px] font-medium ${active ? 'text-black' : done ? 'text-gray-500' : 'text-gray-300'}`}>
                {label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`h-px w-12 mb-4 transition-colors ${i < step ? 'bg-black' : 'bg-gray-200'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Quote card ────────────────────────────────────────────────────────────────

function QuoteCard({ quote, onAccept, accepting }: {
  quote: PipelineQuote;
  onAccept: () => void;
  accepting: boolean;
}) {
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden">

      <div className="px-8 py-6 border-b border-gray-100 bg-gray-50/50">
        <p className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-semibold">Devis de prestation</p>
        <h2 className="text-xl font-semibold text-black" style={{ fontFamily: "'Inter', sans-serif" }}>
          {quote.service}
        </h2>
        <p className="text-sm text-gray-500 mt-0.5">{fmtDate(quote.eventDate)} · {quote.eventVenue}</p>
      </div>

      <div className="px-8 py-6">
        <div className="grid grid-cols-2 gap-4 mb-6">
          {[
            { label: 'Durée', value: `${quote.duration}h` },
            { label: 'Prestataire', value: 'Matt Mez Sax' },
            { label: 'Montant total', value: fmtEur(quote.amount), big: true },
            { label: `Acompte (${quote.depositPercent}%)`, value: fmtEur(quote.deposit), big: true },
          ].map(({ label, value, big }) => (
            <div key={label} className="bg-gray-50 rounded-2xl p-4">
              <p className="text-xs text-gray-400 mb-1">{label}</p>
              <p className={`font-semibold text-black ${big ? 'text-lg' : 'text-sm'}`}>{value}</p>
            </div>
          ))}
        </div>

        {quote.notes && (
          <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 mb-6">
            <p className="text-xs font-semibold text-amber-700 mb-1">Note de Matt</p>
            <p className="text-sm text-amber-800">{quote.notes}</p>
          </div>
        )}

        {quote.status === 'accepted' ? (
          <div className="flex items-center gap-2.5 px-5 py-3.5 bg-green-50 border border-green-200 rounded-2xl">
            <Check className="w-4 h-4 text-green-600" />
            <p className="text-sm font-semibold text-green-700">Devis accepté · Contrat en cours de préparation</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            <button onClick={onAccept} disabled={accepting}
              className="w-full flex items-center justify-center gap-2.5 px-6 py-4 bg-black hover:bg-gray-800 text-white font-semibold rounded-2xl transition-all active:scale-[0.98] disabled:opacity-60">
              {accepting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {accepting ? 'Traitement…' : 'Accepter ce devis'}
            </button>
            <p className="text-xs text-center text-gray-400">
              En acceptant, un contrat vous sera préparé automatiquement.
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ── Contract card ─────────────────────────────────────────────────────────────

function ContractCard({ contract, onSign, signing }: {
  contract: PortalData['contract'];
  onSign: (name: string) => void;
  signing: boolean;
}) {
  const [signName, setSignName] = useState('');
  const [showSign, setShowSign] = useState(false);

  if (!contract) return null;
  const clientSigned = !!contract.signatures.client;
  const allSigned    = clientSigned && !!contract.signatures.vendor;

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden">

      <div className="px-8 py-6 border-b border-gray-100 bg-gray-50/50">
        <p className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-semibold">Contrat de prestation</p>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-black" style={{ fontFamily: "'Inter', sans-serif" }}>
            {contract.service}
          </h2>
          <span className={`text-xs px-2.5 py-1 rounded-xl font-semibold ${
            allSigned ? 'bg-green-100 text-green-700' :
            clientSigned ? 'bg-yellow-100 text-yellow-700' :
            'bg-amber-100 text-amber-700'
          }`}>
            {allSigned ? '✓ Signé' : clientSigned ? 'En attente prestataire' : 'À signer'}
          </span>
        </div>
      </div>

      {/* Parties */}
      <div className="px-8 py-5 border-b border-gray-100 grid grid-cols-2 gap-4">
        <div>
          <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Le client</p>
          <p className="text-sm font-medium text-black">{contract.client.name}</p>
          <p className="text-xs text-gray-400">{contract.client.email}</p>
        </div>
        <div>
          <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Le prestataire</p>
          <p className="text-sm font-medium text-black">{contract.prestataire.name}</p>
        </div>
      </div>

      {/* Conditions */}
      <details className="px-8 py-5 border-b border-gray-100">
        <summary className="text-sm font-medium text-black cursor-pointer select-none">
          Lire les conditions ({contract.conditions.length} articles)
        </summary>
        <ol className="mt-4 space-y-3">
          {contract.conditions.map((cond, i) => (
            <li key={i} className="text-xs text-gray-600 leading-relaxed">
              <span className="font-semibold text-gray-400 mr-1">Art. {i + 1}.</span>{cond}
            </li>
          ))}
        </ol>
      </details>

      {/* Signature status */}
      <div className="px-8 py-5 space-y-3">
        {[
          { who: 'Ma signature (client)', sig: contract.signatures.client },
          { who: `Signature ${contract.prestataire.name}`, sig: contract.signatures.vendor },
        ].map(({ who, sig }) => (
          <div key={who} className={`flex items-center justify-between p-3.5 rounded-xl border ${sig ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
            <div className="flex items-center gap-2.5">
              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${sig ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                {sig ? '✓' : '·'}
              </div>
              <div>
                <p className="text-xs font-medium text-black">{who}</p>
                {sig && <p className="text-[10px] text-gray-400">{sig.name} · {fmtDate(sig.signedAt)}</p>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Sign action */}
      {!clientSigned && (
        <div className="px-8 pb-6">
          {!showSign ? (
            <button onClick={() => setShowSign(true)}
              className="w-full flex items-center justify-center gap-2.5 px-6 py-4 bg-black hover:bg-gray-800 text-white font-semibold rounded-2xl transition-all">
              <PenLine className="w-4 h-4" /> Signer le contrat
            </button>
          ) : (
            <div className="space-y-3 bg-gray-50 rounded-2xl p-5">
              <p className="text-sm text-black font-medium">Signez en tapant votre nom complet :</p>
              <input
                value={signName}
                onChange={e => setSignName(e.target.value)}
                placeholder={contract.client.name}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-black bg-white focus:outline-none focus:border-gray-400 transition-colors"
                style={{ fontFamily: "'Inter', sans-serif", fontSize: '15px' }}
              />
              <div className="flex gap-2">
                <button onClick={() => setShowSign(false)} className="flex-1 py-2.5 border border-gray-200 text-gray-500 rounded-xl text-sm hover:bg-gray-100 transition-colors">
                  Annuler
                </button>
                <button
                  onClick={() => onSign(signName || contract.client.name)}
                  disabled={signing || !signName.trim()}
                  className="flex-1 py-2.5 bg-black text-white font-semibold rounded-xl text-sm hover:bg-gray-800 disabled:opacity-40 transition-all flex items-center justify-center gap-2"
                >
                  {signing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  {signing ? 'Signature…' : 'Confirmer'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

// ── Payment card ──────────────────────────────────────────────────────────────

function PaymentCard({ payment }: { payment: NonNullable<PortalData['payment']> }) {
  const paid = payment.status === 'paid';

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className={`rounded-3xl border shadow-lg overflow-hidden ${paid ? 'bg-green-50 border-green-200' : 'bg-white border-gray-100'}`}>
      <div className="px-8 py-6">
        <p className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-semibold">Acompte de réservation</p>
        <p className="text-3xl font-bold text-black mb-1">{fmtEur(payment.amountEur)}</p>
        {paid ? (
          <div className="flex items-center gap-2 mt-4 px-5 py-3 bg-green-100 rounded-2xl">
            <CheckCheck className="w-4 h-4 text-green-600" />
            <p className="text-sm font-semibold text-green-700">Acompte reçu — prestation confirmée ✓</p>
          </div>
        ) : payment.checkoutUrl ? (
          <div className="mt-5">
            <a href={payment.checkoutUrl} target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2.5 px-6 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-2xl transition-all">
              <CreditCard className="w-4 h-4" /> Payer l'acompte par carte
              <ExternalLink className="w-3.5 h-3.5 opacity-70" />
            </a>
            <p className="text-xs text-center text-gray-400 mt-2">Paiement sécurisé via Stripe</p>
          </div>
        ) : (
          <div className="mt-4 px-5 py-3 bg-amber-50 border border-amber-100 rounded-2xl">
            <p className="text-sm text-amber-700">
              Le lien de paiement est en cours de préparation. Matt vous contactera prochainement.
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────

export default function ClientPortal() {
  const { token }             = useParams<{ token: string }>();
  const [searchParams]        = useSearchParams();
  const [data,   setData]     = useState<PortalData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error,  setError]    = useState('');
  const [accepting, setAccepting] = useState(false);
  const [signing,   setSigning]   = useState(false);

  const paymentSuccess = searchParams.get('paid') === 'true';

  const load = async () => {
    if (!token) return;
    try {
      const d = await clientPortalGet(token);
      setData(d);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Lien invalide ou expiré.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [token]);

  const handleAccept = async () => {
    if (!token) return;
    setAccepting(true);
    try {
      await clientPortalAccept(token);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Erreur');
    }
    setAccepting(false);
  };

  const handleSign = async (name: string) => {
    if (!token) return;
    setSigning(true);
    try {
      await clientPortalSign(token, name);
      await load();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Erreur');
    }
    setSigning(false);
  };

  const step = data ? stageToStep(data.stage) : 0;

  return (
    <div className="min-h-screen bg-black text-white" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* Navbar */}
      <nav className="bg-white/90 backdrop-blur-md border-b border-gray-200/70 px-6 h-14 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <AimeLogoIcon size={14} color="black" />
          <span style={{ fontFamily: "'Helvetica Neue', Helvetica, sans-serif", fontWeight: 700, fontSize: '13px' }}
            className="text-black tracking-tight">
            AIME<sup style={{ fontSize: '0.5em', fontWeight: 700 }}>®</sup>
          </span>
          <span className="text-gray-400 text-sm ml-1">Portail client</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-gray-400">
          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
          Lien sécurisé
        </div>
      </nav>

      <div className="max-w-lg mx-auto px-5 py-10">

        {/* Loading */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
            <p className="text-sm text-gray-400">Chargement…</p>
          </div>
        )}

        {/* Error */}
        {error && !loading && (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
            <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <p className="font-semibold text-black mb-1">Lien introuvable</p>
              <p className="text-sm text-gray-400">{error}</p>
            </div>
          </div>
        )}

        {/* Content */}
        {data && !loading && !error && (
          <>
            {/* Header */}
            <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
              <p className="text-xs text-gray-400 uppercase tracking-wider font-semibold mb-2">
                Bonjour {data.quote?.clientName?.split(' ')[0] ?? ''}
              </p>
              <h1 className="text-2xl font-semibold text-black" style={{ fontFamily: "'Inter', sans-serif" }}>
                Votre dossier mariage
              </h1>
              <p className="text-sm text-gray-400 mt-1">Suivez l'avancement de votre réservation</p>
            </motion.div>

            {/* Step bar */}
            <StepBar step={step} />

            {/* Payment success banner */}
            <AnimatePresence>
              {paymentSuccess && (
                <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="mb-5 flex items-center gap-3 px-5 py-4 bg-green-50 border border-green-200 rounded-2xl">
                  <CheckCheck className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-green-700">Paiement confirmé !</p>
                    <p className="text-xs text-green-500">Votre réservation est définitivement confirmée.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Cards */}
            <div className="space-y-5">
              {data.quote && (
                <QuoteCard quote={data.quote} onAccept={handleAccept} accepting={accepting} />
              )}
              {data.contract && (
                <ContractCard contract={data.contract} onSign={handleSign} signing={signing} />
              )}
              {data.payment && (
                <PaymentCard payment={data.payment} />
              )}
            </div>

            {/* Confirmed footer */}
            {data.stage === 'confirmed' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 text-center">
                <div className="inline-flex items-center gap-2 px-5 py-3 bg-black text-white rounded-2xl shadow-lg">
                  <CheckCheck className="w-4 h-4 text-green-400" />
                  <p className="text-sm font-semibold">Prestation confirmée — à très bientôt !</p>
                </div>
              </motion.div>
            )}
          </>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 py-4 text-center">
        <p className="text-xs text-gray-400">
          <span style={{ fontFamily: "'Inter', sans-serif" }} className="italic">AIME Wedding OS</span>
          {' '}· Propulsé par Cerise IA
        </p>
      </div>
    </div>
  );
}