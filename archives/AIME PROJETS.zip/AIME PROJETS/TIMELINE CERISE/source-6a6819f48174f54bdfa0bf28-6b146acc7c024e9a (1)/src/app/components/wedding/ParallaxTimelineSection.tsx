import { useRef, useState, useEffect, type ReactNode, type CSSProperties } from 'react';
import { motion, useScroll, useTransform, type MotionValue } from 'motion/react';

// ── Hook simple pour alléger le parallax sur mobile ───────────────────────────
function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const media = window.matchMedia('(max-width: 767px)');

    const update = () => {
      setIsMobile(media.matches);
    };

    update();

    if (media.addEventListener) {
      media.addEventListener('change', update);
      return () => media.removeEventListener('change', update);
    }

    media.addListener(update);
    return () => media.removeListener(update);
  }, []);

  return isMobile;
}

// ── Couche soft avec parallax Y ───────────────────────────────────────────────
function SoftParallaxLayer({
  background,
  opacity,
  y,
  scale,
  rotate,
  blur = 0,
  mixBlendMode = 'normal',
}: {
  background: string;
  opacity: MotionValue<number>;
  y: MotionValue<string>;
  scale?: MotionValue<number>;
  rotate?: MotionValue<string>;
  blur?: number;
  mixBlendMode?: CSSProperties['mixBlendMode'];
}) {
  return (
    <motion.div
      className="absolute inset-0 pointer-events-none"
      style={{
        opacity,
        y,
        scale,
        rotate,
        mixBlendMode,
        filter: blur ? `blur(${blur}px)` : undefined,
        willChange: 'transform, opacity',
      }}
    >
      <div
        className="absolute"
        style={{
          inset: '-22% -8%',
          background,
        }}
      />
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
export function ParallaxTimelineSection({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  // ── Plage de scroll de la section dans la page ─────────────────────────────
  const [range, setRange] = useState<[number, number]>([0, 1]);

  useEffect(() => {
    const measure = () => {
      const el = ref.current;
      if (!el) return;

      let top = 0;
      let node: HTMLElement | null = el;

      while (node) {
        top += node.offsetTop;
        node = node.offsetParent as HTMLElement | null;
      }

      const height = el.offsetHeight;
      const start = top;
      const end = top + height - window.innerHeight;

      setRange([start, Math.max(start + 1, end)]);
    };

    measure();

    const raf = requestAnimationFrame(measure);

    window.addEventListener('resize', measure, { passive: true });
    window.addEventListener('load', measure, { passive: true });

    let observer: ResizeObserver | null = null;

    if (typeof ResizeObserver !== 'undefined' && ref.current) {
      observer = new ResizeObserver(measure);
      observer.observe(ref.current);
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', measure);
      window.removeEventListener('load', measure);
      observer?.disconnect();
    };
  }, []);

  // ── Scroll global ──────────────────────────────────────────────────────────
  const { scrollY } = useScroll();

  // ── Progression normalisée de la section ───────────────────────────────────
  const scrollYProgress = useTransform(scrollY, range, [0, 1], {
    clamp: true,
  });

  // ── Parallax réduit sur mobile ─────────────────────────────────────────────
  const yBase = useTransform(
    scrollYProgress,
    [0, 1],
    isMobile ? ['0%', '-3%'] : ['0%', '-10%']
  );

  const yAura1 = useTransform(
    scrollYProgress,
    [0, 1],
    isMobile ? ['4%', '-7%'] : ['10%', '-24%']
  );

  const yAura2 = useTransform(
    scrollYProgress,
    [0, 1],
    isMobile ? ['6%', '-5%'] : ['18%', '-14%']
  );

  const yAura3 = useTransform(
    scrollYProgress,
    [0, 1],
    isMobile ? ['0%', '-8%'] : ['-4%', '-30%']
  );

  // ── Opacités plus douces sur mobile ────────────────────────────────────────
  const opBase = useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.97, 1]);

  const opAura1 = useTransform(
    scrollYProgress,
    [0, 0.4, 1],
    isMobile ? [0.28, 0.42, 0.34] : [0.42, 0.68, 0.5]
  );

  const opAura2 = useTransform(
    scrollYProgress,
    [0, 0.55, 1],
    isMobile ? [0.24, 0.36, 0.3] : [0.35, 0.55, 0.42]
  );

  const opAura3 = useTransform(
    scrollYProgress,
    [0, 0.5, 1],
    isMobile ? [0.12, 0.22, 0.18] : [0.18, 0.34, 0.28]
  );

  // ── Morphing réduit mobile ─────────────────────────────────────────────────
  const scaleAura1 = useTransform(scrollYProgress, [0, 1], isMobile ? [1, 1.02] : [1, 1.08]);
  const scaleAura2 = useTransform(scrollYProgress, [0, 1], isMobile ? [1.01, 0.99] : [1.04, 0.98]);
  const scaleAura3 = useTransform(scrollYProgress, [0, 1], isMobile ? [1, 1.03] : [0.98, 1.12]);

  const rotateAura1 = useTransform(scrollYProgress, [0, 1], isMobile ? ['0deg', '1deg'] : ['-2deg', '3deg']);
  const rotateAura2 = useTransform(scrollYProgress, [0, 1], isMobile ? ['1deg', '-1deg'] : ['4deg', '-3deg']);
  const rotateAura3 = useTransform(scrollYProgress, [0, 1], isMobile ? ['0deg', '1deg'] : ['0deg', '6deg']);

  return (
    <div
      ref={ref}
      className="relative overflow-hidden bg-black text-white"
      style={{
        background: '#000000',
      }}
    >
      {/* ── Background soft parallax ───────────────────────────────────────── */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        {/* Fond général */}
        <SoftParallaxLayer
          background={`
            linear-gradient(
              180deg,
              rgba(0, 0, 0, 1) 0%,
              rgba(5, 5, 8, 1) 44%,
              rgba(0, 0, 0, 1) 100%
            )
          `}
          opacity={opBase}
          y={yBase}
        />

        {/* Halo cyan */}
        <SoftParallaxLayer
          background={`
            radial-gradient(
              circle at 24% 24%,
              rgba(103, 232, 249, ${isMobile ? '0.12' : '0.18'}) 0%,
              rgba(103, 232, 249, ${isMobile ? '0.04' : '0.08'}) 24%,
              transparent 56%
            )
          `}
          opacity={opAura1}
          y={yAura1}
          scale={scaleAura1}
          rotate={rotateAura1}
          blur={isMobile ? 14 : 22}
          mixBlendMode="screen"
        />

        {/* Halo violet */}
        <SoftParallaxLayer
          background={`
            radial-gradient(
              circle at 76% 34%,
              rgba(139, 92, 246, ${isMobile ? '0.14' : '0.20'}) 0%,
              rgba(139, 92, 246, ${isMobile ? '0.05' : '0.10'}) 25%,
              transparent 58%
            )
          `}
          opacity={opAura2}
          y={yAura2}
          scale={scaleAura2}
          rotate={rotateAura2}
          blur={isMobile ? 16 : 26}
          mixBlendMode="screen"
        />

        {/* Halo ambre très doux */}
        <SoftParallaxLayer
          background={`
            radial-gradient(
              ellipse at 48% 76%,
              rgba(251, 191, 36, ${isMobile ? '0.06' : '0.10'}) 0%,
              rgba(251, 191, 36, ${isMobile ? '0.02' : '0.04'}) 28%,
              transparent 62%
            )
          `}
          opacity={opAura3}
          y={yAura3}
          scale={scaleAura3}
          rotate={rotateAura3}
          blur={isMobile ? 20 : 34}
          mixBlendMode="screen"
        />

        {/* Voile sombre premium */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(180deg, rgba(0,0,0,0.85), rgba(0,0,0,0.4) 48%, rgba(0,0,0,0.9))',
          }}
        />

        {/* Texture micro-grille */}
        <div
          className={isMobile ? 'absolute inset-0 opacity-[0.03]' : 'absolute inset-0 opacity-[0.06]'}
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.2) 1px, transparent 0)',
            backgroundSize: isMobile ? '22px 22px' : '18px 18px',
          }}
        />
      </div>

      {/* ── Contenu au-dessus ─────────────────────────────────────────────── */}
      <div className="relative z-10 w-full max-w-full overflow-x-hidden">
        {children}
      </div>
    </div>
  );
}