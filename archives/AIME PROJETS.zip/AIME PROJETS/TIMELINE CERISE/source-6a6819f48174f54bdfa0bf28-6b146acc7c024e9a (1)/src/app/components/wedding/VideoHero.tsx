import { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, Music2 } from 'lucide-react';

const VIDEO_URL = 'https://res.cloudinary.com/divou1vcx/video/upload/v1777569381/aimeherowebsite_dtwbr1.mp4';
const AUDIO_URL = 'https://res.cloudinary.com/divou1vcx/video/upload/v1777569102/Aime_-_Hymne_3_bz5wlf.mp3';

// Paroles poétiques — pas techniques, pas publicitaires
const LYRICS = [
  "Il y a des matins qui goûtent différemment.",
  "L'amour s'improvise. Les belles choses se préparent.",
  "Vous vous êtes dit oui — on veille sur le reste.",
  "Chaque pétale compte. Aucun ne tombe sans qu'on le sache.",
  "Du premier regard au dernier slow.",
  "Parce que votre histoire mérite d'être bien gardée.",
  "AIME — le nom dit tout.",
];

export function VideoHero() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [tagIndex,     setTagIndex]     = useState(0);
  const [tagVisible,   setTagVisible]   = useState(true);

  // ── Scroll top + lancer la vidéo dès le montage ───────────────────────────
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
    // La vidéo tourne en boucle automatiquement (autoPlay + muted)
    videoRef.current?.play().catch(() => {});
  }, []);

  // ── Cycle lyrics every 3 s ────────────────────────────────────────────────
  useEffect(() => {
    const id = setInterval(() => {
      setTagVisible(false);
      setTimeout(() => {
        setTagIndex(i => (i + 1) % LYRICS.length);
        setTagVisible(true);
      }, 380);
    }, 3200);
    return () => clearInterval(id);
  }, []);

  // ── Bouton : contrôle uniquement l'hymne (la vidéo boucle seule) ──────────
  const toggleAudio = () => {
    const a = audioRef.current;
    if (!a) return;
    if (audioPlaying) {
      a.pause();
      setAudioPlaying(false);
    } else {
      a.play().catch(() => {});
      setAudioPlaying(true);
    }
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-black select-none">

      {/* ── Vidéo en boucle automatique ───────────────────────────────────── */}
      <video
        ref={videoRef}
        src={VIDEO_URL}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ opacity: 0.75, transition: 'opacity 1.4s ease' }}
        autoPlay
        loop
        muted
        playsInline
      />

      {/* ── Hymne (audio seul) ────────────────────────────────────────────── */}
      <audio ref={audioRef} src={AUDIO_URL} loop />

      {/* ── Dégradé overlay ───────────────────────────────────────────────── */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/24 pointer-events-none" />

      {/* ── Contenu centré ────────────────────────────────────────────────── */}
      <div className="relative z-10 flex flex-col items-center gap-7 px-6 text-center">

        {/* Label marque */}
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15 }}
          className="text-[10px] font-semibold tracking-[0.3em] uppercase text-white/45"
        >
          AIME · Wedding OS
        </motion.p>

        {/* Paroles en rotation — hauteur fixe pour éviter tout saut */}
        <div className="h-16 md:h-20 flex items-center justify-center overflow-hidden max-w-lg">
          <AnimatePresence mode="wait">
            {tagVisible && (
              <motion.p
                key={tagIndex}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.42, ease: [0.25, 0.46, 0.45, 0.94] }}
                style={{ fontFamily: "'Inter', sans-serif" }}
                className="text-2xl md:text-[28px] font-normal italic text-white/88 leading-snug px-4"
              >
                {LYRICS[tagIndex]}
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        {/* Bouton Play / Pause hymne */}
        <motion.button
          onClick={toggleAudio}
          initial={{ opacity: 0, scale: 0.88 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.35 }}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          aria-label={audioPlaying ? 'Pause hymne' : 'Écouter l\'hymne'}
          className="relative w-14 h-14 rounded-full flex items-center justify-center
                     bg-white/10 backdrop-blur-sm border border-white/20
                     hover:bg-white/18 transition-colors duration-300"
        >
          {/* Anneau pulsant quand l'hymne joue */}
          {audioPlaying && (
            <>
              <motion.span
                className="absolute inset-0 rounded-full border border-white/25"
                animate={{ scale: [1, 1.6], opacity: [0.5, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeOut' }}
              />
              <motion.span
                className="absolute inset-0 rounded-full border border-white/15"
                animate={{ scale: [1, 1.9], opacity: [0.3, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeOut', delay: 0.6 }}
              />
            </>
          )}

          <AnimatePresence mode="wait">
            {audioPlaying ? (
              <motion.div
                key="pause"
                initial={{ opacity: 0, scale: 0.7 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.7 }}
                transition={{ duration: 0.16 }}
              >
                <Pause className="w-4.5 h-4.5 text-white" />
              </motion.div>
            ) : (
              <motion.div
                key="play"
                initial={{ opacity: 0, scale: 0.7 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.7 }}
                transition={{ duration: 0.16 }}
                className="flex flex-col items-center gap-0.5"
              >
                <Music2 className="w-4 h-4 text-white/80" />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>

        {/* Légende sous le bouton */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="text-[9px] tracking-[0.2em] uppercase text-white/30"
        >
          {audioPlaying ? 'Hymne en cours' : 'Écouter l\'hymne'}
        </motion.p>

        {/* Dots progression paroles */}
        <div className="flex items-center gap-1.5 -mt-2">
          {LYRICS.map((_, i) => (
            <motion.span
              key={i}
              animate={{
                opacity: i === tagIndex ? 0.9 : 0.2,
                scale:   i === tagIndex ? 1    : 0.7,
              }}
              transition={{ duration: 0.35 }}
              className="w-1 h-1 rounded-full bg-white block"
            />
          ))}
        </div>
      </div>

      {/* ── Invitation à défiler ───────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.8 }}
        className="absolute bottom-9 left-1/2 -translate-x-1/2 z-10"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-2"
        >
          <span className="text-[9px] tracking-[0.25em] uppercase text-white/25 font-medium">
            Découvrir
          </span>
          <div className="w-px h-8 bg-gradient-to-b from-white/25 to-transparent" />
        </motion.div>
      </motion.div>
    </section>
  );
}
