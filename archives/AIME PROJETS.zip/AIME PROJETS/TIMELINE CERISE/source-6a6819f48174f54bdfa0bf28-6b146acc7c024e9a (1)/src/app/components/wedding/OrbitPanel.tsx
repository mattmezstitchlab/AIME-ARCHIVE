import { AlertTriangle, AlertCircle, ChevronRight, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { WeddingAnalysis } from './WeddingEngine';
import { formatEuro } from './WeddingEngine';

interface OrbitPanelProps {
  analysis: WeddingAnalysis;
  guestCount: number;
  venue: string;
  daysLeft: number | null;
  onActionClick: (action: string) => void;
}

// ─── Score Ring ───────────────────────────────────────────────────────────────

function ScoreRing({ score, confirmed, total }: { score: number; confirmed: number; total: number }) {
  const r    = 34;
  const circ = 2 * Math.PI * r;
  const dash = circ - (score / 100) * circ;
  const strokeColor = score >= 80 ? '#67e8f9' : score >= 50 ? '#8b5cf6' : '#a1a1aa';

  return (
    <div className="flex items-center gap-5">
      <div className="relative w-20 h-20 flex-shrink-0">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r={r} fill="none" stroke="#27272a" strokeWidth="5" />
          <motion.circle
            cx="40" cy="40" r={r}
            fill="none" stroke={strokeColor} strokeWidth="5" strokeLinecap="round"
            strokeDasharray={circ}
            initial={{ strokeDashoffset: circ }}
            animate={{ strokeDashoffset: dash }}
            transition={{ duration: 1.1, ease: [0.25, 0.46, 0.45, 0.94], delay: 0.3 }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.span className="text-xl font-bold text-white leading-none"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            {score}%
          </motion.span>
        </div>
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-white leading-snug mb-1">
          {score >= 80 ? 'Vous êtes bien avancé ✓' : score >= 50 ? 'Vous progressez bien' : 'Quelques points à définir'}
        </p>
        <p className="text-[11px] text-neutral-400 leading-snug">
          Votre mariage est prêt à {score}%
        </p>
        <div className="flex items-center gap-1.5 mt-2">
          <div className="flex-1 h-1 bg-neutral-800 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-cyan-400 rounded-full"
              initial={{ width: '0%' }}
              animate={{ width: `${score}%` }}
              transition={{ duration: 0.9, ease: 'easeOut', delay: 0.4 }}
            />
          </div>
          <span className="text-[10px] text-neutral-400 tabular-nums whitespace-nowrap">
            {confirmed}/{total} confirmés
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Panel ────────────────────────────────────────────────────────────────────

export function OrbitPanel({ analysis, guestCount, venue, daysLeft, onActionClick }: OrbitPanelProps) {
  const criticals = analysis.alerts.filter((a) => a.severity === 'critical');
  const topBudget = [...analysis.budgetLines].sort((a, b) => b.amount - a.amount).slice(0, 4);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-[#0b0b0d] border border-white/10 rounded-3xl shadow-2xl overflow-hidden text-white"
    >
      {/* Header bar */}
      <div className="px-6 py-4 border-b border-white/10 flex flex-wrap items-center justify-between gap-3 bg-white/[0.02]">
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-1 text-[10px] font-bold text-cyan-300 bg-cyan-950/60 border border-cyan-500/30 rounded-full uppercase tracking-[0.2em]">
            Vue d'ensemble
          </span>
          {daysLeft !== null && daysLeft > 0 && (
            <span className="text-xs text-neutral-400 font-medium">
              J-{daysLeft} avant le grand jour
            </span>
          )}
        </div>

        {(guestCount > 0 || venue) && (
          <div className="flex items-center gap-2">
            {guestCount > 0 && (
              <span className="text-xs text-neutral-300 bg-white/5 border border-white/10 px-3 py-1 rounded-full">
                <strong className="text-white">{guestCount}</strong> invités
              </span>
            )}
            {venue && (
              <span className="text-xs text-neutral-300 bg-white/5 border border-white/10 px-3 py-1 rounded-full">
                {venue}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Grid container */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        {/* Col 1: Score & Countdown */}
        <div className="space-y-5 bg-white/[0.02] border border-white/5 p-5 rounded-2xl">
          {daysLeft !== null && daysLeft > 0 && (
            <div className="flex items-center justify-between p-3.5 bg-neutral-900/90 border border-white/10 rounded-xl">
              <div>
                <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest">Compte à rebours</p>
                <p className="text-white text-xs mt-0.5">Grand jour</p>
              </div>
              <p className="text-2xl font-bold text-cyan-300 tabular-nums">J-{daysLeft}</p>
            </div>
          )}

          <ScoreRing score={analysis.score} confirmed={analysis.confirmedCount} total={analysis.totalCount} />
        </div>

        {/* Col 2: Alerts & Actions */}
        <div className="space-y-4 bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-[0.2em]">
                {analysis.alerts.length > 0 ? 'Points à finaliser' : 'Points vérifiés'}
              </p>
              {analysis.alerts.length > 0 && (
                <span className="text-[10px] text-amber-400 font-medium">
                  {analysis.alerts.length} point{analysis.alerts.length > 1 ? 's' : ''}
                </span>
              )}
            </div>

            {analysis.alerts.length === 0 ? (
              <div className="flex items-center gap-2.5 text-xs text-neutral-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Tout est cohérent — votre journée est prête.</span>
              </div>
            ) : (
              <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
                <AnimatePresence>
                  {analysis.alerts.map((alert, i) => (
                    <motion.div
                      key={alert.id}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex items-start gap-2.5 p-2.5 rounded-xl text-xs leading-snug border ${
                        alert.severity === 'critical'
                          ? 'bg-rose-950/40 border-rose-800/40 text-rose-200'
                          : 'bg-neutral-900/80 border-white/10 text-neutral-300'
                      }`}
                    >
                      {alert.severity === 'critical' ? (
                        <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-rose-400" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-amber-400" />
                      )}
                      <span>{alert.message}</span>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>

          {analysis.actions.length > 0 && (
            <div className="pt-3 border-t border-white/10">
              <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-[0.2em] mb-2">Actions conseillées</p>
              <div className="flex flex-wrap gap-1.5">
                {analysis.actions.map((action) => (
                  <button
                    key={action}
                    onClick={() => onActionClick(action)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs text-neutral-200 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 rounded-lg transition-all"
                  >
                    <span>{action}</span>
                    <ChevronRight className="w-3 h-3 text-neutral-400" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Col 3: Budget summary */}
        {analysis.budgetLines.length > 0 && (
          <div className="space-y-3 bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex flex-col justify-between">
            <div>
              <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-[0.2em] mb-3">Budget estimé</p>
              <div className="space-y-2 mb-3">
                {topBudget.map((line) => (
                  <div key={line.label} className="flex items-center justify-between text-xs">
                    <span className="text-neutral-400 truncate mr-2">{line.label}</span>
                    <span className="tabular-nums font-medium text-white flex-shrink-0">
                      {line.isEstimate ? '~' : ''}{formatEuro(line.amount)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-300">Total estimé</span>
                <span className="text-lg font-bold text-cyan-300">~{formatEuro(analysis.totalBudget)}</span>
              </div>
              <p className="text-[9px] text-neutral-500 mt-1">Estimation informative</p>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
