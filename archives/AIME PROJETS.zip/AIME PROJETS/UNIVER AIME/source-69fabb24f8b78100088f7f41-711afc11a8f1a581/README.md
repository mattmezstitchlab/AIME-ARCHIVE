# AIME PRO Prototype & SaaS Base

This project contains the prototype for **AIME PRO**, an orchestration platform for weddings, as well as a base TanStack Start SaaS application.

## Prototype
The conceptual prototype is located at `index.html` in the root directory. You can open this file directly in a web browser to view the static interactive design. 
- It uses vanilla HTML/CSS/JS.
- Integrates Tailwind CSS via CDN.
- Simulates interactions for three portals: Couples, Guests, and Providers.
- Includes client-side hooks for Gemini API and Firebase (for demonstration purposes).

## Application Stack
The broader application is scaffolded using:
- **TanStack Start** (React 19)
- **Vite 7**
- **Tailwind CSS 4**
- **Netlify** for deployment

## Running locally
To start the TanStack Start development server:
```bash
npm install
npm run dev
```
Open `http://localhost:3000` to view the application.
