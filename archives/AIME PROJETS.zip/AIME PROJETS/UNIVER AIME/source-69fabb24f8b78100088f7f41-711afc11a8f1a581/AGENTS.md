# AGENTS.md

This document provides an overview of the project structure for developers and AI agents working on this codebase.

## Project Overview
This repository contains a prototype for "AIME PRO" (an event/wedding orchestration platform) alongside a TanStack Start application scaffold. 

### Tech Stack
| Layer | Technology |
|-------|------------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 |
| Deployment | Netlify |

## Directory Structure
```
├── index.html        # The monolithic HTML prototype for AIME PRO
├── src/
│   ├── routes/       # File-based routing for TanStack Start (SaaS template)
│   │   ├── __root.tsx
│   │   ├── index.tsx
│   │   └── faq.tsx
│   └── styles.css    # Global Tailwind styles
├── package.json      # Project dependencies
└── vite.config.ts    # Vite and TanStack Start configuration
```

## Key Concepts
- **Prototype HTML**: The `index.html` file at the root is a standalone concept. It contains inline CSS, a Tailwind CDN script, and module-based JS for testing Gemini APIs and Firebase. This is a design/UX reference.
- **TanStack Start App**: The `src/` folder holds the actual production-ready application framework. Any prototype features should eventually be migrated here using proper React components, server functions, and secured API routes.

## Development & Security Notes
- The prototype currently implies client-side usage of the Gemini API (`apiKey`). **In production code within `src/`, all AI/API interactions MUST be routed through secure server functions (e.g., TanStack server functions or Netlify Functions) to prevent exposing secrets.**
- State management and databases should utilize Netlify Database/Blobs or an established backend rather than the raw client-side Firebase calls seen in the prototype.
