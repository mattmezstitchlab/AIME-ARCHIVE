import type { Context } from "@netlify/functions";

export default async (req: Request, context: Context) => {
  // Only allow POST requests
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  try {
    const { modelType, payload } = await req.json();

    const apiKey = Netlify.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return Response.json({ error: "API key is not configured" }, { status: 500 });
    }

    let modelId = "";
    let endpoint = "generateContent";

    if (modelType === "text") {
      modelId = "gemini-2.5-flash-preview-09-2025";
    } else if (modelType === "image") {
      modelId = "imagen-4.0-generate-001";
      endpoint = "predict";
    } else if (modelType === "tts") {
      modelId = "gemini-2.5-flash-preview-tts";
    } else {
      return Response.json({ error: "Invalid modelType" }, { status: 400 });
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:${endpoint}?key=${apiKey}`;

    const googleRes = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data = await googleRes.json();

    return Response.json(data, { status: googleRes.status });

  } catch (error) {
    console.error("Gemini API Error:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
};
