import { useEffect, useRef, useState } from "react";
import {
  ArrowRight, Brain, GitBranch, Zap, Eye, Shield, Clock,
  FileText, Users, Heart, Cpu, MessageSquare, BarChart3,
  Calendar, MapPin, CloudRain, Accessibility, Mic2,
  CheckCircle2, AlertTriangle, TrendingUp, Lock, Globe,
  ChevronDown, ExternalLink, Mail, Layers
} from "lucide-react";
import { Link } from "wouter";

/* ============================================================
   RIPPLE / Point Zéro — Site Investisseur
   Design: Cocoon-inspired — #0c0c0c bg, Manrope 800 titles,
   Inter body, white/gray only, Lucide icons, no color accents
   Narrative: Fondateur → Recherche → Point Zéro → Brevet → AIME Wedding
   ============================================================ */

// ─── Scroll animation hook ───────────────────────────────────
function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, visible } = useScrollReveal();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(28px)",
        transition: `opacity 0.65s cubic-bezier(0.23,1,0.32,1) ${delay}ms, transform 0.65s cubic-bezier(0.23,1,0.32,1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

// ─── Data ─────────────────────────────────────────────────────

const AGENTS = [
  {
    img: "/manus-storage/agent_pixelle_55501924.png",
    name: "Pixelle",
    role: "Rédactrice & Éditorialiste",
    mission: "Voix éditoriale d'AIME®. Rédige les rapports, articles et textes de marque. Sur AIME Wedding, elle génère les récits de chaque décision et alerte narrative.",
    icon: <FileText size={14} />,
    tag: "CONTENU"
  },
  {
    img: "/manus-storage/agent_lena_57f84048.png",
    name: "Léna",
    role: "Coordinatrice Projets",
    mission: "Orchestre les 11 territoires AIME®. Sur AIME Wedding, elle synchronise prestataires, délais et livrables — et propage chaque changement dans le HUD.",
    icon: <Calendar size={14} />,
    tag: "COORDINATION"
  },
  {
    img: "/manus-storage/agent_axiom_53d9c323.png",
    name: "Axiom",
    role: "Architecte Systèmes",
    mission: "Conçoit les architectures de Ripple UI. Pense en systèmes, construit en interfaces durables. Il a posé les fondations du moteur Point Zéro.",
    icon: <GitBranch size={14} />,
    tag: "ARCHITECTURE"
  },
  {
    img: "/manus-storage/agent_orion_b45ba00d.png",
    name: "Orion",
    role: "Analyste Données & Veille",
    mission: "Analyse les données de marché et alimente la recherche AIME® en temps réel. Sur AIME Wedding, il surveille budget, météo et disponibilités prestataires.",
    icon: <BarChart3 size={14} />,
    tag: "DONNÉES"
  },
  {
    img: "/manus-storage/agent_nova_1150325b.png",
    name: "Nova",
    role: "Juriste PI & Stratège Brevet",
    mission: "Pilote la stratégie de propriété intellectuelle. A produit le rapport Wide Search et la stratégie PCT. Protège l'innovation RIPPLE dans 4 juridictions.",
    icon: <Shield size={14} />,
    tag: "JURIDIQUE"
  },
  {
    img: "/manus-storage/agent_vera_ddd03870.png",
    name: "Vera",
    role: "Designer UX Causale",
    mission: "Traduit les règles causales en interfaces vivantes. Conçoit chaque pictogramme, animation et état du HUD selon la grammaire Ripple UI.",
    icon: <Eye size={14} />,
    tag: "DESIGN"
  },
  {
    img: "/manus-storage/agent_kael_f121ee58.png",
    name: "Kael",
    role: "Ingénieur Logique Causale",
    mission: "Implémente le moteur analyzeSourceBrute. Décompose chaque information brute en 12 dimensions et calcule les dépendances logiques en temps réel.",
    icon: <Cpu size={14} />,
    tag: "MOTEUR"
  },
  {
    img: "/manus-storage/agent_mira_f6792cba.png",
    name: "Mira",
    role: "Spécialiste Événementiel",
    mission: "Expert métier mariage & événements. Valide la pertinence des impacts générés par Point Zéro et enrichit le système des contraintes terrain réelles.",
    icon: <Heart size={14} />,
    tag: "MÉTIER"
  },
];

const PILLARS = [
  { icon: <Eye size={20} />, title: "Symbole", desc: "Chaque pictogramme est actif, contextuel, porteur d'état. Jamais décoratif." },
  { icon: <BarChart3 size={20} />, title: "Chiffre", desc: "Un nombre associé à chaque symbole actif. La donnée brute rendue lisible." },
  { icon: <Zap size={20} />, title: "État", desc: "Chaque élément a un état vivant : stable, alerte, critique, résolu." },
  { icon: <TrendingUp size={20} />, title: "Impact", desc: "L'onde causale : chaque décision propage ses effets sur tout le système." },
  { icon: <Brain size={20} />, title: "Animation", desc: "Le mouvement signale le changement. Jamais cosmétique, toujours informatif." },
  { icon: <Cpu size={20} />, title: "IA", desc: "Le moteur Point Zéro orchestre, anticipe et suggère en temps réel." },
];

const RULES = [
  { num: "01", rule: "Jamais de page séparée pour afficher un impact", sub: "Tout se passe sur l'écran principal." },
  { num: "02", rule: "Jamais plus de 5 impacts simultanés", sub: "La clarté prime sur l'exhaustivité." },
  { num: "03", rule: "Jamais un pictogramme sans pertinence contextuelle", sub: "Chaque symbole gagne sa présence." },
  { num: "04", rule: "Jamais un message de plus de 10 mots", sub: "Dans le HUD, la concision est une règle absolue." },
  { num: "05", rule: "Jamais un formulaire visible", sub: "Les données se saisissent sur les symboles." },
  { num: "06", rule: "Toujours un chiffre par pictogramme actif", sub: "Le quantitatif ancre le qualitatif." },
  { num: "07", rule: "Toujours une animation pour signaler un impact", sub: "Même minime. Le mouvement informe." },
  { num: "08", rule: "Toujours un Plan B pour chaque alerte critique", sub: "Le système anticipe, pas seulement il alerte." },
];

const TIMELINE = [
  { year: "2018", title: "La conviction fondatrice", desc: "Matt Mez, saxophoniste et designer, formule une idée : les interfaces cachent les conséquences. Premières recherches sur la propagation causale." },
  { year: "2020", title: "AI+ME — L'amplificateur humain", desc: "Développement du concept : l'IA comme amplificateur de l'humain, pas son remplaçant. Premiers prototypes d'interfaces causales." },
  { year: "2022", title: "AIME® — L'écosystème prend forme", desc: "11 territoires d'exploration identifiés. Architecture Intelligente de la Mémoire Ensemble. 162 projets indexés." },
  { year: "2023", title: "Dépôt INPI — 6 classes protégées", desc: "Protection juridique de l'écosystème : classes 16, 23, 26, 35, 41, 42. La vision est désormais protégée." },
  { year: "2024", title: "Ripple UI — La grammaire causale", desc: "Première grammaire UX causale documentée. Formule en 6 couches. Rapports de différenciation et d'antériorité. Innovation mondiale." },
  { year: "2025", title: "AIME Wedding — La preuve concrète", desc: "Application concrète sur l'événementiel mariage. Le HUD causal en production. 0 antériorité directe confirmée. Fortement brevetable." },
];

const WEDDING_IMPACTS = [
  { icon: <Users size={16} />, trigger: "+12 invités", impact: "Budget +1 440€", status: "green" },
  { icon: <CloudRain size={16} />, trigger: "Pluie prévue J-3", impact: "Plan B activé", status: "orange" },
  { icon: <Accessibility size={16} />, trigger: "PMR détecté", impact: "Accessibilité vérifiée", status: "red" },
  { icon: <Mic2 size={16} />, trigger: "Discours +1", impact: "+10 min programme", status: "blue" },
];

// ─── Nav ──────────────────────────────────────────────────────
function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: scrolled ? "rgba(12,12,12,0.95)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none",
        transition: "all 0.3s ease",
      }}
    >
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 28, height: 28, position: "relative",
            display: "flex", alignItems: "center", justifyContent: "center"
          }}>
            <svg viewBox="0 0 28 28" fill="none" style={{ width: 28, height: 28 }}>
              <rect x="2" y="2" width="24" height="24" stroke="white" strokeWidth="1.5" />
              <line x1="2" y1="2" x2="26" y2="26" stroke="white" strokeWidth="1.5" />
              <line x1="26" y1="2" x2="2" y2="26" stroke="white" strokeWidth="1.5" />
            </svg>
          </div>
          <span style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1rem", color: "white", letterSpacing: "-0.02em" }}>
            AIME®
          </span>
        </div>

        {/* Nav links */}
        <nav style={{ display: "flex", gap: "2rem", alignItems: "center" }}>
          {[
            { label: "Histoire", id: "histoire" },
            { label: "Paradigme", id: "paradigme" },
            { label: "Équipe", id: "equipe" },
            { label: "Brevet", id: "brevet" },
            { label: "Application", id: "application" },
          ].map(({ label, id }) => (
            <button
              key={id}
              onClick={() => scrollTo(id)}
              style={{
                background: "none", border: "none", color: "rgba(255,255,255,0.6)",
                fontFamily: "Inter", fontSize: "0.875rem", fontWeight: 500,
                cursor: "pointer", transition: "color 0.2s",
                display: window.innerWidth < 768 ? "none" : "block"
              }}
              onMouseEnter={e => (e.currentTarget.style.color = "white")}
              onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.6)")}
            >
              {label}
            </button>
          ))}
        </nav>

        {/* Design System link */}
        <Link
          href="/design-system"
          style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "0.45rem 1rem",
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.15)",
            borderRadius: 9999,
            color: "rgba(255,255,255,0.75)",
            fontFamily: "Inter", fontSize: "0.8rem", fontWeight: 500,
            textDecoration: "none",
            transition: "all 0.2s",
          }}
          onMouseEnter={(e: React.MouseEvent<HTMLAnchorElement>) => {
            e.currentTarget.style.background = "rgba(255,255,255,0.15)";
            e.currentTarget.style.color = "white";
          }}
          onMouseLeave={(e: React.MouseEvent<HTMLAnchorElement>) => {
            e.currentTarget.style.background = "rgba(255,255,255,0.08)";
            e.currentTarget.style.color = "rgba(255,255,255,0.75)";
          }}
        >
          <Layers size={13} />
          Design System
        </Link>

        <button
          onClick={() => scrollTo("contact")}
          className="btn-primary"
          style={{ fontSize: "0.8rem", padding: "0.6rem 1.4rem" }}
        >
          Nous contacter
        </button>
      </div>
    </header>
  );
}

// ─── Hero ─────────────────────────────────────────────────────
function Hero() {
  return (
    <section style={{ minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "flex-end", paddingBottom: "8rem", paddingTop: "8rem", position: "relative", overflow: "hidden" }}>
      {/* Venn circles background */}
      <div style={{ position: "absolute", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "900px", height: "500px", pointerEvents: "none" }}>
        <svg viewBox="0 0 900 500" fill="none" style={{ width: "100%", height: "100%", opacity: 0.07 }}>
          <circle cx="320" cy="350" r="280" stroke="white" strokeWidth="1" />
          <circle cx="580" cy="350" r="280" stroke="white" strokeWidth="1" />
        </svg>
      </div>

      <div className="container">
        <div style={{ maxWidth: 760 }}>
          <div className="fade-up" style={{ animationDelay: "0ms" }}>
            <span className="section-label" style={{ display: "inline-block", marginBottom: "2rem" }}>
              Interface causale · AIME® · 2018–2026
            </span>
          </div>
          <h1 className="fade-up display-title" style={{ animationDelay: "80ms", marginBottom: "2rem" }}>
            L'onde qui rend<br />tout visible.
          </h1>
          <p className="fade-up" style={{ animationDelay: "160ms", color: "rgba(255,255,255,0.55)", fontSize: "1.125rem", lineHeight: 1.7, maxWidth: 560, marginBottom: "3rem", fontFamily: "Inter" }}>
            RIPPLE UI est le premier HUD causal vivant. Chaque décision propage une onde — les conséquences logistiques, financières et humaines deviennent immédiatement visibles. 0 antériorité directe. Fortement brevetable.
          </p>
          <div className="fade-up" style={{ animationDelay: "240ms", display: "flex", gap: "1rem", flexWrap: "wrap" }}>
            <button className="btn-primary" onClick={() => document.getElementById("paradigme")?.scrollIntoView({ behavior: "smooth" })}>
              Découvrir le paradigme <ArrowRight size={16} />
            </button>
            <a href="https://artistry-copy-b9c98ef7.base44.app" target="_blank" rel="noopener noreferrer" className="btn-outline">
              Voir AIME Wedding <ExternalLink size={14} />
            </a>
          </div>
        </div>

        {/* Stats row */}
        <div className="fade-up" style={{ animationDelay: "320ms", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "2rem", marginTop: "6rem", paddingTop: "3rem", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          {[
            { n: "2018", label: "Année de fondation" },
            { n: "6", label: "Classes INPI déposées" },
            { n: "8", label: "Agents IA spécialisés" },
            { n: "0", label: "Antériorité directe" },
          ].map(({ n, label }) => (
            <div key={label}>
              <div className="stat-number">{n}</div>
              <div style={{ color: "rgba(255,255,255,0.4)", fontSize: "0.8rem", fontFamily: "Inter", marginTop: "0.25rem" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Histoire (chronologie fondateur) ────────────────────────
function Histoire() {
  return (
    <section id="histoire" style={{ padding: "8rem 0", background: "#0f0f0f" }}>
      <div className="container">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6rem", alignItems: "start" }}>
          {/* Left — photo + bio */}
          <Reveal>
            <div>
              <img
                src="/manus-storage/aime_founder_8986b22d.jpg"
                alt="Matt Mez — Fondateur AIME®"
                style={{ width: "100%", aspectRatio: "4/5", objectFit: "cover", borderRadius: "1rem", marginBottom: "2rem" }}
              />
              <div style={{ display: "flex", gap: "1.5rem" }}>
                <img
                  src="/manus-storage/aime_team_220a7b76.jpg"
                  alt="Équipe AIME®"
                  style={{ width: "48%", aspectRatio: "1", objectFit: "cover", borderRadius: "0.75rem" }}
                />
                <img
                  src="/manus-storage/aime_wedding_eb16fbfd.webp"
                  alt="AIME Wedding"
                  style={{ width: "48%", aspectRatio: "1", objectFit: "cover", borderRadius: "0.75rem" }}
                />
              </div>
            </div>
          </Reveal>

          {/* Right — timeline */}
          <div>
            <Reveal>
              <span className="section-label" style={{ display: "block", marginBottom: "1.5rem" }}>L'histoire</span>
              <h2 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "clamp(2rem,4vw,3.5rem)", letterSpacing: "-0.04em", color: "white", lineHeight: 1.05, marginBottom: "1.5rem" }}>
                Matt Mez.<br />Architecte de<br />systèmes causaux.
              </h2>
              <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Inter", lineHeight: 1.7, marginBottom: "3rem", fontSize: "0.95rem" }}>
                Saxophoniste de formation, chercheur indépendant, passionné par la convergence entre musique, technologie et design d'interaction. Depuis 2018, il explore une conviction : les interfaces cachent les conséquences de nos décisions.
              </p>
            </Reveal>

            {/* Timeline */}
            <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
              {TIMELINE.map((item, i) => (
                <Reveal key={item.year} delay={i * 80}>
                  <div style={{ display: "flex", gap: "1.5rem", paddingBottom: "2rem", position: "relative" }}>
                    {/* Line */}
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
                      <div style={{ width: 10, height: 10, borderRadius: "50%", background: i === TIMELINE.length - 1 ? "white" : "rgba(255,255,255,0.3)", flexShrink: 0, marginTop: 4 }} />
                      {i < TIMELINE.length - 1 && (
                        <div style={{ width: 1, flex: 1, background: "rgba(255,255,255,0.1)", marginTop: 6 }} />
                      )}
                    </div>
                    <div style={{ paddingBottom: "0.5rem" }}>
                      <div style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.75rem", color: "rgba(255,255,255,0.35)", letterSpacing: "0.1em", marginBottom: "0.25rem" }}>{item.year}</div>
                      <div style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "1rem", color: "white", marginBottom: "0.4rem" }}>{item.title}</div>
                      <div style={{ fontFamily: "Inter", fontSize: "0.85rem", color: "rgba(255,255,255,0.45)", lineHeight: 1.6 }}>{item.desc}</div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Paradigme Point Zéro ─────────────────────────────────────
function Paradigme() {
  return (
    <section id="paradigme" style={{ padding: "8rem 0" }}>
      <div className="container">
        {/* Header */}
        <Reveal>
          <div style={{ maxWidth: 680, marginBottom: "5rem" }}>
            <span className="section-label" style={{ display: "block", marginBottom: "1.5rem" }}>Le paradigme</span>
            <h2 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "clamp(2rem,4vw,3.5rem)", letterSpacing: "-0.04em", color: "white", lineHeight: 1.05, marginBottom: "1.5rem" }}>
              La plupart des outils<br />montrent des formulaires.<br />RIPPLE montre des<br />conséquences.
            </h2>
            <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Inter", lineHeight: 1.7, fontSize: "0.95rem" }}>
              RIPPLE est une interface causale et temps réel où chaque information a un effet en cascade — une « onde » — sur tout le système. Le Point Zéro est le cœur orchestrateur : il reçoit des informations brutes, les décompose en 12 dimensions, et renvoie les impacts structurés à chaque agent concerné.
            </p>
          </div>
        </Reveal>

        {/* Quote */}
        <Reveal delay={100}>
          <blockquote style={{
            borderLeft: "2px solid rgba(255,255,255,0.2)",
            paddingLeft: "2rem",
            marginBottom: "5rem",
            fontFamily: "Manrope",
            fontWeight: 700,
            fontSize: "clamp(1.1rem,2vw,1.5rem)",
            color: "rgba(255,255,255,0.7)",
            lineHeight: 1.4,
            fontStyle: "italic",
          }}>
            "Ripple UI abandonne la navigation par pages au profit d'un HUD causal, où chaque décision rend ses conséquences visibles via un graphe de dépendances en temps réel."
          </blockquote>
        </Reveal>

        {/* 6 Pillars */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1.5rem", marginBottom: "5rem" }}>
          {PILLARS.map((p, i) => (
            <Reveal key={p.title} delay={i * 60}>
              <div className="dark-card" style={{ padding: "2rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem" }}>
                  <div style={{ color: "rgba(255,255,255,0.5)" }}>{p.icon}</div>
                  <span style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.1rem", color: "white" }}>{p.title}</span>
                </div>
                <p style={{ fontFamily: "Inter", fontSize: "0.875rem", color: "rgba(255,255,255,0.45)", lineHeight: 1.6 }}>{p.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Moteur Point Zéro */}
        <Reveal>
          <div style={{ background: "#111", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "1.5rem", padding: "3rem", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "3rem", alignItems: "center" }}>
            <div>
              <span className="section-label" style={{ display: "block", marginBottom: "1rem" }}>Le moteur</span>
              <h3 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.75rem", color: "white", letterSpacing: "-0.03em", marginBottom: "1rem" }}>
                Point Zéro orchestre.<br />Les agents exécutent.
              </h3>
              <p style={{ fontFamily: "Inter", fontSize: "0.9rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.7, marginBottom: "1.5rem" }}>
                Le moteur <code style={{ background: "rgba(255,255,255,0.08)", padding: "2px 6px", borderRadius: 4, fontFamily: "monospace", fontSize: "0.8rem" }}>analyzeSourceBrute</code> décompose chaque information brute en <strong style={{ color: "white" }}>12 dimensions</strong> : temps, espace, personnes, ressources, actions, documents, mémoire, communication, économie, émotions, validation, relations.
              </p>
              <p style={{ fontFamily: "Inter", fontSize: "0.85rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.6 }}>
                Chaque dimension inclut un niveau de confiance, une détection des manques (oublis probables, silences significatifs) et des liens de dépendance logique. Le flux est bidirectionnel.
              </p>
            </div>
            {/* 12 dimensions grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.5rem" }}>
              {["Temps", "Espace", "Personnes", "Ressources", "Actions", "Documents", "Mémoire", "Communication", "Économie", "Émotions", "Validation", "Relations"].map((dim) => (
                <div key={dim} style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "0.5rem",
                  padding: "0.5rem 0.75rem",
                  fontFamily: "Inter",
                  fontSize: "0.75rem",
                  color: "rgba(255,255,255,0.5)",
                  textAlign: "center",
                }}>
                  {dim}
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ─── Équipe Multi-Agents ──────────────────────────────────────
function Equipe() {
  return (
    <section id="equipe" style={{ padding: "8rem 0", background: "#0f0f0f" }}>
      <div className="container">
        <Reveal>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4rem", alignItems: "end", marginBottom: "4rem" }}>
            <div>
              <span className="section-label" style={{ display: "block", marginBottom: "1.5rem" }}>Intelligence collective</span>
              <h2 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "clamp(2rem,4vw,3.5rem)", letterSpacing: "-0.04em", color: "white", lineHeight: 1.05 }}>
                Un fondateur.<br />Huit agents IA.<br />Un seul système.
              </h2>
            </div>
            <div>
              <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Inter", lineHeight: 1.7, fontSize: "0.95rem" }}>
                AIME® est piloté par Matt Mez, assisté d'une équipe d'agents IA spécialisés. Chaque agent a un rôle précis dans l'écosystème — et tous convergent vers le même noyau : Point Zéro. Cette organisation permet un rythme de recherche et de production qu'une personne seule ne pourrait tenir, tout en gardant une vision unifiée.
              </p>
            </div>
          </div>
        </Reveal>

        {/* Agents grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1.25rem" }}>
          {AGENTS.map((agent, i) => (
            <Reveal key={agent.name} delay={i * 50}>
              <div
                className="dark-card"
                style={{ cursor: "default", transition: "transform 0.2s ease, border-color 0.2s ease" }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.transform = "translateY(-4px)";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.15)";
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.07)";
                }}
              >
                {/* Photo */}
                <div style={{ position: "relative", overflow: "hidden" }}>
                  <img
                    src={agent.img}
                    alt={agent.name}
                    style={{ width: "100%", aspectRatio: "3/4", objectFit: "cover", display: "block" }}
                    onError={e => { (e.target as HTMLImageElement).style.background = "#1a1a1a"; }}
                  />
                  {/* Tag */}
                  <div style={{
                    position: "absolute", top: "0.75rem", left: "0.75rem",
                    background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)",
                    border: "1px solid rgba(255,255,255,0.12)",
                    borderRadius: 999, padding: "0.2rem 0.6rem",
                    display: "flex", alignItems: "center", gap: "0.3rem",
                  }}>
                    <span style={{ color: "rgba(255,255,255,0.5)", display: "flex" }}>{agent.icon}</span>
                    <span style={{ fontFamily: "Inter", fontSize: "0.6rem", fontWeight: 600, letterSpacing: "0.1em", color: "rgba(255,255,255,0.6)" }}>{agent.tag}</span>
                  </div>
                </div>

                {/* Info */}
                <div style={{ padding: "1.25rem" }}>
                  <div style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.05rem", color: "white", marginBottom: "0.2rem" }}>{agent.name}</div>
                  <div style={{ fontFamily: "Inter", fontSize: "0.75rem", color: "rgba(255,255,255,0.4)", marginBottom: "0.75rem" }}>{agent.role}</div>
                  <p style={{ fontFamily: "Inter", fontSize: "0.78rem", color: "rgba(255,255,255,0.35)", lineHeight: 1.55 }}>{agent.mission}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* 8 Rules */}
        <Reveal delay={200}>
          <div style={{ marginTop: "5rem", padding: "3rem", background: "#111", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "1.5rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "2.5rem", flexWrap: "wrap", gap: "1rem" }}>
              <div>
                <span className="section-label" style={{ display: "block", marginBottom: "0.75rem" }}>Discipline produit</span>
                <h3 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.75rem", color: "white", letterSpacing: "-0.03em" }}>
                  8 règles à ne jamais violer.
                </h3>
              </div>
              <p style={{ fontFamily: "Inter", fontSize: "0.85rem", color: "rgba(255,255,255,0.4)", maxWidth: 360, lineHeight: 1.6 }}>
                Ces règles sont des preuves directes de l'inventivité — elles démontrent que le système est pensé comme un tout cohérent, pas comme un assemblage.
              </p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "1rem" }}>
              {RULES.map((r) => (
                <div key={r.num} style={{ display: "flex", gap: "1.25rem", alignItems: "flex-start", padding: "1.25rem", background: "rgba(255,255,255,0.03)", borderRadius: "0.75rem" }}>
                  <span style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.5rem", color: "rgba(255,255,255,0.12)", lineHeight: 1, flexShrink: 0 }}>{r.num}</span>
                  <div>
                    <div style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.9rem", color: "white", marginBottom: "0.2rem" }}>{r.rule}</div>
                    <div style={{ fontFamily: "Inter", fontSize: "0.78rem", color: "rgba(255,255,255,0.35)" }}>{r.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ─── Brevet ───────────────────────────────────────────────────
function Brevet() {
  return (
    <section id="brevet" style={{ padding: "8rem 0" }}>
      <div className="container">
        <Reveal>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "start" }}>
            <div>
              <span className="section-label" style={{ display: "block", marginBottom: "1.5rem" }}>Propriété intellectuelle</span>
              <h2 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "clamp(2rem,4vw,3.5rem)", letterSpacing: "-0.04em", color: "white", lineHeight: 1.05, marginBottom: "1.5rem" }}>
                0 antériorité<br />directe trouvée.
              </h2>
              <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Inter", lineHeight: 1.7, fontSize: "0.95rem", marginBottom: "2rem" }}>
                Recherche Wide Search sur USPTO, EPO, WIPO et INPI. 25 solutions mondiales comparées. Aucune antériorité directe identifiée. L'espace libre est significatif dans toutes les juridictions analysées.
              </p>

              {/* Verdict */}
              <div style={{ background: "#111", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "1rem", padding: "1.75rem", marginBottom: "2rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.75rem" }}>
                  <CheckCircle2 size={18} style={{ color: "rgba(255,255,255,0.6)" }} />
                  <span style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.75rem", letterSpacing: "0.12em", color: "rgba(255,255,255,0.5)" }}>VERDICT PI</span>
                </div>
                <div style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.75rem", color: "white", letterSpacing: "-0.03em", marginBottom: "0.5rem" }}>
                  Fortement brevetable
                </div>
                <div style={{ fontFamily: "Inter", fontSize: "0.8rem", color: "rgba(255,255,255,0.35)", letterSpacing: "0.08em" }}>
                  USPTO · EPO · WIPO · INPI
                </div>
              </div>

              {/* INPI classes */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.75rem" }}>
                {[
                  { n: "16", label: "Imprimés & Publications" },
                  { n: "35", label: "Services de conseil" },
                  { n: "41", label: "Éducation & Formation" },
                  { n: "42", label: "Services technologiques" },
                  { n: "23", label: "Fils & Fibres" },
                  { n: "26", label: "Mercerie & Rubanerie" },
                ].map(({ n, label }) => (
                  <div key={n} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "0.75rem", padding: "1rem", textAlign: "center" }}>
                    <div style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.5rem", color: "white", marginBottom: "0.25rem" }}>{n}</div>
                    <div style={{ fontFamily: "Inter", fontSize: "0.65rem", color: "rgba(255,255,255,0.35)", lineHeight: 1.4 }}>{label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right — strategy */}
            <div>
              <div style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
                {[
                  { icon: <Globe size={18} />, title: "Stratégie PCT internationale", desc: "Dépôt FR → WIPO → USPTO → EPO. Fenêtre de priorité de 12 mois. Couverture simultanée dans 150+ pays." },
                  { icon: <Lock size={18} />, title: "Revendications indépendantes", desc: "Méthode de propagation causale en temps réel. Système de décomposition en 12 dimensions. Architecture multi-agents bidirectionnelle." },
                  { icon: <Shield size={18} />, title: "Dossier Codex — Secrets commerciaux", desc: "Algorithmes de pondération, prompts IA, règles de détection des silences : protégés par secret commercial, pas par brevet." },
                  { icon: <FileText size={18} />, title: "Rapports de preuve disponibles", desc: "Rapport d'antériorité, rapport technique, rapport juridique. Documentation complète sur demande." },
                ].map((item, i) => (
                  <Reveal key={item.title} delay={i * 80}>
                    <div style={{ display: "flex", gap: "1.25rem", padding: "1.5rem", background: "#111", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "1rem" }}>
                      <div style={{ color: "rgba(255,255,255,0.4)", flexShrink: 0, marginTop: 2 }}>{item.icon}</div>
                      <div>
                        <div style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.95rem", color: "white", marginBottom: "0.4rem" }}>{item.title}</div>
                        <div style={{ fontFamily: "Inter", fontSize: "0.82rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.6 }}>{item.desc}</div>
                      </div>
                    </div>
                  </Reveal>
                ))}
              </div>

              {/* Comparison table */}
              <Reveal delay={320}>
                <div style={{ marginTop: "2rem", background: "#111", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "1rem", overflow: "hidden" }}>
                  <div style={{ padding: "1.25rem 1.5rem", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
                    <span style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.85rem", color: "rgba(255,255,255,0.6)" }}>RIPPLE vs. 25 solutions mondiales</span>
                  </div>
                  {[
                    { feature: "Propagation causale visible", ripple: true, others: false },
                    { feature: "Score d'impact global temps réel", ripple: true, others: false },
                    { feature: "Pictogrammes actifs (état + animation)", ripple: true, others: false },
                    { feature: "Contexte narratif IA", ripple: true, others: false },
                    { feature: "Grammaire UX protégeable", ripple: true, others: false },
                  ].map((row) => (
                    <div key={row.feature} style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: "1rem", padding: "0.875rem 1.5rem", borderBottom: "1px solid rgba(255,255,255,0.04)", alignItems: "center" }}>
                      <span style={{ fontFamily: "Inter", fontSize: "0.8rem", color: "rgba(255,255,255,0.5)" }}>{row.feature}</span>
                      <CheckCircle2 size={14} style={{ color: "rgba(255,255,255,0.7)" }} />
                      <div style={{ width: 14, height: 14, borderRadius: "50%", background: "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <div style={{ width: 6, height: 1, background: "rgba(255,255,255,0.3)" }} />
                      </div>
                    </div>
                  ))}
                </div>
              </Reveal>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ─── Application AIME Wedding ─────────────────────────────────
function Application() {
  return (
    <section id="application" style={{ padding: "8rem 0", background: "#0f0f0f" }}>
      <div className="container">
        <Reveal>
          <div style={{ textAlign: "center", marginBottom: "4rem" }}>
            <span className="section-label" style={{ display: "block", marginBottom: "1.5rem" }}>La preuve concrète</span>
            <h2 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "clamp(2rem,4vw,3.5rem)", letterSpacing: "-0.04em", color: "white", lineHeight: 1.05, marginBottom: "1.5rem" }}>
              AIME Wedding.<br />Le HUD causal en production.
            </h2>
            <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Inter", lineHeight: 1.7, fontSize: "0.95rem", maxWidth: 560, margin: "0 auto" }}>
              La première application de coordination de mariage propulsée par Ripple UI. Chaque décision — date, budget, nombre d'invités, météo — propage ses effets en temps réel sur l'ensemble des paramètres.
            </p>
          </div>
        </Reveal>

        {/* iMac mockup with screenshot */}
        <Reveal delay={100}>
          <div style={{ position: "relative", maxWidth: 900, margin: "0 auto 4rem" }}>
            {/* iMac frame */}
            <div style={{
              background: "#1a1a1a",
              borderRadius: "1.5rem 1.5rem 0 0",
              border: "2px solid rgba(255,255,255,0.1)",
              padding: "1.5rem 1.5rem 0",
              boxShadow: "0 40px 80px rgba(0,0,0,0.6)",
            }}>
              {/* Menu bar */}
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "1rem" }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: "rgba(255,255,255,0.15)" }} />
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: "rgba(255,255,255,0.1)" }} />
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: "rgba(255,255,255,0.07)" }} />
                <div style={{ flex: 1, height: 1, background: "rgba(255,255,255,0.05)", marginLeft: "0.5rem" }} />
                <span style={{ fontFamily: "Inter", fontSize: "0.65rem", color: "rgba(255,255,255,0.2)" }}>AIME Wedding — HUD Causal</span>
              </div>
              {/* Screen */}
              <div style={{ borderRadius: "0.5rem 0.5rem 0 0", overflow: "hidden", background: "#0a0a0a" }}>
                <img
                  src="/manus-storage/aime_wedding_eb16fbfd.webp"
                  alt="AIME Wedding — Interface causale"
                  style={{ width: "100%", display: "block" }}
                />
              </div>
            </div>
            {/* iMac stand */}
            <div style={{ display: "flex", justifyContent: "center" }}>
              <div style={{ width: 120, height: 20, background: "#1a1a1a", borderRadius: "0 0 4px 4px", border: "2px solid rgba(255,255,255,0.1)", borderTop: "none" }} />
            </div>
            <div style={{ display: "flex", justifyContent: "center" }}>
              <div style={{ width: 200, height: 6, background: "#111", borderRadius: 3 }} />
            </div>
          </div>
        </Reveal>

        {/* HUD Live demo */}
        <Reveal delay={200}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2rem", maxWidth: 900, margin: "0 auto" }}>
            {/* HUD widget */}
            <div className="hud-card">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.25rem" }}>
                <span style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.9rem", color: "white" }}>Impact en temps réel</span>
                <div style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: "rgba(255,255,255,0.6)", animation: "pulse 2s infinite" }} />
                  <span style={{ fontFamily: "Inter", fontSize: "0.65rem", color: "rgba(255,255,255,0.4)", letterSpacing: "0.1em" }}>LIVE</span>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem" }}>
                {WEDDING_IMPACTS.map((item) => (
                  <div key={item.trigger} style={{ display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.75rem", background: "rgba(255,255,255,0.04)", borderRadius: "0.5rem" }}>
                    <div style={{ color: "rgba(255,255,255,0.5)", flexShrink: 0 }}>{item.icon}</div>
                    <span style={{ fontFamily: "Inter", fontSize: "0.8rem", color: "rgba(255,255,255,0.6)", flex: 1 }}>
                      {item.trigger} <span style={{ color: "rgba(255,255,255,0.3)" }}>→</span> {item.impact}
                    </span>
                    <div style={{
                      width: 8, height: 8, borderRadius: "50%", flexShrink: 0,
                      background: item.status === "green" ? "rgba(255,255,255,0.7)" : item.status === "orange" ? "rgba(255,255,255,0.4)" : item.status === "red" ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.3)"
                    }} />
                  </div>
                ))}
              </div>
            </div>

            {/* Stats + CTA */}
            <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
              <div className="hud-card" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                {[
                  { n: "12", label: "règles causales" },
                  { n: "8", label: "agents actifs" },
                  { n: "7", label: "rôles connectés" },
                  { n: "∞", label: "ondes possibles" },
                ].map(({ n, label }) => (
                  <div key={label} style={{ textAlign: "center", padding: "1rem", background: "rgba(255,255,255,0.03)", borderRadius: "0.5rem" }}>
                    <div style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "1.75rem", color: "white", letterSpacing: "-0.04em" }}>{n}</div>
                    <div style={{ fontFamily: "Inter", fontSize: "0.7rem", color: "rgba(255,255,255,0.35)", marginTop: "0.25rem" }}>{label}</div>
                  </div>
                ))}
              </div>
              <a
                href="https://artistry-copy-b9c98ef7.base44.app"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
                style={{ justifyContent: "center", width: "100%" }}
              >
                Tester AIME Wedding <ExternalLink size={14} />
              </a>
              <a
                href="https://rippleui-nkxkauch.manus.space/ripple-ui"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-outline"
                style={{ justifyContent: "center", width: "100%" }}
              >
                Voir la documentation Ripple UI <ArrowRight size={14} />
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ─── Contact ──────────────────────────────────────────────────
function Contact() {
  return (
    <section id="contact" style={{ padding: "8rem 0", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
      <div className="container">
        <Reveal>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6rem", alignItems: "center" }}>
            <div>
              <span className="section-label" style={{ display: "block", marginBottom: "1.5rem" }}>Contact</span>
              <h2 style={{ fontFamily: "Manrope", fontWeight: 800, fontSize: "clamp(2rem,4vw,3.5rem)", letterSpacing: "-0.04em", color: "white", lineHeight: 1.05, marginBottom: "1.5rem" }}>
                Discutons du<br />paradigme.
              </h2>
              <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Inter", lineHeight: 1.7, fontSize: "0.95rem", marginBottom: "2.5rem" }}>
                Vous souhaitez en savoir plus sur RIPPLE UI, le moteur Point Zéro, la stratégie de brevetabilité ou les opportunités d'investissement dans l'écosystème AIME® ?
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                <a href="https://artistry-copy-b9c98ef7.base44.app" target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ width: "fit-content" }}>
                  Voir AIME Wedding <ExternalLink size={14} />
                </a>
                <a href="https://rippleui-nkxkauch.manus.space" target="_blank" rel="noopener noreferrer" className="btn-outline" style={{ width: "fit-content" }}>
                  Écosystème AIME® <ArrowRight size={14} />
                </a>
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
              {[
                { icon: <Globe size={18} />, label: "Site AIME®", value: "rippleui-nkxkauch.manus.space", href: "https://rippleui-nkxkauch.manus.space" },
                { icon: <ExternalLink size={18} />, label: "AIME Wedding (démo)", value: "artistry-copy-b9c98ef7.base44.app", href: "https://artistry-copy-b9c98ef7.base44.app" },
                { icon: <Shield size={18} />, label: "Marque déposée INPI", value: "Classes 16, 23, 26, 35, 41, 42", href: "#" },
                { icon: <FileText size={18} />, label: "Rapport Wide Search", value: "Disponible sur demande", href: "#" },
              ].map((item) => (
                <a key={item.label} href={item.href} target={item.href !== "#" ? "_blank" : undefined} rel="noopener noreferrer"
                  style={{ display: "flex", gap: "1.25rem", padding: "1.25rem", background: "#111", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "1rem", textDecoration: "none", transition: "border-color 0.2s" }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.2)")}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)")}
                >
                  <div style={{ color: "rgba(255,255,255,0.4)", flexShrink: 0, marginTop: 2 }}>{item.icon}</div>
                  <div>
                    <div style={{ fontFamily: "Inter", fontSize: "0.72rem", color: "rgba(255,255,255,0.35)", marginBottom: "0.2rem", letterSpacing: "0.08em", textTransform: "uppercase" }}>{item.label}</div>
                    <div style={{ fontFamily: "Manrope", fontWeight: 600, fontSize: "0.9rem", color: "white" }}>{item.value}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ borderTop: "1px solid rgba(255,255,255,0.06)", padding: "2.5rem 0" }}>
      <div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <svg viewBox="0 0 28 28" fill="none" style={{ width: 20, height: 20, opacity: 0.6 }}>
            <rect x="2" y="2" width="24" height="24" stroke="white" strokeWidth="1.5" />
            <line x1="2" y1="2" x2="26" y2="26" stroke="white" strokeWidth="1.5" />
            <line x1="26" y1="2" x2="2" y2="26" stroke="white" strokeWidth="1.5" />
          </svg>
          <span style={{ fontFamily: "Manrope", fontWeight: 700, fontSize: "0.85rem", color: "rgba(255,255,255,0.4)" }}>
            AIME® — Matt Mez — 2026
          </span>
        </div>
        <span style={{ fontFamily: "Inter", fontSize: "0.75rem", color: "rgba(255,255,255,0.2)" }}>
          Marque déposée INPI · Classes 16, 23, 26, 35, 41, 42 · Ripple UI — Innovation mondiale
        </span>
      </div>
    </footer>
  );
}

// ─── Main ─────────────────────────────────────────────────────
export default function Home() {
  return (
    <div style={{ background: "#0c0c0c", minHeight: "100vh", color: "white" }}>
      <Nav />
      <Hero />
      <Histoire />
      <Paradigme />
      <Equipe />
      <Brevet />
      <Application />
      <Contact />
      <Footer />
    </div>
  );
}
