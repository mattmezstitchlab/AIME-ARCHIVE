/**
 * AIME® Design System — Source de vérité graphique
 * Design: Éditorial sobre, fond blanc, typographie Aeonik + Inter
 * Sections: Typographie · Couleurs · Espacements · Icônes · Boutons · Cartes · Composants · Incohérences
 */

import {
  AlertTriangle,
  ArrowRight,
  Bell,
  BookOpen,
  Calendar,
  Check,
  ChevronRight,
  Cloud,
  Copy,
  Eye,
  GitBranch,
  Globe,
  Heart,
  Home,
  Info,
  Layers,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Moon,
  Music,
  Plus,
  Search,
  Settings,
  Share2,
  Shield,
  Star,
  Sun,
  Users,
  X,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

// Contenu du fichier tokens.css à télécharger
const TOKENS_CSS_CONTENT = `/**
 * AIME® Design System — tokens.css
 * Source de vérité graphique — v1.0 — Juillet 2026
 * Usage : @import './tokens.css'; dans votre fichier CSS principal
 */

:root {
  /* ── Couleurs ─────────────────────────────────── */
  --color-black:          #0C0C0C;
  --color-dark:           #121212;
  --color-white:          #FFFFFF;
  --color-warm-white:     #F8F8F6;
  --color-warm-gray-100:  #F5F3F0;
  --color-warm-gray-200:  #E5E3DC;
  --color-warm-gray-500:  #727169;

  --color-text-primary:       #121212;
  --color-text-secondary:     rgba(18, 18, 18, 0.6);
  --color-text-on-dark:       rgba(255, 255, 255, 0.9);
  --color-text-muted-dark:    rgba(255, 255, 255, 0.5);

  --color-overlay-light:   rgba(0, 0, 0, 0.35);
  --color-overlay-medium:  rgba(0, 0, 0, 0.65);
  --color-overlay-strong:  rgba(0, 0, 0, 0.75);

  /* ── Typographie ──────────────────────────────── */
  --font-display:  'Aeonik', 'Inter', sans-serif;
  --font-body:     'Inter', sans-serif;
  --font-mono:     'Inter', monospace;

  --text-display: 56px;
  --text-h2:      36px;
  --text-h3:      24px;
  --text-h4:      18px;
  --text-body-lg: 16px;
  --text-body:    14px;
  --text-label:   11px;
  --text-caption: 12px;

  --weight-regular:  400;
  --weight-medium:   500;
  --weight-semibold: 600;
  --weight-bold:     700;

  --tracking-display: -0.04em;
  --tracking-h2:      -0.03em;
  --tracking-h3:      -0.02em;
  --tracking-h4:      -0.01em;
  --tracking-body:     0;
  --tracking-label:    0.16em;
  --tracking-caption:  0.05em;

  --leading-display: 1.0;
  --leading-h2:      1.1;
  --leading-h3:      1.2;
  --leading-h4:      1.3;
  --leading-body:    1.6;

  /* ── Espacements (grille 8pt) ─────────────────── */
  --space-1:   4px;
  --space-2:   8px;
  --space-3:  12px;
  --space-4:  16px;
  --space-6:  24px;
  --space-8:  32px;
  --space-12: 48px;
  --space-16: 64px;
  --space-20: 80px;
  --space-24: 96px;
  --space-32: 128px;

  /* ── Rayons ───────────────────────────────────── */
  --radius-sm:   4px;
  --radius-md:   12px;
  --radius-lg:   16px;
  --radius-full: 9999px;

  /* ── Ombres ───────────────────────────────────── */
  --shadow-card:     0 1px 3px rgba(0, 0, 0, 0.08);
  --shadow-elevated: 0 8px 24px rgba(0, 0, 0, 0.12);
  --shadow-hud:      0 20px 40px rgba(0, 0, 0, 0.3);

  /* ── Bordures ─────────────────────────────────── */
  --border-default:  1px solid #E5E3DC;
  --border-dark:     1px solid rgba(255, 255, 255, 0.1);

  /* ── Transitions ──────────────────────────────── */
  --ease-out:    cubic-bezier(0.23, 1, 0.32, 1);
  --ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);
  --duration-fast:   160ms;
  --duration-normal: 250ms;
  --duration-slow:   400ms;

  /* ── Icônes (Lucide React) ────────────────────── */
  --icon-sm:     16px;  /* inline / texte */
  --icon-md:     20px;  /* boutons / actions */
  --icon-lg:     24px;  /* navigation / hero */
  --icon-stroke: 1.5;   /* strokeWidth uniforme */
}
`;

/* ─── helpers ─── */
function Section({ id, label, title, children }: { id: string; label: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} style={{ padding: "96px 0", borderBottom: "1px solid #E5E3DC" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 48px" }}>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>{label}</p>
        <h2 style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 36, fontWeight: 600, letterSpacing: "-0.03em", lineHeight: 1.1, color: "#121212", marginBottom: 64 }}>{title}</h2>
        {children}
      </div>
    </section>
  );
}

function Token({ name, value, preview }: { name: string; value: string; preview?: React.ReactNode }) {
  const [copied, setCopied] = useState(false);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "12px 0", borderBottom: "1px solid #F5F3F0" }}>
      {preview && <div style={{ flexShrink: 0 }}>{preview}</div>}
      <div style={{ flex: 1 }}>
        <p style={{ fontFamily: "'Inter', monospace", fontSize: 12, fontWeight: 600, color: "#121212", marginBottom: 2 }}>{name}</p>
        <p style={{ fontFamily: "'Inter', monospace", fontSize: 12, color: "#727169" }}>{value}</p>
      </div>
      <button
        onClick={() => { navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
        style={{ padding: "4px 10px", background: copied ? "#121212" : "#F5F3F0", color: copied ? "#fff" : "#727169", border: "none", borderRadius: 4, fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, transition: "all 0.15s" }}
      >
        {copied ? <Check size={12} /> : <Copy size={12} />}
        {copied ? "Copié" : "Copier"}
      </button>
    </div>
  );
}

function DownloadTokensButton() {
  const [downloaded, setDownloaded] = useState(false);
  const handleDownload = () => {
    const blob = new Blob([TOKENS_CSS_CONTENT], { type: "text/css" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "aime-tokens.css";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2500);
  };
  return (
    <button
      onClick={handleDownload}
      style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "10px 24px",
        background: downloaded ? "#121212" : "#121212",
        color: "#fff",
        border: "none",
        borderRadius: 9999,
        fontFamily: "'Inter', sans-serif",
        fontSize: 14, fontWeight: 500,
        cursor: "pointer",
        transition: "all 0.16s cubic-bezier(0.23,1,0.32,1)",
        transform: downloaded ? "scale(0.97)" : "scale(1)",
      }}
      onMouseEnter={e => { e.currentTarget.style.background = "#2a2a2a"; }}
      onMouseLeave={e => { e.currentTarget.style.background = "#121212"; }}
    >
      {downloaded ? <Check size={14} /> : <Copy size={14} />}
      {downloaded ? "aime-tokens.css téléchargé !" : "Télécharger tokens.css"}
    </button>
  );
}

function InconsistencyRow({ category, found, fix }: { category: string; found: string; fix: string }) {
  return (
    <tr>
      <td style={{ padding: "16px 20px", fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 600, color: "#121212", borderBottom: "1px solid #F5F3F0", verticalAlign: "top", width: "15%" }}>{category}</td>
      <td style={{ padding: "16px 20px", fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#c0392b", borderBottom: "1px solid #F5F3F0", verticalAlign: "top", width: "42.5%", lineHeight: 1.6 }}>{found}</td>
      <td style={{ padding: "16px 20px", fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#27ae60", borderBottom: "1px solid #F5F3F0", verticalAlign: "top", width: "42.5%", lineHeight: 1.6 }}>{fix}</td>
    </tr>
  );
}

export default function DesignSystem() {
  const navItems = ["Typographie", "Couleurs", "Espacements", "Icônes", "Boutons", "Cartes", "Composants", "Incohérences"];

  return (
    <div style={{ background: "#FFFFFF", minHeight: "100vh", fontFamily: "'Inter', sans-serif" }}>

      {/* ── NAV STICKY ── */}
      <nav style={{ position: "sticky", top: 0, zIndex: 100, background: "rgba(255,255,255,0.95)", backdropFilter: "blur(12px)", borderBottom: "1px solid #E5E3DC" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 48px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 60 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 28, height: 28, background: "#121212", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Layers size={14} color="#fff" />
            </div>
            <span style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 14, fontWeight: 600, color: "#121212", letterSpacing: "-0.01em" }}>AIME® Design System</span>
            <span style={{ background: "#F5F3F0", color: "#727169", fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 4, letterSpacing: "0.08em", textTransform: "uppercase" }}>v1.0</span>
          </div>
          <div style={{ display: "flex", gap: 32 }}>
            {navItems.map(item => (
              <a key={item} href={`#${item.toLowerCase().replace("é", "e").replace("î", "i")}`}
                style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#727169", textDecoration: "none", transition: "color 0.15s" }}
                onMouseEnter={e => (e.currentTarget.style.color = "#121212")}
                onMouseLeave={e => (e.currentTarget.style.color = "#727169")}
              >{item}</a>
            ))}
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "96px 48px 80px" }}>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 20 }}>Source de vérité graphique · AIME® / AIME Wedding</p>
        <h1 style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 72, fontWeight: 600, letterSpacing: "-0.04em", lineHeight: 1.0, color: "#121212", marginBottom: 32, maxWidth: 800 }}>
          Design System<br />AIME®
        </h1>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, color: "rgba(18,18,18,0.6)", lineHeight: 1.6, maxWidth: 600, marginBottom: 48 }}>
          Ce document recense l'intégralité des décisions graphiques de l'écosystème AIME® — basé sur un audit exhaustif des 8 pages du site existant. Il identifie les incohérences et propose les valeurs officielles unifiées.
        </p>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 24 }}>
          {[
            { label: "8 pages auditées", icon: <Eye size={14} /> },
            { label: "2 polices recensées", icon: <BookOpen size={14} /> },
            { label: "14 couleurs identifiées", icon: <Sun size={14} /> },
            { label: "11 incohérences corrigées", icon: <Check size={14} /> },
          ].map(({ label, icon }) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 16px", background: "#F8F8F6", border: "1px solid #E5E3DC", borderRadius: 9999, fontSize: 13, color: "#121212" }}>
              {icon}{label}
            </div>
          ))}
        </div>

        {/* Boutons d'action */}
        <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
          <DownloadTokensButton />
          <Link
            href="/"
            style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 24px",
              background: "#F8F8F6",
              border: "1px solid #E5E3DC",
              borderRadius: 9999,
              color: "#121212",
              fontFamily: "'Inter', sans-serif",
              fontSize: 14, fontWeight: 500,
              textDecoration: "none",
              transition: "all 0.16s",
            }}
            onMouseEnter={(e: React.MouseEvent<HTMLAnchorElement>) => { e.currentTarget.style.background = "#E5E3DC"; }}
            onMouseLeave={(e: React.MouseEvent<HTMLAnchorElement>) => { e.currentTarget.style.background = "#F8F8F6"; }}
          >
            <ArrowRight size={14} style={{ transform: "rotate(180deg)" }} />
            Retour au site investisseur
          </Link>
        </div>
      </div>

      {/* ══════════════════════════════════════════
          1. TYPOGRAPHIE
      ══════════════════════════════════════════ */}
      <Section id="typographie" label="01 · Typographie" title="Système typographique officiel">
        {/* Polices */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 64 }}>
          <div style={{ padding: 40, background: "#F8F8F6", borderRadius: 12 }}>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Police d'affichage</p>
            <p style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 48, fontWeight: 600, letterSpacing: "-0.04em", lineHeight: 1, color: "#121212", marginBottom: 16 }}>Aeonik</p>
            <p style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 18, color: "#727169", lineHeight: 1.4 }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ<br />abcdefghijklmnopqrstuvwxyz<br />0123456789 &amp; @ # € %</p>
            <div style={{ marginTop: 24, display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[400, 500, 600, 700].map(w => (
                <span key={w} style={{ padding: "4px 12px", background: "#E5E3DC", borderRadius: 4, fontSize: 12, fontFamily: "'Aeonik', 'Inter', sans-serif", fontWeight: w }}>
                  {w === 400 ? "Regular" : w === 500 ? "Medium" : w === 600 ? "Semibold" : "Bold"} {w}
                </span>
              ))}
            </div>
          </div>
          <div style={{ padding: 40, background: "#F8F8F6", borderRadius: 12 }}>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Police de corps</p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 48, fontWeight: 400, letterSpacing: "-0.02em", lineHeight: 1, color: "#121212", marginBottom: 16 }}>Inter</p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 18, color: "#727169", lineHeight: 1.4 }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ<br />abcdefghijklmnopqrstuvwxyz<br />0123456789 &amp; @ # € %</p>
            <div style={{ marginTop: 24, display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[400, 500, 600].map(w => (
                <span key={w} style={{ padding: "4px 12px", background: "#E5E3DC", borderRadius: 4, fontSize: 12, fontFamily: "'Inter', sans-serif", fontWeight: w }}>
                  {w === 400 ? "Regular" : w === 500 ? "Medium" : "Semibold"} {w}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Échelle */}
        <div style={{ marginBottom: 48 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 32 }}>Échelle typographique officielle</p>
          {[
            { level: "Display / H1", tag: "h1", size: "56px", weight: "600", tracking: "-0.04em", lh: "1.0", font: "Aeonik", sample: "L'onde qui rend tout visible." },
            { level: "H2", tag: "h2", size: "36px", weight: "600", tracking: "-0.03em", lh: "1.1", font: "Aeonik", sample: "Paradigme Point Zéro" },
            { level: "H3", tag: "h3", size: "24px", weight: "500", tracking: "-0.02em", lh: "1.2", font: "Aeonik", sample: "Architecture causale" },
            { level: "H4", tag: "h4", size: "18px", weight: "500", tracking: "-0.01em", lh: "1.3", font: "Aeonik", sample: "Moteur multi-agents" },
            { level: "Body Large", tag: "p", size: "16px", weight: "400", tracking: "0", lh: "1.6", font: "Inter", sample: "Chaque décision propage une onde — les conséquences logistiques, financières et humaines deviennent immédiatement visibles." },
            { level: "Body", tag: "p", size: "14px", weight: "400", tracking: "0", lh: "1.6", font: "Inter", sample: "RIPPLE UI est le premier HUD causal vivant. 0 antériorité directe. Fortement brevetable." },
            { level: "Label", tag: "span", size: "11px", weight: "600", tracking: "0.16em", lh: "1.4", font: "Inter", sample: "INTERFACE CAUSALE · AIME® · 2018–2026" },
            { level: "Caption", tag: "span", size: "12px", weight: "400", tracking: "0.05em", lh: "1.4", font: "Inter", sample: "Source : Rapport Wide Search — Juillet 2026" },
          ].map(({ level, size, weight, tracking, lh, font, sample }) => (
            <div key={level} style={{ display: "grid", gridTemplateColumns: "160px 1fr 200px", gap: 24, padding: "24px 0", borderBottom: "1px solid #F5F3F0", alignItems: "center" }}>
              <div>
                <p style={{ fontSize: 11, fontWeight: 600, color: "#727169", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 4 }}>{level}</p>
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#E5E3DC" }}>{font} · {size} · {weight}</p>
              </div>
              <div style={{ fontFamily: font === "Aeonik" ? "'Aeonik', 'Inter', sans-serif" : "'Inter', sans-serif", fontSize: size, fontWeight: parseInt(weight), letterSpacing: tracking, lineHeight: lh, color: "#121212" }}>
                {sample}
              </div>
              <div style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169", lineHeight: 1.8 }}>
                size: {size}<br />weight: {weight}<br />tracking: {tracking}<br />line-height: {lh}
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          2. COULEURS
      ══════════════════════════════════════════ */}
      <Section id="couleurs" label="02 · Couleurs" title="Palette officielle AIME®">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24, marginBottom: 64 }}>
          {[
            { name: "--color-black", hex: "#0C0C0C", label: "Fond principal dark", usage: "Sections dark, hero" },
            { name: "--color-dark", hex: "#121212", label: "Footer, surfaces dark", usage: "Footer, texte principal" },
            { name: "--color-white", hex: "#FFFFFF", label: "Fond principal clair", usage: "Background, texte sur dark" },
            { name: "--color-warm-white", hex: "#F8F8F6", label: "Fond sections claires", usage: "Sections alternées" },
            { name: "--color-warm-gray-100", hex: "#F5F3F0", label: "Badges, tags", usage: "Chips, labels, hover" },
            { name: "--color-warm-gray-200", hex: "#E5E3DC", label: "Bordures", usage: "Séparateurs, borders" },
            { name: "--color-warm-gray-500", hex: "#727169", label: "Texte secondaire", usage: "Icônes, captions, labels" },
            { name: "--color-text-primary", hex: "#121212", label: "Texte principal", usage: "Corps de texte, titres" },
            { name: "--color-text-secondary", hex: "rgba(18,18,18,0.6)", label: "Texte secondaire", usage: "Sous-titres, descriptions" },
            { name: "--color-text-on-dark", hex: "rgba(255,255,255,0.9)", label: "Texte sur fond sombre", usage: "Texte sur sections noires" },
            { name: "--color-text-muted-dark", hex: "rgba(255,255,255,0.5)", label: "Texte atténué dark", usage: "Captions sur fond sombre" },
            { name: "--color-overlay-light", hex: "rgba(0,0,0,0.35)", label: "Overlay image léger", usage: "Gradient début" },
            { name: "--color-overlay-medium", hex: "rgba(0,0,0,0.65)", label: "Overlay image moyen", usage: "Gradient milieu" },
            { name: "--color-overlay-strong", hex: "rgba(0,0,0,0.75)", label: "Overlay image fort", usage: "Gradient fin" },
          ].map(({ name, hex, label, usage }) => {
            const isLight = hex === "#FFFFFF" || hex === "#F8F8F6" || hex === "#F5F3F0" || hex === "#E5E3DC";
            const isDark = hex.startsWith("#0") || hex.startsWith("#1") || hex === "rgba(0,0,0,0.65)" || hex === "rgba(0,0,0,0.75)";
            return (
              <div key={name} style={{ borderRadius: 12, overflow: "hidden", border: "1px solid #E5E3DC" }}>
                <div style={{ height: 80, background: hex, display: "flex", alignItems: "flex-end", padding: 12 }}>
                  {isLight && <span style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169" }}>{hex}</span>}
                  {!isLight && <span style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "rgba(255,255,255,0.7)" }}>{hex}</span>}
                </div>
                <div style={{ padding: "16px 16px 20px", background: "#fff" }}>
                  <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, fontWeight: 600, color: "#121212", marginBottom: 4 }}>{name}</p>
                  <p style={{ fontSize: 12, color: "#727169", marginBottom: 4 }}>{label}</p>
                  <p style={{ fontSize: 11, color: "#E5E3DC" }}>Usage : {usage}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Variables CSS */}
        <div style={{ background: "#0C0C0C", borderRadius: 12, padding: 40 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Variables CSS officielles</p>
          <pre style={{ fontFamily: "'Inter', monospace", fontSize: 13, color: "rgba(255,255,255,0.8)", lineHeight: 1.8, margin: 0, overflowX: "auto" }}>{`:root {
  --color-black:          #0C0C0C;
  --color-dark:           #121212;
  --color-white:          #FFFFFF;
  --color-warm-white:     #F8F8F6;
  --color-warm-gray-100:  #F5F3F0;
  --color-warm-gray-200:  #E5E3DC;
  --color-warm-gray-500:  #727169;

  --color-text-primary:       #121212;
  --color-text-secondary:     rgba(18, 18, 18, 0.6);
  --color-text-on-dark:       rgba(255, 255, 255, 0.9);
  --color-text-muted-dark:    rgba(255, 255, 255, 0.5);

  --color-overlay-light:   rgba(0, 0, 0, 0.35);
  --color-overlay-medium:  rgba(0, 0, 0, 0.65);
  --color-overlay-strong:  rgba(0, 0, 0, 0.75);
}`}</pre>
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          3. ESPACEMENTS
      ══════════════════════════════════════════ */}
      <Section id="espacements" label="03 · Espacements" title="Grille 8pt — Rythme vertical">
        <div style={{ marginBottom: 64 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 32 }}>Échelle officielle (multiples de 4px)</p>
          <div style={{ display: "flex", gap: 0, alignItems: "flex-end", marginBottom: 48 }}>
            {[
              { token: "--space-1", px: 4, label: "4px" },
              { token: "--space-2", px: 8, label: "8px" },
              { token: "--space-3", px: 12, label: "12px" },
              { token: "--space-4", px: 16, label: "16px" },
              { token: "--space-6", px: 24, label: "24px" },
              { token: "--space-8", px: 32, label: "32px" },
              { token: "--space-12", px: 48, label: "48px" },
              { token: "--space-16", px: 64, label: "64px" },
              { token: "--space-20", px: 80, label: "80px" },
              { token: "--space-24", px: 96, label: "96px" },
              { token: "--space-32", px: 128, label: "128px" },
            ].map(({ token, px, label }) => (
              <div key={token} style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}>
                <div style={{ width: "100%", background: "#121212", height: Math.min(px, 128), marginBottom: 8 }} />
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 10, color: "#727169", textAlign: "center" }}>{label}</p>
              </div>
            ))}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 24 }}>
            <div>
              <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Padding sections (vertical)</p>
              {[
                { usage: "Section compacte (footer, nav)", value: "48px (--space-12)" },
                { usage: "Section standard", value: "80px (--space-20)" },
                { usage: "Section principale", value: "96px (--space-24)" },
                { usage: "Section hero", value: "128px (--space-32)" },
              ].map(({ usage, value }) => (
                <div key={usage} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid #F5F3F0" }}>
                  <span style={{ fontSize: 13, color: "#727169" }}>{usage}</span>
                  <span style={{ fontFamily: "'Inter', monospace", fontSize: 12, fontWeight: 600, color: "#121212" }}>{value}</span>
                </div>
              ))}
            </div>
            <div>
              <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Gap entre éléments</p>
              {[
                { usage: "Icône + texte inline", value: "8px (--space-2)" },
                { usage: "Boutons groupés", value: "12px (--space-3)" },
                { usage: "Cartes en grille", value: "24px (--space-6)" },
                { usage: "Sections majeures", value: "64px (--space-16)" },
              ].map(({ usage, value }) => (
                <div key={usage} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid #F5F3F0" }}>
                  <span style={{ fontSize: 13, color: "#727169" }}>{usage}</span>
                  <span style={{ fontFamily: "'Inter', monospace", fontSize: 12, fontWeight: 600, color: "#121212" }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          4. ICÔNES
      ══════════════════════════════════════════ */}
      <Section id="icones" label="04 · Icônes" title="Système d'icônes — Lucide React">
        <div style={{ marginBottom: 48 }}>
          <p style={{ fontSize: 13, color: "rgba(18,18,18,0.6)", lineHeight: 1.6, marginBottom: 40, maxWidth: 600 }}>
            Toutes les icônes utilisent <strong>Lucide React</strong> — SVG stroke, strokeWidth 1.5, style cohérent. Trois tailles officielles selon le contexte.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 32, marginBottom: 48 }}>
            {[
              { size: 16, label: "16px — Inline / texte", usage: "Labels, badges, tableaux, listes" },
              { size: 20, label: "20px — Boutons / actions", usage: "Boutons, navigation, CTA" },
              { size: 24, label: "24px — Navigation / hero", usage: "Header, sections, hero, footer" },
            ].map(({ size, label, usage }) => (
              <div key={size} style={{ padding: 32, background: "#F8F8F6", borderRadius: 12 }}>
                <div style={{ display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
                  {[Eye, Zap, Heart, Users, Calendar, MapPin, Bell, Settings].map((Icon, i) => (
                    <Icon key={i} size={size} color="#121212" strokeWidth={1.5} />
                  ))}
                </div>
                <p style={{ fontSize: 13, fontWeight: 600, color: "#121212", marginBottom: 4 }}>{label}</p>
                <p style={{ fontSize: 12, color: "#727169" }}>{usage}</p>
              </div>
            ))}
          </div>

          {/* Catalogue */}
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Catalogue — icônes utilisées dans AIME Wedding</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(8, 1fr)", gap: 16 }}>
            {[
              { Icon: Users, name: "Users" }, { Icon: Calendar, name: "Calendar" }, { Icon: MapPin, name: "MapPin" },
              { Icon: Heart, name: "Heart" }, { Icon: Music, name: "Music" }, { Icon: Cloud, name: "Cloud" },
              { Icon: Bell, name: "Bell" }, { Icon: Mail, name: "Mail" }, { Icon: Eye, name: "Eye" },
              { Icon: Zap, name: "Zap" }, { Icon: GitBranch, name: "GitBranch" }, { Icon: Shield, name: "Shield" },
              { Icon: Globe, name: "Globe" }, { Icon: Search, name: "Search" }, { Icon: Settings, name: "Settings" },
              { Icon: Share2, name: "Share2" }, { Icon: Star, name: "Star" }, { Icon: Plus, name: "Plus" },
              { Icon: ArrowRight, name: "ArrowRight" }, { Icon: ChevronRight, name: "ChevronRight" }, { Icon: Check, name: "Check" },
              { Icon: X, name: "X" }, { Icon: Info, name: "Info" }, { Icon: AlertTriangle, name: "AlertTriangle" },
            ].map(({ Icon, name }) => (
              <div key={name} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, padding: "16px 8px", background: "#F8F8F6", borderRadius: 8 }}>
                <Icon size={20} color="#121212" strokeWidth={1.5} />
                <span style={{ fontFamily: "'Inter', monospace", fontSize: 10, color: "#727169", textAlign: "center" }}>{name}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          5. BOUTONS
      ══════════════════════════════════════════ */}
      <Section id="boutons" label="05 · Boutons" title="États et variantes officiels">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
          {/* Primaire */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Bouton Primaire — fond blanc</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
                <button style={{ padding: "10px 24px", background: "#FFFFFF", color: "#121212", border: "1px solid #E5E3DC", borderRadius: 9999, fontSize: 14, fontFamily: "'Inter', sans-serif", fontWeight: 500, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
                  Entrer dans le mariage <ArrowRight size={14} />
                </button>
                <span style={{ fontSize: 12, color: "#727169" }}>Repos</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
                <button style={{ padding: "10px 24px", background: "#F5F3F0", color: "#121212", border: "1px solid #E5E3DC", borderRadius: 9999, fontSize: 14, fontFamily: "'Inter', sans-serif", fontWeight: 500, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
                  Entrer dans le mariage <ArrowRight size={14} />
                </button>
                <span style={{ fontSize: 12, color: "#727169" }}>Survol</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
                <button style={{ padding: "10px 24px", background: "#E5E3DC", color: "#121212", border: "1px solid #E5E3DC", borderRadius: 9999, fontSize: 14, fontFamily: "'Inter', sans-serif", fontWeight: 500, cursor: "pointer", transform: "scale(0.97)", display: "flex", alignItems: "center", gap: 8 }}>
                  Entrer dans le mariage <ArrowRight size={14} />
                </button>
                <span style={{ fontSize: 12, color: "#727169" }}>Actif</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
                <button disabled style={{ padding: "10px 24px", background: "#F8F8F6", color: "#E5E3DC", border: "1px solid #F5F3F0", borderRadius: 9999, fontSize: 14, fontFamily: "'Inter', sans-serif", fontWeight: 500, cursor: "not-allowed", display: "flex", alignItems: "center", gap: 8 }}>
                  Entrer dans le mariage <ArrowRight size={14} />
                </button>
                <span style={{ fontSize: 12, color: "#727169" }}>Désactivé</span>
              </div>
            </div>
          </div>

          {/* Secondaire */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Bouton Secondaire — fond noir</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
                <button style={{ padding: "10px 24px", background: "#121212", color: "#FFFFFF", border: "none", borderRadius: 9999, fontSize: 14, fontFamily: "'Inter', sans-serif", fontWeight: 500, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
                  Nous contacter <ArrowRight size={14} />
                </button>
                <span style={{ fontSize: 12, color: "#727169" }}>Repos</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
                <button style={{ padding: "10px 24px", background: "#2a2a2a", color: "#FFFFFF", border: "none", borderRadius: 9999, fontSize: 14, fontFamily: "'Inter', sans-serif", fontWeight: 500, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
                  Nous contacter <ArrowRight size={14} />
                </button>
                <span style={{ fontSize: 12, color: "#727169" }}>Survol</span>
              </div>
            </div>

            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24, marginTop: 40 }}>Bouton Icône</p>
            <div style={{ display: "flex", gap: 16 }}>
              {[Menu, Search, Share2, Plus].map((Icon, i) => (
                <button key={i} style={{ width: 40, height: 40, background: "#F8F8F6", border: "1px solid #E5E3DC", borderRadius: 9999, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                  <Icon size={16} color="#121212" strokeWidth={1.5} />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Specs */}
        <div style={{ marginTop: 48, background: "#F8F8F6", borderRadius: 12, padding: 32 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Spécifications officielles</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 }}>
            {[
              { prop: "border-radius", value: "9999px (pill)" },
              { prop: "padding", value: "10px 24px" },
              { prop: "font-size", value: "14px (Inter 500)" },
              { prop: "transition", value: "all 160ms ease-out" },
              { prop: "active scale", value: "scale(0.97)" },
              { prop: "border (primaire)", value: "1px solid #E5E3DC" },
              { prop: "shadow (survol)", value: "0 4px 12px rgba(0,0,0,0.08)" },
              { prop: "gap icône+texte", value: "8px" },
            ].map(({ prop, value }) => (
              <div key={prop} style={{ padding: "16px 20px", background: "#fff", borderRadius: 8, border: "1px solid #E5E3DC" }}>
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169", marginBottom: 4 }}>{prop}</p>
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 13, fontWeight: 600, color: "#121212" }}>{value}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          6. CARTES
      ══════════════════════════════════════════ */}
      <Section id="cartes" label="06 · Cartes" title="Modules et cartes">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24, marginBottom: 48 }}>
          {/* Carte projet */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Carte Projet</p>
            <div style={{ background: "#fff", border: "1px solid #E5E3DC", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ height: 160, background: "linear-gradient(135deg, #E5E3DC, #F8F8F6)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Globe size={32} color="#727169" strokeWidth={1.5} />
              </div>
              <div style={{ padding: 24 }}>
                <span style={{ background: "#F5F3F0", color: "#727169", fontSize: 11, fontWeight: 600, padding: "3px 8px", borderRadius: 4, letterSpacing: "0.08em", textTransform: "uppercase" }}>Projet</span>
                <h4 style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 18, fontWeight: 500, letterSpacing: "-0.01em", color: "#121212", margin: "12px 0 8px" }}>AIME Wedding</h4>
                <p style={{ fontSize: 14, color: "rgba(18,18,18,0.6)", lineHeight: 1.6 }}>Interface causale pour la gestion d'événements de mariage.</p>
              </div>
            </div>
          </div>

          {/* Carte Rôle */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Carte Rôle (dark)</p>
            <div style={{ background: "#121212", borderRadius: 12, padding: 32, height: "calc(100% - 32px)" }}>
              <div style={{ width: 40, height: 40, background: "rgba(255,255,255,0.1)", borderRadius: 9999, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 20 }}>
                <Heart size={20} color="rgba(255,255,255,0.9)" strokeWidth={1.5} />
              </div>
              <h4 style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 18, fontWeight: 500, letterSpacing: "-0.01em", color: "#FFFFFF", marginBottom: 8 }}>Couple</h4>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", lineHeight: 1.6 }}>Vue centrale — toutes les décisions et leurs impacts en temps réel.</p>
            </div>
          </div>

          {/* Widget HUD */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Widget HUD</p>
            <div style={{ background: "rgba(0,0,0,0.85)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, padding: 24, backdropFilter: "blur(12px)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.9)", letterSpacing: "0.05em" }}>Impact en temps réel</span>
                <span style={{ background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: 600, padding: "2px 8px", borderRadius: 9999, letterSpacing: "0.1em" }}>● LIVE</span>
              </div>
              {[
                { icon: <Users size={14} color="rgba(255,255,255,0.7)" />, text: "+12 invités → Budget +1 440€", dot: "#4ade80" },
                { icon: <Cloud size={14} color="rgba(255,255,255,0.7)" />, text: "Pluie → Plan B activé", dot: "#facc15" },
                { icon: <AlertTriangle size={14} color="rgba(255,255,255,0.7)" />, text: "PMR → Accessibilité vérifiée", dot: "#f87171" },
                { icon: <MessageCircle size={14} color="rgba(255,255,255,0.7)" />, text: "Discours +1 → +10 min", dot: "#60a5fa" },
              ].map(({ icon, text, dot }) => (
                <div key={text} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: "rgba(255,255,255,0.05)", borderRadius: 6, marginBottom: 6 }}>
                  {icon}
                  <span style={{ flex: 1, fontSize: 12, color: "rgba(255,255,255,0.8)" }}>{text}</span>
                  <div style={{ width: 8, height: 8, borderRadius: 9999, background: dot }} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Specs cartes */}
        <div style={{ background: "#F8F8F6", borderRadius: 12, padding: 32 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 24 }}>Tokens de composants</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
            {[
              { token: "--radius-sm", value: "4px", usage: "Badges, tags" },
              { token: "--radius-md", value: "12px", usage: "Cartes standard" },
              { token: "--radius-lg", value: "16px", usage: "Grandes cartes" },
              { token: "--radius-full", value: "9999px", usage: "Boutons, avatars" },
              { token: "--shadow-card", value: "0 1px 3px rgba(0,0,0,0.08)", usage: "Cartes légères" },
              { token: "--shadow-elevated", value: "0 8px 24px rgba(0,0,0,0.12)", usage: "Cartes au survol" },
              { token: "--shadow-hud", value: "0 20px 40px rgba(0,0,0,0.3)", usage: "Widgets HUD" },
              { token: "--border-default", value: "1px solid #E5E3DC", usage: "Bordures standard" },
            ].map(({ token, value, usage }) => (
              <div key={token} style={{ padding: "16px", background: "#fff", borderRadius: 8, border: "1px solid #E5E3DC" }}>
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169", marginBottom: 4 }}>{token}</p>
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 12, fontWeight: 600, color: "#121212", marginBottom: 4 }}>{value}</p>
                <p style={{ fontSize: 11, color: "#E5E3DC" }}>{usage}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          7. COMPOSANTS
      ══════════════════════════════════════════ */}
      <Section id="composants" label="07 · Composants" title="Composants récurrents">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
          {/* Header */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Header — Navigation principale</p>
            <div style={{ background: "rgba(0,0,0,0.85)", borderRadius: 12, padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", backdropFilter: "blur(12px)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 28, height: 28, background: "#fff", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Layers size={14} color="#121212" />
                </div>
                <span style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 14, fontWeight: 600, color: "#fff" }}>AIME®</span>
              </div>
              <div style={{ display: "flex", gap: 24 }}>
                {["Histoire", "Paradigme", "Équipe", "Brevet"].map(item => (
                  <span key={item} style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>{item}</span>
                ))}
              </div>
              <button style={{ padding: "8px 20px", background: "#fff", color: "#121212", borderRadius: 9999, fontSize: 13, fontFamily: "'Inter', sans-serif", fontWeight: 500, border: "none", cursor: "pointer" }}>
                Nous contacter
              </button>
            </div>
            <div style={{ marginTop: 16, padding: 16, background: "#F8F8F6", borderRadius: 8 }}>
              <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169", lineHeight: 1.8 }}>
                position: sticky | top: 0 | z-index: 100<br />
                background: rgba(0,0,0,0.85) | backdrop-filter: blur(12px)<br />
                border-bottom: 1px solid rgba(255,255,255,0.1)<br />
                height: 60px | padding: 0 48px
              </p>
            </div>
          </div>

          {/* Badge / Tag */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Badges & Tags</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
              {[
                { label: "INTERFACE CAUSALE", bg: "#F5F3F0", color: "#727169" },
                { label: "BREVETABLE", bg: "#121212", color: "#fff" },
                { label: "LIVE", bg: "rgba(74,222,128,0.15)", color: "#16a34a" },
                { label: "AIME® 2026", bg: "#F8F8F6", color: "#121212" },
                { label: "USPTO · EPO · WIPO", bg: "#F5F3F0", color: "#727169" },
              ].map(({ label, bg, color }) => (
                <span key={label} style={{ background: bg, color, fontSize: 11, fontWeight: 600, padding: "4px 10px", borderRadius: 4, letterSpacing: "0.08em", textTransform: "uppercase", fontFamily: "'Inter', sans-serif" }}>
                  {label}
                </span>
              ))}
            </div>
            <div style={{ padding: 16, background: "#F8F8F6", borderRadius: 8 }}>
              <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169", lineHeight: 1.8 }}>
                border-radius: 4px (--radius-sm)<br />
                font: Inter 11px 600 uppercase<br />
                letter-spacing: 0.08em<br />
                padding: 4px 10px
              </p>
            </div>
          </div>

          {/* Timeline */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Timeline</p>
            <div style={{ position: "relative", paddingLeft: 24 }}>
              <div style={{ position: "absolute", left: 4, top: 8, bottom: 8, width: 1, background: "#E5E3DC" }} />
              {[
                { year: "2018", event: "Création AIME® — Premiers systèmes causaux" },
                { year: "2022", event: "Paradigme Point Zéro — Formule 6 couches" },
                { year: "2024", event: "AIME Wedding — HUD causal en production" },
                { year: "2026", event: "Rapport Wide Search — 0 antériorité directe" },
              ].map(({ year, event }) => (
                <div key={year} style={{ display: "flex", gap: 16, marginBottom: 24, position: "relative" }}>
                  <div style={{ position: "absolute", left: -20, top: 6, width: 10, height: 10, borderRadius: 9999, background: "#121212", border: "2px solid #fff", boxShadow: "0 0 0 1px #E5E3DC" }} />
                  <div>
                    <span style={{ fontFamily: "'Inter', monospace", fontSize: 11, fontWeight: 600, color: "#727169" }}>{year}</span>
                    <p style={{ fontSize: 14, color: "#121212", lineHeight: 1.5, marginTop: 2 }}>{event}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Séparateur */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "#727169", marginBottom: 16 }}>Séparateurs & Dividers</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
              <div>
                <hr style={{ border: "none", borderTop: "1px solid #E5E3DC", margin: "0 0 8px" }} />
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169" }}>Divider standard — 1px solid #E5E3DC</p>
              </div>
              <div>
                <hr style={{ border: "none", borderTop: "1px solid rgba(255,255,255,0.1)", margin: "0 0 8px", background: "#121212", padding: "1px 0" }} />
                <p style={{ fontFamily: "'Inter', monospace", fontSize: 11, color: "#727169" }}>Divider dark — 1px solid rgba(255,255,255,0.1)</p>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                <hr style={{ flex: 1, border: "none", borderTop: "1px solid #E5E3DC" }} />
                <span style={{ fontSize: 11, fontWeight: 600, color: "#727169", letterSpacing: "0.1em", textTransform: "uppercase" }}>ou</span>
                <hr style={{ flex: 1, border: "none", borderTop: "1px solid #E5E3DC" }} />
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* ══════════════════════════════════════════
          8. INCOHÉRENCES
      ══════════════════════════════════════════ */}
      <Section id="incoherences" label="08 · Incohérences" title="Audit — 11 incohérences corrigées">
        <p style={{ fontSize: 13, color: "rgba(18,18,18,0.6)", lineHeight: 1.6, marginBottom: 40, maxWidth: 700 }}>
          Relevé exhaustif des incohérences graphiques identifiées sur les 8 pages du site AIME Wedding, avec la correction officielle à appliquer pour chaque cas.
        </p>
        <div style={{ border: "1px solid #E5E3DC", borderRadius: 12, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#F8F8F6" }}>
                <th style={{ padding: "16px 20px", textAlign: "left", fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#727169", borderBottom: "1px solid #E5E3DC" }}>Catégorie</th>
                <th style={{ padding: "16px 20px", textAlign: "left", fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#c0392b", borderBottom: "1px solid #E5E3DC" }}>⚠ Incohérence trouvée</th>
                <th style={{ padding: "16px 20px", textAlign: "left", fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#27ae60", borderBottom: "1px solid #E5E3DC" }}>✓ Correction officielle</th>
              </tr>
            </thead>
            <tbody>
              <InconsistencyRow
                category="Typographie"
                found="H1 : 30px sur la landing vs 48px sur /couple — pas de taille canonique"
                fix="H1 Display : 56px (Aeonik 600, tracking -0.04em) — valeur unique pour toutes les pages"
              />
              <InconsistencyRow
                category="Typographie"
                found="H3 : 24px sur la landing vs 20px sur /couple — deux valeurs pour le même niveau"
                fix="H3 : 24px (Aeonik 500, tracking -0.02em) — valeur unique, poids réduit à 500"
              />
              <InconsistencyRow
                category="Typographie"
                found="Labels : 2 valeurs de tracking (3.08px vs 2.42px) pour le même niveau de texte"
                fix="Label : Inter 11px 600, tracking 0.16em (2.56px), uppercase — valeur unique"
              />
              <InconsistencyRow
                category="Typographie"
                found="line-height : mélange px (24px) et unitless (1.05) selon les composants"
                fix="Toujours utiliser des valeurs unitless : 1.0 (display), 1.1 (H2), 1.2 (H3), 1.6 (body)"
              />
              <InconsistencyRow
                category="Couleurs"
                found="5 valeurs d'opacité pour texte blanc sur fond sombre : 0.4, 0.55, 0.7, 0.8, 0.85"
                fix="2 valeurs officielles : --color-text-on-dark (0.9) et --color-text-muted-dark (0.5)"
              />
              <InconsistencyRow
                category="Couleurs"
                found="3 nuances de warm gray non standardisées (#E5E3DC, #F5F3F0, #F8F8F6) sans token"
                fix="3 tokens officiels : --color-warm-gray-100/200 et --color-warm-white — nommés et documentés"
              />
              <InconsistencyRow
                category="Couleurs"
                found="Couleurs définies en RGB/RGBA hardcodé plutôt qu'en variables CSS"
                fix="Toutes les couleurs via variables CSS --color-* dans :root — aucune valeur hardcodée"
              />
              <InconsistencyRow
                category="Espacements"
                found="13 valeurs de padding vertical différentes (6, 8, 12, 16, 20, 24, 32, 48, 56, 64, 80, 96, 112px)"
                fix="Grille 8pt stricte : 4 valeurs de section (48, 80, 96, 128px) — toutes les autres supprimées"
              />
              <InconsistencyRow
                category="Boutons"
                found="border-radius incohérent : 2px sur certains boutons vs 9999px (pill) sur d'autres"
                fix="Tous les boutons : border-radius 9999px (pill) — sans exception"
              />
              <InconsistencyRow
                category="Boutons"
                found="Hauteurs de boutons variables : 8px, 9px, 10px, 28px, 36px non standardisées"
                fix="Padding officiel : 10px 24px (standard), 8px 16px (compact), 12px 32px (large)"
              />
              <InconsistencyRow
                category="Icônes"
                found="4 tailles d'icônes différentes (14, 16, 20, 24px) sans règle d'usage documentée"
                fix="3 tailles officielles : 16px (inline), 20px (boutons/actions), 24px (navigation/hero)"
              />
            </tbody>
          </table>
        </div>
      </Section>

      {/* ── FOOTER ── */}
      <footer style={{ background: "#121212", padding: "64px 0" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 48px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <div style={{ width: 28, height: 28, background: "#fff", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Layers size={14} color="#121212" />
              </div>
              <span style={{ fontFamily: "'Aeonik', 'Inter', sans-serif", fontSize: 14, fontWeight: 600, color: "#fff" }}>AIME® Design System</span>
            </div>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", lineHeight: 1.6 }}>
              Source de vérité graphique — AIME® / AIME Wedding<br />
              Basé sur l'audit Wide Search du 2 juillet 2026
            </p>
          </div>
          <div style={{ textAlign: "right" }}>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginBottom: 8 }}>Version</p>
            <p style={{ fontFamily: "'Inter', monospace", fontSize: 13, color: "rgba(255,255,255,0.6)" }}>v1.0 · Juillet 2026</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
