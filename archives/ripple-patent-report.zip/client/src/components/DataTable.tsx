/* ============================================================
   DATA TABLE — Tableaux comparatifs stylisés
   Design: Onde Causale — fond sombre, accents cyan/or
   ============================================================ */
import { ReactNode } from "react";

interface Column {
  key: string;
  label: string;
  width?: string;
  align?: "left" | "center" | "right";
}

interface DataTableProps {
  columns: Column[];
  rows: Record<string, ReactNode>[];
  caption?: string;
}

export default function DataTable({ columns, rows, caption }: DataTableProps) {
  return (
    <div className="w-full overflow-x-auto rounded-lg" style={{ border: "1px solid oklch(0.25 0.012 260)" }}>
      <table className="w-full text-sm border-collapse">
        {caption && (
          <caption className="text-xs font-mono tracking-wider uppercase mb-2 text-left px-4 pt-3"
            style={{ color: "oklch(0.55 0.012 260)" }}>
            {caption}
          </caption>
        )}
        <thead>
          <tr style={{ background: "oklch(0.18 0.012 260)", borderBottom: "1px solid oklch(0.25 0.012 260)" }}>
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 py-3 font-mono text-xs tracking-wider uppercase"
                style={{
                  color: "oklch(0.72 0.18 200)",
                  textAlign: col.align || "left",
                  width: col.width,
                  whiteSpace: "nowrap",
                }}
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={i}
              className="transition-colors duration-150"
              style={{
                background: i % 2 === 0 ? "oklch(0.12 0.012 260)" : "oklch(0.14 0.012 260)",
                borderBottom: "1px solid oklch(0.20 0.012 260)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLTableRowElement).style.background = "oklch(0.72 0.18 200 / 0.05)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLTableRowElement).style.background = i % 2 === 0 ? "oklch(0.12 0.012 260)" : "oklch(0.14 0.012 260)";
              }}
            >
              {columns.map((col) => (
                <td
                  key={col.key}
                  className="px-4 py-3 leading-relaxed"
                  style={{
                    color: "oklch(0.80 0.008 260)",
                    textAlign: col.align || "left",
                  }}
                >
                  {row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* Verdict Badge Component */
export function VerdictBadge({ level }: { level: "ÉLEVÉ" | "OUI" | "MOYEN" | "NON" | "INÉDIT" | string }) {
  const isPositive = ["ÉLEVÉ", "OUI", "INÉDIT", "BREVETABLE", "FORTEMENT BREVETABLE"].includes(level);
  const isNeutral = ["MOYEN", "PARTIEL"].includes(level);

  return (
    <span
      className="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-mono font-medium"
      style={
        isPositive
          ? { background: "oklch(0.72 0.18 200 / 0.15)", color: "oklch(0.72 0.18 200)", border: "1px solid oklch(0.72 0.18 200 / 0.4)" }
          : isNeutral
          ? { background: "oklch(0.78 0.15 55 / 0.15)", color: "oklch(0.78 0.15 55)", border: "1px solid oklch(0.78 0.15 55 / 0.4)" }
          : { background: "oklch(0.65 0.22 25 / 0.15)", color: "oklch(0.65 0.22 25)", border: "1px solid oklch(0.65 0.22 25 / 0.4)" }
      }
    >
      {level}
    </span>
  );
}

/* Check/Cross icons for boolean columns */
export function BoolIcon({ value }: { value: boolean }) {
  return value ? (
    <span style={{ color: "oklch(0.72 0.18 200)" }} className="text-base">✓</span>
  ) : (
    <span style={{ color: "oklch(0.65 0.22 25)" }} className="text-base">✗</span>
  );
}
