/* ============================================================
   SECTION WRAPPER — Animation d'entrée fade-in-up
   Design: Onde Causale
   ============================================================ */
import { useEffect, useRef, ReactNode } from "react";

interface SectionWrapperProps {
  id: string;
  children: ReactNode;
  className?: string;
  delay?: number;
}

export default function SectionWrapper({ id, children, className = "", delay = 0 }: SectionWrapperProps) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add("visible");
            }, delay);
          }
        });
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [delay]);

  return (
    <section
      ref={ref}
      id={id}
      className={`fade-in-up ${className}`}
    >
      {children}
    </section>
  );
}
