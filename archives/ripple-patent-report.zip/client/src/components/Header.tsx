/* ============================================================
   HEADER — Navigation fixe avec logo Point Zéro
   Design: Onde Causale — fond sidebar bleu nuit, accents cyan
   ============================================================ */
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const navItems = [
  { id: "synthese", label: "Synthèse" },
  { id: "architecture", label: "Architecture" },
  { id: "etat-art", label: "État de l'art" },
  { id: "preuves", label: "Preuves" },
  { id: "anteriorite", label: "Antériorité" },
  { id: "cartographie", label: "Cartographie" },
  { id: "strategie", label: "Stratégie" },
  { id: "codex", label: "Codex" },
];

export default function Header() {
  const [active, setActive] = useState("synthese");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      // Detect active section
      const sections = navItems.map((item) => document.getElementById(item.id));
      let current = "synthese";
      sections.forEach((section) => {
        if (section) {
          const rect = section.getBoundingClientRect();
          if (rect.top <= 120) {
            current = section.id;
          }
        }
      });
      setActive(current);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setMobileOpen(false);
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col fixed left-0 top-0 h-full w-64 z-50"
        style={{ background: "oklch(0.08 0.015 260)", borderRight: "1px solid oklch(0.20 0.012 260)" }}>
        {/* Logo */}
        <div className="px-6 pt-8 pb-6 border-b" style={{ borderColor: "oklch(0.20 0.012 260)" }}>
          <div className="flex items-center gap-3 mb-4">
            <div className="relative w-10 h-10 flex items-center justify-center">
              {/* Ripple rings */}
              <div className="absolute inset-0 rounded-full ripple-ring"
                style={{ border: "1px solid oklch(0.72 0.18 200 / 0.4)" }} />
              <div className="absolute inset-0 rounded-full ripple-ring-2"
                style={{ border: "1px solid oklch(0.72 0.18 200 / 0.3)" }} />
              <div className="absolute inset-0 rounded-full ripple-ring-3"
                style={{ border: "1px solid oklch(0.72 0.18 200 / 0.2)" }} />
              {/* Center dot */}
              <div className="w-3 h-3 rounded-full glow-cyan"
                style={{ background: "oklch(0.72 0.18 200)" }} />
            </div>
            <div>
              <div className="text-xs font-mono tracking-widest uppercase"
                style={{ color: "oklch(0.72 0.18 200)" }}>
                RIPPLE
              </div>
              <div className="text-base font-semibold leading-tight"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.92 0.005 260)" }}>
                Point Zéro
              </div>
            </div>
          </div>
          <div className="text-xs leading-relaxed" style={{ color: "oklch(0.55 0.012 260)" }}>
            Rapport Wide Search<br />
            Brevetabilité · 2 juillet 2026
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 overflow-y-auto">
          <div className="text-xs font-mono tracking-widest uppercase mb-4 px-2"
            style={{ color: "oklch(0.45 0.012 260)" }}>
            Sections
          </div>
          {navItems.map((item, i) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="w-full text-left px-3 py-2.5 rounded-md mb-1 text-sm transition-all duration-200 flex items-center gap-3"
              style={{
                color: active === item.id ? "oklch(0.72 0.18 200)" : "oklch(0.65 0.012 260)",
                background: active === item.id ? "oklch(0.72 0.18 200 / 0.1)" : "transparent",
                borderLeft: active === item.id ? "2px solid oklch(0.72 0.18 200)" : "2px solid transparent",
              }}
            >
              <span className="font-mono text-xs" style={{ color: "oklch(0.45 0.012 260)" }}>
                0{i + 1}
              </span>
              {item.label}
            </button>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-6 py-4 border-t" style={{ borderColor: "oklch(0.20 0.012 260)" }}>
          <div className="text-xs" style={{ color: "oklch(0.40 0.010 260)" }}>
            Manus AI · Wide Research
          </div>
          <div className="flex items-center gap-2 mt-2">
            <div className="w-2 h-2 rounded-full" style={{ background: "oklch(0.65 0.18 160)" }} />
            <span className="text-xs" style={{ color: "oklch(0.55 0.012 260)" }}>
              Niveau d'opportunité : ÉLEVÉ
            </span>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className={`lg:hidden fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "backdrop-blur-xl" : ""}`}
        style={{ background: scrolled ? "oklch(0.08 0.015 260 / 0.95)" : "oklch(0.08 0.015 260)", borderBottom: "1px solid oklch(0.20 0.012 260)" }}>
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="relative w-8 h-8 flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: "oklch(0.72 0.18 200)" }} />
            </div>
            <div>
              <span className="text-xs font-mono tracking-widest" style={{ color: "oklch(0.72 0.18 200)" }}>RIPPLE</span>
              <span className="text-sm font-semibold ml-2" style={{ fontFamily: "'Playfair Display', serif" }}>Point Zéro</span>
            </div>
          </div>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="p-2 rounded-md"
            style={{ color: "oklch(0.72 0.18 200)" }}>
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="border-t px-4 py-4" style={{ borderColor: "oklch(0.20 0.012 260)", background: "oklch(0.08 0.015 260)" }}>
            {navItems.map((item, i) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="w-full text-left px-3 py-2.5 rounded-md mb-1 text-sm flex items-center gap-3"
                style={{
                  color: active === item.id ? "oklch(0.72 0.18 200)" : "oklch(0.65 0.012 260)",
                  background: active === item.id ? "oklch(0.72 0.18 200 / 0.1)" : "transparent",
                }}
              >
                <span className="font-mono text-xs" style={{ color: "oklch(0.45 0.012 260)" }}>0{i + 1}</span>
                {item.label}
              </button>
            ))}
          </div>
        )}
      </header>
    </>
  );
}
