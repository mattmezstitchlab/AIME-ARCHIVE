# Ideas — Point Zéro · RIPPLE — Rapport de Brevetabilité

## Trois approches stylistiques

### Approche 1 — « Dossier Classifié »
**Thème :** Intelligence technique, documents confidentiels, esthétique de la recherche scientifique.
**Intro :** Noir profond, typographie monospace pour les données techniques, accents dorés pour les éléments critiques. Évoque un dossier de brevet officiel numérisé.
**Probabilité :** 0.04

### Approche 2 — « Onde Causale »
**Thème :** Visualisation de données, propagation d'ondes, modernité scientifique.
**Intro :** Fond sombre avec des lignes de grille subtiles, des cercles concentriques animés autour du Point Zéro, couleurs électriques (bleu nuit + cyan + or). Évoque la propagation d'une onde dans un graphe de dépendances.
**Probabilité :** 0.07

### Approche 3 — « Manifeste Éditorial »
**Thème :** Typographie éditoriale premium, magazine de propriété intellectuelle, clarté intellectuelle.
**Intro :** Fond blanc cassé (ivoire), typographie serif élégante pour les titres, sans-serif géométrique pour le corps. Noir d'encre, accents bordeaux/vermillon. Évoque les grandes revues juridiques et scientifiques.
**Probabilité :** 0.03

---

## Approche choisie : **« Onde Causale »** (Probabilité 0.07)

### Design Movement
**Data Visualization Noir** — Inspiré des interfaces de recherche scientifique et des tableaux de bord d'analyse de brevets, avec une esthétique sombre et des éléments lumineux qui évoquent la propagation d'ondes dans un graphe de causalité.

### Core Principles
1. **Profondeur sur fond sombre** : Fond noir/bleu nuit avec des couches de transparence et des effets de lueur subtils.
2. **Données comme art** : Les tableaux comparatifs et les matrices deviennent des éléments visuels forts, pas de simples grilles.
3. **Hiérarchie typographique forte** : Titres en display serif, corps en sans-serif géométrique, données en monospace.
4. **Mouvement causal** : Les animations évoquent la propagation d'une onde — les éléments apparaissent en cascade, les cercles pulsent.

### Color Philosophy
- **Fond principal** : `oklch(0.10 0.015 260)` — Bleu nuit quasi-noir
- **Fond secondaire** : `oklch(0.14 0.012 260)` — Bleu nuit légèrement plus clair
- **Accent primaire** : `oklch(0.72 0.18 200)` — Cyan électrique (onde RIPPLE)
- **Accent secondaire** : `oklch(0.78 0.15 55)` — Or/ambre (brevet, valeur)
- **Texte principal** : `oklch(0.92 0.005 260)` — Blanc légèrement bleuté
- **Texte secondaire** : `oklch(0.65 0.01 260)` — Gris bleuté

### Layout Paradigm
Navigation latérale fixe (sidebar) sur desktop, navigation sticky en haut sur mobile. Le contenu principal défile verticalement avec des sections bien délimitées. Pas de layout centré générique — les sections alternent entre pleine largeur et colonnes asymétriques.

### Signature Elements
1. **Cercles concentriques animés** autour du logo Point Zéro dans le hero
2. **Badges de verdict** colorés (ÉLEVÉ = cyan, MOYEN = or, FAIBLE = rouge) dans les tableaux
3. **Lignes de connexion SVG** subtiles entre les sections pour évoquer le graphe de dépendances

### Interaction Philosophy
Scroll fluide avec révélation progressive des sections. Les tableaux s'animent à l'entrée dans le viewport. Les badges de verdict pulsent légèrement. Navigation sidebar avec indicateur de section active.

### Animation
- Entrées en `fade + translateY(20px)` à 300ms ease-out
- Stagger de 60ms entre les éléments de liste
- Cercles concentriques en `scale + opacity` loop à 3s
- Hover sur les cartes : `translateY(-4px)` + lueur cyan subtile

### Typography System
- **Display/Titres** : `Playfair Display` (serif élégant, autorité)
- **Corps** : `DM Sans` (géométrique, lisible, moderne)
- **Données/Code** : `JetBrains Mono` (monospace, précision technique)
- Hiérarchie : H1 48-64px, H2 32-40px, H3 24px, body 16px, small 14px

### Brand Essence
**Point Zéro · RIPPLE** — L'innovation brevetable au cœur de la coordination événementielle. Pour les inventeurs, les juristes et les investisseurs qui veulent comprendre ce qui rend RIPPLE unique au monde.
Personnalité : **Rigoureux · Visionnaire · Protégeable**

### Brand Voice
- Ton : Assertif, technique, confiant. Pas de jargon inutile, mais précision scientifique.
- Exemple headline : « Une combinaison inédite. Zéro antériorité directe. »
- Exemple CTA : « Consulter le dossier complet »

### Wordmark & Logo
Cercle avec un point central (Point Zéro) entouré de 3 cercles concentriques en dégradé cyan. Le mot « RIPPLE » en petites capitales à côté.

### Signature Brand Color
**Cyan électrique** `oklch(0.72 0.18 200)` — La couleur de l'onde RIPPLE.
