import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { DMC_COLORS } from "./ColorLegend";

const getHexColor = (dmcCode) => {
  const color = DMC_COLORS[dmcCode];
  return color ? color.hex : dmcCode;
};

export default function GridCanvas({ width, height, cells, onCellChange, selectedColor }) {
  const [isPainting, setIsPainting] = useState(false);
  
  const handleCellClick = (row, col) => {
    onCellChange(row, col, selectedColor);
  };

  const handleCellMouseDown = (row, col) => {
    setIsPainting(true);
    onCellChange(row, col, selectedColor);
  };

  const handleCellMouseEnter = (row, col) => {
    if (isPainting) {
      onCellChange(row, col, selectedColor);
    }
  };

  const handleCellTouchStart = (e, row, col) => {
    e.preventDefault();
    setIsPainting(true);
    onCellChange(row, col, selectedColor);
  };

  const handleCellTouchMove = (e) => {
    e.preventDefault();
    if (!isPainting) return;
    
    const touch = e.touches[0];
    const element = document.elementFromPoint(touch.clientX, touch.clientY);
    if (element && element.dataset.row && element.dataset.col) {
      const row = parseInt(element.dataset.row);
      const col = parseInt(element.dataset.col);
      onCellChange(row, col, selectedColor);
    }
  };

  const handleMouseUp = () => {
    setIsPainting(false);
  };

  const handleTouchEnd = () => {
    setIsPainting(false);
  };

  const handleContextMenu = (e, row, col) => {
    e.preventDefault();
    onCellChange(row, col, 'DMC B5200');
  };

  const cellSize = Math.min(30, Math.floor(600 / Math.max(width, height)));

  return (
    <Card className="p-4 bg-white border-2 border-[#A8C2D5]/30 overflow-auto">
      <div className="inline-block">
        <div
          className="grid border-2 border-[#313131]/30"
          style={{
            gridTemplateColumns: `repeat(${width}, ${cellSize}px)`,
            gap: 0,
            touchAction: 'none',
            userSelect: 'none'
          }}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchEnd={handleTouchEnd}
          onTouchCancel={handleTouchEnd}
        >
          {cells.map((row, rowIndex) =>
            row.map((cell, colIndex) => (
              <div
                key={`${rowIndex}-${colIndex}`}
                data-row={rowIndex}
                data-col={colIndex}
                className="border border-[#313131]/20 cursor-pointer transition-all hover:brightness-90"
                style={{
                  width: cellSize,
                  height: cellSize,
                  backgroundColor: getHexColor(cell || 'DMC B5200'),
                }}
                onClick={() => handleCellClick(rowIndex, colIndex)}
                onMouseDown={() => handleCellMouseDown(rowIndex, colIndex)}
                onMouseEnter={() => handleCellMouseEnter(rowIndex, colIndex)}
                onTouchStart={(e) => handleCellTouchStart(e, rowIndex, colIndex)}
                onTouchMove={handleCellTouchMove}
                onContextMenu={(e) => handleContextMenu(e, rowIndex, colIndex)}
              />
            ))
          )}
        </div>
      </div>
    </Card>
  );
}