import React from 'react';
import { Card } from "@/components/ui/card";
import { Check } from "lucide-react";

const DMC_COLORS = [
  { code: 'DMC B5200', name: 'Blanc', hex: '#FFFFFF', border: true },
  { code: 'DMC ECRU', name: 'Écru', hex: '#F5E6C8' },
  { code: 'DMC 310', name: 'Noir', hex: '#000000' },
  { code: 'DMC 666', name: 'Rouge', hex: '#FF1C37' },
  { code: 'DMC 605', name: 'Rose', hex: '#FF8FBF' },
  { code: 'DMC 820', name: 'Bleu', hex: '#14316D' },
  { code: 'DMC 702', name: 'Vert', hex: '#3EB54A' },
  { code: 'DMC 307', name: 'Jaune', hex: '#FFD200' },
  { code: 'DMC 938', name: 'Marron', hex: '#3B2312' },
  { code: 'DMC 415', name: 'Gris', hex: '#B4B9C2' },
];

export default function ColorPalette({ selectedColor, onColorSelect, selectedColorInfo }) {
  return (
    <Card className="p-4 bg-white border-2 border-[#EFA6C5]/30">
      <h3 className="text-sm font-semibold text-[#313131] mb-3">Palette de couleurs</h3>
      
      {selectedColorInfo && (
        <div className="mb-4 p-3 bg-[#EFA6C5]/10 rounded-lg">
          <div className="text-xs text-[#313131]/60 mb-1">Couleur actuelle :</div>
          <div className="flex items-center gap-2">
            <div 
              className="w-6 h-6 rounded border-2 border-gray-200"
              style={{ backgroundColor: selectedColorInfo.hex }}
            />
            <div className="text-sm font-semibold text-[#313131]">
              {selectedColorInfo.code} ({selectedColorInfo.name})
            </div>
          </div>
        </div>
      )}
      
      <div className="flex flex-wrap gap-2">
        {DMC_COLORS.map((color) => (
          <button
            key={color.code}
            onClick={() => onColorSelect(color.code)}
            className={`relative w-12 h-12 rounded-lg transition-all hover:scale-110 ${
              selectedColor === color.code 
                ? 'ring-4 ring-[#EFA6C5] scale-110' 
                : 'ring-2 ring-gray-200'
            }`}
            style={{ 
              backgroundColor: color.hex,
              border: color.border ? '2px solid #D1D5DB' : 'none'
            }}
            title={`${color.code} - ${color.name}`}
          >
            {selectedColor === color.code && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Check 
                  className="w-6 h-6" 
                  style={{ 
                    color: color.hex === '#FFFFFF' || color.code === 'DMC 307' || color.code === 'DMC ECRU'
                      ? '#313131' 
                      : '#FFFFFF' 
                  }} 
                />
              </div>
            )}
          </button>
        ))}
      </div>
    </Card>
  );
}

export { DMC_COLORS };