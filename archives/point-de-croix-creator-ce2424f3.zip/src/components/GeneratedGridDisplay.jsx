import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, ZoomIn, ZoomOut, Palette } from "lucide-react";
import { toast } from "sonner";

export default function GeneratedGridDisplay({ grid }) {
  const [zoom, setZoom] = useState(1);
  const [showColors, setShowColors] = useState(false);
  const gridRef = useRef(null);

  if (!grid || !grid.cells) return null;

  const { width, height, cells, colors } = grid;

  // Calculer la taille des cases selon le zoom
  const cellSize = Math.max(3, Math.min(20, 600 / Math.max(width, height))) * zoom;

  const handleDownload = async () => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      const downloadCellSize = 20;
      canvas.width = width * downloadCellSize;
      canvas.height = height * downloadCellSize;
      
      // Fond blanc
      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Dessiner la grille
      for (let row = 0; row < height; row++) {
        for (let col = 0; col < width; col++) {
          const color = cells[row]?.[col];
          if (color) {
            // Trouver la couleur hex
            const colorInfo = colors?.find(c => c.code === color);
            ctx.fillStyle = colorInfo?.hex || '#CCCCCC';
            ctx.fillRect(
              col * downloadCellSize,
              row * downloadCellSize,
              downloadCellSize,
              downloadCellSize
            );
          }
          
          // Bordure de case
          ctx.strokeStyle = '#E0E0E0';
          ctx.strokeRect(
            col * downloadCellSize,
            row * downloadCellSize,
            downloadCellSize,
            downloadCellSize
          );
        }
      }
      
      // Lignes de repère tous les 10 cases
      ctx.strokeStyle = '#666666';
      ctx.lineWidth = 2;
      for (let i = 0; i <= width; i += 10) {
        ctx.beginPath();
        ctx.moveTo(i * downloadCellSize, 0);
        ctx.lineTo(i * downloadCellSize, canvas.height);
        ctx.stroke();
      }
      for (let i = 0; i <= height; i += 10) {
        ctx.beginPath();
        ctx.moveTo(0, i * downloadCellSize);
        ctx.lineTo(canvas.width, i * downloadCellSize);
        ctx.stroke();
      }
      
      // Télécharger
      canvas.toBlob((blob) => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = `grille_point_croix_${width}x${height}.png`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
        toast.success('Grille téléchargée');
      }, 'image/png');
    } catch (error) {
      console.error('Erreur lors du téléchargement:', error);
      toast.error('Erreur lors du téléchargement');
    }
  };

  return (
    <div className="space-y-4">
      {/* Contrôles */}
      <div className="flex items-center gap-2 justify-between">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
            disabled={zoom <= 0.5}
          >
            <ZoomOut className="w-4 h-4" />
          </Button>
          <span className="text-sm text-[#313131] font-medium min-w-[60px] text-center">
            {Math.round(zoom * 100)}%
          </span>
          <Button
            size="sm"
            onClick={() => setZoom(Math.min(3, zoom + 0.25))}
            disabled={zoom >= 3}
          >
            <ZoomIn className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowColors(!showColors)}
          >
            <Palette className="w-4 h-4 mr-2" />
            Couleurs
          </Button>
          <Button
            size="sm"
            onClick={handleDownload}
            className="bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] text-white"
          >
            <Download className="w-4 h-4 mr-2" />
            Télécharger
          </Button>
        </div>
      </div>

      {/* Info */}
      <div className="text-sm text-[#313131]/70 text-center">
        Grille de {width} × {height} cases ({colors?.length || 0} couleurs)
      </div>

      {/* Grille */}
      <div 
        ref={gridRef}
        className="overflow-auto max-h-[500px] bg-white rounded-lg border-2 border-[#A8C2D5]/30 p-2"
      >
        <div 
          className="inline-block"
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${width}, ${cellSize}px)`,
            gap: '1px',
            backgroundColor: '#E0E0E0'
          }}
        >
          {cells.map((row, rowIndex) => 
            row.map((color, colIndex) => {
              const colorInfo = colors?.find(c => c.code === color);
              return (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  style={{
                    width: `${cellSize}px`,
                    height: `${cellSize}px`,
                    backgroundColor: colorInfo?.hex || '#FFFFFF',
                    border: (rowIndex % 10 === 0 || colIndex % 10 === 0) ? '1px solid #666' : 'none'
                  }}
                  title={color}
                />
              );
            })
          )}
        </div>
      </div>

      {/* Palette de couleurs */}
      {showColors && colors && colors.length > 0 && (
        <Card className="p-4 bg-[#A8C2D5]/10">
          <h4 className="text-sm font-semibold text-[#313131] mb-3">Couleurs utilisées</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {colors.map((color, index) => (
              <div key={index} className="flex items-center gap-2 text-xs">
                <div 
                  className="w-8 h-8 rounded border-2 border-gray-300 flex-shrink-0"
                  style={{ backgroundColor: color.hex }}
                />
                <div>
                  <div className="font-semibold">{color.code}</div>
                  <div className="text-[#313131]/60">{color.name}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}