import React from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FolderOpen, Trash2, Copy, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { DMC_COLORS } from "./ColorLegend";

const getHexColor = (dmcCode) => {
  const color = DMC_COLORS[dmcCode];
  return color ? color.hex : dmcCode;
};

export default function GridCard({ grid, onOpen, onDelete, onDuplicate }) {
  return (
    <Card className="group overflow-hidden bg-white border-2 border-[#A8C2D5]/20 hover:border-[#EFA6C5] transition-all duration-300 hover:shadow-lg">
      <div className="aspect-square relative overflow-hidden bg-[#FFF7EC] p-4">
        <div 
          className="grid border-2 border-[#313131]/20 mx-auto"
          style={{
            gridTemplateColumns: `repeat(${grid.width}, 1fr)`,
            width: '100%',
            maxWidth: '200px',
            aspectRatio: `${grid.width}/${grid.height}`
          }}
        >
          {grid.cells.map((row, rowIndex) =>
            row.map((cell, colIndex) => (
              <div
                key={`${rowIndex}-${colIndex}`}
                className="border border-[#313131]/10"
                style={{
                  backgroundColor: getHexColor(cell || 'DMC B5200'),
                }}
              />
            ))
          )}
        </div>
      </div>
      
      <div className="p-4 space-y-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-[#313131] text-lg truncate flex-1">{grid.name}</h3>
            {grid.image_reference && (
              <ImageIcon className="w-4 h-4 text-[#A8C2D5] flex-shrink-0" title="Avec photo de référence" />
            )}
          </div>
          <p className="text-sm text-[#313131]/60 mt-1">
            {grid.width}×{grid.height} cases
          </p>
          <p className="text-xs text-[#313131]/40 mt-1">
            {format(new Date(grid.created_date), "d MMMM yyyy", { locale: fr })}
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={() => onOpen(grid)}
            className="flex-1 bg-[#EFA6C5] hover:bg-[#EFA6C5]/90 text-white"
          >
            <FolderOpen className="w-3 h-3 mr-1" />
            Ouvrir
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onDuplicate(grid)}
            className="border-[#A8C2D5] text-[#313131] hover:bg-[#A8C2D5]/10"
          >
            <Copy className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onDelete(grid)}
            className="border-red-300 text-red-600 hover:bg-red-50"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </Card>
  );
}