import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, ZoomIn, ZoomOut, Grid3x3, Eye, EyeOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function PhotoReference({ imageUrl, onToggleUnderlay, underlayActive }) {
  const [showPopup, setShowPopup] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [showGrid, setShowGrid] = useState(false);

  if (!imageUrl) return null;

  return (
    <>
      {/* Mini aperçu */}
      <Card className="p-3 bg-white border-2 border-[#A8C2D5]/30">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-semibold text-[#313131]">Photo de référence</h3>
          <Button
            size="sm"
            variant="ghost"
            onClick={onToggleUnderlay}
            className="h-6 px-2 text-xs"
          >
            {underlayActive ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
          </Button>
        </div>
        <div 
          onClick={() => setShowPopup(true)}
          className="relative aspect-square rounded-lg overflow-hidden border-2 border-[#A8C2D5]/20 cursor-pointer hover:opacity-80 transition-opacity"
        >
          <img 
            src={imageUrl} 
            alt="Référence" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/0 hover:bg-black/10 transition-colors">
            <ZoomIn className="w-6 h-6 text-white opacity-0 hover:opacity-100" />
          </div>
        </div>
        <p className="text-[10px] text-[#313131]/60 mt-2 text-center">
          Touche pour agrandir
        </p>
      </Card>

      {/* Popup agrandissement */}
      <AnimatePresence>
        {showPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
            onClick={() => setShowPopup(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-[#313131]">Photo de référence</h3>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowGrid(!showGrid)}
                    className="text-xs"
                  >
                    <Grid3x3 className="w-3 h-3 mr-1" />
                    {showGrid ? 'Masquer' : 'Quadrillage'}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setShowPopup(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-gray-50">
                <div className="flex items-center gap-3 mb-3">
                  <Button
                    size="sm"
                    onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
                    disabled={zoom <= 0.5}
                  >
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <span className="text-sm text-[#313131] font-medium min-w-[60px] text-center">
                    {Math.round(zoom * 100)}%
                  </span>
                  <Button
                    size="sm"
                    onClick={() => setZoom(Math.min(3, zoom + 0.25))}
                    disabled={zoom >= 3}
                  >
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setZoom(1)}
                    className="ml-auto"
                  >
                    Réinitialiser
                  </Button>
                </div>

                <div className="overflow-auto max-h-[calc(90vh-180px)] bg-white rounded-lg border-2 border-[#A8C2D5]/30">
                  <div 
                    className="relative inline-block min-w-full"
                    style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }}
                  >
                    <img 
                      src={imageUrl} 
                      alt="Référence agrandie"
                      className="w-full h-auto"
                    />
                    {showGrid && (
                      <div 
                        className="absolute inset-0 pointer-events-none"
                        style={{
                          backgroundImage: `
                            repeating-linear-gradient(0deg, rgba(0,0,0,0.3) 0px, rgba(0,0,0,0.3) 1px, transparent 1px, transparent 10%),
                            repeating-linear-gradient(90deg, rgba(0,0,0,0.3) 0px, rgba(0,0,0,0.3) 1px, transparent 1px, transparent 10%)
                          `,
                          backgroundSize: '10% 10%'
                        }}
                      />
                    )}
                  </div>
                </div>
                
                {showGrid && (
                  <p className="text-xs text-[#313131]/60 mt-2 text-center">
                    Ce quadrillage est là pour t'aider à compter les cases et reproduire les formes
                  </p>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}