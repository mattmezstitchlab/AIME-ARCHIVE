import React from 'react';
import { Card } from "@/components/ui/card";

const DMC_COLORS = {
  'DMC B5200': { name: 'Blanc', hex: '#FFFFFF', border: true },
  'DMC ECRU': { name: 'Écru', hex: '#F5E6C8' },
  'DMC 310': { name: 'Noir', hex: '#000000' },
  'DMC 666': { name: 'Rouge', hex: '#FF1C37' },
  'DMC 605': { name: 'Rose', hex: '#FF8FBF' },
  'DMC 820': { name: 'Bleu', hex: '#14316D' },
  'DMC 702': { name: 'Vert', hex: '#3EB54A' },
  'DMC 307': { name: 'Jaune', hex: '#FFD200' },
  'DMC 938': { name: 'Marron', hex: '#3B2312' },
  'DMC 415': { name: 'Gris', hex: '#B4B9C2' }
};

export default function ColorLegend({ cells }) {
  const usedColors = React.useMemo(() => {
    const colorSet = new Set();
    cells.forEach(row => {
      row.forEach(cell => {
        if (cell && cell !== 'DMC B5200') {
          colorSet.add(cell);
        }
      });
    });
    return Array.from(colorSet).filter(code => DMC_COLORS[code]);
  }, [cells]);

  if (usedColors.length === 0) {
    return null;
  }

  return (
    <Card className="p-4 bg-white border-2 border-[#A8C2D5]/30">
      <h3 className="text-sm font-semibold text-[#313131] mb-3">Légende des couleurs utilisées</h3>
      <div className="space-y-2">
        {usedColors.map(code => {
          const color = DMC_COLORS[code];
          return (
            <div key={code} className="flex items-center gap-3">
              <div 
                className="w-8 h-8 rounded border-2 border-gray-200 flex-shrink-0"
                style={{ backgroundColor: color.hex }}
              />
              <div className="text-sm">
                <div className="font-semibold text-[#313131]">{code}</div>
                <div className="text-[#313131]/60">{color.name}</div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

export { DMC_COLORS };