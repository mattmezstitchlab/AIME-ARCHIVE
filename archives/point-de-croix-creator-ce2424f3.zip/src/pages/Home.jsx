import React from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, FolderOpen, HelpCircle, Sparkles, ImagePlus } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] via-[#FFF7EC] to-[#EFA6C5]/10 relative overflow-hidden">
      {/* Texture subtile */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `repeating-linear-gradient(0deg, #313131, #313131 1px, transparent 1px, transparent 20px),
                           repeating-linear-gradient(90deg, #313131, #313131 1px, transparent 1px, transparent 20px)`
        }}
      />
      
      <div className="relative z-10 container mx-auto px-4 py-12 max-w-4xl">
        {/* En-tête */}
        <motion.div 
          className="text-center mb-16 mt-8"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-[#EFA6C5]" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-[#313131] mb-4">
            Ma Grille Point de Croix
          </h1>
          <p className="text-xl md:text-2xl text-[#313131]/70 font-light">
            Crée tes grilles en quelques clics
          </p>
        </motion.div>

        {/* Actions principales */}
        <div className="space-y-4 max-w-md mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Link to={createPageUrl('NewGrid')}>
              <Card className="group p-6 hover:shadow-xl transition-all duration-300 border-2 border-[#EFA6C5]/20 hover:border-[#EFA6C5] bg-white cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#EFA6C5] to-[#A8C2D5] flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Plus className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-xl font-bold text-[#313131]">Nouvelle grille</h3>
                    <p className="text-sm text-[#313131]/60">Commence une nouvelle création</p>
                  </div>
                </div>
              </Card>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Link to={createPageUrl('ImportPhoto')}>
              <Card className="group p-6 hover:shadow-xl transition-all duration-300 border-2 border-[#A8C2D5]/20 hover:border-[#A8C2D5] bg-white cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#A8C2D5] to-[#EFA6C5] flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <ImagePlus className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-xl font-bold text-[#313131]">Importer une photo</h3>
                    <p className="text-sm text-[#313131]/60">Crée une grille depuis une image</p>
                  </div>
                </div>
              </Card>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Link to={createPageUrl('MyGrids')}>
              <Card className="group p-6 hover:shadow-xl transition-all duration-300 border-2 border-[#A8C2D5]/20 hover:border-[#A8C2D5] bg-white cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#A8C2D5] to-[#EFA6C5] flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <FolderOpen className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-xl font-bold text-[#313131]">Mes grilles</h3>
                    <p className="text-sm text-[#313131]/60">Retrouve tes créations</p>
                  </div>
                </div>
              </Card>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Link to={createPageUrl('Help')}>
              <Card className="group p-6 hover:shadow-xl transition-all duration-300 border-2 border-[#A8C2D5]/20 hover:border-[#A8C2D5] bg-white cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#313131] to-[#A8C2D5] flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <HelpCircle className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-xl font-bold text-[#313131]">Aide</h3>
                    <p className="text-sm text-[#313131]/60">Apprends à utiliser l'app</p>
                  </div>
                </div>
              </Card>
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
}