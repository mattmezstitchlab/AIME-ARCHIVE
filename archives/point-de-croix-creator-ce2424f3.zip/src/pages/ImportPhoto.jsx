import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, Camera, ArrowLeft, ArrowRight } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function ImportPhoto() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleContinue = async () => {
    if (!imagePreview || !selectedImage) {
      toast.error('Veuillez sélectionner une image');
      return;
    }
    
    try {
      // Upload de l'image pour obtenir une URL permanente
      const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedImage });
      
      // Naviguer vers NewGrid avec l'URL de l'image
      navigate(createPageUrl('NewGrid'), {
        state: {
          importedImage: file_url
        }
      });
    } catch (error) {
      console.error('Erreur lors de l\'upload:', error);
      toast.error('Erreur lors de l\'upload de l\'image');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] to-[#EFA6C5]/10 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" className="mb-4 text-[#313131]">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-[#313131] mb-2">Importer une photo</h1>
          <p className="text-[#313131]/60">Choisis une image pour créer ta grille</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-8 bg-white border-2 border-[#A8C2D5]/30">
            {!imagePreview ? (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="h-32 flex-col gap-3 bg-gradient-to-br from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white"
                  >
                    <Upload className="w-8 h-8" />
                    <span>Choisir depuis la galerie</span>
                  </Button>
                  
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="h-32 flex-col gap-3 border-2 border-[#A8C2D5] hover:bg-[#A8C2D5]/10"
                  >
                    <Camera className="w-8 h-8 text-[#A8C2D5]" />
                    <span className="text-[#313131]">Prendre une photo</span>
                  </Button>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-[#313131] mb-3">Aperçu de l'image</h3>
                  <div className="relative aspect-square max-w-md mx-auto rounded-xl overflow-hidden border-4 border-[#A8C2D5]/30">
                    <img 
                      src={imagePreview} 
                      alt="Preview" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={() => {
                      setImagePreview(null);
                      setSelectedImage(null);
                    }}
                    variant="outline"
                    className="flex-1"
                  >
                    Changer l'image
                  </Button>
                  <Button
                    onClick={handleContinue}
                    className="flex-1 bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white"
                  >
                    Continuer
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </motion.div>
      </div>
    </div>
  );
}