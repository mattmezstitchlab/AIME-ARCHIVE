import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, ImageIcon } from "lucide-react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const SIZES = [10, 15, 20, 25, 30, 40];

export default function NewGrid() {
  const navigate = useNavigate();
  const location = useLocation();
  const importedImage = location.state?.importedImage;
  
  const [gridName, setGridName] = useState('');
  const [width, setWidth] = useState('20');
  const [height, setHeight] = useState('20');

  const handleCreate = () => {
    const w = parseInt(width);
    const h = parseInt(height);
    const name = gridName || `Grille ${new Date().toLocaleDateString('fr-FR')}`;
    
    // Créer une grille vide (blanc DMC)
    const emptyCells = Array(h).fill(null).map(() => Array(w).fill('DMC B5200'));
    
    // Naviguer vers l'éditeur avec les paramètres
    navigate(createPageUrl('Editor'), {
      state: {
        name,
        width: w,
        height: h,
        cells: emptyCells,
        isNew: true,
        importedImage: importedImage
      }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] to-[#EFA6C5]/10 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" className="mb-4 text-[#313131]">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-[#313131] mb-2">Nouvelle grille</h1>
          <p className="text-[#313131]/60">Configure ta grille de broderie</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {importedImage && (
            <Card className="p-4 mb-6 bg-[#A8C2D5]/10 border-2 border-[#A8C2D5]/30">
              <div className="flex items-start gap-3">
                <ImageIcon className="w-5 h-5 text-[#A8C2D5] mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-[#313131] mb-1">
                    Une image a été importée
                  </p>
                  <p className="text-xs text-[#313131]/70">
                    Choisis la taille de ta grille pour commencer à la recopier.
                  </p>
                </div>
              </div>
            </Card>
          )}
          
          <Card className="p-8 bg-white border-2 border-[#A8C2D5]/30">
            <div className="space-y-6">
              <div>
                <Label htmlFor="name" className="text-[#313131] mb-2 block">
                  Nom de la grille <span className="text-[#313131]/40">(optionnel)</span>
                </Label>
                <Input
                  id="name"
                  placeholder="Ma belle grille..."
                  value={gridName}
                  onChange={(e) => setGridName(e.target.value)}
                  className="border-2 border-[#A8C2D5]/50 focus:border-[#EFA6C5]"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-[#313131] mb-2 block">
                    Largeur (nombre de cases)
                  </Label>
                  <Select value={width} onValueChange={setWidth}>
                    <SelectTrigger className="border-2 border-[#A8C2D5]/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SIZES.map(size => (
                        <SelectItem key={size} value={size.toString()}>
                          {size} cases
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-[#313131] mb-2 block">
                    Hauteur (nombre de cases)
                  </Label>
                  <Select value={height} onValueChange={setHeight}>
                    <SelectTrigger className="border-2 border-[#A8C2D5]/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SIZES.map(size => (
                        <SelectItem key={size} value={size.toString()}>
                          {size} cases
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-4 border-t border-[#A8C2D5]/20">
                <div className="flex items-center justify-between text-sm text-[#313131]/60 mb-4">
                  <span>Taille de la grille :</span>
                  <span className="font-semibold text-[#313131]">
                    {width} × {height} = {parseInt(width) * parseInt(height)} cases
                  </span>
                </div>
              </div>

              <Button
                onClick={handleCreate}
                className="w-full h-14 text-lg bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white"
              >
                Créer la grille
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}