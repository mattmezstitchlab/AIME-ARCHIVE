import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, RefreshCw, Download, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { toast } from "sonner";
import GeneratedGridDisplay from "../components/GeneratedGridDisplay";

export default function CreateGrid() {
  const fileInputRef = useRef(null);
  const [width, setWidth] = useState(50);
  const [height, setHeight] = useState(50);
  const [gridSize, setGridSize] = useState('medium');
  const [detailLevel, setDetailLevel] = useState('standard');
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [generatedGrid, setGeneratedGrid] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
      setGeneratedGrid(null);
    }
  };

  const handleReset = () => {
    setWidth(50);
    setHeight(50);
    setGridSize('medium');
    setDetailLevel('standard');
    setSelectedImage(null);
    setImagePreview(null);
    setGeneratedGrid(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleGenerate = async () => {
    if (!selectedImage || width < 10 || height < 10) {
      toast.error('Merci de renseigner la largeur, la hauteur et de choisir une image.');
      return;
    }

    setIsGenerating(true);
    try {
      // Upload de l'image
      const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedImage });

      // Déterminer le nombre de couleurs selon le niveau de détail
      const colorCount = {
        'simplified': 8,
        'standard': 16,
        'detailed': 24
      }[detailLevel] || 16;

      // Utiliser l'IA pour extraire les couleurs et créer la grille
      const prompt = `Analyse cette image et crée une grille de point de croix de ${width}x${height} cases.
      
Pour chaque case de la grille, détermine la couleur dominante de cette zone de l'image.
Utilise ${colorCount} couleurs maximum pour représenter l'image entière.
Les couleurs doivent être des codes DMC réels de fil de broderie.

Retourne un tableau 2D de ${height} lignes et ${width} colonnes, où chaque élément est un code couleur DMC (format: "DMC XXX").

Important: 
- Simplifie les détails pour qu'ils soient reconnaissables en point de croix
- Utilise des couleurs cohérentes dans les zones similaires
- Privilégie les contrastes pour la lisibilité`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            grid: {
              type: "array",
              items: {
                type: "array",
                items: { type: "string" }
              }
            },
            colors_used: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  code: { type: "string" },
                  name: { type: "string" },
                  hex: { type: "string" }
                }
              }
            }
          }
        }
      });

      setGeneratedGrid({
        width,
        height,
        cells: result.grid,
        colors: result.colors_used,
        originalImage: imagePreview
      });

      toast.success('Grille générée avec succès !');
    } catch (error) {
      console.error('Erreur lors de la génération:', error);
      toast.error('Erreur lors de la génération de la grille');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] to-[#EFA6C5]/10 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* En-tête */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold text-[#313131] mb-3">
            Crée ta grille de point de croix
          </h1>
          <p className="text-lg text-[#313131]/70">
            Choisis ton format, importe une image, génère ta grille
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Colonne gauche - Paramètres */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Bloc 1 - Paramètres de la grille */}
            <Card className="p-6 bg-white border-2 border-[#A8C2D5]/30">
              <h3 className="text-xl font-bold text-[#313131] mb-4">Paramètres de la grille</h3>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="width" className="text-[#313131] mb-2 block">
                    Largeur (en cases)
                  </Label>
                  <Input
                    id="width"
                    type="number"
                    min={10}
                    max={300}
                    value={width}
                    onChange={(e) => setWidth(Math.max(10, Math.min(300, parseInt(e.target.value) || 10)))}
                    className="border-2 border-[#A8C2D5]/50 focus:border-[#EFA6C5]"
                  />
                </div>

                <div>
                  <Label htmlFor="height" className="text-[#313131] mb-2 block">
                    Hauteur (en cases)
                  </Label>
                  <Input
                    id="height"
                    type="number"
                    min={10}
                    max={300}
                    value={height}
                    onChange={(e) => setHeight(Math.max(10, Math.min(300, parseInt(e.target.value) || 10)))}
                    className="border-2 border-[#A8C2D5]/50 focus:border-[#EFA6C5]"
                  />
                </div>

                <div>
                  <Label className="text-[#313131] mb-2 block">
                    Taille de la grille
                  </Label>
                  <Select value={gridSize} onValueChange={setGridSize}>
                    <SelectTrigger className="border-2 border-[#A8C2D5]/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Petit format</SelectItem>
                      <SelectItem value="medium">Moyen format</SelectItem>
                      <SelectItem value="large">Grand format</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-[#313131] mb-2 block">
                    Niveau de détail
                  </Label>
                  <Select value={detailLevel} onValueChange={setDetailLevel}>
                    <SelectTrigger className="border-2 border-[#A8C2D5]/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="simplified">Simplifié (moins de couleurs)</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="detailed">Détails élevés</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>

            {/* Bloc 2 - Import d'image */}
            <Card className="p-6 bg-white border-2 border-[#A8C2D5]/30">
              <h3 className="text-xl font-bold text-[#313131] mb-4">Import d'image</h3>
              
              <div className="space-y-4">
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-24 bg-gradient-to-br from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white"
                >
                  <Upload className="w-6 h-6 mr-2" />
                  Importer une photo
                </Button>
                
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/jpg,image/png"
                  onChange={handleFileSelect}
                  className="hidden"
                />

                {imagePreview && (
                  <div className="relative aspect-square rounded-lg overflow-hidden border-2 border-[#A8C2D5]/30">
                    <img 
                      src={imagePreview} 
                      alt="Preview" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                <p className="text-xs text-[#313131]/60 text-center">
                  Choisis une image simple et bien contrastée pour un meilleur résultat en point de croix.
                </p>
              </div>
            </Card>

            {/* Bloc 3 & 5 - Boutons d'action */}
            <div className="flex gap-3">
              <Button
                onClick={handleReset}
                variant="outline"
                className="flex-1 border-2 border-[#A8C2D5]"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Réinitialiser
              </Button>
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !selectedImage}
                className="flex-1 h-14 text-lg bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Génération...
                  </>
                ) : (
                  'Générer ma grille'
                )}
              </Button>
            </div>
          </motion.div>

          {/* Colonne droite - Aperçu */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Card className="p-6 bg-white border-2 border-[#A8C2D5]/30 h-full">
              <h3 className="text-xl font-bold text-[#313131] mb-4">Aperçu de ta grille</h3>
              
              {generatedGrid ? (
                <GeneratedGridDisplay grid={generatedGrid} />
              ) : (
                <div className="flex items-center justify-center h-[calc(100%-3rem)] min-h-[300px] text-center">
                  <p className="text-[#313131]/60">
                    Génère ta première grille pour la voir ici.
                  </p>
                </div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}