import React, { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Save, Trash2, Download, Eye, EyeOff } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import GridCanvas from "../components/GridCanvas";
import ColorPalette, { DMC_COLORS as DMC_COLORS_ARRAY } from "../components/ColorPalette";
import ColorLegend, { DMC_COLORS } from "../components/ColorLegend";
import PhotoReference from "../components/PhotoReference";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function Editor() {
  const location = useLocation();
  const navigate = useNavigate();
  const gridData = location.state;

  const gridCanvasRef = useRef(null);
  const [gridName, setGridName] = useState(gridData?.name || '');
  const [width] = useState(gridData?.width || 20);
  const [height] = useState(gridData?.height || 20);
  const [cells, setCells] = useState(gridData?.cells || []);
  const [selectedColor, setSelectedColor] = useState('DMC 310');
  const [gridId, setGridId] = useState(gridData?.id || null);
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [imageReference] = useState(gridData?.importedImage || gridData?.image_reference || null);
  const [photoUnderlay, setPhotoUnderlay] = useState(false);

  const selectedColorInfo = DMC_COLORS[selectedColor] || { code: selectedColor, name: '', hex: selectedColor };

  useEffect(() => {
    if (!gridData) {
      navigate(createPageUrl('Home'));
    }
  }, [gridData, navigate]);

  const handleCellChange = (row, col, color) => {
    const newCells = cells.map((r, i) =>
      i === row ? r.map((c, j) => (j === col ? color : c)) : r
    );
    setCells(newCells);
  };

  const handleClearAll = () => {
    if (confirm('Êtes-vous sûr de vouloir effacer toute la grille ?')) {
      const emptyCells = Array(height).fill(null).map(() => Array(width).fill('DMC B5200'));
      setCells(emptyCells);
      toast.success('Grille effacée');
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const gridElement = document.querySelector('[data-grid-canvas]');
      if (!gridElement) {
        toast.error('Impossible de capturer la grille');
        return;
      }

      // Utiliser html2canvas pour capturer la grille
      const html2canvas = (await import('https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/+esm')).default;
      const canvas = await html2canvas(gridElement, {
        backgroundColor: '#FFFFFF',
        scale: 2
      });

      // Convertir en blob
      canvas.toBlob(async (blob) => {
        // Créer un lien de téléchargement
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = `${gridName.replace(/[^a-z0-9]/gi, '_')}.png`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
        
        toast.success('Grille exportée avec succès');
      }, 'image/png');
    } catch (error) {
      console.error('Erreur lors de l\'export:', error);
      toast.error('Erreur lors de l\'export');
    } finally {
      setIsExporting(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const gridData = {
        name: gridName,
        width,
        height,
        cells,
        image_reference: imageReference
      };
      
      if (gridId) {
        // Mise à jour
        await base44.entities.Grid.update(gridId, gridData);
        toast.success('Grille sauvegardée');
      } else {
        // Création
        const newGrid = await base44.entities.Grid.create(gridData);
        setGridId(newGrid.id);
        toast.success('Grille créée');
      }
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setIsSaving(false);
    }
  };

  if (!gridData) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] to-[#EFA6C5]/10 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="mb-6">
          <Link to={createPageUrl('MyGrids')}>
            <Button variant="ghost" className="mb-4 text-[#313131]">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Mes grilles
            </Button>
          </Link>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-[#313131]">{gridName}</h1>
              <p className="text-[#313131]/60 mt-1">
                {width} × {height} cases
              </p>
            </div>
            
            <div className="flex gap-2">
              <Button
                onClick={handleClearAll}
                variant="outline"
                className="border-red-300 text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Effacer tout
              </Button>
              <Button
                onClick={handleExport}
                disabled={isExporting}
                variant="outline"
                className="border-[#A8C2D5] text-[#313131] hover:bg-[#A8C2D5]/10"
              >
                <Download className="w-4 h-4 mr-2" />
                {isExporting ? 'Export...' : 'Exporter'}
              </Button>
              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
              </Button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            {imageReference && (
              <div className="mb-4 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setPhotoUnderlay(!photoUnderlay)}
                  className="flex-1"
                >
                  {photoUnderlay ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                  {photoUnderlay ? 'Masquer la photo' : 'Afficher la photo sous la grille'}
                </Button>
              </div>
            )}
            
            <div 
              data-grid-canvas
              className="relative"
            >
              {photoUnderlay && imageReference && (
                <div className="absolute inset-0 rounded-lg overflow-hidden pointer-events-none">
                  <img 
                    src={imageReference} 
                    alt="Référence" 
                    className="w-full h-full object-cover opacity-30"
                  />
                </div>
              )}
              <div className="relative">
                <GridCanvas
                  width={width}
                  height={height}
                  cells={cells}
                  onCellChange={handleCellChange}
                  selectedColor={selectedColor}
                />
              </div>
            </div>
            
            <div className="mt-4 p-4 bg-white/80 rounded-lg border-2 border-[#A8C2D5]/20">
              <div className="text-sm text-[#313131]/70">
                <p className="mb-2">
                  <strong>💡 Astuce :</strong> 
                </p>
                <ul className="space-y-1 ml-4">
                  <li>• Clic gauche : colorier une case</li>
                  <li>• Clic droit : effacer une case</li>
                  <li>• Maintenir le clic : dessiner en continu</li>
                </ul>
              </div>
            </div>
          </motion.div>

          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            {imageReference && (
              <PhotoReference 
                imageUrl={imageReference}
                onToggleUnderlay={() => setPhotoUnderlay(!photoUnderlay)}
                underlayActive={photoUnderlay}
              />
            )}
            
            <ColorPalette
              selectedColor={selectedColor}
              onColorSelect={setSelectedColor}
              selectedColorInfo={selectedColorInfo}
            />
            
            <ColorLegend cells={cells} />
          </motion.div>
        </div>
      </div>
    </div>
  );
}