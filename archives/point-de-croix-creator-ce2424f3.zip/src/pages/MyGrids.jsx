import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Search, Grid3x3, Plus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import GridCard from "../components/GridCard";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function MyGrids() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  const { data: grids = [], isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-created_date'),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['grids']);
      toast.success('Grille supprimée');
    },
  });

  const duplicateMutation = useMutation({
    mutationFn: async (grid) => {
      const { id, created_date, updated_date, created_by, ...gridData } = grid;
      return base44.entities.Grid.create({
        ...gridData,
        name: `Copie de ${grid.name}`,
      });
    },
    onSuccess: (newGrid) => {
      queryClient.invalidateQueries(['grids']);
      toast.success('Grille dupliquée');
      handleOpen(newGrid);
    },
  });

  const filteredGrids = grids.filter(grid =>
    grid.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpen = (grid) => {
    navigate(createPageUrl('Editor'), {
      state: {
        id: grid.id,
        name: grid.name,
        width: grid.width,
        height: grid.height,
        cells: grid.cells,
        image_reference: grid.image_reference,
        isNew: false
      }
    });
  };

  const handleDelete = (grid) => {
    if (confirm(`Êtes-vous sûr de vouloir supprimer "${grid.name}" ?`)) {
      deleteMutation.mutate(grid.id);
    }
  };

  const handleDuplicate = (grid) => {
    duplicateMutation.mutate(grid);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] to-[#EFA6C5]/10 py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" className="mb-4 text-[#313131]">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-4xl font-bold text-[#313131] mb-2">Mes grilles</h1>
              <p className="text-[#313131]/60">
                {grids.length} {grids.length > 1 ? 'grilles enregistrées' : 'grille enregistrée'}
              </p>
            </div>
            
            <Link to={createPageUrl('NewGrid')}>
              <Button className="bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Nouvelle grille
              </Button>
            </Link>
          </div>

          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#313131]/40" />
            <Input
              placeholder="Rechercher une grille..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-2 border-[#A8C2D5]/30 focus:border-[#EFA6C5]"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="aspect-square bg-white/50 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filteredGrids.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-[#A8C2D5]/10 flex items-center justify-center">
              <Grid3x3 className="w-12 h-12 text-[#A8C2D5]" />
            </div>
            <h3 className="text-2xl font-bold text-[#313131] mb-3">
              {searchQuery ? 'Aucune grille trouvée' : 'Aucune grille pour le moment'}
            </h3>
            <p className="text-[#313131]/60 mb-6">
              {searchQuery 
                ? 'Essaye avec un autre terme de recherche'
                : 'Commence par créer ta première grille'}
            </p>
            {!searchQuery && (
              <Link to={createPageUrl('NewGrid')}>
                <Button className="bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Créer ma première grille
                </Button>
              </Link>
            )}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredGrids.map((grid, index) => (
              <motion.div
                key={grid.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <GridCard
                  grid={grid}
                  onOpen={handleOpen}
                  onDelete={handleDelete}
                  onDuplicate={handleDuplicate}
                />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}