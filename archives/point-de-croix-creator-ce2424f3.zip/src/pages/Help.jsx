import React from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const steps = [
  {
    number: "1",
    title: "Crée une nouvelle grille",
    description: "Depuis l'écran d'accueil, clique sur « Nouvelle grille » pour commencer."
  },
  {
    number: "2",
    title: "Choisis la taille",
    description: "Sélectionne le nombre de cases en largeur et en hauteur (de 10×10 à 40×40)."
  },
  {
    number: "3",
    title: "Sélectionne une couleur",
    description: "Dans l'éditeur, choisis une couleur dans la palette en bas de l'écran."
  },
  {
    number: "4",
    title: "Colorie les cases",
    description: "Clique sur les cases pour les colorier. Maintiens le clic pour dessiner en continu."
  },
  {
    number: "5",
    title: "Efface si besoin",
    description: "Clique droit sur une case pour l'effacer, ou utilise le bouton « Effacer tout »."
  },
  {
    number: "6",
    title: "Sauvegarde ton travail",
    description: "Clique sur « Sauvegarder » pour enregistrer ta grille. Tu pourras la retrouver dans « Mes grilles »."
  }
];

const photoSteps = [
  {
    number: "1",
    title: "Importe une photo",
    description: "Depuis l'accueil, choisis « Importer une photo » et sélectionne ton image."
  },
  {
    number: "2",
    title: "Configure ta grille",
    description: "Choisis la taille de grille adaptée à ton modèle."
  },
  {
    number: "3",
    title: "Utilise la photo de référence",
    description: "Dans l'éditeur, regarde la mini-photo à droite. Touche-la pour l'agrandir avec zoom."
  },
  {
    number: "4",
    title: "Active la superposition",
    description: "Utilise le bouton « Afficher la photo sous la grille » pour voir l'image en transparence derrière ta grille."
  },
  {
    number: "5",
    title: "Affiche le quadrillage",
    description: "Dans la popup d'agrandissement, active le quadrillage pour mieux te repérer et compter les cases."
  },
  {
    number: "6",
    title: "Recopie ton modèle",
    description: "Colorie les cases en suivant ton image de référence. La photo reste accessible même après sauvegarde."
  }
];

export default function Help() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7EC] to-[#EFA6C5]/10 py-8">
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" className="mb-4 text-[#313131]">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-[#313131] mb-2">Aide</h1>
          <p className="text-[#313131]/60">Comment utiliser l'application</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4 mb-8"
        >
          <h2 className="text-2xl font-bold text-[#313131] mb-4">Créer une grille manuelle</h2>
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 bg-white border-2 border-[#A8C2D5]/20 hover:border-[#EFA6C5] transition-all duration-300">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#EFA6C5] to-[#A8C2D5] flex items-center justify-center">
                      <span className="text-xl font-bold text-white">{step.number}</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-[#313131] mb-2">{step.title}</h3>
                    <p className="text-[#313131]/70 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="space-y-4 mb-8"
        >
          <h2 className="text-2xl font-bold text-[#313131] mb-4">Utiliser une photo comme modèle</h2>
          {photoSteps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.8 + index * 0.1 }}
            >
              <Card className="p-6 bg-white border-2 border-[#A8C2D5]/20 hover:border-[#EFA6C5] transition-all duration-300">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#A8C2D5] to-[#313131] flex items-center justify-center">
                      <span className="text-xl font-bold text-white">{step.number}</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-[#313131] mb-2">{step.title}</h3>
                    <p className="text-[#313131]/70 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="p-8 text-center bg-gradient-to-r from-[#EFA6C5]/10 to-[#A8C2D5]/10 border-2 border-[#EFA6C5]/30">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-[#EFA6C5]" />
            <h3 className="text-2xl font-bold text-[#313131] mb-4">C'est parti !</h3>
            <p className="text-[#313131]/70 mb-6">
              Tu es maintenant prêt à créer tes plus belles grilles de point de croix.
            </p>
            <Link to={createPageUrl('NewGrid')}>
              <Button className="bg-gradient-to-r from-[#EFA6C5] to-[#A8C2D5] hover:opacity-90 text-white">
                Créer ma première grille
              </Button>
            </Link>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}