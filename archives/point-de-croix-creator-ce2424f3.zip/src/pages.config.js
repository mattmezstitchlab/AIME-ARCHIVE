import Home from './pages/Home';
import NewGrid from './pages/NewGrid';
import Editor from './pages/Editor';
import MyGrids from './pages/MyGrids';
import Help from './pages/Help';
import ImportPhoto from './pages/ImportPhoto';
import CreateGrid from './pages/CreateGrid';


export const PAGES = {
    "Home": Home,
    "NewGrid": NewGrid,
    "Editor": Editor,
    "MyGrids": MyGrids,
    "Help": Help,
    "ImportPhoto": ImportPhoto,
    "CreateGrid": CreateGrid,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
};