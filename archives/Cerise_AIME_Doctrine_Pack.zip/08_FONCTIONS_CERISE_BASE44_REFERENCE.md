# Référence fonctions Cerise / Base44

Ce fichier garde la logique des anciennes fonctions Base44/OpenAI, mais sous forme nettoyée.

## 1. Fonction actuelle observée

Les fonctions Base44 appellent OpenAI avec :

- un system prompt ;
- un contexte utilisateur ;
- un historique récent ;
- un message utilisateur ;
- une réponse courte.

## 2. Variables de contexte utiles

```ts
context = {
  role?: "organiser" | "participer" | "intervenir" | "marie" | "invite" | "prestataire" | "admin",
  prenom?: string,
  nom_mariage?: string,
  page?: string,
  code?: string,
  mariage_id?: string
}
```

## 3. Recommandation de normalisation des rôles

Remplacer progressivement :

- `marie` par `organiser`
- `invite` par `participer`
- `prestataire` par `intervenir`

Conserver les anciens mots comme synonymes acceptés.

## 4. Prompt système court recommandé pour backend

```text
Tu es Cerise, l’agent IA central d’AIME.
Tu reconnais trois rôles universels : Organiser, Participer, Intervenir.
Dans le mariage : Organiser = futurs mariés, Participer = invités, Intervenir = prestataires.
Réponds en français, clairement, avec une prochaine action utile.
Ne fais aucune action sensible sans validation humaine.
```

## 5. Modèle de réponse JSON futur

```json
{
  "role_detected": "organiser",
  "summary": "Votre espace d’organisation est prêt.",
  "next_action": "Continuer le dossier.",
  "buttons": [
    { "label": "Ouvrir mon espace", "path": "/app" },
    { "label": "J’ai un code", "path": null }
  ],
  "requires_confirmation": false
}
```

## 6. Actions futures possibles

- `get_event_context`
- `create_task`
- `prepare_message`
- `update_timeline_item`
- `add_guest`
- `update_rsvp`
- `add_vendor`
- `update_budget_item`
- `create_document`
- `open_space`

## 7. Règle technique

Ne jamais exposer la clé OpenAI côté frontend. Les appels OpenAI doivent passer par une fonction backend ou une intégration sécurisée.
