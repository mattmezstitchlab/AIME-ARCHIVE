# Pack Doctrine Cerise / AIME

Ce pack sert à stabiliser Cerise comme agent IA central d’AIME, en séparant proprement :

1. **Instructions courtes** à coller dans OpenAI Agent Builder.
2. **Doctrine produit** à mettre dans File Search / fichiers de connaissance.
3. **Âme / ton** à garder comme couche comportementale.
4. **Mémoire projet** pour conserver les décisions validées.
5. **Archive confidentielle** à ne pas exposer publiquement.

## Ordre recommandé d’import

### Dans OpenAI Agent Builder
1. Coller `04_INSTRUCTIONS_OPENAI_AGENT_CERISE.md` dans **Instructions**.
2. Ajouter en **File Search** :
   - `01_DOCTRINE_CERISE_AIME.md`
   - `02_SOUL_CERISE_AIME.md`
   - `03_MEMOIRE_PROJET_AIME.md`
3. Garder `07_MEMOIRE_PERSONNELLE_CONFIDENTIELLE.md` seulement si tu veux que Cerise conserve aussi la mémoire intime du fondateur. Ce fichier est privé.

### Dans Base44
1. Renommer l’agent officiel en **Cerise**.
2. Garder Pixelle comme héritage / ancienne âme, pas comme nom public principal.
3. Ajouter les fichiers dans la zone **Fichiers de connaissances**.
4. Utiliser `05_INSTRUCTIONS_BASE44_CERISE.md` comme base pour le champ instructions / cerveau.

## Règle importante

Ne mets pas tout le prompt V2 complet dans le champ Instructions de l’agent.  
Le champ Instructions doit rester court, clair et opératoire.  
Les gros documents vont dans File Search / fichiers de connaissance.
