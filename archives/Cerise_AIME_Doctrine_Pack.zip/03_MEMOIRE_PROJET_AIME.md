# Mémoire Projet AIME

## 1. État actuel du produit

AIME est recentré sur une entrée simple et universelle basée sur trois rôles :

- Organiser ;
- Participer ;
- Intervenir.

La première page utilise trois tickets superposés :

- 03 Intervenir — bleu ciel ;
- 02 Participer — orange ;
- 01 Organiser — fuchsia.

Le visuel “Cerise machine en forme de cerise” est mis de côté pour le moment. Cerise reste l’agent IA, mais pas le visuel principal de la landing.

## 2. Pages principales à conserver

Les pages existantes restent utiles :

- `/app` : espace Organiser / couple / futurs mariés ;
- `/invite` : espace Participer / invités ;
- `/pro` : espace Intervenir / prestataires.

Elles servent d’espaces détaillés ouverts depuis la landing ou depuis Cerise.

## 3. Landing universelle

La landing actuelle doit rester très simple :

- fond blanc / ivoire ;
- AIME centré ;
- titre fort ;
- tickets superposés ;
- bouton code d’accès ;
- footer discret.

Elle n’est plus uniquement mariage. Elle doit pouvoir ouvrir d’autres univers plus tard.

## 4. Logique mariage

Dans l’univers mariage :

- Organiser = futurs mariés ;
- Participer = invités ;
- Intervenir = prestataires.

Mais cette traduction se fait après la reconnaissance du rôle. Le premier écran reste universel.

## 5. Pages mariage déjà pensées / générées

### Côté Organiser / couple

- Espace futurs mariés
- Dossier mariage
- Planning / programme
- Budget
- Prestataires
- Documents
- Invités & RSVP
- Plan de table
- Cagnotte côté mariés
- Messagerie & contacts
- Paramètres & codes d’accès
- Mini-site invité

### Côté Participer / invité

- Espace invité
- Programme invité
- RSVP invité
- Cagnotte invité
- Infos pratiques
- Nous contacter invité
- Écrans de confirmation à prévoir

### Côté Intervenir / prestataire

- Espace prestataire
- Brief & informations
- Planning prestataire
- Documents prestataire
- Contacts prestataire
- Tâches & suivi
- Suivi financier
- Galerie inspiration / moodboard

## 6. Gabarit visuel validé pour les pages détaillées

Chaque espace détaillé garde sa couleur :

- fuchsia = Organiser / couple ;
- orange = Participer / invité ;
- bleu ciel = Intervenir / prestataire.

Structure :

- fond blanc / ivoire ;
- AIME centré ;
- nom du couple ou contexte ;
- date ;
- lieu ;
- titre de page ;
- grand bloc couleur ;
- cartes blanches simples ;
- footer discret.

## 7. Cerise dans Base44 et OpenAI

Base44 contient déjà une mémoire riche de l’ancien agent Pixelle.

OpenAI doit devenir le cerveau propre et officiel de Cerise.

Recommandation :

- Instructions = comportement stable ;
- File Search / Fichiers = doctrine longue ;
- Base44 = interface + données + actions ;
- OpenAI = raisonnement + orchestration.

## 8. Principe de réponse exploitable par l’interface

Cerise doit pouvoir répondre dans un format simple que Base44 affichera dans un rond, un ticket, une carte ou un panneau.

Format recommandé :

```text
role: organiser | participer | intervenir | unknown
summary: phrase courte
next_action: action prioritaire
buttons: [1 à 3 labels]
open_path: /app | /invite | /pro | null
```

## 9. Ne pas perdre

À ne pas perdre dans la suite :

- la simplicité radicale ;
- la logique universelle ;
- la puissance symbolique ;
- le mariage comme démonstrateur ;
- les pages détaillées comme pièces de la maison ;
- Cerise comme porte intelligente ;
- la phrase “Trois rôles. Un seul espace.”
