# Archive AIME Living Editorial V2 — Synthèse structurée

Ce fichier conserve les principes du grand prompt AIME Living Editorial V2 sans surcharger les instructions principales de Cerise.

## 1. Vision

AIME est un cockpit pédagogique où AI + ME travaillent ensemble.

AIME n’est pas un builder. AIME est une Trame.

Promesses publiques :

- Comprendre avant de modifier.
- Choisir sans se perdre.
- Publier sans peur.

Formules :

- “Le plus compliqué, c’est de faire simple.”
- “La documentation précède le code.”

## 2. Manifeste officiel

Les sept phrases officielles doivent rester intactes dans `/manifeste`.

1. « Si la musique est les mots de l'âme, AIME est la partition qui permet au numérique de redevenir humain. »
2. « AIME est né d'une idée simple : le numérique ne devrait pas être réservé à ceux qui savent le casser. »
3. « Le plus compliqué, c'est de faire simple. »
4. « Alors AIME transforme la complexité en Trame. »
5. « Chaque page devient lisible. Chaque élément devient un point. Chaque modification trouve sa juste distance. »
6. « La Clé de Lecture révèle ce que l'on voit. LYRA explique ce que l'on touche. Le cockpit protège ce qu'il ne faut pas casser. »
7. « AIME ne vous laisse pas seulement construire un site. AIME vous aide à le comprendre. »

## 3. Quatre niveaux de protection

Valeurs techniques :

- free
- guided
- protected
- readonly

Libellés publics :

- Libre
- Guidé
- Protégé
- Lecture seule

## 4. Studio de la Trame

Le Studio de la Trame est la couche créative du cockpit AIME.

Il permet de piloter assets, palettes, logos, formats, visuels et publications sans devenir Webflow, Photoshop ou Figma.

Règle : AIME ne donne pas un canvas libre à casser. AIME propose des choix calibrés dans une Trame pensée.

## 5. Clé de Lecture

La Clé de Lecture relie l’élément visible à :

- son asset ;
- sa palette ;
- son logo ;
- son format ;
- sa protection ;
- sa documentation.

Elle route, elle n’édite pas.

## 6. Design Direction

AIME Living Editorial doit être :

- silencieux comme Apple ;
- systémique comme Figma ;
- précis comme Affinity ;
- éditorial comme un grand magazine ;
- pédagogique comme un bon livre ;
- vivant comme un instrument.

## 7. Routes doctrinales historiques

Routes publiques V2 historiques :

- `/`
- `/manifeste`
- `/passage`
- `/registre`
- `/mariage`
- `/modules`
- `/prestataires`

Route admin :

- `/admin`

Note : l’architecture actuelle peut être simplifiée pour le MVP autour de `/`, `/app`, `/invite`, `/pro`.

## 8. Partition Vivante

La Partition Vivante est une interface temporelle inspirée de la musique, avec trois portées :

- Signal ;
- Structure ;
- Matière.

Elle peut devenir une couche future d’orchestration temporelle.

## 9. Règle de tri

Tout ce qui est trop complexe pour la landing actuelle doit aller dans une archive ou un module futur.

La landing actuelle doit rester :

- simple ;
- universelle ;
- ticket-based ;
- sans surcharge.
