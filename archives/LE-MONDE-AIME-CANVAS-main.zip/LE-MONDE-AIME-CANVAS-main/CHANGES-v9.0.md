# LE MONDE AIME v9.0 — Publication & Jour J

- Publication réelle d’un mini-site de mariage dans Supabase lorsque le cloud est connecté.
- Aperçu public local conservé sans configuration externe.
- URL publique, vue Jour J Live et QR Code PNG.
- RSVP public relié au projet avec repli local.
- Page publique responsive construite depuis les mêmes données que la Timeline et le Canvas.
- Vue mobile Jour J avec moment en cours, suite du programme et messages live.
- Application installable et shell hors connexion grâce au manifest et au service worker.
- Schéma RLS pour publications, RSVP et mises à jour live.
