# LE MONDE AIME v8.9 — Comptes & collaboration

- Authentification optionnelle par lien e-mail avec Supabase.
- Mode local conservé lorsque le cloud n’est pas configuré.
- Synchronisation manuelle du projet et restauration d’une version cloud.
- Invitations par e-mail avec rôles Éditeur, Commentateur et Lecteur.
- Schéma Supabase avec RLS pour projets, membres et snapshots.
- Contrôle Compte & collaboration dans le header et l’accueil.
- Nom interne nettoyé : `le-monde-aime-studio`.
