# Changements — v8 Canvas universel & Projets

## Gestionnaire avant le canvas

- Nouvel écran d’accueil inspiré d’un gestionnaire de projets professionnel.
- Cartes de projets avec univers, statut, date, favori et aperçu du visuel principal lorsqu’il existe.
- Recherche, tri, projets récents, favoris, archives et corbeille.
- Création de dossiers et déplacement réel d’un projet dans un dossier.
- Renommage, duplication, export, archivage et suppression.
- Création de sept types d’univers sans dupliquer le builder.

## Un seul canvas universel

- Le mariage conserve les cartes Couple et Prestataire.
- Les autres univers démarrent avec une carte de rôle adaptée.
- Ajout manuel de cartes Couple, Prestataire, Association, Artiste, Lieu et Entreprise.
- Pages, calques et ressources partagent la même navigation latérale.
- Timeline et Mini-site restent des plans autonomes du même espace de travail.

## Toolbar et inspecteurs

- Nouvelle toolbar compacte en bas du canvas.
- Sélection, main, post-it, ajout, médias, style, organisation et publication.
- Menu zoom : valeurs directes, ajustement au canvas, ajustement à la sélection et aperçu sans interface.
- Les panneaux de propriétés s’ouvrent à droite selon l’objet sélectionné.
- Le mini-site possède désormais une palette d’édition verticale à droite ; les textes sont modifiables directement dans la page.

## Agent et tâches exécutables

- L’agent s’adapte à l’univers actif au lieu d’être exclusivement mariage.
- Nouvel onglet **À terminer** avec alertes critiques et avertissements.
- Les actions ouvrent réellement le bon inspecteur ou génèrent la carte de rôle / la connexion initiale du mini-site.
- Le mariage conserve sa connaissance métier spécialisée.

## Sauvegarde

- Données séparées par projet avec clés de stockage isolées.
- Autosauvegarde locale après chaque modification.
- Copie de sécurité du projet dans IndexedDB.
- Bouton et raccourci d’enregistrement manuel avec statut visible.
- Import/export portable `.aime.json`, dans le gestionnaire et dans le panneau Publier.
- Images locales redimensionnées et intégrées au projet pour rester disponibles après redémarrage.

## Contrôles techniques

- Tous les fichiers TypeScript/TSX ont été analysés sans erreur de syntaxe.
- Le graphe des imports relatifs a été contrôlé sans fichier manquant.
- Le magasin multi-projets a passé un test fonctionnel de création, lecture, export et réimport.
- Le build Vite complet n’a pas été exécuté dans l’environnement de génération : le registre npm n’a pas terminé l’installation des dépendances dans le délai disponible.
