import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CalendarDays,
  Check,
  ChevronDown,
  Clock3,
  MapPin,
  Radio,
  RefreshCw,
  Send,
  Users,
  Wifi,
} from 'lucide-react';
import {
  getLiveUpdates,
  getPublishedWedding,
  hasExistingRsvp,
  resolveCurrentMomentIndex,
  submitRsvp,
  subscribeToLiveUpdates,
  subscribeToPublishedWedding,
  type LiveUpdate,
  type PublishedWedding,
  type RsvpSubmission,
} from './publicationService';

interface PublicWeddingSiteProps {
  slug: string;
  mode: 'site' | 'live';
}

export const PublicWeddingSite: React.FC<PublicWeddingSiteProps> = ({ slug, mode }) => {
  const [publication, setPublication] = useState<PublishedWedding | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [updates, setUpdates] = useState<LiveUpdate[]>([]);
  const [liveConnected, setLiveConnected] = useState(false);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const previousTitle = document.title;
    const robots = document.querySelector('meta[name="robots"]');
    const previousRobots = robots?.getAttribute('content') || '';
    document.title = publication?.title ? `${publication.title} — Le Monde Aime` : 'Mariage — Le Monde Aime';
    robots?.setAttribute('content', 'index, follow');
    return () => {
      document.title = previousTitle;
      robots?.setAttribute('content', previousRobots || 'noindex, nofollow');
    };
  }, [publication?.title]);

  useEffect(() => {
    let active = true;
    const loadPublication = async () => {
      try {
        const data = await getPublishedWedding(slug);
        if (!active) return;
        setPublication(data);
        setError(data ? '' : 'Ce mariage n’est pas encore publié ou le lien n’est plus disponible.');
      } catch {
        if (active) setError('Le site ne peut pas être chargé pour le moment.');
      } finally {
        if (active) setLoading(false);
      }
    };
    const loadUpdates = async () => {
      if (mode !== 'live') return;
      const data = await getLiveUpdates(slug);
      if (active) setUpdates(data);
    };

    void loadPublication();
    void loadUpdates();
    const stopPublication = subscribeToPublishedWedding(slug, (next) => {
      if (!active) return;
      setPublication(next);
      setError(next ? '' : 'Cette publication vient d’être retirée.');
      setLiveConnected(true);
    });
    const stopLive = mode === 'live'
      ? subscribeToLiveUpdates(slug, () => {
          setLiveConnected(true);
          void loadUpdates();
        })
      : () => undefined;
    const clock = window.setInterval(() => setNow(new Date()), 30_000);
    return () => {
      active = false;
      stopPublication();
      stopLive();
      window.clearInterval(clock);
    };
  }, [mode, slug]);

  if (loading) return <PublicState title="Ouverture du mariage…" />;
  if (error || !publication) return <PublicState title={error || 'Publication introuvable'} />;
  if (mode === 'live') return <LiveDay publication={publication} updates={updates} now={now} connected={liveConnected} />;
  return <WeddingInvitation publication={publication} />;
};

const WeddingInvitation: React.FC<{ publication: PublishedWedding }> = ({ publication }) => {
  const [form, setForm] = useState<RsvpSubmission>({ name: '', email: '', attendance: 'yes', guestCount: 1, dietaryRequirements: '', message: '' });
  const [website, setWebsite] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [existingResponse, setExistingResponse] = useState(() => hasExistingRsvp(publication.slug));
  const startedAt = useRef(Date.now());

  const send = async () => {
    if (website) {
      setSent(true);
      return;
    }
    if (Date.now() - startedAt.current < 1200) {
      setMessage('Prenez un instant pour vérifier votre réponse.');
      return;
    }
    setBusy(true);
    setMessage('');
    try {
      const result = await submitRsvp(publication.slug, form);
      setSent(true);
      setExistingResponse(true);
      setMessage(result.mode === 'cloud'
        ? result.updated ? 'Votre réponse a été mise à jour et transmise aux mariés.' : 'Votre réponse a bien été transmise aux mariés.'
        : 'Votre réponse a été enregistrée dans cet aperçu local.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'La réponse n’a pas pu être enregistrée.');
    } finally {
      setBusy(false);
    }
  };

  const editAgain = () => {
    setSent(false);
    startedAt.current = Date.now() - 2000;
    setMessage('');
  };

  return <div style={{ minHeight: '100vh', background: '#F3EEE7', color: '#241F1C', fontFamily: 'Inter, system-ui, sans-serif' }}>
    <header style={{ position: 'relative', minHeight: 'min(88vh,820px)', display: 'grid', placeItems: 'center', overflow: 'hidden', background: '#171514' }}>
      {publication.heroPhoto ? publication.heroMediaType === 'video'
        ? <video src={publication.heroPhoto} autoPlay muted loop playsInline style={mediaStyle} />
        : <img src={publication.heroPhoto} alt="" style={mediaStyle} /> : null}
      <div style={{ position: 'absolute', inset: 0, background: publication.heroPhoto ? 'linear-gradient(180deg,rgba(10,8,7,.26),rgba(10,8,7,.78))' : 'radial-gradient(circle at 50% 30%,#6A5E55,#171514 72%)' }} />
      <div style={{ position: 'relative', zIndex: 1, width: 'min(920px,calc(100% - 40px))', textAlign: 'center', color: '#FFF', padding: '88px 0 64px' }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '8px 12px', borderRadius: 99, border: '1px solid rgba(255,255,255,.24)', background: 'rgba(20,18,17,.24)', backdropFilter: 'blur(16px)', fontSize: 10, letterSpacing: '.12em', textTransform: 'uppercase' }}><CalendarDays size={13} /> {formatPublicDate(publication.date)}</span>
        <h1 style={{ margin: '34px auto 20px', maxWidth: 900, fontFamily: 'Georgia, Times, serif', fontSize: 'clamp(50px,10vw,118px)', fontWeight: 400, lineHeight: .9, letterSpacing: '-.065em' }}>{publication.title}</h1>
        <p style={{ margin: '0 auto', maxWidth: 560, color: 'rgba(255,255,255,.72)', fontSize: 'clamp(14px,2vw,18px)', lineHeight: 1.6 }}>Nous serions heureux de partager cette journée avec vous.</p>
        <div style={{ marginTop: 30, display: 'flex', justifyContent: 'center', gap: 18, flexWrap: 'wrap', color: 'rgba(255,255,255,.8)', fontSize: 12 }}><span style={heroMeta}><MapPin size={14} /> {publication.venue || 'Lieu à confirmer'}</span>{publication.city && <span style={heroMeta}>{publication.city}</span>}</div>
        <a href="#programme" aria-label="Voir le programme" style={{ display: 'inline-grid', placeItems: 'center', marginTop: 56, width: 42, height: 42, borderRadius: '50%', color: '#FFF', border: '1px solid rgba(255,255,255,.3)' }}><ChevronDown size={18} /></a>
      </div>
    </header>

    <main>
      <section id="programme" style={{ width: 'min(980px,calc(100% - 40px))', margin: '0 auto', padding: '90px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(220px,.7fr) minmax(0,1.3fr)', gap: 'clamp(36px,8vw,100px)', alignItems: 'start' }} className="lma-public-grid">
          <div style={{ position: 'sticky', top: 30 }}><span style={eyebrow}>Le déroulé</span><h2 style={sectionTitle}>Chaque instant compte.</h2><p style={sectionCopy}>Les horaires et informations ci-dessous sont reliés directement à notre organisation.</p></div>
          <div>{publication.moments.length ? publication.moments.map((moment, index) => <article key={moment.id} style={{ display: 'grid', gridTemplateColumns: '76px 1fr', gap: 22, padding: '24px 0', borderTop: '1px solid rgba(36,31,28,.14)' }}><div style={{ fontFamily: 'Georgia, serif', fontSize: 20 }}>{moment.time || `0${index + 1}`}</div><div><h3 style={{ margin: 0, fontSize: 17 }}>{moment.title}</h3><div style={{ marginTop: 5, color: 'rgba(36,31,28,.55)', fontSize: 11 }}>{moment.subtitle}</div>{moment.notes && <p style={{ margin: '10px 0 0', color: 'rgba(36,31,28,.7)', lineHeight: 1.55, fontSize: 12 }}>{moment.notes}</p>}</div></article>) : <div style={{ padding: 30, border: '1px dashed rgba(36,31,28,.2)', borderRadius: 16 }}>Le programme sera ajouté prochainement.</div>}</div>
        </div>
      </section>

      {publication.allowRsvp && <section style={{ background: '#24211F', color: '#F7F2EC', padding: '90px 20px' }}>
        <div style={{ width: 'min(900px,100%)', margin: '0 auto', display: 'grid', gridTemplateColumns: 'minmax(0,.85fr) minmax(300px,1.15fr)', gap: 'clamp(40px,8vw,100px)' }} className="lma-public-grid">
          <div><span style={{ ...eyebrow, color: 'rgba(247,242,236,.48)' }}>Réponse souhaitée</span><h2 style={{ ...sectionTitle, color: '#FFF' }}>Serez-vous avec nous ?</h2><p style={{ ...sectionCopy, color: 'rgba(247,242,236,.6)' }}>Votre réponse alimente directement la liste des invités et les besoins du repas. Vous pourrez la modifier depuis ce même appareil.</p></div>
          <div style={{ padding: 24, borderRadius: 18, background: '#302C29', border: '1px solid rgba(255,255,255,.09)' }}>
            {sent ? <div style={{ minHeight: 300, display: 'grid', placeItems: 'center', textAlign: 'center' }}><div><span style={{ width: 46, height: 46, borderRadius: '50%', display: 'grid', placeItems: 'center', margin: '0 auto 14px', background: '#F3EEE7', color: '#24211F' }}><Check size={20} /></span><strong style={{ fontSize: 18 }}>Merci pour votre réponse.</strong><p style={{ color: 'rgba(255,255,255,.58)', fontSize: 11, lineHeight: 1.5 }}>{message}</p><button onClick={editAgain} style={{ marginTop: 12, height: 38, padding: '0 14px', borderRadius: 9, border: '1px solid rgba(255,255,255,.16)', background: 'transparent', color: '#FFF', cursor: 'pointer', fontSize: 10 }}>Modifier ma réponse</button></div></div> : <>
              {existingResponse && <div style={{ marginBottom: 12, padding: '9px 10px', borderRadius: 9, background: 'rgba(255,255,255,.055)', color: 'rgba(255,255,255,.7)', fontSize: 9 }}>Une réponse existe déjà sur cet appareil. L’envoi la mettra à jour.</div>}
              <div aria-hidden="true" style={{ position: 'absolute', left: -10000, width: 1, height: 1, overflow: 'hidden' }}><label>Site web<input value={website} onChange={(event) => setWebsite(event.target.value)} tabIndex={-1} autoComplete="off" /></label></div>
              <Field label="Votre nom"><input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} style={publicInput} placeholder="Prénom et nom" autoComplete="name" /></Field>
              <Field label="Votre e-mail"><input value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} style={publicInput} placeholder="facultatif" type="email" autoComplete="email" /></Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}><Field label="Présence"><select value={form.attendance} onChange={(event) => setForm({ ...form, attendance: event.target.value as RsvpSubmission['attendance'] })} style={publicInput}><option value="yes">Oui, avec joie</option><option value="maybe">Je ne sais pas encore</option><option value="no">Non, malheureusement</option></select></Field><Field label="Nombre de personnes"><input value={form.guestCount} onChange={(event) => setForm({ ...form, guestCount: Number(event.target.value) })} style={publicInput} min={0} max={20} type="number" /></Field></div>
              <Field label="Régimes ou allergies"><input value={form.dietaryRequirements} onChange={(event) => setForm({ ...form, dietaryRequirements: event.target.value })} style={publicInput} placeholder="facultatif" /></Field>
              <Field label="Un mot pour les mariés"><textarea value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} style={{ ...publicInput, height: 90, paddingTop: 11, resize: 'vertical' }} /></Field>
              <button disabled={busy || !form.name.trim()} onClick={() => void send()} style={{ width: '100%', height: 44, borderRadius: 11, border: 0, background: '#F3EEE7', color: '#24211F', cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 8, fontWeight: 760 }}>{busy ? <><RefreshCw size={15} /> Envoi…</> : <><Send size={15} /> {existingResponse ? 'Mettre à jour ma réponse' : 'Envoyer ma réponse'}</>}</button>
              {message && <p role="status" style={{ margin: '10px 0 0', color: 'rgba(255,255,255,.62)', fontSize: 10 }}>{message}</p>}
            </>}
          </div>
        </div>
      </section>}
    </main>
    <footer style={{ padding: '26px 20px', textAlign: 'center', background: '#171514', color: 'rgba(255,255,255,.38)', fontSize: 9 }}>Créé avec LE MONDE AIME — Point Zéro des Vivants</footer>
    <ResponsiveStyles />
  </div>;
};

const LiveDay: React.FC<{ publication: PublishedWedding; updates: LiveUpdate[]; now: Date; connected: boolean }> = ({ publication, updates, now, connected }) => {
  const currentIndex = resolveCurrentMomentIndex(publication.moments, now);
  const current = currentIndex >= 0 ? publication.moments[currentIndex] : undefined;
  const next = publication.moments[currentIndex + 1];
  const countdown = next?.time ? minutesUntil(next.time, now) : null;

  return <div style={{ minHeight: '100vh', background: '#101011', color: '#F7F7F8', fontFamily: 'Inter, system-ui, sans-serif', padding: 'max(20px,env(safe-area-inset-top)) 16px 100px' }}>
    <header style={{ width: 'min(760px,100%)', margin: '0 auto 22px', display: 'flex', alignItems: 'center', gap: 10 }}><span style={{ width: 36, height: 36, borderRadius: 11, display: 'grid', placeItems: 'center', background: '#242426', border: '1px solid rgba(255,255,255,.1)' }}><Radio size={16} /></span><div><strong style={{ fontSize: 13 }}>Jour J · Live</strong><div style={{ marginTop: 3, color: 'rgba(255,255,255,.48)', fontSize: 9 }}>{publication.title}</div></div><span style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 6, color: connected ? '#86EFAC' : 'rgba(255,255,255,.42)', fontSize: 8.5 }}><Wifi size={12} /> {connected ? 'Actualisé en direct' : 'Connexion au direct'}</span></header>
    <main style={{ width: 'min(760px,100%)', margin: '0 auto' }}>
      <section style={{ padding: 22, borderRadius: 18, background: '#1D1D1F', border: '1px solid rgba(255,255,255,.09)' }}><span style={{ color: 'rgba(255,255,255,.44)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '.1em' }}>En ce moment</span><h1 style={{ margin: '14px 0 8px', fontSize: 'clamp(30px,8vw,54px)', letterSpacing: '-.05em' }}>{current?.title || 'Bienvenue'}</h1><p style={{ margin: 0, color: 'rgba(255,255,255,.58)', fontSize: 12, lineHeight: 1.55 }}>{current?.notes || current?.subtitle || 'Le direct commencera bientôt.'}</p>{current?.time && <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, marginTop: 18, padding: '7px 10px', borderRadius: 8, background: '#29292C', fontSize: 10 }}><Clock3 size={13} /> {current.time}</div>}{next && <div style={{ marginTop: 18, paddingTop: 14, borderTop: '1px solid rgba(255,255,255,.08)', display: 'flex', gap: 10, alignItems: 'center' }}><span style={{ width: 28, height: 28, borderRadius: 8, background: '#29292C', display: 'grid', placeItems: 'center' }}><CalendarDays size={13} /></span><span style={{ flex: 1 }}><span style={{ display: 'block', color: 'rgba(255,255,255,.4)', fontSize: 8, textTransform: 'uppercase' }}>Ensuite</span><strong style={{ display: 'block', marginTop: 3, fontSize: 10.5 }}>{next.time} · {next.title}</strong></span>{countdown != null && countdown >= 0 && <strong style={{ fontSize: 10 }}>dans {countdown} min</strong>}</div>}</section>

      {updates.length > 0 && <section style={{ marginTop: 16 }}><h2 style={{ fontSize: 12, margin: '0 0 9px' }}>Messages en direct</h2>{updates.map((update) => <article key={update.id} style={{ padding: 14, marginBottom: 8, borderRadius: 12, background: update.level === 'urgent' ? 'rgba(127,29,29,.28)' : '#1D1D1F', border: `1px solid ${update.level === 'urgent' ? 'rgba(248,113,113,.3)' : 'rgba(255,255,255,.08)'}` }}><div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>{update.level === 'urgent' && <AlertTriangle size={13} color="#F87171" />}<strong style={{ fontSize: 11 }}>{update.title}</strong>{update.is_pinned && <span style={{ marginLeft: 'auto', color: 'rgba(255,255,255,.4)', fontSize: 7.5, textTransform: 'uppercase' }}>Épinglé</span>}</div>{update.body && <p style={{ margin: '6px 0 0', color: 'rgba(255,255,255,.55)', fontSize: 10, lineHeight: 1.5 }}>{update.body}</p>}<span style={{ display: 'block', marginTop: 8, color: 'rgba(255,255,255,.28)', fontSize: 7.8 }}>{formatUpdateTime(update.created_at)}</span></article>)}</section>}

      <section style={{ marginTop: 22 }}><h2 style={{ fontSize: 12, margin: '0 0 10px' }}>La suite</h2>{publication.moments.map((moment, index) => <div key={moment.id} style={{ display: 'grid', gridTemplateColumns: '62px 1fr', gap: 10, padding: '12px 0', borderTop: '1px solid rgba(255,255,255,.07)', opacity: index < currentIndex ? .35 : 1 }}><span style={{ fontSize: 11 }}>{moment.time || '—'}</span><span><strong style={{ display: 'block', fontSize: 10.5 }}>{moment.title}</strong><span style={{ display: 'block', color: 'rgba(255,255,255,.42)', fontSize: 8.5, marginTop: 3 }}>{moment.subtitle}</span></span></div>)}</section>
    </main>
  </div>;
};

function formatPublicDate(value: string) {
  if (!value) return 'Date à venir';
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
}

function minutesUntil(time: string, now: Date) {
  const [hour, minute] = time.split(':').map(Number);
  if (!Number.isFinite(hour)) return null;
  return hour * 60 + (Number.isFinite(minute) ? minute : 0) - (now.getHours() * 60 + now.getMinutes());
}

function formatUpdateTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' }).format(date);
}

const PublicState: React.FC<{ title: string }> = ({ title }) => <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', background: '#151516', color: '#F5F5F5', fontFamily: 'Inter, sans-serif', padding: 20, textAlign: 'center' }}><div><span style={{ width: 42, height: 42, display: 'grid', placeItems: 'center', margin: '0 auto 14px', borderRadius: 12, background: '#242426' }}><Users size={18} /></span><strong>{title}</strong></div></div>;
const Field: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => <label style={{ display: 'block', marginBottom: 11 }}><span style={{ display: 'block', marginBottom: 5, color: 'rgba(255,255,255,.48)', fontSize: 8, fontWeight: 760, textTransform: 'uppercase', letterSpacing: '.08em' }}>{label}</span>{children}</label>;
const mediaStyle: React.CSSProperties = { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' };
const heroMeta: React.CSSProperties = { display: 'inline-flex', alignItems: 'center', gap: 7 };
const eyebrow: React.CSSProperties = { display: 'block', color: 'rgba(36,31,28,.48)', fontSize: 9, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.13em' };
const sectionTitle: React.CSSProperties = { margin: '14px 0 16px', fontFamily: 'Georgia, serif', fontSize: 'clamp(34px,6vw,64px)', fontWeight: 400, lineHeight: 1, letterSpacing: '-.045em' };
const sectionCopy: React.CSSProperties = { margin: 0, color: 'rgba(36,31,28,.62)', fontSize: 12, lineHeight: 1.7 };
const publicInput: React.CSSProperties = { width: '100%', height: 40, borderRadius: 9, border: '1px solid rgba(255,255,255,.12)', background: '#24211F', color: '#FFF', padding: '0 10px', boxSizing: 'border-box', outline: 'none', fontFamily: 'Inter, sans-serif', fontSize: 11 };
const ResponsiveStyles = () => <style>{`@media(max-width:720px){.lma-public-grid{grid-template-columns:1fr!important}.lma-public-grid>div:first-child{position:static!important}}`}</style>;
