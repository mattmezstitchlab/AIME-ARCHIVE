import type { SupabaseClient, User } from '@supabase/supabase-js';
import type { WeddingLot } from '../types';
import type { StudioProjectMeta } from '../utils/projectStore';
import { computeWeddingReadiness, weddingBlockingCount, type WeddingProjectData } from '../domain/weddingProject';
import { ensureSupabaseClient } from '../cloud/supabase';

export interface PublishedMoment {
  id: string;
  title: string;
  subtitle: string;
  time: string;
  notes: string;
  image: string;
}

export interface PublishedWedding {
  version: 1 | 2;
  slug: string;
  projectId: string;
  title: string;
  date: string;
  venue: string;
  city: string;
  heroPhoto: string;
  heroMediaType: 'image' | 'video';
  style: string;
  timezone?: string;
  moments: PublishedMoment[];
  allowRsvp: boolean;
  publishedAt: string;
  updatedAt: string;
}

export interface PublishResult {
  slug?: string;
  url: string;
  liveUrl: string;
  mode: 'cloud' | 'local';
  publishedAt?: string;
}

export interface RsvpSubmission {
  name: string;
  email?: string;
  attendance: 'yes' | 'no' | 'maybe';
  guestCount: number;
  dietaryRequirements?: string;
  message?: string;
}

export interface RsvpRecord extends RsvpSubmission {
  id: string;
  publicationSlug: string;
  responseKey: string;
  createdAt: string;
  updatedAt: string;
}

export interface RsvpSummary {
  responses: number;
  attending: number;
  absent: number;
  maybe: number;
  expectedGuests: number;
  dietaryResponses: number;
}

export type LiveUpdateLevel = 'info' | 'important' | 'urgent';

export interface LiveUpdate {
  id: string;
  publication_slug: string;
  title: string;
  body?: string;
  event_time?: string;
  level: LiveUpdateLevel;
  is_pinned: boolean;
  created_at: string;
  updated_at?: string;
}

const LOCAL_PUBLICATION_PREFIX = 'lma_publication:';
const LOCAL_RSVP_PREFIX = 'lma_rsvps:';
const LOCAL_RSVP_KEY_PREFIX = 'lma_rsvp_key:';
const LOCAL_LIVE_PREFIX = 'lma_live_updates:';

export function slugifyPublication(value: string, projectId: string): string {
  const base = value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48) || 'mariage';
  return `${base}-${projectId.slice(-6).toLowerCase()}`;
}

export function buildPublishedWedding(input: {
  project: StudioProjectMeta;
  wedding: WeddingProjectData;
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, unknown>>;
  publishedAt?: string;
}): PublishedWedding {
  const selected = new Set(input.wedding.publication.selectedCardIds);
  const moments: PublishedMoment[] = [];
  for (const lot of input.lots) {
    for (const card of lot.cards) {
      const settings = input.cardSettings[card.id] || {};
      const hasTimelineData = typeof settings.time === 'string' && settings.time.trim();
      if (!selected.has(card.id) && !hasTimelineData) continue;
      moments.push({
        id: card.id,
        title: card.name,
        subtitle: card.subtitle,
        time: typeof settings.time === 'string' ? settings.time.trim() : '',
        notes: typeof settings.notes === 'string' ? settings.notes.trim() : '',
        image: typeof settings.frontMediaUrl === 'string' && settings.frontMediaUrl ? settings.frontMediaUrl : card.image || '',
      });
    }
  }
  moments.sort((a, b) => (a.time || '99:99').localeCompare(b.time || '99:99'));
  const names = input.wedding.identity.brideFirstName && input.wedding.identity.groomFirstName
    ? `${input.wedding.identity.brideFirstName} & ${input.wedding.identity.groomFirstName}`
    : input.project.name;
  const now = new Date().toISOString();
  return {
    version: 2,
    slug: slugifyPublication(names, input.project.id),
    projectId: input.project.id,
    title: names,
    date: input.wedding.publication.heroDate || input.wedding.identity.date,
    venue: input.wedding.publication.heroVenue || input.wedding.venues.reception || input.wedding.venues.ceremony,
    city: input.wedding.venues.city,
    heroPhoto: input.wedding.publication.heroPhoto,
    heroMediaType: input.wedding.publication.heroMediaType,
    style: input.wedding.design.style,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Paris',
    moments,
    allowRsvp: true,
    publishedAt: input.publishedAt || now,
    updatedAt: now,
  };
}

export function publicationUrl(slug: string, mode: 'site' | 'live' = 'site'): string {
  const url = new URL('/', window.location.origin);
  url.searchParams.set(mode, slug);
  return url.toString();
}

export function publicationSlugFromUrl(value: string): string {
  try {
    const url = new URL(value, window.location.origin);
    return url.searchParams.get('site') || url.searchParams.get('live') || '';
  } catch {
    return '';
  }
}

async function ensurePublicationProject(client: SupabaseClient, project: StudioProjectMeta, user: User) {
  const { data: existing, error: readError } = await client
    .from('projects')
    .select('id')
    .eq('id', project.id)
    .maybeSingle();
  if (readError) throw readablePublicationError(readError);

  if (!existing) {
    const { error } = await client.from('projects').insert({
      id: project.id,
      owner_id: user.id,
      name: project.name,
      universe: project.universe,
      status: project.status,
      metadata: { accent: project.accent, favorite: project.favorite },
    });
    if (error) throw readablePublicationError(error);
    return;
  }

  const { error } = await client.from('projects').update({
    name: project.name,
    universe: project.universe,
    status: project.status,
    metadata: { accent: project.accent, favorite: project.favorite },
    updated_at: new Date().toISOString(),
  }).eq('id', project.id);
  if (error) throw readablePublicationError(error);
}

export async function publishWedding(input: {
  project: StudioProjectMeta;
  wedding: WeddingProjectData;
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, unknown>>;
  user: User | null;
}): Promise<{ publication: PublishedWedding; mode: 'cloud' | 'local'; url: string; liveUrl: string }> {
  const client = await ensureSupabaseClient();
  const draft = buildPublishedWedding(input);
  let publication = draft;
  let mode: 'cloud' | 'local' = 'local';

  if (client && input.user) {
    const readiness = computeWeddingReadiness(input.wedding, input.cardSettings);
    const blockerCount = weddingBlockingCount(readiness);
    if (blockerCount > 0) {
      const labels = readiness
        .filter((item) => item.blocking && !item.complete)
        .slice(0, 4)
        .map((item) => item.label);
      const remaining = blockerCount - labels.length;
      throw new Error(`Publication bloquée : complétez ${labels.join(', ')}${remaining > 0 ? ` et ${remaining} autre${remaining > 1 ? 's' : ''}` : ''}.`);
    }

    await ensurePublicationProject(client, input.project, input.user);
    const { data: existing, error: existingError } = await client
      .from('publications')
      .select('published_at, payload')
      .eq('slug', draft.slug)
      .maybeSingle();
    if (existingError && existingError.code !== 'PGRST116') throw readablePublicationError(existingError);

    const existingPublishedAt = typeof existing?.published_at === 'string'
      ? existing.published_at
      : typeof existing?.payload?.publishedAt === 'string'
        ? existing.payload.publishedAt
        : undefined;
    publication = buildPublishedWedding({ ...input, publishedAt: existingPublishedAt });

    const { error } = await client.from('publications').upsert({
      slug: publication.slug,
      project_id: input.project.id,
      owner_id: input.user.id,
      payload: publication,
      status: 'published',
      published_at: publication.publishedAt,
      updated_at: publication.updatedAt,
    }, { onConflict: 'slug' });
    if (error) throw readablePublicationError(error);
    mode = 'cloud';
  }

  localStorage.setItem(`${LOCAL_PUBLICATION_PREFIX}${publication.slug}`, JSON.stringify(publication));
  return {
    publication,
    mode,
    url: publicationUrl(publication.slug, 'site'),
    liveUrl: publicationUrl(publication.slug, 'live'),
  };
}

export async function archivePublication(slug: string): Promise<void> {
  const client = await ensureSupabaseClient();
  if (!client) {
    localStorage.removeItem(`${LOCAL_PUBLICATION_PREFIX}${slug}`);
    return;
  }
  const { error } = await client.from('publications').update({ status: 'archived', updated_at: new Date().toISOString() }).eq('slug', slug);
  if (error) throw readablePublicationError(error);
}

export async function getPublishedWedding(slug: string): Promise<PublishedWedding | null> {
  const client = await ensureSupabaseClient();
  if (client) {
    const { data, error } = await client.from('publications').select('payload').eq('slug', slug).eq('status', 'published').maybeSingle();
    if (!error && data?.payload) {
      const publication = data.payload as PublishedWedding;
      localStorage.setItem(`${LOCAL_PUBLICATION_PREFIX}${slug}`, JSON.stringify(publication));
      return publication;
    }
  }
  try {
    const raw = localStorage.getItem(`${LOCAL_PUBLICATION_PREFIX}${slug}`);
    return raw ? JSON.parse(raw) as PublishedWedding : null;
  } catch {
    return null;
  }
}

function rsvpResponseKey(slug: string) {
  const key = `${LOCAL_RSVP_KEY_PREFIX}${slug}`;
  const existing = localStorage.getItem(key);
  if (existing) return existing;
  const created = crypto.randomUUID();
  localStorage.setItem(key, created);
  return created;
}

export function hasExistingRsvp(slug: string) {
  return Boolean(localStorage.getItem(`${LOCAL_RSVP_KEY_PREFIX}${slug}`));
}

export async function submitRsvp(slug: string, submission: RsvpSubmission): Promise<{ mode: 'cloud' | 'local'; updated: boolean }> {
  validateRsvp(submission);
  const responseKey = rsvpResponseKey(slug);
  const updated = hasLocalRsvp(slug, responseKey);
  const client = await ensureSupabaseClient();

  if (client) {
    const { error } = await client.rpc('submit_public_rsvp', {
      p_publication_slug: slug,
      p_response_key: responseKey,
      p_name: submission.name.trim(),
      p_email: submission.email?.trim() || null,
      p_attendance: submission.attendance,
      p_guest_count: Math.max(0, Math.min(20, Number(submission.guestCount || 0))),
      p_dietary_requirements: submission.dietaryRequirements?.trim() || null,
      p_message: submission.message?.trim() || null,
    });
    if (error) throw readablePublicationError(error);
    cacheLocalRsvp(slug, responseKey, submission);
    return { mode: 'cloud', updated };
  }

  cacheLocalRsvp(slug, responseKey, submission);
  return { mode: 'local', updated };
}

function validateRsvp(submission: RsvpSubmission) {
  const name = submission.name.trim();
  if (name.length < 2) throw new Error('Votre nom est requis.');
  if (name.length > 120) throw new Error('Votre nom est trop long.');
  if (submission.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(submission.email.trim())) throw new Error('L’adresse e-mail est invalide.');
  const count = Number(submission.guestCount);
  if (!Number.isFinite(count) || count < 0 || count > 20) throw new Error('Le nombre de personnes doit être compris entre 0 et 20.');
  if ((submission.dietaryRequirements || '').length > 1000 || (submission.message || '').length > 2000) throw new Error('Votre réponse est trop longue.');
}

function hasLocalRsvp(slug: string, responseKey: string) {
  try {
    const items = JSON.parse(localStorage.getItem(`${LOCAL_RSVP_PREFIX}${slug}`) || '[]') as RsvpRecord[];
    return items.some((item) => item.responseKey === responseKey);
  } catch {
    return false;
  }
}

function cacheLocalRsvp(slug: string, responseKey: string, submission: RsvpSubmission) {
  const key = `${LOCAL_RSVP_PREFIX}${slug}`;
  let items: RsvpRecord[] = [];
  try { items = JSON.parse(localStorage.getItem(key) || '[]') as RsvpRecord[]; } catch { items = []; }
  const now = new Date().toISOString();
  const existing = items.find((item) => item.responseKey === responseKey);
  const record: RsvpRecord = {
    ...submission,
    id: existing?.id || crypto.randomUUID(),
    publicationSlug: slug,
    responseKey,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  };
  localStorage.setItem(key, JSON.stringify([record, ...items.filter((item) => item.responseKey !== responseKey)].slice(0, 500)));
}

export async function listRsvps(slug: string): Promise<RsvpRecord[]> {
  const client = await ensureSupabaseClient();
  if (client) {
    const { data, error } = await client
      .from('rsvps')
      .select('id, publication_slug, response_key, name, email, attendance, guest_count, dietary_requirements, message, created_at, updated_at')
      .eq('publication_slug', slug)
      .order('updated_at', { ascending: false });
    if (error) throw readablePublicationError(error);
    return (data || []).map((item) => ({
      id: item.id,
      publicationSlug: item.publication_slug,
      responseKey: item.response_key,
      name: item.name,
      email: item.email || undefined,
      attendance: item.attendance,
      guestCount: item.guest_count,
      dietaryRequirements: item.dietary_requirements || undefined,
      message: item.message || undefined,
      createdAt: item.created_at,
      updatedAt: item.updated_at,
    })) as RsvpRecord[];
  }
  try { return JSON.parse(localStorage.getItem(`${LOCAL_RSVP_PREFIX}${slug}`) || '[]') as RsvpRecord[]; } catch { return []; }
}

export function summarizeRsvps(items: RsvpRecord[]): RsvpSummary {
  return items.reduce<RsvpSummary>((summary, item) => {
    summary.responses += 1;
    if (item.attendance === 'yes') {
      summary.attending += 1;
      summary.expectedGuests += item.guestCount;
    } else if (item.attendance === 'no') summary.absent += 1;
    else summary.maybe += 1;
    if (item.dietaryRequirements?.trim()) summary.dietaryResponses += 1;
    return summary;
  }, { responses: 0, attending: 0, absent: 0, maybe: 0, expectedGuests: 0, dietaryResponses: 0 });
}

export function rsvpsToCsv(items: RsvpRecord[]) {
  const headers = ['Nom', 'E-mail', 'Présence', 'Personnes', 'Régimes ou allergies', 'Message', 'Mise à jour'];
  const attendance = { yes: 'Oui', no: 'Non', maybe: 'Peut-être' } as const;
  const rows = items.map((item) => [item.name, item.email || '', attendance[item.attendance], String(item.guestCount), item.dietaryRequirements || '', item.message || '', item.updatedAt]);
  return [headers, ...rows].map((row) => row.map(csvCell).join(';')).join('\n');
}

function csvCell(value: string) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

export async function publishLiveUpdate(
  slug: string,
  input: { title: string; body?: string; eventTime?: string; level?: LiveUpdateLevel; pinned?: boolean },
  user: User | null,
) {
  if (!input.title.trim()) throw new Error('Le titre du message est requis.');
  if (input.title.trim().length > 160 || (input.body || '').length > 2000) throw new Error('Le message est trop long.');
  const client = await ensureSupabaseClient();
  if (!client || !user) {
    const key = `${LOCAL_LIVE_PREFIX}${slug}`;
    let existing: LiveUpdate[] = [];
    try { existing = JSON.parse(localStorage.getItem(key) || '[]') as LiveUpdate[]; } catch { existing = []; }
    const now = new Date().toISOString();
    existing.unshift({
      id: crypto.randomUUID(),
      publication_slug: slug,
      title: input.title.trim(),
      body: input.body?.trim() || undefined,
      event_time: input.eventTime || undefined,
      level: input.level || 'info',
      is_pinned: Boolean(input.pinned),
      created_at: now,
      updated_at: now,
    });
    localStorage.setItem(key, JSON.stringify(sortLiveUpdates(existing).slice(0, 50)));
    return 'local' as const;
  }
  const { error } = await client.from('live_updates').insert({
    publication_slug: slug,
    title: input.title.trim(),
    body: input.body?.trim() || null,
    event_time: input.eventTime || null,
    level: input.level || 'info',
    is_pinned: Boolean(input.pinned),
    created_by: user.id,
  });
  if (error) throw readablePublicationError(error);
  return 'cloud' as const;
}

export async function deleteLiveUpdate(id: string): Promise<void> {
  const client = await ensureSupabaseClient();
  if (!client) return;
  const { error } = await client.from('live_updates').delete().eq('id', id);
  if (error) throw readablePublicationError(error);
}

export async function getLiveUpdates(slug: string): Promise<LiveUpdate[]> {
  const client = await ensureSupabaseClient();
  if (client) {
    const { data, error } = await client
      .from('live_updates')
      .select('id, publication_slug, title, body, event_time, level, is_pinned, created_at, updated_at')
      .eq('publication_slug', slug)
      .order('is_pinned', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(50);
    if (!error && data) return sortLiveUpdates(data as LiveUpdate[]);
  }
  try { return sortLiveUpdates(JSON.parse(localStorage.getItem(`${LOCAL_LIVE_PREFIX}${slug}`) || '[]') as LiveUpdate[]); } catch { return []; }
}

function sortLiveUpdates(items: LiveUpdate[]) {
  return [...items].sort((a, b) => Number(b.is_pinned) - Number(a.is_pinned) || new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function resolveCurrentMomentIndex(moments: PublishedMoment[], now: Date = new Date()) {
  if (!moments.length) return -1;
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  let current = -1;
  moments.forEach((moment, index) => {
    const [hour, minute] = moment.time.split(':').map(Number);
    if (!Number.isFinite(hour)) return;
    const total = hour * 60 + (Number.isFinite(minute) ? minute : 0);
    if (total <= nowMinutes) current = index;
  });
  return current >= 0 ? current : 0;
}

export function subscribeToPublishedWedding(slug: string, onChange: (publication: PublishedWedding | null) => void) {
  let disposed = false;
  let channel: any = null;
  void ensureSupabaseClient().then((client) => {
    if (!client || disposed) return;
    channel = client.channel(`publication:${slug}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'publications', filter: `slug=eq.${slug}` }, (payload) => {
        const record = (payload.new || payload.old) as { status?: string; payload?: PublishedWedding };
        onChange(record?.status === 'published' && record.payload ? record.payload : null);
      })
      .subscribe();
  }).catch(() => undefined);
  return () => {
    disposed = true;
    if (channel) void channel.unsubscribe();
  };
}

export function subscribeToLiveUpdates(slug: string, onChange: () => void) {
  let disposed = false;
  let channel: any = null;
  void ensureSupabaseClient().then((client) => {
    if (!client || disposed) return;
    channel = client.channel(`live:${slug}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'live_updates', filter: `publication_slug=eq.${slug}` }, onChange)
      .subscribe();
  }).catch(() => undefined);
  return () => {
    disposed = true;
    if (channel) void channel.unsubscribe();
  };
}

export function subscribeToRsvps(slug: string, onChange: () => void) {
  let disposed = false;
  let channel: any = null;
  void ensureSupabaseClient().then((client) => {
    if (!client || disposed) return;
    channel = client.channel(`rsvps:${slug}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rsvps', filter: `publication_slug=eq.${slug}` }, onChange)
      .subscribe();
  }).catch(() => undefined);
  return () => {
    disposed = true;
    if (channel) void channel.unsubscribe();
  };
}

function readablePublicationError(error: unknown) {
  const candidate = error as { message?: string; code?: string };
  const message = candidate?.message || 'Opération de publication impossible.';
  if (/relation .* does not exist/i.test(message) || candidate?.code === '42P01' || /submit_public_rsvp/i.test(message)) {
    return new Error('Le module Publication V9.5 n’est pas encore installé dans Supabase. Exécutez la migration V9.5.');
  }
  if (/row-level security/i.test(message) || candidate?.code === '42501') {
    return new Error('Supabase a refusé cette action. Vérifiez le compte, le rôle et les politiques RLS.');
  }
  return error instanceof Error ? error : new Error(message);
}
