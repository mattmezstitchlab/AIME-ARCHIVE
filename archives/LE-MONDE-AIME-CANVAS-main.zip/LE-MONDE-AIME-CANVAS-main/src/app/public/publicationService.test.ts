import { describe, expect, it } from 'vitest';
import {
  buildPublishedWedding,
  resolveCurrentMomentIndex,
  rsvpsToCsv,
  slugifyPublication,
  summarizeRsvps,
  type PublishedMoment,
  type RsvpRecord,
} from './publicationService';
import { buildWeddingProjectData } from '../domain/weddingProject';

const setup = {
  brideFirstName: 'Élise', groomFirstName: 'Noé', date: '2027-08-21', ceremonyTime: '15:00',
  ceremonyVenue: 'Mairie', receptionVenue: 'Domaine', receptionCity: 'Lille', guestCount: 80,
  childCount: 8, diet: [], style: 'Chic', colorA: '#111111', colorB: '#eeeeee', budget: 25000,
  witnessA: 'Camille', witnessB: 'Alex',
};

const lots = [{
  id: 1, title: 'Programme', subtitle: 'Jour J', icon: 'Sparkles', accentColor: '#aaa', position: { x: 0, y: 0 },
  cards: [
    { id: 'a', name: 'Cérémonie', subtitle: 'Le oui', icon: 'Heart', type: 'programme' as const },
    { id: 'b', name: 'Cocktail', subtitle: 'La fête', icon: 'Wine', type: 'programme' as const },
    { id: 'c', name: 'Caché', subtitle: 'Privé', icon: 'EyeOff', type: 'programme' as const },
  ],
}];

const project = { id: 'project-abcdef', name: 'Élise & Noé', universe: 'mariage' as const, createdAt: '', updatedAt: '', openedAt: '', favorite: false, archived: false, trashed: false, status: 'draft' as const, accent: '#aaa' };

describe('publicationService', () => {
  it('produit un slug stable et lisible', () => {
    expect(slugifyPublication('Élise & Noé', project.id)).toBe('elise-noe-abcdef');
    expect(slugifyPublication('Été à Lille !', project.id)).toBe('ete-a-lille-abcdef');
  });

  it('publie les cartes choisies ou reliées à un horaire, triées chronologiquement', () => {
    const wedding = buildWeddingProjectData({ setup, totalBudget: 25000, heroPhoto: '', heroMediaType: 'image', heroName: '', heroDate: '', heroVenue: '', selectedCardIds: ['b'] });
    const publication = buildPublishedWedding({
      project,
      wedding,
      lots,
      cardSettings: { a: { time: '15:00', notes: 'Rendez-vous à la mairie' }, b: { time: '17:00' } },
    });
    expect(publication.title).toBe('Élise & Noé');
    expect(publication.moments.map((moment) => moment.id)).toEqual(['a', 'b']);
    expect(publication.moments[0].notes).toBe('Rendez-vous à la mairie');
  });

  it('résume les RSVP en personnes attendues et contraintes alimentaires', () => {
    const rows: RsvpRecord[] = [
      { id: '1', publicationSlug: 'x', responseKey: 'a', name: 'A', attendance: 'yes', guestCount: 3, dietaryRequirements: 'Sans gluten', createdAt: '', updatedAt: '' },
      { id: '2', publicationSlug: 'x', responseKey: 'b', name: 'B', attendance: 'maybe', guestCount: 2, createdAt: '', updatedAt: '' },
      { id: '3', publicationSlug: 'x', responseKey: 'c', name: 'C', attendance: 'no', guestCount: 4, createdAt: '', updatedAt: '' },
    ];
    expect(summarizeRsvps(rows)).toEqual({ responses: 3, attending: 1, absent: 1, maybe: 1, expectedGuests: 3, dietaryResponses: 1 });
    expect(rsvpsToCsv(rows)).toContain('Sans gluten');
  });

  it('sélectionne le dernier moment commencé, y compris après le dernier horaire', () => {
    const moments: PublishedMoment[] = [
      { id: 'a', title: 'A', subtitle: '', time: '10:00', notes: '', image: '' },
      { id: 'b', title: 'B', subtitle: '', time: '15:00', notes: '', image: '' },
      { id: 'c', title: 'C', subtitle: '', time: '20:00', notes: '', image: '' },
    ];
    expect(resolveCurrentMomentIndex(moments, new Date('2026-01-01T09:00:00'))).toBe(0);
    expect(resolveCurrentMomentIndex(moments, new Date('2026-01-01T16:00:00'))).toBe(1);
    expect(resolveCurrentMomentIndex(moments, new Date('2026-01-01T23:00:00'))).toBe(2);
  });
});
