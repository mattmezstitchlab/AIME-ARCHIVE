export type ProjectUniverse = 'mariage' | 'evenement' | 'site' | 'association' | 'prestataire' | 'portfolio' | 'libre';

export interface StudioProjectMeta {
  id: string;
  name: string;
  universe: ProjectUniverse;
  folderId?: string;
  createdAt: string;
  updatedAt: string;
  openedAt: string;
  favorite: boolean;
  archived: boolean;
  trashed: boolean;
  status: 'draft' | 'published';
  accent: string;
}

export interface StudioFolder {
  id: string;
  name: string;
  createdAt: string;
}

export type ProjectSaveState = 'idle' | 'saving' | 'saved' | 'error';

export interface StudioProjectBundle {
  format: 'le-monde-aime-project';
  version: 1;
  exportedAt: string;
  project: Omit<StudioProjectMeta, 'id' | 'createdAt' | 'updatedAt' | 'openedAt'> & { name: string };
  data: Record<string, string>;
}

const PROJECT_INDEX_KEY = 'lma_project_index_v1';
const FOLDERS_KEY = 'lma_project_folders_v1';
const ACTIVE_PROJECT_KEY = 'lma_active_project_v1';
const PROJECT_PREFIX = 'lma_project:';
const DB_NAME = 'lma-studio-v8';
const DB_VERSION = 1;
const DB_STORE = 'projectSnapshots';
const SAVE_EVENT = 'lma:project-save-state';
const DATABASE_OPEN_TIMEOUT_MS = 700;

const LEGACY_PROJECT_KEYS = [
  'lma_agent_accepted', 'lma_agent_log', 'lma_bg_settings', 'lma_budget',
  'lma_canvas_elements', 'lma_canvas_notes', 'lma_card_settings',
  'lma_collaborative_playlist', 'lma_entry_positions', 'lma_entry_states',
  'lma_global_texture', 'lma_hero_date', 'lma_hero_media_type', 'lma_hero_name',
  'lma_hero_photo', 'lma_hero_venue', 'lma_lot_layouts', 'lma_lot_locks',
  'lma_lot_positions', 'lma_lot_z_indexes', 'lma_provider_setup',
  'lma_provider_setup_complete', 'lma_rsvp_responses', 'lma_setup',
  'lma_setup_complete', 'lma_snap_enabled', 'lma_text_settings',
  'lma_timeline_media', 'lma_workspace_mode', 'lma_canvas_transform',
  'lma_view_mode', 'lma_active_lot_id', 'lma_selected_cards',
  'lma_plan_positions', 'lma_plan_sizes', 'lma_plan_covers',
  'lma_remix_permissions', 'lma_remix_history', 'lma_remix_collection',
];

const ACCENTS = ['#A3A3A8'];
const saveTimers = new Map<string, number>();

function now() {
  return new Date().toISOString();
}

function randomId(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try { return JSON.parse(raw) as T; } catch { return fallback; }
}

function readProjectIndex(): StudioProjectMeta[] {
  return safeParse<StudioProjectMeta[]>(localStorage.getItem(PROJECT_INDEX_KEY), []);
}

function writeProjectIndex(projects: StudioProjectMeta[]) {
  localStorage.setItem(PROJECT_INDEX_KEY, JSON.stringify(projects));
  window.dispatchEvent(new CustomEvent('lma:projects-changed'));
}

function projectStorageKey(projectId: string, key: string) {
  return `${PROJECT_PREFIX}${projectId}:${key}`;
}

function emitSaveState(projectId: string, state: ProjectSaveState, error?: string) {
  window.dispatchEvent(new CustomEvent(SAVE_EVENT, { detail: { projectId, state, error, at: now() } }));
}

function inferLegacyProjectName() {
  const setup = safeParse<Record<string, unknown>>(localStorage.getItem('lma_setup'), {});
  const firstA = typeof setup.brideFirstName === 'string' ? setup.brideFirstName.trim() : '';
  const firstB = typeof setup.groomFirstName === 'string' ? setup.groomFirstName.trim() : '';
  return firstA && firstB ? `${firstA} & ${firstB}` : 'Votre mariage';
}

function openDatabase(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    let settled = false;
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    const finish = (database: IDBDatabase | null) => {
      if (settled) {
        database?.close();
        return;
      }
      settled = true;
      window.clearTimeout(timer);
      resolve(database);
    };
    const timer = window.setTimeout(() => finish(null), DATABASE_OPEN_TIMEOUT_MS);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => finish(request.result);
    request.onerror = () => finish(null);
    request.onblocked = () => finish(null);
  });
}

async function putSnapshot(projectId: string, data: Record<string, string>) {
  const db = await openDatabase();
  if (!db) return;
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).put({ id: projectId, data, updatedAt: now() });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

async function getSnapshot(projectId: string): Promise<Record<string, string> | null> {
  const db = await openDatabase();
  if (!db) return null;
  const result = await new Promise<any>((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readonly');
    const request = tx.objectStore(DB_STORE).get(projectId);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
  db.close();
  return result?.data || null;
}

async function deleteSnapshot(projectId: string) {
  const db = await openDatabase();
  if (!db) return;
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).delete(projectId);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export function ensureProjectWorkspace(): StudioProjectMeta[] {
  let projects = readProjectIndex();
  if (projects.length) {
    const active = localStorage.getItem(ACTIVE_PROJECT_KEY);
    if (!active || !projects.some((project) => project.id === active)) {
      localStorage.setItem(ACTIVE_PROJECT_KEY, projects[0].id);
    }
    return projects;
  }

  const timestamp = now();
  const project: StudioProjectMeta = {
    id: randomId('project'),
    name: inferLegacyProjectName(),
    universe: 'mariage',
    createdAt: timestamp,
    updatedAt: timestamp,
    openedAt: timestamp,
    favorite: true,
    archived: false,
    trashed: false,
    status: 'draft',
    accent: ACCENTS[0],
  };
  projects = [project];
  writeProjectIndex(projects);
  localStorage.setItem(ACTIVE_PROJECT_KEY, project.id);

  for (const key of LEGACY_PROJECT_KEYS) {
    const value = localStorage.getItem(key);
    if (value != null) localStorage.setItem(projectStorageKey(project.id, key), value);
  }
  void flushProjectSave(project.id);
  return projects;
}

export function getProjects(): StudioProjectMeta[] {
  return ensureProjectWorkspace();
}

export function getFolders(): StudioFolder[] {
  return safeParse<StudioFolder[]>(localStorage.getItem(FOLDERS_KEY), []);
}

export function createFolder(name: string): StudioFolder {
  const folder: StudioFolder = { id: randomId('folder'), name: name.trim() || 'Nouveau dossier', createdAt: now() };
  const folders = [...getFolders(), folder];
  localStorage.setItem(FOLDERS_KEY, JSON.stringify(folders));
  window.dispatchEvent(new CustomEvent('lma:projects-changed'));
  return folder;
}

export function renameFolder(id: string, name: string) {
  const folders = getFolders().map((folder) => folder.id === id ? { ...folder, name: name.trim() || folder.name } : folder);
  localStorage.setItem(FOLDERS_KEY, JSON.stringify(folders));
  window.dispatchEvent(new CustomEvent('lma:projects-changed'));
}

export function deleteFolder(id: string) {
  localStorage.setItem(FOLDERS_KEY, JSON.stringify(getFolders().filter((folder) => folder.id !== id)));
  writeProjectIndex(getProjects().map((project) => project.folderId === id ? { ...project, folderId: undefined } : project));
}

export function getActiveProjectId(): string {
  const projects = ensureProjectWorkspace();
  return localStorage.getItem(ACTIVE_PROJECT_KEY) || projects[0].id;
}

export function getActiveProject(): StudioProjectMeta {
  const projects = ensureProjectWorkspace();
  const id = getActiveProjectId();
  return projects.find((project) => project.id === id) || projects[0];
}

export function setActiveProject(projectId: string) {
  const timestamp = now();
  const projects = getProjects().map((project) => project.id === projectId ? { ...project, openedAt: timestamp } : project);
  writeProjectIndex(projects);
  localStorage.setItem(ACTIVE_PROJECT_KEY, projectId);
}

export function createProject(input?: { name?: string; universe?: ProjectUniverse; folderId?: string }): StudioProjectMeta {
  const timestamp = now();
  const project: StudioProjectMeta = {
    id: randomId('project'),
    name: input?.name?.trim() || 'Projet sans titre',
    universe: input?.universe || 'libre',
    folderId: input?.folderId,
    createdAt: timestamp,
    updatedAt: timestamp,
    openedAt: timestamp,
    favorite: false,
    archived: false,
    trashed: false,
    status: 'draft',
    accent: ACCENTS[getProjects().length % ACCENTS.length],
  };
  writeProjectIndex([project, ...getProjects()]);
  setActiveProject(project.id);
  return project;
}

export function updateProject(projectId: string, patch: Partial<StudioProjectMeta>) {
  const timestamp = now();
  writeProjectIndex(getProjects().map((project) => project.id === projectId ? { ...project, ...patch, updatedAt: timestamp } : project));
}

export async function duplicateProject(projectId: string): Promise<StudioProjectMeta | null> {
  const source = getProjects().find((project) => project.id === projectId);
  if (!source) return null;
  const copy = createProject({ name: `${source.name} — copie`, universe: source.universe, folderId: source.folderId });
  const prefix = `${PROJECT_PREFIX}${projectId}:`;
  for (let index = 0; index < localStorage.length; index++) {
    const key = localStorage.key(index);
    if (!key?.startsWith(prefix)) continue;
    const shortKey = key.slice(prefix.length);
    const value = localStorage.getItem(key);
    if (value != null) localStorage.setItem(projectStorageKey(copy.id, shortKey), value);
  }
  await flushProjectSave(copy.id);
  return copy;
}

export async function permanentlyDeleteProject(projectId: string) {
  const prefix = `${PROJECT_PREFIX}${projectId}:`;
  const keys: string[] = [];
  for (let index = 0; index < localStorage.length; index++) {
    const key = localStorage.key(index);
    if (key?.startsWith(prefix)) keys.push(key);
  }
  keys.forEach((key) => localStorage.removeItem(key));
  writeProjectIndex(getProjects().filter((project) => project.id !== projectId));
  await deleteSnapshot(projectId);
  const remaining = getProjects();
  if (getActiveProjectId() === projectId && remaining.length) setActiveProject(remaining[0].id);
}

export function getProjectItem(key: string, projectId = getActiveProjectId()): string | null {
  return localStorage.getItem(projectStorageKey(projectId, key));
}

export function setProjectItem(key: string, value: string, projectId = getActiveProjectId()) {
  try {
    localStorage.setItem(projectStorageKey(projectId, key), value);
    touchProject(projectId);
    scheduleProjectSave(projectId);
  } catch (error) {
    emitSaveState(projectId, 'error', error instanceof Error ? error.message : 'Stockage local saturé');
  }
}

export function removeProjectItem(key: string, projectId = getActiveProjectId()) {
  localStorage.removeItem(projectStorageKey(projectId, key));
  touchProject(projectId);
  scheduleProjectSave(projectId);
}

export function collectProjectSnapshot(projectId = getActiveProjectId()): Record<string, string> {
  const prefix = `${PROJECT_PREFIX}${projectId}:`;
  const data: Record<string, string> = {};
  for (let index = 0; index < localStorage.length; index++) {
    const key = localStorage.key(index);
    if (!key?.startsWith(prefix)) continue;
    const value = localStorage.getItem(key);
    if (value != null) data[key.slice(prefix.length)] = value;
  }
  return data;
}

function touchProject(projectId: string) {
  const timestamp = now();
  const projects = getProjects();
  let changed = false;
  const next = projects.map((project) => {
    if (project.id !== projectId) return project;
    changed = true;
    return { ...project, updatedAt: timestamp };
  });
  if (changed) {
    localStorage.setItem(PROJECT_INDEX_KEY, JSON.stringify(next));
  }
}

function scheduleProjectSave(projectId: string) {
  emitSaveState(projectId, 'saving');
  const previous = saveTimers.get(projectId);
  if (previous) window.clearTimeout(previous);
  const timer = window.setTimeout(() => {
    saveTimers.delete(projectId);
    void flushProjectSave(projectId);
  }, 550);
  saveTimers.set(projectId, timer);
}

export async function flushProjectSave(projectId = getActiveProjectId()) {
  const previous = saveTimers.get(projectId);
  if (previous) {
    window.clearTimeout(previous);
    saveTimers.delete(projectId);
  }
  emitSaveState(projectId, 'saving');
  try {
    await putSnapshot(projectId, collectProjectSnapshot(projectId));
    touchProject(projectId);
    emitSaveState(projectId, 'saved');
  } catch (error) {
    emitSaveState(projectId, 'error', error instanceof Error ? error.message : 'Sauvegarde impossible');
  }
}

export async function hydrateProject(projectId: string) {
  setActiveProject(projectId);
  const prefix = `${PROJECT_PREFIX}${projectId}:`;
  let hasLocalData = false;
  for (let index = 0; index < localStorage.length; index++) {
    if (localStorage.key(index)?.startsWith(prefix)) { hasLocalData = true; break; }
  }
  if (hasLocalData) return;
  try {
    const snapshot = await getSnapshot(projectId);
    if (!snapshot) return;
    Object.entries(snapshot).forEach(([key, value]) => localStorage.setItem(projectStorageKey(projectId, key), value));
  } catch {
    // Local metadata remains usable even if IndexedDB is unavailable.
  }
}

export function subscribeToProjectSave(projectId: string, callback: (state: ProjectSaveState) => void) {
  const handler = (event: Event) => {
    const detail = (event as CustomEvent).detail as { projectId: string; state: ProjectSaveState };
    if (detail.projectId === projectId) callback(detail.state);
  };
  window.addEventListener(SAVE_EVENT, handler);
  return () => window.removeEventListener(SAVE_EVENT, handler);
}


const VALID_UNIVERSES: ProjectUniverse[] = ['mariage', 'evenement', 'site', 'association', 'prestataire', 'portfolio', 'libre'];

export function exportProjectBundle(projectId = getActiveProjectId()): StudioProjectBundle | null {
  const project = getProjects().find((item) => item.id === projectId);
  if (!project) return null;
  const { id: _id, createdAt: _createdAt, updatedAt: _updatedAt, openedAt: _openedAt, ...portableProject } = project;
  return {
    format: 'le-monde-aime-project',
    version: 1,
    exportedAt: now(),
    project: portableProject,
    data: collectProjectSnapshot(projectId),
  };
}

export function downloadProjectBundle(projectId = getActiveProjectId()) {
  const bundle = exportProjectBundle(projectId);
  if (!bundle) return;
  const safeName = bundle.project.name.replace(/[^a-z0-9à-ÿ_-]+/gi, '-').replace(/^-+|-+$/g, '') || 'projet';
  const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${safeName}.aime.json`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function importProjectBundle(raw: string): Promise<StudioProjectMeta> {
  const parsed = safeParse<Partial<StudioProjectBundle> | null>(raw, null);
  if (!parsed || parsed.format !== 'le-monde-aime-project' || parsed.version !== 1 || !parsed.project || !parsed.data || typeof parsed.data !== 'object') {
    throw new Error('Ce fichier ne contient pas un projet LE MONDE AIME valide.');
  }
  const universe = VALID_UNIVERSES.includes(parsed.project.universe as ProjectUniverse) ? parsed.project.universe as ProjectUniverse : 'libre';
  const project = createProject({
    name: `${String(parsed.project.name || 'Projet importé')} — import`,
    universe,
    folderId: parsed.project.folderId,
  });
  for (const [key, value] of Object.entries(parsed.data)) {
    if (typeof value === 'string') localStorage.setItem(projectStorageKey(project.id, key), value);
  }
  updateProject(project.id, {
    favorite: Boolean(parsed.project.favorite),
    status: parsed.project.status === 'published' ? 'published' : 'draft',
    accent: typeof parsed.project.accent === 'string' ? parsed.project.accent : project.accent,
  });
  await flushProjectSave(project.id);
  return getProjects().find((item) => item.id === project.id) || project;
}
