export interface PersistentMediaResult {
  url: string;
  persistent: boolean;
  optimized: boolean;
}

const MAX_INLINE_VIDEO_BYTES = 2_400_000;
const MAX_IMAGE_EDGE = 1800;

function readAsDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('Lecture du fichier impossible.'));
    reader.readAsDataURL(file);
  });
}

async function loadImage(file: File): Promise<ImageBitmap | HTMLImageElement> {
  try { return await createImageBitmap(file); } catch { /* Fallback for older browsers and unsupported formats. */ }
  const objectUrl = URL.createObjectURL(file);
  try {
    return await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('Image illisible.'));
      image.src = objectUrl;
    });
  } finally {
    globalThis.setTimeout(() => URL.revokeObjectURL(objectUrl), 0);
  }
}

async function optimizeImage(file: File): Promise<string> {
  const source = await loadImage(file);
  const sourceWidth = 'naturalWidth' in source ? source.naturalWidth : source.width;
  const sourceHeight = 'naturalHeight' in source ? source.naturalHeight : source.height;
  const ratio = Math.min(1, MAX_IMAGE_EDGE / Math.max(sourceWidth, sourceHeight));
  const width = Math.max(1, Math.round(sourceWidth * ratio));
  const height = Math.max(1, Math.round(sourceHeight * ratio));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  if (!context) return readAsDataUrl(file);
  context.drawImage(source as CanvasImageSource, 0, 0, width, height);
  if ('close' in source && typeof source.close === 'function') source.close();
  const webp = canvas.toDataURL('image/webp', .84);
  return webp.startsWith('data:image/webp') ? webp : canvas.toDataURL('image/jpeg', .84);
}

/**
 * Produces a URL that can be stored with the project. Images are resized and
 * inlined. Small videos are inlined. Large videos remain session-only until
 * a remote media library is connected.
 */
export async function fileToPersistentMedia(file: File): Promise<PersistentMediaResult> {
  if (file.type.startsWith('image/')) {
    try {
      return { url: await optimizeImage(file), persistent: true, optimized: true };
    } catch {
      return { url: await readAsDataUrl(file), persistent: true, optimized: false };
    }
  }
  if (file.size <= MAX_INLINE_VIDEO_BYTES) {
    return { url: await readAsDataUrl(file), persistent: true, optimized: false };
  }
  return { url: URL.createObjectURL(file), persistent: false, optimized: false };
}
