import { beforeEach, describe, expect, it } from 'vitest';
import {
  createProject,
  flushProjectSave,
  getActiveProjectId,
  getProjectItem,
  getProjects,
  hydrateProject,
  setProjectItem,
} from './projectStore';

const deleteProjectScopedLocalData = (projectId: string) => {
  const prefix = `lma_project:${projectId}:`;
  const keys: string[] = [];
  for (let index = 0; index < localStorage.length; index += 1) {
    const key = localStorage.key(index);
    if (key?.startsWith(prefix)) keys.push(key);
  }
  keys.forEach((key) => localStorage.removeItem(key));
};

describe('project lifecycle', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('creates, saves, removes local data, then restores the project snapshot', async () => {
    const project = createProject({ name: 'Test ouverture', universe: 'mariage' });
    setProjectItem('lma_setup', JSON.stringify({ brideFirstName: 'Lou', groomFirstName: 'Sam' }), project.id);
    await flushProjectSave(project.id);

    deleteProjectScopedLocalData(project.id);
    expect(getProjectItem('lma_setup', project.id)).toBeNull();

    await hydrateProject(project.id);

    expect(getActiveProjectId()).toBe(project.id);
    expect(getProjectItem('lma_setup', project.id)).toContain('Lou');
  });

  it('keeps project metadata usable when no secondary snapshot exists', async () => {
    const project = createProject({ name: 'Projet vide', universe: 'libre' });
    deleteProjectScopedLocalData(project.id);

    await expect(hydrateProject(project.id)).resolves.toBeUndefined();
    expect(getProjects().some((item) => item.id === project.id)).toBe(true);
    expect(getActiveProjectId()).toBe(project.id);
  });
});
