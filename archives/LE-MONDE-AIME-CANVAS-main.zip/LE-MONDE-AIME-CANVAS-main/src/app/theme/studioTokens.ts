export interface StudioTokens {
  app: string;
  surface: string;
  surface2: string;
  surface3: string;
  text: string;
  muted: string;
  faint: string;
  border: string;
  borderStrong: string;
  primary: string;
  primaryText: string;
  selection: string;
  danger: string;
  warning: string;
  success: string;
}

export function getStudioTokens(isDark: boolean): StudioTokens {
  return isDark
    ? {
        app: '#171718',
        surface: '#1B1B1D',
        surface2: '#252527',
        surface3: '#303033',
        text: '#F5F5F6',
        muted: 'rgba(245,245,246,.52)',
        faint: 'rgba(245,245,246,.28)',
        border: 'rgba(255,255,255,.09)',
        borderStrong: 'rgba(255,255,255,.16)',
        primary: '#F2F2F3',
        primaryText: '#151517',
        selection: '#D4D4D8',
        danger: '#F87171',
        warning: '#FBBF24',
        success: '#A3A3A8',
      }
    : {
        app: '#F0F0F1',
        surface: '#FAFAFB',
        surface2: '#F0F0F2',
        surface3: '#E5E5E7',
        text: '#151517',
        muted: 'rgba(21,21,23,.52)',
        faint: 'rgba(21,21,23,.28)',
        border: 'rgba(0,0,0,.09)',
        borderStrong: 'rgba(0,0,0,.16)',
        primary: '#151517',
        primaryText: '#FFFFFF',
        selection: '#3F3F46',
        danger: '#B42318',
        warning: '#8A6100',
        success: '#52525B',
      };
}
