import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast, Toaster } from 'sonner';
import { InfiniteCanvas } from './components/InfiniteCanvas';
import { Toolbar } from './components/Toolbar';
import { WorkspaceSidebar } from './components/WorkspaceSidebar';
import { ProjectDashboard } from './components/ProjectDashboard';
import { LotGroup } from './components/LotGroup';
import { getCardLayoutSize } from './components/CardStack';
import { LayoutPanel } from './components/LayoutPanel';
import { StudioAddPanel } from './components/StudioAddPanel';
import { StudioMediaPanel } from './components/StudioMediaPanel';
import type { MediaPatch } from './components/StudioMediaPanel';
import { StudioStylePanel } from './components/StudioStylePanel';
import { StudioPublishPanel } from './components/StudioPublishPanel';
import { CanvasElementNode } from './components/CanvasElementNode';
import { CanvasObjectFrame } from './components/CanvasObjectFrame';
import { CanvasPlane } from './components/CanvasPlane';
import type { CanvasPlaneSize } from './components/CanvasPlane';
import { TimelineView } from './components/TimelineView';
import { MiniSitePanel } from './components/MiniSitePanel';
import { MusicPlayerBar } from './components/MusicPlayerBar';
import { MiniSite } from './components/MiniSite';
import { AIAgent } from './components/AIAgent';
import { WeddingControlCenter } from './components/WeddingControlCenter';
import { buildWeddingProjectData, computeWeddingReadiness } from './domain/weddingProject';
import { WorldHub } from './components/WorldHub';
import { RemixProtocolMenu } from './components/RemixProtocolMenu';
import type { RemixActionId } from './components/RemixProtocolMenu';
import { CoverVariationPicker } from './components/CoverVariationPicker';
import { RemixPermissionsPanel } from './components/RemixPermissionsPanel';
import { AgentDotButton } from './components/AgentDotButton';
import type { AgentState } from './components/AgentDotButton';
import { UniversalCard } from './components/UniversalCard';
import type { SetupData } from './components/UniversalCard';
import { ProviderCard } from './components/ProviderCard';
import type { ProviderData } from './components/ProviderCard';
import { CanvasNote } from './components/CanvasNote';
import { CollaborativePlaylistPanel } from './components/CollaborativePlaylistPanel';
import type { PlaylistSuggestion } from './components/CollaborativePlaylistPanel';
import type { CanvasNoteData } from './components/CanvasNote';
import CommandPalette from './components/CommandPalette';
import MiniMap from './components/MiniMap';
import KioskMode from './components/KioskMode';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { PublicWeddingSite } from './public/PublicWeddingSite';
import { publishWedding } from './public/publicationService';
import { CloudAccountControl } from './components/CloudAccountControl';
import { AimeRainbowMark } from './components/AimeRainbowMark';
import { lots } from './data/lots';
import { exportToICS } from './utils/icsExport';
import { collectProjectSnapshot, ensureProjectWorkspace, flushProjectSave, getActiveProject, getProjectItem, getProjects, hydrateProject, setProjectItem, subscribeToProjectSave, updateProject } from './utils/projectStore';
import type { ProjectSaveState, StudioProjectMeta } from './utils/projectStore';
import type { CanvasTransform, Tool, BgSettings, TextSettings, CanvasPoint, CardLayoutMode, WorkspaceLayoutMode, CanvasSelectionSummary, StudioPanelKind, CanvasElementData, CanvasElementType, CanvasElementStyle, CanvasPlanId, CoverVariant, RemixHistoryEntry, RemixPermissions, RemixTarget } from './types';
import type { AnimationSettings } from './components/SettingsPanel';
import { Globe, Command, Home, PanelLeftOpen, Check, Cloud, CloudOff, Sparkles, Download } from 'lucide-react';

const DEFAULT_ANIM: AnimationSettings = {
  springDuration: 0.35, springBounce: 0.25,
  xSpringDuration: 0.5, xSpringBounce: 0.1,
  dragElastic: 0.7, swipeConfidenceThreshold: 10000, zIndexDelay: 0.05,
};

type ViewMode = 'canvas' | 'timeline' | 'minisite';
type Snapshot = Record<string, Record<string, any>>;
type SelectedObject =
  | { kind: 'element'; id: string }
  | { kind: 'plan'; id: CanvasPlanId }
  | { kind: 'entry'; id: 'couple' | 'provider' }
  | { kind: 'lot'; id: number }
  | { kind: 'note'; id: string }
  | null;

interface EntryCanvasState {
  visible: boolean;
  locked: boolean;
  zIndex: number;
}

const GRID_SIZE = 28;
const TIMELINE_PLANE: CanvasPlaneSize = { width: 620, height: 440 };
const MINISITE_PLANE: CanvasPlaneSize = { width: 560, height: 520 };
const DEFAULT_PLAN_POSITIONS: Record<'timeline' | 'minisite', CanvasPoint> = {
  timeline: { x: 760, y: 120 },
  minisite: { x: 760, y: 620 },
};

const DEFAULT_PLAN_COVERS: Record<CanvasPlanId, CoverVariant> = { timeline: 'original', minisite: 'original' };
const DEFAULT_REMIX_PERMISSIONS: RemixPermissions = {
  allowRemixes: true,
  allowMashups: true,
  allowComments: true,
  allowCommercialUse: false,
  requireAttribution: true,
  shareDesign: true,
  shareStructure: true,
  keepPrivateData: true,
};

function remixId(prefix = 'remix') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function coverStyleForElement(variant: CoverVariant, current: CanvasElementStyle): CanvasElementStyle {
  if (variant === 'editorial') return { ...current, background: '#F4EFE7', color: '#291D24', fontFamily: 'Cormorant Garamond', fontWeight: 500, borderRadius: 4, borderWidth: 1, borderColor: '#C79B78', shadow: 12 };
  if (variant === 'immersive') return { ...current, background: 'linear-gradient(145deg,#090B18,#442A73 65%,#0B1C29)', color: '#FFFFFF', fontFamily: 'Inter', fontWeight: 850, borderRadius: 28, borderWidth: 1, borderColor: 'rgba(255,180,106,.42)', shadow: 42 };
  if (variant === 'essential') return { ...current, background: '#FFFFFF', color: '#111318', fontFamily: 'Inter', fontWeight: 750, borderRadius: 14, borderWidth: 1, borderColor: '#D8DCE8', shadow: 8, blur: 0, opacity: 1 };
  return current;
}


const DEFAULT_SETUP: SetupData = {
  brideFirstName: '', groomFirstName: '', date: '', ceremonyTime: '',
  ceremonyVenue: '', receptionVenue: '', receptionCity: '',
  guestCount: 0, childCount: 0, diet: [], style: '',
  colorA: '#C4956A', colorB: '#A8B8C8', budget: 0,
  witnessA: '', witnessB: '',
};

const DEFAULT_PROVIDER: ProviderData = {
  companyName: '', contactName: '', category: '', city: '', serviceArea: '',
  email: '', phone: '', website: '', instagram: '', priceFrom: 0,
  description: '', availability: '', siret: '', acceptsOnlineBooking: true,
};

const DEFAULT_ENTRY_POSITIONS: Record<'couple' | 'provider', CanvasPoint> = {
  couple: { x: 390, y: 120 },
  provider: { x: 90, y: 120 },
};

const DEFAULT_ENTRY_STATES: Record<'couple' | 'provider', EntryCanvasState> = {
  couple: { visible: true, locked: false, zIndex: 100 },
  provider: { visible: true, locked: false, zIndex: 101 },
};

function defaultEntryStatesForUniverse(universe: StudioProjectMeta['universe']): Record<'couple' | 'provider', EntryCanvasState> {
  if (universe === 'mariage') return DEFAULT_ENTRY_STATES;
  if (universe === 'prestataire') return {
    couple: { ...DEFAULT_ENTRY_STATES.couple, visible: false },
    provider: { ...DEFAULT_ENTRY_STATES.provider, visible: true },
  };
  return {
    couple: { ...DEFAULT_ENTRY_STATES.couple, visible: false },
    provider: { ...DEFAULT_ENTRY_STATES.provider, visible: false },
  };
}

function seedRoleForUniverse(universe: StudioProjectMeta['universe']): CanvasElementData | null {
  const presets: Partial<Record<StudioProjectMeta['universe'], { content: string; roleKind: 'association' | 'artiste' | 'projet'; universe: string; subtitle: string }>> = {
    association: { content: 'Notre Association', roleKind: 'association', universe: 'Monde associatif', subtitle: 'Membres, missions, événements et ressources' },
    portfolio: { content: 'Mon Portfolio', roleKind: 'artiste', universe: 'Création & identité', subtitle: 'Projets, médias, récit et contacts' },
    evenement: { content: 'Notre Événement', roleKind: 'projet', universe: 'Événement', subtitle: 'Programme, équipe, public et orchestration' },
    site: { content: 'Notre Univers', roleKind: 'projet', universe: 'Site universel', subtitle: 'Pages, contenus, composants et publication' },
    libre: { content: 'Projet libre', roleKind: 'projet', universe: 'Univers libre', subtitle: 'Une intention à transformer avec le canvas et l’agent' },
  };
  const preset = presets[universe];
  return preset ? createCanvasElement('card', { x: 330, y: 300 }, preset) : null;
}

const DEFAULT_LOT_POSITION: CanvasPoint = { x: 120, y: 560 };

const DEFAULT_ELEMENT_STYLE: CanvasElementStyle = {
  background: 'rgba(255,255,255,.14)', color: '#ffffff', fontSize: 22, fontFamily: 'Inter', fontWeight: 700,
  textAlign: 'left', borderRadius: 18, opacity: 1, blur: 0, borderWidth: 0, borderColor: '#ffffff',
  shadow: 22, objectFit: 'cover', overlay: 'transparent',
};

const DEFAULT_TIMELINE_MEDIA: MediaPatch = {
  type: 'image', url: '', fit: 'cover', opacity: 1, blur: 0, overlay: 'rgba(10,10,11,.48)', muted: true, loop: true, playbackRate: 1,
};

function createCanvasElement(type: CanvasElementType, point: CanvasPoint, payload?: { url?: string; fileName?: string; content?: string; roleKind?: 'couple' | 'prestataire' | 'association' | 'artiste' | 'lieu' | 'entreprise' | 'personne' | 'projet'; universe?: string; subtitle?: string }): CanvasElementData {
  const sizes: Record<CanvasElementType, { width: number; height: number }> = {
    text: { width: 360, height: 120 }, image: { width: 420, height: 280 }, video: { width: 460, height: 280 },
    card: { width: 300, height: 420 }, button: { width: 190, height: 58 }, gallery: { width: 460, height: 320 },
    music: { width: 360, height: 150 }, note: { width: 220, height: 180 }, shape: { width: 260, height: 160 },
    section: { width: 620, height: 360 }, link: { width: 220, height: 58 }, embed: { width: 560, height: 360 },
  };
  const labels: Record<CanvasElementType, string> = {
    text: 'Votre texte', image: payload?.fileName || 'Image', video: payload?.fileName || 'Vidéo', card: payload?.content || 'Nouvelle carte',
    button: 'Découvrir', gallery: 'Galerie', music: 'Votre morceau', note: 'Nouvelle note', shape: '',
    section: 'Nouvelle section', link: 'Ouvrir le lien', embed: 'Contenu web',
  };
  const size = sizes[type];
  const background = type === 'shape' ? '#A3A3A8' : type === 'button' || type === 'link' ? '#A3A3A8' : type === 'note' ? '#FFF1A8' : DEFAULT_ELEMENT_STYLE.background;
  const color = type === 'note' ? '#2A2418' : '#ffffff';
  return {
    id: `element-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, type,
    x: point.x - size.width / 2, y: point.y - size.height / 2, width: size.width, height: size.height,
    content: labels[type], url: payload?.url || '', linkUrl: '', locked: false, hidden: false, zIndex: Date.now(),
    style: { ...DEFAULT_ELEMENT_STYLE, background: payload?.roleKind ? 'linear-gradient(145deg,rgba(24,24,26,.98),rgba(49,49,52,.94))' : background, color, textAlign: type === 'button' || type === 'link' ? 'center' : 'left', borderRadius: type === 'shape' ? 30 : type === 'button' || type === 'link' ? 50 : payload?.roleKind ? 24 : 18 },
    videoMuted: true, videoLoop: true, videoRate: 1,
    roleMeta: payload?.roleKind ? { kind: payload.roleKind, universe: payload.universe || 'Univers libre', subtitle: payload.subtitle || 'Carte de rôle connectée', connections: [] } : undefined,
  };
}

function readStored<T>(key: string, fallback: T): T {
  try {
    const raw = getProjectItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
}

function AppInner({ project, onExit }: { project: StudioProjectMeta; onExit: () => void }) {
  const { isDark } = useTheme();
  const { user } = useAuth();

  const [transform, setTransform] = useState<CanvasTransform>(() => {
    try {
      const saved = getProjectItem('lma_canvas_transform');
      if (saved) return JSON.parse(saved) as CanvasTransform;
    } catch { /* use default framing */ }
    const cx = window.innerWidth / 2 - 480;
    const cy = window.innerHeight / 2 - 300;
    return { x: cx, y: cy, scale: 1 };
  });
  const [activeTool, setActiveTool] = useState<Tool>('select');
  const [bgSettings, setBgSettings] = useState<BgSettings>(() => {
    try { return { type: 'color', value: isDark ? '#242426' : '#E8E8EA', ...JSON.parse(getProjectItem('lma_bg_settings') || '{}') } as BgSettings; }
    catch { return { type: 'color', value: isDark ? '#242426' : '#E8E8EA' }; }
  });
  useEffect(() => {
    const neutral = { type: 'color', value: isDark ? '#242426' : '#E8E8EA' } as BgSettings;
    const migrated = getProjectItem('lma_v85_neutral_migrated') === '1';
    const isNeutral = bgSettings.type === 'color' && ['#242426', '#E8E8EA'].includes(bgSettings.value);
    if (!migrated || isNeutral) {
      setBgSettings(neutral);
      setProjectItem('lma_bg_settings', JSON.stringify(neutral));
      setProjectItem('lma_v85_neutral_migrated', '1');
      window.dispatchEvent(new CustomEvent('lma-canvas-neutralize'));
    }
  }, [isDark]);

  const [textSettings, setTextSettings] = useState<TextSettings>(() => {
    try { return { size: 14, color: '#ffffff', ...JSON.parse(getProjectItem('lma_text_settings') || '{}') }; }
    catch { return { size: 14, color: '#ffffff' }; }
  });
  const [cardSettings, setCardSettings] = useState<Snapshot>(() => {
    try { return JSON.parse(getProjectItem('lma_card_settings') || '{}'); } catch { return {}; }
  });
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);

  // Setup data from universal card
  const [setupData, setSetupData] = useState<SetupData>(() => {
    const saved = getProjectItem('lma_setup');
    return saved ? { ...DEFAULT_SETUP, ...JSON.parse(saved) } : DEFAULT_SETUP;
  });
  const [setupComplete, setSetupComplete] = useState(() => !!getProjectItem('lma_setup_complete'));

  const [providerData, setProviderData] = useState<ProviderData>(() => {
    const saved = getProjectItem('lma_provider_setup');
    return saved ? { ...DEFAULT_PROVIDER, ...JSON.parse(saved) } : DEFAULT_PROVIDER;
  });
  const [providerComplete, setProviderComplete] = useState(() => !!getProjectItem('lma_provider_setup_complete'));

  const coupleName = setupData.brideFirstName && setupData.groomFirstName
    ? `${setupData.brideFirstName} & ${setupData.groomFirstName}`
    : 'Votre mariage';
  const weddingDate = setupData.date || 'Date à définir';

  // View modes — canvas remains the visual foundation.
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    const stored = getProjectItem('lma_view_mode');
    return stored === 'timeline' || stored === 'minisite' ? stored : 'canvas';
  });
  const canvasTransformRef = useRef<CanvasTransform>(transform);
  const previousViewModeRef = useRef<ViewMode>(viewMode);
  const [activeStudioPanel, setActiveStudioPanel] = useState<StudioPanelKind>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [saveState, setSaveState] = useState<ProjectSaveState>('saved');
  const [globalTexture, setGlobalTexture] = useState(() => getProjectItem('lma_global_texture') || '');
  const [miniSitePanelOpen, setMiniSitePanelOpen] = useState(false);
  const [selectedCards, setSelectedCards] = useState<Set<string>>(() => {
    try { return new Set(JSON.parse(getProjectItem('lma_selected_cards') || '[]')); } catch { return new Set(); }
  });
  const [canvasElements, setCanvasElements] = useState<CanvasElementData[]>(() => {
    try {
      const saved = getProjectItem('lma_canvas_elements');
      if (saved) return JSON.parse(saved);
    } catch { /* seed a clean canvas */ }
    const seeded = seedRoleForUniverse(project.universe);
    return seeded ? [seeded] : [];
  });
  const [selectedCanvasElementId, setSelectedCanvasElementId] = useState<string | null>(null);
  const [selectedObject, setSelectedObject] = useState<SelectedObject>(null);
  const [entryStates, setEntryStates] = useState<Record<'couple' | 'provider', EntryCanvasState>>(() => {
    const defaults = defaultEntryStatesForUniverse(project.universe);
    const saved = readStored<Record<'couple' | 'provider', EntryCanvasState>>('lma_entry_states', defaults);
    return {
      couple: { ...defaults.couple, ...(saved.couple || {}) },
      provider: { ...defaults.provider, ...(saved.provider || {}) },
    };
  });
  const [snapEnabled, setSnapEnabled] = useState(() => getProjectItem('lma_snap_enabled') !== '0');
  const [workspaceMode, setWorkspaceMode] = useState<WorkspaceLayoutMode>(() => (getProjectItem('lma_workspace_mode') as WorkspaceLayoutMode) || 'mosaic');
  const [lotLocks, setLotLocks] = useState<Record<number, boolean>>(() => readStored<Record<number, boolean>>('lma_lot_locks', {}));
  const [lotZIndexes, setLotZIndexes] = useState<Record<number, number>>(() => readStored<Record<number, number>>('lma_lot_z_indexes', {}));
  const [timelineMedia, setTimelineMedia] = useState<MediaPatch>(() => {
    try { return { ...DEFAULT_TIMELINE_MEDIA, ...JSON.parse(getProjectItem('lma_timeline_media') || '{}') }; } catch { return DEFAULT_TIMELINE_MEDIA; }
  });
  const [planPositions, setPlanPositions] = useState<Record<'timeline' | 'minisite', CanvasPoint>>(() => readStored('lma_plan_positions', DEFAULT_PLAN_POSITIONS));
  const [planSizes, setPlanSizes] = useState<Record<'timeline' | 'minisite', CanvasPlaneSize>>(() => readStored('lma_plan_sizes', { timeline: TIMELINE_PLANE, minisite: MINISITE_PLANE }));
  const [planCovers, setPlanCovers] = useState<Record<CanvasPlanId, CoverVariant>>(() => readStored('lma_plan_covers', DEFAULT_PLAN_COVERS));
  const [remixPermissions, setRemixPermissions] = useState<RemixPermissions>(() => readStored('lma_remix_permissions', DEFAULT_REMIX_PERMISSIONS));
  const [remixHistory, setRemixHistory] = useState<RemixHistoryEntry[]>(() => {
    try { return JSON.parse(getProjectItem('lma_remix_history') || '[]'); } catch { return []; }
  });
  const [remixMenu, setRemixMenu] = useState<{ x: number; y: number; target: RemixTarget } | null>(null);
  const [coverTarget, setCoverTarget] = useState<RemixTarget | null>(null);
  const [remixManagerOpen, setRemixManagerOpen] = useState(false);

  const [commandOpen, setCommandOpen] = useState(false);
  const [kioskOpen, setKioskOpen] = useState(false);
  const [checklistOpen, setChecklistOpen] = useState(false);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [totalBudget, setTotalBudget] = useState(() => Number(getProjectItem('lma_budget') || setupData.budget || 0));
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [playlistOpen, setPlaylistOpen] = useState(false);
  const [worldOpen, setWorldOpen] = useState(false);
  const [playlistSuggestions, setPlaylistSuggestions] = useState<PlaylistSuggestion[]>(() => {
    try { return JSON.parse(getProjectItem('lma_collaborative_playlist') || '[]'); } catch { return []; }
  });
  const [agentOpen, setAgentOpen] = useState(false);
  const [controlCenterOpen, setControlCenterOpen] = useState(() => project.universe === 'mariage' && getProjectItem('lma_wedding_control_seen') !== '1');
  const [publicationResult, setPublicationResult] = useState<{ url: string; liveUrl: string; mode: 'cloud' | 'local' } | null>(() => {
    try { return JSON.parse(getProjectItem('lma_publication_result') || 'null'); } catch { return null; }
  });
  const [agentThinking, setAgentThinking] = useState(false);
  const [agentHasMessage, setAgentHasMessage] = useState(false);
  const [activeLotId, setActiveLotId] = useState<number | null>(() => {
    const stored = getProjectItem('lma_active_lot_id');
    return stored == null || stored === '' || stored === 'null' ? null : Number(stored);
  });
  const [entryPositions, setEntryPositions] = useState<Record<'couple' | 'provider', CanvasPoint>>(() =>
    readStored('lma_entry_positions', DEFAULT_ENTRY_POSITIONS)
  );
  const [lotPositions, setLotPositions] = useState<Record<number, CanvasPoint>>(() =>
    readStored<Record<number, CanvasPoint>>('lma_lot_positions', {})
  );
  const [lotLayouts, setLotLayouts] = useState<Record<number, CardLayoutMode>>(() =>
    readStored<Record<number, CardLayoutMode>>('lma_lot_layouts', {})
  );
  const [notes, setNotes] = useState<CanvasNoteData[]>(() => {
    try {
      return JSON.parse(getProjectItem('lma_canvas_notes') || '[]');
    } catch {
      return [];
    }
  });

  const agentState: AgentState = agentOpen
    ? (agentThinking ? 'thinking' : 'open')
    : agentHasMessage
    ? 'notification'
    : 'idle';

  // Hero settings
  const [heroPhoto, setHeroPhoto] = useState(() => getProjectItem('lma_hero_photo') || '');
  const [heroMediaType, setHeroMediaType] = useState<'image' | 'video'>(() => (getProjectItem('lma_hero_media_type') as 'image' | 'video') || 'image');
  const [heroVenue, setHeroVenue] = useState(() => getProjectItem('lma_hero_venue') || '');
  const [heroCoupleName, setHeroCoupleName] = useState(() => getProjectItem('lma_hero_name') || '');
  const [heroDate, setHeroDate] = useState(() => getProjectItem('lma_hero_date') || '');
  const handleHeroChange = useCallback((field: string, value: string) => {
    if (field === 'photo') setHeroPhoto(value);
    else if (field === 'mediaType') setHeroMediaType(value === 'video' ? 'video' : 'image');
    else if (field === 'venue') setHeroVenue(value);
    else if (field === 'coupleName') setHeroCoupleName(value);
    else if (field === 'date') setHeroDate(value);
  }, []);

  const history = useRef<Snapshot[]>([{}]);
  const historyIndex = useRef(0);

  const [ChecklistPanel, setChecklistPanel] = useState<React.ComponentType<any> | null>(null);
  const [BudgetDashboard, setBudgetDashboard] = useState<React.ComponentType<any> | null>(null);
  const [TemplatesPanel, setTemplatesPanel] = useState<React.ComponentType<any> | null>(null);

  useEffect(() => {
    if (checklistOpen && !ChecklistPanel)
      import('./components/ChecklistPanel').then((m) => setChecklistPanel(() => m.ChecklistPanel));
  }, [checklistOpen]);
  useEffect(() => {
    if (budgetOpen && !BudgetDashboard)
      import('./components/BudgetDashboard').then((m) => setBudgetDashboard(() => m.BudgetDashboard));
  }, [budgetOpen]);
  useEffect(() => {
    if (templatesOpen && !TemplatesPanel)
      import('./components/TemplatesPanel').then((m) => setTemplatesPanel(() => m.TemplatesPanel));
  }, [templatesOpen]);

  useEffect(() => { setProjectItem('lma_budget', String(totalBudget)); }, [totalBudget]);
  useEffect(() => { setProjectItem('lma_bg_settings', JSON.stringify(bgSettings)); }, [bgSettings]);
  useEffect(() => { setProjectItem('lma_text_settings', JSON.stringify(textSettings)); }, [textSettings]);
  useEffect(() => { setProjectItem('lma_card_settings', JSON.stringify(cardSettings)); }, [cardSettings]);
  useEffect(() => { setProjectItem('lma_entry_positions', JSON.stringify(entryPositions)); }, [entryPositions]);
  useEffect(() => { setProjectItem('lma_entry_states', JSON.stringify(entryStates)); }, [entryStates]);
  useEffect(() => { setProjectItem('lma_snap_enabled', snapEnabled ? '1' : '0'); }, [snapEnabled]);
  useEffect(() => { setProjectItem('lma_workspace_mode', workspaceMode); }, [workspaceMode]);
  useEffect(() => { setProjectItem('lma_lot_locks', JSON.stringify(lotLocks)); }, [lotLocks]);
  useEffect(() => { setProjectItem('lma_lot_z_indexes', JSON.stringify(lotZIndexes)); }, [lotZIndexes]);
  useEffect(() => { setProjectItem('lma_lot_positions', JSON.stringify(lotPositions)); }, [lotPositions]);
  useEffect(() => { setProjectItem('lma_lot_layouts', JSON.stringify(lotLayouts)); }, [lotLayouts]);
  useEffect(() => { setProjectItem('lma_canvas_notes', JSON.stringify(notes)); }, [notes]);
  useEffect(() => { setProjectItem('lma_hero_photo', heroPhoto); }, [heroPhoto]);
  useEffect(() => { setProjectItem('lma_hero_media_type', heroMediaType); }, [heroMediaType]);
  useEffect(() => { setProjectItem('lma_hero_venue', heroVenue); }, [heroVenue]);
  useEffect(() => { setProjectItem('lma_hero_name', heroCoupleName); }, [heroCoupleName]);
  useEffect(() => { setProjectItem('lma_hero_date', heroDate); }, [heroDate]);
  useEffect(() => { setProjectItem('lma_collaborative_playlist', JSON.stringify(playlistSuggestions)); }, [playlistSuggestions]);
  useEffect(() => { setProjectItem('lma_canvas_elements', JSON.stringify(canvasElements)); }, [canvasElements]);
  useEffect(() => { setProjectItem('lma_timeline_media', JSON.stringify(timelineMedia)); }, [timelineMedia]);
  useEffect(() => { setProjectItem('lma_plan_positions', JSON.stringify(planPositions)); }, [planPositions]);
  useEffect(() => { setProjectItem('lma_plan_sizes', JSON.stringify(planSizes)); }, [planSizes]);
  useEffect(() => { setProjectItem('lma_plan_covers', JSON.stringify(planCovers)); }, [planCovers]);
  useEffect(() => { setProjectItem('lma_remix_permissions', JSON.stringify(remixPermissions)); }, [remixPermissions]);
  useEffect(() => { setProjectItem('lma_remix_history', JSON.stringify(remixHistory.slice(-100))); }, [remixHistory]);
  useEffect(() => { setProjectItem('lma_global_texture', globalTexture); }, [globalTexture]);
  useEffect(() => { const timer = window.setTimeout(() => setProjectItem('lma_canvas_transform', JSON.stringify(transform)), 220); return () => window.clearTimeout(timer); }, [transform]);
  useEffect(() => { setProjectItem('lma_view_mode', viewMode); }, [viewMode]);
  useEffect(() => { setProjectItem('lma_active_lot_id', activeLotId == null ? 'null' : String(activeLotId)); }, [activeLotId]);
  useEffect(() => { setProjectItem('lma_selected_cards', JSON.stringify(Array.from(selectedCards))); }, [selectedCards]);
  const weddingProjectData = useMemo(() => buildWeddingProjectData({
    setup: setupData,
    totalBudget,
    heroPhoto,
    heroMediaType,
    heroName: heroCoupleName,
    heroDate,
    heroVenue,
    selectedCardIds: Array.from(selectedCards),
  }), [heroCoupleName, heroDate, heroMediaType, heroPhoto, heroVenue, selectedCards, setupData, totalBudget]);
  const weddingReadiness = useMemo(() => computeWeddingReadiness(weddingProjectData, cardSettings), [cardSettings, weddingProjectData]);
  const publishCurrentWedding = useCallback(async () => {
    if (project.universe !== 'mariage') throw new Error('La publication publique V9.0 est actuellement finalisée pour le module Mariage.');
    const result = await publishWedding({ project, wedding: weddingProjectData, lots, cardSettings, user });
    const compact = { url: result.url, liveUrl: result.liveUrl, mode: result.mode };
    setPublicationResult(compact);
    setProjectItem('lma_publication_result', JSON.stringify(compact));
    if (result.mode === 'cloud') updateProject(project.id, { status: 'published' });
    return compact;
  }, [cardSettings, project, user, weddingProjectData]);
  useEffect(() => {
    if (project.universe === 'mariage') setProjectItem('lma_wedding_project_v1', JSON.stringify(weddingProjectData));
  }, [project.universe, weddingProjectData]);
  useEffect(() => subscribeToProjectSave(project.id, setSaveState), [project.id]);
  useEffect(() => {
    if (window.location.hash === '#playlist-invites') setPlaylistOpen(true);
  }, []);

  const selectCanvasObject = useCallback((object: SelectedObject) => {
    setActiveTool('select');
    setSelectedObject(object);
    setSelectedCanvasElementId(object?.kind === 'element' ? object.id : null);
    if (object?.kind === 'element') setActiveStudioPanel('style');
    else setActiveStudioPanel(null);
  }, []);

  const clearCanvasSelection = useCallback(() => {
    setSelectedObject(null);
    setSelectedCanvasElementId(null);
  }, []);

  const selectPlan = useCallback((id: CanvasPlanId) => {
    setViewMode(id);
    setSelectedObject({ kind: 'plan', id });
    setSelectedCanvasElementId(null);
    setActiveTool('select');
    if (id === 'minisite') setMiniSitePanelOpen(true);
  }, []);

  const openRemixMenu = useCallback((event: React.MouseEvent, target: RemixTarget) => {
    event.stopPropagation();
    setRemixMenu({ x: event.clientX + 4, y: event.clientY + 4, target });
  }, []);

  const addRemixHistory = useCallback((entry: Omit<RemixHistoryEntry, 'id' | 'createdAt'>) => {
    setRemixHistory((previous) => [...previous, { ...entry, id: remixId(), createdAt: new Date().toISOString() }].slice(-100));
  }, []);

  useEffect(() => {
    const previous = previousViewModeRef.current;
    if (previous === 'canvas' && viewMode !== 'canvas') canvasTransformRef.current = transform;
    if (viewMode === 'canvas' && previous !== 'canvas') {
      setTransform(canvasTransformRef.current);
    } else if (viewMode !== 'canvas') {
      const position = planPositions[viewMode];
      const size = planSizes[viewMode];
      const sidebarWidth = sidebarOpen ? 252 : 0;
      const availableWidth = Math.max(640, window.innerWidth - sidebarWidth - 80);
      const availableHeight = Math.max(440, window.innerHeight - 130);
      const scale = Math.max(.18, Math.min(.92, availableWidth / (size.width + 120), availableHeight / (size.height + 120)));
      setTransform({ x: sidebarWidth + 40 - position.x * scale, y: 82 - position.y * scale, scale });
      if (viewMode === 'minisite') setMiniSitePanelOpen(true);
      setActiveTool('select');
    }
    previousViewModeRef.current = viewMode;
  // Focus commands keep every plan mounted in the same universal canvas.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewMode]);


  const addCanvasNote = useCallback((point: CanvasPoint) => {
    const id = `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setNotes((prev) => [
      ...prev,
      {
        id,
        x: snapEnabled ? Math.round(point.x / GRID_SIZE) * GRID_SIZE : point.x,
        y: snapEnabled ? Math.round(point.y / GRID_SIZE) * GRID_SIZE : point.y,
        text: '',
        color: '#FFF1A8',
        locked: false,
        hidden: false,
        zIndex: Date.now(),
      },
    ]);
    selectCanvasObject({ kind: 'note', id });
    setActiveTool('select');
    toast.success('Note ajoutée au canevas.');
  }, [selectCanvasObject, snapEnabled]);

  const updateCanvasNote = useCallback((id: string, patch: Partial<CanvasNoteData>) => {
    setNotes((prev) => prev.map((note) => note.id === id ? { ...note, ...patch } : note));
  }, []);

  const deleteCanvasNote = useCallback((id: string) => {
    setNotes((prev) => prev.filter((note) => note.id !== id));
    setSelectedObject((current) => current?.kind === 'note' && current.id === id ? null : current);
  }, []);

  const duplicateCanvasNote = useCallback((id: string) => {
    setNotes((prev) => {
      const source = prev.find((note) => note.id === id);
      if (!source) return prev;
      const copyId = `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const copy = { ...source, id: copyId, x: source.x + GRID_SIZE, y: source.y + GRID_SIZE, locked: false, hidden: false, zIndex: Date.now() };
      selectCanvasObject({ kind: 'note', id: copyId });
      return [...prev, copy];
    });
  }, [selectCanvasObject]);

  const pushHistory = useCallback((snap: Snapshot) => {
    const next = history.current.slice(0, historyIndex.current + 1);
    next.push(snap);
    if (next.length > 80) next.shift();
    history.current = next;
    historyIndex.current = next.length - 1;
  }, []);

  const visibleCanvasCenter = useCallback((): CanvasPoint => ({
    x: (window.innerWidth / 2 - transform.x) / transform.scale,
    y: (window.innerHeight / 2 - transform.y) / transform.scale,
  }), [transform]);

  const addStudioElement = useCallback((type: CanvasElementType, payload?: { url?: string; fileName?: string; content?: string; roleKind?: 'couple' | 'prestataire' | 'association' | 'artiste' | 'lieu' | 'entreprise' | 'personne' | 'projet'; universe?: string; subtitle?: string }) => {
    const point = visibleCanvasCenter();
    if (type === 'note') {
      addCanvasNote(point);
      return;
    }
    const element = createCanvasElement(type, point, payload);
    setCanvasElements((prev) => [...prev, element]);
    selectCanvasObject({ kind: 'element', id: element.id });
    setActiveTool('select');
    toast.success(`${type === 'text' ? 'Texte' : type === 'image' ? 'Image' : type === 'video' ? 'Vidéo' : 'Élément'} ajouté au canevas.`);
  }, [addCanvasNote, selectCanvasObject, visibleCanvasCenter]);

  const updateCanvasElement = useCallback((id: string, patch: Partial<CanvasElementData>) => {
    setCanvasElements((prev) => prev.map((item) => item.id === id ? { ...item, ...patch } : item));
  }, []);

  const deleteCanvasElement = useCallback((id: string) => {
    setCanvasElements((prev) => prev.filter((item) => item.id !== id));
    setSelectedCanvasElementId((current) => current === id ? null : current);
    setSelectedObject((current) => current?.kind === 'element' && current.id === id ? null : current);
  }, []);

  const duplicateCanvasElement = useCallback((id: string) => {
    setCanvasElements((prev) => {
      const source = prev.find((item) => item.id === id);
      if (!source) return prev;
      const copy: CanvasElementData = { ...source, id: `element-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, x: source.x + 30, y: source.y + 30, zIndex: Date.now(), style: { ...source.style } };
      selectCanvasObject({ kind: 'element', id: copy.id });
      return [...prev, copy];
    });
  }, [selectCanvasObject]);

  const applyPatchToActiveLot = useCallback((patch: Record<string, unknown>) => {
    if (!activeLotId) return;
    const lot = lots.find((item) => item.id === activeLotId);
    if (!lot) return;
    setCardSettings((prev) => {
      const next = { ...prev };
      for (const card of lot.cards) next[card.id] = { ...(next[card.id] || {}), ...patch };
      pushHistory(next);
      return next;
    });
  }, [activeLotId, pushHistory]);

  const applyPatchToAllCards = useCallback((patch: Record<string, unknown>) => {
    setCardSettings((prev) => {
      const next = { ...prev };
      for (const lot of lots) {
        for (const card of lot.cards) next[card.id] = { ...(next[card.id] || {}), ...patch };
      }
      pushHistory(next);
      return next;
    });
  }, [pushHistory]);

  const applyMediaToActiveLot = useCallback((side: 'front' | 'back', patch: MediaPatch) => {
    const prefix = side === 'front' ? 'front' : 'back';
    applyPatchToActiveLot({
      [`${prefix}MediaType`]: patch.type,
      [`${prefix}MediaUrl`]: patch.url,
      [`${prefix}MediaFit`]: patch.fit,
      [`${prefix}Opacity`]: patch.opacity,
      [`${prefix}Blur`]: patch.blur,
      [`${prefix}Overlay`]: patch.overlay,
      [`${prefix}MediaMuted`]: patch.muted,
      [`${prefix}MediaLoop`]: patch.loop,
      [`${prefix}MediaRate`]: patch.playbackRate,
    });
    toast.success(`Média appliqué au ${side === 'front' ? 'recto' : 'verso'} du lot.`);
  }, [applyPatchToActiveLot]);

  const exportStudioProject = useCallback(() => ({
    format: 'le-monde-aime-canvas',
    version: 9.0,
    exportedAt: new Date().toISOString(),
    bgSettings, textSettings, cardSettings, setupData, setupComplete, providerData, providerComplete,
    selectedCards: Array.from(selectedCards), globalTexture, canvasElements, notes, entryPositions, entryStates, snapEnabled, workspaceMode, lotPositions, lotLayouts, lotLocks, lotZIndexes,
    heroPhoto, heroMediaType, heroVenue, heroCoupleName, heroDate, timelineMedia, playlistSuggestions, totalBudget, planPositions, planSizes, planCovers, remixPermissions, remixHistory,
    project: { name: project.name, universe: project.universe },
    storage: collectProjectSnapshot(project.id),
  }), [bgSettings, textSettings, cardSettings, setupData, setupComplete, providerData, providerComplete, selectedCards, globalTexture, canvasElements, notes, entryPositions, entryStates, snapEnabled, workspaceMode, lotPositions, lotLayouts, lotLocks, lotZIndexes, heroPhoto, heroMediaType, heroVenue, heroCoupleName, heroDate, timelineMedia, playlistSuggestions, totalBudget, planPositions, planSizes, planCovers, remixPermissions, remixHistory, project.id, project.name, project.universe]);

  const importStudioProject = useCallback((data: Record<string, any>) => {
    if (data.storage && typeof data.storage === 'object') {
      Object.entries(data.storage).forEach(([key, value]) => { if (typeof value === 'string') setProjectItem(key, value); });
    }
    if (data.bgSettings) setBgSettings(data.bgSettings);
    if (data.textSettings) setTextSettings(data.textSettings);
    if (data.cardSettings) setCardSettings(data.cardSettings);
    if (data.setupData) setSetupData({ ...DEFAULT_SETUP, ...data.setupData });
    if (typeof data.setupComplete === 'boolean') setSetupComplete(data.setupComplete);
    if (data.providerData) setProviderData({ ...DEFAULT_PROVIDER, ...data.providerData });
    if (typeof data.providerComplete === 'boolean') setProviderComplete(data.providerComplete);
    if (Array.isArray(data.selectedCards)) setSelectedCards(new Set(data.selectedCards));
    if (typeof data.globalTexture === 'string') setGlobalTexture(data.globalTexture);
    if (Array.isArray(data.canvasElements)) setCanvasElements(data.canvasElements);
    if (Array.isArray(data.notes)) setNotes(data.notes);
    if (data.entryPositions) setEntryPositions(data.entryPositions);
    if (data.entryStates) setEntryStates({ couple: { ...DEFAULT_ENTRY_STATES.couple, ...(data.entryStates.couple || {}) }, provider: { ...DEFAULT_ENTRY_STATES.provider, ...(data.entryStates.provider || {}) } });
    if (typeof data.snapEnabled === 'boolean') setSnapEnabled(data.snapEnabled);
    if (['mosaic','horizontal','vertical'].includes(data.workspaceMode)) setWorkspaceMode(data.workspaceMode);
    if (data.lotPositions) setLotPositions(data.lotPositions);
    if (data.lotLayouts) setLotLayouts(data.lotLayouts);
    if (data.lotLocks) setLotLocks(data.lotLocks);
    if (data.lotZIndexes) setLotZIndexes(data.lotZIndexes);
    if (typeof data.heroPhoto === 'string') setHeroPhoto(data.heroPhoto);
    if (data.heroMediaType === 'video' || data.heroMediaType === 'image') setHeroMediaType(data.heroMediaType);
    if (typeof data.heroVenue === 'string') setHeroVenue(data.heroVenue);
    if (typeof data.heroCoupleName === 'string') setHeroCoupleName(data.heroCoupleName);
    if (typeof data.heroDate === 'string') setHeroDate(data.heroDate);
    if (data.timelineMedia) setTimelineMedia({ ...DEFAULT_TIMELINE_MEDIA, ...data.timelineMedia });
    if (Array.isArray(data.playlistSuggestions)) setPlaylistSuggestions(data.playlistSuggestions);
    if (typeof data.totalBudget === 'number') setTotalBudget(data.totalBudget);
    if (data.planPositions) setPlanPositions({ ...DEFAULT_PLAN_POSITIONS, ...data.planPositions });
    if (data.planSizes) setPlanSizes({ timeline: { ...TIMELINE_PLANE, ...(data.planSizes.timeline || {}) }, minisite: { ...MINISITE_PLANE, ...(data.planSizes.minisite || {}) } });
    if (data.planCovers) setPlanCovers({ ...DEFAULT_PLAN_COVERS, ...data.planCovers });
    if (data.remixPermissions) setRemixPermissions({ ...DEFAULT_REMIX_PERMISSIONS, ...data.remixPermissions });
    if (Array.isArray(data.remixHistory)) setRemixHistory(data.remixHistory);
  }, []);

  const handleCardSettingChange = useCallback(
    (cardId: string, key: string, value: unknown) => {
      setCardSettings((prev) => {
        const next = { ...prev, [cardId]: { ...(prev[cardId] || {}), [key]: value } };
        pushHistory(next);
        return next;
      });
    },
    [pushHistory]
  );

  const undo = useCallback(() => {
    if (historyIndex.current > 0) {
      historyIndex.current--;
      setCardSettings(history.current[historyIndex.current]);
      toast.success('Annulé');
    }
  }, []);

  const redo = useCallback(() => {
    if (historyIndex.current < history.current.length - 1) {
      historyIndex.current++;
      setCardSettings(history.current[historyIndex.current]);
      toast.success('Rétabli');
    }
  }, []);

  const handleTogglePlay = useCallback((cardId: string) => {
    setPlayingTrackId((prev) => (prev === cardId ? null : cardId));
  }, []);

  const handleZoomChange = useCallback((delta: number) => {
    setTransform((t) => {
      const newScale = Math.max(0.15, Math.min(3, t.scale + delta));
      const cx = window.innerWidth / 2;
      const cy = window.innerHeight / 2;
      const ratio = newScale / t.scale;
      return { x: cx - (cx - t.x) * ratio, y: cy - (cy - t.y) * ratio, scale: newScale };
    });
  }, []);

  const handleToggleCard = useCallback((id: string) => {
    setSelectedCards((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const handleToggleLot = useCallback((lotId: number) => {
    const lot = lots.find((l) => l.id === lotId);
    if (!lot) return;
    const ids = lot.cards.map((c) => c.id);
    setSelectedCards((prev) => {
      const allSelected = ids.every((id) => prev.has(id));
      const next = new Set(prev);
      if (allSelected) ids.forEach((id) => next.delete(id));
      else ids.forEach((id) => next.add(id));
      return next;
    });
  }, []);

  const handleGenerateMiniSite = useCallback(() => {
    setMiniSitePanelOpen(false);
    setViewMode('minisite');
  }, []);


  const focusWorkspace = useCallback((
    lotId: number,
    entries: Record<'couple' | 'provider', CanvasPoint>,
    lotPosition: CanvasPoint,
    layoutMode: CardLayoutMode,
  ) => {
    const lot = lots.find((item) => item.id === lotId);
    if (!lot) return;
    const cardSize = getCardLayoutSize(lot.cards.length, layoutMode);
    const lotHeight = cardSize.height + 72;
    const visibleEntries = (['couple', 'provider'] as const)
      .filter((id) => entryStates[id].visible)
      .map((id) => ({ x: entries[id].x, y: entries[id].y, width: 260, height: 360 }));
    const boxes = [...visibleEntries, { x: lotPosition.x, y: lotPosition.y, width: Math.max(360, cardSize.width), height: lotHeight }];
    const minX = Math.min(...boxes.map((box) => box.x));
    const minY = Math.min(...boxes.map((box) => box.y));
    const maxX = Math.max(...boxes.map((box) => box.x + box.width));
    const maxY = Math.max(...boxes.map((box) => box.y + box.height));
    const contentWidth = Math.max(720, maxX - minX + 80);
    const contentHeight = Math.max(500, maxY - minY + 80);
    const availableWidth = Math.max(560, window.innerWidth - 130);
    const availableHeight = Math.max(420, window.innerHeight - 110);
    const scale = Math.max(0.24, Math.min(0.95, availableWidth / contentWidth, availableHeight / contentHeight));
    setTransform({
      x: 82 - minX * scale,
      y: 76 - minY * scale,
      scale,
    });
  }, [entryStates]);

  const navigateToLot = useCallback((lot: typeof lots[0]) => {
    const entries = entryPositions;
    const savedPosition = lotPositions[lot.id];
    const layoutMode = lotLayouts[lot.id] || 'horizontal';
    const lotSize = getCardLayoutSize(lot.cards.length, layoutMode);
    const visibleEntries = (['couple', 'provider'] as const)
      .filter((id) => entryStates[id].visible)
      .map((id) => ({ x: entries[id].x, y: entries[id].y, width: 260, height: 360 }));
    const intersectsEntry = (position: CanvasPoint) => visibleEntries.some((entry) => (
      position.x < entry.x + entry.width + 28 &&
      position.x + Math.max(360, lotSize.width) > entry.x - 28 &&
      position.y < entry.y + entry.height + 28 &&
      position.y + lotSize.height + 72 > entry.y - 28
    ));
    const rightEdge = visibleEntries.length ? Math.max(...visibleEntries.map((entry) => entry.x + entry.width)) : 112;
    const topEdge = visibleEntries.length ? Math.min(...visibleEntries.map((entry) => entry.y)) : 112;
    const automaticPosition = {
      x: snapEnabled ? Math.round((rightEdge + 56) / GRID_SIZE) * GRID_SIZE : rightEdge + 56,
      y: snapEnabled ? Math.round(topEdge / GRID_SIZE) * GRID_SIZE : topEdge,
    };
    const nextPosition = !savedPosition || intersectsEntry(savedPosition) ? automaticPosition : savedPosition;

    setViewMode('canvas');
    setActiveLotId(lot.id);
    setLotPositions((prev) => ({ ...prev, [lot.id]: nextPosition }));
    selectCanvasObject({ kind: 'lot', id: lot.id });
    setActiveTool('select');
    focusWorkspace(lot.id, entries, nextPosition, layoutMode);
  }, [entryPositions, entryStates, focusWorkspace, lotLayouts, lotPositions, selectCanvasObject, snapEnabled]);

  const getWorkspaceItems = useCallback(() => {
    const items: Array<{ key: string; kind: 'entry' | 'lot' | 'element' | 'note'; id: string; x: number; y: number; width: number; height: number }> = [];
    if (entryStates.couple.visible) items.push({ key: 'entry:couple', kind: 'entry', id: 'couple', ...entryPositions.couple, width: 260, height: 360 });
    if (entryStates.provider.visible) items.push({ key: 'entry:provider', kind: 'entry', id: 'provider', ...entryPositions.provider, width: 260, height: 360 });
    if (activeLotId != null) {
      const lot = lots.find((item) => item.id === activeLotId);
      if (lot) {
        const mode = lotLayouts[activeLotId] || 'horizontal';
        const size = getCardLayoutSize(lot.cards.length, mode);
        const position = lotPositions[activeLotId] || DEFAULT_LOT_POSITION;
        items.push({ key: `lot:${activeLotId}`, kind: 'lot', id: String(activeLotId), ...position, width: Math.max(360, size.width), height: size.height + 72 });
      }
    }
    canvasElements.filter((item) => !item.hidden).forEach((item) => items.push({ key: `element:${item.id}`, kind: 'element', id: item.id, x: item.x, y: item.y, width: item.width, height: item.height }));
    notes.filter((note) => !note.hidden).forEach((note) => items.push({ key: `note:${note.id}`, kind: 'note', id: note.id, x: note.x, y: note.y, width: 190, height: 150 }));
    return items;
  }, [activeLotId, canvasElements, entryPositions, entryStates, lotLayouts, lotPositions, notes]);

  const applyWorkspacePlacements = useCallback((placements: Array<{ key: string; x: number; y: number }>) => {
    const byKey = new Map(placements.map((item) => [item.key, item]));
    setEntryPositions((prev) => ({
      couple: byKey.has('entry:couple') ? { x: byKey.get('entry:couple')!.x, y: byKey.get('entry:couple')!.y } : prev.couple,
      provider: byKey.has('entry:provider') ? { x: byKey.get('entry:provider')!.x, y: byKey.get('entry:provider')!.y } : prev.provider,
    }));
    if (activeLotId != null) {
      const lotPlacement = byKey.get(`lot:${activeLotId}`);
      if (lotPlacement) setLotPositions((prev) => ({ ...prev, [activeLotId]: { x: lotPlacement.x, y: lotPlacement.y } }));
    }
    setCanvasElements((prev) => prev.map((item) => {
      const placement = byKey.get(`element:${item.id}`);
      return placement ? { ...item, x: placement.x, y: placement.y } : item;
    }));
    setNotes((prev) => prev.map((note) => {
      const placement = byKey.get(`note:${note.id}`);
      return placement ? { ...note, x: placement.x, y: placement.y } : note;
    }));
  }, [activeLotId]);

  const fitWorkspacePlacements = useCallback((items: Array<{ x: number; y: number; width: number; height: number }>) => {
    if (!items.length) return;
    const minX = Math.min(...items.map((item) => item.x));
    const minY = Math.min(...items.map((item) => item.y));
    const maxX = Math.max(...items.map((item) => item.x + item.width));
    const maxY = Math.max(...items.map((item) => item.y + item.height));
    const contentWidth = Math.max(520, maxX - minX + 120);
    const contentHeight = Math.max(420, maxY - minY + 120);
    const availableWidth = Math.max(600, window.innerWidth - 120);
    const availableHeight = Math.max(420, window.innerHeight - 105);
    const scale = Math.max(.2, Math.min(1, availableWidth / contentWidth, availableHeight / contentHeight));
    setTransform({ x: 72 - minX * scale, y: 72 - minY * scale, scale });
  }, []);

  const zoomToScale = useCallback((nextScale: number) => {
    setTransform((current) => {
      const scale = Math.max(.15, Math.min(3, nextScale));
      const cx = window.innerWidth / 2;
      const cy = window.innerHeight / 2;
      const ratio = scale / current.scale;
      return { x: cx - (cx - current.x) * ratio, y: cy - (cy - current.y) * ratio, scale };
    });
  }, []);

  const fitCurrentView = useCallback(() => {
    if (viewMode === 'canvas') {
      fitWorkspacePlacements(getWorkspaceItems());
      return;
    }
    const plane = viewMode === 'timeline' ? TIMELINE_PLANE : MINISITE_PLANE;
    const sideOffset = sidebarOpen ? 260 : 0;
    const availableWidth = Math.max(620, window.innerWidth - sideOffset - 92);
    const availableHeight = Math.max(420, window.innerHeight - 118);
    const scale = Math.max(.2, Math.min(.96, availableWidth / (plane.width + 168), availableHeight / (plane.height + 168)));
    setTransform({ x: sideOffset + 50 - 84 * scale, y: 68 - 84 * scale, scale });
  }, [fitWorkspacePlacements, getWorkspaceItems, sidebarOpen, viewMode]);


  const fitSelection = useCallback(() => {
    if (viewMode !== 'canvas' || !selectedObject) {
      fitCurrentView();
      return;
    }
    const key = `${selectedObject.kind}:${selectedObject.id}`;
    const item = getWorkspaceItems().find((entry) => entry.key === key);
    if (item) fitWorkspacePlacements([item]);
    else fitCurrentView();
  }, [fitCurrentView, fitWorkspacePlacements, getWorkspaceItems, selectedObject, viewMode]);

  const arrangeWorkspaceByMode = useCallback((mode: WorkspaceLayoutMode, announce = true) => {
    const source = getWorkspaceItems();
    if (!source.length) return;
    const gap = 56;
    const startX = 112;
    const startY = 112;
    const placements: Array<{ key: string; x: number; y: number; width: number; height: number }> = [];

    if (mode === 'horizontal') {
      let x = startX;
      source.forEach((item) => {
        placements.push({ ...item, x, y: startY });
        x += item.width + gap;
      });
    } else if (mode === 'vertical') {
      let y = startY;
      source.forEach((item) => {
        placements.push({ ...item, x: startX, y });
        y += item.height + gap;
      });
    } else {
      const rowLimit = 1480;
      let x = startX;
      let y = startY;
      let rowHeight = 0;
      source.forEach((item) => {
        if (x > startX && x + item.width > startX + rowLimit) {
          x = startX;
          y += rowHeight + gap;
          rowHeight = 0;
        }
        placements.push({ ...item, x, y });
        x += item.width + gap;
        rowHeight = Math.max(rowHeight, item.height);
      });
    }

    const snapped = placements.map((item) => ({
      ...item,
      x: snapEnabled ? Math.round(item.x / GRID_SIZE) * GRID_SIZE : item.x,
      y: snapEnabled ? Math.round(item.y / GRID_SIZE) * GRID_SIZE : item.y,
    }));
    applyWorkspacePlacements(snapped);
    fitWorkspacePlacements(snapped);
    setWorkspaceMode(mode);
    if (announce) toast.success(`Plan rangé en ${mode === 'mosaic' ? 'mosaïque' : mode === 'horizontal' ? 'horizontal' : 'vertical'}.`);
  }, [applyWorkspacePlacements, fitWorkspacePlacements, getWorkspaceItems, snapEnabled]);

  const arrangeWorkspace = useCallback(() => arrangeWorkspaceByMode(workspaceMode), [arrangeWorkspaceByMode, workspaceMode]);

  const alignWorkspaceTop = useCallback(() => {
    const items = getWorkspaceItems();
    if (!items.length) return;
    const top = Math.min(...items.map((item) => item.y));
    const placements = items.map((item) => ({ key: item.key, x: item.x, y: top }));
    applyWorkspacePlacements(placements);
    toast.success('Objets alignés en haut.');
  }, [applyWorkspacePlacements, getWorkspaceItems]);

  const alignWorkspaceCenter = useCallback(() => {
    const items = getWorkspaceItems();
    if (!items.length) return;
    const minY = Math.min(...items.map((item) => item.y));
    const maxY = Math.max(...items.map((item) => item.y + item.height));
    const axis = (minY + maxY) / 2;
    const placements = items.map((item) => ({ key: item.key, x: item.x, y: axis - item.height / 2 }));
    applyWorkspacePlacements(placements);
    toast.success('Objets centrés sur le même axe.');
  }, [applyWorkspacePlacements, getWorkspaceItems]);

  const distributeWorkspace = useCallback(() => {
    const items = [...getWorkspaceItems()].sort((a, b) => a.x - b.x);
    if (items.length < 2) return;
    const left = Math.min(...items.map((item) => item.x));
    const right = Math.max(...items.map((item) => item.x + item.width));
    const totalWidth = items.reduce((sum, item) => sum + item.width, 0);
    const gap = items.length > 1 ? Math.max(28, (right - left - totalWidth) / (items.length - 1)) : 0;
    let x = left;
    const placements = items.map((item) => {
      const placement = { key: item.key, x, y: item.y };
      x += item.width + gap;
      return placement;
    });
    applyWorkspacePlacements(placements);
    toast.success('Espacement horizontal redistribué.');
  }, [applyWorkspacePlacements, getWorkspaceItems]);

  const resetWorkspace = useCallback(() => {
    setEntryStates(defaultEntryStatesForUniverse(project.universe));
    setEntryPositions(DEFAULT_ENTRY_POSITIONS);
    setLotPositions({});
    setLotLayouts({});
    setLotLocks({});
    setLotZIndexes({});
    clearCanvasSelection();
    setWorkspaceMode('mosaic');
    setTransform({ x: window.innerWidth / 2 - 430, y: window.innerHeight / 2 - 300, scale: 1 });
    toast.success('Plan réinitialisé selon l’univers du projet.');
  }, [clearCanvasSelection, project.universe]);

  const changeActiveLotLayout = useCallback((mode: CardLayoutMode) => {
    if (activeLotId == null) return;
    const position = lotPositions[activeLotId] || DEFAULT_LOT_POSITION;
    setLotLayouts((prev) => ({ ...prev, [activeLotId]: mode }));
    focusWorkspace(activeLotId, entryPositions, position, mode);
  }, [activeLotId, entryPositions, focusWorkspace, lotPositions]);

  const updateActiveLotPosition = useCallback((position: CanvasPoint) => {
    if (activeLotId == null) return;
    setLotPositions((prev) => ({ ...prev, [activeLotId]: position }));
  }, [activeLotId]);

  const updateEntryPosition = useCallback((id: 'couple' | 'provider', position: CanvasPoint) => {
    setEntryPositions((prev) => ({ ...prev, [id]: position }));
  }, []);

  const removeEntryFromCanvas = useCallback((id: 'couple' | 'provider') => {
    setEntryStates((prev) => ({ ...prev, [id]: { ...prev[id], visible: false } }));
    setSelectedObject((current) => current?.kind === 'entry' && current.id === id ? null : current);
    toast.success(`${id === 'couple' ? 'Notre Mariage' : 'Prestataires'} retiré du canevas. Les données sont conservées.`);
  }, []);

  const restoreEntryToCanvas = useCallback((id: 'couple' | 'provider') => {
    setEntryStates((prev) => ({ ...prev, [id]: { ...prev[id], visible: true, locked: false, zIndex: Date.now() } }));
    setEntryPositions((prev) => ({ ...prev, [id]: DEFAULT_ENTRY_POSITIONS[id] }));
    selectCanvasObject({ kind: 'entry', id });
    toast.success(`${id === 'couple' ? 'Notre Mariage' : 'Prestataires'} restauré.`);
  }, [selectCanvasObject]);

  const duplicateEntryAsCard = useCallback((id: 'couple' | 'provider') => {
    const sourcePosition = entryPositions[id];
    const element = createCanvasElement('card', { x: sourcePosition.x + 410, y: sourcePosition.y + 210 });
    element.content = id === 'couple' ? (coupleName || 'Notre Mariage') : (providerData.companyName || 'Prestataire');
    element.style = {
      ...element.style,
      background: id === 'couple' ? 'linear-gradient(135deg,#C4956A,#F2D4AE)' : 'linear-gradient(135deg,#2F2F32,#73737A)',
      color: '#fff',
      borderRadius: 24,
    };
    setCanvasElements((prev) => [...prev, element]);
    selectCanvasObject({ kind: 'element', id: element.id });
    toast.success('Une copie éditable a été créée comme carte libre.');
  }, [coupleName, entryPositions, providerData.companyName, selectCanvasObject]);

  const handleSetupComplete = useCallback((data: SetupData) => {
    setSetupData(data);
    setProjectItem('lma_setup', JSON.stringify(data));
    setProjectItem('lma_setup_complete', '1');
    setSetupComplete(true);
    if (data.budget > 0) setTotalBudget(data.budget);
    if (data.brideFirstName && data.groomFirstName) updateProject(project.id, { name: `${data.brideFirstName} & ${data.groomFirstName}`, universe: 'mariage' });
    toast.success('Votre mariage est configuré ! Sélectionnez un lot dans le menu ▾');
  }, [project.id]);

  const handleProviderComplete = useCallback((data: ProviderData) => {
    setProviderData(data);
    setProjectItem('lma_provider_setup', JSON.stringify(data));
    setProjectItem('lma_provider_setup_complete', '1');
    setProviderComplete(true);
    if (project.universe === 'prestataire' && data.companyName) updateProject(project.id, { name: data.companyName });
    toast.success('Votre profil prestataire est enregistré.');
  }, [project.id, project.universe]);

  const closeWorkspacePanels = useCallback(() => {
    setChecklistOpen(false);
    setBudgetOpen(false);
    setTemplatesOpen(false);
    setMiniSitePanelOpen(false);
    setPlaylistOpen(false);
    setAgentOpen(false);
    setControlCenterOpen(false);
    setActiveStudioPanel(null);
  }, []);

  const openWorkspacePanel = useCallback((panel: StudioPanelKind | 'checklist' | 'budget' | 'templates' | 'minisite' | 'playlist' | 'agent' | 'control') => {
    closeWorkspacePanels();
    if (!panel) return;
    if (panel === 'checklist') setChecklistOpen(true);
    else if (panel === 'budget') setBudgetOpen(true);
    else if (panel === 'templates') setTemplatesOpen(true);
    else if (panel === 'minisite') setMiniSitePanelOpen(true);
    else if (panel === 'playlist') setPlaylistOpen(true);
    else if (panel === 'agent') setAgentOpen(true);
    else if (panel === 'control') { setControlCenterOpen(true); setProjectItem('lma_wedding_control_seen', '1'); }
    else setActiveStudioPanel(panel);
  }, [closeWorkspacePanels]);

  // V9.7: agent actions are declared only after all referenced callbacks are initialized.
  const handleAgentAction = useCallback((action: string) => {
    if (action === 'open-point-zero') { window.dispatchEvent(new CustomEvent('lma-point-zero-toggle', { detail: { open: true } })); return; }
    if (action === 'open-chromatic') { window.dispatchEvent(new CustomEvent('lma-chromatic-toggle', { detail: { open: true } })); return; }
    if (action.startsWith('navigate-lot:')) {
      const lotId = Number(action.split(':')[1]);
      const lot = lots.find((item) => item.id === lotId);
      if (lot) { setViewMode('canvas'); setActiveLotId(lot.id); setActiveTool('select'); toast.success(`Lot « ${lot.title} » ouvert.`); }
      return;
    }
    const agentTarget: RemixTarget = selectedObject?.kind === 'element'
      ? { kind: 'element', id: selectedObject.id, label: canvasElements.find((item) => item.id === selectedObject.id)?.content || 'Élément' }
      : selectedObject?.kind === 'plan'
        ? { kind: 'plan', id: selectedObject.id, label: selectedObject.id === 'minisite' ? 'Mini-site' : 'Timeline' }
        : selectedObject?.kind === 'entry'
          ? { kind: 'entry', id: selectedObject.id, label: selectedObject.id === 'couple' ? 'Notre Mariage' : 'Prestataires' }
          : viewMode === 'timeline'
            ? { kind: 'plan', id: 'timeline', label: 'Timeline' }
            : { kind: 'plan', id: 'minisite', label: 'Mini-site' };
    if (action === 'remix-cover') { setCoverTarget(agentTarget); return; }
    if (action === 'remix-inspiration') { setCoverTarget(agentTarget); toast.info('Choisissez une direction d’inspiration pour créer la variation.'); return; }
    if (action === 'remix-manage') { setRemixManagerOpen(true); return; }
    if (action === 'open-media') {
      setViewMode('canvas');
      openWorkspacePanel('media');
      return;
    }
    if (action === 'open-organize') {
      setViewMode('canvas');
      closeWorkspacePanels();
      if (project.universe === 'mariage') {
        selectCanvasObject({ kind: 'entry', id: 'couple' });
        fitWorkspacePlacements([{ x: entryPositions.couple.x, y: entryPositions.couple.y, width: 260, height: 360 }]);
        toast.info('Complétez la carte « Notre Mariage » : les champs manquants alimenteront la Timeline et le Mini-site.');
      } else openWorkspacePanel('organize');
      return;
    }
    if (action === 'open-minisite') {
      closeWorkspacePanels();
      setViewMode('minisite');
      return;
    }
    if (action === 'open-publish') {
      setViewMode('canvas');
      openWorkspacePanel('publish');
      return;
    }
    if (action === 'generate-minisite') {
      const wanted = new Set(['programme', 'venue', 'photo-video', 'catering', 'music-ceremony', 'music-soiree']);
      const used = new Set<string>();
      const generated = new Set<string>();
      for (const lot of lots) {
        for (const card of lot.cards) {
          if (!wanted.has(card.type) || used.has(card.type)) continue;
          generated.add(card.id);
          used.add(card.type);
        }
      }
      setSelectedCards(generated);
      setViewMode('minisite');
      setActiveStudioPanel(null);
      toast.success('Le mini-site a été connecté automatiquement aux cartes essentielles.');
      return;
    }
    if (action === 'generate-role') {
      const presets: Partial<Record<StudioProjectMeta['universe'], { content: string; roleKind: 'prestataire' | 'association' | 'artiste' | 'projet'; universe: string; subtitle: string }>> = {
        prestataire: { content: project.name, roleKind: 'prestataire', universe: 'Monde professionnel', subtitle: 'Profil, disponibilités, documents et réservations' },
        association: { content: project.name, roleKind: 'association', universe: 'Monde associatif', subtitle: 'Membres, missions, événements et ressources' },
        portfolio: { content: project.name, roleKind: 'artiste', universe: 'Création & identité', subtitle: 'Projets, médias, récit et contacts' },
        evenement: { content: project.name, roleKind: 'projet', universe: 'Événement', subtitle: 'Programme, équipe, public et orchestration' },
        site: { content: project.name, roleKind: 'projet', universe: 'Site universel', subtitle: 'Pages, contenus, composants et publication' },
        libre: { content: project.name, roleKind: 'projet', universe: 'Univers libre', subtitle: 'Une intention à transformer avec le canvas et l’agent' },
      };
      const preset = presets[project.universe];
      if (preset) {
        addStudioElement('card', preset);
        setViewMode('canvas');
        setActiveStudioPanel('style');
        toast.success('La carte de rôle a été générée dans le canvas.');
      }
    }
  }, [addStudioElement, canvasElements, closeWorkspacePanels, entryPositions.couple, fitWorkspacePlacements, openWorkspacePanel, project.name, project.universe, selectCanvasObject, selectedObject, viewMode]);

  const handleAction = useCallback(
    (action: string) => {
      switch (action) {
        case 'ics': case 'export-ics': exportToICS(coupleName, weddingDate, lots, cardSettings); break;
        case 'checklist': openWorkspacePanel('checklist'); break;
        case 'budget': openWorkspacePanel('budget'); break;
        case 'kiosk': closeWorkspacePanels(); setKioskOpen(true); break;
        case 'templates': openWorkspacePanel('templates'); break;
        case 'qr': case 'qr-code': toast.info('QR Code — disponible depuis le mini-site généré'); break;
      }
    },
    [cardSettings, closeWorkspacePanels, coupleName, openWorkspacePanel, weddingDate]
  );

  const activeLot = activeLotId != null ? lots.find((lot) => lot.id === activeLotId) : undefined;
  const selectedCanvasElement = selectedCanvasElementId ? canvasElements.find((item) => item.id === selectedCanvasElementId) || null : null;
  const activeLotLayout: CardLayoutMode = activeLotId != null ? (lotLayouts[activeLotId] || 'horizontal') : 'horizontal';
  const activeLotPosition = activeLotId != null ? (lotPositions[activeLotId] || DEFAULT_LOT_POSITION) : DEFAULT_LOT_POSITION;

  const selectedObjectSummary: CanvasSelectionSummary | null = (() => {
    if (!selectedObject) return null;
    if (selectedObject.kind === 'element') {
      const item = canvasElements.find((element) => element.id === selectedObject.id);
      return item ? { kind: 'element', id: item.id, label: item.content || item.type, locked: item.locked, hidden: item.hidden, canDuplicate: true } : null;
    }
    if (selectedObject.kind === 'plan') {
      return { kind: 'plan', id: selectedObject.id, label: selectedObject.id === 'minisite' ? 'Mini-site' : 'Timeline', locked: false, hidden: false, canDuplicate: true };
    }
    if (selectedObject.kind === 'entry') {
      const state = entryStates[selectedObject.id];
      return { kind: 'entry', id: selectedObject.id, label: selectedObject.id === 'couple' ? 'Notre Mariage' : 'Prestataires', locked: state.locked, hidden: !state.visible, canDuplicate: true };
    }
    if (selectedObject.kind === 'note') {
      const note = notes.find((item) => item.id === selectedObject.id);
      return note ? { kind: 'note', id: note.id, label: note.text || 'Note', locked: !!note.locked, hidden: !!note.hidden, canDuplicate: true } : null;
    }
    if (selectedObject.kind === 'lot') {
      const lot = lots.find((item) => item.id === selectedObject.id);
      return lot ? { kind: 'lot', id: String(lot.id), label: lot.title, locked: !!lotLocks[lot.id], hidden: activeLotId !== lot.id, canDuplicate: false } : null;
    }
    return null;
  })();

  const sidebarEntryLayers: CanvasSelectionSummary[] = project.universe === 'mariage'
    ? [
        { kind: 'entry', id: 'couple', label: 'Notre Mariage', locked: entryStates.couple.locked, hidden: !entryStates.couple.visible, canDuplicate: true },
        { kind: 'entry', id: 'provider', label: 'Prestataires', locked: entryStates.provider.locked, hidden: !entryStates.provider.visible, canDuplicate: true },
      ]
    : project.universe === 'prestataire'
      ? [{ kind: 'entry', id: 'provider', label: 'Profil prestataire', locked: entryStates.provider.locked, hidden: !entryStates.provider.visible, canDuplicate: true }]
      : [];
  const sidebarLayers: CanvasSelectionSummary[] = [
    { kind: 'plan', id: 'timeline', label: 'Timeline', locked: false, hidden: false, canDuplicate: true },
    { kind: 'plan', id: 'minisite', label: 'Mini-site', locked: false, hidden: false, canDuplicate: true },
    ...sidebarEntryLayers,
    ...(activeLot ? [{ kind: 'lot' as const, id: String(activeLot.id), label: activeLot.title, locked: !!lotLocks[activeLot.id], hidden: false }] : []),
    ...canvasElements.map((item) => ({ kind: 'element' as const, id: item.id, label: item.content || item.type, locked: item.locked, hidden: item.hidden, canDuplicate: true })),
    ...notes.map((note) => ({ kind: 'note' as const, id: note.id, label: note.text || 'Post-it', locked: !!note.locked, hidden: !!note.hidden, canDuplicate: true })),
  ];
  const selectedSidebarKey = selectedObject ? `${selectedObject.kind}:${selectedObject.id}` : null;
  const mediaAssets = canvasElements.filter((item) => ['image', 'video', 'music', 'gallery'].includes(item.type));

  const selectSidebarLayer = (layer: CanvasSelectionSummary) => {
    setViewMode('canvas');
    setActiveTool('select');
    if (layer.kind === 'plan') {
      selectPlan(layer.id as CanvasPlanId);
    } else if (layer.kind === 'entry') {
      const id = layer.id as 'couple' | 'provider';
      if (!entryStates[id].visible) restoreEntryToCanvas(id);
      selectCanvasObject({ kind: 'entry', id });
      fitWorkspacePlacements([{ key: `entry:${id}`, x: entryPositions[id].x, y: entryPositions[id].y, width: 260, height: 360 }]);
    } else if (layer.kind === 'element') {
      const item = canvasElements.find((element) => element.id === layer.id);
      if (item?.hidden) updateCanvasElement(item.id, { hidden: false });
      selectCanvasObject({ kind: 'element', id: layer.id });
      if (item) fitWorkspacePlacements([{ key: `element:${item.id}`, x: item.x, y: item.y, width: item.width, height: item.height }]);
    } else if (layer.kind === 'note') {
      const note = notes.find((item) => item.id === layer.id);
      if (note?.hidden) updateCanvasNote(note.id, { hidden: false });
      selectCanvasObject({ kind: 'note', id: layer.id });
      if (note) fitWorkspacePlacements([{ key: `note:${note.id}`, x: note.x, y: note.y, width: 220, height: 180 }]);
    } else if (layer.kind === 'lot') {
      const lot = lots.find((item) => item.id === Number(layer.id));
      if (lot) navigateToLot(lot);
    }
  };

  const toggleSidebarLayerVisibility = (layer: CanvasSelectionSummary) => {
    if (layer.kind === 'plan') {
      toast.info('Les plans maîtres restent visibles dans le canvas unique.');
    } else if (layer.kind === 'entry') {
      const id = layer.id as 'couple' | 'provider';
      if (entryStates[id].visible) removeEntryFromCanvas(id); else restoreEntryToCanvas(id);
    } else if (layer.kind === 'element') {
      const item = canvasElements.find((element) => element.id === layer.id);
      if (item) updateCanvasElement(item.id, { hidden: !item.hidden });
    } else if (layer.kind === 'note') {
      const note = notes.find((item) => item.id === layer.id);
      if (note) updateCanvasNote(note.id, { hidden: !note.hidden });
    } else if (layer.kind === 'lot') {
      if (activeLotId === Number(layer.id)) setActiveLotId(null);
      else {
        const lot = lots.find((item) => item.id === Number(layer.id));
        if (lot) navigateToLot(lot);
      }
    }
  };

  const duplicateSelectedObject = useCallback(() => {
    if (!selectedObject) return;
    if (selectedObject.kind === 'element') duplicateCanvasElement(selectedObject.id);
    else if (selectedObject.kind === 'entry') duplicateEntryAsCard(selectedObject.id);
    else if (selectedObject.kind === 'note') duplicateCanvasNote(selectedObject.id);
  }, [duplicateCanvasElement, duplicateCanvasNote, duplicateEntryAsCard, selectedObject]);

  const deleteSelectedObject = useCallback(() => {
    if (!selectedObject) return;
    if (selectedObject.kind === 'element') deleteCanvasElement(selectedObject.id);
    else if (selectedObject.kind === 'entry') removeEntryFromCanvas(selectedObject.id);
    else if (selectedObject.kind === 'note') deleteCanvasNote(selectedObject.id);
    else if (selectedObject.kind === 'lot') { setActiveLotId(null); clearCanvasSelection(); toast.success('Lot retiré du canevas. Il reste disponible dans le menu.'); }
  }, [clearCanvasSelection, deleteCanvasElement, deleteCanvasNote, removeEntryFromCanvas, selectedObject]);

  const toggleSelectedObjectLock = useCallback(() => {
    if (!selectedObject) return;
    if (selectedObject.kind === 'element') {
      const item = canvasElements.find((element) => element.id === selectedObject.id);
      if (item) updateCanvasElement(item.id, { locked: !item.locked });
    } else if (selectedObject.kind === 'entry') {
      setEntryStates((prev) => ({ ...prev, [selectedObject.id]: { ...prev[selectedObject.id], locked: !prev[selectedObject.id].locked } }));
    } else if (selectedObject.kind === 'note') {
      const note = notes.find((item) => item.id === selectedObject.id);
      if (note) updateCanvasNote(note.id, { locked: !note.locked });
    } else if (selectedObject.kind === 'lot') {
      setLotLocks((prev) => ({ ...prev, [selectedObject.id]: !prev[selectedObject.id] }));
    }
  }, [canvasElements, notes, selectedObject, updateCanvasElement, updateCanvasNote]);

  const toggleSelectedObjectHidden = useCallback(() => {
    if (!selectedObject) return;
    if (selectedObject.kind === 'element') {
      const item = canvasElements.find((element) => element.id === selectedObject.id);
      if (item) updateCanvasElement(item.id, { hidden: !item.hidden });
    } else if (selectedObject.kind === 'entry') {
      setEntryStates((prev) => ({ ...prev, [selectedObject.id]: { ...prev[selectedObject.id], visible: !prev[selectedObject.id].visible } }));
    } else if (selectedObject.kind === 'note') {
      const note = notes.find((item) => item.id === selectedObject.id);
      if (note) updateCanvasNote(note.id, { hidden: !note.hidden });
    } else if (selectedObject.kind === 'lot') {
      setActiveLotId(null);
      clearCanvasSelection();
    }
  }, [canvasElements, clearCanvasSelection, notes, selectedObject, updateCanvasElement, updateCanvasNote]);

  const moveSelectedObjectLayer = useCallback((direction: 'front' | 'back') => {
    if (!selectedObject) return;
    const allZ = [
      ...canvasElements.map((item) => item.zIndex),
      ...notes.map((item) => item.zIndex || 20),
      ...(Object.values(entryStates) as EntryCanvasState[]).map((item) => item.zIndex),
      ...Object.values(lotZIndexes),
    ];
    const zIndex = direction === 'front' ? Math.max(Date.now(), ...allZ.map((value) => value + 1)) : Math.min(1, ...allZ.map((value) => value - 1));
    if (selectedObject.kind === 'element') updateCanvasElement(selectedObject.id, { zIndex });
    else if (selectedObject.kind === 'entry') setEntryStates((prev) => ({ ...prev, [selectedObject.id]: { ...prev[selectedObject.id], zIndex } }));
    else if (selectedObject.kind === 'note') updateCanvasNote(selectedObject.id, { zIndex });
    else if (selectedObject.kind === 'lot') setLotZIndexes((prev) => ({ ...prev, [selectedObject.id]: zIndex }));
  }, [canvasElements, entryStates, lotZIndexes, notes, selectedObject, updateCanvasElement, updateCanvasNote]);


  const downloadStudioProject = useCallback(() => {
    const data = JSON.stringify(exportStudioProject(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `le-monde-aime-${project.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'projet'}-v8.7.aime.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success('Projet AIME exporté.');
  }, [exportStudioProject, project.name]);

  const applyCoverVariant = useCallback((variant: CoverVariant) => {
    const target = coverTarget;
    if (!target) return;
    if (target.kind === 'plan') {
      const id = target.id as CanvasPlanId;
      const before = planCovers[id] || 'original';
      if (before === variant) { setCoverTarget(null); return; }
      setPlanCovers((previous) => ({ ...previous, [id]: variant }));
      addRemixHistory({ action: 'cover', target, before: { coverVariant: before }, after: { coverVariant: variant }, label: `Cover ${variant}` });
      toast.success(`Cover « ${variant} » appliqué à ${target.label}.`);
    } else if (target.kind === 'element') {
      const element = canvasElements.find((item) => item.id === target.id);
      if (!element) return;
      const sourceStyle = element.remixSourceStyle || element.style;
      const nextStyle = variant === 'original' ? sourceStyle : coverStyleForElement(variant, sourceStyle);
      updateCanvasElement(element.id, { style: nextStyle, coverVariant: variant, remixSourceStyle: sourceStyle });
      addRemixHistory({ action: 'cover', target, before: { style: element.style, coverVariant: element.coverVariant || 'original', remixSourceStyle: element.remixSourceStyle }, after: { style: nextStyle, coverVariant: variant, remixSourceStyle: sourceStyle }, label: `Cover ${variant}` });
      toast.success(`Cover « ${variant} » appliqué à l’élément.`);
    } else {
      toast.info('Transformez d’abord cette carte en élément du canvas pour lui appliquer un Cover visuel.');
    }
    setCoverTarget(null);
  }, [addRemixHistory, canvasElements, coverTarget, planCovers, updateCanvasElement]);

  const undoLastRemix = useCallback(() => {
    const entry = remixHistory[remixHistory.length - 1];
    if (!entry) { toast.info('Aucun remix à annuler.'); return; }
    if (entry.target.kind === 'plan') {
      const id = entry.target.id as CanvasPlanId;
      if (entry.before.coverVariant) setPlanCovers((previous) => ({ ...previous, [id]: entry.before.coverVariant as CoverVariant }));
      if (entry.before.size) setPlanSizes((previous) => ({ ...previous, [id]: entry.before.size as CanvasPlaneSize }));
    } else if (entry.target.kind === 'element') {
      if (entry.after.created === true && Object.keys(entry.before).length === 0) {
        setCanvasElements((previous) => previous.filter((item) => item.id !== entry.target.id));
        if (selectedObject?.kind === 'element' && selectedObject.id === entry.target.id) clearCanvasSelection();
      } else {
        const patch: Partial<CanvasElementData> = {};
        if ('style' in entry.before) patch.style = entry.before.style as CanvasElementStyle;
        if ('coverVariant' in entry.before) patch.coverVariant = entry.before.coverVariant as CoverVariant;
        if ('remixSourceStyle' in entry.before) patch.remixSourceStyle = entry.before.remixSourceStyle as CanvasElementStyle | undefined;
        if ('width' in entry.before) patch.width = Number(entry.before.width);
        if ('height' in entry.before) patch.height = Number(entry.before.height);
        if ('content' in entry.before) patch.content = String(entry.before.content ?? '');
        updateCanvasElement(entry.target.id, patch);
      }
    }
    setRemixHistory((previous) => previous.slice(0, -1));
    toast.success('Dernière transformation annulée.');
  }, [clearCanvasSelection, remixHistory, selectedObject, updateCanvasElement]);

  const handleRemixAction = useCallback((action: RemixActionId, target: RemixTarget) => {
    if (action === 'cover') {
      setCoverTarget(target);
      return;
    }
    if (action === 'reuse-recipe') {
      const recipe = {
        protocol: 'AIME Project DNA', version: 1,
        source: { project: project.name, universe: project.universe, target },
        canvas: target.kind === 'plan' ? { size: planSizes[target.id as CanvasPlanId], cover: planCovers[target.id as CanvasPlanId] } : undefined,
        permissions: { design: remixPermissions.shareDesign, structure: remixPermissions.shareStructure, privateDataExcluded: remixPermissions.keepPrivateData },
      };
      void navigator.clipboard.writeText(JSON.stringify(recipe, null, 2))
        .then(() => toast.success('Recette / ADN copiée.'))
        .catch(() => toast.info('Copie automatique indisponible : exportez le projet AIME JSON.'));
      return;
    }
    if (action === 'mashup') {
      const point = visibleCanvasCenter();
      const element = createCanvasElement('section', point, { content: `Mashup · ${target.label} × ${project.name}` });
      element.style = coverStyleForElement('immersive', element.style);
      element.width = 620;
      element.height = 300;
      element.coverVariant = 'immersive';
      setCanvasElements((previous) => [...previous, element]);
      selectCanvasObject({ kind: 'element', id: element.id });
      addRemixHistory({ action: 'inspiration', target: { kind: 'element', id: element.id, label: element.content }, before: {}, after: { created: true }, label: 'Mashup créé' });
      setViewMode('canvas');
      toast.success('Une branche Mashup a été créée dans le canvas.');
      return;
    }
    if (action === 'inspiration') {
      if (target.kind === 'plan') {
        setCoverTarget(target);
        return;
      }
      if (target.kind === 'element') {
        const source = canvasElements.find((item) => item.id === target.id);
        if (!source) return;
        const copy: CanvasElementData = {
          ...source,
          id: remixId('inspiration'), x: source.x + source.width + 56, y: source.y,
          locked: false, hidden: false, zIndex: Date.now(),
          remixSourceStyle: { ...source.style }, coverVariant: 'editorial',
          style: coverStyleForElement('editorial', source.style),
          content: `${source.content} — inspiration`,
        };
        setCanvasElements((previous) => [...previous, copy]);
        selectCanvasObject({ kind: 'element', id: copy.id });
        addRemixHistory({ action: 'inspiration', target: { kind: 'element', id: copy.id, label: copy.content }, before: {}, after: { created: true }, label: 'Variation inspirée' });
        toast.success('Une variation originale a été placée à côté de la source.');
      }
      return;
    }
    if (action === 'extend' || action === 'crop') {
      const factor = action === 'extend' ? 1.24 : .8;
      if (target.kind === 'plan') {
        const id = target.id as CanvasPlanId;
        const before = planSizes[id];
        const after = { width: before.width, height: Math.max(420, Math.round(before.height * factor)) };
        setPlanSizes((previous) => ({ ...previous, [id]: after }));
        addRemixHistory({ action, target, before: { size: before }, after: { size: after }, label: action === 'extend' ? 'Plan prolongé' : 'Plan recadré' });
      } else if (target.kind === 'element') {
        const element = canvasElements.find((item) => item.id === target.id);
        if (!element) return;
        const after = { width: Math.max(100, Math.round(element.width * (action === 'extend' ? 1.12 : .86))), height: Math.max(64, Math.round(element.height * factor)) };
        updateCanvasElement(element.id, after);
        addRemixHistory({ action, target, before: { width: element.width, height: element.height }, after, label: action === 'extend' ? 'Élément prolongé' : 'Élément recadré' });
      }
      toast.success(action === 'extend' ? 'La création a été prolongée.' : 'La création a été recadrée.');
      return;
    }
    if (action === 'reverse') {
      if (target.kind === 'plan') {
        const id = target.id as CanvasPlanId;
        const before = planSizes[id];
        const after = { width: before.height, height: before.width };
        setPlanSizes((previous) => ({ ...previous, [id]: after }));
        addRemixHistory({ action: 'reverse', target, before: { size: before }, after: { size: after }, label: 'Format inversé' });
      } else if (target.kind === 'element') {
        const element = canvasElements.find((item) => item.id === target.id);
        if (!element) return;
        const nextAlign = element.style.textAlign === 'left' ? 'right' : element.style.textAlign === 'right' ? 'left' : 'center';
        const nextStyle = { ...element.style, textAlign: nextAlign as CanvasElementStyle['textAlign'] };
        updateCanvasElement(element.id, { style: nextStyle });
        addRemixHistory({ action: 'reverse', target, before: { style: element.style }, after: { style: nextStyle }, label: 'Composition inversée' });
      }
      toast.success('Composition inversée.');
      return;
    }
    if (action === 'replace') {
      if (target.kind === 'plan') { setCoverTarget(target); return; }
      if (target.kind === 'element') {
        const element = canvasElements.find((item) => item.id === target.id);
        if (!element) return;
        const content = element.type === 'text' || element.type === 'section'
          ? `Nouvelle variation générée pour ${project.name}`
          : element.content;
        updateCanvasElement(element.id, { content, style: coverStyleForElement('essential', element.style), coverVariant: 'essential', remixSourceStyle: element.remixSourceStyle || element.style });
        addRemixHistory({ action: 'inspiration', target, before: { content: element.content, style: element.style }, after: { content }, label: 'Section remplacée' });
        toast.success('La section a été remplacée sans toucher au reste.');
      }
      return;
    }
    if (action === 'duplicate') {
      if (target.kind === 'element') duplicateCanvasElement(target.id);
      else if (target.kind === 'entry') duplicateEntryAsCard(target.id as 'couple' | 'provider');
      else if (target.kind === 'note') duplicateCanvasNote(target.id);
      else if (target.kind === 'plan') setCoverTarget(target);
      else toast.info('Ce lot reste relié à sa source et ne se duplique pas encore.');
      return;
    }
    if (action === 'publish') {
      updateProject(project.id, { status: 'published' });
      toast.success('Projet marqué comme publié.');
      return;
    }
    if (action === 'share-link') {
      void navigator.clipboard.writeText(window.location.href)
        .then(() => toast.success('Lien copié.'))
        .catch(() => toast.info('Copie automatique indisponible dans ce navigateur.'));
      return;
    }
    if (action === 'export-json') { downloadStudioProject(); return; }
    if (action === 'manage') { setRemixManagerOpen(true); return; }
    if (action === 'add-collection') {
      let existing: RemixTarget[] = [];
      try { existing = JSON.parse(getProjectItem('lma_remix_collection') || '[]'); } catch { existing = []; }
      setProjectItem('lma_remix_collection', JSON.stringify([...existing.filter((item) => !(item.kind === target.kind && item.id === target.id)), target]));
      toast.success('Ajouté à la collection d’inspirations.');
      return;
    }
    if (action === 'move-workspace') { setRemixManagerOpen(true); toast.info('Choisissez les droits avant de déplacer cette création vers un espace partagé.'); return; }
    if (action === 'undo-remix') { undoLastRemix(); return; }
    if (action === 'archive') {
      if (target.kind === 'element') updateCanvasElement(target.id, { hidden: true });
      else if (target.kind === 'entry') setEntryStates((previous) => ({ ...previous, [target.id]: { ...previous[target.id as 'couple' | 'provider'], visible: false } }));
      else if (target.kind === 'note') updateCanvasNote(target.id, { hidden: true });
      else if (target.kind === 'lot') setActiveLotId(null);
      else { toast.info('Les plans maîtres restent disponibles dans Pages.'); return; }
      clearCanvasSelection();
      toast.success('Création archivée et masquée dans le projet.');
      return;
    }
    if (action === 'delete') {
      if (target.kind === 'element') deleteCanvasElement(target.id);
      else if (target.kind === 'entry') removeEntryFromCanvas(target.id as 'couple' | 'provider');
      else if (target.kind === 'note') deleteCanvasNote(target.id);
      else if (target.kind === 'lot') setActiveLotId(null);
      else toast.info('Les plans maîtres restent disponibles. Utilisez Masquer dans les propriétés.');
    }
  }, [addRemixHistory, canvasElements, clearCanvasSelection, deleteCanvasElement, deleteCanvasNote, downloadStudioProject, duplicateCanvasElement, duplicateCanvasNote, duplicateEntryAsCard, planCovers, planSizes, project.id, project.name, project.universe, remixPermissions, removeEntryFromCanvas, selectCanvasObject, undoLastRemix, updateCanvasElement, updateCanvasNote, visibleCanvasCenter]);

  const saveProjectNow = useCallback(async () => {
    setSaveState('saving');
    await flushProjectSave(project.id);
    toast.success('Projet enregistré.');
  }, [project.id]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const meta = e.metaKey || e.ctrlKey;
      if (meta && e.key.toLowerCase() === 's') { e.preventDefault(); void saveProjectNow(); return; }
      if (meta && e.key === 'k') { e.preventDefault(); setCommandOpen(true); return; }
      if (meta && e.key === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
      if (meta && e.key === '1') { e.preventDefault(); setViewMode('canvas'); return; }
      if (meta && e.key === '2') { e.preventDefault(); setViewMode('timeline'); return; }
      if (meta && e.key === '3') { e.preventDefault(); setViewMode('minisite'); return; }
      const editingTarget = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || (e.target instanceof HTMLElement && e.target.isContentEditable);
      if (viewMode === 'canvas' && !editingTarget && selectedObject) {
        if ((e.key === 'Backspace' || e.key === 'Delete')) { e.preventDefault(); deleteSelectedObject(); return; }
        if (meta && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateSelectedObject(); return; }
        if (meta && e.key.toLowerCase() === 'l') { e.preventDefault(); toggleSelectedObjectLock(); return; }
      }
      if (e.key === 'Escape') {
        if (viewMode !== 'canvas') { setViewMode('canvas'); return; }
        setCommandOpen(false); setKioskOpen(false);
        setChecklistOpen(false); setBudgetOpen(false); setTemplatesOpen(false);
        setMiniSitePanelOpen(false); setActiveStudioPanel(null); setPlaylistOpen(false);
        return;
      }
      if (!meta && !e.altKey && !e.shiftKey && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        if (e.key === 'g' || e.key === 'G') setActiveTool('hand');
        if (e.key === 'v' || e.key === 'V') setActiveTool('select');
        if (e.key === '+') handleZoomChange(0.2);
        if (e.key === '-') handleZoomChange(-0.2);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [undo, redo, handleZoomChange, viewMode, selectedObject, deleteSelectedObject, duplicateSelectedObject, toggleSelectedObjectLock, saveProjectNow]);
  const relevantEntryIds: Array<'couple' | 'provider'> = project.universe === 'mariage' ? ['couple','provider'] : project.universe === 'prestataire' ? ['provider'] : [];
  const hiddenEntries = relevantEntryIds.filter((id) => !entryStates[id].visible);

  /* ── Theme tokens ── */
  const headerBg     = isDark ? 'rgba(20,20,21,0.98)'    : 'rgba(250,250,251,0.98)';
  const headerBorder = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.08)';
  const textPrimary  = isDark ? '#F4F4F5'                : '#0F0F10';
  const textMuted    = isDark ? 'rgba(244,244,245,0.42)'  : 'rgba(15,15,16,0.42)';
  const planePresetStyle: React.CSSProperties = { height: 24, padding: '0 8px', borderRadius: 6, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.06)', color: '#fff', fontSize: 8, cursor: 'pointer' };
  const currentCoverVariant: CoverVariant = coverTarget?.kind === 'plan'
    ? planCovers[coverTarget.id as CanvasPlanId]
    : coverTarget?.kind === 'element'
      ? canvasElements.find((item) => item.id === coverTarget.id)?.coverVariant || 'original'
      : 'original';

  /* ── Canvas always rendered ── */
  return (
    <div
      data-theme={isDark ? 'dark' : 'light'}
      style={{ width: '100vw', height: '100vh', overflow: 'hidden', fontFamily: 'Inter, sans-serif', fontSize: textSettings.size, color: textPrimary, background: 'var(--lma-bg)', transition: 'background 0.3s' }}
    >
      <Toaster position="bottom-right" theme={isDark ? 'dark' : 'light'} />
      <RemixProtocolMenu
        open={Boolean(remixMenu)}
        x={remixMenu?.x || 0}
        y={remixMenu?.y || 0}
        target={remixMenu?.target || null}
        canUndo={remixHistory.length > 0}
        onAction={handleRemixAction}
        onClose={() => setRemixMenu(null)}
      />
      <CoverVariationPicker
        open={Boolean(coverTarget)}
        target={coverTarget}
        current={currentCoverVariant}
        onApply={applyCoverVariant}
        onClose={() => setCoverTarget(null)}
      />
      <RemixPermissionsPanel
        open={remixManagerOpen}
        permissions={remixPermissions}
        history={remixHistory}
        onChange={setRemixPermissions}
        onClose={() => setRemixManagerOpen(false)}
      />

      {/* The editor opens directly on the two entry cards. */}


      {/* ── Canvas — always rendered beneath everything ── */}
      <InfiniteCanvas
        transform={transform}
        onTransformChange={setTransform}
        activeTool={activeTool}
        bgSettings={bgSettings}
        onCanvasClick={(point) => {
          if (activeTool === 'note') addCanvasNote(point);
          else clearCanvasSelection();
        }}
      >
        <>
            {entryStates.couple.visible && (
              <CanvasObjectFrame
                id="couple"
                label="Notre Mariage"
                position={entryPositions.couple}
                width={260}
                height={360}
                canvasScale={transform.scale}
                activeTool={activeTool}
                selected={selectedObject?.kind === 'entry' && selectedObject.id === 'couple'}
                locked={entryStates.couple.locked}
                zIndex={entryStates.couple.zIndex}
                snapEnabled={snapEnabled}
                gridSize={GRID_SIZE}
                onSelect={() => selectCanvasObject({ kind: 'entry', id: 'couple' })}
                onPositionChange={(position) => updateEntryPosition('couple', position)}
                onDelete={() => removeEntryFromCanvas('couple')}
                onDuplicate={() => duplicateEntryAsCard('couple')}
                onToggleLock={() => setEntryStates((prev) => ({ ...prev, couple: { ...prev.couple, locked: !prev.couple.locked } }))}
                onOpenMenu={(event) => openRemixMenu(event, { kind: 'entry', id: 'couple', label: 'Notre Mariage' })}
              >
                <UniversalCard
                  data={setupData}
                  onChange={setSetupData}
                  onComplete={handleSetupComplete}
                  isComplete={setupComplete}
                />
              </CanvasObjectFrame>
            )}

            {entryStates.provider.visible && (
              <CanvasObjectFrame
                id="provider"
                label="Prestataires"
                position={entryPositions.provider}
                width={260}
                height={360}
                canvasScale={transform.scale}
                activeTool={activeTool}
                selected={selectedObject?.kind === 'entry' && selectedObject.id === 'provider'}
                locked={entryStates.provider.locked}
                zIndex={entryStates.provider.zIndex}
                snapEnabled={snapEnabled}
                gridSize={GRID_SIZE}
                onSelect={() => selectCanvasObject({ kind: 'entry', id: 'provider' })}
                onPositionChange={(position) => updateEntryPosition('provider', position)}
                onDelete={() => removeEntryFromCanvas('provider')}
                onDuplicate={() => duplicateEntryAsCard('provider')}
                onToggleLock={() => setEntryStates((prev) => ({ ...prev, provider: { ...prev.provider, locked: !prev.provider.locked } }))}
                onOpenMenu={(event) => openRemixMenu(event, { kind: 'entry', id: 'provider', label: 'Prestataires' })}
              >
                <ProviderCard
                  data={providerData}
                  onChange={setProviderData}
                  onComplete={handleProviderComplete}
                  isComplete={providerComplete}
                />
              </CanvasObjectFrame>
            )}

            {canvasElements.map((element) => (
              <CanvasElementNode
                key={element.id}
                element={element}
                canvasScale={transform.scale}
                activeTool={activeTool}
                selected={selectedObject?.kind === 'element' && selectedObject.id === element.id}
                onSelect={(id) => selectCanvasObject({ kind: 'element', id })}
                onChange={updateCanvasElement}
                onDelete={deleteCanvasElement}
                onDuplicate={duplicateCanvasElement}
                onOpenMenu={(event, id) => { const item = canvasElements.find((candidate) => candidate.id === id); if (item) openRemixMenu(event, { kind: 'element', id, label: item.content || item.type }); }}
                snapEnabled={snapEnabled}
                gridSize={GRID_SIZE}
              />
            ))}

            {notes.map((note) => (
              <CanvasNote
                key={note.id}
                note={note}
                scale={transform.scale}
                activeTool={activeTool}
                selected={selectedObject?.kind === 'note' && selectedObject.id === note.id}
                snapEnabled={snapEnabled}
                gridSize={GRID_SIZE}
                onSelect={(id) => selectCanvasObject({ kind: 'note', id })}
                onChange={updateCanvasNote}
                onDelete={deleteCanvasNote}
                onDuplicate={duplicateCanvasNote}
                onOpenMenu={(event, id) => { const noteItem = notes.find((candidate) => candidate.id === id); openRemixMenu(event, { kind: 'note', id, label: noteItem?.text || 'Post-it' }); }}
              />
            ))}

            <AnimatePresence mode="wait">
              {activeLot && (
                <motion.div key={activeLot.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}>
                  <LotGroup
                    lot={activeLot}
                    position={activeLotPosition}
                    canvasScale={transform.scale}
                    layoutMode={activeLotLayout}
                    activeTool={activeTool}
                    selected={selectedObject?.kind === 'lot' && selectedObject.id === activeLot.id}
                    locked={!!lotLocks[activeLot.id]}
                    zIndex={lotZIndexes[activeLot.id] || 80}
                    snapEnabled={snapEnabled}
                    gridSize={GRID_SIZE}
                    onSelect={() => selectCanvasObject({ kind: 'lot', id: activeLot.id })}
                    onPositionChange={updateActiveLotPosition}
                    onDelete={() => { setActiveLotId(null); clearCanvasSelection(); }}
                    onToggleLock={() => setLotLocks((prev) => ({ ...prev, [activeLot.id]: !prev[activeLot.id] }))}
                    onOpenMenu={(event) => openRemixMenu(event, { kind: 'lot', id: String(activeLot.id), label: activeLot.title })}
                    cardSettings={cardSettings}
                    onCardSettingChange={handleCardSettingChange}
                    animSettings={DEFAULT_ANIM}
                    playingTrackId={playingTrackId}
                    onTogglePlay={handleTogglePlay}
                    globalTexture={globalTexture}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </>

        <CanvasPlane
          title="Timeline" subtitle="Plan du projet · sélectionnable et redimensionnable"
          position={planPositions.timeline} size={planSizes.timeline} canvasScale={transform.scale} activeTool={activeTool}
          selected={selectedObject?.kind === 'plan' && selectedObject.id === 'timeline'} onSelect={() => selectPlan('timeline')}
          onPositionChange={(position) => setPlanPositions((prev) => ({ ...prev, timeline: position }))}
          onSizeChange={(size) => setPlanSizes((prev) => ({ ...prev, timeline: size }))}
          onOpenMenu={(event) => openRemixMenu(event, { kind: 'plan', id: 'timeline', label: 'Timeline' })}
          toolbar={<><button onClick={() => setPlanSizes((prev) => ({ ...prev, timeline: { width: 620, height: 440 } }))} style={planePresetStyle}>16:9</button><button onClick={() => setPlanSizes((prev) => ({ ...prev, timeline: { width: 520, height: 520 } }))} style={planePresetStyle}>Carré</button></>}
        >
          <TimelineView lots={lots} cardSettings={cardSettings} coupleName={coupleName} weddingDate={weddingDate} embedded backgroundMedia={timelineMedia} coverVariant={planCovers.timeline} />
        </CanvasPlane>

        <CanvasPlane
          title="Mini-site" subtitle="Site éditable · Desktop, tablette, mobile ou format libre"
          position={planPositions.minisite} size={planSizes.minisite} canvasScale={transform.scale} activeTool={activeTool}
          selected={selectedObject?.kind === 'plan' && selectedObject.id === 'minisite'} onSelect={() => selectPlan('minisite')}
          onPositionChange={(position) => setPlanPositions((prev) => ({ ...prev, minisite: position }))}
          onSizeChange={(size) => setPlanSizes((prev) => ({ ...prev, minisite: size }))}
          onOpenMenu={(event) => openRemixMenu(event, { kind: 'plan', id: 'minisite', label: 'Mini-site' })}
          toolbar={<><button onClick={() => setPlanSizes((prev) => ({ ...prev, minisite: { width: 560, height: 520 } }))} style={planePresetStyle}>Desktop</button><button onClick={() => setPlanSizes((prev) => ({ ...prev, minisite: { width: 430, height: 620 } }))} style={planePresetStyle}>Tablette</button><button onClick={() => setPlanSizes((prev) => ({ ...prev, minisite: { width: 320, height: 600 } }))} style={planePresetStyle}>iPhone</button></>}
        >
          <MiniSite
              lots={lots}
              cardSettings={cardSettings}
              selectedCards={selectedCards}
              coupleName={coupleName}
              weddingDate={weddingDate}
              heroPhoto={heroPhoto}
              heroMediaType={heroMediaType}
              heroCoupleName={heroCoupleName || coupleName}
              heroDate={heroDate || weddingDate}
              heroVenue={heroVenue}
              embedded
              coverVariant={planCovers.minisite}
            />
        </CanvasPlane>
      </InfiniteCanvas>

      <WorkspaceSidebar
        open={sidebarOpen}
        viewMode={viewMode}
        onViewModeChange={(mode) => { if (mode === 'canvas') { setViewMode('canvas'); clearCanvasSelection(); } else selectPlan(mode); }}
        onHome={() => { if (project.universe === 'mariage') openWorkspacePanel('control'); else onExit(); }}
        lots={lots}
        activeLotId={activeLotId}
        cardSettings={cardSettings}
        onSelectLot={(id) => { if (id == null) { setActiveLotId(null); clearCanvasSelection(); return; } const lot = lots.find((item) => item.id === id); if (lot) navigateToLot(lot); }}
        layers={sidebarLayers}
        selectedKey={selectedSidebarKey}
        onSelectLayer={selectSidebarLayer}
        onToggleLayerVisibility={toggleSidebarLayerVisibility}
        assets={mediaAssets}
        onSelectAsset={(id) => { selectCanvasObject({ kind: 'element', id }); setViewMode('canvas'); setActiveTool('select'); setActiveStudioPanel('media'); }}
        onClose={() => setSidebarOpen(false)}
      />

      {controlCenterOpen && project.universe === 'mariage' && (
        <WeddingControlCenter
          data={weddingProjectData}
          readiness={weddingReadiness}
          onClose={() => setControlCenterOpen(false)}
          onEditIdentity={() => {
            closeWorkspacePanels();
            setViewMode('canvas');
            selectCanvasObject({ kind: 'entry', id: 'couple' });
            fitWorkspacePlacements([{ x: entryPositions.couple.x, y: entryPositions.couple.y, width: 260, height: 360 }]);
          }}
          onOpenTimeline={() => { closeWorkspacePanels(); selectPlan('timeline'); }}
          onOpenMiniSite={() => { closeWorkspacePanels(); selectPlan('minisite'); }}
          onOpenBudget={() => openWorkspacePanel('budget')}
          onOpenChecklist={() => openWorkspacePanel('checklist')}
          onOpenMedia={() => { setViewMode('canvas'); openWorkspacePanel('media'); }}
        />
      )}

      {/* ── Toolbar — studio families ── */}
      <Toolbar
        activeTool={activeTool}
        onToolChange={setActiveTool}
        activeStudioPanel={activeStudioPanel}
        onStudioPanelChange={(panel) => {
          if (panel && ['add', 'style', 'organize'].includes(panel) && viewMode !== 'canvas') setViewMode('canvas');
          openWorkspacePanel(panel);
        }}
        scale={transform.scale}
        onZoomChange={handleZoomChange}
        onZoomTo={zoomToScale}
        onZoomFit={fitCurrentView}
        onZoomSelection={fitSelection}
        onPreview={() => setKioskOpen(true)}
        onToggleSidebar={() => setSidebarOpen((value) => !value)}
        sidebarOpen={sidebarOpen}
        onBudget={() => setBudgetOpen(true)}
        onChecklist={() => setChecklistOpen(true)}
        onKiosk={() => setKioskOpen(true)}
        onTemplates={() => setTemplatesOpen(true)}
        onPlaylist={() => openWorkspacePanel(playlistOpen ? null : 'playlist')}
        playlistActive={playlistOpen}
      />

      {<MiniMap lots={lots} transform={transform} onNavigate={(x, y) => setTransform((t) => ({ ...t, x, y }))} />}

      {activeStudioPanel === 'add' && (
        <StudioAddPanel onAdd={addStudioElement} onClose={() => setActiveStudioPanel(null)} />
      )}
      {activeStudioPanel === 'media' && (
        <StudioMediaPanel
          bg={bgSettings}
          selectedElement={selectedCanvasElement}
          activeLotTitle={activeLot?.title}
          heroPhoto={heroPhoto}
          heroMediaType={heroMediaType}
          timelineMedia={timelineMedia}
          onCanvasChange={setBgSettings}
          onElementChange={(patch) => selectedCanvasElement && updateCanvasElement(selectedCanvasElement.id, patch)}
          onApplyLotMedia={applyMediaToActiveLot}
          onHeroPhotoChange={(url, type) => { setHeroPhoto(url); setHeroMediaType(type); }}
          onTimelineMediaChange={setTimelineMedia}
          onClose={() => setActiveStudioPanel(null)}
        />
      )}
      {activeStudioPanel === 'style' && (
        <StudioStylePanel
          selectedElement={selectedCanvasElement}
          activeLotTitle={activeLot?.title}
          globalTexture={globalTexture}
          onElementChange={(patch) => selectedCanvasElement && updateCanvasElement(selectedCanvasElement.id, patch)}
          onApplyLotStyle={(_, patch) => applyPatchToActiveLot(patch)}
          onApplyAllCardsStyle={applyPatchToAllCards}
          onGlobalTextureChange={setGlobalTexture}
          onClose={() => setActiveStudioPanel(null)}
        />
      )}
      {activeStudioPanel === 'organize' && (
        <LayoutPanel
          activeLotTitle={activeLot?.title}
          layoutMode={activeLotLayout}
          onLayoutModeChange={changeActiveLotLayout}
          workspaceMode={workspaceMode}
          onWorkspaceModeChange={(mode) => arrangeWorkspaceByMode(mode)}
          onAutoArrange={arrangeWorkspace}
          onAlignTop={alignWorkspaceTop}
          onAlignCenter={alignWorkspaceCenter}
          onDistributeHorizontal={distributeWorkspace}
          onReset={resetWorkspace}
          snapEnabled={snapEnabled}
          onToggleSnap={() => setSnapEnabled((value) => !value)}
          selectedObject={selectedObjectSummary}
          onDuplicateObject={duplicateSelectedObject}
          onDeleteObject={deleteSelectedObject}
          onToggleObjectLock={toggleSelectedObjectLock}
          onToggleObjectHidden={toggleSelectedObjectHidden}
          onBringObjectFront={() => moveSelectedObjectLayer('front')}
          onSendObjectBack={() => moveSelectedObjectLayer('back')}
          hiddenEntries={hiddenEntries}
          onRestoreEntry={restoreEntryToCanvas}
          onClose={() => setActiveStudioPanel(null)}
        />
      )}
      {activeStudioPanel === 'publish' && (
        <StudioPublishPanel
          onView={(mode) => { setViewMode(mode); setActiveStudioPanel(null); }}
          onKiosk={() => { setKioskOpen(true); setActiveStudioPanel(null); }}
          exportProject={exportStudioProject}
          importProject={importStudioProject}
          onPublish={publishCurrentWedding}
          initialPublication={publicationResult}
          onClose={() => setActiveStudioPanel(null)}
        />
      )}

      {/* ── Header ── */}
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0, height: '50px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        paddingLeft: '10px', paddingRight: '14px', gap: '10px',
        background: headerBg, backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
        borderBottom: `1px solid ${headerBorder}`, zIndex: 200,
        transition: 'background 0.3s, border-color 0.3s',
      }}>
        {/* Left: project navigation */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, minWidth: 280 }}>
          <HeaderBtn onClick={onExit} title="Retour aux projets" isDark={isDark} textPrimary={textPrimary} textMuted={textMuted}>
            <Home size={14} />
          </HeaderBtn>
          <HeaderBtn onClick={() => setSidebarOpen((value) => !value)} title="Pages, calques et ressources" isDark={isDark} textPrimary={textPrimary} textMuted={textMuted}>
            <PanelLeftOpen size={14} />
          </HeaderBtn>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 7px', minWidth: 0 }}>
            <AimeRainbowMark size={18} />
            <div style={{ fontSize: 10.5, fontWeight: 850, letterSpacing: '.12em', textTransform: 'uppercase', color: textPrimary, whiteSpace: 'nowrap' }}>Le Monde Aime</div>
          </div>
          <span style={{ width: 1, height: 18, background: headerBorder, margin: '0 3px' }} />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 10.5, fontWeight: 750, color: textPrimary, maxWidth: 170, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{project.name}</div>
            <div style={{ fontSize: 7.5, color: textMuted, marginTop: 1, textTransform: 'capitalize' }}>{project.universe}</div>
          </div>
        </div>

        <div style={{ flex: 1 }} />

        {/* Right: save state, commands and agent */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <CloudAccountControl project={project} compact onOpen={closeWorkspacePanels} />
          <button onClick={() => void saveProjectNow()} title="Enregistrer maintenant (⌘S)" style={{ height: 29, border: 0, borderRadius: 7, padding: '0 8px', background: saveState === 'error' ? 'rgba(248,113,113,.12)' : 'transparent', color: saveState === 'error' ? '#F87171' : textMuted, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, fontSize: 8.5 }}>
            {saveState === 'saving' ? <Cloud size={12} /> : saveState === 'error' ? <CloudOff size={12} /> : <Check size={12} />}
            {saveState === 'saving' ? 'Enregistrement…' : saveState === 'error' ? 'Non enregistré' : 'Enregistré'}
          </button>
          <button
            onClick={() => openWorkspacePanel(activeStudioPanel === 'publish' ? null : 'publish')}
            title="Exporter, publier et partager"
            style={{ height: 29, padding: '0 10px', borderRadius: 8, border: `1px solid ${headerBorder}`, background: activeStudioPanel === 'publish' ? (isDark ? '#F2F2F3' : '#151517') : 'transparent', color: activeStudioPanel === 'publish' ? (isDark ? '#151517' : '#FFFFFF') : textMuted, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, fontSize: 8.5, fontWeight: 760 }}
          >
            <Download size={13} /> Exporter
          </button>
          <HeaderBtn onClick={() => { closeWorkspacePanels(); setWorldOpen(true); }} title="MapMonde — communauté, registre et événements" isDark={isDark} textPrimary={textPrimary} textMuted={textMuted}>
            <Globe size={14} />
          </HeaderBtn>
          <HeaderBtn onClick={() => setCommandOpen(true)} title="⌘K — Commandes" isDark={isDark} textPrimary={textPrimary} textMuted={textMuted}>
            <Command size={13} />
          </HeaderBtn>
          <AgentDotButton
            onClick={() => { openWorkspacePanel(agentOpen ? null : 'agent'); setAgentHasMessage(false); }}
            agentState={agentState}
            title="Assistant IA universel"
          />
        </div>
      </div>

      {/* Timeline and mini-site are now autonomous plans inside the infinite canvas. */}

      {/* ── MiniSite editor panel ── */}
      <AnimatePresence>
        {miniSitePanelOpen && (
          <MiniSitePanel
            lots={lots} selected={selectedCards}
            onToggleCard={handleToggleCard} onToggleLot={handleToggleLot}
            onGenerate={handleGenerateMiniSite} onClose={() => setMiniSitePanelOpen(false)}
            cardSettings={cardSettings}
            heroPhoto={heroPhoto}
            heroMediaType={heroMediaType}
            heroCoupleName={heroCoupleName || coupleName}
            heroDate={heroDate || weddingDate}
            heroVenue={heroVenue}
            onHeroChange={handleHeroChange}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {playlistOpen && (
          <CollaborativePlaylistPanel suggestions={playlistSuggestions} onChange={setPlaylistSuggestions} onClose={() => setPlaylistOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Music bar ── */}
      <MusicPlayerBar lots={lots} cardSettings={cardSettings} collaborativeSuggestions={playlistSuggestions} />

      {/* ── AI Agent — controlled by header button ── */}
      <AIAgent
        lots={lots} cardSettings={cardSettings} viewMode={viewMode}
        onNavigateLot={navigateToLot}
        onAction={handleAgentAction}
        externalOpen={agentOpen}
        onOpenChange={setAgentOpen}
        onThinkingChange={setAgentThinking}
        onNewMessage={() => setAgentHasMessage(true)}
        projectUniverse={project.universe}
        projectName={project.name}
        projectStatus={project.status}
        selectedCount={selectedCards.size}
        canvasElementCount={canvasElements.length}
        selectedObjectLabel={selectedObjectSummary?.label || ''}
        selectedObjectKind={selectedObjectSummary?.kind || ''}
      />

      <WorldHub open={worldOpen} onClose={() => setWorldOpen(false)} />

      {/* ── Command palette ── */}
      <CommandPalette
        open={commandOpen} onClose={() => setCommandOpen(false)}
        lots={lots} cardSettings={cardSettings}
        onNavigateLot={(lot) => { navigateToLot(lot); setCommandOpen(false); }}
        onAction={(a) => { handleAction(a); setCommandOpen(false); }}
      />

      {/* ── Kiosk ── */}
      <AnimatePresence>
        {kioskOpen && (
          <KioskMode lots={lots} cardSettings={cardSettings} coupleName={coupleName} weddingDate={weddingDate} onClose={() => setKioskOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Checklist ── */}
      <AnimatePresence>
        {checklistOpen && ChecklistPanel && (
          <ChecklistPanel lots={lots} cardSettings={cardSettings} weddingDate={weddingDate} onClose={() => setChecklistOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Budget ── */}
      <AnimatePresence>
        {budgetOpen && BudgetDashboard && (
          <BudgetDashboard lots={lots} cardSettings={cardSettings}
            totalBudget={totalBudget} onTotalBudgetChange={setTotalBudget}
            onClose={() => setBudgetOpen(false)} />
        )}
      </AnimatePresence>

      {/* ── Templates ── */}
      <AnimatePresence>
        {templatesOpen && TemplatesPanel && (
          <TemplatesPanel
            onApplyTemplate={(tpl: any) => {
              setCardSettings((prev) => {
                const next = { ...prev };
                Object.entries(tpl.cardDefaults).forEach(([id, defaults]) => {
                  next[id] = { ...(next[id] || {}), ...(defaults as Record<string, any>) };
                });
                pushHistory(next);
                return next;
              });
              setTemplatesOpen(false);
              toast.success(`Template "${tpl.name}" appliqué !`);
            }}
            onClose={() => setTemplatesOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* ── Hint bar (canvas only) ── */}
      {viewMode === 'canvas' && (
        <div style={{
          position: 'fixed', bottom: '64px', left: '50%', transform: 'translateX(-50%)',
          fontFamily: 'Inter', fontSize: '10px',
          color: isDark ? 'rgba(240,238,248,0.22)' : 'rgba(15,15,18,0.32)',
          zIndex: 90, pointerEvents: 'none',
          background: isDark ? 'rgba(0,0,0,0.28)' : 'rgba(255,255,255,0.7)',
          backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
          borderRadius: '50px', padding: '5px 14px', whiteSpace: 'nowrap',
          border: `1px solid ${isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)'}`,
        }}>
          Clic : sélectionner · Glisser le fond : déplacer · ⌘Z : annuler · +/- : zoom
        </div>
      )}
    </div>
  );
}

function WorkspaceRoot() {
  ensureProjectWorkspace();
  const projectIdFromUrl = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('project') : null;
  const availableProjects = getProjects();
  const requestedProject = projectIdFromUrl ? availableProjects.find((item) => item.id === projectIdFromUrl) || null : null;
  const initialProject = requestedProject || getActiveProject();
  const [screen, setScreen] = useState<'projects' | 'editor'>(() => requestedProject ? 'editor' : 'projects');
  const [activeProject, setActiveProjectMeta] = useState<StudioProjectMeta>(() => initialProject);
  const [loadingProject, setLoadingProject] = useState(Boolean(requestedProject));
  const [openWarning, setOpenWarning] = useState('');

  useEffect(() => {
    if (projectIdFromUrl && !requestedProject) {
      const url = new URL(window.location.href);
      url.searchParams.delete('project');
      url.hash = 'projects';
      window.history.replaceState(null, '', url);
      setScreen('projects');
      setLoadingProject(false);
      setOpenWarning('Ce projet n’existe plus dans ce navigateur.');
      return;
    }
    if (!requestedProject) return;
    let cancelled = false;
    void hydrateProject(requestedProject.id)
      .catch(() => {
        if (!cancelled) setOpenWarning('Le stockage complet n’a pas répondu. Le projet a été ouvert avec les données disponibles.');
      })
      .finally(() => {
        if (cancelled) return;
        setActiveProjectMeta(getActiveProject());
        setLoadingProject(false);
      });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const refresh = () => setActiveProjectMeta(getActiveProject());
    window.addEventListener('lma:projects-changed', refresh);
    return () => window.removeEventListener('lma:projects-changed', refresh);
  }, []);

  const openProject = async (project: StudioProjectMeta) => {
    setLoadingProject(true);
    setOpenWarning('');
    const url = new URL(window.location.href);
    url.searchParams.set('project', project.id);
    url.hash = '';
    window.history.replaceState(null, '', url);
    try {
      await hydrateProject(project.id);
      setActiveProjectMeta(getActiveProject());
    } catch {
      setActiveProjectMeta(project);
      setOpenWarning('Le stockage complet n’a pas répondu. Le projet a été ouvert avec les données locales disponibles.');
    } finally {
      setScreen('editor');
      setLoadingProject(false);
    }
  };

  const closeEditor = async () => {
    await flushProjectSave(activeProject.id);
    const url = new URL(window.location.href);
    url.searchParams.delete('project');
    url.hash = 'projects';
    window.history.replaceState(null, '', url);
    setActiveProjectMeta(getActiveProject());
    setScreen('projects');
  };

  if (loadingProject) {
    return <div style={{ width: '100vw', height: '100vh', display: 'grid', placeItems: 'center', background: '#0C0C0E', color: '#fff', fontFamily: 'Inter, sans-serif' }}><div style={{ textAlign: 'center' }}><div style={{ width: 34, height: 34, borderRadius: 12, margin: '0 auto 12px', background: '#2B2B2E', animation: 'pulse 1s ease-in-out infinite' }} /><div style={{ fontSize: 11, opacity: .58 }}>Ouverture du canvas…</div></div></div>;
  }

  if (screen === 'projects') return <ProjectDashboard onOpenProject={openProject} />;
  return <>
    {openWarning && <div role="status" style={{ position: 'fixed', top: 58, left: '50%', transform: 'translateX(-50%)', zIndex: 1200, maxWidth: 560, padding: '9px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(36,36,38,.96)', color: '#E8E8EA', fontSize: 10, fontFamily: 'Inter, sans-serif', boxShadow: '0 18px 45px rgba(0,0,0,.28)' }}>{openWarning}</div>}
    <AppInner key={activeProject.id} project={activeProject} onExit={() => void closeEditor()} />
  </>;
}

function ApplicationRouter() {
  const params = new URLSearchParams(window.location.search);
  const liveSlug = params.get('live');
  const siteSlug = params.get('site');
  if (liveSlug) return <PublicWeddingSite slug={liveSlug} mode="live" />;
  if (siteSlug) return <PublicWeddingSite slug={siteSlug} mode="site" />;
  return <WorkspaceRoot />;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ApplicationRouter />
      </AuthProvider>
    </ThemeProvider>
  );
}

/* ── Shared primitives ───────────────────────────────────────────────────────── */

const HeaderBtn: React.FC<{
  onClick: () => void; title: string; children: React.ReactNode;
  isDark: boolean; textPrimary: string; textMuted: string;
}> = ({ onClick, title, children, isDark, textPrimary, textMuted }) => {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} title={title}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        width: '30px', height: '30px', borderRadius: '7px', border: 'none',
        background: hov ? (isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)') : 'transparent',
        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: hov ? textPrimary : textMuted, transition: 'all 0.15s', flexShrink: 0,
      }}
    >
      {children}
    </button>
  );
};
