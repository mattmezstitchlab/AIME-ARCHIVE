export type AgentProposalAction =
  | 'open-organize'
  | 'open-media'
  | 'generate-minisite'
  | 'open-minisite'
  | 'open-publish'
  | 'remix-cover'
  | 'remix-inspiration'
  | 'remix-manage'
  | 'open-point-zero'
  | 'open-chromatic'
  | `navigate-lot:${number}`;

export interface AgentProposal {
  id: string;
  label: string;
  action: AgentProposalAction;
  rationale: string;
}

export interface ConnectedAgentResponse {
  text: string;
  proposals: AgentProposal[];
  confidence: number;
  source: 'aime-core';
}

export interface AgentRequestContext {
  projectName: string;
  universe: string;
  viewMode: string;
  selectedObject?: { kind: string; label: string };
  selectedCardCount: number;
  canvasElementCount: number;
  cardSummary: Array<{ id: string; name: string; time?: string; status?: string }>;
  domain: Record<string, unknown>;
}

export async function askAimeCore(message: string, context: AgentRequestContext, history: Array<{ role: 'user' | 'agent'; text: string }>): Promise<ConnectedAgentResponse> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 18000);
  try {
    const response = await fetch('/api/agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, context, history: history.slice(-12) }),
      signal: controller.signal,
    });
    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      throw new Error(payload.error || `Agent distant indisponible (${response.status}).`);
    }
    const data = await response.json() as Partial<ConnectedAgentResponse>;
    if (!data.text) throw new Error('Réponse agent incomplète.');
    return {
      text: data.text,
      proposals: Array.isArray(data.proposals) ? data.proposals.slice(0, 4) as AgentProposal[] : [],
      confidence: typeof data.confidence === 'number' ? data.confidence : .65,
      source: 'aime-core',
    };
  } finally {
    window.clearTimeout(timeout);
  }
}
