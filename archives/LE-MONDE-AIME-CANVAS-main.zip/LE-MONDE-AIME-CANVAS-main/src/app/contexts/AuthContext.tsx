import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { AuthChangeEvent, Session, User } from '@supabase/supabase-js';
import {
  ensureSupabaseClient,
  getCloudDiagnostic,
  isSupabaseConfigured,
  supabase,
  type RuntimeCloudDiagnostic,
} from '../cloud/supabase';

interface AuthContextValue {
  configured: boolean;
  loading: boolean;
  session: Session | null;
  user: User | null;
  diagnostic: RuntimeCloudDiagnostic;
  authError: string;
  sendMagicLink: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshConfiguration: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function cleanAuthenticationUrl() {
  if (typeof window === 'undefined') return;
  const url = new URL(window.location.href);
  const authHash = /(?:access_token|refresh_token|error_description|type)=/i.test(url.hash);
  const authQueryKeys = ['code', 'token_hash', 'error', 'error_code', 'error_description'];
  const authQuery = authQueryKeys.some((key) => url.searchParams.has(key));
  if (!authHash && !authQuery) return;

  authQueryKeys.forEach((key) => url.searchParams.delete(key));
  url.hash = '';
  const next = `${url.pathname}${url.search}${url.hash}` || '/';
  window.history.replaceState({}, document.title, next);
}

function readableAuthError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error || 'Connexion impossible.');
  if (/email rate limit exceeded/i.test(message)) {
    return 'Limite d’e-mails atteinte. Attendez avant de demander un nouveau lien, ou configurez un SMTP de production.';
  }
  if (/expired|invalid.*token|token.*invalid/i.test(message)) {
    return 'Ce lien de connexion est expiré ou invalide. Demandez un nouveau lien.';
  }
  return message;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [configured, setConfigured] = useState(isSupabaseConfigured);
  const [diagnostic, setDiagnostic] = useState<RuntimeCloudDiagnostic>(() => getCloudDiagnostic());
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState('');

  const initialize = async () => {
    setLoading(true);
    setAuthError('');
    try {
      const client = await ensureSupabaseClient();
      setConfigured(Boolean(client));
      setDiagnostic(getCloudDiagnostic());
      if (!client) {
        setSession(null);
        return null;
      }

      const { data, error } = await client.auth.getSession();
      if (error) throw error;
      setSession(data.session);
      if (data.session) cleanAuthenticationUrl();
      return client;
    } catch (error) {
      setSession(null);
      setAuthError(readableAuthError(error));
      return null;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | undefined;

    void initialize().then((client) => {
      if (!active || !client) return;
      const { data } = client.auth.onAuthStateChange((event: AuthChangeEvent, nextSession) => {
        if (!active) return;
        setSession(nextSession);
        setAuthError('');
        if (event === 'SIGNED_IN' || event === 'PASSWORD_RECOVERY' || event === 'TOKEN_REFRESHED') {
          cleanAuthenticationUrl();
        }
      });
      unsubscribe = () => data.subscription.unsubscribe();
    });

    return () => {
      active = false;
      unsubscribe?.();
    };
  }, []);

  const value = useMemo<AuthContextValue>(() => ({
    configured,
    loading,
    session,
    user: session?.user || null,
    diagnostic,
    authError,
    sendMagicLink: async (email: string) => {
      const normalizedEmail = email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
        throw new Error('Adresse e-mail invalide.');
      }
      const redirectTo = `${window.location.origin}/`;

      try {
        const response = await fetch('/api/auth-magic-link', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: normalizedEmail, redirectTo }),
        });
        const payload = await response.json().catch(() => ({})) as { error?: string };
        if (!response.ok) throw new Error(payload.error || `Connexion impossible (${response.status}).`);
      } catch (serverError) {
        if (!import.meta.env.DEV) throw new Error(readableAuthError(serverError));
        const client = supabase || await ensureSupabaseClient();
        if (!client) throw new Error(getCloudDiagnostic().error || 'Le cloud n’est pas configuré.');
        const { error } = await client.auth.signInWithOtp({
          email: normalizedEmail,
          options: { emailRedirectTo: redirectTo, shouldCreateUser: true },
        });
        if (error) throw new Error(readableAuthError(error));
      }
    },
    signOut: async () => {
      const client = supabase || await ensureSupabaseClient();
      if (!client) return;
      const { error } = await client.auth.signOut();
      if (error) throw new Error(readableAuthError(error));
      setSession(null);
    },
    refreshConfiguration: async () => {
      const client = await initialize();
      return Boolean(client);
    },
  }), [authError, configured, diagnostic, loading, session]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth doit être utilisé dans AuthProvider.');
  return context;
}
