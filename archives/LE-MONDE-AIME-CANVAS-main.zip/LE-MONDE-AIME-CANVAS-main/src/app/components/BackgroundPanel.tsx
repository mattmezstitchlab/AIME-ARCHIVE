import React, { useEffect, useState } from 'react';
import { X, Palette, Video, Image } from 'lucide-react';
import type { BgSettings, TextSettings } from '../types';

interface BackgroundPanelProps {
  bg: BgSettings;
  onBgChange: (bg: BgSettings) => void;
  text: TextSettings;
  onTextChange: (t: TextSettings) => void;
  onClose: () => void;
  initialTab?: 'bg' | 'text';
}

const PRESET_COLORS = [
  '#FAF7F2', '#1A1A2E', '#0F2027', '#2C1810', '#0A192F',
  '#FAF0E6', '#F5F5DC', '#E8F4F8', '#F0F0F0', '#000000',
];

const PRESET_GRADIENTS = [
  'linear-gradient(135deg,#1A1A2E,#16213E,#0F3460)',
  'linear-gradient(135deg,#0F2027,#203A43,#2C5364)',
  'linear-gradient(135deg,#2C1810,#4A2C2A)',
  'linear-gradient(135deg,#FAF7F2,#F0E8DC)',
  'linear-gradient(135deg,#0A192F,#112240)',
  'linear-gradient(135deg,#1A1A1A,#2D2D2D)',
  'linear-gradient(135deg,#3D1C02,#6A2E0F)',
  'linear-gradient(135deg,#051937,#004D7A,#008793)',
  'linear-gradient(135deg,#200122,#6F0000)',
  'linear-gradient(135deg,#232526,#414345)',
];

const TEXT_COLORS = [
  '#FFFFFF', '#F5F0E8', 'rgba(255,255,255,0.7)', '#1A1A1A', '#2C2C2C', '#C4956A',
];

const TEXT_SIZES = [11, 12, 13, 14, 16, 18];

export const BackgroundPanel: React.FC<BackgroundPanelProps> = ({
  bg,
  onBgChange,
  text,
  onTextChange,
  onClose,
  initialTab = 'bg',
}) => {
  const [tab, setTab] = useState<'bg' | 'text'>(initialTab);
  useEffect(() => setTab(initialTab), [initialTab]);
  const [bgSubTab, setBgSubTab] = useState<'color' | 'gradient' | 'video'>('gradient');
  const [videoUrl, setVideoUrl] = useState(bg.type === 'video' ? bg.value : '');
  const [customColor, setCustomColor] = useState(
    bg.type === 'color' ? bg.value : '#1A1A2E'
  );
  const [customTextColor, setCustomTextColor] = useState(text.color);

  return (
    <div
      style={{
        position: 'fixed',
        top: '50%',
        left: '64px',
        transform: 'translateY(-50%)',
        width: '280px',
        background: 'rgba(255,255,255,0.96)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderRadius: '16px',
        boxShadow: '0 4px 32px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.06)',
        zIndex: 200,
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 16px 0',
        }}
      >
        <div style={{ display: 'flex', gap: '4px' }}>
          {(['bg', 'text'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                padding: '4px 12px',
                borderRadius: '50px',
                border: 'none',
                background: tab === t ? 'rgba(0,0,0,0.08)' : 'transparent',
                cursor: 'pointer',
                fontFamily: 'Inter',
                fontSize: '11px',
                color: tab === t ? 'rgba(0,0,0,0.8)' : 'rgba(0,0,0,0.4)',
              }}
            >
              {t === 'bg' ? 'Fond' : 'Texte'}
            </button>
          ))}
        </div>
        <button
          onClick={onClose}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', color: 'rgba(0,0,0,0.4)' }}
        >
          <X size={14} />
        </button>
      </div>

      <div style={{ padding: '14px 16px 20px' }}>
        {tab === 'bg' && (
          <>
            {/* Sub-tabs */}
            <div style={{ display: 'flex', gap: '4px', marginBottom: '14px' }}>
              {([
                { id: 'color', icon: <Palette size={12} />, label: 'Couleur' },
                { id: 'gradient', icon: <Image size={12} />, label: 'Dégradé' },
                { id: 'video', icon: <Video size={12} />, label: 'Vidéo' },
              ] as const).map((st) => (
                <button
                  key={st.id}
                  onClick={() => setBgSubTab(st.id)}
                  style={{
                    flex: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '4px',
                    padding: '5px',
                    borderRadius: '8px',
                    border: 'none',
                    background: bgSubTab === st.id ? 'rgba(0,0,0,0.08)' : 'transparent',
                    cursor: 'pointer',
                    fontFamily: 'Inter',
                    fontSize: '10px',
                    color: bgSubTab === st.id ? 'rgba(0,0,0,0.8)' : 'rgba(0,0,0,0.4)',
                  }}
                >
                  {st.icon} {st.label}
                </button>
              ))}
            </div>

            {bgSubTab === 'color' && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '6px', marginBottom: '10px' }}>
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => onBgChange({ type: 'color', value: c })}
                      style={{
                        width: '100%',
                        aspectRatio: '1',
                        borderRadius: '8px',
                        background: c,
                        border: bg.value === c ? '2px solid rgba(0,0,0,0.5)' : '1.5px solid rgba(0,0,0,0.1)',
                        cursor: 'pointer',
                      }}
                    />
                  ))}
                </div>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <input
                    type="color"
                    value={customColor}
                    onChange={(e) => { setCustomColor(e.target.value); onBgChange({ type: 'color', value: e.target.value }); }}
                    style={{ width: '36px', height: '36px', border: 'none', borderRadius: '8px', cursor: 'pointer', padding: 0 }}
                  />
                  <input
                    type="text"
                    value={customColor}
                    onChange={(e) => { setCustomColor(e.target.value); onBgChange({ type: 'color', value: e.target.value }); }}
                    style={{ flex: 1, fontFamily: 'Inter', fontSize: '12px', color: 'rgba(0,0,0,0.7)', background: 'rgba(0,0,0,0.04)', border: 'none', borderRadius: '8px', padding: '8px 10px', outline: 'none' }}
                  />
                </div>
              </>
            )}

            {bgSubTab === 'gradient' && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '6px' }}>
                {PRESET_GRADIENTS.map((g) => (
                  <button
                    key={g}
                    onClick={() => onBgChange({ type: 'gradient', value: g })}
                    style={{
                      width: '100%',
                      aspectRatio: '1',
                      borderRadius: '8px',
                      background: g,
                      border: bg.value === g ? '2px solid rgba(255,255,255,0.8)' : '1.5px solid rgba(0,0,0,0.08)',
                      cursor: 'pointer',
                    }}
                  />
                ))}
              </div>
            )}

            {bgSubTab === 'video' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.4)', margin: 0 }}>
                  Collez l'URL d'une vidéo (MP4 direct, Cloudinary, etc.)
                </p>
                <input
                  type="url"
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://..."
                  style={{ fontFamily: 'Inter', fontSize: '12px', color: 'rgba(0,0,0,0.7)', background: 'rgba(0,0,0,0.04)', border: 'none', borderRadius: '8px', padding: '8px 10px', outline: 'none', width: '100%' }}
                />
                <button
                  onClick={() => onBgChange({ type: 'video', value: videoUrl })}
                  style={{
                    padding: '8px 16px',
                    background: 'rgba(0,0,0,0.8)',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    fontFamily: 'Inter',
                    fontSize: '12px',
                  }}
                >
                  Appliquer
                </button>
              </div>
            )}
          </>
        )}

        {tab === 'text' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* Text color */}
            <div>
              <label style={{ display: 'block', fontFamily: 'Inter', fontSize: '10px', color: 'rgba(0,0,0,0.4)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: '8px' }}>
                Couleur du texte
              </label>
              <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '8px' }}>
                {TEXT_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => { setCustomTextColor(c); onTextChange({ ...text, color: c }); }}
                    style={{
                      width: '28px', height: '28px', borderRadius: '50%',
                      background: c,
                      border: text.color === c ? '2px solid rgba(0,0,0,0.5)' : '1.5px solid rgba(0,0,0,0.12)',
                      cursor: 'pointer',
                    }}
                  />
                ))}
                <input
                  type="color"
                  value={customTextColor}
                  onChange={(e) => { setCustomTextColor(e.target.value); onTextChange({ ...text, color: e.target.value }); }}
                  style={{ width: '28px', height: '28px', border: 'none', borderRadius: '50%', cursor: 'pointer', padding: 0 }}
                />
              </div>
            </div>

            {/* Text size */}
            <div>
              <label style={{ display: 'block', fontFamily: 'Inter', fontSize: '10px', color: 'rgba(0,0,0,0.4)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: '8px' }}>
                Taille du texte — {text.size}px
              </label>
              <div style={{ display: 'flex', gap: '6px' }}>
                {TEXT_SIZES.map((s) => (
                  <button
                    key={s}
                    onClick={() => onTextChange({ ...text, size: s })}
                    style={{
                      flex: 1, padding: '6px 0',
                      background: text.size === s ? 'rgba(0,0,0,0.08)' : 'transparent',
                      border: '1.5px solid rgba(0,0,0,0.1)',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      fontFamily: 'Inter',
                      fontSize: '11px',
                      color: 'rgba(0,0,0,0.7)',
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
