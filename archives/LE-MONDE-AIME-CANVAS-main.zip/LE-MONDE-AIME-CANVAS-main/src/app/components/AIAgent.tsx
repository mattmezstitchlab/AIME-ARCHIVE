import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Bot, Send, ChevronDown, MapPin, Loader2, ArrowRight, Clock, Check, CheckCircle2, ListTodo, MessageCircle, Sparkles, Wand2 } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { getStudioTokens } from '../theme/studioTokens';
import { getProjectItem, setProjectItem } from '../utils/projectStore';
import type { WeddingLot } from '../types';
import { askAimeCore, type AgentProposal } from '../agent/agentClient';
import { buildAgentDomainContext } from '../domain/modules';
import type { ProjectUniverse } from '../utils/projectStore';



type AgentActionId = 'generate-role' | 'open-media' | 'open-organize' | 'open-minisite' | 'generate-minisite' | 'open-publish';

const UNIVERSE_LABELS: Record<string, string> = {
  mariage: 'mariage', evenement: 'événement', prestataire: 'activité professionnelle', association: 'association',
  site: 'site universel', portfolio: 'portfolio', libre: 'projet libre',
};

function welcomeMessage(universe = 'mariage', projectName = 'votre projet') {
  const label = UNIVERSE_LABELS[universe] || 'univers';
  if (universe === 'mariage') {
    return `Bonjour ! Je suis l’agent **Le Monde Aime** de **${projectName}**. 💍

Je peux analyser le canvas, compléter le mini-site, organiser les prestataires, corriger les contenus et vous guider sur le Jour J.

L’onglet **À terminer** contient les actions que je peux exécuter directement.`;
  }
  return `Bonjour ! Je suis l’agent **Le Monde Aime** de **${projectName}**. ✦

Ce canvas est configuré pour un ${label}. Je peux créer sa structure, organiser les cartes de rôle, corriger les contenus et préparer sa publication.

L’onglet **À terminer** contient les actions exécutables du projet.`;
}

// ── Wedding knowledge engine ───────────────────────────────────────────────────

function getAgentResponse(
  input: string,
  _lots: WeddingLot[],
  _cardSettings: Record<string, any>,
  universe = 'mariage'
): { text: string; action?: { type: 'navigate'; lotId: number; label: string } } {
  const q = input.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');


  if (q.match(/point zero|point zéro|audit|eaa|wcag|rgaa|importer.*zip|archive zip/)) {
    return { text: `J’ouvre le **Point Zéro** comme porte d’entrée du projet.

Vous pouvez maintenant :

• définir ou déplacer l’origine du canevas
• préparer une mission d’audit EAA / WCAG / RGAA depuis une URL
• importer un ZIP en quarantaine sans exécuter ses scripts
• créer un premier artefact de reconstruction dans le canevas

Chaque import reste traçable et réversible avant toute modification du code source.` };
  }

  if (q.match(/couleur|palette|triade|complementaire|complémentaire|nuancier|arc.?en.?ciel|chromatique/)) {
    return { text: `J’ouvre le **Cercle chromatique AIME**. Il peut appliquer une ambiance au canevas, extraire une teinte avec la pipette et proposer des harmonies analogues, complémentaires, triadiques ou tétradiques.

Si un élément est sélectionné, la palette peut être appliquée directement à cet élément.` };
  }

  if (q.match(/mini.?site|site mobile|landing/) && q.match(/musicien|artiste|saxo|dj|groupe|chanteur/)) {
    return { text: `J’ai compris : vous voulez **générer**, pas recevoir un conseil mariage.

Je vais préparer un plan mobile de mini-site musicien avec :

• couverture artiste et identité
• lecteur musical et extraits
• vidéos et galerie
• prochaines dates
• formules et zone de réservation
• bouton contact / disponibilité
• adaptation iPhone accessible

Dans le prochain incrément, cette demande créera directement le plan dans le canvas. Pour l’instant, ouvrez **Ajouter → Plan mobile** puis utilisez le modèle **Musicien live**.` };
  }

  if (q.match(/cover|remix|variation|inspiration/) && q.match(/site|section|page|plan|element|élément|canvas/)) {
    return { text: `Je prépare le **protocole Remix** sur la sélection active.

Je conserve le contenu et les connexions, puis j’ouvre trois Covers : **Éditorial**, **Immersif** et **Essentiel**. Chaque choix sera enregistré dans la généalogie et pourra être annulé.` };
  }

  if (q.match(/variation|composition|mise en page|layout/) && q.match(/site|section|page|mobile|desktop/)) {
    return { text: `Je peux conserver le contenu et proposer **trois compositions côte à côte** dans le canvas : éditoriale, immersive et compacte. Chaque variante restera sélectionnable, redimensionnable et adaptable en Desktop, Tablette ou Mobile.` };
  }

  if (universe !== 'mariage') {
    if (q.match(/structure|commencer|creer|générer|generer|page|canvas/)) {
      return { text: `Je peux construire la structure de ce projet directement dans le canvas :

• carte de rôle principale
• sections et pages nécessaires
• hiérarchie des contenus
• variante mini-site responsive
• tâches de publication

Ouvrez **À terminer**, puis lancez la première action proposée.` };
    }
    if (q.match(/corrig|modifier|deplac|organis|align|responsive|mobile/)) {
      return { text: `Sélectionnez l’élément concerné dans le canvas ou dans **Calques**. Le panneau droit affichera ses propriétés. Je peux ensuite vous guider pour le déplacer, l’harmoniser ou préparer sa version responsive.` };
    }
    return { text: `Je suis l’agent du projet. Je peux intervenir sur la structure, les cartes de rôle, les pages, le mini-site, les médias et la publication. Consultez **À terminer** pour exécuter les prochaines actions concrètes.` };
  }

  if (q.match(/budget|cout|prix|depense|€|eur/)) {
    return {
      text: `**Budget mariage en France**\n\nMoyenne nationale : **18 000 – 25 000 €** (80-100 invités).\n\n• Réception/salle : 30-40 %\n• Traiteur : 25-35 % (45–90 €/pers.)\n• Photo/Vidéo : 8-12 %\n• Fleurs & décoration : 8-10 %\n• Tenue mariée + costume : 5-8 %\n• DJ/Musique : 3-5 %\n• Imprimés (invitations, menus) : 1-2 %\n\n💡 Réservez 5 % du budget pour les imprévus. Consultez votre tableau Budget dans l'app.`,
      action: { type: 'navigate', lotId: 11, label: 'Ouvrir le Budget' },
    };
  }

  if (q.match(/traiteur|repas|menu|nourriture|cocktail|diner|buffet/)) {
    return {
      text: `**Choisir son traiteur**\n\n• Réservez **12-18 mois** à l'avance\n• Exigez une dégustation gratuite\n• Vérifiez l'assurance responsabilité civile\n• Demandez: est-ce maison ou sous-traité ?\n\n**Tarifs indicatifs :**\n• Cocktail seul : 25-45 €/pers.\n• Dîner assis servi : 70-130 €/pers.\n• Brunch lendemain : 30-55 €/pers.\n\n🌿 Tendance 2025 : menus végétaux, produits locaux, fromages AOP.`,
    };
  }

  if (q.match(/photo|photographe|video|film|reportage/)) {
    return {
      text: `**Photo & Vidéo**\n\n• Bookez **avant** le traiteur (les meilleurs : 18-24 mois à l'avance)\n• Vérifiez les droits d'image dans le contrat\n• Demandez livraison RAW + retouchées\n• Délai de livraison : 6-12 semaines\n\n**Budget :**\n• Photographe seul : 1 500 – 4 000 €\n• Vidéaste seul : 1 200 – 3 500 €\n• Duo photo+vidéo : 3 000 – 6 500 €\n\n📋 Préparez une liste de 20-30 photos indispensables à remettre au photographe J-1.`,
    };
  }

  if (q.match(/programme|planning|horaire|deroul|jour j|ceremonie/)) {
    return {
      text: `**Déroulé type d'une journée**\n\n🕘 **09h00** — Préparatifs mariée\n🕙 **10h30** — Préparatifs marié\n🕛 **12h00** — Cocktail déjeunatoire (optionnel)\n🕑 **14h00** — Cérémonie (civile ou laïque)\n🕓 **15h30** — Cocktail & photos\n🕖 **19h30** — Entrée en salle\n🕗 **20h00** — Dîner\n🕙 **22h30** — Pièce montée + ouverture de bal\n🕛 **00h00** — Soirée dansante\n\n⚠️ Prévoyez 30 min de marge entre chaque moment clé.`,
      action: { type: 'navigate', lotId: 1, label: 'Voir le programme' },
    };
  }

  if (q.match(/invite|rsvp|liste|invitation|convive|table/)) {
    return {
      text: `**Gestion des invités**\n\n📅 **Calendrier :**\n• J-12 mois : liste A + B\n• J-8 mois : faire-parts en précommande\n• J-6 mois : envoi des invitations\n• J-2 mois : deadline RSVP\n• J-3 sem : plan de table définitif\n\n📊 **Taux de présence moyen :** 85-90 %\n\n💡 Prévoyez toujours +10 % de désistements last minute. Votre mini-site peut collecter les RSVP en ligne !`,
    };
  }

  if (q.match(/fleur|deco|decoration|bouquet|arrangement/)) {
    return {
      text: `**Fleurs & Décoration**\n\n✅ Éléments essentiels :\n• Bouquet mariée + boutonnière\n• Centres de table (frais ou séchés)\n• Arche / backdrop cérémonie\n• Pétales & chemin de fleurs\n\n💰 **Budget moyen :** 1 500 – 4 500 €\n\n🌿 **Tendances 2025 :** fleurs séchées (pampas, gypsophile), eucalyptus, palette terracotta & sage. Marché de Rungis (IdF) : -40 % vs fleuriste traditionnel.`,
    };
  }

  if (q.match(/musique|dj|playlist|groupe|son|ambiance|orchestre/)) {
    return {
      text: `**Musique & Animation**\n\n🎵 **Options :**\n• DJ : 800-2 500 € (versatile, catalogue illimité)\n• Groupe live : 1 500-5 000 €\n• Quartet/Pianiste : idéal cérémonie laïque\n• Formule hybride DJ + musiciens live\n\n**5 moments à musicaliser :**\n1. Entrée cortège\n2. Entrée mariée\n3. Cocktail (fond musical)\n4. Entrée en salle\n5. Ouverture de bal\n\nConfigurez vos playlists dans l'app !`,
      action: { type: 'navigate', lotId: 9, label: 'Musique cérémonie' },
    };
  }

  if (q.match(/lieu|salle|chateau|domaine|venue|reception|espace/)) {
    return {
      text: `**Choisir son lieu**\n\n📋 **Critères clés :**\n• Capacité = invités + 20 %\n• Hébergement sur place ?\n• Exclusivité totale de la date ?\n• Traiteur imposé ou libre ?\n• Heure de fin de fête ?\n• Plan B intérieur si pluie ?\n\n💰 **Fourchettes :**\n• Château/Manoir : 3 000-15 000 €/j\n• Domaine rural : 2 000-8 000 €/j\n• Salle communale : 500-1 500 €/j\n\n📅 Réservez **12-24 mois** à l'avance pour les beaux domaines.`,
      action: { type: 'navigate', lotId: 2, label: 'Voir les lieux' },
    };
  }

  if (q.match(/temoin|honneur|evjf|evg|garcon|demoiselle/)) {
    return {
      text: `**Les Témoins**\n\n📜 **Rôle légal :** signature de l'acte de mariage. Max 2 par marié (4 au total).\n\n🎉 **Rôle traditionnel :**\n• Organisation EVJF/EVG (1-3 mois avant)\n• Discours/toast lors du dîner\n• Coordination logistique Jour J\n• Référent pour les invités\n\n💡 Donnez leur accès au mode **Témoins** du mini-site pour leur briefing personnalisé !`,
    };
  }

  if (q.match(/legalement|mairie|etat civil|dossier|administratif|bans/)) {
    return {
      text: `**Démarches administratives**\n\n📋 **Pièces mairie (J-30 jours min.) :**\n• Acte de naissance de moins de 3 mois\n• Pièce d'identité\n• Justificatif de domicile\n• Informations sur les témoins\n• Contrat de mariage (si régime choisi)\n\n⚖️ **Régimes matrimoniaux :**\n• Communauté réduite aux acquêts (défaut)\n• Séparation de biens\n• Communauté universelle\n\n💡 Consultez un notaire pour le contrat de mariage — acte à faire **avant** le mariage.`,
    };
  }

  if (q.match(/surprise|cacher|secret|dissimuler/)) {
    return {
      text: `**Mode Surprise**\n\nLe mode Surprise dans votre mini-site masque automatiquement les moments confidentiels aux mariés.\n\n✅ Activez-le pour :\n• Organiser les surprises entre témoins\n• Cacher des prestations spéciales\n• Bloquer les créneaux réservés aux surprises\n\n⚠️ Si les mariés tentent de placer un événement sur un créneau "Surprise", l'app les avertira de choisir un autre horaire.`,
    };
  }

  if (q.match(/bonjour|salut|aide|help|commencer|debut|start|bienvenue/)) {
    return {
      text: `Bonjour ! Je suis votre assistant **Le Monde Aime** 💍\n\nSpécialisé en organisation de mariages en France, je peux vous conseiller sur :\n\n• 💰 Budget & coûts\n• 📋 Programme de la journée\n• 🍽️ Traiteur & menu\n• 📸 Photo & vidéo\n• 🌸 Fleurs & décoration\n• 🎵 Musique & animation\n• 🏛️ Lieu de réception\n• 💌 Invités & RSVP\n• ⚖️ Démarches administratives\n• 💎 Témoins & surprises\n\nPar quoi commençons-nous ?`,
    };
  }

  if (q.match(/merci|super|parfait|genial|excellent|bravo|top/)) {
    return { text: `Avec plaisir ! 🎊 Je suis là pour vous aider à construire la journée parfaite. N'hésitez pas si vous avez d'autres questions.` };
  }

  return {
    text: `Je suis votre assistant mariage spécialisé. Posez-moi vos questions sur :\n\n💰 Budget · 📋 Programme · 🍽️ Traiteur · 📸 Photo · 🌸 Fleurs · 🎵 Musique · 🏛️ Lieu · 💌 Invités · ⚖️ Administratif · 💎 Témoins & Surprises\n\nQue souhaitez-vous savoir ?`,
  };
}

// ── T&C Modal ─────────────────────────────────────────────────────────────────

const TermsModal: React.FC<{ onAccept: () => void; onDecline: () => void; isDark: boolean }> = ({ onAccept, onDecline, isDark }) => {
  const tokens = getStudioTokens(isDark);
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.52)', backdropFilter: 'blur(6px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}
    >
      <motion.div
        initial={{ scale: .96, y: 14 }} animate={{ scale: 1, y: 0 }} exit={{ scale: .96, y: 14 }}
        style={{ background: tokens.surface, color: tokens.text, borderRadius: 16, padding: 28, maxWidth: 440, width: '100%', boxShadow: '0 24px 64px rgba(0,0,0,.34)', border: `1px solid ${tokens.border}` }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ width: 40, height: 40, borderRadius: 10, background: tokens.surface2, border: `1px solid ${tokens.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Bot size={20} color={tokens.text} /></div>
          <div><div style={{ fontSize: 15, fontWeight: 750 }}>Assistant du projet</div><div style={{ fontSize: 10.5, color: tokens.muted, marginTop: 2 }}>Le Monde Aime · local + AIME CORE</div></div>
        </div>
        <div style={{ fontSize: 12.5, color: tokens.muted, lineHeight: 1.65, marginBottom: 20 }}>
          <p style={{ margin: '0 0 11px', fontWeight: 700, color: tokens.text }}>Utilisation de l’assistant</p>
          <p style={{ margin: '0 0 9px' }}>L’assistant analyse les données du projet visibles dans cette application, propose des actions et peut ouvrir certains outils après votre demande.</p>
          <p style={{ margin: '0 0 9px' }}>Les conversations sont conservées localement dans ce navigateur et dans les données du projet. Elles ne sont pas synchronisées entre appareils tant qu’aucun espace cloud n’est connecté.</p>
          <p style={{ margin: 0 }}>Lorsqu’AIME CORE est configuré, votre demande et un contexte limité du projet sont envoyés à la fonction sécurisée du studio. Les modifications restent proposées et ne sont appliquées qu’après votre confirmation explicite.</p>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <button onClick={onDecline} style={{ flex: 1, height: 38, borderRadius: 9, border: `1px solid ${tokens.border}`, background: 'transparent', color: tokens.muted, cursor: 'pointer', fontSize: 11.5, fontWeight: 600 }}>Refuser</button>
          <button onClick={onAccept} style={{ flex: 2, height: 38, borderRadius: 9, border: 0, background: tokens.primary, color: tokens.primaryText, cursor: 'pointer', fontSize: 11.5, fontWeight: 750, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}><Check size={14} /> Accepter et continuer</button>
        </div>
      </motion.div>
    </motion.div>
  );
};

// ── Message renderer ───────────────────────────────────────────────────────────

const MsgText: React.FC<{ text: string; isDark: boolean }> = ({ text, isDark }) => {
  const lines = text.split('\n');
  return (
    <div style={{ fontFamily: 'Inter', fontSize: '12.5px', lineHeight: 1.65, color: isDark ? 'rgba(240,238,248,0.9)' : '#2A2A3A' }}>
      {lines.map((line, i) => {
        const bold = line.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
        if (line.startsWith('• ') || line.startsWith('✅ ') || line.startsWith('📋 ') || line.match(/^[🕘🕙🕛🕑🕓🕖🕗🕙🕛💡⚠️📅📊💰🎵📸🌿⚖️🎉📜💎💍👋]/)) {
          return <div key={i} style={{ marginBottom: '3px' }} dangerouslySetInnerHTML={{ __html: bold }} />;
        }
        if (line === '') return <div key={i} style={{ height: '6px' }} />;
        return <div key={i} dangerouslySetInnerHTML={{ __html: bold }} />;
      })}
    </div>
  );
};

// ── Guided dot ────────────────────────────────────────────────────────────────

const GuidedDot: React.FC<{ visible: boolean; targetEl?: string }> = ({ visible }) => (
  <AnimatePresence>
    {visible && (
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [1, 1.3, 1], opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
        transition={{ repeat: Infinity, duration: 1.4 }}
        style={{ position: 'fixed', bottom: '90px', right: '80px', width: '12px', height: '12px', borderRadius: '50%', background: '#D4D4D8', boxShadow: '0 0 0 4px rgba(212,212,216,.16)', zIndex: 1200, pointerEvents: 'none' }}
      />
    )}
  </AnimatePresence>
);

// ── Main component ─────────────────────────────────────────────────────────────

export interface AIAgentProps {
  lots: WeddingLot[];
  cardSettings: Record<string, any>;
  viewMode: string;
  onNavigateLot?: (lot: WeddingLot) => void;
  onAction?: (action: string) => void;
  externalOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  onThinkingChange?: (thinking: boolean) => void;
  onNewMessage?: () => void;
  projectUniverse?: string;
  projectName?: string;
  projectStatus?: 'draft' | 'published';
  selectedCount?: number;
  canvasElementCount?: number;
  selectedObjectLabel?: string;
  selectedObjectKind?: string;
}

export const AIAgent: React.FC<AIAgentProps> = ({ lots, cardSettings, viewMode, onNavigateLot, onAction, externalOpen, onOpenChange, onThinkingChange, onNewMessage, projectUniverse = 'mariage', projectName = 'Votre projet', projectStatus = 'draft', selectedCount = 0, canvasElementCount = 0, selectedObjectLabel = '', selectedObjectKind = '' }) => {
  const { isDark } = useTheme();
  const [internalOpen, setInternalOpen] = useState(false);
  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = (v: boolean) => { setInternalOpen(v); onOpenChange?.(v); };
  const [showTerms, setShowTerms] = useState(false);
  const [termsAccepted] = useState(() => !!getProjectItem('lma_agent_accepted'));
  const [accepted, setAccepted] = useState(termsAccepted);
  const [messages, setMessages] = useState<{ id: string; role: 'user' | 'agent'; text: string; ts: Date; action?: any }[]>([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [guidedDot, setGuidedDot] = useState(false);
  const [activeTab, setActiveTab] = useState<'agent' | 'tasks'>('agent');
  const [remoteMode, setRemoteMode] = useState<'unknown' | 'connected' | 'local'>('unknown');
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const tokens = getStudioTokens(isDark);
  const surf = tokens.surface;
  const surf2 = tokens.surface2;
  const surf3 = tokens.surface3;
  const border = tokens.border;
  const textPrimary = tokens.text;
  const textSecondary = tokens.muted;

  const tasks = useMemo(() => {
    const setupComplete = getProjectItem('lma_setup_complete') === '1';
    const heroReady = Boolean(getProjectItem('lma_hero_photo'));
    const miniSiteContent = getProjectItem('lma_minisite_content');
    const result: Array<{ id: string; severity: 'critical' | 'warning' | 'ready'; title: string; detail: string; action?: AgentActionId; actionLabel?: string }> = [];

    if (projectUniverse === 'mariage' && !setupComplete) result.push({ id: 'setup', severity: 'critical', title: 'Informations du mariage incomplètes', detail: 'Le couple, la date ou le lieu doivent être reliés au canvas.', action: 'open-organize', actionLabel: 'Compléter' });
    if (projectUniverse !== 'mariage' && canvasElementCount === 0) result.push({ id: 'role', severity: 'critical', title: 'Aucune carte de rôle', detail: 'Le projet n’a pas encore son point d’entrée universel.', action: 'generate-role', actionLabel: 'Générer la carte' });
    if (['mariage','evenement','site','portfolio'].includes(projectUniverse) && !heroReady) result.push({ id: 'hero', severity: 'warning', title: 'Visuel principal manquant', detail: 'Ajoutez le média qui représentera le projet et son mini-site.', action: 'open-media', actionLabel: 'Choisir un média' });
    if (projectUniverse === 'mariage' && selectedCount === 0) result.push({ id: 'cards', severity: 'critical', title: 'Mini-site sans contenu connecté', detail: 'Aucune carte du mariage n’alimente encore le mini-site.', action: 'generate-minisite', actionLabel: 'Connecter automatiquement' });
    if (!miniSiteContent) result.push({ id: 'minisite', severity: 'warning', title: 'Textes du mini-site à préparer', detail: 'La structure existe, mais ses contenus n’ont pas encore été personnalisés.', action: 'open-minisite', actionLabel: 'Ouvrir le mini-site' });
    if (projectStatus !== 'published') result.push({ id: 'publish', severity: 'warning', title: 'Projet en brouillon', detail: 'Vérifiez l’aperçu avant de choisir les formats de publication.', action: 'open-publish', actionLabel: 'Préparer la publication' });
    if (!result.some((task) => task.severity !== 'ready')) result.push({ id: 'ready', severity: 'ready', title: 'Projet prêt', detail: 'Aucune alerte bloquante détectée sur le canvas.' });
    return result;
  }, [canvasElementCount, projectStatus, projectUniverse, selectedCount, open]);

  const suggestions = useMemo(() => {
    if (selectedObjectKind === 'element') return ['Créer 3 Covers', 'Utiliser comme inspiration', 'Prolonger cet élément', 'Voir ses droits de remix'];
    if (selectedObjectKind === 'plan' && selectedObjectLabel) return [`Remixer ${selectedObjectLabel}`, 'Créer 3 Covers', 'Recadrer le plan', 'Exporter son ADN'];
    if (viewMode === 'minisite') return ['Créer la version mobile', 'Proposer 3 Covers', 'Améliorer l’accessibilité', 'Compléter les contenus'];
    if (viewMode === 'timeline') return ['Détecter les conflits', 'Créer un Cover éditorial', 'Ajouter des temps tampons', 'Version invités'];
    if (selectedCount > 0) return ['Harmoniser la sélection', 'Créer une variante', 'Relier au mini-site', 'Organiser automatiquement'];
    return projectUniverse === 'mariage'
      ? ['Ouvrir Point Zéro', 'Créer un mini-site musicien', 'Harmoniser les couleurs', 'Analyser le projet']
      : ['Ouvrir Point Zéro', 'Créer la structure', 'Harmoniser les couleurs', 'Préparer la publication'];
  }, [projectUniverse, selectedCount, selectedObjectKind, selectedObjectLabel, viewMode]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking]);

  // When external trigger opens the agent, check T&C first
  useEffect(() => {
    if (externalOpen && !accepted) {
      setShowTerms(true);
      onOpenChange?.(false);
    } else if (externalOpen && accepted && messages.length === 0) {
      setTimeout(() => {
        setMessages([{ id: '0', role: 'agent', text: welcomeMessage(projectUniverse, projectName), ts: new Date() }]);
      }, 300);
      setTimeout(() => inputRef.current?.focus(), 400);
    }
  }, [externalOpen]);

  const handleOpen = useCallback(() => {
    if (!accepted) {
      setShowTerms(true);
    } else {
      setOpen(true);
      if (messages.length === 0) {
        setTimeout(() => {
          setMessages([{ id: '0', role: 'agent', text: welcomeMessage(projectUniverse, projectName), ts: new Date() }]);
        }, 300);
      }
      setTimeout(() => inputRef.current?.focus(), 400);
    }
  }, [accepted, messages.length]);

  const handleAccept = useCallback(() => {
    setProjectItem('lma_agent_accepted', '1');
    setAccepted(true);
    setShowTerms(false);
    setOpen(true);
    setTimeout(() => {
      setMessages([{ id: '0', role: 'agent', text: welcomeMessage(projectUniverse, projectName), ts: new Date() }]);
    }, 400);
  }, []);

  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || thinking) return;
    const uid = Date.now().toString();
    setInput('');
    setMessages((prev) => [...prev, { id: uid, role: 'user', text, ts: new Date() }]);
    setThinking(true);
    onThinkingChange?.(true);

    const log = JSON.parse(getProjectItem('lma_agent_log') || '[]');
    log.push({ role: 'user', text, ts: new Date().toISOString(), view: viewMode });
    setProjectItem('lma_agent_log', JSON.stringify(log.slice(-200)));

    let agentText = '';
    let action: any;
    try {
      const cardSummary = lots.flatMap((lot) => lot.cards.map((card) => ({
        id: card.id,
        name: card.name,
        time: typeof cardSettings[card.id]?.time === 'string' ? cardSettings[card.id].time : undefined,
        status: typeof cardSettings[card.id]?.status === 'string' ? cardSettings[card.id].status : undefined,
      }))).slice(0, 90);
      const connected = await askAimeCore(text, {
        projectName,
        universe: projectUniverse,
        viewMode,
        selectedObject: selectedObjectLabel ? { kind: selectedObjectKind || 'object', label: selectedObjectLabel } : undefined,
        selectedCardCount: selectedCount,
        canvasElementCount,
        cardSummary,
        domain: buildAgentDomainContext(projectUniverse as ProjectUniverse),
      }, messages.map((message) => ({ role: message.role, text: message.text })));
      agentText = connected.text;
      action = connected.proposals.length ? { type: 'proposals', items: connected.proposals, confidence: connected.confidence } : undefined;
      setRemoteMode('connected');
    } catch {
      const local = getAgentResponse(text, lots, cardSettings, projectUniverse);
      agentText = local.text;
      action = local.action;
      setRemoteMode('local');
      const normalized = text.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      if (normalized.match(/point zero|point zéro|audit|eaa|wcag|rgaa|importer.*zip|archive zip/)) window.dispatchEvent(new CustomEvent('lma-point-zero-toggle', { detail: { open: true } }));
      if (normalized.match(/couleur|palette|triade|complementaire|complémentaire|nuancier|arc.?en.?ciel|chromatique/)) window.dispatchEvent(new CustomEvent('lma-chromatic-toggle', { detail: { open: true } }));
    }

    const aid = (Date.now() + 1).toString();
    setMessages((prev) => [...prev, { id: aid, role: 'agent', text: agentText, ts: new Date(), action }]);
    setThinking(false);
    onThinkingChange?.(false);
    if (!externalOpen) onNewMessage?.();

    const log2 = JSON.parse(getProjectItem('lma_agent_log') || '[]');
    log2.push({ role: 'agent', text: agentText, ts: new Date().toISOString(), action, mode: action?.type === 'proposals' ? 'aime-core' : 'local' });
    setProjectItem('lma_agent_log', JSON.stringify(log2.slice(-200)));
    if (action?.type === 'navigate') {
      setGuidedDot(true);
      setTimeout(() => setGuidedDot(false), 4000);
    }
  }, [canvasElementCount, cardSettings, externalOpen, input, lots, messages, onAction, onNewMessage, onThinkingChange, projectName, projectUniverse, selectedCount, selectedObjectKind, selectedObjectLabel, thinking, viewMode]);

  const handleNavigate = useCallback((lotId: number) => {
    const lot = lots.find((l) => l.id === lotId);
    if (lot && onNavigateLot) {
      onNavigateLot(lot);
      setOpen(false);
    }
  }, [lots, onNavigateLot]);

  const formatTime = (d: Date) => d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

  return (
    <>
      <GuidedDot visible={guidedDot} />

      <AnimatePresence>{showTerms && <TermsModal isDark={isDark} onAccept={handleAccept} onDecline={() => setShowTerms(false)} />}</AnimatePresence>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.96 }}
            transition={{ type: 'spring', damping: 28, stiffness: 340 }}
            style={{
              position: 'fixed', top: '50px', right: 0, width: 'min(390px, calc(100vw - 24px))', height: 'calc(100vh - 50px)',
              background: surf, borderRadius: 0,
              boxShadow: isDark ? '-18px 0 54px rgba(0,0,0,0.32), -1px 0 0 rgba(255,255,255,0.07)' : '-18px 0 54px rgba(0,0,0,0.10), -1px 0 0 rgba(0,0,0,0.08)',
              zIndex: 500, display: 'flex', flexDirection: 'column', overflow: 'hidden',
            }}
          >
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '14px 16px', borderBottom: `1px solid ${border}`, background: surf, flexShrink: 0 }}>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: surf2, border: `1px solid ${border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Bot size={16} color={textPrimary} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 700, color: textPrimary }}>Assistant LMA</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontFamily: 'Inter', fontSize: '10px', color: textSecondary }}>
                  <div style={{ width: '5px', height: '5px', borderRadius: '50%', background: tokens.selection }} />
                  {remoteMode === 'connected' ? 'AIME CORE · Connecté' : remoteMode === 'local' ? 'Assistant du projet · Local' : 'Assistant du projet · Prêt'}
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                style={{ width: '28px', height: '28px', borderRadius: '7px', border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: textSecondary, flexShrink: 0 }}
              >
                <ChevronDown size={16} />
              </button>
            </div>

            <div style={{ display: 'flex', gap: 4, padding: '8px 10px', borderBottom: `1px solid ${border}`, background: surf, flexShrink: 0 }}>
              <button onClick={() => setActiveTab('agent')} style={{ flex: 1, height: 30, border: 0, borderRadius: 8, background: activeTab === 'agent' ? surf2 : 'transparent', color: activeTab === 'agent' ? textPrimary : textSecondary, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 10, fontWeight: 700 }}><MessageCircle size={12} /> Agent</button>
              <button onClick={() => setActiveTab('tasks')} style={{ flex: 1, height: 30, border: 0, borderRadius: 8, background: activeTab === 'tasks' ? surf2 : 'transparent', color: activeTab === 'tasks' ? textPrimary : textSecondary, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 10, fontWeight: 700 }}><ListTodo size={12} /> À terminer <span style={{ minWidth: 18, height: 18, borderRadius: 9, display: 'grid', placeItems: 'center', background: surf3, color: textSecondary, fontSize: 8 }}>{tasks.filter((task) => task.severity !== 'ready').length}</span></button>
            </div>
            <div style={{ padding: '7px 12px', borderBottom: `1px solid ${border}`, background: surf2, color: textSecondary, fontSize: 8.8, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Sparkles size={11} color={textSecondary} />
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{selectedObjectLabel ? `Contexte actif : ${selectedObjectLabel}` : `Contexte actif : ${projectName}`}</span>
            </div>

            {/* Messages / executable tasks */}
            {activeTab === 'agent' ? <div style={{ flex: 1, overflowY: 'auto', padding: '14px 14px 8px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {messages.map((msg) => (
                <div key={msg.id} style={{ display: 'flex', flexDirection: 'column', alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                  <div
                    style={{
                      maxWidth: '90%', padding: '10px 13px', borderRadius: msg.role === 'user' ? '12px 12px 4px 12px' : '12px 12px 12px 4px',
                      background: msg.role === 'user' ? surf3 : surf2,
                       border: `1px solid ${border}`,
                    }}
                  >
                    {msg.role === 'user' ? (
                      <div style={{ fontFamily: 'Inter', fontSize: '12.5px', color: textPrimary, lineHeight: 1.5 }}>{msg.text}</div>
                    ) : (
                      <MsgText text={msg.text} isDark={isDark} />
                    )}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '3px', padding: '0 4px' }}>
                    <Clock size={9} color={textSecondary} />
                    <span style={{ fontFamily: 'Inter', fontSize: '9px', color: textSecondary }}>{formatTime(msg.ts)}</span>
                  </div>
                  {msg.action?.type === 'navigate' && (
                    <button
                      onClick={() => handleNavigate(msg.action.lotId)}
                      style={{ marginTop: '6px', display: 'flex', alignItems: 'center', gap: '5px', background: surf2, border: `1px solid ${border}`, borderRadius: '8px', padding: '5px 10px', cursor: 'pointer', fontFamily: 'Inter', fontSize: '11px', fontWeight: 600, color: textPrimary }}
                    >
                      <MapPin size={11} /> {msg.action.label} <ArrowRight size={11} />
                    </button>
                  )}
                  {msg.action?.type === 'proposals' && Array.isArray(msg.action.items) && (
                    <div style={{ width: '90%', marginTop: 7, display: 'grid', gap: 6 }}>
                      {(msg.action.items as AgentProposal[]).map((proposal) => (
                        <button key={proposal.id} title={proposal.rationale} onClick={() => onAction?.(proposal.action)} style={{ minHeight: 34, padding: '7px 9px', borderRadius: 8, border: `1px solid ${border}`, background: surf3, color: textPrimary, cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 7, fontSize: 9.5, fontWeight: 760 }}><Wand2 size={12} /> <span style={{ flex: 1 }}>{proposal.label}</span><ArrowRight size={11} /></button>
                      ))}
                      <div style={{ color: textSecondary, fontSize: 8, padding: '0 3px' }}>Confiance {Math.round(Number(msg.action.confidence || 0) * 100)} % · aucune action appliquée sans clic.</div>
                    </div>
                  )}
                </div>
              ))}
              {thinking && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '10px 13px', background: surf2, borderRadius: '12px 12px 12px 4px', width: 'fit-content', border: `1px solid ${border}` }}>
                  <Loader2 size={12} color={textSecondary} style={{ animation: 'spin 1s linear infinite' }} />
                  <span style={{ fontFamily: 'Inter', fontSize: '11px', color: textSecondary }}>En réflexion…</span>
                </div>
              )}
              <div ref={bottomRef} />
            </div> : <div style={{ flex: 1, overflowY: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ padding: '4px 3px 8px' }}><div style={{ fontSize: 12, fontWeight: 800, color: textPrimary }}>Diagnostic du canvas</div><div style={{ fontSize: 9.5, lineHeight: 1.45, color: textSecondary, marginTop: 4 }}>Cliquez sur une action : l’agent ouvre ou génère réellement l’élément concerné.</div></div>
              {tasks.map((task) => {
                const critical = task.severity === 'critical';
                const ready = task.severity === 'ready';
                const accent = ready ? tokens.success : critical ? tokens.danger : tokens.warning;
                return <div key={task.id} style={{ borderRadius: 11, border: `1px solid ${border}`, background: surf2, padding: 11 }}>
                  <div style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
                    <span style={{ color: accent, marginTop: 1 }}>{ready ? <CheckCircle2 size={14} /> : critical ? <AlertCircle size={14} /> : <Sparkles size={14} />}</span>
                    <div style={{ flex: 1 }}><div style={{ color: textPrimary, fontSize: 10.5, fontWeight: 800 }}>{task.title}</div><div style={{ color: textSecondary, fontSize: 9.2, lineHeight: 1.45, marginTop: 4 }}>{task.detail}</div></div>
                  </div>
                  {task.action && <button onClick={() => onAction?.(task.action!)} style={{ width: '100%', height: 30, marginTop: 9, borderRadius: 8, border: `1px solid ${border}`, background: surf3, color: textPrimary, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 9.5, fontWeight: 800 }}><Wand2 size={12} /> {task.actionLabel}</button>}
                </div>;
              })}
            </div>}

            {/* Suggestions + input */}
            {activeTab === 'agent' && <div style={{ padding: '9px 10px 10px', borderTop: `1px solid ${border}`, flexShrink: 0, background: surf }}>
              <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 8 }}>
                {suggestions.map((suggestion) => <button key={suggestion} onClick={() => { setInput(suggestion); setTimeout(() => inputRef.current?.focus(), 0); }} style={{ flex: '0 0 auto', height: 25, padding: '0 9px', borderRadius: 999, border: `1px solid ${border}`, background: surf2, color: textSecondary, cursor: 'pointer', fontSize: 8.8, whiteSpace: 'nowrap' }}>{suggestion}</button>)}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
                placeholder="Posez votre question…"
                style={{
                  flex: 1, padding: '9px 13px', borderRadius: '9px', border: `1px solid ${border}`,
                  background: surf2, fontFamily: 'Inter', fontSize: '12px', color: textPrimary, outline: 'none',
                }}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || thinking}
                style={{
                  width: '38px', height: '38px', borderRadius: '9px', border: 'none', flexShrink: 0,
                  background: input.trim() && !thinking ? tokens.primary : surf2,
                  cursor: input.trim() && !thinking ? 'pointer' : 'default',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: input.trim() && !thinking ? tokens.primaryText : textSecondary, transition: 'all 0.15s',
                }}
              >
                <Send size={14} />
              </button>
              </div>
            </div>}
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </>
  );
};
