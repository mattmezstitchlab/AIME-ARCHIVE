import React, { useMemo, useState } from 'react';
import { ChevronDown, ChevronRight, X } from 'lucide-react';
import type { CardStatus, WeddingLot } from '../types';
import { ICON_MAP } from '../utils/iconMap';
import { useTheme } from '../contexts/ThemeContext';
import { getStudioTokens } from '../theme/studioTokens';

interface BudgetDashboardProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  totalBudget: number;
  onTotalBudgetChange: (value: number) => void;
  onClose: () => void;
}

const STATUS_LABELS: Record<CardStatus, string> = { todo: 'À faire', waiting: 'En attente', confirmed: 'Confirmé', paid: 'Payé' };

function formatEur(value: number) {
  return value.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
}

export const BudgetDashboard: React.FC<BudgetDashboardProps> = ({ lots, cardSettings, totalBudget, onTotalBudgetChange, onClose }) => {
  const { isDark } = useTheme();
  const tokens = getStudioTokens(isDark);
  const [expandedLots, setExpandedLots] = useState<Set<number>>(new Set());
  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetInput, setBudgetInput] = useState(String(totalBudget));

  const stats = useMemo(() => {
    let engaged = 0;
    let deposits = 0;
    const lotStats = lots.map((lot) => {
      let lotBudget = 0;
      let lotDeposit = 0;
      const cards = lot.cards.map((card) => {
        const settings = cardSettings[card.id] || {};
        const budget = Number(settings.budget) || 0;
        const deposit = Number(settings.acompte) || 0;
        lotBudget += budget;
        lotDeposit += deposit;
        return { card, budget, deposit, status: (settings.status as CardStatus) || 'todo' };
      });
      engaged += lotBudget;
      deposits += lotDeposit;
      return { lot, lotBudget, lotDeposit, cards };
    });
    return { engaged, deposits, remaining: totalBudget - engaged, lotStats };
  }, [cardSettings, lots, totalBudget]);

  const safeTotal = Math.max(totalBudget, stats.engaged, 1);
  const engagedWithoutDeposit = Math.max(stats.engaged - stats.deposits, 0);
  const p1 = Math.min(100, engagedWithoutDeposit / safeTotal * 100);
  const p2 = Math.min(100, p1 + stats.deposits / safeTotal * 100);
  const donut = `conic-gradient(${tokens.text} 0 ${p1}%, ${tokens.muted} ${p1}% ${p2}%, ${tokens.surface3} ${p2}% 100%)`;

  const commitBudget = () => {
    const value = Number(budgetInput);
    if (Number.isFinite(value) && value >= 0) onTotalBudgetChange(value);
    setEditingBudget(false);
  };

  return (
    <aside style={{ position: 'fixed', top: 50, right: 0, bottom: 0, width: 'min(420px,calc(100vw - 24px))', zIndex: 520, background: tokens.surface, color: tokens.text, borderLeft: `1px solid ${tokens.border}`, display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif', boxShadow: '-18px 0 54px rgba(0,0,0,.28)' }}>
      <header style={{ height: 54, padding: '0 18px', display: 'flex', alignItems: 'center', borderBottom: `1px solid ${tokens.border}`, flexShrink: 0 }}>
        <div style={{ flex: 1 }}><div style={{ fontSize: 14, fontWeight: 800 }}>Budget</div><div style={{ marginTop: 2, fontSize: 8.5, color: tokens.muted }}>Enveloppe, engagements et acomptes du projet</div></div>
        <button onClick={onClose} aria-label="Fermer" style={{ width: 30, height: 30, borderRadius: 8, border: 0, background: 'transparent', color: tokens.muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={16} /></button>
      </header>

      <div style={{ flex: 1, overflowY: 'auto', padding: 18, scrollbarWidth: 'none' }}>
        <section style={{ padding: 15, borderRadius: 12, background: tokens.surface2, border: `1px solid ${tokens.border}` }}>
          <div style={{ color: tokens.muted, fontSize: 8.5, textTransform: 'uppercase', letterSpacing: '.1em', marginBottom: 7 }}>Enveloppe totale</div>
          {editingBudget ? <input autoFocus type="number" min={0} value={budgetInput} onChange={(event) => setBudgetInput(event.target.value)} onBlur={commitBudget} onKeyDown={(event) => event.key === 'Enter' && commitBudget()} style={{ width: '100%', border: 0, outline: 0, background: 'transparent', color: tokens.text, fontSize: 27, fontWeight: 800 }} /> : <button onClick={() => { setBudgetInput(String(totalBudget)); setEditingBudget(true); }} style={{ padding: 0, border: 0, background: 'transparent', color: tokens.text, fontSize: 27, fontWeight: 800, cursor: 'text' }}>{formatEur(totalBudget)}</button>}
        </section>

        <section style={{ marginTop: 12, padding: 15, borderRadius: 12, background: tokens.surface2, border: `1px solid ${tokens.border}`, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 112, height: 112, borderRadius: '50%', background: donut, display: 'grid', placeItems: 'center', flexShrink: 0 }}><div style={{ width: 72, height: 72, borderRadius: '50%', background: tokens.surface2, display: 'grid', placeItems: 'center', fontSize: 9, color: tokens.muted }}>{totalBudget > 0 ? `${Math.min(100, Math.round(stats.engaged / totalBudget * 100))}%` : '0%'}</div></div>
          <div style={{ flex: 1, display: 'grid', gap: 10 }}>
            <Metric label="Engagé" value={formatEur(stats.engaged)} tokens={tokens} />
            <Metric label="Acomptes versés" value={formatEur(stats.deposits)} tokens={tokens} />
            <Metric label="Restant" value={formatEur(stats.remaining)} tokens={tokens} alert={stats.remaining < 0} />
          </div>
        </section>

        <div style={{ margin: '18px 2px 8px', color: tokens.muted, fontSize: 8.5, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase' }}>Répartition</div>
        <div style={{ display: 'grid', gap: 7 }}>
          {stats.lotStats.map(({ lot, lotBudget, cards }) => {
            const expanded = expandedLots.has(lot.id);
            const detailed = cards.filter((item) => item.budget > 0);
            return <section key={lot.id} style={{ borderRadius: 10, background: tokens.surface2, border: `1px solid ${tokens.border}`, overflow: 'hidden' }}>
              <button onClick={() => setExpandedLots((current) => { const next = new Set(current); if (next.has(lot.id)) next.delete(lot.id); else next.add(lot.id); return next; })} style={{ width: '100%', minHeight: 42, padding: '8px 11px', border: 0, background: 'transparent', color: tokens.text, display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer', textAlign: 'left' }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: tokens.selection, opacity: lotBudget > 0 ? 1 : .35 }} />
                <span style={{ flex: 1, fontSize: 10.5, fontWeight: 650 }}>{lot.title}</span>
                <span style={{ color: lotBudget > 0 ? tokens.text : tokens.muted, fontSize: 10.5, fontWeight: 750 }}>{formatEur(lotBudget)}</span>
                {expanded ? <ChevronDown size={13} color={tokens.muted} /> : <ChevronRight size={13} color={tokens.muted} />}
              </button>
              {expanded && <div style={{ padding: '0 11px 9px', borderTop: `1px solid ${tokens.border}` }}>
                {detailed.length ? detailed.map(({ card, budget, status }) => { const Icon = ICON_MAP[card.icon]; return <div key={card.id} style={{ minHeight: 35, display: 'flex', alignItems: 'center', gap: 7, borderBottom: `1px solid ${tokens.border}` }}>{Icon && <Icon size={12} color={tokens.muted} />}<span style={{ flex: 1, color: tokens.muted, fontSize: 9.5 }}>{card.name}</span><strong style={{ fontSize: 9.5 }}>{formatEur(budget)}</strong><span style={{ padding: '3px 6px', borderRadius: 6, background: tokens.surface3, color: tokens.muted, fontSize: 7.5, fontWeight: 750 }}>{STATUS_LABELS[status]}</span></div>; }) : <div style={{ padding: '10px 0 2px', color: tokens.muted, fontSize: 9 }}>Aucun budget renseigné.</div>}
              </div>}
            </section>;
          })}
        </div>
      </div>
    </aside>
  );
};

const Metric: React.FC<{ label: string; value: string; tokens: ReturnType<typeof getStudioTokens>; alert?: boolean }> = ({ label, value, tokens, alert }) => <div><div style={{ color: tokens.muted, fontSize: 8, textTransform: 'uppercase', letterSpacing: '.08em' }}>{label}</div><div style={{ marginTop: 2, color: alert ? tokens.danger : tokens.text, fontSize: 16, fontWeight: 800 }}>{value}</div></div>;
