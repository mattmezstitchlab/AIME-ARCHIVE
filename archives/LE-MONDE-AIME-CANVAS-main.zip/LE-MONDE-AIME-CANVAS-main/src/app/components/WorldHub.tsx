import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { CalendarDays, Filter, Globe2, Map, Search, Sparkles, Users, X, MapPin } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

type HubView = 'feed' | 'registry' | 'map' | 'agenda';

const cards = [
  { id: 1, kind: 'Profil', title: 'Matt Mez Sax — Musicien live', author: 'Matt Mez Sax', location: 'Lille, Hauts-de-France', image: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=1000&q=85', tags: ['Musique','Prestataire'] },
  { id: 2, kind: 'Projet', title: 'Sophie & Antoine', author: 'Studio AIME', location: '14 septembre 2025', image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=1000&q=85', tags: ['Mariage','Site'] },
  { id: 3, kind: 'Association', title: 'Les Papillons Bleus', author: 'Collectif local', location: 'Nord', image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1000&q=85', tags: ['Association','Solidarité'] },
  { id: 4, kind: 'Lieu', title: 'Domaine des Lumières', author: 'Maison & réception', location: 'Belgique', image: 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?w=1000&q=85', tags: ['Lieu','Réception'] },
  { id: 5, kind: 'Événement', title: 'Concert sous les étoiles', author: 'Le Monde Aime', location: 'Mont Noir', image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=1000&q=85', tags: ['Concert','Sortie'] },
  { id: 6, kind: 'Projet', title: 'Portfolio vivant — Céramique', author: 'AIME Studio', location: 'En ligne', image: 'https://images.unsplash.com/photo-1493106641515-6b5631de4bb9?w=1000&q=85', tags: ['Portfolio','Création'] },
];

export const WorldHub: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => {
  const { isDark } = useTheme();
  const [view, setView] = useState<HubView>('feed');
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('Tous');
  const surface = isDark ? '#171718' : '#F0F0F1';
  const panel = isDark ? '#1E1E20' : '#FAFAFB';
  const panel2 = isDark ? '#242426' : '#FFFFFF';
  const border = isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)';
  const text = isDark ? '#F5F5F5' : '#111112';
  const muted = isDark ? 'rgba(245,245,245,.48)' : 'rgba(17,17,18,.48)';
  const active = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.07)';
  const filtered = useMemo(() => cards.filter((card) => {
    const matchesQuery = `${card.title} ${card.author} ${card.location} ${card.tags.join(' ')}`.toLowerCase().includes(query.toLowerCase());
    const matchesFilter = filter === 'Tous' || card.tags.includes(filter) || card.kind === filter;
    return matchesQuery && matchesFilter;
  }), [query, filter]);

  return <AnimatePresence>{open && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} style={{ position: 'fixed', inset: 0, zIndex: 850, background: surface, color: text, fontFamily: 'Inter, sans-serif' }}>
    <header style={{ height: 64, borderBottom: `1px solid ${border}`, display: 'flex', alignItems: 'center', padding: '0 22px', gap: 16, background: panel }}>
      <div style={{ width: 34, height: 34, borderRadius: 11, background: panel2, border: `1px solid ${border}`, display: 'grid', placeItems: 'center' }}><Globe2 size={18} color={text} /></div>
      <div><div style={{ fontWeight: 850, fontSize: 14 }}>MapMonde</div><div style={{ fontSize: 9.5, color: muted }}>Communauté · registre · réseau · événements</div></div>
      <nav style={{ display: 'flex', gap: 4, marginLeft: 24, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.04)', padding: 4, borderRadius: 10 }}>
        {([['feed','Feed',Sparkles],['registry','Registre',Users],['map','Map',Map],['agenda','Agenda',CalendarDays]] as const).map(([id,label,Icon]) => <button key={id} onClick={() => setView(id)} style={{ height: 32, padding: '0 12px', border: 0, borderRadius: 8, background: view === id ? active : 'transparent', color: view === id ? text : muted, cursor: 'pointer', fontSize: 10.5, fontWeight: 750, display: 'flex', alignItems: 'center', gap: 6 }}><Icon size={13}/>{label}</button>)}
      </nav>
      <div style={{ flex: 1 }} />
      <button onClick={onClose} style={{ width: 34, height: 34, borderRadius: 9, border: `1px solid ${border}`, background: 'transparent', color: text, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={16}/></button>
    </header>

    <div style={{ display: 'grid', gridTemplateColumns: '250px 1fr', height: 'calc(100vh - 64px)' }}>
      <aside style={{ borderRight: `1px solid ${border}`, background: panel, padding: 18, overflowY: 'auto' }}>
        <div style={{ position: 'relative' }}><Search size={14} style={{ position: 'absolute', left: 11, top: 10, color: muted }} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher partout…" style={{ width: '100%', height: 34, borderRadius: 9, border: `1px solid ${border}`, background: panel2, color: text, padding: '0 10px 0 34px', outline: 'none', fontSize: 10.5 }} /></div>
        <div style={{ marginTop: 20, fontSize: 9, color: muted, fontWeight: 800, letterSpacing: '.12em', textTransform: 'uppercase', display: 'flex', gap: 6, alignItems: 'center' }}><Filter size={11}/>Filtres</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginTop: 10 }}>{['Tous','Mariage','Prestataire','Association','Musique','Lieu','Événement','Portfolio'].map((item) => <button key={item} onClick={() => setFilter(item)} style={{ border: `1px solid ${border}`, background: filter === item ? active : 'transparent', color: filter === item ? text : muted, borderRadius: 999, padding: '6px 9px', cursor: 'pointer', fontSize: 9.5 }}>{item}</button>)}</div>
        <div style={{ marginTop: 24, borderTop: `1px solid ${border}`, paddingTop: 15, fontSize: 10, lineHeight: 1.6, color: muted }}>MapMonde relie les profils, projets, lieux, événements et créations. Chaque résultat pourra être ajouté au canevas comme une carte vivante.</div>
        <div style={{ marginTop: 'auto', paddingTop: 24, color: muted, fontSize: 9 }}><span style={{ color: '#6EE7A8' }}>●</span> En ligne · 512 membres</div>
      </aside>

      <main style={{ overflowY: 'auto', padding: 24 }}>
        {view === 'map' ? <div style={{ height: '100%', minHeight: 560, borderRadius: 18, border: `1px solid ${border}`, background: '#1C1C1E', position: 'relative', overflow: 'hidden' }}><div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px)', backgroundSize: '36px 36px' }} />{cards.slice(0,5).map((card, i) => <div key={card.id} style={{ position: 'absolute', left: `${18 + (i*17)%65}%`, top: `${18 + (i*23)%60}%`, transform: 'translate(-50%,-50%)' }}><img src={card.image} alt="" style={{ width: 46, height: 46, borderRadius: '50%', objectFit: 'cover', border: '2px solid rgba(255,255,255,.75)', boxShadow: '0 12px 30px rgba(0,0,0,.35)' }} /><div style={{ marginTop: 7, background: 'rgba(10,10,11,.82)', color: '#fff', padding: '5px 8px', borderRadius: 7, fontSize: 8.5, whiteSpace: 'nowrap' }}>{card.title}</div></div>)}<div style={{ position: 'absolute', left: 20, bottom: 18, color: 'rgba(255,255,255,.65)', fontSize: 10 }}>Vue réseau connecté · bascule géographique</div></div> : view === 'agenda' ? <div style={{ maxWidth: 980, margin: '0 auto' }}><h2 style={{ fontSize: 28, margin: '8px 0 24px' }}>Ce qui se passe autour de vous</h2>{filtered.filter(c => c.kind === 'Événement' || c.tags.includes('Musique')).map((card, index) => <div key={card.id} style={{ display: 'grid', gridTemplateColumns: '76px 76px 1fr auto', gap: 16, padding: 16, borderBottom: `1px solid ${border}`, alignItems: 'center' }}><img src={card.image} alt="" style={{ width: 76, height: 58, borderRadius: 9, objectFit: 'cover' }} /><div><div style={{ fontSize: 22, fontWeight: 850 }}>{index + 24}</div><div style={{ color: muted, fontSize: 9 }}>Juillet 2026</div></div><div><div style={{ fontWeight: 800 }}>{card.title}</div><div style={{ color: muted, fontSize: 10, marginTop: 5, display: 'flex', gap: 5, alignItems: 'center' }}><MapPin size={11}/>{card.location}</div></div><button style={{ border: `1px solid ${border}`, background: panel2, color: text, borderRadius: 9, padding: '8px 11px', cursor: 'pointer', fontSize: 9.5 }}>Voir</button></div>)}</div> : <div><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'end', marginBottom: 18 }}><div><div style={{ fontSize: 27, fontWeight: 880 }}>{view === 'feed' ? 'Pour vous' : 'Registre universel'}</div><div style={{ color: muted, fontSize: 10.5, marginTop: 5 }}>{filtered.length} résultats · profils, créations et projets connectés</div></div></div><div style={{ display: 'grid', gridTemplateColumns: view === 'feed' ? 'repeat(3,minmax(0,1fr))' : 'repeat(4,minmax(0,1fr))', gap: 14 }}>{filtered.map((card) => <motion.article whileHover={{ y: -4 }} key={card.id} style={{ minHeight: view === 'feed' ? 280 : 220, borderRadius: 15, border: `1px solid ${border}`, background: panel2, overflow: 'hidden', cursor: 'pointer' }}><div style={{ height: view === 'feed' ? 170 : 120, position: 'relative' }}><img src={card.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /><div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,transparent 45%,rgba(0,0,0,.75))' }} /></div><div style={{ padding: 14 }}><div style={{ fontSize: 8.5, color: muted, fontWeight: 850, textTransform: 'uppercase', letterSpacing: '.1em' }}>{card.kind}</div><div style={{ fontWeight: 800, fontSize: 12.5, marginTop: 6, lineHeight: 1.35 }}>{card.title}</div><div style={{ color: muted, fontSize: 9.5, marginTop: 6 }}>{card.author} · {card.location}</div><div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: 11 }}>{card.tags.map(tag => <span key={tag} style={{ padding: '4px 7px', borderRadius: 999, background: active, color: muted, fontSize: 8.5 }}>{tag}</span>)}</div></div></motion.article>)}</div></div>}
      </main>
    </div>
  </motion.div>}</AnimatePresence>;
};
