import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FileText, Globe2, Link2, Radio, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import type { RemixTarget } from '../types';
import { getProjectItem, setProjectItem } from '../utils/projectStore';
import { CardPreviewPanel } from './CardPreviewPanel';
import type { CardPreviewMode } from './CardPreviewPanel';
import { CardCompositionPanel } from './CardCompositionPanel';
import type { CardCompositionSettings } from './CardCompositionPanel';

interface ProjectionEventDetail {
  target?: RemixTarget;
  mode?: CardPreviewMode;
}

const DEFAULT_COMPOSITION: CardCompositionSettings = {
  preset: 'editorial',
  background: '#242426',
  textColor: '#F5F5F5',
  accentColor: '#D4D4D8',
  titleVisible: true,
  introVisible: true,
  mediaUrl: '',
  primaryAction: 'Découvrir',
  secondaryAction: '',
};

const keyFor = (target: RemixTarget) => `${target.kind}:${target.id}`;

function readMap<T>(key: string): Record<string, T> {
  try { return JSON.parse(getProjectItem(key) || '{}') as Record<string, T>; }
  catch { return {}; }
}

export const CardProjectionRuntime: React.FC = () => {
  const [previewTarget, setPreviewTarget] = useState<RemixTarget | null>(null);
  const [previewMode, setPreviewMode] = useState<CardPreviewMode>('card');
  const [compositionTarget, setCompositionTarget] = useState<RemixTarget | null>(null);
  const [compositions, setCompositions] = useState<Record<string, CardCompositionSettings>>(() => readMap('lma_v98_compositions'));
  const [connections, setConnections] = useState<Record<string, string[]>>(() => readMap('lma_v98_connections'));

  useEffect(() => { setProjectItem('lma_v98_compositions', JSON.stringify(compositions)); }, [compositions]);
  useEffect(() => { setProjectItem('lma_v98_connections', JSON.stringify(connections)); }, [connections]);

  useEffect(() => {
    const preview = (event: Event) => {
      const detail = (event as CustomEvent<ProjectionEventDetail>).detail;
      if (!detail?.target || detail.target.kind === 'plan') return;
      setPreviewTarget(detail.target);
      setPreviewMode(detail.mode || 'card');
    };
    const compose = (event: Event) => {
      const detail = (event as CustomEvent<ProjectionEventDetail>).detail;
      if (!detail?.target || detail.target.kind === 'plan') return;
      setCompositionTarget(detail.target);
    };
    const connect = (event: Event) => {
      const detail = (event as CustomEvent<ProjectionEventDetail>).detail;
      if (!detail?.target || detail.target.kind === 'plan') return;
      let selected: string[] = [];
      try { selected = JSON.parse(getProjectItem('lma_selected_cards') || '[]') as string[]; } catch { selected = []; }
      const existing = connections[keyFor(detail.target)] || [];
      const ids = selected.length ? selected : existing.length ? existing : [`source-${Date.now().toString(36)}`];
      setConnections((previous) => ({ ...previous, [keyFor(detail.target!)]: Array.from(new Set(ids)) }));
      toast.success(selected.length ? `${selected.length} carte${selected.length > 1 ? 's' : ''} magnétisée${selected.length > 1 ? 's' : ''}.` : 'La carte est prête à recevoir des sources.');
    };
    const detach = (event: Event) => {
      const detail = (event as CustomEvent<ProjectionEventDetail>).detail;
      if (!detail?.target || detail.target.kind === 'plan') return;
      setConnections((previous) => ({ ...previous, [keyFor(detail.target!)]: [] }));
      toast.success('Les cartes ont été détachées.');
    };
    const showConnections = (event: Event) => {
      const detail = (event as CustomEvent<ProjectionEventDetail>).detail;
      if (!detail?.target || detail.target.kind === 'plan') return;
      const count = connections[keyFor(detail.target)]?.length || 0;
      toast.info(count ? `${count} source${count > 1 ? 's' : ''} reliée${count > 1 ? 's' : ''}.` : 'Aucune source reliée pour le moment.');
    };
    window.addEventListener('lma-card-preview', preview as EventListener);
    window.addEventListener('lma-card-compose', compose as EventListener);
    window.addEventListener('lma-card-connect', connect as EventListener);
    window.addEventListener('lma-card-detach', detach as EventListener);
    window.addEventListener('lma-card-show-connections', showConnections as EventListener);
    return () => {
      window.removeEventListener('lma-card-preview', preview as EventListener);
      window.removeEventListener('lma-card-compose', compose as EventListener);
      window.removeEventListener('lma-card-connect', connect as EventListener);
      window.removeEventListener('lma-card-detach', detach as EventListener);
      window.removeEventListener('lma-card-show-connections', showConnections as EventListener);
    };
  }, [connections]);

  const compositionFor = useCallback((target: RemixTarget | null) => target ? compositions[keyFor(target)] || DEFAULT_COMPOSITION : DEFAULT_COMPOSITION, [compositions]);
  const linkedCount = useCallback((target: RemixTarget | null) => target ? connections[keyFor(target)]?.length || 0 : 0, [connections]);
  const renderPreview = useCallback((target: RemixTarget, mode: CardPreviewMode, settings: CardCompositionSettings) => <GenericProjection target={target} mode={mode} settings={settings} linkedCount={linkedCount(target)} />, [linkedCount]);

  return (
    <>
      <CardPreviewPanel
        open={Boolean(previewTarget)}
        target={previewTarget}
        mode={previewMode}
        linkedCount={linkedCount(previewTarget)}
        onModeChange={setPreviewMode}
        onCompose={() => previewTarget && setCompositionTarget(previewTarget)}
        onClose={() => setPreviewTarget(null)}
      >
        {previewTarget && renderPreview(previewTarget, previewMode, compositionFor(previewTarget))}
      </CardPreviewPanel>
      <CardCompositionPanel
        open={Boolean(compositionTarget)}
        target={compositionTarget}
        selectedCount={(() => { try { return (JSON.parse(getProjectItem('lma_selected_cards') || '[]') as string[]).length; } catch { return 0; } })()}
        initial={compositionTarget ? compositionFor(compositionTarget) : undefined}
        onApply={(settings) => compositionTarget && setCompositions((previous) => ({ ...previous, [keyFor(compositionTarget)]: settings }))}
        onUseSelectedCards={() => compositionTarget && window.dispatchEvent(new CustomEvent('lma-card-connect', { detail: { target: compositionTarget } }))}
        onClose={() => setCompositionTarget(null)}
        preview={(settings) => compositionTarget ? renderPreview(compositionTarget, 'section', settings) : null}
      />
    </>
  );
};

const GenericProjection: React.FC<{ target: RemixTarget; mode: CardPreviewMode; settings: CardCompositionSettings; linkedCount: number }> = ({ target, mode, settings, linkedCount }) => {
  if (mode === 'card') return <CardMock target={target} settings={settings} linkedCount={linkedCount} />;
  if (mode === 'story') return <StoryMock target={target} settings={settings} />;
  if (mode === 'pdf') return <PdfMock target={target} settings={settings} />;
  if (mode === 'live') return <LiveMock target={target} settings={settings} />;
  if (mode === 'timeline') return <TimelineMock target={target} settings={settings} />;
  return <SectionMock target={target} settings={settings} mode={mode} linkedCount={linkedCount} />;
};

const CardMock: React.FC<{ target: RemixTarget; settings: CardCompositionSettings; linkedCount: number }> = ({ target, settings, linkedCount }) => <div style={{ minHeight: '100%', padding: 28, boxSizing: 'border-box', background: '#151516', display: 'grid', placeItems: 'center' }}><article style={{ width: 300, minHeight: 440, borderRadius: 28, overflow: 'hidden', background: settings.background, color: settings.textColor, boxShadow: '0 28px 70px rgba(0,0,0,.38)', display: 'flex', flexDirection: 'column' }}><Media settings={settings} height={220} /><div style={{ padding: 24, flex: 1, display: 'flex', flexDirection: 'column' }}><Eyebrow target={target} linkedCount={linkedCount} /><Title target={target} settings={settings} /><Intro settings={settings} /><Actions settings={settings} style={{ marginTop: 'auto', paddingTop: 24 }} /></div></article></div>;

const SectionMock: React.FC<{ target: RemixTarget; settings: CardCompositionSettings; mode: CardPreviewMode; linkedCount: number }> = ({ target, settings, mode, linkedCount }) => {
  const split = settings.preset === 'split-left' || settings.preset === 'split-right';
  const media = <Media settings={settings} height={mode === 'page' || mode === 'site' ? 370 : 280} />;
  const text = <div><Eyebrow target={target} linkedCount={linkedCount} /><Title target={target} settings={settings} large={mode === 'page' || mode === 'site'} /><Intro settings={settings} /><Actions settings={settings} style={{ marginTop: 24 }} /></div>;
  return <div style={{ minHeight: '100%', padding: mode === 'page' || mode === 'site' ? '56px 48px 90px' : 36, boxSizing: 'border-box', background: settings.background, color: settings.textColor }}>
    {(mode === 'site' || mode === 'mobile') && <header style={{ height: 38, marginBottom: 42, display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 8, letterSpacing: '.13em', textTransform: 'uppercase', opacity: .5 }}><span>LE MONDE AIME</span><span>Projet · Aperçu</span></header>}
    {settings.preset === 'visual-background' ? <div style={{ minHeight: 500, borderRadius: 24, overflow: 'hidden', position: 'relative', display: 'flex', alignItems: 'flex-end', padding: 38, boxSizing: 'border-box', background: settings.mediaUrl ? `center/cover url(${settings.mediaUrl})` : `linear-gradient(145deg,${settings.accentColor},${settings.background})` }}><div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,transparent,rgba(0,0,0,.75))' }} /><div style={{ position: 'relative', color: '#fff' }}>{text}</div></div>
      : split ? <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, alignItems: 'center' }}>{settings.preset === 'split-left' ? <>{media}{text}</> : <>{text}{media}</>}</div>
      : settings.preset === 'duo' ? <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>{media}<div style={{ padding: 30, borderRadius: 24, background: `${settings.accentColor}18` }}>{text}</div></div>
      : settings.preset === 'gallery' ? <div><div style={{ display: 'grid', gridTemplateColumns: '1.35fr .65fr', gap: 14 }}>{media}<div style={{ display: 'grid', gap: 14 }}><Media settings={settings} height={132} /><Media settings={{ ...settings, mediaUrl: '' }} height={132} /></div></div><div style={{ marginTop: 34 }}>{text}</div></div>
      : settings.preset === 'slider' || settings.preset === 'horizontal-cards' ? <div><div style={{ display: 'flex', gap: 14, overflow: 'hidden' }}>{[0,1,2].map((item) => <div key={item} style={{ width: item === 0 && settings.preset === 'slider' ? '62%' : '38%', minWidth: 230, flexShrink: 0 }}><Media settings={{ ...settings, mediaUrl: item === 0 ? settings.mediaUrl : '' }} height={270} /></div>)}</div><div style={{ marginTop: 32 }}>{text}</div></div>
      : <div style={{ maxWidth: 900, margin: '0 auto' }}>{text}{settings.mediaUrl && <div style={{ marginTop: 36 }}>{media}</div>}</div>}
  </div>;
};

const StoryMock: React.FC<{ target: RemixTarget; settings: CardCompositionSettings }> = ({ target, settings }) => <div style={{ minHeight: '100%', padding: 18, boxSizing: 'border-box', color: '#fff', display: 'flex', flexDirection: 'column', position: 'relative', background: settings.mediaUrl ? `center/cover url(${settings.mediaUrl})` : `linear-gradient(160deg,${settings.accentColor},${settings.background})` }}><div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(0,0,0,.12),rgba(0,0,0,.82))' }} /><div style={{ position: 'relative', display: 'flex', gap: 4 }}>{[0,1,2,3].map((item) => <span key={item} style={{ height: 3, flex: 1, borderRadius: 99, background: item < 2 ? '#fff' : 'rgba(255,255,255,.28)' }} />)}</div><div style={{ position: 'relative', marginTop: 'auto', padding: '0 7px 28px' }}><Title target={target} settings={{ ...settings, textColor: '#fff' }} large /><Intro settings={{ ...settings, textColor: '#fff' }} /><Actions settings={{ ...settings, accentColor: '#fff', textColor: '#fff' }} style={{ marginTop: 22 }} /></div></div>;
const PdfMock: React.FC<{ target: RemixTarget; settings: CardCompositionSettings }> = ({ target, settings }) => <div style={{ minHeight: '100%', background: '#F5F2EC', color: '#171719', padding: '56px 50px', boxSizing: 'border-box' }}><div style={{ fontSize: 8, letterSpacing: '.16em', textTransform: 'uppercase', opacity: .45 }}>LE MONDE AIME · Document généré</div><div style={{ marginTop: 48, display: 'grid', gridTemplateColumns: '1.05fr .95fr', gap: 32, alignItems: 'end' }}><div><h1 style={{ margin: 0, fontSize: 58, lineHeight: .9, letterSpacing: '-.06em' }}>{target.label}</h1><p style={{ margin: '22px 0 0', fontSize: 13, lineHeight: 1.7, opacity: .6 }}>Une projection professionnelle issue de la carte et de ses relations.</p></div><Media settings={settings} height={280} /></div><div style={{ marginTop: 54, height: 1, background: 'rgba(0,0,0,.14)' }} /><div style={{ marginTop: 26, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>{['Informations','Relations','Prochaine action'].map((label) => <div key={label}><strong style={{ fontSize: 10 }}>{label}</strong><p style={{ fontSize: 9, lineHeight: 1.6, opacity: .48 }}>Contenu synchronisé avec le projet.</p></div>)}</div></div>;
const LiveMock: React.FC<{ target: RemixTarget; settings: CardCompositionSettings }> = ({ target, settings }) => <div style={{ minHeight: '100%', background: '#0F1012', color: '#fff', padding: 36, boxSizing: 'border-box' }}><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '7px 10px', borderRadius: 999, background: 'rgba(255,255,255,.08)', fontSize: 8, letterSpacing: '.12em', textTransform: 'uppercase' }}><Radio size={12} />Jour J Live</span><span style={{ fontSize: 9, opacity: .48 }}>Maintenant</span></div><div style={{ marginTop: 90, maxWidth: 760 }}><div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, color: settings.accentColor, fontSize: 9, textTransform: 'uppercase', letterSpacing: '.12em' }}><Sparkles size={13} />Information reliée</div><h1 style={{ margin: '18px 0 0', fontSize: 62, lineHeight: .92, letterSpacing: '-.06em' }}>{target.label}</h1><p style={{ margin: '22px 0 0', fontSize: 15, lineHeight: 1.65, opacity: .62 }}>Cette carte peut diffuser une information actualisée à toutes les personnes concernées.</p></div></div>;
const TimelineMock: React.FC<{ target: RemixTarget; settings: CardCompositionSettings }> = ({ target, settings }) => <div style={{ minHeight: '100%', background: settings.background, color: settings.textColor, padding: 34, boxSizing: 'border-box' }}><Eyebrow target={target} linkedCount={0} /><Title target={target} settings={settings} /><div style={{ marginTop: 70, position: 'relative', height: 210 }}><div style={{ position: 'absolute', left: 24, right: 24, top: 104, height: 1, background: `${settings.textColor}33` }} />{['09:30','14:30','16:00','19:30','22:00'].map((hour,index) => <div key={hour} style={{ position: 'absolute', left: `${8 + index * 21}%`, top: index % 2 ? 112 : 72, transform: 'translateX(-50%)', textAlign: 'center' }}><span style={{ width: 30, height: 30, borderRadius: '50%', background: settings.textColor, color: settings.background, display: 'grid', placeItems: 'center', fontSize: 7, fontWeight: 800 }}>{index+1}</span><strong style={{ display: 'block', marginTop: 9, fontSize: 8 }}>{hour}</strong></div>)}</div></div>;

const Eyebrow: React.FC<{ target: RemixTarget; linkedCount: number }> = ({ target, linkedCount }) => <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 8, letterSpacing: '.14em', textTransform: 'uppercase', opacity: .48 }}><span>{target.kind}</span>{linkedCount > 0 && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Link2 size={10} />{linkedCount} liée{linkedCount > 1 ? 's' : ''}</span>}</div>;
const Title: React.FC<{ target: RemixTarget; settings: CardCompositionSettings; large?: boolean }> = ({ target, settings, large }) => settings.titleVisible ? <h1 style={{ margin: '14px 0 0', fontSize: large ? 58 : 42, lineHeight: .92, letterSpacing: '-.06em', color: settings.textColor }}>{target.label}</h1> : null;
const Intro: React.FC<{ settings: CardCompositionSettings }> = ({ settings }) => settings.introVisible ? <p style={{ margin: '18px 0 0', maxWidth: 620, fontSize: 12, lineHeight: 1.65, color: settings.textColor, opacity: .62 }}>Cette carte est la source. LE MONDE AIME la transforme en résultat sans dupliquer ses données.</p> : null;
const Actions: React.FC<{ settings: CardCompositionSettings; style?: React.CSSProperties }> = ({ settings, style }) => <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, ...style }}>{settings.primaryAction && <span style={{ minHeight: 36, padding: '0 14px', borderRadius: 999, background: settings.accentColor, color: '#171719', display: 'inline-flex', alignItems: 'center', fontSize: 9, fontWeight: 780 }}>{settings.primaryAction}</span>}{settings.secondaryAction && <span style={{ minHeight: 36, padding: '0 14px', borderRadius: 999, border: `1px solid ${settings.textColor}`, color: settings.textColor, display: 'inline-flex', alignItems: 'center', fontSize: 9 }}>{settings.secondaryAction}</span>}</div>;
const Media: React.FC<{ settings: CardCompositionSettings; height: number }> = ({ settings, height }) => <div style={{ width: '100%', height, borderRadius: 24, overflow: 'hidden', background: settings.mediaUrl ? `center/cover url(${settings.mediaUrl})` : `linear-gradient(145deg,${settings.accentColor},#2A2A2D)`, position: 'relative' }}><div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg,rgba(255,255,255,.08),transparent 44%,rgba(0,0,0,.18))' }} />{!settings.mediaUrl && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', color: 'rgba(255,255,255,.58)' }}><Globe2 size={24} /></div>}</div>;
