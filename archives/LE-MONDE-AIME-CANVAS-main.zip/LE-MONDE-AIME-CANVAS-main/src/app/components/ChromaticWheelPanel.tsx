import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Check, Pipette, Sparkles, X } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

type ApplyScope = 'canvas' | 'selection';

interface ChromaticWheelPanelProps {
  open: boolean;
  seedColor: string;
  targetLabel?: string;
  canApplySelection: boolean;
  onApply: (palette: string[], scope: ApplyScope) => void;
  onClose: () => void;
}

interface PaletteOption {
  id: string;
  label: string;
  colors: string[];
}

const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));

function normalizeHex(value: string) {
  const match = value.match(/#[0-9a-fA-F]{6}/);
  return match ? match[0].toUpperCase() : '#A3A3A8';
}

function hexToHsl(hex: string): [number, number, number] {
  const value = normalizeHex(hex).slice(1);
  const r = parseInt(value.slice(0, 2), 16) / 255;
  const g = parseInt(value.slice(2, 4), 16) / 255;
  const b = parseInt(value.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;
  let h = 0;
  if (delta) {
    if (max === r) h = 60 * (((g - b) / delta) % 6);
    else if (max === g) h = 60 * ((b - r) / delta + 2);
    else h = 60 * ((r - g) / delta + 4);
  }
  if (h < 0) h += 360;
  const l = (max + min) / 2;
  const s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));
  return [h, s * 100, l * 100];
}

function hslToHex(h: number, s: number, l: number) {
  const sat = clamp(s / 100);
  const light = clamp(l / 100);
  const c = (1 - Math.abs(2 * light - 1)) * sat;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = light - c / 2;
  let r = 0; let g = 0; let b = 0;
  const hue = ((h % 360) + 360) % 360;
  if (hue < 60) [r, g] = [c, x];
  else if (hue < 120) [r, g] = [x, c];
  else if (hue < 180) [g, b] = [c, x];
  else if (hue < 240) [g, b] = [x, c];
  else if (hue < 300) [r, b] = [x, c];
  else [r, b] = [c, x];
  return `#${[r, g, b].map((channel) => Math.round((channel + m) * 255).toString(16).padStart(2, '0')).join('')}`.toUpperCase();
}

function buildPalettes(seedColor: string): PaletteOption[] {
  const [h, s, l] = hexToHsl(seedColor);
  const color = (offset: number, sat = s, light = l) => hslToHex(h + offset, sat, light);
  return [
    { id: 'mono', label: 'Monochrome', colors: [hslToHex(h, Math.max(20, s - 18), Math.min(92, l + 24)), seedColor, hslToHex(h, Math.min(100, s + 8), Math.max(15, l - 22))] },
    { id: 'analog', label: 'Analogues', colors: [color(-30), seedColor, color(30)] },
    { id: 'complement', label: 'Complémentaire', colors: [seedColor, color(180)] },
    { id: 'split', label: 'Complémentaire divisée', colors: [seedColor, color(150), color(210)] },
    { id: 'triad', label: 'Triade', colors: [seedColor, color(120), color(240)] },
    { id: 'tetrad', label: 'Tétrade', colors: [seedColor, color(90), color(180), color(270)] },
  ];
}

export const ChromaticWheelPanel: React.FC<ChromaticWheelPanelProps> = ({
  open,
  seedColor,
  targetLabel,
  canApplySelection,
  onApply,
  onClose,
}) => {
  const { isDark } = useTheme();
  const [seed, setSeed] = useState(normalizeHex(seedColor));
  const [activeId, setActiveId] = useState('triad');

  useEffect(() => { if (open) setSeed(normalizeHex(seedColor)); }, [open, seedColor]);
  const palettes = useMemo(() => buildPalettes(seed), [seed]);
  const active = palettes.find((palette) => palette.id === activeId) || palettes[0];
  const surface = isDark ? '#1A1A1D' : '#FFFFFF';
  const surface2 = isDark ? '#242428' : '#F2F2F4';
  const text = isDark ? '#F7F6F8' : '#151518';
  const muted = isDark ? 'rgba(247,246,248,.52)' : 'rgba(21,21,24,.52)';
  const border = isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.10)';

  const pickScreenColor = async () => {
    const EyeDropperCtor = (window as unknown as { EyeDropper?: new () => { open: () => Promise<{ sRGBHex: string }> } }).EyeDropper;
    if (!EyeDropperCtor) return;
    try {
      const result = await new EyeDropperCtor().open();
      setSeed(normalizeHex(result.sRGBHex));
    } catch { /* user cancelled */ }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, y: 18, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 18, scale: .97 }}
          transition={{ type: 'spring', damping: 28, stiffness: 360 }}
          style={{
            position: 'fixed', right: 18, bottom: 66, width: 390, maxHeight: 'calc(100vh - 92px)', overflow: 'hidden', zIndex: 470,
            borderRadius: 18, background: surface, border: `1px solid ${border}`, boxShadow: '0 26px 80px rgba(0,0,0,.34)', color: text, isolation: 'isolate',
          }}
        >
          <div style={{ padding: '14px 15px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: `1px solid ${border}` }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'conic-gradient(#ff4f81,#ffb14f,#f9ef5b,#53d987,#4bc8ff,#715dff,#d957e8,#ff4f81)', boxShadow: '0 0 0 4px rgba(255,255,255,.05)' }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, fontWeight: 850 }}>Cercle chromatique AIME</div>
              <div style={{ marginTop: 2, fontSize: 9, color: muted }}>{targetLabel ? `Sélection : ${targetLabel}` : 'Ambiance du canevas'}</div>
            </div>
            <button onClick={onClose} aria-label="Fermer" style={{ width: 30, height: 30, display: 'grid', placeItems: 'center', border: 0, borderRadius: 8, color: muted, background: 'transparent', cursor: 'pointer' }}><X size={15} /></button>
          </div>

          <div style={{ padding: 15, maxHeight: 'calc(100vh - 170px)', overflowY: 'auto', scrollbarWidth: 'none' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '132px 1fr', gap: 14, alignItems: 'center' }}>
              <button
                type="button"
                aria-label="Choisir une teinte sur le cercle"
                onClick={(event) => {
                  const rect = event.currentTarget.getBoundingClientRect();
                  const x = event.clientX - (rect.left + rect.width / 2);
                  const y = event.clientY - (rect.top + rect.height / 2);
                  const angle = (Math.atan2(y, x) * 180 / Math.PI + 450) % 360;
                  const [, s, l] = hexToHsl(seed);
                  setSeed(hslToHex(angle, Math.max(58, s), Math.min(62, Math.max(42, l))));
                }}
                style={{ width: 132, height: 132, borderRadius: '50%', border: `1px solid ${border}`, cursor: 'crosshair', position: 'relative', background: 'radial-gradient(circle at center,#fff 0 8%,transparent 42%),conic-gradient(#ff0000,#ffff00,#00ff00,#00ffff,#0000ff,#ff00ff,#ff0000)', boxShadow: 'inset 0 0 28px rgba(0,0,0,.2)' }}
              >
                <span style={{ position: 'absolute', inset: 37, borderRadius: '50%', background: seed, border: `3px solid ${surface}`, boxShadow: '0 4px 18px rgba(0,0,0,.32)' }} />
              </button>
              <div>
                <label style={{ display: 'block', fontSize: 8.5, textTransform: 'uppercase', letterSpacing: '.12em', color: muted, marginBottom: 6 }}>Couleur source</label>
                <div style={{ display: 'flex', gap: 7 }}>
                  <input type="color" value={seed} onChange={(event) => setSeed(event.target.value.toUpperCase())} style={{ width: 38, height: 34, padding: 0, border: `1px solid ${border}`, borderRadius: 9, background: surface2, cursor: 'pointer', overflow: 'hidden', appearance: 'none' }} />
                  <input value={seed} onChange={(event) => setSeed(normalizeHex(event.target.value))} style={{ minWidth: 0, flex: 1, height: 34, borderRadius: 9, border: `1px solid ${border}`, background: surface2, color: text, padding: '0 9px', fontSize: 10, fontFamily: 'monospace' }} />
                </div>
                <button onClick={pickScreenColor} style={{ marginTop: 8, width: '100%', height: 32, border: `1px solid ${border}`, borderRadius: 9, background: surface2, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, fontSize: 9.5, fontWeight: 700 }}><Pipette size={13} /> Pipette écran</button>
              </div>
            </div>

            <div style={{ marginTop: 16, display: 'grid', gap: 6 }}>
              {palettes.map((palette) => (
                <button key={palette.id} onClick={() => setActiveId(palette.id)} style={{ height: 42, borderRadius: 11, border: `1px solid ${activeId === palette.id ? 'rgba(255,255,255,.28)' : border}`, background: activeId === palette.id ? (isDark ? '#303033' : '#E9E9EB') : surface2, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '0 10px', gap: 9 }}>
                  <span style={{ width: 118, display: 'flex' }}>{palette.colors.map((color) => <span key={color} style={{ flex: 1, height: 21, background: color, borderRadius: 5, marginLeft: -2, border: `1px solid ${border}` }} />)}</span>
                  <span style={{ flex: 1, textAlign: 'left', fontSize: 9.5, fontWeight: 750 }}>{palette.label}</span>
                  {activeId === palette.id && <Check size={13} />}
                </button>
              ))}
            </div>

            <div style={{ marginTop: 13, padding: 11, borderRadius: 11, background: `linear-gradient(120deg,${active.colors.join(',')})`, minHeight: 58, border: `1px solid ${border}`, display: 'flex', alignItems: 'flex-end' }}>
              <span style={{ padding: '4px 7px', borderRadius: 7, background: 'rgba(0,0,0,.44)', color: '#fff', fontSize: 8.5, fontWeight: 750, backdropFilter: 'blur(8px)' }}>Aperçu {active.label}</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: canApplySelection ? '1fr 1fr' : '1fr', gap: 8, marginTop: 12 }}>
              <button onClick={() => onApply(active.colors, 'canvas')} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, cursor: 'pointer', fontSize: 9.5, fontWeight: 800 }}><Sparkles size={12} style={{ marginRight: 6, verticalAlign: -2 }} />Appliquer au canevas</button>
              {canApplySelection && <button onClick={() => onApply(active.colors, 'selection')} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: isDark ? '#F2F2F3' : '#151517', color: isDark ? '#151517' : '#FFFFFF', cursor: 'pointer', fontSize: 9.5, fontWeight: 850 }}>Appliquer à la sélection</button>}
            </div>
            <div style={{ marginTop: 9, color: muted, fontSize: 8.5, lineHeight: 1.45 }}>Les palettes sont générées mathématiquement pour préserver une harmonie cohérente. L’accessibilité du contraste reste vérifiée au niveau de chaque composant.</div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
