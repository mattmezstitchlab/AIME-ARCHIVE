import React, { useRef } from 'react';
import {
  Type, Image, Video, CreditCard, MousePointerClick, Images, Music2,
  StickyNote, Shapes, PanelsTopLeft, Link2, Code2, Upload, X, Heart, BriefcaseBusiness, Users, Music, MapPinned, Building2,
} from 'lucide-react';
import type { CanvasElementType } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { toast } from 'sonner';
import { fileToPersistentMedia } from '../utils/persistentMedia';

interface StudioAddPanelProps {
  onAdd: (type: CanvasElementType, payload?: { url?: string; fileName?: string; content?: string; roleKind?: 'couple' | 'prestataire' | 'association' | 'artiste' | 'lieu' | 'entreprise' | 'personne' | 'projet'; universe?: string; subtitle?: string }) => void;
  onClose: () => void;
}

const ITEMS: Array<{ type: CanvasElementType; label: string; desc: string; icon: React.ReactNode }> = [
  { type: 'text', label: 'Texte', desc: 'Titre ou paragraphe', icon: <Type size={16} /> },
  { type: 'image', label: 'Image', desc: 'Photo ou visuel', icon: <Image size={16} /> },
  { type: 'video', label: 'Vidéo', desc: 'Fond ou séquence', icon: <Video size={16} /> },
  { type: 'card', label: 'Carte', desc: 'Bloc interactif', icon: <CreditCard size={16} /> },
  { type: 'button', label: 'Bouton', desc: 'Action cliquable', icon: <MousePointerClick size={16} /> },
  { type: 'gallery', label: 'Galerie', desc: 'Collection d’images', icon: <Images size={16} /> },
  { type: 'music', label: 'Musique', desc: 'Titre ou lecteur', icon: <Music2 size={16} /> },
  { type: 'note', label: 'Note', desc: 'Post-it libre', icon: <StickyNote size={16} /> },
  { type: 'shape', label: 'Forme', desc: 'Fond ou séparateur', icon: <Shapes size={16} /> },
  { type: 'section', label: 'Section', desc: 'Zone de composition', icon: <PanelsTopLeft size={16} /> },
  { type: 'link', label: 'Lien', desc: 'URL externe', icon: <Link2 size={16} /> },
  { type: 'embed', label: 'Contenu web', desc: 'Iframe ou page web', icon: <Code2 size={16} /> },
];

const ROLE_ITEMS: Array<{ kind: 'couple' | 'prestataire' | 'association' | 'artiste' | 'lieu' | 'entreprise'; label: string; universe: string; desc: string; icon: React.ReactNode }> = [
  { kind: 'couple', label: 'Couple', universe: 'Mariage', desc: 'Projet, invités et Jour J', icon: <Heart size={15} /> },
  { kind: 'prestataire', label: 'Prestataire', universe: 'Services & événements', desc: 'Profil, réservation et documents', icon: <BriefcaseBusiness size={15} /> },
  { kind: 'association', label: 'Association', universe: 'Monde associatif', desc: 'Membres, missions et ressources', icon: <Users size={15} /> },
  { kind: 'artiste', label: 'Artiste', universe: 'Culture & scène', desc: 'Médias, dates et booking', icon: <Music size={15} /> },
  { kind: 'lieu', label: 'Lieu', universe: 'Espaces & territoires', desc: 'Capacité, agenda et réservation', icon: <MapPinned size={15} /> },
  { kind: 'entreprise', label: 'Entreprise', universe: 'Organisation', desc: 'Équipe, offres et projets', icon: <Building2 size={15} /> },
];


export const StudioAddPanel: React.FC<StudioAddPanelProps> = ({ onAdd, onClose }) => {
  const { isDark } = useTheme();
  const imageInput = useRef<HTMLInputElement>(null);
  const videoInput = useRef<HTMLInputElement>(null);

  const importFile = async (type: 'image' | 'video', file?: File) => {
    if (!file) return;
    const media = await fileToPersistentMedia(file);
    onAdd(type, { url: media.url, fileName: file.name });
    if (media.persistent) toast.success(media.optimized ? 'Image optimisée et enregistrée avec le projet.' : 'Média enregistré avec le projet.');
    else toast.warning('Vidéo volumineuse : elle reste disponible pendant cette session. Utilisez une URL hébergée pour la conserver.');
  };

  return (
    <PanelShell title="Ajouter" subtitle="Construire sur le canevas" onClose={onClose} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>
        {ITEMS.map((item) => (
          <button
            key={item.type}
            onClick={() => {
              if (item.type === 'image') imageInput.current?.click();
              else if (item.type === 'video') videoInput.current?.click();
              else onAdd(item.type);
            }}
            style={{
              border: `1px solid ${isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}`,
              background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.025)',
              color: isDark ? '#F5F5F6' : '#161618', borderRadius: 11, padding: '10px 9px',
              display: 'flex', alignItems: 'flex-start', gap: 8, cursor: 'pointer', textAlign: 'left',
            }}
          >
            <span style={{ width: 28, height: 28, borderRadius: 8, background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)', color: isDark ? '#E4E4E7' : '#3F3F46', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{item.icon}</span>
            <span style={{ minWidth: 0 }}>
              <strong style={{ display: 'block', fontFamily: 'Inter', fontSize: 11, lineHeight: 1.2 }}>{item.label}</strong>
              <span style={{ display: 'block', fontFamily: 'Inter', fontSize: 8.5, opacity: .46, marginTop: 3, lineHeight: 1.25 }}>{item.desc}</span>
            </span>
          </button>
        ))}
      </div>

      <div style={{ marginTop: 14, marginBottom: 7, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontFamily: 'Inter', fontSize: 9, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase', opacity: .46 }}>Cartes de rôle universelles</span>
        <span style={{ fontFamily: 'Inter', fontSize: 8, opacity: .32 }}>même canevas</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>
        {ROLE_ITEMS.map((role) => (
          <button key={role.kind} onClick={() => onAdd('card', { content: role.label, roleKind: role.kind, universe: role.universe, subtitle: role.desc })} style={{ minHeight: 72, border: `1px solid ${isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}`, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.025)', color: isDark ? '#F5F5F6' : '#161618', borderRadius: 11, padding: '10px 9px', display: 'flex', alignItems: 'flex-start', gap: 8, cursor: 'pointer', textAlign: 'left' }}>
            <span style={{ width: 28, height: 28, borderRadius: 9, background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)', color: isDark ? '#E4E4E7' : '#3F3F46', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{role.icon}</span>
            <span><strong style={{ display: 'block', fontFamily: 'Inter', fontSize: 10.5 }}>{role.label}</strong><span style={{ display: 'block', fontFamily: 'Inter', fontSize: 8, opacity: .48, marginTop: 3, lineHeight: 1.3 }}>{role.desc}</span></span>
          </button>
        ))}
      </div>

      <div style={{ marginTop: 12, padding: 10, borderRadius: 11, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.025)', border: `1px solid ${isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontFamily: 'Inter', fontSize: 10, fontWeight: 700, color: isDark ? '#E4E4E7' : '#3F3F46' }}><Upload size={13} /> Import rapide</div>
        <p style={{ margin: '6px 0 0', fontFamily: 'Inter', fontSize: 9, lineHeight: 1.45, opacity: .55 }}>Les images sont optimisées et enregistrées avec le projet. Les vidéos volumineuses nécessitent une URL hébergée pour rester permanentes.</p>
      </div>

      <input ref={imageInput} type="file" accept="image/*" hidden onChange={(e) => { void importFile('image', e.target.files?.[0]); e.currentTarget.value = ''; }} />
      <input ref={videoInput} type="file" accept="video/*" hidden onChange={(e) => { void importFile('video', e.target.files?.[0]); e.currentTarget.value = ''; }} />
    </PanelShell>
  );
};

export const PanelShell: React.FC<{
  title: string; subtitle?: string; onClose: () => void; isDark: boolean; children: React.ReactNode; width?: number;
}> = ({ title, subtitle, onClose, isDark, children, width = 276 }) => (
  <div style={{
    position: 'fixed', right: 14, top: 58, width, maxHeight: 'calc(100vh - 92px)', overflowY: 'auto',
    zIndex: 230, borderRadius: 16, padding: 12, scrollbarWidth: 'none', overscrollBehavior: 'contain',
    background: isDark ? 'rgba(27,27,29,.985)' : 'rgba(250,250,251,.99)',
    color: isDark ? '#F5F5F6' : '#151517',
    border: `1px solid ${isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.07)'}`,
    boxShadow: '0 18px 60px rgba(0,0,0,.25)', backdropFilter: 'blur(22px)', WebkitBackdropFilter: 'blur(22px)',
  }}>
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10, marginBottom: 12 }}>
      <div>
        <div style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: 800, letterSpacing: '.04em', textTransform: 'uppercase' }}>{title}</div>
        {subtitle && <div style={{ fontFamily: 'Inter', fontSize: 9, opacity: .42, marginTop: 3 }}>{subtitle}</div>}
      </div>
      <button onClick={onClose} style={{ width: 26, height: 26, border: 0, borderRadius: 7, background: isDark ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.04)', color: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><X size={13} /></button>
    </div>
    {children}
  </div>
);
