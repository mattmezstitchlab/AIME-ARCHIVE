import React, { useRef } from 'react';
import { FileSearch, Grip, MoreHorizontal, Trash2 } from 'lucide-react';
import type { CanvasPoint, Tool } from '../types';

export interface PointZeroArtifact {
  id: string;
  title: string;
  body: string;
  accent: string;
  x: number;
  y: number;
  width: number;
  height: number;
  createdAt: string;
  kind: 'blank' | 'audit' | 'import';
}

interface PointZeroArtifactCardProps {
  artifact: PointZeroArtifact;
  canvasScale: number;
  activeTool: Tool;
  onChange: (id: string, patch: Partial<PointZeroArtifact>) => void;
  onDelete: (id: string) => void;
}

export const PointZeroArtifactCard: React.FC<PointZeroArtifactCardProps> = ({ artifact, canvasScale, activeTool, onChange, onDelete }) => {
  const dragRef = useRef<{ x: number; y: number; clientX: number; clientY: number; pointerId: number } | null>(null);

  const startDrag = (event: React.PointerEvent) => {
    if (activeTool !== 'select' && activeTool !== 'hand') return;
    event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = { x: artifact.x, y: artifact.y, clientX: event.clientX, clientY: event.clientY, pointerId: event.pointerId };
  };

  return (
    <div
      data-canvas-object
      style={{
        position: 'absolute', left: artifact.x, top: artifact.y, width: artifact.width, height: artifact.height,
        borderRadius: 24, overflow: 'hidden', background: `linear-gradient(145deg,rgba(24,24,27,.98),${artifact.accent}24)`,
        border: `1px solid ${artifact.accent}66`, boxShadow: '0 22px 62px rgba(0,0,0,.34)', color: '#F7F6F8', zIndex: 18,
      }}
    >
      <div
        onPointerDown={startDrag}
        onPointerMove={(event) => {
          const drag = dragRef.current;
          if (!drag || drag.pointerId !== event.pointerId) return;
          const scale = Math.max(.12, canvasScale || 1);
          onChange(artifact.id, { x: drag.x + (event.clientX - drag.clientX) / scale, y: drag.y + (event.clientY - drag.clientY) / scale });
        }}
        onPointerUp={(event) => {
          if (dragRef.current?.pointerId !== event.pointerId) return;
          dragRef.current = null;
          try { event.currentTarget.releasePointerCapture(event.pointerId); } catch { /* noop */ }
        }}
        style={{ height: 42, padding: '0 12px', display: 'flex', alignItems: 'center', gap: 8, borderBottom: '1px solid rgba(255,255,255,.08)', cursor: activeTool === 'select' || activeTool === 'hand' ? 'move' : 'default' }}
      >
        <Grip size={13} color="rgba(255,255,255,.42)" />
        <FileSearch size={14} color={artifact.accent} />
        <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 9.5, fontWeight: 850, letterSpacing: '.05em', textTransform: 'uppercase' }}>{artifact.kind === 'audit' ? 'Audit' : artifact.kind === 'import' ? 'Import ZIP' : 'Point Zéro'}</span>
        <MoreHorizontal size={14} color="rgba(255,255,255,.42)" />
        <button data-no-drag title="Supprimer" onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onDelete(artifact.id); }} style={{ width: 26, height: 26, border: 0, borderRadius: 7, display: 'grid', placeItems: 'center', color: 'rgba(255,255,255,.56)', background: 'transparent', cursor: 'pointer' }}><Trash2 size={12} /></button>
      </div>
      <div style={{ padding: 22, height: 'calc(100% - 42px)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column' }}>
        <div style={{ fontSize: 24, fontWeight: 900, letterSpacing: '-.045em', lineHeight: 1.02 }}>{artifact.title}</div>
        <div style={{ marginTop: 15, whiteSpace: 'pre-wrap', fontSize: 10.5, lineHeight: 1.6, color: 'rgba(247,246,248,.68)', overflow: 'auto' }}>{artifact.body}</div>
        <div style={{ marginTop: 'auto', paddingTop: 14, fontSize: 8, color: 'rgba(247,246,248,.34)', display: 'flex', justifyContent: 'space-between' }}><span>Point Zéro des Vivants</span><span>{new Date(artifact.createdAt).toLocaleString('fr-FR')}</span></div>
      </div>
    </div>
  );
};
