import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, Image, LayoutPanelTop, Link2, MousePointerClick, Palette, Type, X } from 'lucide-react';
import type { RemixTarget } from '../types';
import { useTheme } from '../contexts/ThemeContext';

export type CompositionPreset = 'editorial' | 'visual-background' | 'split-left' | 'split-right' | 'duo' | 'gallery' | 'slider' | 'horizontal-cards';
export interface CardCompositionSettings {
  preset: CompositionPreset;
  background: string;
  textColor: string;
  accentColor: string;
  titleVisible: boolean;
  introVisible: boolean;
  mediaUrl: string;
  primaryAction: string;
  secondaryAction: string;
}

interface CardCompositionPanelProps {
  open: boolean;
  target: RemixTarget | null;
  selectedCount?: number;
  initial?: Partial<CardCompositionSettings>;
  onApply: (settings: CardCompositionSettings) => void;
  onUseSelectedCards?: () => void;
  onClose: () => void;
  preview: (settings: CardCompositionSettings) => React.ReactNode;
}

const DEFAULTS: CardCompositionSettings = {
  preset: 'editorial',
  background: '#242426',
  textColor: '#F5F5F5',
  accentColor: '#D4D4D8',
  titleVisible: true,
  introVisible: true,
  mediaUrl: '',
  primaryAction: 'Découvrir',
  secondaryAction: '',
};

const PRESETS: Array<{ id: CompositionPreset; label: string; description: string }> = [
  { id: 'editorial', label: 'Éditorial', description: 'Titre, introduction et contenu sans visuel imposé.' },
  { id: 'visual-background', label: 'Visuel plein fond', description: 'Image ou vidéo en arrière-plan avec texte superposé.' },
  { id: 'split-left', label: 'Visuel à gauche', description: 'Un carré visuel à gauche, le texte à droite.' },
  { id: 'split-right', label: 'Visuel à droite', description: 'Le texte ouvre la section, le visuel la complète.' },
  { id: 'duo', label: 'Duo', description: 'Deux cartes ou deux visuels en dialogue.' },
  { id: 'gallery', label: 'Galerie', description: 'Un visuel principal accompagné de vignettes.' },
  { id: 'slider', label: 'Slider', description: 'Une séquence horizontale navigable.' },
  { id: 'horizontal-cards', label: 'Cartes horizontales', description: 'Les cartes reliées deviennent une collection.' },
];

type Tab = 'composition' | 'media' | 'color' | 'text' | 'actions';
const TABS: Array<{ id: Tab; label: string; icon: React.ReactNode }> = [
  { id: 'composition', label: 'Composition', icon: <LayoutPanelTop size={14} /> },
  { id: 'media', label: 'Visuels', icon: <Image size={14} /> },
  { id: 'color', label: 'Couleurs', icon: <Palette size={14} /> },
  { id: 'text', label: 'Texte', icon: <Type size={14} /> },
  { id: 'actions', label: 'Boutons', icon: <MousePointerClick size={14} /> },
];

export const CardCompositionPanel: React.FC<CardCompositionPanelProps> = ({
  open,
  target,
  selectedCount = 0,
  initial,
  onApply,
  onUseSelectedCards,
  onClose,
  preview,
}) => {
  const { isDark } = useTheme();
  const [tab, setTab] = useState<Tab>('composition');
  const [form, setForm] = useState<CardCompositionSettings>({ ...DEFAULTS, ...initial });

  useEffect(() => {
    if (!open) return;
    setTab('composition');
    setForm({ ...DEFAULTS, ...initial });
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const escape = (event: KeyboardEvent) => event.key === 'Escape' && onClose();
    window.addEventListener('keydown', escape);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener('keydown', escape);
    };
  }, [initial, onClose, open]);

  const livePreview = useMemo(() => preview(form), [form, preview]);
  if (!open || !target || typeof document === 'undefined') return null;

  const bg = isDark ? '#151516' : '#EEEDEF';
  const panel = isDark ? '#1D1D1F' : '#FFFFFF';
  const surface = isDark ? '#252527' : '#F7F7F8';
  const border = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)';
  const text = isDark ? '#F5F5F5' : '#171719';
  const muted = isDark ? 'rgba(245,245,245,.5)' : 'rgba(23,23,25,.5)';

  return createPortal(
    <div onMouseDown={(event) => event.target === event.currentTarget && onClose()} style={{ position: 'fixed', inset: 0, zIndex: 2147482600, background: 'rgba(0,0,0,.6)', backdropFilter: 'blur(18px)', WebkitBackdropFilter: 'blur(18px)', display: 'grid', placeItems: 'center', padding: 16 }}>
      <section role="dialog" aria-modal="true" aria-label={`Mise en page de ${target.label}`} style={{ width: 'min(1440px,calc(100vw - 24px))', height: 'min(920px,calc(100vh - 24px))', borderRadius: 22, overflow: 'hidden', background: panel, color: text, border: `1px solid ${border}`, boxShadow: '0 38px 124px rgba(0,0,0,.48)', display: 'grid', gridTemplateRows: '70px 54px minmax(0,1fr) 72px' }}>
        <header style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 20px', borderBottom: `1px solid ${border}` }}>
          <span style={{ width: 38, height: 38, borderRadius: 12, display: 'grid', placeItems: 'center', background: surface, border: `1px solid ${border}` }}><LayoutPanelTop size={17} /></span>
          <div style={{ minWidth: 0 }}><div style={{ fontSize: 8, fontWeight: 760, letterSpacing: '.14em', textTransform: 'uppercase', color: muted }}>Mise en page</div><strong style={{ display: 'block', marginTop: 4, fontSize: 18, letterSpacing: '-.025em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{target.label}</strong></div>
          {selectedCount > 0 && <span style={{ marginLeft: 8, minHeight: 24, display: 'inline-flex', alignItems: 'center', gap: 5, padding: '0 9px', borderRadius: 999, background: surface, color: muted, fontSize: 8.5 }}><Link2 size={10} />{selectedCount} carte{selectedCount > 1 ? 's' : ''} prête{selectedCount > 1 ? 's' : ''} à relier</span>}
          <button onClick={onClose} aria-label="Fermer" style={{ marginLeft: 'auto', width: 36, height: 36, borderRadius: 10, border: `1px solid ${border}`, background: surface, color: text, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={16} /></button>
        </header>

        <nav style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '0 16px', borderBottom: `1px solid ${border}`, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {TABS.map((item) => <button key={item.id} onClick={() => setTab(item.id)} style={{ height: 34, padding: '0 12px', borderRadius: 9, border: 0, background: tab === item.id ? (isDark ? '#F5F5F5' : '#171719') : 'transparent', color: tab === item.id ? (isDark ? '#171719' : '#FFFFFF') : muted, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 9.5, fontWeight: tab === item.id ? 780 : 560, whiteSpace: 'nowrap' }}>{item.icon}{item.label}</button>)}
        </nav>

        <div style={{ minHeight: 0, display: 'grid', gridTemplateColumns: 'minmax(430px,.9fr) minmax(420px,1.1fr)' }}>
          <div style={{ minHeight: 0, padding: 24, background: bg, display: 'grid', placeItems: 'center', overflow: 'auto' }}>
            <div style={{ width: 'min(760px,100%)', aspectRatio: '1.25', minHeight: 430, borderRadius: 18, overflow: 'hidden', background: surface, border: `1px solid ${border}`, boxShadow: '0 28px 78px rgba(0,0,0,.34)', display: 'flex', flexDirection: 'column' }}>
              <div style={{ height: 34, flexShrink: 0, borderBottom: `1px solid ${border}`, display: 'flex', alignItems: 'center', gap: 5, padding: '0 12px' }}><i style={{ width: 7, height: 7, borderRadius: '50%', background: muted }} /><i style={{ width: 7, height: 7, borderRadius: '50%', background: muted }} /><i style={{ width: 7, height: 7, borderRadius: '50%', background: muted }} /><span style={{ marginLeft: 9, fontSize: 8, color: muted }}>aperçu en direct</span></div>
              <div style={{ flex: 1, minHeight: 0, overflow: 'auto' }}>{livePreview}</div>
            </div>
          </div>

          <div style={{ minHeight: 0, overflowY: 'auto', padding: 26 }}>
            {tab === 'composition' && <CompositionTab form={form} setForm={setForm} border={border} surface={surface} text={text} muted={muted} />}
            {tab === 'media' && <MediaTab form={form} setForm={setForm} border={border} surface={surface} text={text} muted={muted} />}
            {tab === 'color' && <ColorTab form={form} setForm={setForm} border={border} surface={surface} text={text} muted={muted} />}
            {tab === 'text' && <TextTab form={form} setForm={setForm} border={border} surface={surface} text={text} muted={muted} />}
            {tab === 'actions' && <ActionsTab form={form} setForm={setForm} border={border} surface={surface} text={text} muted={muted} />}
          </div>
        </div>

        <footer style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 18px', borderTop: `1px solid ${border}` }}>
          {selectedCount > 0 && onUseSelectedCards && <button onClick={onUseSelectedCards} style={{ height: 40, padding: '0 14px', borderRadius: 10, border: `1px solid ${border}`, background: surface, color: text, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 9.5, fontWeight: 720 }}><Link2 size={13} />Magnétiser les {selectedCount} cartes</button>}
          <button onClick={onClose} style={{ marginLeft: 'auto', height: 40, padding: '0 16px', borderRadius: 10, border: `1px solid ${border}`, background: 'transparent', color: muted, cursor: 'pointer', fontSize: 9.5 }}>Annuler</button>
          <button onClick={() => { onApply(form); onClose(); }} style={{ height: 42, padding: '0 19px', borderRadius: 10, border: 0, background: isDark ? '#F5F5F5' : '#171719', color: isDark ? '#171719' : '#FFFFFF', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 10, fontWeight: 800 }}><Check size={14} />Appliquer</button>
        </footer>
      </section>
    </div>,
    document.body,
  );
};

interface TabProps {
  form: CardCompositionSettings;
  setForm: React.Dispatch<React.SetStateAction<CardCompositionSettings>>;
  border: string;
  surface: string;
  text: string;
  muted: string;
}

const CompositionTab: React.FC<TabProps> = ({ form, setForm, border, surface, text, muted }) => <div><h3 style={heading}>Choisissez une composition professionnelle</h3><p style={{ ...intro, color: muted }}>La version responsive correspondante sera appliquée automatiquement à la projection.</p><div style={{ marginTop: 22, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 11 }}>{PRESETS.map((preset) => <button key={preset.id} onClick={() => setForm((current) => ({ ...current, preset: preset.id }))} style={{ minHeight: 150, padding: 12, borderRadius: 15, border: `1px solid ${form.preset === preset.id ? text : border}`, background: surface, color: text, cursor: 'pointer', textAlign: 'left', boxShadow: form.preset === preset.id ? `0 0 0 2px ${border}` : 'none' }}><PresetMiniature preset={preset.id} /><div style={{ marginTop: 11, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><strong style={{ fontSize: 11.5 }}>{preset.label}</strong>{form.preset === preset.id && <Check size={13} />}</div><p style={{ margin: '6px 0 0', color: muted, fontSize: 8.5, lineHeight: 1.45 }}>{preset.description}</p></button>)}</div></div>;

const MediaTab: React.FC<TabProps> = ({ form, setForm, border, surface, text, muted }) => <div><h3 style={heading}>Visuels de la composition</h3><p style={{ ...intro, color: muted }}>Collez une URL. L’import par fichier restera accessible depuis la bibliothèque Médias.</p><Field label="URL de l’image ou de la vidéo" muted={muted}><input value={form.mediaUrl} onChange={(event) => setForm((current) => ({ ...current, mediaUrl: event.target.value }))} placeholder="https://…" style={inputStyle(surface, border, text)} /></Field><div style={{ marginTop: 18, minHeight: 210, borderRadius: 16, border: `1px dashed ${border}`, background: form.mediaUrl ? `center/cover url(${form.mediaUrl})` : surface, display: 'grid', placeItems: 'center', color: muted }}>{!form.mediaUrl && <div style={{ textAlign: 'center' }}><Image size={22} /><div style={{ marginTop: 9, fontSize: 9.5 }}>Aucun visuel relié</div></div>}</div></div>;

const ColorTab: React.FC<TabProps> = ({ form, setForm, border, surface, text, muted }) => <div><h3 style={heading}>Couleurs et contraste</h3><p style={{ ...intro, color: muted }}>Les réglages s’appliquent à l’aperçu en direct.</p><div style={{ marginTop: 20, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}><ColorField label="Fond" value={form.background} onChange={(value) => setForm((current) => ({ ...current, background: value }))} border={border} surface={surface} text={text} muted={muted} /><ColorField label="Texte" value={form.textColor} onChange={(value) => setForm((current) => ({ ...current, textColor: value }))} border={border} surface={surface} text={text} muted={muted} /><ColorField label="Action" value={form.accentColor} onChange={(value) => setForm((current) => ({ ...current, accentColor: value }))} border={border} surface={surface} text={text} muted={muted} /></div></div>;

const TextTab: React.FC<TabProps> = ({ form, setForm, border, surface, text, muted }) => <div><h3 style={heading}>Hiérarchie éditoriale</h3><p style={{ ...intro, color: muted }}>Choisissez les zones visibles. Le contenu reste celui de la carte source.</p><div style={{ marginTop: 20, display: 'grid', gap: 10 }}><Toggle active={form.titleVisible} label="Afficher le titre" onClick={() => setForm((current) => ({ ...current, titleVisible: !current.titleVisible }))} border={border} surface={surface} text={text} /><Toggle active={form.introVisible} label="Afficher l’introduction" onClick={() => setForm((current) => ({ ...current, introVisible: !current.introVisible }))} border={border} surface={surface} text={text} /></div></div>;

const ActionsTab: React.FC<TabProps> = ({ form, setForm, border, surface, text, muted }) => <div><h3 style={heading}>Boutons et actions</h3><p style={{ ...intro, color: muted }}>Les actions restent sémantiques : découvrir, réserver, contacter, payer ou naviguer.</p><Field label="Action principale" muted={muted}><input value={form.primaryAction} onChange={(event) => setForm((current) => ({ ...current, primaryAction: event.target.value }))} placeholder="Découvrir" style={inputStyle(surface, border, text)} /></Field><Field label="Action secondaire" muted={muted}><input value={form.secondaryAction} onChange={(event) => setForm((current) => ({ ...current, secondaryAction: event.target.value }))} placeholder="Optionnel" style={inputStyle(surface, border, text)} /></Field></div>;

const PresetMiniature: React.FC<{ preset: CompositionPreset }> = ({ preset }) => {
  const box: React.CSSProperties = { borderRadius: 7, background: 'rgba(127,127,132,.18)' };
  if (preset === 'visual-background') return <div style={{ height: 66, borderRadius: 9, background: 'linear-gradient(135deg,#45454A,#18181A)', padding: 10, display: 'flex', alignItems: 'flex-end' }}><span style={{ width: '70%', height: 8, borderRadius: 5, background: 'rgba(255,255,255,.74)' }} /></div>;
  if (preset === 'split-left' || preset === 'split-right') return <div style={{ height: 66, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, direction: preset === 'split-right' ? 'rtl' : 'ltr' }}><span style={{ ...box, background: 'linear-gradient(135deg,#8A8A90,#404044)' }} /><span style={{ ...box, padding: 9, display: 'grid', alignContent: 'center', gap: 5 }}><i style={{ height: 7, borderRadius: 4, background: 'rgba(127,127,132,.45)' }} /><i style={{ height: 5, width: '70%', borderRadius: 4, background: 'rgba(127,127,132,.24)' }} /></span></div>;
  if (preset === 'duo') return <div style={{ height: 66, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}><span style={{ ...box, background: '#45454A' }} /><span style={{ ...box, background: '#69696E' }} /></div>;
  if (preset === 'gallery') return <div style={{ height: 66, display: 'grid', gridTemplateColumns: '1.4fr .6fr', gap: 6 }}><span style={{ ...box, background: '#515156' }} /><span style={{ display: 'grid', gap: 5 }}><i style={box} /><i style={box} /></span></div>;
  if (preset === 'slider' || preset === 'horizontal-cards') return <div style={{ height: 66, display: 'flex', gap: 6, overflow: 'hidden' }}>{[0,1,2].map((value) => <span key={value} style={{ ...box, width: preset === 'slider' && value === 0 ? '66%' : '42%', flexShrink: 0, background: value === 0 ? '#515156' : '#77777D' }} />)}</div>;
  return <div style={{ height: 66, ...box, padding: 10, display: 'grid', alignContent: 'center', gap: 6 }}><span style={{ height: 8, width: '74%', borderRadius: 5, background: 'rgba(127,127,132,.45)' }} /><span style={{ height: 5, borderRadius: 5, background: 'rgba(127,127,132,.22)' }} /><span style={{ height: 5, width: '62%', borderRadius: 5, background: 'rgba(127,127,132,.22)' }} /></div>;
};

const ColorField: React.FC<{ label: string; value: string; onChange: (value: string) => void; border: string; surface: string; text: string; muted: string }> = ({ label, value, onChange, border, surface, text, muted }) => <label style={{ display: 'block' }}><span style={{ display: 'block', marginBottom: 7, color: muted, fontSize: 8, fontWeight: 760, textTransform: 'uppercase', letterSpacing: '.1em' }}>{label}</span><input type="color" value={value} onChange={(event) => onChange(event.target.value)} style={{ width: '100%', height: 66, padding: 5, borderRadius: 12, border: `1px solid ${border}`, background: surface, color: text }} /><code style={{ display: 'block', marginTop: 7, color: muted, fontSize: 8.5 }}>{value}</code></label>;
const Toggle: React.FC<{ active: boolean; label: string; onClick: () => void; border: string; surface: string; text: string }> = ({ active, label, onClick, border, surface, text }) => <button onClick={onClick} style={{ minHeight: 44, padding: '0 13px', borderRadius: 11, border: `1px solid ${active ? text : border}`, background: surface, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 9, fontSize: 10, textAlign: 'left' }}><span style={{ width: 18, height: 18, borderRadius: 6, border: `1px solid ${active ? text : border}`, background: active ? text : 'transparent', color: surface, display: 'grid', placeItems: 'center' }}>{active && <Check size={11} />}</span>{label}</button>;
const Field: React.FC<{ label: string; muted: string; children: React.ReactNode }> = ({ label, muted, children }) => <label style={{ display: 'block', marginTop: 20 }}><span style={{ display: 'block', marginBottom: 7, color: muted, fontSize: 8, fontWeight: 760, textTransform: 'uppercase', letterSpacing: '.1em' }}>{label}</span>{children}</label>;
const inputStyle = (background: string, border: string, color: string): React.CSSProperties => ({ width: '100%', height: 42, boxSizing: 'border-box', borderRadius: 10, border: `1px solid ${border}`, background, color, padding: '0 12px', outline: 'none', fontSize: 10.5 });
const heading: React.CSSProperties = { margin: 0, fontSize: 25, letterSpacing: '-.045em' };
const intro: React.CSSProperties = { margin: '9px 0 0', maxWidth: 620, fontSize: 10.5, lineHeight: 1.6 };
