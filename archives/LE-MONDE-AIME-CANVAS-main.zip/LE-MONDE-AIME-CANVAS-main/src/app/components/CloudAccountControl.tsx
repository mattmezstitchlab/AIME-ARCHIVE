import React, { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle,
  Check,
  Cloud,
  CloudDownload,
  CloudOff,
  CloudUpload,
  History,
  LogOut,
  Mail,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UserRound,
  Users,
  X,
} from 'lucide-react';
import { toast } from 'sonner';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import type { StudioProjectMeta } from '../utils/projectStore';
import { collectProjectSnapshot } from '../utils/projectStore';
import {
  applyCloudSnapshot,
  CloudConflictError,
  fetchCloudSnapshot,
  getCloudSyncState,
  inviteProjectMember,
  listCloudProjects,
  listProjectMembers,
  removeProjectMember,
  syncProjectToCloud,
  type CloudMember,
  type CloudProjectSummary,
  type CloudRole,
  type CloudSyncState,
} from '../cloud/cloudProjectStore';

interface CloudAccountControlProps {
  project?: StudioProjectMeta | null;
  onOpen?: () => void;
  compact?: boolean;
}

const AUTO_SYNC_KEY = 'lma_cloud_auto_sync_v1';

export const CloudAccountControl: React.FC<CloudAccountControlProps> = ({ project, onOpen, compact }) => {
  const { isDark } = useTheme();
  const auth = useAuth();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [role, setRole] = useState<Exclude<CloudRole, 'owner'>>('editor');
  const [members, setMembers] = useState<CloudMember[]>([]);
  const [cloudProjects, setCloudProjects] = useState<CloudProjectSummary[]>([]);
  const [syncState, setSyncState] = useState<CloudSyncState | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [autoSync, setAutoSync] = useState(() => localStorage.getItem(AUTO_SYNC_KEY) === '1');
  const [cooldown, setCooldown] = useState(0);
  const lastCloudOperationRef = useRef(0);
  const autoSyncTimerRef = useRef<number | null>(null);

  const bg = isDark ? '#1D1D1F' : '#FAFAFB';
  const surface = isDark ? '#242426' : '#FFFFFF';
  const surface2 = isDark ? '#2B2B2E' : '#F1F1F3';
  const border = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)';
  const text = isDark ? '#F5F5F5' : '#121213';
  const muted = isDark ? 'rgba(245,245,245,.48)' : 'rgba(18,18,19,.5)';

  useEffect(() => {
    if (!cooldown) return;
    const timer = window.setInterval(() => setCooldown((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [cooldown > 0]);

  useEffect(() => {
    if (!open || typeof document === 'undefined') return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', closeOnEscape);
    };
  }, [open]);

  const refreshCloudData = useCallback(async () => {
    if (!auth.user || !auth.configured) return;
    const tasks: Promise<unknown>[] = [
      listCloudProjects().then(setCloudProjects),
    ];
    if (project) {
      tasks.push(listProjectMembers(project.id).then(setMembers));
      tasks.push(getCloudSyncState(project.id).then(setSyncState));
    }
    const results = await Promise.allSettled(tasks);
    const rejected = results.find((result) => result.status === 'rejected') as PromiseRejectedResult | undefined;
    if (rejected) setMessage(rejected.reason instanceof Error ? rejected.reason.message : 'Lecture du cloud impossible.');
  }, [auth.configured, auth.user, project?.id]);

  useEffect(() => {
    if (!open || !auth.user) return;
    void refreshCloudData();
  }, [auth.user, open, refreshCloudData]);

  const performSync = useCallback(async (force = false, automatic = false) => {
    if (!project || !auth.user || busy) return;
    setBusy(true);
    if (!automatic) setMessage('');
    try {
      const result = await syncProjectToCloud(project, collectProjectSnapshot(project.id), auth.user, { force });
      lastCloudOperationRef.current = Date.now();
      setSyncState({ status: 'synchronized', localVersion: result.version, remoteVersion: result.version });
      if (!automatic) {
        toast.success(result.created ? 'Projet créé dans le cloud.' : 'Projet synchronisé dans le cloud.');
        setMessage(force ? 'Le cloud a été remplacé par cette version locale.' : 'Sauvegarde cloud à jour.');
      }
    } catch (error) {
      if (error instanceof CloudConflictError) {
        setSyncState({ status: 'conflict', localVersion: error.localVersion, remoteVersion: error.remoteVersion });
        setMessage(error.message);
      } else if (!automatic) {
        setMessage(error instanceof Error ? error.message : 'Synchronisation impossible.');
      }
    } finally {
      setBusy(false);
    }
  }, [auth.user, busy, project]);

  useEffect(() => {
    if (!autoSync || !auth.user || !project) return;
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<{ projectId?: string; state?: string }>).detail;
      if (detail?.projectId !== project.id || detail?.state !== 'saved') return;
      if (Date.now() - lastCloudOperationRef.current < 4500) return;
      if (autoSyncTimerRef.current) window.clearTimeout(autoSyncTimerRef.current);
      autoSyncTimerRef.current = window.setTimeout(() => void performSync(false, true), 2200);
    };
    window.addEventListener('lma:project-save-state', handler);
    return () => {
      window.removeEventListener('lma:project-save-state', handler);
      if (autoSyncTimerRef.current) window.clearTimeout(autoSyncTimerRef.current);
    };
  }, [auth.user, autoSync, performSync, project?.id]);

  const openPanel = () => {
    onOpen?.();
    setOpen(true);
    setMessage('');
  };

  const signIn = async () => {
    if (cooldown > 0) return;
    setBusy(true);
    setMessage('');
    try {
      await auth.sendMagicLink(email);
      setCooldown(60);
      setMessage('Lien de connexion envoyé. Consultez votre boîte mail et ouvrez le lien sur cet appareil.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Connexion impossible.');
    } finally {
      setBusy(false);
    }
  };

  const restoreCloud = async () => {
    if (!project || busy) return;
    setBusy(true);
    setMessage('');
    try {
      const snapshot = await fetchCloudSnapshot(project.id);
      if (!snapshot) throw new Error('Aucune version cloud disponible pour ce projet.');
      lastCloudOperationRef.current = Date.now();
      await applyCloudSnapshot(project.id, snapshot);
      toast.success('Version cloud chargée.');
      window.location.reload();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Chargement impossible.');
      setBusy(false);
    }
  };

  const invite = async () => {
    if (!project || busy) return;
    setBusy(true);
    setMessage('');
    try {
      await inviteProjectMember(project.id, inviteEmail, role);
      setInviteEmail('');
      setMembers(await listProjectMembers(project.id));
      toast.success('Contributeur ajouté au projet.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Invitation impossible.');
    } finally {
      setBusy(false);
    }
  };

  const retryConfiguration = async () => {
    setBusy(true);
    setMessage('');
    try {
      const ready = await auth.refreshConfiguration();
      setMessage(ready ? 'Cloud détecté. Vous pouvez maintenant vous connecter.' : auth.diagnostic.error || 'Le cloud reste indisponible.');
    } finally {
      setBusy(false);
    }
  };

  const toggleAutoSync = () => {
    const next = !autoSync;
    setAutoSync(next);
    localStorage.setItem(AUTO_SYNC_KEY, next ? '1' : '0');
    setMessage(next ? 'Sauvegarde automatique activée après chaque modification locale.' : 'Sauvegarde automatique désactivée.');
  };

  const statusLabel = auth.loading
    ? 'Vérification de la configuration…'
    : auth.configured
      ? auth.user ? 'Cloud connecté' : 'Connexion par lien sécurisé'
      : auth.diagnostic.error ? 'Cloud à vérifier' : 'Mode local — aucune donnée envoyée';

  const syncPresentation = syncState ? syncStatusText(syncState.status) : null;

  const panel = open && typeof document !== 'undefined'
    ? createPortal(
        <div role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setOpen(false); }} style={{ position: 'fixed', inset: 0, zIndex: 2147483000, background: 'rgba(0,0,0,.42)', isolation: 'isolate' }}>
          <aside role="dialog" aria-modal="true" aria-label="Compte et collaboration" style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: 'min(420px,100vw)', background: bg, color: text, borderLeft: `1px solid ${border}`, boxShadow: '-24px 0 64px rgba(0,0,0,.34)', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif', zIndex: 1 }}>
            <header style={{ minHeight: 62, padding: '12px 16px', borderBottom: `1px solid ${border}`, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: surface2, border: `1px solid ${border}`, display: 'grid', placeItems: 'center' }}>{auth.configured ? <Cloud size={16} /> : <CloudOff size={16} />}</div>
              <div style={{ flex: 1 }}><strong style={{ fontSize: 13 }}>Compte & collaboration</strong><div style={{ fontSize: 9, color: muted, marginTop: 3 }}>{statusLabel}</div></div>
              <button onClick={() => setOpen(false)} aria-label="Fermer" style={{ width: 30, height: 30, border: 0, background: 'transparent', color: muted, cursor: 'pointer' }}><X size={16} /></button>
            </header>

            <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
              {auth.loading ? (
                <Section surface={surface} border={border}><strong style={{ fontSize: 12 }}>Vérification du cloud</strong><p style={{ margin: '8px 0 0', color: muted, fontSize: 9.5, lineHeight: 1.55 }}>LE MONDE AIME contrôle la configuration et la session sans afficher aucune clé.</p></Section>
              ) : !auth.configured ? (
                <Section surface={surface} border={border}>
                  <strong style={{ fontSize: 12 }}>Cloud non activé</strong>
                  <p style={{ margin: '8px 0 10px', color: muted, fontSize: 9.5, lineHeight: 1.55 }}>{auth.diagnostic.error || 'Les variables publiques Supabase ne sont pas disponibles dans ce déploiement.'}</p>
                  <DiagnosticRow label="Source" value={auth.diagnostic.source === 'runtime' ? 'Configuration Vercel runtime' : auth.diagnostic.source === 'build' ? 'Build Vite' : 'Non détectée'} border={border} muted={muted} />
                  <DiagnosticRow label="URL Supabase" value={auth.diagnostic.urlPresent ? auth.diagnostic.urlValid ? 'Détectée et valide' : 'Détectée mais invalide' : 'Absente'} border={border} muted={muted} />
                  <DiagnosticRow label="Clé publique" value={auth.diagnostic.keyPresent ? `Détectée (${auth.diagnostic.keyLength} caractères)` : 'Absente ou vide'} border={border} muted={muted} />
                  <DiagnosticRow label="Environnement" value={auth.diagnostic.environment || 'Inconnu'} border={border} muted={muted} />
                  <button disabled={busy} onClick={() => void retryConfiguration()} style={secondary(surface2, border, text)}><RefreshCw size={12} /> Revérifier la configuration</button>
                </Section>
              ) : !auth.user ? (
                <Section surface={surface} border={border}>
                  <strong style={{ display: 'block', fontSize: 12, marginBottom: 4 }}>Cloud disponible</strong>
                  <p style={{ margin: '0 0 10px', color: muted, fontSize: 9.2, lineHeight: 1.45 }}>Connectez-vous par e-mail pour synchroniser vos projets.</p>
                  <Label muted={muted}>Adresse e-mail</Label>
                  <input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="nom@exemple.fr" style={input(surface2, border, text)} />
                  <button disabled={busy || cooldown > 0 || !email.includes('@')} onClick={() => void signIn()} style={primary(text, isDark)}><Mail size={13} /> {cooldown > 0 ? `Nouveau lien dans ${cooldown} s` : 'Envoyer le lien de connexion'}</button>
                  {auth.authError && <p style={{ margin: '10px 0 0', color: '#F87171', fontSize: 9, lineHeight: 1.45 }}>{auth.authError}</p>}
                </Section>
              ) : <>
                <Section surface={surface} border={border}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><div style={{ width: 36, height: 36, borderRadius: 12, background: surface2, display: 'grid', placeItems: 'center' }}><UserRound size={17} /></div><div style={{ flex: 1, minWidth: 0 }}><strong style={{ fontSize: 11 }}>{auth.user.email}</strong><div style={{ color: muted, fontSize: 8.5, marginTop: 3 }}>Compte authentifié · session sécurisée</div></div><button onClick={() => void auth.signOut()} title="Se déconnecter" style={iconButton(surface2, border, muted)}><LogOut size={14} /></button></div>
                </Section>

                {project && <Section surface={surface} border={border}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <div style={{ width: 34, height: 34, borderRadius: 10, background: surface2, display: 'grid', placeItems: 'center' }}>{syncState?.status === 'conflict' ? <AlertTriangle size={15} /> : <ShieldCheck size={15} />}</div>
                    <div style={{ flex: 1 }}><strong style={{ fontSize: 11 }}>Synchronisation du projet</strong><div style={{ color: muted, fontSize: 8.5, marginTop: 3 }}>{project.name}</div>{syncPresentation && <div style={{ marginTop: 7, fontSize: 9, fontWeight: 720 }}>{syncPresentation}</div>}</div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 12 }}>
                    <button disabled={busy} onClick={() => void performSync(false)} style={secondary(surface2, border, text)}><CloudUpload size={12} /> Sauvegarder</button>
                    <button disabled={busy} onClick={() => void restoreCloud()} style={secondary(surface2, border, text)}><CloudDownload size={12} /> Charger</button>
                  </div>
                  {syncState?.status === 'conflict' && <button disabled={busy} onClick={() => void performSync(true)} style={{ ...secondary(surface2, border, text), marginTop: 8 }}><AlertTriangle size={12} /> Remplacer le cloud par cette version</button>}
                  <button onClick={toggleAutoSync} style={{ ...secondary('transparent', border, text), marginTop: 8, justifyContent: 'space-between', padding: '0 11px' }}><span style={{ display: 'flex', alignItems: 'center', gap: 7 }}><RefreshCw size={12} /> Sauvegarde automatique</span><strong>{autoSync ? 'Activée' : 'Désactivée'}</strong></button>
                </Section>}

                <Section surface={surface} border={border}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><History size={14} /><strong style={{ fontSize: 11 }}>Projets accessibles dans le cloud</strong><span style={{ marginLeft: 'auto', color: muted, fontSize: 8.5 }}>{cloudProjects.length}</span></div>
                  <div style={{ marginTop: 9 }}>
                    {cloudProjects.length ? cloudProjects.slice(0, 6).map((item) => <div key={item.id} style={{ minHeight: 40, display: 'flex', alignItems: 'center', gap: 9, borderTop: `1px solid ${border}` }}><Cloud size={12} color={muted} /><span style={{ flex: 1, minWidth: 0 }}><strong style={{ display: 'block', fontSize: 9.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</strong><span style={{ display: 'block', color: muted, fontSize: 7.8, marginTop: 2 }}>{item.universe} · {item.status}</span></span>{item.id === project?.id && <Check size={12} />}</div>) : <p style={{ color: muted, fontSize: 8.8, lineHeight: 1.45 }}>Aucun projet cloud pour ce compte. La première sauvegarde créera le projet.</p>}
                  </div>
                </Section>

                {project && <Section surface={surface} border={border}>
                  <strong style={{ fontSize: 11 }}>Contributeurs</strong><p style={{ margin: '5px 0 12px', color: muted, fontSize: 8.8, lineHeight: 1.45 }}>Ajoutez une personne par e-mail et choisissez son niveau d’accès.</p><Label muted={muted}>E-mail</Label><input value={inviteEmail} onChange={(event) => setInviteEmail(event.target.value)} placeholder="contributeur@exemple.fr" style={input(surface2, border, text)} /><Label muted={muted}>Rôle</Label><select value={role} onChange={(event) => setRole(event.target.value as Exclude<CloudRole,'owner'>)} style={input(surface2, border, text)}><option value="editor">Éditeur</option><option value="commenter">Commentateur</option><option value="viewer">Lecteur</option></select><button disabled={busy || !inviteEmail.includes('@')} onClick={() => void invite()} style={primary(text, isDark)}><Users size={13} /> Ajouter au projet</button><div style={{ marginTop: 12 }}>{members.map((member) => <div key={member.id} style={{ minHeight: 42, display: 'flex', alignItems: 'center', gap: 9, borderTop: `1px solid ${border}` }}><span style={{ flex: 1, minWidth: 0 }}><strong style={{ display: 'block', fontSize: 9.5, overflow: 'hidden', textOverflow: 'ellipsis' }}>{member.email}</strong><span style={{ display: 'block', color: muted, fontSize: 8, marginTop: 2 }}>{roleLabel(member.role)}</span></span><button onClick={() => void removeProjectMember(member.id).then(() => setMembers((items) => items.filter((item) => item.id !== member.id)))} style={iconButton('transparent', border, muted)}><Trash2 size={12} /></button></div>)}</div>
                </Section>}
              </>}
              {message && <div role="status" style={{ marginTop: 12, padding: '10px 12px', borderRadius: 9, background: surface, border: `1px solid ${border}`, color: muted, fontSize: 9.2, lineHeight: 1.45 }}>{message}</div>}
            </div>
          </aside>
        </div>,
        document.body,
      )
    : null;

  return <>
    <button onClick={openPanel} title={auth.loading ? 'Vérification cloud' : auth.configured ? auth.user ? `Compte ${auth.user.email || ''}` : 'Connexion cloud' : 'Mode local'} style={{ height: compact ? 29 : 32, minWidth: compact ? 29 : 32, padding: compact ? 0 : '0 9px', borderRadius: 8, border: `1px solid ${border}`, background: 'transparent', color: auth.user ? text : muted, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 8.5 }}>
      {auth.configured ? auth.user ? <Cloud size={14} /> : <UserRound size={14} /> : auth.loading ? <RefreshCw size={14} /> : <CloudOff size={14} />}
      {!compact && <span>{auth.user ? 'Compte' : auth.configured ? 'Connexion' : auth.loading ? 'Vérification' : 'Local'}</span>}
    </button>
    {panel}
  </>;
};

function syncStatusText(status: CloudSyncState['status']) {
  if (status === 'synchronized') return 'Version locale et cloud identiques';
  if (status === 'local-only') return 'Pas encore sauvegardé dans le cloud';
  if (status === 'cloud-newer') return 'Une version cloud est disponible';
  if (status === 'local-newer') return 'La version locale doit être sauvegardée';
  return 'Conflit : choisissez quelle version conserver';
}

function roleLabel(role: CloudRole) {
  if (role === 'editor') return 'Éditeur';
  if (role === 'commenter') return 'Commentateur';
  if (role === 'viewer') return 'Lecteur';
  return 'Propriétaire';
}

const Section: React.FC<{ surface: string; border: string; children: React.ReactNode }> = ({ surface, border, children }) => <section style={{ padding: 14, borderRadius: 12, background: surface, border: `1px solid ${border}`, marginBottom: 12 }}>{children}</section>;
const Label: React.FC<{ muted: string; children: React.ReactNode }> = ({ muted, children }) => <label style={{ display: 'block', margin: '10px 0 5px', color: muted, fontSize: 8, fontWeight: 750, letterSpacing: '.08em', textTransform: 'uppercase' }}>{children}</label>;
const DiagnosticRow: React.FC<{ label: string; value: string; border: string; muted: string }> = ({ label, value, border, muted }) => <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, minHeight: 34, borderTop: `1px solid ${border}`, fontSize: 8.8 }}><span style={{ color: muted }}>{label}</span><strong style={{ textAlign: 'right', fontSize: 8.8 }}>{value}</strong></div>;
const input = (background: string, border: string, color: string): React.CSSProperties => ({ width: '100%', height: 38, borderRadius: 9, border: `1px solid ${border}`, background, color, padding: '0 10px', boxSizing: 'border-box', outline: 'none', fontSize: 10 });
const primary = (text: string, isDark: boolean): React.CSSProperties => ({ marginTop: 11, width: '100%', height: 38, borderRadius: 9, border: 0, background: isDark ? '#F4F4F5' : '#18181A', color: isDark ? '#18181A' : '#FFFFFF', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, fontSize: 9.5, fontWeight: 780 });
const secondary = (background: string, border: string, color: string): React.CSSProperties => ({ width: '100%', height: 36, borderRadius: 9, border: `1px solid ${border}`, background, color, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 9 });
const iconButton = (background: string, border: string, color: string): React.CSSProperties => ({ width: 30, height: 30, borderRadius: 8, border: `1px solid ${border}`, background, color, cursor: 'pointer', display: 'grid', placeItems: 'center' });
