import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { GitBranch, History, ShieldCheck, X } from 'lucide-react';
import type { RemixHistoryEntry, RemixPermissions } from '../types';
import { useTheme } from '../contexts/ThemeContext';

interface RemixPermissionsPanelProps {
  open: boolean;
  permissions: RemixPermissions;
  history: RemixHistoryEntry[];
  onChange: (permissions: RemixPermissions) => void;
  onClose: () => void;
}

const labels: Array<{ key: keyof RemixPermissions; title: string; desc: string }> = [
  { key: 'allowRemixes', title: 'Autoriser les remixes', desc: 'La communauté peut créer une branche liée.' },
  { key: 'allowMashups', title: 'Autoriser les mashups', desc: 'Cette création peut être fusionnée avec une autre.' },
  { key: 'allowComments', title: 'Autoriser les commentaires', desc: 'Les contributeurs peuvent commenter le projet.' },
  { key: 'allowCommercialUse', title: 'Usage commercial', desc: 'Autoriser l’utilisation dans un projet commercial.' },
  { key: 'requireAttribution', title: 'Attribution obligatoire', desc: 'Conserver le lien vers l’auteur et la source.' },
  { key: 'shareDesign', title: 'Partager le design', desc: 'Palette, typographie, rythme et composition.' },
  { key: 'shareStructure', title: 'Partager la structure', desc: 'Sections, relations et logique responsive.' },
  { key: 'keepPrivateData', title: 'Protéger les données privées', desc: 'Invités, contrats, budget et documents restent exclus.' },
];

export const RemixPermissionsPanel: React.FC<RemixPermissionsPanelProps> = ({ open, permissions, history, onChange, onClose }) => {
  const { isDark } = useTheme();
  const surface = isDark ? '#121117' : '#FBFAFC';
  const card = isDark ? '#1B1A21' : '#FFFFFF';
  const text = isDark ? '#F7F6FA' : '#17161A';
  const muted = isDark ? 'rgba(247,246,250,.48)' : 'rgba(23,22,26,.5)';
  const border = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)';
  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => event.target === event.currentTarget && onClose()} style={{ position: 'fixed', inset: 0, zIndex: 1510, background: 'rgba(3,3,7,.62)', backdropFilter: 'blur(14px)', display: 'grid', placeItems: 'center', padding: 24 }}>
          <motion.div initial={{ y: 22, opacity: 0, scale: .98 }} animate={{ y: 0, opacity: 1, scale: 1 }} exit={{ y: 18, opacity: 0, scale: .98 }} style={{ width: 'min(920px,94vw)', maxHeight: '88vh', overflow: 'hidden', display: 'grid', gridTemplateRows: 'auto 1fr', borderRadius: 23, background: surface, color: text, border: `1px solid ${border}`, boxShadow: '0 40px 120px rgba(0,0,0,.48)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '19px 21px', borderBottom: `1px solid ${border}` }}>
              <span style={{ width: 38, height: 38, borderRadius: 12, display: 'grid', placeItems: 'center', background: 'linear-gradient(135deg,#8B5CF6,#EC4899)', color: '#fff' }}><ShieldCheck size={18} /></span>
              <div style={{ flex: 1 }}><div style={{ fontSize: 15, fontWeight: 850 }}>Droits de remix & généalogie</div><div style={{ marginTop: 3, fontSize: 9.5, color: muted }}>Définissez ce qui peut être transmis sans exposer les données sensibles.</div></div>
              <button onClick={onClose} style={{ width: 34, height: 34, border: 0, borderRadius: 10, background: 'transparent', color: muted, cursor: 'pointer' }}><X size={17} /></button>
            </div>
            <div style={{ overflow: 'auto', display: 'grid', gridTemplateColumns: '1.1fr .9fr', gap: 15, padding: 18 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {labels.map((item) => {
                  const value = permissions[item.key];
                  return <button key={item.key} onClick={() => onChange({ ...permissions, [item.key]: !value })} style={{ width: '100%', padding: '12px 13px', borderRadius: 13, border: `1px solid ${border}`, background: card, color: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left' }}>
                    <span style={{ flex: 1 }}><strong style={{ display: 'block', fontSize: 10.5 }}>{item.title}</strong><span style={{ display: 'block', marginTop: 4, fontSize: 8.7, lineHeight: 1.4, color: muted }}>{item.desc}</span></span>
                    <span style={{ width: 38, height: 22, borderRadius: 999, padding: 2, boxSizing: 'border-box', background: value ? '#EC4899' : isDark ? 'rgba(255,255,255,.12)' : 'rgba(0,0,0,.12)', transition: 'background .18s', display: 'flex', justifyContent: value ? 'flex-end' : 'flex-start' }}><span style={{ width: 18, height: 18, borderRadius: 999, background: '#fff', boxShadow: '0 2px 7px rgba(0,0,0,.25)' }} /></span>
                  </button>;
                })}
              </div>
              <div style={{ borderRadius: 15, border: `1px solid ${border}`, background: card, padding: 14, minHeight: 420 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><History size={15} color="#A78BFA" /><strong style={{ fontSize: 11 }}>Mémoire des transformations</strong></div>
                <div style={{ marginTop: 5, fontSize: 8.7, lineHeight: 1.45, color: muted }}>Chaque Cover, prolongement ou inspiration crée une branche traçable.</div>
                <div style={{ height: 1, background: border, margin: '13px 0' }} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {history.slice().reverse().slice(0, 12).map((entry, index) => <div key={entry.id} style={{ display: 'flex', gap: 9, padding: 9, borderRadius: 10, background: isDark ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.025)' }}>
                    <span style={{ width: 26, height: 26, borderRadius: 8, display: 'grid', placeItems: 'center', background: 'rgba(139,92,246,.15)', color: '#A78BFA', flexShrink: 0 }}><GitBranch size={13} /></span>
                    <span style={{ flex: 1, minWidth: 0 }}><strong style={{ display: 'block', fontSize: 9.5 }}>{entry.label}</strong><span style={{ display: 'block', marginTop: 3, fontSize: 7.8, color: muted }}>{entry.target.label} · {new Date(entry.createdAt).toLocaleString('fr-FR')}</span></span>
                    {index === 0 && <span style={{ fontSize: 7.5, color: '#34D399', fontWeight: 800 }}>ACTUEL</span>}
                  </div>)}
                  {!history.length && <div style={{ padding: 28, textAlign: 'center', fontSize: 9, lineHeight: 1.5, color: muted }}>Aucune transformation enregistrée.<br />Le premier Cover créera la branche d’origine.</div>}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
