import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { RotateCcw } from 'lucide-react';
import { ICON_MAP } from '../utils/iconMap';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CardBack, STATUS_DOT_COLOR } from './CardBack';
import { MusicFront } from './MusicFront';
import { TEXTURE_OVERLAYS } from './TexturePanel';
import type { CardLayoutMode, WeddingCard } from '../types';
import type { AnimationSettings } from './SettingsPanel';

const NUM_VISIBLE = 4;
const CARD_W = 323;
const CARD_H = 484;
const SPREAD_SCALE = 0.68;
const SPREAD_W = Math.round(CARD_W * SPREAD_SCALE);
const SPREAD_H = Math.round(CARD_H * SPREAD_SCALE);
const SPREAD_GAP = 22;

const CARD_TYPE_IMAGES: Record<string, string> = {
  programme: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=900&q=85',
  venue: 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?w=900&q=85',
  'photo-video': 'https://images.unsplash.com/photo-1554048612-b6a482bc67e5?w=900&q=85',
  beauty: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=900&q=85',
  catering: 'https://images.unsplash.com/photo-1555244162-803834f70033?w=900&q=85',
  flowers: 'https://images.unsplash.com/photo-1523438885200-e635ba2c371e?w=900&q=85',
  artist: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=900&q=85',
  animation: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=900&q=85',
  'music-ceremony': 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=900&q=85',
  'music-soiree': 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=900&q=85',
  guests: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=900&q=85',
  budget: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=900&q=85',
  admin: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=900&q=85',
  honeymoon: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=900&q=85',
  planning: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=900&q=85',
};

const swipePower = (offset: number, velocity: number) => Math.abs(offset) * velocity;

const cardVariants = (settings: AnimationSettings) => ({
  visible: (i: number) => ({
    opacity: 1,
    zIndex: [4, 3, 2, 1][i] ?? 0,
    scale: [1, 0.91, 0.85, 0.79][i] ?? 0.75,
    y: [0, -10, 0, 10][i] ?? 16,
    rotate: [0, 2, 4, 6][i] ?? 8,
    x: [0, 28, 44, 58][i] ?? 70,
    transition: {
      zIndex: { delay: settings.zIndexDelay },
      scale: { type: 'spring', duration: settings.springDuration, bounce: settings.springBounce },
      y: { type: 'spring', duration: settings.springDuration, bounce: settings.springBounce },
      x: { type: 'spring', duration: settings.xSpringDuration, bounce: settings.xSpringBounce },
    },
  }),
  exit: { opacity: 0, scale: 0.5, y: 50, transition: { duration: 0.2 } },
});

export function getCardLayoutSize(count: number, mode: CardLayoutMode) {
  if (mode === 'stack') return { width: CARD_W, height: CARD_H + (count > 1 ? 28 : 0) };
  if (mode === 'horizontal') {
    return { width: Math.max(SPREAD_W, count * SPREAD_W + Math.max(0, count - 1) * SPREAD_GAP), height: SPREAD_H };
  }
  if (mode === 'vertical') {
    return { width: SPREAD_W, height: Math.max(SPREAD_H, count * SPREAD_H + Math.max(0, count - 1) * SPREAD_GAP) };
  }
  const columns = Math.max(1, Math.min(count <= 4 ? 2 : 3, count));
  const rows = Math.ceil(count / columns);
  return {
    width: columns * SPREAD_W + Math.max(0, columns - 1) * SPREAD_GAP,
    height: rows * SPREAD_H + Math.max(0, rows - 1) * SPREAD_GAP,
  };
}

interface CardStackProps {
  cards: WeddingCard[];
  cardSettings: Record<string, Record<string, any>>;
  onCardSettingChange: (cardId: string, key: string, value: unknown) => void;
  animSettings: AnimationSettings;
  playingTrackId: string | null;
  onTogglePlay: (cardId: string) => void;
  globalTexture?: string;
  layoutMode?: CardLayoutMode;
}

export const CardStack: React.FC<CardStackProps> = ({
  cards,
  cardSettings,
  onCardSettingChange,
  animSettings,
  playingTrackId,
  onTogglePlay,
  globalTexture,
  layoutMode = 'stack',
}) => {
  const [startIndex, setStartIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [flippedCardId, setFlippedCardId] = useState<string | null>(null);
  const hasDragged = useRef(false);
  const numItems = cards.length;

  useEffect(() => {
    setIsFlipped(false);
    setFlippedCardId(null);
  }, [layoutMode]);

  if (layoutMode !== 'stack') {
    return (
      <SpreadCards
        cards={cards}
        layoutMode={layoutMode}
        cardSettings={cardSettings}
        onCardSettingChange={onCardSettingChange}
        playingTrackId={playingTrackId}
        onTogglePlay={onTogglePlay}
        globalTexture={globalTexture}
        flippedCardId={flippedCardId}
        onFlip={setFlippedCardId}
      />
    );
  }

  const visibleIndices = Array.from({ length: Math.min(NUM_VISIBLE, numItems) }, (_, i) =>
    (startIndex + i) % numItems
  );

  const paginate = () => {
    setStartIndex((prev) => (prev + 1) % numItems);
    setIsFlipped(false);
  };

  const variants = cardVariants(animSettings);
  const isMusic = (c: WeddingCard) => c.type === 'music-ceremony' || c.type === 'music-soiree';

  return (
    <div
      style={{ width: `${CARD_W}px`, height: `${CARD_H}px`, position: 'relative' }}
      onMouseDown={(e) => e.stopPropagation()}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <AnimatePresence initial={false}>
        {visibleIndices.map((cardIndex, i) => {
          const card = cards[cardIndex];
          const isTop = i === 0;
          const settings = cardSettings[card.id] || {};
          const flipped = isTop && isFlipped;

          return (
            <motion.div
              key={card.id}
              custom={i}
              variants={variants}
              initial="exit"
              animate="visible"
              exit="exit"
              drag={isTop && !isFlipped}
              dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
              dragElastic={animSettings.dragElastic}
              onDragStart={() => { hasDragged.current = true; }}
              onDragEnd={(_, { offset, velocity }) => {
                const swipe = swipePower(offset.x, velocity.x);
                if (swipe < -animSettings.swipeConfidenceThreshold || swipe > animSettings.swipeConfidenceThreshold) paginate();
                setTimeout(() => { hasDragged.current = false; }, 80);
              }}
              onClick={() => {
                if (!hasDragged.current && isTop && !isMusic(card)) setIsFlipped((f) => !f);
              }}
              style={{
                position: 'absolute', width: `${CARD_W}px`, height: `${CARD_H}px`, borderRadius: '24px',
                cursor: isTop ? (isFlipped ? 'default' : 'pointer') : 'default', perspective: '1200px',
                boxShadow: '0px 20px 12px rgba(0,0,0,0.05),0px 9px 9px rgba(0,0,0,0.09),0px 2px 5px rgba(0,0,0,0.1)',
              }}
            >
              <CardShell
                card={card}
                settings={settings}
                cardIndex={cardIndex}
                flipped={flipped}
                showConfigureHint={isTop}
                playing={playingTrackId === card.id}
                onTogglePlay={onTogglePlay}
                onChange={onCardSettingChange}
                onClose={() => setIsFlipped(false)}
                globalTexture={globalTexture}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>

      {numItems > 1 && (
        <div style={{ position: 'absolute', bottom: '-28px', left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: '5px' }}>
          {cards.map((_, i) => (
            <div
              key={i}
              onClick={() => { setStartIndex(i); setIsFlipped(false); }}
              style={{
                width: i === startIndex ? '18px' : '5px', height: '5px', borderRadius: '50px',
                background: i === startIndex ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.35)',
                cursor: 'pointer', transition: 'all 0.25s ease',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const SpreadCards: React.FC<{
  cards: WeddingCard[];
  layoutMode: Exclude<CardLayoutMode, 'stack'>;
  cardSettings: Record<string, Record<string, any>>;
  onCardSettingChange: (cardId: string, key: string, value: unknown) => void;
  playingTrackId: string | null;
  onTogglePlay: (cardId: string) => void;
  globalTexture?: string;
  flippedCardId: string | null;
  onFlip: (cardId: string | null) => void;
}> = ({
  cards, layoutMode, cardSettings, onCardSettingChange, playingTrackId,
  onTogglePlay, globalTexture, flippedCardId, onFlip,
}) => {
  const size = getCardLayoutSize(cards.length, layoutMode);
  const columns = Math.max(1, Math.min(cards.length <= 4 ? 2 : 3, cards.length));

  const layoutStyle: React.CSSProperties = layoutMode === 'mosaic'
    ? { display: 'grid', gridTemplateColumns: `repeat(${columns}, ${SPREAD_W}px)`, gap: `${SPREAD_GAP}px` }
    : { display: 'flex', flexDirection: layoutMode === 'horizontal' ? 'row' : 'column', gap: `${SPREAD_GAP}px` };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: 'spring', damping: 28, stiffness: 260 }}
      style={{ width: size.width, height: size.height, ...layoutStyle }}
      onMouseDown={(e) => e.stopPropagation()}
      onPointerDown={(e) => e.stopPropagation()}
    >
      {cards.map((card, cardIndex) => {
        const settings = cardSettings[card.id] || {};
        const isMusic = card.type === 'music-ceremony' || card.type === 'music-soiree';
        const flipped = flippedCardId === card.id;
        return (
          <motion.div
            layout
            key={card.id}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(cardIndex * 0.035, 0.25) }}
            style={{ width: SPREAD_W, height: SPREAD_H, position: 'relative', flex: '0 0 auto', perspective: '1200px' }}
          >
            <div
              onClick={() => { if (!isMusic) onFlip(flipped ? null : card.id); }}
              style={{
                width: CARD_W, height: CARD_H, transform: `scale(${SPREAD_SCALE})`, transformOrigin: 'top left',
                cursor: isMusic ? 'default' : 'pointer', borderRadius: '24px',
                boxShadow: '0px 20px 28px rgba(0,0,0,0.16),0px 4px 10px rgba(0,0,0,0.1)',
              }}
            >
              <CardShell
                card={card}
                settings={settings}
                cardIndex={cardIndex}
                flipped={flipped}
                showConfigureHint
                playing={playingTrackId === card.id}
                onTogglePlay={onTogglePlay}
                onChange={onCardSettingChange}
                onClose={() => onFlip(null)}
                globalTexture={globalTexture}
              />
            </div>
          </motion.div>
        );
      })}
    </motion.div>
  );
};

const CardShell: React.FC<{
  card: WeddingCard;
  settings: Record<string, any>;
  cardIndex: number;
  flipped: boolean;
  showConfigureHint: boolean;
  playing: boolean;
  onTogglePlay: (cardId: string) => void;
  onChange: (cardId: string, key: string, value: unknown) => void;
  onClose: () => void;
  globalTexture?: string;
}> = ({ card, settings, cardIndex, flipped, showConfigureHint, playing, onTogglePlay, onChange, onClose, globalTexture }) => {
  const isMusic = card.type === 'music-ceremony' || card.type === 'music-soiree';
  return (
    <motion.div
      animate={{ rotateY: flipped ? 180 : 0 }}
      transition={{ type: 'spring', stiffness: 260, damping: 32 }}
      style={{ transformStyle: 'preserve-3d', width: '100%', height: '100%', position: 'relative' }}
    >
      <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden', borderRadius: '24px', overflow: 'hidden' }}>
        {isMusic ? (
          <MusicFront
            card={card}
            isPlaying={playing}
            onTogglePlay={(e) => { e.stopPropagation(); onTogglePlay(card.id); }}
            settings={settings}
          />
        ) : (
          <CardFront card={card} settings={settings} showConfigureHint={showConfigureHint} flipped={flipped} cardIndex={cardIndex} />
        )}
      </div>

      <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden', transform: 'rotateY(180deg)', borderRadius: '24px', overflow: 'hidden' }}>
        <CardBack
          card={card}
          settings={settings}
          onChange={(key, value) => onChange(card.id, key, value)}
          onClose={onClose}
          globalTexture={globalTexture}
        />
      </div>
    </motion.div>
  );
};

// ── Card front ───────────────────────────────────────────────────────────────

const CardFront: React.FC<{
  card: WeddingCard;
  settings: Record<string, any>;
  showConfigureHint: boolean;
  flipped: boolean;
  cardIndex: number;
}> = ({ card, settings, showConfigureHint, flipped, cardIndex }) => {
  const CardIcon = ICON_MAP[card.icon] ?? ICON_MAP['Sparkles'];
  const statusColor = STATUS_DOT_COLOR[settings.status || 'todo'];
  const fallbackImage = CARD_TYPE_IMAGES[card.type] || 'https://images.unsplash.com/photo-1519741497674-611481863552?w=900&q=85';
  const frontMediaUrl = settings.frontMediaUrl || '';
  const frontMediaType = settings.frontMediaType || (frontMediaUrl ? 'image' : '');
  const frontTexture = settings.frontTexture || '';
  const textureStyle = TEXTURE_OVERLAYS[frontTexture] || {};
  const radius = settings.frontRadius ?? 24;
  const frontOpacity = settings.frontOpacity ?? 1;
  const frontBlur = settings.frontBlur ?? 0;
  const frontOverlay = settings.frontOverlay || 'transparent';
  const borderWidth = settings.frontBorderWidth ?? 0;
  const borderColor = settings.frontBorderColor || 'rgba(255,255,255,.25)';
  const shadow = settings.frontShadow ?? 0;
  const textColor = settings.frontColor || '#fff';
  const fontFamily = settings.frontFontFamily || 'Inter, sans-serif';

  return (
    <div style={{
      width: '100%', height: '100%', borderRadius: radius, overflow: 'hidden', position: 'relative',
      background: settings.frontBackground || card.gradient || '#171526',
      border: borderWidth ? `${borderWidth}px solid ${borderColor}` : undefined,
      boxSizing: 'border-box',
      boxShadow: shadow ? `0 12px ${shadow}px rgba(0,0,0,.28)` : undefined,
    }}>
      <div style={{ position: 'absolute', inset: 0, opacity: frontOpacity, filter: frontBlur ? `blur(${frontBlur}px) scale(1.03)` : undefined }}>
        {frontMediaUrl ? (
          frontMediaType === 'video' ? (
            <video
              src={frontMediaUrl}
              autoPlay
              muted={settings.frontMediaMuted !== false}
              loop={settings.frontMediaLoop !== false}
              playsInline
              onLoadedMetadata={(e) => { e.currentTarget.playbackRate = settings.frontMediaRate || 1; }}
              style={{ width: '100%', height: '100%', objectFit: settings.frontMediaFit || 'cover', display: 'block' }}
            />
          ) : (
            <ImageWithFallback src={frontMediaUrl} alt={card.name} style={{ width: '100%', height: '100%', objectFit: settings.frontMediaFit || 'cover', display: 'block' }} />
          )
        ) : (
          <ImageWithFallback src={card.image || fallbackImage} alt={card.name} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
        )}
      </div>

      {frontTexture && <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', ...textureStyle }} />}
      {frontOverlay !== 'transparent' && <div style={{ position: 'absolute', inset: 0, background: frontOverlay, pointerEvents: 'none' }} />}
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(0,0,0,0.12) 0%,rgba(0,0,0,0) 30%,rgba(0,0,0,0.55) 70%,rgba(0,0,0,0.82) 100%)', borderRadius: radius }} />

      {settings.status && settings.status !== 'todo' && (
        <div style={{ position: 'absolute', top: '13px', left: '13px', width: '8px', height: '8px', borderRadius: '50%', background: statusColor, zIndex: 3, boxShadow: `0 0 8px ${statusColor}88` }} />
      )}

      <div style={{ position: 'absolute', top: '16px', left: '28px', right: '14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', fontWeight: 600, color: 'rgba(255,255,255,0.45)', letterSpacing: '0.04em' }}>
          {String(cardIndex + 1).padStart(2, '0')}
        </span>

        {showConfigureHint && !flipped && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', borderRadius: '50px', padding: '4px 9px' }}>
            <RotateCcw size={9} color="rgba(255,255,255,0.7)" />
            <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(255,255,255,0.7)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Configurer</span>
          </div>
        )}
      </div>

      <div style={{ position: 'absolute', bottom: '20px', left: '20px', right: '20px' }}>
        {settings.time && (
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', background: 'rgba(255,255,255,0.13)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', borderRadius: '50px', padding: '5px 11px', marginBottom: '10px' }}>
            <CardIcon size={10} color="rgba(255,255,255,0.8)" />
            <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.85)', letterSpacing: '0.02em' }}>{settings.time}</span>
            {settings.lieu && (
              <><span style={{ color: 'rgba(255,255,255,0.3)', fontSize: '9px' }}>·</span><span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.65)', maxWidth: '90px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{settings.lieu}</span></>
            )}
          </div>
        )}

        {!settings.time && <div style={{ marginBottom: '8px', display: 'flex', alignItems: 'center' }}><CardIcon size={13} color="rgba(255,255,255,0.4)" /></div>}

        <p style={{ fontFamily, fontSize: '22px', fontWeight: 800, color: textColor, textTransform: 'uppercase', letterSpacing: '-0.01em', lineHeight: 1.05, margin: 0 }}>
          {card.name}
        </p>
        <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '13px', fontStyle: 'italic', fontWeight: 300, color: 'rgba(255,255,255,0.65)', margin: '5px 0 0', letterSpacing: '0.01em' }}>
          {card.subtitle}
        </p>
      </div>
    </div>
  );
};
