import React, { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Check, Grid2X2, Sparkles, Wand2, X } from 'lucide-react';
import type { ProjectUniverse, StudioFolder } from '../utils/projectStore';
import { AimeRainbowMark } from './AimeRainbowMark';

export type ProjectStartMode = 'guided' | 'template' | 'blank';

export interface ProjectCreationInput {
  name: string;
  universe: ProjectUniverse;
  folderId?: string;
  startMode: ProjectStartMode;
}

interface ProjectCreationDialogProps {
  open: boolean;
  initialUniverse: ProjectUniverse | null;
  folders: StudioFolder[];
  defaultFolderId?: string;
  isDark: boolean;
  onClose: () => void;
  onCreate: (input: ProjectCreationInput) => void | Promise<void>;
}

const UNIVERSE_OPTIONS: Array<{ id: ProjectUniverse; label: string; description: string }> = [
  { id: 'mariage', label: 'Mariage', description: 'Organisation, invités, budget, timeline, mini-site et Jour J.' },
  { id: 'site', label: 'Mini-site', description: 'Présence web responsive composée à partir de contenus reliés.' },
  { id: 'prestataire', label: 'Profil', description: 'Activité, médias, offres, disponibilités et demandes.' },
  { id: 'evenement', label: 'Événement', description: 'Programme, équipe, public, publication et mode live.' },
  { id: 'portfolio', label: 'Portfolio', description: 'Projets, récit, médias, références et prises de contact.' },
  { id: 'association', label: 'Association', description: 'Membres, missions, ressources, agenda et registre.' },
  { id: 'libre', label: 'Point Zéro', description: 'Canevas libre pour importer, auditer ou inventer un format.' },
];

const START_MODES: Array<{ id: ProjectStartMode; title: string; description: string; icon: React.ReactNode }> = [
  { id: 'guided', title: 'Guidé par AIME', description: 'Le studio vous conduit dans l’ordre et signale ce qui manque.', icon: <Sparkles size={16} /> },
  { id: 'template', title: 'Modèle essentiel', description: 'Une structure minimale est préparée selon le type de projet.', icon: <Wand2 size={16} /> },
  { id: 'blank', title: 'Canevas vide', description: 'Vous partez d’un espace propre et composez librement.', icon: <Grid2X2 size={16} /> },
];

function defaultName(universe: ProjectUniverse) {
  if (universe === 'mariage') return 'Nouveau mariage';
  const label = UNIVERSE_OPTIONS.find((item) => item.id === universe)?.label || 'projet';
  return `Nouveau ${label.toLocaleLowerCase('fr')}`;
}

export const ProjectCreationDialog: React.FC<ProjectCreationDialogProps> = ({
  open,
  initialUniverse,
  folders,
  defaultFolderId,
  isDark,
  onClose,
  onCreate,
}) => {
  const [universe, setUniverse] = useState<ProjectUniverse>(initialUniverse || 'mariage');
  const [name, setName] = useState(defaultName(initialUniverse || 'mariage'));
  const [folderId, setFolderId] = useState(defaultFolderId || '');
  const [startMode, setStartMode] = useState<ProjectStartMode>('guided');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    const nextUniverse = initialUniverse || 'mariage';
    setUniverse(nextUniverse);
    setName(defaultName(nextUniverse));
    setFolderId(defaultFolderId || '');
    setStartMode('guided');
    setSubmitting(false);
    setError('');
  }, [defaultFolderId, initialUniverse, open]);

  useEffect(() => {
    if (!open) return;
    setName((current) => {
      const knownDefaults = UNIVERSE_OPTIONS.map((item) => defaultName(item.id));
      return !current.trim() || knownDefaults.includes(current) ? defaultName(universe) : current;
    });
  }, [open, universe]);

  const selectedUniverse = useMemo(() => UNIVERSE_OPTIONS.find((item) => item.id === universe) || UNIVERSE_OPTIONS[0], [universe]);

  if (!open) return null;

  const bg = isDark ? '#1C1C1E' : '#FAFAFA';
  const surface = isDark ? '#242426' : '#FFFFFF';
  const surface2 = isDark ? '#2C2C2E' : '#F1F1F2';
  const border = isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.10)';
  const text = isDark ? '#F5F5F5' : '#121213';
  const muted = isDark ? 'rgba(245,245,245,.52)' : 'rgba(18,18,19,.52)';
  const selected = isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.065)';

  const submit = async () => {
    if (submitting) return;
    const cleanName = name.trim();
    if (!cleanName) {
      setError('Donnez un nom au projet avant de continuer.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await onCreate({ name: cleanName, universe, folderId: folderId || undefined, startMode });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'La création du projet a échoué.');
      setSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-creation-title"
      onMouseDown={(event) => { if (event.target === event.currentTarget && !submitting) onClose(); }}
      style={{ position: 'fixed', inset: 0, zIndex: 1500, background: 'rgba(8,8,9,.72)', backdropFilter: 'blur(12px)', display: 'grid', placeItems: 'center', padding: 20 }}
    >
      <section style={{ width: 'min(760px, 100%)', maxHeight: 'min(790px, calc(100vh - 40px))', overflowY: 'auto', borderRadius: 18, border: `1px solid ${border}`, background: bg, color: text, boxShadow: '0 36px 100px rgba(0,0,0,.5)' }}>
        <header style={{ position: 'sticky', top: 0, zIndex: 2, minHeight: 72, padding: '18px 20px', boxSizing: 'border-box', display: 'flex', alignItems: 'flex-start', gap: 14, background: bg, borderBottom: `1px solid ${border}` }}>
          <AimeRainbowMark size={38} />
          <div style={{ minWidth: 0 }}>
            <h2 id="project-creation-title" style={{ margin: 0, fontSize: 18, letterSpacing: '-.025em' }}>Créer un projet</h2>
            <p style={{ margin: '5px 0 0', color: muted, fontSize: 10.5 }}>Choisissez d’abord ce que vous créez. Rien n’est enregistré avant validation.</p>
          </div>
          <button disabled={submitting} onClick={onClose} aria-label="Fermer" style={{ marginLeft: 'auto', width: 34, height: 34, borderRadius: 9, border: `1px solid ${border}`, background: surface, color: text, cursor: submitting ? 'not-allowed' : 'pointer', display: 'grid', placeItems: 'center' }}><X size={16} /></button>
        </header>

        <div style={{ padding: 20, display: 'grid', gap: 22 }}>
          <div>
            <div style={sectionLabel(muted)}>1 · Type de projet</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 8 }}>
              {UNIVERSE_OPTIONS.map((item) => {
                const active = item.id === universe;
                return <button key={item.id} onClick={() => setUniverse(item.id)} style={{ minHeight: 78, padding: '12px 13px', borderRadius: 12, border: `1px solid ${active ? (isDark ? 'rgba(255,255,255,.28)' : 'rgba(0,0,0,.26)') : border}`, background: active ? selected : surface, color: text, cursor: 'pointer', textAlign: 'left', display: 'flex', gap: 10 }}><span style={{ width: 20, paddingTop: 1 }}>{active ? <Check size={15} /> : <span style={{ display: 'block', width: 13, height: 13, borderRadius: 4, border: `1px solid ${border}` }} />}</span><span><strong style={{ display: 'block', fontSize: 11.5 }}>{item.label}</strong><span style={{ display: 'block', marginTop: 5, color: muted, fontSize: 9, lineHeight: 1.4 }}>{item.description}</span></span></button>;
              })}
            </div>
          </div>

          <div>
            <div style={sectionLabel(muted)}>2 · Identité</div>
            <label style={{ display: 'grid', gap: 7, fontSize: 10, color: muted }}>
              Nom du projet
              <input autoFocus value={name} onChange={(event) => setName(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') void submit(); }} placeholder={defaultName(universe)} style={{ width: '100%', height: 44, borderRadius: 11, border: `1px solid ${border}`, background: surface, color: text, padding: '0 13px', boxSizing: 'border-box', outline: 'none', fontSize: 13 }} />
            </label>
            {!!folders.length && <label style={{ display: 'grid', gap: 7, marginTop: 12, fontSize: 10, color: muted }}>Dossier <select value={folderId} onChange={(event) => setFolderId(event.target.value)} style={{ width: '100%', height: 42, borderRadius: 11, border: `1px solid ${border}`, background: surface, color: text, padding: '0 12px', outline: 'none' }}><option value="">Sans dossier</option>{folders.map((folder) => <option key={folder.id} value={folder.id}>{folder.name}</option>)}</select></label>}
          </div>

          <div>
            <div style={sectionLabel(muted)}>3 · Point de départ</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 8 }}>
              {START_MODES.map((mode) => {
                const active = mode.id === startMode;
                return <button key={mode.id} onClick={() => setStartMode(mode.id)} style={{ minHeight: 112, padding: 13, borderRadius: 12, border: `1px solid ${active ? (isDark ? 'rgba(255,255,255,.28)' : 'rgba(0,0,0,.26)') : border}`, background: active ? selected : surface, color: text, cursor: 'pointer', textAlign: 'left' }}><span style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><span style={{ width: 30, height: 30, borderRadius: 9, display: 'grid', placeItems: 'center', background: surface2 }}>{mode.icon}</span>{active && <Check size={15} />}</span><strong style={{ display: 'block', marginTop: 12, fontSize: 11 }}>{mode.title}</strong><span style={{ display: 'block', marginTop: 6, color: muted, fontSize: 8.8, lineHeight: 1.4 }}>{mode.description}</span></button>;
              })}
            </div>
          </div>

          <div style={{ borderRadius: 13, border: `1px solid ${border}`, background: surface, padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, minWidth: 0 }}><strong style={{ display: 'block', fontSize: 11.5 }}>{selectedUniverse.label} · {START_MODES.find((item) => item.id === startMode)?.title}</strong><span style={{ display: 'block', marginTop: 5, color: muted, fontSize: 9.2 }}>Le projet sera créé une seule fois, puis ouvert dans son espace dédié.</span></div>
            <button disabled={submitting || !name.trim()} onClick={() => void submit()} style={{ minWidth: 185, height: 42, borderRadius: 11, border: `1px solid ${border}`, background: isDark ? '#F2F2F2' : '#151516', color: isDark ? '#111' : '#FFF', cursor: submitting || !name.trim() ? 'not-allowed' : 'pointer', opacity: submitting || !name.trim() ? .55 : 1, fontWeight: 760, fontSize: 10.5, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>{submitting ? 'Création…' : 'Créer et ouvrir'} {!submitting && <ArrowRight size={14} />}</button>
          </div>

          {error && <div role="alert" style={{ borderRadius: 10, border: '1px solid rgba(248,113,113,.28)', background: 'rgba(248,113,113,.08)', color: isDark ? '#FCA5A5' : '#B42318', padding: '10px 12px', fontSize: 10 }}>{error}</div>}
        </div>
      </section>
    </div>
  );
};

const sectionLabel = (color: string): React.CSSProperties => ({ marginBottom: 9, color, fontSize: 8.5, fontWeight: 800, letterSpacing: '.11em', textTransform: 'uppercase' });
