import React, { useRef } from 'react';
import { Eye, GripHorizontal, LayoutTemplate, Lock, MoreHorizontal, Trash2, Unlock } from 'lucide-react';
import type { CanvasPoint, RemixTarget, Tool } from '../types';

interface CanvasObjectFrameProps {
  id: string;
  label: string;
  targetKind?: RemixTarget['kind'];
  position: CanvasPoint;
  width: number;
  height: number;
  canvasScale: number;
  activeTool: Tool;
  selected: boolean;
  locked: boolean;
  zIndex?: number;
  snapEnabled?: boolean;
  gridSize?: number;
  onSelect: () => void;
  onPositionChange: (position: CanvasPoint) => void;
  onDelete: () => void;
  onDuplicate?: () => void;
  onToggleLock: () => void;
  onPreview?: () => void;
  onCompose?: () => void;
  onOpenMenu?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  children: React.ReactNode;
}

const snap = (value: number, enabled: boolean, grid: number) => enabled ? Math.round(value / grid) * grid : value;

export const CanvasObjectFrame: React.FC<CanvasObjectFrameProps> = ({
  id,
  label,
  targetKind = 'entry',
  position,
  width,
  height,
  canvasScale,
  activeTool,
  selected,
  locked,
  zIndex = 50,
  snapEnabled = true,
  gridSize = 28,
  onSelect,
  onPositionChange,
  onDelete,
  onToggleLock,
  onPreview,
  onCompose,
  onOpenMenu,
  children,
}) => {
  const dragRef = useRef<{
    pointerId: number;
    clientX: number;
    clientY: number;
    origin: CanvasPoint;
  } | null>(null);

  const target: RemixTarget = { kind: targetKind, id, label } as RemixTarget;
  const preview = onPreview || (() => window.dispatchEvent(new CustomEvent('lma-card-preview', { detail: { target, mode: 'card' } })));
  const compose = onCompose || (() => window.dispatchEvent(new CustomEvent('lma-card-compose', { detail: { target } })));

  const startDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    event.stopPropagation();
    onSelect();
    if (locked || activeTool !== 'select') return;
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      pointerId: event.pointerId,
      clientX: event.clientX,
      clientY: event.clientY,
      origin: position,
    };
  };

  const moveDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const scale = Math.max(0.12, canvasScale || 1);
    onPositionChange({
      x: snap(drag.origin.x + (event.clientX - drag.clientX) / scale, snapEnabled, gridSize),
      y: snap(drag.origin.y + (event.clientY - drag.clientY) / scale, snapEnabled, gridSize),
    });
  };

  const endDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (dragRef.current?.pointerId !== event.pointerId) return;
    dragRef.current = null;
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch { /* noop */ }
  };

  const stopControlPointer = (event: React.PointerEvent) => {
    event.stopPropagation();
  };

  return (
    <div
      data-canvas-object
      onClick={(event) => { event.stopPropagation(); onSelect(); }}
      style={{
        position: 'absolute',
        left: position.x,
        top: position.y,
        width,
        height,
        zIndex,
        outline: selected ? '2px solid #D4D4D8' : '1px solid transparent',
        outlineOffset: 5,
        borderRadius: 24,
        transition: dragRef.current ? 'none' : 'left .16s ease, top .16s ease, outline-color .15s ease',
      }}
    >
      {activeTool === 'select' && (
        <div
          onPointerDown={startDrag}
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          title={locked ? `${label} est verrouillé` : `Déplacer ${label}`}
          style={{
            position: 'absolute', top: -30, left: '50%', transform: 'translateX(-50%)', height: 22, minWidth: 56,
            padding: '0 9px', borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
            background: selected ? '#1B1B1D' : 'rgba(23,21,32,.72)', color: '#fff', fontFamily: 'Inter, sans-serif',
            fontSize: 8, fontWeight: 700, letterSpacing: '.04em', cursor: locked ? 'not-allowed' : 'grab', touchAction: 'none',
            boxShadow: '0 7px 20px rgba(0,0,0,.22)', opacity: selected ? 1 : .56, whiteSpace: 'nowrap',
          }}
        >
          <GripHorizontal size={12} />{selected ? label : ''}
        </div>
      )}

      {children}

      {selected && (
        <div
          onPointerDown={stopControlPointer}
          style={{ position: 'absolute', top: -38, right: 0, display: 'flex', alignItems: 'center', gap: 2, padding: 5, borderRadius: 11, background: '#1B1B1D', color: '#fff', boxShadow: '0 10px 28px rgba(0,0,0,.3)' }}
        >
          <Control title="Aperçu vivant" onClick={preview}><Eye size={12} /></Control>
          <Control title="Mise en page" onClick={compose}><LayoutTemplate size={12} /></Control>
          {onOpenMenu && <button type="button" title="Remix, éditer, relier, publier et gérer" onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onOpenMenu(event); }} style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', display: 'grid', placeItems: 'center', cursor: 'pointer' }}><MoreHorizontal size={14} /></button>}
          <Control title={locked ? 'Déverrouiller' : 'Verrouiller'} onClick={onToggleLock}>{locked ? <Unlock size={12} /> : <Lock size={12} />}</Control>
          <Control title="Supprimer du canevas" onClick={onDelete}><Trash2 size={12} /></Control>
        </div>
      )}
    </div>
  );
};

const Control: React.FC<{ title: string; onClick: () => void; children: React.ReactNode }> = ({ title, onClick, children }) => (
  <button type="button" title={title} onPointerDown={(event) => { event.stopPropagation(); }} onClick={(event) => { event.stopPropagation(); onClick(); }} style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>{children}</button>
);
