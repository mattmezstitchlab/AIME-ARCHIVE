import React, { useState } from 'react';
import { Command } from 'cmdk';
import { motion, AnimatePresence } from 'motion/react';
import {
  CalendarArrowDown,
  QrCode,
  Euro,
  ClipboardList,
  Monitor,
  Search,
} from 'lucide-react';
import { WeddingLot } from '../types';
import { ICON_MAP } from '../utils/iconMap';

interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  onNavigateLot: (lot: WeddingLot) => void;
  onAction: (action: string) => void;
}

interface CommandItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  shortcut?: string;
  onSelect: () => void;
}

export default function CommandPalette({
  open,
  onClose,
  lots,
  onNavigateLot,
  onAction,
}: CommandPaletteProps) {

  const actionItems: CommandItem[] = [
    {
      id: 'export-ics',
      label: 'Exporter ICS',
      icon: <CalendarArrowDown size={16} />,
      onSelect: () => { onAction('export-ics'); onClose(); },
    },
    {
      id: 'qr-code',
      label: 'Générer QR Code',
      icon: <QrCode size={16} />,
      onSelect: () => { onAction('qr-code'); onClose(); },
    },
    {
      id: 'budget',
      label: 'Voir Budget',
      icon: <Euro size={16} />,
      onSelect: () => { onAction('budget'); onClose(); },
    },
    {
      id: 'checklist',
      label: 'Liste de contrôle IA',
      icon: <ClipboardList size={16} />,
      onSelect: () => { onAction('checklist'); onClose(); },
    },
    {
      id: 'kiosk',
      label: 'Mode Kiosque',
      icon: <Monitor size={16} />,
      onSelect: () => { onAction('kiosk'); onClose(); },
    },
  ];

  return (
    <AnimatePresence>
      {open && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh]"
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
        >
          <motion.div
            className="fixed inset-0"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15, ease: 'easeOut' }}
            style={{ width: 640, position: 'relative', zIndex: 1 }}
          >
            <Command
              className="rounded-2xl overflow-hidden shadow-2xl"
              style={{
                background: 'rgba(24,24,26,0.985)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
              onKeyDown={(e) => { if (e.key === 'Escape') onClose(); }}
              loop
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  padding: '14px 16px',
                  borderBottom: '1px solid rgba(255,255,255,0.06)',
                }}
              >
                <Search size={16} color="rgba(255,255,255,0.4)" />
                <Command.Input
                  placeholder="Rechercher une action, un outil ou un lot…"
                  style={{
                    flex: 1,
                    background: 'transparent',
                    border: 'none',
                    outline: 'none',
                    color: 'white',
                    fontSize: 15,
                  }}
                  className="placeholder:text-white/30"
                />
                <kbd
                  style={{
                    padding: '2px 6px',
                    borderRadius: 5,
                    background: 'rgba(255,255,255,0.08)',
                    color: 'rgba(255,255,255,0.4)',
                    fontSize: 11,
                    fontFamily: 'inherit',
                  }}
                >
                  ESC
                </kbd>
              </div>

              <Command.List style={{ maxHeight: 440, overflowY: 'auto', padding: '6px 0' }}>
                <Command.Empty
                  style={{
                    padding: '32px 16px',
                    textAlign: 'center',
                    color: 'rgba(255,255,255,0.3)',
                    fontSize: 14,
                  }}
                >
                  Aucun résultat.
                </Command.Empty>

                <CommandGroup heading="Actions" items={actionItems} />

                {lots.length > 0 && (
                  <Command.Group>
                    <GroupHeading label="Lots" />
                    {lots.map((lot) => {
                      const Icon = ICON_MAP[lot.icon];
                      return (
                        <CommandItemRow
                          key={lot.id}
                          value={`lot-${lot.id}-${lot.title}`}
                          label={lot.title}
                          icon={Icon ? <Icon size={16} /> : null}
                          accentColor={lot.accentColor}
                          onSelect={() => { onNavigateLot(lot); onClose(); }}
                        />
                      );
                    })}
                  </Command.Group>
                )}
              </Command.List>
            </Command>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

function GroupHeading({ label }: { label: string }) {
  return (
    <div
      style={{
        padding: '8px 16px 4px',
        fontSize: 11,
        fontWeight: 600,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        color: 'rgba(255,255,255,0.25)',
      }}
    >
      {label}
    </div>
  );
}

function CommandGroup({ heading, items }: { heading: string; items: CommandItem[] }) {
  return (
    <Command.Group>
      <GroupHeading label={heading} />
      {items.map((item) => (
        <Command.Item
          key={item.id}
          value={`${heading}-${item.id}-${item.label}`}
          onSelect={item.onSelect}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            padding: '8px 16px',
            cursor: 'pointer',
            color: 'rgba(255,255,255,0.85)',
            fontSize: 14,
            borderRadius: 6,
            margin: '1px 6px',
          }}
          className="data-[selected=true]:bg-white/[0.06] data-[selected=true]:text-white"
        >
          <span style={{ color: 'rgba(255,255,255,0.45)', flexShrink: 0 }}>{item.icon}</span>
          <span style={{ flex: 1 }}>{item.label}</span>
          {item.shortcut && (
            <kbd
              style={{
                padding: '2px 6px',
                borderRadius: 5,
                background: 'rgba(255,255,255,0.06)',
                color: 'rgba(255,255,255,0.3)',
                fontSize: 11,
                fontFamily: 'inherit',
              }}
            >
              {item.shortcut}
            </kbd>
          )}
        </Command.Item>
      ))}
    </Command.Group>
  );
}

function CommandItemRow({
  value,
  label,
  icon,
  accentColor,
  onSelect,
}: {
  value: string;
  label: string;
  icon: React.ReactNode;
  accentColor: string;
  onSelect: () => void;
}) {
  return (
    <Command.Item
      value={value}
      onSelect={onSelect}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 16px',
        cursor: 'pointer',
        color: 'rgba(255,255,255,0.85)',
        fontSize: 14,
        borderRadius: 6,
        margin: '1px 6px',
      }}
      className="data-[selected=true]:bg-white/[0.06] data-[selected=true]:text-white"
    >
      <span style={{ color: accentColor, flexShrink: 0 }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
    </Command.Item>
  );
}
