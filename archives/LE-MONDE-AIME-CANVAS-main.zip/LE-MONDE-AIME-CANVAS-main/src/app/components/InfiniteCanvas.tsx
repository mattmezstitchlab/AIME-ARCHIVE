import React, { useRef, useCallback, useEffect, useState } from 'react';
import type { CanvasTransform, BgSettings, Tool } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { getProjectItem, setProjectItem } from '../utils/projectStore';
import { ChromaticWheelPanel } from './ChromaticWheelPanel';
import { PointZeroMarker } from './PointZeroMarker';
import { PointZeroPanel } from './PointZeroPanel';
import type { PointZeroImportReport, PointZeroState } from './PointZeroPanel';
import { PointZeroArtifactCard } from './PointZeroArtifactCard';
import type { PointZeroArtifact } from './PointZeroArtifactCard';

interface InfiniteCanvasProps {
  transform: CanvasTransform;
  onTransformChange: (t: CanvasTransform) => void;
  activeTool: Tool;
  bgSettings: BgSettings;
  children: React.ReactNode;
  onCanvasClick?: (point: { x: number; y: number }) => void;
}

const MIN_SCALE = 0.12;
const MAX_SCALE = 3;
const ZOOM_SPEED = 0.0008;
const LEGACY_BLUE_CANVAS = 'linear-gradient(135deg,#1A1A2E,#16213E,#0F3460)';
const NEUTRAL_CANVAS = { dark: '#242426', light: '#E8E8EA' } as const;

type SelectionContext = { kind: 'element'; label: string; background: string } | null;

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = getProjectItem(key);
    return raw ? { ...fallback as any, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
}

export const InfiniteCanvas: React.FC<InfiniteCanvasProps> = ({
  transform,
  onTransformChange,
  activeTool,
  bgSettings,
  children,
  onCanvasClick,
}) => {
  const { isDark } = useTheme();
  const containerRef = useRef<HTMLDivElement>(null);
  const isPanning = useRef(false);
  const didPan = useRef(false);
  const lastMouse = useRef({ x: 0, y: 0 });
  const transformRef = useRef(transform);
  transformRef.current = transform;

  const [chromaticOpen, setChromaticOpen] = useState(false);
  const [pointZeroOpen, setPointZeroOpen] = useState(false);
  const [selectionContext, setSelectionContext] = useState<SelectionContext>(null);
  const [pointZero, setPointZero] = useState<PointZeroState>(() => readJson('lma_point_zero', { x: 0, y: 0, visible: true, locked: false }));
  const [artifacts, setArtifacts] = useState<PointZeroArtifact[]>(() => {
    try { return JSON.parse(getProjectItem('lma_point_zero_artifacts') || '[]'); } catch { return []; }
  });
  const [imports, setImports] = useState<PointZeroImportReport[]>(() => {
    try { return JSON.parse(getProjectItem('lma_point_zero_imports') || '[]'); } catch { return []; }
  });
  const [ambienceOverride, setAmbienceOverride] = useState<BgSettings | null>(() => {
    try { return JSON.parse(getProjectItem('lma_canvas_ambience_override') || 'null'); } catch { return null; }
  });

  useEffect(() => { setProjectItem('lma_point_zero', JSON.stringify(pointZero)); }, [pointZero]);
  useEffect(() => { setProjectItem('lma_point_zero_artifacts', JSON.stringify(artifacts.slice(-80))); }, [artifacts]);
  useEffect(() => { setProjectItem('lma_point_zero_imports', JSON.stringify(imports.slice(-40))); }, [imports]);
  useEffect(() => { setProjectItem('lma_canvas_ambience_override', JSON.stringify(ambienceOverride)); }, [ambienceOverride]);

  useEffect(() => {
    const reset = () => setAmbienceOverride(null);
    window.addEventListener('lma-canvas-neutralize', reset);
    return () => window.removeEventListener('lma-canvas-neutralize', reset);
  }, []);

  useEffect(() => {
    const onPointZero = (event: Event) => {
      const detail = (event as CustomEvent<{ open?: boolean }>).detail;
      setPointZeroOpen((current) => detail?.open ?? !current);
      setChromaticOpen(false);
    };
    const onChromatic = (event: Event) => {
      const detail = (event as CustomEvent<{ open?: boolean }>).detail;
      setChromaticOpen((current) => detail?.open ?? !current);
      setPointZeroOpen(false);
    };
    const onSelection = (event: Event) => {
      const detail = (event as CustomEvent<SelectionContext>).detail;
      setSelectionContext(detail || null);
    };
    window.addEventListener('lma-point-zero-toggle', onPointZero as EventListener);
    window.addEventListener('lma-chromatic-toggle', onChromatic as EventListener);
    window.addEventListener('lma-canvas-selection', onSelection as EventListener);
    return () => {
      window.removeEventListener('lma-point-zero-toggle', onPointZero as EventListener);
      window.removeEventListener('lma-chromatic-toggle', onChromatic as EventListener);
      window.removeEventListener('lma-canvas-selection', onSelection as EventListener);
    };
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('lma-point-zero-state', { detail: { open: pointZeroOpen } }));
  }, [pointZeroOpen]);
  useEffect(() => {
    window.dispatchEvent(new CustomEvent('lma-chromatic-state', { detail: { open: chromaticOpen } }));
  }, [chromaticOpen]);

  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    const rect = containerRef.current!.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const t = transformRef.current;
    const rawDelta = e.deltaMode === 1 ? e.deltaY * 20 : e.deltaY;
    const factor = Math.pow(2, -rawDelta * ZOOM_SPEED);
    const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, t.scale * factor));
    const ratio = newScale / t.scale;
    onTransformChange({
      x: mx - (mx - t.x) * ratio,
      y: my - (my - t.y) * ratio,
      scale: newScale,
    });
  }, [onTransformChange]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (activeTool !== 'hand' && activeTool !== 'select') return;
    const target = e.target as HTMLElement;
    if (target.closest('[data-canvas-object]')) return;
    isPanning.current = true;
    didPan.current = false;
    lastMouse.current = { x: e.clientX, y: e.clientY };
    e.preventDefault();
  }, [activeTool]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isPanning.current) return;
    const dx = e.clientX - lastMouse.current.x;
    const dy = e.clientY - lastMouse.current.y;
    if (Math.abs(dx) + Math.abs(dy) > 2) didPan.current = true;
    lastMouse.current = { x: e.clientX, y: e.clientY };
    const t = transformRef.current;
    onTransformChange({ ...t, x: t.x + dx, y: t.y + dy });
  }, [onTransformChange]);

  const stopPan = useCallback(() => { isPanning.current = false; }, []);

  const handleClick = useCallback((e: React.MouseEvent) => {
    if (didPan.current) { didPan.current = false; return; }
    const target = e.target as HTMLElement;
    if (!target.closest('[data-canvas-object]')) setSelectionContext(null);
    const rect = containerRef.current!.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const t = transformRef.current;

    if (activeTool === 'note' || activeTool === 'select') {
      onCanvasClick?.({ x: (mx - t.x) / t.scale, y: (my - t.y) / t.scale });
      if (activeTool === 'note') return;
    }

    if (activeTool !== 'zoom-in' && activeTool !== 'zoom-out') return;
    const factor = activeTool === 'zoom-in' ? 1.4 : 0.7;
    const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, t.scale * factor));
    const ratio = newScale / t.scale;
    onTransformChange({ x: mx - (mx - t.x) * ratio, y: my - (my - t.y) * ratio, scale: newScale });
  }, [activeTool, onCanvasClick, onTransformChange]);

  const touchRef = useRef<{ x: number; y: number; dist: number } | null>(null);
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      touchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, dist: 0 };
    } else if (e.touches.length === 2) {
      const dx = e.touches[1].clientX - e.touches[0].clientX;
      const dy = e.touches[1].clientY - e.touches[0].clientY;
      touchRef.current = {
        x: (e.touches[0].clientX + e.touches[1].clientX) / 2,
        y: (e.touches[0].clientY + e.touches[1].clientY) / 2,
        dist: Math.sqrt(dx * dx + dy * dy),
      };
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (!touchRef.current) return;
    const t = transformRef.current;
    if (e.touches.length === 1) {
      const dx = e.touches[0].clientX - touchRef.current.x;
      const dy = e.touches[0].clientY - touchRef.current.y;
      touchRef.current = { ...touchRef.current, x: e.touches[0].clientX, y: e.touches[0].clientY };
      onTransformChange({ ...t, x: t.x + dx, y: t.y + dy });
    } else if (e.touches.length === 2) {
      const dx = e.touches[1].clientX - e.touches[0].clientX;
      const dy = e.touches[1].clientY - e.touches[0].clientY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      const rect = containerRef.current!.getBoundingClientRect();
      const mx = cx - rect.left;
      const my = cy - rect.top;
      const factor = dist / (touchRef.current.dist || dist);
      const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, t.scale * factor));
      const ratio = newScale / t.scale;
      touchRef.current = { x: cx, y: cy, dist };
      onTransformChange({ x: mx - (mx - t.x) * ratio, y: my - (my - t.y) * ratio, scale: newScale });
    }
  }, [onTransformChange]);

  const cursor =
    activeTool === 'hand' || activeTool === 'select' ? (isPanning.current ? 'grabbing' : 'default')
    : activeTool === 'zoom-in' ? 'zoom-in'
    : activeTool === 'zoom-out' ? 'zoom-out'
    : 'default';

  const dotSpacing = 28 * transform.scale;
  const dotRadius = Math.max(0.6, transform.scale * 0.9);
  const ox = ((transform.x % dotSpacing) + dotSpacing) % dotSpacing;
  const oy = ((transform.y % dotSpacing) + dotSpacing) % dotSpacing;

  const neutral: BgSettings = { type: 'color', value: isDark ? NEUTRAL_CANVAS.dark : NEUTRAL_CANVAS.light };
  const sourceBg = !bgSettings.value || bgSettings.value === LEGACY_BLUE_CANVAS ? neutral : bgSettings;
  const effectiveBg = ambienceOverride || sourceBg;
  const bgCSS: React.CSSProperties = effectiveBg.type === 'color' ? { backgroundColor: effectiveBg.value } : effectiveBg.type === 'gradient' ? { background: effectiveBg.value } : {};
  const dotAlpha = effectiveBg.type === 'video' ? 0.28 : isDark ? 0.14 : 0.11;
  const dotColor = isDark ? '255,255,255' : '0,0,0';
  const seedColor = (selectionContext?.background || effectiveBg.value).match(/#[0-9a-fA-F]{6}/)?.[0] || '#A3A3A8';

  const addArtifact = (kind: PointZeroArtifact['kind'], title: string, body: string, accent: string) => {
    const index = artifacts.length;
    setArtifacts((previous) => [...previous, {
      id: `point-zero-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
      kind,
      title,
      body,
      accent,
      x: pointZero.x + 110 + (index % 4) * 28,
      y: pointZero.y + 90 + (index % 4) * 28,
      width: 620,
      height: 360,
      createdAt: new Date().toISOString(),
    }]);
  };

  return (
    <>
      <div
        ref={containerRef}
        style={{
          position: 'fixed',
          inset: 0,
          overflow: 'hidden',
          cursor,
          userSelect: 'none',
          transform: 'translateZ(0)',
          ...bgCSS,
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={stopPan}
        onMouseLeave={stopPan}
        onClick={handleClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={() => { touchRef.current = null; }}
      >
        {effectiveBg.type === 'image' && effectiveBg.value && (
          <img
            key={effectiveBg.value}
            src={effectiveBg.value}
            alt="Fond du canevas"
            style={{
              position: 'absolute', inset: 0, width: '100%', height: '100%',
              objectFit: effectiveBg.fit || 'cover', zIndex: 0,
              opacity: effectiveBg.opacity ?? 1,
              filter: effectiveBg.blur ? `blur(${effectiveBg.blur}px) scale(1.03)` : undefined,
            }}
          />
        )}
        {effectiveBg.type === 'video' && effectiveBg.value && (
          <video
            key={effectiveBg.value}
            autoPlay
            loop={effectiveBg.loop !== false}
            muted={effectiveBg.muted !== false}
            playsInline
            onLoadedMetadata={(e) => { e.currentTarget.playbackRate = effectiveBg.playbackRate || 1; }}
            style={{
              position: 'absolute', inset: 0, width: '100%', height: '100%',
              objectFit: effectiveBg.fit || 'cover', zIndex: 0,
              opacity: effectiveBg.opacity ?? 1,
              filter: effectiveBg.blur ? `blur(${effectiveBg.blur}px) scale(1.03)` : undefined,
            }}
          >
            <source src={effectiveBg.value} />
          </video>
        )}
        {(effectiveBg.type === 'image' || effectiveBg.type === 'video') && effectiveBg.overlay && effectiveBg.overlay !== 'transparent' && (
          <div style={{ position: 'absolute', inset: 0, zIndex: 0, background: effectiveBg.overlay, pointerEvents: 'none' }} />
        )}

        <div aria-hidden style={{ position: 'absolute', top: '-40px', left: '-40px', right: '-40px', bottom: '-40px', pointerEvents: 'none', zIndex: 1, overflow: 'hidden' }}>
          <div style={{
            position: 'absolute', inset: 0,
            backgroundImage: `radial-gradient(circle, rgba(${dotColor},${dotAlpha}) ${dotRadius}px, transparent ${dotRadius}px)`,
            backgroundSize: `${dotSpacing}px ${dotSpacing}px`,
            transform: `translate(${ox}px, ${oy}px)`,
            willChange: 'transform',
          }} />
        </div>

        <div style={{
          position: 'absolute', top: 0, left: 0, transformOrigin: '0 0',
          transform: `translate(${transform.x}px,${transform.y}px) scale(${transform.scale})`,
          willChange: 'transform', zIndex: 2, isolation: 'isolate',
        }}>
          <PointZeroMarker
            point={pointZero}
            visible={pointZero.visible}
            locked={pointZero.locked}
            canvasScale={transform.scale}
            activeTool={activeTool}
            onChange={(next) => setPointZero((current) => ({ ...current, ...next }))}
            onOpen={() => setPointZeroOpen(true)}
          />
          {artifacts.map((artifact) => (
            <PointZeroArtifactCard
              key={artifact.id}
              artifact={artifact}
              canvasScale={transform.scale}
              activeTool={activeTool}
              onChange={(id, patch) => setArtifacts((previous) => previous.map((item) => item.id === id ? { ...item, ...patch } : item))}
              onDelete={(id) => setArtifacts((previous) => previous.filter((item) => item.id !== id))}
            />
          ))}
          {children}
        </div>
      </div>

      <ChromaticWheelPanel
        open={chromaticOpen}
        seedColor={seedColor}
        targetLabel={selectionContext?.label}
        canApplySelection={Boolean(selectionContext)}
        onApply={(colors, scope) => {
          const background = colors.length === 1 ? colors[0] : `linear-gradient(135deg,${colors.join(',')})`;
          if (scope === 'canvas') {
            setAmbienceOverride({ type: colors.length === 1 ? 'color' : 'gradient', value: background });
          } else {
            window.dispatchEvent(new CustomEvent('lma-apply-selection-palette', { detail: { colors, background } }));
          }
        }}
        onClose={() => setChromaticOpen(false)}
      />

      <PointZeroPanel
        open={pointZeroOpen}
        pointZero={pointZero}
        onPointZeroChange={setPointZero}
        onCenter={() => {
          const current = transformRef.current;
          onTransformChange({ ...current, x: window.innerWidth / 2 - pointZero.x * current.scale, y: window.innerHeight / 2 - pointZero.y * current.scale });
        }}
        onReset={() => {
          setPointZero({ x: 0, y: 0, visible: true, locked: false });
          const current = transformRef.current;
          onTransformChange({ ...current, x: window.innerWidth / 2, y: window.innerHeight / 2 });
        }}
        onCreateBlank={() => {
          addArtifact('blank', 'Nouveau départ', 'Un plan libre créé depuis le Point Zéro. Décrivez votre intention à l’Agent pour générer les premières sections.', '#A3A3A8');
          setPointZeroOpen(false);
        }}
        onCreateAuditMission={(mission) => {
          addArtifact('audit', 'Mission · Audit accessibilité', `${mission.url}\n${mission.country} · ${mission.service}\n${mission.standard}\n\nÉtat : périmètre créé. Le scan distant et la validation humaine seront raccordés au moteur Audit & Proof.`, '#A3A3A8');
        }}
        onImportReport={(report) => {
          setImports((previous) => [report, ...previous.filter((item) => item.id !== report.id)].slice(0, 40));
          addArtifact('import', 'Import ZIP · Inventaire sûr', `${report.fileName}\n${report.framework} · ${report.fileCount} fichiers · ${report.codeCount} fichiers code · ${report.mediaCount} médias\n\n${report.sensitive.length ? `${report.sensitive.length} fichier(s) sensible(s) potentiel(s) à isoler.` : 'Aucun secret évident détecté dans les noms de fichiers.'}\nSource conservée intacte avant reconstruction.`, '#A3A3A8');
        }}
        onClose={() => setPointZeroOpen(false)}
      />
    </>
  );
};
