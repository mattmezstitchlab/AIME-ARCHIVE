import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  X, Music2, UserRoundPlus, Headphones, Plus, Search, Check, Ban,
  Trash2, Download, ThumbsUp, Link2, Copy, Users, Clock3,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export type PlaylistSuggestionStatus = 'pending' | 'approved' | 'rejected';

export interface PlaylistSuggestion {
  id: string;
  title: string;
  artist: string;
  contributor: string;
  role: string;
  moment: string;
  message: string;
  url: string;
  votes: number;
  status: PlaylistSuggestionStatus;
  createdAt: string;
}

interface CollaborativePlaylistPanelProps {
  suggestions: PlaylistSuggestion[];
  onChange: (items: PlaylistSuggestion[]) => void;
  onClose: () => void;
}

const MOMENTS = [
  'Accueil des invités', 'Cérémonie', 'Sortie des mariés', 'Cocktail',
  'Entrée en salle', 'Dîner', 'Ouverture de bal', 'Soirée dansante', 'Brunch', 'Peu importe',
];
const ROLES = ['Invité·e', 'Marié·e', 'Témoin', 'Famille', 'Prestataire', 'DJ / musicien'];

export const CollaborativePlaylistPanel: React.FC<CollaborativePlaylistPanelProps> = ({ suggestions, onChange, onClose }) => {
  const { isDark } = useTheme();
  const [tab, setTab] = useState<'guest' | 'dj'>('guest');
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | PlaylistSuggestionStatus>('all');
  const [form, setForm] = useState({
    title: '', artist: '', contributor: '', role: 'Invité·e', moment: 'Soirée dansante', message: '', url: '',
  });

  const surface = isDark ? '#1B1B1D' : '#FAFAFB';
  const surface2 = isDark ? '#252527' : '#F0F0F2';
  const surface3 = isDark ? '#303033' : '#E7E7E9';
  const text = isDark ? '#F5F5F6' : '#151517';
  const muted = isDark ? 'rgba(245,245,246,.50)' : 'rgba(21,21,23,.50)';
  const border = isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.10)';
  const primaryBg = isDark ? '#F2F2F3' : '#151517';
  const primaryText = isDark ? '#151517' : '#FFFFFF';
  const inputStyle: React.CSSProperties = {
    width: '100%', border: `1px solid ${border}`, borderRadius: 9,
    background: surface2, padding: '9px 10px', font: '10.5px Inter, sans-serif',
    color: text, outline: 'none', boxSizing: 'border-box',
  };

  const filtered = useMemo(() => suggestions.filter((item) => {
    const haystack = `${item.title} ${item.artist} ${item.contributor} ${item.moment}`.toLowerCase();
    return haystack.includes(query.toLowerCase()) && (statusFilter === 'all' || item.status === statusFilter);
  }), [suggestions, query, statusFilter]);
  const approved = suggestions.filter((item) => item.status === 'approved').length;
  const pending = suggestions.filter((item) => item.status === 'pending').length;

  const addSuggestion = () => {
    if (!form.title.trim() || !form.artist.trim() || !form.contributor.trim()) return;
    onChange([
      ...suggestions,
      {
        id: `song-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        ...form,
        title: form.title.trim(), artist: form.artist.trim(), contributor: form.contributor.trim(),
        status: 'pending', votes: 1, createdAt: new Date().toISOString(),
      },
    ]);
    setForm({ title: '', artist: '', contributor: '', role: 'Invité·e', moment: 'Soirée dansante', message: '', url: '' });
  };
  const patch = (id: string, data: Partial<PlaylistSuggestion>) =>
    onChange(suggestions.map((item) => item.id === id ? { ...item, ...data } : item));
  const remove = (id: string) => onChange(suggestions.filter((item) => item.id !== id));

  const exportCsv = () => {
    const rows = [
      ['Titre', 'Artiste', 'Proposé par', 'Rôle', 'Moment', 'Votes', 'Statut', 'Lien', 'Message'],
      ...suggestions.map((item) => [item.title, item.artist, item.contributor, item.role, item.moment, String(item.votes), item.status, item.url, item.message]),
    ];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'playlist-collaborative.csv';
    a.click();
    URL.revokeObjectURL(url);
  };
  const copyGuestLink = async () => navigator.clipboard?.writeText(`${window.location.origin}${window.location.pathname}#playlist-invites`);

  const field = (label: string, child: React.ReactNode) => (
    <label style={{ display: 'block', marginTop: 10 }}>
      <span style={{ display: 'block', fontSize: 8, fontWeight: 750, letterSpacing: '.08em', textTransform: 'uppercase', color: muted, marginBottom: 5 }}>{label}</span>
      {child}
    </label>
  );
  const smallAction = (label: string, icon: React.ReactNode, active: boolean, onClick: () => void) => (
    <button onClick={onClick} style={{ height: 28, padding: '0 8px', borderRadius: 7, border: `1px solid ${border}`, background: active ? primaryBg : surface2, color: active ? primaryText : text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, fontSize: 8.5, fontWeight: 700 }}>
      {icon}{label}
    </button>
  );

  return (
    <motion.aside
      initial={{ x: -360, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -360, opacity: 0 }}
      transition={{ type: 'spring', damping: 30, stiffness: 320 }}
      style={{ position: 'fixed', left: 66, top: 60, bottom: 18, zIndex: 350, width: 360, borderRadius: 17, background: surface, color: text, border: `1px solid ${border}`, boxShadow: '0 24px 70px rgba(0,0,0,.32)', overflow: 'hidden', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}
    >
      <header style={{ padding: '14px 15px 11px', borderBottom: `1px solid ${border}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, background: surface2, color: text, display: 'grid', placeItems: 'center', border: `1px solid ${border}` }}><Music2 size={16} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12.5, fontWeight: 800 }}>Playlist collaborative</div>
            <div style={{ fontSize: 8.5, color: muted, marginTop: 2 }}>{suggestions.length} proposition{suggestions.length > 1 ? 's' : ''} · {approved} validée{approved > 1 ? 's' : ''}</div>
          </div>
          <button onClick={onClose} style={{ border: 0, background: 'transparent', width: 28, height: 28, display: 'grid', placeItems: 'center', cursor: 'pointer', color: muted }}><X size={15} /></button>
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 11, background: surface2, padding: 3, borderRadius: 9 }}>
          <button onClick={() => setTab('guest')} style={{ flex: 1, height: 29, border: 0, borderRadius: 7, background: tab === 'guest' ? surface3 : 'transparent', color: tab === 'guest' ? text : muted, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, fontSize: 9.5, fontWeight: tab === 'guest' ? 750 : 550 }}><UserRoundPlus size={12} />Invités</button>
          <button onClick={() => setTab('dj')} style={{ flex: 1, height: 29, border: 0, borderRadius: 7, background: tab === 'dj' ? surface3 : 'transparent', color: tab === 'dj' ? text : muted, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, fontSize: 9.5, fontWeight: tab === 'dj' ? 750 : 550 }}><Headphones size={12} />Vue DJ{pending ? ` · ${pending}` : ''}</button>
        </div>
      </header>

      <div style={{ flex: 1, overflowY: 'auto', padding: 15, scrollbarWidth: 'none' }}>
        {tab === 'guest' ? (
          <div>
            <div style={{ borderRadius: 12, padding: 12, background: surface2, border: `1px solid ${border}` }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Users size={14} /><strong style={{ fontSize: 11 }}>La musique de tous</strong></div>
              <p style={{ margin: '6px 0 0', fontSize: 9.5, lineHeight: 1.5, color: muted }}>Chaque invité peut proposer un morceau. L’organisation et le DJ conservent la validation finale.</p>
            </div>
            {field('Votre prénom et nom', <input style={inputStyle} value={form.contributor} onChange={(e) => setForm({ ...form, contributor: e.target.value })} placeholder="Ex. Camille Martin" />)}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>
              {field('Votre rôle', <select style={inputStyle} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>{ROLES.map((role) => <option key={role}>{role}</option>)}</select>)}
              {field('Moment souhaité', <select style={inputStyle} value={form.moment} onChange={(e) => setForm({ ...form, moment: e.target.value })}>{MOMENTS.map((moment) => <option key={moment}>{moment}</option>)}</select>)}
            </div>
            {field('Titre du morceau', <input style={inputStyle} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex. September" />)}
            {field('Artiste', <input style={inputStyle} value={form.artist} onChange={(e) => setForm({ ...form, artist: e.target.value })} placeholder="Ex. Earth, Wind & Fire" />)}
            {field('Lien d’écoute — facultatif', <div style={{ position: 'relative' }}><Link2 size={12} style={{ position: 'absolute', left: 9, top: 10, color: muted }} /><input style={{ ...inputStyle, paddingLeft: 28 }} value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="Spotify, Apple Music, YouTube…" /></div>)}
            {field('Pourquoi ce morceau ?', <textarea style={{ ...inputStyle, minHeight: 64, resize: 'vertical' }} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Un souvenir, une dédicace, une envie…" />)}
            <button onClick={addSuggestion} disabled={!form.title.trim() || !form.artist.trim() || !form.contributor.trim()} style={{ marginTop: 11, width: '100%', height: 38, border: 0, borderRadius: 9, background: primaryBg, color: primaryText, cursor: 'pointer', opacity: (!form.title.trim() || !form.artist.trim() || !form.contributor.trim()) ? .35 : 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 10, fontWeight: 750 }}><Plus size={13} />Ajouter à la playlist</button>
            <button onClick={copyGuestLink} style={{ width: '100%', marginTop: 7, height: 36, border: `1px solid ${border}`, borderRadius: 9, background: surface2, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 9.5, fontWeight: 700 }}><Copy size={12} />Copier le lien invités</button>
          </div>
        ) : (
          <div>
            <div style={{ display: 'flex', gap: 7, marginBottom: 9 }}>
              <div style={{ flex: 1, position: 'relative' }}><Search size={12} style={{ position: 'absolute', left: 9, top: 9, color: muted }} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher…" style={{ ...inputStyle, paddingLeft: 28, paddingTop: 7, paddingBottom: 7 }} /></div>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)} style={{ ...inputStyle, width: 105, paddingTop: 7, paddingBottom: 7 }}><option value="all">Tous</option><option value="pending">À valider</option><option value="approved">Validés</option><option value="rejected">Refusés</option></select>
            </div>
            <button onClick={exportCsv} style={{ width: '100%', height: 34, border: `1px solid ${border}`, borderRadius: 9, background: surface2, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 10, fontSize: 9.5, fontWeight: 700 }}><Download size={12} />Exporter pour le DJ</button>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {filtered.map((song) => (
                <article key={song.id} style={{ border: `1px solid ${border}`, background: surface2, borderRadius: 11, padding: 10 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <div style={{ width: 32, height: 32, borderRadius: 9, background: surface3, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Music2 size={14} /></div>
                    <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontSize: 10.5, fontWeight: 760, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{song.title}</div><div style={{ fontSize: 8.5, color: muted, marginTop: 2 }}>{song.artist}</div><div style={{ display: 'flex', gap: 7, marginTop: 5, fontSize: 7.8, color: muted }}><span>{song.contributor}</span><span style={{ display: 'flex', gap: 3, alignItems: 'center' }}><Clock3 size={8} />{song.moment}</span></div></div>
                    <button onClick={() => patch(song.id, { votes: song.votes + 1 })} style={{ border: `1px solid ${border}`, background: surface3, color: text, borderRadius: 8, height: 27, padding: '0 7px', display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer', fontSize: 8.5, fontWeight: 750 }}><ThumbsUp size={10} />{song.votes}</button>
                  </div>
                  {song.message && <p style={{ margin: '7px 0 0', padding: '7px 8px', borderRadius: 8, background: surface, fontSize: 8.5, lineHeight: 1.45, color: muted }}>{song.message}</p>}
                  <div style={{ display: 'flex', gap: 5, marginTop: 7 }}>
                    {smallAction('Valider', <Check size={11} />, song.status === 'approved', () => patch(song.id, { status: 'approved' }))}
                    {smallAction('Refuser', <Ban size={11} />, song.status === 'rejected', () => patch(song.id, { status: 'rejected' }))}
                    {song.url && smallAction('Écouter', <Link2 size={11} />, false, () => window.open(song.url, '_blank', 'noopener,noreferrer'))}
                    <button onClick={() => remove(song.id)} title="Supprimer" style={{ marginLeft: 'auto', border: 0, background: 'transparent', color: muted, width: 27, cursor: 'pointer' }}><Trash2 size={11} /></button>
                  </div>
                </article>
              ))}
              {filtered.length === 0 && <div style={{ padding: 26, textAlign: 'center', fontSize: 9.5, color: muted }}>Aucune proposition dans cette vue.</div>}
            </div>
          </div>
        )}
      </div>
    </motion.aside>
  );
};
