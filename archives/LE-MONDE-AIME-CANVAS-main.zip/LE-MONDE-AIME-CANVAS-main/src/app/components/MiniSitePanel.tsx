import React, { useMemo, useRef, useState } from 'react';
import {
  X, Globe, Square, CheckSquare, GripVertical, Users, Briefcase, Heart,
  Shield, AlertTriangle, ImagePlus, Upload, MapPin, Link2, Video, ChevronRight,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useTheme } from '../contexts/ThemeContext';
import type { WeddingLot } from '../types';
import { toast } from 'sonner';
import { fileToPersistentMedia } from '../utils/persistentMedia';

type PanelMode = 'maries' | 'invite' | 'prestataire' | 'temoins' | 'surprise';

const PANEL_MODES: { id: PanelMode; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'maries', label: 'Mariés', icon: <Heart size={10} />, desc: 'Vue complète — organisation & suivi' },
  { id: 'invite', label: 'Invités', icon: <Users size={10} />, desc: 'Programme, RSVP et informations pratiques' },
  { id: 'prestataire', label: 'Presta.', icon: <Briefcase size={10} />, desc: 'Briefs, horaires et contacts utiles' },
  { id: 'temoins', label: 'Témoins', icon: <Shield size={10} />, desc: 'Coordination et moments attribués' },
  { id: 'surprise', label: 'Surprise', icon: <AlertTriangle size={10} />, desc: 'Éléments réservés aux personnes autorisées' },
];

const LOT_FILTER: Record<PanelMode, (lot: WeddingLot) => boolean> = {
  maries: () => true,
  invite: (lot) => [1, 2, 5, 9, 10].includes(lot.id),
  prestataire: (lot) => [2, 3, 4, 5, 6, 7, 8, 9, 10].includes(lot.id),
  temoins: (lot) => [1, 7, 8, 9, 10, 11].includes(lot.id),
  surprise: () => true,
};

export interface MiniSitePanelProps {
  lots: WeddingLot[];
  selected: Set<string>;
  onToggleCard: (id: string) => void;
  onToggleLot: (lotId: number) => void;
  onGenerate: () => void;
  onClose: () => void;
  cardSettings: Record<string, Record<string, any>>;
  heroPhoto?: string;
  heroMediaType?: 'image' | 'video';
  heroCoupleName?: string;
  heroDate?: string;
  heroVenue?: string;
  onHeroChange?: (field: string, value: string) => void;
}

export const MiniSitePanel: React.FC<MiniSitePanelProps> = ({
  lots, selected, onToggleLot, onGenerate, onClose,
  heroPhoto = '', heroMediaType = 'image', heroCoupleName = '', heroDate = '', heroVenue = '',
  onHeroChange,
}) => {
  const { isDark } = useTheme();
  const [mode, setMode] = useState<PanelMode>('maries');
  const [lotOrder, setLotOrder] = useState<number[]>(lots.map((lot) => lot.id));
  const [dragLot, setDragLot] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const surface = isDark ? '#171719' : '#FFFFFF';
  const surface2 = isDark ? '#212124' : '#F5F5F6';
  const border = isDark ? 'rgba(255,255,255,.085)' : 'rgba(0,0,0,.085)';
  const text = isDark ? '#F4F4F5' : '#111113';
  const muted = isDark ? 'rgba(244,244,245,.48)' : 'rgba(17,17,19,.48)';
  const soft = isDark ? 'rgba(244,244,245,.26)' : 'rgba(17,17,19,.28)';

  const filteredLots = useMemo(() => lotOrder
    .map((id) => lots.find((lot) => lot.id === id))
    .filter((lot): lot is WeddingLot => Boolean(lot) && LOT_FILTER[mode](lot)), [lotOrder, lots, mode]);

  const total = selected.size;

  const handleHeroFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !onHeroChange) return;
    const media = await fileToPersistentMedia(file);
    onHeroChange('photo', media.url);
    onHeroChange('mediaType', file.type.startsWith('video/') ? 'video' : 'image');
    if (!media.persistent) toast.warning('Cette vidéo volumineuse restera liée à la session. Utilisez une URL hébergée pour la conserver.');
  };

  const handleDrop = (targetId: number) => {
    if (dragLot == null || dragLot === targetId) { setDragLot(null); setDragOver(null); return; }
    setLotOrder((previous) => {
      const next = [...previous];
      const from = next.indexOf(dragLot);
      const to = next.indexOf(targetId);
      next.splice(from, 1);
      next.splice(to, 0, dragLot);
      return next;
    });
    setDragLot(null);
    setDragOver(null);
  };

  return (
    <motion.aside
      initial={{ x: 360, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 360, opacity: 0 }}
      transition={{ type: 'spring', damping: 30, stiffness: 320 }}
      style={{ position: 'fixed', top: 50, right: 0, bottom: 0, width: 340, background: surface, borderLeft: `1px solid ${border}`, boxShadow: isDark ? '-14px 0 38px rgba(0,0,0,.28)' : '-6px 0 24px rgba(0,0,0,.06)', zIndex: 150, display: 'flex', flexDirection: 'column', color: text }}
    >
      <div style={{ padding: '14px 16px 12px', borderBottom: `1px solid ${border}`, flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Globe size={14} />
          <strong style={{ fontSize: 11, letterSpacing: '.11em', textTransform: 'uppercase' }}>Mini-site</strong>
          <span style={{ marginLeft: 'auto', fontSize: 8.5, color: muted }}>{total} carte{total > 1 ? 's' : ''}</span>
          <button onClick={onClose} aria-label="Fermer" style={{ width: 28, height: 28, border: 0, borderRadius: 8, background: 'transparent', color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={14} /></button>
        </div>
        <div style={{ display: 'flex', gap: 3, marginTop: 12, padding: 3, borderRadius: 10, background: surface2 }}>
          {PANEL_MODES.map((item) => <button key={item.id} onClick={() => setMode(item.id)} title={item.desc} style={{ flex: 1, height: 28, border: 0, borderRadius: 7, background: mode === item.id ? (isDark ? '#303033' : '#FFFFFF') : 'transparent', color: mode === item.id ? text : soft, cursor: 'pointer', fontSize: 8.5, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3, fontWeight: mode === item.id ? 750 : 500 }}>{item.icon}{item.label}</button>)}
        </div>
        <p style={{ margin: '8px 1px 0', fontSize: 8.7, lineHeight: 1.45, color: muted }}>{PANEL_MODES.find((item) => item.id === mode)?.desc}</p>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', scrollbarWidth: 'none' }}>
        <section style={{ padding: '14px 16px', borderBottom: `1px solid ${border}` }}>
          <SectionLabel icon={<ImagePlus size={11} />} label="En-tête du site" color={muted} />
          <button onClick={() => fileRef.current?.click()} style={{ width: '100%', height: 82, marginTop: 9, borderRadius: 11, border: `1px dashed ${border}`, padding: 0, background: surface2, overflow: 'hidden', cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
            {heroPhoto ? (heroMediaType === 'video' ? <video src={heroPhoto} autoPlay muted loop playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <img src={heroPhoto} alt="Aperçu de l’en-tête" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />) : <span style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, color: muted, fontSize: 8.5 }}><Upload size={15} />Ajouter une photo</span>}
          </button>
          <input ref={fileRef} type="file" accept="image/*,video/*" hidden onChange={handleHeroFile} />
          <div style={{ display: 'grid', gap: 6, marginTop: 8 }}>
            <HeroInput value={heroPhoto} onChange={(value) => onHeroChange?.('photo', value)} placeholder="URL d’image ou de vidéo…" icon={heroMediaType === 'video' ? <Video size={10} /> : <Link2 size={10} />} surface={surface2} border={border} text={text} muted={muted} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
              {(['image', 'video'] as const).map((type) => <button key={type} onClick={() => onHeroChange?.('mediaType', type)} style={{ height: 28, borderRadius: 8, border: `1px solid ${border}`, background: heroMediaType === type ? (isDark ? '#333336' : '#E9E9EB') : surface2, color: heroMediaType === type ? text : muted, cursor: 'pointer', fontSize: 8.5, fontWeight: 700 }}>{type === 'image' ? 'Image' : 'Vidéo'}</button>)}
            </div>
            <HeroInput value={heroCoupleName} onChange={(value) => onHeroChange?.('coupleName', value)} placeholder="Titre du site" icon={<Heart size={10} />} surface={surface2} border={border} text={text} muted={muted} />
            <HeroInput value={heroDate} onChange={(value) => onHeroChange?.('date', value)} placeholder="Date" icon={<MapPin size={10} />} surface={surface2} border={border} text={text} muted={muted} />
            <HeroInput value={heroVenue} onChange={(value) => onHeroChange?.('venue', value)} placeholder="Lieu" icon={<MapPin size={10} />} surface={surface2} border={border} text={text} muted={muted} />
          </div>
        </section>

        <section style={{ padding: '14px 16px 18px' }}>
          <SectionLabel icon={<CheckSquare size={11} />} label="Sections affichées" color={muted} />
          <p style={{ margin: '7px 0 11px', color: muted, fontSize: 8.5, lineHeight: 1.5 }}>Choisissez les lots visibles ici. Leur contenu se complète depuis <strong style={{ color: text }}>Lots de cartes</strong> dans le panneau gauche.</p>
          <div style={{ display: 'grid', gap: 5 }}>
            {filteredLots.map((lot) => {
              const selectedCount = lot.cards.filter((card) => selected.has(card.id)).length;
              const allSelected = selectedCount === lot.cards.length;
              return <div key={lot.id} draggable onDragStart={() => setDragLot(lot.id)} onDragOver={(event) => { event.preventDefault(); setDragOver(lot.id); }} onDrop={() => handleDrop(lot.id)} onDragEnd={() => { setDragLot(null); setDragOver(null); }} style={{ height: 39, padding: '0 8px', borderRadius: 9, border: `1px solid ${dragOver === lot.id ? 'rgba(255,255,255,.24)' : border}`, background: dragOver === lot.id ? (isDark ? '#2B2B2E' : '#EEEEF0') : surface2, display: 'flex', alignItems: 'center', gap: 7 }}>
                <GripVertical size={11} color={soft} style={{ cursor: 'grab' }} />
                <button onClick={() => onToggleLot(lot.id)} style={{ border: 0, padding: 0, background: 'transparent', color: allSelected ? text : muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}>{allSelected ? <CheckSquare size={12} /> : <Square size={12} />}</button>
                <span style={{ minWidth: 0, flex: 1, fontSize: 9.5, fontWeight: 650, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{lot.title}</span>
                <span style={{ fontSize: 8, color: muted }}>{selectedCount}/{lot.cards.length}</span>
                <ChevronRight size={11} color={soft} />
              </div>;
            })}
          </div>
        </section>
      </div>

      <div style={{ padding: 12, borderTop: `1px solid ${border}`, flexShrink: 0 }}>
        <button onClick={onGenerate} disabled={total === 0} style={{ width: '100%', height: 40, borderRadius: 10, border: `1px solid ${border}`, background: total ? (isDark ? '#F2F2F3' : '#151517') : surface2, color: total ? (isDark ? '#151517' : '#FFFFFF') : muted, cursor: total ? 'pointer' : 'not-allowed', fontSize: 9.5, fontWeight: 850, letterSpacing: '.05em', textTransform: 'uppercase' }}>Ouvrir le mini-site</button>
      </div>
    </motion.aside>
  );
};

const SectionLabel: React.FC<{ icon: React.ReactNode; label: string; color: string }> = ({ icon, label, color }) => <div style={{ display: 'flex', alignItems: 'center', gap: 6, color, fontSize: 8, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase' }}>{icon}{label}</div>;

const HeroInput: React.FC<{ value: string; onChange: (value: string) => void; placeholder: string; icon: React.ReactNode; surface: string; border: string; text: string; muted: string }> = ({ value, onChange, placeholder, icon, surface, border, text, muted }) => <label style={{ height: 32, borderRadius: 8, border: `1px solid ${border}`, background: surface, display: 'flex', alignItems: 'center', gap: 7, padding: '0 9px', color: muted }}><span style={{ display: 'grid', placeItems: 'center' }}>{icon}</span><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} style={{ minWidth: 0, flex: 1, border: 0, outline: 'none', background: 'transparent', color: text, fontSize: 9.5 }} /></label>;
