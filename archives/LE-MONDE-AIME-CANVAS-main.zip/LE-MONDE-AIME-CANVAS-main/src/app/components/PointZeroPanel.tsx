import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import JSZip from 'jszip';
import { Archive, CheckCircle2, Crosshair, FileCode2, Globe2, Layers3, Lock, ShieldCheck, Sparkles, Unlock, UploadCloud, X } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export interface PointZeroState {
  x: number;
  y: number;
  visible: boolean;
  locked: boolean;
}

export interface PointZeroImportReport {
  id: string;
  fileName: string;
  size: number;
  fileCount: number;
  codeCount: number;
  mediaCount: number;
  framework: string;
  roots: string[];
  sensitive: string[];
  generatedAt: string;
}

interface AuditMission {
  url: string;
  country: string;
  service: string;
  standard: string;
}

interface PointZeroPanelProps {
  open: boolean;
  pointZero: PointZeroState;
  onPointZeroChange: (state: PointZeroState) => void;
  onCenter: () => void;
  onReset: () => void;
  onCreateBlank: () => void;
  onCreateAuditMission: (mission: AuditMission) => void;
  onImportReport: (report: PointZeroImportReport) => void;
  onClose: () => void;
}

type TabId = 'origin' | 'audit' | 'import';

function detectFramework(paths: string[]) {
  const has = (needle: string) => paths.some((path) => path.toLowerCase().endsWith(needle));
  if (has('next.config.js') || has('next.config.mjs') || paths.some((path) => path.includes('/.next/'))) return 'Next.js';
  if (has('vite.config.ts') || has('vite.config.js')) return 'Vite';
  if (has('angular.json')) return 'Angular';
  if (has('svelte.config.js')) return 'Svelte';
  if (has('package.json')) return 'Projet JavaScript / TypeScript';
  if (has('index.html')) return 'Site HTML statique';
  return 'Technologie à confirmer';
}

export const PointZeroPanel: React.FC<PointZeroPanelProps> = ({
  open,
  pointZero,
  onPointZeroChange,
  onCenter,
  onReset,
  onCreateBlank,
  onCreateAuditMission,
  onImportReport,
  onClose,
}) => {
  const { isDark } = useTheme();
  const [tab, setTab] = useState<TabId>('origin');
  const [url, setUrl] = useState('');
  const [country, setCountry] = useState('France');
  const [service, setService] = useState('Site ou service numérique');
  const [zipBusy, setZipBusy] = useState(false);
  const [report, setReport] = useState<PointZeroImportReport | null>(null);
  const [auditCreated, setAuditCreated] = useState(false);

  const surface = isDark ? '#171719' : '#FFFFFF';
  const surface2 = isDark ? '#232326' : '#F3F3F5';
  const text = isDark ? '#F7F6F8' : '#151518';
  const muted = isDark ? 'rgba(247,246,248,.50)' : 'rgba(21,21,24,.50)';
  const border = isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.10)';

  const createAudit = () => {
    try {
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol)) return;
      onCreateAuditMission({ url: parsed.toString(), country, service, standard: 'EAA · EN 301 549 · WCAG 2.2 AA · RGAA 4.1.2' });
      setAuditCreated(true);
    } catch { setAuditCreated(false); }
  };

  const inspectZip = async (file: File) => {
    setZipBusy(true);
    setReport(null);
    try {
      const zip = await JSZip.loadAsync(file);
      const paths = Object.values(zip.files).filter((entry) => !entry.dir).map((entry) => entry.name);
      const codeExtensions = /\.(tsx?|jsx?|vue|svelte|html?|css|scss|sass|less|json|mdx?|ya?ml)$/i;
      const mediaExtensions = /\.(png|jpe?g|webp|gif|svg|mp4|mov|webm|mp3|wav|ogg|pdf)$/i;
      const sensitivePattern = /(^|\/)(\.env($|\.)|.*\.(pem|key|p12|pfx)|id_rsa|credentials|secrets?\.(json|ya?ml)|.*\.keystore$)/i;
      const roots = Array.from(new Set(paths.map((path) => path.split('/')[0]).filter(Boolean))).slice(0, 12);
      const nextReport: PointZeroImportReport = {
        id: `pz-import-${Date.now().toString(36)}`,
        fileName: file.name,
        size: file.size,
        fileCount: paths.length,
        codeCount: paths.filter((path) => codeExtensions.test(path)).length,
        mediaCount: paths.filter((path) => mediaExtensions.test(path)).length,
        framework: detectFramework(paths),
        roots,
        sensitive: paths.filter((path) => sensitivePattern.test(path)).slice(0, 20),
        generatedAt: new Date().toISOString(),
      };
      setReport(nextReport);
      onImportReport(nextReport);
    } finally {
      setZipBusy(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button aria-label="Fermer Point Zéro" onClick={onClose} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} style={{ position: 'fixed', inset: 0, zIndex: 600, border: 0, background: 'rgba(0,0,0,.46)', backdropFilter: 'blur(6px)' }} />
          <motion.section initial={{ opacity: 0, y: 24, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 24, scale: .97 }} transition={{ type: 'spring', damping: 30, stiffness: 360 }} style={{ position: 'fixed', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: 'min(720px,calc(100vw - 28px))', maxHeight: 'min(760px,calc(100vh - 28px))', overflow: 'hidden', zIndex: 610, borderRadius: 22, background: surface, color: text, border: `1px solid ${border}`, boxShadow: '0 40px 120px rgba(0,0,0,.46)' }}>
            <header style={{ padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 11, borderBottom: `1px solid ${border}` }}>
              <div style={{ width: 38, height: 38, borderRadius: '50%', display: 'grid', placeItems: 'center', background: '#242426', border: `1px solid ${border}`, boxShadow: '0 0 0 5px rgba(255,255,255,.04)' }}><Crosshair size={16} color="#fff" /></div>
              <div style={{ flex: 1 }}><div style={{ fontSize: 14, fontWeight: 900 }}>Point Zéro des Vivants</div><div style={{ marginTop: 2, color: muted, fontSize: 9.5 }}>Origine, audit et renaissance d’un projet dans le même canevas.</div></div>
              <button onClick={onClose} aria-label="Fermer" style={{ width: 32, height: 32, borderRadius: 9, border: 0, background: 'transparent', color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={16} /></button>
            </header>

            <nav style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 5, padding: 8, borderBottom: `1px solid ${border}` }}>
              {([
                ['origin', 'Origine', <Crosshair size={13} />],
                ['audit', 'Auditer une URL', <ShieldCheck size={13} />],
                ['import', 'Importer un ZIP', <Archive size={13} />],
              ] as const).map(([id, label, icon]) => <button key={id} onClick={() => setTab(id)} style={{ height: 34, border: 0, borderRadius: 9, background: tab === id ? surface2 : 'transparent', color: tab === id ? text : muted, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, fontSize: 9.5, fontWeight: 800 }}>{icon}{label}</button>)}
            </nav>

            <div style={{ padding: 18, overflowY: 'auto', maxHeight: 'calc(min(760px,100vh - 28px) - 122px)' }}>
              {tab === 'origin' && <div>
                <div style={{ padding: 14, borderRadius: 14, background: surface2, border: `1px solid ${border}` }}>
                  <div style={{ display: 'flex', gap: 11, alignItems: 'center' }}><Sparkles size={18} color={text} /><div><div style={{ fontSize: 11.5, fontWeight: 850 }}>Une origine commune</div><div style={{ marginTop: 3, color: muted, fontSize: 9, lineHeight: 1.5 }}>Le Point Zéro peut devenir le centre d’une grille, le début d’une timeline ou l’ancrage d’un projet collectif.</div></div></div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginTop: 14 }}>
                  {(['x','y'] as const).map((axis) => <label key={axis} style={{ fontSize: 8.5, color: muted, textTransform: 'uppercase', letterSpacing: '.12em' }}>{axis.toUpperCase()}<input type="number" value={Math.round(pointZero[axis])} onChange={(event) => onPointZeroChange({ ...pointZero, [axis]: Number(event.target.value) || 0 })} style={{ marginTop: 6, width: '100%', height: 38, boxSizing: 'border-box', borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, padding: '0 11px', fontSize: 11 }} /></label>)}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginTop: 10 }}>
                  <button onClick={() => onPointZeroChange({ ...pointZero, visible: !pointZero.visible })} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, cursor: 'pointer', fontSize: 9.5, fontWeight: 800 }}>{pointZero.visible ? 'Masquer le repère' : 'Afficher le repère'}</button>
                  <button onClick={() => onPointZeroChange({ ...pointZero, locked: !pointZero.locked })} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, cursor: 'pointer', fontSize: 9.5, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}>{pointZero.locked ? <Lock size={13} /> : <Unlock size={13} />}{pointZero.locked ? 'Déverrouiller' : 'Verrouiller'}</button>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.4fr', gap: 9, marginTop: 10 }}>
                  <button onClick={onCenter} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, cursor: 'pointer', fontSize: 9.5, fontWeight: 800 }}>Centrer la vue</button>
                  <button onClick={onReset} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, cursor: 'pointer', fontSize: 9.5, fontWeight: 800 }}>Réinitialiser 0,0</button>
                  <button onClick={onCreateBlank} style={{ height: 38, borderRadius: 10, border: `1px solid ${border}`, background: isDark ? '#F2F2F3' : '#151517', color: isDark ? '#151517' : '#FFFFFF', cursor: 'pointer', fontSize: 9.5, fontWeight: 850 }}>Créer depuis ce point</button>
                </div>
              </div>}

              {tab === 'audit' && <div>
                <div style={{ padding: 14, borderRadius: 14, background: surface2, border: `1px solid ${border}`, display: 'flex', gap: 11 }}><ShieldCheck size={19} color={text} /><div><div style={{ fontSize: 11.5, fontWeight: 850 }}>Préparer un audit crédible</div><div style={{ marginTop: 4, fontSize: 9, lineHeight: 1.55, color: muted }}>Cette étape crée la mission et son périmètre dans le canevas. Le scan distant et les tests humains seront ajoutés au moteur Audit & Proof.</div></div></div>
                <label style={{ display: 'block', marginTop: 14, fontSize: 8.5, color: muted, textTransform: 'uppercase', letterSpacing: '.12em' }}>URL du service<input value={url} onChange={(event) => { setUrl(event.target.value); setAuditCreated(false); }} placeholder="https://exemple.fr" style={{ marginTop: 6, width: '100%', height: 40, boxSizing: 'border-box', borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, padding: '0 12px', fontSize: 10.5 }} /></label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 9, marginTop: 10 }}>
                  <label style={{ fontSize: 8.5, color: muted, textTransform: 'uppercase', letterSpacing: '.12em' }}>Pays<select value={country} onChange={(event) => setCountry(event.target.value)} style={{ marginTop: 6, width: '100%', height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, padding: '0 10px', fontSize: 10 }}><option>France</option><option>Belgique</option><option>Union européenne</option><option>Autre</option></select></label>
                  <label style={{ fontSize: 8.5, color: muted, textTransform: 'uppercase', letterSpacing: '.12em' }}>Type de service<select value={service} onChange={(event) => setService(event.target.value)} style={{ marginTop: 6, width: '100%', height: 38, borderRadius: 10, border: `1px solid ${border}`, background: surface2, color: text, padding: '0 10px', fontSize: 10 }}><option>Site ou service numérique</option><option>Commerce électronique</option><option>Application mobile</option><option>Service public</option><option>Document ou magazine</option></select></label>
                </div>
                <div style={{ marginTop: 10, padding: 10, borderRadius: 10, border: `1px solid ${border}`, color: muted, fontSize: 8.8, lineHeight: 1.5 }}>Référentiel préparé : <strong style={{ color: text }}>EAA · EN 301 549 · WCAG 2.2 AA · RGAA 4.1.2</strong>. WCAG 3 restera présenté comme une couche prospective, jamais comme une certification.</div>
                <button onClick={createAudit} style={{ marginTop: 12, width: '100%', height: 42, borderRadius: 11, border: 0, background: isDark ? '#F2F2F3' : '#151517', color: isDark ? '#151517' : '#FFFFFF', cursor: 'pointer', fontSize: 10, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>{auditCreated ? <CheckCircle2 size={15} /> : <Globe2 size={15} />}{auditCreated ? 'Mission ajoutée au canevas' : 'Créer la mission d’audit'}</button>
              </div>}

              {tab === 'import' && <div>
                <div style={{ padding: 14, borderRadius: 14, background: surface2, border: `1px solid ${border}`, display: 'flex', gap: 11 }}><Archive size={19} color={text} /><div><div style={{ fontSize: 11.5, fontWeight: 850 }}>Quarantaine avant reconstruction</div><div style={{ marginTop: 4, fontSize: 9, lineHeight: 1.55, color: muted }}>Le ZIP est inventorié sans exécuter ses scripts. Les secrets potentiels sont signalés avant toute conversion.</div></div></div>
                <label style={{ marginTop: 14, minHeight: 120, borderRadius: 14, border: `1px dashed ${border}`, background: surface2, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, color: muted }}><UploadCloud size={22} /><span style={{ fontSize: 10, fontWeight: 800, color: text }}>{zipBusy ? 'Inventaire en cours…' : 'Choisir une archive ZIP'}</span><span style={{ fontSize: 8.5 }}>Base44, Manus, React, Vite, HTML ou autre export</span><input type="file" accept=".zip,application/zip" disabled={zipBusy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void inspectZip(file); }} style={{ display: 'none' }} /></label>
                {report && <div style={{ marginTop: 12, borderRadius: 14, border: `1px solid ${border}`, overflow: 'hidden' }}>
                  <div style={{ padding: 12, background: surface2, display: 'flex', alignItems: 'center', gap: 9 }}><FileCode2 size={16} color={text} /><div style={{ flex: 1 }}><div style={{ fontSize: 10.5, fontWeight: 850 }}>{report.fileName}</div><div style={{ marginTop: 2, fontSize: 8.5, color: muted }}>{report.framework} · {(report.size / 1024 / 1024).toFixed(1)} Mo</div></div><CheckCircle2 size={16} color={text} /></div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 1, background: border }}>
                    {[['Fichiers', report.fileCount], ['Code', report.codeCount], ['Médias', report.mediaCount]].map(([label, value]) => <div key={String(label)} style={{ padding: 11, background: surface, textAlign: 'center' }}><div style={{ fontSize: 15, fontWeight: 900 }}>{value}</div><div style={{ marginTop: 2, fontSize: 8, color: muted }}>{label}</div></div>)}
                  </div>
                  <div style={{ padding: 12 }}><div style={{ fontSize: 8.5, color: muted }}>Dossiers racine</div><div style={{ marginTop: 7, display: 'flex', flexWrap: 'wrap', gap: 5 }}>{report.roots.map((root) => <span key={root} style={{ padding: '4px 7px', borderRadius: 7, background: surface2, fontSize: 8.5 }}>{root}</span>)}</div>
                    <div style={{ marginTop: 10, color: report.sensitive.length ? '#F59E7A' : '#54C895', fontSize: 8.8, fontWeight: 750 }}>{report.sensitive.length ? `${report.sensitive.length} fichier(s) sensible(s) potentiel(s) à isoler.` : 'Aucun secret évident détecté dans les noms de fichiers.'}</div>
                  </div>
                </div>}
              </div>}
            </div>
          </motion.section>
        </>
      )}
    </AnimatePresence>
  );
};
