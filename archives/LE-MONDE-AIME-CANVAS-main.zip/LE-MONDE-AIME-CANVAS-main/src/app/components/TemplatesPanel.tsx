import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { getStudioTokens } from '../theme/studioTokens';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
export interface WeddingTemplate {
  id: string;
  name: string;
  description: string;
  style: string;
  gradient: string;
  cardDefaults: Record<string, Record<string, any>>;
}

interface TemplatesPanelProps {
  onApplyTemplate: (template: WeddingTemplate) => void;
  onClose: () => void;
}

const STYLE_COLORS: Record<string, { bg: string; text: string }> = {
  classique: { bg: 'rgba(255,255,255,.08)', text: '#D4D4D8' },
  boheme: { bg: 'rgba(255,255,255,.08)', text: '#D4D4D8' },
  champetre: { bg: 'rgba(255,255,255,.08)', text: '#D4D4D8' },
  urbain: { bg: 'rgba(255,255,255,.08)', text: '#D4D4D8' },
  luxe: { bg: 'rgba(255,255,255,.08)', text: '#D4D4D8' },
};

const TEMPLATES: WeddingTemplate[] = [
  {
    id: 'classique',
    name: 'Mariage Classique',
    description: 'Noir et or, cérémonie religieuse à 14h suivie d\'un cocktail dînatoire à 19h.',
    style: 'classique',
    gradient: 'linear-gradient(135deg, #1a1206 0%, #3d2b00 50%, #7c5c00 100%)',
    cardDefaults: {
      'prog-1': { time: '10:00', notes: 'Préparatifs mariée' },
      'prog-2': { time: '12:00', notes: 'Préparatifs marié' },
      'prog-3': { time: '14:00', notes: 'Cérémonie religieuse — Église Saint-Pierre' },
      'prog-4': { time: '15:30', notes: 'Sortie des mariés — lancer de confettis' },
      'prog-5': { time: '16:00', notes: 'Séance photos de groupe' },
      'prog-6': { time: '17:00', notes: 'Cocktail — champagne et canapés' },
      'prog-7': { time: '19:00', notes: 'Ouverture du bal — première danse' },
      'prog-8': { time: '19:30', notes: 'Dîner de mariage — menu gastronomique' },
      'prog-9': { time: '22:00', notes: 'Pièce montée — discours' },
      'prog-10': { time: '22:30', notes: 'Soirée dansante — DJ set' },
      'prog-11': { time: '02:00', notes: 'Buffet de nuit' },
      'prog-12': { time: '04:00', notes: 'Fin de soirée' },
    },
  },
  {
    id: 'boheme',
    name: 'Mariage Bohème',
    description: 'Rose poudré et vert sauge, cérémonie laïque en plein air sous les étoiles.',
    style: 'boheme',
    gradient: 'linear-gradient(135deg, #2d1a22 0%, #5c2d3d 40%, #3d5c3a 100%)',
    cardDefaults: {
      'prog-1': { time: '09:00', notes: 'Préparatifs dans la nature — huttes privées' },
      'prog-2': { time: '11:00', notes: 'Brunch des proches' },
      'prog-3': { time: '15:00', notes: 'Cérémonie laïque en plein air — arche de fleurs' },
      'prog-4': { time: '16:00', notes: 'Sortie des mariés — pétales de roses séchées' },
      'prog-5': { time: '16:30', notes: 'Portraits intimistes dans les jardins' },
      'prog-6': { time: '17:30', notes: 'Cocktail apéritif — vin naturel et planches' },
      'prog-7': { time: '19:30', notes: 'Dîner convivial — grandes tablées' },
      'prog-8': { time: '21:30', notes: 'Feu de camp et musique live' },
      'prog-9': { time: '22:30', notes: 'Gâteau boho — naked cake' },
      'prog-10': { time: '23:00', notes: 'Soirée festive — DJ bohème' },
      'prog-11': { time: '01:00', notes: 'Lâcher de lanternes' },
      'prog-12': { time: '03:00', notes: 'Fin de soirée' },
    },
  },
  {
    id: 'champetre',
    name: 'Mariage Champêtre',
    description: 'Lin et terracotta, dans une ferme ou un domaine rural authentique.',
    style: 'champetre',
    gradient: 'linear-gradient(135deg, #2a1a0a 0%, #6b4226 45%, #8b6914 100%)',
    cardDefaults: {
      'prog-1': { time: '09:30', notes: 'Préparatifs à la ferme — grange décorée' },
      'prog-2': { time: '11:30', notes: 'Accueil des invités — limonade et jus maison' },
      'prog-3': { time: '14:30', notes: 'Cérémonie champêtre — sous les arbres' },
      'prog-4': { time: '15:45', notes: 'Vin d\'honneur — produits locaux et vins du terroir' },
      'prog-5': { time: '16:30', notes: 'Jeux en plein air — pétanque, tir à la corde' },
      'prog-6': { time: '18:00', notes: 'Séance photo coucher de soleil' },
      'prog-7': { time: '19:30', notes: 'Dîner champêtre — buffet de saison' },
      'prog-8': { time: '21:00', notes: 'Chants et musiques folk' },
      'prog-9': { time: '21:30', notes: 'Tarte aux fruits — pièce montée rustique' },
      'prog-10': { time: '22:00', notes: 'Soirée — accordéon et DJ folk' },
      'prog-11': { time: '01:30', notes: 'Soupe à l\'oignon — tradition' },
      'prog-12': { time: '03:30', notes: 'Fin de soirée' },
    },
  },
  {
    id: 'urbain',
    name: 'Mariage Urbain',
    description: 'Slate et acier, dans un loft industriel ou un musée — cocktail décontracté.',
    style: 'urbain',
    gradient: 'linear-gradient(135deg, #0d0f14 0%, #1e2433 50%, #2c3447 100%)',
    cardDefaults: {
      'prog-1': { time: '11:00', notes: 'Préparatifs — suite hôtel design' },
      'prog-2': { time: '13:00', notes: 'Pause déjeuner — restaurant tendance' },
      'prog-3': { time: '15:30', notes: 'Cérémonie civile — mairie du centre-ville' },
      'prog-4': { time: '16:30', notes: 'Séance photos urbaine — street art et rooftop' },
      'prog-5': { time: '18:00', notes: 'Cocktail — bar à vins naturels et tapas créatives' },
      'prog-6': { time: '20:00', notes: 'Dîner — restaurant éphémère dans le loft' },
      'prog-7': { time: '22:00', notes: 'After party — DJ électro-jazz' },
      'prog-8': { time: '22:30', notes: 'Gâteau design — layer cake' },
      'prog-9': { time: '23:00', notes: 'Photo booth et animations' },
      'prog-10': { time: '00:00', notes: 'Club privé — soirée dansante' },
      'prog-11': { time: '02:00', notes: 'Food trucks de nuit' },
      'prog-12': { time: '04:00', notes: 'After after — after party restreinte' },
    },
  },
  {
    id: 'luxe',
    name: 'Mariage Luxe',
    description: 'Or et ivoire, dans un palace ou un château — dîner gastronomique étoilé.',
    style: 'luxe',
    gradient: 'linear-gradient(135deg, #0a0800 0%, #2a2000 40%, #4d3d00 70%, #7a6000 100%)',
    cardDefaults: {
      'prog-1': { time: '08:00', notes: 'Suite présidentielle — maquillage et coiffure' },
      'prog-2': { time: '10:00', notes: 'Préparatifs dans les appartements du château' },
      'prog-3': { time: '12:00', notes: 'Déjeuner privé de famille — salon d\'honneur' },
      'prog-4': { time: '14:30', notes: 'Cérémonie dans la chapelle du domaine' },
      'prog-5': { time: '16:00', notes: 'Vin d\'honneur — champagne grand cru et amuse-bouches' },
      'prog-6': { time: '17:30', notes: 'Séance photo dans les jardins à la française' },
      'prog-7': { time: '19:30', notes: 'Cocktail dînatoire — galerie des glaces' },
      'prog-8': { time: '20:30', notes: 'Dîner gastronomique étoilé — grande salle' },
      'prog-9': { time: '23:00', notes: 'Découpe du gâteau — pièce montée de luxe' },
      'prog-10': { time: '23:30', notes: 'Bal — orchestre live et DJ' },
      'prog-11': { time: '02:00', notes: 'Brunch de nuit — crêpes et champagne' },
      'prog-12': { time: '05:00', notes: 'Lever du soleil — terrasse panoramique' },
    },
  },
];

export const TemplatesPanel: React.FC<TemplatesPanelProps> = ({ onApplyTemplate, onClose }) => {
  const { isDark } = useTheme();
  const tokens = getStudioTokens(isDark);
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.6)',
          zIndex: 60,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px',
          fontFamily: 'Inter, sans-serif',
        }}
        onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          style={{
            width: 700,
            maxHeight: '80vh',
            background: tokens.surface,
            borderRadius: 16,
            border: `1px solid ${tokens.border}`,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}
        >
          {/* Header */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '20px 24px',
            borderBottom: `1px solid ${tokens.border}`,
            flexShrink: 0,
          }}>
            <div>
              <div style={{ color: tokens.text, fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em' }}>Modèles de mariage</div>
              <div style={{ color: tokens.muted, fontSize: 12, marginTop: 3 }}>Choisissez un modèle pour pré-remplir votre programme</div>
            </div>
            <button
              onClick={onClose}
              style={{ background: tokens.surface2, border: `1px solid ${tokens.border}`, borderRadius: 8, cursor: 'pointer', color: tokens.muted, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32 }}
            >
              <X size={16} />
            </button>
          </div>

          {/* Grid */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: 16,
            }}>
              {TEMPLATES.map((template, idx) => {
                const styleColors = STYLE_COLORS[template.style] || STYLE_COLORS.classique;
                return (
                  <motion.div
                    key={template.id}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.07, duration: 0.3 }}
                    style={{
                      background: tokens.surface2,
                      borderRadius: 12,
                      border: '1px solid rgba(255,255,255,0.07)',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    {/* Gradient swatch */}
                    <div style={{
                      height: 80,
                      background: template.gradient,
                      flexShrink: 0,
                      position: 'relative',
                    }}>
                      <div style={{
                        position: 'absolute',
                        bottom: 8,
                        right: 10,
                        fontSize: 9,
                        fontWeight: 700,
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        padding: '3px 8px',
                        borderRadius: 4,
                        background: styleColors.bg,
                        color: styleColors.text,
                        border: `1px solid ${styleColors.text}33`,
                        backdropFilter: 'blur(4px)',
                      }}>
                        {template.style}
                      </div>
                    </div>

                    {/* Content */}
                    <div style={{ padding: '14px', flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
                      <div style={{ color: 'white', fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em' }}>{template.name}</div>
                      <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, lineHeight: 1.5, flex: 1 }}>{template.description}</div>
                      <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11 }}>
                        {Object.keys(template.cardDefaults).length} étapes préprogrammées
                      </div>
                      <button
                        onClick={() => onApplyTemplate(template)}
                        style={{
                          width: '100%',
                          padding: '9px',
                          borderRadius: 8,
                          background: 'rgba(255,255,255,0.08)',
                          border: '1px solid rgba(255,255,255,0.12)',
                          color: 'rgba(255,255,255,0.9)',
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: 'pointer',
                          transition: 'all 0.15s',
                          fontFamily: 'Inter, sans-serif',
                          marginTop: 4,
                        }}
                        onMouseEnter={e => {
                          (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.14)';
                          (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(255,255,255,0.2)';
                        }}
                        onMouseLeave={e => {
                          (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)';
                          (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(255,255,255,0.12)';
                        }}
                      >
                        Appliquer ce modèle
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
