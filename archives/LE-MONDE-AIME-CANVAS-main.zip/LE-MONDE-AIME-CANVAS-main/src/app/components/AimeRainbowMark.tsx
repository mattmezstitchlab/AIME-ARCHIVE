import React from 'react';

interface AimeRainbowMarkProps {
  size?: number;
  title?: string;
  className?: string;
}

export const AimeRainbowMark: React.FC<AimeRainbowMarkProps> = ({
  size = 30,
  title = 'LE MONDE AIME',
  className,
}) => (
  <span
    className={className}
    role="img"
    aria-label={title}
    style={{
      width: size,
      height: size,
      flex: '0 0 auto',
      display: 'inline-grid',
      placeItems: 'center',
      borderRadius: '50%',
      padding: Math.max(2, Math.round(size * 0.09)),
      boxSizing: 'border-box',
      background: 'conic-gradient(from 215deg,#F1A55B,#F3D875,#8FC8A5,#70BBD0,#8D83D8,#D783B9,#D97976,#F1A55B)',
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.28),0 0 0 1px rgba(0,0,0,.16)',
    }}
  >
    <span
      aria-hidden="true"
      style={{
        width: '46%',
        height: '46%',
        borderRadius: '50%',
        background: '#242426',
        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.12)',
      }}
    />
  </span>
);
