import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { getProjectItem, setProjectItem } from '../utils/projectStore';
import {
  Edit2, Layers, Type, Palette, Wand2, Eye, EyeOff, Loader2,
  ChevronUp, ChevronDown, Music2, MapPin, Users, Camera,
} from 'lucide-react';
import { ICON_MAP } from '../utils/iconMap';
import type { CoverVariant, WeddingLot, WeddingCard } from '../types';

interface MiniSiteProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  selectedCards: Set<string>;
  coupleName: string;
  weddingDate: string;
  heroPhoto?: string;
  heroMediaType?: 'image' | 'video';
  heroCoupleName?: string;
  heroDate?: string;
  heroVenue?: string;
  embedded?: boolean;
  coverVariant?: CoverVariant;
}

const AI_TEMPLATES: Record<string, string[]> = {
  hero: ['Une journée d\'amour et de lumière, orchestrée avec soin pour vous et vos proches.', 'Le commencement d\'une belle histoire — vivez ce jour dans la grâce et la joie.'],
  programme: ['Chaque moment de ce jour unique est pensé avec soin pour créer des souvenirs inoubliables.', 'Un programme tissé d\'émotions, de rires et de tendresse — de l\'aube jusqu\'aux étoiles.'],
  venue: ['Un lieu d\'exception choisi avec amour, où chaque pierre raconte une histoire et chaque angle révèle la beauté.', 'Entre ces murs chargés d\'histoire, votre union trouvera l\'écrin qui lui correspond.'],
  team: ['Des artisans du bonheur, sélectionnés avec soin pour leur excellence et leur passion du détail.', 'Chaque prestataire partage votre vision : créer une journée parfaite, dans les moindres détails.'],
  music: ['Une sélection musicale soigneusement choisie pour accompagner chaque émotion de votre journée.', 'Des notes qui bercent l\'amour, font danser les cœurs et resteront gravées dans vos mémoires.'],
  rsvp: ['Votre présence est notre plus beau cadeau. Confirmez votre venue pour que nous puissions vous accueillir comme il se doit.', 'Nous avons hâte de partager ce moment avec vous. Dites-nous que vous serez là !'],
};

const SECTION_NAMES: Record<string, string> = {
  hero: 'Héros',
  programme: 'Programme',
  venue: 'Le Lieu',
  team: 'Notre Équipe',
  music: 'La Playlist',
  rsvp: 'RSVP',
  footer: 'Pied de page',
};

const LAYOUTS = ['1col', '2col', 'fullbleed'] as const;
const TYPOS = ['editorial', 'modern'] as const;

type Layout = typeof LAYOUTS[number];
type Typo = typeof TYPOS[number];

export const MiniSite: React.FC<MiniSiteProps> = ({
  lots,
  cardSettings,
  selectedCards,
  coupleName,
  weddingDate,
  heroPhoto = '',
  heroMediaType = 'image',
  heroCoupleName = '',
  heroDate = '',
  heroVenue = '',
  embedded = false,
  coverVariant = 'original',
}) => {
  const readRecord = <T,>(key: string, fallback: T): T => {
    try { return JSON.parse(getProjectItem(key) || '') as T; } catch { return fallback; }
  };
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [hiddenSections, setHiddenSections] = useState<Set<string>>(() => new Set(readRecord<string[]>('lma_minisite_hidden_sections', [])));
  const [sectionLayouts, setSectionLayouts] = useState<Record<string, Layout>>(() => readRecord('lma_minisite_layouts', {}));
  const [sectionTypos, setSectionTypos] = useState<Record<string, Typo>>(() => readRecord('lma_minisite_typos', {}));
  const [sectionContent, setSectionContent] = useState<Record<string, string>>(() => readRecord('lma_minisite_content', {}));
  const [sectionBackgrounds, setSectionBackgrounds] = useState<Record<string, string>>(() => readRecord('lma_minisite_backgrounds', {}));
  const [isGenerating, setIsGenerating] = useState(false);
  const [sectionOrder, setSectionOrder] = useState<string[]>(() => readRecord('lma_minisite_order', ['hero','programme','venue','team','music','rsvp','footer']));
  const [rsvp, setRsvp] = useState({ name: '', email: '', count: '1' });

  useEffect(() => { setProjectItem('lma_minisite_hidden_sections', JSON.stringify(Array.from(hiddenSections))); }, [hiddenSections]);
  useEffect(() => { setProjectItem('lma_minisite_layouts', JSON.stringify(sectionLayouts)); }, [sectionLayouts]);
  useEffect(() => { setProjectItem('lma_minisite_typos', JSON.stringify(sectionTypos)); }, [sectionTypos]);
  useEffect(() => { setProjectItem('lma_minisite_content', JSON.stringify(sectionContent)); }, [sectionContent]);
  useEffect(() => { setProjectItem('lma_minisite_backgrounds', JSON.stringify(sectionBackgrounds)); }, [sectionBackgrounds]);
  useEffect(() => { setProjectItem('lma_minisite_order', JSON.stringify(sectionOrder)); }, [sectionOrder]);

  const displayCoupleName = sectionContent['hero-title'] || heroCoupleName || coupleName;
  const displayDate = sectionContent['hero-date'] || heroDate || weddingDate;

  const getCards = (type: string): WeddingCard[] =>
    lots.flatMap((l) => l.cards).filter((c) => selectedCards.has(c.id) && c.type === type);

  const programmeCards = getCards('programme');
  const venueCards = getCards('venue');
  const vendorCards = [
    ...getCards('photo-video'),
    ...getCards('beauty'),
    ...getCards('catering'),
    ...getCards('flowers'),
    ...getCards('artist'),
    ...getCards('animation'),
  ];
  const musicCards = [...getCards('music-ceremony'), ...getCards('music-soiree')];

  const venueSettings = venueCards[0] ? cardSettings[venueCards[0].id] || {} : {};
  const venueName = venueSettings.nom || '';
  const displayVenue = sectionContent['hero-venue'] || heroVenue || venueName;

  const toggleHidden = (id: string) =>
    setHiddenSections((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const moveSection = (id: string, direction: -1 | 1) => {
    setSectionOrder((prev) => {
      const index = prev.indexOf(id);
      const nextIndex = Math.max(0, Math.min(prev.length - 1, index + direction));
      if (index < 0 || index === nextIndex) return prev;
      const next = [...prev];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next;
    });
  };

  const cycleSectionBackground = (id: string) => {
    const choices = ['#ffffff','#FAFAF8','#F4F2EE','linear-gradient(135deg,#161226,#31205A)','linear-gradient(135deg,#F1D7C4,#C8D7E8)','linear-gradient(135deg,#0B1B24,#16374B)'];
    setSectionBackgrounds((prev) => {
      const current = prev[id] || '';
      const index = choices.indexOf(current);
      return { ...prev, [id]: choices[(index + 1) % choices.length] };
    });
  };

  const generateAI = async (sectionId: string) => {
    setIsGenerating(true);
    await new Promise((r) => setTimeout(r, 1600));
    const templates = AI_TEMPLATES[sectionId] || AI_TEMPLATES.hero;
    setSectionContent((prev) => ({ ...prev, [sectionId]: templates[Math.floor(Math.random() * templates.length)] }));
    setIsGenerating(false);
  };

  const layout = (id: string): Layout => sectionLayouts[id] || '1col';
  const typo = (id: string): Typo => sectionTypos[id] || 'editorial';

  const maxWidth = (id: string) => layout(id) === 'fullbleed' ? '100%' : layout(id) === '2col' ? '1100px' : '760px';

  const headingStyle = (id: string, size = 40): React.CSSProperties => ({
    fontFamily: typo(id) === 'editorial' ? 'Inter, sans-serif' : 'Cormorant Garamond, serif',
    fontSize: `${size}px`,
    fontWeight: typo(id) === 'editorial' ? 800 : 300,
    fontStyle: typo(id) === 'editorial' ? 'normal' : 'italic',
    textTransform: typo(id) === 'editorial' ? 'uppercase' : 'none',
    letterSpacing: typo(id) === 'editorial' ? '-0.02em' : '0.02em',
    color: 'inherit',
    margin: 0,
  });

  const Section: React.FC<{
    id: string;
    bg?: string;
    color?: string;
    children: React.ReactNode;
    padH?: number;
    padV?: number;
    minH?: string;
  }> = ({ id, bg = '#fff', color = '#000', children, padH = 60, padV = 80, minH }) => {
    const isActive = activeSection === id;
    const isHidden = hiddenSections.has(id);

    return (
      <section
        data-section-id={id}
        onClick={(e) => { e.stopPropagation(); setActiveSection(id); }}
        style={{
          background: sectionBackgrounds[id] || bg,
          color,
          padding: `${padV}px ${padH}px`,
          position: 'relative',
          outline: isActive ? '3px solid rgba(196,149,106,0.7)' : '3px solid transparent',
          outlineOffset: '-3px',
          opacity: isHidden ? 0.25 : 1,
          transition: 'outline 0.2s, opacity 0.3s',
          minHeight: minH,
          cursor: 'default',
          order: sectionOrder.indexOf(id),
        }}
      >
        {isActive && (
          <div style={{
            position: 'absolute', top: 10, right: 12, zIndex: 5,
            background: 'rgba(196,149,106,0.9)', borderRadius: '50px',
            padding: '4px 10px', display: 'flex', alignItems: 'center', gap: '5px',
          }}>
            <Edit2 size={10} color="#fff" />
            <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, color: '#fff', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              {SECTION_NAMES[id] || id}
            </span>
          </div>
        )}
        {children}
      </section>
    );
  };

  const sectionDesc = (id: string, defaultText: string) =>
    sectionContent[id] || defaultText;

  const ContentDesc: React.FC<{ id: string; default: string; light?: boolean }> = ({ id, default: def, light }) => (
    <p
      contentEditable
      suppressContentEditableWarning
      onClick={(event) => { event.stopPropagation(); setActiveSection(id); }}
      onBlur={(event) => setSectionContent((prev) => ({ ...prev, [id]: event.currentTarget.textContent || def }))}
      style={{
      fontFamily: 'Cormorant Garamond, serif',
      fontSize: '17px',
      fontStyle: 'italic',
      color: light ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.45)',
      margin: '12px 0 36px',
      lineHeight: 1.7,
      maxWidth: '560px',
    }}>
      {sectionDesc(id, def)}
    </p>
  );

  const IndexLabel: React.FC<{ n: number; light?: boolean }> = ({ n, light }) => (
    <p style={{
      fontFamily: 'Inter',
      fontSize: '10px',
      fontWeight: 700,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: light ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)',
      marginBottom: '8px',
    }}>
      {String(n).padStart(2, '0')}
    </p>
  );

  return (
    <div
      data-lma-minisite
      data-cover={coverVariant}
      style={{ position: embedded ? 'absolute' : 'fixed', inset: 0, paddingTop: embedded ? 0 : '52px', background: coverVariant === 'editorial' ? '#F5EFE7' : coverVariant === 'essential' ? '#F8F9FC' : '#fff', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}
      onClick={() => setActiveSection(null)}
    >
      <style>{`
        [data-lma-minisite][data-cover="editorial"] [data-section-id="hero"]{background:linear-gradient(155deg,#2B1D25,#6C443D)!important}
        [data-lma-minisite][data-cover="editorial"] [data-section-id="programme"],
        [data-lma-minisite][data-cover="editorial"] [data-section-id="rsvp"]{background:#F7F1E9!important}
        [data-lma-minisite][data-cover="editorial"] [data-section-id="venue"]{background:#EFE2D4!important}
        [data-lma-minisite][data-cover="editorial"] h1,
        [data-lma-minisite][data-cover="editorial"] h2{font-family:'Cormorant Garamond',serif!important;font-weight:400!important;font-style:italic!important;text-transform:none!important;letter-spacing:-.025em!important}
        [data-lma-minisite][data-cover="editorial"] section{border-radius:0!important}
        [data-lma-minisite][data-cover="immersive"] [data-section-id="hero"]{background:radial-gradient(circle at 74% 22%,rgba(255,180,108,.55),transparent 22%),linear-gradient(150deg,#090B18,#402565 62%,#071621)!important}
        [data-lma-minisite][data-cover="immersive"] [data-section-id="music"]{background:radial-gradient(circle at 22% 20%,rgba(139,92,246,.35),transparent 25%),linear-gradient(160deg,#090A18,#21143B)!important}
        [data-lma-minisite][data-cover="immersive"] section{box-shadow:inset 0 1px 0 rgba(255,255,255,.05)}
        [data-lma-minisite][data-cover="immersive"] h1{letter-spacing:-.06em!important;text-shadow:0 18px 60px rgba(0,0,0,.45)}
        [data-lma-minisite][data-cover="essential"] *{animation:none!important;transition:none!important}
        [data-lma-minisite][data-cover="essential"] [data-section-id="hero"]{background:linear-gradient(145deg,#FFFFFF,#E9ECF7)!important;color:#111318!important;min-height:68vh!important}
        [data-lma-minisite][data-cover="essential"] [data-section-id="hero"] h1,
        [data-lma-minisite][data-cover="essential"] [data-section-id="hero"] p{color:#111318!important;text-shadow:none!important}
        [data-lma-minisite][data-cover="essential"] [data-section-id="music"]{background:#111318!important}
        [data-lma-minisite][data-cover="essential"] section{padding-top:56px!important;padding-bottom:56px!important}
        [data-lma-minisite][data-cover="essential"] h1,
        [data-lma-minisite][data-cover="essential"] h2{font-family:Inter,sans-serif!important;font-style:normal!important;font-weight:800!important;letter-spacing:-.04em!important}
      `}</style>
      {/* Sticky mini-site nav */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: coverVariant === 'immersive' ? 'rgba(10,9,18,.94)' : coverVariant === 'editorial' ? 'rgba(247,241,233,.96)' : 'rgba(255,255,255,0.96)', backdropFilter: 'blur(16px)',
        borderBottom: coverVariant === 'immersive' ? '1px solid rgba(255,255,255,.1)' : '1px solid rgba(0,0,0,0.07)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 40px', height: '44px',
      }}
      onClick={(e) => e.stopPropagation()}
      >
        <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: coverVariant === 'immersive' ? 'rgba(255,255,255,.48)' : 'rgba(0,0,0,0.35)' }}>
          Le Monde Aime
        </span>
        <span style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '15px', fontStyle: 'italic', color: coverVariant === 'immersive' ? 'rgba(255,255,255,.82)' : 'rgba(0,0,0,0.7)' }}>
          {displayCoupleName}
        </span>
        <div style={{ display: 'flex', gap: '20px' }}>
          {[['programme', 'Programme'], ['venue', 'Lieu'], ['team', 'Équipe'], ['music', 'Musique']].map(([id, label]) => (
            <a
              key={id}
              href={`#ms-${id}`}
              onClick={(e) => e.stopPropagation()}
              style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', color: coverVariant === 'immersive' ? 'rgba(255,255,255,.55)' : 'rgba(0,0,0,0.45)', textDecoration: 'none' }}
            >
              {label}
            </a>
          ))}
        </div>
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>

        {/* ── HERO ── */}
        {!hiddenSections.has('hero') && (
          <Section id="hero" bg="linear-gradient(160deg,#0e0e1a 0%,#1a1030 40%,#0a1a2e 100%)" color="#fff" padV={120} minH="88vh">
            {heroPhoto && (
              <>
                {heroMediaType === 'video' || /\.(mp4|webm|mov)(\?|$)/i.test(heroPhoto) ? (
                  <video src={heroPhoto} autoPlay muted loop playsInline style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <img src={heroPhoto} alt="Visuel du mariage" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
                )}
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(160deg,rgba(5,4,15,.72),rgba(21,10,42,.55),rgba(3,16,30,.7))' }} />
              </>
            )}
            <div style={{ maxWidth: '900px', margin: '0 auto', textAlign: 'center', position: 'relative', zIndex: 1 }}>
              <p contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('hero'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'hero-date': event.currentTarget.textContent || displayDate }))} style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: '16px', outline: 'none' }}>
                {displayDate}
              </p>
              <h1 contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('hero'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'hero-title': event.currentTarget.textContent || displayCoupleName }))} style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 'clamp(40px, 8vw, 88px)',
                fontWeight: 800,
                textTransform: 'uppercase',
                letterSpacing: '-0.03em',
                color: '#fff',
                lineHeight: 0.95,
                margin: 0,
              }}>
                {displayCoupleName}
              </h1>
              {displayVenue && (
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '20px', fontStyle: 'italic', color: 'rgba(255,255,255,0.5)', marginTop: '20px' }}>
                  <span contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('hero'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'hero-venue': event.currentTarget.textContent || displayVenue }))}>{displayVenue}</span>
                </p>
              )}
              <ContentDesc id="hero" default="Une journée d'amour et de lumière, partagée avec ceux qui nous sont chers." light />
              <div style={{ width: '32px', height: '1px', background: 'rgba(255,255,255,0.25)', margin: '0 auto' }} />
            </div>
          </Section>
        )}

        {/* ── PROGRAMME ── */}
        {programmeCards.length > 0 && !hiddenSections.has('programme') && (
          <Section id="programme" bg="#FAFAF8" padV={80}>
            <div id="ms-programme" style={{ maxWidth: maxWidth('programme'), margin: '0 auto' }}>
              <IndexLabel n={1} />
              <h2 contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('programme'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'programme-title': event.currentTarget.textContent || 'Programme' }))} style={{ ...headingStyle('programme', 38), outline: 'none' }}>{sectionContent['programme-title'] || 'Programme'}</h2>
              <ContentDesc id="programme" default="Chaque instant soigneusement pensé pour vous." />

              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {programmeCards.map((card, idx) => {
                  const s = cardSettings[card.id] || {};
                  const CardIcon = ICON_MAP[card.icon];
                  return (
                    <div key={card.id} style={{ display: 'flex', gap: '20px', padding: '20px 0', borderBottom: idx < programmeCards.length - 1 ? '1px solid rgba(0,0,0,0.07)' : 'none' }}>
                      <div style={{ width: '52px', flexShrink: 0 }}>
                        <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          {CardIcon && <CardIcon size={16} color="rgba(0,0,0,0.45)" strokeWidth={1.8} />}
                        </div>
                        {s.time && (
                          <p style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, color: '#C4956A', margin: '6px 0 0', letterSpacing: '0.04em' }}>{s.time}</p>
                        )}
                      </div>
                      <div style={{ flex: 1 }}>
                        <h3 style={{ fontFamily: 'Inter', fontSize: '15px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.02em', color: '#000', margin: '0 0 4px' }}>
                          {card.name}
                        </h3>
                        <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '14px', fontStyle: 'italic', color: 'rgba(0,0,0,0.45)', margin: 0 }}>
                          {s.lieu || card.subtitle}
                        </p>
                        {s.notes && (
                          <p style={{ fontFamily: 'Inter', fontSize: '12px', color: 'rgba(0,0,0,0.4)', margin: '6px 0 0', lineHeight: 1.5 }}>{s.notes}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Section>
        )}

        {/* ── LIEU ── */}
        {venueCards.length > 0 && !hiddenSections.has('venue') && (
          <Section id="venue" bg="#fff" padV={80}>
            <div id="ms-venue" style={{ maxWidth: maxWidth('venue'), margin: '0 auto' }}>
              <IndexLabel n={2} />
              <h2 contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('venue'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'venue-title': event.currentTarget.textContent || 'Le Lieu' }))} style={{ ...headingStyle('venue', 38), outline: 'none' }}>{sectionContent['venue-title'] || 'Le Lieu'}</h2>
              <ContentDesc id="venue" default="Un cadre d'exception pour célébrer votre amour." />

              <div style={{ display: 'grid', gridTemplateColumns: layout('venue') === '2col' ? 'repeat(2, 1fr)' : 'repeat(auto-fill, minmax(300px, 1fr))', gap: '24px' }}>
                {venueCards.map((card) => {
                  const s = cardSettings[card.id] || {};
                  return (
                    <div key={card.id} style={{ borderRadius: '16px', overflow: 'hidden', boxShadow: '0 4px 28px rgba(0,0,0,0.08)' }}>
                      <div style={{ height: '220px', background: card.image ? `url(${card.image}) center/cover` : card.gradient, backgroundSize: 'cover' }} />
                      <div style={{ padding: '22px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '6px' }}>
                          <MapPin size={12} color="rgba(0,0,0,0.35)" />
                          <p style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'rgba(0,0,0,0.35)', margin: 0 }}>{card.subtitle}</p>
                        </div>
                        <h3 style={{ fontFamily: 'Inter', fontSize: '18px', fontWeight: 800, textTransform: 'uppercase', color: '#000', margin: '0 0 6px' }}>
                          {s.nom || card.name}
                        </h3>
                        {s.adresse && (
                          <p style={{ fontFamily: 'Inter', fontSize: '12px', color: 'rgba(0,0,0,0.45)', margin: 0 }}>{s.adresse}</p>
                        )}
                        {s.capacite && (
                          <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.35)', margin: '6px 0 0', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <Users size={11} /> {s.capacite} invités
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Section>
        )}

        {/* ── ÉQUIPE ── */}
        {vendorCards.length > 0 && !hiddenSections.has('team') && (
          <Section id="team" bg="#F4F2EE" padV={80}>
            <div id="ms-team" style={{ maxWidth: maxWidth('team'), margin: '0 auto' }}>
              <IndexLabel n={3} />
              <h2 contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('team'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'team-title': event.currentTarget.textContent || 'Notre Équipe' }))} style={{ ...headingStyle('team', 38), outline: 'none' }}>{sectionContent['team-title'] || 'Notre Équipe'}</h2>
              <ContentDesc id="team" default="Des artisans du bonheur, sélectionnés pour leur excellence." />

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '16px' }}>
                {vendorCards.map((card) => {
                  const s = cardSettings[card.id] || {};
                  const CardIcon = ICON_MAP[card.icon];
                  return (
                    <div key={card.id} style={{ borderRadius: '12px', overflow: 'hidden', background: '#fff', boxShadow: '0 2px 16px rgba(0,0,0,0.06)' }}>
                      <div style={{ height: '150px', background: card.image ? `url(${card.image}) center/cover` : card.gradient, backgroundSize: 'cover', position: 'relative' }}>
                        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.4) 100%)' }} />
                      </div>
                      <div style={{ padding: '14px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '4px' }}>
                          {CardIcon && <CardIcon size={11} color="rgba(0,0,0,0.35)" />}
                          <p style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: 'rgba(0,0,0,0.35)', margin: 0 }}>{card.subtitle}</p>
                        </div>
                        <h4 style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.02em', color: '#000', margin: 0, lineHeight: 1.2 }}>
                          {s.nom || card.name}
                        </h4>
                        {s.tel && <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(0,0,0,0.4)', margin: '4px 0 0' }}>{s.tel}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Section>
        )}

        {/* ── MUSIQUE ── */}
        {musicCards.length > 0 && !hiddenSections.has('music') && (
          <Section id="music" bg="linear-gradient(160deg,#0e0e1a 0%,#1a1030 100%)" color="#fff" padV={80}>
            <div id="ms-music" style={{ maxWidth: maxWidth('music'), margin: '0 auto' }}>
              <IndexLabel n={4} light />
              <h2 contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('music'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'music-title': event.currentTarget.textContent || 'La Playlist' }))} style={{ ...headingStyle('music', 38), color: '#fff', outline: 'none' }}>{sectionContent['music-title'] || 'La Playlist'}</h2>
              <ContentDesc id="music" default="La musique qui bercera votre amour et fera danser vos invités." light />

              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', marginTop: '8px' }}>
                {musicCards.map((card, idx) => {
                  const s = cardSettings[card.id] || {};
                  const playlist: Array<{ title: string; artist: string }> = s.playlist || [];
                  return (
                    <div key={card.id}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '14px', padding: '12px 14px', background: 'rgba(255,255,255,0.05)', borderRadius: '8px', marginBottom: '2px' }}>
                        <div style={{ width: '32px', height: '32px', borderRadius: '6px', background: card.gradient, flexShrink: 0 }} />
                        <div style={{ flex: 1 }}>
                          <p style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 700, color: '#fff', margin: 0 }}>{card.name}</p>
                          <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '12px', fontStyle: 'italic', color: 'rgba(255,255,255,0.4)', margin: 0 }}>{card.subtitle}</p>
                        </div>
                        <Music2 size={14} color="rgba(255,255,255,0.25)" />
                      </div>
                      {playlist.map((track, ti) => (
                        <div key={ti} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '8px 14px 8px 60px' }}>
                          <span style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(255,255,255,0.2)', width: '20px', flexShrink: 0, textAlign: 'right' }}>{ti + 1}</span>
                          <span style={{ fontFamily: 'Inter', fontSize: '12px', color: 'rgba(255,255,255,0.7)', flex: 1 }}>{track.title}</span>
                          <span style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '11px', fontStyle: 'italic', color: 'rgba(255,255,255,0.35)' }}>{track.artist}</span>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>
          </Section>
        )}

        {/* ── RSVP ── */}
        {!hiddenSections.has('rsvp') && (
          <Section id="rsvp" bg="#fff" padV={80}>
            <div style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
              <IndexLabel n={5} />
              <h2 contentEditable suppressContentEditableWarning onClick={(event) => { event.stopPropagation(); setActiveSection('rsvp'); }} onBlur={(event) => setSectionContent((prev) => ({ ...prev, 'rsvp-title': event.currentTarget.textContent || 'RSVP' }))} style={{ ...headingStyle('rsvp', 38), outline: 'none' }}>{sectionContent['rsvp-title'] || 'RSVP'}</h2>
              <ContentDesc id="rsvp" default="Votre présence est notre plus beau cadeau. Confirmez votre venue." />
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '16px' }}>
                <input value={rsvp.name} onChange={(e) => setRsvp((v) => ({ ...v, name: e.target.value }))} placeholder="Prénom & Nom" style={{ padding: '13px 16px', borderRadius: '10px', border: '1.5px solid rgba(0,0,0,0.1)', fontFamily: 'Inter', fontSize: '13px', color: 'rgba(0,0,0,0.7)', outline: 'none', background: '#fafafa' }} />
                <input value={rsvp.email} onChange={(e) => setRsvp((v) => ({ ...v, email: e.target.value }))} type="email" placeholder="Email" style={{ padding: '13px 16px', borderRadius: '10px', border: '1.5px solid rgba(0,0,0,0.1)', fontFamily: 'Inter', fontSize: '13px', color: 'rgba(0,0,0,0.7)', outline: 'none', background: '#fafafa' }} />
                <input value={rsvp.count} onChange={(e) => setRsvp((v) => ({ ...v, count: e.target.value }))} type="number" min={1} placeholder="Nombre de personnes" style={{ padding: '13px 16px', borderRadius: '10px', border: '1.5px solid rgba(0,0,0,0.1)', fontFamily: 'Inter', fontSize: '13px', color: 'rgba(0,0,0,0.7)', outline: 'none', background: '#fafafa' }} />
                <button onClick={() => { if (!rsvp.name || !rsvp.email) { toast.error('Indiquez votre nom et votre email.'); return; } const existing = JSON.parse(getProjectItem('lma_rsvp_responses') || '[]'); setProjectItem('lma_rsvp_responses', JSON.stringify([...existing, { ...rsvp, createdAt: new Date().toISOString() }])); toast.success('Votre présence est confirmée.'); }} style={{ padding: '14px', background: '#000', color: '#fff', border: 'none', borderRadius: '10px', fontFamily: 'Inter', fontSize: '12px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer' }}>
                  Confirmer ma présence
                </button>
              </div>
            </div>
          </Section>
        )}

        {/* ── FOOTER ── */}
        {!hiddenSections.has('footer') && (
          <Section id="footer" bg="#000" color="#fff" padV={60}>
            <div style={{ textAlign: 'center' }}>
              <p style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.3)', marginBottom: '14px' }}>Le Monde Aime</p>
              <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '24px', fontStyle: 'italic', color: 'rgba(255,255,255,0.75)', margin: 0 }}>{displayCoupleName}</p>
              <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.3)', marginTop: '8px' }}>{displayDate}</p>
            </div>
          </Section>
        )}

        {/* Bottom padding */}
        <div style={{ height: '80px', order: 999 }} />
      </div>

      {/* ── Bottom editing toolbar ── */}
      {activeSection && (
        <motion.div
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 60, opacity: 0 }}
          style={{
            position: embedded ? 'absolute' : 'fixed',
            top: embedded ? 56 : 64,
            right: 12,
            width: '220px',
            maxHeight: embedded ? 'calc(100% - 72px)' : 'calc(100vh - 80px)',
            overflowY: 'auto',
            background: 'rgba(8,8,12,0.97)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '14px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'stretch',
            padding: '12px',
            gap: '6px',
            boxShadow: '0 18px 50px rgba(0,0,0,.35)',
            zIndex: 300,
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Section label */}
          <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, color: '#C4956A', letterSpacing: '0.09em', textTransform: 'uppercase', marginBottom: '5px', flexShrink: 0 }}>
            {SECTION_NAMES[activeSection] || activeSection}
          </span>

          {/* Layout cycles */}
          <ToolbarBtn
            icon={<Layers size={13} />}
            label={layout(activeSection) === '1col' ? '1 Col' : layout(activeSection) === '2col' ? '2 Col' : 'Plein'}
            onClick={() => setSectionLayouts((prev) => {
              const cur = prev[activeSection] || '1col';
              const next = cur === '1col' ? '2col' : cur === '2col' ? 'fullbleed' : '1col';
              return { ...prev, [activeSection]: next };
            })}
          />

          {/* Typo toggle */}
          <ToolbarBtn
            icon={<Type size={13} />}
            label={typo(activeSection) === 'editorial' ? 'Éditorial' : 'Serif'}
            onClick={() => setSectionTypos((prev) => ({
              ...prev,
              [activeSection]: prev[activeSection] === 'editorial' ? 'modern' : 'editorial',
            }))}
          />
          <ToolbarBtn icon={<Palette size={13} />} label="Couleur" onClick={() => cycleSectionBackground(activeSection)} />

          <Sep />

          {/* AI Generate */}
          <button
            onClick={() => generateAI(activeSection)}
            disabled={isGenerating}
            style={{
              display: 'flex', alignItems: 'center', gap: '6px',
              padding: '7px 13px', borderRadius: '8px',
              background: isGenerating ? 'rgba(196,149,106,0.3)' : 'rgba(196,149,106,0.85)',
              border: 'none',
              cursor: isGenerating ? 'default' : 'pointer',
              color: '#fff',
              fontFamily: 'Inter', fontSize: '11px', fontWeight: 600,
              letterSpacing: '0.04em',
              flexShrink: 0,
            }}
          >
            {isGenerating ? (
              <motion.span animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 0.9, ease: 'linear' }} style={{ display: 'flex' }}>
                <Loader2 size={13} />
              </motion.span>
            ) : (
              <Wand2 size={13} />
            )}
            {isGenerating ? 'Génération…' : 'Générer le texte'}
          </button>

          <Sep />

          {/* Move up/down */}
          <ToolbarBtn icon={<ChevronUp size={13} />} label="" onClick={() => moveSection(activeSection, -1)} />
          <ToolbarBtn icon={<ChevronDown size={13} />} label="" onClick={() => moveSection(activeSection, 1)} />

          <Sep />

          {/* Show/hide */}
          <ToolbarBtn
            icon={hiddenSections.has(activeSection) ? <Eye size={13} /> : <EyeOff size={13} />}
            label={hiddenSections.has(activeSection) ? 'Afficher' : 'Masquer'}
            onClick={() => toggleHidden(activeSection)}
          />
        </motion.div>
      )}
    </div>
  );
};

const ToolbarBtn: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void }> = ({ icon, label, onClick }) => (
  <button
    onClick={onClick}
    style={{
      display: 'flex', alignItems: 'center', gap: label ? '5px' : 0,
      padding: label ? '8px 10px' : '8px 10px',
      borderRadius: '8px',
      background: 'rgba(255,255,255,0.06)',
      border: 'none',
      cursor: 'pointer',
      color: 'rgba(255,255,255,0.6)',
      fontFamily: 'Inter',
      fontSize: '11px',
      whiteSpace: 'nowrap', justifyContent: 'flex-start', width: '100%',
    }}
  >
    {icon}
    {label && label}
  </button>
);

const Sep = () => (
  <div style={{ height: '1px', width: '100%', background: 'rgba(255,255,255,0.08)', margin: '4px 0', flexShrink: 0 }} />
);
