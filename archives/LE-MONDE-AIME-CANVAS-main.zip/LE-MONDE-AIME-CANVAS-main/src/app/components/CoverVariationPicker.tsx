import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Check, Columns3, Sparkles, X } from 'lucide-react';
import type { CoverVariant, RemixTarget } from '../types';
import { useTheme } from '../contexts/ThemeContext';

export interface CoverPreset {
  id: Exclude<CoverVariant, 'original'>;
  name: string;
  subtitle: string;
  palette: string[];
  preview: React.CSSProperties;
  accent: string;
}

export const COVER_PRESETS: CoverPreset[] = [
  {
    id: 'editorial',
    name: 'Éditorial',
    subtitle: 'Hiérarchie forte, blanc cassé, rythme magazine',
    palette: ['#F4EFE7', '#271A22', '#A46845'],
    preview: { background: 'linear-gradient(145deg,#F7F1E9 0 58%,#291C24 58%)', color: '#241A20' },
    accent: '#A46845',
  },
  {
    id: 'immersive',
    name: 'Immersif',
    subtitle: 'Image, profondeur, lumière et contraste',
    palette: ['#090B18', '#442A73', '#FFB46A'],
    preview: { background: 'radial-gradient(circle at 72% 24%,rgba(255,177,102,.5),transparent 22%),linear-gradient(145deg,#0A0D1E,#3A245F 58%,#0A1724)', color: '#FFFFFF' },
    accent: '#FFB46A',
  },
  {
    id: 'essential',
    name: 'Essentiel',
    subtitle: 'Simple, accessible, mobile et très lisible',
    palette: ['#FFFFFF', '#111318', '#5B67F1'],
    preview: { background: 'linear-gradient(180deg,#FFFFFF,#EEF0F6)', color: '#111318' },
    accent: '#5B67F1',
  },
];

interface CoverVariationPickerProps {
  open: boolean;
  target: RemixTarget | null;
  current: CoverVariant;
  onApply: (variant: CoverVariant) => void;
  onClose: () => void;
}

export const CoverVariationPicker: React.FC<CoverVariationPickerProps> = ({ open, target, current, onApply, onClose }) => {
  const { isDark } = useTheme();
  const surface = isDark ? '#131218' : '#F8F7FA';
  const text = isDark ? '#F8F7FB' : '#17161B';
  const muted = isDark ? 'rgba(248,247,251,.48)' : 'rgba(23,22,27,.52)';
  const border = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)';

  return (
    <AnimatePresence>
      {open && target && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onMouseDown={(event) => event.target === event.currentTarget && onClose()}
          style={{ position: 'fixed', inset: 0, zIndex: 1500, background: 'rgba(3,3,8,.66)', backdropFilter: 'blur(16px)', display: 'grid', placeItems: 'center', padding: 28 }}
        >
          <motion.div
            initial={{ y: 24, scale: .97, opacity: 0 }} animate={{ y: 0, scale: 1, opacity: 1 }} exit={{ y: 18, scale: .98, opacity: 0 }}
            style={{ width: 'min(1060px,94vw)', maxHeight: '88vh', overflow: 'auto', borderRadius: 24, background: surface, color: text, border: `1px solid ${border}`, boxShadow: '0 40px 120px rgba(0,0,0,.5)' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '20px 22px', borderBottom: `1px solid ${border}` }}>
              <span style={{ width: 38, height: 38, borderRadius: 12, display: 'grid', placeItems: 'center', background: 'linear-gradient(135deg,#7C3AED,#EC4899)', color: '#fff' }}><Sparkles size={18} /></span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 850 }}>Créer un Cover</div>
                <div style={{ marginTop: 3, fontSize: 9.5, color: muted }}>Même contenu et mêmes connexions, trois expressions visuelles pour « {target.label} ».</div>
              </div>
              <button onClick={onClose} style={{ width: 34, height: 34, borderRadius: 10, border: 0, background: 'transparent', color: muted, cursor: 'pointer' }}><X size={17} /></button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 14, padding: 20 }}>
              {COVER_PRESETS.map((preset) => {
                const active = current === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => onApply(preset.id)}
                    style={{ padding: 0, borderRadius: 18, overflow: 'hidden', border: active ? `2px solid ${preset.accent}` : `1px solid ${border}`, background: isDark ? '#1A191F' : '#fff', color: 'inherit', cursor: 'pointer', textAlign: 'left', boxShadow: active ? `0 0 0 5px ${preset.accent}18` : '0 12px 34px rgba(0,0,0,.08)' }}
                  >
                    <div style={{ height: 310, padding: 18, boxSizing: 'border-box', ...preset.preview, position: 'relative', overflow: 'hidden' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 7.5, fontWeight: 800, letterSpacing: '.12em', textTransform: 'uppercase', opacity: .55 }}><span>Le Monde Aime</span><span>Cover</span></div>
                      <div style={{ marginTop: 58, maxWidth: '82%' }}>
                        <div style={{ fontSize: preset.id === 'editorial' ? 34 : preset.id === 'immersive' ? 29 : 25, lineHeight: .95, fontWeight: preset.id === 'editorial' ? 450 : 850, fontFamily: preset.id === 'editorial' ? 'Cormorant Garamond,serif' : 'Inter,sans-serif', fontStyle: preset.id === 'editorial' ? 'italic' : 'normal', letterSpacing: preset.id === 'immersive' ? '-.05em' : '-.025em' }}>{target.label}</div>
                        <div style={{ marginTop: 13, fontSize: 9, lineHeight: 1.45, opacity: .56 }}>Une composition générée depuis le même ADN de contenu.</div>
                      </div>
                      <div style={{ position: 'absolute', left: 18, right: 18, bottom: 18, display: 'grid', gridTemplateColumns: preset.id === 'essential' ? '1fr' : '1.1fr .9fr', gap: 8 }}>
                        <div style={{ height: 66, borderRadius: preset.id === 'essential' ? 12 : 3, background: preset.id === 'editorial' ? '#C99773' : preset.id === 'immersive' ? 'rgba(255,255,255,.14)' : '#E4E7F2', border: '1px solid rgba(127,127,127,.14)' }} />
                        {preset.id !== 'essential' && <div style={{ height: 66, borderRadius: preset.id === 'immersive' ? 22 : 3, background: preset.id === 'editorial' ? '#2B1C24' : 'rgba(255,177,106,.45)' }} />}
                      </div>
                    </div>
                    <div style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ width: 30, height: 30, borderRadius: 10, display: 'grid', placeItems: 'center', background: `${preset.accent}18`, color: preset.accent }}><Columns3 size={14} /></span>
                      <span style={{ flex: 1 }}><strong style={{ display: 'block', fontSize: 11.5 }}>{preset.name}</strong><span style={{ display: 'block', marginTop: 3, fontSize: 8.3, lineHeight: 1.35, color: muted }}>{preset.subtitle}</span></span>
                      {active && <span style={{ width: 24, height: 24, borderRadius: 999, display: 'grid', placeItems: 'center', background: preset.accent, color: '#fff' }}><Check size={13} /></span>}
                    </div>
                  </button>
                );
              })}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '14px 22px 20px' }}>
              <button onClick={() => onApply('original')} style={{ height: 38, padding: '0 14px', borderRadius: 10, border: `1px solid ${border}`, background: 'transparent', color: muted, cursor: 'pointer', fontSize: 10, fontWeight: 700 }}>Revenir à l’original</button>
              <div style={{ fontSize: 8.8, color: muted }}>Chaque choix est enregistré dans la généalogie et peut être annulé.</div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
