import React, { useRef, useState } from 'react';
import { Eye, GripVertical, LayoutTemplate, Lock, MoreHorizontal, Trash2, Unlock } from 'lucide-react';
import { ICON_MAP } from '../utils/iconMap';
import { CardStack, getCardLayoutSize } from './CardStack';
import type { CanvasPoint, CardLayoutMode, Tool, WeddingLot } from '../types';
import type { AnimationSettings } from './SettingsPanel';

interface LotGroupProps {
  lot: WeddingLot;
  position: CanvasPoint;
  canvasScale: number;
  layoutMode: CardLayoutMode;
  activeTool: Tool;
  selected: boolean;
  locked: boolean;
  zIndex?: number;
  snapEnabled?: boolean;
  gridSize?: number;
  onSelect: () => void;
  onPositionChange: (position: CanvasPoint) => void;
  onDelete: () => void;
  onToggleLock: () => void;
  onPreview?: () => void;
  onCompose?: () => void;
  onOpenMenu?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  cardSettings: Record<string, Record<string, any>>;
  onCardSettingChange: (cardId: string, key: string, value: unknown) => void;
  animSettings: AnimationSettings;
  playingTrackId: string | null;
  onTogglePlay: (cardId: string) => void;
  globalTexture?: string;
}

export const LotGroup: React.FC<LotGroupProps> = ({
  lot,
  position,
  canvasScale,
  layoutMode,
  activeTool,
  selected,
  locked,
  zIndex = 80,
  snapEnabled = true,
  gridSize = 28,
  onSelect,
  onPositionChange,
  onDelete,
  onToggleLock,
  onPreview,
  onCompose,
  onOpenMenu,
  cardSettings,
  onCardSettingChange,
  animSettings,
  playingTrackId,
  onTogglePlay,
  globalTexture,
}) => {
  const [dragging, setDragging] = useState(false);
  const dragRef = useRef<{
    pointerId: number;
    clientX: number;
    clientY: number;
    origin: CanvasPoint;
  } | null>(null);

  const configuredCount = lot.cards.filter(
    (card) => Object.keys(cardSettings[card.id] || {}).some((key) => {
      const value = cardSettings[card.id][key];
      return value && value !== '' && value !== false && value !== 0;
    })
  ).length;

  const LotIcon = ICON_MAP[lot.icon] ?? ICON_MAP.Sparkles;
  const size = getCardLayoutSize(lot.cards.length, layoutMode);
  const headerWidth = Math.max(323, Math.min(size.width, 620));

  const beginDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    event.stopPropagation();
    event.preventDefault();
    onSelect();
    if (locked || activeTool !== 'select') return;
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      pointerId: event.pointerId,
      clientX: event.clientX,
      clientY: event.clientY,
      origin: position,
    };
    setDragging(true);
  };

  const moveDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    event.stopPropagation();
    const scale = Math.max(0.15, canvasScale || 1);
    const rawX = drag.origin.x + (event.clientX - drag.clientX) / scale;
    const rawY = drag.origin.y + (event.clientY - drag.clientY) / scale;
    onPositionChange({
      x: snapEnabled ? Math.round(rawX / gridSize) * gridSize : rawX,
      y: snapEnabled ? Math.round(rawY / gridSize) * gridSize : rawY,
    });
  };

  const endDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (dragRef.current?.pointerId !== event.pointerId) return;
    event.stopPropagation();
    dragRef.current = null;
    setDragging(false);
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch { /* no-op */ }
  };

  return (
    <div
      data-canvas-object
      style={{
        position: 'absolute', left: position.x, top: position.y,
        width: `${Math.max(360, size.width)}px`,
        minHeight: size.height + 72,
        outline: selected ? '2px solid #D4D4D8' : '1px solid transparent',
        outlineOffset: 8,
        borderRadius: 18,
        zIndex,
        transition: dragging ? 'none' : 'left 0.2s cubic-bezier(.2,.8,.2,1), top 0.2s cubic-bezier(.2,.8,.2,1), outline-color .15s',
      }}
      onMouseDown={(event) => event.stopPropagation()}
      onClick={(event) => { event.stopPropagation(); onSelect(); }}
    >
      {selected && (
        <div
          onPointerDown={(event) => { event.stopPropagation(); }}
          style={{ position: 'absolute', top: -42, right: 0, zIndex: 20, display: 'flex', gap: 2, padding: 5, borderRadius: 11, background: '#1B1B1D', color: '#fff', boxShadow: '0 10px 28px rgba(0,0,0,.3)' }}
        >
          {onPreview && <LotControl title="Aperçu vivant" onClick={onPreview}><Eye size={12} /></LotControl>}
          {onCompose && <LotControl title="Mise en page" onClick={onCompose}><LayoutTemplate size={12} /></LotControl>}
          {onOpenMenu && <button type="button" title="Remix, éditer, relier, publier et gérer" onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onOpenMenu(event); }} style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><MoreHorizontal size={14} /></button>}
          <LotControl title={locked ? 'Déverrouiller le lot' : 'Verrouiller le lot'} onClick={onToggleLock}>
            {locked ? <Unlock size={12} /> : <Lock size={12} />}
          </LotControl>
          <LotControl title="Retirer le lot du canevas" onClick={onDelete}><Trash2 size={12} /></LotControl>
        </div>
      )}

      <div
        onPointerDown={beginDrag}
        onPointerMove={moveDrag}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        title={locked ? 'Lot verrouillé' : 'Déplacer tout le lot'}
        style={{
          width: `${headerWidth}px`, marginBottom: '20px', padding: '8px 8px 8px 4px',
          borderRadius: '12px', cursor: locked ? 'not-allowed' : activeTool === 'select' ? (dragging ? 'grabbing' : 'grab') : 'default', touchAction: 'none',
          background: dragging || selected ? 'rgba(255,255,255,0.11)' : 'rgba(10,10,18,0.18)',
          backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', gap: '8px', boxSizing: 'border-box',
          transition: 'background 0.15s ease',
        }}
      >
        <LotIcon size={13} color={lot.accentColor} strokeWidth={1.8} />
        <div style={{ minWidth: 0 }}>
          <h2 style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.92)', margin: 0, lineHeight: 1 }}>
            {lot.title}
          </h2>
          <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '13px', fontStyle: 'italic', color: 'rgba(255,255,255,0.38)', margin: '4px 0 0', letterSpacing: '0.02em' }}>
            {lot.subtitle}
          </p>
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '7px', flexShrink: 0 }}>
          {configuredCount > 0 && (
            <span style={{ fontFamily: 'Inter', fontSize: '10px', color: lot.accentColor, background: `${lot.accentColor}22`, borderRadius: '50px', padding: '2px 7px' }}>
              {configuredCount}/{lot.cards.length}
            </span>
          )}
          <span style={{ display: 'flex', alignItems: 'center', gap: '3px', fontFamily: 'Inter', fontSize: '8px', color: 'rgba(255,255,255,0.42)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
            <GripVertical size={13} /> {locked ? 'verrouillé' : 'déplacer'}
          </span>
        </div>
      </div>

      <CardStack
        cards={lot.cards}
        cardSettings={cardSettings}
        onCardSettingChange={onCardSettingChange}
        animSettings={animSettings}
        playingTrackId={playingTrackId}
        onTogglePlay={onTogglePlay}
        globalTexture={globalTexture}
        layoutMode={layoutMode}
      />
    </div>
  );
};

const LotControl: React.FC<{ title: string; onClick: () => void; children: React.ReactNode }> = ({ title, onClick, children }) => (
  <button
    type="button"
    title={title}
    onPointerDown={(event) => { event.stopPropagation(); }}
    onClick={(event) => { event.stopPropagation(); onClick(); }}
    style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', cursor: 'pointer', display: 'grid', placeItems: 'center' }}
  >
    {children}
  </button>
);
