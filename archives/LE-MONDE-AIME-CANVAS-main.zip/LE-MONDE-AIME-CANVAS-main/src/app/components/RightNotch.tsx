import React, { useState } from 'react';
import { Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { useTheme } from '../contexts/ThemeContext';

interface RightNotchProps {
  isOpen: boolean;
  onClick: () => void;
  selectedCount: number;
}

export const RightNotch: React.FC<RightNotchProps> = ({ isOpen, onClick, selectedCount }) => {
  const { isDark } = useTheme();
  const [hov, setHov] = useState(false);

  const bg = isOpen
    ? (isDark ? 'rgba(255,255,255,0.12)' : '#0F0F12')
    : hov
    ? (isDark ? 'rgba(30,27,48,0.98)' : 'rgba(255,255,255,1)')
    : (isDark ? 'rgba(13,12,24,0.94)' : 'rgba(255,255,255,0.96)');

  const color = isOpen
    ? (isDark ? '#F0EEF8' : '#FFFFFF')
    : (isDark ? 'rgba(240,238,248,0.6)' : 'rgba(15,15,18,0.6)');

  const border = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.1)';

  return (
    <motion.button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      title={isOpen ? 'Fermer l\'éditeur mini-site' : 'Ouvrir l\'éditeur mini-site'}
      style={{
        position: 'fixed',
        right: isOpen ? '340px' : '0px',
        top: '50%',
        transform: 'translateY(-50%)',
        zIndex: 140,
        width: hov && !isOpen ? '30px' : '24px',
        height: '80px',
        background: bg,
        border: `1px solid ${border}`,
        borderRight: isOpen ? `1px solid ${border}` : 'none',
        borderRadius: isOpen ? '8px 0 0 8px' : '8px 0 0 8px',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '6px',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        boxShadow: isDark ? '-4px 0 16px rgba(0,0,0,0.3)' : '-2px 0 12px rgba(0,0,0,0.06)',
        opacity: 1,
        transition: 'background 0.15s, color 0.15s, opacity 0.15s, border-color 0.15s',
      }}
      animate={{ right: isOpen ? 340 : 0 }}
      transition={{ type: 'spring', damping: 30, stiffness: 320 }}
    >
      <Globe size={11} color={color} />
      <span style={{
        fontFamily: 'Inter', fontSize: '7px', fontWeight: 800,
        letterSpacing: '0.12em', textTransform: 'uppercase',
        writingMode: 'vertical-rl', color, userSelect: 'none',
        transform: 'rotate(180deg)',
      }}>
        Site
      </span>
      {selectedCount > 0 && !isOpen && (
        <div style={{
          position: 'absolute', top: '6px', right: '3px',
          width: '14px', height: '14px', borderRadius: '50%',
          background: '#C4956A', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Inter', fontSize: '8px', fontWeight: 700, color: '#fff',
        }}>
          {selectedCount > 9 ? '9+' : selectedCount}
        </div>
      )}
    </motion.button>
  );
};
