import React from 'react';
import {
  ArrowUp,
  Crosshair,
  MoveHorizontal,
  Columns3,
  Grip,
  LayoutGrid,
  Layers3,
  RotateCcw,
  Rows3,
  Sparkles,
  X,
  Copy,
  Trash2,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  BringToFront,
  SendToBack,
  Magnet,
  Heart,
  BriefcaseBusiness,
} from 'lucide-react';
import type { CardLayoutMode, CanvasSelectionSummary, WorkspaceLayoutMode } from '../types';
import { useTheme } from '../contexts/ThemeContext';

interface LayoutPanelProps {
  activeLotTitle?: string;
  layoutMode: CardLayoutMode;
  onLayoutModeChange: (mode: CardLayoutMode) => void;
  workspaceMode: WorkspaceLayoutMode;
  onWorkspaceModeChange: (mode: WorkspaceLayoutMode) => void;
  onAutoArrange: () => void;
  onAlignTop: () => void;
  onAlignCenter: () => void;
  onDistributeHorizontal: () => void;
  onReset: () => void;
  snapEnabled: boolean;
  onToggleSnap: () => void;
  selectedObject?: CanvasSelectionSummary | null;
  onDuplicateObject?: () => void;
  onDeleteObject?: () => void;
  onToggleObjectLock?: () => void;
  onToggleObjectHidden?: () => void;
  onBringObjectFront?: () => void;
  onSendObjectBack?: () => void;
  hiddenEntries?: Array<'couple' | 'provider'>;
  onRestoreEntry?: (id: 'couple' | 'provider') => void;
  onClose: () => void;
}

const LOT_MODES: Array<{ id: CardLayoutMode; label: string; icon: React.ReactNode }> = [
  { id: 'stack', label: 'Pile', icon: <Layers3 size={15} /> },
  { id: 'mosaic', label: 'Mosaïque', icon: <LayoutGrid size={15} /> },
  { id: 'horizontal', label: 'Horizontal', icon: <Columns3 size={15} /> },
  { id: 'vertical', label: 'Vertical', icon: <Rows3 size={15} /> },
];

const WORKSPACE_MODES: Array<{ id: WorkspaceLayoutMode; label: string; icon: React.ReactNode }> = [
  { id: 'mosaic', label: 'Mosaïque', icon: <LayoutGrid size={15} /> },
  { id: 'horizontal', label: 'Horizontal', icon: <Columns3 size={15} /> },
  { id: 'vertical', label: 'Vertical', icon: <Rows3 size={15} /> },
];

export const LayoutPanel: React.FC<LayoutPanelProps> = ({
  activeLotTitle,
  layoutMode,
  onLayoutModeChange,
  workspaceMode,
  onWorkspaceModeChange,
  onAutoArrange,
  onAlignTop,
  onAlignCenter,
  onDistributeHorizontal,
  onReset,
  snapEnabled,
  onToggleSnap,
  selectedObject,
  onDuplicateObject,
  onDeleteObject,
  onToggleObjectLock,
  onToggleObjectHidden,
  onBringObjectFront,
  onSendObjectBack,
  hiddenEntries = [],
  onRestoreEntry,
  onClose,
}) => {
  const { isDark } = useTheme();
  const surface = isDark ? 'rgba(18,16,33,0.97)' : 'rgba(255,255,255,0.98)';
  const border = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
  const text = isDark ? '#F2F0F8' : '#111116';
  const muted = isDark ? 'rgba(242,240,248,0.5)' : 'rgba(17,17,22,0.52)';
  const control = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.045)';
  const active = isDark ? 'rgba(139,92,246,.24)' : 'rgba(139,92,246,.13)';

  return (
    <aside
      onMouseDown={(event) => event.stopPropagation()}
      onPointerDown={(event) => event.stopPropagation()}
      style={{
        position: 'fixed',
        left: '62px',
        top: '184px',
        width: '306px',
        maxHeight: 'calc(100vh - 205px)',
        overflowY: 'auto',
        zIndex: 230,
        borderRadius: '16px',
        padding: '14px',
        background: surface,
        border: `1px solid ${border}`,
        boxShadow: isDark ? '0 18px 60px rgba(0,0,0,0.45)' : '0 18px 60px rgba(0,0,0,0.16)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        color: text,
        fontFamily: 'Inter, sans-serif',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px' }}>
        <div>
          <div style={{ fontSize: '12px', fontWeight: 800, letterSpacing: '-0.01em' }}>Organiser le canevas</div>
          <div style={{ marginTop: '3px', fontSize: '10px', lineHeight: 1.4, color: muted }}>
            Tous les objets utilisent désormais les mêmes commandes.
          </div>
        </div>
        <button onClick={onClose} aria-label="Fermer" style={{ width: 26, height: 26, border: 'none', borderRadius: 7, background: control, color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
          <X size={13} />
        </button>
      </div>

      <SectionLabel>Magnétisme</SectionLabel>
      <button
        onClick={onToggleSnap}
        style={{
          width: '100%', border: `1px solid ${snapEnabled ? '#8B5CF6' : border}`, borderRadius: 10,
          background: snapEnabled ? active : control, color: text, padding: '9px 10px', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontFamily: 'Inter',
        }}
      >
        <span style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 10, fontWeight: 700 }}><Magnet size={14} /> Aimantation sur les points</span>
        <span style={{ fontSize: 8, opacity: .55 }}>{snapEnabled ? 'ACTIF · 28 px' : 'LIBRE'}</span>
      </button>

      <SectionLabel>Disposition de tous les objets</SectionLabel>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6 }}>
        {WORKSPACE_MODES.map((mode) => (
          <button
            key={mode.id}
            onClick={() => onWorkspaceModeChange(mode.id)}
            style={{
              border: `1px solid ${workspaceMode === mode.id ? '#8B5CF6' : border}`,
              borderRadius: 10,
              padding: '9px 5px',
              background: workspaceMode === mode.id ? active : control,
              color: text,
              cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5,
              fontFamily: 'Inter', fontSize: 8.5, fontWeight: 650,
            }}
          >
            {mode.icon}{mode.label}
          </button>
        ))}
      </div>

      <button
        onClick={onAutoArrange}
        style={{
          marginTop: 7, width: '100%', border: `1px solid ${border}`, borderRadius: '10px', background: control,
          padding: '10px 11px', display: 'flex', alignItems: 'center', gap: '9px', cursor: 'pointer', color: text,
          fontFamily: 'Inter', textAlign: 'left',
        }}
      >
        <Sparkles size={15} />
        <span>
          <span style={{ display: 'block', fontSize: '11px', fontWeight: 700 }}>Ranger automatiquement</span>
          <span style={{ display: 'block', marginTop: '2px', fontSize: '9px', color: muted }}>Cartes d’entrée, lot, notes, frames et médias.</span>
        </span>
      </button>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px', marginTop: '7px' }}>
        <SmallAction icon={<ArrowUp size={14} />} label="Haut" onClick={onAlignTop} bg={control} border={border} color={text} />
        <SmallAction icon={<Crosshair size={14} />} label="Centrer" onClick={onAlignCenter} bg={control} border={border} color={text} />
        <SmallAction icon={<MoveHorizontal size={14} />} label="Distribuer" onClick={onDistributeHorizontal} bg={control} border={border} color={text} />
      </div>

      <SectionLabel>Disposition interne du lot</SectionLabel>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px' }}>
        {LOT_MODES.map((mode) => (
          <button
            key={mode.id}
            onClick={() => onLayoutModeChange(mode.id)}
            disabled={!activeLotTitle}
            style={{
              border: `1px solid ${layoutMode === mode.id && activeLotTitle ? '#8B5CF6' : border}`,
              borderRadius: '10px', padding: '9px 8px', background: layoutMode === mode.id && activeLotTitle ? active : control,
              color: activeLotTitle ? text : muted, opacity: activeLotTitle ? 1 : 0.5,
              cursor: activeLotTitle ? 'pointer' : 'not-allowed', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
              fontFamily: 'Inter', fontSize: '9px', fontWeight: layoutMode === mode.id ? 750 : 550,
            }}
          >
            {mode.icon}{mode.label}
          </button>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8, padding: '8px 9px', borderRadius: 9, background: control, color: muted }}>
        <Grip size={13} /><span style={{ fontSize: 8.5, lineHeight: 1.35 }}>{activeLotTitle ? `Lot actif : ${activeLotTitle}` : 'Ouvrez un lot dans le menu pour organiser ses cartes.'}</span>
      </div>

      {selectedObject && (
        <>
          <SectionLabel>Objet sélectionné</SectionLabel>
          <div style={{ marginBottom: 7, padding: '8px 9px', borderRadius: 9, background: active, border: '1px solid rgba(139,92,246,.35)' }}>
            <div style={{ fontSize: 10, fontWeight: 800 }}>{selectedObject.label}</div>
            <div style={{ fontSize: 8, marginTop: 2, opacity: .48, textTransform: 'uppercase' }}>{selectedObject.kind}</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px' }}>
            <SmallAction disabled={!selectedObject.canDuplicate} icon={<Copy size={14} />} label="Dupliquer" onClick={() => onDuplicateObject?.()} bg={control} border={border} color={text} />
            <SmallAction icon={selectedObject.locked ? <Unlock size={14} /> : <Lock size={14} />} label={selectedObject.locked ? 'Ouvrir' : 'Bloquer'} onClick={() => onToggleObjectLock?.()} bg={control} border={border} color={text} />
            <SmallAction icon={selectedObject.hidden ? <Eye size={14} /> : <EyeOff size={14} />} label={selectedObject.hidden ? 'Afficher' : 'Masquer'} onClick={() => onToggleObjectHidden?.()} bg={control} border={border} color={text} />
            <SmallAction icon={<Trash2 size={14} />} label="Supprimer" onClick={() => onDeleteObject?.()} bg={control} border={border} color={text} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', marginTop: '6px' }}>
            <SmallAction icon={<BringToFront size={14} />} label="Premier plan" onClick={() => onBringObjectFront?.()} bg={control} border={border} color={text} />
            <SmallAction icon={<SendToBack size={14} />} label="Arrière-plan" onClick={() => onSendObjectBack?.()} bg={control} border={border} color={text} />
          </div>
        </>
      )}

      {hiddenEntries.length > 0 && (
        <>
          <SectionLabel>Éléments retirés</SectionLabel>
          <div style={{ display: 'grid', gap: 6 }}>
            {hiddenEntries.map((entry) => (
              <button
                key={entry}
                onClick={() => onRestoreEntry?.(entry)}
                style={{ border: `1px solid ${border}`, borderRadius: 9, padding: '8px 10px', background: control, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'Inter', fontSize: 9.5 }}
              >
                {entry === 'couple' ? <Heart size={13} /> : <BriefcaseBusiness size={13} />}
                Restaurer {entry === 'couple' ? 'Notre Mariage' : 'Prestataires'}
              </button>
            ))}
          </div>
        </>
      )}

      <button onClick={onReset} style={{ marginTop: 10, width: '100%', height: 31, border: 'none', borderRadius: 8, background: 'transparent', color: muted, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'Inter', fontSize: 9 }}>
        <RotateCcw size={12} /> Réinitialiser le plan
      </button>
    </aside>
  );
};

const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ margin: '14px 0 7px', fontFamily: 'Inter', fontSize: '8px', fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase', opacity: 0.42 }}>
    {children}
  </div>
);

const SmallAction: React.FC<{
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  bg: string;
  border: string;
  color: string;
  disabled?: boolean;
}> = ({ icon, label, onClick, bg, border, color, disabled }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    style={{
      border: `1px solid ${border}`, borderRadius: '9px', background: bg, color,
      padding: '8px 5px', cursor: disabled ? 'not-allowed' : 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px',
      fontFamily: 'Inter', fontSize: '8px', fontWeight: 600, opacity: disabled ? .35 : 1,
    }}
  >
    {icon}{label}
  </button>
);
