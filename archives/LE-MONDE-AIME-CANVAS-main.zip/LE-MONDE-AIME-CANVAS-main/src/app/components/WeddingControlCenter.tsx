import React from 'react';
import {
  AlertTriangle,
  CalendarDays,
  Check,
  ChevronRight,
  Circle,
  Euro,
  Globe2,
  Image as ImageIcon,
  MapPin,
  Palette,
  Timer,
  UserRoundCheck,
  Users,
  X,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import type { WeddingProjectData, WeddingReadinessGroup, WeddingReadinessItem } from '../domain/weddingProject';
import { nextWeddingAction, weddingBlockingCount, weddingReadinessPercent } from '../domain/weddingProject';

interface WeddingControlCenterProps {
  data: WeddingProjectData;
  readiness: WeddingReadinessItem[];
  onClose: () => void;
  onEditIdentity: () => void;
  onOpenTimeline: () => void;
  onOpenMiniSite: () => void;
  onOpenBudget: () => void;
  onOpenChecklist: () => void;
  onOpenMedia: () => void;
}

const iconFor = (id: WeddingReadinessItem['id']) => {
  if (id === 'identity') return <Users size={14} />;
  if (id === 'date') return <CalendarDays size={14} />;
  if (id === 'venue') return <MapPin size={14} />;
  if (id === 'guests') return <Users size={14} />;
  if (id === 'budget') return <Euro size={14} />;
  if (id === 'style') return <Palette size={14} />;
  if (id === 'witnesses') return <UserRoundCheck size={14} />;
  if (id === 'timeline') return <Timer size={14} />;
  if (id === 'minisite') return <Globe2 size={14} />;
  return <ImageIcon size={14} />;
};

const GROUPS: Array<{ id: WeddingReadinessGroup; label: string; description: string }> = [
  { id: 'foundations', label: 'Fondations', description: 'Les décisions qui dimensionnent tout le mariage.' },
  { id: 'orchestration', label: 'Orchestration', description: 'Les personnes, horaires et responsabilités du Jour J.' },
  { id: 'publication', label: 'Publication', description: 'Ce que les invités verront et utiliseront.' },
];

export const WeddingControlCenter: React.FC<WeddingControlCenterProps> = ({
  data,
  readiness,
  onClose,
  onEditIdentity,
  onOpenTimeline,
  onOpenMiniSite,
  onOpenBudget,
  onOpenChecklist,
  onOpenMedia,
}) => {
  const { isDark } = useTheme();
  const bg = isDark ? '#1D1D1F' : '#FAFAFB';
  const surface = isDark ? '#242426' : '#FFFFFF';
  const surface2 = isDark ? '#2B2B2E' : '#F1F1F3';
  const border = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)';
  const text = isDark ? '#F5F5F5' : '#121213';
  const muted = isDark ? 'rgba(245,245,245,.48)' : 'rgba(18,18,19,.5)';
  const progress = weddingReadinessPercent(readiness);
  const blockers = weddingBlockingCount(readiness);
  const nextAction = nextWeddingAction(readiness);
  const title = data.identity.brideFirstName && data.identity.groomFirstName
    ? `${data.identity.brideFirstName} & ${data.identity.groomFirstName}`
    : 'Votre mariage';

  const actionFor = (id: WeddingReadinessItem['id']) => {
    if (id === 'identity' || id === 'date' || id === 'venue' || id === 'guests' || id === 'style' || id === 'witnesses') return onEditIdentity;
    if (id === 'budget') return onOpenBudget;
    if (id === 'timeline') return onOpenTimeline;
    if (id === 'minisite') return onOpenMiniSite;
    return onOpenMedia;
  };

  const days = daysUntil(data.identity.date);
  const timelineItem = readiness.find((item) => item.id === 'timeline');

  return (
    <aside style={{ position: 'fixed', top: 50, right: 0, bottom: 0, width: 'min(430px, calc(100vw - 24px))', zIndex: 510, background: bg, color: text, borderLeft: `1px solid ${border}`, boxShadow: '-20px 0 54px rgba(0,0,0,.22)', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}>
      <header style={{ minHeight: 68, padding: '14px 16px', borderBottom: `1px solid ${border}`, display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 38, height: 38, borderRadius: 11, background: surface2, border: `1px solid ${border}`, display: 'grid', placeItems: 'center' }}>{blockers ? <AlertTriangle size={17} /> : <Check size={17} />}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 800 }}>Wedding Control Room</div>
          <div style={{ marginTop: 3, fontSize: 9.5, color: muted, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{title} · {blockers ? `${blockers} blocage${blockers > 1 ? 's' : ''}` : 'fondations prêtes'}</div>
        </div>
        <button onClick={onClose} aria-label="Fermer" style={{ width: 30, height: 30, borderRadius: 8, border: 0, background: 'transparent', color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={16} /></button>
      </header>

      <div style={{ padding: 16, borderBottom: `1px solid ${border}` }}>
        <div style={{ display: 'flex', alignItems: 'end', gap: 10 }}>
          <strong style={{ fontSize: 34, lineHeight: 1, letterSpacing: '-.05em' }}>{progress}%</strong>
          <span style={{ color: muted, fontSize: 10, paddingBottom: 3 }}>de préparation structurée</span>
        </div>
        <div style={{ height: 6, borderRadius: 99, overflow: 'hidden', background: surface2, marginTop: 12 }}><div style={{ width: `${progress}%`, height: '100%', background: isDark ? '#E5E5E7' : '#2C2C2F', transition: 'width .35s ease' }} /></div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 7, marginTop: 14 }}>
          <Metric label="Échéance" value={days == null ? '—' : days >= 0 ? `J-${days}` : `J+${Math.abs(days)}`} surface={surface} border={border} muted={muted} />
          <Metric label="Invités" value={data.guests.adultsAndChildren ? String(data.guests.adultsAndChildren) : '—'} surface={surface} border={border} muted={muted} />
          <Metric label="Budget" value={compactMoney(data.finance.totalBudget)} surface={surface} border={border} muted={muted} />
          <Metric label="Timeline" value={timelineItem ? `${Math.round(timelineItem.score * 100)}%` : '—'} surface={surface} border={border} muted={muted} />
        </div>
      </div>

      {nextAction && <div style={{ padding: '12px 16px 14px', borderBottom: `1px solid ${border}` }}>
        <div style={{ padding: 13, borderRadius: 12, background: surface, border: `1px solid ${nextAction.blocking ? 'rgba(248,113,113,.28)' : border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span style={{ width: 28, height: 28, borderRadius: 8, display: 'grid', placeItems: 'center', background: surface2 }}>{iconFor(nextAction.id)}</span><div><div style={{ color: nextAction.blocking ? '#F87171' : muted, fontSize: 8, fontWeight: 820, letterSpacing: '.09em', textTransform: 'uppercase' }}>{nextAction.blocking ? 'À débloquer maintenant' : 'Prochaine amélioration'}</div><strong style={{ display: 'block', marginTop: 3, fontSize: 11 }}>{nextAction.label}</strong></div></div>
          <p style={{ margin: '10px 0 0', color: muted, fontSize: 8.8, lineHeight: 1.5 }}>{nextAction.impact}</p>
          {!!nextAction.missing.length && <p style={{ margin: '7px 0 0', fontSize: 8.7, lineHeight: 1.45 }}>Manque : {nextAction.missing.join(' · ')}</p>}
          <button onClick={actionFor(nextAction.id)} style={{ marginTop: 11, width: '100%', height: 36, borderRadius: 9, border: 0, background: isDark ? '#F4F4F5' : '#18181A', color: isDark ? '#18181A' : '#FFFFFF', cursor: 'pointer', fontSize: 9.5, fontWeight: 780, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}>{nextAction.actionLabel}<ChevronRight size={13} /></button>
        </div>
      </div>}

      <div style={{ flex: 1, overflowY: 'auto', padding: 12 }}>
        {GROUPS.map((group) => {
          const items = readiness.filter((item) => item.group === group.id);
          const groupScore = Math.round(items.reduce((sum, item) => sum + item.score * item.weight, 0) / Math.max(1, items.reduce((sum, item) => sum + item.weight, 0)) * 100);
          return <section key={group.id} style={{ marginBottom: 15 }}>
            <div style={{ padding: '4px 4px 9px', display: 'flex', alignItems: 'end', gap: 8 }}><div style={{ flex: 1 }}><div style={{ color: muted, fontSize: 8.3, fontWeight: 820, letterSpacing: '.1em', textTransform: 'uppercase' }}>{group.label}</div><div style={{ color: muted, fontSize: 7.8, marginTop: 3 }}>{group.description}</div></div><strong style={{ fontSize: 10 }}>{groupScore}%</strong></div>
            {items.map((item) => (
              <button key={item.id} onClick={actionFor(item.id)} style={{ width: '100%', minHeight: 62, padding: '9px 10px', marginBottom: 6, borderRadius: 10, border: `1px solid ${item.severity === 'blocking' ? 'rgba(248,113,113,.23)' : border}`, background: surface, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left' }}>
                <span style={{ width: 32, height: 32, borderRadius: 8, display: 'grid', placeItems: 'center', background: surface2, color: item.complete ? text : muted }}>{iconFor(item.id)}</span>
                <span style={{ flex: 1, minWidth: 0 }}><span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><strong style={{ display: 'block', fontSize: 10.5 }}>{item.label}</strong>{item.severity === 'blocking' && <span style={{ color: '#F87171', fontSize: 7.2, fontWeight: 820, textTransform: 'uppercase' }}>Bloquant</span>}</span><span style={{ display: 'block', marginTop: 3, color: muted, fontSize: 8.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.detail}</span><span style={{ display: 'block', marginTop: 4, color: item.complete ? muted : text, fontSize: 7.8 }}>{item.complete ? 'Complet' : item.actionLabel}</span></span>
                {item.complete ? <Check size={14} /> : item.blocking ? <AlertTriangle size={13} color="#F87171" /> : <Circle size={13} color={muted} />}
              </button>
            ))}
          </section>;
        })}
      </div>

      <footer style={{ padding: 12, borderTop: `1px solid ${border}`, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <Action label="Checklist" onClick={onOpenChecklist} surface={surface} border={border} text={text} />
        <Action label="Timeline" onClick={onOpenTimeline} surface={surface} border={border} text={text} />
        <Action label="Budget" onClick={onOpenBudget} surface={surface} border={border} text={text} />
        <Action label="Mini-site" onClick={onOpenMiniSite} surface={surface} border={border} text={text} />
      </footer>
    </aside>
  );
};

function daysUntil(value: string): number | null {
  if (!value) return null;
  const target = new Date(`${value}T12:00:00`);
  if (Number.isNaN(target.getTime())) return null;
  const today = new Date();
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12);
  return Math.ceil((target.getTime() - start.getTime()) / 86400000);
}

function compactMoney(value: number) {
  if (!value) return '—';
  if (value >= 1000) return `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 1 }).format(value / 1000)} k€`;
  return `${new Intl.NumberFormat('fr-FR').format(value)} €`;
}

const Metric: React.FC<{ label: string; value: string; surface: string; border: string; muted: string }> = ({ label, value, surface, border, muted }) => <div style={{ minWidth: 0, padding: '9px 7px', borderRadius: 10, background: surface, border: `1px solid ${border}` }}><strong style={{ display: 'block', fontSize: 12, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{value}</strong><span style={{ display: 'block', marginTop: 4, fontSize: 7.5, color: muted }}>{label}</span></div>;
const Action: React.FC<{ label: string; onClick: () => void; surface: string; border: string; text: string }> = ({ label, onClick, surface, border, text }) => <button onClick={onClick} style={{ height: 36, borderRadius: 9, border: `1px solid ${border}`, background: surface, color: text, cursor: 'pointer', fontSize: 9.5, fontWeight: 720 }}>{label}</button>;
