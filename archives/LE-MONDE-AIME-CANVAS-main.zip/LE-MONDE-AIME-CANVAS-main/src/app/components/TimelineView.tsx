import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Clock, MapPin, AlignJustify, Rows3, Edit3, X, Timer,
  Calendar, ChevronDown, ChevronUp, BarChart2, AlertTriangle,
  Radio,
  Wine, UtensilsCrossed, Leaf, ChefHat, Star, CircleDot,
  IceCreamCone, Cake, GlassWater, Coffee, Droplets, Soup, Salad,
} from 'lucide-react';
import { ICON_MAP } from '../utils/iconMap';
import type { CoverVariant, WeddingLot } from '../types';

interface TimelineViewProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  coupleName: string;
  weddingDate: string;
  embedded?: boolean;
  backgroundMedia?: { type: 'image' | 'video'; url: string; fit: 'cover' | 'contain'; opacity: number; blur: number; overlay: string; muted: boolean; loop: boolean; playbackRate: number };
  coverVariant?: CoverVariant;
}

// ── Date helpers ──────────────────────────────────────────────────────────────

const MONTHS_FR: Record<string, number> = {
  janvier: 0, février: 1, mars: 2, avril: 3, mai: 4, juin: 5,
  juillet: 6, août: 7, septembre: 8, octobre: 9, novembre: 10, décembre: 11,
};

function parseWeddingDate(s: string): Date | null {
  const p = s.toLowerCase().trim().split(/\s+/);
  if (p.length < 3) return null;
  const d = parseInt(p[0], 10), m = MONTHS_FR[p[1]], y = parseInt(p[2], 10);
  if (isNaN(d) || m === undefined || isNaN(y)) return null;
  return new Date(y, m, d);
}

function getCountdown(weddingStr: string, time?: string) {
  const base = parseWeddingDate(weddingStr);
  if (!base) return null;
  const target = new Date(base);
  if (time) {
    const [h = 0, mi = 0] = time.split(':').map(Number);
    target.setHours(h, mi, 0, 0);
  } else {
    target.setHours(0, 0, 0, 0);
  }
  const diff = target.getTime() - Date.now();
  const abs = Math.abs(diff);
  const days = Math.floor(abs / 86400000);
  const hours = Math.floor((abs % 86400000) / 3600000);
  const mins = Math.floor((abs % 3600000) / 60000);
  const past = diff < 0;
  return { days, hours, mins, past };
}

function formatCountdown(cd: ReturnType<typeof getCountdown>): string {
  if (!cd) return '';
  const { days, hours, mins, past } = cd;
  const pfx = past ? 'Il y a ' : 'Dans ';
  if (days > 0) return `${pfx}${days}j ${hours}h`;
  if (hours > 0) return `${pfx}${hours}h ${mins}min`;
  return `${pfx}${mins}min`;
}

// ── Tick marks for the horizontal line ───────────────────────────────────────

function buildTicks(cards: CardItem[], spacing: number): Array<{ x: number; label: string }> {
  const timed = cards.filter((c) => c.time).map((c, i) => ({
    x: cards.indexOf(c) * spacing + spacing / 2,
    label: c.time,
  }));
  return timed;
}

// ── Types ─────────────────────────────────────────────────────────────────────

interface CardItem {
  id: string;
  name: string;
  subtitle: string;
  icon: string;
  time: string;
  lieu: string;
  notes: string;
  gradient?: string;
  image?: string;
}

// ── Catering data ─────────────────────────────────────────────────────────────

// Resolve icons with fallbacks for any that might not exist in the installed version
const _IceCreamCone = typeof IceCreamCone !== 'undefined' ? IceCreamCone : Star;
const _Soup = typeof Soup !== 'undefined' ? Soup : Droplets;
const _Salad = typeof Salad !== 'undefined' ? Salad : Leaf;

interface CateringItem {
  id: string;
  label: string;
  Icon: React.FC<{ size?: number; color?: string; strokeWidth?: number }>;
  defaultTime: string;
  qty: number;
}

const CATERING_ITEMS: CateringItem[] = [
  { id: 'champagne',  label: 'Champagne',        Icon: Wine,          defaultTime: '12:00', qty: 1 },
  { id: 'aperitif',   label: 'Apéritif',          Icon: Wine,          defaultTime: '13:00', qty: 1 },
  { id: 'mises',      label: 'Mises en bouche',   Icon: UtensilsCrossed, defaultTime: '13:30', qty: 6 },
  { id: 'entree',     label: 'Entrée',             Icon: _Salad,        defaultTime: '19:30', qty: 1 },
  { id: 'plat',       label: 'Plat principal',     Icon: ChefHat,       defaultTime: '20:30', qty: 1 },
  { id: 'fromage',    label: 'Plateau fromages',   Icon: CircleDot,     defaultTime: '21:30', qty: 1 },
  { id: 'dessert',    label: 'Dessert',            Icon: _IceCreamCone, defaultTime: '22:00', qty: 1 },
  { id: 'piece',      label: 'Pièce montée',       Icon: Cake,          defaultTime: '22:30', qty: 1 },
  { id: 'boisson',    label: 'Open bar',           Icon: GlassWater,    defaultTime: '23:00', qty: 1 },
  { id: 'soupe',      label: "Soupe à l'oignon",  Icon: _Soup,         defaultTime: '01:00', qty: 1 },
  { id: 'cafe',       label: 'Café / Digestif',    Icon: Coffee,        defaultTime: '02:00', qty: 1 },
];

// ── Component ─────────────────────────────────────────────────────────────────

export const TimelineView: React.FC<TimelineViewProps> = ({
  lots,
  cardSettings,
  coupleName,
  weddingDate,
  embedded = false,
  backgroundMedia,
  coverVariant = 'original',
}) => {
  const programmeLot = lots.find((l) => l.id === 1);
  const [spacing, setSpacing] = useState(180);
  const [mode, setMode] = useState<'horizontal' | 'vertical' | 'gantt' | 'live'>('horizontal');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [editMode, setEditMode] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  if (!programmeLot) return null;

  const cards: CardItem[] = programmeLot.cards.map((c) => ({
    ...c,
    time: cardSettings[c.id]?.time || '',
    lieu: cardSettings[c.id]?.lieu || '',
    notes: cardSettings[c.id]?.notes || '',
  }));

  const sorted = [...cards].sort((a, b) => {
    if (!a.time && !b.time) return 0;
    if (!a.time) return 1;
    if (!b.time) return -1;
    return a.time.localeCompare(b.time);
  });

  const totalWidth = sorted.length * spacing + 96;

  return (
    <div
      data-lma-timeline
      data-cover={coverVariant}
      style={{
        position: embedded ? 'absolute' : 'fixed',
        inset: 0,
        paddingTop: embedded ? 0 : '52px',
        background: embedded || backgroundMedia?.url ? 'transparent' : coverVariant === 'editorial' ? 'rgba(42,27,34,.86)' : coverVariant === 'essential' ? 'rgba(17,19,24,.98)' : coverVariant === 'immersive' ? 'radial-gradient(circle at 75% 18%,rgba(255,177,102,.3),transparent 24%),rgba(8,6,18,.86)' : 'rgba(8,6,18,.72)',
        backdropFilter: embedded ? 'none' : 'blur(4px)',
        WebkitBackdropFilter: embedded ? 'none' : 'blur(4px)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      <style>{`
        [data-lma-timeline][data-cover="editorial"]{font-family:'Cormorant Garamond',serif!important}
        [data-lma-timeline][data-cover="editorial"] button{border-radius:3px!important}
        [data-lma-timeline][data-cover="essential"] *{animation:none!important;transition:none!important}
        [data-lma-timeline][data-cover="essential"]{filter:none!important}
        [data-lma-timeline][data-cover="immersive"]{filter:saturate(1.12) contrast(1.04)}
      `}</style>
      {backgroundMedia?.url && (
        <>
          {backgroundMedia.type === 'video' ? (
            <video
              src={backgroundMedia.url}
              autoPlay
              muted={backgroundMedia.muted}
              loop={backgroundMedia.loop}
              playsInline
              onLoadedMetadata={(e) => { e.currentTarget.playbackRate = backgroundMedia.playbackRate || 1; }}
              style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: backgroundMedia.fit, opacity: backgroundMedia.opacity, filter: backgroundMedia.blur ? `blur(${backgroundMedia.blur}px) scale(1.03)` : undefined, zIndex: 0 }}
            />
          ) : (
            <img src={backgroundMedia.url} alt="Fond timeline" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: backgroundMedia.fit, opacity: backgroundMedia.opacity, filter: backgroundMedia.blur ? `blur(${backgroundMedia.blur}px) scale(1.03)` : undefined, zIndex: 0 }} />
          )}
          <div style={{ position: 'absolute', inset: 0, background: backgroundMedia.overlay || 'rgba(7,5,18,.48)', zIndex: 0, pointerEvents: 'none' }} />
        </>
      )}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: coverVariant === 'essential' ? 'linear-gradient(160deg,rgba(17,19,24,.88),rgba(27,31,42,.88))' : coverVariant === 'editorial' ? 'linear-gradient(160deg,rgba(54,31,41,.58),rgba(108,67,61,.35),rgba(32,22,31,.5))' : embedded ? 'linear-gradient(160deg,rgba(14,14,26,.24),rgba(26,16,48,.18),rgba(10,26,46,.22))' : 'linear-gradient(160deg,rgba(14,14,26,.45),rgba(26,16,48,.35),rgba(10,26,46,.42))', zIndex: 0 }} />
      {/* ── Sub-header ────────────────────────────────────────────────────── */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px 32px',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          flexShrink: 0,
          background: 'rgba(0,0,0,0.2)',
          position: 'relative', zIndex: 1,
        }}
      >
        <Calendar size={13} color="rgba(255,255,255,0.35)" />
        <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', whiteSpace: 'nowrap' }}>
          {weddingDate} — {coupleName}
        </span>

        {/* Mode toggle */}
        <div style={{ display: 'flex', gap: '2px', background: 'rgba(255,255,255,0.07)', borderRadius: '7px', padding: '3px', marginLeft: '8px' }}>
          <ModeBtn active={mode === 'horizontal'} onClick={() => setMode('horizontal')} icon={<Rows3 size={12} />} label="Horizontal" />
          <ModeBtn active={mode === 'vertical'} onClick={() => setMode('vertical')} icon={<AlignJustify size={12} />} label="Vertical" />
          <ModeBtn active={mode === 'gantt'} onClick={() => setMode('gantt')} icon={<BarChart2 size={12} />} label="Gantt" />
          <ModeBtn active={mode === 'live'} onClick={() => setMode('live')} icon={<Radio size={12} />} label="Live" />
        </div>

        {/* Spacing slider — center */}
        {mode === 'horizontal' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1, justifyContent: 'center', maxWidth: '280px', margin: '0 auto' }}>
            <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(255,255,255,0.25)', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>Resserrer</span>
            <div style={{ position: 'relative', flex: 1 }}>
              <input
                type="range"
                min={80}
                max={320}
                value={spacing}
                onChange={(e) => setSpacing(Number(e.target.value))}
                style={{
                  width: '100%',
                  accentColor: '#C4956A',
                  cursor: 'ew-resize',
                }}
              />
            </div>
            <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(255,255,255,0.25)', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>Étaler</span>
          </div>
        )}

        <div style={{ marginLeft: 'auto', display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(255,255,255,0.2)', letterSpacing: '0.04em' }}>
            {sorted.filter((c) => c.time).length}/{sorted.length} horaires
          </span>
          <button
            onClick={() => setEditMode((v) => !v)}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              background: editMode ? '#C4956A' : 'rgba(255,255,255,0.08)',
              border: 'none', borderRadius: '7px',
              padding: '5px 12px', cursor: 'pointer',
              fontFamily: 'Inter', fontSize: '10px', fontWeight: 600,
              color: editMode ? '#fff' : 'rgba(255,255,255,0.55)',
              letterSpacing: '0.05em', transition: 'all 0.2s',
            }}
          >
            <Edit3 size={11} />
            {editMode ? 'Fermer' : 'Modifier'}
          </button>
        </div>
      </div>

      {/* ── Content ───────────────────────────────────────────────────────── */}
      {mode === 'horizontal' && (
        <HorizontalTimeline
          sorted={sorted}
          spacing={spacing}
          totalWidth={totalWidth}
          expandedId={expandedId}
          setExpandedId={setExpandedId}
          editMode={editMode}
          weddingDate={weddingDate}
          scrollRef={scrollRef}
        />
      )}
      {mode === 'vertical' && (
        <VerticalTimeline
          sorted={sorted}
          expandedId={expandedId}
          setExpandedId={setExpandedId}
          editMode={editMode}
          weddingDate={weddingDate}
        />
      )}
      {mode === 'gantt' && (
        <GanttTimeline
          sorted={sorted}
          cardSettings={cardSettings}
          weddingDate={weddingDate}
        />
      )}
      {mode === 'live' && (
        <LiveDayMode
          sorted={sorted}
          weddingDate={weddingDate}
          coupleName={coupleName}
        />
      )}
    </div>
  );
};

// ── Horizontal timeline ───────────────────────────────────────────────────────

const HorizontalTimeline: React.FC<{
  sorted: CardItem[];
  spacing: number;
  totalWidth: number;
  expandedId: string | null;
  setExpandedId: (id: string | null) => void;
  editMode: boolean;
  weddingDate: string;
  scrollRef: React.RefObject<HTMLDivElement>;
}> = ({ sorted, spacing, totalWidth, expandedId, setExpandedId, editMode, weddingDate, scrollRef }) => {
  const HALF = 190;

  // Catering quantities (click to increment)
  const [qtys, setQtys] = useState<Record<string, number>>(() =>
    Object.fromEntries(CATERING_ITEMS.map((item) => [item.id, item.qty]))
  );

  const incrementQty = (id: string) => {
    setQtys((prev) => ({ ...prev, [id]: (prev[id] ?? 1) + 1 }));
  };

  // Total content width must accommodate catering items too
  const cateringTotalWidth = CATERING_ITEMS.length * spacing + 96;
  const effectiveTotalWidth = Math.max(totalWidth, cateringTotalWidth);

  return (
    <div
      ref={scrollRef}
      style={{
        flex: 1,
        overflowX: 'auto',
        overflowY: 'hidden',
        display: 'flex',
        alignItems: 'center',
        padding: '0 48px',
        scrollbarWidth: 'none',
        position: 'relative',
      }}
    >
      <div style={{ width: effectiveTotalWidth, height: '100%', position: 'relative', flexShrink: 0 }}>
        {/* ── Central axis line ── */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: '50%',
            height: '1px',
            background: 'linear-gradient(90deg,transparent,rgba(255,255,255,0.18) 4%,rgba(255,255,255,0.18) 96%,transparent)',
            transform: 'translateY(-50%)',
          }}
        />

        {/* ── Hour graduation ticks ── */}
        {sorted.map((card, idx) => {
          if (!card.time) return null;
          const cx = 48 + idx * spacing + spacing / 2;
          return (
            <React.Fragment key={`tick-${card.id}`}>
              {/* Vertical tick line */}
              <div
                style={{
                  position: 'absolute',
                  left: cx,
                  top: '50%',
                  width: '1px',
                  height: '18px',
                  background: 'rgba(196,149,106,0.4)',
                  transform: 'translateX(-50%) translateY(22px)',
                }}
              />
              {/* Time label below tick */}
              <div
                style={{
                  position: 'absolute',
                  left: cx,
                  top: '50%',
                  transform: 'translateX(-50%) translateY(46px)',
                  fontFamily: 'Inter',
                  fontSize: '10px',
                  fontWeight: 700,
                  color: '#C4956A',
                  letterSpacing: '0.06em',
                  whiteSpace: 'nowrap',
                }}
              >
                {card.time}
              </div>
            </React.Fragment>
          );
        })}

        {/* ── Cards ── */}
        {sorted.map((card, idx) => {
          const CardIcon = ICON_MAP[card.icon] ?? ICON_MAP['Wand2'];
          const cx = 48 + idx * spacing + spacing / 2;
          const isAbove = idx % 2 === 0;
          const isExpanded = expandedId === card.id;
          const cd = card.time ? getCountdown(weddingDate, card.time) : null;
          const hasTime = !!card.time;

          return (
            <div
              key={card.id}
              style={{ position: 'absolute', left: cx, top: '50%', transform: 'translateX(-50%) translateY(-50%)' }}
            >
              {/* Card label — above or below */}
              <motion.div
                initial={false}
                style={{
                  position: 'absolute',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  width: Math.max(spacing - 16, 80),
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '5px',
                  ...(isAbove
                    ? { bottom: '50px', paddingBottom: '8px' }
                    : { top: '50px', paddingTop: '8px' }),
                  cursor: 'pointer',
                }}
                onClick={() => setExpandedId(isExpanded ? null : card.id)}
              >
                {/* Title */}
                <p
                  style={{
                    fontFamily: 'Inter',
                    fontSize: Math.max(10, Math.min(14, spacing / 14)),
                    fontWeight: 800,
                    textTransform: 'uppercase',
                    letterSpacing: '-0.01em',
                    color: isExpanded ? '#C4956A' : '#fff',
                    textAlign: 'center',
                    margin: 0,
                    lineHeight: 1.1,
                    transition: 'color 0.2s',
                  }}
                >
                  {card.name}
                </p>

                {/* Sub-info chips — icons instead of italic */}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '3px', justifyContent: 'center' }}>
                  {card.lieu && (
                    <span style={CHIP}>
                      <MapPin size={8} />
                      {card.lieu.slice(0, 16)}{card.lieu.length > 16 ? '…' : ''}
                    </span>
                  )}
                  {!card.lieu && card.subtitle && (
                    <span style={{ ...CHIP, background: 'rgba(255,255,255,0.06)' }}>
                      {card.subtitle.slice(0, 20)}
                    </span>
                  )}
                  {editMode && cd && (
                    <span style={{ ...CHIP, background: cd.past ? 'rgba(255,80,80,0.15)' : 'rgba(196,149,106,0.18)', color: cd.past ? '#ff8080' : '#C4956A' }}>
                      <Timer size={8} />
                      {formatCountdown(cd)}
                    </span>
                  )}
                </div>

                {/* Expand arrow */}
                <div style={{ color: 'rgba(255,255,255,0.25)', transition: 'transform 0.2s', transform: isExpanded ? 'rotate(180deg)' : 'none' }}>
                  {isAbove ? <ChevronDown size={10} /> : <ChevronUp size={10} />}
                </div>
              </motion.div>

              {/* Connector line node → label */}
              <div
                style={{
                  position: 'absolute',
                  left: '50%',
                  width: '1px',
                  background: hasTime ? 'rgba(196,149,106,0.3)' : 'rgba(255,255,255,0.1)',
                  transform: 'translateX(-50%)',
                  ...(isAbove
                    ? { bottom: '22px', height: '28px' }
                    : { top: '22px', height: '28px' }),
                }}
              />

              {/* ── White node ── */}
              <div
                onClick={() => setExpandedId(isExpanded ? null : card.id)}
                style={{
                  position: 'relative',
                  zIndex: 2,
                  width: '44px',
                  height: '44px',
                  borderRadius: '50%',
                  background: '#ffffff',
                  border: hasTime ? '2.5px solid #C4956A' : '2px solid rgba(255,255,255,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  boxShadow: hasTime
                    ? '0 0 0 4px rgba(196,149,106,0.15), 0 4px 16px rgba(0,0,0,0.4)'
                    : '0 4px 16px rgba(0,0,0,0.3)',
                  transition: 'transform 0.15s, box-shadow 0.15s',
                }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.transform = 'scale(1.12)'; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.transform = 'scale(1)'; }}
              >
                {CardIcon && <CardIcon size={18} color="#000" strokeWidth={1.8} />}
              </div>

              {/* ── Expanded detail panel ── */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.88, y: isAbove ? -10 : 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.88, y: isAbove ? -10 : 10 }}
                    transition={{ type: 'spring', stiffness: 320, damping: 28 }}
                    style={{
                      position: 'absolute',
                      left: '50%',
                      transform: 'translateX(-50%)',
                      width: '220px',
                      ...(isAbove ? { bottom: 'calc(50% + 80px)' } : { top: 'calc(50% + 80px)' }),
                      background: 'rgba(20,15,40,0.97)',
                      backdropFilter: 'blur(24px)',
                      WebkitBackdropFilter: 'blur(24px)',
                      borderRadius: '16px',
                      border: '1px solid rgba(196,149,106,0.25)',
                      padding: '16px',
                      zIndex: 10,
                      boxShadow: '0 8px 48px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04)',
                    }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      onClick={() => setExpandedId(null)}
                      style={{ position: 'absolute', top: '10px', right: '10px', background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.3)', padding: '2px' }}
                    >
                      <X size={12} />
                    </button>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                      <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {CardIcon && <CardIcon size={13} color="#000" strokeWidth={1.8} />}
                      </div>
                      <p style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 800, textTransform: 'uppercase', color: '#fff', margin: 0, letterSpacing: '-0.01em', lineHeight: 1.1 }}>
                        {card.name}
                      </p>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      {card.time && (
                        <Row icon={<Clock size={10} color="#C4956A" />} label={card.time} accent />
                      )}
                      {card.lieu && (
                        <Row icon={<MapPin size={10} color="rgba(255,255,255,0.4)" />} label={card.lieu} />
                      )}
                      {cd && (
                        <Row
                          icon={<Timer size={10} color={cd.past ? '#ff8080' : '#C4956A'} />}
                          label={formatCountdown(cd)}
                          accent={!cd.past}
                          faded={cd.past}
                        />
                      )}
                    </div>

                    {card.notes && (
                      <div style={{ marginTop: '10px', padding: '8px', background: 'rgba(255,255,255,0.04)', borderRadius: '8px' }}>
                        <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.5)', margin: 0, lineHeight: 1.5 }}>
                          {card.notes}
                        </p>
                      </div>
                    )}

                    {!card.time && !card.lieu && !card.notes && (
                      <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.25)', margin: '8px 0 0', textAlign: 'center' }}>
                        Aucun horaire configuré — cliquez sur la carte pour l'éditer
                      </p>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}

        {/* ── Catering strip ── */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            height: '80px',
            background: 'rgba(0,0,0,0.3)',
            display: 'flex',
            alignItems: 'flex-end',
            paddingBottom: '10px',
          }}
        >
          {CATERING_ITEMS.map((item, idx) => {
            const cx = 48 + idx * spacing + spacing / 2;
            const qty = qtys[item.id] ?? item.qty;
            const { Icon } = item;
            return (
              <div
                key={item.id}
                onClick={() => incrementQty(item.id)}
                title={`${item.label} — cliquer pour augmenter`}
                style={{
                  position: 'absolute',
                  left: cx,
                  transform: 'translateX(-50%)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '3px',
                  cursor: 'pointer',
                  userSelect: 'none',
                }}
              >
                {/* Circle icon */}
                <motion.div
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.92 }}
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    background: '#ffffff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.4)',
                    flexShrink: 0,
                  }}
                >
                  <Icon size={12} color="#000" strokeWidth={1.8} />
                </motion.div>

                {/* Quantity badge */}
                <div
                  style={{
                    background: 'rgba(255,255,255,0.6)',
                    borderRadius: '50px',
                    padding: '1px 5px',
                    fontFamily: 'Inter',
                    fontSize: '9px',
                    fontWeight: 700,
                    color: '#000',
                    lineHeight: 1.3,
                    whiteSpace: 'nowrap',
                  }}
                >
                  ×{qty}
                </div>

                {/* Label */}
                <span
                  style={{
                    fontFamily: 'Inter',
                    fontSize: '8px',
                    color: 'rgba(255,255,255,0.35)',
                    whiteSpace: 'nowrap',
                    letterSpacing: '0.02em',
                    maxWidth: '60px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    textAlign: 'center',
                  }}
                >
                  {item.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scroll hint */}
      <div
        style={{
          position: 'absolute', bottom: '18px', left: '50%', transform: 'translateX(-50%)',
          fontFamily: 'Inter', fontSize: '9px', color: 'rgba(255,255,255,0.2)',
          letterSpacing: '0.1em', textTransform: 'uppercase', pointerEvents: 'none',
          display: 'flex', alignItems: 'center', gap: '6px',
        }}
      >
        <span>←</span>
        <span>Défiler pour voir toute la journée</span>
        <span>→</span>
      </div>
    </div>
  );
};

// ── Vertical timeline ─────────────────────────────────────────────────────────

const VerticalTimeline: React.FC<{
  sorted: CardItem[];
  expandedId: string | null;
  setExpandedId: (id: string | null) => void;
  editMode: boolean;
  weddingDate: string;
}> = ({ sorted, expandedId, setExpandedId, editMode, weddingDate }) => (
  <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', padding: '24px 0 48px', scrollbarWidth: 'none', position: 'relative' }}>
    {/* Vertical axis */}
    <div
      style={{
        position: 'absolute',
        left: '120px',
        top: 0,
        bottom: 0,
        width: '1px',
        background: 'linear-gradient(180deg,transparent,rgba(255,255,255,0.14) 4%,rgba(255,255,255,0.14) 96%,transparent)',
        pointerEvents: 'none',
      }}
    />

    {sorted.map((card, idx) => {
      const CardIcon = ICON_MAP[card.icon] ?? ICON_MAP['Wand2'];
      const isExpanded = expandedId === card.id;
      const cd = card.time ? getCountdown(weddingDate, card.time) : null;
      const hasTime = !!card.time;

      return (
        <motion.div
          key={card.id}
          layout
          style={{ display: 'flex', alignItems: 'flex-start', padding: '0 48px 0 0', marginBottom: '4px' }}
        >
          {/* Time column */}
          <div style={{ width: '100px', textAlign: 'right', paddingRight: '20px', paddingTop: '10px', flexShrink: 0 }}>
            {hasTime ? (
              <span style={{ fontFamily: 'Inter', fontSize: '13px', fontWeight: 700, color: '#C4956A', letterSpacing: '0.04em' }}>
                {card.time}
              </span>
            ) : (
              <span style={{ fontFamily: 'Inter', fontSize: '10px', color: 'rgba(255,255,255,0.15)', letterSpacing: '0.06em' }}>
                —
              </span>
            )}
          </div>

          {/* Node */}
          <div style={{ position: 'relative', flexShrink: 0, zIndex: 1 }}>
            <div
              onClick={() => setExpandedId(isExpanded ? null : card.id)}
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                background: '#ffffff',
                border: hasTime ? '2.5px solid #C4956A' : '2px solid rgba(255,255,255,0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                boxShadow: hasTime ? '0 0 0 4px rgba(196,149,106,0.12), 0 4px 12px rgba(0,0,0,0.4)' : '0 4px 12px rgba(0,0,0,0.3)',
                transition: 'transform 0.15s',
                flexShrink: 0,
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.transform = 'scale(1.1)'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.transform = 'scale(1)'; }}
            >
              {CardIcon && <CardIcon size={16} color="#000" strokeWidth={1.8} />}
            </div>

            {/* Connecting line to next item */}
            {idx < sorted.length - 1 && (
              <div style={{ position: 'absolute', left: '50%', top: '40px', width: '1px', height: '40px', background: 'rgba(255,255,255,0.08)', transform: 'translateX(-50%)' }} />
            )}
          </div>

          {/* Card content */}
          <div style={{ flex: 1, paddingLeft: '20px', paddingBottom: '16px', minWidth: 0 }}>
            <div
              style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', paddingTop: '8px' }}
              onClick={() => setExpandedId(isExpanded ? null : card.id)}
            >
              <p style={{ fontFamily: 'Inter', fontSize: '14px', fontWeight: 800, textTransform: 'uppercase', color: isExpanded ? '#C4956A' : '#fff', margin: 0, letterSpacing: '-0.01em', transition: 'color 0.2s' }}>
                {card.name}
              </p>
              {isExpanded ? <ChevronUp size={12} color="rgba(255,255,255,0.3)" /> : <ChevronDown size={12} color="rgba(255,255,255,0.3)" />}
            </div>

            {/* Sub chips */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginTop: '5px' }}>
              {card.lieu && <span style={CHIP}><MapPin size={8} />{card.lieu}</span>}
              {!card.lieu && <span style={{ ...CHIP, background: 'rgba(255,255,255,0.05)' }}>{card.subtitle}</span>}
              {editMode && cd && (
                <span style={{ ...CHIP, background: cd.past ? 'rgba(255,80,80,0.15)' : 'rgba(196,149,106,0.18)', color: cd.past ? '#ff8080' : '#C4956A' }}>
                  <Timer size={8} />{formatCountdown(cd)}
                </span>
              )}
            </div>

            {/* Expanded detail */}
            <AnimatePresence>
              {isExpanded && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.22, ease: 'easeInOut' }}
                  style={{ overflow: 'hidden' }}
                >
                  <div
                    style={{
                      marginTop: '10px',
                      padding: '12px 14px',
                      background: 'rgba(255,255,255,0.04)',
                      borderRadius: '10px',
                      border: '1px solid rgba(255,255,255,0.06)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px',
                    }}
                  >
                    {card.time && <Row icon={<Clock size={10} color="#C4956A" />} label={`${card.time} — Heure prévue`} accent />}
                    {cd && <Row icon={<Timer size={10} color={cd.past ? '#ff8080' : '#C4956A'} />} label={formatCountdown(cd)} accent={!cd.past} faded={cd.past} />}
                    {card.notes && (
                      <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.45)', margin: 0, lineHeight: 1.55 }}>
                        {card.notes}
                      </p>
                    )}
                    {!card.time && !card.lieu && !card.notes && (
                      <p style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.25)', margin: 0 }}>
                        Aucune information renseignée pour ce moment.
                      </p>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      );
    })}
  </div>
);

// ── Shared primitives ─────────────────────────────────────────────────────────

const CHIP: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: '4px',
  fontFamily: 'Inter',
  fontSize: '9px',
  fontWeight: 500,
  color: 'rgba(255,255,255,0.45)',
  background: 'rgba(255,255,255,0.08)',
  borderRadius: '50px',
  padding: '2px 7px',
  letterSpacing: '0.03em',
  whiteSpace: 'nowrap',
};

const Row: React.FC<{ icon: React.ReactNode; label: string; accent?: boolean; faded?: boolean }> = ({ icon, label, accent, faded }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
    {icon}
    <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: accent ? 600 : 400, color: faded ? 'rgba(255,128,128,0.8)' : accent ? '#C4956A' : 'rgba(255,255,255,0.5)', letterSpacing: '0.02em' }}>
      {label}
    </span>
  </div>
);

const ModeBtn: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    title={label}
    style={{
      display: 'flex', alignItems: 'center', gap: '4px',
      padding: '4px 9px', borderRadius: '5px', border: 'none',
      background: active ? 'rgba(255,255,255,0.12)' : 'transparent',
      color: active ? '#fff' : 'rgba(255,255,255,0.35)',
      cursor: 'pointer', fontFamily: 'Inter', fontSize: '10px', fontWeight: active ? 600 : 400,
      transition: 'all 0.15s',
    }}
  >
    {icon}
    <span>{label}</span>
  </button>
);

// ── Gantt timeline ────────────────────────────────────────────────────────────

function timeToMinutes(t: string): number {
  const [h = 0, m = 0] = t.split(':').map(Number);
  return h * 60 + m;
}

const GanttTimeline: React.FC<{
  sorted: CardItem[];
  cardSettings: Record<string, Record<string, any>>;
  weddingDate: string;
}> = ({ sorted, weddingDate }) => {
  const timed = sorted.filter((c) => c.time);
  if (timed.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ fontFamily: 'Inter', fontSize: '13px', color: 'rgba(255,255,255,0.3)', textAlign: 'center' }}>
          Configurez des horaires sur vos cartes pour voir le Gantt.
        </p>
      </div>
    );
  }

  const allMins = timed.map((c) => timeToMinutes(c.time));
  const minTime = Math.min(...allMins) - 30;
  const maxTime = Math.max(...allMins) + 90;
  const range = maxTime - minTime;

  const hours: number[] = [];
  for (let h = Math.floor(minTime / 60); h <= Math.ceil(maxTime / 60); h++) hours.push(h);

  // Detect conflicts
  const conflicts = new Set<string>();
  for (let i = 0; i < timed.length; i++) {
    for (let j = i + 1; j < timed.length; j++) {
      const diff = Math.abs(timeToMinutes(timed[i].time) - timeToMinutes(timed[j].time));
      if (diff < 30) {
        conflicts.add(timed[i].id);
        conflicts.add(timed[j].id);
      }
    }
  }

  const TRACK_H = 44;
  const LABEL_W = 150;

  return (
    <div style={{ flex: 1, overflowY: 'auto', overflowX: 'auto', padding: '24px 32px', scrollbarWidth: 'none' }}>
      {conflicts.size > 0 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px', padding: '10px 14px', background: 'rgba(245,158,11,0.12)', borderRadius: '10px', border: '1px solid rgba(245,158,11,0.25)' }}>
          <AlertTriangle size={13} color="#F59E0B" />
          <span style={{ fontFamily: 'Inter', fontSize: '11px', color: '#F59E0B', fontWeight: 600 }}>
            {conflicts.size} conflits d'horaires détectés — certains moments se chevauchent (moins de 30 min d'écart)
          </span>
        </div>
      )}

      <div style={{ minWidth: `${LABEL_W + 700}px`, position: 'relative' }}>
        {/* Hour ruler */}
        <div style={{ display: 'flex', marginLeft: LABEL_W, marginBottom: '8px' }}>
          {hours.map((h) => {
            const left = ((h * 60 - minTime) / range) * 700;
            return (
              <div key={h} style={{ position: 'absolute', left: LABEL_W + left, top: 0, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div style={{ width: '1px', height: '8px', background: 'rgba(255,255,255,0.15)' }} />
                <span style={{ fontFamily: 'Inter', fontSize: '9px', color: 'rgba(255,255,255,0.3)', letterSpacing: '0.04em', whiteSpace: 'nowrap' }}>{String(h % 24).padStart(2, '0')}h00</span>
              </div>
            );
          })}
        </div>

        {/* Hour grid lines */}
        <div style={{ position: 'absolute', left: LABEL_W, right: 0, top: '24px', bottom: 0, pointerEvents: 'none' }}>
          {hours.map((h) => {
            const left = ((h * 60 - minTime) / range) * 700;
            return <div key={h} style={{ position: 'absolute', left, top: 0, bottom: 0, width: '1px', background: 'rgba(255,255,255,0.06)' }} />;
          })}
        </div>

        {/* Current time indicator */}
        <NowIndicator minTime={minTime} range={range} labelW={LABEL_W} weddingDate={weddingDate} />

        {/* Rows */}
        <div style={{ marginTop: '24px' }}>
          {timed.map((card, idx) => {
            const CardIcon = ICON_MAP[card.icon] ?? ICON_MAP['Wand2'];
            const start = timeToMinutes(card.time);
            const durStr = card.notes?.match(/(\d+)h/) ? card.notes.match(/(\d+)h/)![1] : '1';
            const dur = parseInt(durStr, 10) * 60;
            const barLeft = ((start - minTime) / range) * 700;
            const barW = Math.max((dur / range) * 700, 40);
            const isConflict = conflicts.has(card.id);

            return (
              <div key={card.id} style={{ display: 'flex', alignItems: 'center', marginBottom: '4px', height: TRACK_H }}>
                {/* Label */}
                <div style={{ width: LABEL_W, display: 'flex', alignItems: 'center', gap: '7px', paddingRight: '12px', flexShrink: 0 }}>
                  <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <CardIcon size={11} color="#000" strokeWidth={1.8} />
                  </div>
                  <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, color: '#fff', textTransform: 'uppercase', letterSpacing: '-0.01em', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {card.name}
                  </span>
                </div>

                {/* Bar track */}
                <div style={{ position: 'relative', flex: 1, height: TRACK_H - 8, background: 'rgba(255,255,255,0.03)', borderRadius: '4px' }}>
                  <motion.div
                    initial={{ scaleX: 0, originX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ delay: idx * 0.04, duration: 0.4, ease: 'easeOut' }}
                    style={{
                      position: 'absolute',
                      left: barLeft,
                      top: '4px',
                      width: barW,
                      height: TRACK_H - 16,
                      borderRadius: '6px',
                      background: isConflict
                        ? 'linear-gradient(90deg,rgba(245,158,11,0.7),rgba(245,158,11,0.4))'
                        : 'linear-gradient(90deg,rgba(196,149,106,0.7),rgba(196,149,106,0.35))',
                      border: isConflict ? '1px solid rgba(245,158,11,0.5)' : '1px solid rgba(196,149,106,0.3)',
                      display: 'flex',
                      alignItems: 'center',
                      paddingLeft: '8px',
                      overflow: 'hidden',
                    }}
                  >
                    <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, color: 'rgba(255,255,255,0.8)', whiteSpace: 'nowrap' }}>{card.time}</span>
                    {isConflict && <AlertTriangle size={9} color="#F59E0B" style={{ marginLeft: '4px' }} />}
                  </motion.div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

const NowIndicator: React.FC<{ minTime: number; range: number; labelW: number; weddingDate: string }> = ({ minTime, range, labelW, weddingDate }) => {
  const [nowMins, setNowMins] = useState(() => {
    const n = new Date();
    return n.getHours() * 60 + n.getMinutes();
  });
  useEffect(() => {
    const t = setInterval(() => {
      const n = new Date();
      setNowMins(n.getHours() * 60 + n.getMinutes());
    }, 60000);
    return () => clearInterval(t);
  }, []);

  const wedding = parseWeddingDate(weddingDate);
  const today = new Date();
  const isWeddingDay = wedding && wedding.getFullYear() === today.getFullYear() && wedding.getMonth() === today.getMonth() && wedding.getDate() === today.getDate();
  if (!isWeddingDay) return null;

  const left = ((nowMins - minTime) / range) * 700;
  if (left < 0 || left > 700) return null;

  return (
    <div style={{ position: 'absolute', left: labelW + left, top: '24px', bottom: 0, width: '2px', background: '#ef4444', zIndex: 5, pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', top: 0, left: '-16px', background: '#ef4444', borderRadius: '3px', padding: '1px 4px' }}>
        <span style={{ fontFamily: 'Inter', fontSize: '8px', fontWeight: 700, color: '#fff' }}>Maintenant</span>
      </div>
    </div>
  );
};

// ── Live day mode ─────────────────────────────────────────────────────────────

const LiveDayMode: React.FC<{ sorted: CardItem[]; weddingDate: string; coupleName: string }> = ({ sorted, weddingDate, coupleName }) => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const nowMins = time.getHours() * 60 + time.getMinutes();
  const timed = sorted.filter((c) => c.time);
  const current = [...timed].reverse().find((c) => timeToMinutes(c.time) <= nowMins);
  const next = timed.find((c) => timeToMinutes(c.time) > nowMins);

  const CurrentIcon = current ? (ICON_MAP[current.icon] ?? ICON_MAP['Wand2']) : null;
  const NextIcon = next ? (ICON_MAP[next.icon] ?? ICON_MAP['Wand2']) : null;

  const hh = String(time.getHours()).padStart(2, '0');
  const mm = String(time.getMinutes()).padStart(2, '0');
  const ss = String(time.getSeconds()).padStart(2, '0');

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '32px', position: 'relative' }}>
      {/* Live indicator */}
      <div style={{ position: 'absolute', top: '16px', left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: '6px' }}>
        <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#ef4444', animation: 'pulse 1s infinite' }} />
        <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#ef4444' }}>En direct</span>
      </div>

      {/* Clock */}
      <div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: '88px', fontWeight: 800, color: '#fff', letterSpacing: '-0.04em', lineHeight: 1, textAlign: 'center' }}>
          {hh}<span style={{ color: 'rgba(255,255,255,0.3)', animation: 'blink 1s step-end infinite' }}>:</span>{mm}
        </div>
        <div style={{ fontFamily: 'Inter', fontSize: '16px', color: 'rgba(255,255,255,0.35)', textAlign: 'center', marginTop: '4px', letterSpacing: '0.06em' }}>:{ss}</div>
      </div>

      {/* Current moment */}
      <AnimatePresence mode="wait">
        {current && (
          <motion.div
            key={current.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}
          >
            {CurrentIcon && (
              <div style={{ width: '80px', height: '80px', borderRadius: '50%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 40px rgba(255,255,255,0.15)' }}>
                <CurrentIcon size={36} color="#000" strokeWidth={1.5} />
              </div>
            )}
            <div style={{ textAlign: 'center' }}>
              <p style={{ fontFamily: 'Inter', fontSize: '32px', fontWeight: 800, textTransform: 'uppercase', color: '#fff', margin: 0, letterSpacing: '-0.02em' }}>{current.name}</p>
              {current.lieu && <p style={{ fontFamily: 'Inter', fontSize: '13px', color: '#C4956A', margin: '4px 0 0', letterSpacing: '0.04em' }}>{current.lieu}</p>}
            </div>
          </motion.div>
        )}
        {!current && (
          <motion.div key="waiting" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <p style={{ fontFamily: 'Inter', fontSize: '24px', fontWeight: 800, color: 'rgba(255,255,255,0.3)', textAlign: 'center' }}>En attente du programme…</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Next moment */}
      {next && NextIcon && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', background: 'rgba(255,255,255,0.05)', borderRadius: '16px', padding: '12px 24px', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <NextIcon size={16} color="rgba(255,255,255,0.7)" strokeWidth={1.8} />
          </div>
          <div>
            <p style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.3)', margin: 0 }}>Prochain moment</p>
            <p style={{ fontFamily: 'Inter', fontSize: '14px', fontWeight: 700, color: 'rgba(255,255,255,0.7)', margin: '2px 0 0' }}>{next.name} — {next.time}</p>
          </div>
        </div>
      )}

      {/* Programme mini list */}
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center', maxWidth: '500px' }}>
        {timed.map((c) => {
          const past = timeToMinutes(c.time) < nowMins;
          const isCur = c.id === current?.id;
          const Ic = ICON_MAP[c.icon] ?? ICON_MAP['Wand2'];
          return (
            <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '4px 10px', borderRadius: '50px', background: isCur ? 'rgba(196,149,106,0.2)' : 'rgba(255,255,255,0.04)', border: isCur ? '1px solid #C4956A' : '1px solid transparent', opacity: past && !isCur ? 0.35 : 1, transition: 'all 0.3s' }}>
              <Ic size={10} color={isCur ? '#C4956A' : 'rgba(255,255,255,0.5)'} strokeWidth={1.8} />
              <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: isCur ? 700 : 400, color: isCur ? '#C4956A' : 'rgba(255,255,255,0.5)' }}>{c.time} {c.name}</span>
            </div>
          );
        })}
      </div>

      <style>{`@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} } @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.3)} }`}</style>
    </div>
  );
};
