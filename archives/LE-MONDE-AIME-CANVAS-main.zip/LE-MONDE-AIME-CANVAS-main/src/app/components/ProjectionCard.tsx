import React from 'react';
import { CalendarRange, Globe2, Link2, Sparkles } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import type { CanvasPlanId, CoverVariant } from '../types';

interface ProjectionCardProps {
  type: CanvasPlanId;
  linkedCount: number;
  readiness: number;
  coverVariant?: CoverVariant;
  onOpenPreview?: () => void;
}

export const ProjectionCard: React.FC<ProjectionCardProps> = ({
  type,
  linkedCount,
  readiness,
  coverVariant = 'original',
  onOpenPreview,
}) => {
  const { isDark } = useTheme();
  const isTimeline = type === 'timeline';
  const Icon = isTimeline ? CalendarRange : Globe2;
  const title = isTimeline ? 'Timeline' : 'Mini-site';
  const subtitle = isTimeline
    ? 'Ordonne les moments et les cartes reliées.'
    : 'Projette les cartes en site responsive.';
  const neutral = isDark ? '#1C1C1E' : '#F7F7F8';
  const text = isDark ? '#F5F5F5' : '#171719';
  const muted = isDark ? 'rgba(245,245,245,.52)' : 'rgba(23,23,25,.5)';
  const border = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.09)';
  const previewBg = coverVariant === 'editorial'
    ? 'linear-gradient(145deg,#E7E1D7,#FAF7F1)'
    : coverVariant === 'immersive'
      ? 'linear-gradient(145deg,#080A12,#282E3A)'
      : coverVariant === 'essential'
        ? 'linear-gradient(145deg,#FFFFFF,#ECEDEF)'
        : 'linear-gradient(145deg,#262629,#111113)';

  return (
    <article
      onDoubleClick={onOpenPreview}
      style={{
        width: '100%',
        height: '100%',
        boxSizing: 'border-box',
        borderRadius: 24,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        background: neutral,
        color: text,
        border: `1px solid ${border}`,
        boxShadow: isDark ? '0 22px 54px rgba(0,0,0,.32)' : '0 18px 42px rgba(0,0,0,.10)',
        userSelect: 'none',
      }}
    >
      <div style={{ height: 190, padding: 16, boxSizing: 'border-box', background: previewBg, color: coverVariant === 'editorial' || coverVariant === 'essential' ? '#171719' : '#fff', position: 'relative', overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ width: 36, height: 36, borderRadius: 11, display: 'grid', placeItems: 'center', background: 'rgba(255,255,255,.14)', border: '1px solid rgba(255,255,255,.16)' }}><Icon size={17} /></span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, minHeight: 24, padding: '0 8px', borderRadius: 999, background: 'rgba(0,0,0,.18)', color: '#fff', fontSize: 8, fontWeight: 750 }}><Link2 size={10} />{linkedCount} reliée{linkedCount > 1 ? 's' : ''}</span>
        </div>

        {isTimeline ? <TimelineMiniature /> : <SiteMiniature />}
        <div style={{ position: 'absolute', inset: 'auto -30px -44px auto', width: 130, height: 130, borderRadius: '50%', border: '1px solid rgba(255,255,255,.12)' }} />
      </div>

      <div style={{ flex: 1, padding: '18px 18px 16px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 8, fontWeight: 820, letterSpacing: '.12em', textTransform: 'uppercase', color: muted }}>Carte de projection</span>
          <Sparkles size={11} style={{ color: muted }} />
        </div>
        <h3 style={{ margin: '10px 0 0', fontSize: 24, lineHeight: 1, letterSpacing: '-.045em' }}>{title}</h3>
        <p style={{ margin: '9px 0 0', fontSize: 10, lineHeight: 1.5, color: muted }}>{subtitle}</p>

        <div style={{ marginTop: 'auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 7, fontSize: 8.5, color: muted }}><span>Préparation</span><strong style={{ color: text }}>{Math.round(readiness)}%</strong></div>
          <div style={{ height: 5, borderRadius: 999, overflow: 'hidden', background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)' }}><span style={{ display: 'block', width: `${Math.max(0, Math.min(100, readiness))}%`, height: '100%', borderRadius: 999, background: isDark ? '#E5E5E7' : '#242426' }} /></div>
          <button type="button" onClick={(event) => { event.stopPropagation(); onOpenPreview?.(); }} style={{ marginTop: 13, width: '100%', height: 34, borderRadius: 9, border: `1px solid ${border}`, background: 'transparent', color: text, cursor: 'pointer', fontSize: 9, fontWeight: 760 }}>Aperçu</button>
        </div>
      </div>
    </article>
  );
};

const TimelineMiniature = () => (
  <div style={{ position: 'absolute', left: 16, right: 16, bottom: 18, height: 82 }}>
    <div style={{ position: 'absolute', left: 18, right: 18, top: 39, height: 1, background: 'rgba(255,255,255,.28)' }} />
    {[12, 38, 64, 88].map((left, index) => (
      <span key={left} style={{ position: 'absolute', left: `${left}%`, top: index % 2 ? 45 : 27, width: 22, height: 22, borderRadius: '50%', transform: 'translateX(-50%)', background: '#F5F5F5', color: '#111113', display: 'grid', placeItems: 'center', fontSize: 7, fontWeight: 800 }}>{index + 1}</span>
    ))}
  </div>
);

const SiteMiniature = () => (
  <div style={{ position: 'absolute', left: 25, right: 25, bottom: 16, height: 112, borderRadius: 11, overflow: 'hidden', background: '#F7F7F8', boxShadow: '0 12px 32px rgba(0,0,0,.28)' }}>
    <div style={{ height: 18, borderBottom: '1px solid rgba(0,0,0,.08)', display: 'flex', alignItems: 'center', gap: 4, padding: '0 8px' }}><i style={{ width: 4, height: 4, borderRadius: '50%', background: '#B7B7BB' }} /><i style={{ width: 4, height: 4, borderRadius: '50%', background: '#B7B7BB' }} /><i style={{ width: 4, height: 4, borderRadius: '50%', background: '#B7B7BB' }} /></div>
    <div style={{ height: 94, padding: 12, boxSizing: 'border-box', background: 'linear-gradient(145deg,#19191C,#303036)', color: '#fff' }}><div style={{ width: '72%', height: 7, borderRadius: 6, background: 'rgba(255,255,255,.92)' }} /><div style={{ marginTop: 7, width: '48%', height: 4, borderRadius: 6, background: 'rgba(255,255,255,.38)' }} /><div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '1.2fr .8fr', gap: 6 }}><span style={{ height: 37, borderRadius: 7, background: 'rgba(255,255,255,.12)' }} /><span style={{ height: 37, borderRadius: 7, background: 'rgba(255,255,255,.22)' }} /></div></div>
  </div>
);
