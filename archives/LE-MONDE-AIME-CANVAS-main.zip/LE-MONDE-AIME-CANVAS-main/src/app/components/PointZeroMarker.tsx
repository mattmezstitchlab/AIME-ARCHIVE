import React, { useRef } from 'react';
import { Crosshair, Lock } from 'lucide-react';
import type { CanvasPoint, Tool } from '../types';

interface PointZeroMarkerProps {
  point: CanvasPoint;
  visible: boolean;
  locked: boolean;
  canvasScale: number;
  activeTool: Tool;
  onChange: (point: CanvasPoint) => void;
  onOpen: () => void;
}

export const PointZeroMarker: React.FC<PointZeroMarkerProps> = ({
  point,
  visible,
  locked,
  canvasScale,
  activeTool,
  onChange,
  onOpen,
}) => {
  const dragRef = useRef<{ clientX: number; clientY: number; x: number; y: number } | null>(null);

  if (!visible) return null;

  const interactive = activeTool === 'select' || activeTool === 'hand';

  return (
    <div
      data-canvas-object
      aria-label="Point Zéro du canevas"
      title={locked ? 'Point Zéro verrouillé' : 'Déplacer le Point Zéro'}
      onDoubleClick={(event) => { event.stopPropagation(); onOpen(); }}
      onPointerDown={(event) => {
        if (!interactive || locked) return;
        event.stopPropagation();
        event.currentTarget.setPointerCapture(event.pointerId);
        dragRef.current = { clientX: event.clientX, clientY: event.clientY, x: point.x, y: point.y };
      }}
      onPointerMove={(event) => {
        if (!dragRef.current || locked) return;
        event.stopPropagation();
        onChange({
          x: dragRef.current.x + (event.clientX - dragRef.current.clientX) / Math.max(canvasScale, 0.01),
          y: dragRef.current.y + (event.clientY - dragRef.current.clientY) / Math.max(canvasScale, 0.01),
        });
      }}
      onPointerUp={(event) => {
        dragRef.current = null;
        if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
      }}
      style={{
        position: 'absolute',
        left: point.x,
        top: point.y,
        width: 1,
        height: 1,
        zIndex: 8,
        pointerEvents: interactive ? 'auto' : 'none',
        cursor: locked ? 'default' : 'move',
      }}
    >
      <div aria-hidden style={{ position: 'absolute', left: -86, top: -0.5, width: 172, height: 1, background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.12),rgba(255,255,255,.62),rgba(255,255,255,.12),transparent)' }} />
      <div aria-hidden style={{ position: 'absolute', top: -86, left: -0.5, height: 172, width: 1, background: 'linear-gradient(180deg,transparent,rgba(255,255,255,.12),rgba(255,255,255,.62),rgba(255,255,255,.12),transparent)' }} />
      <div style={{
        position: 'absolute', left: -14, top: -14, width: 28, height: 28, borderRadius: '50%',
        border: '1px solid rgba(255,255,255,.58)', background: 'rgba(19,19,21,.82)',
        boxShadow: '0 0 0 4px rgba(255,255,255,.07), 0 8px 26px rgba(0,0,0,.28)',
        display: 'grid', placeItems: 'center', color: '#FFFFFF', backdropFilter: 'blur(14px)',
      }}>
        {locked ? <Lock size={11} /> : <Crosshair size={13} />}
      </div>
      <div style={{
        position: 'absolute', left: 20, top: -18, whiteSpace: 'nowrap', padding: '5px 8px', borderRadius: 8,
        background: 'rgba(18,18,20,.84)', border: '1px solid rgba(255,255,255,.11)', color: '#F4F3F5',
        fontSize: 8, fontWeight: 800, letterSpacing: '.12em', textTransform: 'uppercase', boxShadow: '0 10px 30px rgba(0,0,0,.22)',
      }}>
        Point Zéro <span style={{ opacity: .48, marginLeft: 5 }}>({Math.round(point.x)}, {Math.round(point.y)})</span>
      </div>
    </div>
  );
};
