import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { CalendarRange, FileText, Globe2, LayoutPanelTop, Monitor, Radio, Smartphone, Sparkles, X } from 'lucide-react';
import type { RemixTarget } from '../types';
import { useTheme } from '../contexts/ThemeContext';

export type CardPreviewMode = 'card' | 'section' | 'page' | 'site' | 'mobile' | 'timeline' | 'story' | 'pdf' | 'live';

interface CardPreviewPanelProps {
  open: boolean;
  target: RemixTarget | null;
  mode: CardPreviewMode;
  linkedCount?: number;
  onModeChange: (mode: CardPreviewMode) => void;
  onCompose?: () => void;
  onClose: () => void;
  children: React.ReactNode;
}

const MODES: Array<{ id: CardPreviewMode; label: string; icon: React.ReactNode }> = [
  { id: 'card', label: 'Carte', icon: <LayoutPanelTop size={13} /> },
  { id: 'section', label: 'Section', icon: <LayoutPanelTop size={13} /> },
  { id: 'page', label: 'Page', icon: <FileText size={13} /> },
  { id: 'site', label: 'Site', icon: <Globe2 size={13} /> },
  { id: 'mobile', label: 'Mobile', icon: <Smartphone size={13} /> },
  { id: 'timeline', label: 'Timeline', icon: <CalendarRange size={13} /> },
  { id: 'story', label: 'Story', icon: <Smartphone size={13} /> },
  { id: 'pdf', label: 'PDF', icon: <FileText size={13} /> },
  { id: 'live', label: 'Jour J Live', icon: <Radio size={13} /> },
];

export const CardPreviewPanel: React.FC<CardPreviewPanelProps> = ({
  open,
  target,
  mode,
  linkedCount = 0,
  onModeChange,
  onCompose,
  onClose,
  children,
}) => {
  const { isDark } = useTheme();

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const escape = (event: KeyboardEvent) => event.key === 'Escape' && onClose();
    window.addEventListener('keydown', escape);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener('keydown', escape);
    };
  }, [onClose, open]);

  if (!open || !target || typeof document === 'undefined') return null;

  const bg = isDark ? '#151516' : '#ECECEF';
  const panel = isDark ? '#1D1D1F' : '#FFFFFF';
  const surface = isDark ? '#252527' : '#F7F7F8';
  const border = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)';
  const text = isDark ? '#F5F5F5' : '#171719';
  const muted = isDark ? 'rgba(245,245,245,.5)' : 'rgba(23,23,25,.5)';
  const isPhone = mode === 'mobile' || mode === 'story';
  const viewportWidth = isPhone ? 390 : mode === 'card' ? 390 : mode === 'section' ? 900 : mode === 'pdf' ? 740 : 1180;
  const viewportHeight = mode === 'card' ? 590 : mode === 'section' ? 520 : mode === 'story' ? 690 : mode === 'pdf' ? 720 : 680;

  return createPortal(
    <div onMouseDown={(event) => event.target === event.currentTarget && onClose()} style={{ position: 'fixed', inset: 0, zIndex: 2147482500, background: 'rgba(0,0,0,.58)', backdropFilter: 'blur(18px)', WebkitBackdropFilter: 'blur(18px)', display: 'grid', placeItems: 'center', padding: 18 }}>
      <section role="dialog" aria-modal="true" aria-label={`Aperçu de ${target.label}`} style={{ width: 'min(1480px,calc(100vw - 28px))', height: 'min(940px,calc(100vh - 28px))', borderRadius: 22, overflow: 'hidden', background: panel, color: text, border: `1px solid ${border}`, boxShadow: '0 36px 120px rgba(0,0,0,.46)', display: 'grid', gridTemplateRows: '62px 52px minmax(0,1fr)' }}>
        <header style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 18px', borderBottom: `1px solid ${border}` }}>
          <span style={{ width: 36, height: 36, borderRadius: 11, background: surface, display: 'grid', placeItems: 'center', border: `1px solid ${border}` }}><Monitor size={16} /></span>
          <div style={{ minWidth: 0 }}><div style={{ fontSize: 8, letterSpacing: '.13em', textTransform: 'uppercase', color: muted }}>Aperçu vivant</div><strong style={{ display: 'block', marginTop: 3, fontSize: 15, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{target.label}</strong></div>
          <span style={{ marginLeft: 8, minHeight: 24, padding: '0 9px', borderRadius: 999, display: 'inline-flex', alignItems: 'center', gap: 5, background: surface, color: muted, fontSize: 8.5 }}>{linkedCount} carte{linkedCount > 1 ? 's' : ''} reliée{linkedCount > 1 ? 's' : ''}</span>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 7 }}>
            {onCompose && <button onClick={onCompose} style={{ height: 34, padding: '0 12px', borderRadius: 9, border: `1px solid ${border}`, background: surface, color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7, fontSize: 9.5, fontWeight: 760 }}><Sparkles size={13} />Mise en page</button>}
            <button onClick={onClose} aria-label="Fermer" style={{ width: 34, height: 34, borderRadius: 9, border: `1px solid ${border}`, background: surface, color: text, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={15} /></button>
          </div>
        </header>

        <nav style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '0 14px', borderBottom: `1px solid ${border}`, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {MODES.map((item) => <button key={item.id} onClick={() => onModeChange(item.id)} style={{ minWidth: 'max-content', height: 32, padding: '0 10px', borderRadius: 8, border: 0, background: mode === item.id ? (isDark ? '#F5F5F5' : '#171719') : 'transparent', color: mode === item.id ? (isDark ? '#171719' : '#FFFFFF') : muted, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 8.8, fontWeight: mode === item.id ? 780 : 560 }}>{item.icon}{item.label}</button>)}
        </nav>

        <div style={{ minHeight: 0, overflow: 'auto', background: bg, padding: 28, display: 'grid', placeItems: 'center' }}>
          <div style={{ width: `min(${viewportWidth}px,100%)`, height: `min(${viewportHeight}px,calc(100vh - 210px))`, minHeight: 360, transition: 'width .28s ease,height .28s ease', borderRadius: isPhone ? 34 : 18, border: `1px solid ${border}`, background: surface, boxShadow: '0 28px 84px rgba(0,0,0,.34)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            {!isPhone && <div style={{ height: 34, flexShrink: 0, borderBottom: `1px solid ${border}`, display: 'flex', alignItems: 'center', gap: 5, padding: '0 12px', background: panel }}><i style={{ width: 7, height: 7, borderRadius: '50%', background: muted }} /><i style={{ width: 7, height: 7, borderRadius: '50%', background: muted }} /><i style={{ width: 7, height: 7, borderRadius: '50%', background: muted }} /><span style={{ marginLeft: 9, fontSize: 8, color: muted }}>{mode}.lemondeaime.app</span></div>}
            <div style={{ flex: 1, minHeight: 0, overflow: 'auto' }}>{children}</div>
          </div>
        </div>
      </section>
    </div>,
    document.body,
  );
};
