import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Archive,
  ArchiveRestore,
  BarChart3,
  BookOpen,
  BriefcaseBusiness,
  CalendarDays,
  ChevronDown,
  Copy,
  Download,
  FileText,
  Folder,
  FolderInput,
  FolderOpen,
  Globe2,
  Grid2X2,
  Heart,
  Home,
  LayoutTemplate,
  Library,
  Mail,
  MoreHorizontal,
  Plus,
  Search,
  Sparkles,
  Star,
  Trash2,
  Upload,
  Users,
  X,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { CloudAccountControl } from './CloudAccountControl';
import { ProjectCreationDialog, type ProjectCreationInput } from './ProjectCreationDialog';
import { HomeGuide } from './HomeGuide';
import { AimeRainbowMark } from './AimeRainbowMark';
import {
  createFolder,
  createProject,
  downloadProjectBundle,
  duplicateProject,
  getActiveProject,
  getFolders,
  getProjectItem,
  getProjects,
  importProjectBundle,
  permanentlyDeleteProject,
  setProjectItem,
  updateProject,
} from '../utils/projectStore';
import type { ProjectUniverse, StudioFolder, StudioProjectMeta } from '../utils/projectStore';

interface ProjectDashboardProps {
  onOpenProject: (project: StudioProjectMeta) => void | Promise<void>;
}

type Filter = 'all' | 'recent' | 'favorites' | 'shared' | 'templates' | 'analytics' | 'archive' | 'trash' | `folder:${string}`;

type UniverseOption = {
  id: ProjectUniverse;
  label: string;
  description: string;
  icon: React.ReactNode;
  image: string;
};

const UNIVERSES: UniverseOption[] = [
  { id: 'mariage', label: 'Mariage', description: 'Créez un univers élégant pour votre grand jour.', icon: <Heart size={17} />, image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=1000&q=85' },
  { id: 'site', label: 'Mini-site', description: 'Créez un site moderne, clair et responsive.', icon: <Globe2 size={17} />, image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1000&q=85' },
  { id: 'prestataire', label: 'Profil', description: 'Présentez votre activité, vos médias et vos offres.', icon: <BriefcaseBusiness size={17} />, image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=1000&q=85' },
  { id: 'evenement', label: 'Événement', description: 'Organisez, orchestrez et partagez vos événements.', icon: <CalendarDays size={17} />, image: 'https://images.unsplash.com/photo-1507501336603-6e31db2be093?w=1000&q=85' },
  { id: 'portfolio', label: 'Portfolio', description: 'Exposez votre travail, votre récit et vos projets.', icon: <FileText size={17} />, image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1000&q=85' },
  { id: 'association', label: 'Association', description: 'Rassemblez membres, causes, ressources et actions.', icon: <Users size={17} />, image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1000&q=85' },
  { id: 'libre', label: 'Point de croix & libre', description: 'Partez d’un Point Zéro et inventez votre propre format.', icon: <Sparkles size={17} />, image: 'https://images.unsplash.com/photo-1604881991720-f91add269bed?w=1000&q=85' },
];

function relativeDate(value: string) {
  const diff = Date.now() - new Date(value).getTime();
  const minutes = Math.max(1, Math.round(diff / 60000));
  if (minutes < 60) return `Il y a ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `Il y a ${hours} h`;
  const days = Math.round(hours / 24);
  if (days < 30) return `Il y a ${days} j`;
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short' }).format(new Date(value));
}

function universeLabel(universe: ProjectUniverse) {
  return UNIVERSES.find((item) => item.id === universe)?.label || 'Projet';
}

function universeImage(universe: ProjectUniverse) {
  return UNIVERSES.find((item) => item.id === universe)?.image || UNIVERSES[0].image;
}

export const ProjectDashboard: React.FC<ProjectDashboardProps> = ({ onOpenProject }) => {
  const { isDark, toggle } = useTheme();
  const [projects, setProjects] = useState<StudioProjectMeta[]>(() => getProjects());
  const [folders, setFolders] = useState<StudioFolder[]>(() => getFolders());
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');
  const [folderOpen, setFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [sort, setSort] = useState<'recent' | 'name'>('recent');
  const [importError, setImportError] = useState('');
  const [openingProjectId, setOpeningProjectId] = useState<string | null>(null);
  const [openError, setOpenError] = useState('');
  const [creationOpen, setCreationOpen] = useState(false);
  const [creationUniverse, setCreationUniverse] = useState<ProjectUniverse | null>(null);
  const [guideOpen, setGuideOpen] = useState(false);

  const reload = () => {
    setProjects([...getProjects()]);
    setFolders([...getFolders()]);
  };

  useEffect(() => {
    const handler = () => reload();
    window.addEventListener('lma:projects-changed', handler);
    return () => window.removeEventListener('lma:projects-changed', handler);
  }, []);

  const visibleProjects = useMemo(() => {
    let result = projects.filter((project) => {
      if (filter === 'archive') return project.archived && !project.trashed;
      if (filter === 'trash') return project.trashed;
      if (project.archived || project.trashed) return false;
      if (filter === 'favorites') return project.favorite;
      if (filter === 'recent') return Date.now() - new Date(project.openedAt).getTime() < 1000 * 60 * 60 * 24 * 14;
      if (filter === 'shared' || filter === 'templates' || filter === 'analytics') return false;
      if (filter.startsWith('folder:')) return project.folderId === filter.slice(7);
      return true;
    });
    const normalized = query.trim().toLocaleLowerCase('fr');
    if (normalized) result = result.filter((project) => `${project.name} ${project.universe}`.toLocaleLowerCase('fr').includes(normalized));
    result.sort((a, b) => sort === 'name' ? a.name.localeCompare(b.name, 'fr') : new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    return result;
  }, [filter, projects, query, sort]);

  const bg = isDark ? '#171718' : '#F0F0F1';
  const panel = isDark ? '#1D1D1F' : '#FAFAFB';
  const panel2 = isDark ? '#242426' : '#FFFFFF';
  const border = isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.09)';
  const text = isDark ? '#F5F5F5' : '#121213';
  const muted = isDark ? 'rgba(245,245,245,.48)' : 'rgba(18,18,19,.48)';
  const active = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.07)';

  const requestOpen = async (project: StudioProjectMeta) => {
    if (openingProjectId) return;
    setOpenError('');
    setOpeningProjectId(project.id);
    try {
      await onOpenProject(project);
    } catch (error) {
      setOpenError(error instanceof Error ? error.message : 'Le projet n’a pas pu être ouvert.');
    } finally {
      setOpeningProjectId(null);
    }
  };

  const openCreation = (universe: ProjectUniverse | null) => {
    if (openingProjectId) return;
    setOpenError('');
    setCreationUniverse(universe);
    setCreationOpen(true);
  };

  const createAndOpen = async (input: ProjectCreationInput) => {
    if (openingProjectId) return;
    const project = createProject({
      name: input.name,
      universe: input.universe,
      folderId: input.folderId,
    });
    setProjectItem('lma_creation_mode', input.startMode, project.id);
    setProjectItem('lma_project_universe', input.universe, project.id);
    if (input.startMode === 'guided') setProjectItem('lma_onboarding_step', 'identity', project.id);
    reload();
    setCreationOpen(false);
    await requestOpen(project);
  };

  const importProjectFile = async (file?: File) => {
    if (!file) return;
    setImportError('');
    try {
      const project = await importProjectBundle(await file.text());
      reload();
      await requestOpen(project);
    } catch (error) {
      setImportError(error instanceof Error ? error.message : 'Import impossible.');
    }
  };

  const addFolder = () => {
    if (!newFolderName.trim()) return;
    const folder = createFolder(newFolderName);
    setNewFolderName('');
    setFolderOpen(false);
    setFilter(`folder:${folder.id}`);
    reload();
  };

  const recentSidebar = projects
    .filter((item) => !item.archived && !item.trashed)
    .sort((a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime())
    .slice(0, 4);

  const title = filter === 'all' ? 'Accueil'
    : filter === 'recent' ? 'Récents'
    : filter === 'favorites' ? 'Favoris'
    : filter === 'archive' ? 'Archives'
    : filter === 'trash' ? 'Corbeille'
    : filter.startsWith('folder:') ? folders.find((folder) => folder.id === filter.slice(7))?.name || 'Dossier'
    : filter === 'templates' ? 'Modèles'
    : filter === 'analytics' ? 'Analytics'
    : 'Partagés';

  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', background: bg, color: text, fontFamily: 'Inter, sans-serif' }}>
      {openingProjectId && <div aria-live="polite" style={{ position: 'fixed', inset: 0, zIndex: 1200, display: 'grid', placeItems: 'center', background: 'rgba(10,10,11,.42)', backdropFilter: 'blur(5px)' }}><div style={{ minWidth: 210, padding: '14px 16px', borderRadius: 12, border: `1px solid ${border}`, background: panel2, color: text, boxShadow: '0 24px 60px rgba(0,0,0,.32)', textAlign: 'center', fontSize: 10.5 }}><strong style={{ display: 'block', fontSize: 12, marginBottom: 5 }}>Ouverture du projet</strong>Chargement sécurisé des données…</div></div>}
      {openError && <div role="alert" style={{ position: 'fixed', top: 18, left: '50%', transform: 'translateX(-50%)', zIndex: 1300, maxWidth: 520, padding: '10px 13px', borderRadius: 10, border: '1px solid rgba(248,113,113,.28)', background: panel2, color: text, boxShadow: '0 18px 45px rgba(0,0,0,.22)', fontSize: 10 }}>{openError}</div>}

      <aside style={{ position: 'fixed', inset: '0 auto 0 0', width: 236, background: panel, borderRight: `1px solid ${border}`, padding: 16, boxSizing: 'border-box', display: 'flex', flexDirection: 'column' }}>
        <div style={{ minHeight: 45, display: 'flex', alignItems: 'center', gap: 10, paddingBottom: 12 }}>
          <AimeRainbowMark size={30} />
          <div style={{ minWidth: 0 }}><div style={{ fontSize: 11.5, fontWeight: 820, letterSpacing: '.03em' }}>LE MONDE AIME</div><div style={{ fontSize: 8.5, color: muted, marginTop: 2 }}>Point Zéro des Vivants</div></div>
          <span style={{ marginLeft: 'auto' }}><CloudAccountControl project={getActiveProject()} compact /></span>
          <button title="Changer de thème" onClick={toggle} style={{ width: 28, height: 28, borderRadius: 8, border: `1px solid ${border}`, background: 'transparent', color: muted, cursor: 'pointer' }}>◐</button>
        </div>

        <button onClick={() => setFilter('all')} style={{ height: 34, width: '100%', padding: '0 10px', borderRadius: 8, border: 0, background: filter === 'all' ? active : 'transparent', color: text, display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer', fontSize: 10.5, fontWeight: filter === 'all' ? 700 : 500 }}><Home size={14} /> Accueil</button>
        <div style={{ position: 'relative', margin: '11px 0 15px' }}><Search size={14} style={{ position: 'absolute', left: 11, top: 10, color: muted }} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Rechercher…" style={{ width: '100%', height: 34, borderRadius: 9, border: `1px solid ${border}`, background: panel2, color: text, padding: '0 10px 0 34px', boxSizing: 'border-box', outline: 'none', fontSize: 10 }} /></div>

        {!!recentSidebar.length && <>
          <SideLabel>Projets</SideLabel>
          {recentSidebar.map((project) => {
            const image = getProjectItem('lma_hero_photo', project.id) || universeImage(project.universe);
            return <button key={project.id} onClick={() => void requestOpen(project)} style={{ minHeight: 46, width: '100%', padding: '5px 7px', border: 0, borderRadius: 8, background: 'transparent', color: text, display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer', textAlign: 'left' }}><img src={image} alt="" style={{ width: 34, height: 34, borderRadius: 7, objectFit: 'cover', border: `1px solid ${border}` }} /><span style={{ minWidth: 0 }}><strong style={{ display: 'block', fontSize: 9.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{project.name}</strong><span style={{ display: 'block', fontSize: 8, color: muted, marginTop: 3 }}>{universeLabel(project.universe)}</span></span></button>;
          })}
          <button onClick={() => setFilter('all')} style={{ margin: '4px 7px 12px', border: 0, background: 'transparent', color: muted, cursor: 'pointer', fontSize: 8.5 }}>Voir tous les projets</button>
        </>}

        <SideLabel>Outils</SideLabel>
        <NavItem icon={<BookOpen size={14} />} label="Mode d’emploi" active={guideOpen} onClick={() => { setFilter('all'); setGuideOpen(true); }} isDark={isDark} />
        <NavItem icon={<LayoutTemplate size={14} />} label="Modèles du projet" active={filter === 'templates'} onClick={() => setFilter('templates')} isDark={isDark} />
        <NavItem icon={<Library size={14} />} label="Favoris" active={filter === 'favorites'} onClick={() => setFilter('favorites')} isDark={isDark} />
        <NavItem icon={<Mail size={14} />} label="Invitations · bientôt" active={filter === 'shared'} onClick={() => setFilter('shared')} isDark={isDark} />
        <NavItem icon={<BarChart3 size={14} />} label="Analytics · bientôt" active={filter === 'analytics'} onClick={() => setFilter('analytics')} isDark={isDark} />

        <div style={{ height: 1, background: border, margin: '13px 5px' }} />
        <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px 6px' }}><span style={{ fontSize: 8.5, textTransform: 'uppercase', letterSpacing: '.1em', color: muted, fontWeight: 800 }}>Dossiers</span><button title="Nouveau dossier" onClick={() => setFolderOpen(true)} style={{ marginLeft: 'auto', width: 24, height: 24, border: 0, background: 'transparent', color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Plus size={14} /></button></div>
        {folders.slice(0, 6).map((folder) => <NavItem key={folder.id} icon={filter === `folder:${folder.id}` ? <FolderOpen size={14} /> : <Folder size={14} />} label={folder.name} active={filter === `folder:${folder.id}`} onClick={() => setFilter(`folder:${folder.id}`)} isDark={isDark} />)}

        <div style={{ flex: 1 }} />
        <NavItem icon={<Archive size={14} />} label="Archives" active={filter === 'archive'} onClick={() => setFilter('archive')} isDark={isDark} />
        <NavItem icon={<Trash2 size={14} />} label="Corbeille" active={filter === 'trash'} onClick={() => setFilter('trash')} isDark={isDark} />
      </aside>

      <main style={{ marginLeft: 236, height: '100vh', overflowY: 'auto', padding: '28px 34px 70px', boxSizing: 'border-box' }}>
        <header style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 24 }}>
          <div><h1 style={{ margin: 0, fontSize: 25, letterSpacing: '-.035em' }}>{filter === 'all' ? 'Que voulez-vous créer ?' : title}</h1><p style={{ margin: '6px 0 0', color: muted, fontSize: 10.5 }}>{filter === 'all' ? 'Choisissez le type de projet qui correspond à votre besoin.' : `${visibleProjects.length} projet${visibleProjects.length > 1 ? 's' : ''}`}</p></div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <label style={topButton(panel2, border, text)}><Upload size={13} /> Importer<input type="file" accept="application/json,.json,.aime.json" hidden onChange={(event) => { void importProjectFile(event.target.files?.[0]); event.currentTarget.value = ''; }} /></label>
            <button onClick={() => setSort((value) => value === 'recent' ? 'name' : 'recent')} style={topButton(panel2, border, text)}>{sort === 'recent' ? 'Dernière modification' : 'Nom'} <ChevronDown size={13} /></button>
            <button onClick={() => openCreation(null)} style={{ ...topButton('#F4F4F4', border, '#111'), fontWeight: 760 }}><Plus size={14} /> Nouveau projet</button>
          </div>
        </header>

        {importError && <div style={{ margin: '-10px 0 18px', borderRadius: 10, padding: '10px 12px', background: 'rgba(248,113,113,.12)', color: '#F87171', fontSize: 10 }}>{importError}</div>}

        {filter === 'all' && <HomeGuide
          isDark={isDark}
          projectCount={projects.filter((project) => !project.trashed).length}
          hasRecentProject={recentSidebar.length > 0}
          open={guideOpen}
          onOpen={() => setGuideOpen(true)}
          onClose={() => setGuideOpen(false)}
          onCreate={() => openCreation(null)}
          onOpenRecent={() => { const recent = recentSidebar[0]; if (recent) void requestOpen(recent); }}
        />}

        {filter === 'all' && <section style={{ marginBottom: 34 }}><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 12 }}>{UNIVERSES.map((item) => <motion.button whileHover={{ y: -3 }} key={item.id} onClick={() => openCreation(item.id)} style={{ minHeight: 206, position: 'relative', padding: 0, overflow: 'hidden', borderRadius: 14, border: `1px solid ${border}`, background: panel2, color: '#fff', cursor: 'pointer', textAlign: 'left' }}><img src={item.image} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} /><div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(0,0,0,.03),rgba(0,0,0,.78))' }} /><span style={{ position: 'absolute', left: 16, top: 15, width: 32, height: 32, borderRadius: 9, display: 'grid', placeItems: 'center', background: 'rgba(15,15,16,.55)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,.18)' }}>{item.icon}</span><span style={{ position: 'absolute', left: 16, right: 16, bottom: 15 }}><strong style={{ display: 'block', fontSize: 15 }}>{item.label}</strong><span style={{ display: 'block', marginTop: 5, fontSize: 9.5, lineHeight: 1.45, color: 'rgba(255,255,255,.72)' }}>{item.description}</span></span></motion.button>)}</div></section>}

        {filter === 'templates' || filter === 'shared' || filter === 'analytics'
          ? <EmptyState icon={filter === 'templates' ? <LayoutTemplate size={24} /> : filter === 'analytics' ? <BarChart3 size={24} /> : <Users size={24} />} title={filter === 'templates' ? 'Modèles du projet' : filter === 'analytics' ? 'Analytics — bientôt' : 'Invitations — bientôt'} description={filter === 'templates' ? 'Ouvrez un projet puis choisissez Outils → Modèles pour appliquer un programme sans modifier les autres projets.' : filter === 'analytics' ? 'Les statistiques réelles seront activées après la publication et la connexion du stockage cloud.' : 'Les invitations et la collaboration apparaîtront ici après la connexion des comptes et permissions.'} border={border} muted={muted} />
          : visibleProjects.length
            ? <section><h2 style={{ margin: '0 0 14px', fontSize: 17 }}>{filter === 'all' ? 'Projets récents' : title}</h2><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(250px,1fr))', gap: 18 }}>{visibleProjects.map((project, index) => <ProjectCard key={project.id} project={project} index={index} isDark={isDark} folders={folders} onOpen={() => void requestOpen(project)} onFavorite={() => updateProject(project.id, { favorite: !project.favorite })} onRename={() => { const name = window.prompt('Nouveau nom du projet', project.name); if (name?.trim()) updateProject(project.id, { name: name.trim() }); }} onMove={(folderId) => updateProject(project.id, { folderId })} onExport={() => downloadProjectBundle(project.id)} onDuplicate={async () => { const copy = await duplicateProject(project.id); if (copy) reload(); }} onArchive={() => updateProject(project.id, { archived: !project.archived, trashed: false })} onTrash={() => updateProject(project.id, { trashed: !project.trashed })} onDelete={() => void permanentlyDeleteProject(project.id)} />)}</div></section>
            : <EmptyState icon={<FolderOpen size={24} />} title="Aucun projet ici" description="Créez un univers depuis les cartes de l’accueil ou importez un projet." border={border} muted={muted} />}
      </main>

      <ProjectCreationDialog open={creationOpen} initialUniverse={creationUniverse} folders={folders} defaultFolderId={filter.startsWith('folder:') ? filter.slice(7) : undefined} isDark={isDark} onClose={() => setCreationOpen(false)} onCreate={createAndOpen} />

      <AnimatePresence>{folderOpen && <Modal onClose={() => setFolderOpen(false)} isDark={isDark} title="Nouveau dossier" subtitle="Classez plusieurs univers sans les séparer du canevas."><input autoFocus value={newFolderName} onChange={(event) => setNewFolderName(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') addFolder(); }} placeholder="Nom du dossier" style={{ width: '100%', height: 42, borderRadius: 10, border: `1px solid ${border}`, background: panel2, color: text, padding: '0 12px', boxSizing: 'border-box', outline: 'none' }} /><button onClick={addFolder} style={{ marginTop: 12, width: '100%', height: 40, borderRadius: 10, border: `1px solid ${border}`, background: '#F4F4F4', color: '#111', cursor: 'pointer', fontWeight: 750 }}>Créer le dossier</button></Modal>}</AnimatePresence>
    </div>
  );
};

const SideLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => <div style={{ fontSize: 8.5, textTransform: 'uppercase', letterSpacing: '.1em', color: 'rgba(150,150,155,.75)', padding: '3px 8px 7px', fontWeight: 800 }}>{children}</div>;
const topButton = (background: string, border: string, color: string): React.CSSProperties => ({ height: 35, padding: '0 12px', borderRadius: 9, border: `1px solid ${border}`, background, color, cursor: 'pointer', fontSize: 9.5, display: 'flex', alignItems: 'center', gap: 7, boxSizing: 'border-box' });
const NavItem: React.FC<{ icon: React.ReactNode; label: string; active: boolean; onClick: () => void; isDark: boolean }> = ({ icon, label, active, onClick, isDark }) => <button onClick={onClick} style={{ height: 33, width: '100%', padding: '0 10px', borderRadius: 8, border: 0, background: active ? (isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.07)') : 'transparent', color: active ? (isDark ? '#fff' : '#111') : (isDark ? 'rgba(255,255,255,.55)' : 'rgba(0,0,0,.58)'), display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer', fontSize: 10.2, fontWeight: active ? 700 : 500, textAlign: 'left' }}>{icon}<span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{label}</span></button>;

const ProjectCard: React.FC<{
  project: StudioProjectMeta;
  index: number;
  isDark: boolean;
  folders: StudioFolder[];
  onOpen: () => void;
  onFavorite: () => void;
  onRename: () => void;
  onDuplicate: () => void;
  onExport: () => void;
  onMove: (folderId?: string) => void;
  onArchive: () => void;
  onTrash: () => void;
  onDelete: () => void;
}> = ({ project, index, isDark, folders, onOpen, onFavorite, onRename, onDuplicate, onExport, onMove, onArchive, onTrash, onDelete }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [folderMenuOpen, setFolderMenuOpen] = useState(false);
  const heroPreview = getProjectItem('lma_hero_photo', project.id) || universeImage(project.universe);
  const border = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)';
  const text = isDark ? '#F5F5F5' : '#121213';

  return <motion.article initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(index * .035, .25) }} style={{ position: 'relative' }}>
    <button onClick={onOpen} style={{ width: '100%', border: 0, background: 'transparent', padding: 0, cursor: 'pointer', textAlign: 'left', color: text }}><div style={{ position: 'relative', aspectRatio: '1.46', borderRadius: 13, overflow: 'hidden', border: `1px solid ${border}`, background: '#1A1A1B' }}><img src={heroPreview} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} /><div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,transparent 35%,rgba(0,0,0,.82))' }} /><div style={{ position: 'absolute', left: 14, right: 14, bottom: 13, color: '#fff' }}><span style={{ fontSize: 8, opacity: .65, textTransform: 'uppercase', letterSpacing: '.1em' }}>{universeLabel(project.universe)}</span><strong style={{ display: 'block', marginTop: 5, fontSize: 15 }}>{project.name}</strong><span style={{ display: 'block', marginTop: 5, fontSize: 8.5, opacity: .68 }}>{relativeDate(project.updatedAt)}</span></div></div></button>
    <button onClick={(event) => { event.stopPropagation(); setMenuOpen((value) => !value); }} style={{ position: 'absolute', right: 8, top: 8, width: 30, height: 30, borderRadius: 8, border: '1px solid rgba(255,255,255,.16)', background: 'rgba(10,10,11,.65)', color: '#fff', cursor: 'pointer', display: 'grid', placeItems: 'center', backdropFilter: 'blur(12px)' }}><MoreHorizontal size={15} /></button>
    {menuOpen && <div style={{ position: 'absolute', right: 8, top: 42, zIndex: 20, width: 174, padding: 5, borderRadius: 10, border: `1px solid ${border}`, background: isDark ? '#242426' : '#fff', boxShadow: '0 16px 40px rgba(0,0,0,.25)' }}>
      <MenuAction icon={<Star size={13} />} label={project.favorite ? 'Retirer des favoris' : 'Ajouter aux favoris'} onClick={() => { onFavorite(); setMenuOpen(false); }} />
      <MenuAction icon={<FileText size={13} />} label="Renommer" onClick={() => { onRename(); setMenuOpen(false); }} />
      <MenuAction icon={<Copy size={13} />} label="Dupliquer" onClick={() => { onDuplicate(); setMenuOpen(false); }} />
      <MenuAction icon={<Download size={13} />} label="Exporter le projet" onClick={() => { onExport(); setMenuOpen(false); }} />
      <MenuAction icon={<FolderInput size={13} />} label="Déplacer vers…" onClick={() => setFolderMenuOpen((value) => !value)} />
      {folderMenuOpen && <div style={{ margin: '2px 4px 5px', padding: 4, borderRadius: 8, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.035)' }}><MenuAction icon={<Grid2X2 size={12} />} label="Sans dossier" onClick={() => { onMove(undefined); setFolderMenuOpen(false); setMenuOpen(false); }} />{folders.map((folder) => <MenuAction key={folder.id} icon={<Folder size={12} />} label={folder.name} onClick={() => { onMove(folder.id); setFolderMenuOpen(false); setMenuOpen(false); }} />)}</div>}
      <MenuAction icon={project.archived ? <ArchiveRestore size={13} /> : <Archive size={13} />} label={project.archived ? 'Restaurer' : 'Archiver'} onClick={() => { onArchive(); setMenuOpen(false); }} />
      {project.trashed ? <MenuAction danger icon={<Trash2 size={13} />} label="Supprimer définitivement" onClick={() => { onDelete(); setMenuOpen(false); }} /> : <MenuAction danger icon={<Trash2 size={13} />} label="Mettre à la corbeille" onClick={() => { onTrash(); setMenuOpen(false); }} />}
    </div>}
  </motion.article>;
};

const MenuAction: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void; danger?: boolean }> = ({ icon, label, onClick, danger }) => <button onClick={onClick} style={{ width: '100%', minHeight: 32, border: 0, background: 'transparent', color: danger ? '#F87171' : 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 9, padding: '0 9px', borderRadius: 7, fontSize: 9.5, textAlign: 'left' }}>{icon}{label}</button>;
const EmptyState: React.FC<{ icon: React.ReactNode; title: string; description: string; border: string; muted: string }> = ({ icon, title, description, border, muted }) => <div style={{ minHeight: 240, border: `1px dashed ${border}`, borderRadius: 16, display: 'grid', placeItems: 'center', textAlign: 'center', padding: 30 }}><div><div style={{ color: muted, marginBottom: 10 }}>{icon}</div><strong style={{ fontSize: 14 }}>{title}</strong><p style={{ color: muted, fontSize: 10, lineHeight: 1.55, maxWidth: 320 }}>{description}</p></div></div>;
const Modal: React.FC<{ onClose: () => void; isDark: boolean; title: string; subtitle: string; children: React.ReactNode }> = ({ onClose, isDark, title, subtitle, children }) => <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={onClose} style={{ position: 'fixed', inset: 0, zIndex: 900, background: 'rgba(0,0,0,.62)', display: 'grid', placeItems: 'center', padding: 20 }}><motion.div initial={{ y: 15, scale: .98 }} animate={{ y: 0, scale: 1 }} onMouseDown={(event) => event.stopPropagation()} style={{ width: 'min(480px,100%)', borderRadius: 16, border: `1px solid ${isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)'}`, background: isDark ? '#242426' : '#fff', color: isDark ? '#fff' : '#111', padding: 20, boxShadow: '0 30px 80px rgba(0,0,0,.35)' }}><div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: 16 }}><div><h2 style={{ margin: 0, fontSize: 17 }}>{title}</h2><p style={{ margin: '6px 0 0', fontSize: 9.5, color: isDark ? 'rgba(255,255,255,.48)' : 'rgba(0,0,0,.5)' }}>{subtitle}</p></div><button onClick={onClose} style={{ marginLeft: 'auto', border: 0, background: 'transparent', color: 'inherit', cursor: 'pointer' }}><X size={16} /></button></div>{children}</motion.div></motion.div>;
