import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Check,
  Clock3,
  Download,
  FileJson,
  Globe2,
  Image as ImageIcon,
  Link2,
  ListChecks,
  Presentation,
  Printer,
  QrCode,
  Radio,
  RefreshCw,
  Rocket,
  Send,
  Trash2,
  Upload,
  Users,
} from 'lucide-react';
import QRCode from 'qrcode';
import { toast } from 'sonner';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { PanelShell } from './StudioAddPanel';
import {
  archivePublication,
  deleteLiveUpdate,
  getLiveUpdates,
  listRsvps,
  publicationSlugFromUrl,
  publishLiveUpdate,
  rsvpsToCsv,
  subscribeToLiveUpdates,
  subscribeToRsvps,
  summarizeRsvps,
  type LiveUpdate,
  type LiveUpdateLevel,
  type PublishResult,
  type RsvpRecord,
} from '../public/publicationService';

interface StudioPublishPanelProps {
  onView: (view: 'canvas' | 'timeline' | 'minisite') => void;
  onKiosk: () => void;
  exportProject: () => Record<string, unknown>;
  importProject: (data: Record<string, unknown>) => void;
  onPublish?: () => Promise<PublishResult>;
  initialPublication?: PublishResult | null;
  onClose: () => void;
}

type PublishTab = 'publish' | 'rsvp' | 'live';

export const StudioPublishPanel: React.FC<StudioPublishPanelProps> = ({ onView, onKiosk, exportProject, importProject, onPublish, initialPublication, onClose }) => {
  const { isDark } = useTheme();
  const auth = useAuth();
  const input = useRef<HTMLInputElement>(null);
  const [publication, setPublication] = useState<PublishResult | null>(() => normalizePublication(initialPublication));
  const [publishing, setPublishing] = useState(false);
  const [tab, setTab] = useState<PublishTab>('publish');
  const [rsvps, setRsvps] = useState<RsvpRecord[]>([]);
  const [liveUpdates, setLiveUpdates] = useState<LiveUpdate[]>([]);
  const [managementLoading, setManagementLoading] = useState(false);
  const [liveTitle, setLiveTitle] = useState('');
  const [liveBody, setLiveBody] = useState('');
  const [liveLevel, setLiveLevel] = useState<LiveUpdateLevel>('info');
  const [livePinned, setLivePinned] = useState(false);
  const [liveSending, setLiveSending] = useState(false);

  const slug = publication?.slug || (publication?.url ? publicationSlugFromUrl(publication.url) : '');
  const rsvpSummary = useMemo(() => summarizeRsvps(rsvps), [rsvps]);

  const refreshManagement = async () => {
    if (!slug) return;
    setManagementLoading(true);
    try {
      const [nextRsvps, nextUpdates] = await Promise.all([
        auth.user ? listRsvps(slug) : Promise.resolve([]),
        getLiveUpdates(slug),
      ]);
      setRsvps(nextRsvps);
      setLiveUpdates(nextUpdates);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Lecture des données publiques impossible.');
    } finally {
      setManagementLoading(false);
    }
  };

  useEffect(() => {
    if (!slug) return;
    void refreshManagement();
    const stopRsvps = auth.user ? subscribeToRsvps(slug, () => void refreshManagement()) : () => undefined;
    const stopLive = subscribeToLiveUpdates(slug, () => void refreshManagement());
    return () => {
      stopRsvps();
      stopLive();
    };
  }, [auth.user?.id, slug]);

  const downloadProject = () => {
    const data = JSON.stringify(exportProject(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `le-monde-aime-${new Date().toISOString().slice(0,10)}.aime.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success('Projet exporté.');
  };

  const loadProject = async (file?: File) => {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      importProject(data);
      toast.success('Projet importé.');
    } catch {
      toast.error('Ce fichier projet est invalide.');
    }
  };

  const publish = async () => {
    if (!onPublish) return;
    setPublishing(true);
    try {
      const result = normalizePublication(await onPublish());
      setPublication(result);
      toast.success(result?.mode === 'cloud' ? 'Mini-site publié en ligne.' : 'Aperçu public créé dans ce navigateur.');
      if (result?.slug) window.setTimeout(() => void refreshManagement(), 250);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Publication impossible.');
    } finally {
      setPublishing(false);
    }
  };

  const copyLink = async (target = publication?.url || window.location.href) => {
    await navigator.clipboard.writeText(target);
    toast.success(publication ? 'Lien public copié.' : 'Lien de la session copié.');
  };

  const createQr = async () => {
    if (!publication?.url) {
      toast.info('Publiez d’abord le mini-site.');
      return;
    }
    const dataUrl = await QRCode.toDataURL(publication.url, { width: 900, margin: 3, color: { dark: '#111111', light: '#FFFFFF' } });
    const anchor = document.createElement('a');
    anchor.href = dataUrl;
    anchor.download = 'qr-code-mariage.png';
    anchor.click();
    toast.success('QR Code téléchargé.');
  };

  const downloadRsvps = () => {
    if (!rsvps.length) {
      toast.info('Aucune réponse à exporter.');
      return;
    }
    const blob = new Blob([`\uFEFF${rsvpsToCsv(rsvps)}`], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `reponses-${slug}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success('Liste RSVP exportée.');
  };

  const sendLive = async () => {
    if (!slug) {
      toast.info('Publiez d’abord le mini-site.');
      return;
    }
    setLiveSending(true);
    try {
      const mode = await publishLiveUpdate(slug, { title: liveTitle, body: liveBody, level: liveLevel, pinned: livePinned }, auth.user);
      setLiveTitle('');
      setLiveBody('');
      setLiveLevel('info');
      setLivePinned(false);
      await refreshManagement();
      toast.success(mode === 'cloud' ? 'Message envoyé au Jour J Live.' : 'Message ajouté à l’aperçu local.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Envoi impossible.');
    } finally {
      setLiveSending(false);
    }
  };

  const archive = async () => {
    if (!slug || !window.confirm('Retirer cette publication du web ?')) return;
    try {
      await archivePublication(slug);
      setPublication(null);
      setRsvps([]);
      setLiveUpdates([]);
      toast.success('Publication retirée. Le projet reste intact.');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Archivage impossible.');
    }
  };

  const deleteUpdate = async (id: string) => {
    try {
      await deleteLiveUpdate(id);
      setLiveUpdates((items) => items.filter((item) => item.id !== id));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Suppression impossible.');
    }
  };

  return (
    <PanelShell title="Publier" subtitle="Mini-site, réponses et Jour J Live" onClose={onClose} isDark={isDark} width={350}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 5, marginBottom: 14 }}>
        <TabButton active={tab === 'publish'} label="Publier" icon={<Rocket size={12} />} onClick={() => setTab('publish')} isDark={isDark} />
        <TabButton active={tab === 'rsvp'} label={`RSVP${rsvps.length ? ` · ${rsvps.length}` : ''}`} icon={<Users size={12} />} onClick={() => setTab('rsvp')} isDark={isDark} />
        <TabButton active={tab === 'live'} label="Jour J" icon={<Radio size={12} />} onClick={() => setTab('live')} isDark={isDark} />
      </div>

      {tab === 'publish' && <>
        <SectionTitle>Publication</SectionTitle>
        <button disabled={publishing || !onPublish} onClick={() => void publish()} style={{ width: '100%', minHeight: 54, borderRadius: 11, padding: '10px 12px', marginBottom: 9, border: 0, background: isDark ? '#F2F2F3' : '#19191B', color: isDark ? '#151517' : '#FFFFFF', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left' }}><span style={{ width: 30, height: 30, borderRadius: 8, display: 'grid', placeItems: 'center', background: isDark ? 'rgba(0,0,0,.08)' : 'rgba(255,255,255,.1)' }}><Rocket size={15} /></span><span><strong style={{ display: 'block', fontSize: 10.5 }}>{publishing ? 'Publication en cours…' : publication ? 'Mettre à jour le mini-site' : 'Publier le mini-site'}</strong><span style={{ display: 'block', marginTop: 3, fontSize: 8.5, opacity: .55 }}>{publication?.mode === 'cloud' ? 'URL publique active' : publication?.mode === 'local' ? 'Aperçu local — connectez le cloud pour partager' : 'Crée le site, le RSVP et la vue Jour J'}</span></span></button>
        {publication && <div style={{ marginBottom: 14, padding: 10, borderRadius: 10, border: `1px solid ${line(isDark)}`, background: soft(isDark) }}><div style={{ display: 'flex', alignItems: 'center', gap: 7 }}><Check size={13} /><strong style={{ fontSize: 9.5 }}>{publication.mode === 'cloud' ? 'Publication en ligne' : 'Aperçu local'}</strong></div><div style={{ marginTop: 5, fontSize: 8, opacity: .48, wordBreak: 'break-all' }}>{publication.url}</div><button onClick={() => void archive()} style={{ marginTop: 9, border: 0, background: 'transparent', color: '#F87171', cursor: 'pointer', fontSize: 8.5, padding: 0 }}>Retirer la publication</button></div>}

        <SectionTitle>Aperçus</SectionTitle>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7, marginBottom: 14 }}>
          <Action icon={<Globe2 size={15} />} title="Mini-site" desc="Version web scrollable" onClick={() => publication ? window.open(publication.url, '_blank') : onView('minisite')} isDark={isDark} />
          <Action icon={<Radio size={15} />} title="Jour J Live" desc="Vue mobile actualisée" onClick={() => publication ? window.open(publication.liveUrl, '_blank') : toast.info('Publiez d’abord le mini-site.')} isDark={isDark} />
          <Action icon={<Clock3 size={15} />} title="Timeline" desc="Orchestration du jour" onClick={() => onView('timeline')} isDark={isDark} />
          <Action icon={<Presentation size={15} />} title="Présentation" desc="Plein écran / kiosque" onClick={onKiosk} isDark={isDark} />
          <Action icon={<ImageIcon size={15} />} title="Canevas" desc="Retour à l’édition" onClick={() => onView('canvas')} isDark={isDark} />
        </div>

        <SectionTitle>Exporter & partager</SectionTitle>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7, marginBottom: 14 }}>
          <Action icon={<Link2 size={15} />} title="Copier le lien" desc={publication ? 'Lien public' : 'Lien de la session'} onClick={() => void copyLink()} isDark={isDark} />
          <Action icon={<QrCode size={15} />} title="QR Code" desc="PNG haute définition" onClick={() => void createQr()} isDark={isDark} />
          <Action icon={<Printer size={15} />} title="Imprimer / PDF" desc="Dialogue du navigateur" onClick={() => window.print()} isDark={isDark} />
          <Action icon={<Download size={15} />} title="Exporter JSON" desc="Sauvegarde complète" onClick={downloadProject} isDark={isDark} />
        </div>

        <SectionTitle>Importer</SectionTitle>
        <button onClick={() => input.current?.click()} style={{ width: '100%', borderRadius: 10, padding: '10px 12px', border: `1px dashed ${isDark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.18)'}`, background: 'transparent', color: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 9 }}><span style={{ width: 30, height: 30, borderRadius: 8, background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Upload size={14} /></span><span style={{ textAlign: 'left' }}><strong style={{ display: 'block', fontSize: 10 }}>Importer un projet</strong><span style={{ display: 'block', fontSize: 8.5, opacity: .45, marginTop: 3 }}>Restaure canevas, médias et réglages</span></span></button>
        <input ref={input} type="file" accept="application/json,.json" hidden onChange={(event) => { void loadProject(event.target.files?.[0]); event.currentTarget.value = ''; }} />
        <div style={{ marginTop: 12, display: 'flex', gap: 8, padding: 10, borderRadius: 10, background: soft(isDark) }}><FileJson size={14} style={{ flexShrink: 0, opacity: .55 }} /><p style={{ margin: 0, fontSize: 9, lineHeight: 1.45, opacity: .5 }}>Le JSON reste la sauvegarde portable. La publication partageable nécessite le compte cloud.</p></div>
      </>}

      {tab === 'rsvp' && <>
        {!publication ? <Empty icon={<Users size={18} />} title="Publiez d’abord le mini-site" description="Les réponses apparaîtront ici en temps réel." isDark={isDark} /> : !auth.user ? <Empty icon={<AlertTriangle size={18} />} title="Connexion requise" description="Connectez le compte propriétaire pour consulter les réponses." isDark={isDark} /> : <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6, marginBottom: 12 }}>
            <Metric label="Réponses" value={rsvpSummary.responses} isDark={isDark} />
            <Metric label="Personnes" value={rsvpSummary.expectedGuests} isDark={isDark} />
            <Metric label="Allergies" value={rsvpSummary.dietaryResponses} isDark={isDark} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6, marginBottom: 12 }}>
            <SmallMetric label="Oui" value={rsvpSummary.attending} isDark={isDark} />
            <SmallMetric label="Peut-être" value={rsvpSummary.maybe} isDark={isDark} />
            <SmallMetric label="Non" value={rsvpSummary.absent} isDark={isDark} />
          </div>
          <button disabled={managementLoading} onClick={() => void refreshManagement()} style={{ ...wideButton(isDark), marginBottom: 7 }}><RefreshCw size={12} /> Actualiser</button>
          <button onClick={downloadRsvps} style={{ ...wideButton(isDark), marginBottom: 12 }}><Download size={12} /> Exporter en CSV</button>
          <SectionTitle>Dernières réponses</SectionTitle>
          {rsvps.length ? rsvps.slice(0, 30).map((item) => <article key={item.id} style={{ padding: 11, marginBottom: 7, borderRadius: 10, border: `1px solid ${line(isDark)}`, background: soft(isDark) }}><div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><span style={{ width: 26, height: 26, borderRadius: 8, display: 'grid', placeItems: 'center', background: isDark ? '#2B2B2E' : '#ECECEF' }}>{item.attendance === 'yes' ? <Check size={13} /> : item.attendance === 'no' ? <Trash2 size={12} /> : <Clock3 size={12} />}</span><span style={{ flex: 1 }}><strong style={{ display: 'block', fontSize: 9.8 }}>{item.name}</strong><span style={{ display: 'block', marginTop: 3, fontSize: 8, opacity: .48 }}>{item.guestCount} personne{item.guestCount > 1 ? 's' : ''}{item.email ? ` · ${item.email}` : ''}</span></span></div>{item.dietaryRequirements && <p style={{ margin: '8px 0 0', fontSize: 8.5, lineHeight: 1.4 }}>Repas : {item.dietaryRequirements}</p>}{item.message && <p style={{ margin: '6px 0 0', fontSize: 8.5, lineHeight: 1.4, opacity: .62 }}>{item.message}</p>}</article>) : <Empty icon={<ListChecks size={18} />} title="Aucune réponse" description="Le tableau se mettra à jour dès le premier RSVP." isDark={isDark} />}
        </>}
      </>}

      {tab === 'live' && <>
        {!publication ? <Empty icon={<Radio size={18} />} title="Publiez d’abord le mini-site" description="La vue Jour J utilise la même publication." isDark={isDark} /> : <>
          <SectionTitle>Envoyer un message en direct</SectionTitle>
          <input value={liveTitle} onChange={(event) => setLiveTitle(event.target.value)} placeholder="Ex. La cérémonie commence dans 10 minutes" style={field(isDark)} />
          <textarea value={liveBody} onChange={(event) => setLiveBody(event.target.value)} placeholder="Précision facultative" style={{ ...field(isDark), height: 76, paddingTop: 9, resize: 'vertical', marginTop: 7 }} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 7, marginTop: 7 }}>
            <select value={liveLevel} onChange={(event) => setLiveLevel(event.target.value as LiveUpdateLevel)} style={field(isDark)}><option value="info">Information</option><option value="important">Important</option><option value="urgent">Urgent</option></select>
            <button onClick={() => setLivePinned((value) => !value)} style={{ ...wideButton(isDark), width: 92 }}>{livePinned ? 'Épinglé' : 'Épingler'}</button>
          </div>
          <button disabled={liveSending || !liveTitle.trim()} onClick={() => void sendLive()} style={{ ...wideButton(isDark), margin: '8px 0 14px', background: isDark ? '#F2F2F3' : '#19191B', color: isDark ? '#151517' : '#FFF' }}><Send size={12} /> {liveSending ? 'Envoi…' : 'Envoyer au Live'}</button>
          <button onClick={() => window.open(publication.liveUrl, '_blank')} style={{ ...wideButton(isDark), marginBottom: 14 }}><Radio size={12} /> Ouvrir la vue Jour J</button>
          <SectionTitle>Messages actifs</SectionTitle>
          {liveUpdates.length ? liveUpdates.map((item) => <article key={item.id} style={{ padding: 11, marginBottom: 7, borderRadius: 10, border: `1px solid ${item.level === 'urgent' ? 'rgba(248,113,113,.28)' : line(isDark)}`, background: soft(isDark) }}><div style={{ display: 'flex', alignItems: 'center', gap: 7 }}><Radio size={12} /><strong style={{ flex: 1, fontSize: 9.5 }}>{item.title}</strong>{item.is_pinned && <span style={{ fontSize: 7, opacity: .48 }}>Épinglé</span>}<button onClick={() => void deleteUpdate(item.id)} aria-label="Supprimer" style={{ width: 25, height: 25, display: 'grid', placeItems: 'center', border: 0, background: 'transparent', color: '#F87171', cursor: 'pointer' }}><Trash2 size={11} /></button></div>{item.body && <p style={{ margin: '7px 0 0', fontSize: 8.4, lineHeight: 1.45, opacity: .58 }}>{item.body}</p>}</article>) : <Empty icon={<Radio size={18} />} title="Aucun message" description="Les alertes et changements apparaîtront ici." isDark={isDark} />}
        </>}
      </>}
    </PanelShell>
  );
};

function normalizePublication(value?: PublishResult | null): PublishResult | null {
  if (!value?.url || !value.liveUrl) return null;
  return {
    ...value,
    slug: value.slug || publicationSlugFromUrl(value.url),
    publishedAt: value.publishedAt || new Date().toISOString(),
  };
}

const line = (isDark: boolean) => isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.09)';
const soft = (isDark: boolean) => isDark ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.025)';
const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => <div style={{ fontSize: 8.5, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase', opacity: .42, marginBottom: 7 }}>{children}</div>;
const TabButton: React.FC<{ active: boolean; label: string; icon: React.ReactNode; onClick: () => void; isDark: boolean }> = ({ active, label, icon, onClick, isDark }) => <button onClick={onClick} style={{ height: 34, borderRadius: 8, border: `1px solid ${line(isDark)}`, background: active ? (isDark ? '#F2F2F3' : '#19191B') : soft(isDark), color: active ? (isDark ? '#151517' : '#FFF') : 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, fontSize: 8.5, fontWeight: 750 }}>{icon}{label}</button>;
const Action: React.FC<{ icon: React.ReactNode; title: string; desc: string; onClick: () => void; isDark: boolean }> = ({ icon, title, desc, onClick, isDark }) => <button onClick={onClick} style={{ borderRadius: 11, padding: 10, border: `1px solid ${line(isDark)}`, background: soft(isDark), color: 'inherit', cursor: 'pointer', textAlign: 'left', display: 'flex', gap: 8 }}><span style={{ width: 28, height: 28, borderRadius: 8, background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{icon}</span><span><strong style={{ display: 'block', fontSize: 10 }}>{title}</strong><span style={{ display: 'block', fontSize: 8.5, opacity: .43, marginTop: 3, lineHeight: 1.3 }}>{desc}</span></span></button>;
const Metric: React.FC<{ label: string; value: number; isDark: boolean }> = ({ label, value, isDark }) => <div style={{ padding: '10px 8px', borderRadius: 10, border: `1px solid ${line(isDark)}`, background: soft(isDark) }}><strong style={{ display: 'block', fontSize: 16 }}>{value}</strong><span style={{ display: 'block', marginTop: 4, fontSize: 7.5, opacity: .45 }}>{label}</span></div>;
const SmallMetric: React.FC<{ label: string; value: number; isDark: boolean }> = ({ label, value, isDark }) => <div style={{ padding: '7px 8px', borderRadius: 8, border: `1px solid ${line(isDark)}`, background: soft(isDark), display: 'flex', justifyContent: 'space-between', gap: 5, fontSize: 8.5 }}><span style={{ opacity: .48 }}>{label}</span><strong>{value}</strong></div>;
const Empty: React.FC<{ icon: React.ReactNode; title: string; description: string; isDark: boolean }> = ({ icon, title, description, isDark }) => <div style={{ minHeight: 180, borderRadius: 12, border: `1px dashed ${line(isDark)}`, display: 'grid', placeItems: 'center', padding: 20, textAlign: 'center' }}><div><span style={{ width: 38, height: 38, margin: '0 auto 10px', borderRadius: 10, display: 'grid', placeItems: 'center', background: soft(isDark) }}>{icon}</span><strong style={{ display: 'block', fontSize: 10.5 }}>{title}</strong><p style={{ margin: '6px auto 0', maxWidth: 240, fontSize: 8.5, lineHeight: 1.45, opacity: .45 }}>{description}</p></div></div>;
const field = (isDark: boolean): React.CSSProperties => ({ width: '100%', height: 38, borderRadius: 9, border: `1px solid ${line(isDark)}`, background: soft(isDark), color: 'inherit', padding: '0 10px', boxSizing: 'border-box', outline: 'none', fontFamily: 'Inter', fontSize: 9.5 });
const wideButton = (isDark: boolean): React.CSSProperties => ({ width: '100%', height: 36, borderRadius: 9, border: `1px solid ${line(isDark)}`, background: soft(isDark), color: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 8.8, fontWeight: 720 });
