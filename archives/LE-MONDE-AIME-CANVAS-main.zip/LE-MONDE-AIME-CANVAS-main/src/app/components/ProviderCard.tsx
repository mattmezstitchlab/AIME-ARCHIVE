import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Briefcase, MapPin, Mail, Euro, Shield,
  ChevronRight, Check, RotateCcw, Globe, Phone,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export interface ProviderData {
  companyName: string;
  contactName: string;
  category: string;
  city: string;
  serviceArea: string;
  email: string;
  phone: string;
  website: string;
  instagram: string;
  priceFrom: number;
  description: string;
  availability: string;
  siret: string;
  acceptsOnlineBooking: boolean;
}

interface ProviderCardProps {
  data: ProviderData;
  onChange: (data: ProviderData) => void;
  onComplete: (data: ProviderData) => void;
  isComplete: boolean;
}

const CATEGORIES = [
  'Wedding planner', 'Lieu', 'Traiteur', 'Photographe', 'Vidéaste',
  'DJ', 'Musicien', 'Fleuriste', 'Décorateur', 'Beauté', 'Transport', 'Autre',
];

const SECTIONS = [
  { id: 'identity', label: 'Votre activité', icon: <Briefcase size={13} /> },
  { id: 'service', label: 'Votre service', icon: <Shield size={13} /> },
  { id: 'area', label: 'Votre zone', icon: <MapPin size={13} /> },
  { id: 'contact', label: 'Vos contacts', icon: <Mail size={13} /> },
  { id: 'offer', label: 'Votre offre', icon: <Euro size={13} /> },
];

function pct(data: ProviderData): number {
  const checks = [
    data.companyName,
    data.contactName,
    data.category,
    data.city,
    data.email || data.phone,
    data.description,
    data.priceFrom > 0,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

export const ProviderCard: React.FC<ProviderCardProps> = ({ data, onChange, onComplete, isComplete }) => {
  const { isDark } = useTheme();
  const [flipped, setFlipped] = useState(false);
  const [section, setSection] = useState(0);
  const completion = pct(data);

  const set = <K extends keyof ProviderData>(field: K, value: ProviderData[K]) => {
    onChange({ ...data, [field]: value });
  };

  const accent = isDark ? '#F0F0F0' : '#222222';
  const surf = isDark ? '#242426' : '#FFFFFF';
  const surf2 = isDark ? '#1D1D1F' : '#F5F5F7';
  const border = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
  const tp = isDark ? '#F5F5F5' : '#0F0F12';
  const ts = isDark ? 'rgba(245,245,245,0.5)' : '#6B6B7B';
  const tm = isDark ? 'rgba(245,245,245,0.28)' : 'rgba(15,15,18,0.3)';

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '8px 11px', borderRadius: '8px',
    border: `1px solid ${border}`, background: surf2,
    fontFamily: 'Inter', fontSize: '12px', color: tp, outline: 'none',
    boxSizing: 'border-box', transition: 'border-color 0.15s',
  };

  return (
    <div
      style={{ width: '260px', height: '360px', perspective: '1200px', cursor: 'default', flexShrink: 0 }}
      onClick={(e) => e.stopPropagation()}
    >
      <motion.div
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ type: 'spring', damping: 26, stiffness: 220 }}
        style={{ width: '100%', height: '100%', transformStyle: 'preserve-3d', position: 'relative' }}
      >
        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden',
          borderRadius: '18px', overflow: 'hidden',
          backgroundImage: 'linear-gradient(180deg,rgba(0,0,0,.06),rgba(0,0,0,.8)),url(https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=900&q=85)',
           backgroundSize: 'cover', backgroundPosition: 'center',
          boxShadow: isDark ? '0 12px 48px rgba(0,0,0,0.5)' : '0 8px 32px rgba(0,0,0,0.14)',
        }}>
          <div style={{ position: 'absolute', top: '-48px', right: '-36px', width: '170px', height: '170px', borderRadius: '50%', background: 'rgba(255,255,255,0.12)' }} />
          <div style={{ position: 'absolute', bottom: '-40px', left: '-26px', width: '130px', height: '130px', borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />

          <div style={{ position: 'relative', padding: '28px 24px', height: '100%', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
            <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: 'rgba(255,255,255,0.22)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <Briefcase size={22} color="#fff" />
            </div>

            <div style={{ fontFamily: 'Inter', fontSize: '20px', fontWeight: 800, color: '#fff', letterSpacing: '-0.01em', marginBottom: '6px' }}>
              Prestataires
            </div>
            <div style={{ fontFamily: 'Inter', fontSize: '12px', color: 'rgba(255,255,255,0.75)', lineHeight: 1.5, marginBottom: 'auto' }}>
              {data.companyName || data.contactName
                ? [data.companyName || data.contactName, data.category].filter(Boolean).join(' · ')
                : 'Présentez votre activité aux futurs mariés'}
            </div>

            {(data.city || data.serviceArea) && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '12px' }}>
                <MapPin size={11} color="rgba(255,255,255,0.72)" />
                <span style={{ fontFamily: 'Inter', fontSize: '11px', color: 'rgba(255,255,255,0.72)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {data.city || data.serviceArea}
                </span>
              </div>
            )}

            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <svg width="36" height="36">
                <circle cx="18" cy="18" r="14" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
                <circle
                  cx="18" cy="18" r="14" fill="none" stroke="rgba(255,255,255,0.88)" strokeWidth="3"
                  strokeDasharray={`${2 * Math.PI * 14}`}
                  strokeDashoffset={`${2 * Math.PI * 14 * (1 - completion / 100)}`}
                  strokeLinecap="round" transform="rotate(-90 18 18)"
                  style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                />
                <text x="18" y="22" textAnchor="middle" style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, fill: '#fff' }}>
                  {completion}%
                </text>
              </svg>
              <button
                onClick={() => setFlipped(true)}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px',
                  padding: '8px 14px', borderRadius: '9px',
                  background: 'rgba(255,255,255,0.22)', border: '1px solid rgba(255,255,255,0.28)',
                  color: '#fff', fontFamily: 'Inter', fontSize: '11px', fontWeight: 700,
                  cursor: 'pointer', backdropFilter: 'blur(8px)',
                }}
              >
                {isComplete || completion === 100 ? <Check size={12} /> : null}
                {completion === 0 ? 'Créer mon profil' : completion === 100 ? 'Complet' : 'Continuer'}
                <ChevronRight size={11} />
              </button>
            </div>
          </div>
        </div>

        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden',
          transform: 'rotateY(180deg)', borderRadius: '18px', overflow: 'hidden',
          background: surf,
          boxShadow: isDark ? '0 12px 48px rgba(0,0,0,0.5)' : '0 8px 32px rgba(0,0,0,0.12)',
          display: 'flex', flexDirection: 'column', border: `1px solid ${border}`,
        }}>
          <div style={{ padding: '14px 16px 10px', borderBottom: `1px solid ${border}`, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', gap: '6px' }}>
              {SECTIONS.map((item, index) => (
                <button
                  key={item.id}
                  onClick={() => setSection(index)}
                  title={item.label}
                  style={{
                    width: '22px', height: '22px', borderRadius: '6px', border: 'none',
                    background: section === index ? 'rgba(255,255,255,0.1)' : 'transparent',
                    color: section === index ? accent : tm,
                    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}
                >
                  {React.cloneElement(item.icon as React.ReactElement, { size: 11 })}
                </button>
              ))}
            </div>
            <button
              onClick={() => setFlipped(false)}
              style={{ width: '22px', height: '22px', borderRadius: '6px', border: 'none', background: 'transparent', cursor: 'pointer', color: tm, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            >
              <RotateCcw size={11} />
            </button>
          </div>

          <div style={{ padding: '8px 16px 4px', flexShrink: 0 }}>
            <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: accent }}>
              {SECTIONS[section].label}
            </span>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '4px 16px 14px', scrollbarWidth: 'none' }}>
            <AnimatePresence mode="wait">
              <motion.div key={section} initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }} transition={{ duration: 0.15 }}>
                {section === 0 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <Field label="Nom commercial" value={data.companyName} onChange={(v) => set('companyName', v)} placeholder="Studio, domaine, artiste…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                    <Field label="Votre nom" value={data.contactName} onChange={(v) => set('contactName', v)} placeholder="Prénom et nom" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                    <div>
                      <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '6px' }}>Catégorie</span>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                        {CATEGORIES.map((category) => (
                          <Chip key={category} label={category} active={data.category === category} onClick={() => set('category', data.category === category ? '' : category)} accent={accent} />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {section === 1 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <TextArea label="Présentation" value={data.description} onChange={(v) => set('description', v)} placeholder="Votre spécialité, votre approche, ce qui vous rend unique…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                    <Field label="Disponibilités" value={data.availability} onChange={(v) => set('availability', v)} placeholder="Week-ends, saison, délai…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                  </div>
                )}

                {section === 2 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <Field label="Ville de départ" value={data.city} onChange={(v) => set('city', v)} placeholder="Lille, Paris, Lyon…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                    <Field label="Zone d’intervention" value={data.serviceArea} onChange={(v) => set('serviceArea', v)} placeholder="100 km, France, Europe…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                  </div>
                )}

                {section === 3 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <IconField icon={<Mail size={11} />} label="E-mail" value={data.email} onChange={(v) => set('email', v)} placeholder="contact@…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} type="email" />
                    <IconField icon={<Phone size={11} />} label="Téléphone" value={data.phone} onChange={(v) => set('phone', v)} placeholder="06…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} type="tel" />
                    <IconField icon={<Globe size={11} />} label="Site web" value={data.website} onChange={(v) => set('website', v)} placeholder="https://…" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                    <Field label="Instagram" value={data.instagram} onChange={(v) => set('instagram', v)} placeholder="@votrecompte" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                  </div>
                )}

                {section === 4 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts }}>Tarif à partir de</span>
                        <span style={{ fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, color: accent }}>{(data.priceFrom || 0).toLocaleString('fr-FR')} €</span>
                      </div>
                      <input type="range" min={0} max={10000} step={50} value={data.priceFrom || 0} onChange={(e) => set('priceFrom', Number(e.target.value))} style={{ width: '100%', accentColor: accent }} />
                    </div>
                    <Field label="SIRET (privé)" value={data.siret} onChange={(v) => set('siret', v)} placeholder="14 chiffres" inputStyle={inputStyle} border={border} ts={ts} accent={accent} />
                    <ToggleLine label="Accepter les demandes en ligne" active={data.acceptsOnlineBooking} onClick={() => set('acceptsOnlineBooking', !data.acceptsOnlineBooking)} accent={accent} surf2={surf2} border={border} tp={tp} />
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          <div style={{ padding: '10px 16px', borderTop: `1px solid ${border}`, flexShrink: 0, display: 'flex', gap: '6px' }}>
            {section < SECTIONS.length - 1 ? (
              <button
                onClick={() => setSection((value) => value + 1)}
                style={{ flex: 1, padding: '8px', borderRadius: '8px', border: 'none', background: accent, color: '#fff', fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}
              >
                Suivant <ChevronRight size={12} />
              </button>
            ) : (
              <button
                onClick={() => { onComplete(data); setFlipped(false); }}
                style={{ flex: 1, padding: '8px', borderRadius: '8px', border: 'none', background: completion >= 40 ? accent : 'rgba(110,106,216,0.35)', color: '#fff', fontFamily: 'Inter', fontSize: '11px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}
              >
                <Check size={12} /> Enregistrer
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

interface FieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  inputStyle: React.CSSProperties;
  border: string;
  ts: string;
  accent: string;
}

const Field: React.FC<FieldProps> = ({ label, value, onChange, placeholder, type = 'text', inputStyle, border, ts, accent }) => (
  <div>
    <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '4px' }}>{label}</span>
    <input
      type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} style={inputStyle}
      onFocus={(e) => { e.currentTarget.style.borderColor = accent; }}
      onBlur={(e) => { e.currentTarget.style.borderColor = border; }}
    />
  </div>
);

const IconField: React.FC<FieldProps & { icon: React.ReactNode }> = ({ icon, ...props }) => (
  <div style={{ position: 'relative' }}>
    <div style={{ position: 'absolute', left: 9, bottom: 10, color: props.ts, pointerEvents: 'none', zIndex: 1 }}>{icon}</div>
    <Field {...props} inputStyle={{ ...props.inputStyle, paddingLeft: '28px' }} />
  </div>
);

const TextArea: React.FC<Omit<FieldProps, 'type'>> = ({ label, value, onChange, placeholder, inputStyle, border, ts, accent }) => (
  <div>
    <span style={{ fontFamily: 'Inter', fontSize: '9px', fontWeight: 600, color: ts, display: 'block', marginBottom: '4px' }}>{label}</span>
    <textarea
      value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)}
      style={{ ...inputStyle, minHeight: '86px', resize: 'vertical', lineHeight: 1.45 }}
      onFocus={(e) => { e.currentTarget.style.borderColor = accent; }}
      onBlur={(e) => { e.currentTarget.style.borderColor = border; }}
    />
  </div>
);

const Chip: React.FC<{ label: string; active: boolean; onClick: () => void; accent: string }> = ({ label, active, onClick, accent }) => (
  <button
    onClick={onClick}
    style={{
      padding: '4px 8px', borderRadius: '50px', border: 'none', cursor: 'pointer',
      fontFamily: 'Inter', fontSize: '9px', fontWeight: active ? 700 : 400,
      background: active ? 'rgba(110,106,216,0.18)' : 'transparent',
      color: active ? accent : '#9B9BAA',
      outline: `1px solid ${active ? 'rgba(110,106,216,0.42)' : 'rgba(0,0,0,0.1)'}`,
      transition: 'all 0.12s',
    }}
  >
    {label}
  </button>
);

const ToggleLine: React.FC<{ label: string; active: boolean; onClick: () => void; accent: string; surf2: string; border: string; tp: string }> = ({ label, active, onClick, accent, surf2, border, tp }) => (
  <button
    onClick={onClick}
    style={{ width: '100%', border: `1px solid ${border}`, background: surf2, borderRadius: '8px', padding: '9px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', color: tp }}
  >
    <span style={{ fontFamily: 'Inter', fontSize: '10px', fontWeight: 600 }}>{label}</span>
    <span style={{ width: '32px', height: '18px', borderRadius: '20px', background: active ? accent : 'rgba(120,120,130,0.25)', padding: '2px', boxSizing: 'border-box', display: 'flex', justifyContent: active ? 'flex-end' : 'flex-start', transition: 'all 0.2s' }}>
      <span style={{ width: '14px', height: '14px', borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
    </span>
  </button>
);
