import React, { useRef } from 'react';
import { Copy, Lock, MoreHorizontal, Palette, Trash2, Unlock } from 'lucide-react';
import type { Tool } from '../types';

export interface CanvasNoteData {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  locked?: boolean;
  hidden?: boolean;
  zIndex?: number;
}

interface CanvasNoteProps {
  note: CanvasNoteData;
  scale: number;
  activeTool: Tool;
  selected: boolean;
  snapEnabled?: boolean;
  gridSize?: number;
  onSelect: (id: string) => void;
  onChange: (id: string, patch: Partial<CanvasNoteData>) => void;
  onDelete: (id: string) => void;
  onDuplicate: (id: string) => void;
  onOpenMenu?: (event: React.MouseEvent<HTMLButtonElement>, id: string) => void;
}

const COLORS = ['#FFF1A8', '#FFD0D8', '#CDEBFF', '#D9F5CF', '#E6D6FF', '#FFE0B8'];

export const CanvasNote: React.FC<CanvasNoteProps> = ({
  note,
  scale,
  activeTool,
  selected,
  snapEnabled = true,
  gridSize = 28,
  onSelect,
  onChange,
  onDelete,
  onDuplicate,
  onOpenMenu,
}) => {
  const drag = useRef<{ pointerId: number; clientX: number; clientY: number; x: number; y: number } | null>(null);

  if (note.hidden) return null;

  const startDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    event.stopPropagation();
    event.preventDefault();
    onSelect(note.id);
    if (note.locked || activeTool !== 'select') return;
    drag.current = { pointerId: event.pointerId, clientX: event.clientX, clientY: event.clientY, x: note.x, y: note.y };
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const moveDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!drag.current || drag.current.pointerId !== event.pointerId) return;
    event.stopPropagation();
    const rawX = drag.current.x + (event.clientX - drag.current.clientX) / Math.max(scale, 0.01);
    const rawY = drag.current.y + (event.clientY - drag.current.clientY) / Math.max(scale, 0.01);
    onChange(note.id, {
      x: snapEnabled ? Math.round(rawX / gridSize) * gridSize : rawX,
      y: snapEnabled ? Math.round(rawY / gridSize) * gridSize : rawY,
    });
  };

  const stopDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!drag.current || drag.current.pointerId !== event.pointerId) return;
    drag.current = null;
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch { /* already released */ }
  };

  const cycleColor = () => {
    const index = COLORS.indexOf(note.color);
    onChange(note.id, { color: COLORS[(index + 1 + COLORS.length) % COLORS.length] });
  };

  const controlPointer = (event: React.PointerEvent) => {
    event.stopPropagation();
  };

  return (
    <div
      data-canvas-object
      onClick={(event) => { event.stopPropagation(); onSelect(note.id); }}
      style={{
        position: 'absolute', left: note.x, top: note.y, width: 190, minHeight: 150,
        borderRadius: '4px 4px 12px 4px', background: note.color,
        boxShadow: '0 14px 28px rgba(0,0,0,0.2)', overflow: 'visible',
        transform: 'rotate(-0.6deg)', color: '#2A241B', zIndex: note.zIndex || 20,
        outline: selected ? '2px solid #8B5CF6' : '1px solid transparent', outlineOffset: 5,
      }}
    >
      <div style={{ borderRadius: '4px 4px 12px 4px', overflow: 'hidden', background: note.color }}>
        <div
          onPointerDown={startDrag}
          onPointerMove={moveDrag}
          onPointerUp={stopDrag}
          onPointerCancel={stopDrag}
          style={{
            height: 30, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0 8px 0 11px', cursor: note.locked ? 'not-allowed' : activeTool === 'select' ? 'grab' : 'default',
            borderBottom: '1px solid rgba(40,32,18,0.08)', touchAction: 'none',
          }}
        >
          <span style={{ fontFamily: 'Inter', fontSize: 8, fontWeight: 800, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.45 }}>
            Note
          </span>
          <div onPointerDown={controlPointer} style={{ display: 'flex', gap: 2 }}>
            <NoteButton title="Changer la couleur" onClick={cycleColor}><Palette size={12} /></NoteButton>
            <NoteButton title="Dupliquer" onClick={() => onDuplicate(note.id)}><Copy size={12} /></NoteButton>
            {onOpenMenu && <button type="button" title="Remix, modifier, partager et gérer" onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onOpenMenu(event, note.id); }} style={{ width: 24, height: 24, border: 'none', background: 'transparent', cursor: 'pointer', display: 'grid', placeItems: 'center', color: 'rgba(42,36,27,0.5)' }}><MoreHorizontal size={12} /></button>}
            <NoteButton title={note.locked ? 'Déverrouiller' : 'Verrouiller'} onClick={() => onChange(note.id, { locked: !note.locked })}>
              {note.locked ? <Unlock size={12} /> : <Lock size={12} />}
            </NoteButton>
            <NoteButton title="Supprimer" onClick={() => onDelete(note.id)}><Trash2 size={12} /></NoteButton>
          </div>
        </div>
        <textarea
          value={note.text}
          onChange={(event) => onChange(note.id, { text: event.target.value })}
          placeholder="Écrire une note…"
          autoFocus={!note.text}
          style={{
            display: 'block', width: '100%', minHeight: 120, resize: 'none', border: 'none', outline: 'none',
            background: 'transparent', padding: '12px 14px 16px', boxSizing: 'border-box',
            fontFamily: 'Inter', fontSize: 13, lineHeight: 1.55, color: '#2A241B',
          }}
          onPointerDown={(event) => event.stopPropagation()}
          onClick={(event) => event.stopPropagation()}
        />
      </div>
    </div>
  );
};

const NoteButton: React.FC<{ title: string; onClick: () => void; children: React.ReactNode }> = ({ title, onClick, children }) => (
  <button
    type="button"
    title={title}
    onPointerDown={(event) => { event.stopPropagation(); }}
    onClick={(event) => { event.stopPropagation(); onClick(); }}
    style={{ width: 24, height: 24, border: 'none', background: 'transparent', cursor: 'pointer', display: 'grid', placeItems: 'center', color: 'rgba(42,36,27,0.5)' }}
  >
    {children}
  </button>
);
