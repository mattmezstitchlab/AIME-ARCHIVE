import React, { useMemo, useState } from 'react';
import { ChevronRight, X } from 'lucide-react';
import { motion } from 'motion/react';
import type { WeddingLot } from '../types';
import { ICON_MAP } from '../utils/iconMap';
import { useTheme } from '../contexts/ThemeContext';
import { getStudioTokens } from '../theme/studioTokens';

interface ChecklistPanelProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  weddingDate: string;
  onClose: () => void;
}

type Priority = 'urgent' | 'important' | 'a-prevoir' | 'fait';
const MONTHS: Record<string, number> = { janvier: 0, février: 1, mars: 2, avril: 3, mai: 4, juin: 5, juillet: 6, août: 7, septembre: 8, octobre: 9, novembre: 10, décembre: 11 };
const ORDER: Record<Priority, number> = { urgent: 0, important: 1, 'a-prevoir': 2, fait: 3 };
const LABELS: Record<Priority, string> = { urgent: 'Urgent', important: 'Important', 'a-prevoir': 'À prévoir', fait: 'Fait' };

function parseDate(value: string) {
  const parts = value.toLowerCase().trim().split(/\s+/);
  if (parts.length < 3) return null;
  const day = Number(parts[0]); const month = MONTHS[parts[1]]; const year = Number(parts[2]);
  return Number.isFinite(day) && month !== undefined && Number.isFinite(year) ? new Date(year, month, day) : null;
}

export const ChecklistPanel: React.FC<ChecklistPanelProps> = ({ lots, cardSettings, weddingDate, onClose }) => {
  const { isDark } = useTheme();
  const tokens = getStudioTokens(isDark);
  const [report, setReport] = useState<string | null>(null);
  const parsed = useMemo(() => parseDate(weddingDate), [weddingDate]);
  const days = useMemo(() => parsed ? Math.ceil((parsed.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000) : null, [parsed]);
  const items = useMemo(() => {
    const result: Array<{ id: string; name: string; icon: string; lot: string; priority: Priority }> = [];
    lots.forEach((lot) => lot.cards.forEach((card) => {
      const status = cardSettings[card.id]?.status;
      const priority: Priority = status === 'confirmed' || status === 'paid' ? 'fait' : days !== null && days < 90 ? 'urgent' : days !== null && days < 180 ? 'important' : 'a-prevoir';
      result.push({ id: card.id, name: card.name, icon: card.icon, lot: lot.title, priority });
    }));
    return result.sort((a, b) => ORDER[a.priority] - ORDER[b.priority]);
  }, [cardSettings, days, lots]);
  const done = items.filter((item) => item.priority === 'fait').length;
  const progress = items.length ? done / items.length * 100 : 0;
  const tone = (priority: Priority) => priority === 'urgent' ? tokens.danger : priority === 'important' ? tokens.warning : priority === 'fait' ? tokens.success : tokens.muted;

  const createReport = () => {
    const open = items.filter((item) => item.priority !== 'fait');
    const urgent = open.filter((item) => item.priority === 'urgent');
    setReport([
      'Diagnostic local de préparation',
      '',
      `${done} élément(s) terminé(s) sur ${items.length}.`,
      urgent.length ? `${urgent.length} action(s) deviennent urgentes au regard de la date renseignée.` : 'Aucune urgence calculée à partir de la date renseignée.',
      open.length ? `Prochaine action suggérée : ${open[0].name} — ${open[0].lot}.` : 'Toutes les cartes suivies sont confirmées ou payées.',
      '',
      'Ce diagnostic est calculé localement depuis les statuts du projet. Il ne constitue pas une analyse distante par intelligence artificielle.',
    ].join('\n'));
  };

  return <aside style={{ position: 'fixed', top: 50, right: 0, bottom: 0, width: 'min(390px,calc(100vw - 24px))', zIndex: 520, background: tokens.surface, color: tokens.text, borderLeft: `1px solid ${tokens.border}`, display: 'flex', flexDirection: 'column', boxShadow: '-18px 0 54px rgba(0,0,0,.28)', fontFamily: 'Inter, sans-serif' }}>
    <header style={{ minHeight: 54, padding: '0 16px', display: 'flex', alignItems: 'center', borderBottom: `1px solid ${tokens.border}` }}><div style={{ flex: 1 }}><div style={{ fontSize: 14, fontWeight: 800 }}>Checklist</div><div style={{ marginTop: 2, color: tokens.muted, fontSize: 8.5 }}>{days === null ? 'Date à définir' : days >= 0 ? `J-${days}` : `J+${Math.abs(days)}`}</div></div><button onClick={onClose} style={{ width: 30, height: 30, display: 'grid', placeItems: 'center', border: 0, borderRadius: 8, background: 'transparent', color: tokens.muted, cursor: 'pointer' }}><X size={16} /></button></header>
    <div style={{ padding: '11px 16px', borderBottom: `1px solid ${tokens.border}` }}><div style={{ display: 'flex', justifyContent: 'space-between', color: tokens.muted, fontSize: 8.5, marginBottom: 6 }}><span>Progression</span><strong style={{ color: tokens.text }}>{done} / {items.length}</strong></div><div style={{ height: 5, borderRadius: 99, background: tokens.surface3, overflow: 'hidden' }}><motion.div initial={{ width: 0 }} animate={{ width: `${progress}%` }} style={{ height: '100%', background: tokens.selection }} /></div></div>
    <div style={{ flex: 1, overflowY: 'auto', padding: 12, scrollbarWidth: 'none' }}>{items.map((item, index) => { const Icon = ICON_MAP[item.icon]; const complete = item.priority === 'fait'; return <motion.div key={item.id} initial={{ opacity: 0, x: 12 }} animate={{ opacity: complete ? .52 : 1, x: 0 }} transition={{ delay: Math.min(index * .02, .25) }} style={{ minHeight: 46, display: 'flex', alignItems: 'center', gap: 9, padding: '7px 9px', marginBottom: 5, borderRadius: 9, background: tokens.surface2, border: `1px solid ${tokens.border}` }}><span style={{ padding: '3px 6px', borderRadius: 6, background: tokens.surface3, color: tone(item.priority), fontSize: 7.5, fontWeight: 800 }}>{LABELS[item.priority]}</span>{Icon && <Icon size={13} color={tokens.muted} />}<div style={{ minWidth: 0, flex: 1 }}><div style={{ fontSize: 9.8, fontWeight: 650, textDecoration: complete ? 'line-through' : 'none', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</div><div style={{ marginTop: 2, fontSize: 8, color: tokens.muted }}>{item.lot}</div></div>{!complete && <ChevronRight size={12} color={tokens.faint} />}</motion.div>; })}</div>
    <footer style={{ padding: 12, borderTop: `1px solid ${tokens.border}` }}>{report && <pre style={{ maxHeight: 150, overflowY: 'auto', margin: '0 0 8px', padding: 10, borderRadius: 9, background: tokens.surface2, border: `1px solid ${tokens.border}`, color: tokens.muted, fontFamily: 'Inter, sans-serif', fontSize: 8.8, lineHeight: 1.55, whiteSpace: 'pre-wrap' }}>{report}</pre>}<button onClick={createReport} style={{ width: '100%', height: 36, borderRadius: 9, border: 0, background: tokens.primary, color: tokens.primaryText, cursor: 'pointer', fontSize: 9.5, fontWeight: 800 }}>Générer le diagnostic local</button></footer>
  </aside>;
};
