import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SkipBack, SkipForward, Play, Pause } from 'lucide-react';
import type { WeddingLot } from '../types';
import type { PlaylistSuggestion } from './CollaborativePlaylistPanel';

interface MusicPlayerBarProps {
  lots: WeddingLot[];
  cardSettings: Record<string, Record<string, any>>;
  collaborativeSuggestions?: PlaylistSuggestion[];
}

interface Track {
  title: string;
  artist: string;
  duration: string;
  gradient: string;
  cardName: string;
  cardId: string;
}

const MUSIC_LOT_IDS = [9, 10];

export const MusicPlayerBar: React.FC<MusicPlayerBarProps> = ({ lots, cardSettings, collaborativeSuggestions = [] }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const thumbRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Collect all tracks from music lots
  const tracks: Track[] = [];
  for (const lot of lots) {
    if (!MUSIC_LOT_IDS.includes(lot.id)) continue;
    for (const card of lot.cards) {
      const settings = cardSettings[card.id];
      const playlist: Array<{ title: string; artist: string; duration: string }> =
        settings?.playlist ?? [];
      if (!Array.isArray(playlist) || playlist.length === 0) continue;
      for (const item of playlist) {
        tracks.push({
          title: item.title,
          artist: item.artist,
          duration: item.duration,
          gradient: card.gradient ?? 'linear-gradient(135deg,#667EEA,#764BA2)',
          cardName: card.name,
          cardId: card.id,
        });
      }
    }
  }

  for (const item of collaborativeSuggestions) {
    if (item.status !== 'approved') continue;
    tracks.push({
      title: item.title, artist: item.artist, duration: '',
      gradient: 'linear-gradient(135deg,#5D43D7,#9686FF)',
      cardName: `Invités · ${item.moment}`, cardId: item.id,
    });
  }

  // Don't render if no tracks
  if (tracks.length === 0) return null;

  const current = tracks[currentIndex] ?? null;

  const handlePrev = () => {
    setCurrentIndex((i) => (i - 1 + tracks.length) % tracks.length);
  };

  const handleNext = () => {
    setCurrentIndex((i) => (i + 1) % tracks.length);
  };

  const handlePlayPause = () => {
    setIsPlaying((p) => !p);
  };

  // Auto-scroll to center the active thumbnail
  useEffect(() => {
    const container = scrollRef.current;
    const thumb = thumbRefs.current[currentIndex];
    if (!container || !thumb) return;
    const containerRect = container.getBoundingClientRect();
    const thumbRect = thumb.getBoundingClientRect();
    const offset =
      thumbRect.left - containerRect.left - containerRect.width / 2 + thumbRect.width / 2;
    container.scrollBy({ left: offset, behavior: 'smooth' });
  }, [currentIndex]);

  return (
    <motion.div
      initial={{ y: 80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 280, damping: 32 }}
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        height: 72,
        background: 'rgba(8, 6, 18, 0.96)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        borderTop: '1px solid rgba(255,255,255,0.06)',
        zIndex: 300,
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        gap: 12,
        boxSizing: 'border-box',
      }}
    >
      {/* LEFT: current track info (220px fixed) */}
      <div
        style={{
          width: 220,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          overflow: 'hidden',
        }}
      >
        <AnimatePresence mode="wait" initial={false}>
          {current && (
            <motion.div
              key={`art-${currentIndex}`}
              initial={{ x: 24, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -24, opacity: 0 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              style={{
                width: 40,
                height: 40,
                borderRadius: 8,
                background: current.gradient,
                flexShrink: 0,
              }}
            />
          )}
        </AnimatePresence>
        <AnimatePresence mode="wait" initial={false}>
          {current && (
            <motion.div
              key={`info-${currentIndex}`}
              initial={{ x: 24, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -24, opacity: 0 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              style={{ overflow: 'hidden', minWidth: 0 }}
            >
              <div
                style={{
                  color: '#ffffff',
                  fontSize: 13,
                  fontWeight: 600,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  lineHeight: '1.3',
                }}
              >
                {current.title}
              </div>
              <div
                style={{
                  color: 'rgba(255,255,255,0.4)',
                  fontSize: 10,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  lineHeight: '1.3',
                  marginTop: 2,
                }}
              >
                {current.cardName}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* CENTER: controls */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 16,
          flexShrink: 0,
        }}
      >
        <button
          onClick={handlePrev}
          disabled={!current}
          style={{
            background: 'none',
            border: 'none',
            cursor: current ? 'pointer' : 'default',
            padding: 4,
            display: 'flex',
            alignItems: 'center',
            color: current ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.2)',
            transition: 'color 0.15s',
          }}
        >
          <SkipBack size={18} />
        </button>

        <button
          onClick={handlePlayPause}
          disabled={!current}
          style={{
            width: 40,
            height: 40,
            borderRadius: '50%',
            background: current ? '#ffffff' : 'rgba(255,255,255,0.15)',
            border: 'none',
            cursor: current ? 'pointer' : 'default',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#08060F',
            flexShrink: 0,
            transition: 'background 0.15s',
          }}
        >
          {isPlaying ? <Pause size={18} /> : <Play size={18} />}
        </button>

        <button
          onClick={handleNext}
          disabled={!current}
          style={{
            background: 'none',
            border: 'none',
            cursor: current ? 'pointer' : 'default',
            padding: 4,
            display: 'flex',
            alignItems: 'center',
            color: current ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.2)',
            transition: 'color 0.15s',
          }}
        >
          <SkipForward size={18} />
        </button>
      </div>

      {/* RIGHT: horizontally scrollable thumbnail strip */}
      <div
        ref={scrollRef}
        style={{
          flex: 1,
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          overflowX: 'auto',
          overflowY: 'hidden',
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
          padding: '4px 0',
        }}
      >
        {tracks.map((track, idx) => {
          const isActive = idx === currentIndex;
          return (
            <div
              key={`${track.cardId}-${idx}`}
              ref={(el) => { thumbRefs.current[idx] = el; }}
              onClick={() => setCurrentIndex(idx)}
              style={{
                width: 40,
                height: 40,
                flexShrink: 0,
                borderRadius: 6,
                background: track.gradient,
                cursor: 'pointer',
                position: 'relative',
                overflow: 'hidden',
                boxSizing: 'border-box',
                outline: isActive ? '2px solid rgba(255,255,255,0.9)' : '2px solid transparent',
                outlineOffset: 1,
                transition: 'outline-color 0.15s',
              }}
            >
              {/* Fade-to-bottom overlay with title */}
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(to bottom, transparent 30%, rgba(0,0,0,0.65) 100%)',
                  display: 'flex',
                  alignItems: 'flex-end',
                  padding: '0 2px 2px',
                }}
              >
                <span
                  style={{
                    color: '#fff',
                    fontSize: 6,
                    fontWeight: 600,
                    lineHeight: 1.1,
                    overflow: 'hidden',
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    textOverflow: 'ellipsis',
                    wordBreak: 'break-word',
                  }}
                >
                  {track.title}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
};
