import React, { useEffect, useRef, useState } from 'react';
import { Image, Video, Upload, Link2, MonitorUp, CreditCard, Globe2, Clock3, MousePointer2 } from 'lucide-react';
import type { BgSettings, CanvasElementData } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { PanelShell } from './StudioAddPanel';
import { toast } from 'sonner';
import { fileToPersistentMedia } from '../utils/persistentMedia';

export type MediaTarget = 'canvas' | 'element' | 'lot-front' | 'lot-back' | 'minisite-hero' | 'timeline';

export interface MediaPatch {
  type: 'image' | 'video';
  url: string;
  fit: 'cover' | 'contain';
  opacity: number;
  blur: number;
  overlay: string;
  muted: boolean;
  loop: boolean;
  playbackRate: number;
}

interface StudioMediaPanelProps {
  bg: BgSettings;
  selectedElement: CanvasElementData | null;
  activeLotTitle?: string;
  heroPhoto: string;
  heroMediaType: 'image' | 'video';
  timelineMedia: MediaPatch;
  onCanvasChange: (bg: BgSettings) => void;
  onElementChange: (patch: Partial<CanvasElementData>) => void;
  onApplyLotMedia: (side: 'front' | 'back', patch: MediaPatch) => void;
  onHeroPhotoChange: (url: string, type: 'image' | 'video') => void;
  onTimelineMediaChange: (patch: MediaPatch) => void;
  onClose: () => void;
}

const DEFAULT: MediaPatch = {
  type: 'image', url: '', fit: 'cover', opacity: 1, blur: 0, overlay: 'transparent', muted: true, loop: true, playbackRate: 1,
};

export const StudioMediaPanel: React.FC<StudioMediaPanelProps> = ({
  bg, selectedElement, activeLotTitle, heroPhoto, heroMediaType, timelineMedia,
  onCanvasChange, onElementChange, onApplyLotMedia, onHeroPhotoChange, onTimelineMediaChange, onClose,
}) => {
  const { isDark } = useTheme();
  const [target, setTarget] = useState<MediaTarget>(selectedElement ? 'element' : 'canvas');
  const [draft, setDraft] = useState<MediaPatch>(DEFAULT);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (target === 'canvas') {
      setDraft({
        ...DEFAULT,
        type: bg.type === 'video' ? 'video' : 'image',
        url: bg.type === 'image' || bg.type === 'video' ? bg.value : '',
        fit: bg.fit || 'cover', opacity: bg.opacity ?? 1, blur: bg.blur ?? 0,
        overlay: bg.overlay || 'transparent', muted: bg.muted !== false, loop: bg.loop !== false, playbackRate: bg.playbackRate || 1,
      });
    } else if (target === 'element' && selectedElement) {
      setDraft({
        ...DEFAULT,
        type: selectedElement.type === 'video' ? 'video' : 'image', url: selectedElement.url,
        fit: selectedElement.style.objectFit, opacity: selectedElement.style.opacity, blur: selectedElement.style.blur,
        overlay: selectedElement.style.overlay, muted: selectedElement.videoMuted !== false,
        loop: selectedElement.videoLoop !== false, playbackRate: selectedElement.videoRate || 1,
      });
    } else if (target === 'minisite-hero') {
      setDraft({ ...DEFAULT, type: heroMediaType, url: heroPhoto });
    } else if (target === 'timeline') {
      setDraft(timelineMedia);
    } else {
      setDraft(DEFAULT);
    }
  }, [target, selectedElement?.id, bg, heroPhoto, heroMediaType, timelineMedia]);

  const apply = (next: MediaPatch = draft) => {
    if (target === 'canvas') {
      onCanvasChange({ type: next.type, value: next.url, fit: next.fit, opacity: next.opacity, blur: next.blur, overlay: next.overlay, muted: next.muted, loop: next.loop, playbackRate: next.playbackRate });
    } else if (target === 'element' && selectedElement) {
      const canSwitchMediaType = selectedElement.type === 'image' || selectedElement.type === 'video';
      onElementChange({
        ...(canSwitchMediaType ? { type: next.type } : {}),
        url: next.url,
        style: { ...selectedElement.style, objectFit: next.fit, opacity: next.opacity, blur: next.blur, overlay: next.overlay },
        videoMuted: next.muted, videoLoop: next.loop, videoRate: next.playbackRate,
      });
    } else if (target === 'lot-front') onApplyLotMedia('front', next);
    else if (target === 'lot-back') onApplyLotMedia('back', next);
    else if (target === 'minisite-hero') onHeroPhotoChange(next.url, next.type);
    else if (target === 'timeline') onTimelineMediaChange(next);
  };

  const patch = (value: Partial<MediaPatch>, live = true) => {
    const next = { ...draft, ...value };
    setDraft(next);
    if (live) apply(next);
  };

  const importFile = async (file?: File) => {
    if (!file) return;
    const type: 'image' | 'video' = file.type.startsWith('video/') ? 'video' : 'image';
    const media = await fileToPersistentMedia(file);
    patch({ type, url: media.url });
    if (!media.persistent) toast.warning('Cette vidéo volumineuse restera liée à la session. Utilisez une URL hébergée pour une conservation permanente.');
  };

  const targets: Array<{ id: MediaTarget; label: string; icon: React.ReactNode; disabled?: boolean }> = [
    { id: 'canvas', label: 'Canevas', icon: <MonitorUp size={13} /> },
    { id: 'element', label: 'Objet sélectionné', icon: <MousePointer2 size={13} />, disabled: !selectedElement },
    { id: 'lot-front', label: `Recto${activeLotTitle ? ` · ${activeLotTitle}` : ''}`, icon: <CreditCard size={13} />, disabled: !activeLotTitle },
    { id: 'lot-back', label: `Verso${activeLotTitle ? ` · ${activeLotTitle}` : ''}`, icon: <CreditCard size={13} />, disabled: !activeLotTitle },
    { id: 'minisite-hero', label: 'Hero mini-site', icon: <Globe2 size={13} /> },
    { id: 'timeline', label: 'Timeline', icon: <Clock3 size={13} /> },
  ];

  return (
    <PanelShell title="Médias" subtitle="Une source, plusieurs destinations" onClose={onClose} isDark={isDark} width={310}>
      <Label isDark={isDark}>Appliquer à</Label>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 13 }}>
        {targets.map((item) => (
          <button key={item.id} disabled={item.disabled} onClick={() => setTarget(item.id)} style={{
            display: 'flex', alignItems: 'center', gap: 5, borderRadius: 8, padding: '6px 8px', cursor: item.disabled ? 'not-allowed' : 'pointer',
            border: `1px solid ${target === item.id ? '#8B5CF6' : isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}`,
            background: target === item.id ? 'rgba(139,92,246,.16)' : 'transparent', color: isDark ? '#F3EFFF' : '#211A2C',
            fontFamily: 'Inter', fontSize: 9, opacity: item.disabled ? .35 : 1,
          }}>{item.icon}{item.label}</button>
        ))}
      </div>

      <Label isDark={isDark}>Type de média</Label>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 10 }}>
        <Segment active={draft.type === 'image'} onClick={() => patch({ type: 'image' }, false)} isDark={isDark}><Image size={13} /> Image</Segment>
        <Segment active={draft.type === 'video'} onClick={() => patch({ type: 'video' }, false)} isDark={isDark}><Video size={13} /> Vidéo</Segment>
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <Link2 size={12} style={{ position: 'absolute', left: 9, top: 10, opacity: .4 }} />
          <input value={draft.url} onChange={(e) => setDraft({ ...draft, url: e.target.value })} onBlur={() => apply()} placeholder={target === 'element' && selectedElement?.type === 'embed' ? 'URL du site à intégrer…' : target === 'element' && selectedElement?.type === 'music' ? 'URL audio…' : 'URL image, vidéo ou fichier…'} style={inputStyle(isDark, 28)} />
        </div>
        <button onClick={() => fileInput.current?.click()} title="Importer un fichier" style={iconButton(isDark)}><Upload size={14} /></button>
      </div>
      <input ref={fileInput} type="file" accept="image/*,video/*" hidden onChange={(e) => { void importFile(e.target.files?.[0]); e.currentTarget.value = ''; }} />

      <Label isDark={isDark}>Cadrage</Label>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 11 }}>
        <Segment active={draft.fit === 'cover'} onClick={() => patch({ fit: 'cover' })} isDark={isDark}>Remplir</Segment>
        <Segment active={draft.fit === 'contain'} onClick={() => patch({ fit: 'contain' })} isDark={isDark}>Contenir</Segment>
      </div>

      <Range label="Opacité" value={draft.opacity} min={0.1} max={1} step={0.05} display={`${Math.round(draft.opacity * 100)}%`} onChange={(v) => patch({ opacity: v })} isDark={isDark} />
      <Range label="Flou" value={draft.blur} min={0} max={20} step={1} display={`${draft.blur}px`} onChange={(v) => patch({ blur: v })} isDark={isDark} />

      <Label isDark={isDark}>Voile coloré</Label>
      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
        {['transparent','rgba(0,0,0,.24)','rgba(9,5,35,.42)','rgba(196,149,106,.28)','rgba(255,255,255,.2)'].map((c) => (
          <button key={c} onClick={() => patch({ overlay: c })} title={c} style={{ width: 30, height: 30, borderRadius: 8, background: c === 'transparent' ? 'linear-gradient(135deg,#fff 48%,#f55 49%,#f55 53%,#fff 54%)' : c, border: draft.overlay === c ? '2px solid #8B5CF6' : `1px solid ${isDark ? 'rgba(255,255,255,.15)' : 'rgba(0,0,0,.12)'}`, cursor: 'pointer' }} />
        ))}
        <input type="color" onChange={(e) => patch({ overlay: `${e.target.value}66` })} style={{ width: 30, height: 30, padding: 0, border: 0, borderRadius: 8, background: 'transparent' }} />
      </div>

      {draft.type === 'video' && (
        <div style={{ padding: 10, borderRadius: 11, background: isDark ? 'rgba(255,255,255,.04)' : 'rgba(0,0,0,.03)' }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            <Toggle label="Boucle" active={draft.loop} onClick={() => patch({ loop: !draft.loop })} isDark={isDark} />
            <Toggle label="Muet" active={draft.muted} onClick={() => patch({ muted: !draft.muted })} isDark={isDark} />
          </div>
          <Range label="Vitesse" value={draft.playbackRate} min={0.5} max={2} step={0.25} display={`${draft.playbackRate}×`} onChange={(v) => patch({ playbackRate: v })} isDark={isDark} />
        </div>
      )}

      <button onClick={() => apply()} style={{ marginTop: 12, width: '100%', border: 0, borderRadius: 10, padding: '9px 12px', background: '#8B5CF6', color: '#fff', fontFamily: 'Inter', fontSize: 11, fontWeight: 800, cursor: 'pointer' }}>Appliquer le média</button>
    </PanelShell>
  );
};

const Label: React.FC<{ isDark: boolean; children: React.ReactNode }> = ({ children }) => <div style={{ fontFamily: 'Inter', fontSize: 8.5, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase', opacity: .42, marginBottom: 6 }}>{children}</div>;

const Segment: React.FC<{ active: boolean; onClick: () => void; isDark: boolean; children: React.ReactNode }> = ({ active, onClick, isDark, children }) => (
  <button onClick={onClick} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '7px 8px', borderRadius: 8, cursor: 'pointer', border: `1px solid ${active ? '#8B5CF6' : isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}`, background: active ? 'rgba(139,92,246,.16)' : 'transparent', color: 'inherit', fontFamily: 'Inter', fontSize: 9.5 }}>{children}</button>
);

const Toggle: React.FC<{ label: string; active: boolean; onClick: () => void; isDark: boolean }> = ({ label, active, onClick, isDark }) => (
  <button onClick={onClick} style={{ flex: 1, padding: '6px 8px', borderRadius: 8, cursor: 'pointer', border: `1px solid ${active ? '#8B5CF6' : isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}`, background: active ? 'rgba(139,92,246,.15)' : 'transparent', color: 'inherit', fontFamily: 'Inter', fontSize: 9 }}>{label}</button>
);

const Range: React.FC<{ label: string; value: number; min: number; max: number; step: number; display: string; onChange: (value: number) => void; isDark: boolean }> = ({ label, value, min, max, step, display, onChange }) => (
  <div style={{ marginBottom: 10 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Inter', fontSize: 9, marginBottom: 5 }}><span style={{ opacity: .5 }}>{label}</span><strong>{display}</strong></div>
    <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} style={{ width: '100%', accentColor: '#8B5CF6' }} />
  </div>
);

const inputStyle = (isDark: boolean, leftPad = 10): React.CSSProperties => ({ width: '100%', boxSizing: 'border-box', padding: `8px 8px 8px ${leftPad}px`, borderRadius: 8, border: `1px solid ${isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)'}`, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.025)', color: 'inherit', fontFamily: 'Inter', fontSize: 9.5, outline: 0 });
const iconButton = (isDark: boolean): React.CSSProperties => ({ width: 34, height: 34, borderRadius: 8, border: `1px solid ${isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)'}`, background: 'transparent', color: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' });
