import React, { useEffect, useState } from 'react';
import { CreditCard, MousePointer2, Layers3, Sparkles } from 'lucide-react';
import type { CanvasElementData, CanvasElementStyle } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { PanelShell } from './StudioAddPanel';

export type StyleTarget = 'element' | 'lot-front' | 'lot-back' | 'all-cards';

interface StudioStylePanelProps {
  selectedElement: CanvasElementData | null;
  activeLotTitle?: string;
  globalTexture: string;
  onElementChange: (patch: Partial<CanvasElementData>) => void;
  onApplyLotStyle: (side: 'front' | 'back', patch: Record<string, unknown>) => void;
  onApplyAllCardsStyle: (patch: Record<string, unknown>) => void;
  onGlobalTextureChange: (texture: string) => void;
  onClose: () => void;
}

const TEXTURES = [
  { id: '', label: 'Aucune', bg: '#eee' },
  { id: 'glow-violet', label: 'Violet', bg: 'radial-gradient(circle,#9b5cff,#1a0a2e)' },
  { id: 'glow-rose', label: 'Rose', bg: 'radial-gradient(circle,#fb7185,#2a0010)' },
  { id: 'aurora', label: 'Aurora', bg: 'linear-gradient(135deg,#34d399,#8b5cf6,#3b82f6)' },
  { id: 'marble', label: 'Marbre', bg: 'linear-gradient(135deg,#e8e0d8,#fff,#d8d0c8)' },
  { id: 'linen', label: 'Lin', bg: 'repeating-linear-gradient(90deg,#e8e0d5 0 2px,#f0e8de 2px 4px)' },
  { id: 'gold', label: 'Or', bg: 'linear-gradient(135deg,#b8860b,#ffd700,#daa520)' },
  { id: 'velvet', label: 'Velours', bg: 'radial-gradient(circle,#4a1464,#200830)' },
  { id: 'neon', label: 'Néon', bg: 'linear-gradient(135deg,#00ffaa,#0064ff,#ff0096)' },
  { id: 'dark-glass', label: 'Verre', bg: 'linear-gradient(135deg,#1e2030,#505078,#1e2030)' },
];

const DEFAULT_STYLE: CanvasElementStyle = {
  background: 'rgba(255,255,255,.12)', color: '#ffffff', fontSize: 22, fontFamily: 'Inter', fontWeight: 700,
  textAlign: 'left', borderRadius: 18, opacity: 1, blur: 0, borderWidth: 0, borderColor: '#ffffff', shadow: 20,
  objectFit: 'cover', overlay: 'transparent',
};

export const StudioStylePanel: React.FC<StudioStylePanelProps> = ({
  selectedElement, activeLotTitle, globalTexture, onElementChange, onApplyLotStyle, onApplyAllCardsStyle, onGlobalTextureChange, onClose,
}) => {
  const { isDark } = useTheme();
  const [target, setTarget] = useState<StyleTarget>(selectedElement ? 'element' : activeLotTitle ? 'lot-front' : 'all-cards');
  const [draft, setDraft] = useState<CanvasElementStyle>(selectedElement?.style || DEFAULT_STYLE);
  const [texture, setTexture] = useState(globalTexture);

  useEffect(() => {
    if (target === 'element' && selectedElement) setDraft(selectedElement.style);
  }, [target, selectedElement?.id]);

  const patchStyle = (patch: Partial<CanvasElementStyle>) => {
    const next = { ...draft, ...patch };
    setDraft(next);
    if (target === 'element' && selectedElement) onElementChange({ style: next });
    else if (target === 'lot-front') onApplyLotStyle('front', toCardPatch(next, 'front'));
    else if (target === 'lot-back') onApplyLotStyle('back', toCardPatch(next, 'back'));
    else if (target === 'all-cards') onApplyAllCardsStyle(toCardPatch(next, 'front'));
  };

  const applyTexture = (id: string) => {
    setTexture(id);
    if (target === 'element' && selectedElement) {
      const backgrounds: Record<string, string> = {
        '': draft.background,
        'glow-violet': 'radial-gradient(ellipse at 40% 40%,rgba(168,85,247,.55),rgba(20,7,45,.95))',
        'glow-rose': 'radial-gradient(ellipse at 60% 40%,rgba(244,63,94,.55),rgba(42,0,16,.95))',
        aurora: 'linear-gradient(135deg,rgba(52,211,153,.85),rgba(139,92,246,.85),rgba(59,130,246,.85))',
        marble: 'linear-gradient(135deg,#e8e0d8,#f5f0eb,#d8d0c8)',
        linen: 'repeating-linear-gradient(90deg,#e8e0d5 0 3px,#f0e8de 3px 5px)',
        gold: 'linear-gradient(135deg,#b8860b,#ffd700,#daa520)',
        velvet: 'radial-gradient(ellipse,#4a1464,#200830)',
        neon: 'linear-gradient(135deg,#00ffaa,#0064ff,#ff0096)',
        'dark-glass': 'linear-gradient(135deg,rgba(30,32,48,.92),rgba(80,80,120,.75))',
      };
      patchStyle({ background: backgrounds[id] || draft.background });
    } else if (target === 'lot-front') onApplyLotStyle('front', { frontTexture: id });
    else if (target === 'lot-back') onApplyLotStyle('back', { texture: id });
    else onGlobalTextureChange(id);
  };

  return (
    <PanelShell title="Style" subtitle="Habiller chaque élément" onClose={onClose} isDark={isDark} width={310}>
      <SmallLabel>Cible</SmallLabel>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 13 }}>
        <TargetButton label="Objet" icon={<MousePointer2 size={12} />} active={target === 'element'} disabled={!selectedElement} onClick={() => setTarget('element')} isDark={isDark} />
        <TargetButton label={`Recto${activeLotTitle ? ` · ${activeLotTitle}` : ''}`} icon={<CreditCard size={12} />} active={target === 'lot-front'} disabled={!activeLotTitle} onClick={() => setTarget('lot-front')} isDark={isDark} />
        <TargetButton label="Verso" icon={<CreditCard size={12} />} active={target === 'lot-back'} disabled={!activeLotTitle} onClick={() => setTarget('lot-back')} isDark={isDark} />
        <TargetButton label="Toutes les cartes" icon={<Layers3 size={12} />} active={target === 'all-cards'} onClick={() => setTarget('all-cards')} isDark={isDark} />
      </div>

      <SmallLabel>Texture</SmallLabel>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 5, marginBottom: 14 }}>
        {TEXTURES.map((item) => (
          <button key={item.id} title={item.label} onClick={() => applyTexture(item.id)} style={{ aspectRatio: '1', borderRadius: 8, border: texture === item.id ? `2px solid ${isDark ? '#D4D4D8' : '#3F3F46'}` : `1px solid ${isDark ? 'rgba(255,255,255,.12)' : 'rgba(0,0,0,.1)'}`, background: item.bg, cursor: 'pointer', position: 'relative' }}>
            {item.id === '' && <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666' }}>×</span>}
          </button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
        <ColorField label="Fond" value={draft.background.startsWith('#') ? draft.background : '#242426'} onChange={(v) => patchStyle({ background: v })} isDark={isDark} />
        <ColorField label="Texte" value={draft.color} onChange={(v) => patchStyle({ color: v })} isDark={isDark} />
        <ColorField label="Bordure" value={draft.borderColor} onChange={(v) => patchStyle({ borderColor: v })} isDark={isDark} />
        <div>
          <SmallLabel>Alignement</SmallLabel>
          <select value={draft.textAlign} onChange={(e) => patchStyle({ textAlign: e.target.value as CanvasElementStyle['textAlign'] })} style={selectStyle(isDark)}><option value="left">Gauche</option><option value="center">Centre</option><option value="right">Droite</option></select>
        </div>
      </div>

      <SmallLabel>Typographie</SmallLabel>
      <div style={{ display: 'grid', gridTemplateColumns: '1.35fr .75fr .75fr', gap: 6, marginBottom: 12 }}>
        <select value={draft.fontFamily} onChange={(e) => patchStyle({ fontFamily: e.target.value })} style={selectStyle(isDark)}>
          <option value="Inter">Inter</option><option value="Cormorant Garamond">Cormorant</option><option value="Georgia">Georgia</option><option value="monospace">Mono</option>
        </select>
        <input type="number" min={8} max={120} value={draft.fontSize} onChange={(e) => patchStyle({ fontSize: Number(e.target.value) })} style={inputStyle(isDark)} title="Taille" />
        <select value={draft.fontWeight} onChange={(e) => patchStyle({ fontWeight: Number(e.target.value) })} style={selectStyle(isDark)}><option value={300}>Fin</option><option value={400}>Normal</option><option value={600}>Semi</option><option value={800}>Fort</option></select>
      </div>

      <Slider label="Angles" value={draft.borderRadius} min={0} max={80} suffix="px" onChange={(v) => patchStyle({ borderRadius: v })} />
      <Slider label="Ombre" value={draft.shadow} min={0} max={80} suffix="" onChange={(v) => patchStyle({ shadow: v })} />
      <Slider label="Transparence" value={draft.opacity} min={0.1} max={1} step={0.05} suffix="" display={`${Math.round(draft.opacity * 100)}%`} onChange={(v) => patchStyle({ opacity: v })} />
      <Slider label="Bordure" value={draft.borderWidth} min={0} max={10} suffix="px" onChange={(v) => patchStyle({ borderWidth: v })} />
      <Slider label="Flou" value={draft.blur} min={0} max={16} suffix="px" onChange={(v) => patchStyle({ blur: v })} />

      <div style={{ marginTop: 12, padding: 10, borderRadius: 10, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.025)', display: 'flex', gap: 8 }}>
        <Sparkles size={14} color={isDark ? "#D4D4D8" : "#3F3F46"} />
        <span style={{ fontFamily: 'Inter', fontSize: 9, lineHeight: 1.45, opacity: .58 }}>Les réglages s’appliquent immédiatement. Le recto et le verso peuvent avoir des médias et textures différents.</span>
      </div>
    </PanelShell>
  );
};

function toCardPatch(style: CanvasElementStyle, side: 'front' | 'back') {
  const p = side === 'front' ? 'front' : 'back';
  return {
    [`${p}Background`]: style.background,
    [`${p}Color`]: style.color,
    [`${p}Radius`]: style.borderRadius,
    [`${p}Opacity`]: style.opacity,
    [`${p}Blur`]: style.blur,
    [`${p}BorderWidth`]: style.borderWidth,
    [`${p}BorderColor`]: style.borderColor,
    [`${p}Shadow`]: style.shadow,
    [`${p}FontFamily`]: style.fontFamily,
  };
}

const SmallLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => <div style={{ fontFamily: 'Inter', fontSize: 8.5, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase', opacity: .42, marginBottom: 6 }}>{children}</div>;
const TargetButton: React.FC<{ label: string; icon: React.ReactNode; active: boolean; disabled?: boolean; onClick: () => void; isDark: boolean }> = ({ label, icon, active, disabled, onClick, isDark }) => <button disabled={disabled} onClick={onClick} style={{ display: 'flex', alignItems: 'center', gap: 5, borderRadius: 8, padding: '6px 8px', border: `1px solid ${active ? (isDark ? '#D4D4D8' : '#3F3F46') : isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)'}`, background: active ? (isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.07)') : 'transparent', color: 'inherit', fontFamily: 'Inter', fontSize: 9, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .35 : 1 }}>{icon}{label}</button>;
const ColorField: React.FC<{ label: string; value: string; onChange: (v: string) => void; isDark: boolean }> = ({ label, value, onChange, isDark }) => <div><SmallLabel>{label}</SmallLabel><div style={{ display: 'flex', gap: 5 }}><input type="color" value={normalizeColor(value)} onChange={(e) => onChange(e.target.value)} style={{ width: 34, height: 32, border: 0, borderRadius: 8, padding: 0, background: 'transparent' }} /><input value={value} onChange={(e) => onChange(e.target.value)} style={{ ...inputStyle(isDark), minWidth: 0 }} /></div></div>;
const Slider: React.FC<{ label: string; value: number; min: number; max: number; step?: number; suffix: string; display?: string; onChange: (v: number) => void }> = ({ label, value, min, max, step = 1, suffix, display, onChange }) => <div style={{ marginBottom: 9 }}><div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Inter', fontSize: 9, marginBottom: 4 }}><span style={{ opacity: .48 }}>{label}</span><b>{display || `${value}${suffix}`}</b></div><input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} style={{ width: '100%', accentColor: '#A3A3A8' }} /></div>;
const inputStyle = (isDark: boolean): React.CSSProperties => ({ width: '100%', boxSizing: 'border-box', padding: '7px 8px', borderRadius: 8, border: `1px solid ${isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)'}`, background: isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.025)', color: 'inherit', fontFamily: 'Inter', fontSize: 9, outline: 0 });
const selectStyle = (isDark: boolean): React.CSSProperties => ({ ...inputStyle(isDark), appearance: 'auto' });
function normalizeColor(value: string) { return /^#[0-9a-f]{6}$/i.test(value) ? value : '#242426'; }
