import React, { useEffect, useRef, useState } from 'react';
import type { StudioPanelKind, Tool } from '../types';
import {
  Check, ChevronDown, Eye, Image as ImageIcon, LayoutGrid, LayoutPanelLeft,
  ListChecks, Maximize2, MousePointer2, Music2, Paintbrush, PanelLeftOpen, Plus,
  Settings2, StickyNote, Sun, Moon, Tv2, Wallet, LayoutTemplate, Crosshair,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface ToolbarProps {
  activeTool: Tool;
  onToolChange: (tool: Tool) => void;
  activeStudioPanel: StudioPanelKind;
  onStudioPanelChange: (panel: StudioPanelKind) => void;
  scale: number;
  onZoomChange: (delta: number) => void;
  onZoomTo: (scale: number) => void;
  onZoomFit: () => void;
  onZoomSelection: () => void;
  onPreview: () => void;
  onToggleSidebar: () => void;
  sidebarOpen: boolean;
  onBudget: () => void;
  onChecklist: () => void;
  onKiosk: () => void;
  onTemplates: () => void;
  onPlaylist: () => void;
  playlistActive: boolean;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTool, onToolChange, activeStudioPanel, onStudioPanelChange,
  scale, onZoomChange, onZoomTo, onZoomFit, onZoomSelection, onPreview, onToggleSidebar,
  sidebarOpen, onBudget, onChecklist, onKiosk, onTemplates, onPlaylist, playlistActive,
}) => {
  const { isDark, toggle } = useTheme();
  const [zoomOpen, setZoomOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [pointZeroOpen, setPointZeroOpen] = useState(false);
  const [chromaticOpen, setChromaticOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) {
        setZoomOpen(false);
        setMoreOpen(false);
      }
    };
    window.addEventListener('mousedown', close);
    return () => window.removeEventListener('mousedown', close);
  }, []);

  useEffect(() => {
    const pointState = (event: Event) => setPointZeroOpen(Boolean((event as CustomEvent<{ open?: boolean }>).detail?.open));
    const chromaState = (event: Event) => setChromaticOpen(Boolean((event as CustomEvent<{ open?: boolean }>).detail?.open));
    window.addEventListener('lma-point-zero-state', pointState as EventListener);
    window.addEventListener('lma-chromatic-state', chromaState as EventListener);
    return () => {
      window.removeEventListener('lma-point-zero-state', pointState as EventListener);
      window.removeEventListener('lma-chromatic-state', chromaState as EventListener);
    };
  }, []);

  const creationButtons: Array<{ id: Exclude<StudioPanelKind, null>; icon: React.ReactNode; label: string }> = [
    { id: 'add', icon: <Plus size={15} />, label: 'Ajouter une carte ou un élément' },
    { id: 'media', icon: <ImageIcon size={15} />, label: 'Médias du projet' },
  ];

  const surface = isDark ? 'rgba(24,24,26,.97)' : 'rgba(255,255,255,.97)';
  const border = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)';
  const text = isDark ? '#F4F4F5' : '#151516';
  const muted = isDark ? 'rgba(244,244,245,.52)' : 'rgba(21,21,22,.52)';

  const openPanel = (panel: Exclude<StudioPanelKind, null>) => {
    onStudioPanelChange(activeStudioPanel === panel ? null : panel);
    setMoreOpen(false);
  };

  return (
    <div ref={rootRef} style={{ position: 'fixed', left: '50%', bottom: 14, transform: 'translateX(-50%)', zIndex: 240, display: 'flex', alignItems: 'center', gap: 4, padding: 6, borderRadius: 14, background: surface, border: `1px solid ${border}`, boxShadow: '0 16px 46px rgba(0,0,0,.28)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)', color: text }}>
      <ToolButton active={sidebarOpen} label="Afficher les cartes et calques" onClick={onToggleSidebar} isDark={isDark}>{sidebarOpen ? <LayoutPanelLeft size={15} /> : <PanelLeftOpen size={15} />}</ToolButton>
      <Divider isDark={isDark} />
      <ToolButton active={activeTool === 'select'} label="Sélection et déplacement direct (V)" onClick={() => onToolChange('select')} isDark={isDark}><MousePointer2 size={15} /></ToolButton>
      <ToolButton active={activeTool === 'note'} label="Ajouter un post-it" onClick={() => onToolChange('note')} isDark={isDark}><StickyNote size={15} /></ToolButton>
      <ToolButton active={pointZeroOpen} label="Point Zéro — origine, URL et ZIP" onClick={() => window.dispatchEvent(new CustomEvent('lma-point-zero-toggle'))} isDark={isDark}><Crosshair size={15} /></ToolButton>
      <ToolButton active={chromaticOpen} label="Cercle chromatique AIME" onClick={() => window.dispatchEvent(new CustomEvent('lma-chromatic-toggle'))} isDark={isDark}><span aria-hidden style={{ width: 16, height: 16, borderRadius: '50%', display: 'block', background: 'conic-gradient(#ff4f81,#ffb14f,#f9ef5b,#53d987,#4bc8ff,#715dff,#d957e8,#ff4f81)', boxShadow: chromaticOpen ? '0 0 0 3px rgba(255,255,255,.18)' : 'none' }} /></ToolButton>
      <Divider isDark={isDark} />
      {creationButtons.map((item) => <ToolButton key={item.id} active={activeStudioPanel === item.id} label={item.label} onClick={() => openPanel(item.id)} isDark={isDark}>{item.icon}</ToolButton>)}
      <Divider isDark={isDark} />
      <ToolButton active={playlistActive} label="Playlist collaborative" onClick={onPlaylist} isDark={isDark}><Music2 size={15} /></ToolButton>

      <div style={{ position: 'relative' }}>
        <button onClick={() => { setZoomOpen((value) => !value); setMoreOpen(false); }} title="Zoom, cadrage et aperçu global" style={{ height: 32, minWidth: 68, padding: '0 8px', borderRadius: 8, border: 0, background: zoomOpen ? (isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.07)') : 'transparent', color: zoomOpen ? text : muted, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, fontSize: 9.5, fontWeight: 700 }}>
          {Math.round(scale * 100)}% <ChevronDown size={11} />
        </button>
        {zoomOpen && <Popup isDark={isDark} width={190}>
          <PopupRow label="Zoom avant" hint="+" onClick={() => onZoomChange(.2)} />
          <PopupRow label="Zoom arrière" hint="−" onClick={() => onZoomChange(-.2)} />
          <Separator isDark={isDark} />
          {[.25, .5, .75, 1].map((value) => <PopupRow key={value} label={`${Math.round(value * 100)} %`} active={Math.abs(scale - value) < .03} onClick={() => onZoomTo(value)} />)}
          <Separator isDark={isDark} />
          <PopupRow label="Ajuster au canevas" icon={<Maximize2 size={12} />} onClick={onZoomFit} />
          <PopupRow label="Ajuster à la sélection" icon={<MousePointer2 size={12} />} onClick={onZoomSelection} />
          <Separator isDark={isDark} />
          <PopupRow label="Aperçu global sans interface" icon={<Eye size={12} />} onClick={onPreview} />
        </Popup>}
      </div>

      <div style={{ position: 'relative' }}>
        <ToolButton active={moreOpen} label="Outils secondaires du projet" onClick={() => { setMoreOpen((value) => !value); setZoomOpen(false); }} isDark={isDark}><Settings2 size={15} /></ToolButton>
        {moreOpen && <Popup isDark={isDark} width={226}>
          <div style={{ padding: '6px 9px 7px', fontSize: 8, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase', opacity: .42 }}>Projet entier</div>
          <PopupRow label="Style global" icon={<Paintbrush size={13} />} onClick={() => openPanel('style')} />
          <PopupRow label="Organiser le canevas" icon={<LayoutGrid size={13} />} onClick={() => openPanel('organize')} />
          <PopupRow label="Modèles" icon={<LayoutTemplate size={13} />} onClick={onTemplates} />
          <Separator isDark={isDark} />
          <PopupRow label="Budget" icon={<Wallet size={13} />} onClick={onBudget} />
          <PopupRow label="Checklist" icon={<ListChecks size={13} />} onClick={onChecklist} />
          <PopupRow label="Mode kiosque" icon={<Tv2 size={13} />} onClick={onKiosk} />
          <Separator isDark={isDark} />
          <PopupRow label={isDark ? 'Mode clair' : 'Mode sombre'} icon={isDark ? <Sun size={13} /> : <Moon size={13} />} onClick={toggle} />
        </Popup>}
      </div>
    </div>
  );
};

const ToolButton: React.FC<{ active?: boolean; label: string; onClick: () => void; isDark: boolean; children: React.ReactNode }> = ({ active, label, onClick, isDark, children }) => <button title={label} onClick={onClick} style={{ width: 32, height: 32, borderRadius: 8, border: 0, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', background: active ? (isDark ? 'rgba(255,255,255,.14)' : 'rgba(0,0,0,.10)') : 'transparent', color: active ? (isDark ? '#FFFFFF' : '#111113') : isDark ? 'rgba(244,244,245,.56)' : 'rgba(15,15,16,.56)', transition: 'all .15s' }}>{children}</button>;
const Popup: React.FC<{ isDark: boolean; width: number; children: React.ReactNode }> = ({ isDark, width, children }) => <div style={{ position: 'absolute', bottom: 41, left: '50%', transform: 'translateX(-50%)', width, padding: 5, borderRadius: 11, background: isDark ? '#242426' : '#fff', color: isDark ? '#F6F6F7' : '#18181A', border: `1px solid ${isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.09)'}`, boxShadow: '0 18px 48px rgba(0,0,0,.28)' }}>{children}</div>;
const PopupRow: React.FC<{ label: string; onClick: () => void; hint?: string; icon?: React.ReactNode; active?: boolean }> = ({ label, onClick, hint, icon, active }) => <button onClick={onClick} style={{ width: '100%', height: 31, borderRadius: 7, border: 0, background: active ? 'rgba(255,255,255,.10)' : 'transparent', color: 'inherit', cursor: 'pointer', padding: '0 9px', display: 'flex', alignItems: 'center', gap: 8, fontSize: 9.5, textAlign: 'left' }}>{icon}{label}{active && <Check size={11} style={{ marginLeft: 'auto' }} />}{hint && !active && <span style={{ marginLeft: 'auto', opacity: .4, fontSize: 8.5 }}>{hint}</span>}</button>;
const Divider: React.FC<{ isDark: boolean }> = ({ isDark }) => <div style={{ width: 1, height: 22, background: isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)', margin: '0 2px' }} />;
const Separator: React.FC<{ isDark: boolean }> = ({ isDark }) => <div style={{ height: 1, background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)', margin: '4px 5px' }} />;
