import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive, CalendarRange, ChevronRight, Copy, Download, Eye, FileJson, FileText,
  GitBranch, Globe2, History, LayoutTemplate, Link2, Lock, MoreHorizontal, MoveRight,
  Pencil, Radio, RefreshCw, RotateCcw, Scissors, Share2, Smartphone, Sparkles,
  Trash2, Unlink, Wand2, Network, Layers3, ArrowRightLeft,
} from 'lucide-react';
import type { RemixTarget } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { CardProjectionRuntime } from './CardProjectionRuntime';
import type { CardPreviewMode } from './CardPreviewPanel';

export type RemixActionId =
  | 'preview' | 'preview-card' | 'preview-section' | 'preview-page' | 'preview-site'
  | 'preview-mobile' | 'preview-timeline' | 'preview-story' | 'preview-pdf' | 'preview-live'
  | 'layout' | 'depth' | 'causal-impact' | 'transform-card' | 'cover' | 'reuse-recipe' | 'mashup' | 'inspiration' | 'extend' | 'crop'
  | 'reverse' | 'replace' | 'duplicate' | 'flip' | 'connect' | 'show-connections' | 'detach'
  | 'publish' | 'publish-section' | 'publish-minisite' | 'publish-story' | 'publish-live'
  | 'share-link' | 'export-json' | 'manage' | 'add-collection' | 'move-workspace'
  | 'undo-remix' | 'archive' | 'hide' | 'lock' | 'delete';

interface RemixProtocolMenuProps {
  open: boolean;
  x: number;
  y: number;
  target: RemixTarget | null;
  canUndo?: boolean;
  linkedCount?: number;
  onAction: (action: RemixActionId, target: RemixTarget) => void;
  onClose: () => void;
}

type Submenu = 'preview' | 'remix' | 'edit' | 'link' | 'transform' | 'publish' | 'download' | 'manage' | null;

const PREVIEW_ACTIONS: Partial<Record<RemixActionId, CardPreviewMode>> = {
  preview: 'card', 'preview-card': 'card', 'preview-section': 'section', 'preview-page': 'page',
  'preview-site': 'site', 'preview-mobile': 'mobile', 'preview-timeline': 'timeline',
  'preview-story': 'story', 'preview-pdf': 'pdf', 'preview-live': 'live',
  'publish-section': 'section', 'publish-minisite': 'site', 'publish-story': 'story', 'publish-live': 'live',
};

export const RemixProtocolMenu: React.FC<RemixProtocolMenuProps> = ({
  open, x, y, target, canUndo = false, linkedCount = 0, onAction, onClose,
}) => {
  const { isDark } = useTheme();
  const rootRef = useRef<HTMLDivElement>(null);
  const [submenu, setSubmenu] = useState<Submenu>(null);

  useEffect(() => {
    if (!open) return;
    setSubmenu(null);
    const close = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) onClose();
    };
    const closeEsc = (event: KeyboardEvent) => event.key === 'Escape' && onClose();
    window.addEventListener('mousedown', close);
    window.addEventListener('keydown', closeEsc);
    return () => {
      window.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', closeEsc);
    };
  }, [open, onClose]);

  const position = useMemo(() => {
    const menuWidth = 252;
    const submenuWidth = 294;
    const total = submenu ? menuWidth + 8 + submenuWidth : menuWidth;
    const viewportWidth = typeof window === 'undefined' ? 1440 : window.innerWidth;
    const viewportHeight = typeof window === 'undefined' ? 900 : window.innerHeight;
    return {
      left: Math.max(12, Math.min(x, viewportWidth - total - 12)),
      top: Math.max(58, Math.min(y, viewportHeight - 650)),
    };
  }, [submenu, x, y]);

  const dispatchRuntimeAction = (action: RemixActionId, activeTarget: RemixTarget) => {
    const mode = PREVIEW_ACTIONS[action];
    if (mode) {
      const name = activeTarget.kind === 'plan' ? 'lma-plan-preview' : 'lma-card-preview';
      window.dispatchEvent(new CustomEvent(name, { detail: { target: activeTarget, mode } }));
    } else if (action === 'layout' || action === 'depth') {
      const name = activeTarget.kind === 'plan' ? 'lma-plan-compose' : 'lma-card-compose';
      window.dispatchEvent(new CustomEvent(name, { detail: { target: activeTarget, mode: action === 'depth' ? 'depth' : 'layout' } }));
    } else if (action === 'causal-impact') {
      window.dispatchEvent(new CustomEvent('lma-causal-impact', { detail: { target: activeTarget } }));
    } else if (action === 'transform-card') {
      window.dispatchEvent(new CustomEvent('lma-card-transform', { detail: { target: activeTarget } }));
    } else if (action === 'connect') {
      const name = activeTarget.kind === 'plan' ? 'lma-plan-connect' : 'lma-card-connect';
      window.dispatchEvent(new CustomEvent(name, { detail: { target: activeTarget } }));
    } else if (action === 'detach') {
      const name = activeTarget.kind === 'plan' ? 'lma-plan-detach' : 'lma-card-detach';
      window.dispatchEvent(new CustomEvent(name, { detail: { target: activeTarget } }));
    } else if (action === 'show-connections') {
      const name = activeTarget.kind === 'plan' ? 'lma-plan-show-connections' : 'lma-card-show-connections';
      window.dispatchEvent(new CustomEvent(name, { detail: { target: activeTarget } }));
    }
  };

  const run = (action: RemixActionId) => {
    if (!target) return;
    dispatchRuntimeAction(action, target);
    onAction(action, target);
    onClose();
  };
  const toggle = (id: Submenu) => setSubmenu(submenu === id ? null : id);

  const surface = isDark ? '#252527' : '#FFFFFF';
  const surfaceHover = isDark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.055)';
  const text = isDark ? '#F8F8F9' : '#18181A';
  const muted = isDark ? 'rgba(248,248,249,.48)' : 'rgba(24,24,26,.5)';
  const border = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)';

  return (
    <>
      <CardProjectionRuntime />
      {open && target && (
        <div ref={rootRef} style={{ position: 'fixed', left: position.left, top: position.top, zIndex: 2147482200, display: 'flex', gap: 8, fontFamily: 'Inter, sans-serif', color: text }}>
          <div style={{ width: 252, padding: 7, borderRadius: 17, background: surface, border: `1px solid ${border}`, boxShadow: '0 26px 80px rgba(0,0,0,.42)', backdropFilter: 'blur(24px)' }}>
            <div style={{ padding: '7px 10px 9px', borderBottom: `1px solid ${border}`, marginBottom: 4 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 10.5, fontWeight: 850 }}><MoreHorizontal size={14} /> Actions de la carte</div>
              <div style={{ marginTop: 4, fontSize: 8.5, color: muted, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{target.label} · {target.kind}{linkedCount ? ` · ${linkedCount} reliée${linkedCount > 1 ? 's' : ''}` : ''}</div>
            </div>

            <Row icon={<Eye size={15} />} label="Aperçu" desc="Carte, section, site, mobile ou Live" submenu active={submenu === 'preview'} onClick={() => toggle('preview')} hover={surfaceHover} />
            <Row icon={<LayoutTemplate size={15} />} label="Mise en page" desc="Composition, visuels, couleurs, texte, boutons" onClick={() => run('layout')} hover={surfaceHover} />
            <Row icon={<Layers3 size={15} />} label="Profondeur" desc="Ce qui compose la carte et ce qu'elle influence" onClick={() => run('depth')} hover={surfaceHover} />
            <Row icon={<Network size={15} />} label="Empreinte causale" desc="Voir les conséquences de cette carte" onClick={() => run('causal-impact')} hover={surfaceHover} />
            <Divider border={border} />
            <Row icon={<RefreshCw size={15} />} label="Remix" submenu active={submenu === 'remix'} onClick={() => toggle('remix')} hover={surfaceHover} />
            <Row icon={<ArrowRightLeft size={15} />} label="Transformer en" desc="Section, page, mini-site, timeline…" submenu active={submenu === 'transform'} onClick={() => toggle('transform')} hover={surfaceHover} />
            <Row icon={<Pencil size={15} />} label="Éditer" submenu active={submenu === 'edit'} onClick={() => toggle('edit')} hover={surfaceHover} />
            <Row icon={<Link2 size={15} />} label="Relier" desc="Magnétiser cette carte avec d’autres" submenu active={submenu === 'link'} onClick={() => toggle('link')} hover={surfaceHover} />
            <Divider border={border} />
            <Row icon={<Globe2 size={15} />} label="Publier" submenu active={submenu === 'publish'} onClick={() => toggle('publish')} hover={surfaceHover} />
            <Row icon={<Share2 size={15} />} label="Partager" onClick={() => run('share-link')} hover={surfaceHover} />
            <Row icon={<Download size={15} />} label="Exporter" submenu active={submenu === 'download'} onClick={() => toggle('download')} hover={surfaceHover} />
            <Row icon={<MoreHorizontal size={15} />} label="Gérer" submenu active={submenu === 'manage'} onClick={() => toggle('manage')} hover={surfaceHover} />
          </div>

          {submenu && (
            <div style={{ width: 294, padding: 7, borderRadius: 17, background: surface, border: `1px solid ${border}`, boxShadow: '0 26px 80px rgba(0,0,0,.42)', alignSelf: 'flex-start', maxHeight: 'calc(100vh - 76px)', overflowY: 'auto' }}>
              {submenu === 'preview' && <>
                <SubTitle label="Projeter la même carte dans plusieurs formats" muted={muted} />
                <Row icon={<LayoutTemplate size={15} />} label="Carte" desc="Le recto dans son format source" onClick={() => run('preview-card')} hover={surfaceHover} />
                <Row icon={<LayoutTemplate size={15} />} label="Section" desc="Une section éditoriale responsive" onClick={() => run('preview-section')} hover={surfaceHover} />
                <Row icon={<FileText size={15} />} label="Page" desc="Une page complète construite autour d’elle" onClick={() => run('preview-page')} hover={surfaceHover} />
                <Row icon={<Globe2 size={15} />} label="Site complet" desc="Toutes les cartes reliées dans un site" onClick={() => run('preview-site')} hover={surfaceHover} />
                <Row icon={<Smartphone size={15} />} label="Mobile" desc="Version téléphone" onClick={() => run('preview-mobile')} hover={surfaceHover} />
                <Row icon={<CalendarRange size={15} />} label="Timeline" desc="Projection chronologique" onClick={() => run('preview-timeline')} hover={surfaceHover} />
                <Row icon={<Smartphone size={15} />} label="Story" desc="Présentation verticale animée" onClick={() => run('preview-story')} hover={surfaceHover} />
                <Row icon={<FileText size={15} />} label="PDF" desc="Document imprimable" onClick={() => run('preview-pdf')} hover={surfaceHover} />
                <Row icon={<Radio size={15} />} label="Jour J Live" desc="Projection en direct" onClick={() => run('preview-live')} hover={surfaceHover} />
              </>}

              {submenu === 'remix' && <>
                <SubTitle label="Remixer sans perdre la source" muted={muted} />
                <Row icon={<RefreshCw size={15} />} label="Créer un Cover" desc="Trois variations côte à côte" onClick={() => run('cover')} hover={surfaceHover} />
                <Row icon={<GitBranch size={15} />} label="Réutiliser la recette" desc="Copier l’ADN de génération" onClick={() => run('reuse-recipe')} hover={surfaceHover} />
                <Row icon={<LayoutTemplate size={15} />} label="Mashup" desc="Fusionner avec un autre objet" onClick={() => run('mashup')} hover={surfaceHover} />
                <Row icon={<Sparkles size={15} />} label="Utiliser comme inspiration" desc="Transférer le style, pas le contenu" onClick={() => run('inspiration')} hover={surfaceHover} />
              </>}

              {submenu === 'transform' && <>
                <SubTitle label="La même matière, une autre sortie" muted={muted} />
                <Row icon={<LayoutTemplate size={15} />} label="Section" desc="Une composition éditoriale autonome" onClick={() => run('transform-card')} hover={surfaceHover} />
                <Row icon={<FileText size={15} />} label="Page" desc="Une page complète autour de cette carte" onClick={() => run('preview-page')} hover={surfaceHover} />
                <Row icon={<Globe2 size={15} />} label="Mini-site" desc="Une expérience partageable issue de la carte" onClick={() => run('preview-site')} hover={surfaceHover} />
                <Row icon={<CalendarRange size={15} />} label="Timeline" desc="Une projection dans le temps" onClick={() => run('preview-timeline')} hover={surfaceHover} />
                <Row icon={<Smartphone size={15} />} label="Invitation / Story" desc="Une sortie verticale prête à partager" onClick={() => run('preview-story')} hover={surfaceHover} />
              </>}

              {submenu === 'edit' && <>
                <SubTitle label="Modifier la carte et sa projection" muted={muted} />
                <Row icon={<RotateCcw size={15} />} label="Retourner la carte" desc="Passer du recto au verso" onClick={() => run('flip')} hover={surfaceHover} />
                <Row icon={<LayoutTemplate size={15} />} label="Mise en page" desc="Ouvrir le studio de composition" onClick={() => run('layout')} hover={surfaceHover} />
                <Row icon={<MoveRight size={15} />} label="Prolonger" desc="Étendre le format ou la durée" onClick={() => run('extend')} hover={surfaceHover} />
                <Row icon={<Scissors size={15} />} label="Recadrer" desc="Réduire au contenu essentiel" onClick={() => run('crop')} hover={surfaceHover} />
                <Row icon={<RotateCcw size={15} />} label="Inverser" desc="Retourner l’ordre ou la composition" onClick={() => run('reverse')} hover={surfaceHover} />
                <Row icon={<Wand2 size={15} />} label="Remplacer la section" desc="Régénérer sans toucher au reste" onClick={() => run('replace')} hover={surfaceHover} />
              </>}

              {submenu === 'link' && <>
                <SubTitle label="Créer une relation vivante" muted={muted} />
                <Row icon={<Link2 size={15} />} label="Magnétiser avec la sélection" desc="Utiliser les cartes cochées comme sources" onClick={() => run('connect')} hover={surfaceHover} />
                <Row icon={<GitBranch size={15} />} label="Voir les cartes reliées" desc="Afficher la composition source" onClick={() => run('show-connections')} hover={surfaceHover} />
                <Row icon={<Unlink size={15} />} label="Détacher les sources" desc="La carte redevient indépendante" onClick={() => run('detach')} hover={surfaceHover} />
              </>}

              {submenu === 'publish' && <>
                <SubTitle label="Une carte, plusieurs sorties" muted={muted} />
                <Row icon={<LayoutTemplate size={15} />} label="Publier comme section" desc="Ajouter au site principal" onClick={() => run('publish-section')} hover={surfaceHover} />
                <Row icon={<Globe2 size={15} />} label="Publier comme mini-site" desc="Créer une adresse partageable" onClick={() => run('publish-minisite')} hover={surfaceHover} />
                <Row icon={<Smartphone size={15} />} label="Publier comme Story" desc="Format vertical" onClick={() => run('publish-story')} hover={surfaceHover} />
                <Row icon={<Radio size={15} />} label="Activer le Jour J Live" desc="Projection en temps réel" onClick={() => run('publish-live')} hover={surfaceHover} />
              </>}

              {submenu === 'download' && <>
                <SubTitle label="Exporter la matière du projet" muted={muted} />
                <Row icon={<FileJson size={15} />} label="Projet AIME JSON" desc="Structure, médias et réglages" onClick={() => run('export-json')} hover={surfaceHover} />
                <Row icon={<FileText size={15} />} label="PDF" desc="Projection prête à imprimer" onClick={() => run('preview-pdf')} hover={surfaceHover} />
                <Row icon={<GitBranch size={15} />} label="Recette / ADN" desc="Structure portable du projet" onClick={() => run('reuse-recipe')} hover={surfaceHover} />
              </>}

              {submenu === 'manage' && <>
                <SubTitle label="Ordre, droits et mémoire" muted={muted} />
                <Row icon={<Copy size={15} />} label="Dupliquer" desc="Créer une copie liée" onClick={() => run('duplicate')} hover={surfaceHover} />
                <Row icon={<Lock size={15} />} label="Verrouiller / déverrouiller" desc="Protéger la position et les réglages" onClick={() => run('lock')} hover={surfaceHover} />
                <Row icon={<MoveRight size={15} />} label="Masquer du canevas" desc="Conserver la carte dans le projet" onClick={() => run('hide')} hover={surfaceHover} />
                <Row icon={<Radio size={15} />} label="Ajouter à une collection" onClick={() => run('add-collection')} hover={surfaceHover} />
                <Row icon={<MoveRight size={15} />} label="Déplacer vers un espace" onClick={() => run('move-workspace')} hover={surfaceHover} />
                <Row icon={<History size={15} />} label="Voir la généalogie" desc="Origine et transformations" onClick={() => run('manage')} hover={surfaceHover} />
                {canUndo && <Row icon={<RotateCcw size={15} />} label="Annuler le dernier remix" onClick={() => run('undo-remix')} hover={surfaceHover} accent="#C4A7FF" />}
                <Divider border={border} />
                <Row icon={<Archive size={15} />} label="Archiver" onClick={() => run('archive')} hover={surfaceHover} />
                <Row icon={<Trash2 size={15} />} label="Mettre à la corbeille" onClick={() => run('delete')} hover={surfaceHover} accent="#F87171" />
              </>}
            </div>
          )}
        </div>
      )}
    </>
  );
};

const Row: React.FC<{
  icon: React.ReactNode;
  label: string;
  desc?: string;
  submenu?: boolean;
  active?: boolean;
  accent?: string;
  hover: string;
  onClick: () => void;
}> = ({ icon, label, desc, submenu, active, accent, hover, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    onMouseEnter={(event) => { event.currentTarget.style.background = hover; }}
    onMouseLeave={(event) => { event.currentTarget.style.background = active ? hover : 'transparent'; }}
    style={{
      width: '100%', minHeight: desc ? 50 : 40, padding: desc ? '7px 10px' : '0 10px', border: 0, borderRadius: 10,
      background: active ? hover : 'transparent', color: accent || 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left',
    }}
  >
    <span style={{ width: 20, display: 'grid', placeItems: 'center', flexShrink: 0 }}>{icon}</span>
    <span style={{ flex: 1, minWidth: 0 }}>
      <span style={{ display: 'block', fontSize: 12, fontWeight: 650 }}>{label}</span>
      {desc && <span style={{ display: 'block', marginTop: 3, fontSize: 8.5, opacity: .48, lineHeight: 1.35 }}>{desc}</span>}
    </span>
    {submenu && <ChevronRight size={14} style={{ opacity: .55 }} />}
  </button>
);

const Divider: React.FC<{ border: string }> = ({ border }) => <div style={{ height: 1, background: border, margin: '5px 8px' }} />;
const SubTitle: React.FC<{ label: string; muted: string }> = ({ label, muted }) => <div style={{ padding: '8px 10px 7px', fontSize: 8.5, fontWeight: 800, letterSpacing: '.08em', textTransform: 'uppercase', color: muted }}>{label}</div>;
