import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  ArrowRight,
  BookOpen,
  Bot,
  Check,
  Cloud,
  FolderOpen,
  LayoutDashboard,
  MousePointer2,
  Plus,
  Rocket,
  Save,
  Sparkles,
  X,
} from 'lucide-react';

interface HomeGuideProps {
  isDark: boolean;
  projectCount: number;
  hasRecentProject: boolean;
  open: boolean;
  onOpen: () => void;
  onClose: () => void;
  onCreate: () => void;
  onOpenRecent: () => void;
}

const STEPS = [
  {
    number: '01',
    title: 'Choisir un univers',
    description: 'Mariage, mini-site, profil, événement, portfolio, association ou projet libre.',
    icon: <LayoutDashboard size={16} />,
  },
  {
    number: '02',
    title: 'Créer le point de départ',
    description: 'Nommez le projet puis choisissez Guidé par AIME, Modèle essentiel ou Canevas vide.',
    icon: <Plus size={16} />,
  },
  {
    number: '03',
    title: 'Renseigner les cartes sources',
    description: 'Les informations saisies alimentent ensuite le canevas, la timeline, le mini-site et les outils.',
    icon: <MousePointer2 size={16} />,
  },
  {
    number: '04',
    title: 'Composer dans le canevas',
    description: 'Sélectionnez, déplacez, ajoutez des médias et organisez les lots depuis une seule surface.',
    icon: <Sparkles size={16} />,
  },
  {
    number: '05',
    title: 'Demander à AIME CORE',
    description: 'L’agent analyse le contexte, suggère la prochaine action et prépare les éléments à valider.',
    icon: <Bot size={16} />,
  },
  {
    number: '06',
    title: 'Sauvegarder et publier',
    description: 'Connectez le cloud, synchronisez, puis publiez le mini-site, le RSVP et la vue Jour J.',
    icon: <Rocket size={16} />,
  },
];

const INTERFACE = [
  ['Colonne gauche', 'Vos projets, dossiers, pages, calques et ressources.'],
  ['Centre', 'Le canevas vivant dans lequel toutes les cartes et sorties restent reliées.'],
  ['Barre du bas', 'Sélection, déplacement, ajout, média, style, organisation, musique et aperçu.'],
  ['Haut à droite', 'Compte cloud, état de sauvegarde, export, communauté et AIME CORE.'],
];

export const HomeGuide: React.FC<HomeGuideProps> = ({
  isDark,
  projectCount,
  hasRecentProject,
  open,
  onOpen,
  onClose,
  onCreate,
  onOpenRecent,
}) => {
  const tokens = guideTokens(isDark);

  useEffect(() => {
    if (!open || typeof document === 'undefined') return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose, open]);

  const dialog = open && typeof document !== 'undefined'
    ? createPortal(
        <div
          role="presentation"
          onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}
          style={{ position: 'fixed', inset: 0, zIndex: 2147482500, background: 'rgba(0,0,0,.58)', backdropFilter: 'blur(7px)', display: 'grid', placeItems: 'center', padding: 18 }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="lma-home-guide-title"
            style={{ width: 'min(920px,100%)', maxHeight: 'min(820px,calc(100vh - 36px))', overflow: 'hidden', display: 'flex', flexDirection: 'column', borderRadius: 18, border: `1px solid ${tokens.border}`, background: tokens.panel, color: tokens.text, boxShadow: '0 34px 100px rgba(0,0,0,.42)' }}
          >
            <header style={{ minHeight: 74, padding: '16px 18px', borderBottom: `1px solid ${tokens.border}`, display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 40, height: 40, borderRadius: 12, display: 'grid', placeItems: 'center', background: tokens.surface, border: `1px solid ${tokens.border}` }}><BookOpen size={18} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h2 id="lma-home-guide-title" style={{ margin: 0, fontSize: 18, letterSpacing: '-.025em' }}>Mode d’emploi — LE MONDE AIME</h2>
                <p style={{ margin: '5px 0 0', color: tokens.muted, fontSize: 10, lineHeight: 1.45 }}>Un seul chemin : créer, relier, orchestrer, sauvegarder et publier.</p>
              </div>
              <button aria-label="Fermer le mode d’emploi" onClick={onClose} style={iconButton(tokens)}><X size={17} /></button>
            </header>

            <div style={{ flex: 1, overflowY: 'auto', padding: 18 }}>
              <section style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1.3fr) minmax(250px,.7fr)', gap: 14 }} className="lma-guide-hero-grid">
                <div style={{ padding: 20, borderRadius: 15, border: `1px solid ${tokens.border}`, background: tokens.surface }}>
                  <span style={eyebrow(tokens)}>Le principe</span>
                  <h3 style={{ margin: '10px 0 8px', fontSize: 25, letterSpacing: '-.04em', lineHeight: 1.05 }}>Une information saisie une fois, utilisée partout.</h3>
                  <p style={{ margin: 0, color: tokens.muted, fontSize: 11, lineHeight: 1.65, maxWidth: 620 }}>Les cartes sont les sources vivantes du projet. La timeline, le mini-site, le budget, les documents et l’agent ne sont pas des outils séparés : ils lisent les mêmes données et se mettent à jour ensemble.</p>
                </div>
                <div style={{ padding: 18, borderRadius: 15, border: `1px solid ${tokens.border}`, background: tokens.surface }}>
                  <span style={eyebrow(tokens)}>Votre espace</span>
                  <strong style={{ display: 'block', marginTop: 11, fontSize: 30, letterSpacing: '-.05em' }}>{projectCount}</strong>
                  <span style={{ display: 'block', marginTop: 2, color: tokens.muted, fontSize: 9.5 }}>projet{projectCount > 1 ? 's' : ''} enregistré{projectCount > 1 ? 's' : ''}</span>
                  <div style={{ height: 1, background: tokens.border, margin: '16px 0' }} />
                  <div style={{ display: 'flex', gap: 8, color: tokens.muted, fontSize: 9, lineHeight: 1.45 }}><Save size={14} style={{ flexShrink: 0 }} /> Les modifications locales sont enregistrées automatiquement. Le cloud ajoute la synchronisation entre appareils.</div>
                </div>
              </section>

              <section style={{ marginTop: 22 }}>
                <span style={eyebrow(tokens)}>Le parcours conseillé</span>
                <div style={{ marginTop: 10, display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: 9 }} className="lma-guide-step-grid">
                  {STEPS.map((step) => <GuideStep key={step.number} step={step} tokens={tokens} />)}
                </div>
              </section>

              <section style={{ marginTop: 22 }}>
                <span style={eyebrow(tokens)}>L’interface en un coup d’œil</span>
                <div style={{ marginTop: 10, borderRadius: 14, overflow: 'hidden', border: `1px solid ${tokens.border}` }}>
                  {INTERFACE.map(([label, description], index) => (
                    <div key={label} style={{ minHeight: 52, padding: '10px 13px', display: 'grid', gridTemplateColumns: '150px 1fr', gap: 14, alignItems: 'center', background: index % 2 ? tokens.surface : tokens.panel, borderTop: index ? `1px solid ${tokens.border}` : 0 }} className="lma-guide-interface-row">
                      <strong style={{ fontSize: 10 }}>{label}</strong>
                      <span style={{ color: tokens.muted, fontSize: 9.5, lineHeight: 1.5 }}>{description}</span>
                    </div>
                  ))}
                </div>
              </section>

              <section style={{ marginTop: 22, display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 9 }} className="lma-guide-benefits-grid">
                <Benefit icon={<Check size={14} />} title="Toujours sélectionnable" copy="Cliquez directement sur un objet : l’outil revient automatiquement en mode sélection." tokens={tokens} />
                <Benefit icon={<Cloud size={14} />} title="Local puis cloud" copy="Travaillez sans compte, puis connectez le cloud pour synchroniser et collaborer." tokens={tokens} />
                <Benefit icon={<FolderOpen size={14} />} title="Portable" copy="Importez ou exportez un projet complet au format AIME JSON à tout moment." tokens={tokens} />
              </section>
            </div>

            <footer style={{ padding: 14, borderTop: `1px solid ${tokens.border}`, display: 'flex', alignItems: 'center', gap: 9, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
              {hasRecentProject && <button onClick={() => { onClose(); onOpenRecent(); }} style={secondaryButton(tokens)}><FolderOpen size={14} /> Ouvrir le dernier projet</button>}
              <button onClick={() => { onClose(); onCreate(); }} style={primaryButton(tokens)}><Plus size={14} /> Créer un projet <ArrowRight size={14} /></button>
            </footer>
            <style>{`@media(max-width:760px){.lma-guide-hero-grid,.lma-guide-step-grid,.lma-guide-benefits-grid{grid-template-columns:1fr!important}.lma-guide-interface-row{grid-template-columns:1fr!important;gap:4px!important}}`}</style>
          </section>
        </div>,
        document.body,
      )
    : null;

  return <>
    <section style={{ marginBottom: 20, padding: 16, borderRadius: 15, border: `1px solid ${tokens.border}`, background: tokens.panel, display: 'grid', gridTemplateColumns: 'minmax(260px,.8fr) minmax(440px,1.2fr)', gap: 16, alignItems: 'center' }} className="lma-home-guide-card">
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}><span style={{ width: 32, height: 32, borderRadius: 10, display: 'grid', placeItems: 'center', background: tokens.surface, border: `1px solid ${tokens.border}` }}><BookOpen size={15} /></span><span style={eyebrow(tokens)}>Prise en main</span></div>
        <h2 style={{ margin: '13px 0 7px', fontSize: 19, letterSpacing: '-.035em' }}>Comprendre LE MONDE AIME en 3 minutes.</h2>
        <p style={{ margin: 0, maxWidth: 480, color: tokens.muted, fontSize: 10, lineHeight: 1.6 }}>Découvrez le rôle des cartes, du canevas, de la timeline, du mini-site, du cloud et de l’agent avant de commencer.</p>
        <div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
          <button onClick={onOpen} style={primaryButton(tokens)}><BookOpen size={13} /> Voir le mode d’emploi</button>
          {hasRecentProject
            ? <button onClick={onOpenRecent} style={secondaryButton(tokens)}><FolderOpen size={13} /> Reprendre mon projet</button>
            : <button onClick={onCreate} style={secondaryButton(tokens)}><Plus size={13} /> Créer mon premier projet</button>}
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 8 }} className="lma-home-guide-steps">
        {STEPS.slice(0, 6).map((step) => <div key={step.number} style={{ minHeight: 72, padding: 10, borderRadius: 11, border: `1px solid ${tokens.border}`, background: tokens.surface }}><span style={{ color: tokens.muted, fontSize: 8, fontWeight: 850, letterSpacing: '.08em' }}>{step.number}</span><strong style={{ display: 'block', marginTop: 10, fontSize: 9.5, lineHeight: 1.3 }}>{step.title}</strong></div>)}
      </div>
      <style>{`@media(max-width:980px){.lma-home-guide-card{grid-template-columns:1fr!important}.lma-home-guide-steps{grid-template-columns:repeat(3,minmax(0,1fr))!important}}@media(max-width:620px){.lma-home-guide-steps{grid-template-columns:repeat(2,minmax(0,1fr))!important}}`}</style>
    </section>
    {dialog}
  </>;
};

interface GuideTokens {
  panel: string;
  surface: string;
  border: string;
  text: string;
  muted: string;
  primaryBg: string;
  primaryText: string;
}

function guideTokens(isDark: boolean): GuideTokens {
  return {
    panel: isDark ? '#1D1D1F' : '#FAFAFB',
    surface: isDark ? '#242426' : '#FFFFFF',
    border: isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.09)',
    text: isDark ? '#F5F5F5' : '#121213',
    muted: isDark ? 'rgba(245,245,245,.5)' : 'rgba(18,18,19,.52)',
    primaryBg: isDark ? '#F3F3F4' : '#18181A',
    primaryText: isDark ? '#18181A' : '#FFFFFF',
  };
}

const GuideStep: React.FC<{ step: typeof STEPS[number]; tokens: GuideTokens }> = ({ step, tokens }) => <article style={{ minHeight: 96, padding: 13, borderRadius: 12, border: `1px solid ${tokens.border}`, background: tokens.surface, display: 'grid', gridTemplateColumns: '34px 1fr', gap: 10, alignItems: 'start' }}><span style={{ width: 32, height: 32, borderRadius: 9, display: 'grid', placeItems: 'center', border: `1px solid ${tokens.border}`, color: tokens.muted }}>{step.icon}</span><span><span style={{ display: 'block', color: tokens.muted, fontSize: 7.5, fontWeight: 850, letterSpacing: '.09em' }}>{step.number}</span><strong style={{ display: 'block', marginTop: 4, fontSize: 10.5 }}>{step.title}</strong><span style={{ display: 'block', marginTop: 5, color: tokens.muted, fontSize: 8.8, lineHeight: 1.45 }}>{step.description}</span></span></article>;

const Benefit: React.FC<{ icon: React.ReactNode; title: string; copy: string; tokens: GuideTokens }> = ({ icon, title, copy, tokens }) => <div style={{ padding: 13, borderRadius: 12, border: `1px solid ${tokens.border}`, background: tokens.surface }}><span style={{ width: 28, height: 28, borderRadius: 8, display: 'grid', placeItems: 'center', border: `1px solid ${tokens.border}`, color: tokens.muted }}>{icon}</span><strong style={{ display: 'block', marginTop: 10, fontSize: 10 }}>{title}</strong><span style={{ display: 'block', marginTop: 5, color: tokens.muted, fontSize: 8.7, lineHeight: 1.5 }}>{copy}</span></div>;

const eyebrow = (tokens: GuideTokens): React.CSSProperties => ({ color: tokens.muted, fontSize: 8, fontWeight: 850, textTransform: 'uppercase', letterSpacing: '.12em' });
const iconButton = (tokens: GuideTokens): React.CSSProperties => ({ width: 32, height: 32, borderRadius: 9, border: `1px solid ${tokens.border}`, background: 'transparent', color: tokens.muted, cursor: 'pointer', display: 'grid', placeItems: 'center' });
const primaryButton = (tokens: GuideTokens): React.CSSProperties => ({ minHeight: 36, padding: '0 13px', borderRadius: 9, border: 0, background: tokens.primaryBg, color: tokens.primaryText, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7, fontSize: 9.5, fontWeight: 780 });
const secondaryButton = (tokens: GuideTokens): React.CSSProperties => ({ minHeight: 36, padding: '0 13px', borderRadius: 9, border: `1px solid ${tokens.border}`, background: tokens.surface, color: tokens.text, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7, fontSize: 9.5, fontWeight: 680 });
