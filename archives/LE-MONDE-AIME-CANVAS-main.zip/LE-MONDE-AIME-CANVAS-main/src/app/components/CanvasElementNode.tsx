import React, { useEffect, useRef, useState } from 'react';
import { Eye, Grip, LayoutTemplate, Lock, MoreHorizontal, Trash2, Unlock } from 'lucide-react';
import type { CanvasElementData, Tool } from '../types';

interface CanvasElementNodeProps {
  element: CanvasElementData;
  canvasScale: number;
  activeTool: Tool;
  selected: boolean;
  onSelect: (id: string) => void;
  onChange: (id: string, patch: Partial<CanvasElementData>) => void;
  onDelete: (id: string) => void;
  onDuplicate: (id: string) => void;
  onPreview?: (id: string) => void;
  onCompose?: (id: string) => void;
  onOpenMenu?: (event: React.MouseEvent<HTMLButtonElement>, id: string) => void;
  snapEnabled?: boolean;
  gridSize?: number;
}

export const CanvasElementNode: React.FC<CanvasElementNodeProps> = ({
  element,
  canvasScale,
  activeTool,
  selected,
  onSelect,
  onChange,
  onDelete,
  onPreview,
  onCompose,
  onOpenMenu,
  snapEnabled = true,
  gridSize = 28,
}) => {
  const dragRef = useRef<{ pointerId: number; clientX: number; clientY: number; x: number; y: number } | null>(null);
  const resizeRef = useRef<{ pointerId: number; clientX: number; clientY: number; w: number; h: number } | null>(null);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    if (!selected) return;
    window.dispatchEvent(new CustomEvent('lma-canvas-selection', {
      detail: { kind: 'element', label: element.content || element.type, background: element.style.background },
    }));
  }, [element.content, element.style.background, element.type, selected]);

  useEffect(() => {
    const applyPalette = (event: Event) => {
      if (!selected) return;
      const detail = (event as CustomEvent<{ colors?: string[]; background?: string }>).detail;
      if (!detail?.background) return;
      onChange(element.id, {
        style: {
          ...element.style,
          background: detail.background,
          color: '#FFFFFF',
          borderWidth: Math.max(1, element.style.borderWidth),
          borderColor: detail.colors?.[1] || detail.colors?.[0] || element.style.borderColor,
        },
      });
    };
    window.addEventListener('lma-apply-selection-palette', applyPalette as EventListener);
    return () => window.removeEventListener('lma-apply-selection-palette', applyPalette as EventListener);
  }, [element.id, element.style, onChange, selected]);

  if (element.hidden) return null;

  const startDrag = (e: React.PointerEvent, fromHandle = false) => {
    const target = e.target as HTMLElement;
    if (!fromHandle && (target.closest('[data-no-drag]') || ['INPUT','TEXTAREA','BUTTON','AUDIO','VIDEO','IFRAME'].includes(target.tagName))) return;
    onSelect(element.id);
    if (element.locked || activeTool !== 'select') return;
    e.preventDefault();
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = { pointerId: e.pointerId, clientX: e.clientX, clientY: e.clientY, x: element.x, y: element.y };
  };

  const beginDrag = (e: React.PointerEvent) => startDrag(e, false);
  const beginHandleDrag = (e: React.PointerEvent) => startDrag(e, true);

  const moveDrag = (e: React.PointerEvent) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== e.pointerId) return;
    const scale = Math.max(0.12, canvasScale || 1);
    onChange(element.id, {
      x: snapEnabled ? Math.round((drag.x + (e.clientX - drag.clientX) / scale) / gridSize) * gridSize : drag.x + (e.clientX - drag.clientX) / scale,
      y: snapEnabled ? Math.round((drag.y + (e.clientY - drag.clientY) / scale) / gridSize) * gridSize : drag.y + (e.clientY - drag.clientY) / scale,
    });
  };

  const endDrag = (e: React.PointerEvent) => {
    if (dragRef.current?.pointerId !== e.pointerId) return;
    dragRef.current = null;
    try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch { /* noop */ }
  };

  const beginResize = (e: React.PointerEvent) => {
    if (element.locked) return;
    e.preventDefault();
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    resizeRef.current = { pointerId: e.pointerId, clientX: e.clientX, clientY: e.clientY, w: element.width, h: element.height };
  };

  const moveResize = (e: React.PointerEvent) => {
    const resize = resizeRef.current;
    if (!resize || resize.pointerId !== e.pointerId) return;
    const scale = Math.max(0.12, canvasScale || 1);
    onChange(element.id, {
      width: Math.max(80, snapEnabled ? Math.round((resize.w + (e.clientX - resize.clientX) / scale) / gridSize) * gridSize : resize.w + (e.clientX - resize.clientX) / scale),
      height: Math.max(48, snapEnabled ? Math.round((resize.h + (e.clientY - resize.clientY) / scale) / gridSize) * gridSize : resize.h + (e.clientY - resize.clientY) / scale),
    });
  };

  const endResize = (e: React.PointerEvent) => {
    if (resizeRef.current?.pointerId !== e.pointerId) return;
    resizeRef.current = null;
    try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch { /* noop */ }
  };

  const s = element.style;
  const commonContentStyle: React.CSSProperties = {
    width: '100%', height: '100%', boxSizing: 'border-box', position: 'relative', overflow: 'hidden',
    borderRadius: s.borderRadius,
    opacity: s.opacity,
    border: s.borderWidth > 0 ? `${s.borderWidth}px solid ${s.borderColor}` : 'none',
    boxShadow: s.shadow > 0 ? `0 ${Math.max(2, s.shadow / 3)}px ${s.shadow}px rgba(0,0,0,0.28)` : 'none',
    background: s.background,
    color: s.color,
    fontFamily: s.fontFamily,
    fontSize: s.fontSize,
    fontWeight: s.fontWeight,
    textAlign: s.textAlign,
    filter: s.blur > 0 ? `blur(${s.blur}px)` : undefined,
  };

  const renderContent = () => {
    if (element.type === 'image') {
      return element.url ? <img src={element.url} alt={element.content || 'Image'} style={{ width: '100%', height: '100%', objectFit: s.objectFit, display: 'block' }} /> : <Placeholder label="Importer une image" />;
    }
    if (element.type === 'video') {
      return element.url ? <video src={element.url} autoPlay playsInline muted={element.videoMuted !== false} loop={element.videoLoop !== false} onLoadedMetadata={(e) => { e.currentTarget.playbackRate = element.videoRate || 1; }} style={{ width: '100%', height: '100%', objectFit: s.objectFit, display: 'block' }} /> : <Placeholder label="Importer une vidéo" />;
    }
    if (element.type === 'embed') return element.url ? <iframe title={element.content || 'Contenu web'} src={element.url} style={{ width: '100%', height: '100%', border: 0, pointerEvents: selected ? 'auto' : 'none' }} /> : <Placeholder label="Coller une URL web" />;
    if (element.type === 'music') return <div style={{ padding: 18, height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 12 }}><div style={{ fontSize: Math.max(18, s.fontSize), fontWeight: 800 }}>{element.content || 'Titre musical'}</div>{element.url ? <audio controls src={element.url} style={{ width: '100%' }} /> : <span style={{ opacity: 0.55 }}>Ajoutez une URL audio</span>}</div>;
    if (element.type === 'gallery') {
      const urls = element.url.split('\n').map((v) => v.trim()).filter(Boolean).slice(0, 6);
      return urls.length ? <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 4, padding: 4, width: '100%', height: '100%', boxSizing: 'border-box' }}>{urls.map((url, index) => <img key={`${url}-${index}`} src={url} alt="Galerie" style={{ width: '100%', height: '100%', minHeight: 0, objectFit: 'cover', borderRadius: Math.max(4, s.borderRadius / 2) }} />)}</div> : <Placeholder label="Galerie — une URL par ligne" />;
    }
    if (element.type === 'card' && element.roleMeta) return <div style={{ padding: 22, width: '100%', height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', position: 'relative' }}><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}><span style={{ padding: '5px 8px', borderRadius: 999, background: 'rgba(255,255,255,.08)', color: '#E4E4E7', fontSize: 8, fontWeight: 800, letterSpacing: '.08em', textTransform: 'uppercase' }}>{element.roleMeta.universe}</span><span style={{ width: 8, height: 8, borderRadius: 99, background: '#A3A3A8', boxShadow: '0 0 0 5px rgba(163,163,168,.10)' }} /></div><div style={{ marginTop: 'auto', marginBottom: 'auto' }}>{editing ? <textarea autoFocus value={element.content} onChange={(event) => onChange(element.id, { content: event.target.value })} onBlur={() => setEditing(false)} style={{ width: '100%', minHeight: 90, resize: 'none', background: 'transparent', border: 0, color: 'inherit', font: 'inherit', fontSize: Math.max(24, s.fontSize), fontWeight: 800, lineHeight: 1, outline: 0 }} /> : <div style={{ fontSize: Math.max(24, s.fontSize), fontWeight: 850, letterSpacing: '-.05em', lineHeight: 1 }}>{element.content}</div>}<div style={{ marginTop: 12, fontSize: 10, lineHeight: 1.45, opacity: .52 }}>{element.roleMeta.subtitle}</div></div><div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 8.5, opacity: .45 }}><span style={{ width: 20, height: 20, borderRadius: 7, display: 'grid', placeItems: 'center', background: 'rgba(255,255,255,.08)' }}>+</span>Connecter cette carte à un univers</div></div>;
    if (element.type === 'shape') return <div style={{ width: '100%', height: '100%', background: s.background }} />;
    if (element.type === 'button' || element.type === 'link') return <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 12, boxSizing: 'border-box' }}>{editing ? <input autoFocus value={element.content} onChange={(e) => onChange(element.id, { content: e.target.value })} onBlur={() => setEditing(false)} onKeyDown={(e) => e.key === 'Enter' && setEditing(false)} style={{ width: '100%', background: 'transparent', border: 0, color: 'inherit', font: 'inherit', textAlign: 'inherit', outline: 0 }} /> : <span>{element.content || (element.type === 'button' ? 'Bouton' : 'Lien')}</span>}</div>;
    return <div style={{ padding: element.type === 'section' || element.type === 'card' ? 22 : 12, width: '100%', height: '100%', boxSizing: 'border-box', display: 'flex', alignItems: element.type === 'text' ? 'flex-start' : 'center', justifyContent: s.textAlign === 'center' ? 'center' : s.textAlign === 'right' ? 'flex-end' : 'flex-start' }}>{editing ? <textarea autoFocus value={element.content} onChange={(e) => onChange(element.id, { content: e.target.value })} onBlur={() => setEditing(false)} style={{ width: '100%', height: '100%', resize: 'none', background: 'transparent', border: 0, color: 'inherit', font: 'inherit', textAlign: 'inherit', outline: 0 }} /> : <span style={{ whiteSpace: 'pre-wrap', lineHeight: 1.35 }}>{element.content || 'Double-cliquez pour écrire'}</span>}</div>;
  };

  return (
    <div data-canvas-object onPointerDown={beginDrag} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag} onDoubleClick={(e) => { e.stopPropagation(); if (!['image','video','embed','gallery','music','shape'].includes(element.type)) setEditing(true); }} onClick={(e) => { e.stopPropagation(); onSelect(element.id); }} style={{ position: 'absolute', left: element.x, top: element.y, width: element.width, height: element.height, zIndex: element.zIndex, cursor: element.locked ? 'not-allowed' : activeTool === 'select' ? 'move' : 'default', outline: selected ? '2px solid #D4D4D8' : '1px solid transparent', outlineOffset: 4, transition: dragRef.current || resizeRef.current ? 'none' : 'outline-color 0.15s' }}>
      <div style={commonContentStyle}>{renderContent()}{s.overlay && s.overlay !== 'transparent' && <div style={{ position: 'absolute', inset: 0, background: s.overlay, pointerEvents: 'none' }} />}</div>

      {selected && <><div data-no-drag onPointerDown={(e) => { e.stopPropagation(); }} style={{ position: 'absolute', top: -39, left: 0, display: 'flex', alignItems: 'center', gap: 2, padding: 5, borderRadius: 11, background: '#1B1B1D', color: '#fff', boxShadow: '0 10px 28px rgba(0,0,0,.3)' }}><span title={element.locked ? 'Objet verrouillé' : 'Déplacer l’objet'} onPointerDown={beginHandleDrag} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag} style={{ width: 27, height: 27, display: 'grid', placeItems: 'center', cursor: element.locked ? 'not-allowed' : 'grab', touchAction: 'none' }}><Grip size={13} /></span>{onPreview && <TinyButton title="Aperçu vivant" onClick={(e) => { e.stopPropagation(); onPreview(element.id); }}><Eye size={12} /></TinyButton>}{onCompose && <TinyButton title="Mise en page" onClick={(e) => { e.stopPropagation(); onCompose(element.id); }}><LayoutTemplate size={12} /></TinyButton>}{onOpenMenu && <TinyButton title="Remix, éditer, relier, publier et gérer" onClick={(e) => { e.stopPropagation(); onOpenMenu(e, element.id); }}><MoreHorizontal size={14} /></TinyButton>}<TinyButton title={element.locked ? 'Déverrouiller' : 'Verrouiller'} onClick={(e) => { e.stopPropagation(); onChange(element.id, { locked: !element.locked }); }}>{element.locked ? <Unlock size={12} /> : <Lock size={12} />}</TinyButton><TinyButton title="Supprimer" onClick={(e) => { e.stopPropagation(); onDelete(element.id); }}><Trash2 size={12} /></TinyButton></div>{!element.locked && <div onPointerDown={beginResize} onPointerMove={moveResize} onPointerUp={endResize} onPointerCancel={endResize} style={{ position: 'absolute', right: -7, bottom: -7, width: 14, height: 14, borderRadius: 4, background: '#D4D4D8', border: '2px solid #1B1B1D', cursor: 'nwse-resize', touchAction: 'none' }} />}</>}
    </div>
  );
};

const Placeholder: React.FC<{ label: string }> = ({ label }) => <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, boxSizing: 'border-box', background: 'repeating-linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.07) 8px,rgba(0,0,0,.05) 8px,rgba(0,0,0,.05) 16px)', color: 'rgba(255,255,255,.65)', fontFamily: 'Inter', fontSize: 12, textAlign: 'center' }}>{label}</div>;
const TinyButton: React.FC<{ title: string; onClick: (e: React.MouseEvent) => void; children: React.ReactNode }> = ({ title, onClick, children }) => <button data-no-drag title={title} onPointerDown={(e) => { e.stopPropagation(); }} onClick={onClick} style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>{children}</button>;
