import React, { useMemo, useState } from 'react';
import {
  ChevronDown, ChevronRight, Eye, EyeOff, File, Globe2, Image as ImageIcon, Layers3,
  LayoutGrid, Lock, Monitor, Music2, PanelLeftClose, Search, StickyNote, Type, Video, Home,
  GitBranch, ArrowRight, Sparkles,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import type { CanvasElementData, CanvasSelectionSummary, RemixTarget, WeddingLot } from '../types';

type ViewMode = 'canvas' | 'timeline' | 'minisite';
type SidebarTab = 'pages' | 'layers' | 'assets' | 'causal';

interface WorkspaceSidebarProps {
  open: boolean;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  onHome: () => void;
  lots: WeddingLot[];
  activeLotId: number | null;
  cardSettings: Record<string, Record<string, any>>;
  onSelectLot: (id: number | null) => void;
  layers: CanvasSelectionSummary[];
  selectedKey?: string | null;
  onSelectLayer: (layer: CanvasSelectionSummary) => void;
  onToggleLayerVisibility: (layer: CanvasSelectionSummary) => void;
  assets: CanvasElementData[];
  onSelectAsset: (id: string) => void;
  onClose: () => void;
}

function layerIcon(layer: CanvasSelectionSummary) {
  if (layer.kind === 'plan') return layer.id === 'minisite' ? <Globe2 size={13} /> : <Monitor size={13} />;
  if (layer.kind === 'entry') return <File size={13} />;
  if (layer.kind === 'lot') return <Layers3 size={13} />;
  if (layer.kind === 'note') return <StickyNote size={13} />;
  return <Type size={13} />;
}

function assetIcon(type: CanvasElementData['type']) {
  if (type === 'video') return <Video size={13} />;
  if (type === 'music') return <Music2 size={13} />;
  return <ImageIcon size={13} />;
}

function lotVisual(lot: WeddingLot, cardSettings: Record<string, Record<string, any>>) {
  for (const card of lot.cards) {
    const settings = cardSettings[card.id] || {};
    const custom = settings.frontMediaUrl || settings.image || settings.photo;
    if (typeof custom === 'string' && custom) return { image: custom, background: undefined };
    if (card.image) return { image: card.image, background: undefined };
  }
  const first = lot.cards[0];
  return { image: undefined, background: first?.gradient || 'linear-gradient(145deg,#2A2A2D,#161618)' };
}

function causalInfluences(label: string) {
  const value = label.toLocaleLowerCase('fr');
  if (value.includes('lieu') || value.includes('domaine') || value.includes('venue')) return ['Date et disponibilité', 'Budget', 'Invités', 'Décoration', 'Logistique'];
  if (value.includes('mariage') || value.includes('couple') || value.includes('projet')) return ['Timeline', 'Mini-site', 'Invitations', 'Prestataires', 'Contenus du jour J'];
  if (value.includes('invité') || value.includes('guest')) return ['Traiteur', 'Plan de table', 'Budget', 'Logistique'];
  if (value.includes('budget') || value.includes('prix')) return ['Prestataires', 'Choix du lieu', 'Priorités', 'Décisions à prendre'];
  return ['Timeline', 'Mini-site', 'Décisions liées', 'Contenus dérivés'];
}

export const WorkspaceSidebar: React.FC<WorkspaceSidebarProps> = ({
  open, viewMode, onViewModeChange, onHome, lots, activeLotId, cardSettings, onSelectLot,
  layers, selectedKey, onSelectLayer, onToggleLayerVisibility, assets, onSelectAsset, onClose,
}) => {
  const { isDark } = useTheme();
  const [tab, setTab] = useState<SidebarTab>('pages');
  const [query, setQuery] = useState('');
  const [lotsOpen, setLotsOpen] = useState(true);
  const border = isDark ? 'rgba(255,255,255,.075)' : 'rgba(0,0,0,.08)';
  const text = isDark ? '#F2F2F3' : '#151517';
  const muted = isDark ? 'rgba(242,242,243,.44)' : 'rgba(21,21,23,.45)';
  const panel = isDark ? 'rgba(20,20,21,.99)' : 'rgba(250,250,251,.99)';
  const activeBg = isDark ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.07)';
  const softBg = isDark ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.035)';

  const filteredLayers = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase('fr');
    return normalized ? layers.filter((layer) => layer.label.toLocaleLowerCase('fr').includes(normalized)) : layers;
  }, [layers, query]);

  const selectedLayer = selectedKey ? layers.find((layer) => `${layer.kind}:${layer.id}` === selectedKey) : undefined;
  const causalSource = selectedLayer?.label || 'Projet';
  const influences = causalInfluences(causalSource);

  if (!open) return null;

  const openProjection = (id: 'timeline' | 'minisite') => {
    onSelectLot(null);
    const target: RemixTarget = { kind: 'plan', id, label: id === 'timeline' ? 'Timeline' : 'Mini-site' };
    window.dispatchEvent(new CustomEvent('lma-plan-preview', { detail: { target, mode: id === 'timeline' ? 'timeline' : 'site' } }));
  };

  const planButton = (id: ViewMode, label: string, icon: React.ReactNode) => {
    const projection = id !== 'canvas';
    return <button key={id} onClick={() => projection ? openProjection(id) : (onSelectLot(null), onViewModeChange('canvas'))} style={{ width: '100%', minHeight: 42, border: 0, borderRadius: 8, background: id === 'canvas' && viewMode === 'canvas' && activeLotId == null ? activeBg : 'transparent', color: text, cursor: 'pointer', padding: '5px 10px', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left' }}><span style={{ color: id === 'canvas' && viewMode === 'canvas' && activeLotId == null ? text : muted, display: 'grid', placeItems: 'center' }}>{icon}</span><span style={{ minWidth: 0, flex: 1 }}><strong style={{ display: 'block', fontSize: 10.5, fontWeight: id === 'canvas' && viewMode === 'canvas' && activeLotId == null ? 720 : 560 }}>{label}</strong>{projection && <span style={{ display: 'block', marginTop: 3, color: muted, fontSize: 7.8 }}>Carte de projection · aperçu</span>}</span><ChevronRight size={12} style={{ color: muted, opacity: .55 }} /></button>;
  };

  return <aside style={{ position: 'fixed', top: 50, bottom: 0, left: 0, width: 268, zIndex: 190, background: panel, color: text, borderRight: `1px solid ${border}`, backdropFilter: 'blur(22px)', WebkitBackdropFilter: 'blur(22px)', boxShadow: isDark ? '12px 0 34px rgba(0,0,0,.12)' : '10px 0 30px rgba(0,0,0,.04)', display: 'flex', flexDirection: 'column' }}>
    <div style={{ height: 48, display: 'flex', alignItems: 'center', gap: 3, padding: '0 7px', borderBottom: `1px solid ${border}` }}>
      {(['pages', 'layers', 'causal', 'assets'] as SidebarTab[]).map((id) => <button key={id} onClick={() => setTab(id)} title={id === 'causal' ? 'Empreinte causale' : undefined} style={{ height: 30, padding: '0 8px', border: 0, borderRadius: 7, background: tab === id ? activeBg : 'transparent', color: tab === id ? text : muted, cursor: 'pointer', fontSize: 9.2, fontWeight: tab === id ? 750 : 500 }}>{id === 'pages' ? 'Cartes' : id === 'layers' ? 'Calques' : id === 'causal' ? 'Impact' : 'Ressources'}</button>)}
      <button title="Masquer le panneau" onClick={onClose} style={{ marginLeft: 'auto', width: 28, height: 28, border: 0, borderRadius: 7, background: 'transparent', color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><PanelLeftClose size={15} /></button>
    </div>

    {(tab === 'layers' || tab === 'assets') && <div style={{ position: 'relative', margin: '10px 10px 6px' }}><Search size={13} style={{ position: 'absolute', left: 9, top: 9, color: muted }} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Rechercher…" style={{ width: '100%', height: 31, borderRadius: 8, border: `1px solid ${border}`, background: softBg, color: text, padding: '0 9px 0 30px', boxSizing: 'border-box', outline: 'none', fontSize: 9.5 }} /></div>}

    <div style={{ flex: 1, overflowY: 'auto', padding: 9, scrollbarWidth: 'thin' }}>
      {tab === 'pages' && <div>
        <SectionLabel text="Cartes du projet" muted={muted} />
        <button onClick={onHome} style={{ width: '100%', height: 38, border: 0, borderRadius: 8, background: 'transparent', color: text, cursor: 'pointer', padding: '0 10px', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left' }}><Home size={14} color={muted} /><span style={{ fontSize: 10.5 }}>Accueil</span></button>
        {planButton('canvas', 'Canevas principal', <LayoutGrid size={14} />)}
        <button onClick={() => setLotsOpen((value) => !value)} style={{ width: '100%', height: 38, border: 0, borderRadius: 8, background: activeLotId != null ? activeBg : 'transparent', color: text, cursor: 'pointer', padding: '0 10px', display: 'flex', alignItems: 'center', gap: 10, textAlign: 'left', marginTop: 2 }}><Layers3 size={14} color={activeLotId != null ? text : muted} /><span style={{ fontSize: 10.5, fontWeight: activeLotId != null ? 720 : 520 }}>Lots de cartes</span><span style={{ marginLeft: 'auto', color: muted }}>{lotsOpen ? <ChevronDown size={13} /> : <ChevronRight size={13} />}</span></button>
        {lotsOpen && <div style={{ margin: '4px 0 8px 8px', paddingLeft: 8, borderLeft: `1px solid ${border}`, display: 'flex', flexDirection: 'column', gap: 3 }}>{lots.map((lot) => { const active = activeLotId === lot.id; const visual = lotVisual(lot, cardSettings); return <button key={lot.id} onClick={() => { onViewModeChange('canvas'); onSelectLot(lot.id); }} style={{ minHeight: 46, width: '100%', border: 0, borderRadius: 8, padding: '5px 7px', background: active ? activeBg : 'transparent', color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 9, textAlign: 'left' }}><span style={{ width: 34, height: 34, borderRadius: 7, flexShrink: 0, overflow: 'hidden', background: visual.background || '#29292B', border: `1px solid ${border}` }}>{visual.image && <img src={visual.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}</span><span style={{ minWidth: 0, flex: 1 }}><strong style={{ display: 'block', fontSize: 9.7, fontWeight: active ? 720 : 560, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lot.title}</strong><span style={{ display: 'block', marginTop: 3, fontSize: 8, color: muted }}>{lot.cards.length} cartes</span></span></button>; })}</div>}
        {planButton('timeline', 'Timeline', <Monitor size={14} />)}
        {planButton('minisite', 'Mini-site', <Globe2 size={14} />)}
        <div style={{ height: 1, background: border, margin: '14px 4px' }} />
        <div style={{ margin: '6px 8px', padding: 11, borderRadius: 10, background: softBg, border: `1px solid ${border}` }}><div style={{ fontSize: 9, fontWeight: 760, marginBottom: 6 }}>Les cartes sont la source</div><p style={{ margin: 0, color: muted, fontSize: 8.5, lineHeight: 1.55 }}>Timeline et Mini-site sont des cartes de projection. Remplissez et reliez les cartes, puis ouvrez leur aperçu.</p></div>
      </div>}

      {tab === 'causal' && <div>
        <SectionLabel text="Empreinte causale" muted={muted} />
        <div style={{ padding: '10px 10px 14px', borderRadius: 12, background: softBg, border: `1px solid ${border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span style={{ width: 28, height: 28, borderRadius: 8, display: 'grid', placeItems: 'center', background: activeBg }}><GitBranch size={14} /></span><div><div style={{ fontSize: 10, fontWeight: 800 }}>{causalSource}</div><div style={{ marginTop: 3, fontSize: 8, color: muted }}>Point de départ sélectionné</div></div></div>
          <div style={{ margin: '14px 0 8px', height: 1, background: border }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: muted, fontSize: 8.5 }}><Sparkles size={11} /> Cette carte influence</div>
          <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 5 }}>{influences.map((item) => <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '7px 8px', borderRadius: 7, background: isDark ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.025)', fontSize: 9 }}><ArrowRight size={11} style={{ color: muted }} />{item}</div>)}</div>
          <div style={{ marginTop: 12, fontSize: 8, lineHeight: 1.5, color: muted }}>La modification d'une carte peut produire des conséquences sur les projections et les décisions liées.</div>
        </div>
        <div style={{ margin: '12px 8px', padding: 10, borderRadius: 10, border: `1px dashed ${border}`, color: muted, fontSize: 8.5, lineHeight: 1.5 }}>Sélectionnez une carte dans le canevas pour recalculer son empreinte.</div>
      </div>}

      {tab === 'layers' && <div><SectionLabel text={`${filteredLayers.length} objets`} muted={muted} />{filteredLayers.map((layer) => { const key = `${layer.kind}:${layer.id}`; const active = selectedKey === key; return <div key={key} style={{ height: 35, borderRadius: 8, background: active ? activeBg : 'transparent', display: 'flex', alignItems: 'center', gap: 7, padding: '0 5px 0 9px' }}><button onClick={() => layer.kind === 'plan' ? openProjection(layer.id as 'timeline' | 'minisite') : onSelectLayer(layer)} style={{ flex: 1, minWidth: 0, height: '100%', border: 0, background: 'transparent', color: text, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, textAlign: 'left' }}>{layerIcon(layer)}<span style={{ fontSize: 9.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{layer.label}</span>{layer.locked && <Lock size={10} style={{ opacity: .4, marginLeft: 'auto' }} />}</button><button title={layer.hidden ? 'Afficher' : 'Masquer'} onClick={() => onToggleLayerVisibility(layer)} style={{ width: 25, height: 25, border: 0, borderRadius: 6, background: 'transparent', color: muted, cursor: 'pointer', display: 'grid', placeItems: 'center' }}>{layer.hidden ? <EyeOff size={12} /> : <Eye size={12} />}</button></div>; })}{!filteredLayers.length && <div style={{ padding: 18, textAlign: 'center', color: muted, fontSize: 9 }}>Aucun objet ne correspond à la recherche.</div>}</div>}

      {tab === 'assets' && <div><SectionLabel text={`${assets.length} médias liés`} muted={muted} /><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>{assets.map((asset) => <button key={asset.id} onClick={() => onSelectAsset(asset.id)} style={{ aspectRatio: '1.2', borderRadius: 9, border: `1px solid ${border}`, overflow: 'hidden', padding: 0, background: softBg, color: text, cursor: 'pointer', position: 'relative' }}>{asset.url && asset.type === 'image' ? <img src={asset.url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center', color: muted }}>{assetIcon(asset.type)}</span>}<span style={{ position: 'absolute', left: 5, right: 5, bottom: 5, padding: '3px 5px', borderRadius: 5, background: 'rgba(0,0,0,.6)', color: '#fff', fontSize: 7.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{asset.content || asset.type}</span></button>)}</div>{!assets.length && <div style={{ padding: 22, textAlign: 'center', color: muted, fontSize: 9, lineHeight: 1.5 }}>Ajoutez une image, une vidéo ou une musique depuis la barre inférieure.</div>}</div>}
    </div>
  </aside>;
};

const SectionLabel: React.FC<{ text: string; muted: string }> = ({ text, muted }) => <div style={{ padding: '7px 8px 8px', color: muted, fontSize: 8, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase' }}>{text}</div>;
