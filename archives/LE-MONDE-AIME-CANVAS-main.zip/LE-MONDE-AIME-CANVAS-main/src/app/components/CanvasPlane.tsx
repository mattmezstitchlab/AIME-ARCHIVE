import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Eye, GripHorizontal, LayoutTemplate, MoreHorizontal } from 'lucide-react';
import type { CanvasPlanId, CanvasPoint, RemixTarget, Tool } from '../types';
import { getProjectItem, setProjectItem } from '../utils/projectStore';
import { ProjectionCard } from './ProjectionCard';
import { CardPreviewPanel } from './CardPreviewPanel';
import type { CardPreviewMode } from './CardPreviewPanel';
import { CardCompositionPanel } from './CardCompositionPanel';
import type { CardCompositionSettings } from './CardCompositionPanel';

export interface CanvasPlaneSize { width: number; height: number }

interface CanvasPlaneProps {
  title: string;
  subtitle: string;
  position: CanvasPoint;
  size: CanvasPlaneSize;
  canvasScale: number;
  activeTool: Tool;
  selected?: boolean;
  locked?: boolean;
  zIndex?: number;
  onSelect?: () => void;
  onPositionChange?: (position: CanvasPoint) => void;
  onSizeChange?: (size: CanvasPlaneSize) => void;
  onOpenMenu?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  children: React.ReactNode;
  toolbar?: React.ReactNode;
}

const DEFAULT_COMPOSITION: CardCompositionSettings = {
  preset: 'editorial', background: '#242426', textColor: '#F5F5F5', accentColor: '#D4D4D8',
  titleVisible: true, introVisible: true, mediaUrl: '', primaryAction: 'Découvrir', secondaryAction: '',
};

function readRecord<T>(key: string): Record<string, T> {
  try { return JSON.parse(getProjectItem(key) || '{}') as Record<string, T>; }
  catch { return {}; }
}

export const CanvasPlane: React.FC<CanvasPlaneProps> = ({
  title, subtitle, position, size, canvasScale, activeTool, selected = false,
  locked = false, zIndex = 30, onPositionChange, onSizeChange, onOpenMenu, children,
}) => {
  const id: CanvasPlanId = title.toLocaleLowerCase('fr').includes('timeline') ? 'timeline' : 'minisite';
  const target: RemixTarget = { kind: 'plan', id, label: title };
  const defaultMode: CardPreviewMode = id === 'timeline' ? 'timeline' : 'site';
  const rootRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ pointerId: number; clientX: number; clientY: number; origin: CanvasPoint } | null>(null);
  const [localSelected, setLocalSelected] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewMode, setPreviewMode] = useState<CardPreviewMode>(defaultMode);
  const [compositionOpen, setCompositionOpen] = useState(false);
  const [composition, setComposition] = useState<CardCompositionSettings>(() => readRecord<CardCompositionSettings>('lma_v98_plan_compositions')[id] || DEFAULT_COMPOSITION);
  const [connections, setConnections] = useState<string[]>(() => readRecord<string[]>('lma_v98_plan_connections')[id] || []);
  const isSelected = selected || localSelected;

  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setLocalSelected(false);
    };
    window.addEventListener('mousedown', close);
    return () => window.removeEventListener('mousedown', close);
  }, []);

  useEffect(() => {
    const preview = (event: Event) => {
      const detail = (event as CustomEvent<{ target?: RemixTarget; mode?: CardPreviewMode }>).detail;
      if (detail?.target?.kind !== 'plan' || detail.target.id !== id) return;
      setPreviewMode(detail.mode || defaultMode);
      setPreviewOpen(true);
    };
    const compose = (event: Event) => {
      const detail = (event as CustomEvent<{ target?: RemixTarget }>).detail;
      if (detail?.target?.kind === 'plan' && detail.target.id === id) setCompositionOpen(true);
    };
    const connect = (event: Event) => {
      const detail = (event as CustomEvent<{ target?: RemixTarget }>).detail;
      if (detail?.target?.kind !== 'plan' || detail.target.id !== id) return;
      let selectedCards: string[] = [];
      try { selectedCards = JSON.parse(getProjectItem('lma_selected_cards') || '[]') as string[]; } catch { selectedCards = []; }
      const next = selectedCards.length ? selectedCards : connections.length ? connections : [`source-${Date.now().toString(36)}`];
      setConnections(Array.from(new Set(next)));
    };
    const detach = (event: Event) => {
      const detail = (event as CustomEvent<{ target?: RemixTarget }>).detail;
      if (detail?.target?.kind === 'plan' && detail.target.id === id) setConnections([]);
    };
    const show = (event: Event) => {
      const detail = (event as CustomEvent<{ target?: RemixTarget }>).detail;
      if (detail?.target?.kind !== 'plan' || detail.target.id !== id) return;
      window.dispatchEvent(new CustomEvent('lma-toast-info', { detail: { message: connections.length ? `${connections.length} carte${connections.length > 1 ? 's' : ''} reliée${connections.length > 1 ? 's' : ''}.` : 'Aucune carte reliée.' } }));
    };
    window.addEventListener('lma-plan-preview', preview as EventListener);
    window.addEventListener('lma-plan-compose', compose as EventListener);
    window.addEventListener('lma-plan-connect', connect as EventListener);
    window.addEventListener('lma-plan-detach', detach as EventListener);
    window.addEventListener('lma-plan-show-connections', show as EventListener);
    return () => {
      window.removeEventListener('lma-plan-preview', preview as EventListener);
      window.removeEventListener('lma-plan-compose', compose as EventListener);
      window.removeEventListener('lma-plan-connect', connect as EventListener);
      window.removeEventListener('lma-plan-detach', detach as EventListener);
      window.removeEventListener('lma-plan-show-connections', show as EventListener);
    };
  }, [connections, defaultMode, id]);

  useEffect(() => {
    const current = readRecord<CardCompositionSettings>('lma_v98_plan_compositions');
    setProjectItem('lma_v98_plan_compositions', JSON.stringify({ ...current, [id]: composition }));
  }, [composition, id]);
  useEffect(() => {
    const current = readRecord<string[]>('lma_v98_plan_connections');
    setProjectItem('lma_v98_plan_connections', JSON.stringify({ ...current, [id]: connections }));
  }, [connections, id]);

  const startDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    event.stopPropagation();
    setLocalSelected(true);
    if (locked || activeTool !== 'select' || !onPositionChange) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = { pointerId: event.pointerId, clientX: event.clientX, clientY: event.clientY, origin: position };
  };
  const moveDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId || !onPositionChange) return;
    const scale = Math.max(.12, canvasScale || 1);
    onPositionChange({ x: drag.origin.x + (event.clientX - drag.clientX) / scale, y: drag.origin.y + (event.clientY - drag.clientY) / scale });
  };
  const endDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (dragRef.current?.pointerId !== event.pointerId) return;
    dragRef.current = null;
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch { /* noop */ }
  };

  const readiness = useMemo(() => {
    let selectedCards: string[] = [];
    try { selectedCards = JSON.parse(getProjectItem('lma_selected_cards') || '[]') as string[]; } catch { selectedCards = []; }
    return Math.min(100, Math.round(((connections.length || selectedCards.length) / 7) * 100));
  }, [connections.length]);

  const applyComposition = (settings: CardCompositionSettings) => {
    setComposition(settings);
    const nextSize = settings.preset === 'visual-background' ? { width: 1180, height: 720 }
      : settings.preset === 'split-left' || settings.preset === 'split-right' ? { width: 1100, height: 640 }
      : settings.preset === 'slider' || settings.preset === 'horizontal-cards' ? { width: 1240, height: 620 }
      : settings.preset === 'gallery' ? { width: 1120, height: 760 }
      : { width: 980, height: 680 };
    onSizeChange?.(nextSize);
  };

  return (
    <>
      <div
        ref={rootRef}
        data-canvas-object
        onClick={(event) => { event.stopPropagation(); setLocalSelected(true); }}
        style={{ position: 'absolute', left: position.x, top: position.y, width: 260, height: 360, borderRadius: 24, outline: isSelected ? '2px solid #D4D4D8' : '1px solid transparent', outlineOffset: 5, zIndex, transition: dragRef.current ? 'none' : 'left .18s ease,top .18s ease,outline-color .15s' }}
      >
        <div onPointerDown={startDrag} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag} title={locked ? `${title} verrouillée` : `Déplacer ${title}`} style={{ position: 'absolute', top: -30, left: '50%', transform: 'translateX(-50%)', height: 22, minWidth: 56, padding: '0 9px', borderRadius: 999, background: isSelected ? '#1B1B1D' : 'rgba(23,21,32,.72)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, fontFamily: 'Inter', fontSize: 8, fontWeight: 750, cursor: locked ? 'not-allowed' : 'grab', touchAction: 'none', boxShadow: '0 7px 20px rgba(0,0,0,.22)', opacity: isSelected ? 1 : .56 }}><GripHorizontal size={12} />{isSelected ? title : ''}</div>

        <ProjectionCard type={id} linkedCount={connections.length} readiness={readiness} coverVariant={composition.preset === 'visual-background' ? 'immersive' : composition.preset === 'editorial' ? 'editorial' : 'original'} onOpenPreview={() => { setPreviewMode(defaultMode); setPreviewOpen(true); }} />

        {isSelected && <div onPointerDown={(event) => event.stopPropagation()} style={{ position: 'absolute', top: -39, right: 0, display: 'flex', alignItems: 'center', gap: 2, padding: 5, borderRadius: 11, background: '#1B1B1D', color: '#fff', boxShadow: '0 10px 28px rgba(0,0,0,.3)' }}><Control title="Aperçu vivant" onClick={() => { setPreviewMode(defaultMode); setPreviewOpen(true); }}><Eye size={12} /></Control><Control title="Mise en page" onClick={() => setCompositionOpen(true)}><LayoutTemplate size={12} /></Control>{onOpenMenu && <button type="button" title="Remix, éditer, relier, publier et gérer" onClick={(event) => { event.stopPropagation(); onOpenMenu(event); }} style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><MoreHorizontal size={14} /></button>}</div>}
      </div>

      <CardPreviewPanel open={previewOpen} target={target} mode={previewMode} linkedCount={connections.length} onModeChange={setPreviewMode} onCompose={() => setCompositionOpen(true)} onClose={() => setPreviewOpen(false)}>{children}</CardPreviewPanel>
      <CardCompositionPanel open={compositionOpen} target={target} selectedCount={connections.length} initial={composition} onApply={applyComposition} onUseSelectedCards={() => window.dispatchEvent(new CustomEvent('lma-plan-connect', { detail: { target } }))} onClose={() => setCompositionOpen(false)} preview={(settings) => <PlanCompositionPreview title={title} subtitle={subtitle} settings={settings} />}/>
    </>
  );
};

const PlanCompositionPreview: React.FC<{ title: string; subtitle: string; settings: CardCompositionSettings }> = ({ title, subtitle, settings }) => {
  const visual = <div style={{ minHeight: 230, borderRadius: 22, background: settings.mediaUrl ? `center/cover url(${settings.mediaUrl})` : `linear-gradient(145deg,${settings.accentColor},#2A2A2D)` }} />;
  const text = <div><div style={{ fontSize: 8, letterSpacing: '.14em', textTransform: 'uppercase', opacity: .48 }}>Carte de projection</div>{settings.titleVisible && <h1 style={{ margin: '14px 0 0', fontSize: 46, lineHeight: .92, letterSpacing: '-.06em' }}>{title}</h1>}{settings.introVisible && <p style={{ margin: '17px 0 0', fontSize: 11, lineHeight: 1.6, opacity: .58 }}>{subtitle}</p>}<div style={{ marginTop: 22 }}><span style={{ display: 'inline-flex', minHeight: 36, alignItems: 'center', padding: '0 14px', borderRadius: 999, background: settings.accentColor, color: '#171719', fontSize: 9, fontWeight: 780 }}>{settings.primaryAction || 'Découvrir'}</span></div></div>;
  const split = settings.preset === 'split-left' || settings.preset === 'split-right';
  return <div style={{ minHeight: '100%', padding: 34, boxSizing: 'border-box', background: settings.background, color: settings.textColor }}>{settings.preset === 'visual-background' ? <div style={{ minHeight: 470, borderRadius: 24, padding: 34, boxSizing: 'border-box', display: 'flex', alignItems: 'flex-end', background: settings.mediaUrl ? `center/cover url(${settings.mediaUrl})` : `linear-gradient(145deg,${settings.accentColor},${settings.background})`, color: '#fff' }}>{text}</div> : split ? <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, alignItems: 'center' }}>{settings.preset === 'split-left' ? <>{visual}{text}</> : <>{text}{visual}</>}</div> : <div style={{ maxWidth: 800, margin: '0 auto' }}>{text}<div style={{ marginTop: 30 }}>{visual}</div></div>}</div>;
};

const Control: React.FC<{ title: string; onClick: () => void; children: React.ReactNode }> = ({ title, onClick, children }) => <button type="button" title={title} onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onClick(); }} style={{ width: 27, height: 27, border: 0, borderRadius: 8, background: 'transparent', color: '#fff', cursor: 'pointer', display: 'grid', placeItems: 'center' }}>{children}</button>;
