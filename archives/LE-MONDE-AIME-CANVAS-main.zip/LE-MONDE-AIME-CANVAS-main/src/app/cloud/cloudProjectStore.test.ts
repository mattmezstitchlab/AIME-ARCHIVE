import { describe, expect, it } from 'vitest';
import { classifyCloudSyncState } from './cloudProjectStore';

describe('classifyCloudSyncState', () => {
  it('identifie un projet uniquement local', () => {
    expect(classifyCloudSyncState(0, 0)).toBe('local-only');
  });

  it('identifie une version cloud à charger sur un nouvel appareil', () => {
    expect(classifyCloudSyncState(0, 42, false)).toBe('cloud-newer');
  });

  it('refuse un écrasement silencieux si le local a déjà changé', () => {
    expect(classifyCloudSyncState(0, 42, true)).toBe('conflict');
    expect(classifyCloudSyncState(41, 42, true)).toBe('conflict');
  });

  it('distingue une version locale plus récente', () => {
    expect(classifyCloudSyncState(43, 42)).toBe('local-newer');
  });

  it('confirme une synchronisation identique', () => {
    expect(classifyCloudSyncState(42, 42)).toBe('synchronized');
    expect(classifyCloudSyncState(42, 42, true)).toBe('local-newer');
  });
});
