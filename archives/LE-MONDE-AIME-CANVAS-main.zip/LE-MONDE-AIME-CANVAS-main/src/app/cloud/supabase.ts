import { createClient, type SupabaseClient } from '@supabase/supabase-js';

export interface RuntimeCloudDiagnostic {
  source: 'build' | 'runtime' | 'none';
  urlPresent: boolean;
  keyPresent: boolean;
  urlValid: boolean;
  keyLength: number;
  environment?: string;
  openaiConfigured?: boolean;
  urlSource?: string;
  keySource?: string;
  error?: string;
}

const rawBuildUrl = String(import.meta.env.VITE_SUPABASE_URL || '').trim();
const rawBuildPublishableKey = String(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

function normalizeSupabaseUrl(value: string): string {
  if (!value) return '';
  const withoutQuotes = value.replace(/^['"]|['"]$/g, '').trim().replace(/\/+$/, '');
  try {
    const parsed = new URL(withoutQuotes);
    return parsed.protocol === 'https:' && parsed.hostname.endsWith('.supabase.co') ? parsed.toString().replace(/\/$/, '') : '';
  } catch {
    return '';
  }
}

function cleanKey(value: string) {
  return value.replace(/^['"]|['"]$/g, '').trim();
}

function createSupabaseClient(url: string, publishableKey: string): SupabaseClient | null {
  if (!url || publishableKey.length < 20) return null;
  try {
    return createClient(url, publishableKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
      realtime: { params: { eventsPerSecond: 8 } },
    });
  } catch (error) {
    console.error('[LMA] Supabase initialization failed', error);
    return null;
  }
}

const buildUrl = normalizeSupabaseUrl(rawBuildUrl);
const buildKey = cleanKey(rawBuildPublishableKey);
const buildClient = createSupabaseClient(buildUrl, buildKey);

export let supabase: SupabaseClient | null = buildClient;
export let isSupabaseConfigured = Boolean(buildClient);
export let supabaseConfigurationError = !rawBuildUrl || !rawBuildPublishableKey
  ? ''
  : !buildUrl
    ? 'VITE_SUPABASE_URL est invalide.'
    : buildKey.length < 20
      ? 'VITE_SUPABASE_PUBLISHABLE_KEY est absente ou invalide.'
      : buildClient
        ? ''
        : 'Le client Supabase n’a pas pu être initialisé.';

export let cloudDiagnostic: RuntimeCloudDiagnostic = {
  source: buildClient ? 'build' : 'none',
  urlPresent: Boolean(rawBuildUrl),
  keyPresent: Boolean(rawBuildPublishableKey),
  urlValid: Boolean(buildUrl),
  keyLength: buildKey.length,
  urlSource: rawBuildUrl ? 'VITE_SUPABASE_URL' : 'missing',
  keySource: rawBuildPublishableKey ? 'VITE_SUPABASE_PUBLISHABLE_KEY' : 'missing',
  error: supabaseConfigurationError || undefined,
};

let runtimePromise: Promise<SupabaseClient | null> | null = null;
let runtimeChecked = false;

export async function ensureSupabaseClient(): Promise<SupabaseClient | null> {
  if (runtimeChecked) return supabase;
  if (runtimePromise) return runtimePromise;

  runtimePromise = fetch('/api/public-config', { cache: 'no-store' })
    .then(async (response) => {
      if (!response.ok) throw new Error(`Configuration runtime indisponible (${response.status}).`);
      return response.json() as Promise<{
        supabaseUrl?: string;
        supabasePublishableKey?: string;
        supabaseConfigured?: boolean;
        openaiConfigured?: boolean;
        environment?: string;
        urlSource?: string;
        keySource?: string;
      }>;
    })
    .then((config) => {
      runtimeChecked = true;
      const runtimeUrl = normalizeSupabaseUrl(String(config.supabaseUrl || ''));
      const runtimeKey = cleanKey(String(config.supabasePublishableKey || ''));
      const runtimeClient = createSupabaseClient(runtimeUrl, runtimeKey);

      if (runtimeClient) {
        // The runtime configuration is authoritative: a Vercel Marketplace resource can
        // replace an older VITE_* build value without another code change.
        supabase = runtimeClient;
        isSupabaseConfigured = true;
        supabaseConfigurationError = '';
        cloudDiagnostic = {
          source: 'runtime',
          urlPresent: true,
          keyPresent: true,
          urlValid: true,
          keyLength: runtimeKey.length,
          environment: config.environment,
          openaiConfigured: config.openaiConfigured,
          urlSource: config.urlSource || 'runtime',
          keySource: config.keySource || 'runtime',
        };
        return runtimeClient;
      }

      if (buildClient) {
        supabase = buildClient;
        isSupabaseConfigured = true;
        supabaseConfigurationError = '';
        cloudDiagnostic = {
          source: 'build',
          urlPresent: Boolean(rawBuildUrl),
          keyPresent: Boolean(rawBuildPublishableKey),
          urlValid: Boolean(buildUrl),
          keyLength: buildKey.length,
          environment: config.environment,
          openaiConfigured: config.openaiConfigured,
          urlSource: 'VITE_SUPABASE_URL',
          keySource: 'VITE_SUPABASE_PUBLISHABLE_KEY',
        };
        return buildClient;
      }

      const error = !config.supabaseUrl
        ? 'Aucune URL Supabase n’est reliée à ce déploiement Vercel.'
        : !config.supabasePublishableKey
          ? 'Aucune Publishable key Supabase n’est reliée à ce déploiement Vercel.'
          : !runtimeUrl
            ? 'La valeur Supabase reçue par Vercel n’est pas une URL valide.'
            : runtimeKey.length < 20
              ? 'La Publishable key Supabase est trop courte ou invalide.'
              : 'Le client Supabase n’a pas pu être créé.';

      supabase = null;
      isSupabaseConfigured = false;
      supabaseConfigurationError = error;
      cloudDiagnostic = {
        source: 'none',
        urlPresent: Boolean(config.supabaseUrl),
        keyPresent: Boolean(config.supabasePublishableKey),
        urlValid: Boolean(runtimeUrl),
        keyLength: runtimeKey.length,
        environment: config.environment,
        openaiConfigured: config.openaiConfigured,
        urlSource: config.urlSource || 'missing',
        keySource: config.keySource || 'missing',
        error,
      };
      return null;
    })
    .catch((error) => {
      runtimeChecked = true;
      if (buildClient) {
        supabase = buildClient;
        isSupabaseConfigured = true;
        supabaseConfigurationError = '';
        cloudDiagnostic = {
          source: 'build',
          urlPresent: Boolean(rawBuildUrl),
          keyPresent: Boolean(rawBuildPublishableKey),
          urlValid: Boolean(buildUrl),
          keyLength: buildKey.length,
          urlSource: 'VITE_SUPABASE_URL',
          keySource: 'VITE_SUPABASE_PUBLISHABLE_KEY',
        };
        return buildClient;
      }
      cloudDiagnostic = {
        ...cloudDiagnostic,
        source: 'none',
        error: error instanceof Error ? error.message : 'Diagnostic cloud impossible.',
      };
      supabaseConfigurationError = cloudDiagnostic.error || '';
      return null;
    })
    .finally(() => {
      runtimePromise = null;
    });

  return runtimePromise;
}

export function getCloudDiagnostic(): RuntimeCloudDiagnostic {
  return { ...cloudDiagnostic };
}

export function getCloudModeLabel() {
  return supabase
    ? 'Cloud disponible'
    : supabaseConfigurationError
      ? 'Cloud à vérifier'
      : 'Mode local';
}
