import type { User } from '@supabase/supabase-js';
import type { StudioProjectMeta } from '../utils/projectStore';
import {
  collectProjectSnapshot,
  getProjectItem,
  getProjects,
  removeProjectItem,
  setProjectItem,
  updateProject,
} from '../utils/projectStore';
import { ensureSupabaseClient, supabase } from './supabase';

export type CloudRole = 'owner' | 'editor' | 'commenter' | 'viewer';
export type CloudSyncStatus = 'local-only' | 'synchronized' | 'local-newer' | 'cloud-newer' | 'conflict';

export interface CloudMember {
  id: string;
  project_id: string;
  user_id: string | null;
  email: string;
  role: CloudRole;
  created_at: string;
}

export interface CloudSnapshot {
  project_id: string;
  data: Record<string, string>;
  version: number;
  updated_at: string;
  updated_by: string | null;
}

export interface CloudProjectSummary {
  id: string;
  owner_id: string;
  name: string;
  universe: StudioProjectMeta['universe'];
  status: StudioProjectMeta['status'];
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface CloudSyncState {
  status: CloudSyncStatus;
  localVersion: number;
  remoteVersion: number;
  remoteUpdatedAt?: string;
}

export interface CloudSyncResult {
  version: number;
  created: boolean;
  forced: boolean;
}

const CLOUD_VERSION_KEY = 'lma_cloud_version';

export class CloudConflictError extends Error {
  readonly localVersion: number;
  readonly remoteVersion: number;

  constructor(localVersion: number, remoteVersion: number) {
    super('Une version plus récente existe dans le cloud. Chargez-la ou confirmez l’écrasement.');
    this.name = 'CloudConflictError';
    this.localVersion = localVersion;
    this.remoteVersion = remoteVersion;
  }
}

async function requireCloud() {
  const client = supabase || await ensureSupabaseClient();
  if (!client) throw new Error('Le cloud Supabase n’est pas configuré.');
  return client;
}

function localCloudVersion(projectId: string) {
  const value = Number(getProjectItem(CLOUD_VERSION_KEY, projectId) || 0);
  return Number.isFinite(value) && value > 0 ? value : 0;
}

function readableCloudError(error: unknown) {
  const candidate = error as { message?: string; code?: string; details?: string; hint?: string };
  const message = candidate?.message || 'Opération cloud impossible.';
  if (/relation .* does not exist/i.test(message) || candidate?.code === '42P01') {
    return new Error('Les tables cloud ne sont pas encore installées dans Supabase. Exécutez la migration V9.3.');
  }
  if (/row-level security/i.test(message) || candidate?.code === '42501') {
    return new Error('Supabase a refusé cette action. Vérifiez la connexion du compte et les politiques RLS.');
  }
  return error instanceof Error ? error : new Error(message);
}

export function classifyCloudSyncState(localVersion: number, remoteVersion: number, hasLocalChanges = false): CloudSyncStatus {
  if (!remoteVersion) return 'local-only';
  if (!localVersion) return hasLocalChanges ? 'conflict' : 'cloud-newer';
  if (localVersion === remoteVersion) return hasLocalChanges ? 'local-newer' : 'synchronized';
  return remoteVersion > localVersion ? (hasLocalChanges ? 'conflict' : 'cloud-newer') : 'local-newer';
}

export async function getCloudSyncState(projectId: string, hasLocalChanges = false): Promise<CloudSyncState> {
  const snapshot = await fetchCloudSnapshot(projectId);
  const localVersion = localCloudVersion(projectId);
  const remoteVersion = Number(snapshot?.version || 0);
  return {
    status: classifyCloudSyncState(localVersion, remoteVersion, hasLocalChanges),
    localVersion,
    remoteVersion,
    remoteUpdatedAt: snapshot?.updated_at,
  };
}

export async function syncProjectToCloud(
  project: StudioProjectMeta,
  snapshot: Record<string, string>,
  user: User,
  options: { force?: boolean } = {},
): Promise<CloudSyncResult> {
  const client = await requireCloud();
  try {
    const { data: existing, error: existingError } = await client
      .from('projects')
      .select('id, owner_id')
      .eq('id', project.id)
      .maybeSingle();
    if (existingError) throw existingError;

    const { data: remoteSnapshot, error: remoteError } = await client
      .from('project_snapshots')
      .select('version, updated_at')
      .eq('project_id', project.id)
      .maybeSingle();
    if (remoteError) throw remoteError;

    const localVersion = localCloudVersion(project.id);
    const remoteVersion = Number(remoteSnapshot?.version || 0);
    if (remoteVersion && remoteVersion !== localVersion && !options.force) {
      throw new CloudConflictError(localVersion, remoteVersion);
    }

    if (!existing) {
      const { error } = await client.from('projects').insert({
        id: project.id,
        owner_id: user.id,
        name: project.name,
        universe: project.universe,
        status: project.status,
        metadata: { accent: project.accent, favorite: project.favorite },
      });
      if (error) throw error;
    } else {
      const { error } = await client.from('projects').update({
        name: project.name,
        universe: project.universe,
        status: project.status,
        metadata: { accent: project.accent, favorite: project.favorite },
        updated_at: new Date().toISOString(),
      }).eq('id', project.id);
      if (error) throw error;
    }

    const version = Math.max(Date.now(), remoteVersion + 1);
    const { error: snapshotError } = await client.from('project_snapshots').upsert({
      project_id: project.id,
      data: snapshot,
      updated_by: user.id,
      version,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'project_id' });
    if (snapshotError) throw snapshotError;

    setProjectItem(CLOUD_VERSION_KEY, String(version), project.id);
    return { version, created: !existing, forced: Boolean(options.force) };
  } catch (error) {
    if (error instanceof CloudConflictError) throw error;
    throw readableCloudError(error);
  }
}

export async function fetchCloudSnapshot(projectId: string): Promise<CloudSnapshot | null> {
  const client = await requireCloud();
  try {
    const { data, error } = await client
      .from('project_snapshots')
      .select('*')
      .eq('project_id', projectId)
      .maybeSingle();
    if (error) throw error;
    return data as CloudSnapshot | null;
  } catch (error) {
    throw readableCloudError(error);
  }
}

export async function applyCloudSnapshot(projectId: string, snapshot: CloudSnapshot) {
  const current = collectProjectSnapshot(projectId);
  for (const key of Object.keys(current)) removeProjectItem(key, projectId);
  for (const [key, value] of Object.entries(snapshot.data || {})) {
    if (typeof value === 'string') setProjectItem(key, value, projectId);
  }
  setProjectItem(CLOUD_VERSION_KEY, String(Number(snapshot.version || 0)), projectId);
  updateProject(projectId, { openedAt: new Date().toISOString() });
  window.dispatchEvent(new CustomEvent('lma:cloud-snapshot-applied', {
    detail: { projectId, version: snapshot.version },
  }));
}

export async function listCloudProjects(): Promise<CloudProjectSummary[]> {
  const client = await requireCloud();
  try {
    const { data, error } = await client
      .from('projects')
      .select('id, owner_id, name, universe, status, metadata, created_at, updated_at')
      .order('updated_at', { ascending: false });
    if (error) throw error;
    return (data || []) as CloudProjectSummary[];
  } catch (error) {
    throw readableCloudError(error);
  }
}

export async function listProjectMembers(projectId: string): Promise<CloudMember[]> {
  const client = await requireCloud();
  try {
    const { data, error } = await client
      .from('project_members')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return (data || []) as CloudMember[];
  } catch (error) {
    throw readableCloudError(error);
  }
}

export async function inviteProjectMember(projectId: string, email: string, role: Exclude<CloudRole, 'owner'>): Promise<void> {
  const client = await requireCloud();
  const normalizedEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) throw new Error('Adresse e-mail invalide.');
  try {
    const { error } = await client.from('project_members').upsert({
      project_id: projectId,
      email: normalizedEmail,
      role,
    }, { onConflict: 'project_id,email' });
    if (error) throw error;
  } catch (error) {
    throw readableCloudError(error);
  }
}

export async function removeProjectMember(memberId: string): Promise<void> {
  const client = await requireCloud();
  try {
    const { error } = await client.from('project_members').delete().eq('id', memberId);
    if (error) throw error;
  } catch (error) {
    throw readableCloudError(error);
  }
}

export function subscribeToCloudProject(projectId: string, onChange: (snapshot: CloudSnapshot) => void) {
  let disposed = false;
  let channel: ReturnType<NonNullable<typeof supabase>['channel']> | null = null;

  void requireCloud().then((client) => {
    if (disposed) return;
    channel = client
      .channel(`project:${projectId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'project_snapshots',
        filter: `project_id=eq.${projectId}`,
      }, (payload) => {
        const next = payload.new as CloudSnapshot;
        if (next?.project_id) onChange(next);
      })
      .subscribe();
  }).catch(() => undefined);

  return () => {
    disposed = true;
    if (channel) void (supabase || undefined)?.removeChannel(channel);
  };
}

export function currentProject(projectId: string): StudioProjectMeta | null {
  return getProjects().find((item) => item.id === projectId) || null;
}
