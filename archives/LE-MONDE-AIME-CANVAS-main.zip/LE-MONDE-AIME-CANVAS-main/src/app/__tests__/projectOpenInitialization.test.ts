import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('project editor initialization order', () => {
  it('declares agent actions after the callbacks used by its dependency list', () => {
    const source = readFileSync('src/app/App.tsx', 'utf8');
    const agent = source.indexOf('const handleAgentAction = useCallback');
    const fit = source.indexOf('const fitWorkspacePlacements = useCallback');
    const close = source.indexOf('const closeWorkspacePanels = useCallback');
    const open = source.indexOf('const openWorkspacePanel = useCallback');

    expect(agent).toBeGreaterThan(0);
    expect(agent).toBeGreaterThan(fit);
    expect(agent).toBeGreaterThan(close);
    expect(agent).toBeGreaterThan(open);
  });

  it('uses the canonical rainbow mark in project identity surfaces', () => {
    const app = readFileSync('src/app/App.tsx', 'utf8');
    const dashboard = readFileSync('src/app/components/ProjectDashboard.tsx', 'utf8');
    const creation = readFileSync('src/app/components/ProjectCreationDialog.tsx', 'utf8');

    expect(app).toContain('<AimeRainbowMark size={18} />');
    expect(dashboard).toContain('<AimeRainbowMark size={30} />');
    expect(creation).toContain('<AimeRainbowMark size={38} />');
  });
});
