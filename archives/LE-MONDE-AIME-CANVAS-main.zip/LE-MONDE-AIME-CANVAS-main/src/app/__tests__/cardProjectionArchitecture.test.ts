import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('V9.8 card-first projection architecture', () => {
  it('renders timeline and mini-site as compact projection cards', () => {
    const source = readFileSync('src/app/components/CanvasPlane.tsx', 'utf8');

    expect(source).toContain('<ProjectionCard');
    expect(source).toContain('width: 260');
    expect(source).toContain('height: 360');
    expect(source).toContain('<CardPreviewPanel');
    expect(source).toContain('<CardCompositionPanel');
    expect(source).not.toContain('plan du projet');
  });

  it('centralizes card actions in the ellipsis menu', () => {
    const source = readFileSync('src/app/components/RemixProtocolMenu.tsx', 'utf8');

    for (const label of ['Aperçu', 'Mise en page', 'Remix', 'Éditer', 'Relier', 'Publier', 'Exporter', 'Gérer']) {
      expect(source).toContain(`label=\"${label}\"`);
    }
    expect(source).toContain('<CardProjectionRuntime />');
    expect(source).toContain("'lma-card-preview'");
    expect(source).toContain("'lma-plan-preview'");
  });

  it('keeps the live composition controls together', () => {
    const source = readFileSync('src/app/components/CardCompositionPanel.tsx', 'utf8');

    for (const label of ['Composition', 'Visuels', 'Couleurs', 'Texte', 'Boutons']) {
      expect(source).toContain(`label: '${label}'`);
    }
    expect(source).toContain('aperçu en direct');
    expect(source).toContain('Magnétiser les');
  });

  it('describes timeline and mini-site as projection cards in navigation', () => {
    const source = readFileSync('src/app/components/WorkspaceSidebar.tsx', 'utf8');

    expect(source).toContain('Carte de projection · aperçu');
    expect(source).toContain('Les cartes sont la source');
    expect(source).toContain("window.dispatchEvent(new CustomEvent('lma-plan-preview'");
  });
});
