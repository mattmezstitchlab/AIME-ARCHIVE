import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('V9.8.1 studio toolbar cleanup', () => {
  it('keeps creation actions visible and moves global configuration to the secondary menu', () => {
    const source = readFileSync('src/app/components/Toolbar.tsx', 'utf8');

    expect(source).toContain("label: 'Ajouter une carte ou un élément'");
    expect(source).toContain("label: 'Médias du projet'");
    expect(source).toContain('Style global');
    expect(source).toContain('Organiser le canevas');
    expect(source).toContain('Aperçu global sans interface');
    expect(source).not.toContain("{ id: 'style', icon:");
    expect(source).not.toContain("{ id: 'organize', icon:");
  });
});
