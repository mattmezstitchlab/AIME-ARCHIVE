import type { ProjectUniverse } from '../utils/projectStore';

export interface DomainModule {
  id: ProjectUniverse;
  label: string;
  mission: string;
  primaryRole: string;
  essentialData: string[];
  agentCapabilities: string[];
  outputs: string[];
  maturity: 'operational' | 'beta' | 'lab';
}

export const DOMAIN_MODULES: Record<ProjectUniverse, DomainModule> = {
  mariage: {
    id: 'mariage',
    label: 'Mariage',
    mission: 'Organiser, publier et piloter un mariage depuis une donnée commune.',
    primaryRole: 'Couple / Wedding planner',
    essentialData: ['couple', 'date', 'lieux', 'invités', 'prestataires', 'moments', 'budget', 'médias'],
    agentCapabilities: ['diagnostiquer la préparation', 'relier les cartes', 'proposer des temps tampons', 'préparer la publication', 'piloter le Jour J'],
    outputs: ['Control Room', 'Timeline', 'Mini-site', 'RSVP', 'Jour J Live', 'PDF'],
    maturity: 'operational',
  },
  prestataire: {
    id: 'prestataire',
    label: 'Prestataire',
    mission: 'Présenter une activité et transformer une demande en réservation suivie.',
    primaryRole: 'Professionnel / Artiste / Lieu',
    essentialData: ['identité', 'offres', 'disponibilités', 'médias', 'tarifs', 'documents', 'paiements'],
    agentCapabilities: ['construire le profil', 'qualifier une demande', 'préparer une offre', 'organiser les documents'],
    outputs: ['Profil public', 'Formulaire', 'Devis', 'Espace client'],
    maturity: 'beta',
  },
  association: {
    id: 'association',
    label: 'Association',
    mission: 'Relier membres, missions, ressources et événements dans un registre vivant.',
    primaryRole: 'Association / Collectif',
    essentialData: ['membres', 'missions', 'ressources', 'besoins', 'événements', 'preuves'],
    agentCapabilities: ['cartographier les besoins', 'relier les ressources', 'préparer une action', 'documenter les impacts'],
    outputs: ['Registre', 'Carte', 'Agenda', 'Page publique'],
    maturity: 'beta',
  },
  evenement: {
    id: 'evenement',
    label: 'Événement',
    mission: 'Orchestrer une équipe, un programme, un public et une publication.',
    primaryRole: 'Organisateur',
    essentialData: ['programme', 'équipe', 'lieu', 'public', 'billetterie', 'médias'],
    agentCapabilities: ['construire le déroulé', 'détecter les conflits', 'préparer les communications'],
    outputs: ['Timeline', 'Landing', 'Agenda', 'Mode live'],
    maturity: 'beta',
  },
  portfolio: {
    id: 'portfolio',
    label: 'Portfolio',
    mission: 'Transformer une trajectoire créative en récit, œuvres et opportunités.',
    primaryRole: 'Artiste / Créatif',
    essentialData: ['identité', 'projets', 'médias', 'récit', 'contacts'],
    agentCapabilities: ['curater les projets', 'proposer un récit', 'générer des variantes éditoriales'],
    outputs: ['Portfolio', 'Dossier', 'Présentation'],
    maturity: 'beta',
  },
  site: {
    id: 'site',
    label: 'Site universel',
    mission: 'Composer une présence web à partir de sections, données et composants.',
    primaryRole: 'Créateur de projet',
    essentialData: ['pages', 'sections', 'contenus', 'médias', 'navigation', 'SEO'],
    agentCapabilities: ['proposer une structure', 'créer des Covers', 'préparer le responsive'],
    outputs: ['Site', 'Présentation', 'PDF'],
    maturity: 'beta',
  },
  libre: {
    id: 'libre',
    label: 'Point Zéro',
    mission: 'Importer, auditer ou inventer un format sans imposer un domaine.',
    primaryRole: 'Projet libre',
    essentialData: ['intention', 'sources', 'artefacts', 'relations', 'preuves'],
    agentCapabilities: ['clarifier l’intention', 'importer une source', 'proposer un schéma', 'conserver la provenance'],
    outputs: ['Canvas', 'Audit', 'Registre', 'Prototype'],
    maturity: 'lab',
  },
};

export function getDomainModule(universe: ProjectUniverse): DomainModule {
  return DOMAIN_MODULES[universe] || DOMAIN_MODULES.libre;
}

export function buildAgentDomainContext(universe: ProjectUniverse) {
  const module = getDomainModule(universe);
  return {
    id: module.id,
    label: module.label,
    mission: module.mission,
    primaryRole: module.primaryRole,
    essentialData: module.essentialData,
    capabilities: module.agentCapabilities,
    outputs: module.outputs,
    maturity: module.maturity,
  };
}
