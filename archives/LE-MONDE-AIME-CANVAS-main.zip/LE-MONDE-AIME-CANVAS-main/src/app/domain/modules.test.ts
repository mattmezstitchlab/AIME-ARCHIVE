import { describe, expect, it } from 'vitest';
import { buildAgentDomainContext, DOMAIN_MODULES, getDomainModule } from './modules';

describe('domain modules', () => {
  it('keeps wedding operational and other universes explicit', () => {
    expect(DOMAIN_MODULES.mariage.maturity).toBe('operational');
    expect(DOMAIN_MODULES.prestataire.outputs).toContain('Profil public');
    expect(DOMAIN_MODULES.libre.maturity).toBe('lab');
  });

  it('builds a constrained context for AIME CORE', () => {
    const context = buildAgentDomainContext('association');
    expect(context.label).toBe('Association');
    expect(context.essentialData).toContain('membres');
    expect(getDomainModule('mariage').outputs).toContain('Jour J Live');
  });
});
