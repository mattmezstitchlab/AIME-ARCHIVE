import type { SetupData } from '../components/UniversalCard';

export interface WeddingProjectData {
  version: 1;
  identity: {
    brideFirstName: string;
    groomFirstName: string;
    date: string;
    ceremonyTime: string;
  };
  venues: {
    ceremony: string;
    reception: string;
    city: string;
  };
  guests: {
    adultsAndChildren: number;
    children: number;
    dietaryRequirements: string[];
  };
  design: {
    style: string;
    colorA: string;
    colorB: string;
  };
  finance: {
    totalBudget: number;
  };
  contacts: {
    witnessA: string;
    witnessB: string;
  };
  publication: {
    heroPhoto: string;
    heroMediaType: 'image' | 'video';
    heroName: string;
    heroDate: string;
    heroVenue: string;
    selectedCardIds: string[];
  };
  updatedAt: string;
}

export type WeddingReadinessGroup = 'foundations' | 'orchestration' | 'publication';
export type WeddingReadinessSeverity = 'complete' | 'attention' | 'blocking';

export interface WeddingReadinessItem {
  id: 'identity' | 'date' | 'venue' | 'guests' | 'budget' | 'style' | 'witnesses' | 'timeline' | 'minisite' | 'visual';
  group: WeddingReadinessGroup;
  label: string;
  complete: boolean;
  blocking: boolean;
  severity: WeddingReadinessSeverity;
  score: number;
  weight: number;
  detail: string;
  actionLabel: string;
  impact: string;
  missing: string[];
}

export const EMPTY_WEDDING_PROJECT: WeddingProjectData = {
  version: 1,
  identity: { brideFirstName: '', groomFirstName: '', date: '', ceremonyTime: '' },
  venues: { ceremony: '', reception: '', city: '' },
  guests: { adultsAndChildren: 0, children: 0, dietaryRequirements: [] },
  design: { style: '', colorA: '#A3A3A8', colorB: '#D4D4D8' },
  finance: { totalBudget: 0 },
  contacts: { witnessA: '', witnessB: '' },
  publication: { heroPhoto: '', heroMediaType: 'image', heroName: '', heroDate: '', heroVenue: '', selectedCardIds: [] },
  updatedAt: new Date(0).toISOString(),
};

export function buildWeddingProjectData(input: {
  setup: SetupData;
  totalBudget: number;
  heroPhoto: string;
  heroMediaType: 'image' | 'video';
  heroName: string;
  heroDate: string;
  heroVenue: string;
  selectedCardIds: string[];
}): WeddingProjectData {
  const { setup } = input;
  return {
    version: 1,
    identity: {
      brideFirstName: setup.brideFirstName,
      groomFirstName: setup.groomFirstName,
      date: setup.date,
      ceremonyTime: setup.ceremonyTime,
    },
    venues: {
      ceremony: setup.ceremonyVenue,
      reception: setup.receptionVenue,
      city: setup.receptionCity,
    },
    guests: {
      adultsAndChildren: setup.guestCount,
      children: setup.childCount,
      dietaryRequirements: [...setup.diet],
    },
    design: {
      style: setup.style,
      colorA: setup.colorA,
      colorB: setup.colorB,
    },
    finance: { totalBudget: input.totalBudget || setup.budget || 0 },
    contacts: { witnessA: setup.witnessA, witnessB: setup.witnessB },
    publication: {
      heroPhoto: input.heroPhoto,
      heroMediaType: input.heroMediaType,
      heroName: input.heroName,
      heroDate: input.heroDate,
      heroVenue: input.heroVenue,
      selectedCardIds: [...input.selectedCardIds],
    },
    updatedAt: new Date().toISOString(),
  };
}

export function setupFromWeddingProject(data: WeddingProjectData): SetupData {
  return {
    brideFirstName: data.identity.brideFirstName,
    groomFirstName: data.identity.groomFirstName,
    date: data.identity.date,
    ceremonyTime: data.identity.ceremonyTime,
    ceremonyVenue: data.venues.ceremony,
    receptionVenue: data.venues.reception,
    receptionCity: data.venues.city,
    guestCount: data.guests.adultsAndChildren,
    childCount: data.guests.children,
    diet: [...data.guests.dietaryRequirements],
    style: data.design.style,
    colorA: data.design.colorA,
    colorB: data.design.colorB,
    budget: data.finance.totalBudget,
    witnessA: data.contacts.witnessA,
    witnessB: data.contacts.witnessB,
  };
}

function readinessItem(input: Omit<WeddingReadinessItem, 'complete' | 'severity'>): WeddingReadinessItem {
  const score = Math.max(0, Math.min(1, input.score));
  const complete = score >= 1;
  return {
    ...input,
    score,
    complete,
    severity: complete ? 'complete' : input.blocking ? 'blocking' : 'attention',
  };
}

function formatWeddingDate(value: string) {
  if (!value) return '';
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
}

export function computeWeddingReadiness(data: WeddingProjectData, cardSettings: Record<string, Record<string, unknown>>): WeddingReadinessItem[] {
  const timelineMoments = Object.values(cardSettings).filter((settings) => typeof settings.time === 'string' && settings.time.trim()).length;
  const identityCount = Number(Boolean(data.identity.brideFirstName)) + Number(Boolean(data.identity.groomFirstName));
  const dateCount = Number(Boolean(data.identity.date)) + Number(Boolean(data.identity.ceremonyTime));
  const venueReady = Boolean(data.venues.ceremony || data.venues.reception);
  const witnessCount = Number(Boolean(data.contacts.witnessA)) + Number(Boolean(data.contacts.witnessB));
  const selectedCards = data.publication.selectedCardIds.length;

  return [
    readinessItem({
      id: 'identity', group: 'foundations', label: 'Identité du couple', blocking: true, score: identityCount / 2, weight: 10,
      detail: identityCount === 2 ? `${data.identity.brideFirstName} & ${data.identity.groomFirstName}` : identityCount ? 'Un prénom sur deux est renseigné' : 'Prénoms à renseigner',
      actionLabel: 'Compléter le couple',
      impact: 'Les noms alimentent le mini-site, les invitations, les documents et tous les écrans du Jour J.',
      missing: [!data.identity.brideFirstName ? 'Prénom de la première personne' : '', !data.identity.groomFirstName ? 'Prénom de la seconde personne' : ''].filter(Boolean),
    }),
    readinessItem({
      id: 'date', group: 'foundations', label: 'Date et heure', blocking: true, score: dateCount / 2, weight: 12,
      detail: data.identity.date ? `${formatWeddingDate(data.identity.date)}${data.identity.ceremonyTime ? ` · ${data.identity.ceremonyTime}` : ''}` : 'Date à définir',
      actionLabel: 'Définir la date',
      impact: 'La date déclenche le rétroplanning, la météo, les disponibilités, les échéances et les rappels.',
      missing: [!data.identity.date ? 'Date du mariage' : '', !data.identity.ceremonyTime ? 'Heure de cérémonie' : ''].filter(Boolean),
    }),
    readinessItem({
      id: 'venue', group: 'foundations', label: 'Lieux', blocking: true, score: (Number(venueReady) + Number(Boolean(data.venues.city))) / 2, weight: 12,
      detail: data.venues.reception || data.venues.ceremony || 'Lieu principal à définir',
      actionLabel: 'Renseigner les lieux',
      impact: 'Les lieux déterminent les trajets, les horaires, la logistique, le plan B et les informations pratiques.',
      missing: [!venueReady ? 'Lieu de cérémonie ou de réception' : '', !data.venues.city ? 'Ville' : ''].filter(Boolean),
    }),
    readinessItem({
      id: 'guests', group: 'foundations', label: 'Invités', blocking: true, score: data.guests.adultsAndChildren > 0 ? 1 : 0, weight: 8,
      detail: data.guests.adultsAndChildren > 0 ? `${data.guests.adultsAndChildren} personne${data.guests.adultsAndChildren > 1 ? 's' : ''} prévues` : 'Nombre d’invités à définir',
      actionLabel: 'Estimer les invités',
      impact: 'Le nombre d’invités dimensionne le lieu, le budget, le traiteur, les transports et les plans de table.',
      missing: data.guests.adultsAndChildren > 0 ? [] : ['Nombre estimé de personnes'],
    }),
    readinessItem({
      id: 'budget', group: 'foundations', label: 'Budget', blocking: true, score: data.finance.totalBudget > 0 ? 1 : 0, weight: 10,
      detail: data.finance.totalBudget > 0 ? new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(data.finance.totalBudget) : 'Enveloppe à définir',
      actionLabel: 'Définir le budget',
      impact: 'Le budget permet d’arbitrer les priorités et d’anticiper acomptes, soldes et dépassements.',
      missing: data.finance.totalBudget > 0 ? [] : ['Enveloppe totale'],
    }),
    readinessItem({
      id: 'style', group: 'foundations', label: 'Direction artistique', blocking: false, score: data.design.style ? 1 : 0, weight: 5,
      detail: data.design.style || 'Ambiance à choisir',
      actionLabel: 'Choisir le style',
      impact: 'Le style harmonise le mini-site, les cartes, les couleurs, les fleurs, la papeterie et les tenues.',
      missing: data.design.style ? [] : ['Style ou ambiance'],
    }),
    readinessItem({
      id: 'witnesses', group: 'orchestration', label: 'Témoins et relais', blocking: false, score: witnessCount / 2, weight: 3,
      detail: witnessCount === 2 ? 'Deux relais renseignés' : witnessCount === 1 ? 'Un relais renseigné' : 'Aucun témoin ou relais renseigné',
      actionLabel: 'Ajouter les relais',
      impact: 'Les relais peuvent recevoir des missions, des alertes, des documents et des surprises dédiées.',
      missing: [!data.contacts.witnessA ? 'Premier témoin ou relais' : '', !data.contacts.witnessB ? 'Second témoin ou relais' : ''].filter(Boolean),
    }),
    readinessItem({
      id: 'timeline', group: 'orchestration', label: 'Timeline du Jour J', blocking: true, score: Math.min(1, timelineMoments / 5), weight: 18,
      detail: timelineMoments ? `${timelineMoments} horaire${timelineMoments > 1 ? 's' : ''} relié${timelineMoments > 1 ? 's' : ''}` : 'Aucun horaire relié',
      actionLabel: 'Construire la timeline',
      impact: 'La timeline devient la source commune des prestataires, proches, déplacements, retards et plans B.',
      missing: timelineMoments >= 5 ? [] : [`${Math.max(0, 5 - timelineMoments)} moment${Math.max(0, 5 - timelineMoments) > 1 ? 's' : ''} essentiel${Math.max(0, 5 - timelineMoments) > 1 ? 's' : ''} à planifier`],
    }),
    readinessItem({
      id: 'minisite', group: 'publication', label: 'Contenus du mini-site', blocking: false, score: Math.min(1, selectedCards / 5), weight: 12,
      detail: selectedCards ? `${selectedCards} carte${selectedCards > 1 ? 's' : ''} connectée${selectedCards > 1 ? 's' : ''}` : 'Aucune carte connectée',
      actionLabel: 'Composer le mini-site',
      impact: 'Les cartes choisies déterminent ce que les invités voient et les informations qu’ils peuvent utiliser.',
      missing: selectedCards >= 5 ? [] : [`Sélectionner encore ${Math.max(0, 5 - selectedCards)} carte${Math.max(0, 5 - selectedCards) > 1 ? 's' : ''}`],
    }),
    readinessItem({
      id: 'visual', group: 'publication', label: 'Visuel principal', blocking: false, score: data.publication.heroPhoto ? 1 : 0, weight: 10,
      detail: data.publication.heroPhoto ? 'Visuel principal prêt' : 'Visuel principal manquant',
      actionLabel: 'Choisir un visuel',
      impact: 'Le visuel principal porte l’identité du projet dans l’accueil, le mini-site, les partages et les aperçus.',
      missing: data.publication.heroPhoto ? [] : ['Photo ou vidéo principale'],
    }),
  ];
}

export function weddingReadinessPercent(items: WeddingReadinessItem[]): number {
  const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
  if (!totalWeight) return 0;
  const score = items.reduce((sum, item) => sum + item.score * item.weight, 0);
  return Math.round((score / totalWeight) * 100);
}

export function nextWeddingAction(items: WeddingReadinessItem[]): WeddingReadinessItem | null {
  return items.find((item) => !item.complete && item.blocking)
    || items.find((item) => !item.complete)
    || null;
}

export function weddingBlockingCount(items: WeddingReadinessItem[]): number {
  return items.filter((item) => !item.complete && item.blocking).length;
}
