import { describe, expect, it } from 'vitest';
import {
  buildWeddingProjectData,
  computeWeddingReadiness,
  EMPTY_WEDDING_PROJECT,
  nextWeddingAction,
  weddingBlockingCount,
  weddingReadinessPercent,
  type WeddingProjectData,
} from './weddingProject';

const setup = {
  brideFirstName: 'Lou',
  groomFirstName: 'Sam',
  date: '2027-06-12',
  ceremonyTime: '15:00',
  ceremonyVenue: 'Mairie',
  receptionVenue: 'Domaine des Étoiles',
  receptionCity: 'Lille',
  guestCount: 90,
  childCount: 12,
  diet: ['Végétarien'],
  style: 'Chic',
  colorA: '#111111',
  colorB: '#EEEEEE',
  budget: 30000,
  witnessA: 'Camille',
  witnessB: 'Alex',
};

function emptyProject(): WeddingProjectData {
  return JSON.parse(JSON.stringify(EMPTY_WEDDING_PROJECT)) as WeddingProjectData;
}

describe('WeddingProjectData', () => {
  it('builds one canonical wedding snapshot', () => {
    const data = buildWeddingProjectData({
      setup,
      totalBudget: 32000,
      heroPhoto: 'https://example.com/photo.jpg',
      heroMediaType: 'image',
      heroName: 'Lou & Sam',
      heroDate: '12 juin 2027',
      heroVenue: 'Domaine des Étoiles',
      selectedCardIds: ['prog-1', 'lieu-1', 'art-1'],
    });

    expect(data.identity.brideFirstName).toBe('Lou');
    expect(data.venues.reception).toBe('Domaine des Étoiles');
    expect(data.finance.totalBudget).toBe(32000);
    expect(data.publication.selectedCardIds).toHaveLength(3);
  });

  it('commence par l’identité et signale les blocages structurants', () => {
    const readiness = computeWeddingReadiness(emptyProject(), {});
    expect(weddingReadinessPercent(readiness)).toBe(0);
    expect(nextWeddingAction(readiness)?.id).toBe('identity');
    expect(weddingBlockingCount(readiness)).toBeGreaterThan(0);
  });

  it('valorise une étape partielle sans la déclarer complète', () => {
    const data = emptyProject();
    data.identity.brideFirstName = 'Sophie';
    const readiness = computeWeddingReadiness(data, {});
    const identity = readiness.find((item) => item.id === 'identity');
    expect(identity?.score).toBe(0.5);
    expect(identity?.complete).toBe(false);
    expect(weddingReadinessPercent(readiness)).toBeGreaterThan(0);
  });

  it('atteint 100 % lorsque les dix fondations sont réellement prêtes', () => {
    const data = buildWeddingProjectData({
      setup,
      totalBudget: 32000,
      heroPhoto: 'https://example.com/photo.jpg',
      heroMediaType: 'image',
      heroName: 'Lou & Sam',
      heroDate: '12 juin 2027',
      heroVenue: 'Domaine des Étoiles',
      selectedCardIds: ['prog-1', 'lieu-1', 'art-1', 'guest-1', 'music-1'],
    });
    const cardSettings = Object.fromEntries(['a', 'b', 'c', 'd', 'e'].map((id, index) => [id, { time: `${10 + index}:00` }]));
    const readiness = computeWeddingReadiness(data, cardSettings);

    expect(weddingReadinessPercent(readiness)).toBe(100);
    expect(nextWeddingAction(readiness)).toBeNull();
    expect(weddingBlockingCount(readiness)).toBe(0);
  });

  it('place la timeline avant les finitions de publication lorsqu’elle bloque', () => {
    const data = buildWeddingProjectData({
      setup,
      totalBudget: 32000,
      heroPhoto: '',
      heroMediaType: 'image',
      heroName: 'Lou & Sam',
      heroDate: '12 juin 2027',
      heroVenue: 'Domaine des Étoiles',
      selectedCardIds: [],
    });
    const readiness = computeWeddingReadiness(data, {});
    expect(nextWeddingAction(readiness)?.id).toBe('timeline');
  });
});
