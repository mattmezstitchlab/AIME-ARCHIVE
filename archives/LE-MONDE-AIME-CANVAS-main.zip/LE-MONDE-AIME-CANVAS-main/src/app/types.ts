export type Tool =
  | 'select'
  | 'hand'
  | 'zoom-in'
  | 'zoom-out'
  | 'note'
  | 'background'
  | 'text';

export type StudioPanelKind = 'add' | 'media' | 'style' | 'organize' | 'publish' | null;

export type CardStatus = 'todo' | 'waiting' | 'confirmed' | 'paid';

export type CardLayoutMode = 'stack' | 'mosaic' | 'horizontal' | 'vertical';
export type WorkspaceLayoutMode = 'mosaic' | 'horizontal' | 'vertical';
export type CanvasObjectKind = 'element' | 'entry' | 'lot' | 'note' | 'plan';


export type CanvasPlanId = 'timeline' | 'minisite';
export type CoverVariant = 'original' | 'editorial' | 'immersive' | 'essential';

export interface RemixTarget {
  kind: CanvasObjectKind;
  id: string;
  label: string;
}

export interface RemixPermissions {
  allowRemixes: boolean;
  allowMashups: boolean;
  allowComments: boolean;
  allowCommercialUse: boolean;
  requireAttribution: boolean;
  shareDesign: boolean;
  shareStructure: boolean;
  keepPrivateData: boolean;
}

export interface RemixHistoryEntry {
  id: string;
  action: 'cover' | 'extend' | 'crop' | 'reverse' | 'inspiration' | 'duplicate';
  target: RemixTarget;
  before: Record<string, unknown>;
  after: Record<string, unknown>;
  createdAt: string;
  label: string;
}

export interface CanvasSelectionSummary {
  kind: CanvasObjectKind;
  id: string;
  label: string;
  locked: boolean;
  hidden: boolean;
  canDuplicate?: boolean;
}

export interface CanvasPoint {
  x: number;
  y: number;
}

export type CardType =
  | 'programme'
  | 'venue'
  | 'photo-video'
  | 'beauty'
  | 'catering'
  | 'flowers'
  | 'artist'
  | 'animation'
  | 'music-ceremony'
  | 'music-soiree'
  | 'guest'
  | 'budget'
  | 'admin'
  | 'honeymoon'
  | 'retroplanning';

export interface WeddingCard {
  id: string;
  name: string;
  subtitle: string;
  image?: string;
  gradient?: string;
  type: CardType;
  icon: string;
}

export interface WeddingLot {
  id: number;
  title: string;
  subtitle: string;
  icon: string;
  accentColor: string;
  position: { x: number; y: number };
  cards: WeddingCard[];
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  duration: string;
  bpm?: number;
  moment: string;
  gradient: string;
  category: 'ceremony' | 'soiree';
  phase?: string;
}

export interface CanvasTransform {
  x: number;
  y: number;
  scale: number;
}

export interface BgSettings {
  type: 'color' | 'gradient' | 'image' | 'video';
  value: string;
  fit?: 'cover' | 'contain';
  opacity?: number;
  blur?: number;
  overlay?: string;
  muted?: boolean;
  loop?: boolean;
  playbackRate?: number;
}

export interface TextSettings {
  size: number;
  color: string;
}

export type CanvasElementType =
  | 'text'
  | 'image'
  | 'video'
  | 'card'
  | 'button'
  | 'gallery'
  | 'music'
  | 'note'
  | 'shape'
  | 'section'
  | 'link'
  | 'embed';

export interface CanvasElementStyle {
  background: string;
  color: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: number;
  textAlign: 'left' | 'center' | 'right';
  borderRadius: number;
  opacity: number;
  blur: number;
  borderWidth: number;
  borderColor: string;
  shadow: number;
  objectFit: 'cover' | 'contain';
  overlay: string;
}


export interface CanvasRoleMeta {
  kind: 'couple' | 'prestataire' | 'association' | 'artiste' | 'lieu' | 'entreprise' | 'personne' | 'projet';
  universe: string;
  subtitle: string;
  connections: string[];
}

export interface CanvasElementData {
  id: string;
  type: CanvasElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  content: string;
  url: string;
  linkUrl?: string;
  locked: boolean;
  hidden: boolean;
  zIndex: number;
  style: CanvasElementStyle;
  videoMuted?: boolean;
  videoLoop?: boolean;
  videoRate?: number;
  roleMeta?: CanvasRoleMeta;
  coverVariant?: CoverVariant;
  remixSourceStyle?: CanvasElementStyle;
}
