import { createRoot } from 'react-dom/client';
import './styles/index.css';

function showBootError(error: unknown) {
  const root = document.getElementById('root');
  const message = error instanceof Error ? error.message : String(error || 'Erreur inconnue');
  const stack = error instanceof Error ? error.stack || '' : '';
  console.error('[LMA] Application boot failed', error);
  if (!root) return;
  root.innerHTML = `
    <main style="min-height:100vh;box-sizing:border-box;display:grid;place-items:center;padding:24px;background:#151516;color:#F5F5F5;font-family:Inter,system-ui,sans-serif">
      <section style="width:min(620px,100%);padding:22px;border-radius:16px;background:#242426;border:1px solid rgba(255,255,255,.1);box-shadow:0 28px 80px rgba(0,0,0,.32)">
        <div style="display:flex;align-items:center;gap:11px">
          <span role="img" aria-label="LE MONDE AIME" style="width:32px;height:32px;flex:0 0 auto;display:grid;place-items:center;border-radius:50%;padding:3px;box-sizing:border-box;background:conic-gradient(from 215deg,#F1A55B,#F3D875,#8FC8A5,#70BBD0,#8D83D8,#D783B9,#D97976,#F1A55B);box-shadow:inset 0 0 0 1px rgba(255,255,255,.28),0 0 0 1px rgba(0,0,0,.16)"><span aria-hidden="true" style="width:46%;height:46%;border-radius:50%;background:#242426;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)"></span></span>
          <div style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.45)">LE MONDE AIME · Diagnostic de démarrage</div>
        </div>
        <h1 style="margin:16px 0 8px;font-size:24px;line-height:1.15">L’application n’a pas pu démarrer.</h1>
        <p style="margin:0;color:rgba(255,255,255,.62);font-size:13px;line-height:1.6">Le projet est intact. Cette page affiche l’erreur réelle au lieu d’un écran blanc.</p>
        <pre style="margin:18px 0 0;padding:14px;border-radius:11px;overflow:auto;background:#18181A;border:1px solid rgba(255,255,255,.08);color:#F4B4B4;font:11px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap">${escapeHtml(message)}${stack ? `\n\n${escapeHtml(stack)}` : ''}</pre>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px">
          <button onclick="location.reload()" style="height:38px;padding:0 14px;border:0;border-radius:9px;background:#F4F4F5;color:#18181A;font-weight:750;cursor:pointer">Réessayer</button>
          <button onclick="navigator.serviceWorker?.getRegistrations().then(r=>Promise.all(r.map(x=>x.unregister()))).finally(()=>caches?.keys().then(k=>Promise.all(k.map(x=>caches.delete(x)))).finally(()=>location.reload()))" style="height:38px;padding:0 14px;border:1px solid rgba(255,255,255,.13);border-radius:9px;background:transparent;color:#F5F5F5;font-weight:650;cursor:pointer">Vider le cache de l’application</button>
        </div>
      </section>
    </main>`;
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  }[character] || character));
}

async function bootstrap() {
  try {
    const [{ default: App }] = await Promise.all([
      import('./app/App'),
    ]);
    const root = document.getElementById('root');
    if (!root) throw new Error('Élément #root introuvable.');
    createRoot(root).render(<App />);

    if ('serviceWorker' in navigator && import.meta.env.PROD) {
      window.addEventListener('load', () => {
        void navigator.serviceWorker.register('/sw.js').catch((error) => {
          console.warn('[LMA] Service worker registration skipped', error);
        });
      });
    }
  } catch (error) {
    showBootError(error);
  }
}

window.addEventListener('error', (event) => {
  if (!document.getElementById('root')?.hasChildNodes()) showBootError(event.error || event.message);
});
window.addEventListener('unhandledrejection', (event) => {
  if (!document.getElementById('root')?.hasChildNodes()) showBootError(event.reason);
});

void bootstrap();
