# LE MONDE AIME v8.1 — MapMonde & Agent contextuel

- Ajout du bouton MapMonde dans l’en-tête.
- Nouveau hub plein écran : Feed, Registre, Map réseau et Agenda.
- Recherche et filtres universels par domaine.
- Chips de suggestions contextuelles dans l’Agent.
- Correction de la réponse à une demande de mini-site musicien.
- Le panneau Mini-site peut désormais être ouvert depuis la vue Mini-site, pas seulement depuis Canvas.
- Libellé Agent IA rendu universel.

## Étape suivante
Unifier Mini-site et Timeline comme plans redimensionnables dans le Canvas unique, puis ajouter les formats Desktop/Tablette/Mobile et la bibliothèque de templates.
