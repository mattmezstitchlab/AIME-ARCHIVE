from pathlib import Path


def read(path: str) -> str:
    return Path(path).read_text(encoding='utf-8')


def write(path: str, value: str) -> None:
    Path(path).write_text(value, encoding='utf-8')


def once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise SystemExit(f'Missing pattern: {label}')
    return text.replace(old, new, 1)


app_path = 'src/app/App.tsx'
app = read(app_path)
app = once(app,
    "import { AuthProvider } from './contexts/AuthContext';",
    "import { AuthProvider, useAuth } from './contexts/AuthContext';\nimport { PublicWeddingSite } from './public/PublicWeddingSite';\nimport { publishWedding } from './public/publicationService';",
    'Public route imports')
app = once(app,
    "function AppInner({ project, onExit }: { project: StudioProjectMeta; onExit: () => void }) {\n  const { isDark } = useTheme();",
    "function AppInner({ project, onExit }: { project: StudioProjectMeta; onExit: () => void }) {\n  const { isDark } = useTheme();\n  const { user } = useAuth();",
    'Auth user in editor')
app = once(app,
    "  const [controlCenterOpen, setControlCenterOpen] = useState(() => project.universe === 'mariage' && getProjectItem('lma_wedding_control_seen') !== '1');",
    "  const [controlCenterOpen, setControlCenterOpen] = useState(() => project.universe === 'mariage' && getProjectItem('lma_wedding_control_seen') !== '1');\n  const [publicationResult, setPublicationResult] = useState<{ url: string; liveUrl: string; mode: 'cloud' | 'local' } | null>(() => {\n    try { return JSON.parse(getProjectItem('lma_publication_result') || 'null'); } catch { return null; }\n  });",
    'Publication result state')
readiness_anchor = "  const weddingReadiness = useMemo(() => computeWeddingReadiness(weddingProjectData, cardSettings), [cardSettings, weddingProjectData]);\n"
publish_block = readiness_anchor + "  const publishCurrentWedding = useCallback(async () => {\n    if (project.universe !== 'mariage') throw new Error('La publication publique V9.0 est actuellement finalisée pour le module Mariage.');\n    const result = await publishWedding({ project, wedding: weddingProjectData, lots, cardSettings, user });\n    const compact = { url: result.url, liveUrl: result.liveUrl, mode: result.mode };\n    setPublicationResult(compact);\n    setProjectItem('lma_publication_result', JSON.stringify(compact));\n    if (result.mode === 'cloud') updateProject(project.id, { status: 'published' });\n    return compact;\n  }, [cardSettings, project, user, weddingProjectData]);\n"
app = once(app, readiness_anchor, publish_block, 'Publish current wedding callback')
old_publish_panel = '''          exportProject={exportStudioProject}
          importProject={importStudioProject}
          onClose={() => setActiveStudioPanel(null)}'''
new_publish_panel = '''          exportProject={exportStudioProject}
          importProject={importStudioProject}
          onPublish={publishCurrentWedding}
          initialPublication={publicationResult}
          onClose={() => setActiveStudioPanel(null)}'''
app = once(app, old_publish_panel, new_publish_panel, 'Publish panel props')
app = app.replace('    version: 8.8,', '    version: 9.0,')
old_app = '''export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <WorkspaceRoot />
      </AuthProvider>
    </ThemeProvider>
  );
}'''
new_app = '''function ApplicationRouter() {
  const params = new URLSearchParams(window.location.search);
  const liveSlug = params.get('live');
  const siteSlug = params.get('site');
  if (liveSlug) return <PublicWeddingSite slug={liveSlug} mode="live" />;
  if (siteSlug) return <PublicWeddingSite slug={siteSlug} mode="site" />;
  return <WorkspaceRoot />;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ApplicationRouter />
      </AuthProvider>
    </ThemeProvider>
  );
}'''
app = once(app, old_app, new_app, 'Public application router')
write(app_path, app)

public_path = 'src/app/public/PublicWeddingSite.tsx'
public = read(public_path)
meta_anchor = "  const [updates, setUpdates] = useState<Array<{ id: string; title: string; body?: string; event_time?: string; created_at: string }>>([]);\n"
meta_block = meta_anchor + "\n  useEffect(() => {\n    const previousTitle = document.title;\n    const robots = document.querySelector('meta[name=\"robots\"]');\n    const previousRobots = robots?.getAttribute('content') || '';\n    document.title = publication?.title ? `${publication.title} — Le Monde Aime` : 'Mariage — Le Monde Aime';\n    robots?.setAttribute('content', 'index, follow');\n    return () => { document.title = previousTitle; robots?.setAttribute('content', previousRobots || 'noindex, nofollow'); };\n  }, [publication?.title]);\n"
public = once(public, meta_anchor, meta_block, 'Public SEO metadata')
write(public_path, public)

main_path = 'src/main.tsx'
main = read(main_path)
if "navigator.serviceWorker.register('/sw.js')" not in main:
    main += "\nif ('serviceWorker' in navigator && import.meta.env.PROD) {\n  window.addEventListener('load', () => {\n    void navigator.serviceWorker.register('/sw.js').catch(() => undefined);\n  });\n}\n"
write(main_path, main)

index_path = 'index.html'
index = read(index_path)
index = once(index,
    '    <meta name="description" content="Un même canvas pour créer, relier et publier des univers : mariage, événement, prestataire, association, site et portfolio." />',
    '    <meta name="description" content="Un même canvas pour organiser, relier et publier un mariage, un événement ou un univers vivant." />\n    <meta name="theme-color" content="#151516" />\n    <link rel="manifest" href="/manifest.webmanifest" />\n    <link rel="icon" href="/icon.svg" type="image/svg+xml" />',
    'Manifest metadata')
write(index_path, index)

package_path = 'package.json'
package = read(package_path)
package = package.replace('"version": "0.8.9"', '"version": "0.9.0"')
if '"qrcode"' not in package:
    package = package.replace('"motion": "12.23.24",', '"motion": "12.23.24",\n    "qrcode": "^1.5.4",')
if '"@types/qrcode"' not in package:
    package = package.replace('"@vitejs/plugin-react": "4.7.0",', '"@vitejs/plugin-react": "4.7.0",\n    "@types/qrcode": "^1.5.5",')
write(package_path, package)

Path('CHANGES-v9.0.md').write_text('''# LE MONDE AIME v9.0 — Publication & Jour J

- Publication réelle d’un mini-site de mariage dans Supabase lorsque le cloud est connecté.
- Aperçu public local conservé sans configuration externe.
- URL publique, vue Jour J Live et QR Code PNG.
- RSVP public relié au projet avec repli local.
- Page publique responsive construite depuis les mêmes données que la Timeline et le Canvas.
- Vue mobile Jour J avec moment en cours, suite du programme et messages live.
- Application installable et shell hors connexion grâce au manifest et au service worker.
- Schéma RLS pour publications, RSVP et mises à jour live.
''', encoding='utf-8')
print('V9.0 migration applied')
