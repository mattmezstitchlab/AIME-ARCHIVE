from pathlib import Path
import re


def read(path: str) -> str:
    return Path(path).read_text(encoding='utf-8')


def write(path: str, value: str) -> None:
    Path(path).write_text(value, encoding='utf-8')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        if new in text:
            return text
        raise SystemExit(f'Missing pattern: {label}')
    return text.replace(old, new, 1)


# projectStore: remove the last legacy Sophie & Antoine fallback and make IndexedDB bounded.
store_path = 'src/app/utils/projectStore.ts'
store = read(store_path)
store = store.replace("return firstA && firstB ? `${firstA} & ${firstB}` : 'Sophie & Antoine';", "return firstA && firstB ? `${firstA} & ${firstB}` : 'Votre mariage';")
store = replace_once(store, "const SAVE_EVENT = 'lma:project-save-state';", "const SAVE_EVENT = 'lma:project-save-state';\nconst DATABASE_OPEN_TIMEOUT_MS = 700;", 'database timeout constant')
open_db_pattern = re.compile(r"function openDatabase\(\): Promise<IDBDatabase \| null> \{.*?\n\}\n\nasync function putSnapshot", re.S)
open_db_replacement = '''function openDatabase(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    let settled = false;
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    const finish = (database: IDBDatabase | null) => {
      if (settled) {
        database?.close();
        return;
      }
      settled = true;
      window.clearTimeout(timer);
      resolve(database);
    };
    const timer = window.setTimeout(() => finish(null), DATABASE_OPEN_TIMEOUT_MS);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => finish(request.result);
    request.onerror = () => finish(null);
    request.onblocked = () => finish(null);
  });
}

async function putSnapshot'''
store, count = open_db_pattern.subn(open_db_replacement, store, count=1)
if count != 1 and 'DATABASE_OPEN_TIMEOUT_MS' not in store:
    raise SystemExit('Could not replace openDatabase')
write(store_path, store)

# App: validate URL project IDs, always leave loading state, and recover to the editor.
app_path = 'src/app/App.tsx'
app = read(app_path)
workspace_pattern = re.compile(r"function WorkspaceRoot\(\) \{.*?\n\}\n\nexport default function App\(\)", re.S)
workspace_replacement = '''function WorkspaceRoot() {
  ensureProjectWorkspace();
  const projectIdFromUrl = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('project') : null;
  const availableProjects = getProjects();
  const requestedProject = projectIdFromUrl ? availableProjects.find((item) => item.id === projectIdFromUrl) || null : null;
  const initialProject = requestedProject || getActiveProject();
  const [screen, setScreen] = useState<'projects' | 'editor'>(() => requestedProject ? 'editor' : 'projects');
  const [activeProject, setActiveProjectMeta] = useState<StudioProjectMeta>(() => initialProject);
  const [loadingProject, setLoadingProject] = useState(Boolean(requestedProject));
  const [openWarning, setOpenWarning] = useState('');

  useEffect(() => {
    if (projectIdFromUrl && !requestedProject) {
      const url = new URL(window.location.href);
      url.searchParams.delete('project');
      url.hash = 'projects';
      window.history.replaceState(null, '', url);
      setScreen('projects');
      setLoadingProject(false);
      setOpenWarning('Ce projet n’existe plus dans ce navigateur.');
      return;
    }
    if (!requestedProject) return;
    let cancelled = false;
    void hydrateProject(requestedProject.id)
      .catch(() => {
        if (!cancelled) setOpenWarning('Le stockage complet n’a pas répondu. Le projet a été ouvert avec les données disponibles.');
      })
      .finally(() => {
        if (cancelled) return;
        setActiveProjectMeta(getActiveProject());
        setLoadingProject(false);
      });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const refresh = () => setActiveProjectMeta(getActiveProject());
    window.addEventListener('lma:projects-changed', refresh);
    return () => window.removeEventListener('lma:projects-changed', refresh);
  }, []);

  const openProject = async (project: StudioProjectMeta) => {
    setLoadingProject(true);
    setOpenWarning('');
    const url = new URL(window.location.href);
    url.searchParams.set('project', project.id);
    url.hash = '';
    window.history.replaceState(null, '', url);
    try {
      await hydrateProject(project.id);
      setActiveProjectMeta(getActiveProject());
    } catch {
      setActiveProjectMeta(project);
      setOpenWarning('Le stockage complet n’a pas répondu. Le projet a été ouvert avec les données locales disponibles.');
    } finally {
      setScreen('editor');
      setLoadingProject(false);
    }
  };

  const closeEditor = async () => {
    await flushProjectSave(activeProject.id);
    const url = new URL(window.location.href);
    url.searchParams.delete('project');
    url.hash = 'projects';
    window.history.replaceState(null, '', url);
    setActiveProjectMeta(getActiveProject());
    setScreen('projects');
  };

  if (loadingProject) {
    return <div style={{ width: '100vw', height: '100vh', display: 'grid', placeItems: 'center', background: '#0C0C0E', color: '#fff', fontFamily: 'Inter, sans-serif' }}><div style={{ textAlign: 'center' }}><div style={{ width: 34, height: 34, borderRadius: 12, margin: '0 auto 12px', background: '#2B2B2E', animation: 'pulse 1s ease-in-out infinite' }} /><div style={{ fontSize: 11, opacity: .58 }}>Ouverture du canvas…</div></div></div>;
  }

  if (screen === 'projects') return <ProjectDashboard onOpenProject={openProject} />;
  return <>
    {openWarning && <div role="status" style={{ position: 'fixed', top: 58, left: '50%', transform: 'translateX(-50%)', zIndex: 1200, maxWidth: 560, padding: '9px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,.12)', background: 'rgba(36,36,38,.96)', color: '#E8E8EA', fontSize: 10, fontFamily: 'Inter, sans-serif', boxShadow: '0 18px 45px rgba(0,0,0,.28)' }}>{openWarning}</div>}
    <AppInner key={activeProject.id} project={activeProject} onExit={() => void closeEditor()} />
  </>;
}

export default function App()'''
app, count = workspace_pattern.subn(workspace_replacement, app, count=1)
if count != 1:
    raise SystemExit('Could not replace WorkspaceRoot')
write(app_path, app)

# Dashboard: visible progress and recoverable click errors.
dashboard_path = 'src/app/components/ProjectDashboard.tsx'
dashboard = read(dashboard_path)
dashboard = replace_once(dashboard, "  const [importError, setImportError] = useState('');", "  const [importError, setImportError] = useState('');\n  const [openingProjectId, setOpeningProjectId] = useState<string | null>(null);\n  const [openError, setOpenError] = useState('');", 'dashboard opening states')
dashboard = replace_once(dashboard, "  const createAndOpen = async (universe: ProjectUniverse) => {", "  const requestOpen = async (project: StudioProjectMeta) => {\n    if (openingProjectId) return;\n    setOpenError('');\n    setOpeningProjectId(project.id);\n    try {\n      await onOpenProject(project);\n    } catch (error) {\n      setOpenError(error instanceof Error ? error.message : 'Le projet n’a pas pu être ouvert.');\n    } finally {\n      setOpeningProjectId(null);\n    }\n  };\n\n  const createAndOpen = async (universe: ProjectUniverse) => {", 'requestOpen helper')
dashboard = dashboard.replace('    await onOpenProject(project);', '    await requestOpen(project);')
dashboard = dashboard.replace('onClick={() => onOpenProject(project)}', 'onClick={() => void requestOpen(project)}')
dashboard = dashboard.replace('onOpen={() => onOpenProject(project)}', 'onOpen={() => void requestOpen(project)}')
root_marker = "    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', background: bg, color: text, fontFamily: 'Inter, sans-serif' }}>"
root_insert = root_marker + "\n      {openingProjectId && <div aria-live=\"polite\" style={{ position: 'fixed', inset: 0, zIndex: 1200, display: 'grid', placeItems: 'center', background: 'rgba(10,10,11,.42)', backdropFilter: 'blur(5px)' }}><div style={{ minWidth: 210, padding: '14px 16px', borderRadius: 12, border: `1px solid ${border}`, background: panel2, color: text, boxShadow: '0 24px 60px rgba(0,0,0,.32)', textAlign: 'center', fontSize: 10.5 }}><strong style={{ display: 'block', fontSize: 12, marginBottom: 5 }}>Ouverture du projet</strong>Chargement sécurisé des données…</div></div>}\n      {openError && <div role=\"alert\" style={{ position: 'fixed', top: 18, left: '50%', transform: 'translateX(-50%)', zIndex: 1300, maxWidth: 520, padding: '10px 13px', borderRadius: 10, border: '1px solid rgba(248,113,113,.28)', background: isDark ? '#242426' : '#FFFFFF', color: isDark ? '#F5F5F5' : '#121213', boxShadow: '0 18px 45px rgba(0,0,0,.22)', fontSize: 10 }}>{openError}</div>}"
dashboard = replace_once(dashboard, root_marker, root_insert, 'dashboard opening overlay')
write(dashboard_path, dashboard)

# Package metadata and tests.
package_path = 'package.json'
package = read(package_path)
package = package.replace('"version": "0.8.7"', '"version": "0.8.7-1"')
package = package.replace('"build": "vite build",', '"build": "vite build",\n    "test": "vitest run",')
write(package_path, package)

Path('CHANGES-v8.7.1.md').write_text('''# LE MONDE AIME v8.7.1 — Fiabilité des projets\n\n- Ouverture bornée : IndexedDB ne peut plus bloquer indéfiniment le studio.\n- Identifiants de projet invalides renvoyés proprement vers l’accueil.\n- Chargement visible et erreurs récupérables.\n- Un projet s’ouvre même si le stockage secondaire est momentanément indisponible.\n- Suppression du dernier fallback de démonstration « Sophie & Antoine ».\n- Tests automatisés du cycle créer → sauvegarder → réhydrater.\n''', encoding='utf-8')
print('V8.7.1 migration applied')
