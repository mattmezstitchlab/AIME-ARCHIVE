from pathlib import Path
import re


def read(path: str) -> str:
    return Path(path).read_text(encoding='utf-8')


def write(path: str, value: str) -> None:
    Path(path).write_text(value, encoding='utf-8')


def once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise SystemExit(f'Missing pattern: {label}')
    return text.replace(old, new, 1)


agent_path = 'src/app/components/AIAgent.tsx'
agent = read(agent_path)
agent = once(agent,
    "import type { WeddingLot } from '../types';",
    "import type { WeddingLot } from '../types';\nimport { askAimeCore, type AgentProposal } from '../agent/agentClient';\nimport { buildAgentDomainContext } from '../domain/modules';\nimport type { ProjectUniverse } from '../utils/projectStore';",
    'Connected agent imports')
agent = once(agent,
    "  const [activeTab, setActiveTab] = useState<'agent' | 'tasks'>('agent');",
    "  const [activeTab, setActiveTab] = useState<'agent' | 'tasks'>('agent');\n  const [remoteMode, setRemoteMode] = useState<'unknown' | 'connected' | 'local'>('unknown');",
    'Remote mode state')
agent = agent.replace('Le Monde Aime · moteur local', 'Le Monde Aime · local + AIME CORE')
agent = agent.replace('Aucun message externe n’est envoyé sans confirmation explicite. Le moteur actuel reste un assistant guidé local, et non un agent distant connecté.', 'Lorsqu’AIME CORE est configuré, votre demande et un contexte limité du projet sont envoyés à la fonction sécurisée du studio. Les modifications restent proposées et ne sont appliquées qu’après votre confirmation explicite.')
handle_pattern = re.compile(r"  const handleSend = useCallback\(\(\) => \{.*?\n  \}, \[input, thinking, lots, cardSettings, viewMode, projectUniverse, onAction\]\);", re.S)
handle_replacement = '''  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || thinking) return;
    const uid = Date.now().toString();
    setInput('');
    setMessages((prev) => [...prev, { id: uid, role: 'user', text, ts: new Date() }]);
    setThinking(true);
    onThinkingChange?.(true);

    const log = JSON.parse(getProjectItem('lma_agent_log') || '[]');
    log.push({ role: 'user', text, ts: new Date().toISOString(), view: viewMode });
    setProjectItem('lma_agent_log', JSON.stringify(log.slice(-200)));

    let agentText = '';
    let action: any;
    try {
      const cardSummary = lots.flatMap((lot) => lot.cards.map((card) => ({
        id: card.id,
        name: card.name,
        time: typeof cardSettings[card.id]?.time === 'string' ? cardSettings[card.id].time : undefined,
        status: typeof cardSettings[card.id]?.status === 'string' ? cardSettings[card.id].status : undefined,
      }))).slice(0, 90);
      const connected = await askAimeCore(text, {
        projectName,
        universe: projectUniverse,
        viewMode,
        selectedObject: selectedObjectLabel ? { kind: selectedObjectKind || 'object', label: selectedObjectLabel } : undefined,
        selectedCardCount: selectedCount,
        canvasElementCount,
        cardSummary,
        domain: buildAgentDomainContext(projectUniverse as ProjectUniverse),
      }, messages.map((message) => ({ role: message.role, text: message.text })));
      agentText = connected.text;
      action = connected.proposals.length ? { type: 'proposals', items: connected.proposals, confidence: connected.confidence } : undefined;
      setRemoteMode('connected');
    } catch {
      const local = getAgentResponse(text, lots, cardSettings, projectUniverse);
      agentText = local.text;
      action = local.action;
      setRemoteMode('local');
      const normalized = text.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      if (normalized.match(/point zero|point zéro|audit|eaa|wcag|rgaa|importer.*zip|archive zip/)) window.dispatchEvent(new CustomEvent('lma-point-zero-toggle', { detail: { open: true } }));
      if (normalized.match(/couleur|palette|triade|complementaire|complémentaire|nuancier|arc.?en.?ciel|chromatique/)) window.dispatchEvent(new CustomEvent('lma-chromatic-toggle', { detail: { open: true } }));
    }

    const aid = (Date.now() + 1).toString();
    setMessages((prev) => [...prev, { id: aid, role: 'agent', text: agentText, ts: new Date(), action }]);
    setThinking(false);
    onThinkingChange?.(false);
    if (!externalOpen) onNewMessage?.();

    const log2 = JSON.parse(getProjectItem('lma_agent_log') || '[]');
    log2.push({ role: 'agent', text: agentText, ts: new Date().toISOString(), action, mode: action?.type === 'proposals' ? 'aime-core' : 'local' });
    setProjectItem('lma_agent_log', JSON.stringify(log2.slice(-200)));
    if (action?.type === 'navigate') {
      setGuidedDot(true);
      setTimeout(() => setGuidedDot(false), 4000);
    }
  }, [canvasElementCount, cardSettings, externalOpen, input, lots, messages, onAction, onNewMessage, onThinkingChange, projectName, projectUniverse, selectedCount, selectedObjectKind, selectedObjectLabel, thinking, viewMode]);'''
agent, count = handle_pattern.subn(handle_replacement, agent, count=1)
if count != 1:
    raise SystemExit('Could not replace AIAgent handleSend')
agent = once(agent,
    "                  Assistant du projet · Local",
    "                  {remoteMode === 'connected' ? 'AIME CORE · Connecté' : remoteMode === 'local' ? 'Assistant du projet · Local' : 'Assistant du projet · Prêt'}",
    'Connected agent label')
navigate_block = '''                  {msg.action?.type === 'navigate' && (
                    <button
                      onClick={() => handleNavigate(msg.action.lotId)}
                      style={{ marginTop: '6px', display: 'flex', alignItems: 'center', gap: '5px', background: surf2, border: `1px solid ${border}`, borderRadius: '8px', padding: '5px 10px', cursor: 'pointer', fontFamily: 'Inter', fontSize: '11px', fontWeight: 600, color: textPrimary }}
                    >
                      <MapPin size={11} /> {msg.action.label} <ArrowRight size={11} />
                    </button>
                  )}'''
proposal_block = navigate_block + '''
                  {msg.action?.type === 'proposals' && Array.isArray(msg.action.items) && (
                    <div style={{ width: '90%', marginTop: 7, display: 'grid', gap: 6 }}>
                      {(msg.action.items as AgentProposal[]).map((proposal) => (
                        <button key={proposal.id} title={proposal.rationale} onClick={() => onAction?.(proposal.action)} style={{ minHeight: 34, padding: '7px 9px', borderRadius: 8, border: `1px solid ${border}`, background: surf3, color: textPrimary, cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 7, fontSize: 9.5, fontWeight: 760 }}><Wand2 size={12} /> <span style={{ flex: 1 }}>{proposal.label}</span><ArrowRight size={11} /></button>
                      ))}
                      <div style={{ color: textSecondary, fontSize: 8, padding: '0 3px' }}>Confiance {Math.round(Number(msg.action.confidence || 0) * 100)} % · aucune action appliquée sans clic.</div>
                    </div>
                  )}'''
agent = once(agent, navigate_block, proposal_block, 'Proposal confirmation buttons')
write(agent_path, agent)

app_path = 'src/app/App.tsx'
app = read(app_path)
agent_action_anchor = "  const handleAgentAction = useCallback((action: string) => {\n"
agent_action_block = agent_action_anchor + "    if (action === 'open-point-zero') { window.dispatchEvent(new CustomEvent('lma-point-zero-toggle', { detail: { open: true } })); return; }\n    if (action === 'open-chromatic') { window.dispatchEvent(new CustomEvent('lma-chromatic-toggle', { detail: { open: true } })); return; }\n    if (action.startsWith('navigate-lot:')) {\n      const lotId = Number(action.split(':')[1]);\n      const lot = lots.find((item) => item.id === lotId);\n      if (lot) { setViewMode('canvas'); setActiveLotId(lot.id); setActiveTool('select'); toast.success(`Lot « ${lot.title} » ouvert.`); }\n      return;\n    }\n"
app = once(app, agent_action_anchor, agent_action_block, 'Agent proposal actions')
write(app_path, app)

package_path = 'package.json'
package = read(package_path)
package = package.replace('"version": "0.9.0"', '"version": "0.9.1"')
if '"openai"' not in package:
    package = package.replace('"motion": "12.23.24",', '"motion": "12.23.24",\n    "openai": "^6.7.0",')
if '"@vercel/node"' not in package:
    package = package.replace('"@types/qrcode": "^1.5.5",', '"@types/qrcode": "^1.5.5",\n    "@vercel/node": "^5.5.6",')
write(package_path, package)

vercel_path = 'vercel.json'
vercel = read(vercel_path)
if '"api/agent.ts"' not in vercel:
    vercel = vercel.replace('  "rewrites": [', '  "functions": {\n    "api/agent.ts": { "maxDuration": 30 }\n  },\n  "rewrites": [')
write(vercel_path, vercel)

Path('CHANGES-v9.1.md').write_text('''# LE MONDE AIME v9.1 — AIME CORE & modules universels\n\n- Fonction Vercel sécurisée utilisant l’API OpenAI Responses côté serveur.\n- Aucune clé OpenAI exposée au navigateur.\n- AIME CORE répond avec texte, confiance et propositions d’actions contrôlées.\n- Chaque action doit être confirmée par un clic avant modification du projet.\n- Repli automatique vers le moteur local lorsque l’agent distant n’est pas configuré ou indisponible.\n- Registre de modules pour Mariage, Prestataire, Association, Événement, Portfolio, Site et Point Zéro.\n- Contexte métier du module actif transmis à AIME CORE.\n- Limitation de débit, validation d’origine et liste fermée des actions exécutables.\n''', encoding='utf-8')
print('V9.1 migration applied')
