from pathlib import Path


def read(path: str) -> str:
    return Path(path).read_text(encoding='utf-8')


def write(path: str, value: str) -> None:
    Path(path).write_text(value, encoding='utf-8')


def once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise SystemExit(f'Missing pattern: {label}')
    return text.replace(old, new, 1)


app_path = 'src/app/App.tsx'
app = read(app_path)
app = once(app,
    "import React, { useState, useCallback, useEffect, useRef } from 'react';",
    "import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';",
    'React useMemo import')
app = once(app,
    "import { AIAgent } from './components/AIAgent';",
    "import { AIAgent } from './components/AIAgent';\nimport { WeddingControlCenter } from './components/WeddingControlCenter';\nimport { buildWeddingProjectData, computeWeddingReadiness } from './domain/weddingProject';",
    'Wedding imports')
app = once(app,
    "  const [agentOpen, setAgentOpen] = useState(false);",
    "  const [agentOpen, setAgentOpen] = useState(false);\n  const [controlCenterOpen, setControlCenterOpen] = useState(() => project.universe === 'mariage' && getProjectItem('lma_wedding_control_seen') !== '1');",
    'Control center state')
canonical_anchor = "  useEffect(() => { setProjectItem('lma_selected_cards', JSON.stringify(Array.from(selectedCards))); }, [selectedCards]);\n"
canonical_block = canonical_anchor + "  const weddingProjectData = useMemo(() => buildWeddingProjectData({\n    setup: setupData,\n    totalBudget,\n    heroPhoto,\n    heroMediaType,\n    heroName: heroCoupleName,\n    heroDate,\n    heroVenue,\n    selectedCardIds: Array.from(selectedCards),\n  }), [heroCoupleName, heroDate, heroMediaType, heroPhoto, heroVenue, selectedCards, setupData, totalBudget]);\n  const weddingReadiness = useMemo(() => computeWeddingReadiness(weddingProjectData, cardSettings), [cardSettings, weddingProjectData]);\n  useEffect(() => {\n    if (project.universe === 'mariage') setProjectItem('lma_wedding_project_v1', JSON.stringify(weddingProjectData));\n  }, [project.universe, weddingProjectData]);\n"
app = once(app, canonical_anchor, canonical_block, 'Canonical wedding persistence')
app = once(app,
    "    setAgentOpen(false);\n    setActiveStudioPanel(null);",
    "    setAgentOpen(false);\n    setControlCenterOpen(false);\n    setActiveStudioPanel(null);",
    'Close control center')
app = once(app,
    "const openWorkspacePanel = useCallback((panel: StudioPanelKind | 'checklist' | 'budget' | 'templates' | 'minisite' | 'playlist' | 'agent') => {",
    "const openWorkspacePanel = useCallback((panel: StudioPanelKind | 'checklist' | 'budget' | 'templates' | 'minisite' | 'playlist' | 'agent' | 'control') => {",
    'Workspace panel type')
app = once(app,
    "    else if (panel === 'agent') setAgentOpen(true);\n    else setActiveStudioPanel(panel);",
    "    else if (panel === 'agent') setAgentOpen(true);\n    else if (panel === 'control') { setControlCenterOpen(true); setProjectItem('lma_wedding_control_seen', '1'); }\n    else setActiveStudioPanel(panel);",
    'Open control center')
app = app.replace("    version: 8.5,", "    version: 8.8,")
app = once(app,
    "        onHome={onExit}",
    "        onHome={() => { if (project.universe === 'mariage') openWorkspacePanel('control'); else onExit(); }}",
    'Sidebar project home')
sidebar_end = "        onClose={() => setSidebarOpen(false)}\n      />\n\n      {/* ── Toolbar — studio families ── */}"
control_render = "        onClose={() => setSidebarOpen(false)}\n      />\n\n      {controlCenterOpen && project.universe === 'mariage' && (\n        <WeddingControlCenter\n          data={weddingProjectData}\n          readiness={weddingReadiness}\n          onClose={() => setControlCenterOpen(false)}\n          onEditIdentity={() => {\n            closeWorkspacePanels();\n            setViewMode('canvas');\n            selectCanvasObject({ kind: 'entry', id: 'couple' });\n            fitWorkspacePlacements([{ x: entryPositions.couple.x, y: entryPositions.couple.y, width: 260, height: 360 }]);\n          }}\n          onOpenTimeline={() => { closeWorkspacePanels(); selectPlan('timeline'); }}\n          onOpenMiniSite={() => { closeWorkspacePanels(); selectPlan('minisite'); }}\n          onOpenBudget={() => openWorkspacePanel('budget')}\n          onOpenChecklist={() => openWorkspacePanel('checklist')}\n          onOpenMedia={() => { setViewMode('canvas'); openWorkspacePanel('media'); }}\n        />\n      )}\n\n      {/* ── Toolbar — studio families ── */}"
app = once(app, sidebar_end, control_render, 'Wedding Control Room render')
app = app.replace("          ⌘K Commandes · ⌘Z Annuler · G Pan · V Sélect · +/- Zoom · Échap Retour", "          Clic : sélectionner · Glisser le fond : déplacer · ⌘Z : annuler · +/- : zoom")
write(app_path, app)

sidebar_path = 'src/app/components/WorkspaceSidebar.tsx'
sidebar = read(sidebar_path)
sidebar = sidebar.replace('Une navigation, un seul canevas', 'Une Control Room, un seul canevas')
sidebar = sidebar.replace('Les lots, la timeline et le mini-site sont des contenus reliés. Le panneau de gauche sert de structure ; le centre sert à les visualiser et les éditer.', 'Accueil ouvre la Control Room. Les lots, la timeline, le budget et le mini-site lisent les mêmes données du mariage.')
write(sidebar_path, sidebar)

package_path = 'package.json'
package = read(package_path)
package = package.replace('"version": "0.8.7-1"', '"version": "0.8.8"')
write(package_path, package)

Path('CHANGES-v8.8.md').write_text('''# LE MONDE AIME v8.8 — Wedding MVP\n\n- Wedding Control Room accessible depuis Accueil dans le projet.\n- Modèle canonique `WeddingProjectData` partagé par identité, lieux, invités, budget et publication.\n- Indicateur de préparation calculé à partir des vraies données du projet.\n- Accès direct aux actions essentielles : couple, timeline, budget, checklist, média et mini-site.\n- Snapshot canonique sauvegardé localement dans `lma_wedding_project_v1`.\n- Export du studio mis à niveau en version 8.8.\n- Aide d’interaction simplifiée : sélection directe et déplacement du fond.\n''', encoding='utf-8')
print('V8.8 migration applied')
