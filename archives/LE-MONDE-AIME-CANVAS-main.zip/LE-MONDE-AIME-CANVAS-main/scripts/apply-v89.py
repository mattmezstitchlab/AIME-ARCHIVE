from pathlib import Path


def read(path: str) -> str:
    return Path(path).read_text(encoding='utf-8')


def write(path: str, value: str) -> None:
    Path(path).write_text(value, encoding='utf-8')


def once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise SystemExit(f'Missing pattern: {label}')
    return text.replace(old, new, 1)


app_path = 'src/app/App.tsx'
app = read(app_path)
app = once(app,
    "import { ThemeProvider, useTheme } from './contexts/ThemeContext';",
    "import { ThemeProvider, useTheme } from './contexts/ThemeContext';\nimport { AuthProvider } from './contexts/AuthContext';\nimport { CloudAccountControl } from './components/CloudAccountControl';",
    'Auth imports')
header_marker = "        {/* Right: save state, commands and agent */}\n        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>"
header_replacement = header_marker + "\n          <CloudAccountControl project={project} compact onOpen={closeWorkspacePanels} />"
app = once(app, header_marker, header_replacement, 'Cloud account header control')
old_wrapper = '''export default function App() {
  return (
    <ThemeProvider>
      <WorkspaceRoot />
    </ThemeProvider>
  );
}'''
new_wrapper = '''export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <WorkspaceRoot />
      </AuthProvider>
    </ThemeProvider>
  );
}'''
app = once(app, old_wrapper, new_wrapper, 'AuthProvider wrapper')
write(app_path, app)

project_path = 'src/app/components/ProjectDashboard.tsx'
project = read(project_path)
project = once(project,
    "import { useTheme } from '../contexts/ThemeContext';",
    "import { useTheme } from '../contexts/ThemeContext';\nimport { CloudAccountControl } from './CloudAccountControl';",
    'Dashboard cloud import')
project = once(project,
    "  importProjectBundle, permanentlyDeleteProject, updateProject,",
    "  importProjectBundle, permanentlyDeleteProject, updateProject, getActiveProject,",
    'Dashboard active project import')
project = once(project,
    "          <button title=\"Changer de thème\" onClick={toggle} style={{ marginLeft: 'auto', width: 28, height: 28, borderRadius: 8, border: `1px solid ${border}`, background: 'transparent', color: muted, cursor: 'pointer' }}>◐</button>",
    "          <span style={{ marginLeft: 'auto' }}><CloudAccountControl project={getActiveProject()} compact /></span>\n          <button title=\"Changer de thème\" onClick={toggle} style={{ width: 28, height: 28, borderRadius: 8, border: `1px solid ${border}`, background: 'transparent', color: muted, cursor: 'pointer' }}>◐</button>",
    'Dashboard cloud account button')
write(project_path, project)

package_path = 'package.json'
package = read(package_path)
package = package.replace('"name": "simple-card-studio"', '"name": "le-monde-aime-studio"')
package = package.replace('"version": "0.8.8"', '"version": "0.8.9"')
if '"@supabase/supabase-js"' not in package:
    package = package.replace('"@radix-ui/react-switch": "1.1.3",', '"@radix-ui/react-switch": "1.1.3",\n    "@supabase/supabase-js": "^2.76.1",')
write(package_path, package)

Path('CHANGES-v8.9.md').write_text('''# LE MONDE AIME v8.9 — Comptes & collaboration\n\n- Authentification optionnelle par lien e-mail avec Supabase.\n- Mode local conservé lorsque le cloud n’est pas configuré.\n- Synchronisation manuelle du projet et restauration d’une version cloud.\n- Invitations par e-mail avec rôles Éditeur, Commentateur et Lecteur.\n- Schéma Supabase avec RLS pour projets, membres et snapshots.\n- Contrôle Compte & collaboration dans le header et l’accueil.\n- Nom interne nettoyé : `le-monde-aime-studio`.\n''', encoding='utf-8')
print('V8.9 migration applied')
