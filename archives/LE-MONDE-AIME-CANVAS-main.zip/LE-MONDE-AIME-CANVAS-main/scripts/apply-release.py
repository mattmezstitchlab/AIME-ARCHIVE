from runpy import run_path

run_path('scripts/apply-v91.py', run_name='__main__')
