# LE MONDE AIME v8.6 — Cohérence & Export

- Exporter / Publier déplacé dans le header, en haut à droite.
- Suppression des boutons Publier et Enregistrer dupliqués dans la toolbar basse.
- Palette de commandes recentrée sur les actions et les lots, sans navigation doublonnée.
- Playlist collaborative intégrée aux thèmes sombre et clair.
- Panneaux Ajouter, Style, Exporter et Point Zéro neutralisés.
- Sélections, poignées et contours du canevas passés en gris neutre.
- La couleur reste disponible dans le cercle chromatique et les contenus, jamais imposée au chrome de l’interface.
