create table if not exists public.publications (
  slug text primary key,
  project_id text not null references public.projects(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  payload jsonb not null,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  published_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.rsvps (
  id uuid primary key default gen_random_uuid(),
  publication_slug text not null references public.publications(slug) on delete cascade,
  name text not null,
  email text,
  attendance text not null check (attendance in ('yes','no','maybe')),
  guest_count integer not null default 1 check (guest_count >= 0 and guest_count <= 20),
  dietary_requirements text,
  message text,
  created_at timestamptz not null default now()
);

create table if not exists public.live_updates (
  id uuid primary key default gen_random_uuid(),
  publication_slug text not null references public.publications(slug) on delete cascade,
  title text not null,
  body text,
  event_time timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.publications enable row level security;
alter table public.rsvps enable row level security;
alter table public.live_updates enable row level security;

drop policy if exists publications_public_read on public.publications;
create policy publications_public_read on public.publications for select using (status = 'published' or public.can_read_project(project_id));
drop policy if exists publications_owner_insert on public.publications;
create policy publications_owner_insert on public.publications for insert with check (owner_id = auth.uid() and public.can_edit_project(project_id));
drop policy if exists publications_owner_update on public.publications;
create policy publications_owner_update on public.publications for update using (public.can_edit_project(project_id)) with check (public.can_edit_project(project_id));
drop policy if exists publications_owner_delete on public.publications;
create policy publications_owner_delete on public.publications for delete using (owner_id = auth.uid());

drop policy if exists rsvps_public_insert on public.rsvps;
create policy rsvps_public_insert on public.rsvps for insert with check (exists (select 1 from public.publications p where p.slug = publication_slug and p.status = 'published'));
drop policy if exists rsvps_project_read on public.rsvps;
create policy rsvps_project_read on public.rsvps for select using (exists (select 1 from public.publications p where p.slug = publication_slug and public.can_read_project(p.project_id)));
drop policy if exists rsvps_project_delete on public.rsvps;
create policy rsvps_project_delete on public.rsvps for delete using (exists (select 1 from public.publications p where p.slug = publication_slug and public.can_edit_project(p.project_id)));

drop policy if exists live_updates_public_read on public.live_updates;
create policy live_updates_public_read on public.live_updates for select using (exists (select 1 from public.publications p where p.slug = publication_slug and p.status = 'published'));
drop policy if exists live_updates_editor_insert on public.live_updates;
create policy live_updates_editor_insert on public.live_updates for insert with check (exists (select 1 from public.publications p where p.slug = publication_slug and public.can_edit_project(p.project_id)));
drop policy if exists live_updates_editor_update on public.live_updates;
create policy live_updates_editor_update on public.live_updates for update using (exists (select 1 from public.publications p where p.slug = publication_slug and public.can_edit_project(p.project_id)));
drop policy if exists live_updates_editor_delete on public.live_updates;
create policy live_updates_editor_delete on public.live_updates for delete using (exists (select 1 from public.publications p where p.slug = publication_slug and public.can_edit_project(p.project_id)));

alter publication supabase_realtime add table public.live_updates;
