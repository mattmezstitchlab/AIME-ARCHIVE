create extension if not exists pgcrypto;

create table if not exists public.publications (
  slug text primary key,
  project_id text not null references public.projects(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  payload jsonb not null,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  published_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.rsvps (
  id uuid primary key default gen_random_uuid(),
  publication_slug text not null references public.publications(slug) on delete cascade,
  response_key uuid not null default gen_random_uuid(),
  name text not null,
  email text,
  attendance text not null check (attendance in ('yes','no','maybe')),
  guest_count integer not null default 1 check (guest_count >= 0 and guest_count <= 20),
  dietary_requirements text,
  message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.live_updates (
  id uuid primary key default gen_random_uuid(),
  publication_slug text not null references public.publications(slug) on delete cascade,
  title text not null,
  body text,
  event_time timestamptz,
  level text not null default 'info' check (level in ('info','important','urgent')),
  is_pinned boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.rsvps add column if not exists response_key uuid;
update public.rsvps set response_key = gen_random_uuid() where response_key is null;
alter table public.rsvps alter column response_key set default gen_random_uuid();
alter table public.rsvps alter column response_key set not null;
alter table public.rsvps add column if not exists updated_at timestamptz not null default now();
alter table public.live_updates add column if not exists level text not null default 'info';
alter table public.live_updates add column if not exists is_pinned boolean not null default false;
alter table public.live_updates add column if not exists updated_at timestamptz not null default now();

create unique index if not exists rsvps_publication_response_key_uidx on public.rsvps(publication_slug, response_key);
create index if not exists rsvps_publication_created_idx on public.rsvps(publication_slug, created_at desc);
create index if not exists live_updates_publication_created_idx on public.live_updates(publication_slug, is_pinned desc, created_at desc);
create index if not exists publications_project_idx on public.publications(project_id, updated_at desc);

alter table public.publications enable row level security;
alter table public.rsvps enable row level security;
alter table public.live_updates enable row level security;

drop policy if exists publications_public_read on public.publications;
create policy publications_public_read on public.publications
for select
using (status = 'published' or public.can_read_project(project_id));

drop policy if exists publications_owner_insert on public.publications;
create policy publications_owner_insert on public.publications
for insert to authenticated
with check (owner_id = auth.uid() and public.can_edit_project(project_id));

drop policy if exists publications_owner_update on public.publications;
create policy publications_owner_update on public.publications
for update to authenticated
using (public.can_edit_project(project_id))
with check (public.can_edit_project(project_id));

drop policy if exists publications_owner_delete on public.publications;
create policy publications_owner_delete on public.publications
for delete to authenticated
using (owner_id = auth.uid());

-- Public RSVP writes go through the validated RPC below. Direct anonymous inserts are disabled.
drop policy if exists rsvps_public_insert on public.rsvps;
drop policy if exists rsvps_project_read on public.rsvps;
create policy rsvps_project_read on public.rsvps
for select to authenticated
using (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_read_project(p.project_id)
  )
);

drop policy if exists rsvps_project_update on public.rsvps;
create policy rsvps_project_update on public.rsvps
for update to authenticated
using (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
)
with check (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
);

drop policy if exists rsvps_project_delete on public.rsvps;
create policy rsvps_project_delete on public.rsvps
for delete to authenticated
using (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
);

drop policy if exists live_updates_public_read on public.live_updates;
create policy live_updates_public_read on public.live_updates
for select
using (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and (p.status = 'published' or public.can_read_project(p.project_id))
  )
);

drop policy if exists live_updates_editor_insert on public.live_updates;
create policy live_updates_editor_insert on public.live_updates
for insert to authenticated
with check (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
);

drop policy if exists live_updates_editor_update on public.live_updates;
create policy live_updates_editor_update on public.live_updates
for update to authenticated
using (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
)
with check (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
);

drop policy if exists live_updates_editor_delete on public.live_updates;
create policy live_updates_editor_delete on public.live_updates
for delete to authenticated
using (
  exists (
    select 1 from public.publications p
    where p.slug = publication_slug
      and public.can_edit_project(p.project_id)
  )
);

create or replace function public.submit_public_rsvp(
  p_publication_slug text,
  p_response_key uuid,
  p_name text,
  p_email text,
  p_attendance text,
  p_guest_count integer,
  p_dietary_requirements text,
  p_message text
)
returns table (rsvp_id uuid, rsvp_updated_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_updated_at timestamptz;
begin
  if p_publication_slug is null or length(trim(p_publication_slug)) < 3 then
    raise exception 'Publication invalide.' using errcode = '22023';
  end if;
  if p_response_key is null then
    raise exception 'Clé de réponse invalide.' using errcode = '22023';
  end if;
  if p_name is null or length(trim(p_name)) < 2 or length(trim(p_name)) > 120 then
    raise exception 'Le nom doit contenir entre 2 et 120 caractères.' using errcode = '22023';
  end if;
  if p_email is not null and length(trim(p_email)) > 180 then
    raise exception 'Adresse e-mail trop longue.' using errcode = '22023';
  end if;
  if p_attendance not in ('yes','no','maybe') then
    raise exception 'Réponse de présence invalide.' using errcode = '22023';
  end if;
  if p_guest_count < 0 or p_guest_count > 20 then
    raise exception 'Le nombre de personnes doit être compris entre 0 et 20.' using errcode = '22023';
  end if;
  if coalesce(length(p_dietary_requirements), 0) > 1000 or coalesce(length(p_message), 0) > 2000 then
    raise exception 'La réponse est trop longue.' using errcode = '22023';
  end if;
  if not exists (
    select 1 from public.publications p
    where p.slug = p_publication_slug and p.status = 'published'
  ) then
    raise exception 'Cette invitation n’accepte pas de réponse.' using errcode = 'P0001';
  end if;

  insert into public.rsvps (
    publication_slug,
    response_key,
    name,
    email,
    attendance,
    guest_count,
    dietary_requirements,
    message,
    updated_at
  ) values (
    p_publication_slug,
    p_response_key,
    trim(p_name),
    nullif(trim(coalesce(p_email, '')), ''),
    p_attendance,
    p_guest_count,
    nullif(trim(coalesce(p_dietary_requirements, '')), ''),
    nullif(trim(coalesce(p_message, '')), ''),
    now()
  )
  on conflict (publication_slug, response_key)
  do update set
    name = excluded.name,
    email = excluded.email,
    attendance = excluded.attendance,
    guest_count = excluded.guest_count,
    dietary_requirements = excluded.dietary_requirements,
    message = excluded.message,
    updated_at = now()
  returning id, updated_at into v_id, v_updated_at;

  return query select v_id, v_updated_at;
end;
$$;

revoke all on function public.submit_public_rsvp(text, uuid, text, text, text, integer, text, text) from public;
grant execute on function public.submit_public_rsvp(text, uuid, text, text, text, integer, text, text) to anon, authenticated;

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists publications_touch_updated_at on public.publications;
create trigger publications_touch_updated_at
before update on public.publications
for each row execute function public.touch_updated_at();

drop trigger if exists rsvps_touch_updated_at on public.rsvps;
create trigger rsvps_touch_updated_at
before update on public.rsvps
for each row execute function public.touch_updated_at();

drop trigger if exists live_updates_touch_updated_at on public.live_updates;
create trigger live_updates_touch_updated_at
before update on public.live_updates
for each row execute function public.touch_updated_at();

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'publications'
  ) then alter publication supabase_realtime add table public.publications; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'rsvps'
  ) then alter publication supabase_realtime add table public.rsvps; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'live_updates'
  ) then alter publication supabase_realtime add table public.live_updates; end if;
end
$$;
