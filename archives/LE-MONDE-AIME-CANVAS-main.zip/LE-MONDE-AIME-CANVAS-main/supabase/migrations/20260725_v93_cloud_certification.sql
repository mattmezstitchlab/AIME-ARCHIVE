create extension if not exists pgcrypto;

create table if not exists public.projects (
  id text primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  universe text not null default 'libre',
  status text not null default 'draft',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id text not null references public.projects(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  role text not null check (role in ('editor','commenter','viewer')),
  created_at timestamptz not null default now(),
  unique(project_id, email)
);

create table if not exists public.project_snapshots (
  project_id text primary key references public.projects(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

alter table public.projects add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.projects add column if not exists updated_at timestamptz not null default now();
alter table public.project_members add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.project_snapshots add column if not exists version bigint not null default 1;
alter table public.project_snapshots add column if not exists updated_by uuid references auth.users(id) on delete set null;
alter table public.project_snapshots add column if not exists updated_at timestamptz not null default now();

create index if not exists projects_owner_updated_idx on public.projects(owner_id, updated_at desc);
create index if not exists project_members_project_idx on public.project_members(project_id);
create index if not exists project_members_user_idx on public.project_members(user_id);
create index if not exists project_members_email_lower_idx on public.project_members(lower(email));
create index if not exists project_snapshots_updated_idx on public.project_snapshots(updated_at desc);

alter table public.projects enable row level security;
alter table public.project_members enable row level security;
alter table public.project_snapshots enable row level security;

create or replace function public.can_read_project(target_project_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.projects p
    where p.id = target_project_id
      and (
        p.owner_id = auth.uid()
        or exists (
          select 1
          from public.project_members m
          where m.project_id = p.id
            and (
              m.user_id = auth.uid()
              or lower(m.email) = lower(coalesce(auth.jwt()->>'email', ''))
            )
        )
      )
  );
$$;

create or replace function public.can_edit_project(target_project_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.projects p
    where p.id = target_project_id
      and (
        p.owner_id = auth.uid()
        or exists (
          select 1
          from public.project_members m
          where m.project_id = p.id
            and m.role = 'editor'
            and (
              m.user_id = auth.uid()
              or lower(m.email) = lower(coalesce(auth.jwt()->>'email', ''))
            )
        )
      )
  );
$$;

revoke all on function public.can_read_project(text) from public;
revoke all on function public.can_edit_project(text) from public;
grant execute on function public.can_read_project(text) to authenticated;
grant execute on function public.can_edit_project(text) to authenticated;

drop policy if exists projects_select on public.projects;
create policy projects_select on public.projects
for select to authenticated
using (public.can_read_project(id));

drop policy if exists projects_insert on public.projects;
create policy projects_insert on public.projects
for insert to authenticated
with check (owner_id = auth.uid());

drop policy if exists projects_update on public.projects;
create policy projects_update on public.projects
for update to authenticated
using (public.can_edit_project(id))
with check (public.can_edit_project(id));

drop policy if exists projects_delete on public.projects;
create policy projects_delete on public.projects
for delete to authenticated
using (owner_id = auth.uid());

drop policy if exists members_select on public.project_members;
create policy members_select on public.project_members
for select to authenticated
using (public.can_read_project(project_id));

drop policy if exists members_insert on public.project_members;
create policy members_insert on public.project_members
for insert to authenticated
with check (
  exists (
    select 1 from public.projects p
    where p.id = project_id and p.owner_id = auth.uid()
  )
);

drop policy if exists members_update on public.project_members;
create policy members_update on public.project_members
for update to authenticated
using (
  exists (
    select 1 from public.projects p
    where p.id = project_id and p.owner_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from public.projects p
    where p.id = project_id and p.owner_id = auth.uid()
  )
);

drop policy if exists members_delete on public.project_members;
create policy members_delete on public.project_members
for delete to authenticated
using (
  exists (
    select 1 from public.projects p
    where p.id = project_id and p.owner_id = auth.uid()
  )
);

drop policy if exists snapshots_select on public.project_snapshots;
create policy snapshots_select on public.project_snapshots
for select to authenticated
using (public.can_read_project(project_id));

drop policy if exists snapshots_insert on public.project_snapshots;
create policy snapshots_insert on public.project_snapshots
for insert to authenticated
with check (public.can_edit_project(project_id));

drop policy if exists snapshots_update on public.project_snapshots;
create policy snapshots_update on public.project_snapshots
for update to authenticated
using (public.can_edit_project(project_id))
with check (public.can_edit_project(project_id));

drop policy if exists snapshots_delete on public.project_snapshots;
create policy snapshots_delete on public.project_snapshots
for delete to authenticated
using (public.can_edit_project(project_id));

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists projects_touch_updated_at on public.projects;
create trigger projects_touch_updated_at
before update on public.projects
for each row execute function public.touch_updated_at();

drop trigger if exists snapshots_touch_updated_at on public.project_snapshots;
create trigger snapshots_touch_updated_at
before update on public.project_snapshots
for each row execute function public.touch_updated_at();

create or replace function public.claim_project_memberships()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.email is not null then
    update public.project_members
      set user_id = new.id
      where user_id is null
        and lower(email) = lower(new.email);
  end if;
  return new;
end;
$$;

drop trigger if exists auth_user_claim_project_memberships on auth.users;
create trigger auth_user_claim_project_memberships
after insert or update of email on auth.users
for each row execute function public.claim_project_memberships();

update public.project_members m
set user_id = u.id
from auth.users u
where m.user_id is null
  and u.email is not null
  and lower(m.email) = lower(u.email);

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'project_snapshots'
  ) then
    alter publication supabase_realtime add table public.project_snapshots;
  end if;
end
$$;
