create extension if not exists pgcrypto;

create table if not exists public.projects (
  id text primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  universe text not null default 'libre',
  status text not null default 'draft',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id text not null references public.projects(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  role text not null check (role in ('editor','commenter','viewer')),
  created_at timestamptz not null default now(),
  unique(project_id, email)
);

create table if not exists public.project_snapshots (
  project_id text primary key references public.projects(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

alter table public.projects enable row level security;
alter table public.project_members enable row level security;
alter table public.project_snapshots enable row level security;

create or replace function public.can_read_project(target_project_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.projects p
    where p.id = target_project_id
      and (
        p.owner_id = auth.uid()
        or exists (
          select 1 from public.project_members m
          where m.project_id = p.id
            and (m.user_id = auth.uid() or lower(m.email) = lower(coalesce(auth.jwt()->>'email','')))
        )
      )
  );
$$;

create or replace function public.can_edit_project(target_project_id text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.projects p
    where p.id = target_project_id
      and (
        p.owner_id = auth.uid()
        or exists (
          select 1 from public.project_members m
          where m.project_id = p.id
            and m.role = 'editor'
            and (m.user_id = auth.uid() or lower(m.email) = lower(coalesce(auth.jwt()->>'email','')))
        )
      )
  );
$$;

drop policy if exists projects_select on public.projects;
create policy projects_select on public.projects for select using (public.can_read_project(id));
drop policy if exists projects_insert on public.projects;
create policy projects_insert on public.projects for insert with check (owner_id = auth.uid());
drop policy if exists projects_update on public.projects;
create policy projects_update on public.projects for update using (public.can_edit_project(id)) with check (public.can_edit_project(id));
drop policy if exists projects_delete on public.projects;
create policy projects_delete on public.projects for delete using (owner_id = auth.uid());

drop policy if exists members_select on public.project_members;
create policy members_select on public.project_members for select using (public.can_read_project(project_id));
drop policy if exists members_insert on public.project_members;
create policy members_insert on public.project_members for insert with check (exists (select 1 from public.projects p where p.id = project_id and p.owner_id = auth.uid()));
drop policy if exists members_update on public.project_members;
create policy members_update on public.project_members for update using (exists (select 1 from public.projects p where p.id = project_id and p.owner_id = auth.uid()));
drop policy if exists members_delete on public.project_members;
create policy members_delete on public.project_members for delete using (exists (select 1 from public.projects p where p.id = project_id and p.owner_id = auth.uid()));

drop policy if exists snapshots_select on public.project_snapshots;
create policy snapshots_select on public.project_snapshots for select using (public.can_read_project(project_id));
drop policy if exists snapshots_insert on public.project_snapshots;
create policy snapshots_insert on public.project_snapshots for insert with check (public.can_edit_project(project_id));
drop policy if exists snapshots_update on public.project_snapshots;
create policy snapshots_update on public.project_snapshots for update using (public.can_edit_project(project_id)) with check (public.can_edit_project(project_id));

grant execute on function public.can_read_project(text) to authenticated;
grant execute on function public.can_edit_project(text) to authenticated;

alter publication supabase_realtime add table public.project_snapshots;
