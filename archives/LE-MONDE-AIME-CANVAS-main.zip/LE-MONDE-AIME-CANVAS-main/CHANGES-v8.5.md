# LE MONDE AIME v8.5 — Architecture claire

- Interface entièrement neutralisée : gris sombre et clair, sans mauve ni bleu imposé.
- Navigation unique dans la colonne gauche ; suppression des modes dupliqués dans le header et du menu logo redondant.
- Lots de cartes affichés avec vignettes visuelles et recentrage automatique dans le canevas.
- Timeline et mini-site compactés comme plans du même canevas.
- Sélection directe permanente : cliquer un objet le sélectionne, glisser le fond déplace le canevas.
- Panneau Mini-site simplifié : configuration du site et sections, sans duplication des cartes métier.
- Première page recentrée sur « Que voulez-vous créer ? » avec modèles visuels et projets récents.
- Cartes, profils, projets et MapMonde enrichis avec des photos réelles.
- Point Zéro et cercle chromatique rendus neutres, sans bordures blanches parasites.
