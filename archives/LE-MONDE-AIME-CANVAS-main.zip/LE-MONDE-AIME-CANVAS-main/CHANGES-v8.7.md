# LE MONDE AIME v8.7 — Système unifié

- Design tokens communs pour les panneaux système.
- Agent et consentement neutralisés, statut local explicite et texte de conservation corrigé.
- Budget et Checklist reconstruits sur le même panneau graphite.
- Diagnostic Checklist présenté honnêtement comme calcul local.
- Nouveau mariage sans fuite des données de démonstration Sophie & Antoine.
- Budget initial à zéro tant qu’aucune enveloppe n’est renseignée.
- Un seul panneau de travail principal ouvert à la fois.
- Modèles, invitations et analytics clarifiés dans l’accueil.
- Accents aléatoires des nouveaux projets remplacés par une base neutre.
