# LE MONDE AIME v9.1 — AIME CORE & modules universels

- Fonction Vercel sécurisée utilisant l’API OpenAI Responses côté serveur.
- Aucune clé OpenAI exposée au navigateur.
- AIME CORE répond avec texte, confiance et propositions d’actions contrôlées.
- Chaque action doit être confirmée par un clic avant modification du projet.
- Repli automatique vers le moteur local lorsque l’agent distant n’est pas configuré ou indisponible.
- Registre de modules pour Mariage, Prestataire, Association, Événement, Portfolio, Site et Point Zéro.
- Contexte métier du module actif transmis à AIME CORE.
- Limitation de débit, validation d’origine et liste fermée des actions exécutables.
- Release candidate vérifiée par les tests du studio et le build Vite.
