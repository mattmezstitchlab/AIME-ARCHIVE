# LE MONDE AIME — Canvas universel v8.7

Studio visuel React + Vite. Le mariage reste le premier univers complet, mais le même canvas accueille aussi les projets prestataire, association, événement, site, portfolio et projet libre.

## Lancer le projet

```bash
npm install
npm run dev
```

Ouvrir l’adresse affichée par Vite, généralement `http://localhost:5173/`.

## Parcours

1. L’application s’ouvre sur le **gestionnaire de projets**.
2. Créez un univers ou ouvrez une carte existante.
3. Le projet s’ouvre dans le **même canvas universel**.
4. Revenez au gestionnaire avec le bouton Accueil en haut à gauche.

Une URL directe de projet utilise `?project=<identifiant>`. Les ancres du mini-site (`#ms-team`, par exemple) restent ainsi disponibles.

## Principes de la v8.7

- gestionnaire de projets avec recherche, tri, favoris, dossiers, archives et corbeille ;
- création par univers : mariage, événement, prestataire, association, site, portfolio ou libre ;
- cartes de rôle universelles connectables : Couple, Prestataire, Association, Artiste, Lieu et Entreprise ;
- panneau gauche **Pages / Calques / Ressources** ;
- inspecteurs contextuels à droite ;
- toolbar flottante : sélection, main, post-it, ajout, médias, style, organisation, aperçu et zoom ;
- Timeline et Mini-site restent des plans du même canvas ;
- édition directe des textes du mini-site et panneau de section à droite ;
- agent du projet avec onglet **À terminer** et actions exécutables ;
- sauvegarde immédiate dans le projet, autosauvegarde IndexedDB et état Enregistré / Sauvegarde / Erreur ;
- import/export portable `.aime.json` ;
- images importées optimisées et enregistrées avec le projet.
- protocole universel **AIME Remix** sur les plans, éléments, cartes, lots et post-it ;
- Covers Éditorial, Immersif et Essentiel sans perte du contenu source ;
- première recette portable **AIME Project DNA** ;
- généalogie, annulation et droits de remix enregistrés par projet.
- fond de canevas neutre en mode clair et sombre ;
- Point Zéro visible, déplaçable, verrouillable et persistant ;
- entrée Point Zéro pour préparer un audit URL ou inventorier un ZIP sans exécuter ses scripts ;
- cercle chromatique avec harmonies et application au canevas ou à la sélection ;
- Agent ancré comme panneau droit pleine hauteur.

Les vidéos volumineuses importées localement restent liées à la session. Pour une conservation permanente et la publication, utilisez une URL hébergée.

## Raccourcis

- `V` : sélection
- `G` : main / déplacement du canvas
- `⌘/Ctrl + S` : enregistrer maintenant
- `⌘/Ctrl + D` : dupliquer l’objet sélectionné
- `⌘/Ctrl + L` : verrouiller ou déverrouiller
- `Suppr` ou `Retour arrière` : retirer l’objet sélectionné
- `⌘/Ctrl + 1` : Canvas
- `⌘/Ctrl + 2` : Timeline
- `⌘/Ctrl + 3` : Mini-site
- `⌘/Ctrl + K` : commandes


## État réel du produit

- L’assistant actuel est un moteur local guidé : il analyse le projet, ouvre des outils et exécute certaines actions, mais aucun modèle distant n’est encore connecté.
- Les projets sont sauvegardés dans le navigateur avec `localStorage` et IndexedDB. La synchronisation multi-appareils, les comptes et la collaboration temps réel restent à connecter.
- Le déploiement Vercel publie le studio. La publication indépendante de chaque mini-site utilisateur, les domaines et les analytics réelles appartiennent au prochain moteur cloud.
- Les entrées Invitations et Analytics sont signalées **bientôt** tant que leurs services ne sont pas raccordés.
