# LE MONDE AIME v8.2 — Canvas unique et plans redimensionnables

- La Timeline et le Mini-site restent désormais montés dans le même canvas universel.
- Chaque plan peut être sélectionné, déplacé et redimensionné.
- Le Mini-site propose des formats Desktop, Tablette et iPhone directement dans son en-tête.
- La Timeline propose des formats 16:9 et carré.
- Les positions et dimensions des plans sont enregistrées par projet.
- Les commandes de navigation servent maintenant à focaliser un plan sans quitter le canvas.
- Le clic sur le plan Mini-site ouvre automatiquement son panneau d’édition.
