# Activation sécurisée de LE MONDE AIME V9.1

> Ne jamais copier une clé privée dans un ticket GitHub, une capture d’écran ou une conversation. Les valeurs sensibles doivent être saisies directement dans Supabase, Vercel ou OpenAI.

## 1. Créer et relier Supabase

1. Créer un projet Supabase.
2. Dans **Connect** ou **Settings → API Keys**, relever :
   - le **Project URL** ;
   - la **Publishable key** (`sb_publishable_…`).
3. Depuis une copie locale du dépôt :

```bash
npx supabase login
npx supabase link --project-ref VOTRE_PROJECT_REF
npx supabase db push
```

Les migrations suivantes seront appliquées :

- `supabase/migrations/20260724_v89_accounts_collaboration.sql`
- `supabase/migrations/20260724_v90_publication_rsvp_live.sql`

## 2. Configurer les redirections Auth

Dans Supabase : **Authentication → URL Configuration**.

- Site URL : `https://le-monde-aime-canvas.vercel.app`
- Redirect URL de production : `https://le-monde-aime-canvas.vercel.app/**`
- Développement local : `http://localhost:5173/**`
- Ajouter au besoin le motif de prévisualisation Vercel correspondant au compte.

## 3. Activer Supabase dans Vercel

Dans le projet Vercel : **Settings → Environment Variables**.

Ajouter pour **Production**, **Preview** et **Development** :

```text
VITE_SUPABASE_URL=<Project URL Supabase>
VITE_SUPABASE_PUBLISHABLE_KEY=<Publishable key Supabase>
```

Ne pas utiliser de Secret key ou de `service_role` dans une variable commençant par `VITE_`.

## 4. Activer AIME CORE

Créer une clé API dans le projet OpenAI destiné à LE MONDE AIME, puis ajouter dans Vercel :

```text
OPENAI_API_KEY=<clé secrète OpenAI>
OPENAI_MODEL=gpt-5
```

`OPENAI_API_KEY` reste côté serveur dans la fonction `api/agent.ts` et ne doit jamais commencer par `VITE_`.

## 5. Redéployer

Les nouvelles variables ne modifient pas les déploiements déjà construits. Dans Vercel :

1. ouvrir **Deployments** ;
2. sélectionner le dernier déploiement de `main` ;
3. choisir **Redeploy**.

## 6. Vérification fonctionnelle

### Compte et cloud

- ouvrir l’application ;
- cliquer sur **Compte** ;
- vérifier que l’état n’indique plus « Mode local » ;
- envoyer un lien de connexion ;
- synchroniser un projet ;
- se reconnecter et charger la version cloud.

### Publication

- ouvrir un projet Mariage ;
- compléter la Wedding Control Room ;
- ouvrir **Exporter** ;
- publier le mini-site ;
- ouvrir l’URL publique ;
- envoyer un RSVP ;
- vérifier la vue **Jour J Live**.

### AIME CORE

- ouvrir l’Assistant ;
- poser une demande portant sur le projet ;
- vérifier l’indication **AIME CORE · Connecté** ;
- vérifier que les actions sont proposées sous forme de boutons ;
- confirmer qu’aucune action n’est appliquée avant le clic.

## État attendu

| Fonction | Sans services externes | Après activation |
|---|---|---|
| Canvas, Timeline, Budget, Mini-site | Local | Local + cloud |
| Comptes | Désactivés | Magic link Supabase |
| Collaboration | Locale | Rôles et snapshots partagés |
| Publication | Aperçu local | URL publique persistante |
| RSVP | Navigateur local | Base Supabase |
| AIME CORE | Moteur local | Agent OpenAI côté serveur |
