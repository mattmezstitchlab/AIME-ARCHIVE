# LE MONDE AIME v8.8 — Wedding MVP

- Wedding Control Room accessible depuis Accueil dans le projet.
- Modèle canonique `WeddingProjectData` partagé par identité, lieux, invités, budget et publication.
- Indicateur de préparation calculé à partir des vraies données du projet.
- Accès direct aux actions essentielles : couple, timeline, budget, checklist, média et mini-site.
- Snapshot canonique sauvegardé localement dans `lma_wedding_project_v1`.
- Export du studio mis à niveau en version 8.8.
- Aide d’interaction simplifiée : sélection directe et déplacement du fond.
