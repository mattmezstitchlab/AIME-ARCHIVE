# LE MONDE AIME v8.7.1 — Fiabilité des projets

- Ouverture bornée : IndexedDB ne peut plus bloquer indéfiniment le studio.
- Identifiants de projet invalides renvoyés proprement vers l’accueil.
- Chargement visible et erreurs récupérables.
- Un projet s’ouvre même si le stockage secondaire est momentanément indisponible.
- Suppression du dernier fallback de démonstration « Sophie & Antoine ».
- Tests automatisés du cycle créer → sauvegarder → réhydrater.
