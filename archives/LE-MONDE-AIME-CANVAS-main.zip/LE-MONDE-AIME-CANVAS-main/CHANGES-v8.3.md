# LE MONDE AIME v8.3 — AIME Remix Protocol

## Nouveau protocole universel

- Chaque plan, section, carte de rôle, lot et post-it possède désormais un menu `•••` inspiré des studios créatifs : **Remix, Modifier, Publier, Partager, Exporter et Gérer**.
- Le menu agit sur l’objet sélectionné sans quitter le canvas unique.
- Les plans Mini-site et Timeline peuvent recevoir un **Cover** tout en conservant leurs contenus et données.
- Trois Covers sont fournis : **Éditorial**, **Immersif** et **Essentiel**, avec retour immédiat à l’original.
- Les éléments libres du canvas peuvent aussi recevoir un Cover, être prolongés, recadrés, inversés, remplacés ou utilisés comme inspiration.

## Actions réellement exécutées

- **Réutiliser la recette** copie un premier `AIME Project DNA` portable.
- **Mashup** crée une nouvelle branche visuelle dans le canvas.
- **Utiliser comme inspiration** génère une variation liée à côté de la source.
- **Prolonger / Recadrer / Inverser** transforment réellement les dimensions ou la composition.
- **Publier** met à jour le statut local du projet.
- **Partager** copie le lien de la session quand le navigateur l’autorise.
- **Exporter** produit un fichier `.aime.json` version 8.3.
- **Archiver** masque réellement l’objet sans supprimer sa source.

## Mémoire et droits

- Chaque Cover ou transformation importante est enregistré dans une **généalogie de remix**.
- La dernière transformation peut être annulée ; une branche nouvellement générée est alors retirée proprement.
- Un panneau de droits permet de régler : remixes, mashups, commentaires, usage commercial, attribution, partage du design, partage de la structure et protection des données privées.
- Les réglages et l’historique sont enregistrés par projet, inclus dans l’export et restaurés lors de l’import.

## Agent contextuel

- L’Agent propose maintenant des chips adaptées au plan ou à l’élément sélectionné : Covers, inspiration, prolongement, recadrage, export de l’ADN et droits de remix.
- Une demande comme « créer trois Covers » ouvre directement le protocole de variation du bon objet.
