# LE MONDE AIME v8.4 — Point Zéro Core

## Canevas neutralisé

- Le fond bleu historique est migré vers un gris neutre : sombre `#242426`, clair `#E8E8EA`.
- La grille de points adapte automatiquement son contraste au thème clair ou sombre.
- Les anciennes préférences personnalisées restent conservées.

## Point Zéro des Vivants

- Un repère Point Zéro est visible directement dans le canevas.
- Il peut être déplacé, verrouillé, masqué, recentré ou réinitialisé en `(0,0)`.
- Le nouveau panneau Point Zéro permet de créer un plan libre depuis l’origine.
- Une URL peut être transformée en mission d’audit documentée : EAA, EN 301 549, WCAG 2.2 AA et RGAA 4.1.2.
- Un ZIP peut être inventorié localement en quarantaine, sans exécuter ses scripts : framework, fichiers, code, médias, racines et secrets potentiels.
- Chaque mission ou import crée un artefact traçable dans le canevas.

## Cercle chromatique AIME

- Nouveau bouton circulaire arc-en-ciel dans la toolbar.
- Sélection libre d’une couleur, pipette écran et six harmonies : monochrome, analogues, complémentaire, complémentaire divisée, triade et tétrade.
- Une palette peut être appliquée au fond du canevas ou directement à l’élément libre sélectionné.

## Agent et interface droite

- L’Agent s’ouvre désormais comme un panneau droit pleine hauteur, dans l’esprit d’un inspecteur de studio.
- Il affiche le contexte actif et propose Point Zéro et les harmonies chromatiques dans ses suggestions.
- Les demandes liées à l’audit, aux ZIP, au Point Zéro ou aux palettes ouvrent les bons outils.

## Portabilité

- Export `.aime.json` mis à jour en version 8.4.
- Le Point Zéro et les rapports d’import ZIP sont persistés par projet et restaurés à l’import.

## Vérification

- Installation des dépendances et build Vite validés par GitHub Actions avant ouverture de la pull request.
