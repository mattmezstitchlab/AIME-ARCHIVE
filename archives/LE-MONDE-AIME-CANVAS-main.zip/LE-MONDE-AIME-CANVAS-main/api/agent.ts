import type { VercelRequest, VercelResponse } from '@vercel/node';
import OpenAI from 'openai';

const ALLOWED_ACTIONS = new Set([
  'open-organize', 'open-media', 'generate-minisite', 'open-minisite', 'open-publish',
  'remix-cover', 'remix-inspiration', 'remix-manage', 'open-point-zero', 'open-chromatic',
]);

const requestCounters = new Map<string, { count: number; resetAt: number }>();

function allowRequest(key: string): boolean {
  const now = Date.now();
  const current = requestCounters.get(key);
  if (!current || current.resetAt < now) {
    requestCounters.set(key, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (current.count >= 12) return false;
  current.count += 1;
  return true;
}

function cleanProposal(value: any, index: number) {
  const action = String(value?.action || '');
  const valid = ALLOWED_ACTIONS.has(action) || /^navigate-lot:\d+$/.test(action);
  if (!valid) return null;
  return {
    id: String(value?.id || `proposal-${index + 1}`),
    label: String(value?.label || 'Appliquer cette action').slice(0, 80),
    action,
    rationale: String(value?.rationale || 'Action proposée par AIME CORE.').slice(0, 220),
  };
}

function parseAgentOutput(raw: string) {
  const match = raw.match(/\{[\s\S]*\}/);
  if (!match) return { text: raw.slice(0, 4000), proposals: [], confidence: .55 };
  try {
    const parsed = JSON.parse(match[0]);
    return {
      text: String(parsed.text || raw).slice(0, 4000),
      proposals: Array.isArray(parsed.proposals) ? parsed.proposals.map(cleanProposal).filter(Boolean).slice(0, 4) : [],
      confidence: Math.max(0, Math.min(1, Number(parsed.confidence) || .65)),
    };
  } catch {
    return { text: raw.slice(0, 4000), proposals: [], confidence: .5 };
  }
}

export default async function handler(request: VercelRequest, response: VercelResponse) {
  if (request.method !== 'POST') return response.status(405).json({ error: 'Méthode non autorisée.' });
  if (!process.env.OPENAI_API_KEY) return response.status(503).json({ error: 'AIME CORE distant n’est pas encore configuré.' });

  const origin = request.headers.origin;
  const forwardedHost = String(request.headers['x-forwarded-host'] || request.headers.host || '');
  if (origin) {
    try {
      if (new URL(origin).host !== forwardedHost && !origin.startsWith('http://localhost')) return response.status(403).json({ error: 'Origine refusée.' });
    } catch { return response.status(403).json({ error: 'Origine invalide.' }); }
  }

  const clientKey = String(request.headers['x-forwarded-for'] || request.socket.remoteAddress || 'anonymous').split(',')[0].trim();
  if (!allowRequest(clientKey)) return response.status(429).json({ error: 'Trop de demandes. Réessayez dans une minute.' });

  const body = typeof request.body === 'string' ? JSON.parse(request.body) : request.body || {};
  const message = String(body.message || '').trim().slice(0, 3000);
  if (!message) return response.status(400).json({ error: 'Message manquant.' });
  const context = body.context && typeof body.context === 'object' ? body.context : {};
  const history = Array.isArray(body.history) ? body.history.slice(-12) : [];

  const instructions = `Tu es AIME CORE, l’orchestrateur d’un studio de projets vivants conçu en France.
Tu coopères mentalement avec les rôles Visionnaire, Architecte, Vérificateur, UX/UI, Développeur, Juridique et spécialiste du domaine actif.
Tu ne prétends jamais avoir exécuté une modification. Tu proposes au maximum 4 actions contrôlées, que l’utilisateur devra confirmer dans l’interface.
Tu distingues toujours ce qui est certain, probable ou à vérifier. Tu respectes la confidentialité et n’inventes ni données, ni prix, ni statut juridique.
Les seules actions autorisées sont : open-organize, open-media, generate-minisite, open-minisite, open-publish, remix-cover, remix-inspiration, remix-manage, open-point-zero, open-chromatic, navigate-lot:<numéro>.
Réponds uniquement avec un objet JSON valide :
{"text":"réponse claire en français","confidence":0.0,"proposals":[{"id":"...","label":"...","action":"...","rationale":"..."}]}`;

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  try {
    const result = await openai.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5',
      instructions,
      input: JSON.stringify({ message, context, history }),
      max_output_tokens: 1100,
    });
    const parsed = parseAgentOutput(result.output_text || '');
    return response.status(200).json({ ...parsed, source: 'aime-core' });
  } catch (error) {
    console.error('AIME CORE error', error instanceof Error ? error.message : error);
    return response.status(502).json({ error: 'AIME CORE n’a pas pu répondre. Le moteur local reste disponible.' });
  }
}
