import type { VercelRequest, VercelResponse } from '@vercel/node';

function normalizeUrl(value: string) {
  const trimmed = value.trim().replace(/^['"]|['"]$/g, '').replace(/\/+$/, '');
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' && parsed.hostname.endsWith('.supabase.co') ? trimmed : '';
  } catch {
    return '';
  }
}

function firstEnvironmentValue(names: string[]): { value: string; source: string } {
  for (const name of names) {
    const value = String(process.env[name] || '').trim().replace(/^['"]|['"]$/g, '');
    if (value) return { value, source: name };
  }
  return { value: '', source: '' };
}

function firstPublishableKey(): { value: string; source: string } {
  const direct = firstEnvironmentValue([
    'SUPABASE_PUBLISHABLE_KEY',
    'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'VITE_SUPABASE_PUBLISHABLE_KEY',
    'VITE_SUPABASE_ANON_KEY',
    'PUBLIC_SUPABASE_ANON_KEY',
  ]);
  if (direct.value) return direct;

  const plural = String(process.env.SUPABASE_PUBLISHABLE_KEYS || '').trim();
  if (plural) {
    try {
      const parsed = JSON.parse(plural) as Record<string, unknown>;
      for (const name of ['web', 'default']) {
        const value = parsed[name];
        if (typeof value === 'string' && value.trim()) return { value: value.trim(), source: `SUPABASE_PUBLISHABLE_KEYS.${name}` };
      }
      const first = Object.entries(parsed).find(([, value]) => typeof value === 'string' && value.trim());
      if (first && typeof first[1] === 'string') return { value: first[1].trim(), source: `SUPABASE_PUBLISHABLE_KEYS.${first[0]}` };
    } catch {
      // The diagnostic below will report the missing usable key.
    }
  }
  return { value: '', source: '' };
}

export default function handler(_request: VercelRequest, response: VercelResponse) {
  // Marketplace integration variables are intentionally preferred. They belong to the
  // Supabase resource explicitly connected to this Vercel project and are kept in sync.
  const urlCandidate = firstEnvironmentValue([
    'SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_URL',
    'VITE_SUPABASE_URL',
    'PUBLIC_SUPABASE_URL',
  ]);
  const keyCandidate = firstPublishableKey();

  const supabaseUrl = normalizeUrl(urlCandidate.value);
  const supabasePublishableKey = keyCandidate.value;

  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.status(200).json({
    supabaseUrl,
    supabasePublishableKey,
    supabaseConfigured: Boolean(supabaseUrl && supabasePublishableKey.length >= 20),
    openaiConfigured: Boolean(process.env.OPENAI_API_KEY),
    environment: process.env.VERCEL_ENV || 'unknown',
    urlSource: urlCandidate.source || 'missing',
    keySource: keyCandidate.source || 'missing',
  });
}
