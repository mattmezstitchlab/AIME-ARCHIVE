import type { VercelRequest, VercelResponse } from '@vercel/node';
import { Agent, request as httpsRequest } from 'node:https';

const PRODUCTION_REDIRECT_URL = 'https://app.lemondeaime.com/';
const counters = new Map<string, { count: number; resetAt: number }>();
const ipv4Agent = new Agent({ keepAlive: false, family: 4 });

function firstEnvironmentValue(names: string[]): { value: string; source: string } {
  for (const name of names) {
    const value = String(process.env[name] || '').trim().replace(/^['"]|['"]$/g, '');
    if (value) return { value, source: name };
  }
  return { value: '', source: '' };
}

function firstPublishableKey(): { value: string; source: string } {
  const direct = firstEnvironmentValue([
    'SUPABASE_PUBLISHABLE_KEY',
    'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'VITE_SUPABASE_PUBLISHABLE_KEY',
    'VITE_SUPABASE_ANON_KEY',
    'PUBLIC_SUPABASE_ANON_KEY',
  ]);
  if (direct.value) return direct;

  const plural = String(process.env.SUPABASE_PUBLISHABLE_KEYS || '').trim();
  if (plural) {
    try {
      const parsed = JSON.parse(plural) as Record<string, unknown>;
      for (const name of ['web', 'default']) {
        const value = parsed[name];
        if (typeof value === 'string' && value.trim()) return { value: value.trim(), source: `SUPABASE_PUBLISHABLE_KEYS.${name}` };
      }
      const first = Object.entries(parsed).find(([, value]) => typeof value === 'string' && value.trim());
      if (first && typeof first[1] === 'string') return { value: first[1].trim(), source: `SUPABASE_PUBLISHABLE_KEYS.${first[0]}` };
    } catch {
      // A precise configuration error is returned below.
    }
  }
  return { value: '', source: '' };
}

function normalizeUrl(value: string): string {
  const trimmed = value.trim().replace(/^['"]|['"]$/g, '').replace(/\/+$/, '');
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' && parsed.hostname.endsWith('.supabase.co') ? trimmed : '';
  } catch {
    return '';
  }
}

function allowedRedirect(value: string, requestOrigin: string): string {
  // Production Magic Links must always return to the canonical LE MONDE AIME domain,
  // even if a stale browser, preview deployment or Supabase template proposes localhost.
  if (process.env.VERCEL_ENV === 'production') return PRODUCTION_REDIRECT_URL;

  try {
    const candidate = new URL(value);
    const origin = new URL(requestOrigin);
    const allowedHost = candidate.host === origin.host
      || candidate.host === 'app.lemondeaime.com'
      || candidate.host.endsWith('.vercel.app')
      || candidate.hostname === 'localhost';
    return candidate.protocol.startsWith('http') && allowedHost ? candidate.toString() : `${origin.origin}/`;
  } catch {
    try { return `${new URL(requestOrigin).origin}/`; } catch { return PRODUCTION_REDIRECT_URL; }
  }
}

function rateLimit(key: string): boolean {
  const now = Date.now();
  const current = counters.get(key);
  if (!current || current.resetAt <= now) {
    counters.set(key, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (current.count >= 5) return false;
  current.count += 1;
  return true;
}

interface SupabaseHttpResult {
  status: number;
  body: string;
  requestId?: string;
}

function sendOtpWithHttps(url: string, publishableKey: string, email: string, redirectTo: string): Promise<SupabaseHttpResult> {
  const endpoint = new URL('/auth/v1/otp', url);
  endpoint.searchParams.set('redirect_to', redirectTo);
  const payload = JSON.stringify({ email, create_user: true });

  return new Promise((resolve, reject) => {
    const headers: Record<string, string | number> = {
      apikey: publishableKey,
      'content-type': 'application/json',
      'content-length': Buffer.byteLength(payload),
      'x-client-info': 'le-monde-aime-vercel/9.1',
    };
    if (publishableKey.startsWith('eyJ')) headers.authorization = `Bearer ${publishableKey}`;

    const request = httpsRequest(endpoint, {
      method: 'POST',
      headers,
      agent: ipv4Agent,
    }, (supabaseResponse) => {
      const chunks: Buffer[] = [];
      supabaseResponse.on('data', (chunk) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
      supabaseResponse.on('end', () => {
        resolve({
          status: supabaseResponse.statusCode || 502,
          body: Buffer.concat(chunks).toString('utf8'),
          requestId: typeof supabaseResponse.headers['x-request-id'] === 'string' ? supabaseResponse.headers['x-request-id'] : undefined,
        });
      });
    });

    request.setTimeout(12_000, () => request.destroy(Object.assign(new Error('Connexion à Supabase expirée.'), { code: 'ETIMEDOUT' })));
    request.on('error', reject);
    request.write(payload);
    request.end();
  });
}

function readableNetworkError(error: unknown, host: string): { message: string; code?: string } {
  const candidate = error as { message?: string; code?: string; cause?: { code?: string; message?: string } };
  const code = candidate?.code || candidate?.cause?.code;
  if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') return { message: `Le domaine Supabase relié à Vercel ne peut pas être résolu (${host}).`, code };
  if (code === 'ETIMEDOUT') return { message: 'La connexion entre Vercel et Supabase a expiré.', code };
  if (code === 'ECONNREFUSED') return { message: 'Supabase a refusé la connexion réseau.', code };
  if (code === 'ECONNRESET') return { message: 'La connexion à Supabase a été interrompue.', code };
  return { message: candidate?.message || candidate?.cause?.message || 'Le service de connexion ne répond pas.', code };
}

export default async function handler(request: VercelRequest, response: VercelResponse) {
  if (request.method !== 'POST') return response.status(405).json({ error: 'Méthode non autorisée.' });

  const clientKey = String(request.headers['x-forwarded-for'] || request.socket.remoteAddress || 'anonymous').split(',')[0].trim();
  if (!rateLimit(clientKey)) return response.status(429).json({ error: 'Trop de demandes. Réessayez dans une minute.' });

  let body: Record<string, unknown> = {};
  try {
    body = typeof request.body === 'string' ? JSON.parse(request.body || '{}') : request.body || {};
  } catch {
    return response.status(400).json({ error: 'Requête invalide.' });
  }
  const email = String(body.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return response.status(400).json({ error: 'Adresse e-mail invalide.' });

  // Prefer the Marketplace resource explicitly connected to this Vercel project.
  const urlCandidate = firstEnvironmentValue([
    'SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_URL',
    'VITE_SUPABASE_URL',
    'PUBLIC_SUPABASE_URL',
  ]);
  const url = normalizeUrl(urlCandidate.value);
  const publishableKeyCandidate = firstPublishableKey();
  const publishableKey = publishableKeyCandidate.value;

  if (!url) return response.status(503).json({
    error: 'Aucune ressource Supabase valide n’est connectée à ce projet Vercel.',
    urlSource: urlCandidate.source || 'missing',
  });
  if (!publishableKey) return response.status(503).json({
    error: 'La Publishable key Supabase est absente du déploiement Vercel.',
    keySource: publishableKeyCandidate.source || 'missing',
  });

  const requestOrigin = typeof request.headers.origin === 'string'
    ? request.headers.origin
    : `https://${String(request.headers['x-forwarded-host'] || request.headers.host || 'app.lemondeaime.com')}`;
  const redirectTo = allowedRedirect(String(body.redirectTo || ''), requestOrigin);

  try {
    const result = await sendOtpWithHttps(url, publishableKey, email, redirectTo);
    if (result.status < 200 || result.status >= 300) {
      let errorMessage = `Supabase a refusé la demande (${result.status}).`;
      let errorCode: string | undefined;
      try {
        const parsed = JSON.parse(result.body) as { msg?: string; message?: string; error_description?: string; error_code?: string; code?: string };
        errorMessage = parsed.msg || parsed.message || parsed.error_description || errorMessage;
        errorCode = parsed.error_code || parsed.code;
      } catch {
        if (result.body.trim()) errorMessage = result.body.trim().slice(0, 300);
      }
      return response.status(result.status).json({
        error: errorMessage,
        code: errorCode || null,
        requestId: result.requestId || null,
        urlSource: urlCandidate.source,
        keySource: publishableKeyCandidate.source,
      });
    }

    response.setHeader('Cache-Control', 'no-store, max-age=0');
    return response.status(200).json({
      ok: true,
      redirectTo,
      transport: 'node-https',
      urlSource: urlCandidate.source,
      keySource: publishableKeyCandidate.source,
    });
  } catch (error) {
    const diagnostic = readableNetworkError(error, new URL(url).hostname);
    console.error('[LMA] Magic link delivery failed', diagnostic.code || 'UNKNOWN', diagnostic.message, urlCandidate.source);
    return response.status(502).json({
      error: diagnostic.message,
      code: diagnostic.code || null,
      urlSource: urlCandidate.source,
      keySource: publishableKeyCandidate.source,
    });
  }
}
