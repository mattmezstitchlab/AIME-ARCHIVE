import { z } from "zod";
import { syncedPatternProjectSchema } from "../../shared/pattern";
import {
  deletePatternProject,
  listPatternProjects,
  listPatternVersions,
  renamePatternProject,
  upsertPatternProject,
} from "../patternDb";
import { protectedProcedure, router } from "../_core/trpc";
import { storagePut } from "../storage";

export const patternsRouter = router({
  list: protectedProcedure.query(({ ctx }) => listPatternProjects(ctx.user.id)),

  save: protectedProcedure
    .input(z.object({ project: syncedPatternProjectSchema, createVersion: z.boolean().default(true) }))
    .mutation(({ ctx, input }) => upsertPatternProject(ctx.user.id, input.project, input.createVersion)),

  uploadSource: protectedProcedure
    .input(z.object({
      clientId: z.string().min(8).max(64),
      fileName: z.string().min(1).max(255),
      mimeType: z.enum(["image/png", "image/jpeg", "image/webp", "application/pdf"]),
      base64: z.string().min(4).max(20_000_000),
    }))
    .mutation(async ({ ctx, input }) => {
      const bytes = Buffer.from(input.base64, "base64");
      if (!bytes.length || bytes.length > 12_000_000) throw new Error("La source dépasse la limite sécurisée de 12 Mo.");
      const safeName = input.fileName.normalize("NFKD").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120) || "source";
      const key = `patterns/${ctx.user.id}/${input.clientId}/${Date.now()}-${safeName}`;
      const stored = await storagePut(key, bytes, input.mimeType);
      return { key: stored.key, url: stored.url, mimeType: input.mimeType, size: bytes.length };
    }),

  rename: protectedProcedure
    .input(z.object({ clientId: z.string().min(8).max(64), name: z.string().trim().min(1).max(160) }))
    .mutation(async ({ ctx, input }) => {
      await renamePatternProject(ctx.user.id, input.clientId, input.name);
      return { success: true } as const;
    }),

  delete: protectedProcedure
    .input(z.object({ clientId: z.string().min(8).max(64) }))
    .mutation(async ({ ctx, input }) => {
      await deletePatternProject(ctx.user.id, input.clientId);
      return { success: true } as const;
    }),

  versions: protectedProcedure
    .input(z.object({ clientId: z.string().min(8).max(64) }))
    .query(({ ctx, input }) => listPatternVersions(ctx.user.id, input.clientId)),
});
