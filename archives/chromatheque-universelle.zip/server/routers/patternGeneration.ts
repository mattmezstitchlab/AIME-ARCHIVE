import { z } from "zod";
import { generateImage } from "../_core/imageGeneration";
import { protectedProcedure, router } from "../_core/trpc";

export const patternGenerationRouter = router({
  generate: protectedProcedure
    .input(z.object({
      prompt: z.string().trim().min(3).max(1200),
      width: z.number().int().min(12).max(240),
      height: z.number().int().min(12).max(240),
      maxColors: z.number().int().min(2).max(36),
    }))
    .mutation(async ({ input }) => {
      const ratio = input.width === input.height ? "square" : input.width > input.height ? "landscape" : "portrait";
      const generationPrompt = [
        "Create a clean source illustration specifically intended for deterministic conversion into a counted cross-stitch chart.",
        `Composition: ${ratio}, one centered readable subject, strong silhouette, no cropping, no frame.`,
        `Color budget: at most ${input.maxColors} visually distinct flat color regions, high separation between adjacent regions.`,
        "Rendering constraints: flat colors, minimal gradients, no photographic texture, no tiny isolated details, no dithering, no text, no letters, no symbols, no watermark, neutral light background.",
        `User subject: ${input.prompt}`,
        "The result must remain recognizable when reduced to a coarse rectangular grid.",
      ].join("\n");

      const result = await generateImage({
        prompt: generationPrompt,
        model: "MODEL_GPT_IMAGE_2",
        quality: "medium",
      });
      if (!result.url) throw new Error("La génération n’a produit aucune image exploitable.");
      return {
        url: result.url,
        model: "GPT Image 2",
        quality: "medium" as const,
      };
    }),
});
