import { and, desc, eq, max } from "drizzle-orm";
import { patternProjects, patternProjectVersions } from "../drizzle/schema";
import type { SyncedPatternProject } from "../shared/pattern";
import { getDb } from "./db";

export async function listPatternProjects(userId: number) {
  const db = await requireDb();
  return db
    .select()
    .from(patternProjects)
    .where(eq(patternProjects.userId, userId))
    .orderBy(desc(patternProjects.updatedAt));
}

export async function upsertPatternProject(
  userId: number,
  input: SyncedPatternProject,
  createVersion = true,
) {
  const db = await requireDb();
  const source = input.provenance;

  await db
    .insert(patternProjects)
    .values({
      userId,
      clientId: input.clientId,
      name: input.name,
      sourceType: source.sourceType,
      sourceName: source.sourceName,
      sourceKey: source.sourceKey,
      sourceUrl: source.sourceUrl,
      sourcePage: source.sourcePage,
      prompt: source.prompt,
      rightsConfirmedAt: source.rightsConfirmedAt ? new Date(source.rightsConfirmedAt) : null,
      provenance: input.provenance,
      document: input.document,
      conversion: input.conversion,
      printSettings: input.printSettings,
    })
    .onDuplicateKeyUpdate({
      set: {
        name: input.name,
        sourceType: source.sourceType,
        sourceName: source.sourceName,
        sourceKey: source.sourceKey,
        sourceUrl: source.sourceUrl,
        sourcePage: source.sourcePage,
        prompt: source.prompt,
        rightsConfirmedAt: source.rightsConfirmedAt ? new Date(source.rightsConfirmedAt) : null,
        provenance: input.provenance,
        document: input.document,
        conversion: input.conversion,
        printSettings: input.printSettings,
        updatedAt: new Date(),
      },
    });

  const [project] = await db
    .select()
    .from(patternProjects)
    .where(and(eq(patternProjects.userId, userId), eq(patternProjects.clientId, input.clientId)))
    .limit(1);

  if (!project) throw new Error("Projet synchronisé introuvable après enregistrement.");

  if (createVersion) {
    const [latest] = await db
      .select({ revision: max(patternProjectVersions.revision) })
      .from(patternProjectVersions)
      .where(and(eq(patternProjectVersions.userId, userId), eq(patternProjectVersions.projectId, project.id)));

    await db.insert(patternProjectVersions).values({
      projectId: project.id,
      userId,
      revision: (latest?.revision ?? 0) + 1,
      provenance: input.provenance,
      document: input.document,
      conversion: input.conversion,
      printSettings: input.printSettings,
    });
  }

  return project;
}

export async function renamePatternProject(userId: number, clientId: string, name: string) {
  const db = await requireDb();
  await db
    .update(patternProjects)
    .set({ name, updatedAt: new Date() })
    .where(and(eq(patternProjects.userId, userId), eq(patternProjects.clientId, clientId)));
}

export async function deletePatternProject(userId: number, clientId: string) {
  const db = await requireDb();
  await db
    .delete(patternProjects)
    .where(and(eq(patternProjects.userId, userId), eq(patternProjects.clientId, clientId)));
}

export async function listPatternVersions(userId: number, clientId: string) {
  const db = await requireDb();
  const [project] = await db
    .select({ id: patternProjects.id })
    .from(patternProjects)
    .where(and(eq(patternProjects.userId, userId), eq(patternProjects.clientId, clientId)))
    .limit(1);
  if (!project) return [];

  return db
    .select()
    .from(patternProjectVersions)
    .where(and(eq(patternProjectVersions.userId, userId), eq(patternProjectVersions.projectId, project.id)))
    .orderBy(desc(patternProjectVersions.revision));
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Base de données indisponible.");
  return db;
}
