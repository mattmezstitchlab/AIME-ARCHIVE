# Contrat de source — Générateur de patrons

## Principe

Le site ne prétend pas reconstruire automatiquement l’intention originale d’un créateur à partir d’une image ou d’un PDF. Il produit une **source de travail traçable, reproductible et éditable** : chaque cellule, fil, symbole et transformation doit pouvoir être inspecté dans l’Atelier.

| Élément | Exigence |
|---|---|
| Provenance | Conserver le nom du fichier ou le prompt, le type de source, la date et les paramètres de conversion. |
| Droits | Demander à l’utilisateur de confirmer qu’il dispose des droits nécessaires avant tout import. |
| Conversion | Rendre la réduction de palette, les dimensions de grille et le nettoyage déterministes pour une même source et les mêmes réglages. |
| Confettis | Définir comme confetti une composante colorée isolée inférieure ou égale au seuil choisi ; proposer son remplacement par la couleur voisine dominante, sans appliquer de suppression cachée. |
| Couleurs | Afficher les équivalences DMC comme indicatives, car la couleur écran ne garantit pas le rendu textile. |
| PDF | Convertir uniquement les pages sélectionnées en surfaces raster de travail ; ne pas présenter l’extraction comme une récupération parfaite des données originales du patron. |
| Édition | Ouvrir tout résultat dans la grille Atelier et préserver annulation, rétablissement et retouches manuelles. |
| Local | Garder les projets utilisables hors connexion et sans compte dans le stockage du navigateur. |
| Synchronisé | Après connexion, conserver les projets, versions, sources et réglages dans la bibliothèque distante de l’utilisateur. |
| Migration | Copier explicitement un projet local vers le compte sans supprimer sa copie locale. |

## Critères de qualité

Une conversion est recevable lorsque les dimensions sont explicites, que la palette ne dépasse pas la limite choisie, que chaque couleur possède un symbole distinct, que les cellules isolées sont quantifiées avant et après nettoyage, et que le résultat peut être imprimé puis édité sans dépendre du fichier source.
