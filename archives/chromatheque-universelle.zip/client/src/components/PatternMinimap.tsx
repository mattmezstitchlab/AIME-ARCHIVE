// Atlas cinétique — mini-plan de territoire : motif condensé, emprise caméra et navigation directe sans détourner le geste de dessin.

import { useMemo, useRef } from "react";
import type { DmcThread } from "@/data/dmcThreads";
import type { PatternSnapshot } from "@/lib/embroidery";

type Camera = { x: number; y: number; zoom: number };
type CanvasMetrics = { viewportWidth: number; viewportHeight: number; baseWidth: number; baseHeight: number };

type Props = {
  width: number;
  height: number;
  snapshot: PatternSnapshot;
  threadsByCode: Map<string, DmcThread>;
  camera: Camera;
  metrics: CanvasMetrics;
  onNavigate: (normalizedX: number, normalizedY: number) => void;
};

const VIEW_WIDTH = 200;
const VIEW_HEIGHT = 120;
const PADDING = 8;

export default function PatternMinimap({ width, height, snapshot, threadsByCode, camera, metrics, onNavigate }: Props) {
  const pointerId = useRef<number | null>(null);
  const bounds = useMemo(() => fitPattern(width, height), [height, width]);
  const viewport = useMemo(() => getViewport(camera, metrics), [camera, metrics]);
  const marks = useMemo(() => Object.values(snapshot).filter((mark) => mark.x >= 0 && mark.y >= 0 && mark.x < width && mark.y < height), [height, snapshot, width]);

  const navigate = (event: React.PointerEvent<SVGSVGElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const svgX = (event.clientX - rect.left) / rect.width * VIEW_WIDTH;
    const svgY = (event.clientY - rect.top) / rect.height * VIEW_HEIGHT;
    onNavigate(
      clamp((svgX - bounds.x) / bounds.width, 0, 1),
      clamp((svgY - bounds.y) / bounds.height, 0, 1),
    );
  };

  return (
    <aside className="studio-minimap" aria-label="Mini-plan interactif du patron">
      <div className="studio-minimap-heading"><span>NAV·MINI</span><strong>{width} × {height}</strong><small>CLIQUER · GLISSER</small></div>
      <svg
        viewBox={`0 0 ${VIEW_WIDTH} ${VIEW_HEIGHT}`}
        role="application"
        tabIndex={0}
        aria-label="Mini-plan du patron ; cliquer, glisser ou utiliser les flèches pour déplacer la caméra"
        onKeyDown={(event) => {
          const centerX = clamp((viewport.left + viewport.right) / 2, 0, 1);
          const centerY = clamp((viewport.top + viewport.bottom) / 2, 0, 1);
          const step = event.shiftKey ? 0.15 : 0.05;
          if (event.key === "ArrowLeft") onNavigate(centerX - step, centerY);
          else if (event.key === "ArrowRight") onNavigate(centerX + step, centerY);
          else if (event.key === "ArrowUp") onNavigate(centerX, centerY - step);
          else if (event.key === "ArrowDown") onNavigate(centerX, centerY + step);
          else if (event.key === "Home") onNavigate(0.5, 0.5);
          else return;
          event.preventDefault();
          event.stopPropagation();
        }}
        onPointerDown={(event) => {
          event.preventDefault();
          event.stopPropagation();
          pointerId.current = event.pointerId;
          event.currentTarget.setPointerCapture(event.pointerId);
          navigate(event);
        }}
        onPointerMove={(event) => {
          if (pointerId.current === event.pointerId) navigate(event);
        }}
        onPointerUp={(event) => {
          if (pointerId.current !== event.pointerId) return;
          pointerId.current = null;
          if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
        }}
        onPointerCancel={() => { pointerId.current = null; }}
      >
        <rect x={bounds.x} y={bounds.y} width={bounds.width} height={bounds.height} className="studio-minimap-ground" />
        {Array.from({ length: Math.floor(width / 5) + 1 }, (_, index) => {
          const column = Math.min(width, index * 5);
          const x = bounds.x + column / width * bounds.width;
          return <line key={`x-${column}`} x1={x} y1={bounds.y} x2={x} y2={bounds.y + bounds.height} className="studio-minimap-gridline" />;
        })}
        {Array.from({ length: Math.floor(height / 5) + 1 }, (_, index) => {
          const row = Math.min(height, index * 5);
          const y = bounds.y + row / height * bounds.height;
          return <line key={`y-${row}`} x1={bounds.x} y1={y} x2={bounds.x + bounds.width} y2={y} className="studio-minimap-gridline" />;
        })}
        {marks.map((mark) => {
          const thread = threadsByCode.get(mark.threadCode);
          return <rect key={mark.id} x={bounds.x + mark.x / width * bounds.width} y={bounds.y + mark.y / height * bounds.height} width={Math.max(0.8, bounds.width / width)} height={Math.max(0.8, bounds.height / height)} fill={thread?.hex ?? "#17211f"} />;
        })}
        <rect
          x={bounds.x + viewport.left * bounds.width}
          y={bounds.y + viewport.top * bounds.height}
          width={Math.max(3, (viewport.right - viewport.left) * bounds.width)}
          height={Math.max(3, (viewport.bottom - viewport.top) * bounds.height)}
          className="studio-minimap-viewport"
        />
        <circle cx={bounds.x + 0.5 * bounds.width} cy={bounds.y + 0.5 * bounds.height} r="1.5" className="studio-minimap-origin" />
      </svg>
      <div className="studio-minimap-coordinates"><span>X {Math.round((0.5 - camera.x / Math.max(1, metrics.baseWidth * camera.zoom)) * width)}</span><span>Y {Math.round((0.5 - camera.y / Math.max(1, metrics.baseHeight * camera.zoom)) * height)}</span><strong>{Math.round(camera.zoom * 100)}%</strong></div>
    </aside>
  );
}

function fitPattern(width: number, height: number) {
  const scale = Math.min((VIEW_WIDTH - PADDING * 2) / width, (VIEW_HEIGHT - PADDING * 2) / height);
  const fittedWidth = width * scale;
  const fittedHeight = height * scale;
  return { x: (VIEW_WIDTH - fittedWidth) / 2, y: (VIEW_HEIGHT - fittedHeight) / 2, width: fittedWidth, height: fittedHeight };
}

function getViewport(camera: Camera, metrics: CanvasMetrics) {
  if (!metrics.baseWidth || !metrics.baseHeight) return { left: 0, top: 0, right: 1, bottom: 1 };
  const halfVisibleWidth = metrics.viewportWidth / (2 * camera.zoom);
  const halfVisibleHeight = metrics.viewportHeight / (2 * camera.zoom);
  const centerX = metrics.baseWidth / 2 - camera.x / camera.zoom;
  const centerY = metrics.baseHeight / 2 - camera.y / camera.zoom;
  return {
    left: clamp((centerX - halfVisibleWidth) / metrics.baseWidth, 0, 1),
    top: clamp((centerY - halfVisibleHeight) / metrics.baseHeight, 0, 1),
    right: clamp((centerX + halfVisibleWidth) / metrics.baseWidth, 0, 1),
    bottom: clamp((centerY + halfVisibleHeight) / metrics.baseHeight, 0, 1),
  };
}

function clamp(value: number, minimum: number, maximum: number) {
  return Math.min(maximum, Math.max(minimum, value));
}
