// Atelier Atlas cinétique — canevas instrumenté, facettes visibles et symboles textiles lisibles sans dépendre de la couleur seule.

import { useEffect, useRef } from "react";
import type { GridGeometry, PatternSnapshot } from "@/lib/embroidery";
import type { DmcThread } from "@/data/dmcThreads";
import type { StitchDefinition } from "@/data/stitches";

type Props = {
  width: number;
  height: number;
  geometry: GridGeometry;
  snapshot: PatternSnapshot;
  threadsByCode: Map<string, DmcThread>;
  stitchesById: Map<string, StitchDefinition>;
  onCellAction: (x: number, y: number) => void;
  drawingEnabled?: boolean;
};

export default function EmbroideryGrid({
  width,
  height,
  geometry,
  snapshot,
  threadsByCode,
  stitchesById,
  onCellAction,
  drawingEnabled = true,
}: Props) {
  const drawing = useRef(false);
  const lastCell = useRef<string | null>(null);

  useEffect(() => {
    const stop = () => {
      drawing.current = false;
      lastCell.current = null;
    };
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
    return () => {
      window.removeEventListener("pointerup", stop);
      window.removeEventListener("pointercancel", stop);
    };
  }, []);

  const act = (x: number, y: number) => {
    const key = `${x}:${y}`;
    if (lastCell.current === key) return;
    lastCell.current = key;
    onCellAction(x, y);
  };

  const cells = [];
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const key = `${x}:${y}`;
      const mark = snapshot[key];
      const thread = mark ? threadsByCode.get(mark.threadCode) : undefined;
      const stitch = mark ? stitchesById.get(mark.stitchId) : undefined;
      cells.push(
        <button
          key={key}
          type="button"
          className={`embroidery-cell ${mark ? "is-stitched" : ""} ${x === 0 && y === 0 ? "is-origin" : ""} ${(x + 1) % 5 === 0 ? "is-major-x" : ""} ${(y + 1) % 5 === 0 ? "is-major-y" : ""}`}
          data-coordinate={`${String(x).padStart(2, "0")}:${String(y).padStart(2, "0")}`}
          style={{
            backgroundColor: thread?.hex ?? "transparent",
            color: thread ? readableText(thread.hex) : undefined,
          }}
          aria-label={mark ? `Colonne ${x + 1}, ligne ${y + 1} : ${stitch?.nameFr ?? mark.stitchId}, DMC ${mark.threadCode}` : `Colonne ${x + 1}, ligne ${y + 1} : vide`}
          onPointerDown={(event) => {
            if (!drawingEnabled) return;
            event.preventDefault();
            drawing.current = true;
            lastCell.current = null;
            act(x, y);
          }}
          onPointerEnter={() => {
            if (drawingEnabled && drawing.current) act(x, y);
          }}
          onKeyDown={(event) => {
            if (drawingEnabled && (event.key === "Enter" || event.key === " ")) {
              event.preventDefault();
              onCellAction(x, y);
            }
          }}
        >
          {mark ? <span aria-hidden="true">{stitch?.symbol ?? "×"}</span> : null}
        </button>,
      );
    }
  }

  return (
    <div className="embroidery-canvas" data-geometry={geometry}>
      <div className="grid-axis grid-axis-x" aria-hidden="true">
        {Array.from({ length: width }, (_, index) => <span key={index}>{index % 5 === 0 ? index + 1 : ""}</span>)}
      </div>
      <div className="grid-axis grid-axis-y" aria-hidden="true">
        {Array.from({ length: height }, (_, index) => <span key={index}>{index % 5 === 0 ? index + 1 : ""}</span>)}
      </div>
      <div className="grid-origin" aria-hidden="true"><span>O</span><b>00:00</b></div>
      <div
        className="embroidery-grid"
        style={{
          gridTemplateColumns: `repeat(${width}, minmax(0, 1fr))`,
          gridTemplateRows: `repeat(${height}, minmax(0, 1fr))`,
          aspectRatio: `${width} / ${height}`,
        }}
        role="grid"
        aria-label={`Grille de broderie ${width} colonnes par ${height} lignes`}
      >
        {cells}
      </div>
    </div>
  );
}

function readableText(hex: string) {
  const value = hex.replace("#", "");
  const r = Number.parseInt(value.slice(0, 2), 16);
  const g = Number.parseInt(value.slice(2, 4), 16);
  const b = Number.parseInt(value.slice(4, 6), 16);
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.58 ? "#17211f" : "#ffffff";
}
