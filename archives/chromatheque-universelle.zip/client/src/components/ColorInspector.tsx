// Atlas cinétique — la fiche sépare valeur exacte, dérivation perceptuelle, approximation d’impression et provenance.

import { Check, Clipboard, ExternalLink, Info, Printer, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Slider } from "@/components/ui/slider";
import {
  contrastRatio,
  findExactName,
  rgbToCmyk,
  rgbToHex,
  rgbToOklch,
  type RGB,
} from "@/lib/color";

type ColorInspectorProps = {
  rgb: RGB;
  previewRgb?: RGB | null;
  onChange: (rgb: RGB) => void;
};

function CopyValue({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    toast.success(`${value} copié`);
    window.setTimeout(() => setCopied(false), 1200);
  };
  return (
    <button className="copy-value" type="button" onClick={copy} aria-label={`Copier ${value}`}>
      <code>{value}</code>{copied ? <Check size={14} /> : <Clipboard size={14} />}
    </button>
  );
}

export default function ColorInspector({ rgb, previewRgb, onChange }: ColorInspectorProps) {
  const active = previewRgb ?? rgb;
  const hex = rgbToHex(active);
  const cmyk = rgbToCmyk(active);
  const oklch = rgbToOklch(active);
  const named = findExactName(hex);
  const whiteContrast = contrastRatio(active, { r: 255, g: 255, b: 255 });
  const darkContrast = contrastRatio(active, { r: 23, g: 33, b: 31 });
  const channels: Array<{ key: keyof RGB; label: string; short: string }> = [
    { key: "r", label: "Rouge", short: "R" },
    { key: "g", label: "Vert", short: "V" },
    { key: "b", label: "Bleu", short: "B" },
  ];

  const updateChannel = (key: keyof RGB, value: number[]) => onChange({ ...rgb, [key]: value[0] });

  return (
    <aside className="inspector-panel" aria-labelledby="inspector-title">
      <div className="inspector-kicker">
        <span className={`live-dot ${previewRgb ? "is-preview" : ""}`} />
        {previewRgb ? "Aperçu spatial" : "Sélection active"}
      </div>
      <div className="swatch-hero" style={{ background: hex }}>
        <span className="swatch-grid" />
        <div className="swatch-coordinate">sRGB / 24 bits</div>
      </div>

      <div className="inspector-title-row">
        <div>
          <p className="eyebrow">fiche technique</p>
          <h2 id="inspector-title">{named?.frenchName ?? named?.name ?? "Nuance sans nom normatif"}</h2>
        </div>
        {named && <span className="proof-badge"><ShieldCheck size={13} /> CSS</span>}
      </div>

      <div className="primary-values">
        <CopyValue value={hex} />
        <CopyValue value={`rgb(${active.r}, ${active.g}, ${active.b})`} />
      </div>

      <div className="metric-table">
        <div><span>Identifiant entier</span><code>{((active.r << 16) | (active.g << 8) | active.b).toLocaleString("fr-FR")}</code></div>
        <div><span>OKLCH dérivé</span><code>{oklch.l.toFixed(1)}% {oklch.c.toFixed(3)} {oklch.h.toFixed(1)}°</code></div>
        <div><span>Contraste blanc</span><code>{whiteContrast.toFixed(2)}:1</code></div>
        <div><span>Contraste graphite</span><code>{darkContrast.toFixed(2)}:1</code></div>
      </div>

      {!previewRgb && (
        <div className="channel-controls">
          <div className="section-label">Canaux RVB exacts</div>
          {channels.map((channel) => (
            <label className="channel-row" key={channel.key}>
              <span className={`channel-tag channel-${channel.key}`}>{channel.short}</span>
              <span>{channel.label}</span>
              <Slider
                min={0}
                max={255}
                step={1}
                value={[rgb[channel.key]]}
                onValueChange={(value) => updateChannel(channel.key, value)}
                aria-label={`Canal ${channel.label}`}
              />
              <input
                type="number"
                min={0}
                max={255}
                value={rgb[channel.key]}
                onChange={(event) => updateChannel(channel.key, [Math.min(255, Math.max(0, Number(event.target.value)))])}
              />
            </label>
          ))}
        </div>
      )}

      <section className="print-block">
        <div className="print-title"><Printer size={16} /><strong>Projection CMJN indicative</strong></div>
        <div className="cmyk-values">
          {Object.entries(cmyk).map(([key, value]) => <span key={key}><b>{key.toUpperCase()}</b>{value}%</span>)}
        </div>
        <p><Info size={13} /> Calcul arithmétique de repérage, sans profil ICC. Une valeur d’impression fiable dépend du procédé, du papier, des encres et du profil de destination.</p>
        <a href="https://www.color.org/" target="_blank" rel="noreferrer">Comprendre les profils ICC <ExternalLink size={12} /></a>
      </section>

      <section className="provenance-block">
        <div className="section-label">Statut du nom</div>
        {named ? (
          <p><strong>{named.name}</strong> est une entrée {named.status} du corpus {named.corpus}. L’appellation française est éditoriale lorsqu’elle diffère du mot-clé.</p>
        ) : (
          <p>Aucun mot-clé du corpus local ne correspond exactement à cette adresse. Cela ne signifie pas qu’aucun nom culturel ou commercial n’existe.</p>
        )}
      </section>
    </aside>
  );
}
