// Atlas cinétique — territoire dominant, orientation permanente, adresse octale vivante.

import { useEffect, useMemo, useState } from "react";
import { ArrowUpLeft, Crosshair, RotateCcw } from "lucide-react";
import { bestTextColor, childCenter, formatRange, prefixRange, rgbToHex, type RGB } from "@/lib/color";
import { Button } from "@/components/ui/button";

const BIT_LABELS = ["000", "001", "010", "011", "100", "101", "110", "111"];

type ChromatomeMapProps = {
  prefix: number[];
  onChange: (digits: number[]) => void;
  onPreview: (rgb: RGB | null) => void;
};

export default function ChromatomeMap({ prefix, onChange, onPreview }: ChromatomeMapProps) {
  const [focused, setFocused] = useState(0);
  const range = useMemo(() => prefixRange(prefix), [prefix]);
  const complete = prefix.length === 8;

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      if (/^[0-7]$/.test(event.key) && !complete) {
        onChange([...prefix, Number(event.key)]);
        return;
      }
      if ((event.key === "Backspace" || event.key === "Escape") && prefix.length > 0) {
        event.preventDefault();
        onChange(prefix.slice(0, -1));
        return;
      }
      if (["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp"].includes(event.key)) {
        event.preventDefault();
        const delta = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : event.key === "ArrowDown" ? 4 : -4;
        setFocused((value) => (value + delta + 8) % 8);
      }
      if ((event.key === "Enter" || event.key === " ") && !complete) {
        event.preventDefault();
        onChange([...prefix, focused]);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [complete, focused, onChange, prefix]);

  return (
    <section className="chromatome-stage" aria-labelledby="chromatome-title">
      <div className="stage-heading">
        <div>
          <p className="eyebrow"><Crosshair size={14} /> territoire adressable</p>
          <h2 id="chromatome-title">Le Chromatome</h2>
          <p className="stage-subtitle">
            {complete ? "Adresse exacte atteinte." : `Niveau ${prefix.length} sur 8 · choisissez une branche de l’espace RVB.`}
          </p>
        </div>
        <div className="stage-actions">
          <Button
            variant="outline"
            size="sm"
            className="instrument-button"
            disabled={prefix.length === 0}
            onClick={() => onChange(prefix.slice(0, -1))}
          >
            <ArrowUpLeft size={15} /> Remonter
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="instrument-button"
            disabled={prefix.length === 0}
            onClick={() => onChange([])}
          >
            <RotateCcw size={15} /> Vue globale
          </Button>
        </div>
      </div>

      <div className="address-ribbon" aria-label="Adresse octale de la couleur">
        {Array.from({ length: 8 }, (_, index) => {
          const digit = prefix[index];
          return (
            <button
              key={index}
              type="button"
              className={`address-cell ${digit !== undefined ? "is-filled" : ""}`}
              onClick={() => digit !== undefined && onChange(prefix.slice(0, index + 1))}
              aria-label={digit !== undefined ? `Revenir au niveau ${index + 1}, chiffre ${digit}` : `Niveau ${index + 1} non défini`}
            >
              <span>{index + 1}</span>
              <strong>{digit ?? "·"}</strong>
              <small>{digit !== undefined ? BIT_LABELS[digit] : "RVB"}</small>
            </button>
          );
        })}
      </div>

      <div className="range-line">
        <span>Emprise active</span>
        <code>{formatRange(range.min, range.max)}</code>
        <span>{Math.pow(8, 8 - prefix.length).toLocaleString("fr-FR")} adresse{prefix.length === 8 ? "" : "s"}</span>
      </div>

      {complete ? (
        <div
          className="exact-color-field"
          style={{ background: rgbToHex(range.center), color: bestTextColor(range.center) }}
          role="img"
          aria-label={`Couleur exacte ${rgbToHex(range.center)}`}
        >
          <div className="exact-crosshair" />
          <p>Adresse complète</p>
          <strong>{rgbToHex(range.center)}</strong>
          <code>octal {prefix.join("")}</code>
        </div>
      ) : (
        <div className="octant-grid" role="grid" aria-label={`Huit branches du niveau ${prefix.length + 1}`}>
          {Array.from({ length: 8 }, (_, digit) => {
            const center = childCenter(prefix, digit);
            const child = prefixRange([...prefix, digit]);
            const color = rgbToHex(center);
            return (
              <button
                key={digit}
                type="button"
                role="gridcell"
                tabIndex={focused === digit ? 0 : -1}
                className={`octant-cell octant-${digit} ${focused === digit ? "is-focused" : ""}`}
                style={{ background: color, color: bestTextColor(center) }}
                onFocus={() => setFocused(digit)}
                onMouseEnter={() => onPreview(center)}
                onMouseLeave={() => onPreview(null)}
                onClick={() => onChange([...prefix, digit])}
                aria-label={`Branche ${digit}, bits RVB ${BIT_LABELS[digit]}, ${formatRange(child.min, child.max)}`}
              >
                <span className="octant-index">0{digit}</span>
                <span className="octant-bits">RVB {BIT_LABELS[digit]}</span>
                <strong>{color}</strong>
                <small>{formatRange(child.min, child.max)}</small>
              </button>
            );
          })}
          <div className="map-reticle" aria-hidden="true"><span /><span /></div>
        </div>
      )}

      <footer className="stage-legend">
        <span><kbd>0–7</kbd> choisir</span>
        <span><kbd>←↑↓→</kbd> orienter</span>
        <span><kbd>Entrée</kbd> valider</span>
        <span><kbd>Échap</kbd> remonter</span>
      </footer>
    </section>
  );
}
