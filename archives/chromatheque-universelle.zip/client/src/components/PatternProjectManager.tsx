import { useMemo, useState } from "react";
import { Check, Cloud, CloudUpload, FolderOpen, LogIn, Pencil, Plus, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { deleteProjectSource, getProjectSource } from "@/lib/patternSourceStore";
import {
  deleteLocalProject,
  renameLocalProject,
  saveLocalProject,
  type LocalPatternProject,
} from "@/lib/patternLibrary";
import { syncedPatternProjectSchema, type SyncedPatternProject } from "@shared/pattern";

type Props = {
  open: boolean;
  activeId: string;
  currentProject: SyncedPatternProject;
  localProjects: LocalPatternProject[];
  onClose: () => void;
  onCreate: () => void;
  onLoad: (project: SyncedPatternProject) => void;
  onRefresh: () => void;
};

export default function PatternProjectManager({
  open,
  activeId,
  currentProject,
  localProjects,
  onClose,
  onCreate,
  onLoad,
  onRefresh,
}: Props) {
  const { isAuthenticated, user, loading } = useAuth();
  const utils = trpc.useUtils();
  const cloudQuery = trpc.patterns.list.useQuery(undefined, { enabled: isAuthenticated, retry: false });
  const saveMutation = trpc.patterns.save.useMutation();
  const uploadSourceMutation = trpc.patterns.uploadSource.useMutation();
  const renameCloudMutation = trpc.patterns.rename.useMutation();
  const deleteCloudMutation = trpc.patterns.delete.useMutation();
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");

  const cloudProjects = useMemo(() => (cloudQuery.data ?? []).map(row => {
    const document = row.document as Record<string, unknown> | null;
    const parsed = syncedPatternProjectSchema.safeParse({
      clientId: row.clientId,
      name: row.name,
      document: row.document,
      conversion: row.conversion,
      printSettings: row.printSettings,
      provenance: row.provenance ?? {
        sourceType: row.sourceType,
        sourceName: row.sourceName,
        sourceKey: row.sourceKey,
        sourceUrl: row.sourceUrl,
        sourceMimeType: null,
        sourceSize: null,
        sourcePage: row.sourcePage,
        prompt: row.prompt,
        rightsConfirmedAt: row.rightsConfirmedAt?.toISOString() ?? null,
        transformations: [],
      },
    });
    return parsed.success ? parsed.data : null;
  }).filter((project): project is SyncedPatternProject => Boolean(project)), [cloudQuery.data]);

  if (!open) return null;

  const syncCurrent = async () => {
    let project = currentProject;
    const localSource = await getProjectSource(activeId);
    if (localSource && !project.provenance.sourceUrl) {
      const uploaded = await uploadSourceMutation.mutateAsync({
        clientId: activeId,
        fileName: localSource.file.name,
        mimeType: normalizeSourceMime(localSource.file),
        base64: await fileToBase64(localSource.file),
      });
      project = {
        ...project,
        provenance: {
          ...project.provenance,
          sourceKey: uploaded.key,
          sourceUrl: uploaded.url,
          sourceMimeType: uploaded.mimeType,
          sourceSize: uploaded.size,
        },
      };
    }
    await saveMutation.mutateAsync({ project, createVersion: true });
    saveLocalProject(project, "synced");
    onLoad(project);
    onRefresh();
    await utils.patterns.list.invalidate();
    toast.success("Projet synchronisé", { description: localSource ? "Le patron et sa source sont archivés ; la copie locale reste disponible." : "Le patron est synchronisé ; aucune source locale n’était associée." });
  };

  const commitRename = async (project: LocalPatternProject) => {
    const name = renameValue.trim();
    if (!name) return;
    renameLocalProject(project.clientId, name);
    if (project.syncState === "synced" && isAuthenticated) {
      await renameCloudMutation.mutateAsync({ clientId: project.clientId, name });
      await utils.patterns.list.invalidate();
    }
    setRenamingId(null);
    onRefresh();
  };

  const removeProject = async (project: LocalPatternProject) => {
    if (!window.confirm(`Supprimer « ${project.name} » de cet appareil${project.syncState === "synced" ? " et de la bibliothèque synchronisée" : ""} ?`)) return;
    deleteLocalProject(project.clientId);
    await deleteProjectSource(project.clientId).catch(() => undefined);
    if (project.syncState === "synced" && isAuthenticated) {
      await deleteCloudMutation.mutateAsync({ clientId: project.clientId });
      await utils.patterns.list.invalidate();
    }
    onRefresh();
  };

  return (
    <div className="project-manager-backdrop" role="presentation" onPointerDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <aside className="project-manager" aria-label="Bibliothèque de patrons" aria-modal="true" role="dialog">
        <header>
          <div><span>REGISTRE · PATRONS</span><h2>Bibliothèque</h2></div>
          <button type="button" onClick={onClose} aria-label="Fermer la bibliothèque"><X size={17} /></button>
        </header>

        <div className="project-manager-actions">
          <Button type="button" onClick={onCreate}><Plus size={15} /> Nouveau patron</Button>
          <Button type="button" variant="outline" onClick={() => void syncCurrent()} disabled={!isAuthenticated || saveMutation.isPending || uploadSourceMutation.isPending}>
            <CloudUpload size={15} /> {saveMutation.isPending || uploadSourceMutation.isPending ? "Synchronisation…" : "Synchroniser l’actuel"}
          </Button>
        </div>

        <section className="project-library-section">
          <div className="project-section-heading"><span>LOCAL · {localProjects.length}</span><small>Disponible sans connexion</small></div>
          <div className="project-list">
            {localProjects.map(project => (
              <article key={project.clientId} className={project.clientId === activeId ? "is-active" : ""}>
                <button type="button" className="project-open" onClick={() => onLoad(project)}>
                  <FolderOpen size={15} /><span><strong>{project.name}</strong><small>{project.document.dimensions.width} × {project.document.dimensions.height} · {new Date(project.updatedAt).toLocaleDateString("fr-FR")}</small></span>
                </button>
                <span className={`project-sync-state is-${project.syncState}`}>{project.syncState === "synced" ? <><Check size={11} /> synchronisé</> : project.syncState === "pending" ? "à synchroniser" : "local"}</span>
                {renamingId === project.clientId ? (
                  <form onSubmit={event => { event.preventDefault(); void commitRename(project); }}><input autoFocus value={renameValue} onChange={event => setRenameValue(event.target.value)} aria-label="Nouveau nom" /><button type="submit"><Check size={14} /></button></form>
                ) : (
                  <div className="project-row-actions"><button type="button" onClick={() => { setRenamingId(project.clientId); setRenameValue(project.name); }} aria-label={`Renommer ${project.name}`}><Pencil size={13} /></button><button type="button" onClick={() => void removeProject(project)} aria-label={`Supprimer ${project.name}`}><Trash2 size={13} /></button></div>
                )}
              </article>
            ))}
            {!localProjects.length && <p className="project-empty">Aucun patron local. Créez-en un ou importez une source depuis l’accueil.</p>}
          </div>
        </section>

        <section className="project-library-section project-cloud-section">
          <div className="project-section-heading"><span>NUAGE · {cloudProjects.length}</span><small>{isAuthenticated ? user?.name ?? "Compte connecté" : "Connexion requise"}</small></div>
          {!isAuthenticated ? (
            <div className="project-login"><Cloud size={22} /><p>Connectez-vous pour retrouver vos patrons et leurs versions sur plusieurs appareils.</p><Button type="button" onClick={() => startLogin()} disabled={loading}><LogIn size={15} /> Se connecter</Button></div>
          ) : (
            <div className="project-list cloud-project-list">
              {cloudProjects.map(project => (
                <article key={project.clientId} className={project.clientId === activeId ? "is-active" : ""}>
                  <button type="button" className="project-open" onClick={() => { saveLocalProject(project, "synced"); onRefresh(); onLoad(project); }}><Cloud size={15} /><span><strong>{project.name}</strong><small>{project.document.dimensions.width} × {project.document.dimensions.height} · version synchronisée</small></span></button>
                </article>
              ))}
              {cloudQuery.isLoading && <p className="project-empty">Lecture de la bibliothèque…</p>}
              {!cloudQuery.isLoading && !cloudProjects.length && <p className="project-empty">Aucun patron synchronisé pour ce compte.</p>}
            </div>
          )}
        </section>
      </aside>
    </div>
  );
}

function normalizeSourceMime(file: File): "image/png" | "image/jpeg" | "image/webp" | "application/pdf" {
  if (file.type === "image/jpeg" || file.type === "image/webp" || file.type === "application/pdf") return file.type;
  return "image/png";
}

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error ?? new Error("Source locale illisible"));
    reader.onload = () => {
      const value = String(reader.result ?? "");
      resolve(value.slice(value.indexOf(",") + 1));
    };
    reader.readAsDataURL(file);
  });
}
