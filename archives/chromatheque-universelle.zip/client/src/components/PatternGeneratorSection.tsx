import { useRef, useState } from "react";
import { ArrowRight, FileImage, FileText, ImagePlus, Loader2, ShieldCheck, WandSparkles, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { queuePatternIntake } from "@/lib/patternIntakeQueue";

export default function PatternGeneratorSection() {
  const fileInput = useRef<HTMLInputElement>(null);
  const [prompt, setPrompt] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [settings, setSettings] = useState({ targetWidth: 60, targetHeight: 60, maxColors: 16, confettiThreshold: 2 });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!prompt.trim() && !file) {
      toast.error("Ajoutez une instruction ou une source", { description: "Décrivez le motif souhaité, ou choisissez une image ou un PDF." });
      return;
    }
    if (file && !rightsConfirmed) {
      toast.error("Confirmation requise", { description: "Confirmez que vous êtes autorisé à convertir cette source." });
      return;
    }
    setBusy(true);
    try {
      await queuePatternIntake({
        kind: file ? "file" : "prompt",
        prompt: prompt.trim() || null,
        fileName: file?.name ?? null,
        fileType: file?.type ?? null,
        rightsConfirmedAt: new Date().toISOString(),
        ...settings,
      }, file ?? undefined);
      window.location.href = "/atelier?intake=1";
    } catch {
      toast.error("Préparation impossible", { description: "Le navigateur n’a pas pu conserver cette source localement." });
      setBusy(false);
    }
  };

  const chooseFile = (selected: File | null) => {
    if (!selected) return;
    const isImage = selected.type.startsWith("image/");
    const isPdf = selected.type === "application/pdf" || selected.name.toLowerCase().endsWith(".pdf");
    if (!isImage && !isPdf) {
      toast.error("Format non pris en charge", { description: "Utilisez une image PNG, JPEG ou WebP, ou un document PDF." });
      return;
    }
    if (selected.size > 25 * 1024 * 1024) {
      toast.error("Fichier trop volumineux", { description: "La limite locale est de 25 Mo par source." });
      return;
    }
    setFile(selected);
    setRightsConfirmed(false);
  };

  return (
    <section className="pattern-generator-section" id="generateur">
      <div className="pattern-generator-intro">
        <p className="eyebrow"><WandSparkles size={14} /> atelier génératif · source contrôlée</p>
        <h2>De l’idée ou du document<br /><em>à la grille brodable.</em></h2>
        <p>Décrivez un motif, importez une image ou préparez un PDF de patron. La conversion produit des cases éditables, une palette indicative et un journal des transformations — jamais une boîte noire présentée comme infaillible.</p>
        <div className="pattern-generator-proof"><span>A</span><strong>Source conservée</strong><small>nom, page et paramètres</small><span>M</span><strong>Nettoyage mesuré</strong><small>confettis avant / après</small><span>N</span><strong>Résultat éditable</strong><small>chaque case reste modifiable</small></div>
      </div>

      <form className="pattern-generator-console" onSubmit={submit}>
        <div className="generator-console-head"><span>CONSOLE · PATRON</span><small>LOCAL D’ABORD</small></div>
        <label className="generator-prompt"><span>Instruction</span><textarea value={prompt} onChange={event => setPrompt(event.target.value)} placeholder="Ex. Un martin-pêcheur géométrique, 60 × 60 cases, 14 couleurs, fond clair, détails lisibles au point de croix…" rows={5} /></label>
        <div className="generator-or"><i />ou partir d’une source<i /></div>
        <input ref={fileInput} type="file" accept="image/png,image/jpeg,image/webp,application/pdf,.pdf" hidden onChange={event => chooseFile(event.target.files?.[0] ?? null)} />
        {!file ? (
          <button type="button" className="generator-dropzone" onClick={() => fileInput.current?.click()} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); chooseFile(event.dataTransfer.files[0] ?? null); }}>
            <ImagePlus size={22} /><strong>Image ou PDF</strong><small>PNG · JPEG · WebP · PDF · 25 Mo max.</small>
          </button>
        ) : (
          <div className="generator-file"><span>{file.type === "application/pdf" ? <FileText size={20} /> : <FileImage size={20} />}</span><div><strong>{file.name}</strong><small>{(file.size / 1024 / 1024).toFixed(1)} Mo · conservé localement</small></div><button type="button" onClick={() => { setFile(null); setRightsConfirmed(false); if (fileInput.current) fileInput.current.value = ""; }} aria-label="Retirer la source"><X size={15} /></button></div>
        )}

        <div className="generator-settings">
          <label><span>Largeur</span><input type="number" min={12} max={240} value={settings.targetWidth} onChange={event => setSettings(current => ({ ...current, targetWidth: clamp(Number(event.target.value), 12, 240) }))} /><small>cases</small></label>
          <label><span>Hauteur</span><input type="number" min={12} max={240} value={settings.targetHeight} onChange={event => setSettings(current => ({ ...current, targetHeight: clamp(Number(event.target.value), 12, 240) }))} /><small>cases</small></label>
          <label><span>Palette</span><input type="number" min={2} max={36} value={settings.maxColors} onChange={event => setSettings(current => ({ ...current, maxColors: clamp(Number(event.target.value), 2, 36) }))} /><small>couleurs max.</small></label>
          <label><span>Confettis</span><input type="number" min={0} max={8} value={settings.confettiThreshold} onChange={event => setSettings(current => ({ ...current, confettiThreshold: clamp(Number(event.target.value), 0, 8) }))} /><small>voisins min.</small></label>
        </div>

        {file && <label className="generator-rights"><input type="checkbox" checked={rightsConfirmed} onChange={event => setRightsConfirmed(event.target.checked)} /><ShieldCheck size={16} /><span>Je confirme disposer des droits nécessaires pour convertir et utiliser ce fichier.</span></label>}
        <div className="generator-submit"><div><strong>{file ? "CONVERSION LOCALE" : "GÉNÉRATION ASSISTÉE"}</strong><small>{file ? "La source ne sera synchronisée qu’à votre demande." : "Le visuel généré sera ensuite converti par le même moteur déterministe."}</small></div><Button type="submit" disabled={busy || (Boolean(file) && !rightsConfirmed)}>{busy ? <Loader2 className="animate-spin" size={16} /> : <WandSparkles size={16} />}{busy ? "Préparation…" : "Ouvrir dans l’Atelier"}<ArrowRight size={15} /></Button></div>
      </form>
    </section>
  );
}

function clamp(value: number, min: number, max: number) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}
