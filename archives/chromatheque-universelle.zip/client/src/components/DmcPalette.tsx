// Atlas cinétique — registre horizontal DMC, mesuré et traçable ; la couleur écran reste explicitement indicative.

import { useMemo, useState } from "react";
import { ExternalLink, Search } from "lucide-react";
import { DMC_SOURCE, dmcThreads, type DmcThread } from "@/data/dmcThreads";

type Props = {
  selectedCode: string;
  onSelect: (thread: DmcThread) => void;
};

export default function DmcPalette({ selectedCode, onSelect }: Props) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("fr");
    if (!needle) return dmcThreads;
    return dmcThreads.filter((thread) => `${thread.code} ${thread.name}`.toLocaleLowerCase("fr").includes(needle));
  }, [query]);

  return (
    <section className="studio-dmc-dock" aria-labelledby="dmc-heading">
      <div className="studio-dmc-heading">
        <div><span className="studio-dock-label">FILS DMC · CORPUS</span><strong id="dmc-heading">{filtered.length.toLocaleString("fr-FR")}</strong></div>
        <i className="studio-panel-index" aria-hidden="true">D·456</i>
        <label className="studio-dmc-search">
          <Search size={14} />
          <span className="sr-only">Rechercher un code ou un nom DMC</span>
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Code ou nom…" />
        </label>
        <p><b>C</b> corpus secondaire · <b>A</b> approximation écran</p>
        <a href={DMC_SOURCE.officialCardUrl} target="_blank" rel="noreferrer">Carte physique <ExternalLink size={11} /></a>
      </div>

      <div className="studio-thread-strip" role="listbox" aria-label="Fils DMC disponibles">
        {filtered.map((thread) => (
          <button
            type="button"
            role="option"
            aria-selected={thread.code === selectedCode}
            className={`studio-thread-chip ${thread.code === selectedCode ? "is-active" : ""}`}
            key={thread.code}
            onClick={() => onSelect(thread)}
            title={`${thread.code} — ${thread.name} · valeur écran indicative`}
          >
            <span className="studio-thread-swatch" style={{ background: thread.hex }} aria-hidden="true" />
            <span><strong>{thread.code}</strong><small>{thread.name}</small></span>
            <b aria-hidden="true">A</b>
          </button>
        ))}
      </div>
    </section>
  );
}
