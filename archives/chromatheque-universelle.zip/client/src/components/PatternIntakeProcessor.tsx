import { useEffect, useState } from "react";
import { CheckCircle2, FileImage, FileText, Loader2, ShieldCheck, WandSparkles, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { convertFileToPattern, inspectPdf, type ConvertedPattern } from "@/lib/imagePatternConversion";
import { clearPatternIntake, consumePatternIntake, type PatternIntakeRequest } from "@/lib/patternIntakeQueue";

type PendingIntake = PatternIntakeRequest & { file: File | null };

type Props = {
  onApply: (result: ConvertedPattern, request: PatternIntakeRequest, sourceFile: File | null) => Promise<void> | void;
  onPromptGenerate?: (request: PatternIntakeRequest) => Promise<ConvertedPattern>;
};

export default function PatternIntakeProcessor({ onApply, onPromptGenerate }: Props) {
  const [request, setRequest] = useState<PendingIntake | null>(null);
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ConvertedPattern | null>(null);
  const [settings, setSettings] = useState({ width: 60, height: 60, maxColors: 16 });

  useEffect(() => {
    void consumePatternIntake().then(pending => {
      if (!pending) return;
      setRequest(pending);
      setSettings({ width: pending.targetWidth, height: pending.targetHeight, maxColors: pending.maxColors });
      if (pending.file && isPdf(pending.file)) {
        void inspectPdf(pending.file).then(info => setPageCount(info.pageCount)).catch(() => toast.error("PDF illisible", { description: "Le document ne peut pas être rendu dans ce navigateur." }));
      }
    });
  }, []);

  if (!request) return null;

  const dismiss = async () => {
    await clearPatternIntake(request.id);
    setRequest(null);
    window.history.replaceState({}, "", "/atelier");
  };

  const updateSetting = (key: keyof typeof settings, value: number, min: number, max: number) => {
    setResult(null);
    setSettings(current => ({ ...current, [key]: clamp(value, min, max) }));
  };

  const process = async () => {
    setBusy(true);
    try {
      const converted = request.file
        ? await convertFileToPattern(request.file, { ...settings, pdfPage: page, confettiThreshold: request.confettiThreshold })
        : onPromptGenerate
          ? await onPromptGenerate({ ...request, targetWidth: settings.width, targetHeight: settings.height, maxColors: settings.maxColors })
          : null;
      if (!converted) throw new Error("Génération indisponible");
      setResult(converted);
      toast.success("Conversion prête à vérifier", { description: `${converted.palette.length} couleurs · ${converted.cleanup.replaced} confetti${converted.cleanup.replaced > 1 ? "s" : ""} réaffecté${converted.cleanup.replaced > 1 ? "s" : ""}.` });
    } catch (error) {
      toast.error("Conversion impossible", { description: error instanceof Error ? error.message : "La source n’a pas pu être convertie." });
    } finally {
      setBusy(false);
    }
  };

  const apply = async () => {
    if (!result) return;
    await onApply(result, { ...request, targetWidth: settings.width, targetHeight: settings.height, maxColors: settings.maxColors }, request.file);
    await dismiss();
    toast.success("Patron placé dans l’Atelier", { description: `${result.width} × ${result.height} cases, entièrement éditables.` });
  };

  return (
    <div className="intake-backdrop" role="presentation">
      <section className="intake-panel" role="dialog" aria-modal="true" aria-labelledby="intake-title">
        <header><div><span>SOURCE · {request.kind === "prompt" ? "GÉNÉRATION" : isPdf(request.file) ? "PDF" : "IMAGE"}</span><h2 id="intake-title">Préparer le patron</h2></div><button type="button" onClick={() => void dismiss()} aria-label="Fermer"><X size={17} /></button></header>
        <div className="intake-source">
          <i>{request.kind === "prompt" ? <WandSparkles /> : isPdf(request.file) ? <FileText /> : <FileImage />}</i>
          <div><strong>{request.fileName ?? "Instruction générative"}</strong><p>{request.prompt || "Conversion locale de la source sélectionnée."}</p></div>
          <b><ShieldCheck size={13} /> droits confirmés</b>
        </div>

        {pageCount && pageCount > 1 && <label className="intake-page"><span>Page à convertir</span><input type="number" min={1} max={pageCount} value={page} onChange={event => { setResult(null); setPage(clamp(Number(event.target.value), 1, pageCount)); }} /><small>/ {pageCount}</small></label>}

        <div className="intake-settings">
          <label><span>Largeur</span><input type="number" min={12} max={240} value={settings.width} onChange={event => updateSetting("width", Number(event.target.value), 12, 240)} /><small>cases</small></label>
          <label><span>Hauteur</span><input type="number" min={12} max={240} value={settings.height} onChange={event => updateSetting("height", Number(event.target.value), 12, 240)} /><small>cases</small></label>
          <label><span>Palette</span><input type="number" min={2} max={36} value={settings.maxColors} onChange={event => updateSetting("maxColors", Number(event.target.value), 2, 36)} /><small>couleurs max.</small></label>
        </div>

        {result && <section className="intake-result" aria-label="Résultat de la conversion">
          <div className="intake-preview"><img src={result.previewDataUrl} alt="Aperçu de la source convertie" /><span>{result.width} × {result.height} cases</span></div>
          <div className="intake-audit"><span>NETTOYAGE</span><strong>{result.cleanup.replaced} cellules réaffectées</strong><small>{result.cleanup.before} confettis détectés · {result.cleanup.after} restant{result.cleanup.after > 1 ? "s" : ""}</small></div>
          <div className="intake-palette" aria-label={`${result.palette.length} références DMC indicatives`}>
            {result.palette.slice(0, 24).map(thread => <i key={thread.code} style={{ background: thread.hex }} title={`DMC ${thread.code} · ${thread.name} · ${thread.cells} cases`}><span>{thread.code}</span></i>)}
          </div>
        </section>}

        <div className="intake-notice"><strong>Source de vérité</strong><p>La conversion conserve le nom, la page et les réglages. Les références DMC sont des correspondances écran indicatives ; chaque case reste éditable avant impression.</p></div>
        <footer><button type="button" className="intake-cancel" onClick={() => void dismiss()}>Annuler</button>{result ? <Button type="button" onClick={() => void apply()}><CheckCircle2 size={16} />Appliquer à la grille</Button> : <Button type="button" onClick={() => void process()} disabled={busy || (request.kind === "prompt" && !onPromptGenerate)}>{busy ? <Loader2 className="animate-spin" size={16} /> : <WandSparkles size={16} />}{busy ? "Conversion…" : request.kind === "prompt" ? "Générer et convertir" : "Analyser et convertir"}</Button>}</footer>
      </section>
    </div>
  );
}

function isPdf(file: File | null) {
  return Boolean(file && (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")));
}

function clamp(value: number, min: number, max: number) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}
