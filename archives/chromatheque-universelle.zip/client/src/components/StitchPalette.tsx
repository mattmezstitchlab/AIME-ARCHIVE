// Atlas cinétique — bande documentaire de spécimens numérotés, compacte et instrumentale au-dessus du canevas.

import { useMemo, useState } from "react";
import { ExternalLink } from "lucide-react";
import { stitchFamilies, stitches, type StitchDefinition } from "@/data/stitches";

type Props = {
  selectedId: string;
  onSelect: (stitch: StitchDefinition) => void;
};

export default function StitchPalette({ selectedId, onSelect }: Props) {
  const [family, setFamily] = useState("Tous");
  const filtered = useMemo(
    () => family === "Tous" ? stitches : stitches.filter((stitch) => stitch.family === family),
    [family],
  );
  const active = stitches.find((stitch) => stitch.id === selectedId) ?? stitches[0];

  return (
    <section className="studio-stitch-ribbon" aria-labelledby="stitch-heading">
      <div className="studio-stitch-heading">
        <div><span>POINTS · CORPUS</span><strong id="stitch-heading">{stitches.length}</strong></div>
        <i className="studio-panel-index" aria-hidden="true">S·24</i>
        <label>
          <span className="sr-only">Filtrer les points par famille</span>
          <select value={family} onChange={(event) => setFamily(event.target.value)}>
            <option>Tous</option>
            {stitchFamilies.map((item) => <option key={item}>{item}</option>)}
          </select>
        </label>
      </div>

      <div className="studio-stitch-strip" role="listbox" aria-label="Points de broderie disponibles">
        {filtered.map((stitch, index) => (
          <button
            type="button"
            role="option"
            aria-selected={stitch.id === selectedId}
            className={`studio-stitch-chip ${stitch.id === selectedId ? "is-active" : ""}`}
            key={stitch.id}
            onClick={() => onSelect(stitch)}
            title={`${stitch.nameFr} · ${stitch.culture} · point sourcé`}
          >
            <span aria-hidden="true">{stitch.symbol}</span>
            <span><strong>{stitch.nameFr}</strong><small>{String(index + 1).padStart(2, "0")} · {stitch.family}</small></span>
            <b>N</b>
          </button>
        ))}
      </div>

      <a className="studio-active-source" href={active.sourceUrl} target="_blank" rel="noreferrer" title={`Source de ${active.nameFr}`}>
        <small>SOURCE ACTIVE</small><span>{active.culture}</span><ExternalLink size={11} />
      </a>
    </section>
  );
}
