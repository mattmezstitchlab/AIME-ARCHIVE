// Atlas cinétique — les traces historiques sont des dossiers sourcés, jamais des « couleurs secrètes » affirmées sans preuve.

import { ArrowUpRight, FlaskConical, Library, SearchCheck } from "lucide-react";
import { archiveRecords } from "@/data/colorCorpus";

export default function ResearchArchive() {
  return (
    <section className="archive-section" id="archives" aria-labelledby="archive-title">
      <div className="archive-image" aria-hidden="true">
        <img src="/manus-storage/pigment-archive_6aae2dc5.png" alt="" />
        <div className="image-index">PLANCHE 03 / MATIÈRES</div>
      </div>
      <div className="archive-content">
        <div className="archive-heading">
          <div>
            <p className="eyebrow"><Library size={14} /> enquête patrimoniale</p>
            <h2 id="archive-title">Chercher les traces,<br />pas fabriquer des mystères.</h2>
          </div>
          <p>
            Une couleur numérique est une adresse. Un pigment historique est une matière, un procédé et un contexte. La Chromathèque relie ces objets sans prétendre les confondre.
          </p>
        </div>

        <div className="proof-legend" aria-label="Légende des statuts documentaires">
          <span><b>N</b> norme</span>
          <span><b>A</b> archive</span>
          <span><b>M</b> mesure</span>
          <span><b>C</b> controverse</span>
          <small>Chaque balise précise la nature de la preuve, pas la beauté de la couleur.</small>
        </div>

        <div className="archive-records">
          {archiveRecords.map((record, index) => (
            <article className="archive-card" key={record.title}>
              <div className="record-number">0{index + 1}</div>
              <div className="record-swatch" style={{ background: record.displayHex }}>
                <span>{record.displayHex}</span>
              </div>
              <div className="record-body">
                <div className="record-meta">
                  <span><b className="proof-letter">A</b><FlaskConical size={12} /> {record.kind}</span>
                  <span>CONFIANCE {record.confidence}</span>
                </div>
                <h3>{record.title}</h3>
                <p className="record-subtitle">{record.subtitle} · {record.period}</p>
                <p>{record.note}</p>
                <a href={record.sourceUrl} target="_blank" rel="noreferrer">
                  {record.sourceLabel} <ArrowUpRight size={13} />
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="archive-manifesto">
          <SearchCheck size={22} />
          <div>
            <strong>Règle d’enquête</strong>
            <p>Chaque dossier distingue la valeur d’écran, le matériau, l’attestation, l’approximation et le niveau de confiance. Une absence de preuve reste une absence de preuve.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
