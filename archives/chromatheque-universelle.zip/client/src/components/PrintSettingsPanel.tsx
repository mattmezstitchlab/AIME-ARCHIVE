import { Printer, X } from "lucide-react";
import type { PatternPagePlan } from "@/lib/patternExport";
import type { PrintSettings } from "@shared/pattern";

const PAGE_FORMATS: Array<{ value: PrintSettings["pageSize"]; label: string; note: string }> = [
  { value: "a4", label: "A4", note: "210 × 297 mm" },
  { value: "a3", label: "A3", note: "297 × 420 mm" },
  { value: "letter", label: "Letter", note: "216 × 279 mm" },
];

const ORIENTATIONS: Array<{ value: PrintSettings["orientation"]; label: string }> = [
  { value: "auto", label: "Automatique" },
  { value: "portrait", label: "Portrait" },
  { value: "landscape", label: "Paysage" },
];

type PrintSettingsPanelProps = {
  open: boolean;
  settings: PrintSettings;
  plan: PatternPagePlan;
  onChange: (settings: PrintSettings) => void;
  onClose: () => void;
  onPrint: () => void;
};

export default function PrintSettingsPanel({ open, settings, plan, onChange, onClose, onPrint }: PrintSettingsPanelProps) {
  if (!open) return null;
  const totalPages = plan.tiles.length + 2;
  const update = <K extends keyof PrintSettings>(key: K, value: PrintSettings[K]) => onChange({ ...settings, [key]: value });

  return (
    <div className="print-settings-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="print-settings-panel" role="dialog" aria-modal="true" aria-labelledby="print-settings-title">
        <header>
          <div><span className="panel-kicker">SORTIE DOCUMENTAIRE · P·02</span><h2 id="print-settings-title"><Printer size={19} /> Paramètres d’impression</h2></div>
          <button type="button" className="panel-icon-button" onClick={onClose} aria-label="Fermer les paramètres d’impression"><X size={18} /></button>
        </header>

        <div className="print-settings-group">
          <div className="print-settings-heading"><strong>Format de page</strong><span>Standard physique du papier</span></div>
          <div className="print-choice-grid print-choice-grid-formats">
            {PAGE_FORMATS.map((format) => (
              <button key={format.value} type="button" className={settings.pageSize === format.value ? "is-selected" : ""} onClick={() => update("pageSize", format.value)}>
                <strong>{format.label}</strong><small>{format.note}</small>
              </button>
            ))}
          </div>
        </div>

        <div className="print-settings-group">
          <div className="print-settings-heading"><strong>Orientation</strong><span>La valeur automatique suit le patron</span></div>
          <div className="print-choice-grid">
            {ORIENTATIONS.map((orientation) => (
              <button key={orientation.value} type="button" className={settings.orientation === orientation.value ? "is-selected" : ""} onClick={() => update("orientation", orientation.value)}>
                <strong>{orientation.label}</strong>
              </button>
            ))}
          </div>
        </div>

        <div className="print-range-grid">
          <label>
            <span><strong>Chevauchement</strong><output>{settings.overlapCells} facette{settings.overlapCells > 1 ? "s" : ""}</output></span>
            <input type="range" min="0" max="8" step="1" value={settings.overlapCells} onChange={(event) => update("overlapCells", Number(event.target.value))} />
            <small>Répète les cellules de bord pour faciliter l’assemblage.</small>
          </label>
          <label>
            <span><strong>Taille d’une case</strong><output>{settings.cellSizeMm} mm</output></span>
            <input type="range" min="2" max="8" step="0.5" value={settings.cellSizeMm} onChange={(event) => update("cellSizeMm", Number(event.target.value))} />
            <small>Une case plus grande augmente le nombre de feuilles.</small>
          </label>
        </div>

        <aside className="print-plan-summary">
          <div><span>PLANCHES DE GRILLE</span><strong>{plan.tiles.length}</strong></div>
          <div><span>PDF COMPLET</span><strong>{totalPages} pages</strong></div>
          <div><span>ORIENTATION RÉELLE</span><strong>{plan.orientation === "portrait" ? "Portrait" : "Paysage"}</strong></div>
          <p>Le PDF contient un plan d’assemblage, {plan.tiles.length} planche{plan.tiles.length > 1 ? "s" : ""} et une légende DMC.</p>
        </aside>

        <footer>
          <button type="button" className="print-secondary" onClick={onClose}>Conserver les réglages</button>
          <button type="button" className="print-primary" onClick={onPrint}><Printer size={16} /> Générer le PDF · {totalPages} pages</button>
        </footer>
      </section>
    </div>
  );
}
