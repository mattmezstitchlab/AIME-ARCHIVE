import { cellKey, createMark, type PatternSnapshot, type StitchMark } from "@/lib/embroidery";

export type ConfettiCleanupResult = {
  snapshot: PatternSnapshot;
  before: number;
  after: number;
  replaced: number;
  threshold: number;
};

export function cleanPatternConfetti(snapshot: PatternSnapshot, width: number, height: number, requestedThreshold: number): ConfettiCleanupResult {
  const threshold = Math.max(0, Math.min(12, Math.round(requestedThreshold)));
  if (threshold === 0) return { snapshot, before: 0, after: 0, replaced: 0, threshold };
  const components = findComponents(snapshot, width, height);
  const smallComponents = components.filter(component => component.length <= threshold);
  const next = { ...snapshot };
  let replaced = 0;

  for (const component of smallComponents) {
    const componentKeys = new Set(component.map(mark => cellKey(mark.x, mark.y)));
    const neighborCounts = new Map<string, { mark: StitchMark; count: number }>();
    for (const mark of component) {
      for (const [x, y] of neighbors(mark.x, mark.y)) {
        if (x < 0 || y < 0 || x >= width || y >= height) continue;
        const key = cellKey(x, y);
        if (componentKeys.has(key)) continue;
        const neighbor = next[key];
        if (!neighbor || neighbor.threadCode === mark.threadCode) continue;
        const signature = `${neighbor.threadCode}/${neighbor.stitchId}`;
        const current = neighborCounts.get(signature);
        neighborCounts.set(signature, { mark: neighbor, count: (current?.count ?? 0) + 1 });
      }
    }
    const replacement = Array.from(neighborCounts.values()).sort((a, b) => b.count - a.count)[0]?.mark;
    if (!replacement) continue;
    for (const mark of component) {
      next[cellKey(mark.x, mark.y)] = createMark(mark.x, mark.y, replacement.stitchId, replacement.threadCode);
      replaced += 1;
    }
  }

  const after = findComponents(next, width, height).filter(component => component.length <= threshold).reduce((sum, component) => sum + component.length, 0);
  return {
    snapshot: next,
    before: smallComponents.reduce((sum, component) => sum + component.length, 0),
    after,
    replaced,
    threshold,
  };
}

function findComponents(snapshot: PatternSnapshot, width: number, height: number) {
  const visited = new Set<string>();
  const components: StitchMark[][] = [];
  for (const mark of Object.values(snapshot)) {
    const startKey = cellKey(mark.x, mark.y);
    if (visited.has(startKey) || mark.x >= width || mark.y >= height) continue;
    const component: StitchMark[] = [];
    const queue = [mark];
    visited.add(startKey);
    while (queue.length) {
      const current = queue.shift()!;
      component.push(current);
      for (const [x, y] of neighbors(current.x, current.y)) {
        const key = cellKey(x, y);
        if (visited.has(key)) continue;
        const candidate = snapshot[key];
        if (!candidate || candidate.threadCode !== mark.threadCode) continue;
        visited.add(key);
        queue.push(candidate);
      }
    }
    components.push(component);
  }
  return components;
}

function neighbors(x: number, y: number): Array<[number, number]> {
  return [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]];
}
