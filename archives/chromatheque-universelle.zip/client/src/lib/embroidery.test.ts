import { describe, expect, it } from "vitest";
import {
  clearPattern,
  eraseCell,
  floodFill,
  paintCell,
  patternStats,
  redo,
  undo,
  type PatternHistory,
} from "./embroidery";

const empty = (): PatternHistory => ({ past: [], present: {}, future: [] });

describe("moteur de motif de broderie", () => {
  it("dessine une marque déterministe", () => {
    const next = paintCell(empty(), 2, 3, "cross", "310");
    expect(next.present["2:3"]).toMatchObject({ x: 2, y: 3, stitchId: "cross", threadCode: "310" });
  });

  it("évite une entrée d’historique si la marque est identique", () => {
    const once = paintCell(empty(), 2, 3, "cross", "310");
    const twice = paintCell(once, 2, 3, "cross", "310");
    expect(twice).toBe(once);
  });

  it("efface une cellule existante", () => {
    const drawn = paintCell(empty(), 1, 1, "cross", "310");
    const erased = eraseCell(drawn, 1, 1);
    expect(erased.present["1:1"]).toBeUndefined();
  });

  it("remplit une zone vide dans les limites de la grille", () => {
    const filled = floodFill(empty(), 3, 2, 0, 0, "half-cross", "321");
    expect(Object.keys(filled.present)).toHaveLength(6);
    expect(filled.present["2:1"].threadCode).toBe("321");
  });

  it("annule puis rétablit une action", () => {
    const drawn = paintCell(empty(), 0, 0, "cross", "310");
    const previous = undo(drawn);
    expect(Object.keys(previous.present)).toHaveLength(0);
    expect(redo(previous).present["0:0"]).toBeDefined();
  });

  it("calcule les fils et points réellement utilisés", () => {
    let history = paintCell(empty(), 0, 0, "cross", "310");
    history = paintCell(history, 1, 0, "cross", "310");
    history = paintCell(history, 2, 0, "french-knot", "321");
    const stats = patternStats(history.present);
    expect(stats.marks).toBe(3);
    expect(stats.threads).toEqual([["310", 2], ["321", 1]]);
    expect(stats.stitches).toEqual([["cross", 2], ["french-knot", 1]]);
  });

  it("vide un motif en une seule action réversible", () => {
    const drawn = paintCell(empty(), 0, 0, "cross", "310");
    const cleared = clearPattern(drawn);
    expect(cleared.present).toEqual({});
    expect(undo(cleared).present["0:0"]).toBeDefined();
  });
});
