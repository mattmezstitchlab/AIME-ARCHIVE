// Atlas cinétique — modèle textile : coordonnées explicites, géométries de points et historique réversible.

export type GridGeometry = "square" | "diamond" | "hex";
export type GridPresetId = "square" | "portrait" | "landscape" | "banner" | "custom";
export type StitchGeometry = "cross" | "half" | "quarter" | "three-quarter" | "line" | "knot" | "loop" | "fill" | "couching";
export type DrawingTool = "draw" | "erase" | "fill" | "pan";

export type GridPreset = {
  id: GridPresetId;
  label: string;
  width: number;
  height: number;
  description: string;
};

export type StitchMark = {
  id: string;
  x: number;
  y: number;
  stitchId: string;
  threadCode: string;
  orientation: 0 | 45 | 90 | 135;
};

export type PatternSnapshot = Record<string, StitchMark>;

export type PatternHistory = {
  past: PatternSnapshot[];
  present: PatternSnapshot;
  future: PatternSnapshot[];
};

export const GRID_PRESETS: GridPreset[] = [
  { id: "square", label: "Carré", width: 24, height: 24, description: "24 × 24 facettes" },
  { id: "portrait", label: "Portrait", width: 20, height: 30, description: "20 × 30 facettes" },
  { id: "landscape", label: "Paysage", width: 32, height: 20, description: "32 × 20 facettes" },
  { id: "banner", label: "Bannière", width: 40, height: 14, description: "40 × 14 facettes" },
  { id: "custom", label: "Sur mesure", width: 28, height: 22, description: "Dimensions libres" },
];

export function cellKey(x: number, y: number) {
  return `${x}:${y}`;
}

export function createMark(x: number, y: number, stitchId: string, threadCode: string): StitchMark {
  return {
    id: cellKey(x, y),
    x,
    y,
    stitchId,
    threadCode,
    orientation: 0,
  };
}

export function commit(history: PatternHistory, next: PatternSnapshot): PatternHistory {
  if (next === history.present) return history;
  return { past: [...history.past, history.present], present: next, future: [] };
}

export function paintCell(
  history: PatternHistory,
  x: number,
  y: number,
  stitchId: string,
  threadCode: string,
): PatternHistory {
  const key = cellKey(x, y);
  const current = history.present[key];
  if (current?.stitchId === stitchId && current?.threadCode === threadCode) return history;
  return commit(history, { ...history.present, [key]: createMark(x, y, stitchId, threadCode) });
}

export function eraseCell(history: PatternHistory, x: number, y: number): PatternHistory {
  const key = cellKey(x, y);
  if (!history.present[key]) return history;
  const next = { ...history.present };
  delete next[key];
  return commit(history, next);
}

export function floodFill(
  history: PatternHistory,
  width: number,
  height: number,
  startX: number,
  startY: number,
  stitchId: string,
  threadCode: string,
): PatternHistory {
  const origin = history.present[cellKey(startX, startY)];
  const targetSignature = origin ? `${origin.stitchId}/${origin.threadCode}` : "empty";
  const next = { ...history.present };
  const queue: Array<[number, number]> = [[startX, startY]];
  const visited = new Set<string>();

  while (queue.length) {
    const [x, y] = queue.shift()!;
    const key = cellKey(x, y);
    if (visited.has(key) || x < 0 || y < 0 || x >= width || y >= height) continue;
    visited.add(key);
    const mark = history.present[key];
    const signature = mark ? `${mark.stitchId}/${mark.threadCode}` : "empty";
    if (signature !== targetSignature) continue;
    next[key] = createMark(x, y, stitchId, threadCode);
    queue.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
  }

  return commit(history, next);
}

export function undo(history: PatternHistory): PatternHistory {
  const previous = history.past.at(-1);
  if (!previous) return history;
  return {
    past: history.past.slice(0, -1),
    present: previous,
    future: [history.present, ...history.future],
  };
}

export function redo(history: PatternHistory): PatternHistory {
  const next = history.future[0];
  if (!next) return history;
  return {
    past: [...history.past, history.present],
    present: next,
    future: history.future.slice(1),
  };
}

export function clearPattern(history: PatternHistory): PatternHistory {
  if (!Object.keys(history.present).length) return history;
  return commit(history, {});
}

export function patternStats(snapshot: PatternSnapshot) {
  const marks = Object.values(snapshot);
  const threadCounts = new Map<string, number>();
  const stitchCounts = new Map<string, number>();
  for (const mark of marks) {
    threadCounts.set(mark.threadCode, (threadCounts.get(mark.threadCode) ?? 0) + 1);
    stitchCounts.set(mark.stitchId, (stitchCounts.get(mark.stitchId) ?? 0) + 1);
  }
  return {
    marks: marks.length,
    threads: Array.from(threadCounts.entries()).sort((a, b) => b[1] - a[1]),
    stitches: Array.from(stitchCounts.entries()).sort((a, b) => b[1] - a[1]),
  };
}
