// Atlas cinétique — exactitude numérique sRGB d’abord, proximité et impression explicitement contextualisées.

import { namedColors, type NamedColor } from "@/data/colorCorpus";

export type RGB = { r: number; g: number; b: number };
export type CMYK = { c: number; m: number; y: number; k: number };
export type OKLCH = { l: number; c: number; h: number };

const clampByte = (value: number) => Math.min(255, Math.max(0, Math.round(value)));

export function normalizeHex(value: string): string | null {
  const raw = value.trim().replace(/^#/, "");
  if (/^[0-9a-fA-F]{3}$/.test(raw)) {
    return `#${raw.split("").map((char) => char + char).join("").toUpperCase()}`;
  }
  if (/^[0-9a-fA-F]{6}$/.test(raw)) return `#${raw.toUpperCase()}`;
  return null;
}

export function hexToRgb(hex: string): RGB {
  const normalized = normalizeHex(hex) ?? "#000000";
  const value = Number.parseInt(normalized.slice(1), 16);
  return { r: (value >> 16) & 255, g: (value >> 8) & 255, b: value & 255 };
}

export function rgbToHex({ r, g, b }: RGB): string {
  return `#${[r, g, b].map((value) => clampByte(value).toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}

export function rgbToInt({ r, g, b }: RGB): number {
  return (clampByte(r) << 16) | (clampByte(g) << 8) | clampByte(b);
}

export function intToRgb(value: number): RGB {
  return { r: (value >> 16) & 255, g: (value >> 8) & 255, b: value & 255 };
}

export function rgbToMortonDigits({ r, g, b }: RGB): number[] {
  return Array.from({ length: 8 }, (_, depth) => {
    const bit = 7 - depth;
    return (((r >> bit) & 1) << 2) | (((g >> bit) & 1) << 1) | ((b >> bit) & 1);
  });
}

export function mortonDigitsToRgb(digits: number[]): RGB {
  let r = 0;
  let g = 0;
  let b = 0;
  digits.slice(0, 8).forEach((digit, depth) => {
    const bit = 7 - depth;
    r |= ((digit >> 2) & 1) << bit;
    g |= ((digit >> 1) & 1) << bit;
    b |= (digit & 1) << bit;
  });
  return { r, g, b };
}

export function prefixRange(digits: number[]): { min: RGB; max: RGB; center: RGB } {
  const min = mortonDigitsToRgb(digits);
  const remaining = 8 - Math.min(digits.length, 8);
  const spread = remaining === 0 ? 0 : (1 << remaining) - 1;
  const max = { r: min.r + spread, g: min.g + spread, b: min.b + spread };
  const center = {
    r: Math.round((min.r + max.r) / 2),
    g: Math.round((min.g + max.g) / 2),
    b: Math.round((min.b + max.b) / 2),
  };
  return { min, max, center };
}

export function childCenter(prefix: number[], digit: number): RGB {
  return prefixRange([...prefix, digit]).center;
}

export function rgbToCmyk({ r, g, b }: RGB): CMYK {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const k = 1 - Math.max(rn, gn, bn);
  if (k >= 0.999999) return { c: 0, m: 0, y: 0, k: 100 };
  return {
    c: Math.round(((1 - rn - k) / (1 - k)) * 100),
    m: Math.round(((1 - gn - k) / (1 - k)) * 100),
    y: Math.round(((1 - bn - k) / (1 - k)) * 100),
    k: Math.round(k * 100),
  };
}

function linearize(channel: number): number {
  const value = channel / 255;
  return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
}

export function rgbToOklch({ r, g, b }: RGB): OKLCH {
  const lr = linearize(r);
  const lg = linearize(g);
  const lb = linearize(b);
  const l = 0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb;
  const m = 0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb;
  const s = 0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb;
  const lRoot = Math.cbrt(l);
  const mRoot = Math.cbrt(m);
  const sRoot = Math.cbrt(s);
  const lightness = 0.2104542553 * lRoot + 0.793617785 * mRoot - 0.0040720468 * sRoot;
  const a = 1.9779984951 * lRoot - 2.428592205 * mRoot + 0.4505937099 * sRoot;
  const bb = 0.0259040371 * lRoot + 0.7827717662 * mRoot - 0.808675766 * sRoot;
  const chroma = Math.sqrt(a * a + bb * bb);
  let hue = (Math.atan2(bb, a) * 180) / Math.PI;
  if (hue < 0) hue += 360;
  return { l: lightness * 100, c: chroma, h: Number.isFinite(hue) ? hue : 0 };
}

export function relativeLuminance(rgb: RGB): number {
  const { r, g, b } = rgb;
  return 0.2126 * linearize(r) + 0.7152 * linearize(g) + 0.0722 * linearize(b);
}

export function contrastRatio(a: RGB, b: RGB): number {
  const l1 = relativeLuminance(a);
  const l2 = relativeLuminance(b);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

export function bestTextColor(rgb: RGB): "#17211F" | "#FFFFFF" {
  return contrastRatio(rgb, { r: 23, g: 33, b: 31 }) >= contrastRatio(rgb, { r: 255, g: 255, b: 255 })
    ? "#17211F"
    : "#FFFFFF";
}

export function findExactName(hex: string): NamedColor | undefined {
  const normalized = normalizeHex(hex);
  return namedColors.find((item) => item.hex === normalized);
}

export function findNamedColors(query: string): NamedColor[] {
  const normalized = normalizeHex(query);
  const lowered = query.trim().toLocaleLowerCase("fr");
  return namedColors.filter((item) =>
    normalized
      ? item.hex === normalized
      : item.name.toLocaleLowerCase("fr").includes(lowered) ||
        item.frenchName?.toLocaleLowerCase("fr").includes(lowered),
  );
}

export function parseColorQuery(query: string): RGB | null {
  const hex = normalizeHex(query);
  if (hex) return hexToRgb(hex);
  const rgbMatch = query.match(/rgb\s*\(\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*\)/i);
  if (rgbMatch) return { r: clampByte(Number(rgbMatch[1])), g: clampByte(Number(rgbMatch[2])), b: clampByte(Number(rgbMatch[3])) };
  const named = findNamedColors(query)[0];
  return named ? hexToRgb(named.hex) : null;
}

export function formatRange(min: RGB, max: RGB): string {
  return `R ${min.r}–${max.r} · V ${min.g}–${max.g} · B ${min.b}–${max.b}`;
}
