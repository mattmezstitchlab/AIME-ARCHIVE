import type { RGB } from "@/lib/color";
import { rgbToHex } from "@/lib/color";

export type HSL = { h: number; s: number; l: number };
export type HarmonyKind = "complementary" | "analogous" | "triadic" | "tetradic";

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const wrapHue = (value: number) => ((value % 360) + 360) % 360;

export function rgbToHsl({ r, g, b }: RGB): HSL {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const delta = max - min;
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;

  if (delta !== 0) {
    s = delta / (1 - Math.abs(2 * l - 1));
    if (max === rn) h = 60 * (((gn - bn) / delta) % 6);
    else if (max === gn) h = 60 * ((bn - rn) / delta + 2);
    else h = 60 * ((rn - gn) / delta + 4);
  }

  return { h: wrapHue(h), s: s * 100, l: l * 100 };
}

export function hslToRgb({ h, s, l }: HSL): RGB {
  const hue = wrapHue(h);
  const saturation = clamp(s, 0, 100) / 100;
  const lightness = clamp(l, 0, 100) / 100;
  const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation;
  const x = chroma * (1 - Math.abs(((hue / 60) % 2) - 1));
  const m = lightness - chroma / 2;
  let rn = 0;
  let gn = 0;
  let bn = 0;

  if (hue < 60) [rn, gn, bn] = [chroma, x, 0];
  else if (hue < 120) [rn, gn, bn] = [x, chroma, 0];
  else if (hue < 180) [rn, gn, bn] = [0, chroma, x];
  else if (hue < 240) [rn, gn, bn] = [0, x, chroma];
  else if (hue < 300) [rn, gn, bn] = [x, 0, chroma];
  else [rn, gn, bn] = [chroma, 0, x];

  return {
    r: Math.round((rn + m) * 255),
    g: Math.round((gn + m) * 255),
    b: Math.round((bn + m) * 255),
  };
}

const harmonyOffsets: Record<HarmonyKind, number[]> = {
  complementary: [0, 180],
  analogous: [-30, 0, 30],
  triadic: [0, 120, 240],
  tetradic: [0, 90, 180, 270],
};

export function buildHarmony(rgb: RGB, kind: HarmonyKind): RGB[] {
  const base = rgbToHsl(rgb);
  return harmonyOffsets[kind].map(offset => hslToRgb({ ...base, h: base.h + offset }));
}

export function compositeOver(foreground: RGB, background: RGB, alpha: number): RGB {
  const a = clamp(alpha, 0, 1);
  return {
    r: Math.round(foreground.r * a + background.r * (1 - a)),
    g: Math.round(foreground.g * a + background.g * (1 - a)),
    b: Math.round(foreground.b * a + background.b * (1 - a)),
  };
}

function srgbToLinear(channel: number) {
  const value = channel / 255;
  return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
}

export function rgbToLab({ r, g, b }: RGB): { l: number; a: number; b: number } {
  const lr = srgbToLinear(r);
  const lg = srgbToLinear(g);
  const lb = srgbToLinear(b);
  const x = (0.4124564 * lr + 0.3575761 * lg + 0.1804375 * lb) / 0.95047;
  const y = (0.2126729 * lr + 0.7151522 * lg + 0.072175 * lb) / 1;
  const z = (0.0193339 * lr + 0.119192 * lg + 0.9503041 * lb) / 1.08883;
  const pivot = (value: number) => value > 216 / 24389 ? Math.cbrt(value) : (24389 / 27 * value + 16) / 116;
  const fx = pivot(x);
  const fy = pivot(y);
  const fz = pivot(z);
  return { l: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) };
}

export function deltaE76(first: RGB, second: RGB): number {
  const a = rgbToLab(first);
  const b = rgbToLab(second);
  return Math.sqrt((a.l - b.l) ** 2 + (a.a - b.a) ** 2 + (a.b - b.b) ** 2);
}

export function paletteToCss(colors: RGB[], prefix = "chromatique"): string {
  return `:root {\n${colors.map((color, index) => `  --${prefix}-${index + 1}: ${rgbToHex(color)};`).join("\n")}\n}`;
}

export function paletteToJson(colors: RGB[]): string {
  return JSON.stringify(
    colors.map((color, index) => ({ index: index + 1, hex: rgbToHex(color), rgb: color })),
    null,
    2,
  );
}
