// Atlas cinétique — persistance locale versionnée, défensive et limitée aux données nécessaires à la reprise du motif.

import type { GridGeometry, PatternSnapshot, StitchMark } from "@/lib/embroidery";

export const ATELIER_STORAGE_KEY = "chromatheque.atelier.document.v1";

export type SavedAtelierDocument = {
  version: 1;
  updatedAt: string;
  documentTitle: string;
  presetId: string;
  dimensions: { width: number; height: number };
  geometry: GridGeometry;
  selectedThreadCode: string;
  selectedStitchId: string;
  camera: { x: number; y: number; zoom: number };
  snapshot: PatternSnapshot;
};

export type AtelierDraftInput = Omit<SavedAtelierDocument, "version" | "updatedAt">;

export function loadAtelierDocument(): SavedAtelierDocument | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(ATELIER_STORAGE_KEY);
    if (!raw) return null;
    return sanitizeDocument(JSON.parse(raw));
  } catch {
    return null;
  }
}

export function saveAtelierDocument(input: AtelierDraftInput): SavedAtelierDocument | null {
  if (typeof window === "undefined") return null;
  const document: SavedAtelierDocument = {
    ...input,
    version: 1,
    updatedAt: new Date().toISOString(),
  };
  try {
    window.localStorage.setItem(ATELIER_STORAGE_KEY, JSON.stringify(document));
    return document;
  } catch {
    return null;
  }
}

function sanitizeDocument(value: unknown): SavedAtelierDocument | null {
  if (!isRecord(value) || value.version !== 1) return null;
  const dimensions = sanitizeDimensions(value.dimensions);
  const geometry = sanitizeGeometry(value.geometry);
  const camera = sanitizeCamera(value.camera);
  const snapshot = sanitizeSnapshot(value.snapshot);
  if (!dimensions || !geometry || !camera || !snapshot) return null;

  return {
    version: 1,
    updatedAt: typeof value.updatedAt === "string" ? value.updatedAt : new Date(0).toISOString(),
    documentTitle: typeof value.documentTitle === "string" ? value.documentTitle.slice(0, 120) : "Motif sans titre",
    presetId: typeof value.presetId === "string" ? value.presetId : "custom",
    dimensions,
    geometry,
    selectedThreadCode: typeof value.selectedThreadCode === "string" ? value.selectedThreadCode : "310",
    selectedStitchId: typeof value.selectedStitchId === "string" ? value.selectedStitchId : "cross",
    camera,
    snapshot,
  };
}

function sanitizeDimensions(value: unknown) {
  if (!isRecord(value) || !isFiniteNumber(value.width) || !isFiniteNumber(value.height)) return null;
  return {
    width: clampInteger(value.width, 6, 240),
    height: clampInteger(value.height, 6, 240),
  };
}

function sanitizeGeometry(value: unknown): GridGeometry | null {
  return value === "square" || value === "diamond" || value === "hex" ? value : null;
}

function sanitizeCamera(value: unknown) {
  if (!isRecord(value) || !isFiniteNumber(value.x) || !isFiniteNumber(value.y) || !isFiniteNumber(value.zoom)) {
    return { x: 0, y: 0, zoom: 1 };
  }
  return {
    x: clamp(value.x, -100000, 100000),
    y: clamp(value.y, -100000, 100000),
    zoom: clamp(value.zoom, 0.25, 4),
  };
}

function sanitizeSnapshot(value: unknown): PatternSnapshot | null {
  if (!isRecord(value)) return null;
  const snapshot: PatternSnapshot = {};
  for (const entry of Object.values(value)) {
    const mark = sanitizeMark(entry);
    if (mark) snapshot[`${mark.x}:${mark.y}`] = mark;
  }
  return snapshot;
}

function sanitizeMark(value: unknown): StitchMark | null {
  if (!isRecord(value) || !isFiniteNumber(value.x) || !isFiniteNumber(value.y)) return null;
  if (typeof value.stitchId !== "string" || typeof value.threadCode !== "string") return null;
  const x = clampInteger(value.x, 0, 239);
  const y = clampInteger(value.y, 0, 239);
  const orientation = value.orientation === 45 || value.orientation === 90 || value.orientation === 135 ? value.orientation : 0;
  return {
    id: `${x}:${y}`,
    x,
    y,
    stitchId: value.stitchId,
    threadCode: value.threadCode,
    orientation,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function clampInteger(value: number, minimum: number, maximum: number) {
  return Math.round(clamp(value, minimum, maximum));
}

function clamp(value: number, minimum: number, maximum: number) {
  return Math.min(maximum, Math.max(minimum, value));
}
