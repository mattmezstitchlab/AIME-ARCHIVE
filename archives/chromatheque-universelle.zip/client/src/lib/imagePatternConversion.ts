import { dmcThreads, type DmcThread } from "@/data/dmcThreads";
import { cellKey, createMark, type PatternSnapshot } from "@/lib/embroidery";
import { cleanPatternConfetti } from "@/lib/patternCleanup";

export type ConversionOptions = {
  width: number;
  height: number;
  maxColors: number;
  pdfPage?: number;
  confettiThreshold?: number;
};

export type ConvertedPattern = {
  snapshot: PatternSnapshot;
  width: number;
  height: number;
  palette: Array<DmcThread & { cells: number }>;
  source: {
    name: string;
    mimeType: string;
    page: number | null;
    pageCount: number | null;
    originalWidth: number;
    originalHeight: number;
    secureUrl?: string;
  };
  previewDataUrl: string;
  cleanup: { before: number; after: number; replaced: number; threshold: number };
};

type RasterSource = {
  canvas: HTMLCanvasElement;
  page: number | null;
  pageCount: number | null;
  originalWidth: number;
  originalHeight: number;
};

type Rgb = { r: number; g: number; b: number };

type ParsedThread = DmcThread & { rgb: Rgb };

const parsedThreads: ParsedThread[] = dmcThreads.map(thread => ({ ...thread, rgb: hexToRgb(thread.hex) }));

export async function inspectPdf(file: File) {
  const document = await loadPdf(file);
  return { pageCount: document.numPages };
}

export async function convertFileToPattern(file: File, options: ConversionOptions): Promise<ConvertedPattern> {
  const width = clamp(options.width, 12, 240);
  const height = clamp(options.height, 12, 240);
  const maxColors = clamp(options.maxColors, 2, 36);
  const raster = isPdf(file) ? await rasterizePdf(file, options.pdfPage ?? 1) : await rasterizeImage(file);
  const sample = sampleRaster(raster.canvas, width, height);
  const assigned = assignDmcPalette(sample, maxColors);
  const snapshot: PatternSnapshot = {};

  assigned.forEach((thread, index) => {
    if (!thread) return;
    const x = index % width;
    const y = Math.floor(index / width);
    snapshot[cellKey(x, y)] = createMark(x, y, "cross", thread.code);
  });

  const cleanup = cleanPatternConfetti(snapshot, width, height, options.confettiThreshold ?? 0);
  const counts = new Map<string, number>();
  Object.values(cleanup.snapshot).forEach(mark => counts.set(mark.threadCode, (counts.get(mark.threadCode) ?? 0) + 1));
  const palette = Array.from(counts.entries())
    .map(([code, cells]) => ({ ...dmcThreads.find(thread => thread.code === code)!, cells }))
    .sort((a, b) => b.cells - a.cells);

  return {
    snapshot: cleanup.snapshot,
    width,
    height,
    palette,
    source: {
      name: file.name,
      mimeType: file.type || (isPdf(file) ? "application/pdf" : "image/*"),
      page: raster.page,
      pageCount: raster.pageCount,
      originalWidth: raster.originalWidth,
      originalHeight: raster.originalHeight,
    },
    previewDataUrl: raster.canvas.toDataURL("image/jpeg", 0.78),
    cleanup: { before: cleanup.before, after: cleanup.after, replaced: cleanup.replaced, threshold: cleanup.threshold },
  };
}

async function rasterizeImage(file: File): Promise<RasterSource> {
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("Canvas indisponible");
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(bitmap, 0, 0);
  bitmap.close();
  return { canvas, page: null, pageCount: null, originalWidth: canvas.width, originalHeight: canvas.height };
}

async function rasterizePdf(file: File, requestedPage: number): Promise<RasterSource> {
  const document = await loadPdf(file);
  const pageNumber = clamp(requestedPage, 1, document.numPages);
  const page = await document.getPage(pageNumber);
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(2.4, Math.max(1.25, 1800 / Math.max(base.width, base.height)));
  const viewport = page.getViewport({ scale });
  const canvas = window.document.createElement("canvas");
  canvas.width = Math.ceil(viewport.width);
  canvas.height = Math.ceil(viewport.height);
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("Canvas indisponible");
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvas, canvasContext: context, viewport }).promise;
  return {
    canvas,
    page: pageNumber,
    pageCount: document.numPages,
    originalWidth: Math.round(base.width),
    originalHeight: Math.round(base.height),
  };
}

async function loadPdf(file: File) {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const workerUrl = (await import("pdfjs-dist/legacy/build/pdf.worker.min.mjs?url")).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
  const bytes = new Uint8Array(await file.arrayBuffer());
  return pdfjs.getDocument({ data: bytes }).promise;
}

function sampleRaster(source: HTMLCanvasElement, width: number, height: number) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("Canvas indisponible");
  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = "high";
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, width, height);
  const scale = Math.min(width / source.width, height / source.height);
  const drawWidth = source.width * scale;
  const drawHeight = source.height * scale;
  context.drawImage(source, (width - drawWidth) / 2, (height - drawHeight) / 2, drawWidth, drawHeight);
  return context.getImageData(0, 0, width, height);
}

function assignDmcPalette(image: ImageData, maxColors: number): Array<ParsedThread | null> {
  const initial: ParsedThread[] = [];
  const counts = new Map<string, number>();
  for (let index = 0; index < image.data.length; index += 4) {
    const alpha = image.data[index + 3] ?? 255;
    const rgb = compositeOnWhite({ r: image.data[index]!, g: image.data[index + 1]!, b: image.data[index + 2]! }, alpha);
    const nearest = findNearestThread(rgb, parsedThreads);
    initial.push(nearest);
    counts.set(nearest.code, (counts.get(nearest.code) ?? 0) + 1);
  }

  const selectedCodes = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, maxColors).map(([code]) => code);
  const selected = parsedThreads.filter(thread => selectedCodes.includes(thread.code));
  return initial.map((thread, index) => {
    const offset = index * 4;
    const alpha = image.data[offset + 3] ?? 255;
    const rgb = compositeOnWhite({ r: image.data[offset]!, g: image.data[offset + 1]!, b: image.data[offset + 2]! }, alpha);
    return selectedCodes.includes(thread.code) ? thread : findNearestThread(rgb, selected);
  });
}

function findNearestThread(rgb: Rgb, palette: ParsedThread[]) {
  let nearest = palette[0]!;
  let best = Number.POSITIVE_INFINITY;
  for (const thread of palette) {
    const distance = perceptualRgbDistance(rgb, thread.rgb);
    if (distance < best) {
      best = distance;
      nearest = thread;
    }
  }
  return nearest;
}

function perceptualRgbDistance(a: Rgb, b: Rgb) {
  const meanRed = (a.r + b.r) / 2;
  const red = a.r - b.r;
  const green = a.g - b.g;
  const blue = a.b - b.b;
  return Math.sqrt((2 + meanRed / 256) * red * red + 4 * green * green + (2 + (255 - meanRed) / 256) * blue * blue);
}

function compositeOnWhite(rgb: Rgb, alpha: number): Rgb {
  const opacity = alpha / 255;
  return {
    r: Math.round(rgb.r * opacity + 255 * (1 - opacity)),
    g: Math.round(rgb.g * opacity + 255 * (1 - opacity)),
    b: Math.round(rgb.b * opacity + 255 * (1 - opacity)),
  };
}

function hexToRgb(hex: string): Rgb {
  const normalized = hex.replace("#", "");
  return {
    r: Number.parseInt(normalized.slice(0, 2), 16),
    g: Number.parseInt(normalized.slice(2, 4), 16),
    b: Number.parseInt(normalized.slice(4, 6), 16),
  };
}

function isPdf(file: File) {
  return file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, Math.round(value)));
}
