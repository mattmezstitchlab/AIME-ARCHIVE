import { describe, expect, it } from "vitest";
import { createMark, cellKey, type PatternSnapshot } from "@/lib/embroidery";
import { cleanPatternConfetti } from "@/lib/patternCleanup";
import { getPatternPagePlan } from "@/lib/patternExport";
import { syncedPatternProjectSchema } from "@shared/pattern";

function filledSnapshot(width: number, height: number, threadCode = "310"): PatternSnapshot {
  const snapshot: PatternSnapshot = {};
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      snapshot[cellKey(x, y)] = createMark(x, y, "cross", threadCode);
    }
  }
  return snapshot;
}

describe("nettoyage déterministe des confettis", () => {
  it("rattache une cellule isolée à la couleur dominante de son voisinage", () => {
    const snapshot = filledSnapshot(3, 3);
    snapshot[cellKey(1, 1)] = createMark(1, 1, "cross", "666");

    const result = cleanPatternConfetti(snapshot, 3, 3, 1);

    expect(result.before).toBe(1);
    expect(result.replaced).toBe(1);
    expect(result.after).toBe(0);
    expect(result.snapshot[cellKey(1, 1)]?.threadCode).toBe("310");
    expect(snapshot[cellKey(1, 1)]?.threadCode).toBe("666");
  });

  it("désactive toute transformation avec un seuil nul", () => {
    const snapshot = filledSnapshot(2, 2);
    const result = cleanPatternConfetti(snapshot, 2, 2, 0);
    expect(result.snapshot).toBe(snapshot);
    expect(result.replaced).toBe(0);
  });
});

describe("provenance synchronisée", () => {
  it("conserve les références de source sécurisée et l’attestation de droits", () => {
    const provenance = {
      sourceType: "pdf" as const,
      sourceName: "patron-etsy.pdf",
      sourceKey: "pattern-sources/user/project/source.pdf",
      sourceUrl: "/manus-storage/pattern-sources/user/project/source.pdf",
      sourceMimeType: "application/pdf",
      sourceSize: 824_000,
      sourcePage: 3,
      prompt: null,
      rightsConfirmedAt: "2026-07-17T09:55:00.000Z",
      transformations: ["quantification-dmc", "nettoyage-confettis:2"],
    };
    const conversion = {
      targetWidth: 24,
      targetHeight: 18,
      maxColors: 12,
      confettiThreshold: 2,
      convertedCells: 432,
      confettiBefore: 9,
      confettiAfter: 1,
    };
    const printSettings = {
      pageSize: "a4" as const,
      orientation: "portrait" as const,
      overlapCells: 2,
      cellSizeMm: 4,
    };
    const project = syncedPatternProjectSchema.parse({
      clientId: "project-source-01",
      name: "Patron source",
      document: {
        version: 2,
        updatedAt: "2026-07-17T10:00:00.000Z",
        documentTitle: "Patron source",
        presetId: "custom",
        dimensions: { width: 24, height: 18 },
        geometry: "square",
        selectedThreadCode: "310",
        selectedStitchId: "cross",
        camera: { x: 0, y: 0, zoom: 1 },
        snapshot: {},
        printSettings,
        conversion,
        provenance,
      },
      conversion,
      printSettings,
      provenance,
    });

    expect(project.provenance.sourceKey).toContain("pattern-sources/");
    expect(project.provenance.sourceMimeType).toBe("application/pdf");
    expect(project.provenance.sourcePage).toBe(3);
    expect(project.provenance.transformations).toContain("quantification-dmc");
    expect(project.document.provenance).toEqual(project.provenance);
  });
});

describe("planification PDF multipage", () => {
  it("respecte le format, l’orientation, le chevauchement et l’échelle", () => {
    const plan = getPatternPagePlan(
      { width: 100, height: 70 },
      { pageSize: "letter", orientation: "landscape", overlapCells: 4, cellSizeMm: 5 },
    );

    expect(plan.orientation).toBe("landscape");
    expect(plan.pageWidth).toBeCloseTo(279.4);
    expect(plan.pageHeight).toBeCloseTo(215.9);
    expect(plan.overlap).toBe(4);
    expect(plan.cell).toBe(5);
    expect(plan.tiles.length).toBeGreaterThan(1);
    expect(plan.tiles.every(tile => tile.x1 <= 100 && tile.y1 <= 70)).toBe(true);
  });

  it("réduit ou conserve le nombre de planches lorsque le papier grandit", () => {
    const options = { width: 120, height: 120 };
    const a4 = getPatternPagePlan(options, { pageSize: "a4", orientation: "portrait", overlapCells: 2, cellSizeMm: 4 });
    const a3 = getPatternPagePlan(options, { pageSize: "a3", orientation: "portrait", overlapCells: 2, cellSizeMm: 4 });
    expect(a3.tiles.length).toBeLessThanOrEqual(a4.tiles.length);
  });
});
