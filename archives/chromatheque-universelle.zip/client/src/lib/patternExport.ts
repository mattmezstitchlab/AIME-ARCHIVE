// Export documentaire — fichiers autonomes, grille vectorielle et distinction explicite entre données calculées et approximations écran DMC.

import { jsPDF } from "jspdf";
import type { DmcThread } from "@/data/dmcThreads";
import type { StitchDefinition } from "@/data/stitches";
import type { GridGeometry, PatternSnapshot } from "@/lib/embroidery";
import type { PrintSettings } from "@shared/pattern";

export type PatternExportOptions = {
  title: string;
  width: number;
  height: number;
  geometry: GridGeometry;
  snapshot: PatternSnapshot;
  threadsByCode: Map<string, DmcThread>;
  stitchesById: Map<string, StitchDefinition>;
};

type LegendEntry = {
  code: string;
  name: string;
  hex: string;
  count: number;
  stitches: string[];
};

export type PatternPageTile = {
  index: number;
  column: number;
  row: number;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
};

export type PatternPagePlan = {
  orientation: "landscape" | "portrait";
  pageWidth: number;
  pageHeight: number;
  cell: number;
  overlap: number;
  columns: number;
  rows: number;
  tiles: PatternPageTile[];
};

const SVG_NS = "http://www.w3.org/2000/svg";
const DEFAULT_MULTIPAGE_SETTINGS: PrintSettings = { pageSize: "a4", orientation: "auto", overlapCells: 2, cellSizeMm: 4 };
const PAGE_DIMENSIONS: Record<PrintSettings["pageSize"], readonly [number, number]> = {
  a4: [210, 297],
  a3: [297, 420],
  letter: [215.9, 279.4],
};

export function buildPatternSvg(options: PatternExportOptions) {
  const cell = 24;
  const gridWidth = options.width * cell;
  const gridHeight = options.height * cell;
  const legend = collectLegend(options);
  const legendRows = Math.max(1, Math.ceil(legend.length / 2));
  const documentWidth = Math.max(760, gridWidth + 112);
  const gridX = (documentWidth - gridWidth) / 2;
  const gridY = 112;
  const legendY = gridY + gridHeight + 62;
  const documentHeight = legendY + legendRows * 34 + 92;
  const geometryLabel = options.geometry === "square" ? "carrée" : options.geometry === "diamond" ? "losange" : "alvéolaire";

  const cells: string[] = [];
  for (let y = 0; y < options.height; y += 1) {
    for (let x = 0; x < options.width; x += 1) {
      const mark = options.snapshot[`${x}:${y}`];
      const thread = mark ? options.threadsByCode.get(mark.threadCode) : undefined;
      const stitch = mark ? options.stitchesById.get(mark.stitchId) : undefined;
      const left = gridX + x * cell;
      const top = gridY + y * cell;
      cells.push(svgCell(options.geometry, left, top, cell, thread?.hex ?? "#ffffff"));
      if (mark) {
        const color = readableText(thread?.hex ?? "#ffffff");
        cells.push(`<text x="${left + cell / 2}" y="${top + cell / 2 + 4}" text-anchor="middle" font-family="IBM Plex Mono,monospace" font-size="11" font-weight="700" fill="${color}">${escapeXml(stitch?.symbol ?? "×")}</text>`);
      }
    }
  }

  const labels = Array.from({ length: options.width }, (_, x) => x % 5 === 0
    ? `<text x="${gridX + x * cell + cell / 2}" y="${gridY - 10}" text-anchor="middle" class="axis">${x + 1}</text>`
    : "").join("") + Array.from({ length: options.height }, (_, y) => y % 5 === 0
    ? `<text x="${gridX - 12}" y="${gridY + y * cell + cell / 2 + 3}" text-anchor="end" class="axis">${y + 1}</text>`
    : "").join("");

  const legendItems = legend.length
    ? legend.map((entry, index) => {
      const column = index % 2;
      const row = Math.floor(index / 2);
      const x = 58 + column * (documentWidth / 2 - 12);
      const y = legendY + row * 34;
      const stitchText = entry.stitches.length ? ` · ${entry.stitches.join(", ")}` : "";
      return `<g transform="translate(${x} ${y})"><rect width="22" height="22" fill="${entry.hex}" stroke="#17211f" stroke-width="0.8"/><text x="32" y="9" class="legend-code">DMC ${escapeXml(entry.code)} · ${entry.count}</text><text x="32" y="22" class="legend-name">${escapeXml(entry.name + stitchText)}</text></g>`;
    }).join("")
    : `<text x="58" y="${legendY + 16}" class="legend-name">Aucun fil utilisé dans ce patron.</text>`;

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="${SVG_NS}" width="${documentWidth}" height="${documentHeight}" viewBox="0 0 ${documentWidth} ${documentHeight}" role="img" aria-labelledby="title description">
  <title id="title">${escapeXml(options.title)}</title>
  <desc id="description">Patron de broderie ${options.width} par ${options.height}, géométrie ${geometryLabel}, avec grille, symboles et légende DMC.</desc>
  <style>
    .micro{font:500 10px 'IBM Plex Mono',monospace;letter-spacing:1.4px;fill:#66716d}.title{font:600 28px Fraunces,serif;fill:#17211f}.meta{font:600 11px 'IBM Plex Mono',monospace;fill:#17211f}.axis{font:500 8px 'IBM Plex Mono',monospace;fill:#6f7976}.legend-code{font:700 10px 'IBM Plex Mono',monospace;fill:#17211f}.legend-name{font:400 9px 'IBM Plex Sans',sans-serif;fill:#65706c}.note{font:400 8px 'IBM Plex Sans',sans-serif;fill:#6f7976}
  </style>
  <rect width="100%" height="100%" fill="#ffffff"/>
  <path d="M38 48h16v-16h16v16h16v16H70v16H54V64H38z" fill="none" stroke="#0e7c66" stroke-width="2"/>
  <text x="106" y="38" class="micro">CHROMATHÈQUE UNIVERSELLE · ATELIER 01</text>
  <text x="106" y="70" class="title">${escapeXml(options.title)}</text>
  <text x="${documentWidth - 50}" y="42" text-anchor="end" class="meta">${options.width} × ${options.height} FACETTES</text>
  <text x="${documentWidth - 50}" y="62" text-anchor="end" class="micro">GÉOMÉTRIE ${geometryLabel.toUpperCase()}</text>
  <line x1="38" y1="92" x2="${documentWidth - 38}" y2="92" stroke="#d9dedb"/>
  ${labels}
  <g>${cells.join("")}</g>
  <text x="48" y="${legendY - 24}" class="micro">LÉGENDE DOCUMENTAIRE · ${legend.length} FIL${legend.length > 1 ? "S" : ""}</text>
  <line x1="48" y1="${legendY - 14}" x2="${documentWidth - 48}" y2="${legendY - 14}" stroke="#d9dedb"/>
  ${legendItems}
  <line x1="38" y1="${documentHeight - 54}" x2="${documentWidth - 38}" y2="${documentHeight - 54}" stroke="#d9dedb"/>
  <text x="38" y="${documentHeight - 34}" class="note">A · Les couleurs Hex associées aux fils DMC sont des approximations écran indicatives non officielles.</text>
  <text x="${documentWidth - 38}" y="${documentHeight - 34}" text-anchor="end" class="note">C · Grille et quantités calculées depuis le motif.</text>
</svg>`;
}

export function downloadPatternSvg(options: PatternExportOptions) {
  const svg = buildPatternSvg(options);
  downloadBlob(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }), `${slugify(options.title)}.svg`);
}

export async function downloadPatternPdf(options: PatternExportOptions) {
  const orientation = options.width >= options.height ? "landscape" : "portrait";
  const pdf = new jsPDF({ orientation, unit: "mm", format: "a4", compress: true });
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const margin = 12;
  const headerBottom = 30;
  const availableWidth = pageWidth - margin * 2;
  const availableHeight = pageHeight - headerBottom - 34;
  const cell = Math.min(availableWidth / options.width, availableHeight / options.height);
  const gridWidth = cell * options.width;
  const gridHeight = cell * options.height;
  const gridX = (pageWidth - gridWidth) / 2;
  const gridY = headerBottom + 8;
  const legend = collectLegend(options);

  pdf.setProperties({
    title: options.title,
    subject: "Patron de broderie — Chromathèque Universelle",
    author: "Chromathèque Universelle",
    keywords: "broderie, patron, DMC, grille, Chromathèque",
    creator: "Chromathèque Universelle",
  });
  drawPdfHeader(pdf, options, pageWidth, margin);
  drawPdfGrid(pdf, options, gridX, gridY, cell);

  const legendY = gridY + gridHeight + 8;
  if (legend.length <= 8 && legendY + Math.max(18, legend.length * 5.8) < pageHeight - 12) {
    drawPdfLegend(pdf, legend, margin, legendY, pageWidth, pageHeight);
  } else {
    pdf.addPage("a4", orientation);
    drawPdfHeader(pdf, options, pageWidth, margin, "LÉGENDE DMC");
    drawPdfLegend(pdf, legend, margin, 38, pageWidth, pageHeight);
  }

  pdf.save(`${slugify(options.title)}.pdf`);
}

export function getPatternPagePlan(
  options: Pick<PatternExportOptions, "width" | "height">,
  settings: PrintSettings = DEFAULT_MULTIPAGE_SETTINGS,
): PatternPagePlan {
  const orientation = settings.orientation === "auto"
    ? (options.width >= options.height ? "landscape" : "portrait")
    : settings.orientation;
  const [shortSide, longSide] = PAGE_DIMENSIONS[settings.pageSize];
  const pageWidth = orientation === "landscape" ? longSide : shortSide;
  const pageHeight = orientation === "landscape" ? shortSide : longSide;
  const margin = 10;
  const headerBottom = 31;
  const footerHeight = 14;
  const axisSpace = 7;
  const cell = settings.cellSizeMm;
  const overlap = settings.overlapCells;
  const columns = Math.max(6, Math.floor((pageWidth - margin * 2 - axisSpace) / cell));
  const rows = Math.max(6, Math.floor((pageHeight - headerBottom - footerHeight - axisSpace) / cell));
  const xStarts = makeTileStarts(options.width, columns, overlap);
  const yStarts = makeTileStarts(options.height, rows, overlap);
  const tiles: PatternPageTile[] = [];
  for (let row = 0; row < yStarts.length; row += 1) {
    const y0 = yStarts[row];
    for (let column = 0; column < xStarts.length; column += 1) {
      const x0 = xStarts[column];
      tiles.push({
        index: tiles.length,
        column,
        row,
        x0,
        y0,
        x1: Math.min(options.width, x0 + columns),
        y1: Math.min(options.height, y0 + rows),
      });
    }
  }
  return { orientation, pageWidth, pageHeight, cell, overlap, columns, rows, tiles };
}

export async function downloadPatternMultipagePdf(
  options: PatternExportOptions,
  settings: PrintSettings = DEFAULT_MULTIPAGE_SETTINGS,
) {
  const plan = getPatternPagePlan(options, settings);
  const pdf = new jsPDF({ orientation: plan.orientation, unit: "mm", format: settings.pageSize, compress: true });
  const legend = collectLegend(options);
  pdf.setProperties({
    title: `${options.title} — impression multipage`,
    subject: "Patron de broderie multipage avec plan d’assemblage",
    author: "Chromathèque Universelle",
    keywords: "broderie, patron, DMC, grille, impression multipage",
    creator: "Chromathèque Universelle",
  });

  drawPdfHeader(pdf, options, plan.pageWidth, 10, `PLAN D’ASSEMBLAGE · ${plan.tiles.length} FEUILLE${plan.tiles.length > 1 ? "S" : ""}`);
  drawPdfAssemblyOverview(pdf, options, plan);

  for (const tile of plan.tiles) {
    pdf.addPage(settings.pageSize, plan.orientation);
    drawPdfHeader(
      pdf,
      options,
      plan.pageWidth,
      10,
      `FEUILLE ${tile.index + 1}/${plan.tiles.length} · X ${tile.x0 + 1}–${tile.x1} · Y ${tile.y0 + 1}–${tile.y1}`,
    );
    drawPdfGridRegion(pdf, options, tile, 17, 38, plan.cell);
    drawPdfTileFooter(pdf, plan, tile);
  }

  pdf.addPage("a4", plan.orientation);
  drawPdfHeader(pdf, options, plan.pageWidth, 10, "LÉGENDE DMC · IMPRESSION MULTIPAGE");
  drawPdfLegend(pdf, legend, 10, 38, plan.pageWidth, plan.pageHeight);
  pdf.save(`${slugify(options.title)}-impression-multipage.pdf`);
}

function drawPdfHeader(pdf: jsPDF, options: PatternExportOptions, pageWidth: number, margin: number, eyebrow = "CHROMATHÈQUE UNIVERSELLE · ATELIER 01") {
  pdf.setDrawColor(14, 124, 102);
  pdf.setLineWidth(0.65);
  pdf.rect(margin, 11, 7, 7);
  pdf.rect(margin + 3.5, 14.5, 7, 7);
  pdf.setTextColor(101, 112, 108);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(7);
  pdf.text(eyebrow, margin + 15, 13.4);
  pdf.setTextColor(23, 33, 31);
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(16);
  pdf.text(options.title || "Motif sans titre", margin + 15, 21.2, { maxWidth: pageWidth - margin * 2 - 70 });
  pdf.setFont("courier", "bold");
  pdf.setFontSize(8);
  pdf.text(`${options.width} × ${options.height} FACETTES`, pageWidth - margin, 14, { align: "right" });
  pdf.setFont("courier", "normal");
  pdf.setFontSize(6.8);
  pdf.text(`GÉOMÉTRIE ${options.geometry.toUpperCase()}`, pageWidth - margin, 20, { align: "right" });
  pdf.setDrawColor(215, 221, 218);
  pdf.setLineWidth(0.2);
  pdf.line(margin, 27, pageWidth - margin, 27);
}

function drawPdfAssemblyOverview(pdf: jsPDF, options: PatternExportOptions, plan: PatternPagePlan) {
  const margin = 15;
  const top = 38;
  const availableWidth = plan.pageWidth - margin * 2;
  const availableHeight = plan.pageHeight - top - 24;
  const cell = Math.min(availableWidth / options.width, availableHeight / options.height);
  const gridWidth = options.width * cell;
  const gridHeight = options.height * cell;
  const startX = (plan.pageWidth - gridWidth) / 2;
  drawPdfGrid(pdf, options, startX, top, cell);

  pdf.setFont("courier", "bold");
  pdf.setFontSize(7);
  for (const tile of plan.tiles) {
    const left = startX + tile.x0 * cell;
    const y = top + tile.y0 * cell;
    const width = (tile.x1 - tile.x0) * cell;
    const height = (tile.y1 - tile.y0) * cell;
    pdf.setDrawColor(14, 124, 102);
    pdf.setLineWidth(0.55);
    pdf.rect(left, y, width, height);
    pdf.setFillColor(255, 255, 255);
    pdf.rect(left + 1, y + 1, 8, 5, "F");
    pdf.setTextColor(14, 124, 102);
    pdf.text(String(tile.index + 1).padStart(2, "0"), left + 2, y + 4.5);
  }

  pdf.setTextColor(96, 106, 102);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(7);
  pdf.text(`Chevauchement de ${plan.overlap} facettes entre feuilles · conserver les repères de coordonnées pour l’assemblage.`, margin, plan.pageHeight - 11);
}

function drawPdfGridRegion(pdf: jsPDF, options: PatternExportOptions, tile: PatternPageTile, startX: number, startY: number, cell: number) {
  const gridWidth = (tile.x1 - tile.x0) * cell;
  const gridHeight = (tile.y1 - tile.y0) * cell;
  pdf.setDrawColor(14, 124, 102);
  pdf.setLineWidth(0.55);
  pdf.rect(startX, startY, gridWidth, gridHeight);

  for (let x = tile.x0; x < tile.x1; x += 1) {
    if (x === tile.x0 || x === tile.x1 - 1 || x % 5 === 0) {
      pdf.setTextColor(70, 82, 77);
      pdf.setFont("courier", "normal");
      pdf.setFontSize(5.8);
      pdf.text(String(x + 1), startX + (x - tile.x0 + 0.5) * cell, startY - 2, { align: "center" });
    }
  }
  for (let y = tile.y0; y < tile.y1; y += 1) {
    if (y === tile.y0 || y === tile.y1 - 1 || y % 5 === 0) {
      pdf.setTextColor(70, 82, 77);
      pdf.setFont("courier", "normal");
      pdf.setFontSize(5.8);
      pdf.text(String(y + 1), startX - 2.2, startY + (y - tile.y0 + 0.66) * cell, { align: "right" });
    }
  }

  pdf.setLineWidth(0.14);
  for (let y = tile.y0; y < tile.y1; y += 1) {
    for (let x = tile.x0; x < tile.x1; x += 1) {
      const mark = options.snapshot[`${x}:${y}`];
      const thread = mark ? options.threadsByCode.get(mark.threadCode) : undefined;
      const stitch = mark ? options.stitchesById.get(mark.stitchId) : undefined;
      const left = startX + (x - tile.x0) * cell;
      const top = startY + (y - tile.y0) * cell;
      const rgb = hexToRgb(thread?.hex ?? "#ffffff");
      pdf.setFillColor(rgb.r, rgb.g, rgb.b);
      pdf.setDrawColor((x + 1) % 5 === 0 || (y + 1) % 5 === 0 ? 92 : 190);
      drawPdfCell(pdf, options.geometry, left, top, cell);
      if (mark) {
        const text = readableText(thread?.hex ?? "#ffffff") === "#ffffff" ? 255 : 23;
        pdf.setTextColor(text, text, text);
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(7.2);
        pdf.text(safePdfSymbol(stitch?.symbol), left + cell / 2, top + cell * 0.68, { align: "center" });
      }
    }
  }
}

function drawPdfTileFooter(pdf: jsPDF, plan: PatternPagePlan, tile: PatternPageTile) {
  const mapCell = 5;
  const mapWidth = Math.max(...plan.tiles.map((item) => item.column)) * mapCell + mapCell;
  const mapX = plan.pageWidth - 10 - mapWidth;
  const mapY = plan.pageHeight - 10 - (Math.max(...plan.tiles.map((item) => item.row)) + 1) * mapCell;
  for (const item of plan.tiles) {
    pdf.setFillColor(item.index === tile.index ? 14 : 232, item.index === tile.index ? 124 : 238, item.index === tile.index ? 102 : 235);
    pdf.setDrawColor(127, 139, 134);
    pdf.rect(mapX + item.column * mapCell, mapY + item.row * mapCell, mapCell - 0.5, mapCell - 0.5, "FD");
  }
  pdf.setTextColor(80, 91, 87);
  pdf.setFont("courier", "normal");
  pdf.setFontSize(6);
  pdf.text(`FEUILLE ${tile.index + 1}/${plan.tiles.length} · recouvrement ${plan.overlap} facettes`, 10, plan.pageHeight - 8);
}

function makeTileStarts(total: number, span: number, overlap: number) {
  if (total <= span) return [0];
  const starts = [0];
  while (starts.at(-1)! + span < total) {
    const next = Math.min(total - span, starts.at(-1)! + span - overlap);
    if (next <= starts.at(-1)!) break;
    starts.push(next);
  }
  return starts;
}

function drawPdfGrid(pdf: jsPDF, options: PatternExportOptions, startX: number, startY: number, cell: number) {
  pdf.setLineWidth(Math.max(0.08, Math.min(0.22, cell * 0.035)));
  for (let y = 0; y < options.height; y += 1) {
    for (let x = 0; x < options.width; x += 1) {
      const mark = options.snapshot[`${x}:${y}`];
      const thread = mark ? options.threadsByCode.get(mark.threadCode) : undefined;
      const stitch = mark ? options.stitchesById.get(mark.stitchId) : undefined;
      const left = startX + x * cell;
      const top = startY + y * cell;
      const rgb = hexToRgb(thread?.hex ?? "#ffffff");
      pdf.setFillColor(rgb.r, rgb.g, rgb.b);
      pdf.setDrawColor((x + 1) % 5 === 0 || (y + 1) % 5 === 0 ? 92 : 190);
      drawPdfCell(pdf, options.geometry, left, top, cell);
      if (mark && cell >= 2.6) {
        const text = readableText(thread?.hex ?? "#ffffff") === "#ffffff" ? 255 : 23;
        pdf.setTextColor(text, text, text);
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(Math.max(4, Math.min(8, cell * 1.55)));
        pdf.text(safePdfSymbol(stitch?.symbol), left + cell / 2, top + cell * 0.67, { align: "center" });
      }
    }
  }
}

function drawPdfLegend(pdf: jsPDF, legend: LegendEntry[], margin: number, startY: number, pageWidth: number, pageHeight: number) {
  pdf.setTextColor(23, 33, 31);
  pdf.setFont("courier", "bold");
  pdf.setFontSize(8);
  pdf.text(`LÉGENDE DOCUMENTAIRE · ${legend.length} FIL${legend.length > 1 ? "S" : ""}`, margin, startY);
  let y = startY + 7;
  const rowHeight = 7.5;
  if (!legend.length) {
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8);
    pdf.text("Aucun fil utilisé dans ce patron.", margin, y);
  }
  for (const entry of legend) {
    if (y + rowHeight > pageHeight - 18) {
      pdf.addPage();
      y = 20;
    }
    const rgb = hexToRgb(entry.hex);
    pdf.setFillColor(rgb.r, rgb.g, rgb.b);
    pdf.setDrawColor(23, 33, 31);
    pdf.rect(margin, y - 4.2, 5, 5, "FD");
    pdf.setTextColor(23, 33, 31);
    pdf.setFont("courier", "bold");
    pdf.setFontSize(7.4);
    pdf.text(`DMC ${entry.code} · ${entry.count}`, margin + 8, y - 1);
    pdf.setFont("helvetica", "normal");
    pdf.setTextColor(96, 106, 102);
    pdf.setFontSize(6.8);
    const label = `${entry.name}${entry.stitches.length ? ` · ${entry.stitches.join(", ")}` : ""}`;
    pdf.text(label, margin + 42, y - 1, { maxWidth: pageWidth - margin * 2 - 42 });
    y += rowHeight;
  }
  pdf.setDrawColor(215, 221, 218);
  pdf.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(5.8);
  pdf.setTextColor(105, 115, 111);
  pdf.text("A · Couleurs Hex DMC : approximations écran indicatives non officielles. C · Grille et quantités calculées.", margin, pageHeight - 9);
}

function drawPdfCell(pdf: jsPDF, geometry: GridGeometry, x: number, y: number, size: number) {
  if (geometry === "diamond") {
    pdf.triangle(x + size / 2, y, x + size, y + size / 2, x + size / 2, y + size, "FD");
    pdf.triangle(x + size / 2, y, x + size / 2, y + size, x, y + size / 2, "FD");
    return;
  }
  if (geometry === "hex") {
    const inset = size * 0.22;
    const path = [
      { op: "m" as const, c: [inset, 0] },
      { op: "l" as const, c: [size - inset * 2, 0] },
      { op: "l" as const, c: [inset, size / 2] },
      { op: "l" as const, c: [-(size - inset * 2), 0] },
      { op: "l" as const, c: [-inset, -size / 2] },
    ];
    pdf.path(path).fillStroke();
    return;
  }
  pdf.rect(x, y, size, size, "FD");
}

function collectLegend(options: PatternExportOptions): LegendEntry[] {
  const entries = new Map<string, { count: number; stitches: Set<string> }>();
  for (const mark of Object.values(options.snapshot)) {
    if (mark.x < 0 || mark.y < 0 || mark.x >= options.width || mark.y >= options.height) continue;
    const current = entries.get(mark.threadCode) ?? { count: 0, stitches: new Set<string>() };
    current.count += 1;
    const stitch = options.stitchesById.get(mark.stitchId);
    if (stitch) current.stitches.add(stitch.nameFr);
    entries.set(mark.threadCode, current);
  }
  return Array.from(entries.entries())
    .map(([code, usage]) => {
      const thread = options.threadsByCode.get(code);
      return { code, name: thread?.name ?? "Fil non indexé", hex: thread?.hex ?? "#ffffff", count: usage.count, stitches: Array.from(usage.stitches).sort() };
    })
    .sort((a, b) => b.count - a.count || a.code.localeCompare(b.code, "fr", { numeric: true }));
}

function svgCell(geometry: GridGeometry, x: number, y: number, size: number, fill: string) {
  const common = `fill="${fill}" stroke="#9aa39f" stroke-width="0.7"`;
  if (geometry === "diamond") return `<polygon points="${x + size / 2},${y} ${x + size},${y + size / 2} ${x + size / 2},${y + size} ${x},${y + size / 2}" ${common}/>`;
  if (geometry === "hex") return `<polygon points="${x + size * 0.22},${y} ${x + size * 0.78},${y} ${x + size},${y + size / 2} ${x + size * 0.78},${y + size} ${x + size * 0.22},${y + size} ${x},${y + size / 2}" ${common}/>`;
  return `<rect x="${x}" y="${y}" width="${size}" height="${size}" ${common}/>`;
}

function safePdfSymbol(symbol?: string) {
  if (!symbol) return "x";
  return /^[\x20-\x7E]$/.test(symbol) ? symbol : "x";
}

function readableText(hex: string) {
  const { r, g, b } = hexToRgb(hex);
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.58 ? "#17211f" : "#ffffff";
}

function hexToRgb(hex: string) {
  const normalized = hex.replace("#", "").padEnd(6, "0");
  return {
    r: Number.parseInt(normalized.slice(0, 2), 16) || 0,
    g: Number.parseInt(normalized.slice(2, 4), 16) || 0,
    b: Number.parseInt(normalized.slice(4, 6), 16) || 0,
  };
}

function escapeXml(value: string) {
  return value.replace(/[<>&"']/g, (character) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;" })[character] ?? character);
}

function slugify(value: string) {
  return (value || "motif-broderie").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "motif-broderie";
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
