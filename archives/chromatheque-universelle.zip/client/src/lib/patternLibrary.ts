import { syncedPatternProjectSchema, type SyncedPatternProject } from "@shared/pattern";

const LIBRARY_KEY = "chromatheque.pattern.library.v2";
const ACTIVE_PROJECT_KEY = "chromatheque.pattern.active.v2";

export type LocalPatternProject = SyncedPatternProject & {
  createdAt: string;
  updatedAt: string;
  syncState: "local" | "synced" | "pending";
};

type StoredLibrary = {
  version: 2;
  projects: LocalPatternProject[];
};

export function createProjectId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `pattern-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function listLocalProjects(): LocalPatternProject[] {
  if (typeof window === "undefined") return [];
  try {
    const value = JSON.parse(window.localStorage.getItem(LIBRARY_KEY) ?? "null") as unknown;
    if (!isRecord(value) || value.version !== 2 || !Array.isArray(value.projects)) return [];
    return value.projects
      .map(sanitizeProject)
      .filter((project): project is LocalPatternProject => Boolean(project))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    return [];
  }
}

export function saveLocalProject(
  project: SyncedPatternProject,
  syncState: LocalPatternProject["syncState"] = "local",
) {
  const now = new Date().toISOString();
  const projects = listLocalProjects();
  const existing = projects.find(item => item.clientId === project.clientId);
  const saved: LocalPatternProject = {
    ...project,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    syncState,
  };
  const next = [saved, ...projects.filter(item => item.clientId !== project.clientId)];
  persist(next);
  setActiveProjectId(project.clientId);
  return saved;
}

export function renameLocalProject(clientId: string, name: string) {
  const projects = listLocalProjects();
  const normalized = name.trim().slice(0, 160);
  if (!normalized) return null;
  let renamed: LocalPatternProject | null = null;
  const next = projects.map(project => {
    if (project.clientId !== clientId) return project;
    renamed = { ...project, name: normalized, updatedAt: new Date().toISOString(), syncState: project.syncState === "synced" ? "pending" : project.syncState };
    return renamed;
  });
  persist(next);
  return renamed;
}

export function deleteLocalProject(clientId: string) {
  persist(listLocalProjects().filter(project => project.clientId !== clientId));
  if (getActiveProjectId() === clientId) setActiveProjectId(null);
}

export function getLocalProject(clientId: string | null) {
  if (!clientId) return null;
  return listLocalProjects().find(project => project.clientId === clientId) ?? null;
}

export function getActiveProjectId() {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(ACTIVE_PROJECT_KEY);
}

export function setActiveProjectId(clientId: string | null) {
  if (typeof window === "undefined") return;
  if (clientId) window.localStorage.setItem(ACTIVE_PROJECT_KEY, clientId);
  else window.localStorage.removeItem(ACTIVE_PROJECT_KEY);
}

function persist(projects: LocalPatternProject[]) {
  if (typeof window === "undefined") return;
  const library: StoredLibrary = { version: 2, projects: projects.slice(0, 80) };
  window.localStorage.setItem(LIBRARY_KEY, JSON.stringify(library));
}

function sanitizeProject(value: unknown): LocalPatternProject | null {
  if (!isRecord(value)) return null;
  const parsed = syncedPatternProjectSchema.safeParse(value);
  if (!parsed.success) return null;
  return {
    ...parsed.data,
    createdAt: typeof value.createdAt === "string" ? value.createdAt : parsed.data.document.updatedAt,
    updatedAt: typeof value.updatedAt === "string" ? value.updatedAt : parsed.data.document.updatedAt,
    syncState: value.syncState === "synced" || value.syncState === "pending" ? value.syncState : "local",
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
