import { describe, expect, it } from "vitest";
import { hexToRgb, rgbToHex } from "@/lib/color";
import {
  buildHarmony,
  compositeOver,
  deltaE76,
  hslToRgb,
  paletteToCss,
  paletteToJson,
  rgbToHsl,
} from "@/lib/laboratory";

describe("Laboratoire couleur", () => {
  it("conserve une couleur lors d’un aller-retour RVB vers HSL", () => {
    const source = hexToRgb("#0E7C66");
    expect(rgbToHex(hslToRgb(rgbToHsl(source)))).toBe("#0E7C66");
  });

  it("construit les harmonies avec le nombre de spécimens attendu", () => {
    const source = hexToRgb("#0E7C66");
    expect(buildHarmony(source, "complementary")).toHaveLength(2);
    expect(buildHarmony(source, "analogous")).toHaveLength(3);
    expect(buildHarmony(source, "triadic")).toHaveLength(3);
    expect(buildHarmony(source, "tetradic")).toHaveLength(4);
  });

  it("compose exactement un premier plan semi-transparent sur un fond", () => {
    expect(compositeOver({ r: 255, g: 0, b: 0 }, { r: 255, g: 255, b: 255 }, 0.5)).toEqual({ r: 255, g: 128, b: 128 });
    expect(compositeOver({ r: 10, g: 20, b: 30 }, { r: 100, g: 110, b: 120 }, 0)).toEqual({ r: 100, g: 110, b: 120 });
  });

  it("retourne une distance nulle pour deux couleurs identiques", () => {
    const color = hexToRgb("#B66A3C");
    expect(deltaE76(color, color)).toBeCloseTo(0, 8);
    expect(deltaE76(hexToRgb("#000000"), hexToRgb("#FFFFFF"))).toBeGreaterThan(99);
  });

  it("exporte une palette lisible en CSS et JSON", () => {
    const colors = [hexToRgb("#0E7C66"), hexToRgb("#B66A3C")];
    expect(paletteToCss(colors)).toContain("--chromatique-1: #0E7C66;");
    expect(JSON.parse(paletteToJson(colors))).toEqual([
      { index: 1, hex: "#0E7C66", rgb: { r: 14, g: 124, b: 102 } },
      { index: 2, hex: "#B66A3C", rgb: { r: 182, g: 106, b: 60 } },
    ]);
  });
});
