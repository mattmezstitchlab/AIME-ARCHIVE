import { describe, expect, it } from "vitest";
import {
  bestTextColor,
  contrastRatio,
  hexToRgb,
  intToRgb,
  mortonDigitsToRgb,
  normalizeHex,
  parseColorQuery,
  prefixRange,
  rgbToCmyk,
  rgbToHex,
  rgbToInt,
  rgbToMortonDigits,
} from "./color";

describe("moteur chromatique", () => {
  it("normalise les écritures hexadécimales", () => {
    expect(normalizeHex("#0e7c66")).toBe("#0E7C66");
    expect(normalizeHex("abc")).toBe("#AABBCC");
    expect(normalizeHex("xyz")).toBeNull();
  });

  it("préserve exactement les 24 bits entre Hex, RVB et entier", () => {
    const samples = ["#000000", "#FFFFFF", "#0E7C66", "#123456", "#FF00AA"];
    for (const hex of samples) {
      const rgb = hexToRgb(hex);
      expect(rgbToHex(rgb)).toBe(hex);
      expect(intToRgb(rgbToInt(rgb))).toEqual(rgb);
    }
  });

  it("rend l’adresse octale Morton strictement réversible", () => {
    const samples = [
      { r: 0, g: 0, b: 0 },
      { r: 255, g: 255, b: 255 },
      { r: 14, g: 124, b: 102 },
      { r: 18, g: 52, b: 86 },
      { r: 255, g: 0, b: 170 },
    ];
    for (const rgb of samples) {
      const digits = rgbToMortonDigits(rgb);
      expect(digits).toHaveLength(8);
      expect(digits.every((digit) => digit >= 0 && digit <= 7)).toBe(true);
      expect(mortonDigitsToRgb(digits)).toEqual(rgb);
    }
  });

  it("définit correctement les bornes d’un préfixe octal", () => {
    expect(prefixRange([])).toEqual({
      min: { r: 0, g: 0, b: 0 },
      max: { r: 255, g: 255, b: 255 },
      center: { r: 128, g: 128, b: 128 },
    });
    const exact = prefixRange(rgbToMortonDigits({ r: 14, g: 124, b: 102 }));
    expect(exact.min).toEqual({ r: 14, g: 124, b: 102 });
    expect(exact.max).toEqual(exact.min);
  });

  it("calcule le CMJN indicatif avec les cas limites attendus", () => {
    expect(rgbToCmyk({ r: 0, g: 0, b: 0 })).toEqual({ c: 0, m: 0, y: 0, k: 100 });
    expect(rgbToCmyk({ r: 255, g: 255, b: 255 })).toEqual({ c: 0, m: 0, y: 0, k: 0 });
    expect(rgbToCmyk({ r: 255, g: 0, b: 0 })).toEqual({ c: 0, m: 100, y: 100, k: 0 });
  });

  it("analyse Hex, RGB et noms attestés", () => {
    expect(parseColorQuery("#0E7C66")).toEqual({ r: 14, g: 124, b: 102 });
    expect(parseColorQuery("rgb(14, 124, 102)")).toEqual({ r: 14, g: 124, b: 102 });
    expect(parseColorQuery("red")).toEqual({ r: 255, g: 0, b: 0 });
  });

  it("respecte les invariants WCAG de contraste", () => {
    expect(contrastRatio({ r: 0, g: 0, b: 0 }, { r: 255, g: 255, b: 255 })).toBeCloseTo(21, 5);
    expect(bestTextColor({ r: 0, g: 0, b: 0 })).toBe("#FFFFFF");
    expect(bestTextColor({ r: 255, g: 255, b: 255 })).toBe("#17211F");
  });
});
