export type PatternIntakeKind = "prompt" | "file";

export type PatternIntakeRequest = {
  id: string;
  kind: PatternIntakeKind;
  prompt: string | null;
  fileName: string | null;
  fileType: string | null;
  rightsConfirmedAt: string;
  targetWidth: number;
  targetHeight: number;
  maxColors: number;
  confettiThreshold: number;
  createdAt: string;
};

const DB_NAME = "chromatheque-pattern-intake";
const STORE = "requests";
const ACTIVE_KEY = "chromatheque.pattern.intake.active";

export async function queuePatternIntake(
  input: Omit<PatternIntakeRequest, "id" | "createdAt">,
  file?: File,
) {
  const id = crypto.randomUUID();
  const request: PatternIntakeRequest = { ...input, id, createdAt: new Date().toISOString() };
  const database = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE, "readwrite");
    transaction.objectStore(STORE).put({ ...request, file: file ?? null });
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Échec de la préparation de la source"));
  });
  window.sessionStorage.setItem(ACTIVE_KEY, id);
  return request;
}

export async function consumePatternIntake() {
  const id = window.sessionStorage.getItem(ACTIVE_KEY);
  if (!id) return null;
  const database = await openDatabase();
  const result = await new Promise<(PatternIntakeRequest & { file: File | null }) | null>((resolve, reject) => {
    const transaction = database.transaction(STORE, "readonly");
    const request = transaction.objectStore(STORE).get(id);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error ?? new Error("Source locale illisible"));
  });
  return result;
}

export async function clearPatternIntake(id: string) {
  const database = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE, "readwrite");
    transaction.objectStore(STORE).delete(id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Source locale impossible à retirer"));
  });
  if (window.sessionStorage.getItem(ACTIVE_KEY) === id) window.sessionStorage.removeItem(ACTIVE_KEY);
}

function openDatabase() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = window.indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE)) database.createObjectStore(STORE, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Stockage local indisponible"));
  });
}
