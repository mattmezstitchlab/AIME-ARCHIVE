// Atlas cinétique — les noms sont toujours rattachés à un corpus et les récits à une source.

export type NamedColor = {
  name: string;
  frenchName?: string;
  hex: string;
  corpus: "CSS" | "Projet";
  status?: "normatif" | "éditorial";
};

export const namedColors: NamedColor[] = [
  { name: "Black", frenchName: "Noir", hex: "#000000", corpus: "CSS", status: "normatif" },
  { name: "White", frenchName: "Blanc", hex: "#FFFFFF", corpus: "CSS", status: "normatif" },
  { name: "Red", frenchName: "Rouge", hex: "#FF0000", corpus: "CSS", status: "normatif" },
  { name: "Lime", frenchName: "Vert primaire", hex: "#00FF00", corpus: "CSS", status: "normatif" },
  { name: "Blue", frenchName: "Bleu", hex: "#0000FF", corpus: "CSS", status: "normatif" },
  { name: "Yellow", frenchName: "Jaune", hex: "#FFFF00", corpus: "CSS", status: "normatif" },
  { name: "Cyan", frenchName: "Cyan", hex: "#00FFFF", corpus: "CSS", status: "normatif" },
  { name: "Magenta", frenchName: "Magenta", hex: "#FF00FF", corpus: "CSS", status: "normatif" },
  { name: "Gray", frenchName: "Gris", hex: "#808080", corpus: "CSS", status: "normatif" },
  { name: "Silver", frenchName: "Argent", hex: "#C0C0C0", corpus: "CSS", status: "normatif" },
  { name: "Maroon", frenchName: "Marron sombre", hex: "#800000", corpus: "CSS", status: "normatif" },
  { name: "Olive", frenchName: "Olive", hex: "#808000", corpus: "CSS", status: "normatif" },
  { name: "Green", frenchName: "Vert", hex: "#008000", corpus: "CSS", status: "normatif" },
  { name: "Purple", frenchName: "Pourpre", hex: "#800080", corpus: "CSS", status: "normatif" },
  { name: "Teal", frenchName: "Sarcelle", hex: "#008080", corpus: "CSS", status: "normatif" },
  { name: "Navy", frenchName: "Bleu marine", hex: "#000080", corpus: "CSS", status: "normatif" },
  { name: "Orange", frenchName: "Orange", hex: "#FFA500", corpus: "CSS", status: "normatif" },
  { name: "Gold", frenchName: "Or", hex: "#FFD700", corpus: "CSS", status: "normatif" },
  { name: "Coral", frenchName: "Corail", hex: "#FF7F50", corpus: "CSS", status: "normatif" },
  { name: "Tomato", frenchName: "Tomate", hex: "#FF6347", corpus: "CSS", status: "normatif" },
  { name: "Crimson", frenchName: "Cramoisi", hex: "#DC143C", corpus: "CSS", status: "normatif" },
  { name: "Salmon", frenchName: "Saumon", hex: "#FA8072", corpus: "CSS", status: "normatif" },
  { name: "Khaki", frenchName: "Kaki", hex: "#F0E68C", corpus: "CSS", status: "normatif" },
  { name: "Plum", frenchName: "Prune", hex: "#DDA0DD", corpus: "CSS", status: "normatif" },
  { name: "Orchid", frenchName: "Orchidée", hex: "#DA70D6", corpus: "CSS", status: "normatif" },
  { name: "Indigo", frenchName: "Indigo", hex: "#4B0082", corpus: "CSS", status: "normatif" },
  { name: "Violet", frenchName: "Violet", hex: "#EE82EE", corpus: "CSS", status: "normatif" },
  { name: "Pink", frenchName: "Rose", hex: "#FFC0CB", corpus: "CSS", status: "normatif" },
  { name: "HotPink", frenchName: "Rose vif", hex: "#FF69B4", corpus: "CSS", status: "normatif" },
  { name: "DeepPink", frenchName: "Rose profond", hex: "#FF1493", corpus: "CSS", status: "normatif" },
  { name: "Turquoise", frenchName: "Turquoise", hex: "#40E0D0", corpus: "CSS", status: "normatif" },
  { name: "Aquamarine", frenchName: "Aigue-marine", hex: "#7FFFD4", corpus: "CSS", status: "normatif" },
  { name: "SkyBlue", frenchName: "Bleu ciel", hex: "#87CEEB", corpus: "CSS", status: "normatif" },
  { name: "SteelBlue", frenchName: "Bleu acier", hex: "#4682B4", corpus: "CSS", status: "normatif" },
  { name: "RoyalBlue", frenchName: "Bleu royal", hex: "#4169E1", corpus: "CSS", status: "normatif" },
  { name: "MidnightBlue", frenchName: "Bleu nuit", hex: "#191970", corpus: "CSS", status: "normatif" },
  { name: "SeaGreen", frenchName: "Vert de mer", hex: "#2E8B57", corpus: "CSS", status: "normatif" },
  { name: "ForestGreen", frenchName: "Vert forêt", hex: "#228B22", corpus: "CSS", status: "normatif" },
  { name: "OliveDrab", frenchName: "Olive terne", hex: "#6B8E23", corpus: "CSS", status: "normatif" },
  { name: "Chocolate", frenchName: "Chocolat", hex: "#D2691E", corpus: "CSS", status: "normatif" },
  { name: "Sienna", frenchName: "Terre de Sienne", hex: "#A0522D", corpus: "CSS", status: "normatif" },
  { name: "Peru", frenchName: "Pérou", hex: "#CD853F", corpus: "CSS", status: "normatif" },
  { name: "Beige", frenchName: "Beige", hex: "#F5F5DC", corpus: "CSS", status: "normatif" },
  { name: "Ivory", frenchName: "Ivoire", hex: "#FFFFF0", corpus: "CSS", status: "normatif" },
  { name: "Snow", frenchName: "Neige", hex: "#FFFAFA", corpus: "CSS", status: "normatif" },
  { name: "SlateGray", frenchName: "Gris ardoise", hex: "#708090", corpus: "CSS", status: "normatif" },
  { name: "RebeccaPurple", frenchName: "Pourpre Rebecca", hex: "#663399", corpus: "CSS", status: "normatif" },
  { name: "ChromatomeGreen", frenchName: "Vert Chromatome", hex: "#0E7C66", corpus: "Projet", status: "éditorial" },
];

export type ArchiveRecord = {
  title: string;
  subtitle: string;
  period: string;
  kind: string;
  confidence: "A" | "B";
  displayHex: string;
  note: string;
  sourceLabel: string;
  sourceUrl: string;
};

export const archiveRecords: ArchiveRecord[] = [
  {
    title: "Vert de Scheele",
    subtitle: "Pigment arsenical documenté",
    period: "1775 — XIXe siècle",
    kind: "Pigment devenu obsolète",
    confidence: "B",
    displayHex: "#3A8F59",
    note: "L’Hex est une évocation d’écran, pas une identité matérielle. L’usage de pigments arsenicaux dans les papiers peints a progressivement disparu.",
    sourceLabel: "Saint Louis Art Museum",
    sourceUrl: "https://www.slam.org/blog/arsenic-in-victorian-wallpaper/",
  },
  {
    title: "Pourpre de Tyr",
    subtitle: "Colorant historique patrimonial",
    period: "Antiquité",
    kind: "Matériau rare documenté",
    confidence: "B",
    displayHex: "#6C2F5B",
    note: "La collection Forbes conserve des matériaux historiques. Toute valeur Web n’est qu’une approximation contextualisée de l’apparence.",
    sourceLabel: "Harvard Art Museums",
    sourceUrl: "https://harvardartmuseums.org/article/pigment-collection-colors-all-aspects-of-the-museums",
  },
  {
    title: "Bleu égyptien",
    subtitle: "Pigment synthétique ancien",
    period: "Antiquité — aujourd’hui étudié",
    kind: "Trace matérielle retrouvée",
    confidence: "B",
    displayHex: "#2E5EAA",
    note: "Le corpus muséal relie composition, origine, période et analyses ; il ne réduit pas le pigment à un code Hex unique.",
    sourceLabel: "Forbes Pigment Collection",
    sourceUrl: "https://cameo.mfa.org/wiki/Forbes_Pigment_Database",
  },
];
