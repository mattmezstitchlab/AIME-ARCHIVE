// Atlas cinétique — atlas de points évolutif : descriptions originales, provenance visible, aucune prétention d’exhaustivité mondiale.

import type { StitchGeometry } from "@/lib/embroidery";

export type StitchDefinition = {
  id: string;
  nameFr: string;
  nameEn: string;
  family: string;
  geometry: StitchGeometry;
  symbol: string;
  culture: string;
  support: string;
  sourceLabel: string;
  sourceUrl: string;
};

const RSN = "https://rsnstitchbank.org/";
const DMC_CROSS = "https://www.dmc.com/FR/fr/sbs-cross-stitch-stitch-diagrams";
const DMC_EMBROIDERY = "https://www.dmc.com/DE/fr/sbs-embroidery-stitch-diagrams";
const EGA_BLACKWORK = "https://egausa.org/embroidery-techniques-from-around-the-world-blackwork/";
const EGA_CREWEL = "https://egausa.org/embroidery-techniques-from-around-the-world-crewel/";

export const stitches: StitchDefinition[] = [
  { id: "cross", nameFr: "Point de croix", nameEn: "Cross stitch", family: "Points comptés", geometry: "cross", symbol: "×", culture: "Diffusion internationale", support: "Toile à trame régulière", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_CROSS },
  { id: "half-cross", nameFr: "Demi-point", nameEn: "Half cross", family: "Points comptés", geometry: "half", symbol: "╱", culture: "Diffusion internationale", support: "Toile à trame régulière", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_CROSS },
  { id: "quarter-cross", nameFr: "Quart de point", nameEn: "Quarter stitch", family: "Points comptés", geometry: "quarter", symbol: "⌜", culture: "Diffusion internationale", support: "Toile à trame régulière", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_CROSS },
  { id: "three-quarter", nameFr: "Trois-quarts", nameEn: "Three-quarter stitch", family: "Points comptés", geometry: "three-quarter", symbol: "⋊", culture: "Diffusion internationale", support: "Toile à trame régulière", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_CROSS },
  { id: "backstitch", nameFr: "Point arrière", nameEn: "Back stitch", family: "Ligne et contour", geometry: "line", symbol: "—", culture: "Diffusion internationale", support: "Tous supports", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "running", nameFr: "Point avant", nameEn: "Running stitch", family: "Ligne et contour", geometry: "line", symbol: "╌", culture: "Diffusion internationale ; kantha et sashiko selon contexte", support: "Tous supports", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "stem", nameFr: "Point de tige", nameEn: "Stem stitch", family: "Ligne et contour", geometry: "line", symbol: "〰", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "split", nameFr: "Point fendu", nameEn: "Split stitch", family: "Ligne et contour", geometry: "line", symbol: "≋", culture: "Europe et diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "chain", nameFr: "Point de chaînette", nameEn: "Chain stitch", family: "Boucles", geometry: "loop", symbol: "∞", culture: "Diffusion internationale ; chikankari selon variantes", support: "Tissu libre", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_EMBROIDERY },
  { id: "detached-chain", nameFr: "Chaînette détachée", nameEn: "Detached chain", family: "Boucles", geometry: "loop", symbol: "◇", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "blanket", nameFr: "Point de feston", nameEn: "Blanket stitch", family: "Bordure", geometry: "line", symbol: "┴", culture: "Diffusion internationale", support: "Bordures et appliqués", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "satin", nameFr: "Passé plat", nameEn: "Satin stitch", family: "Remplissage", geometry: "fill", symbol: "▰", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_EMBROIDERY },
  { id: "long-short", nameFr: "Passé empiétant", nameEn: "Long and short stitch", family: "Remplissage", geometry: "fill", symbol: "▥", culture: "Diffusion internationale ; peinture à l’aiguille", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "brick", nameFr: "Point de brique", nameEn: "Brick stitch", family: "Remplissage", geometry: "fill", symbol: "▦", culture: "Diffusion internationale", support: "Tissu libre ou compté", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "french-knot", nameFr: "Nœud français", nameEn: "French knot", family: "Nœuds", geometry: "knot", symbol: "●", culture: "Diffusion internationale", support: "Tous supports", sourceLabel: "DMC — diagrammes", sourceUrl: DMC_EMBROIDERY },
  { id: "colonial-knot", nameFr: "Nœud colonial", nameEn: "Colonial knot", family: "Nœuds", geometry: "knot", symbol: "◎", culture: "Tradition occidentale", support: "Tous supports", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "bullion", nameFr: "Point de poste", nameEn: "Bullion knot", family: "Relief", geometry: "knot", symbol: "◉", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "couching", nameFr: "Couchure", nameEn: "Couching", family: "Fils couchés", geometry: "couching", symbol: "⊢", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "herringbone", nameFr: "Point de chausson", nameEn: "Herringbone stitch", family: "Croisés", geometry: "cross", symbol: "≪", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "fly", nameFr: "Point de mouche", nameEn: "Fly stitch", family: "Boucles", geometry: "loop", symbol: "∨", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "feather", nameFr: "Point d’épine", nameEn: "Feather stitch", family: "Bordure", geometry: "line", symbol: "⋔", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "seed", nameFr: "Point de semis", nameEn: "Seed stitch", family: "Remplissage", geometry: "fill", symbol: "∴", culture: "Diffusion internationale", support: "Tissu libre", sourceLabel: "RSN Stitch Bank", sourceUrl: RSN },
  { id: "blackwork-double-running", nameFr: "Point Holbein", nameEn: "Double running stitch", family: "Blackwork", geometry: "line", symbol: "═", culture: "Blackwork européen", support: "Toile comptée", sourceLabel: "Embroiderers’ Guild of America", sourceUrl: EGA_BLACKWORK },
  { id: "crewel-chain", nameFr: "Chaînette crewel", nameEn: "Crewel chain", family: "Crewel", geometry: "loop", symbol: "⛓", culture: "Broderie crewel", support: "Tissu sergé ou lin", sourceLabel: "Embroiderers’ Guild of America", sourceUrl: EGA_CREWEL },
];

export const stitchFamilies = Array.from(new Set(stitches.map((stitch) => stitch.family)));
