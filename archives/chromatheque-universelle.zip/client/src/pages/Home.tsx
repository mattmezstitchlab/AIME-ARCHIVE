// Atlas cinétique — composition asymétrique : instrumentation, territoire, preuve et lecture éditoriale.

import { useCallback, useMemo, useState } from "react";
import { ArrowDown, ArrowRight, BookOpen, Braces, Database, Menu, Search, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import ChromatomeMap from "@/components/ChromatomeMap";
import ColorInspector from "@/components/ColorInspector";
import ResearchArchive from "@/components/ResearchArchive";
import PatternGeneratorSection from "@/components/PatternGeneratorSection";
import { namedColors } from "@/data/colorCorpus";
import {
  hexToRgb,
  parseColorQuery,
  prefixRange,
  rgbToHex,
  rgbToMortonDigits,
  type RGB,
} from "@/lib/color";

const HERO_URL = "/manus-storage/chromatheque-future-embroidery-hero_f16b0d46.png";
const MARK_URL = "/manus-storage/chromatheque-octal-thread-symbol-clean_ec5d4069.png";

export default function Home() {
  const [prefix, setPrefix] = useState<number[]>([]);
  const [selected, setSelected] = useState<RGB>(() => hexToRgb("#0E7C66"));
  const [preview, setPreview] = useState<RGB | null>(null);
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);

  const currentRange = useMemo(() => prefixRange(prefix), [prefix]);

  const handlePrefixChange = useCallback((digits: number[]) => {
    setPrefix(digits);
    setSelected(prefixRange(digits).center);
    setPreview(null);
  }, []);

  const handleExactChange = useCallback((rgb: RGB) => {
    setSelected(rgb);
    setPrefix(rgbToMortonDigits(rgb));
  }, []);

  const runSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const result = parseColorQuery(query);
    if (!result) {
      toast.error("Couleur introuvable", { description: "Essayez #0E7C66, rgb(14, 124, 102) ou RebeccaPurple." });
      return;
    }
    handleExactChange(result);
    setQuery(rgbToHex(result));
    document.getElementById("explorer")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand brand-symbolic" href="#top" aria-label="Chromathèque Universelle, accueil">
          <img src={MARK_URL} alt="" />
          <span aria-hidden="true"><strong>U·24</strong><small>ATLAS CINÉTIQUE</small></span>
        </a>
        <nav className={menuOpen ? "is-open" : ""} aria-label="Navigation principale">
          <a href="#explorer" onClick={() => setMenuOpen(false)}>Explorer</a>
          <a href="#generateur" onClick={() => setMenuOpen(false)}>Générer</a>
          <a href="/laboratoire" onClick={() => setMenuOpen(false)}>Laboratoire</a>
          <a href="/atelier" onClick={() => setMenuOpen(false)}>Atelier</a>
          <a href="#methode" onClick={() => setMenuOpen(false)}>Méthode</a>
          <a href="#archives" onClick={() => setMenuOpen(false)}>Archives</a>
          <a href="#sources" onClick={() => setMenuOpen(false)}>Sources</a>
        </nav>
        <div className="topbar-counter"><span>ADRESSES</span><strong>16 777 216</strong></div>
        <button className="mobile-menu" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Ouvrir le menu">
          {menuOpen ? <X /> : <Menu />}
        </button>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-art"><img src={HERO_URL} alt="Paysage futuriste composé de fils lumineux, de facettes textiles et de broderies cartographiques" /></div>
          <div className="hero-copy">
            <p className="hero-index">ATLAS NUMÉRIQUE · ÉDITION 01</p>
            <h1>Chaque couleur du Web.<br /><em>Une adresse, une trace.</em></h1>
            <p className="hero-lead">
              Une carte calculée des <strong>16 777 216 nuances sRGB</strong>, conçue pour explorer sans confondre le code écran, la perception, l’impression et l’histoire matérielle.
            </p>
            <form className="universal-search" onSubmit={runSearch}>
              <Search size={18} />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                list="named-colors"
                placeholder="#0E7C66 · rgb(14, 124, 102) · nom CSS"
                aria-label="Rechercher une couleur par Hex, RGB ou nom"
              />
              <datalist id="named-colors">{namedColors.map((color) => <option key={color.name} value={color.name}>{color.hex}</option>)}</datalist>
              <button type="submit">Localiser <ArrowRight size={16} /></button>
            </form>
            <div className="hero-note"><span className="proof-shape">A</span> Les 16,7 millions d’adresses sont générées à la demande ; seuls les noms et documents attestés sont indexés.</div>
            <a className="scroll-cue" href="#explorer"><ArrowDown size={15} /> Entrer dans le Chromatome</a>
          </div>
          <div className="hero-atlas-instrument" aria-hidden="true">
            <div className="hero-atlas-address"><span>ADRESSE OCTALE</span><strong>0·2·7·4·1·6·3·5</strong></div>
            <div className="hero-atlas-origin"><i />ORIGINE · U·24</div>
            <div className="hero-atlas-scale"><span>0</span><i /><span>16 777 216</span></div>
            <div className="hero-atlas-coordinate">R 014<br />V 124<br />B 102</div>
          </div>
          <div className="hero-axis" aria-hidden="true"><span>R</span><span>V</span><span>B</span></div>
        </section>

        <PatternGeneratorSection />

        <section className="explorer-section" id="explorer">
          <div className="explorer-rail">
            <div className="rail-label">COORDONNÉES</div>
            <div className="rail-coordinate"><span>HEX</span><strong>{rgbToHex(selected)}</strong></div>
            <div className="rail-coordinate"><span>OCTAL</span><strong>{prefix.length ? prefix.join("") : "∅"}</strong></div>
            <div className="rail-coordinate"><span>NIVEAU</span><strong>{prefix.length}/8</strong></div>
            <div className="rail-scale">
              {Array.from({ length: 9 }, (_, index) => <span key={index} className={index <= prefix.length ? "active" : ""}>{index}</span>)}
            </div>
            <div className="rail-caption">Emprise<br />{Math.pow(8, 8 - prefix.length).toLocaleString("fr-FR")} teinte{prefix.length === 8 ? "" : "s"}</div>
          </div>

          <ChromatomeMap prefix={prefix} onChange={handlePrefixChange} onPreview={setPreview} />
          <ColorInspector rgb={selected} previewRgb={preview} onChange={handleExactChange} />

          <div className="explorer-footnote">
            <span>EMPRISE RVB</span>
            <code>R {currentRange.min.r}–{currentRange.max.r} / V {currentRange.min.g}–{currentRange.max.g} / B {currentRange.min.b}–{currentRange.max.b}</code>
          </div>
        </section>

        <section className="method-section" id="methode">
          <div className="method-intro">
            <p className="eyebrow"><Braces size={14} /> innovation d’affichage</p>
            <h2>Huit décisions.<br /><em>Une couleur exacte.</em></h2>
            <p>
              Le Chromatome ne dessine pas seize millions de cases. Il partitionne simultanément les huit bits de rouge, vert et bleu. À chaque niveau, huit branches divisent le cube RVB ; après huit choix, l’adresse est exacte et réversible.
            </p>
            <a href="#explorer">Tester le parcours <ArrowRight size={15} /></a>
          </div>
          <div className="method-steps">
            <article><span>01</span><Database /><h3>Adresse calculée</h3><p>Chaque couleur est un entier de 0 à 16 777 215. Aucune table géante n’est nécessaire pour calculer Hex et RVB.</p></article>
            <article><span>02</span><Braces /><h3>Chemin octal</h3><p>Un chiffre de 0 à 7 encode un bit de chacun des trois canaux. Huit chiffres suffisent pour retrouver la couleur sans perte.</p></article>
            <article><span>03</span><BookOpen /><h3>Document séparé</h3><p>Les noms, pigments, retraits et récits sont des couches sourcées, jamais des propriétés inventées de l’adresse numérique.</p></article>
          </div>
          <div className="method-equation" aria-label="Formule du nombre total de couleurs">
            <span>2<sup>8</sup></span><b>×</b><span>2<sup>8</sup></span><b>×</b><span>2<sup>8</sup></span><b>=</b><strong>16 777 216</strong>
          </div>
        </section>

        <ResearchArchive />

        <section className="sources-section" id="sources">
          <div>
            <p className="eyebrow">socle vérifiable</p>
            <h2>Normes, science<br />et limites déclarées.</h2>
          </div>
          <div className="source-grid">
            <a href="https://www.w3.org/TR/css-color-4/" target="_blank" rel="noreferrer"><span>01 / NORME</span><strong>CSS Color Module Level 4</strong><p>Définition des couleurs sRGB et des mots-clés CSS.</p></a>
            <a href="https://www.color.org/" target="_blank" rel="noreferrer"><span>02 / IMPRESSION</span><strong>International Color Consortium</strong><p>Profils de couleur et conversions vers un périphérique de destination.</p></a>
            <a href="https://cie.co.at/publications/colorimetry-part-6-ciede2000-colour-difference-formula" target="_blank" rel="noreferrer"><span>03 / PERCEPTION</span><strong>CIEDE2000</strong><p>Cadre normatif de différence colorimétrique perceptuelle.</p></a>
            <a href="https://www.w3.org/WAI/WCAG22/Understanding/use-of-color" target="_blank" rel="noreferrer"><span>04 / ACCÈS</span><strong>WCAG 2.2</strong><p>La couleur ne doit jamais être le seul moyen de transmettre une information.</p></a>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="brand brand-symbolic footer-brand" aria-label="Chromathèque Universelle"><img src={MARK_URL} alt="" /><span aria-hidden="true"><strong>U·24</strong><small>ATLAS CINÉTIQUE</small></span></div>
        <p>Une couleur d’écran n’est ni un pigment, ni une encre, ni une vérité culturelle universelle.</p>
        <div><a href="#top">Haut de page</a><span>·</span><a href="#sources">Sources</a></div>
      </footer>
    </div>
  );
}
