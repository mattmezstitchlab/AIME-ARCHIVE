import { useMemo, useState } from "react";
import { ArrowLeft, Copy, Download, Menu, Search, X } from "lucide-react";
import { toast } from "sonner";
import {
  bestTextColor,
  contrastRatio,
  hexToRgb,
  normalizeHex,
  parseColorQuery,
  rgbToCmyk,
  rgbToHex,
  rgbToMortonDigits,
  rgbToOklch,
  type RGB,
} from "@/lib/color";
import {
  buildHarmony,
  compositeOver,
  deltaE76,
  paletteToCss,
  paletteToJson,
  rgbToHsl,
  type HarmonyKind,
} from "@/lib/laboratory";

const MARK_URL = "/manus-storage/chromatheque-octal-thread-symbol-clean_ec5d4069.png";
const harmonyLabels: Record<HarmonyKind, string> = {
  complementary: "Complémentaire",
  analogous: "Analogues",
  triadic: "Triadique",
  tetradic: "Tétradique",
};

function ColorEntry({ id, label, value, onChange }: { id: string; label: string; value: string; onChange: (value: string) => void }) {
  const normalized = normalizeHex(value) ?? "#000000";
  return (
    <label className="lab-color-entry" htmlFor={id}>
      <span>{label}</span>
      <span className="lab-color-entry-row">
        <input id={`${id}-picker`} type="color" value={normalized} onChange={event => onChange(event.target.value.toUpperCase())} aria-label={`${label}, sélecteur visuel`} />
        <input id={id} value={value} onChange={event => onChange(event.target.value)} spellCheck={false} aria-label={`${label}, valeur Hex`} />
      </span>
    </label>
  );
}

function downloadText(filename: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export default function Laboratoire() {
  const [primaryInput, setPrimaryInput] = useState("#0E7C66");
  const [comparisonInput, setComparisonInput] = useState("#B66A3C");
  const [backgroundInput, setBackgroundInput] = useState("#F2F0E8");
  const [harmonyKind, setHarmonyKind] = useState<HarmonyKind>("analogous");
  const [alpha, setAlpha] = useState(72);
  const [menuOpen, setMenuOpen] = useState(false);

  const primary = useMemo(() => parseColorQuery(primaryInput) ?? hexToRgb("#0E7C66"), [primaryInput]);
  const comparison = useMemo(() => parseColorQuery(comparisonInput) ?? hexToRgb("#B66A3C"), [comparisonInput]);
  const background = useMemo(() => parseColorQuery(backgroundInput) ?? hexToRgb("#F2F0E8"), [backgroundInput]);
  const harmony = useMemo(() => buildHarmony(primary, harmonyKind), [primary, harmonyKind]);
  const composite = useMemo(() => compositeOver(primary, background, alpha / 100), [primary, background, alpha]);
  const hsl = rgbToHsl(primary);
  const oklch = rgbToOklch(primary);
  const cmyk = rgbToCmyk(primary);
  const octal = rgbToMortonDigits(primary).join("·");
  const contrast = contrastRatio(primary, comparison);
  const delta = deltaE76(primary, comparison);

  const copyPalette = async () => {
    await navigator.clipboard.writeText(paletteToCss(harmony));
    toast.success("Palette CSS copiée");
  };

  return (
    <div className="site-shell lab-shell">
      <header className="topbar lab-topbar">
        <a className="brand brand-symbolic" href="/" aria-label="Chromathèque Universelle, accueil">
          <img src={MARK_URL} alt="" />
          <span aria-hidden="true"><strong>U·24</strong><small>LABORATOIRE·01</small></span>
        </a>
        <nav className={menuOpen ? "is-open" : ""} aria-label="Navigation principale">
          <a href="/#explorer">Explorer</a>
          <a href="/#generateur">Générer</a>
          <a href="/laboratoire" aria-current="page">Laboratoire</a>
          <a href="/atelier">Atelier</a>
          <a href="/#sources">Sources</a>
        </nav>
        <div className="topbar-counter"><span>ESPACE</span><strong>sRGB · 24 BITS</strong></div>
        <button className="mobile-menu" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Fermer le menu" : "Ouvrir le menu"}>
          {menuOpen ? <X /> : <Menu />}
        </button>
      </header>

      <main className="lab-main">
        <section className="lab-hero">
          <div className="lab-hero-copy">
            <a className="lab-back" href="/"><ArrowLeft size={14} /> Retour à l’Atlas</a>
            <p className="eyebrow"><Search size={14} /> module d’analyse · L·24</p>
            <h1>Observer une couleur.<br /><em>Mesurer ses relations.</em></h1>
            <p>Le Laboratoire réunit les outils opérationnels de Chromaverse dans le langage de la Chromathèque : harmonies calculées, transparence, comparaison et exports. Les valeurs d’impression restent des approximations sans profil ICC.</p>
          </div>
          <div className="lab-hero-specimen" style={{ background: rgbToHex(primary), color: bestTextColor(primary) }}>
            <span>SPÉCIMEN ACTIF · ADRESSE L·24</span>
            <strong>{rgbToHex(primary)}</strong>
            <div className="lab-octal-address" aria-label={`Adresse octale ${octal}`}>
              {rgbToMortonDigits(primary).map((digit, index) => <i key={`${digit}-${index}`}><small>{index + 1}</small>{digit}</i>)}
            </div>
          </div>
        </section>

        <section className="lab-grid" aria-label="Outils du Laboratoire couleur">
          <article className="lab-panel lab-primary-panel">
            <div className="lab-panel-head"><span>01</span><div><small>A · ANALYSE CALCULÉE</small><h2>Couleur active</h2></div></div>
            <ColorEntry id="lab-primary" label="Hex, RGB ou nom CSS" value={primaryInput} onChange={setPrimaryInput} />
            <div className="lab-metrics">
              <div><span>RVB</span><strong>{primary.r} · {primary.g} · {primary.b}</strong></div>
              <div><span>HSL</span><strong>{hsl.h.toFixed(1)}° · {hsl.s.toFixed(1)} % · {hsl.l.toFixed(1)} %</strong></div>
              <div><span>OKLCH</span><strong>{oklch.l.toFixed(1)} · {oklch.c.toFixed(3)} · {oklch.h.toFixed(1)}°</strong></div>
              <div><span>CMJN*</span><strong>{cmyk.c} · {cmyk.m} · {cmyk.y} · {cmyk.k} %</strong></div>
            </div>
            <p className="lab-caveat">* Conversion mathématique indicative. Le rendu imprimé dépend du support, de l’encre et du profil de destination.</p>
          </article>

          <article className="lab-panel lab-harmony-panel">
            <div className="lab-panel-head"><span>02</span><div><small>A · HARMONIES CALCULÉES</small><h2>Relations de teinte</h2></div></div>
            <label className="lab-select-label" htmlFor="harmony-kind">Construction</label>
            <select id="harmony-kind" value={harmonyKind} onChange={event => setHarmonyKind(event.target.value as HarmonyKind)}>
              {Object.entries(harmonyLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
            <div className="lab-palette" aria-label={`Palette ${harmonyLabels[harmonyKind]}`}>
              {harmony.map((color, index) => (
                <button key={`${rgbToHex(color)}-${index}`} type="button" style={{ background: rgbToHex(color), color: bestTextColor(color) }} onClick={() => setPrimaryInput(rgbToHex(color))}>
                  <span>{String(index + 1).padStart(2, "0")} · R{String(color.r).padStart(3, "0")} V{String(color.g).padStart(3, "0")} B{String(color.b).padStart(3, "0")}</span><strong>{rgbToHex(color)}</strong>
                </button>
              ))}
            </div>
            <div className="lab-actions">
              <button type="button" onClick={copyPalette}><Copy size={14} /> Copier CSS</button>
              <button type="button" onClick={() => downloadText("palette-chromatheque.json", paletteToJson(harmony), "application/json")}><Download size={14} /> Export JSON</button>
            </div>
          </article>

          <article className="lab-panel lab-compare-panel">
            <div className="lab-panel-head"><span>03</span><div><small>M · MESURES COMPARÉES</small><h2>Deux couleurs</h2></div></div>
            <ColorEntry id="lab-comparison" label="Seconde couleur" value={comparisonInput} onChange={setComparisonInput} />
            <div className="lab-compare-strip">
              <div style={{ background: rgbToHex(primary), color: bestTextColor(primary) }}>{rgbToHex(primary)}</div>
              <div style={{ background: rgbToHex(comparison), color: bestTextColor(comparison) }}>{rgbToHex(comparison)}</div>
            </div>
            <div className="lab-comparison-metrics">
              <div><span>CONTRASTE WCAG</span><strong>{contrast.toFixed(2)} : 1</strong><small>{contrast >= 4.5 ? "AA pour texte normal" : contrast >= 3 ? "AA pour grand texte" : "Contraste insuffisant"}</small></div>
              <div><span>ΔE 1976</span><strong>{delta.toFixed(2)}</strong><small>Distance perceptuelle indicative</small></div>
              <div><span>ÉCART RVB</span><strong>{Math.abs(primary.r - comparison.r)} · {Math.abs(primary.g - comparison.g)} · {Math.abs(primary.b - comparison.b)}</strong><small>Différences par canal</small></div>
            </div>
          </article>

          <article className="lab-panel lab-alpha-panel">
            <div className="lab-panel-head"><span>04</span><div><small>C · COMPOSITION DE CANAUX</small><h2>Composition alpha</h2></div></div>
            <ColorEntry id="lab-background" label="Fond" value={backgroundInput} onChange={setBackgroundInput} />
            <label className="lab-range" htmlFor="lab-alpha"><span>Opacité du spécimen</span><strong>{alpha} %</strong></label>
            <input id="lab-alpha" type="range" min="0" max="100" value={alpha} onChange={event => setAlpha(Number(event.target.value))} />
            <div className="lab-alpha-preview" style={{ backgroundColor: rgbToHex(background) }}>
              <div style={{ backgroundColor: `rgb(${primary.r} ${primary.g} ${primary.b} / ${alpha / 100})` }}>
                <span>RÉSULTAT COMPOSÉ</span><strong>{rgbToHex(composite)}</strong>
              </div>
            </div>
            <p className="lab-caveat">À 0 %, la mémoire RVB de la couleur existe dans le code mais son rendu est celui du fond. L’Hex affiché correspond au résultat composé opaque.</p>
          </article>
        </section>
      </main>

      <footer className="site-footer lab-footer">
        <div className="brand brand-symbolic footer-brand" aria-label="Chromathèque Universelle"><img src={MARK_URL} alt="" /><span aria-hidden="true"><strong>L·24</strong><small>LABORATOIRE</small></span></div>
        <p>Mesurer sans confondre code, perception, écran et matière.</p>
        <div><a href="/">Atlas</a><span>·</span><a href="/atelier">Atelier</a></div>
      </footer>
    </div>
  );
}
