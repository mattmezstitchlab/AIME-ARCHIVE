// Atlas cinétique — cockpit textile plein écran : territoire panoramique mesuré, exports locaux et corpus rétractables.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import {
  ArrowLeft,
  ChevronDown,
  Download,
  Eraser,
  FileCode2,
  FileText,
  FolderCog,
  Grid3X3,
  Hand,
  LocateFixed,
  Minus,
  PaintBucket,
  PanelBottomClose,
  PanelBottomOpen,
  PanelTopClose,
  PanelTopOpen,
  Pencil,
  Plus,
  Printer,
  Redo2,
  Save,
  Trash2,
  Undo2,
} from "lucide-react";
import { Panel, PanelGroup, PanelResizeHandle, type ImperativePanelHandle } from "react-resizable-panels";
import { toast } from "sonner";
import EmbroideryGrid from "@/components/EmbroideryGrid";
import DmcPalette from "@/components/DmcPalette";
import PatternMinimap from "@/components/PatternMinimap";
import PatternProjectManager from "@/components/PatternProjectManager";
import PrintSettingsPanel from "@/components/PrintSettingsPanel";
import PatternIntakeProcessor from "@/components/PatternIntakeProcessor";
import StitchPalette from "@/components/StitchPalette";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { dmcThreads, type DmcThread } from "@/data/dmcThreads";
import { stitches, type StitchDefinition } from "@/data/stitches";
import {
  GRID_PRESETS,
  clearPattern,
  eraseCell,
  floodFill,
  paintCell,
  patternStats,
  redo,
  undo,
  type DrawingTool,
  type GridGeometry,
  type PatternHistory,
} from "@/lib/embroidery";
import { loadAtelierDocument, saveAtelierDocument } from "@/lib/atelierStorage";
import { convertFileToPattern, type ConvertedPattern } from "@/lib/imagePatternConversion";
import type { PatternIntakeRequest } from "@/lib/patternIntakeQueue";
import { saveProjectSource } from "@/lib/patternSourceStore";
import { trpc } from "@/lib/trpc";
import {
  createProjectId,
  getActiveProjectId,
  getLocalProject,
  listLocalProjects,
  saveLocalProject,
  setActiveProjectId,
  type LocalPatternProject,
} from "@/lib/patternLibrary";
import type { ConversionSettings, PatternDocument, PatternProvenance, PrintSettings, SyncedPatternProject } from "@shared/pattern";
import {
  downloadPatternMultipagePdf,
  downloadPatternPdf,
  downloadPatternSvg,
  getPatternPagePlan,
  type PatternExportOptions,
} from "@/lib/patternExport";

const DEFAULT_THREAD = dmcThreads.find((thread) => thread.code === "310") ?? dmcThreads[0];
const MARK_URL = "/manus-storage/chromatheque-octal-thread-symbol-clean_ec5d4069.png";
const MIN_ZOOM = 0.25;
const MAX_ZOOM = 4;
const DEFAULT_PRINT_SETTINGS: PrintSettings = { pageSize: "a4", orientation: "auto", overlapCells: 2, cellSizeMm: 4 };
const DEFAULT_CONVERSION: ConversionSettings = { targetWidth: 60, targetHeight: 60, maxColors: 16, confettiThreshold: 2, convertedCells: 0, confettiBefore: 0, confettiAfter: 0 };
const DEFAULT_PROVENANCE: PatternProvenance = { sourceType: "manual", sourceName: null, sourceKey: null, sourceUrl: null, sourceMimeType: null, sourceSize: null, sourcePage: null, prompt: null, rightsConfirmedAt: null, transformations: [] };
const sessionPanelStorage = {
  getItem(name: string) {
    return typeof window === "undefined" ? null : window.sessionStorage.getItem(name);
  },
  setItem(name: string, value: string) {
    if (typeof window !== "undefined") window.sessionStorage.setItem(name, value);
  },
};

type Camera = { x: number; y: number; zoom: number };
type CanvasMetrics = { viewportWidth: number; viewportHeight: number; baseWidth: number; baseHeight: number };
type PanGesture = { pointerId: number; startX: number; startY: number; cameraX: number; cameraY: number } | null;

export default function Atelier() {
  const restoredProject = useMemo(() => getLocalProject(getActiveProjectId()), []);
  const restoredDocument = useMemo(() => restoredProject?.document ?? loadAtelierDocument(), [restoredProject]);
  const [documentTitle, setDocumentTitle] = useState(restoredDocument?.documentTitle ?? "Motif sans titre");
  const [presetId, setPresetId] = useState(restoredDocument?.presetId ?? "square");
  const [dimensions, setDimensions] = useState(restoredDocument?.dimensions ?? { width: 24, height: 24 });
  const [geometry, setGeometry] = useState<GridGeometry>(restoredDocument?.geometry ?? "square");
  const [tool, setTool] = useState<DrawingTool>("draw");
  const [selectedThread, setSelectedThread] = useState<DmcThread>(() => dmcThreads.find((thread) => thread.code === restoredDocument?.selectedThreadCode) ?? DEFAULT_THREAD);
  const [selectedStitch, setSelectedStitch] = useState<StitchDefinition>(() => stitches.find((stitch) => stitch.id === restoredDocument?.selectedStitchId) ?? stitches[0]);
  const [camera, setCamera] = useState<Camera>(restoredDocument?.camera ?? { x: 0, y: 0, zoom: 1 });
  const [canvasMetrics, setCanvasMetrics] = useState<CanvasMetrics>({ viewportWidth: 0, viewportHeight: 0, baseWidth: 0, baseHeight: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [pointsOpen, setPointsOpen] = useState(true);
  const [dmcOpen, setDmcOpen] = useState(true);
  const [saveState, setSaveState] = useState<"restored" | "saving" | "saved" | "error">(restoredDocument ? "restored" : "saved");
  const [savedAt, setSavedAt] = useState(restoredDocument?.updatedAt ?? "");
  const [history, setHistory] = useState<PatternHistory>({ past: [], present: restoredDocument?.snapshot ?? {}, future: [] });
  const [activeProjectId, setActiveProjectIdState] = useState(restoredProject?.clientId ?? createProjectId());
  const [localProjects, setLocalProjects] = useState<LocalPatternProject[]>(() => listLocalProjects());
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [printSettingsOpen, setPrintSettingsOpen] = useState(false);
  const [printSettings, setPrintSettings] = useState<PrintSettings>(restoredProject?.printSettings ?? DEFAULT_PRINT_SETTINGS);
  const [conversion, setConversion] = useState<ConversionSettings>(restoredProject?.conversion ?? DEFAULT_CONVERSION);
  const [provenance, setProvenance] = useState<PatternProvenance>(restoredProject?.provenance ?? DEFAULT_PROVENANCE);
  const pointsPanelRef = useRef<ImperativePanelHandle>(null);
  const dmcPanelRef = useRef<ImperativePanelHandle>(null);
  const panGesture = useRef<PanGesture>(null);
  const spacePressed = useRef(false);
  const viewportRef = useRef<HTMLDivElement>(null);
  const zoomLayerRef = useRef<HTMLDivElement>(null);
  const generatePattern = trpc.patternGeneration.generate.useMutation();

  const threadsByCode = useMemo(() => new Map(dmcThreads.map((thread) => [thread.code, thread])), []);
  const stitchesById = useMemo(() => new Map(stitches.map((stitch) => [stitch.id, stitch])), []);
  const stats = useMemo(() => patternStats(history.present), [history.present]);
  const exportOptions = useMemo<PatternExportOptions>(() => ({
    title: documentTitle.trim() || "Motif sans titre",
    width: dimensions.width,
    height: dimensions.height,
    geometry,
    snapshot: history.present,
    threadsByCode,
    stitchesById,
  }), [documentTitle, dimensions, geometry, history.present, threadsByCode, stitchesById]);
  const multipagePlan = useMemo(() => getPatternPagePlan(exportOptions, printSettings), [exportOptions, printSettings]);
  const buildCurrentProject = useCallback((updatedAt: string): SyncedPatternProject => {
    const document: PatternDocument = {
      version: 2,
      updatedAt,
      documentTitle: documentTitle.trim() || "Motif sans titre",
      presetId,
      dimensions,
      geometry,
      selectedThreadCode: selectedThread.code,
      selectedStitchId: selectedStitch.id,
      camera,
      snapshot: history.present,
      printSettings,
      conversion,
      provenance,
    };
    return {
      clientId: activeProjectId,
      name: document.documentTitle,
      document,
      printSettings,
      conversion,
      provenance,
    };
  }, [activeProjectId, camera, conversion, dimensions, documentTitle, geometry, history.present, presetId, printSettings, provenance, selectedStitch.id, selectedThread.code]);
  const currentProject = useMemo(() => buildCurrentProject(savedAt || new Date(0).toISOString()), [buildCurrentProject, savedAt]);

  useEffect(() => {
    const viewport = viewportRef.current;
    const zoomLayer = zoomLayerRef.current;
    if (!viewport || !zoomLayer) return;
    const measure = () => setCanvasMetrics({
      viewportWidth: viewport.clientWidth,
      viewportHeight: viewport.clientHeight,
      baseWidth: zoomLayer.offsetWidth,
      baseHeight: zoomLayer.offsetHeight,
    });
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(viewport);
    observer.observe(zoomLayer);
    return () => observer.disconnect();
  }, [dimensions.height, dimensions.width, pointsOpen, dmcOpen]);

  useEffect(() => {
    setSaveState("saving");
    const timer = window.setTimeout(() => {
      const saved = saveAtelierDocument({
        documentTitle,
        presetId,
        dimensions,
        geometry,
        selectedThreadCode: selectedThread.code,
        selectedStitchId: selectedStitch.id,
        camera,
        snapshot: history.present,
      });
      if (!saved) {
        setSaveState("error");
        return;
      }
      const previous = getLocalProject(activeProjectId);
      const syncState = previous?.syncState === "synced" ? "pending" : previous?.syncState ?? "local";
      saveLocalProject(buildCurrentProject(saved.updatedAt), syncState);
      setActiveProjectId(activeProjectId);
      setLocalProjects(listLocalProjects());
      setSavedAt(saved.updatedAt);
      setSaveState("saved");
    }, 450);
    return () => window.clearTimeout(timer);
  }, [activeProjectId, buildCurrentProject]);

  useEffect(() => {
    const keyDown = (event: KeyboardEvent) => {
      if (event.code === "Space" && !isEditableTarget(event.target)) {
        spacePressed.current = true;
        document.body.classList.add("is-space-panning");
        event.preventDefault();
      }
    };
    const keyUp = (event: KeyboardEvent) => {
      if (event.code === "Space") {
        spacePressed.current = false;
        document.body.classList.remove("is-space-panning");
      }
    };
    window.addEventListener("keydown", keyDown);
    window.addEventListener("keyup", keyUp);
    return () => {
      window.removeEventListener("keydown", keyDown);
      window.removeEventListener("keyup", keyUp);
      document.body.classList.remove("is-space-panning");
    };
  }, []);

  const choosePreset = (id: string) => {
    const preset = GRID_PRESETS.find((item) => item.id === id);
    if (!preset) return;
    if (Object.keys(history.present).length && (preset.width !== dimensions.width || preset.height !== dimensions.height)) {
      toast.info("Le motif a été conservé", { description: "Les marques hors du nouveau format restent dans l’historique mais ne sont plus visibles." });
    }
    setPresetId(id);
    setDimensions({ width: preset.width, height: preset.height });
    setCamera({ x: 0, y: 0, zoom: 1 });
  };

  const updateDimension = (key: "width" | "height", value: number) => {
    setPresetId("custom");
    setDimensions((current) => ({ ...current, [key]: Math.min(240, Math.max(6, value || 6)) }));
  };

  const actOnCell = (x: number, y: number) => {
    setHistory((current) => {
      if (tool === "pan") return current;
      if (tool === "erase") return eraseCell(current, x, y);
      if (tool === "fill") return floodFill(current, dimensions.width, dimensions.height, x, y, selectedStitch.id, selectedThread.code);
      return paintCell(current, x, y, selectedStitch.id, selectedThread.code);
    });
  };

  const setZoom = useCallback((nextZoom: number) => {
    setCamera((current) => ({ ...current, zoom: clamp(nextZoom, MIN_ZOOM, MAX_ZOOM) }));
  }, []);

  const navigateFromMinimap = useCallback((normalizedX: number, normalizedY: number) => {
    setCamera((current) => ({
      ...current,
      x: (0.5 - normalizedX) * canvasMetrics.baseWidth * current.zoom,
      y: (0.5 - normalizedY) * canvasMetrics.baseHeight * current.zoom,
    }));
  }, [canvasMetrics.baseHeight, canvasMetrics.baseWidth]);

  const zoomAroundPoint = useCallback((nextZoom: number, clientX?: number, clientY?: number, bounds?: DOMRect) => {
    setCamera((current) => {
      const zoom = clamp(nextZoom, MIN_ZOOM, MAX_ZOOM);
      if (!bounds || clientX === undefined || clientY === undefined) return { ...current, zoom };
      const pointerX = clientX - bounds.left - bounds.width / 2;
      const pointerY = clientY - bounds.top - bounds.height / 2;
      const ratio = zoom / current.zoom;
      return { zoom, x: pointerX - (pointerX - current.x) * ratio, y: pointerY - (pointerY - current.y) * ratio };
    });
  }, []);

  const handleWheel = (event: React.WheelEvent<HTMLDivElement>) => {
    event.preventDefault();
    const factor = Math.exp(-event.deltaY * 0.0015);
    zoomAroundPoint(camera.zoom * factor, event.clientX, event.clientY, event.currentTarget.getBoundingClientRect());
  };

  const startPan = (event: React.PointerEvent<HTMLDivElement>) => {
    const requested = tool === "pan" || event.button === 1 || spacePressed.current;
    if (!requested) return;
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    panGesture.current = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, cameraX: camera.x, cameraY: camera.y };
    setIsPanning(true);
  };

  const movePan = (event: React.PointerEvent<HTMLDivElement>) => {
    const gesture = panGesture.current;
    if (!gesture || gesture.pointerId !== event.pointerId) return;
    setCamera((current) => ({ ...current, x: gesture.cameraX + event.clientX - gesture.startX, y: gesture.cameraY + event.clientY - gesture.startY }));
  };

  const stopPan = (event: React.PointerEvent<HTMLDivElement>) => {
    if (panGesture.current?.pointerId !== event.pointerId) return;
    panGesture.current = null;
    setIsPanning(false);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };

  const refreshLibrary = useCallback(() => setLocalProjects(listLocalProjects()), []);

  const loadProject = useCallback((project: SyncedPatternProject) => {
    const document = project.document;
    setActiveProjectIdState(project.clientId);
    setActiveProjectId(project.clientId);
    setDocumentTitle(project.name);
    setPresetId(document.presetId);
    setDimensions(document.dimensions);
    setGeometry(document.geometry);
    setSelectedThread(dmcThreads.find(thread => thread.code === document.selectedThreadCode) ?? DEFAULT_THREAD);
    setSelectedStitch(stitches.find(stitch => stitch.id === document.selectedStitchId) ?? stitches[0]);
    setCamera(document.camera);
    setHistory({ past: [], present: document.snapshot, future: [] });
    setPrintSettings(project.printSettings);
    setConversion(project.conversion);
    setProvenance(project.provenance);
    setSavedAt(document.updatedAt);
    setSaveState("restored");
    setLibraryOpen(false);
  }, []);

  const createProject = useCallback(() => {
    const clientId = createProjectId();
    setActiveProjectIdState(clientId);
    setActiveProjectId(clientId);
    setDocumentTitle("Nouveau patron");
    setPresetId("square");
    setDimensions({ width: 24, height: 24 });
    setGeometry("square");
    setCamera({ x: 0, y: 0, zoom: 1 });
    setHistory({ past: [], present: {}, future: [] });
    setPrintSettings(DEFAULT_PRINT_SETTINGS);
    setConversion(DEFAULT_CONVERSION);
    setProvenance(DEFAULT_PROVENANCE);
    setLibraryOpen(false);
    toast.success("Nouveau patron créé", { description: "Le projet précédent reste dans la bibliothèque locale." });
  }, []);

  const generateFromPrompt = useCallback(async (request: PatternIntakeRequest) => {
    if (!request.prompt) throw new Error("Le prompt est vide.");
    const generated = await generatePattern.mutateAsync({
      prompt: request.prompt,
      width: request.targetWidth,
      height: request.targetHeight,
      maxColors: request.maxColors,
    });
    const response = await fetch(generated.url, { credentials: "include" });
    if (!response.ok) throw new Error("Le visuel généré ne peut pas être relu pour la conversion.");
    const blob = await response.blob();
    const file = new File([blob], `gpt-image-2-${Date.now()}.png`, { type: blob.type || "image/png" });
    const converted = await convertFileToPattern(file, {
      width: request.targetWidth,
      height: request.targetHeight,
      maxColors: request.maxColors,
      confettiThreshold: request.confettiThreshold,
    });
    return {
      ...converted,
      source: { ...converted.source, name: `${generated.model} · ${request.prompt.slice(0, 80)}`, secureUrl: generated.url },
    };
  }, [generatePattern]);

  const applyConvertedPattern = useCallback(async (result: ConvertedPattern, request: PatternIntakeRequest, sourceFile: File | null) => {
    const clientId = createProjectId();
    if (sourceFile) {
      try {
        await saveProjectSource(clientId, sourceFile);
      } catch {
        toast.warning("Source non archivée localement", { description: "Le patron reste éditable, mais le fichier original devra être réimporté pour une synchronisation complète." });
      }
    }
    const sourceType: PatternProvenance["sourceType"] = request.kind === "prompt"
      ? "prompt"
      : request.fileType === "application/pdf" || request.fileName?.toLowerCase().endsWith(".pdf")
        ? "pdf"
        : "image";
    const title = request.kind === "prompt"
      ? (request.prompt?.trim().slice(0, 80) || "Patron généré")
      : (request.fileName?.replace(/\.[^.]+$/, "") || "Patron importé");
    const firstThread = result.palette[0];
    const crossStitch = stitches.find(stitch => stitch.id === "cross") ?? stitches[0];

    setActiveProjectIdState(clientId);
    setActiveProjectId(clientId);
    setDocumentTitle(title);
    setPresetId("custom");
    setDimensions({ width: result.width, height: result.height });
    setGeometry("square");
    setCamera({ x: 0, y: 0, zoom: 1 });
    setHistory({ past: [], present: result.snapshot, future: [] });
    if (firstThread) setSelectedThread(dmcThreads.find(thread => thread.code === firstThread.code) ?? DEFAULT_THREAD);
    setSelectedStitch(crossStitch);
    setConversion({
      targetWidth: result.width,
      targetHeight: result.height,
      maxColors: request.maxColors,
      confettiThreshold: request.confettiThreshold,
      convertedCells: Object.keys(result.snapshot).length,
      confettiBefore: result.cleanup.before,
      confettiAfter: result.cleanup.after,
    });
    setProvenance({
      sourceType,
      sourceName: result.source.name,
      sourceKey: null,
      sourceUrl: result.source.secureUrl ?? null,
      sourceMimeType: result.source.mimeType,
      sourceSize: sourceFile?.size ?? null,
      sourcePage: result.source.page,
      prompt: request.prompt,
      rightsConfirmedAt: request.rightsConfirmedAt,
      transformations: [
        `Rastérisation ${result.source.originalWidth} × ${result.source.originalHeight}`,
        `Rééchantillonnage ${result.width} × ${result.height} cases`,
        `Quantification vers ${result.palette.length} références DMC indicatives`,
        `Nettoyage des îlots de ${result.cleanup.threshold} case${result.cleanup.threshold > 1 ? "s" : ""} ou moins : ${result.cleanup.replaced} cellule${result.cleanup.replaced > 1 ? "s" : ""} réaffectée${result.cleanup.replaced > 1 ? "s" : ""}`,
      ],
    });
    setPrintSettings(DEFAULT_PRINT_SETTINGS);
    setTool("draw");
    setLibraryOpen(false);
  }, []);

  const togglePoints = () => {
    const panel = pointsPanelRef.current;
    if (panel) panel.isCollapsed() ? panel.expand(9) : panel.collapse();
  };

  const toggleDmc = () => {
    const panel = dmcPanelRef.current;
    if (panel) panel.isCollapsed() ? panel.expand(17) : panel.collapse();
  };

  const exportSvg = () => {
    try {
      downloadPatternSvg(exportOptions);
      toast.success("Patron SVG téléchargé", { description: "Le fichier conserve la grille, les symboles et la légende DMC." });
    } catch {
      toast.error("Export SVG impossible");
    }
  };

  const exportPdf = async () => {
    const promise = downloadPatternPdf(exportOptions);
    toast.promise(promise, { loading: "Composition du PDF…", success: "Patron PDF téléchargé", error: "Export PDF impossible" });
    await promise;
  };

  const exportMultipagePdf = async () => {
    const promise = downloadPatternMultipagePdf(exportOptions, printSettings);
    toast.promise(promise, {
      loading: `Composition de ${multipagePlan.tiles.length} feuille${multipagePlan.tiles.length > 1 ? "s" : ""}…`,
      success: `PDF multipage téléchargé · ${multipagePlan.tiles.length} feuille${multipagePlan.tiles.length > 1 ? "s" : ""} + plan et légende`,
      error: "Impression multipage impossible",
    });
    await promise;
  };

  return (
    <div className="atelier-shell atelier-studio-shell">
      <header className="studio-appbar">
        <div className="studio-appbar-left">
          <Link className="studio-back" href="/" aria-label="Retour à l’atlas des couleurs"><ArrowLeft size={16} /></Link>
          <Link className="studio-brand studio-brand-symbolic" href="/" aria-label="Chromathèque Universelle, retour à l’accueil">
            <img className="studio-brand-symbol" src={MARK_URL} alt="" />
            <span aria-hidden="true"><strong>U·24</strong><small>ATELIER·01</small></span>
          </Link>
          <input className="studio-document studio-document-input" value={documentTitle} onChange={(event) => setDocumentTitle(event.target.value)} aria-label="Titre du patron" />
          <button type="button" className="studio-library-trigger" onClick={() => setLibraryOpen(true)}><FolderCog size={15} /><span>Mes patrons</span><b>{localProjects.length}</b></button>
        </div>
        <div className="studio-appbar-status" aria-label="Statistiques et sauvegarde du motif">
          <span>{dimensions.width} × {dimensions.height}</span><span>{stats.marks} marque{stats.marks > 1 ? "s" : ""}</span><span>{stats.threads.length} fil{stats.threads.length > 1 ? "s" : ""}</span>
          <span className={`studio-save-state is-${saveState}`} aria-live="polite" title={savedAt ? `Dernière sauvegarde locale : ${new Date(savedAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}` : "Sauvegarde locale active"}><Save size={12} />{saveState === "saving" ? "Sauvegarde…" : saveState === "error" ? "Non sauvegardé" : saveState === "restored" ? "Motif restauré" : "Sauvegardé"}</span>
        </div>
      </header>

      <PanelGroup direction="vertical" autoSaveId="chromatheque-atelier-panels" storage={sessionPanelStorage} className="studio-main studio-panel-layout">
        <Panel ref={pointsPanelRef} id="points-panel" order={1} defaultSize={11} minSize={7} maxSize={28} collapsedSize={0} collapsible onCollapse={() => setPointsOpen(false)} onExpand={() => setPointsOpen(true)}>
          <StitchPalette selectedId={selectedStitch.id} onSelect={setSelectedStitch} />
        </Panel>
        <PanelResizeHandle className="studio-resize-handle studio-resize-handle-top" aria-label="Redimensionner le panneau des points" />

        <Panel id="canvas-panel" order={2} defaultSize={70} minSize={36}>
          <div className="studio-workspace-panel">
            <section className="studio-controlbar" aria-label="Commandes de la grille">
              <div className="studio-toolgroup" aria-label="Outils de dessin">
                <button type="button" className={tool === "draw" ? "is-active" : ""} onClick={() => setTool("draw")} title="Dessiner"><Pencil size={16} /><span>Dessiner</span></button>
                <button type="button" className={tool === "erase" ? "is-active" : ""} onClick={() => setTool("erase")} title="Effacer"><Eraser size={16} /><span>Effacer</span></button>
                <button type="button" className={tool === "fill" ? "is-active" : ""} onClick={() => setTool("fill")} title="Remplir"><PaintBucket size={16} /><span>Remplir</span></button>
                <button type="button" className={tool === "pan" ? "is-active" : ""} onClick={() => setTool("pan")} title="Déplacer le canevas"><Hand size={16} /><span>Main</span></button>
              </div>
              <div className="studio-divider" />
              <div className="studio-formatgroup" aria-label="Format de la grille">
                <Grid3X3 size={15} />
                <select value={presetId} onChange={(event) => choosePreset(event.target.value)} aria-label="Format prédéfini">
                  {GRID_PRESETS.filter((preset) => preset.id !== "custom").map((preset) => <option key={preset.id} value={preset.id}>{preset.label} · {preset.width} × {preset.height}</option>)}
                  <option value="custom">Personnalisé</option>
                </select>
                <label><span>L</span><input type="number" min="6" max="240" value={dimensions.width} onChange={(event) => updateDimension("width", Number(event.target.value))} /></label><span className="studio-times">×</span><label><span>H</span><input type="number" min="6" max="240" value={dimensions.height} onChange={(event) => updateDimension("height", Number(event.target.value))} /></label>
              </div>
              <div className="studio-divider" />
              <div className="studio-geometrygroup" aria-label="Géométrie des facettes">
                {(["square", "diamond", "hex"] as GridGeometry[]).map((item) => <button type="button" key={item} className={geometry === item ? "is-active" : ""} onClick={() => setGeometry(item)} title={item === "square" ? "Carré" : item === "diamond" ? "Losange" : "Alvéole"}><span aria-hidden="true">{item === "square" ? "□" : item === "diamond" ? "◇" : "⬡"}</span></button>)}
              </div>
              <div className="studio-controlspacer" />
              <div className="studio-panel-controls" aria-label="Panneaux">
                <button type="button" onClick={togglePoints} aria-pressed={!pointsOpen} title={pointsOpen ? "Replier les points" : "Afficher les points"}>{pointsOpen ? <PanelTopClose size={15} /> : <PanelTopOpen size={15} />}</button>
                <button type="button" onClick={toggleDmc} aria-pressed={!dmcOpen} title={dmcOpen ? "Replier les fils DMC" : "Afficher les fils DMC"}>{dmcOpen ? <PanelBottomClose size={15} /> : <PanelBottomOpen size={15} />}</button>
              </div>
              <div className="studio-historygroup" aria-label="Historique">
                <button type="button" onClick={() => setHistory(undo)} disabled={!history.past.length} aria-label="Annuler"><Undo2 size={16} /></button><button type="button" onClick={() => setHistory(redo)} disabled={!history.future.length} aria-label="Rétablir"><Redo2 size={16} /></button><button type="button" onClick={() => setHistory(clearPattern)} disabled={!stats.marks} aria-label="Vider la grille"><Trash2 size={16} /></button>
              </div>
              <div className="studio-zoomgroup" aria-label="Zoom">
                <button type="button" onClick={() => setZoom(camera.zoom - 0.1)} aria-label="Réduire le zoom"><Minus size={15} /></button><strong>{Math.round(camera.zoom * 100)}%</strong><button type="button" onClick={() => setZoom(camera.zoom + 0.1)} aria-label="Augmenter le zoom"><Plus size={15} /></button><button type="button" onClick={() => setCamera({ x: 0, y: 0, zoom: 1 })} aria-label="Recentrer le canevas" title="Recentrer"><LocateFixed size={15} /></button>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild><button type="button" className="studio-export-trigger"><Download size={15} /><span>Exporter</span><ChevronDown size={13} /></button></DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="studio-export-menu">
                  <DropdownMenuItem onSelect={exportSvg}><FileCode2 size={16} /><span><strong>Patron SVG</strong><small>Vectoriel, grille et légende</small></span></DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => void exportPdf()}><FileText size={16} /><span><strong>Patron PDF</strong><small>A4, orientation automatique</small></span></DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => setPrintSettingsOpen(true)}><Printer size={16} /><span><strong>Impression multipage</strong><small>{multipagePlan.tiles.length} feuille{multipagePlan.tiles.length > 1 ? "s" : ""} · {printSettings.pageSize.toUpperCase()} · réglages</small></span></DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </section>

            <section className={`studio-canvas ${tool === "pan" ? "is-pan-tool" : ""} ${isPanning ? "is-panning" : ""}`} id="canevas">
              <div className="studio-canvas-meta studio-canvas-meta-left"><i className="studio-map-pulse" aria-hidden="true" /><span>POINT</span><strong>{selectedStitch.nameFr}</strong><span>FIL</span><strong>DMC {selectedThread.code}</strong></div>
              <div className="studio-canvas-meta studio-canvas-meta-right"><span>PLAN</span><strong>{dimensions.width} × {dimensions.height}</strong><span>CAMÉRA</span><strong>{Math.round(camera.zoom * 100)}% · {Math.round(camera.x)}:{Math.round(camera.y)}</strong></div>
              <div
                ref={viewportRef}
                className="studio-canvas-viewport"
                aria-label="Territoire de broderie panoramique"
                onWheel={handleWheel}
                onPointerDownCapture={(event) => {
                  if (spacePressed.current || event.button === 1) {
                    startPan(event);
                    event.stopPropagation();
                  }
                }}
                onPointerDown={(event) => { if (tool === "pan") startPan(event); }}
                onPointerMove={movePan}
                onPointerUp={stopPan}
                onPointerCancel={stopPan}
              >
                <div className="studio-map-frame" aria-hidden="true">
                  <span className="studio-map-corner studio-map-corner-tl">O·00:00</span>
                  <span className="studio-map-corner studio-map-corner-tr">X·{String(dimensions.width).padStart(2, "0")}</span>
                  <span className="studio-map-corner studio-map-corner-bl">Y·{String(dimensions.height).padStart(2, "0")}</span>
                  <span className="studio-map-corner studio-map-corner-br">U·24</span>
                  <i className="studio-map-axis studio-map-axis-x" />
                  <i className="studio-map-axis studio-map-axis-y" />
                </div>
                <div ref={zoomLayerRef} className="studio-canvas-zoom" style={{ transform: `translate(calc(-50% + ${camera.x}px), calc(-50% + ${camera.y}px)) scale(${camera.zoom})` }}>
                  <EmbroideryGrid width={dimensions.width} height={dimensions.height} geometry={geometry} snapshot={history.present} threadsByCode={threadsByCode} stitchesById={stitchesById} onCellAction={actOnCell} drawingEnabled={tool !== "pan"} />
                </div>
                <div className="studio-map-scale" aria-hidden="true"><span>ÉCHELLE</span><i /><strong>{Math.round(camera.zoom * 100)}%</strong><small>{Math.round(camera.x)}:{Math.round(camera.y)}</small></div>
                <PatternMinimap width={dimensions.width} height={dimensions.height} snapshot={history.present} threadsByCode={threadsByCode} camera={camera} metrics={canvasMetrics} onNavigate={navigateFromMinimap} />
              </div>
              <div className="studio-statusbar">
                <div className="studio-active-thread"><i style={{ background: selectedThread.hex }} /><strong>DMC {selectedThread.code}</strong><span>{selectedThread.name}</span><b>A</b></div><div className="studio-active-stitch"><strong>{selectedStitch.symbol} {selectedStitch.nameFr}</strong><span>{selectedStitch.family}</span><b>N</b></div><div className="studio-proof"><b>M</b> caméra libre · molette zoom · Espace + glisser déplacement · <b>A</b> écran indicatif</div>
              </div>
            </section>
          </div>
        </Panel>

        <PanelResizeHandle className="studio-resize-handle studio-resize-handle-bottom" aria-label="Redimensionner le panneau des fils DMC" />
        <Panel ref={dmcPanelRef} id="dmc-panel" order={3} defaultSize={19} minSize={9} maxSize={38} collapsedSize={0} collapsible onCollapse={() => setDmcOpen(false)} onExpand={() => setDmcOpen(true)}>
          <DmcPalette selectedCode={selectedThread.code} onSelect={setSelectedThread} />
        </Panel>
      </PanelGroup>
      <PrintSettingsPanel
        open={printSettingsOpen}
        settings={printSettings}
        plan={multipagePlan}
        onChange={setPrintSettings}
        onClose={() => setPrintSettingsOpen(false)}
        onPrint={() => { setPrintSettingsOpen(false); void exportMultipagePdf(); }}
      />
      <PatternIntakeProcessor onApply={applyConvertedPattern} onPromptGenerate={generateFromPrompt} />
      <PatternProjectManager
        open={libraryOpen}
        activeId={activeProjectId}
        currentProject={currentProject}
        localProjects={localProjects}
        onClose={() => setLibraryOpen(false)}
        onCreate={createProject}
        onLoad={loadProject}
        onRefresh={refreshLibrary}
      />
    </div>
  );
}

function clamp(value: number, minimum: number, maximum: number) {
  return Math.min(maximum, Math.max(minimum, value));
}

function isEditableTarget(target: EventTarget | null) {
  return target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement || (target instanceof HTMLElement && target.isContentEditable);
}
