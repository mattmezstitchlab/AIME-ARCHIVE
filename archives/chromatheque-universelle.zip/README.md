# Chromathèque Universelle

**Chromathèque Universelle** est une application de recherche et d’exploration des **16 777 216 adresses sRGB 24 bits**. Son interface centrale, le **Chromatome**, remplace une grille impossible à parcourir par huit décisions octales successives. Chaque décision révèle simultanément les bits de rouge, de vert et de bleu ; huit niveaux identifient donc une couleur exacte sans créer seize millions d’éléments dans le DOM.

## Principe d’innovation

L’adresse Chromatome est une écriture Morton en base 8. À chaque profondeur `d`, un chiffre de `0` à `7` encode le triplet `(bitR, bitV, bitB)` correspondant au même rang binaire des trois canaux. La transformation est **bijective** : toute couleur RVB possède une adresse de huit chiffres, et toute adresse valide restitue exactement la couleur d’origine.

| Niveau | Décision | Résolution restante |
|---:|---|---:|
| 0 | Espace sRGB complet | 16 777 216 couleurs |
| 1 | Choix d’un octant RGB | 2 097 152 couleurs |
| 4 | Préfixe de quatre chiffres | 4 096 couleurs |
| 8 | Adresse complète | 1 couleur exacte |

La recherche directe par Hex, notation `rgb(...)` ou nom attesté reste équivalente au parcours spatial. La fiche technique expose Hex, RVB, une conversion CMJN **indicative**, OKLCH, contrastes et provenance du nom lorsqu’il existe.

## Limite scientifique importante

La conversion sRGB vers CMJN n’est pas universelle. L’application affiche la formule arithmétique sans profil uniquement comme repère. Une valeur destinée à l’impression doit être recalculée avec un profil ICC de destination, un procédé, un papier, des encres et une intention de rendu définis. De même, une couleur numérique ne doit pas être confondue avec un pigment historique : la section d’archives relie les documents, mais conserve explicitement cette distinction.

## Corpus documentaire

Le corpus initial distingue les noms normalisés, les alias et les dossiers historiques. Les balises de preuve utilisent quatre catégories : **N** pour norme, **A** pour archive, **M** pour mesure et **C** pour controverse. Les récits non vérifiables de « couleurs cachées » ne sont pas présentés comme des faits ; l’enquête vise plutôt les appellations oubliées, les pigments historiques ou dangereux, les entrées retirées et les phénomènes de révision documentaire.

## Technologies

L’application utilise React 19, TypeScript, Vite, Tailwind CSS 4 et les composants Radix/shadcn déjà présents dans le gabarit. Le rendu du Chromatome reste côté client et ne matérialise jamais l’espace complet en mémoire. Les ressources visuelles sont servies depuis le stockage persistant du projet.

## Organisation principale

| Fichier | Rôle |
|---|---|
| `client/src/components/ChromatomeMap.tsx` | Navigation octale, plages RVB et interaction clavier |
| `client/src/components/ColorInspector.tsx` | Fiche technique et contrastes |
| `client/src/components/ResearchArchive.tsx` | Dossiers historiques et provenance |
| `client/src/lib/color.ts` | Conversions et bijection Chromatome |
| `client/src/data/colorCorpus.ts` | Corpus local sourcé |
| `rapport-chromatheque-universelle.md` | Rapport scientifique et stratégique complet |
| `research/analysis/` | Matrice de décision, spécification et diagrammes |

## Validation locale

```bash
pnpm install
pnpm vitest run client/src/lib/color.test.ts
pnpm check
pnpm build
pnpm dev
```

La batterie actuelle vérifie la normalisation Hex, la réversibilité Hex/RVB/entier, la bijection Morton sur huit niveaux, les bornes de préfixes, les cas limites CMJN, l’analyse des requêtes et les invariants essentiels du contraste WCAG.

## Rapport et méthode

Le rapport principal compte environ **6 949 mots**, 22 sections et 24 références. Il synthétise quatorze recherches parallèles sur les standards Web, la colorimétrie, les profils ICC, les distances perceptuelles, la visualisation massive, les structures spatiales, le rendu navigateur, l’accessibilité, les corpus historiques, les licences, l’état de l’art et les nouveaux paradigmes d’interface. Le choix du Chromatome est justifié par une matrice multicritère reproductible située dans `research/analysis/`.

## Atelier / Grille de broderie

La route `/atelier` ajoute un cockpit de composition textile à la Chromathèque. Le canevas propose des formats carré, portrait, paysage, bannière ou personnalisés de 6 à 60 facettes par axe. Trois géométries visuelles sont disponibles : carré, losange et alvéole. L’utilisateur peut dessiner, effacer, remplir une zone, annuler, rétablir, zoomer et consulter une légende calculée des fils et points réellement employés.

Le nuancier intégré contient **456 références** issues du dépôt secondaire public `nathantspencer/DMC-ColorCodes`. Les codes, noms et valeurs Hex ne sont pas décrits comme une publication officielle de DMC. Les couleurs d’écran servent à la composition et doivent être confrontées à une carte physique avec échantillons avant production. Le fichier `client/src/data/dmcThreads.ts` conserve la provenance et le niveau de confiance de chaque entrée.

La bibliothèque initiale comprend **24 points** représentant des familles de points comptés, lignes, boucles, remplissages, nœuds, couchures, blackwork et crewel. Chaque point possède un symbole original, un contexte, un support et une source institutionnelle ou pédagogique. Cette bibliothèque est explicitement évolutive : elle ne prétend pas épuiser toutes les traditions mondiales.

| Badge | Signification dans l’Atelier |
|---|---|
| **N** | Notice ou point relié à une source documentaire |
| **A** | Approximation calculée, notamment le rendu Hex d’un fil |
| **M** | Réalité matérielle à vérifier sur le fil, la toile et sous l’éclairage réel |
| **C** | Entrée issue d’un corpus de travail |

La validation complète s’exécute avec `pnpm check`, `pnpm vitest run` et `pnpm build`. Les tests de `client/src/lib/embroidery.test.ts` couvrent le dessin, la gomme, le remplissage, l’historique, les statistiques et l’effacement réversible du motif.
