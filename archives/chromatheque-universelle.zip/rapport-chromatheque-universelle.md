# Chromathèque Universelle

## Rapport de recherche et proposition d’un nouvel atlas des 16 777 216 couleurs du Web

**Auteur : Manus AI**  
**Date : 16 juillet 2026**  
**Méthode : recherche parallèle sur quatorze axes, validation croisée de sources normatives, scientifiques, institutionnelles et techniques**

![Comparaison des paradigmes](research/analysis/comparaison-concepts.png)

## Résumé exécutif

Le défi n’est pas de produire une liste de seize millions de lignes. Il consiste à rendre **chaque valeur sRGB 24 bits individuellement adressable**, à permettre une exploration intelligible de l’ensemble, puis à relier la petite fraction documentée de ces valeurs à des noms, des standards, des usages, des pigments ou des récits historiques sans confondre des objets de nature différente.

L’espace étudié comporte exactement `256 × 256 × 256 = 16 777 216` triplets lorsque chacun des trois canaux rouge, vert et bleu est codé sur huit bits. Ces triplets sont des **adresses numériques** dans un espace sRGB discret ; ils ne correspondent ni à seize millions de noms usuels, ni à seize millions de sensations nécessairement distinguables, ni à seize millions de recettes d’impression. sRGB constitue un espace colorimétrique caractérisé, normalisé sous IEC 61966-2-1, avec un point blanc, des primaires et une fonction de transfert définis.[1] [2]

La recherche conclut qu’une interface universelle doit maintenir trois plans séparés mais synchronisés :

| Plan | Question résolue | Vérité de référence |
|---|---|---|
| **Adresse numérique** | Quelle valeur exacte a été sélectionnée ? | triplet sRGB 8 bits, Hex et entier 24 bits |
| **Proximité perceptuelle** | Quelles couleurs paraissent proches dans un contexte donné ? | Oklab/OKLCH pour l’interaction ; CIEDE2000 lorsque pertinent |
| **Connaissance documentaire** | Quels noms, objets, standards, usages ou événements sont attestés ? | sources, portée, licence, date et niveau de confiance |

Le concept recommandé est le **Chromatome hybride**. Chaque couleur y devient une adresse de huit chiffres octaux obtenue en entrelaçant, niveau par niveau, les bits des trois canaux. Une décision octale sélectionne l’un des huit sous-cubes RGB ; huit décisions isolent une couleur parmi `8^8`, soit exactement 16 777 216 possibilités. La carte récursive n’affiche donc jamais seize millions d’éléments : elle montre les huit régions du niveau courant, puis révèle progressivement les détails utiles. Une lentille perceptuelle reprojette la sélection dans Oklab/OKLCH ; une couche documentaire signale les entrées nommées, historiques, retirées, renommées ou controversées.

Cette solution obtient **9,65/10** dans la matrice de conception pondérée, contre 8,43 pour un moteur tabulaire pur, 8,38 pour un octree seul, 8,04 pour un atlas de coupes, 7,30 pour une carte de Hilbert, 6,66 pour un solide perceptuel et 6,09 pour un cube RGB 3D. Il s’agit d’une évaluation conceptuelle argumentée, non d’une mesure utilisateur. Elle devra être confirmée par des tests comparatifs.

> **Recommandation centrale :** construire un atlas à zoom sémantique où l’octree garantit l’exhaustivité et la réversibilité, où la lentille perceptuelle corrige la faiblesse des voisinages RGB, et où un graphe de provenance transforme la « chasse aux couleurs manquantes » en enquête documentaire vérifiable.

## 1. Objet, périmètre et méthode

### 1.1 Objet du projet

La Chromathèque Universelle vise deux ambitions liées. La première est mathématique et informatique : donner accès à toute valeur du cube sRGB 24 bits sans précharger une base exhaustive. La seconde est culturelle : documenter les noms et matériaux chromatiques rarement visibles, retirés de catalogues, renommés, dangereux, localisés dans des archives ou seulement connus de communautés spécialisées.

Le terme **universelle** désigne ici l’exhaustivité de l’espace numérique sRGB 8 bits et l’ouverture du modèle documentaire. Il ne signifie pas que sRGB contient toutes les couleurs physiquement produisibles, tous les stimuli perceptibles ou tous les gamuts d’impression. CSS Color Level 4 permet d’ailleurs d’exprimer des couleurs dans plusieurs espaces plus larges que sRGB et précise qu’une couleur valide peut rester hors gamut pour un périphérique donné.[3]

### 1.2 Questions de recherche

Le travail répond à six questions structurantes :

| Question | Critère de réponse |
|---|---|
| Comment rendre 16 777 216 couleurs explorables ? | adresse exacte, profondeur limitée, orientation et performance |
| Quelle représentation évite une masse illisible ? | agrégation multi-échelles et génération à la demande |
| Comment rapprocher calcul numérique et perception ? | séparation RGB exact / espace perceptuel explicité |
| Comment représenter les noms et histoires ? | graphe de sources, relations qualifiées et multilinguisme |
| Que signifie « retrouver une couleur perdue » ? | objet documentaire attesté, jamais révélation invérifiable |
| Comment afficher le CMJN honnêtement ? | distinction entre approximation pédagogique et transformation ICC |

### 1.3 Recherche parallèle

Quatorze recherches indépendantes ont été conduites sur les thèmes suivants : standards Web et couleurs nommées ; fondements du sRGB 24 bits ; conversion RGB–CMJN ; espaces perceptuels ; visualisation de grands espaces ; rendu navigateur ; accessibilité ; pigments historiques ; couleurs retirées ou renommées ; jeux de données et licences ; produits existants ; moteur de recherche ; architecture de données ; paradigmes spéculatifs réalisables. Les résultats complets sont conservés dans le dossier `research/`.

Les affirmations structurantes ont ensuite été recoupées avec les spécifications du W3C, le registre de l’International Color Consortium, les recommandations WCAG, la CIE, des documentations MDN et des institutions muséales. Cette méthode réduit le risque de transformer une anecdote populaire, une convention logicielle ou une approximation commerciale en fait scientifique.

### 1.4 Grille d’évaluation

Les concepts ont été notés de 1 à 10 sur neuf critères pondérés, définis avant l’évaluation.

| Critère | Pondération | Interprétation |
|---|---:|---|
| Exhaustivité adressable | 20 % | toute valeur doit être accessible et partageable |
| Orientation et réversibilité | 15 % | l’utilisateur comprend où il est et peut revenir en arrière |
| Fluidité et sobriété technique | 15 % | pas de millions de nœuds DOM ni de transfert massif |
| Fidélité perceptuelle | 12 % | les voisinages visuels ne sont pas assimilés à la distance RGB |
| Découverte et sérendipité | 10 % | l’interface favorise les trouvailles sans devenir aléatoire |
| Lisibilité documentaire | 8 % | sources, statuts et incertitudes restent compréhensibles |
| Accessibilité | 8 % | fonctionnement au clavier et sans dépendance exclusive à la couleur |
| Extensibilité | 7 % | ajout de corpus, langues, mesures et espaces colorimétriques |
| Export et reproductibilité | 5 % | états, calculs et résultats sont réutilisables |

## 2. Ce que représentent réellement les 16 777 216 couleurs

### 2.1 Un espace discret d’adresses

Chaque canal prend une valeur entière de 0 à 255. Un triplet `(R,V,B)` se convertit en entier canonique :

`rgb24 = (R << 16) | (V << 8) | B`

L’Hexadécimal `#RRGGBB` en est une notation lisible. La plage entière va de `0x000000` à `0xFFFFFF`. L’exhaustivité peut donc être obtenue par calcul : stocker une fiche par triplet est redondant pour les propriétés déterministes telles que Hex, RVB, adresse Morton, HSL, Oklab ou CMJN approximatif.

La valeur à stocker durablement n’est pas « la couleur elle-même », mais l’**annotation non déductible** : un nom attesté, un alias, une source, une mesure, une relation historique, un profil d’impression ou une décision éditoriale.

### 2.2 sRGB n’est pas le monde visible entier

Le registre ICC décrit sRGB comme un encodage colorimétrique à trois composantes, associé notamment au point blanc D65, à des primaires définies et à une fonction de transfert par morceaux.[2] Les valeurs 8 bits sont un échantillonnage de cet espace, pas une carte exhaustive de tous les spectres lumineux. Deux spectres différents peuvent produire une apparence identique dans certaines conditions, tandis qu’un matériau réel change d’apparence selon l’illuminant, le support, la finition et l’observateur.

Il faut donc éviter quatre équivalences trompeuses :

| Équivalence trompeuse | Correction |
|---|---|
| un Hex = un pigment | un Hex décrit une cible d’affichage ; un pigment possède des propriétés matérielles et spectrales |
| un RGB = un CMJN universel | l’impression dépend du profil, du procédé, du papier, des encres et de l’intention de rendu |
| une distance RGB = une différence visuelle | la géométrie RGB n’est pas perceptuellement uniforme |
| un nom = une valeur unique universelle | les noms dépendent des corpus, langues, époques et conventions |

### 2.3 Couleurs CSS nommées

Les couleurs nommées CSS forment un corpus important mais limité. Leur histoire réunit les seize noms HTML historiques, des noms issus de X11/SVG, des alias et des ajouts plus récents comme `rebeccapurple`. MDN rappelle que ces mots-clés désignent des couleurs sRGB et que la logique des noms n’est pas parfaitement systématique.[4] Une chromathèque sérieuse doit donc conserver l’identifiant du corpus, l’édition, les alias et la valeur exacte, plutôt que d’attribuer un « nom officiel » mondial à une couleur.

Le contraste entre le nombre de valeurs adressables et le nombre de noms standardisés est essentiel : l’immense majorité des triplets sRGB n’a pas de nom normalisé. Cette absence n’est pas une suppression ; c’est l’état normal d’un continuum quantifié.

## 3. Perception : la proximité n’est pas l’adresse

### 3.1 Limites de la distance euclidienne RGB

Dans le cube RGB, des pas numériques égaux ne produisent pas des différences visuelles égales. Les canaux sont encodés avec une fonction de transfert non linéaire ; la sensibilité humaine varie selon la clarté, la chroma et la teinte. Le rapport de distance brute `sqrt(ΔR²+ΔV²+ΔB²)` ne doit donc pas alimenter seul un classement de « couleurs les plus proches ».

La norme CIEDE2000 rappelle que les espaces XYZ et xyY ne sont pas perceptuellement uniformes et que même CIELAB ou CIELUV n’en donnent qu’une approximation. CIEDE2000 ajoute des corrections pour la clarté, la chroma, la teinte et leurs interactions, dans des conditions d’application déterminées.[5] Cette sophistication ne transforme pas la formule en modèle universel de toute perception ; les conditions d’observation et l’adaptation restent importantes.

### 3.2 Rôle d’Oklab et OKLCH

Oklab fournit une géométrie pratique pour les interpolations, les voisinages et les outils interactifs. OKLCH réexprime cette géométrie à l’aide d’une clarté, d’une chroma et d’un angle de teinte plus faciles à manipuler. CSS Color Level 4 définit aujourd’hui des fonctions associées à ces espaces modernes.[3]

La recommandation est fonctionnelle :

| Besoin | Espace ou métrique |
|---|---|
| identifiant et fidélité au code Web | sRGB 8 bits |
| exploration intuitive locale | Oklab / OKLCH |
| comparaison experte documentée | CIELAB + CIEDE2000, avec paramètres visibles |
| conversion entre périphériques | profils ICC et espace de connexion |

### 3.3 Conséquence pour l’interface

Une seule carte ne peut pas optimiser simultanément l’exactitude de l’adresse RGB, l’uniformité perceptuelle et la densité documentaire. Le produit doit proposer des **vues coordonnées**. Sélectionner une couleur dans la carte d’adresses actualise la lentille perceptuelle et les documents associés ; sélectionner un voisin perceptuel replace la carte à l’adresse exacte correspondante.

## 4. CMJN : une conversion à deux niveaux

### 4.1 Pourquoi il n’existe pas de CMJN universel

L’ICC promeut une gestion des couleurs ouverte et indépendante des fournisseurs ; sa spécification v4 est normalisée sous ISO 15076-1.[6] Un profil de sortie décrit les caractéristiques d’une condition d’impression. L’ICC indique explicitement qu’aucun profil unique ne convient à toute application.[7] Dans une chaîne gérée, la conversion passe généralement par un espace de connexion de profils, tel que XYZ ou Lab, avant d’atteindre le CMJN de destination.[8]

Un quadruplet CMJN sans profil peut être utile pour l’apprentissage, mais il ne garantit pas le résultat imprimé. La Chromathèque doit donc afficher deux blocs visuellement distincts.

| Sortie | Données | Promesse autorisée |
|---|---|---|
| **CMJN pédagogique** | formule déterministe simple | approximation sans profil |
| **CMJN géré** | profils source/destination, intention de rendu, moteur, date | résultat lié à une condition précise |

### 4.2 Formule pédagogique

Une formule courante normalise les canaux `r`, `v`, `b` dans `[0,1]`, pose `K = 1 − max(r,v,b)`, puis calcule, si `K ≠ 1`, `C = (1−r−K)/(1−K)`, `M = (1−v−K)/(1−K)` et `J = (1−b−K)/(1−K)`. Cette formule doit être étiquetée « approximation mathématique » et ne doit jamais être présentée comme une recette d’impression.

### 4.3 Données nécessaires à une conversion professionnelle

Une conversion gérée doit enregistrer le profil source, le profil de sortie, l’intention de rendu, les options de compensation du point noir, la version du moteur, la date et les valeurs résultantes. Une même couleur sRGB peut alors produire plusieurs quadruplets valides, chacun dans un contexte de production distinct.

## 5. État de l’art des interfaces chromatiques

### 5.1 Familles existantes

Les produits existants se répartissent principalement entre générateurs de palettes, roues et plans de sélection, outils d’accessibilité, bibliothèques de standards industriels, systèmes professionnels de gestion colorimétrique et collections muséales. Ces familles sont utiles, mais répondent à des problèmes différents. Une roue est efficace pour composer ; un vérificateur WCAG évalue un couple texte–fond ; une base de pigments décrit des matériaux ; un profil ICC prédit une transformation ; aucun de ces outils ne devient automatiquement un atlas exhaustif.

### 5.2 Représentations candidates

| Représentation | Force | Limite dominante |
|---|---|---|
| cube RGB 3D | structure exacte et immédiatement reconnaissable | occlusion, ciblage, désorientation, accessibilité |
| solide OKLCH | voisinages et contrôles perceptuels | gamut irrégulier et adressage sRGB indirect |
| coupes 2D | précision, performance et comparaison | navigation séquentielle moins mémorable |
| courbe de Hilbert | ordre dense et localité partiellement préservée | voisinages artificiels et apprentissage difficile |
| octree | hiérarchie naturelle de huit sous-cubes | proximité non perceptuelle |
| recherche tabulaire | puissance, précision, accessibilité | faible sérendipité |
| mosaïque/treemap | zoom multi-échelles et annotation | géométrie pouvant masquer les axes |

### 5.3 Lacune de produit

Le marché dispose de sélecteurs, de catalogues et de calculateurs ; il manque un **atlas multi-échelles** qui donne à chaque couleur une adresse stable, montre ses voisins selon plusieurs définitions et expose la provenance des connaissances associées. L’innovation n’est donc pas un nouvel effet graphique isolé. Elle réside dans la coordination rigoureuse de la carte, de la lentille et du graphe documentaire.

## 6. Le Chromatome : innovation retenue

![Architecture du Chromatome](research/analysis/architecture-chromatome.png)

### 6.1 Une adresse octale réversible

Les huit bits de chaque canal sont lus du bit de poids fort au bit de poids faible. À chaque niveau `i`, les trois bits correspondants forment un chiffre octal :

`dᵢ = 4 × bitᵢ(R) + 2 × bitᵢ(V) + bitᵢ(B)`

La suite `d₇d₆…d₀` est une adresse de Morton en trois dimensions. Un chiffre indique simultanément la moitié basse ou haute de chaque canal. L’utilisateur ne doit pas connaître la théorie des codes spatiaux : l’interface traduit chaque décision par trois mini-indicateurs — rouge bas/haut, vert bas/haut, bleu bas/haut — et affiche les plages numériques restantes.

| Profondeur | Couleurs dans la région active | Information ajoutée |
|---:|---:|---|
| 0 | 16 777 216 | cube sRGB entier |
| 1 | 2 097 152 | trois bits déterminés |
| 2 | 262 144 | six bits déterminés |
| 3 | 32 768 | neuf bits déterminés |
| 4 | 4 096 | douze bits déterminés |
| 5 | 512 | quinze bits déterminés |
| 6 | 64 | dix-huit bits déterminés |
| 7 | 8 | vingt et un bits déterminés |
| 8 | 1 | triplet exact |

Cette propriété constitue le cœur du pari : l’intégralité est présente comme **espace adressable**, mais seulement la région utile est rendue. La profondeur maximale de huit rend le parcours compréhensible et mesurable.

### 6.2 Carte Chromatome

La carte est une mosaïque récursive de huit tuiles. Chaque tuile peut être représentée par sa couleur médiane, par une microtexture calculée ou par un échantillon stratifié. La géométrie doit rester stable afin que la mémoire spatiale puisse se former. Une boussole indique les directions d’augmentation des trois canaux ; un fil d’Ariane affiche l’adresse octale et les intervalles RGB.

Le zoom est **sémantique**. À grande échelle, la carte montre des familles et des densités documentaires. Plus près, elle affiche plages, Hex représentatifs et contrastes. Au niveau final, elle devient une fiche technique. L’utilisateur n’agrandit pas une vignette jusqu’au pixel : il change de niveau de sens.

### 6.3 Lentille perceptuelle

La lentille prend la couleur sélectionnée comme centre et calcule un voisinage en Oklab ou OKLCH. Elle répond à des questions que l’octree ne peut résoudre : quelles couleurs semblent les plus proches ? Quelle variation modifie principalement la clarté ? Où se trouvent les alternatives de chroma équivalente ?

La lentille propose au minimum quatre anneaux fonctionnels :

| Anneau | Fonction |
|---|---|
| voisins immédiats | classement par distance perceptuelle choisie |
| variations contrôlées | clarté, chroma ou teinte isolées |
| repères nommés | couleurs documentées proches |
| contraintes | gamut, contraste, simulation de déficiences visuelles |

La formule utilisée doit rester visible. Un résultat calculé avec la distance euclidienne Oklab n’est pas étiqueté « CIEDE2000 » ; une mesure CIEDE2000 doit être testée sur les paires de référence publiées par Sharma.[9]

### 6.4 Balises documentaires

Les balises sont rares par rapport aux feuilles numériques. Elles apparaissent donc comme une constellation sur la carte plutôt que comme un pavage uniforme. Leur forme encode la nature de l’entrée, leur contour le niveau de confiance, et leur densité peut être agrégée aux niveaux éloignés.

| Relation | Usage |
|---|---|
| `EXACT_IN_STANDARD` | la source définit explicitement une valeur numérique |
| `ALIAS_OF` | autre nom pour la même valeur dans un corpus déterminé |
| `DISPLAY_APPROXIMATION_OF` | approximation écran d’un matériau ou échantillon |
| `REMOVED_FROM` | entrée retirée d’une version identifiée |
| `RENAMED_TO` | changement de désignation documenté |
| `ATTESTED_IN` | présence historique dans une source |
| `CONTESTED` | interprétation ou attribution débattue |

Cette grammaire évite la formule trompeuse « ce pigment est #00A86B ». La fiche dira plutôt qu’une source ou une mesure donnée propose `#00A86B` comme approximation d’affichage d’un échantillon défini.

### 6.5 Recherche et réversibilité

La barre de commande accepte Hex, syntaxe `rgb()`, nom, alias, adresse Chromatome, plages de canaux, périodes, institutions, types de matériaux et statuts documentaires. Chaque résultat ouvre la carte à son adresse exacte et peut être partagé par URL. Inversement, toute sélection de carte devient une requête textuelle reproductible.

La recherche de similarité doit distinguer trois commandes : « proche numériquement », « proche perceptuellement » et « proche documentairement ». Cette explicitation transforme une ambiguïté fréquente en instrument pédagogique.

## 7. Matrice de décision

La comparaison détaillée est disponible dans `research/analysis/matrice-concepts.csv`. Le tableau ci-dessous présente la synthèse.

| Rang | Concept | Score pondéré / 10 | Conclusion |
|---:|---|---:|---|
| 1 | **Chromatome hybride** | **9,65** | synthèse complète des trois plans |
| 2 | Moteur de recherche tabulaire | 8,43 | excellent instrument, exploration faible |
| 3 | Octree à zoom sémantique | 8,38 | adresse remarquable, perception insuffisante |
| 4 | Atlas de coupes 2D | 8,04 | précis et robuste, moins différenciant |
| 5 | Carte de Hilbert | 7,30 | dense et mémorable, voisinages artificiels |
| 6 | Solide perceptuel OKLCH | 6,66 | perception utile, exhaustivité moins lisible |
| 7 | Cube RGB 3D | 6,09 | démonstratif, mais peu opérable à grande échelle |

Le score élevé du Chromatome ne signifie pas que chaque vue interne doit être complexe. Au contraire, la carte principale doit rester simple ; la puissance vient de la transition vers les autres plans lorsque la question change.

## 8. Architecture des données

### 8.1 Principe : calculer l’exhaustif, stocker l’exception

Une table de 16 777 216 lignes comportant Hex, trois entiers et des conversions calculables gaspillerait stockage, bande passante et temps d’indexation. Un identifiant `rgb24` suffit à reconstruire les canaux :

`R = (rgb24 >> 16) & 255`  
`V = (rgb24 >> 8) & 255`  
`B = rgb24 & 255`

Les conversions déterministes peuvent être mémorisées en cache lorsqu’elles sont coûteuses, sans devenir la source de vérité. La base persiste ce qui ne peut pas être déduit : noms, langues, corpus, relations, mesures, licences, profils et citations.

### 8.2 Entités proposées

| Entité | Champs principaux | Remarque |
|---|---|---|
| `ColorAddress` | `rgb24`, Hex et canaux calculés | objet virtuel ou matérialisé à la demande |
| `NamedColor` | libellé, langue, corpus, édition, valeur/plage, statut | un nom peut viser plusieurs valeurs selon les sources |
| `DocumentaryRecord` | type, titre, période, lieu, description, confiance | unité de connaissance éditoriale |
| `MaterialSample` | matériau, composition, support, illuminant, mesures | distinct de la représentation écran |
| `Relation` | source, cible, prédicat, portée, confiance | permet alias, retrait, approximation et controverse |
| `Citation` | auteur, institution, titre, URL, date, licence, extrait | obligatoire pour les affirmations historiques |
| `PrintConversion` | profils, intention, options, moteur, CMJN | résultat contextuel, jamais valeur canonique |
| `Corpus` | propriétaire, version, licence, politique de mise à jour | évite le mélange des référentiels |

### 8.3 Identifiants et déduplication

L’identifiant canonique d’une valeur numérique est `rgb24`. Les noms ne sont jamais utilisés comme clés primaires. Deux libellés identiques peuvent viser des valeurs différentes ; deux libellés différents peuvent viser la même valeur. La déduplication exacte s’effectue sur le couple corpus–valeur ; la proximité perceptuelle produit des suggestions, pas des fusions automatiques.

Les documents et matériaux disposent d’identifiants indépendants. Une approximation sRGB est liée par une relation qualifiée, ce qui autorise plusieurs approximations selon l’illuminant, la photographie ou la méthode de mesure.

### 8.4 Provenance et confiance

Chaque assertion doit connaître sa source et sa portée. Un modèle minimal de confiance peut employer quatre niveaux :

| Niveau | Définition |
|---|---|
| **A — normatif ou mesuré** | valeur définie par une norme ou mesure instrumentale avec conditions |
| **B — institutionnel attesté** | musée, archive, publication scientifique ou catalogue critique |
| **C — secondaire recoupé** | synthèse cohérente avec plusieurs sources crédibles |
| **D — piste à vérifier** | mention unique, ambiguë ou sans accès à la source primaire |

Le niveau ne doit pas être converti en pourcentage pseudo-précis. Une note explique toujours la cause de l’incertitude.

### 8.5 Multilinguisme

Un nom est une ressource linguistique avec langue, région, translittération, dates d’usage et notes culturelles. La traduction automatique peut aider à découvrir des correspondances mais ne doit pas écraser l’original. Le moteur conserve les variantes orthographiques et les termes historiques potentiellement sensibles dans leur contexte, accompagnés d’une politique éditoriale.

### 8.6 Licences

Les corpus ouverts, les standards consultables et les catalogues commerciaux n’accordent pas les mêmes droits. Les données Pantone, RAL ou de fabricants ne doivent pas être copiées en masse sans autorisation. La base doit stocker licence, attribution, restrictions et méthode d’acquisition au niveau du corpus. Les sources publiques peuvent être liées sans que leur contenu intégral soit reproduit.

## 9. Architecture technique et performances

### 9.1 Budget de rendu

La règle d’or est de ne jamais représenter une couleur par un nœud DOM permanent. Le DOM sert aux commandes, libellés, résultats, panneaux et alternatives accessibles. La carte est rendue comme un champ paramétrique ou une texture.

WebGPU expose buffers, textures, pipelines et calculs GPU adaptés aux rendus massifs, mais sa disponibilité n’est pas encore universelle.[10] [11] L’architecture doit appliquer une amélioration progressive :

| Niveau | Technologie | Usage |
|---:|---|---|
| 1 | Canvas 2D | compatibilité et prototype fonctionnel |
| 2 | OffscreenCanvas + Worker | rendu hors du fil principal |
| 3 | WebGL2 | accélération largement disponible |
| 4 | WebGPU | rendu et calcul modernes lorsque pris en charge |

OffscreenCanvas peut être utilisé dans un Worker afin de réduire le blocage de l’interface ; les Workers communiquent par messages et exécutent les calculs en arrière-plan.[12] [13]

### 9.2 Stratégie de niveau de détail

Le moteur reçoit un état minimal : adresse active, profondeur, taille du viewport, mode de représentation et filtres. Il calcule uniquement les tuiles visibles, les balises agrégées et les étiquettes dont la taille dépasse un seuil. Les annotations documentaires sont paginées ou chargées par région.

Le cache suit la hiérarchie : chaque nœud mémorise éventuellement sa densité documentaire, sa miniature et ses statistiques. Les feuilles RGB n’ont pas besoin d’exister en base pour être visitées.

### 9.3 Indexation

La recherche exacte par Hex ou RGB est un calcul direct. Les noms utilisent un index textuel normalisé mais respectueux des diacritiques et langues. Les voisinages perceptuels des seules entrées documentées peuvent utiliser un index spatial Oklab ; les couleurs numériques arbitraires sont générées autour de la requête selon le besoin. Les relations documentaires peuvent être servies par une base relationnelle avec tables de liens ou, à grande échelle, par un graphe.

### 9.4 États partageables

L’URL encode le mode, l’adresse, la profondeur, les filtres et la métrique perceptuelle. Le même état produit la même vue de données, hors variations de taille d’écran. Les exports contiennent les hypothèses : espace source, profil éventuel, formule, version du corpus et date.

### 9.5 Objectifs de performance du prototype

| Indicateur | Cible initiale |
|---|---:|
| ouverture d’un Hex saisi | moins de 100 ms hors chargement initial |
| interaction carte | 60 i/s visées, 30 i/s minimum acceptable sur appareil modeste |
| profondeur pour une couleur exacte | 8 décisions maximum |
| nœuds DOM liés aux couleurs | aucun ensemble exhaustif ; seulement les éléments visibles/accessibles |
| tâche longue sur fil principal | aucune au-delà de 50 ms visées |
| taille du noyau de données initial | corpus nommé minimal et métadonnées, pas la table RGB exhaustive |

Ces objectifs sont des critères de conception à mesurer, non des performances déjà démontrées.

## 10. Accessibilité et vision des couleurs

### 10.1 La couleur ne suffit jamais

WCAG 2.2 exige que la couleur ne soit pas l’unique moyen de transmettre une information ou une action.[14] Dans le Chromatome, chaque tuile possède une adresse textuelle, un état de focus, un contour de sélection et une description des plages RGB. Les types documentaires se distinguent par forme et libellé, pas uniquement par teinte.

### 10.2 Contrastes

WCAG 2.2 demande au niveau AA un rapport d’au moins 4,5:1 pour le texte ordinaire et 3:1 pour le grand texte, sous les exceptions prévues.[15] L’interface adopte un chrome neutre qui ne change pas avec la couleur explorée. Lorsqu’un texte est superposé à un échantillon, un algorithme choisit un premier plan approprié et affiche le ratio obtenu.

Il faut éviter la mention « cette couleur est accessible » : l’accessibilité dépend d’un rôle et d’un contexte. Une couleur peut convenir comme fond avec du texte noir et échouer avec du texte blanc.

### 10.3 Navigation clavier et alternative au canvas

Toutes les actions essentielles sont disponibles au clavier : déplacement entre octants, entrée, remontée, recherche et ouverture de fiche. Une table synchronisée présente les huit régions ou les résultats visibles. Les technologies d’assistance disposent ainsi d’une structure sémantique équivalente au rendu graphique.

### 10.4 Simulations et limites

Les modes de simulation de déficiences de vision des couleurs sont des aides de conception, non des reproductions parfaites de l’expérience individuelle. Ils doivent être nommés comme simulations, accompagnés de contrôles de contraste et d’un rappel que les utilisateurs réels restent la meilleure source de validation.

### 10.5 Mouvement

Les transitions servent à conserver l’orientation lors d’un changement de niveau. Elles n’animent que transformation et opacité, restent brèves et se désactivent selon `prefers-reduced-motion`. Les commandes fréquentes, notamment la recherche clavier, répondent instantanément.

## 11. La « chasse aux couleurs manquantes »

### 11.1 Redéfinir la mission

La promesse crédible n’est pas de révéler des longueurs d’onde secrètes qu’un écran sRGB aurait cachées. Elle consiste à retrouver et relier des **traces documentaires** : pigments ou colorants abandonnés, recettes disparues, noms rares, entrées retirées, appellations modifiées, échantillons non numérisés, données sans traduction, mesures incompatibles ou récits contestés.

> Une couleur « manquante » est une lacune dans un corpus, une transmission ou une documentation ; elle n’est pas nécessairement une nouvelle sensation visuelle.

### 11.2 Typologie des lacunes

| Type de lacune | Exemple de preuve attendue | Traitement dans la Chromathèque |
|---|---|---|
| pigment devenu obsolète | analyses, catalogues, archives de fabrication | fiche matériau et motif d’obsolescence |
| appellation renommée | deux éditions d’un référentiel | relation `RENAMED_TO` avec dates |
| entrée retirée | version antérieure et version actuelle | relation `REMOVED_FROM` et justification attestée |
| nom régional rare | dictionnaire, archive ou collection | nom multilingue avec aire et période |
| échantillon sans valeur numérique stable | mesure ou photographie documentée | plusieurs approximations contextualisées |
| attribution contestée | sources contradictoires | relation `CONTESTED`, arguments et confiance |
| lacune de numérisation | inventaire institutionnel non reproduit en ligne | piste de recherche et statut d’accès |

### 11.3 Collections de pigments

Les Harvard Art Museums décrivent la Forbes Pigment Collection comme un ensemble de plus de 2 700 pigments, enrichi et utilisé par les scientifiques de la conservation. La collection comprend notamment des matériaux historiques tels que lapis-lazuli, bleu égyptien, pourpre de Tyr et vert malachite.[16] La base CAMEO du Museum of Fine Arts de Boston décrit un corpus Forbes élargi de plus de 3 000 colorants répartis entre plusieurs institutions.[17] Ces nombres ne se contredisent pas nécessairement : ils renvoient à des périmètres différents.

Ces collections montrent la bonne unité de connaissance. Le sujet n’est pas seulement une apparence ; ce sont aussi une composition, une origine, une période, une technique d’identification et un réseau d’institutions.

### 11.4 Pigments dangereux et disparitions d’usage

Le Saint Louis Art Museum documente l’invention du vert de Scheele en 1775 et l’emploi de pigments arsenicaux dans des papiers peints, avant leur obsolescence progressive dans cet usage à la fin du XIXe siècle.[18] Le RISD Museum a analysé des papiers peints des XVIIIe et XIXe siècles et confirmé la présence d’arsenic dans plusieurs zones ; il rappelle aussi que le problème ne se limitait pas aux verts.[19]

Ces cas illustrent une disparition documentée d’un matériau ou d’un usage, pas celle d’un triplet RGB. Une reproduction écran est utile pour orienter le visiteur, mais doit rester qualifiée d’approximation.

### 11.5 Couleurs retirées, renommées et controversées

Un registre sérieux exige une preuve versionnée. Une publication secondaire affirmant qu’une couleur a été « interdite » ne suffit pas. Pour accepter un retrait, la Chromathèque cherchera l’entrée dans une édition antérieure, son absence ou remplacement dans une édition ultérieure, puis une explication institutionnelle si elle existe.

Les raisons de changement peuvent être techniques, commerciales, juridiques, culturelles ou éthiques. La fiche ne réduit pas ces causes à une étiquette unique ; elle conserve les formulations des organismes concernés et indique les désaccords.

### 11.6 Workflow d’enquête

| Étape | Action | Sortie |
|---:|---|---|
| 1 | signalement d’une piste | entrée non publiée ou niveau D |
| 2 | identification des sources primaires | bibliographie et documents d’archive |
| 3 | recoupement indépendant | chronologie et divergences |
| 4 | qualification de l’objet | nom, matériau, standard, valeur ou usage |
| 5 | approximation ou mesure | conditions et méthode explicites |
| 6 | revue éditoriale | niveau de confiance et publication |
| 7 | suivi | nouvelles sources, corrections et versionnement |

### 11.7 Interface de chasse

Le mode « Lacunes » présente une carte documentaire, non un palmarès sensationnaliste. Les filtres portent sur période, lieu, matériau, statut, institution, niveau de preuve et besoin de contribution. Une fiche peut solliciter une traduction, une photographie autorisée, une analyse ou l’identification d’une édition manquante.

La contribution publique doit être modérée. Les utilisateurs peuvent proposer des sources, mais ne créent pas directement des faits publiés. Chaque modification garde son auteur, sa date et son historique.

## 12. Gouvernance scientifique et éditoriale

### 12.1 Charte de vérité

La Chromathèque applique cinq règles :

1. Une valeur calculée est distinguée d’une valeur mesurée.
2. Une approximation écran n’est pas une identité matérielle.
3. Un nom est toujours rattaché à un corpus, une langue ou une source.
4. Une conversion CMJN de production est rattachée à des profils et conditions.
5. Une affirmation historique possède une citation, une portée et un niveau de confiance.

### 12.2 Comité et rôles

Le projet gagnerait à associer colorimétrie, développement graphique, conservation-restauration, histoire des techniques, linguistique, accessibilité et droit des données. Le comité ne doit pas valider chaque calcul déterministe, mais les politiques de source, les cas controversés, les corpus sensibles et les changements de schéma.

### 12.3 Versionnement

Chaque corpus intégré possède un numéro de version. Les fiches documentaires conservent l’historique des modifications et les relations obsolètes. Une exportation indique la date, la version des formules et les corpus actifs. Cette discipline permet de corriger sans effacer les états antérieurs.

### 12.4 Droit de correction

Les institutions, chercheurs et communautés concernées doivent pouvoir demander une correction documentée. Une correction ne supprime pas silencieusement l’historique ; elle ajoute un nouvel état, une justification et, si nécessaire, une note sur l’erreur antérieure.

## 13. Conception de l’expérience

### 13.1 Parcours principal

Le premier écran affirme le nombre total et propose trois portes : explorer la carte, saisir une couleur, ou ouvrir la chasse documentaire. La carte occupe l’espace central ; la fiche latérale reste ancrée. L’utilisateur peut choisir entre « Adresse », « Perception » et « Documents », tout en conservant la même sélection.

### 13.2 Hiérarchie de la fiche couleur

| Niveau | Contenu |
|---|---|
| immédiat | échantillon, Hex, RVB, bouton de copie, adresse Chromatome |
| technique | HSL/HWB, Oklab/OKLCH, contraste contextuel, CMJN pédagogique |
| documentaire | noms, alias, corpus, relations historiques, sources |
| expert | métriques, profils ICC, paramètres et exports |

Cette progression évite qu’une fiche ordinaire soit noyée sous les détails, tout en rendant ceux-ci accessibles.

### 13.3 Identité visuelle

L’interface doit être neutre sans être clinique. Un fond ivoire très clair et un graphite profond offrent un contexte stable ; un vert minéral sert de couleur de marque sans entrer en compétition avec les échantillons. La typographie combine un caractère éditorial pour les titres et une grotesque lisible pour les données. Les angles, filets et coordonnées évoquent un atlas scientifique plutôt qu’un tableau de bord générique.

La couleur sélectionnée ne recolore pas tout le chrome. Elle apparaît dans la carte, les échantillons et certains signaux contrôlés, ce qui préserve contraste, stabilité et identité.

### 13.4 Micro-interactions

Le passage entre niveaux doit donner l’impression que la tuile choisie devient le nouveau territoire. Le fil d’Ariane et les plages de canaux se mettent à jour pendant la transition. Les interactions fréquentes restent inférieures à 300 ms ; les raccourcis clavier ne sont pas animés. Les mouvements non essentiels sont désactivables.

## 14. Plan de réalisation

### 14.1 Phase A — preuve d’adressage

Le premier prototype doit démontrer le calcul Hex ↔ RGB ↔ adresse octale, la mosaïque à huit niveaux, le partage d’URL et la fiche technique. Il fonctionne avec Canvas 2D afin de valider la mécanique avant toute optimisation GPU.

### 14.2 Phase B — perception et accessibilité

La seconde étape ajoute Oklab/OKLCH, les voisinages, les contrôles de contraste, la navigation clavier, la table alternative et les tests avec des utilisateurs présentant différentes visions des couleurs.

### 14.3 Phase C — corpus documentaire

Un corpus pilote intègre les couleurs CSS, une sélection de pigments institutionnels et quelques cas de retraits ou renommages parfaitement sourcés. Le but n’est pas le volume, mais la solidité du modèle de provenance.

### 14.4 Phase D — moteur et contributions

La recherche multilingue, les filtres d’enquête, les propositions de sources et le workflow éditorial sont ajoutés après validation du schéma. Les corpus propriétaires ne sont intégrés qu’avec les droits nécessaires.

### 14.5 Phase E — accélération et ouverture

WebGL2 ou WebGPU accélère la carte lorsque les mesures le justifient. Une API publique peut exposer les adresses, calculs et entrées ouvertes. Les exports mentionnent leurs licences et hypothèses.

## 15. Protocole d’évaluation

### 15.1 Étude comparative

Le Chromatome doit être comparé à un sélecteur 2D classique, un cube RGB 3D et une recherche directe. Les participants réalisent des tâches d’adressage, de retour à une couleur, de découverte d’une voisine et d’identification d’une source.

| Mesure | Question |
|---|---|
| temps de tâche | le parcours en huit niveaux reste-t-il efficace ? |
| taux d’erreur | l’utilisateur distingue-t-il adresse et perception ? |
| rappel spatial | retrouve-t-il une région après interruption ? |
| sérendipité utile | découvre-t-il des entrées pertinentes sans se perdre ? |
| charge perçue | l’interface est-elle compréhensible sans formation ? |
| accessibilité | les tâches sont-elles réalisables au clavier et avec assistance ? |

### 15.2 Tests scientifiques

Les conversions sRGB doivent être testées sur des valeurs de référence. L’implémentation CIEDE2000 utilise les jeux de paires publiés par Sharma.[9] Les ratios WCAG ne sont pas arrondis avant comparaison aux seuils.[15] Les conversions ICC, lorsqu’elles seront introduites, conservent les profils et paramètres pour assurer la reproductibilité.

### 15.3 Tests de performance

Les mesures couvrent temps de démarrage, cadence d’image, durée des tâches du fil principal, consommation mémoire et comportement sur appareil mobile. Les modes Canvas, WebGL2 et WebGPU sont comparés lorsque disponibles. Le repli doit rester fonctionnel, même s’il est visuellement moins riche.

## 16. Risques et parades

| Risque | Gravité | Parade |
|---|---|---|
| confusion entre code et perception | élevée | séparation visible des modes et légendes permanentes |
| effet graphique sans utilité | élevée | tests de tâches et maintien de la recherche directe |
| surpromesse de « couleurs secrètes » | élevée | charte documentaire, niveaux de preuve et vocabulaire prudent |
| faux CMJN universel | élevée | double sortie, profil obligatoire pour le mode production |
| copie de corpus propriétaires | élevée | registre de licences et ingestion contrôlée |
| surcharge cognitive | moyenne | zoom sémantique, détails progressifs et tutoriel court |
| exclusion par le canvas | élevée | table synchronisée, clavier et annonces sémantiques |
| incompatibilité WebGPU | moyenne | amélioration progressive et Canvas universel |
| divergences historiques | normale | relations contestées et versionnement, pas d’effacement |
| coût de maintenance | moyenne | calcul à la demande et corpus modulaires |

## 17. Recommandations finales

La Chromathèque ne doit pas commencer par générer un fichier massif. Elle doit commencer par le **mécanisme d’adresse** et la **grammaire de preuve**. Ces deux fondations permettent ensuite d’accueillir des millions de valeurs virtuelles et des milliers de documents réels sans les confondre.

Le prototype recommandé comprend cinq fonctions non négociables : carte octree en huit niveaux, saisie directe réversible, lentille Oklab/OKLCH, fiche Hex/RVB/CMJN explicitement contextualisée, et balises documentaires avec provenance. Le cube 3D, la courbe de Hilbert ou les visualisations spectaculaires peuvent devenir des vues secondaires, mais ne doivent pas porter seuls la navigation principale.

La « meilleure innovation d’affichage » n’est pas de forcer seize millions de pixels sur une page. C’est de garantir qu’une couleur quelconque est **à huit décisions**, qu’elle peut être comparée selon la bonne notion de proximité, et que toute histoire associée indique ce qui est connu, mesuré, interprété ou encore manquant.

## Conclusion

Le pari est réalisable parce que le nombre de couleurs est immense pour une interface naïve mais petit et parfaitement structuré pour un espace d’adresses 24 bits. Le Chromatome exploite cette structure plutôt que de la subir. Il remplace le catalogue exhaustif par une carte calculée, la proximité implicite par des métriques explicites et le mythe des couleurs cachées par une enquête traçable.

Cette architecture peut devenir à la fois un outil de conception, un instrument pédagogique, un registre patrimonial et une plateforme de recherche. Sa valeur dépendra moins du volume initial de noms que de la clarté de ses distinctions : **code, apparence, matériau et récit**.

## Annexes disponibles

| Fichier | Contenu |
|---|---|
| `research/analysis/specification-chromatome.md` | spécification détaillée du mécanisme |
| `research/analysis/matrice-concepts.csv` | notes et calculs de la comparaison |
| `research/analysis/comparaison-concepts.png` | graphique de synthèse |
| `research/analysis/architecture-chromatome.png` | architecture multi-vues |
| `research/validation-sources-primaires.md` | registre de validation des sources |
| `research/01-…` à `research/14-…` | rapports parallèles complets |

## Références

[1]: https://www.w3.org/Graphics/Color/sRGB.html "W3C — A Standard Default Color Space for the Internet — sRGB (source historique)"
[2]: https://registry.color.org/rgb-registry/srgb "International Color Consortium — sRGB Three Component Color Encoding Registry"
[3]: https://www.w3.org/TR/css-color-4/ "W3C — CSS Color Module Level 4"
[4]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Values/named-color "MDN — named-color CSS data type"
[5]: https://cie.co.at/publications/colorimetry-part-6-ciede2000-colour-difference-formula "CIE — Colorimetry Part 6: CIEDE2000 Colour-Difference Formula"
[6]: https://www.color.org/ "International Color Consortium"
[7]: https://registry.color.org/profile-library/ "ICC — Profile Library"
[8]: https://experienceleague.adobe.com/en/docs/dynamic-media-classic/using/support-files/icc-profiles "Adobe — ICC profiles"
[9]: https://www.ece.rochester.edu/~gsharma/ciede2000/ "University of Rochester — CIEDE2000 implementation notes and test data"
[10]: https://www.w3.org/TR/webgpu/ "W3C — WebGPU"
[11]: https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API "MDN — WebGPU API"
[12]: https://developer.mozilla.org/en-US/docs/Web/API/OffscreenCanvas "MDN — OffscreenCanvas"
[13]: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers "MDN — Using Web Workers"
[14]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C WAI — Understanding Success Criterion 1.4.1 Use of Color"
[15]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html "W3C WAI — Understanding Success Criterion 1.4.3 Contrast Minimum"
[16]: https://harvardartmuseums.org/article/pigment-collection-colors-all-aspects-of-the-museums "Harvard Art Museums — Pigment collection colors all aspects of the museums"
[17]: https://cameo.mfa.org/wiki/Forbes_Pigment_Database "Museum of Fine Arts Boston CAMEO — Forbes Pigment Database"
[18]: https://www.slam.org/blog/arsenic-in-victorian-wallpaper/ "Saint Louis Art Museum — Arsenic in Victorian wallpaper"
[19]: https://risdmuseum.org/issue-15-green/object-lesson-deceptive-decor-uncovering-arsenic-18th-19th-century-wallpapers-emily "RISD Museum — Uncovering arsenic in eighteenth- and nineteenth-century wallpapers"
[20]: https://www.w3.org/TR/WCAG22/ "W3C — Web Content Accessibility Guidelines 2.2"
[21]: https://www.w3.org/TR/css-color-3/ "W3C — CSS Color Module Level 3"
[22]: https://aclanthology.org/L06-1080/ "Bordoni — Towards an Ontology for Art and Colours"
[23]: https://www.iso.org/obp/ui/#!iso:std:60611:en "ISO/IEC 17823 — Colour terminology for office equipment"
[24]: https://raphlinus.github.io/color/2021/01/18/oklab-critique.html "Raph Levien — An interactive review of Oklab"
