ALTER TABLE `pattern_project_versions` ADD `provenance` json NOT NULL;--> statement-breakpoint
ALTER TABLE `pattern_projects` ADD `provenance` json NOT NULL;