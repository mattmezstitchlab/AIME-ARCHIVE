import { index, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type PatternSourceType = "manual" | "prompt" | "image" | "pdf";

export const patternProjects = mysqlTable(
  "pattern_projects",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    clientId: varchar("clientId", { length: 64 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    sourceType: mysqlEnum("sourceType", ["manual", "prompt", "image", "pdf"]).default("manual").notNull(),
    sourceName: varchar("sourceName", { length: 255 }),
    sourceKey: varchar("sourceKey", { length: 768 }),
    sourceUrl: text("sourceUrl"),
    sourcePage: int("sourcePage"),
    prompt: text("prompt"),
    rightsConfirmedAt: timestamp("rightsConfirmedAt"),
    provenance: json("provenance").notNull(),
    document: json("document").notNull(),
    conversion: json("conversion").notNull(),
    printSettings: json("printSettings").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("pattern_projects_user_client_unique").on(table.userId, table.clientId),
    index("pattern_projects_user_updated_idx").on(table.userId, table.updatedAt),
  ],
);

export const patternProjectVersions = mysqlTable(
  "pattern_project_versions",
  {
    id: int("id").autoincrement().primaryKey(),
    projectId: int("projectId").notNull().references(() => patternProjects.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    revision: int("revision").notNull(),
    provenance: json("provenance").notNull(),
    document: json("document").notNull(),
    conversion: json("conversion").notNull(),
    printSettings: json("printSettings").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("pattern_versions_project_revision_unique").on(table.projectId, table.revision),
    index("pattern_versions_user_created_idx").on(table.userId, table.createdAt),
  ],
);

export type PatternProject = typeof patternProjects.$inferSelect;
export type InsertPatternProject = typeof patternProjects.$inferInsert;
export type PatternProjectVersion = typeof patternProjectVersions.$inferSelect;
export type InsertPatternProjectVersion = typeof patternProjectVersions.$inferInsert;