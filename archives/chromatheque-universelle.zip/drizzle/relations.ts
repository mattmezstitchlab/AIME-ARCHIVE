import { relations } from "drizzle-orm";
import { patternProjects, patternProjectVersions, users } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  patternProjects: many(patternProjects),
  patternProjectVersions: many(patternProjectVersions),
}));

export const patternProjectsRelations = relations(patternProjects, ({ many, one }) => ({
  user: one(users, {
    fields: [patternProjects.userId],
    references: [users.id],
  }),
  versions: many(patternProjectVersions),
}));

export const patternProjectVersionsRelations = relations(patternProjectVersions, ({ one }) => ({
  project: one(patternProjects, {
    fields: [patternProjectVersions.projectId],
    references: [patternProjects.id],
  }),
  user: one(users, {
    fields: [patternProjectVersions.userId],
    references: [users.id],
  }),
}));
