CREATE TABLE `pattern_project_versions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`userId` int NOT NULL,
	`revision` int NOT NULL,
	`document` json NOT NULL,
	`conversion` json NOT NULL,
	`printSettings` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pattern_project_versions_id` PRIMARY KEY(`id`),
	CONSTRAINT `pattern_versions_project_revision_unique` UNIQUE(`projectId`,`revision`)
);
--> statement-breakpoint
CREATE TABLE `pattern_projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`clientId` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`sourceType` enum('manual','prompt','image','pdf') NOT NULL DEFAULT 'manual',
	`sourceName` varchar(255),
	`sourceKey` varchar(768),
	`sourceUrl` text,
	`sourcePage` int,
	`prompt` text,
	`rightsConfirmedAt` timestamp,
	`document` json NOT NULL,
	`conversion` json NOT NULL,
	`printSettings` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pattern_projects_id` PRIMARY KEY(`id`),
	CONSTRAINT `pattern_projects_user_client_unique` UNIQUE(`userId`,`clientId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
ALTER TABLE `pattern_project_versions` ADD CONSTRAINT `pattern_project_versions_projectId_pattern_projects_id_fk` FOREIGN KEY (`projectId`) REFERENCES `pattern_projects`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `pattern_project_versions` ADD CONSTRAINT `pattern_project_versions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `pattern_projects` ADD CONSTRAINT `pattern_projects_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `pattern_versions_user_created_idx` ON `pattern_project_versions` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `pattern_projects_user_updated_idx` ON `pattern_projects` (`userId`,`updatedAt`);