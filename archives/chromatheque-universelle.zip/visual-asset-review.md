# Contrôle des nouveaux médias

Le panorama héro est validé : format 16:9, zone sombre et calme à gauche pour la typographie, volume de broderie architecturale détaillé à droite, palette graphite–émeraude–or cohérente avec l’Atlas cinétique.

Le symbole possède une silhouette octale forte et reste exploitable à petite taille, mais la suppression du fond temporaire a laissé des franges magenta et des bandes résiduelles dans la transparence. Il doit être régénéré ou nettoyé avant publication ; la version actuelle ne doit pas être livrée.
