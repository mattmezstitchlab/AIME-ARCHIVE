import { z } from "zod";

export const gridGeometrySchema = z.enum(["square", "diamond", "hex"]);
export const patternSourceTypeSchema = z.enum(["manual", "prompt", "image", "pdf"]);
export const pageSizeSchema = z.enum(["a4", "a3", "letter"]);
export const pageOrientationSchema = z.enum(["auto", "portrait", "landscape"]);

export const stitchMarkSchema = z.object({
  id: z.string().max(64),
  x: z.number().int().min(0).max(399),
  y: z.number().int().min(0).max(399),
  stitchId: z.string().min(1).max(64),
  threadCode: z.string().min(1).max(32),
  orientation: z.union([z.literal(0), z.literal(45), z.literal(90), z.literal(135)]),
});

export const patternSnapshotSchema = z.record(z.string(), stitchMarkSchema);

export const printSettingsSchema = z.object({
  pageSize: pageSizeSchema.default("a4"),
  orientation: pageOrientationSchema.default("auto"),
  overlapCells: z.number().int().min(0).max(8).default(2),
  cellSizeMm: z.number().min(2).max(8).default(4),
});

export const conversionSettingsSchema = z.object({
  targetWidth: z.number().int().min(6).max(240).default(60),
  targetHeight: z.number().int().min(6).max(240).default(60),
  maxColors: z.number().int().min(2).max(48).default(16),
  confettiThreshold: z.number().int().min(0).max(12).default(2),
  convertedCells: z.number().int().min(0).default(0),
  confettiBefore: z.number().int().min(0).default(0),
  confettiAfter: z.number().int().min(0).default(0),
});

export const patternProvenanceSchema = z.object({
  sourceType: patternSourceTypeSchema.default("manual"),
  sourceName: z.string().max(255).nullable().default(null),
  sourceKey: z.string().max(768).nullable().default(null),
  sourceUrl: z.string().max(2048).nullable().default(null),
  sourceMimeType: z.string().max(160).nullable().default(null),
  sourceSize: z.number().int().min(0).max(15_000_000).nullable().default(null),
  sourcePage: z.number().int().min(1).max(999).nullable().default(null),
  prompt: z.string().max(2000).nullable().default(null),
  rightsConfirmedAt: z.string().datetime().nullable().default(null),
  transformations: z.array(z.string().max(180)).max(20).default([]),
});

export const patternDocumentSchema = z.object({
  version: z.literal(2),
  updatedAt: z.string().datetime(),
  documentTitle: z.string().min(1).max(160),
  presetId: z.string().max(64),
  dimensions: z.object({
    width: z.number().int().min(6).max(240),
    height: z.number().int().min(6).max(240),
  }),
  geometry: gridGeometrySchema,
  selectedThreadCode: z.string().max(32),
  selectedStitchId: z.string().max(64),
  camera: z.object({
    x: z.number().finite(),
    y: z.number().finite(),
    zoom: z.number().min(0.25).max(4),
  }),
  snapshot: patternSnapshotSchema,
  printSettings: printSettingsSchema,
  conversion: conversionSettingsSchema,
  provenance: patternProvenanceSchema,
});

export const syncedPatternProjectSchema = z.object({
  clientId: z.string().min(8).max(64),
  name: z.string().min(1).max(160),
  document: patternDocumentSchema,
  conversion: conversionSettingsSchema,
  printSettings: printSettingsSchema,
  provenance: patternProvenanceSchema,
});

export type GridGeometryData = z.infer<typeof gridGeometrySchema>;
export type PatternSourceType = z.infer<typeof patternSourceTypeSchema>;
export type PrintSettings = z.infer<typeof printSettingsSchema>;
export type ConversionSettings = z.infer<typeof conversionSettingsSchema>;
export type PatternProvenance = z.infer<typeof patternProvenanceSchema>;
export type PatternDocument = z.infer<typeof patternDocumentSchema>;
export type SyncedPatternProject = z.infer<typeof syncedPatternProjectSchema>;
