# Validation par sources primaires et institutionnelles

## Standards Web et sRGB

Le module **CSS Color Level 4** précise qu’il étend CSS à des espaces autres que sRGB, notamment afin d’exprimer des couleurs plus saturées hors du gamut sRGB. Il définit aussi la colorimétrie, les espaces colorimétriques, la linéarisation des espaces RGB encodés en gamma, les notions de caractérisation, de calibration et de gamut. Le texte rappelle qu’une couleur CSS valide peut néanmoins être hors gamut pour un périphérique donné et qu’un mappage de gamut est alors nécessaire. Source : W3C, *CSS Color Module Level 4*, https://www.w3.org/TR/css-color-4/

La page historique W3C sur sRGB indique explicitement qu’elle est obsolète comme spécification et que sRGB a ensuite été normalisé sous **IEC 61966-2-1**. Elle reste utile pour comprendre la motivation d’un espace par défaut pour Internet, la distinction entre espaces dépendants et indépendants du périphérique et les conditions de visualisation. Source : W3C, *A Standard Default Color Space for the Internet — sRGB*, https://www.w3.org/Graphics/Color/sRGB.html

Le registre de l’International Color Consortium identifie sRGB comme **IEC 61966-2-1:1999** et fournit ses primaires, le point blanc D65, la fonction de transfert par morceaux, une profondeur d’encodage de référence de 8 bits avec possibilité d’autres profondeurs, ainsi que les conditions de visualisation de référence. Source : ICC, *sRGB — Three Component Color Encoding Registry*, https://registry.color.org/rgb-registry/srgb

La documentation MDN recense les couleurs nommées CSS, rappelle les 16 couleurs de base, l’adoption des noms X11 via SVG puis CSS Color Level 3, l’ajout de `rebeccapurple` au niveau 4 et les alias tels que `aqua`/`cyan` ou `fuchsia`/`magenta`. Elle précise que les noms représentent des couleurs sRGB et ne reposent pas tous sur une logique stricte. Source : MDN, *<named-color> CSS data type*, https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Values/named-color

## Conséquences retenues

Le rapport distinguera l’univers exhaustif des **triplets sRGB 8 bits**, soit 256³ adresses, des espaces CSS modernes à gamut plus large. Les noms CSS formeront un corpus officiel mais extrêmement parcellaire par rapport à l’espace numérique. Les alias seront modélisés séparément des couleurs uniques. Toute affirmation liée à sRGB citera l’IEC ou l’ICC lorsque possible, tandis que la page W3C de 1996 sera présentée comme une source historique et non comme la norme actuelle.

## Gestion des couleurs, profils ICC et CMJN

L’International Color Consortium indique que sa mission est de promouvoir des systèmes de gestion des couleurs **ouverts, neutres vis-à-vis des fournisseurs et multiplateformes**. La spécification ICC v4 a été normalisée sous **ISO 15076-1** et les profils servent d’éléments centraux du flux de gestion des couleurs. Source : ICC, https://www.color.org/

La bibliothèque officielle de profils ICC précise qu’il existe différents types de profils et que l’ICC ne peut recommander un profil universel pour toute application : l’utilisateur doit vérifier qu’un profil convient à ses exigences. Cette réserve confirme qu’une valeur CMJN dépourvue de condition d’impression et de profil de destination ne peut être présentée comme une vérité universelle. Source : ICC, *Profile Library*, https://registry.color.org/profile-library/

La documentation Adobe sur les profils ICC rappelle qu’un profil de sortie s’applique notamment aux imprimantes, qu’un type d’espace comme RGB décrit le nombre et l’interprétation des composantes sans définir à lui seul les caractéristiques colorimétriques particulières, et que la transformation passe typiquement par un **Profile Connection Space** XYZ ou Lab avant la conversion vers CMJN. Source : Adobe Experience League, *ICC profiles*, https://experienceleague.adobe.com/en/docs/dynamic-media-classic/using/support-files/icc-profiles

### Décision de modélisation

Chaque fiche couleur affichera deux niveaux distincts : **CMJN estimé**, calcul déterministe et explicitement étiqueté comme approximation sans profil ; **CMJN géré**, champ réservé à une transformation liée à un profil ICC, une intention de rendu et une condition d’impression identifiés. Cette distinction évite de transformer une commodité mathématique en promesse de fidélité imprimée.

## Distance perceptuelle et espaces de travail

La norme conjointe ISO/CIE sur **CIEDE2000** rappelle que les distances égales dans XYZ, xyY et le diagramme de chromaticité xy ne représentent pas des différences visuelles égales. CIELAB et CIELUV sont seulement plus proches de l’uniformité, et CIEDE2000 ajoute des corrections dépendant de la clarté, de la chroma, de la teinte et de leurs interactions. La norme encadre aussi les conditions d’application : aucune distance numérique ne doit être décrite comme une mesure parfaite et universelle de la perception. Source : CIE, *Colorimetry — Part 6: CIEDE2000 Colour-Difference Formula*, https://cie.co.at/publications/colorimetry-part-6-ciede2000-colour-difference-formula

La page d’implémentation de Gaurav Sharma fournit des jeux de données de référence et signale des discontinuités mathématiques de CIEDE2000. L’application devra donc tester toute implémentation avancée contre ces valeurs et réserver CIEDE2000 aux fonctions où sa précision justifie son coût. Source : University of Rochester, https://www.ece.rochester.edu/~gsharma/ciede2000/

Une revue interactive d’Oklab souligne qu’un espace perceptuel idéal est impossible dans une géométrie euclidienne simple, mais que les approximations perceptuelles restent très utiles pour les dégradés, les palettes, les sélecteurs et la séparation de la clarté, de la chroma et de la teinte. Elle rappelle également que les conditions d’observation modifient la perception. Source secondaire technique : Raph Levien, *An interactive review of Oklab*, https://raphlinus.github.io/color/2021/01/18/oklab-critique.html

### Décision de modélisation

Le moteur conservera le **cube RGB exact** comme vérité d’adressage et utilisera **OKLCH/Oklab** pour la navigation perceptuelle, les voisinages interactifs et les interpolations. CIEDE2000 sera proposé comme métrique experte ou de validation, avec ses hypothèses visibles.

## Accessibilité chromatique

Le critère WCAG 2.2 **1.4.1 — Usage de la couleur** interdit d’utiliser la couleur comme seul moyen visuel de transmettre une information, une action ou un état. Toute structure de la carte devra donc être doublée par des coordonnées, libellés, formes, motifs, contours ou indications textuelles. Source : W3C WAI, https://www.w3.org/WAI/WCAG22/Understanding/use-of-color

Le critère WCAG 2.2 **1.4.3 — Contraste minimal** impose au niveau AA un rapport d’au moins **4,5:1** pour le texte ordinaire et **3:1** pour le grand texte, avec des exceptions limitées. Les seuils ne doivent pas être arrondis. Source : W3C WAI, https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html

La recommandation WCAG 2.2 insiste sur les quatre principes « perceptible, utilisable, compréhensible, robuste » et sur une validation mêlant tests automatisés et évaluation humaine. Source : W3C, https://www.w3.org/TR/WCAG22/

### Décision d’interface

La couleur explorée ne pourra jamais déterminer seule l’état d’un contrôle. L’application proposera une **peau d’interface neutre à fort contraste**, des repères numériques permanents, la navigation clavier, des marqueurs de sélection géométriques et des simulations de déficiences de vision des couleurs. Le système calculera à la volée les couleurs de texte adaptées au fond et affichera les ratios WCAG sans les confondre avec une validation esthétique générale.

## Rendu massif dans le navigateur

La spécification W3C présente **WebGPU** comme une API exposant efficacement les capacités du matériel GPU au Web et conçue pour correspondre aux API graphiques natives modernes. Elle fournit notamment buffers, textures, files de commandes, pipelines de rendu et de calcul, ainsi que des shaders validés. Source : W3C, *WebGPU*, https://www.w3.org/TR/webgpu/

MDN précise que WebGPU permet des calculs et rendus à haute performance, réduit le coût CPU par objet et prend en charge les pipelines de calcul général. Toutefois, son statut n’est pas encore « Baseline » sur tous les navigateurs courants : une architecture de production doit donc détecter sa disponibilité et prévoir un mode de repli. Source : MDN, *WebGPU API*, https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API

**OffscreenCanvas** est largement disponible depuis mars 2023 et permet de découpler le rendu du DOM ; les opérations peuvent être exécutées dans un Web Worker afin d’éviter que le calcul graphique lourd ne bloque le fil principal. Les Web Workers exécutent des scripts en arrière-plan sans interférer avec l’interface et communiquent par messages ou transferts. Sources : MDN, https://developer.mozilla.org/en-US/docs/Web/API/OffscreenCanvas et https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

### Décision d’architecture

L’application ne créera jamais 16 777 216 nœuds DOM et ne transférera pas une table exhaustive de couleurs : **chaque couleur sera calculée analytiquement depuis son identifiant 24 bits**. Le rendu principal sera une texture ou un champ paramétrique généré sur le GPU. L’architecture suivra une progression de capacités : WebGPU lorsque disponible ; WebGL2 ou Canvas 2D/OffscreenCanvas comme repli ; DOM uniquement pour les contrôles, libellés, résultats et éléments accessibles. Les calculs secondaires et index de recherche seront placés dans des Workers.

## Pistes institutionnelles à valider — pigments historiques et « couleurs perdues »

La recherche documentaire a identifié plusieurs corpus crédibles à examiner : la **Forbes Pigment Collection** des Harvard Art Museums, décrite comme un assemblage de plus de 2 700 pigments utilisé par les scientifiques de la conservation (https://harvardartmuseums.org/article/pigment-collection-colors-all-aspects-of-the-museums) ; la **Forbes Pigment Database** du MFA CAMEO, annoncée comme documentant plus de 3 000 colorants (https://cameo.mfa.org/wiki/Forbes_Pigment_Database) ; et des études muséales sur les verts arsenicaux de Scheele dans les papiers peints victoriens (https://www.slam.org/blog/arsenic-in-victorian-wallpaper/ ; https://risdmuseum.org/issue-15-green/object-lesson-deceptive-decor-uncovering-arsenic-18th-19th-century-wallpapers-emily).

Ces pistes appuient une définition prudente de la « chasse aux couleurs manquantes » : retrouver des **pigments, recettes, dénominations, usages et échantillons historiques documentés**, non prétendre découvrir des stimuli visuels situés hors du gamut sRGB. Les nombres de collections et les détails historiques doivent encore être recoupés dans les pages complètes avant citation finale.

## Corpus muséaux et pigments historiques validés

Les **Harvard Art Museums** décrivent la Forbes Pigment Collection comme un ensemble de **plus de 2 700 pigments**, toujours enrichi et activement utilisé par les scientifiques de la conservation comme collection d’essais et de références analytiques. Commencée par Edward Forbes au tournant du XXe siècle, elle contient notamment des matériaux japonais réunis dans les années 1930 et des pigments historiques tels que lapis-lazuli, pourpre de Tyr, bleu égyptien et vert malachite. Source institutionnelle : https://harvardartmuseums.org/article/pigment-collection-colors-all-aspects-of-the-museums

La base CAMEO du Museum of Fine Arts de Boston indique que la collection Forbes élargie comprend **plus de 3 000 colorants** répartis entre plusieurs institutions. Son objectif est de réunir inventaires, désignations concurrentes et résultats d’analyse afin d’aider à déterminer la composition des matériaux. Cette divergence apparente entre « 2 700 pigments » et « plus de 3 000 colorants » s’explique par le périmètre : collection centrale de Harvard contre corpus Forbes distribué et agrégé. Source institutionnelle : https://cameo.mfa.org/wiki/Forbes_Pigment_Database

Le Saint Louis Art Museum documente l’invention du **vert de Scheele** en 1775 et l’utilisation ultérieure de pigments arsenicaux dans les papiers peints et d’autres produits. La prise de conscience publique et les substitutions plus sûres ont rendu ces pigments obsolètes dans les papiers peints à la fin du XIXe siècle. Le musée distingue explicitement les preuves documentaires de l’analyse matérielle : pour son panneau *The Peacock Garden* de 1889, l’absence probable d’arsenic reste une hypothèse tant qu’une analyse XRF n’a pas été conduite. Source : https://www.slam.org/blog/arsenic-in-victorian-wallpaper/

Le RISD Museum a testé scientifiquement des papiers peints des XVIIIe et XIXe siècles et confirmé la présence d’arsenic dans plusieurs zones colorées. Le texte rappelle que le vert de Scheele, vif mais instable, fut suivi vers 1814 par le vert émeraude, plus durable ; il montre surtout que l’arsenic ne concernait pas uniquement le vert. Source : https://risdmuseum.org/issue-15-green/object-lesson-deceptive-decor-uncovering-arsenic-18th-19th-century-wallpapers-emily

### Conséquence éditoriale

La rubrique « couleurs disparues » sera conçue comme un **registre d’objets documentaires** : pigment ou colorant, noms et alias, dates et lieux attestés, composition, usages, motif de disparition ou restriction, institutions conservatrices, méthodes d’analyse et sources. Une approximation sRGB pourra illustrer chaque entrée, mais sera toujours qualifiée de **représentation écran**, jamais d’équivalence physique du matériau.

## État de l’art des interfaces et lacune de produit

La synthèse parallèle des outils existants distingue quatre familles actuellement fragmentées : générateurs de palettes et inspiration (par exemple Coolors, Color Hunt, Adobe Color), vérificateurs d’accessibilité, atlas industriels ou physiques, et gestion colorimétrique professionnelle. Les outils courants privilégient roues, plans saturation–luminosité et palettes présélectionnées ; ils ne rendent pas simultanément l’intégralité du cube sRGB **adressable, orientable et documentée**. Rapport de recherche parallèle conservé dans `research/11-etat-de-l-art-des-outils-et-interfaces-d-exploration-des-couleurs-produi.md`.

Les visualisations pertinentes recensées sont : cube RGB, solide perceptuel, coupes bidimensionnelles, octree, courbe de Hilbert, treemap et niveaux de détail. Leur fonction n’est pas interchangeable. Le cube RGB garantit l’exactitude du codage ; une vue OKLCH/Oklab facilite la navigation perceptuelle ; les coupes facilitent la comparaison précise ; l’octree fournit une hiérarchie naturelle de 8 sous-cubes ; la courbe de Hilbert fournit un ordre linéaire préservant partiellement la localité ; le niveau de détail évite l’affichage naïf de millions d’objets. Rapport parallèle : `research/05-visualisation-de-grands-espaces-chromatiques-cubes-rgb-solides-perceptue.md`.

### Lacune retenue

L’opportunité n’est pas de créer un sélecteur de plus, mais un **atlas universel multi-échelles** qui relie trois vérités : l’adresse numérique exacte de chaque sRGB 24 bits, son voisinage perceptuel approximatif, et les connaissances attestées qui ne concernent qu’une minorité de couleurs ou de matériaux. Le produit doit maintenir visibles ces distinctions au lieu de fusionner valeurs numériques, noms commerciaux, pigments et sensations.
