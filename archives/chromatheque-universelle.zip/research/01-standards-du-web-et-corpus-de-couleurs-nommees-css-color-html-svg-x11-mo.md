# Standards du Web et corpus de couleurs nommées

## Introduction

Ce rapport a pour objectif d'explorer en profondeur les standards de couleurs utilisés sur le Web, en se focalisant sur les spécifications **CSS Color**, **HTML**, **SVG**, ainsi que les noms de couleurs **X11**. Il analyse les mots-clés historiques, les alias et la compatibilité navigateur, afin de fournir une base solide pour la conception d'une interface innovante capable d'adresser et d'explorer l'intégralité des 16 777 216 couleurs du modèle RGB.

## Définitions Clés

*   **Couleur Web** : Une couleur spécifiée pour l'affichage de contenu sur le World Wide Web. Elle est généralement définie par un triplet RGB (Rouge, Vert, Bleu) en format hexadécimal ou par un nom de couleur prédéfini [1].
*   **Hex Triplet** : Une représentation hexadécimale à six chiffres (ou huit pour inclure le canal alpha) utilisée en HTML, CSS et SVG pour définir une couleur. Chaque paire de chiffres hexadécimaux (de `00` à `FF`) représente l'intensité d'une composante (rouge, vert, bleu) sur une échelle de 0 à 255 [1]. Par exemple, le rouge pur est représenté par `#FF0000`.
*   **sRGB** : L'espace colorimétrique standardisé (standard Red Green Blue) par défaut pour le Web. Il fournit une définition colorimétrique non ambiguë et objectivement mesurable, servant de référence pour la plupart des affichages numériques [1, 2].
*   **Mots-clés de couleur nommés** : Des identifiants textuels prédéfinis (par exemple, `red`, `blue`, `black`) qui peuvent être utilisés dans CSS et HTML pour spécifier des couleurs. Le nombre et la nature de ces mots-clés ont évolué au fil des différentes spécifications [2, 3].

## État de l'art des standards de couleurs sur le Web

### Évolution des spécifications HTML et CSS Color

L'histoire des couleurs sur le Web débute avec un ensemble restreint de noms. La spécification **HTML 4.01**, ratifiée en 1999, définissait 16 couleurs de base, principalement issues de la palette VGA de Windows [1]. Le module **CSS Level 1** a également défini ces 16 couleurs, auxquelles `orange` a été ajouté dans **CSS Level 2** [2].

Les navigateurs ont rapidement étendu cette liste en intégrant de nombreux noms de couleurs dérivés du système **X11**. Ces noms ont été formellement standardisés dans **SVG 1.0**, puis dans **CSS Colors Level 3**, où ils ont été définis de manière uniforme, incluant des alias pour des couleurs ayant des orthographes différentes [2].

Les spécifications plus récentes, notamment **CSS Colors Level 4**, ont introduit des avancées significatives. Elles permettent de spécifier des couleurs dans des espaces colorimétriques plus larges que le sRGB, tels que `display-p3` ou `rec2020`, afin de tirer parti des capacités des écrans modernes et d'afficher des gamuts de couleurs plus étendus [3].

Les méthodes de spécification des couleurs en CSS sont diverses et incluent [4, 5]:

*   **Noms de couleurs** : `red`, `blue`, `transparent`, `rebeccapurple` (ajouté en CSS Colors Level 4 en hommage à Eric Meyer) [2].
*   **Valeurs hexadécimales** : `#RRGGBB` (six chiffres) ou `#RGB` (trois chiffres, forme raccourcie) [1].
*   **Fonctions RGB** : `rgb(R, G, B)` ou `rgb(R%, G%, B%)` pour les valeurs entières ou en pourcentage [2].
*   **Fonctions RGBA** : `rgba(R, G, B, A)` qui ajoute un canal alpha pour la gestion de la transparence [2].
*   **Fonctions HSL/HSLA** : `hsl(H, S, L)` et `hsla(H, S, L, A)` basées sur la Teinte, la Saturation et la Luminosité, offrant une approche plus intuitive pour la manipulation des couleurs [4].
*   **Fonctions OKLCH/OKLAB** : Des formats plus récents conçus pour une meilleure uniformité perceptuelle et une manipulation plus prédictible des couleurs par l'œil humain [6].

### Couleurs SVG

Le format **SVG (Scalable Vector Graphics)** intègre également la gestion des couleurs. La spécification **SVG 1.1** a standardisé une liste étendue de mots-clés de couleurs, souvent désignés comme les couleurs X11 [1, 2]. De plus, SVG 1.1 a introduit la possibilité d'utiliser des profils **ICC (International Color Consortium)** pour une gestion colorimétrique plus précise dans des environnements où la fidélité des couleurs est critique [7].

### Noms de couleurs X11

Les noms de couleurs **X11** ont joué un rôle fondamental dans la définition des couleurs web. Les premières implémentations de navigateurs comme Mosaic et Netscape Navigator, étant des applications du système X Window, ont naturellement adopté ces noms comme base pour leurs palettes de couleurs [2]. La liste X11 est un fichier texte qui associe des chaînes de caractères à des valeurs RGB. Bien que non formellement standardisée par Xlib, son influence a été majeure sur les noms de couleurs reconnus sur le Web [2].

Il est important de noter les divergences entre les noms de couleurs X11 et les standards W3C, particulièrement pour les nuances de gris. Par exemple, le mot-clé `Gray` en HTML/CSS est défini comme un gris à 50% (`rgb(128, 128, 128)`), tandis que le `gray` de X11 correspondait à un gris plus clair (`rgb(190, 190, 190)`). Cette différence a mené à des incohérences, où `Dark Gray` en CSS 3.0 peut apparaître plus clair que `Gray` [2]. Pour résoudre ces ambiguïtés, les versions récentes de X.Org (depuis 2014) supportent également les définitions W3C, en utilisant des préfixes `Web` et `X11` pour distinguer les noms en cas de conflit [2].

## Mots-clés historiques, alias et compatibilité navigateur

Les 16 couleurs de base définies dans HTML 4.01 (`black`, `silver`, `gray`, `white`, `maroon`, `red`, `purple`, `fuchsia`, `green`, `lime`, `olive`, `yellow`, `navy`, `blue`, `teal`, et `aqua`) étaient universellement compatibles avec les navigateurs de l'époque [1]. L'ajout du mot-clé `orange` a complété cette palette initiale.

L'intégration des noms de couleurs X11 a considérablement enrichi le corpus de mots-clés. Il existe des alias, comme `aqua` et `cyan`, ou `fuchsia` et `magenta`, qui désignent la même couleur mais proviennent de différentes origines [2]. La compatibilité navigateur a été un enjeu majeur, les implémentations variant initialement. Cependant, la plupart des navigateurs modernes ont convergé pour supporter la liste étendue des couleurs nommées à partir de 2005 [1].

Les spécifications actuelles, comme CSS Color Module Level 4, continuent d'introduire de nouvelles fonctionnalités et espaces colorimétriques, ce qui exige une mise à jour constante des moteurs de rendu des navigateurs pour garantir une prise en charge complète et uniforme [3].

## Données techniques

Le modèle de couleur RGB, fondamental pour l'affichage numérique, utilise 24 bits (8 bits par canal pour le Rouge, le Vert et le Bleu), permettant de représenter 256 x 256 x 256 = 16 777 216 couleurs distinctes [1].

| Format de couleur | Description | Exemple | Nombre de couleurs représentables | Transparence (Alpha) |
|:------------------|:------------|:--------|:----------------------------------|:---------------------|
| Hexadécimal       | `#RRGGBB` ou `#RGB` | `#FF0000` (rouge), `#F00` (rouge) | 16 777 216 (6 chiffres), 4 096 (3 chiffres) | Non (sauf `#RRGGBBAA` en CSS4) [3] |
| RGB               | `rgb(R, G, B)` | `rgb(255, 0, 0)` | 16 777 216                        | Non                  |
| RGBA              | `rgba(R, G, B, A)` | `rgba(255, 0, 0, 0.5)` | 16 777 216                        | Oui                  |
| HSL               | `hsl(H, S, L)` | `hsl(0, 100%, 50%)` (rouge) | Théoriquement infini (précision flottante) | Non                  |
| HSLA              | `hsla(H, S, L, A)` | `hsla(0, 100%, 50%, 0.5)` | Théoriquement infini (précision flottante) | Oui                  |
| Noms de couleurs  | Mots-clés prédéfinis | `red`, `blue`, `rebeccapurple` | Environ 140 (selon les standards) [2] | `transparent` (mot-clé spécial) [2] |
| OKLCH/OKLAB       | Formats perceptuels modernes | `oklch(50% 0.1 200)` | Théoriquement infini (précision flottante) | Oui (avec canal alpha) |

Les espaces colorimétriques modernes comme `display-p3` et `rec2020` étendent le gamut sRGB, permettant d'afficher des couleurs plus saturées et vives. Par exemple, `display-p3` offre un volume de 1,233 million d'unités Lab, contre 0,820 pour sRGB, démontrant une capacité de reproduction colorimétrique supérieure [3].

## Limites et controverses

*   **Gamut sRGB restreint** : Le sRGB, bien qu'universellement supporté, ne couvre qu'une fraction des couleurs perceptibles par l'œil humain (environ 35%) [6]. Cette limitation empêche l'affichage de couleurs très saturées que certains dispositifs modernes sont capables de produire. Les nouvelles spécifications CSS Color Level 4 visent à surmonter cette contrainte en intégrant des espaces colorimétriques à large gamut [3].
*   **Incohérences des noms de couleurs** : Les divergences historiques entre les noms de couleurs X11 et les standards W3C ont créé des ambiguïtés et des rendus inconsistants, notamment pour les nuances de gris. Cette situation a nécessité des efforts de standardisation et l'introduction de préfixes pour clarifier les références [2].
*   **La notion de « couleurs secrètes » ou « disparues »** : Il n'existe pas de preuve attestant de l'existence de « couleurs secrètes » intrinsèquement cachées. Cependant, le concept de « couleurs disparues » peut être interprété comme des noms de couleurs tombés en désuétude, des pigments historiquement utilisés mais non reproductibles avec les technologies actuelles, ou des couleurs retirées des standards. Par exemple, certains noms de couleurs X11 n'ont pas été intégrés aux standards web, ou des alias ont été créés pour unifier des noms différents désignant la même couleur [2]. Ces phénomènes sont davantage liés à l'évolution des technologies d'affichage, des standards et des conventions linguistiques qu'à une disparition physique des couleurs.
*   **Variabilité du rendu et compatibilité** : Bien que les navigateurs modernes supportent les standards actuels, des variations subtiles dans le rendu des couleurs peuvent persister. Ces différences sont attribuables aux profils colorimétriques spécifiques des écrans, aux réglages des utilisateurs et aux implémentations des moteurs de rendu. L'utilisation de profils ICC en SVG est une tentative d'améliorer la cohérence colorimétrique à travers différents dispositifs [7].

## Implications directes pour l'architecture de données

Pour une interface conçue pour explorer et manipuler 16 777 216 couleurs RGB, l'architecture de données doit être à la fois robuste et flexible. Les implications principales sont les suivantes :

*   **Stockage optimisé des couleurs** : Les couleurs doivent être stockées de manière efficace, idéalement sous forme de triplets RGB (entiers de 0 à 255) ou de valeurs hexadécimales. Pour des manipulations plus intuitives, des représentations HSL, OKLCH ou CIELAB peuvent être calculées à la volée ou stockées comme attributs secondaires. Le choix du format doit minimiser la perte de précision et faciliter les conversions entre les différents espaces.
*   **Gestion des métadonnées colorimétriques** : Chaque couleur pourrait être enrichie de métadonnées, incluant son nom (si applicable), ses alias historiques, sa provenance (standard CSS, X11, etc.), et des informations perceptuelles (par exemple, son accessibilité pour les personnes atteintes de daltonisme). Ces métadonnées sont essentielles pour une exploration sémantique et éducative.
*   **Indexation et recherche avancée** : Un système d'indexation performant est nécessaire pour permettre une exploration rapide et pertinente des couleurs. Cet index pourrait être basé sur les composantes RGB, HSL, ou des coordonnées dans des espaces colorimétriques perceptuels (comme CIELAB ou CIELCH), facilitant la recherche de couleurs similaires, complémentaires ou appartenant à des catégories spécifiques.
*   **Intégration des profils colorimétriques (ICC)** : L'architecture doit prévoir la gestion et l'application des profils ICC pour garantir une représentation fidèle des couleurs sur une variété de dispositifs d'affichage. Ceci est crucial pour les applications nécessitant une haute précision colorimétrique.

## Implications directes pour une interface innovante

Une interface capable de gérer l'intégralité du spectre RGB offre des opportunités considérables pour l'innovation en matière d'affichage et d'interaction utilisateur :

*   **Exploration visuelle intuitive et multidimensionnelle** : L'interface pourrait proposer des outils d'exploration basés sur des modèles de couleurs perceptuels (HSL, CIELAB, CIELCH) plutôt que sur les seules valeurs RGB brutes. Des sélecteurs de couleurs avancés, des palettes dynamiques, des visualisations 2D ou 3D des espaces colorimétriques permettraient aux utilisateurs de naviguer intuitivement dans l'immense espace des 16,7 millions de couleurs.
*   **Recherche sémantique et contextuelle des couleurs** : Au-delà de la recherche par nom ou valeur numérique, l'interface pourrait intégrer une recherche basée sur des descripteurs sémantiques (par exemple, « couleurs chaudes », « couleurs froides », « couleurs pastel », « couleurs vives ») ou des associations culturelles et émotionnelles. Cela nécessiterait une base de données de couleurs nommées enrichie et des algorithmes de correspondance sémantique.
*   **Outils de compatibilité et de prévisualisation avancés** : L'interface devrait offrir des fonctionnalités de prévisualisation de l'apparence des couleurs sur différents types d'écrans et dans divers espaces colorimétriques (sRGB, Display P3, etc.). Des alertes visuelles pourraient indiquer les couleurs hors gamut ou les problèmes potentiels d'accessibilité (par exemple, pour les personnes daltoniennes), assurant ainsi une conception inclusive.
*   **Immersion historique et éducative** : L'interface pourrait intégrer une dimension historique, documentant l'évolution des noms de couleurs, les standards obsolètes, les alias et les couleurs X11. Cela offrirait une expérience éducative, montrant comment les couleurs ont été nommées, utilisées et standardisées au fil du temps.

## Recommandations concrètes

1.  **Prioriser les espaces colorimétriques perceptuels pour l'interaction utilisateur** : Développer des sélecteurs et des outils d'exploration de couleurs qui s'appuient sur des modèles comme HSL, CIELAB ou CIELCH. Ces modèles sont plus alignés sur la perception humaine et facilitent la création et l'ajustement intuitif des couleurs, en complément des valeurs RGB brutes.
2.  **Construire une base de données de noms de couleurs enrichie et interrogeable** : Créer ou intégrer une base de données complète qui mappe les valeurs RGB aux noms de couleurs reconnus (standards CSS, X11, alias historiques) et à des descripteurs sémantiques. Cette base de données devrait être interrogeable pour permettre une recherche riche et contextuelle des couleurs.
3.  **Intégrer des outils de gestion de gamut et de prévisualisation en temps réel** : L'interface doit inclure des fonctionnalités permettant de visualiser l'impact des différents espaces colorimétriques (sRGB, Display P3, etc.) sur le rendu des couleurs. Des alertes visuelles pour les couleurs hors gamut et des vérifications d'accessibilité (contraste, daltonisme) devraient être intégrées pour guider les utilisateurs vers des choix colorimétriques optimaux.

## Bibliographie

[1] Wikipedia. *Web colors*. Disponible sur : [https://en.wikipedia.org/wiki/Web_colors](https://en.wikipedia.org/wiki/Web_colors)
[2] Mozilla. *<named-color> CSS type*. Disponible sur : [https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Values/named-color](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Values/named-color)
[3] W3C. *CSS Color Module Level 4*. Disponible sur : [https://www.w3.org/TR/css-color-4/](https://www.w3.org/TR/css-color-4/)
[4] W3C. *CSS Color Module Level 3*. Disponible sur : [https://www.w3.org/TR/css-color-3/](https://www.w3.org/TR/css-color-3/)
[5] W3Schools. *CSS Colors*. Disponible sur : [https://www.w3schools.com/css/css_colors.asp](https://www.w3schools.com/css/css_colors.asp)
[6] Evil Martians. *OKLCH in CSS: why we moved from RGB and HSL*. Disponible sur : [https://evilmartians.com/chronicles/oklch-in-css-why-quit-rgb-hsl](https://evilmartians.com/chronicles/oklch-in-css-why-quit-rgb-hsl)
[7] W3C. *SVG Color 1.2, Part 2: Language*. Disponible sur : [https://www.w3.org/TR/SVGColor12/](https://www.w3.org/TR/SVGColor12/)
