# Rapport sur les Couleurs Retirées, Renommées, Controversées ou Absentes des Standards

## 1. Introduction et Définitions

Cet axe de recherche explore les dynamiques complexes qui mènent au retrait, au renommage, à la controverse ou à l'absence de certaines couleurs dans les standards et catalogues. Comprendre ces phénomènes est crucial pour le développement d'une interface innovante capable de gérer et d'explorer les 16 777 216 couleurs RGB, en particulier pour anticiper les implications en termes d'architecture de données et d'expérience utilisateur.

Une **couleur retirée** fait référence à un pigment ou une teinte qui a été délibérément écartée des palettes officielles ou des standards pour diverses raisons, souvent liées à la toxicité, à l'instabilité ou à des considérations éthiques. Les **couleurs renommées** sont des teintes dont l'appellation a évolué au fil du temps, reflétant des changements culturels, scientifiques ou commerciaux. Les **couleurs controversées** sont celles qui suscitent des débats, qu'il s'agisse de leur propriété intellectuelle, de leur impact environnemental ou de leur perception sociale. Enfin, les **couleurs absentes des standards** désignent des teintes qui, bien qu'existantes dans le spectre visuel ou dans des usages spécifiques, ne sont pas codifiées ou reconnues par les systèmes de classification dominants comme Pantone ou RAL.

## 2. État de l'Art et Contexte Historique

L'histoire des couleurs est intrinsèquement liée à l'évolution des techniques, des connaissances scientifiques et des sensibilités culturelles. De nombreux pigments utilisés par les maîtres anciens, bien que magnifiques, étaient extrêmement toxiques et ont été progressivement abandonnés ou remplacés par des alternatives plus sûres [1].

### 2.1. Pigments Toxiques et Retraits Documentés

Historiquement, des pigments comme le **blanc de plomb** (blanc de céruse), le **vermillon** (sulfure de mercure), les **verts arsenicaux** (vert de Scheele, vert de Paris) et le **jaune de Naples** (antimoniate de plomb) étaient couramment utilisés. Le blanc de plomb, apprécié pour son pouvoir couvrant et sa luminosité, était un neurotoxique puissant. Le vermillon, un rouge éclatant, contenait du mercure, provoquant des troubles neurologiques chez les artistes. Les verts arsenicaux, bien que révolutionnaires pour leur vivacité, étaient des poisons redoutables, responsables de maladies chroniques et de décès [1]. Le jaune de Naples, quant à lui, contenait de l'antimoine, un métal toxique [1].

Ces pigments ont été progressivement retirés des palettes des artistes et des catalogues en raison de leur dangerosité avérée pour la santé humaine et l'environnement. Les connaissances scientifiques croissantes sur la toxicologie ont conduit à leur remplacement par des alternatives synthétiques plus sûres, telles que le blanc de titane pour le blanc de plomb, et des rouges organiques pour le vermillon [1].

### 2.2. Changements de Nomenclature et Couleurs Oubliées

La nomenclature des couleurs a également évolué. Des noms de couleurs ont pu être oubliés ou remplacés par des termes plus modernes ou plus précis. Par exemple, le 
brun momie, un pigment populaire du XVIe au XIXe siècle, était littéralement fabriqué à partir de momies égyptiennes broyées. Son utilisation a été progressivement abandonnée, non seulement pour des raisons éthiques et de disponibilité, mais aussi en raison de sa variabilité et de ses propriétés techniques insatisfaisantes [2]. Ce cas illustre comment des couleurs peuvent être renommées ou retirées des usages pour des raisons éthiques et pratiques.

### 2.3. Couleurs Absentes des Standards et Catalogues

Certaines couleurs, bien qu'existantes dans la nature ou perceptibles par l'œil humain, ne sont pas formellement intégrées dans les systèmes de standardisation comme Pantone ou RAL. Cela peut être dû à leur complexité de reproduction, à leur instabilité, ou simplement à un manque de demande industrielle. L'exploration des 16 777 216 couleurs RGB révèle une multitude de nuances qui n'ont pas d'équivalent direct ou de nom établi dans les catalogues commerciaux, posant un défi pour leur identification et leur communication.

## 3. Sécurité/Toxicité et Prudence Interprétative

La question de la sécurité et de la toxicité des pigments est primordiale. Les exemples historiques de pigments à base de plomb, de mercure ou d'arsenic démontrent les risques graves pour la santé des artistes et des artisans. Aujourd'hui, les réglementations strictes encadrent la composition des pigments et des colorants, garantissant la sécurité des produits disponibles sur le marché. Cependant, la prudence reste de mise lors de l'interprétation des données historiques ou de l'exploration de nouvelles sources de couleurs.

Il est essentiel de distinguer les faits avérés des mythes. L'idée de « couleurs secrètes » ou « interdites » doit être abordée avec discernement. Si des pigments ont été retirés pour toxicité ou obsolescence, il ne s'agit pas de couleurs intrinsèquement « secrètes », mais plutôt de matériaux dont l'usage a été documenté et dont les raisons du retrait sont claires. La recherche doit se concentrer sur les retraits attestés de standards, les lacunes de corpus et les pigments disparus, plutôt que sur des spéculations non fondées.

## 4. Limites et Controverses

### 4.1. La Controverse du Vantablack

Le Vantablack, un matériau ultra-noir capable d'absorber jusqu'à 99,965% de la lumière visible, a suscité une controverse notable dans le monde de l'art. Développé initialement pour des applications aérospatiales et de défense, son utilisation artistique exclusive a été accordée à l'artiste Anish Kapoor. Cette exclusivité a provoqué l'indignation de nombreux artistes qui ont dénoncé un monopole sur une « couleur » ou un matériau [3]. Cette affaire soulève des questions sur la propriété intellectuelle des couleurs et des matériaux, et sur l'accès des artistes à des innovations technologiques.

### 4.2. Stabilité et Durabilité des Couleurs

Au-delà de la toxicité, la stabilité et la durabilité des couleurs sont des facteurs importants pour leur adoption ou leur retrait des standards. Certains pigments anciens étaient connus pour leur instabilité à la lumière ou à l'humidité, entraînant une altération des œuvres d'art au fil du temps. Les standards modernes privilégient les pigments et colorants offrant une excellente résistance au vieillissement et aux facteurs environnementaux.

## 5. Implications Directes pour l’Architecture de Données

Pour une interface gérant 16 777 216 couleurs RGB, l'architecture de données doit être robuste et flexible. Elle doit pouvoir : 

*   **Gérer des métadonnées riches** : Chaque couleur pourrait être associée à des informations telles que son nom (historique, standardisé, ou généré), sa composition chimique (si applicable), sa toxicité potentielle, sa stabilité, son origine géographique ou culturelle, et les dates de son introduction ou de son retrait des standards. 
*   **Intégrer des systèmes de classification multiples** : L'interface devrait pouvoir mapper les couleurs RGB à différents systèmes de classification (Pantone, RAL, NCS, etc.) et gérer les cas où une couleur n'a pas d'équivalent direct ou est absente d'un standard donné. 
*   **Tracer l'historique des couleurs** : Un système de versioning ou d'historique pourrait documenter les changements de nomenclature, les retraits et les controverses associées à certaines couleurs. 
*   **Gérer les alertes de sécurité** : Pour les couleurs historiquement toxiques ou celles dont la composition est incertaine, l'architecture devrait permettre d'afficher des avertissements ou des informations contextuelles pertinentes.

## 6. Implications Directes pour une Interface Innovante

Une interface innovante pour l'exploration des couleurs devrait aller au-delà de la simple visualisation des teintes. Elle pourrait :

*   **Visualiser l'historique et les controverses** : Permettre aux utilisateurs de voir l'évolution des noms de couleurs, les raisons de leur retrait (toxicité, éthique) et les débats associés (comme le Vantablack). 
*   **Afficher des informations contextuelles** : Au survol ou au clic sur une couleur, afficher des fiches détaillées incluant son histoire, sa composition, sa signification culturelle, et des avertissements de sécurité si nécessaire. 
*   **Proposer des alternatives sûres** : Pour les couleurs historiquement toxiques, l'interface pourrait suggérer des équivalents modernes et sûrs, avec des comparaisons visuelles. 
*   **Explorer les 
couleurs non standardisées** : Offrir des outils pour explorer les vastes espaces de couleurs RGB qui ne sont pas couverts par les standards existants, permettant aux utilisateurs de nommer, classer et documenter leurs propres découvertes.
*   **Intégrer des filtres éthiques et de durabilité** : Permettre aux utilisateurs de filtrer les couleurs en fonction de critères éthiques (par exemple, sans pigments d'origine animale) ou de durabilité (par exemple, pigments résistants à la décoloration).

## 7. Recommandations Concrètes

1.  **Développer une base de données sémantique des couleurs** : Créer une base de données qui ne se contente pas de stocker les valeurs RGB, mais qui intègre également des métadonnées riches et structurées sur l'histoire, la composition, la toxicité, les standards associés et les controverses de chaque couleur. Cette base de données devrait être extensible pour permettre l'ajout de nouvelles informations et de nouvelles couleurs non standardisées.
2.  **Implémenter un système de visualisation dynamique** : Concevoir une interface utilisateur qui permet une exploration intuitive de l'espace colorimétrique RGB, avec des superpositions d'informations contextuelles (historique, toxicité, standards) et des outils de filtrage avancés. L'interface devrait clairement distinguer les couleurs standardisées des couleurs non standardisées, et offrir des options pour la création et la documentation de nouvelles couleurs.
3.  **Intégrer des avertissements et des alternatives** : Pour toute couleur historiquement associée à des problèmes de toxicité ou d'éthique, l'interface doit afficher des avertissements clairs et proposer des alternatives modernes et sûres. Cela inclut la visualisation des équivalents chromatiques dans les palettes contemporaines.

## 8. Bibliographie

[1] Walensky-Shop. *Pigments Toxiques des Maîtres Anciens : Histoire & Dangers*. Disponible sur : [https://walensky-shop.fr/blogs/artistes-celebres-4/quels-pigments-utilises-par-les-maitres-anciens-sont-aujourdhui-toxiques](https://walensky-shop.fr/blogs/artistes-celebres-4/quels-pigments-utilises-par-les-maitres-anciens-sont-aujourdhui-toxiques)

[2] Art in Society. *The life and death of Mummy Brown*. Disponible sur : [https://www.artinsociety.com/the-life-and-death-of-mummy-brownl.html](https://www.artinsociety.com/the-life-and-death-of-mummy-brownl.html)

[3] Wikipedia. *Vantablack*. Disponible sur : [https://en.wikipedia.org/wiki/Vantablack](https://en.wikipedia.org/wiki/Vantablack)
