# Rapport sur les Espaces Perceptuels et Distances Colorimétriques

## 1. Introduction

Ce rapport explore les espaces colorimétriques perceptuels et les métriques de distance colorimétrique, essentiels pour la conception d'une interface innovante capable de naviguer et d'explorer efficacement les 16 777 216 couleurs RGB. L'objectif est de fournir une compréhension approfondie des concepts clés, de l'état de l'art, des limites, et des implications pratiques pour l'architecture de données et l'interface utilisateur, en mettant l'accent sur la similarité perceptuelle.

## 2. Définitions

### 2.1. Espace Colorimétrique

Un **espace colorimétrique** est un modèle mathématique qui permet de représenter les couleurs par des valeurs numériques, assurant une reproduction cohérente des couleurs à travers différents dispositifs (écrans, imprimantes, etc.) [^1]. Il s'agit d'une construction mathématique où les couleurs sont des ensembles ordonnés de nombres, généralement des triplets, qui correspondent à des coordonnées spécifiques dans un système défini. Ces espaces sont fondamentaux pour la quantification, la reproduction et la communication objectives de la couleur [^1]. La vision humaine des couleurs repose sur trois types de photorécepteurs à cônes (L, M, S) dans la rétine, sensibles aux grandes, moyennes et courtes longueurs d'onde (rouge, vert, bleu respectivement). Le cerveau interprète la combinaison de ces réponses pour générer la sensation de couleur [^1].

### 2.2. CIE XYZ

L'**espace colorimétrique CIE 1931 XYZ** est un espace standard, indépendant du dispositif, défini par la Commission Internationale de l'Éclairage (CIE). Ses trois axes (X, Y, Z) sont des primaires « imaginaires » construites mathématiquement pour que toutes les couleurs visibles aient des coordonnées non négatives [^1]. La valeur Y correspond à la luminosité perçue. Cet espace est la base de tous les autres espaces indépendants du dispositif et sert de référence dans les normes internationales [^1]. Cependant, il n'est pas perceptuellement uniforme, ce qui signifie que des distances égales dans l'espace XYZ ne correspondent pas nécessairement à des différences de couleur perçues comme équivalentes par l'œil humain [^1].

### 2.3. CIELAB (L*a*b*)

L'**espace colorimétrique CIELAB**, également appelé L*a*b*, a été défini par la CIE en 1976. Il exprime la couleur en trois valeurs : L* pour la luminosité perceptuelle, et a* et b* pour les quatre couleurs uniques de la vision humaine (rouge, vert, bleu et jaune) [^2]. L'axe a* représente l'opposition vert-rouge (valeurs négatives vers le vert, positives vers le rouge), et l'axe b* représente l'opposition bleu-jaune (valeurs négatives vers le bleu, positives vers le jaune) [^2]. CIELAB a été conçu pour être un espace perceptuellement uniforme, où un changement numérique donné correspond à un changement perçu similaire de la couleur. Bien que l'espace LAB ne soit pas parfaitement uniforme perceptuellement, il est néanmoins utile dans l'industrie pour détecter de petites différences de couleur [^2]. Il est calculé par rapport à un illuminant de référence, généralement D65 [^2].

### 2.4. CIELCh (L*C*h)

L'**espace CIELCh** (ou L*C*h) est une transformation cylindrique de l'espace CIELAB. Il utilise les coordonnées polaires C* (chroma, ou intensité de la couleur) et h° (angle de teinte, angle de la teinte dans la roue chromatique CIELAB) au lieu des coordonnées cartésiennes a* et b*. La luminosité L* de CIELAB reste inchangée [^2, ^3]. L'axe C* représente la distance par rapport à l'axe de luminosité (L*), commençant à 0 au centre (couleurs achromatiques). L'angle de teinte h° est exprimé en degrés, avec 0° correspondant à l'axe +a* (rouge) et 90° à l'axe +b* (jaune) [^3]. Cet espace est souvent préféré par certains professionnels car son système est bien corrélé avec la façon dont l'œil humain perçoit la couleur [^3].

### 2.5. OKLab et OKLCh

**OKLab** est un espace colorimétrique plus récent, conçu pour être encore plus perceptuellement uniforme que CIELAB, en particulier pour les opérations de mélange et de manipulation des couleurs. Il vise à corriger certaines des non-uniformités de CIELAB, notamment dans la région des bleus [^4]. **OKLCh** est la version cylindrique d'OKLab, similaire à la relation entre CIELAB et CIELCh, offrant une représentation en termes de luminosité, chroma et teinte qui est plus intuitive et mieux alignée avec la perception humaine que les espaces précédents [^4]. Ces espaces sont particulièrement pertinents pour les applications où la prévisibilité des mélanges de couleurs et la perception de la similarité sont cruciales.

### 2.6. Delta E (ΔE)

Le **Delta E (ΔE)** est une métrique qui quantifie la différence ou la distance entre deux couleurs. Il est utilisé pour analyser numériquement à quel point deux couleurs sont éloignées l'une de l'autre [^4]. Plusieurs formules de Delta E existent, chacune cherchant à mieux corréler la distance numérique avec la différence de couleur perçue par l'œil humain. Les versions les plus courantes incluent :

*   **ΔE76 (ou ΔE*ab*)**: La formule la plus simple, basée sur la distance euclidienne dans l'espace CIELAB. Elle est rapide mais moins précise car CIELAB n'est pas parfaitement uniforme [^4].
*   **ΔE94**: Introduit des pondérations pour la luminosité, la chroma et la teinte afin de mieux refléter la perception humaine, mais reste imparfait [^4].
*   **ΔE2000**: L'algorithme le plus sophistiqué et le plus précis pour les différences de couleur en SDR (Standard Dynamic Range). Il incorpore des corrections pour les régions problématiques de CIELAB, notamment les bleus, et est considéré comme l'état de l'art pour la mesure des différences de couleur [^2, ^3, ^4].
*   **ΔEok**: Basé sur l'espace OKLab, il utilise une distance euclidienne dans cet espace, qui est conçu pour être plus perceptuellement uniforme [^4].

Le Delta E est crucial pour le contrôle qualité, l'appariement des couleurs et la détermination de la tolérance de couleur, c'est-à-dire la limite acceptable de différence entre un échantillon et un standard [^3].

## 3. État de l'art et données techniques

L'état de l'art en matière d'espaces colorimétriques perceptuels est marqué par une évolution constante visant à mieux modéliser la vision humaine. Le **CIE XYZ**, établi en 1931, reste la pierre angulaire de la colorimétrie, servant de référence universelle et de base pour la conversion entre différents espaces [^1]. Cependant, sa non-uniformité perceptuelle le rend inadapté pour des comparaisons directes de similarité visuelle [^1].

Le **CIELAB (L*a*b*)**, introduit en 1976, a représenté une avancée majeure en tentant de créer un espace où des distances numériques égales correspondent à des différences de couleur perçues comme équivalentes [^2]. Sa structure à trois axes (L* pour la luminosité, a* pour l'axe vert-rouge, b* pour l'axe bleu-jaune) est basée sur le modèle des couleurs opposées de la vision humaine [^2]. Le **CIELCh (L*C*h)**, une transformation cylindrique de CIELAB, offre une représentation plus intuitive en termes de luminosité (L*), chroma (C*) et teinte (h°), ce qui facilite la compréhension des attributs de couleur par les professionnels [^3].

Les métriques de différence de couleur, ou **Delta E (ΔE)**, ont également évolué pour compenser les imperfections des espaces colorimétriques. Le **ΔE76** (distance euclidienne simple dans CIELAB) a été supplanté par des formules plus complexes comme le **ΔE94** et surtout le **ΔE2000**. Le ΔE2000 est actuellement la formule la plus précise pour évaluer les différences de couleur en SDR, intégrant des corrections pour les non-uniformités de CIELAB, notamment dans la région des bleus [^2, ^3, ^4]. Il prend en compte des facteurs de pondération pour la luminosité, la chroma et la teinte, ainsi qu'un terme de rotation de la teinte pour gérer la région problématique des bleus [^4].

Plus récemment, des espaces comme **OKLab** et **OKLCh** ont émergé, développés par Björn Ottosson, avec l'objectif d'offrir une uniformité perceptuelle encore supérieure à celle de CIELAB, en particulier pour les opérations de mélange et de manipulation des couleurs dans les applications numériques [^4, ^5]. Ces nouveaux espaces sont conçus pour corriger les lacunes de CIELAB, notamment la non-linéarité de la teinte dans la région bleue, qui peut entraîner des changements de teinte indésirables lors de la réduction de la chroma [^5].

## 4. Limites et controverses

Malgré les avancées, les espaces colorimétriques perceptuels et les métriques de Delta E présentent des limites et font l'objet de controverses. La principale limitation du **CIELAB** est qu'il n'est **pas parfaitement uniforme perceptuellement** [^2, ^5]. Des études ont montré que des formes de Delta E 2000 constantes dans CIELAB ne sont pas des cercles de taille identique et uniformément espacés, ce qui indique une surestimation des couleurs à chroma élevée et des formes elliptiques et rotatives dans la région bleu-violet (autour de 270 à 330 degrés) [^5]. Cette non-uniformité de la teinte et de la linéarité de la teinte dans la région bleue est particulièrement problématique, car elle peut entraîner des changements de teinte visibles (par exemple, le bleu virant au violet) lors de la réduction de la chroma, ce qui est très indésirable pour le mappage de gamut [^5].

Les formules de Delta E, bien que de plus en plus sophistiquées (comme le ΔE2000), sont des tentatives de compenser les non-uniformités de l'espace sous-jacent. Elles peuvent devenir très complexes mathématiquement, rendant leur implémentation et leur compréhension difficiles [^5]. De plus, certaines de ces formules ne sont pas symétriques, ce qui signifie que la distance entre la couleur A et la couleur B n'est pas toujours la même que la distance entre la couleur B et la couleur A [^4].

Les modèles d'apparence des couleurs (CAM), tels que CAM16-UCS, visent à améliorer la prédiction de la perception des couleurs en tenant compte des conditions d'observation (luminosité ambiante, point blanc, etc.). Cependant, leur complexité de calcul et leur instabilité numérique, ainsi que le manque d'accès aux détails des conditions d'observation dans de nombreux contextes (comme le web), limitent leur applicabilité pratique [^5].

L'émergence d'espaces comme **OKLab** et **OKLCh** est une réponse directe à ces limitations. Ils sont conçus pour être plus robustes et perceptuellement uniformes, offrant une meilleure base pour les calculs de similarité et les manipulations de couleurs. Cependant, étant plus récents, leur adoption universelle et l'existence d'outils et de bibliothèques complètes peuvent encore être en développement par rapport aux standards établis de longue date comme CIELAB.

Il est important de noter que l'existence de « couleurs secrètes » n'est pas prouvée. Les discussions portent plutôt sur les limites des gamuts des dispositifs, les couleurs non représentables dans certains espaces, ou les nuances subtiles qui peuvent être perdues lors des conversions entre espaces colorimétriques. Les « lacunes de corpus » ou les « retraits de standards » se réfèrent aux couleurs qui ne peuvent pas être affichées par un dispositif donné ou qui sont hors du gamut d'un espace colorimétrique spécifique, plutôt qu'à des couleurs intrinsèquement « secrètes » [^5].
## 5. Implications directes pour l'architecture de données

Pour une interface capable d'adresser et d'explorer les 16 777 216 couleurs RGB, l'architecture de données doit être conçue pour gérer efficacement la complexité des espaces colorimétriques perceptuels. Il est crucial de stocker les couleurs dans un format qui préserve leur uniformité perceptuelle et facilite les calculs de similarité. L'utilisation d'un espace comme **OKLab** ou **OKLCh** pour le stockage interne des données de couleur est fortement recommandée, car ils offrent une meilleure uniformité perceptuelle que CIELAB, réduisant ainsi les erreurs dans les calculs de distance et de regroupement des couleurs [^5].

Les données de couleur devraient être représentées en virgule flottante (floating-point) plutôt qu'en entiers 8 bits par canal pour éviter les erreurs de quantification et la perte de précision, étant donné la grande étendue du gamut des couleurs humaines et la non-linéarité des espaces perceptuels [^2]. Une conversion bidirectionnelle robuste entre l'espace RGB (pour l'affichage) et l'espace perceptuel choisi (pour la logique métier) doit être implémentée, en tenant compte des illuminants de référence et des profils ICC pour assurer la cohérence des couleurs à travers les différents dispositifs.

L'indexation des couleurs pour la recherche par similarité perceptuelle nécessitera des structures de données optimisées, telles que des arbres kd-tree ou des bases de données vectorielles, pour permettre des requêtes rapides sur des millions de points de couleur. Chaque couleur pourrait être associée à ses coordonnées dans l'espace OKLab/OKLCh, facilitant ainsi la recherche des "voisins" perceptuels.

## 6. Implications directes pour une interface innovante

Une interface innovante pour l'exploration des couleurs RGB devrait tirer parti des propriétés des espaces colorimétriques perceptuels pour offrir une expérience utilisateur intuitive et efficace. La navigation par similarité perceptuelle serait au cœur de cette interface. Au lieu de manipuler des valeurs RGB brutes, les utilisateurs interagiraient avec les dimensions de luminosité, chroma et teinte (LCh ou OKLCh), qui correspondent plus directement à la façon dont les humains perçoivent la couleur [^3].

L'interface pourrait visualiser l'espace colorimétrique en 3D, permettant aux utilisateurs de "voler" à travers le gamut des couleurs et de sélectionner des points d'intérêt. Des outils de sélection basés sur le Delta E permettraient de définir des tolérances de couleur pour des recherches précises, par exemple, trouver toutes les couleurs "similaires" à une couleur donnée avec un ΔEok inférieur à un certain seuil. Cela permettrait de regrouper les couleurs de manière perceptuellement significative, évitant les regroupements arbitraires basés sur des distances euclidiennes dans des espaces non uniformes.

Des fonctionnalités telles que le "mappage de gamut intelligent" pourraient aider les utilisateurs à comprendre comment les couleurs hors gamut d'un dispositif cible seraient rendues, en utilisant des algorithmes qui minimisent les changements perceptuels indésirables (par exemple, en réduisant la chroma tout en maintenant la teinte et la luminosité) [^5]. L'interface pourrait également offrir des outils pour explorer les "chemins de couleur" perceptuellement uniformes, facilitant la création de dégradés harmonieux ou de palettes de couleurs cohérentes.

## 7. Recommandations concrètes

1.  **Adopter OKLab/OKLCh comme espace de travail interne principal :** Pour la manipulation et la comparaison des couleurs, privilégier OKLab ou OKLCh en raison de leur uniformité perceptuelle supérieure par rapport à CIELAB. Cela garantira que les calculs de similarité et les opérations de mélange de couleurs reflètent fidèlement la perception humaine.
2.  **Utiliser des représentations en virgule flottante :** Stocker toutes les données de couleur en virgule flottante pour maintenir la précision et éviter les erreurs de quantification, en particulier lors de la conversion entre les espaces et la manipulation des 16 millions de couleurs RGB.
3.  **Implémenter le Delta Eok pour la mesure de similarité :** Utiliser le Delta Eok comme métrique de distance par défaut pour la navigation par similarité perceptuelle. Cela permettra de quantifier les différences de couleur de manière plus fiable et de définir des seuils de tolérance pertinents pour l'utilisateur.
4.  **Concevoir une interface centrée sur les attributs perceptuels :** Permettre aux utilisateurs d'interagir directement avec la luminosité, la chroma et la teinte (L, C, h) plutôt qu'avec les composants RGB. Des visualisations 3D de l'espace colorimétrique peuvent enrichir l'expérience d'exploration.
5.  **Intégrer des outils de mappage de gamut :** Fournir des fonctionnalités pour visualiser et gérer les couleurs hors gamut, avec des options de rendu qui privilégient la préservation de la teinte et de la luminosité lors de la réduction de la chroma.
6.  **Optimiser l'indexation des couleurs :** Mettre en place des structures de données avancées (ex: kd-trees) pour permettre une recherche rapide et efficace des couleurs similaires dans l'ensemble des 16 millions de couleurs.

## 8. Bibliographie

[^1]: Tarmacview. (s.d.). *Espace colorimétrique*. Consulté le 16 juillet 2026, de https://www.tarmacview.com/fr/glossary/color-space/
[^2]: Wikipedia. (s.d.). *CIELAB color space*. Consulté le 16 juillet 2026, de https://en.wikipedia.org/wiki/CIELAB_color_space
[^3]: Konica Minolta Sensing. (s.d.). *Understanding the CIE L*C*h Color Space*. Consulté le 16 juillet 2026, de https://sensing.konicaminolta.us/us/blog/understanding-the-cie-lch-color-space/
[^4]: Facelessuser. (s.d.). *Color Distance and Delta E - ColorAide Documentation*. Consulté le 16 juillet 2026, de https://facelessuser.github.io/coloraide/distance/
[^5]: Lilley, C. (s.d.). *Better than Lab? Gamut reduction CIE Lab & OKLab*. W3C. Consulté le 16 juillet 2026, de https://www.w3.org/Graphics/Color/Workshop/slides/talk/lilley
