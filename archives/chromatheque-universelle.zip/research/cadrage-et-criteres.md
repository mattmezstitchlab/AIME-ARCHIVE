# Cadrage scientifique et critères d’innovation

## Objet

Le projet vise à rendre **adressables, explorables et documentables** les 16 777 216 triplets de l’espace RGB 24 bits, soit toutes les combinaisons où R, V et B prennent chacune une valeur entière de 0 à 255. Il ne suppose pas que chaque triplet possède un nom usuel, une signification historique ou une apparence universellement stable. La base exhaustive est donc **algorithmique** pour les valeurs numériques et **documentaire** pour les noms, histoires, pigments, retraits et sources.

## Hypothèses scientifiques

L’espace de référence du Web sera sRGB 8 bits par canal. Une couleur numérique sera identifiée canoniquement par un entier non signé de 24 bits et par son code hexadécimal à six chiffres. Les données RVB et Hex sont exactes dans ce référentiel. Les coordonnées perceptuelles, contrastes et distances sont calculées. La conversion CMJN sera explicitement qualifiée : une conversion naïve pourra être proposée comme approximation pédagogique, tandis qu’une conversion de production dépendra d’un profil ICC, d’un support, d’une encre, d’un procédé et d’une intention de rendu.

Le terme « couleur manquante » désignera une **lacune documentaire**, un nom rare ou oublié, une entrée retirée ou renommée, un pigment abandonné, une couleur absente d’un corpus particulier ou une zone sous-documentée de l’espace numérique. Il ne désignera jamais une couleur physique secrète dont l’existence ne serait pas étayée.

## Critères pondérés

| Critère | Poids | Définition opérationnelle |
|---|---:|---|
| Exhaustivité adressable | 20 % | Toute valeur de `#000000` à `#FFFFFF` doit être atteignable et identifiable sans pré-générer 16,7 millions de fiches. |
| Orientation et réversibilité | 15 % | L’utilisateur doit toujours comprendre sa position et pouvoir revenir à un état antérieur. |
| Fluidité et sobriété technique | 15 % | L’interaction courante doit rester fluide sur un navigateur moderne, avec dégradation progressive. |
| Fidélité perceptuelle | 12 % | Les proximités proposées doivent mieux refléter la perception que la seule distance euclidienne RGB. |
| Découverte et sérendipité | 10 % | Le dispositif doit favoriser les trouvailles sans perdre l’accès déterministe à une valeur exacte. |
| Lisibilité documentaire | 8 % | Les noms, alias, sources, dates et niveaux de confiance doivent rester compréhensibles. |
| Accessibilité | 8 % | Clavier, lecteur d’écran, contraste et modes de déficience chromatique doivent être intégrés. |
| Extensibilité | 7 % | Le modèle doit accepter langues, profils, espaces colorimétriques et corpus futurs. |
| Export et reproductibilité | 5 % | Toute sélection doit pouvoir être copiée ou exportée avec son référentiel et sa provenance. |

## Principes de décision

Une interface gagnante ne cherchera pas à afficher simultanément 16 777 216 objets DOM. Elle combinera une **adresse exacte**, une **représentation multi-échelle**, des **coupes perceptuelles**, un **rendu calculé à la demande** et une **couche documentaire distincte**. Le rapport comparera les concepts sur la grille ci-dessus et retiendra un système hybride plutôt qu’un gadget visuel isolé si cette combinaison obtient le meilleur score.
