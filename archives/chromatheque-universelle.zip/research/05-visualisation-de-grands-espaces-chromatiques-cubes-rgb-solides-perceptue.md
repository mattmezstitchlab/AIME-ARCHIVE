# Rapport sur la Visualisation des Grands Espaces Chromatiques

## Introduction

La perception et la reproduction des couleurs sont des aspects fondamentaux de l'expérience visuelle humaine et des technologies d'affichage. Avec l'avènement des écrans haute résolution et des capacités de traitement graphique avancées, la gestion et la visualisation de vastes gammes de couleurs, telles que les 16 777 216 couleurs du modèle RGB 24 bits, deviennent un défi technique et conceptuel. Ce rapport explore les méthodes et les implications de la visualisation de ces grands espaces chromatiques, en se penchant sur des concepts tels que les cubes RGB, les solides perceptuels, les coupes, les projections, les cartes, les treemaps, les octrees, les courbes de remplissage de l'espace et les niveaux de détail.

## Définitions

### Espace Chromatique

Un **espace chromatique** est une gamme définie de couleurs, une carte tridimensionnelle qui attribue des valeurs numériques précises à chaque couleur. Il sert de dictionnaire pour interpréter les données de couleur entre différents appareils [1].

*   **RGB (Red, Green, Blue)**: Un modèle de couleur additif où les couleurs sont créées en combinant différentes intensités de lumière rouge, verte et bleue. Le RGB 24 bits permet 256 niveaux pour chaque canal (0-255), résultant en 256^3 = 16 777 216 couleurs distinctes.
*   **sRGB**: La norme la plus ancienne et la plus universelle, couvrant environ 35% des couleurs visibles. Conçu pour les moniteurs et le web, c'est le choix par défaut pour la plupart des appareils grand public [2].
*   **Adobe RGB (1998)**: Couvre environ 50% des couleurs visibles, avec une gamme plus large dans les cyans et les verts, conçu pour l'impression professionnelle [2].
*   **ProPhoto RGB**: Un espace chromatique très large, utilisé en interne par des logiciels comme Lightroom. Il contient des couleurs que l'œil humain ne peut pas voir, ce qui le rend utile pour l'édition interne afin d'éviter les pertes de données [2] [3].
*   **Display P3**: Un espace chromatique moderne, développé pour le cinéma numérique et adopté par Apple, couvrant environ 25% de couleurs supplémentaires par rapport au sRGB [2].
*   **Rec. 709**: L'équivalent vidéo du sRGB, standard pour la vidéo HD [2].
*   **Rec. 2020**: La norme à large gamut pour la vidéo 4K UHD et HDR [2].
*   **CIE XYZ (1931)**: Un espace indépendant du périphérique qui vise à décrire toutes les couleurs visibles par l'œil humain moyen. Il sert de référence standard pour de nombreux autres espaces colorimétriques [4] [5].
*   **CIELAB (L*a*b*)**: Un espace chromatique perceptuellement uniforme (ou du moins, conçu pour l'être), où L* représente la luminosité, a* l'axe vert-rouge, et b* l'axe bleu-jaune. Il est indépendant du périphérique et couvre toute la gamme de la perception humaine des couleurs [4] [5].
*   **CIELUV**: Similaire au CIELAB, une transformation du CIE XYZ visant une uniformité perceptuelle [5].
*   **HSL (Hue, Saturation, Lightness) et HSV (Hue, Saturation, Value)**: Représentations alternatives du modèle RGB, conçues pour s'aligner davantage sur la perception humaine. Cependant, ils ne séparent pas toujours efficacement les composants de couleur selon la perception humaine [5].
*   **HWB (Hue, Whiteness, Blackness)**: Une représentation cylindrique du modèle RGB, similaire à HSL et HSV, mais conçue pour être plus intuitive [5].
*   **HCL (Hue-Chroma-Luminance) ou Lch**: Modèles d'espace chromatique cylindriques conçus pour s'accorder avec la perception humaine de la couleur, souvent utilisés en visualisation d'informations [5].
*   **HSLuv**: Une tentative plus récente de rendre les espaces perceptuellement uniformes plus intuitifs, en utilisant le CIELUV avec les dimensions du modèle HSL [5].

### Gamut

Le **gamut** est la plage de couleurs spécifique et délimitée qu'un espace chromatique peut représenter ou qu'un appareil peut reproduire [2].

### Solides Perceptuels

Un **solide de couleur** est une représentation tridimensionnelle d'un espace ou modèle de couleur, permettant de visualiser la luminosité, la teinte et la chromaticité. Des exemples historiques incluent les sphères de couleur de Philipp Otto Runge et Johannes Itten, ainsi que le système de couleurs de Munsell [4] [5]. Les solides de couleur optimaux représentent la limite théorique des couleurs que les surfaces peuvent avoir [4].

### Cubes RGB

Le **cube RGB** est une visualisation intuitive de l'espace couleur RGB, où chaque axe représente l'intensité d'une des couleurs primaires (rouge, vert, bleu). Il est souvent utilisé pour illustrer la structure de l'espace RGB [6].

### Coupes et Projections

Pour visualiser plusieurs espaces chromatiques simultanément ou pour analyser des aspects spécifiques, des **coupes bidimensionnelles** sont souvent utilisées. Ces coupes peuvent montrer la gamme de couleurs à une luminance donnée (par exemple, 50% de luminance) [7]. Les **projections** sont des représentations 2D d'un espace 3D, comme le diagramme de chromaticité CIE xy [4].

### Cartes (Color Mapping)

Le **color mapping** (ou cartographie des couleurs) est l'application de couleurs à des données pour les visualiser. Il est crucial pour transformer des données complexes en récits clairs et intuitifs [8] [9].

### Treemaps

Les **treemaps** sont des visualisations de données hiérarchiques composées de rectangles imbriqués dont la taille est proportionnelle à la valeur de données correspondante. La couleur peut être utilisée pour représenter des dimensions ou des mesures [10] [11].

### Octrees

Un **octree** est une structure de données arborescente où chaque nœud interne a exactement huit enfants. Les octrees sont souvent utilisés pour partitionner un espace tridimensionnel, notamment pour la quantification des couleurs en réduisant le nombre de couleurs dans une image [12] [13] [14].

### Courbes de Remplissage de l'Espace

Les **courbes de remplissage de l'espace**, comme la courbe de Hilbert, sont des fractales continues qui permettent une cartographie entre un espace 1D et un espace 2D (ou 3D) en préservant la localité. Elles sont utilisées en informatique pour l'indexation spatiale et la compression de données [15].

### Niveaux de Détail (LOD)

Le **niveau de détail (LOD)** est une technique utilisée en infographie 3D pour réduire la complexité d'un modèle 3D à distance, améliorant ainsi les performances de rendu. Bien que principalement appliqué à la géométrie, le concept peut être étendu à la visualisation des couleurs pour gérer la complexité des grands espaces chromatiques [12].

## État de l'art et Données techniques

La gestion des couleurs est un domaine complexe où différents espaces chromatiques sont utilisés en fonction de l'application. Les espaces comme sRGB, Adobe RGB et ProPhoto RGB sont couramment employés en photographie et en impression, chacun offrant un gamut différent [2]. ProPhoto RGB, avec son gamut très large, est souvent préféré pour l'édition interne afin de préserver un maximum d'informations colorimétriques avant l'exportation vers un espace de destination plus restreint [2] [3].

La visualisation de ces espaces se fait souvent via des **cubes RGB** ou des **solides de couleur** qui représentent les limites du gamut. Les solides de couleur perceptuellement uniformes, comme ceux basés sur CIELAB, sont particulièrement utiles car ils tentent de représenter les différences de couleur de manière cohérente avec la perception humaine [4] [5]. Cependant, même CIELAB n'est pas parfaitement uniforme, notamment dans les teintes bleues [5]. Des espaces comme HSLuv ont été développés pour améliorer cette uniformité perceptuelle et offrir une interface plus intuitive pour les designers [5].

Les **coupes 2D** et les **projections** sont des outils essentiels pour comparer les gamuts de différents espaces colorimétriques. Par exemple, une coupe à 50% de luminance permet de visualiser les couleurs reproductibles par plusieurs espaces et d'identifier les zones où un espace est plus étendu qu'un autre [7].

Pour la gestion de la complexité des grands espaces chromatiques, des structures de données comme les **octrees** sont utilisées. Elles permettent une **quantification des couleurs** efficace, réduisant le nombre de couleurs distinctes dans une image tout en minimisant la perte visuelle. L'algorithme de quantification par octree divise récursivement l'espace couleur en huit octants, regroupant les couleurs similaires [12] [13] [14].

Les **courbes de remplissage de l'espace**, telles que la courbe de Hilbert, offrent une méthode pour linéariser un espace multidimensionnel tout en conservant la proximité des points. Cela peut être appliqué à l'indexation des couleurs, permettant de stocker et de récupérer efficacement des données de couleur dans de grandes bases de données [15].

Les **treemaps** peuvent être utilisées pour visualiser des hiérarchies de couleurs, par exemple, pour organiser une palette de couleurs en fonction de catégories ou de mesures. Cependant, leur efficacité pour des comparaisons précises de couleurs peut être limitée en raison de la perception humaine de l'aire et de la couleur [10] [11].

## Limites et Controverses

La gestion des couleurs est semée d'embûches, principalement dues aux **incompatibilités entre les espaces chromatiques et les appareils** [2]. Une image éditée dans un espace large gamut (comme Adobe RGB) peut apparaître terne ou désaturée sur un écran sRGB si la conversion n'est pas gérée correctement. De même, les moniteurs à large gamut peuvent afficher des couleurs sursaturées si le logiciel ne gère pas correctement les profils colorimétriques [2].

Le problème du **banding** (apparition de bandes de couleur abruptes) est une limitation technique qui survient lors de l'édition d'images en 8 bits, surtout avec de grands espaces chromatiques. Travailler en 16 bits est recommandé pour éviter ce problème, bien que cela augmente la taille des fichiers et que de nombreux filtres ou formats ne soient pas compatibles avec le 16 bits [1].

Les espaces colorimétriques comme HSL et HSV, bien qu'intuitifs, ne sont pas **perceptuellement uniformes**, ce qui signifie qu'une même variation numérique ne correspond pas toujours à une variation perçue égale. Cela peut entraîner des gradients de couleur visuellement inégaux ou des choix de couleurs aléatoires qui ne sont pas uniformément lumineux [5].

Concernant les **treemaps**, bien qu'utiles pour visualiser des hiérarchies, elles sont moins efficaces pour des comparaisons précises de valeurs en raison de la difficulté pour l'œil humain de juger l'aire avec exactitude. L'utilisation de trop de couleurs ou de couleurs similaires peut également rendre les treemaps confuses [11].

Quant aux 
couleurs « secrètes » ou oubliées, il n'y a pas de preuve scientifique de leur existence. Le rapport se concentrera sur les couleurs attestées et les lacunes des corpus existants.

## Implications directes pour l’architecture de données

La gestion des 16 777 216 couleurs RGB d'un espace 24 bits a des implications significatives pour l'architecture de données. Chaque couleur est représentée par trois octets (un pour le rouge, un pour le vert, un pour le bleu), ce qui, pour une image, peut rapidement générer des volumes de données importants. L'utilisation d'espaces colorimétriques à large gamut comme ProPhoto RGB pour l'édition interne signifie que les données doivent être stockées avec une profondeur de bits suffisante (par exemple, 16 bits par canal) pour éviter le banding et la perte d'informations lors des manipulations. Cela implique des fichiers plus volumineux et des exigences de stockage et de traitement accrues [1].

Les **octrees** sont une solution efficace pour la quantification et la compression des données de couleur. En réduisant le nombre de couleurs uniques à un sous-ensemble gérable (par exemple, 256 couleurs pour une palette), les octrees permettent de diminuer la taille des fichiers tout en conservant une bonne fidélité visuelle. L'architecture de données doit donc prévoir des mécanismes pour la création, le stockage et l'application de ces palettes de couleurs optimisées [12] [13] [14].

Les **courbes de remplissage de l'espace**, comme la courbe de Hilbert, peuvent être utilisées pour l'indexation spatiale des couleurs. En transformant les coordonnées 3D de l'espace couleur en une seule dimension, elles permettent une recherche et une récupération plus efficaces des couleurs similaires, ce qui est crucial pour les bases de données de couleurs ou les systèmes de gestion de contenu [15].

La nécessité de gérer différents espaces colorimétriques (sRGB, Adobe RGB, Display P3, etc.) implique une architecture de données flexible capable de stocker les profils ICC associés aux images et de réaliser des conversions précises entre ces espaces. Les métadonnées des images doivent inclure des informations sur l'espace colorimétrique d'origine pour garantir une reproduction fidèle [2].

## Implications directes pour une interface innovante

Une interface capable d'adresser et d'explorer 16 777 216 couleurs RGB doit surmonter les limitations des interfaces traditionnelles qui se basent souvent sur des sélecteurs de couleurs 2D ou des curseurs linéaires. L'innovation réside dans la capacité à visualiser et interagir avec l'espace couleur de manière intuitive et perceptuellement uniforme.

L'utilisation de **solides de couleur 3D interactifs** est essentielle. Plutôt que de simples cubes RGB, des représentations basées sur des espaces perceptuellement uniformes comme CIELAB ou HSLuv permettraient aux utilisateurs de naviguer dans l'espace couleur en fonction de la teinte, de la saturation et de la luminosité perçues, plutôt que des valeurs RGB brutes. Cela faciliterait la sélection de couleurs harmonieuses ou la modification de couleurs de manière prévisible [5].

Les **coupes et projections dynamiques** de l'espace couleur pourraient offrir des vues ciblées sur des gamuts spécifiques ou des plages de couleurs d'intérêt. Par exemple, une interface pourrait permettre à l'utilisateur de 
sélectionner une zone de l'espace CIELAB et d'en voir la projection 2D, ou de visualiser les gamuts de différents appareils superposés pour comprendre les limitations de reproduction [7].

Les **octrees** pourraient être utilisés en arrière-plan pour permettre une navigation fluide et un affichage adaptatif des couleurs. Par exemple, l'interface pourrait afficher un niveau de détail (LOD) plus élevé pour les zones de l'espace couleur où l'utilisateur interagit, et un LOD plus faible pour les zones moins pertinentes, optimisant ainsi les performances sans sacrifier la précision là où elle est nécessaire [12].

Les **courbes de remplissage de l'espace** pourraient servir à organiser des palettes de couleurs ou à créer des parcours visuels à travers l'espace couleur, offrant une manière non linéaire mais structurée d'explorer la richesse des teintes disponibles. Cela pourrait être particulièrement utile pour la génération de dégradés complexes ou la recherche de couleurs complémentaires [15].

Une interface innovante devrait également intégrer des outils de **color mapping** avancés, permettant aux utilisateurs de définir des règles complexes pour l'application des couleurs, par exemple, pour visualiser des données multidimensionnelles où différentes propriétés sont encodées par la teinte, la saturation et la luminosité [8] [9].

Enfin, l'interface devrait offrir une **gestion robuste des profils colorimétriques**, permettant aux utilisateurs de prévisualiser et de convertir facilement les couleurs entre différents espaces (sRGB, Adobe RGB, Display P3, etc.) pour s'assurer que les couleurs affichées sont fidèles à l'intention créative et compatibles avec les périphériques de sortie [2].

## Recommandations concrètes

1.  **Développer un sélecteur de couleurs 3D basé sur CIELAB/HSLuv**: Créer une interface interactive permettant de naviguer dans l'espace couleur en utilisant des dimensions perceptuellement uniformes (Luminosité, Chroma, Teinte) plutôt que les valeurs RGB brutes. Cela facilitera la sélection de couleurs et la création de palettes harmonieuses. L'interface devrait permettre des 
visualisations sous forme de solides de couleur interactifs, avec des options de coupes et de projections dynamiques pour explorer des sous-ensembles de couleurs.
2.  **Intégrer la quantification des couleurs basée sur les octrees**: Pour les applications nécessitant une réduction du nombre de couleurs (par exemple, pour l'optimisation des performances ou la compatibilité avec des affichages limités), l'interface devrait offrir des outils de quantification des couleurs basés sur les octrees, permettant de contrôler la fidélité visuelle et la taille de la palette résultante.
3.  **Mettre en œuvre des outils de gestion des profils colorimétriques**: L'interface doit permettre l'importation, l'exportation et la conversion entre les profils colorimétriques standards (sRGB, Adobe RGB, Display P3, etc.), avec des prévisualisations en temps réel des effets de ces conversions sur les couleurs affichées.
4.  **Utiliser les courbes de remplissage de l'espace pour l'exploration avancée**: Pour les utilisateurs experts, intégrer des visualisations basées sur les courbes de remplissage de l'espace (comme la courbe de Hilbert) pour explorer de manière non linéaire et intuitive de vastes collections de couleurs, facilitant la découverte de relations chromatiques complexes.

## Bibliographie

[1] Eizo. *Gestion des couleurs : traiter les espaces colorimétriques*. [https://www.eizo.be/fr/gestion-des-couleurs-etalonnage/gestion-des-couleurs-pour-les-photographes/episode-04-traiter-les-espaces-colorimetriques](https://www.eizo.be/fr/gestion-des-couleurs-etalonnage/gestion-des-couleurs-pour-les-photographes/episode-04-traiter-les-espaces-colorimetriques)

[2] The Atelier Breugnot. *[FR] Les Espaces Chromatiques : La Force Invisible Qui Façonne Chaque Image*. [https://www.theatelierbreugnot.com/fr/post/fr-les-espaces-chromatiques-la-force-invisible-qui-fa%C3%A7onne-chaque-image](https://www.theatelierbreugnot.com/fr/post/fr-les-espaces-chromatiques-la-force-invisible-qui-fa%C3%A7onne-chaque-image)

[3] Ubuntu Help. *Définition d’un espace colorimétrique*. [https://help.ubuntu.com/stable/ubuntu-help/color-whatisspace.html.fr](https://help.ubuntu.com/stable/ubuntu-help/color-whatisspace.html.fr)

[4] Wikipedia. *Color solid*. [https://en.wikipedia.org/wiki/Color_solid](https://en.wikipedia.org/wiki/Color_solid)

[5] Chromatone Center. *Perceptual color models*. [https://chromatone.center/theory/color/models/perceptual/](https://chromatone.center/theory/color/models/perceptual/)

[6] Alexander Ellis. *Playing with a 3D representation of RGB color space*. [https://alexanderell.is/posts/rgb-color-space/](https://alexanderell.is/posts/rgb-color-space/)

[7] Cambridge in Colour. *Color Management: Understanding Color Spaces*. [https://www.cambridgeincolour.com/tutorials/color-spaces.htm](https://www.cambridgeincolour.com/tutorials/color-spaces.htm)

[8] Golden Software. *Boost Your Data's Impact with Color Mapping Techniques*. [https://www.goldensoftware.com/boost-data-visualization-with-color-mapping/](https://www.goldensoftware.com/boost-data-visualization-with-color-mapping/)

[9] Kenneth Moreland. *Color Map Advice for Scientific Visualization*. [https://www.kennethmoreland.com/color-advice/](https://www.kennethmoreland.com/color-advice/)

[10] Tableau. *What is a Tree Map?*. [https://www.tableau.com/chart/what-is-treemap](https://www.tableau.com/chart/what-is-treemap)

[11] Nielsen Norman Group. *Treemaps: Data Visualization of Complex Hierarchies*. [https://www.nngroup.com/articles/treemaps/](https://www.nngroup.com/articles/treemaps/)

[12] Wikipedia. *Octree*. [https://en.wikipedia.org/wiki/Octree](https://en.wikipedia.org/wiki/Octree)

[13] Jacob Filipp. *JAN96: Color Quantization using Octrees*. [https://jacobfilipp.com/DrDobbs/articles/DDJ/1996/9601/9601f/9601f.htm](https://jacobfilipp.com/DrDobbs/articles/DDJ/1996/9601/9601f/9601f.htm)

[14] Leptonica. *Color quantization using octrees*. [http://www.leptonica.org/papers/colorquant.pdf](http://www.leptonica.org/papers/colorquant.pdf)

[15] Wikipedia. *Hilbert curve*. [https://en.wikipedia.org/wiki/Hilbert_curve](https://en.wikipedia.org/wiki/Hilbert_curve)
