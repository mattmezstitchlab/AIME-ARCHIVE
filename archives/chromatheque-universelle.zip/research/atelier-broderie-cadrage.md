# Cadrage — Chromathèque Atelier

## Positionnement

La version fusionnée conserve **Chromathèque Universelle** comme produit principal. Le Chromatome demeure le moteur d’exploration des 16 777 216 adresses sRGB. Les fonctions utiles de Chromaverse deviennent un **Laboratoire** et la création textile devient un **Atelier** distinct, relié au même objet couleur.

| Route | Fonction | État cible |
|---|---|---|
| `/` | Atlas, Chromatome, méthode et archives | Conservée et enrichie par la navigation globale |
| `/laboratoire` | Harmonies, comparaison, transparence et exports | Nouveau module inspiré de Chromaverse |
| `/atelier` | Grille de broderie, formats, fils, points et légende | Nouveau module principal de création |

## Principe de l’Atelier

L’Atelier doit ressembler à un **cockpit éditorial de broderie** plutôt qu’à une feuille quadrillée générique. La zone centrale accueille la grille. Un rail gauche contient les formats, la géométrie et les outils. Un rail droit rassemble le fil actif, le point actif, le nuancier DMC et les statistiques du motif. Le motif demeure modifiable au clavier et au pointeur.

La première version prend en charge plusieurs géométries : grille carrée de point de croix, facettes en losange pour les diagonales, et alvéoles optionnelles pour une composition plus fluide. Les formats prédéfinis sont carré, portrait, paysage et bannière, avec largeur et hauteur personnalisables dans des limites compatibles avec un rendu interactif côté navigateur.

## Modèle fonctionnel initial

Un projet contient un format, une largeur, une hauteur, une géométrie et une collection de marques. Chaque marque référence une coordonnée, un point de broderie et une référence de fil. La légende est calculée depuis les références effectivement utilisées. L’historique local conserve les actions nécessaires à l’annulation et au rétablissement.

Les données DMC sont une couche documentaire séparée. Chaque entrée doit indiquer son code, son nom, sa famille, une représentation sRGB indicative, sa source et un statut de vérification. Les valeurs écran ne sont jamais présentées comme une mesure spectrale du fil réel. Les points internationaux utilisent également une provenance et une taxonomie ; l’expression « universels du monde entier » est traitée comme un objectif de corpus extensible, non comme une promesse d’exhaustivité absolue invérifiable.

## Contraintes techniques

La version actuelle est une application React statique. La grille sera donc dessinée en SVG ou Canvas et son état sera conservé côté client. Le DOM ne doit pas contenir une cellule complexe par point pour les grands formats. Les palettes seront virtuellement parcourables et recherchables. Aucune fonction serveur, base distante ou compte utilisateur n’est nécessaire pour la première livraison.
