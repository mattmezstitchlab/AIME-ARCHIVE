# Fondements numériques du RGB 24 bits et de sRGB

## 1. Introduction

Ce rapport explore les fondements numériques du modèle de couleur RGB 24 bits et de l'espace colorimétrique sRGB. Il aborde le codage des 16 777 216 triplets de couleurs, les mécanismes de transfert, le gamut, la quantification, les caractéristiques des écrans et les limites physiques associées. L'objectif est de fournir une compréhension approfondie de ces concepts et de leurs implications pour l'architecture de données et la conception d'interfaces innovantes.

## 2. Définitions

### RGB (Red, Green, Blue)

Le modèle de couleur **RGB** est un modèle additif dans lequel les couleurs rouge, verte et bleue sont combinées de diverses manières pour reproduire un large éventail de couleurs. Chaque couleur primaire est représentée par une intensité lumineuse. Dans le contexte numérique, ces intensités sont généralement exprimées sous forme de valeurs numériques.

### RGB 24 bits

Le **RGB 24 bits** fait référence à un système de codage des couleurs où chaque pixel est représenté par 24 bits de données. Ces 24 bits sont répartis également entre les trois canaux de couleur (rouge, vert, bleu), attribuant 8 bits à chaque canal. Avec 8 bits par canal, chaque couleur primaire peut avoir 2^8 = 256 niveaux d'intensité différents (de 0 à 255). La combinaison de ces 256 niveaux pour chaque canal donne un total de 256 × 256 × 256 = 16 777 216 couleurs possibles. Ce nombre est souvent appelé « couleurs vraies » ou « True Color ».

### sRGB (standard Red, Green, Blue)

**sRGB** est un espace colorimétrique standardisé, créé conjointement par HP et Microsoft en 1996 et officialisé par l'International Electrotechnical Commission (IEC) sous la norme IEC 61966-2-1:1999 [1]. Il est devenu l'espace colorimétrique par défaut pour le web, les moniteurs, les imprimantes et de nombreux autres périphériques. sRGB définit non seulement les primaires de couleur (les teintes de rouge, vert et bleu), mais aussi une fonction de transfert (gamma) et un point blanc, garantissant une reproduction cohérente des couleurs sur différents appareils dans des conditions d'affichage typiques de bureau et de domicile [1].

### Gamut

Le **gamut** d'un espace colorimétrique est l'ensemble complet des couleurs qui peuvent être reproduites ou affichées dans cet espace. Le gamut sRGB est un triangle de couleurs défini par les chromaticités de ses primaires rouge, vert et bleu. Toutes les couleurs représentables dans sRGB se trouvent à l'intérieur de ce triangle [1].

### Fonction de transfert (Gamma)

La **fonction de transfert**, souvent appelée **correction gamma**, décrit la relation non linéaire entre les valeurs numériques des couleurs et l'intensité lumineuse réelle affichée par un écran. Pour sRGB, cette fonction est conçue pour compenser la réponse non linéaire des écrans CRT historiques et pour optimiser la perception visuelle humaine, qui est plus sensible aux variations dans les tons sombres [1].

### Quantification

La **quantification** est le processus de conversion d'un signal analogique continu (comme la lumière) en un ensemble discret de valeurs numériques. Dans le contexte des couleurs, cela signifie attribuer une valeur numérique spécifique à chaque niveau d'intensité d'une couleur primaire. Pour le RGB 24 bits, chaque canal est quantifié sur 256 niveaux.

## 3. État de l'art et Données techniques

### Codage des 16 777 216 triplets

Le codage des couleurs en RGB 24 bits est direct : chaque pixel est composé de trois octets, un pour le rouge, un pour le vert et un pour le bleu. Chaque octet peut prendre une valeur de 0 à 255. Par exemple, le noir est (0, 0, 0), le blanc est (255, 255, 255), le rouge pur est (255, 0, 0), etc. Ces triplets sont souvent représentés en hexadécimal (par exemple, #FFFFFF pour le blanc) [2].

### Fonction de transfert sRGB

La fonction de transfert sRGB est définie par une section linéaire pour les valeurs d'intensité faibles et une loi de puissance décalée pour le reste de la plage. Pour les valeurs R', G', B' (valeurs numériques normalisées de 0 à 1), l'intensité linéaire R, G, B est calculée comme suit [1] :

```
Si R' <= 0.04045, alors R = R' / 12.92
Sinon, R = ((R' + 0.055) / 1.055)^2.4
```

La fonction inverse est utilisée pour convertir les intensités linéaires en valeurs R'G'B' pour l'affichage. Cette non-linéarité est cruciale pour assurer que les couleurs sont perçues de manière uniforme par l'œil humain et pour optimiser l'utilisation des 8 bits par canal [1].

### Gamut sRGB

Le gamut sRGB est basé sur les primaires de couleur du standard HDTV ITU-R BT.709. Ces primaires ont été choisies pour correspondre aux phosphores des écrans CRT de l'époque. Le point blanc de sRGB est le D65, qui représente la lumière du jour moyenne [1].

### Conversion CIE XYZ

Le standard sRGB spécifie également une matrice de conversion entre les valeurs linéaires RGB et l'espace colorimétrique perceptuel CIE XYZ. Cette conversion permet de relier les couleurs sRGB à un système indépendant du périphérique, basé sur la perception humaine [1] :

```
[X]
[Y] = [ 0.4124  0.3576  0.1805 ] [R]
[Z]   [ 0.2126  0.7152  0.0722 ] [G]
      [ 0.0193  0.1192  0.9505 ] [B]
```

Une matrice inverse est également fournie pour la conversion de CIE XYZ vers RGB linéaire.

## 4. Limites et Controverses

### Limites du gamut sRGB

Bien que sRGB soit largement adopté, son gamut est relativement restreint par rapport à d'autres espaces colorimétriques plus larges (comme Adobe RGB ou DCI-P3). Cela signifie que certaines couleurs vives, particulièrement dans les verts et les bleus saturés, ne peuvent pas être représentées avec précision dans l'espace sRGB. Pour les applications professionnelles (photographie, cinéma), cela peut entraîner une perte de fidélité des couleurs [3].

### Précision de la quantification 8 bits

Avec 8 bits par canal, il y a 256 niveaux d'intensité. Bien que 16,7 millions de couleurs soient généralement suffisantes pour la plupart des usages, des phénomènes comme le *banding* (apparition de bandes de couleurs distinctes au lieu de dégradés lisses) peuvent survenir dans des dégradés subtils, surtout sur des écrans de haute qualité ou avec des contenus à large gamut. Cela est dû à l'incapacité de l'échelle 8 bits à représenter suffisamment de nuances entre deux valeurs adjacentes [4].

### Écrans et limites physiques

Les écrans modernes, en particulier les écrans HDR (High Dynamic Range) et ceux utilisant des technologies comme l'OLED ou les points quantiques, sont capables d'afficher des gamuts de couleurs beaucoup plus larges que sRGB et des plages dynamiques plus élevées. Cependant, la plupart des contenus et des systèmes d'exploitation continuent d'utiliser sRGB par défaut, ce qui peut limiter la pleine exploitation des capacités de ces écrans. La conversion entre différents espaces colorimétriques (*gamut mapping*) est un défi technique pour assurer une reproduction fidèle des couleurs [5].

### Le mythe des « couleurs secrètes » et les noms oubliés

Le concept de « couleurs secrètes » ou « couleurs interdites » est souvent une simplification abusive de phénomènes perceptuels ou techniques. Il n'existe pas de couleurs physiquement impossibles à afficher dans le spectre visible par l'œil humain. Cependant, certains systèmes de reproduction des couleurs (comme le sRGB) ont un gamut limité, ce qui signifie qu'ils ne peuvent pas représenter toutes les couleurs que l'œil humain peut percevoir ou que d'autres espaces colorimétriques plus larges peuvent reproduire. Les « noms oubliés » ou « pigments disparus » font référence à des couleurs historiques ou des pigments qui ne sont plus utilisés, souvent pour des raisons de coût, de toxicité ou de stabilité, mais dont la perception n'est pas intrinsèquement différente. Il est crucial de distinguer ces aspects des limitations techniques des espaces colorimétriques numériques. Il n'y a pas de preuve attestée de l'existence de couleurs « secrètes » au-delà des capacités de perception humaine ou des limitations techniques des systèmes de reproduction.
