# Comparaison directe — Chromaverse et Chromathèque Universelle

## Conclusion synthétique

Les deux sites partagent le même socle — **les 16 777 216 couleurs sRGB 24 bits calculées à la demande** — mais ils ne racontent pas la même chose et ne proposent pas le même outil principal. **Chromaverse est d’abord un laboratoire d’analyse d’une couleur et de ses usages**. **Chromathèque Universelle est d’abord une carte de navigation exhaustive et une enquête documentaire**. Ils se recouvrent sur les conversions techniques, mais sont complémentaires sur leur mécanisme central.

| Dimension | Chromaverse | Chromathèque Universelle |
|---|---|---|
| Question principale | « Que signifie et que permet cette couleur dans le code, à l’écran et dans une palette ? » | « Où se situe cette couleur dans l’ensemble des 16 777 216 adresses, et quelles traces documentaires lui sont associées ? » |
| Innovation centrale | Observation de la mémoire RVBA, notamment le cas alpha nul ; laboratoire couleur complet | **Chromatome**, parcours octal réversible en huit décisions dans l’espace RVB |
| Accès aux 16,7 millions | Calcul direct par indice entier `R × 65 536 + V × 256 + B` et recherche | Carte hiérarchique adressable : huit branches par niveau, huit niveaux, une couleur exacte |
| Outils de création | Harmonies complémentaire, analogues, triadique, tétradique ; export ASE, JSON, CSS | Pas encore d’harmonies ni d’export de palette |
| Comparaison | Comparateur de deux couleurs, contraste, Delta E 1976, écarts RVB et HSL | Fiche d’une couleur, contraste blanc/graphite, OKLCH, emprise de navigation |
| Transparence | Axe majeur : HEX8, alpha, mémoire RGB invisible sous `A = 0` | Non traité dans la version actuelle, centrée sur sRGB opaque 24 bits |
| Histoire et archives | Très limité ; surtout normes et limites d’écran | Axe majeur : pigments historiques, sources muséales, niveaux de confiance, distinction numérique/matière |
| Provenance des noms | Nom proche par approximation lexicale/distance RVB | Nom exact ou éditorial avec statut et provenance du corpus |
| CMJN | Approximation mathématique avec avertissement ICC | Approximation mathématique avec avertissement ICC et renvoi institutionnel |
| Positionnement visuel | Laboratoire néo-moderniste très minimal, blanc/noir, typographie sans-serif | Atlas cartographique éditorial, minéral, hero illustré, serif + mono |
| Rapport de recherche | Non visible comme livrable central | Rapport de 6 949 mots, 14 recherches parallèles, matrice multicritère et architecture documentée |

## Recouvrements réels

Les deux applications calculent Hex, RVB et CMJN à la demande, affichent le contraste, rappellent les limites de calibration et évitent de charger une table de 16,7 millions d’enregistrements. Elles ont donc un **même noyau mathématique**, mais leurs couches supérieures diffèrent.

Chromaverse possède davantage d’outils immédiatement utiles au designer : harmonies, export de palettes, comparaison de deux couleurs et étude de la transparence. La Chromathèque possède la navigation spatiale que Chromaverse n’a pas : le Chromatome donne une adresse octale réversible et permet de parcourir l’espace, plutôt que de seulement chercher une valeur déjà connue.

## Recommandation

Il ne faut pas maintenir deux promesses universelles concurrentes. La direction la plus cohérente consiste à faire de **Chromathèque Universelle la marque et l’atlas principal**, puis à intégrer **Chromaverse comme le module « Laboratoire »** d’une couleur. Le menu cible pourrait devenir : `Explorer` (Chromatome), `Laboratoire` (outils Chromaverse), `Comparer`, `Archives`, `Sources`.

Dans cette fusion, le Chromatome resterait l’innovation propriétaire d’orientation et d’adressage. Chromaverse apporterait les outils opérationnels : alpha, harmonies, exports et comparateur. Une seule fiche couleur devrait alimenter tous les modules afin d’éviter les divergences de calcul et de terminologie.

## Sources examinées

- Chromaverse : https://chromaverse-cvvdetgt.manus.space/?color=3157D5
- Chromathèque Universelle : aperçu local du projet `chromatheque-universelle`, version `67e659e1`
