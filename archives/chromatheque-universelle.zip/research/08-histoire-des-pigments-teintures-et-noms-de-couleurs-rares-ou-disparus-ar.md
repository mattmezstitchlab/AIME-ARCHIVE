# Rapport sur l'Histoire des Pigments, Teintures et Noms de Couleurs Rares ou Disparus

## Introduction

L'exploration des 16 777 216 couleurs du spectre RGB pour une interface innovante nécessite une compréhension approfondie de la couleur, non seulement en tant que phénomène physique, mais aussi en tant que construction culturelle et historique. Cet axe de recherche se concentre sur l'histoire des pigments, des teintures et des noms de couleurs rares ou disparus, afin d'éclairer les dynamiques d'apparition, de valorisation, d'oubli et de redécouverte des teintes. L'objectif est de fournir une base solide pour l'architecture de données et la conception d'une interface capable de naviguer et de présenter cette richesse chromatique.

## Définitions

*   **Pigment :** Substance colorée insoluble, utilisée pour colorer d'autres matériaux en étant dispersée dans un liant. Les pigments peuvent être d'origine minérale, végétale, animale ou synthétique.
*   **Teinture :** Substance colorée soluble, utilisée pour imprégner et colorer des fibres textiles ou d'autres matériaux.
*   **Nom de couleur rare ou disparu :** Terme désignant une couleur qui n'est plus couramment utilisée dans le langage courant, dont la signification exacte a évolué ou a été perdue, ou qui fait référence à un pigment ou une teinture dont la production a cessé.

## État de l'Art et Données Techniques

L'histoire des couleurs est intrinsèquement liée aux avancées technologiques, aux routes commerciales et aux contextes culturels [1].

### Pigments Naturels Rares et Précieux

Historiquement, certains pigments étaient d'une valeur inestimable en raison de leur rareté, de la difficulté de leur extraction ou de leur fabrication [1].

*   **Outremer naturel :** Obtenu à partir du lapis-lazuli, principalement extrait du Badakhshan en Afghanistan. Son coût était si élevé à la Renaissance qu'il valait parfois plus cher que l'or, réservé aux figures sacrées comme la Vierge Marie. Le processus de fabrication était laborieux, nécessitant le broyage de la pierre et la séparation des impuretés pour obtenir un bleu pur et vibrant [1].
*   **Jaune de Naples :** Composé d'antimoniate de plomb, ce pigment était apprécié du XVIIe au XIXe siècle pour sa douceur et sa chaleur. Cependant, sa composition à base de plomb le rendait hautement toxique, exposant les artistes au saturnisme et à d'autres troubles neurologiques. Les versions modernes sont des reconstitutions sans plomb [1].
*   **Brun de momie :** Un pigment brun transparent populaire aux XVIIIe et XIXe siècles, fabriqué à partir d'un mélange de bitume, de résine et de momies égyptiennes broyées. Sa production a décliné au début du XXe siècle en raison de l'épuisement des stocks de momies et de la prise de conscience de son origine macabre [1].
*   **Rouge cochenille :** Issu d'un insecte parasite du cactus, la cochenille, massivement exploitée en Amérique centrale. Séchés et broyés, ces insectes produisaient un rouge carmin d'une puissance remarquable, devenant une ressource stratégique et géopolitique pour l'Espagne [1].

### L'Avènement des Pigments Synthétiques

L'introduction des pigments synthétiques a révolutionné la palette des artistes, offrant des alternatives plus économiques et parfois plus stables [1].

*   **Bleu de Prusse :** Inventé au début du XVIIIe siècle, il fut le premier pigment synthétique à rivaliser avec les pigments naturels coûteux comme l'outremer. Son bleu profond et intense a démocratisé l'accès à cette couleur [1].
*   **Vert émeraude (ou vert de Paris) :** Très prisé au XIXe siècle pour son éclat, ce pigment à base d'arséniate de cuivre était malheureusement toxique, l'arsenic pouvant devenir volatil dans certaines conditions d'humidité [1].

### Couleurs Conceptuelles et Modernes

L'art contemporain a également exploré la rareté et la signification des couleurs [1].

*   **International Klein Blue (IKB) :** Développé par Yves Klein, ce bleu saturé et intense est devenu une œuvre d'art en soi, cherchant à préserver la pureté du pigment par un liant spécifique [1].
*   **Vantablack :** Un matériau ultra-absorbant qui absorbe près de 99,96 % de la lumière visible, créant une absence de relief et une perception d'un 
noir absolu. Son exclusivité artistique a suscité une polémique [1].

### Noms de Couleurs Rares ou Disparus

La langue française a connu de nombreux noms de couleurs qui sont aujourd'hui tombés en désuétude ou dont la signification précise s'est perdue. Ces termes reflètent des perceptions chromatiques et des pratiques culturelles spécifiques à leur époque [2].

*   **Incarnat :** Un rose vif, dont le nom vient de l'italien *incarnato*, signifiant 
‘la chair’ [2].
*   **Pourpre :** Historiquement, un rouge violacé très prisé et coûteux, extrait de mollusques (murex). Sa rareté le réservait aux puissants, symbolisant le pouvoir. Le terme peut désigner la couleur (masculin) ou la matière colorante/étoffe teinte (féminin) [2].
*   **Cuisse-de-nymphe-émue :** Une couleur chair du XVIIIe siècle, aujourd'hui inusitée [2].
*   **Puce :** Un marron foncé [2].
*   **Smaragdin :** Un vert, du grec *smaragdos* pour ‘l’émeraude’ [2].
*   **Zinzolin :** Un violet rougeâtre [2].

## Limites et Controverses

La perception et la dénomination des couleurs sont sujettes à des variations culturelles et linguistiques. Ce qui est considéré comme une couleur distincte dans une culture peut être une nuance d’une autre couleur dans une autre. De plus, la disponibilité des pigments et des teintures a historiquement influencé la palette chromatique et, par extension, le vocabulaire des couleurs.

*   **Toxicité des pigments :** De nombreux pigments historiques, comme le jaune de Naples (plomb) ou le vert émeraude (arsenic), étaient hautement toxiques, posant des risques pour la santé des artistes et des artisans [1].
*   **Disparition des couleurs du quotidien :** À l’ère moderne, une tendance à la monochromie est observée dans l’environnement quotidien (voitures, intérieurs, vêtements), avec une prédominance des noirs, gris et blancs. Cette 
tendance est attribuée à des facteurs de goût, de consommation de masse et d’influence des avant-gardes artistiques et architecturales [3].
*   **Chromophobie :** Le concept de "chromophobie" décrit une peur ou une méfiance de la couleur en Occident, la considérant comme vulgaire ou moins raffinée que le noir, le blanc et le gris. Cette perspective a influencé l’art et l’architecture, bien que des figures comme Le Corbusier aient finalement réintroduit la couleur dans leurs œuvres [3].

## Implications Directes pour l’Architecture de Données

Pour une interface explorant 16 777 216 couleurs RGB, l’architecture de données doit être robuste et flexible pour gérer la complexité historique et sémantique des couleurs.

*   **Base de données sémantique :** Développer une base de données qui ne se contente pas de stocker les codes RGB, mais qui associe à chaque couleur (ou gamme de couleurs) des métadonnées riches : noms historiques, origines (minérale, végétale, synthétique), périodes d’utilisation, symboliques culturelles, toxicité, et anecdotes. Cela permettrait de contextualiser chaque couleur.
*   **Gestion des synonymes et variations :** Les noms de couleurs peuvent avoir des synonymes ou des variations régionales/historiques. L’architecture doit permettre de lier ces termes à une couleur ou une gamme de couleurs spécifique, tout en gérant les ambiguïtés.
*   **Indexation temporelle et géographique :** Associer des données temporelles (périodes d’usage, dates de découverte/disparition) et géographiques (lieux d’extraction, cultures dominantes) aux couleurs pour permettre une exploration historique et culturelle.
*   **Modélisation des relations :** Établir des relations entre les couleurs (ex: couleurs complémentaires, couleurs associées à un mouvement artistique, couleurs dérivées d’un même pigment) pour faciliter la navigation et la découverte.

## Implications Directes pour une Interface Innovante

Une interface innovante devrait capitaliser sur cette richesse historique et technique pour offrir une expérience utilisateur immersive et éducative.

*   **Visualisation contextuelle :** Au-delà de l’affichage de la couleur elle-même, l’interface pourrait présenter des informations contextuelles (histoire, origine, symbolique) lorsque l’utilisateur interagit avec une couleur. Par exemple, en survolant un "Jaune de Naples", une fiche informative pourrait apparaître, mentionnant sa toxicité historique et sa composition.
*   **Exploration narrative :** Permettre aux utilisateurs de voyager à travers l’histoire des couleurs, en présentant des "lignes du temps" interactives montrant l’apparition et la disparition de pigments ou de noms de couleurs. Des "cartes des couleurs" pourraient illustrer leur diffusion géographique.
*   **Recherche sémantique avancée :** Offrir des fonctionnalités de recherche basées sur des critères historiques, culturels ou techniques (ex: "couleurs utilisées par les Impressionnistes", "pigments toxiques", "couleurs symbolisant la royauté").
*   **Reconstitution virtuelle :** Proposer des simulations de couleurs telles qu’elles auraient pu apparaître avec des pigments historiques, en tenant compte des liants et des supports de l’époque, pour illustrer les différences avec les rendus numériques modernes.
*   **Alertes et avertissements :** Intégrer des avertissements pour les couleurs associées à des pigments toxiques ou à des controverses, sensibilisant ainsi l’utilisateur aux aspects moins connus de leur histoire.

## Recommandations Concrètes

1.  **Développer un thésaurus chromatique historique :** Créer une base de données exhaustive des noms de couleurs, pigments et teintures, avec leurs définitions, étymologies, périodes d’usage, compositions chimiques (si pertinentes), et références culturelles. Ce thésaurus serait la pierre angulaire de l’interface.
2.  **Intégrer des sources primaires et muséales :** Collaborer avec des musées, des archives et des institutions de recherche pour intégrer des images de nuanciers anciens, des extraits de dictionnaires historiques et des cas attestés de pigments ou de noms de couleurs oubliés. Cela renforcerait l’authenticité et la crédibilité de l’interface.
3.  **Concevoir des parcours d’exploration thématiques :** Proposer des "visites guidées" virtuelles autour de thèmes spécifiques (ex: "Les couleurs de la Renaissance", "L’impact de la chimie sur la couleur", "Les couleurs du deuil"), permettant une immersion profonde dans des aspects particuliers de l’histoire des couleurs.

## Bibliographie

[1] Artemisia Online. (2026, 24 juin). *Les pigments rares dans l’histoire de la peinture : quand la couleur valait plus cher que l’or*. [https://artemisiaonline.com/2026/06/24/les-pigments-rares-dans-lhistoire-de-la-peinture-quand-la-couleur-valait-plus-cher-que-lor/](https://artemisiaonline.com/2026/06/24/les-pigments-rares-dans-lhistoire-de-la-peinture-quand-la-couleur-valait-plus-cher-que-lor/)

[2] RTL.fr. (2022, 14 mai). *Zinzolin, smaragdin, puce... Les couleurs disparues de la langue française*. [https://www.rtl.fr/culture/culture-generale/zinzolin-smaragdin-puce-les-couleurs-disparues-de-la-langue-francaise-7900152673](https://www.rtl.fr/culture/culture-generale/zinzolin-smaragdin-puce-les-couleurs-disparues-de-la-langue-francaise-7900152673)

[3] Radio France. (2022, 20 octobre). *Pourquoi la couleur a disparu de notre quotidien*. [https://www.radiofrance.fr/franceculture/pourquoi-la-couleur-a-disparu-de-notre-quotidien-6306229](https://www.radiofrance.fr/franceculture/pourquoi-la-couleur-a-disparu-de-notre-quotidien-6306229)
