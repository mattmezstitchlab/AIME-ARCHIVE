# Matrice de décision des concepts

Les notes vont de 1 à 10. Elles constituent une évaluation de conception argumentée, non une mesure expérimentale. Les pondérations ont été fixées dans `cadrage-et-criteres.md` avant la notation.

| Rang | Concept | Score pondéré / 10 | Justification synthétique |
|---:|---|---:|---|
| 1 | **Chromatome hybride** | 9.65 | Combine l’adresse octree exacte, les coupes perceptuelles, les balises documentaires et un moteur de recherche réversible. |
| 2 | **Moteur de recherche tabulaire** | 8.43 | Excellent instrument documentaire et technique, mais faible comme espace d’exploration et de sérendipité. |
| 3 | **Octree à zoom sémantique** | 8.38 | Huit niveaux suffisent pour isoler une couleur exacte ; la proximité hiérarchique n’est pas perceptuelle. |
| 4 | **Atlas de coupes 2D** | 8.04 | Précis, performant et accessible ; moins distinctif et moins propice aux découvertes transversales. |
| 5 | **Carte de Hilbert** | 7.30 | Exhaustive et dense, avec une forte signature visuelle ; l’ordre 1D crée toutefois des voisinages artificiels. |
| 6 | **Solide perceptuel OKLCH** | 6.66 | Très bon pour les voisinages ressentis, mais l’adressage exhaustif sRGB et l’orientation restent moins directs. |
| 7 | **Cube RGB 3D navigable** | 6.09 | Exact et spectaculaire, mais occlusions, désorientation, ciblage et accessibilité limitent l’usage quotidien. |

## Définition du concept gagnant

Le **Chromatome hybride** représente les 24 bits d’une couleur comme un parcours de huit décisions octales. À chaque niveau, le volume RGB est divisé simultanément en deux sur chacun de ses trois axes, soit huit sous-volumes. Après huit niveaux, le parcours désigne exactement un triplet RGB. La carte 2D récursive affiche uniquement les tuiles du niveau utile, tandis qu’une lentille OKLCH/Oklab révèle les voisins perceptuels et qu’une couche documentaire signale les couleurs nommées, historiques ou retirées.

Cette architecture n’affirme pas que la proximité dans l’octree soit perceptuelle. Elle utilise l’octree pour l’**adresse exacte et le zoom**, puis un espace perceptuel distinct pour la **comparaison des apparences**. Cette séparation est le cœur scientifique de l’innovation.
