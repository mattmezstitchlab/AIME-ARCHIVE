# Spécification du Chromatome hybride

## Résumé exécutif

Le **Chromatome** est un atlas multi-échelles des 16 777 216 couleurs sRGB 24 bits. Il ne tente jamais d’afficher simultanément 16 millions de composants d’interface. Il transforme chaque couleur en une **adresse de huit chiffres octaux**, obtenue par entrelacement des bits rouge, vert et bleu. Une carte récursive donne accès à l’adresse exacte en huit niveaux ; une lentille perceptuelle Oklab/OKLCH montre les voisins visuellement proches ; des balises documentaires identifient la petite minorité de valeurs auxquelles sont attachés des noms, normes, récits historiques ou approximations de pigments.

> **Principe central :** l’espace RGB organise l’adresse numérique exacte ; l’espace perceptuel organise la ressemblance ; le graphe documentaire organise les connaissances. Aucun de ces trois plans ne doit être présenté comme équivalent aux deux autres.

## 1. Adresse chromatique en huit décisions

Pour une couleur `R`, `V`, `B` comprise entre 0 et 255, chaque canal s’écrit sur huit bits. Au niveau `i`, de 7 à 0, les trois bits de même poids forment un chiffre octal :

`d_i = 4 × bit_i(R) + 2 × bit_i(V) + bit_i(B)`

L’adresse complète est donc `d_7 d_6 … d_0`. Chaque chiffre indique l’un des huit octants du cube RGB courant. Après huit subdivisions, les trois canaux sont entièrement déterminés. Ce code est un **ordre de Morton 3D** présenté à l’utilisateur comme un « génome chromatique » réversible.

| Propriété | Valeur |
|---|---:|
| Canaux | 3 |
| Bits par canal | 8 |
| Décisions par niveau | 8 octants |
| Profondeur exacte | 8 niveaux |
| Feuilles | `8^8 = 16 777 216` |
| Identifiant canonique | entier RGB non signé sur 24 bits |

### Exemple

Pour `#FF702C`, soit `R=255`, `V=112`, `B=44`, l’interface calcule l’adresse octale à partir des triplets de bits, puis permet le trajet inverse sans perte. Le code Hex reste toujours affiché comme identifiant familier ; l’adresse octale sert à l’orientation multi-échelles.

## 2. Carte récursive 2D

Chaque niveau est une mosaïque de huit tuiles disposées selon une géométrie stable. La tuile représente un sous-volume RGB par sa couleur médiane ou une texture calculée. Un clic ou un zoom entre dans le sous-volume. Le fil d’Ariane affiche la profondeur, les intervalles `R`, `V`, `B` encore possibles et le nombre de feuilles restantes.

| Niveau | Nombre de couleurs par tuile sélectionnée | Sens de la vue |
|---:|---:|---|
| 0 | 16 777 216 | totalité du cube sRGB |
| 1 | 2 097 152 | un grand octant |
| 2 | 262 144 | une famille numérique |
| 3 | 32 768 | une région explorable |
| 4 | 4 096 | une nappe détaillée |
| 5 | 512 | voisinage numérique |
| 6 | 64 | nuancier fin |
| 7 | 8 | derniers candidats |
| 8 | 1 | fiche exacte |

Le rendu n’instancie que les tuiles visibles et leurs étiquettes utiles. Canvas 2D constitue le mode universel ; WebGL ou WebGPU peut accélérer les transitions et textures, avec maintien d’une vue tabulaire accessible.

## 3. Zoom sémantique

Le contenu change avec l’échelle plutôt que d’agrandir mécaniquement les mêmes objets.

| Échelle | Information prioritaire |
|---|---|
| Monde | familles dominantes, repères des axes RGB, proportion du corpus documenté |
| Région | intervalles de canaux, histogramme perceptuel, densité des balises documentaires |
| Quartier | Hex représentatifs, proximité Oklab, contrastes sur noir et blanc |
| Feuille | Hex, RVB, adresse octale, HSL/HWB, Oklab/OKLCH, CMJN pédagogique, avertissements ICC, sources et alias |

## 4. Lentille perceptuelle

La proximité dans l’ordre de Morton n’est pas une distance perceptuelle. La lentille, activée sur une sélection, reprojette localement les couleurs vers Oklab/OKLCH et affiche un voisinage ordonné par distance perceptuelle. Elle peut proposer une distance simple dans Oklab pour l’interaction rapide et CIEDE2000 dans CIELAB pour les comparaisons documentées, en indiquant toujours la formule utilisée.

Cette lentille sert également à distinguer :

- les voisins numériques dans le cube RGB ;
- les voisins visuels calculés ;
- les couleurs nommées proches ;
- les approximations écran de matériaux historiques.

## 5. Balises documentaires et « couleurs manquantes »

Une balise ne transforme pas une couleur numérique en pigment. Elle relie une valeur sRGB à une entrée documentaire avec une relation qualifiée.

| Relation | Signification |
|---|---|
| `EXACT_IN_STANDARD` | valeur numérique explicitement définie par un standard ou corpus |
| `ALIAS_OF` | autre nom pour la même valeur dans un référentiel déterminé |
| `DISPLAY_APPROXIMATION_OF` | approximation sRGB d’un matériau, pigment ou échantillon physique |
| `REMOVED_FROM` | entrée retirée d’une édition ou d’un catalogue documenté |
| `RENAMED_TO` | appellation remplacée par une autre |
| `ATTESTED_IN` | nom ou usage attesté dans une source historique |
| `CONTESTED` | attribution ou interprétation débattue |

Le mode **Chasse aux lacunes** filtre les entrées retirées, renommées, rarement documentées, non traduites ou sans correspondance numérique stable. Il montre la preuve, le niveau de confiance et les conflits de sources ; il ne prétend pas révéler des couleurs physiques secrètes.

## 6. Recherche unifiée

La barre de commande accepte : Hex, `rgb()`, nom, alias, adresse octale, plage de canaux, teinte approximative, institution, période, type de matériau et statut documentaire. Toute requête devient un état partageable dans l’URL. Les résultats peuvent ouvrir la carte, la lentille ou la fiche documentaire sans perdre le contexte.

## 7. CMJN et impression

Une fiche peut fournir deux niveaux distincts :

| Niveau | Usage | Formulation requise |
|---|---|---|
| Approximation mathématique | pédagogie et orientation | « CMJN approximatif sans profil » |
| Conversion de production | prépresse | résultat associé à un profil ICC, une intention de rendu et des conditions de sortie |

Il n’existe pas de quadruplet CMJN universel déductible d’un RGB indépendamment du périphérique et du procédé. L’application doit empêcher visuellement la confusion entre ces deux niveaux.

## 8. Accessibilité par conception

La couleur n’est jamais le seul canal d’information. Chaque tuile possède une adresse textuelle et un état de focus. La vue tabulaire est fonctionnellement équivalente à la carte. Les interactions essentielles fonctionnent au clavier ; les animations respectent `prefers-reduced-motion`. Les contrastes WCAG concernent les exemples de texte ou de composants, et non la « conformité intrinsèque » d’une couleur isolée.

## 9. Architecture de données minimale

La totalité des valeurs RGB est **calculée**, non stockée comme 16 777 216 fiches. Seules les annotations sont persistées.

| Entité | Champs principaux |
|---|---|
| `ColorAddress` | `rgb24`, `hex`, `r`, `g`, `b`, `morton24`, coordonnées calculées |
| `NamedColor` | nom, langue, corpus, valeur ou plage, statut, licence |
| `DocumentaryRecord` | type, titre, dates, lieux, description, confiance |
| `MaterialSample` | composition, support, illuminant, données spectrales éventuelles |
| `Relation` | source, cible, prédicat qualifié, portée, confiance |
| `Citation` | URL, institution, auteur, date, licence, extrait vérifié |
| `PrintConversion` | profil source, profil destination, intention, valeurs CMJN, date de calcul |

## 10. Indicateurs de réussite du prototype

Le prototype devra démontrer que n’importe quel Hex est accessible en huit décisions au maximum depuis la vue racine, que la saisie directe est instantanée, que le rendu ne crée pas des millions de nœuds DOM et que la navigation conserve une fréquence d’images acceptable sur un appareil courant. Un test utilisateur devra comparer l’orientation et la découverte face à un sélecteur 2D et à un cube 3D.

## 11. Risques et parades

| Risque | Parade |
|---|---|
| Confusion entre hiérarchie numérique et ressemblance | bascule explicite « adresse / perception » et légende persistante |
| Effet spectaculaire mais désorientant | fil d’Ariane, minimap, plages RGB et retour instantané |
| Surcharge documentaire | détails progressifs et provenance repliable |
| Couleurs illisibles comme fond d’UI | chrome neutre, calcul automatique du texte noir ou blanc |
| Surpromesse CMJN | libellés séparés et profil obligatoire pour la production |
| Inaccessibilité du canvas | vue tabulaire synchronisée et commandes clavier |
