# Synthèse des recherches terminées — Chromathèque Atelier

**Auteur : Manus AI**  
**Périmètre : neuf axes terminés sur dix**

## Synthèse exécutive

Les recherches convergent sur une distinction essentielle : **DMC peut être une source de vérité pour ses propres numéros, noms et familles de fils lorsqu’ils sont vérifiés sur ses supports officiels, mais pas pour une valeur RGB universelle**. La couleur textile réelle dépend du fil physique, de l’éclairage, du bain de teinture, du support et du phénomène de métamérisme. L’écran ne fournit donc qu’une représentation indicative. La carte DMC contenant de vrais échantillons demeure la meilleure référence pratique disponible pour choisir un fil réel.[1] [2]

La bibliothèque de points doit être présentée comme un **atlas évolutif et documenté**, non comme la totalité définitive des points du monde. La RSN Stitch Bank, les diagrammes DMC, les guildes et les collections muséales fournissent des fondations solides, mais les variations régionales, les traditions orales et les traductions rendent l’exhaustivité mondiale absolue impossible à démontrer.[3] [4]

> **Décision de produit recommandée :** employer le code DMC comme identifiant commercial vérifié, afficher le rendu Hex/RGB comme « approximation écran non officielle », conserver une provenance par entrée et recommander le nuancier physique pour toute décision textile finale.

## Ce que les neuf axes établissent

| Axe terminé | Conclusion exploitable | Conséquence pour l’interface |
|---|---|---|
| Données DMC secondaires | Les listes code–nom–RGB divergent et leurs licences sont parfois ambiguës. | Aucun jeu secondaire ne doit être présenté seul comme source de vérité ; chaque ligne doit porter sa provenance et son statut. |
| Gammes spéciales et historiques | Color Variations, Coloris, Étoile, Light Effects et Satin forment des familles distinctes ; les références retirées exigent une couche historique séparée. | Ajouter `famille`, `statut`, `date_verification` et `source_url`, sans mélanger actif, spécial et retiré. |
| Taxonomies institutionnelles | La RSN Stitch Bank fournit une base structurée reconnue pour les points et leurs variantes.[3] | Classer par famille, géométrie, support, usage, noms FR/EN et provenance culturelle. |
| Points comptés | Croix entière, demi-point, quarts, trois-quarts, point arrière et nœuds requièrent des géométries et symboles différents.[4] | Le modèle de grille ne doit pas limiter une cellule à une seule croix complète. |
| Traditions mondiales | Sashiko, kantha, chikankari, suzani, blackwork, crewel, couching et stumpwork ne se réduisent pas à des équivalents DMC. | Ajouter contexte, matériaux traditionnels et prudence culturelle ; DMC reste une option moderne, non l’origine de la tradition. |
| Logiciels de motifs | Les besoins récurrents sont grille, symboles, légende, densité, miroir, rotation, redimensionnement et exports. | Construire d’abord un éditeur de motif compté ; séparer les formats machine propriétaires d’une éventuelle phase ultérieure. |
| Propriété intellectuelle | Il faut éviter de reproduire le graphisme ou les images du nuancier officiel et déclarer l’absence d’affiliation.[5] | Créer une présentation originale, citer DMC comme marque et ne générer aucun faux code ou nom. |
| Colorimétrie textile | RGB/Hex ne reproduit pas la réflectance d’un fil ; éclairage et métamérisme modifient l’apparence.[6] | Afficher un avertissement persistant et, à terme, stocker des mesures Lab/XYZ si un protocole physique est disponible. |
| Architecture frontend | Une grande grille et un nuancier nécessitent rendu optimisé, recherche, sous-palettes, clavier et focus visible.[7] [8] | Utiliser Canvas ou SVG optimisé, virtualiser les longues palettes et rendre chaque action accessible sans couleur seule. |

## Hiérarchie de confiance proposée

| Niveau | Type de donnée | Statut affiché |
|---|---|---|
| **A — primaire** | Code, nom ou famille confirmé sur une page ou un support officiel DMC | « Vérifié DMC » |
| **B — institutionnel** | Description d’un point provenant de la RSN, d’un musée, d’une guilde ou d’une institution culturelle | « Source institutionnelle » |
| **C — secondaire recoupé** | RGB, alias, équivalence ou statut historique confirmé par plusieurs sources indépendantes | « Indicatif recoupé » |
| **D — secondaire unique** | Donnée provenant d’un seul catalogue tiers ou site communautaire | « À confirmer » |
| **E — contribution** | Proposition utilisateur non encore validée | « Non vérifié » |

Cette hiérarchie permet d’exposer un catalogue très large sans transformer une approximation en fait. Elle doit être visible dans la fiche du fil et dans celle du point.

## Modèle de données minimal recommandé

| Entité | Champs indispensables |
|---|---|
| **Fil** | `code`, `nom`, `famille`, `statut`, `rgb_indicatif`, `source_rgb`, `source_officielle`, `niveau_confiance`, `date_verification` |
| **Point** | `id`, `nom_fr`, `nom_en`, `famille`, `geometrie`, `support`, `usage`, `provenance`, `variantes`, `source`, `niveau_confiance` |
| **Marque de grille** | `x`, `y`, `ancrages`, `point_id`, `fil_code`, `orientation`, `couche` |
| **Motif** | `largeur`, `hauteur`, `format`, `geometrie`, `densite`, `unite`, `marques`, `historique` |

Les **ancrages** sont nécessaires pour représenter les quarts de point, trois-quarts, diagonales, points arrière et couchures ; une simple relation « une couleur par case » serait insuffisante.

## Bibliothèque initiale de points

La première livraison peut couvrir les familles les mieux documentées tout en conservant une structure extensible.

| Famille | Points ou techniques initiaux |
|---|---|
| Comptés | Croix entière, demi-croix, quart, trois-quarts, petite croix, point arrière, point lancé, nœud français |
| Ligne et contour | Point avant, point arrière, point de tige, point fendu, point de chaînette, couchure |
| Remplissage | Passé plat, passé empiétant, point de satin, point de brique, semis |
| Boucles et nœuds | Nœud français, nœud colonial, point de boucle, chaînette détachée |
| Relief | Point de poste, point de feston rembourré, stumpwork, couchure en relief |
| Traditions documentées | Sashiko, kantha, chikankari, suzani, blackwork et crewel comme dossiers culturels reliés aux points employés |

Cette liste n’est pas « tous les points du monde » : elle constitue un noyau vérifiable autour duquel des variantes et traditions peuvent être ajoutées avec leur provenance.

## Formulation recommandée dans le produit

> « Les numéros et noms DMC sont vérifiés lorsqu’une source officielle est disponible. Les couleurs affichées à l’écran sont des approximations non officielles et peuvent différer du fil réel selon l’écran, l’éclairage et le bain de teinture. Pour un choix final, consultez une carte physique avec échantillons. Chromathèque Atelier est un outil indépendant, non affilié à DMC. »

## Limite du lot présenté

L’axe consacré à l’**audit exhaustif du catalogue officiel DMC actuel** n’a pas produit de rapport terminé et n’est donc pas inclus. Les neuf axes permettent de définir le modèle, les règles de confiance et l’expérience de l’atelier, mais **ils ne suffisent pas encore à annoncer une liste complète et à jour de toutes les références DMC**.

## Références

[1]: https://www.dmc.com/US/en/products/floss-color-card-mouline-pearl-cotton "DMC — Floss Color Card"
[2]: https://www.xrite.com/fr-fr/blog/what-is-metamerism "X-Rite — Définition du métamérisme"
[3]: https://rsnstitchbank.org/ "Royal School of Needlework — RSN Stitch Bank"
[4]: https://www.dmc.com/FR/fr/sbs-cross-stitch-stitch-diagrams "DMC — Diagrammes du point de croix"
[5]: https://www.dmc.com/FR/fr/terms-and-conditions "DMC France — Conditions générales"
[6]: https://www.hunterlab.eu/fr/secteurs-dactivite/textiles/ "HunterLab — Mesure de la couleur des textiles"
[7]: https://www.w3.org/WAI/standards-guidelines/wcag/ "W3C — Web Content Accessibility Guidelines"
[8]: https://www.w3.org/WAI/ARIA/apg/patterns/ "W3C — ARIA Authoring Practices Guide"
