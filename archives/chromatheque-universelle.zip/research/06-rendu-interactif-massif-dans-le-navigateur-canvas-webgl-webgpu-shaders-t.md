# Rapport sur le Rendu Interactif Massif dans le Navigateur

## Axe de Recherche
Rendu interactif massif dans le navigateur : Canvas, WebGL, WebGPU, shaders, textures, instanciation, virtualisation, tuilage, calcul à la demande et budgets de performance.

## Introduction
Ce rapport explore les technologies et techniques permettant un rendu graphique interactif et massif directement au sein des navigateurs web. L'objectif est d'évaluer les capacités actuelles et futures de Canvas, WebGL et WebGPU, ainsi que les concepts associés tels que les shaders, les textures, l'instanciation, la virtualisation, le tuilage, le calcul à la demande et la gestion des budgets de performance, dans le contexte d'une interface capable d'adresser et d'explorer les 16 777 216 couleurs RGB.

## 1. Définitions

### Canvas
L'élément HTML `<canvas>` fournit une API de dessin pour le rendu graphique 2D à l'aide de JavaScript. Il est adapté pour des graphiques simples, des animations et des visualisations de données, mais ses performances peuvent devenir un goulot d'étranglement pour des scènes complexes ou un grand nombre d'éléments interactifs [1].

### WebGL
WebGL (Web Graphics Library) est une API JavaScript pour le rendu de graphiques 2D et 3D interactifs dans n'importe quel navigateur web compatible, sans l'utilisation de plug-ins. Basé sur OpenGL ES 2.0, il permet d'accéder directement au GPU du système via des shaders (programmes exécutés sur le GPU) écrits en GLSL (OpenGL Shading Language) [2].

### WebGPU
WebGPU est le successeur de WebGL, offrant un accès de bas niveau et à usage général aux capacités du GPU. Conçu pour être compatible avec les API graphiques modernes (Direct3D 12, Metal, Vulkan), WebGPU prend en charge non seulement le rendu graphique, mais aussi les calculs GPGPU (General-Purpose GPU) de manière plus efficace. Il utilise le WGSL (WebGPU Shading Language) [2] [3].

### Shaders
Les shaders sont de petits programmes exécutés sur le GPU. Il existe principalement deux types pour le rendu graphique : les **shaders de sommets** (vertex shaders) qui transforment la position des sommets dans l'espace 3D, et les **shaders de fragments** (fragment shaders) qui calculent la couleur de chaque pixel. WebGPU introduit également les **shaders de calcul** (compute shaders) pour des calculs parallèles généraux sur le GPU [2] [4].

### Textures
Les textures sont des images (ou des données) appliquées sur la surface des objets 3D pour leur donner de la couleur, des motifs ou d'autres détails visuels. Elles sont stockées dans la mémoire du GPU et peuvent être manipulées par les shaders [2].

### Instanciation
L'instanciation est une technique d'optimisation qui permet de dessiner plusieurs copies de la même géométrie (forme) avec un seul appel de dessin au GPU. Chaque copie, ou instance, peut avoir des propriétés uniques (position, couleur, échelle) définies par des données d'instance, réduisant considérablement la charge CPU pour le rendu de scènes massives [4].

### Virtualisation et Tuilage (Virtual Texturing/Tiling)
La virtualisation des textures (ou tuilage) est une technique qui permet de gérer des textures extrêmement grandes qui ne tiendraient pas entièrement dans la mémoire du GPU. Seules les parties visibles et nécessaires de la texture sont chargées en mémoire à la demande, optimisant ainsi l'utilisation des ressources [5].

### Calcul à la Demande (On-Demand Computation)
Le calcul à la demande fait référence à l'exécution de calculs uniquement lorsque cela est nécessaire, souvent en réponse à des interactions utilisateur ou à des changements de scène. Combiné aux capacités GPGPU de WebGPU, cela permet d'optimiser les ressources en évitant les calculs inutiles [2].

### Budgets de Performance
Les budgets de performance sont des limites définies pour l'utilisation des ressources (CPU, GPU, mémoire, bande passante) afin de garantir une expérience utilisateur fluide (par exemple, 60 images par seconde). La gestion de ces budgets est cruciale pour le rendu interactif massif, nécessitant des optimisations à tous les niveaux [6].

## 2. État de l'Art

### Évolution des API Graphiques Web
L'évolution des API graphiques web a progressé de l'élément `<canvas>` 2D, qui offre une abstraction de haut niveau mais des performances limitées pour des scènes complexes, à WebGL, qui a ouvert la voie au rendu 3D accéléré par le GPU dans le navigateur. WebGL, bien que révolutionnaire, est basé sur une API OpenGL ES 2.0 vieillissante, souffre d'un état global complexe et de limitations pour le GPGPU [2].

WebGPU représente la nouvelle génération, conçue pour s'aligner sur les API natives modernes (Vulkan, Metal, Direct3D 12). Il offre une architecture plus performante, un modèle d'état sans état (pipeline-based), une gestion asynchrone des opérations GPU et un support de première classe pour les shaders de calcul. Cela permet des applications graphiques plus exigeantes et des calculs parallèles complexes directement dans le navigateur [2] [3].

### Capacités Actuelles et Futures
*   **Canvas 2D**: Idéal pour des visualisations simples, des graphiques vectoriels et des animations légères. Limité pour la manipulation de millions de pixels individuellement et interactivement.
*   **WebGL**: Capable de rendre des scènes 3D complexes avec des millions de polygones. Des bibliothèques comme Three.js et Babylon.js simplifient son utilisation. Cependant, la gestion d'un très grand nombre d'objets distincts (comme 16 millions de carrés de couleur) peut encore être coûteuse en appels de dessin (draw calls) et en gestion de l'état CPU [2].
*   **WebGPU**: Offre des améliorations significatives en termes de performances et de flexibilité. Ses shaders de calcul sont particulièrement pertinents pour manipuler de vastes ensembles de données (comme 16 millions de couleurs) directement sur le GPU. La gestion des pipelines et l'asynchronisme réduisent les goulots d'étranglement CPU. Des entreprises comme Figma l'utilisent pour des performances de rendu accrues [2] [3] [7].

### Techniques d'Optimisation
Les techniques d'optimisation sont essentielles pour le rendu massif:
*   **Instanciation**: Réduit le nombre d'appels de dessin en permettant de rendre de multiples copies d'une géométrie avec un seul appel. Chaque instance peut avoir des attributs uniques (couleur, position) passés via des tampons d'instance [4]. Pour une interface de 16 millions de couleurs, cela signifie qu'un seul modèle de carré peut être dessiné 16 millions de fois avec des couleurs différentes en un seul appel.
*   **Virtualisation et Tuilage**: Permet de gérer des textures massives en ne chargeant que les parties visibles à l'écran. Cela est crucial si l'interface utilise des textures pour représenter l'espace colorimétrique [5].
*   **Calcul à la Demande**: Les shaders de calcul de WebGPU permettent de mettre à jour l'état des couleurs (par exemple, lors d'une recherche ou d'un filtrage) directement sur le GPU, sans avoir à transférer de grandes quantités de données entre le CPU et le GPU [4].

## 3. Données Techniques

### Comparaison des API

| Caractéristique | Canvas 2D | WebGL | WebGPU |
| :--- | :--- | :--- | :--- |
| **Accès Matériel** | Haut niveau | Bas niveau (OpenGL ES) | Très bas niveau (Vulkan, Metal, D3D12) |
| **Performances** | Faibles pour rendu massif | Bonnes, mais limitées par l'état global | Excellentes, architecture sans état |
| **GPGPU** | Non supporté | Limité (via textures) | Support natif (Compute Shaders) |
| **Asynchronisme** | Synchrone | Principalement synchrone | Asynchrone |
| **Langage Shaders** | N/A | GLSL | WGSL |

### Budgets de Performance
Pour maintenir 60 FPS, le temps de rendu total par image doit être inférieur à 16,6 millisecondes. Avec WebGPU, la réduction des surcoûts CPU permet de consacrer une plus grande partie de ce budget aux calculs GPU réels. L'utilisation de tampons de stockage (storage buffers) pour l'état des instances et le modèle de ping-pong (alternance entre deux tampons) sont des modèles de conception clés pour maximiser l'efficacité [4] [6].

## 4. Limites et Controverses

### Complexité d'Apprentissage
WebGPU est une API de bas niveau, ce qui signifie qu'elle nécessite beaucoup plus de code de configuration (boilerplate) que WebGL ou Canvas. La gestion explicite de la mémoire, des pipelines et des tampons de commandes augmente la courbe d'apprentissage pour les développeurs [6].

### Compatibilité et Adoption
Bien que WebGPU soit standardisé, son support dans tous les navigateurs et sur tous les appareils n'est pas encore universel. Les développeurs doivent souvent prévoir des solutions de repli (fallbacks) vers WebGL pour assurer une large compatibilité [2].

### Limites Matérielles
Même avec WebGPU, le rendu de 16 millions d'éléments interactifs simultanément peut saturer la mémoire vidéo (VRAM) ou la bande passante mémoire des GPU d'entrée de gamme ou mobiles. Des techniques de virtualisation et de niveau de détail (LOD) restent nécessaires [6].

## 5. Implications Directes pour l'Architecture de Données

Pour une interface gérant 16 777 216 couleurs, l'architecture de données doit être conçue pour minimiser les transferts entre le CPU et le GPU :
*   **Stockage GPU-Centric**: L'état des couleurs (position, sélection, propriétés) doit résider principalement dans des tampons de stockage (storage buffers) sur le GPU.
*   **Mises à jour par Compute Shaders**: Les opérations de filtrage, de tri ou de mise à jour de l'état doivent être effectuées par des shaders de calcul, évitant ainsi de rapatrier les données vers le CPU [4].
*   **Structures de Données Linéaires**: Les données doivent être organisées sous forme de tableaux plats (TypedArrays en JavaScript) pour correspondre à la disposition en mémoire attendue par les shaders [4].

## 6. Implications Directes pour une Interface Innovante

L'utilisation de WebGPU permet d'envisager des interfaces utilisateur radicalement nouvelles pour l'exploration des couleurs :
*   **Fluidité Inégalée**: La capacité de rendre et de mettre à jour des millions d'éléments à 60 FPS permet des interactions fluides (zoom, panoramique, filtrage en temps réel) sur l'ensemble de l'espace RGB.
*   **Visualisations Complexes**: Les shaders de calcul permettent de générer des visualisations dynamiques (par exemple, des regroupements par similarité, des projections 3D) à la volée.
*   **Interactivité Profonde**: Chaque couleur peut réagir individuellement aux actions de l'utilisateur sans ralentir l'interface globale, grâce à l'instanciation et au calcul parallèle.

## 7. Recommandations Concrètes

1.  **Adopter WebGPU comme API Principale**: Pour le rendu de 16 millions d'éléments, WebGPU est indispensable en raison de ses performances supérieures et de son support des shaders de calcul.
2.  **Utiliser l'Instanciation Massive**: Représenter chaque couleur comme une instance d'une géométrie simple (par exemple, un point ou un carré) pour minimiser les appels de dessin.
3.  **Implémenter la Logique d'Interaction via Compute Shaders**: Déplacer la logique de filtrage, de sélection et d'animation des couleurs du CPU vers des shaders de calcul sur le GPU.
4.  **Gérer l'État avec le Modèle Ping-Pong**: Utiliser deux tampons de stockage pour l'état des couleurs et alterner entre eux pour les mises à jour dynamiques, garantissant ainsi la cohérence des données.
5.  **Prévoir un Fallback WebGL**: Implémenter une version simplifiée (peut-être avec un sous-ensemble de couleurs ou des techniques de tuilage plus agressives) en WebGL pour les navigateurs ne supportant pas encore WebGPU.

## 8. Bibliographie

[1] Mozilla. (s.d.). *HTMLCanvasElement*. Consulté le 16 juillet 2026, de [https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement](https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement)
[2] Mozilla. (s.d.). *WebGPU API*. Consulté le 16 juillet 2026, de [https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API](https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API)
[3] Chrome for Developers. (2023, 19 septembre). *From WebGL to WebGPU*. Consulté le 16 juillet 2026, de [https://developer.chrome.com/docs/web-platform/webgpu/from-webgl-to-webgpu](https://developer.chrome.com/docs/web-platform/webgpu/from-webgl-to-webgpu)
[4] Google Codelabs. (s.d.). *Your first WebGPU app*. Consulté le 16 juillet 2026, de [https://codelabs.developers.google.com/your-first-webgpu-app](https://codelabs.developers.google.com/your-first-webgpu-app)
[5] Three.js Discourse. (2023, 29 juin). *Virtual Textures - Showcase*. Consulté le 16 juillet 2026, de [https://discourse.threejs.org/t/virtual-textures/53353](https://discourse.threejs.org/t/virtual-textures/53353)
[6] Surma. (2022, 8 mars). *WebGPU — All of the cores, none of the canvas*. Consulté le 16 juillet 2026, de [https://surma.dev/things/webgpu/](https://surma.dev/things/webgpu/)
[7] Figma. (2025, 18 septembre). *Figma Rendering: Powered by WebGPU*. Consulté le 16 juillet 2026, de [https://www.figma.com/blog/figma-rendering-powered-by-webgpu/](https://www.figma.com/blog/figma-rendering-powered-by-webgpu/)
