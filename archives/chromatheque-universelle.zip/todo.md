# Travaux — Chromathèque Universelle

- [x] Définir le périmètre scientifique : espace RGB 24 bits, sRGB, limites d’affichage, conversions CMJN et gestion des profils.
- [x] Définir les critères d’évaluation d’une innovation d’affichage : exhaustivité adressable, densité, fluidité, lisibilité, sérendipité, accessibilité et traçabilité.
- [x] Confirmer les axes exacts de recherche parallèle et lancer tous les sous-travaux en un seul lot.
- [x] Rechercher les standards et corpus de couleurs nommées du Web et de l’informatique.
- [x] Rechercher les espaces perceptuels, distances colorimétriques et limites du RGB/CMJN.
- [x] Rechercher les techniques de visualisation de très grands espaces multidimensionnels.
- [x] Rechercher les modes de rendu performants côté navigateur pour des millions d’éléments adressables.
- [x] Rechercher les couleurs historiques, pigments disparus, appellations rares et couleurs retirées de standards.
- [x] Rechercher les enjeux d’accessibilité, de daltonisme et de gestion des couleurs par écran.
- [x] Rechercher les questions de provenance, de propriété intellectuelle et de normalisation des noms de couleurs.
- [x] Comparer plusieurs concepts d’interface et formaliser une matrice de décision pondérée.
- [x] Retenir et spécifier un paradigme innovant d’exploration des 16 777 216 couleurs.
- [x] Construire un modèle de données distinguant valeurs calculées, noms attestés, alias, sources et niveaux de confiance.
- [x] Rédiger un rapport ultra-complet en français avec citations et bibliographie.
- [x] Créer les schémas et visualisations déterministes nécessaires au rapport.
- [x] Rédiger les orientations de design de l’application dans ideas.md.
- [x] Concevoir ou générer les ressources visuelles et le symbole de marque.
- [x] Implémenter l’interface de navigation chromatique recommandée.
- [x] Vérifier la compilation, l’exactitude des conversions et les performances.
- [x] Vérifier l’interface sur ordinateur et mobile, puis appliquer la revue esthétique.
- [x] Créer le checkpoint final et livrer le rapport, ses annexes et l’application.

## Comparaison Chromaverse

- [x] Examiner visuellement et fonctionnellement le site Chromaverse fourni par l’utilisateur.
- [x] Relever sa proposition de valeur, ses mécanismes d’exploration et son niveau de couverture des couleurs.
- [x] Comparer son modèle d’affichage, ses données et ses usages avec le Chromatome.
- [x] Identifier les doublons, les complémentarités et les éventuelles contradictions.
- [x] Expliquer simplement la différence et recommander de conserver, fusionner ou repositionner les deux projets.

## Fusion et atelier de broderie

- [x] Auditer les composants actuels et définir les routes de la version fusionnée.
- [x] Rechercher les sources officielles ou reconnues pour le nuancier DMC et documenter leurs limites d’usage.
- [x] Établir un corpus traçable des références DMC disponibles sans inventer de codes, noms ou équivalences.
- [x] Rechercher et structurer les familles mondiales de points de broderie par tradition, géométrie et usage.
- [x] Définir les formats de grille : carré, paysage, portrait, bannière et dimensions personnalisées.
- [x] Concevoir le modèle de motif : cellules, facettes, couches, points, couleurs, symboles et historique d’actions.
- [x] Intégrer un module Laboratoire issu des fonctions utiles de Chromaverse.
- [x] Développer la page Atelier avec grille interactive, zoom, déplacement, dessin, gomme et remplissage.
- [x] Ajouter les sélecteurs de formats, de densité et d’affichage des coordonnées.
- [x] Créer la palette d’outils des points de broderie avec aperçu et métadonnées.
- [x] Créer le nuancier DMC visible, recherchable et filtrable avec provenance affichée.
- [x] Relier chaque fil DMC à sa représentation sRGB indicative et signaler les limites écran/textile.
- [x] Permettre la sélection d’un fil et d’un point pour dessiner sur la grille.
- [x] Ajouter les statistiques du motif et une légende des fils et points utilisés.
- [x] Mettre à jour la documentation, les sources et les décisions de design.
- [x] Ajouter des tests déterministes du modèle de grille et du corpus.
- [x] Vérifier TypeScript, build, interactions desktop et mobile.
- [x] Réaliser la revue visuelle, appliquer les améliorations et créer un nouveau checkpoint.

## Page Atelier / Grille — livraison dédiée

- [x] Définir le modèle TypeScript des formats, marques, points, fils et statistiques.
- [x] Constituer un corpus DMC intégré limité aux références traçables disponibles, avec statut indicatif des couleurs écran.
- [x] Constituer une bibliothèque initiale de points par familles et géométries avec sources.
- [x] Développer le moteur d’état de la grille avec dessin, gomme, remplissage, annulation et rétablissement.
- [x] Construire le sélecteur de formats carré, portrait, paysage, bannière et personnalisé.
- [x] Construire la palette visible des fils DMC avec recherche et filtre.
- [x] Construire la palette des points avec symboles et aperçus originaux.
- [x] Afficher la légende et les statistiques calculées depuis le motif.
- [x] Ajouter la route `/atelier` et les liens de navigation depuis l’accueil.
- [x] Étendre le système visuel Atlas cinétique à la page de grille.
- [x] Ajouter les tests du moteur de motif et valider TypeScript et le build.
- [x] Vérifier la page sur ordinateur et mobile, corriger l’ergonomie puis sauvegarder un checkpoint.

## Correctif « Asset failed »

- [x] Localiser toute occurrence textuelle, image cassée ou fallback de ressource autour du Chromatome.
- [x] Identifier l’URL ou le composant à l’origine du texte semi-transparent.
- [x] Remplacer la ressource défaillante ou supprimer son texte de remplacement visible.
- [x] Ajouter un fallback silencieux et cohérent si la ressource externe échoue de nouveau.
- [x] Vérifier l’accueil sur ordinateur et mobile, puis valider TypeScript et le build.
- [x] Sauvegarder et livrer le correctif dans un nouveau checkpoint.

## Refonte Atelier — « Framer de la broderie »

- [x] Supprimer le manifeste éditorial et faire démarrer l’Atelier directement dans le cockpit.
- [x] Remplacer les fonds à lignes ou contours gris par un fond blanc uni.
- [x] Recomposer la page en barre d’application, ruban de points, canevas central et ruban DMC inférieur.
- [x] Déplacer la bibliothèque des points dans un carrousel horizontal supérieur toujours visible.
- [x] Déplacer les 456 références DMC dans un tiroir horizontal inférieur recherchable.
- [x] Regrouper formats, géométrie, outils, zoom et historique dans une barre compacte autour du canevas.
- [x] Garder la grille dominante et augmenter sa surface utile dans le premier écran.
- [x] Adapter les rubans horizontaux au clavier, au tactile et aux petits écrans.
- [x] Préserver les badges de provenance sans alourdir l’interface de création.
- [x] Valider TypeScript, tests, build et interactions principales.
- [x] Vérifier visuellement la page sur ordinateur et mobile, puis créer un checkpoint.

## Extension Atelier et identité — impression, persistance et navigation

- [x] Générer et intégrer un visuel héro futuriste consacré à la broderie, cohérent avec l’Atlas cinétique.
- [x] Remplacer le logotype textuel Chromathèque dans l’en-tête principal par un symbole graphique accessible et lisible.
- [x] Ajouter un export PDF multipage avec découpage automatique des grands patrons, chevauchement, repères de page et vue d’ensemble.
- [x] Ajouter une commande d’impression explicite et vérifier le téléchargement d’un document multipage.
- [x] Sauvegarder automatiquement le titre, le format, la géométrie, les sélections et le motif dans `localStorage` avec restauration au chargement.
- [x] Afficher un état de sauvegarde discret et prévoir une récupération robuste des données invalides ou anciennes.
- [x] Ajouter un mini-plan interactif représentant le patron, la fenêtre visible et permettant le recentrage par clic ou glisser.
- [x] Vérifier TypeScript, la construction de production et les interactions principales sur ordinateur et mobile.
- [x] Mettre à jour `ideas.md`, créer un checkpoint final et publier la version validée.

## Générateur de patrons, projets multiples et impression avancée

- [x] Définir les limites de la notion de « source de vérité » : provenance conservée, conversion déterministe, paramètres visibles et résultat toujours éditable.
- [x] Ajouter une section Atelier sur l’accueil avec prompt, import d’image et import PDF, plus confirmation des droits d’utilisation.
- [x] Préparer le stockage sécurisé des fichiers importés et la génération assistée côté serveur.
- [x] Convertir une image importée en grille de cellules avec dimensions, palette DMC indicative et symboles.
- [x] Extraire une page PDF en image de travail puis permettre le choix explicite de la page pertinente.
- [x] Nettoyer les confettis isolés selon un seuil réglable sans masquer les transformations appliquées.
- [x] Relier un prompt de création à un patron généré puis converti en grille Atelier.
- [x] Transférer le résultat vers l’Atelier avec source, paramètres de conversion et avertissements de fidélité.
- [x] Ajouter un panneau de projets permettant de créer, charger, renommer et supprimer plusieurs sauvegardes locales.
- [x] Ajouter les paramètres d’impression : format de page, orientation et chevauchement.
- [x] Adapter le moteur PDF multipage aux paramètres choisis et afficher le nombre de feuilles avant export.
- [x] Ajouter une animation subtile au héros et un effet de survol accessible au symbole de marque.
- [x] Vérifier les imports, la conversion, les sauvegardes, l’impression, l’accessibilité, le responsive, TypeScript et le build.
- [x] Mettre à jour la documentation de design, créer un checkpoint et publier la version validée.
- [x] Préserver un mode local complet sans connexion, avec conversion et bibliothèque de projets dans le navigateur.
- [x] Ajouter un mode connecté synchronisant projets, sources, versions et réglages d’impression entre appareils.
- [x] Permettre la migration volontaire d’un projet local vers la bibliothèque synchronisée sans supprimer l’original local.
