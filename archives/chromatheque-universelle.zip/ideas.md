# Orientations de design — Chromathèque Universelle

## Trois directions envisagées

### 1. Atlas cinétique

**Theme Name** : Atlas cinétique  
**Very Brief Intro** : Une cartographie scientifique contemporaine, mêlant précision éditoriale, repères topographiques et mouvement spatial. L’interface donne l’impression d’explorer un territoire calculé plutôt que de parcourir un catalogue.  
**Probability** : 0,03

### 2. Cabinet spectral

**Theme Name** : Cabinet spectral  
**Very Brief Intro** : Un cabinet de curiosités numérique sombre, tactile et muséal, où les couleurs documentées apparaissent comme des spécimens précieux. L’atmosphère valorise la chasse historique mais pourrait réduire la neutralité nécessaire à l’analyse des teintes.  
**Probability** : 0,07

### 3. Folio chromatique

**Theme Name** : Folio chromatique  
**Very Brief Intro** : Un système éditorial lumineux inspiré des atlas imprimés, des tables scientifiques et de la presse culturelle. Il est très lisible, mais moins apte à matérialiser la profondeur récursive des seize millions d’adresses.  
**Probability** : 0,02

## Approche retenue : Atlas cinétique

### Design Movement

L’interface s’inscrit dans un **néo-modernisme cartographique** : rigueur du modernisme suisse, densité contrôlée des atlas scientifiques, repères de cartographie topographique et micro-interactions spatiales contemporaines. Elle évite l’esthétique générique du tableau de bord, les cartes uniformément arrondies et les gradients décoratifs sans fonction.

### Core Principles

1. **La couleur explorée est le sujet, jamais le décor** : le chrome de l’application reste stable, neutre et contrasté afin que chaque nuance soit jugée dans un environnement constant.
2. **Toute profondeur doit rester orientée** : fil d’Ariane octal, plages RVB, échelle, boussole de canaux et retour au niveau parent accompagnent chaque zoom.
3. **La densité devient lisible par couches** : l’adresse, la perception et le document se révèlent progressivement plutôt que d’être empilés simultanément.
4. **La preuve est visible** : chaque nom, récit ou approximation est associé à un statut, une source et une relation explicite.

### Color Philosophy

Le fond principal est un **ivoire minéral** légèrement chaud, choisi pour réduire la fatigue et rappeler le papier d’un atlas sans jaunir les échantillons. Le graphite bleuté fournit une base textuelle stable. La couleur de marque est un **vert oxydé profond**, distinctif mais suffisamment contenu pour ne pas rivaliser avec l’espace chromatique. Les couleurs vives n’apparaissent que dans les données, la carte et la sélection. Les alertes utilisent aussi forme, icône et libellé afin de ne jamais dépendre uniquement de la couleur.

Palette directrice : ivoire `#F2F0E8`, graphite `#17211F`, graphite secondaire `#59605D`, vert oxydé `#0E7C66`, cuivre documentaire `#B66A3C`, blanc minéral `#FBFAF5`.

### Layout Paradigm

La structure adopte un **plan de travail asymétrique à trois bandes** : rail vertical de navigation et d’indices à gauche, territoire Chromatome central dominant, fiche technique coulissante à droite. Le sommet n’est pas une barre de navigation traditionnelle mais une ligne d’instrumentation compacte contenant identité, recherche et compteur. Sur mobile, le territoire reste prioritaire, le rail devient une barre basse et la fiche un tiroir. La page de rapport utilise une composition éditoriale en marge, avec sommaire collant et colonne de lecture.

### Signature Elements

1. **Les lignes isochromatiques** : fins filets de repère, graduations, croisillons et coordonnées qui donnent au territoire une matérialité cartographique.
2. **L’adresse octale vivante** : huit cellules numérotées qui se remplissent au fil du parcours, chaque chiffre montrant les bits R/V/B associés.
3. **Les balises de preuve** : symboles géométriques différenciant norme, archive, mesure et controverse, avec un contour qui encode le niveau de confiance.

### Interaction Philosophy

Les interactions sont instrumentales, directes et réversibles. Survoler prévisualise sans changer l’état ; cliquer ou valider au clavier engage un niveau ; `Échap` ou la flèche de retour remonte. Chaque action importante met à jour simultanément l’adresse, les intervalles et la fiche. La recherche directe et le parcours spatial sont strictement équivalents : aucun mode n’est une impasse.

### Animation

Les changements de niveau utilisent une transition de 220 à 280 ms où la tuile sélectionnée s’étend par transformation tandis que les autres s’effacent. Les panneaux apparaissent depuis leur origine avec `cubic-bezier(0.23, 1, 0.32, 1)`. Les survols restent inférieurs à 160 ms. Les commandes clavier sont instantanées. Aucune largeur ou hauteur n’est animée ; seuls transformation et opacité le sont. `prefers-reduced-motion` supprime les transitions spatiales non essentielles.

### Typography System

**Fraunces** est réservé aux grands titres, aux citations et à la dimension patrimoniale ; ses formes expressives créent une identité éditoriale. **IBM Plex Sans** structure les commandes, textes et libellés. **IBM Plex Mono** affiche Hex, RVB, adresses, intervalles et mesures. Les titres ne sont pas tous massifs : l’échelle repose sur le contraste entre sérif éditoriale, grotesque condensée par le poids et données monospaces. Les chiffres utilisent des variantes tabulaires lorsque disponibles.

### Brand Essence

**La carte scientifique et culturelle de chaque adresse chromatique du Web, conçue pour les créateurs, chercheurs et curieux qui veulent explorer sans confondre code, perception et histoire.**

Personnalité : **rigoureuse, exploratoire, cultivée**.

### Brand Voice

Les titres sont courts, affirmatifs et précis. Les appels à l’action emploient des verbes d’exploration ou d’enquête, jamais une promesse vague. Les microcopies expliquent ce que le système calcule et ce qu’il ne prétend pas prouver.

Exemples : **« Huit décisions. Une couleur exacte. »** ; **« Suivre la trace documentaire »**.

### Wordmark & Logo

Le symbole est un **cube impossible ouvert en huit cellules**, dont trois arêtes prolongées forment discrètement les axes R, V et B. La silhouette doit rester lisible à 24 px et fonctionner en monochrome. Le mot-symbole « Chromathèque » est composé avec une ligature personnalisée entre le `m` et le `a`, tandis que « Universelle » devient une légende monospacée alignée comme une coordonnée d’atlas. Le symbole ne contient aucun texte et sert de favicon.

### Signature Brand Color

**Vert Chromatome — `#0E7C66`**. Ce vert minéral évoque à la fois l’oxydation des pigments, le repère cartographique et l’instrument scientifique. Il est réservé à l’identité, aux états actifs et aux actions confirmées.

## Règle de cohérence

Avant toute décision visuelle ou fonctionnelle : **« Ce choix renforce-t-il ou dilue-t-il l’Atlas cinétique ? »** La carte doit rester dominante, l’orientation permanente, les données monospaces et la preuve documentaire immédiatement identifiable.

## Décisions de style

- Les sections éditoriales hors Chromatome conservent un vocabulaire cartographique visible — coordonnées, graduations, filets de mesure, légendes et balises — afin que toute la page demeure un atlas plutôt qu’une mise en page de magazine conventionnelle.
- Le symbole du cube impossible ouvert en huit cellules constitue un motif de système : il est agrandi dans l’identité et revient comme repère graphique discret dans les sections clés.
- Toute couleur vive hors échantillons est justifiée comme donnée, sélection, axe ou mesure ; aucun dégradé spectral n’est utilisé comme simple ambiance décorative.
- Les statuts documentaires forment une légende stable : **N** pour norme, **A** pour archive, **M** pour mesure et **C** pour controverse.

## Extension de design — Atelier / Grille

L’Atelier prolonge l’**Atlas cinétique** sous la forme d’un **cockpit de cartographie textile**. La grille occupe le territoire central et reprend les graduations, coordonnées et balises de preuve de l’atlas. Le rail gauche devient une réglette de format et d’outils ; le rail droit rassemble le fil actif, le point actif, la bibliothèque et la légende calculée.

La géométrie carrée reste le mode exact du point de croix, mais l’interface propose aussi des **facettes en losange** et des **alvéoles** pour préfigurer des broderies moins contraintes par l’angle droit. Les cellules ne sont pas décorées : elles montrent réellement le symbole du point et la couleur du fil sélectionné. Les couleurs DMC sont donc des données, jamais une ambiance.

Les cartes de fils n’imitent pas le nuancier officiel. Elles utilisent une mise en page originale, compacte et monospacée, avec code, nom, famille, pastille indicative et statut de provenance. La mention « écran indicatif » reste persistante. Les points sont représentés par un langage de signes original construit à partir de segments, croisements, boucles et ancrages ; aucune illustration externe protégée n’est reproduite.

L’Atelier reste lumineux autour du plan de travail, tandis que le canevas central adopte un graphite profond afin d’évoquer un écran d’instrument. Les commandes fréquentes sont instantanées, les palettes glissent en moins de 220 ms et la navigation clavier ne reçoit aucune animation retardatrice.

## Décisions de style — Atelier / revue finale

- Le héros de l’Atelier porte désormais une instrumentation cartographique visible : plan dynamique, origine, échelle, graduations et coordonnées calculées du canevas.
- Le cube ouvert de la Chromathèque devient un motif récurrent dans le héros, les en-têtes de bibliothèques, l’identité et les annotations du cockpit.
- Chaque surface de sélection expose une logique documentaire stable : **N** pour notice sourcée, **A** pour approximation calculée, **M** pour réalité matérielle et **C** pour entrée de corpus.
- Les références DMC sont traitées comme identifiants de corpus ; les valeurs Hex demeurent explicitement des approximations d’écran et renvoient vers une carte physique.

## Style Decisions — Atelier logiciel plein écran

L’Atelier abandonne sa longue introduction éditoriale au profit d’un **cockpit immédiat inspiré des logiciels de création comme Framer**. Le fond extérieur devient blanc uni, sans lignes de construction grises ni contours décoratifs. La grille constitue le territoire dominant dès le premier écran.

La hiérarchie fixe est désormais : barre d’application compacte, ruban horizontal des points de broderie, barre de contexte et d’outils, canevas central, puis tiroir horizontal des fils DMC. Les points et les fils se choisissent comme des outils de création, non comme des sections documentaires éloignées du geste. Les badges de preuve restent visibles, mais condensés dans les infobulles, les sélections actives et les notes de statut.

L’identité Atlas cinétique subsiste dans les coordonnées, l’échelle, les symboles et la précision typographique ; elle ne doit plus créer de bruit visuel autour du canevas. Le blanc est le plan de travail, le graphite structure les commandes et la couleur n’apparaît que comme donnée textile ou sélection active.

## Style Decisions — cockpit plein écran validé

- L’Atelier s’ouvre directement dans le logiciel : aucun manifeste ni bloc éditorial ne précède la grille.
- Les sections claires utilisent un blanc uni ; les lignes grises décoratives et les courbes de fond sont supprimées.
- Les points forment un ruban horizontal supérieur et les fils DMC un tiroir horizontal inférieur, afin de préserver la grille comme surface dominante.
- La grille reçoit uniquement des repères fonctionnels : origine 00:00, coordonnées, axes et traits majeurs tous les cinq points.
- La marque compacte réemploie un système ouvert de huit cellules et l’identifiant coordonné `U·24 / ATELIER·01`.
- Chaque point et chaque fil reste un spécimen documentaire : symbole ou code monospace et statut N ou A visibles dans les rubans.

## Style Decisions — instrumentation propriétaire de l’Atelier

- Le canevas ne doit jamais lire comme une simple zone blanche autour d’une grille : un cadre de coordonnées, des axes gradués, une échelle, l’origine et l’état de caméra forment un instrument continu, sans limiter le déplacement panoramique.
- Le ruban des points est une bande de spécimens documentaires numérotés, non un carrousel de cartes produit ; ses symboles, familles et preuves restent compacts, réglés et alignés.
- La marque octale doit être lisible comme un repère propriétaire dans l’en-tête et réapparaître par les identifiants `U·24`, `S·24` et `D·456` dans le cockpit.
- Les poignées de redimensionnement sont explicitement identifiables comme commandes de réglage, tout en restant visuellement subordonnées à la grille.
- L’Atlas cinétique s’exprime par la mesure et la preuve, non par des ornements : les lignes visibles dans le territoire correspondent à des axes, graduations, coordonnées ou mailles d’échelle.

## Extension identité et navigation — juillet 2026

- Le héros d’accueil adopte un **paysage de broderie futuriste** en graphite, émeraude et fil d’or : matière textile réelle à droite, réserve sombre pour la typographie à gauche.
- Le wordmark visible est remplacé par un **symbole octal tissé** sans texte, tandis que les identifiants `U·24` et `ATELIER·01` restent des métadonnées documentaires secondaires.
- Le mini-plan appartient au système d’instrumentation du canevas : cadre visible émeraude, coordonnées, échelle et navigation directe par clic ou glisser.
- La persistance locale doit rester discrète et vérifiable par un état `Sauvegardé`, sans interrompre le geste de création.
- L’impression multipage est traitée comme un dossier d’assemblage scientifique : plan général, feuilles coordonnées, chevauchements et légende finale.

## Extension générateur, projets et synchronisation — juillet 2026

- Le générateur est présenté comme un **poste d’entrée documentaire** plutôt qu’une boîte magique : prompt, image et PDF convergent vers le même aperçu déterministe avant toute application au canevas.
- L’attestation de droits précède chaque import. La source originale reste dans le navigateur par défaut ; sa présence locale, son nom, son type, sa taille et la page PDF choisie sont visibles dans la provenance du projet.
- La synchronisation cloud est une action volontaire distincte de l’autosauvegarde locale. Son libellé décrit le transfert de la source, et l’interface conserve simultanément le projet local afin de ne pas imposer un basculement irréversible.
- La bibliothèque sépare clairement **projets locaux** et **projets synchronisés** tout en gardant les mêmes commandes essentielles : créer, charger, renommer et supprimer.
- L’aperçu de conversion rend visibles la palette DMC indicative, les dimensions finales, le nombre de cellules et le bilan des confettis. L’utilisateur valide ensuite un résultat toujours éditable dans l’Atelier.
- Les réglages d’impression appartiennent au dossier technique du patron : format, orientation, taille de cellule, chevauchement et nombre de feuilles sont calculés avant l’export.
- Le mouvement de marque reste secondaire et non bloquant : dérive lente du textile, pulsation d’adresse et rotation de l’origine uniquement lorsque `prefers-reduced-motion` autorise le mouvement ; le symbole octal répond au survol, au focus et à l’activation sans masquer son libellé accessible.


## Laboratoire couleur — intégration Chromaverse

Le **Laboratoire L·24** reprend les fonctions opérationnelles utiles de Chromaverse sans créer un second univers visuel. La page conserve l’ivoire minéral, le graphite, le vert oxydé, la typographie éditoriale et la mesure monospacée de l’Atlas cinétique. Chaque couleur active est traitée comme un territoire adressable : l’Hex est associé à huit cellules octales, tandis que les harmonies portent leurs coordonnées RVB.

Les panneaux utilisent les statuts documentaires **A** pour une valeur calculée, **M** pour une mesure comparative et **C** pour une composition de canaux. Les conversions CMJN et les distances perceptuelles sont explicitement décrites comme indicatives : elles ne remplacent ni un profil ICC de destination ni une validation matérielle. Les exports CSS et JSON restent déterministes et directement reproductibles.

La composition responsive conserve la hiérarchie instrumentale sur petits écrans : spécimen actif, couleur analysée, harmonies, comparaison puis transparence. Les interactions utilisent des transitions courtes limitées à la transformation et à la couleur, avec neutralisation dans `prefers-reduced-motion`.
