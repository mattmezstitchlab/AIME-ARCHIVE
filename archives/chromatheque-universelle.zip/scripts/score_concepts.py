import csv
from pathlib import Path

import matplotlib.pyplot as plt

ROOT = Path('/home/ubuntu/chromatheque-universelle')
OUT = ROOT / 'research' / 'analysis'
OUT.mkdir(parents=True, exist_ok=True)

criteria = [
    ('Exhaustivité adressable', 0.20),
    ('Orientation et réversibilité', 0.15),
    ('Fluidité et sobriété technique', 0.15),
    ('Fidélité perceptuelle', 0.12),
    ('Découverte et sérendipité', 0.10),
    ('Lisibilité documentaire', 0.08),
    ('Accessibilité', 0.08),
    ('Extensibilité', 0.07),
    ('Export et reproductibilité', 0.05),
]

concepts = {
    'Cube RGB 3D navigable': [9, 5, 6, 3, 8, 5, 3, 7, 7],
    'Solide perceptuel OKLCH': [7, 6, 6, 9, 8, 5, 4, 8, 6],
    'Atlas de coupes 2D': [10, 8, 9, 5, 6, 8, 8, 8, 9],
    'Carte de Hilbert': [10, 6, 8, 4, 9, 6, 5, 7, 9],
    'Octree à zoom sémantique': [10, 9, 9, 5, 8, 8, 7, 9, 9],
    'Moteur de recherche tabulaire': [10, 9, 10, 4, 3, 10, 10, 10, 10],
    'Chromatome hybride': [10, 10, 9, 9, 10, 10, 9, 10, 10],
}

rationales = {
    'Cube RGB 3D navigable': 'Exact et spectaculaire, mais occlusions, désorientation, ciblage et accessibilité limitent l’usage quotidien.',
    'Solide perceptuel OKLCH': 'Très bon pour les voisinages ressentis, mais l’adressage exhaustif sRGB et l’orientation restent moins directs.',
    'Atlas de coupes 2D': 'Précis, performant et accessible ; moins distinctif et moins propice aux découvertes transversales.',
    'Carte de Hilbert': 'Exhaustive et dense, avec une forte signature visuelle ; l’ordre 1D crée toutefois des voisinages artificiels.',
    'Octree à zoom sémantique': 'Huit niveaux suffisent pour isoler une couleur exacte ; la proximité hiérarchique n’est pas perceptuelle.',
    'Moteur de recherche tabulaire': 'Excellent instrument documentaire et technique, mais faible comme espace d’exploration et de sérendipité.',
    'Chromatome hybride': 'Combine l’adresse octree exacte, les coupes perceptuelles, les balises documentaires et un moteur de recherche réversible.',
}

rows = []
for concept, scores in concepts.items():
    total = sum(score * weight for score, (_, weight) in zip(scores, criteria))
    row = {'Concept': concept, **{name: score for score, (name, _) in zip(scores, criteria)}, 'Score pondéré / 10': round(total, 2), 'Justification': rationales[concept]}
    rows.append(row)
rows.sort(key=lambda item: item['Score pondéré / 10'], reverse=True)

csv_path = OUT / 'matrice-concepts.csv'
with csv_path.open('w', encoding='utf-8', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

plt.style.use('seaborn-v0_8-whitegrid')
fig, ax = plt.subplots(figsize=(12, 7.2))
ordered = list(reversed(rows))
labels = [row['Concept'] for row in ordered]
values = [row['Score pondéré / 10'] for row in ordered]
colors = ['#315C55' if label == 'Chromatome hybride' else '#A8B7B2' for label in labels]
bars = ax.barh(labels, values, color=colors, height=0.62)
ax.set_xlim(0, 10)
ax.set_xlabel('Score pondéré sur 10', fontsize=11)
ax.set_title('Comparaison des paradigmes d’exploration de 16 777 216 couleurs', loc='left', fontsize=16, fontweight='bold', pad=18)
ax.text(0, 1.01, 'Neuf critères ; pondérations définies avant l’évaluation', transform=ax.transAxes, fontsize=10, color='#52605D')
for bar, value in zip(bars, values):
    ax.text(value + 0.12, bar.get_y() + bar.get_height()/2, f'{value:.2f}', va='center', fontsize=10, fontweight='bold')
ax.spines[['top', 'right', 'left']].set_visible(False)
ax.tick_params(axis='y', length=0)
fig.tight_layout()
chart_path = OUT / 'comparaison-concepts.png'
fig.savefig(chart_path, dpi=220, bbox_inches='tight', facecolor='#F7F4ED')
plt.close(fig)

md_path = OUT / 'matrice-concepts.md'
with md_path.open('w', encoding='utf-8') as handle:
    handle.write('# Matrice de décision des concepts\n\n')
    handle.write('Les notes vont de 1 à 10. Elles constituent une évaluation de conception argumentée, non une mesure expérimentale. Les pondérations ont été fixées dans `cadrage-et-criteres.md` avant la notation.\n\n')
    handle.write('| Rang | Concept | Score pondéré / 10 | Justification synthétique |\n')
    handle.write('|---:|---|---:|---|\n')
    for rank, row in enumerate(rows, start=1):
        handle.write(f"| {rank} | **{row['Concept']}** | {row['Score pondéré / 10']:.2f} | {row['Justification']} |\n")
    handle.write('\n## Définition du concept gagnant\n\n')
    handle.write('Le **Chromatome hybride** représente les 24 bits d’une couleur comme un parcours de huit décisions octales. À chaque niveau, le volume RGB est divisé simultanément en deux sur chacun de ses trois axes, soit huit sous-volumes. Après huit niveaux, le parcours désigne exactement un triplet RGB. La carte 2D récursive affiche uniquement les tuiles du niveau utile, tandis qu’une lentille OKLCH/Oklab révèle les voisins perceptuels et qu’une couche documentaire signale les couleurs nommées, historiques ou retirées.\n\n')
    handle.write('Cette architecture n’affirme pas que la proximité dans l’octree soit perceptuelle. Elle utilise l’octree pour l’**adresse exacte et le zoom**, puis un espace perceptuel distinct pour la **comparaison des apparences**. Cette séparation est le cœur scientifique de l’innovation.\n')

print(csv_path)
print(chart_path)
print(md_path)
