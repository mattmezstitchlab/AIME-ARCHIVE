import json
import re
import urllib.request
from pathlib import Path

INDEX = Path('/home/ubuntu/recherche_chromatheque_universelle.json')
OUT = Path('/home/ubuntu/chromatheque-universelle/research')
OUT.mkdir(parents=True, exist_ok=True)

def slugify(text: str) -> str:
    replacements = str.maketrans('àâäéèêëîïôöùûüÿçœæ', 'aaaeeeeiioouuuycoe')
    value = text.lower().translate(replacements)
    value = re.sub(r'[^a-z0-9]+', '-', value).strip('-')
    return value[:72]

with INDEX.open('r', encoding='utf-8') as handle:
    data = json.load(handle)

manifest = []
for number, item in enumerate(data['results'], start=1):
    output = item['output']
    filename = f"{number:02d}-{slugify(output['axe'])}.md"
    destination = OUT / filename
    urllib.request.urlretrieve(output['rapport_file'], destination)
    manifest.append({
        'id': number,
        'axe': output['axe'],
        'resume': output['resume'],
        'recommandation_cle': output['recommandation_cle'],
        'confiance': output['confiance'],
        'fichier': str(destination),
    })

with (OUT / 'manifest.json').open('w', encoding='utf-8') as handle:
    json.dump(manifest, handle, ensure_ascii=False, indent=2)

print(f"Téléchargés : {len(manifest)} rapports dans {OUT}")
