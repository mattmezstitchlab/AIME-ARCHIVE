import csv
import json
from pathlib import Path

root = Path('/home/ubuntu/chromatheque-universelle')
source = root / 'research/dmc-colorcodes/result.csv'
target = root / 'client/src/data/dmcThreads.ts'

rows = []
with source.open(encoding='utf-8-sig', newline='') as handle:
    reader = csv.DictReader(handle)
    for row in reader:
        code = (row.get('DMC_COLOR') or '').strip()
        name = (row.get(' COLOR_NAME') or row.get('COLOR_NAME') or '').strip()
        hex_value = (row.get(' RGB_COLOR') or row.get('RGB_COLOR') or '').strip().upper()
        if not code or not name or not hex_value:
            continue
        rows.append({'code': code, 'name': name, 'hex': hex_value})

rows.sort(key=lambda item: (not item['code'].isdigit(), int(item['code']) if item['code'].isdigit() else 10**9, item['code']))

header = '''// Atlas cinétique — corpus DMC secondaire : codes et noms issus du dépôt public nathantspencer/DMC-ColorCodes ; couleurs écran indicatives, non officielles.\n\nexport type DmcThread = {\n  code: string;\n  name: string;\n  hex: string;\n  family: "Mouliné spécial — index secondaire";\n  confidence: "secondary";\n  sourceUrl: string;\n};\n\nexport const DMC_SOURCE = {\n  label: "nathantspencer/DMC-ColorCodes — extraction secondaire",\n  url: "https://github.com/nathantspencer/DMC-ColorCodes",\n  officialCardUrl: "https://www.dmc.com/US/en/products/floss-color-card-mouline-pearl-cotton",\n  note: "Les codes et noms sont un index de travail. Les valeurs Hex sont des approximations écran non officielles ; le nuancier physique à échantillons reste la référence pratique.",\n} as const;\n\n'''

items = []
for row in rows:
    items.append(
        '  { code: %s, name: %s, hex: %s, family: "Mouliné spécial — index secondaire", confidence: "secondary", sourceUrl: DMC_SOURCE.url },'
        % (json.dumps(row['code'], ensure_ascii=False), json.dumps(row['name'], ensure_ascii=False), json.dumps(row['hex'], ensure_ascii=False))
    )

body = 'export const dmcThreads: DmcThread[] = [\n' + '\n'.join(items) + '\n];\n'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(header + body, encoding='utf-8')
print(f'Generated {len(rows)} DMC entries at {target}')
