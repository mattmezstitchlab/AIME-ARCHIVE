# Validation — extension Atelier et identité

## Impression multipage

Le patron de contrôle `60 × 60` produit un document PDF A4 paysage de **6 pages** : un plan d’assemblage, quatre feuilles de patron et une légende finale. Le plan d’assemblage identifie clairement les feuilles `01–04`, montre leur position relative et précise le chevauchement de deux facettes entre tuiles. Les feuilles de patron conservent les coordonnées globales sur leurs axes, les lignes maîtresses et les repères d’assemblage dans les angles. La légende finale relie le symbole, le code DMC, le nom du fil et le point utilisé.

## Sauvegarde locale

Un point ajouté dans la première cellule a été automatiquement enregistré, puis restauré après un rechargement complet de la route `/atelier`. L’indicateur est revenu à l’état `Sauvegardé` après le délai d’écriture.

## Mini-plan

À `110 %`, le mini-plan affiche le cadre visible et les coordonnées de son centre. Un déplacement clavier réel avec `ArrowDown` a fait passer la caméra de `0:0` à `0:-47`, et le centre affiché de `X 12 / Y 12` à `X 12 / Y 13`, confirmant le recentrage interactif. Le mini-plan est focalisable, utilisable par clic, glisser, flèches, `Maj + flèche` et `Origine`.

## Identité

L’accueil utilise un panorama sombre de broderie futuriste avec superposition de coordonnées, origine, adresse octale et échelle. Le wordmark visible a été remplacé par le symbole octal nettoyé dans les en-têtes et le pied de page, avec libellés accessibles conservés.

## Générateur, bibliothèque et impression avancée

Le parcours local d’import d’image a été vérifié de bout en bout : l’attestation de droits bloque correctement la transmission, la source passe par IndexedDB sans téléversement automatique, puis l’Atelier affiche l’aperçu, la palette DMC indicative et le bilan des confettis avant toute application. Après validation, le motif devient un projet local éditable et est restauré au rechargement.

Le registre affiche plusieurs projets locaux persistés avec les commandes de création, renommage et suppression. Le volet synchronisé reste clairement séparé en l’absence de session, et la génération par prompt ainsi que la synchronisation déclenchent le flux de connexion attendu.

Le panneau d’impression expose les formats A4, A3 et Letter, les orientations automatique, portrait et paysage, le chevauchement et la taille de case. Sur le patron de contrôle `60 × 60`, les changements de paramètres recalculent immédiatement le nombre de feuilles avant export.

Le registre local a également été exercé avec un projet temporaire : la création a fait passer le compteur de deux à trois après le délai normal d’autosauvegarde, le renommage a été reflété immédiatement, puis la suppression confirmée a ramené le registre à ses deux projets utiles. Aucun patron de contrôle supplémentaire n’a été conservé.

## Synchronisation sécurisée et revalidation finale

La synchronisation volontaire téléverse désormais la source locale durable depuis IndexedDB vers S3 avant d’enregistrer le projet distant. Les types acceptés sont limités à PNG, JPEG, WebP et PDF, la taille est plafonnée à 12 Mo côté routeur, et le document synchronisé conserve la clé, l’URL de stockage, le type MIME, la taille, la page PDF, l’attestation de droits et la liste des transformations. La source reste locale tant que l’utilisateur ne choisit pas explicitement `Synchroniser`.

La base a été migrée avec succès pour ajouter la colonne JSON `provenance` aux tables `pattern_projects` et `pattern_project_versions`. Le chargement cloud privilégie cette provenance complète et conserve un repli compatible avec les lignes historiques antérieures à la migration.

La validation automatisée du 17 juillet 2026 a réussi sans erreur : `pnpm check`, **20 tests Vitest sur 4 fichiers**, puis `pnpm build`. Un test dédié vérifie que la référence S3, le type MIME PDF, la page source, l’attestation et les transformations survivent à la validation du contrat synchronisé.

Les captures plein écran de l’accueil et de `/atelier` confirment la présence de la section générateur, du cockpit, du compteur de projets, du mini-plan et des commandes d’export dans l’identité Atlas cinétique. Les requêtes `auth.me` et `patterns.list` ont répondu en HTTP 200 dans la session de prévisualisation connectée ; le navigateur externe isolé est resté non authentifié, de sorte qu’aucun téléversement réel de fichier utilisateur n’a été déclenché pendant cette passe. Cette limitation évite tout effet de bord sur un compte réel et ne remet pas en cause les tests du contrat, la migration ni les contrôles serveur.

La suppression locale d’un projet appelle explicitement `deleteProjectSource(clientId)` après la mise à jour de la bibliothèque, ce qui retire également le fichier source durable de l’IndexedDB du navigateur. La suppression d’un enregistrement synchronisé supprime ses données de base et ses versions ; l’objet S3 n’est pas effacé automatiquement par l’API de stockage disponible et peut donc rester orphelin côté stockage interne.


## Validation du Laboratoire L·24 — 17 juillet 2026

Le dernier module issu de Chromaverse est désormais intégré à la route publique `/laboratoire`. Il réunit l’analyse RVB, HSL, OKLCH et CMJN indicative, quatre constructions d’harmonie, la comparaison par contraste WCAG et ΔE 1976, la composition alpha et les exports CSS ou JSON. La couleur active conserve son adresse octale en huit cellules et les modules affichent les statuts de preuve A, M et C.

La validation automatisée finale a exécuté `pnpm check`, `pnpm test` et `pnpm build` avec succès. Les **5 fichiers de test et 25 tests** sont passés, dont cinq tests déterministes propres au Laboratoire. La construction de production a abouti ; elle conserve uniquement l’avertissement connu de taille des bundles Vite et la résolution différée normale des ressources `/manus-storage/`.

Les captures pleine page ont vérifié `/laboratoire` en **1440 × 900** et **390 × 844**. La navigation, l’adresse segmentée, les panneaux analytiques, les palettes, les métriques, le curseur de transparence et le pied de page restent lisibles et ordonnés sur les deux formats. Les journaux récents n’ont montré aucune erreur applicative liée à cette route.
