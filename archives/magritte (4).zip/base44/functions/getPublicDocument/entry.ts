import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

Deno.serve(async (req) => {
  try {
    const { id } = await req.json();
    if (!id || typeof id !== 'string') {
      return Response.json({ error: 'Document introuvable' }, { status: 404 });
    }
    // Public endpoint: the unguessable document id acts as the share token.
    // Clients (not registered users) open their quote/invoice via this link.
    const base44 = createClientFromRequest(req);
    const doc = await base44.asServiceRole.entities.Document.get(id);
    if (!doc) {
      return Response.json({ error: 'Document introuvable' }, { status: 404 });
    }
    return Response.json({ document: doc });
  } catch (error) {
    return Response.json({ error: 'Document introuvable' }, { status: 404 });
  }
});