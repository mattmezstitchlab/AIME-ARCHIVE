import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const token = String(body.token || "");
    if (!/^[a-f0-9]{32,128}$/i.test(token)) return Response.json({ error: "Lien invalide" }, { status: 400 });
    const guests = await base44.asServiceRole.entities.WeddingGuest.filter({ access_token: token }, "-created_date", 1);
    const guest = guests[0];
    if (!guest) return Response.json({ error: "Invitation introuvable" }, { status: 404 });
    if (body.action === "respond") {
      if (!["confirme", "decline"].includes(body.rsvp_status)) return Response.json({ error: "Réponse invalide" }, { status: 400 });
      await base44.asServiceRole.entities.WeddingGuest.update(guest.id, {
        rsvp_status: body.rsvp_status,
        meal_preference: String(body.meal_preference || "").slice(0, 200),
        response_note: String(body.response_note || "").slice(0, 500),
        responded_at: new Date().toISOString()
      });
    }
    const profiles = guest.wedding_profile_id ? await base44.asServiceRole.entities.WeddingProfile.filter({ id: guest.wedding_profile_id }, "-created_date", 1) : [];
    const profile = profiles[0];
    if (body.action === "respond" && profile?.created_by_id) {
      await base44.asServiceRole.entities.CoordinationNotification.create({ recipient_user_id: profile.created_by_id, wedding_profile_id: profile.id, type: "rsvp", title: `Réponse de ${guest.full_name}`, message: body.rsvp_status === "confirme" ? `${guest.full_name} confirme sa présence.` : `${guest.full_name} ne pourra pas être présent·e.`, source_id: guest.id, read: false });
    }
    return Response.json({ guest: { full_name: guest.full_name, party_size: guest.party_size || 1, rsvp_status: body.action === "respond" ? body.rsvp_status : guest.rsvp_status, meal_preference: body.action === "respond" ? String(body.meal_preference || "") : guest.meal_preference || "" }, wedding: profile ? { partner_one: profile.partner_one, partner_two: profile.partner_two, wedding_date: profile.wedding_date, location: profile.location } : null });
  } catch (error) {
    console.error("guestRsvp error", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}