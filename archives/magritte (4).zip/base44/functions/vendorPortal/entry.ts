import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req), body = await req.json(), token = String(body.token || "");
    let notificationType = "", notificationMessage = "";
    if (!/^[a-f0-9]{32,128}$/i.test(token)) return Response.json({ error: "Lien invalide" }, { status: 400 });
    const vendors = await base44.asServiceRole.entities.WeddingVendor.filter({ access_token: token }, "-created_date", 1), vendor = vendors[0];
    if (!vendor) return Response.json({ error: "Accès introuvable" }, { status: 404 });
    if (body.action === "updateNotes") {
      if (!["contribution", "regie"].includes(vendor.access_level)) return Response.json({ error: "Accès lecture seule" }, { status: 403 });
      await base44.asServiceRole.entities.WeddingVendor.update(vendor.id, { notes: String(body.notes || "").slice(0, 2000) });
      vendor.notes = String(body.notes || "").slice(0, 2000);
      notificationType = "vendor_note";
      notificationMessage = `${vendor.name} a mis à jour sa note de coordination.`;
    }
    if (body.action === "updateTimeline") {
      if (vendor.access_level !== "regie") return Response.json({ error: "Accès régie requis" }, { status: 403 });
      const allowed = ["a_venir", "confirme", "en_cours", "termine", "retard"];
      if (!allowed.includes(body.status)) return Response.json({ error: "Statut invalide" }, { status: 400 });
      const items = await base44.asServiceRole.entities.TimelineItem.filter({ id: String(body.item_id || ""), wedding_profile_id: vendor.wedding_profile_id }, "-created_date", 1);
      if (!items[0]) return Response.json({ error: "Étape introuvable" }, { status: 404 });
      await base44.asServiceRole.entities.TimelineItem.update(items[0].id, { status: body.status });
      notificationType = "timeline";
      notificationMessage = `${vendor.name} a passé « ${items[0].title} » au statut ${body.status.replaceAll("_", " ")}.`;
    }
    const profiles = vendor.wedding_profile_id ? await base44.asServiceRole.entities.WeddingProfile.filter({ id: vendor.wedding_profile_id }, "-created_date", 1) : [];
    if (notificationType && profiles[0]?.created_by_id) {
      await base44.asServiceRole.entities.CoordinationNotification.create({ recipient_user_id: profiles[0].created_by_id, wedding_profile_id: profiles[0].id, type: notificationType, title: vendor.name, message: notificationMessage, source_id: vendor.id, read: false });
    }
    const timeline = vendor.wedding_profile_id ? await base44.asServiceRole.entities.TimelineItem.filter({ wedding_profile_id: vendor.wedding_profile_id }, "scheduled_at", 100) : [];
    return Response.json({ vendor: { name: vendor.name, category: vendor.category, access_level: vendor.access_level, notes: vendor.notes || "" }, wedding: profiles[0] ? { partner_one: profiles[0].partner_one, partner_two: profiles[0].partner_two, wedding_date: profiles[0].wedding_date, location: profiles[0].location } : null, timeline: timeline.map((item) => ({ id: item.id, title: item.title, scheduled_at: item.scheduled_at, duration_minutes: item.duration_minutes, status: item.status, responsible: item.responsible, notes: item.notes })) });
  } catch (error) {
    console.error("vendorPortal error", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}