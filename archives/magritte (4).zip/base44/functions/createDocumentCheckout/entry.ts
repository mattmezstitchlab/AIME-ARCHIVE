import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import Stripe from 'npm:stripe@17.7.0';

Deno.serve(async (req) => {
  try {
    // Public app: clients paying a quote/invoice are not registered users.
    const { documentId, paymentType, origin } = await req.json();
    if (!documentId || !['deposit', 'full'].includes(paymentType)) {
      return Response.json({ error: 'Requête invalide' }, { status: 400 });
    }
    const base44 = createClientFromRequest(req);
    const doc = await base44.asServiceRole.entities.Document.get(documentId);
    if (!doc) return Response.json({ error: 'Document introuvable' }, { status: 404 });
    if (doc.status === 'paye') return Response.json({ error: 'Ce document est déjà réglé.' }, { status: 400 });

    const total = Number(doc.total) || 0;
    const deposit = Number(doc.deposit_amount) || 0;
    let amount, label;
    if (paymentType === 'deposit') {
      if (deposit <= 0 || doc.status === 'acompte_paye') {
        return Response.json({ error: 'Acompte non disponible pour ce document.' }, { status: 400 });
      }
      amount = deposit;
      label = `Acompte — ${doc.doc_type} ${doc.number || ''}`.trim();
    } else {
      amount = doc.status === 'acompte_paye' ? total - deposit : total;
      label = `Règlement — ${doc.doc_type} ${doc.number || ''}`.trim();
    }
    if (!amount || amount <= 0) {
      return Response.json({ error: 'Montant invalide.' }, { status: 400 });
    }

    const baseUrl = origin || req.headers.get('origin') || '';
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'eur',
          product_data: { name: label },
          unit_amount: Math.round(amount * 100),
        },
        quantity: 1,
      }],
      customer_email: doc.client_email || undefined,
      success_url: `${baseUrl}/document/${documentId}?paiement=succes`,
      cancel_url: `${baseUrl}/document/${documentId}`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        document_id: documentId,
        payment_type: paymentType,
      },
    });
    return Response.json({ url: session.url });
  } catch (error) {
    console.error('createDocumentCheckout error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});