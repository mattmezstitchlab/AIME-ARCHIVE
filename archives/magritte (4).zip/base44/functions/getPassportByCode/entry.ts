import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const classification = (item) => {
      const presets = {
        "matt-mez-fondateur": { subject_type: "person", taxonomy_path: "Personne / Professionnel / Fondateur" },
        "matt-mez": { subject_type: "person", taxonomy_path: "Personne / Professionnel / Musicien" },
        "matt-mez-graphiste": { subject_type: "person", taxonomy_path: "Personne / Professionnel / Designer graphique" },
        "aime-studio": { subject_type: "organization", taxonomy_path: "Organisation / Entreprise / Studio créatif" },
        "le-monde-aime": { subject_type: "organization", taxonomy_path: "Organisation / Association" }
      };
      const preset = presets[item.provider_slug] || {};
      return { subject_type: item.subject_type || preset.subject_type || "person", taxonomy_path: item.taxonomy_path || preset.taxonomy_path || item.profession };
    };
    if (body.founder_collection === true) {
      const active = await base44.asServiceRole.entities.Passport.filter({ status: "actif" }, "created_date", 200);
      const founder = active.find((item) => item.provider_slug === "matt-mez-fondateur");
      if (!founder) return Response.json({ passports: [] });
      const passports = active.filter((item) => item.created_by_id === founder.created_by_id).map((item) => { const type = classification(item); return { provider_slug: item.provider_slug, name: item.name, profession: item.profession, location: item.location, avatar: item.avatar, cover_image: item.cover_image, subject_type: type.subject_type, taxonomy_path: type.taxonomy_path, card_media: item.card_media, card_content: item.card_content, access_mode: "public", has_contact: Boolean(item.contact_email || (item.menu || []).some((menuItem) => menuItem.key === "contact" && menuItem.visible !== false)), tracks: (item.tracks || []).filter((track) => track.audio_url), card_config: item.card_config ? { back_title: item.card_config.back_title, back_text: item.card_config.back_text, back_access_mode: item.card_config.back_access_mode || "private", actions: (item.card_config.actions || []).map((action) => action.access === "protected" ? { key: action.key, label: action.label, target: action.target, icon: action.icon, placement: action.placement, access: action.access } : action) } : null }; });
      return Response.json({ passports });
    }
    if (body.contact_selection === true) {
      const settings = (await base44.asServiceRole.entities.SiteSettings.filter({ key: "main" }, undefined, 1))[0];
      const selected = settings?.contact?.selected_passport_ids || [];
      const active = await base44.asServiceRole.entities.Passport.filter({ status: "actif" }, "-updated_date", 200);
      const passports = active.filter((item) => selected.includes(item.id)).map((item) => ({ id: item.id, provider_slug: item.provider_slug, name: item.name, profession: item.profession, location: item.location, avatar: item.avatar, cover_image: item.cover_image, subject_type: item.subject_type, taxonomy_path: item.taxonomy_path, card_media: item.card_media, card_content: item.card_content, access_mode: item.access_mode || "private", has_contact: Boolean(item.contact_email || (item.menu || []).some((menuItem) => menuItem.key === "contact" && menuItem.visible !== false)), tracks: (item.tracks || []).filter((track) => track.audio_url).map((track) => ({ title: track.title, artist: track.artist, cover_url: track.cover_url, audio_url: track.audio_url })), card_config: item.card_config ? { back_title: item.card_config.back_title, back_text: item.card_config.back_text, back_access_mode: item.card_config.back_access_mode || "private", actions: (item.card_config.actions || []).map((action) => action.access === "protected" ? { key: action.key, label: action.label, target: action.target, icon: action.icon, placement: action.placement, access: action.access } : action) } : null }));
      return Response.json({ passports });
    }

    const code = String(body.code || "").trim().toUpperCase();
    const providerSlug = String(body.provider_slug || "").trim();
    const publicFounder = body.public_founder === true && providerSlug === "matt-mez-fondateur";
    const active = await base44.asServiceRole.entities.Passport.filter({ status: "actif" }, "-updated_date", 200);
    if (body.card_access === true) {
      const cardPassport = active.find((item) => item.provider_slug === providerSlug);
      if (!cardPassport) return Response.json({ error: "Passport introuvable" }, { status: 404 });
      const expectedCode = String(cardPassport.card_config?.back_access_code || cardPassport.access_code || "").toUpperCase();
      if (!code || code !== expectedCode) return Response.json({ error: "Code du verso incorrect" }, { status: 403 });
      const config = cardPassport.card_config || {};
      return Response.json({ card_config: { back_title: config.back_title, back_text: config.back_text, back_access_mode: config.back_access_mode || "private", actions: config.actions || [] } });
    }
    let passport = providerSlug ? active.find((item) => item.provider_slug === providerSlug) : null;
    let audience = null;

    if (!passport && code) passport = active.find((item) => String(item.access_code || "").toUpperCase() === code);
    if (!passport && code) {
      passport = active.find((item) => (item.audiences || []).some((group) => String(group.access_code || "").toUpperCase() === code));
      audience = passport?.audiences?.find((group) => String(group.access_code || "").toUpperCase() === code) || null;
    }
    if (!passport) return Response.json({ error: "Passport introuvable" }, { status: 404 });
    if (code) audience = (passport.audiences || []).find((group) => String(group.access_code || "").toUpperCase() === code) || audience;

    const profileMode = passport.profile_access?.mode || "inherit";
    const profileCode = code && String(passport.profile_access?.code || "").toUpperCase() === code;
    const fullCode = Boolean(code && (String(passport.access_code || "").toUpperCase() === code || profileCode));
    const founder = active.find((item) => item.provider_slug === "matt-mez-fondateur");
    const founderShowcase = body.founder_showcase === true && founder && passport.created_by_id === founder.created_by_id;
    const isPublic = profileMode === "public" || founderShowcase || (profileMode !== "private" && ((passport.access_mode || "private") === "public" || publicFounder));
    if (!isPublic && !fullCode && !audience && body.auto_access === true) {
      let user = null;
      try { user = await base44.auth.me(); } catch (_) { user = null; }
      if (user) {
        const owned = await base44.entities.Passport.list(undefined, 100);
        audience = (passport.audiences || []).find((group) => (group.allowed_emails || []).map((email) => email.toLowerCase()).includes(String(user.email || "").toLowerCase()) || (group.allowed_passport_ids || []).some((id) => owned.some((item) => item.id === id))) || null;
      }
    }
    if (!isPublic && !fullCode && !audience) return Response.json({ error: "Accès refusé pour ce Passport" }, { status: 403 });

    const allowedKeys = audience?.menu_keys || [];
    const menu = allowedKeys.length ? (passport.menu || []).filter((item) => allowedKeys.includes(item.key)) : (passport.menu || []);
    const type = classification(passport);
    return Response.json({ passport: { provider_slug: passport.provider_slug, name: passport.name, profession: passport.profession, location: passport.location, avatar: passport.avatar, cover_image: passport.cover_image, subject_type: type.subject_type, taxonomy_path: type.taxonomy_path, card_media: passport.card_media, card_content: passport.card_content, biography: passport.biography, contact_email: passport.contact_email, tracks: passport.tracks || [], menu, audience: audience?.label || null } });
  } catch (error) {
    console.error("getPassportByCode", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}