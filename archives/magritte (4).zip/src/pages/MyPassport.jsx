import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { usePassportEditor } from "@/lib/usePassportEditor";
import PassportLogin from "@/components/passport/PassportLogin";
import PassportManagerList from "@/components/passport/PassportManagerList";
import PassportEditorForm from "@/components/passport/PassportEditorForm";
import AccountCanvasHome from "@/components/account/AccountCanvasHome";

export default function MyPassport({ accountMode = false }) {
  const { isAuthenticated, isLoadingAuth, user } = useAuth();
  const editor = usePassportEditor(user, Boolean(isAuthenticated));
  const editorAnchor = useRef(null);
  const autoCreateHandled = useRef(false);
  const [pendingScroll, setPendingScroll] = useState(false);
  const openEditor = (action) => { setPendingScroll(true); action(); };
  useEffect(() => {
    if (autoCreateHandled.current || editor.isLoading || new URLSearchParams(window.location.search).get("create") !== "mariage") return;
    autoCreateHandled.current = true;
    const existing = editor.passports.find((item) => item.taxonomy_slug === "event-mariage" || item.provider_slug?.startsWith("passport-mariage-") || item.profession === "Mariage");
    openEditor(() => existing ? editor.configure(existing) : editor.selectType("event"));
  }, [editor.isLoading, editor.passports]);
  useEffect(() => {
    if (!pendingScroll || (!editor.form && !editor.isChoosingTemplate)) return;
    const frame = window.requestAnimationFrame(() => {
      const top = (editorAnchor.current?.getBoundingClientRect().top || 0) + window.scrollY - 88;
      window.scrollTo({ top, behavior: "smooth" });
      setPendingScroll(false);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [pendingScroll, editor.form, editor.isChoosingTemplate]);
  if (isLoadingAuth || editor.isLoading) return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-6 w-6 animate-spin"/></div>;
  if (!isAuthenticated) return <PassportLogin accountMode={accountMode}/>;
  const eyebrow = accountMode ? "Espace personnel" : "Espace Passport";
  const title = accountMode ? "Mon compte" : "Mes Passports";
  const description = accountMode ? "Votre centre de pilotage relie vos Passports, vos priorités et Agent AIME." : "Créez plusieurs identités et configurez chacune indépendamment.";
  const configurePassport = (passport) => openEditor(() => editor.configure(passport));
  return <main className="min-h-screen px-4 pb-24 pt-20 md:px-8 md:pt-24"><div className="mx-auto max-w-6xl space-y-14">
    <header className="flex flex-wrap items-end justify-between gap-6"><div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">{eyebrow}</span><h1 className="mt-3 text-5xl font-light tracking-tight md:text-7xl">{title}</h1><p className="mt-4 max-w-xl text-muted-foreground">{description}</p></div><Button onClick={() => openEditor(editor.startCreate)}><Plus className="h-4 w-4"/>Créer un Passport</Button></header>
    {accountMode ? <AccountCanvasHome passports={editor.passports} onConfigure={configurePassport}/> : <PassportManagerList passports={editor.passports} onConfigure={configurePassport}/>}<div ref={editorAnchor} className="scroll-mt-24">{(editor.form || editor.isChoosingTemplate) && <PassportEditorForm editor={editor}/>}</div> 
  </div></main>;
}