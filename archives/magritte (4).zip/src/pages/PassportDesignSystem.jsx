import React, { useEffect } from "react";
import PassportCard from "@/components/passport/PassportCard";
import { PASSPORT_CARD_SAMPLES } from "@/lib/passportCardSamples";

export default function PassportDesignSystem() {
  useEffect(() => { window.scrollTo(0, 0); }, []);
  return (
    <main className="min-h-screen bg-white px-6 pb-24 pt-10 text-charcoal md:px-9 md:pt-10">
      <div className="mx-auto max-w-[1400px]">
        <p className="font-mono text-2xl font-semibold uppercase tracking-[-0.08em] md:text-4xl">Passport Design System</p>
        <header className="mb-12 mt-16 md:mb-14 md:mt-20">
          <h1 className="text-4xl font-semibold tracking-tight md:text-6xl">Cartes Passport</h1>
          <p className="mt-2 text-xl font-light tracking-tight md:text-4xl">Une collection de gabarits selon chaque identité.</p>
        </header>
        <section className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5" aria-label="Collection de cartes Passport">
          {PASSPORT_CARD_SAMPLES.map((card) => <PassportCard key={card.type} card={card}/>) }
        </section>
      </div>
    </main>
  );
}