import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useTheme } from "next-themes";
import { LayoutGrid } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import { SITE_CANVAS_PAGES } from "@/lib/siteCanvasPages";
import { HOME_SECTIONS } from "@/lib/homeSectionRegistry";
import { useVisualPageLayout } from "@/lib/useVisualPageLayout";
import { useVisualContentEditor } from "@/lib/useVisualContentEditor";
import { useCanvasElementOverride } from "@/lib/useCanvasElementOverride";
import useSettingsSection from "@/components/admin/useSettingsSection";
import CanvasFrame from "@/components/editor/CanvasFrame";
import CanvasToolbar from "@/components/editor/CanvasToolbar";
import CanvasInspector from "@/components/editor/CanvasInspector";
import CanvasSectionControls from "@/components/editor/CanvasSectionControls";
import CanvasElementControls from "@/components/editor/CanvasElementControls";

const palettes = { light: { background: "#F6F6F6", primary: "#2E5BFF", accent: "#A3B18A" }, dark: { background: "#121212", primary: "#5B7CFF", accent: "#A3B18A" } };
const heroDefaults = { mode: "current", title: "", subtitle: "", height_vh: 100, overlay_opacity: 40, media: { type: "image", url: "" }, slides: [] };

export default function SiteCanvas() {
  const { user } = useAuth();
  useTheme();
  const [selected, setSelected] = useState(SITE_CANVAS_PAGES[0]);
  const [selectedSection, setSelectedSection] = useState("hero");
  const [selectedElement, setSelectedElement] = useState(null);
  const [elementPatch, setElementPatch] = useState(null);
  const [focused, setFocused] = useState(false);
  const [device, setDevice] = useState("desktop");
  const [zoom, setZoomState] = useState(30);
  const [frameVersion, setFrameVersion] = useState(0);
  const editor = useVisualPageLayout("home", HOME_SECTIONS);
  const content = useVisualContentEditor();
  const identity = useSettingsSection("design_system", palettes);
  const heroContent = useSettingsSection("hero", heroDefaults);
  const elementEditor = useCanvasElementOverride(selected.path);
  const fullMediaHero = heroContent.value.mode === "full_image" || heroContent.value.mode === "full_video";
  const registry = useMemo(() => HOME_SECTIONS.map((item) => item.key === "hero" && fullMediaHero ? { ...item, fields: [{ key: "hero.title", label: "Grand titre", type: "textarea" }, { key: "hero.subtitle", label: "Sous-titre" }] } : item), [fullMediaHero]);
  const definition = registry.find((item) => item.key === selectedSection), section = editor.sections.find((item) => item.key === selectedSection);
  const valueFor = (key) => key === "hero.title" ? heroContent.value.title : key === "hero.subtitle" ? heroContent.value.subtitle : content.t(key);
  const saveContent = (values) => Object.keys(values).some((key) => key.startsWith("hero.")) ? heroContent.save({ ...heroContent.value, title: values["hero.title"], subtitle: values["hero.subtitle"] }) : content.save(values);
  const setColor = (mode, key, value) => identity.setValue((current) => ({ ...current, [mode]: { ...current[mode], [key]: value } }));
  const refreshAfter = async (action) => { await action(); setFrameVersion((version) => version + 1); };
  const setZoom = (value) => setZoomState(Math.min(100, Math.max(15, value)));
  const inspect = (page) => { setSelected(page); setSelectedSection(page.key === "home" ? "hero" : ""); setSelectedElement(null); setElementPatch(null); setFocused(true); setZoomState(100); };
  const overview = () => { setFocused(false); setSelectedElement(null); setZoomState(30); };
  const selectElement = (element) => { if (selected.key === "home" && element.tag === "SECTION" && element.sectionKey) { setSelectedSection(element.sectionKey); setSelectedElement(null); } else setSelectedElement(element); };
  const saveElement = async (values) => { const saved = await elementEditor.save(selectedElement.id, values); setSelectedElement((current) => ({ ...current, ...saved })); setElementPatch({ id: selectedElement.id, values: saved }); };
  if (user?.role !== "admin") return <main className="flex min-h-screen items-center justify-center bg-background"><div className="text-center"><h1 className="text-3xl font-light">Accès privé</h1><Link className="mt-4 inline-block text-primary underline" to="/">Retour à l’accueil</Link></div></main>;
  return <main className="editor-canvas-grid fixed inset-0 overflow-auto bg-muted pr-80">
    <header className="sticky left-0 top-0 z-20 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur"><div><p className="font-mono text-[10px] uppercase tracking-widest text-primary">AIME® Studio</p><h1 className="text-lg font-light">{focused ? `Inspection — ${selected.label}` : "Canevas responsive"}</h1></div>{focused && <Button variant="outline" size="sm" onClick={overview}><LayoutGrid />Toutes les pages</Button>}</header>
    {focused ? <div className="flex min-h-[calc(100vh-4rem)] items-start justify-center p-8" style={{ transform: `scale(${zoom / 100})`, transformOrigin: "top center" }}><CanvasFrame key={`${selected.key}-${device}-${frameVersion}`} page={selected} device={device} active focused onSelect={() => {}} onVisibleSection={selected.key === "home" ? setSelectedSection : undefined} onElementSelect={selectElement} elementPatch={elementPatch}/></div> : <div className="relative p-12" style={{ width: 1320 * zoom / 100 }}><div className="grid w-[1240px] origin-top-left grid-cols-3 items-start gap-x-16 gap-y-20" style={{ transform: `scale(${zoom / 100})` }}>{SITE_CANVAS_PAGES.map((page, index) => <CanvasFrame key={`${page.key}-${device}`} page={page} device={device} index={index} active={selected.key === page.key} onSelect={() => inspect(page)} />)}</div></div>}
    <CanvasInspector page={selected} device={device} focused={focused} sectionLabel={selectedElement?.label || definition?.label}>{focused && selectedElement ? <CanvasElementControls element={selectedElement} saving={elementEditor.saving} error={elementEditor.error} onSave={saveElement}/> : focused && selected.key === "home" ? <CanvasSectionControls definition={definition} section={section} sections={editor.sections} saving={editor.saving} error={editor.error} valueFor={valueFor} contentSaving={content.saving || heroContent.saving} contentError={content.error} onSaveContent={(values) => refreshAfter(() => saveContent(values))} identity={{ value: identity.value, saving: identity.saving, saved: identity.saved, onChange: setColor, onSave: () => refreshAfter(identity.save) }} onDesign={(key, patch) => refreshAfter(() => editor.updateDesign(key, patch))} onMove={(key, step) => refreshAfter(() => editor.move(key, step))} onToggle={(key) => refreshAfter(() => editor.toggle(key))}/> : focused ? <p className="text-sm text-muted-foreground">Cliquez sur un élément de la page pour afficher ses réglages.</p> : null}</CanvasInspector>
    <CanvasToolbar device={device} onDevice={setDevice} zoom={zoom} onZoom={setZoom} onFit={() => setZoom(focused ? 80 : 20)} />
  </main>;
}