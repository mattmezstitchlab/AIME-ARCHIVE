import React, { useEffect, useState } from "react";
import { Navigate, useParams } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { WEDDING_MODULES } from "@/lib/weddingModules";
import { useWeddingModuleData } from "@/lib/useWeddingModuleData";
import { useWeddingSimulation } from "@/lib/useWeddingSimulation";
import useSiteSettings from "@/lib/useSiteSettings";
import { mergeWeddingModules } from "@/lib/weddingModuleSettings";
import { addCanvasModule, getCanvasModuleKeys } from "@/lib/moduleCanvasCart";
import ModuleHero from "@/components/wedding-module/ModuleHero";
import ModulePresentation from "@/components/wedding-module/ModulePresentation";
import ModuleWorkspace from "@/components/wedding-module/ModuleWorkspace";
import WeddingPassportCreator from "@/components/wedding-module/WeddingPassportCreator";
import WeddingSimulationForm from "@/components/wedding-module/WeddingSimulationForm";
import SimulationCanvasPreview from "@/components/wedding-module/SimulationCanvasPreview";

export default function WeddingModule() {
  const { module: type } = useParams(), baseModule = WEDDING_MODULES[type];
  const { user, isAuthenticated } = useAuth();
  const { settings } = useSiteSettings(), module = mergeWeddingModules(settings).find((item) => item.key === type) || baseModule;
  const data = useWeddingModuleData(Boolean(isAuthenticated)), { simulation, saveSimulation } = useWeddingSimulation();
  const [added, setAdded] = useState(() => getCanvasModuleKeys().includes(type)), [finalizing, setFinalizing] = useState(false);
  useEffect(() => setAdded(getCanvasModuleKeys().includes(type)), [type]);
  if (!module) return <Navigate to="/project/mariage-platform" replace/>;
  const includedWithWeddingPassport = Boolean(data.passport) && type !== "canevas";
  const addToCanvas = () => { addCanvasModule(type); setAdded(true); };
  const beginFinalization = () => { if (!isAuthenticated) { base44.auth.redirectToLogin(window.location.href); return; } setFinalizing(true); };
  const waiting = isAuthenticated && data.loadingPassports;
  return <main><ModuleHero key={type} type={type} module={module} added={includedWithWeddingPassport || added} onAdd={addToCanvas}/>
    {type === "passport" && !waiting && !data.passport && <section className="px-6 pt-20 md:px-8 md:pt-24"><WeddingSimulationForm simulation={simulation} onSave={saveSimulation}/></section>}
    <ModulePresentation module={module} type={type} simulation={simulation}/>
    {type === "canevas" && !waiting && !data.passport ? <section id="outil" className="scroll-mt-24 px-6 pb-24 md:px-8"><div className="mx-auto max-w-7xl space-y-8"><SimulationCanvasPreview simulation={simulation} onFinalize={beginFinalization}/>{finalizing && <WeddingPassportCreator user={user} simulation={simulation} profile={data.profile}/>}</div></section> : !(type === "passport" && !waiting && !data.passport) && <section id="outil" className="scroll-mt-24 px-6 pb-24 md:px-8"><div className="mx-auto max-w-7xl">{waiting ? <div className="flex h-64 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin"/></div> : <ModuleWorkspace type={type} data={data} isAuthenticated={Boolean(isAuthenticated)}/>}</div></section>}
  </main>;
}