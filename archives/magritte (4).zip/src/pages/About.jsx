import React, { useEffect } from "react";
import AboutSection from "@/components/about/AboutSection";
import ContactSection from "@/components/contact/ContactSection";
import { usePageSections } from "@/lib/usePageSections";

export default function About() {
  const { sections, isLoading } = usePageSections("about");
  useEffect(() => { window.scrollTo(0, 0); }, []);
  if (isLoading) return <div className="flex min-h-screen items-center justify-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-foreground/20 border-t-foreground"/></div>;
  return <main className="min-h-screen bg-background">
    {sections.map((section, index) => <AboutSection key={section.id} section={index === 0 ? { ...section, eyebrow: "Passport fondateur · Marque AIME®" } : section} index={index}/>)}
    <ContactSection/>
  </main>;
}