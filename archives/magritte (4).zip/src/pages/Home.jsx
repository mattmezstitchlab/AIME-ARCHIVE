import React from "react";
import { motion } from "framer-motion";
import RainbowBackground from "@/components/desk/RainbowBackground";
import HeartMosaic from "@/components/desk/HeartMosaic";

/**
 * Home — La grande landing AIME®.
 * Titre énorme en Archivo Black noir, dossiers disposés en cœur (25 dossiers),
 * clic sur un dossier → il s'agrandit et ses documents sortent en éventail.
 */
export default function Home() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <RainbowBackground />

      {/* HERO — titre Archivo Black noir, percutant */}
      <section className="relative z-10 pt-24 md:pt-28 pb-4 md:pb-6 px-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-5xl mx-auto text-center"
        >
          <div className="text-[11px] tracking-[0.3em] uppercase text-stone-500 mb-6 font-sans">
            AIME® · une présence qui s'occupe du reste
          </div>

          <h1
            className="font-display text-stone-900 leading-[0.98] uppercase"
            style={{
              fontSize: "clamp(2.6rem, 7vw, 5.6rem)",
              letterSpacing: "-0.035em"
            }}
          >
            Respirez.<br />
            Aïma s'occupe<br />
            du reste.
          </h1>

          <p className="mt-8 md:mt-10 max-w-xl mx-auto text-stone-700 text-[15px] md:text-[17px] leading-relaxed font-sans">
            Tes 25 dossiers, posés en cœur. Clique sur l'un d'eux, ses papiers se déploient.
            Aïma comprend, classe, écrit, t'accompagne.
          </p>
        </motion.div>
      </section>

      {/* MOSAÏQUE-CŒUR — les 25 dossiers en forme de cœur, centrée */}
      <section className="relative z-10 pt-2 pb-24 md:pb-32 px-4 flex justify-center">
        <HeartMosaic />
      </section>
    </div>
  );
}