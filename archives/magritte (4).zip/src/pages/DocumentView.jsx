import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useSiteTexts } from "@/lib/siteTexts";
import { DOC_TYPES, DOC_STATUS, formatEUR } from "@/lib/frLabels";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function DocumentView() {
  const { id } = useParams();
  const { t } = useSiteTexts();
  const [paying, setPaying] = useState(null); // 'deposit' | 'full'
  const [payError, setPayError] = useState("");
  const paymentSuccess = new URLSearchParams(window.location.search).get("paiement") === "succes";

  const { data, isLoading } = useQuery({
    queryKey: ["publicDocument", id],
    queryFn: async () => (await base44.functions.invoke("getPublicDocument", { id })).data,
  });
  const doc = data?.document;

  const handlePay = async (paymentType) => {
    if (window.self !== window.top) {
      alert("Le paiement en ligne fonctionne uniquement depuis le site publié. Ouvrez cette page dans un nouvel onglet.");
      return;
    }
    setPaying(paymentType);
    setPayError("");
    try {
      const res = await base44.functions.invoke("createDocumentCheckout", {
        documentId: id,
        paymentType,
        origin: window.location.origin,
      });
      window.location.href = res.data.url;
    } catch {
      setPayError("Le paiement n'a pas pu être initialisé. Merci de réessayer.");
      setPaying(null);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-foreground/20 border-t-foreground rounded-full animate-spin" />
      </div>
    );
  }

  if (!doc) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <p className="font-mono text-sm text-muted-foreground">Document introuvable.</p>
      </div>
    );
  }

  const status = DOC_STATUS[doc.status] || DOC_STATUS.brouillon;
  const total = Number(doc.total) || 0;
  const deposit = Number(doc.deposit_amount) || 0;
  const canPayDeposit = deposit > 0 && !["acompte_paye", "paye"].includes(doc.status);
  const remaining = doc.status === "acompte_paye" ? total - deposit : total;
  const canPayFull = total > 0 && doc.status !== "paye";

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 md:px-8">
      <div className="max-w-3xl mx-auto">
        {paymentSuccess && (
          <div className="mb-8 border border-green-600 bg-green-50 text-green-800 px-6 py-4 font-body text-sm">
            Merci ! Votre paiement a bien été reçu. Le statut du document sera mis à jour sous peu.
          </div>
        )}

        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-border pb-8 mb-8">
          <div>
            <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground">{DOC_TYPES[doc.doc_type]}</span>
            <h1 className="font-body text-4xl md:text-5xl font-light tracking-tight text-foreground mt-2">{doc.number || DOC_TYPES[doc.doc_type]}</h1>
            <p className="font-mono text-xs text-muted-foreground mt-2">
              Émis le {format(new Date(doc.created_date), "d MMMM yyyy", { locale: fr })}
            </p>
          </div>
          <span className={`font-mono text-xs px-3 py-1.5 rounded-full ${status.color}`}>{status.label}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          <div>
            <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Émetteur</span>
            <p className="font-body text-base text-foreground">{t("business.name")}</p>
            <p className="font-body text-sm text-muted-foreground">{t("business.address")}</p>
            <p className="font-body text-sm text-muted-foreground">SIRET : {t("business.siret")}</p>
            <p className="font-body text-sm text-muted-foreground">{t("business.email")}{t("business.phone") ? ` · ${t("business.phone")}` : ""}</p>
          </div>
          <div>
            <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Client</span>
            <p className="font-body text-base text-foreground">{doc.client_name}</p>
            {doc.client_email && <p className="font-body text-sm text-muted-foreground">{doc.client_email}</p>}
            {doc.client_phone && <p className="font-body text-sm text-muted-foreground">{doc.client_phone}</p>}
          </div>
        </div>

        {(doc.event_type || doc.event_date || doc.event_location) && (
          <div className="mb-10">
            <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Événement</span>
            <p className="font-body text-base text-foreground">
              {[doc.event_type, doc.event_date ? format(new Date(doc.event_date), "d MMMM yyyy", { locale: fr }) : null, doc.event_location].filter(Boolean).join(" — ")}
            </p>
          </div>
        )}

        {(doc.items || []).length > 0 && (
          <table className="w-full mb-8">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left font-mono text-xs tracking-widest uppercase text-muted-foreground py-3">Prestation</th>
                <th className="text-right font-mono text-xs tracking-widest uppercase text-muted-foreground py-3">Qté</th>
                <th className="text-right font-mono text-xs tracking-widest uppercase text-muted-foreground py-3">Prix unitaire</th>
                <th className="text-right font-mono text-xs tracking-widest uppercase text-muted-foreground py-3">Montant</th>
              </tr>
            </thead>
            <tbody>
              {doc.items.map((item, i) => (
                <tr key={i} className="border-b border-border">
                  <td className="font-body text-sm text-foreground py-3">{item.description}</td>
                  <td className="font-body text-sm text-foreground py-3 text-right">{item.quantity}</td>
                  <td className="font-body text-sm text-foreground py-3 text-right">{formatEUR(item.unit_price)}</td>
                  <td className="font-body text-sm text-foreground py-3 text-right">{formatEUR((Number(item.quantity) || 0) * (Number(item.unit_price) || 0))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="flex flex-col items-end gap-1 mb-10">
          <p className="font-body text-xl text-foreground">Total : <strong>{formatEUR(total)}</strong></p>
          {deposit > 0 && <p className="font-body text-sm text-muted-foreground">Acompte demandé : {formatEUR(deposit)}</p>}
          {doc.status === "acompte_paye" && <p className="font-body text-sm text-muted-foreground">Solde restant : {formatEUR(remaining)}</p>}
          <p className="font-mono text-xs text-muted-foreground mt-2">{t("business.legal")}</p>
        </div>

        {doc.notes && (
          <div className="mb-10">
            <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Conditions</span>
            <p className="font-body text-sm text-muted-foreground whitespace-pre-wrap">{doc.notes}</p>
          </div>
        )}

        {doc.status === "paye" ? (
          <p className="font-body text-base text-green-700 border-t border-border pt-8">✓ Ce document a été réglé intégralement. Merci !</p>
        ) : (
          (canPayDeposit || canPayFull) && (
            <div className="border-t border-border pt-8">
              <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-4">Paiement en ligne sécurisé</span>
              <div className="flex flex-wrap gap-4">
                {canPayDeposit && (
                  <Button onClick={() => handlePay("deposit")} disabled={!!paying} className="font-mono text-xs tracking-widest uppercase px-8 py-6">
                    {paying === "deposit" && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Payer l'acompte — {formatEUR(deposit)}
                  </Button>
                )}
                {canPayFull && (
                  <Button onClick={() => handlePay("full")} disabled={!!paying} variant={canPayDeposit ? "outline" : "default"} className="font-mono text-xs tracking-widest uppercase px-8 py-6">
                    {paying === "full" && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    {doc.status === "acompte_paye" ? `Payer le solde — ${formatEUR(remaining)}` : `Payer la totalité — ${formatEUR(total)}`}
                  </Button>
                )}
              </div>
              {payError && <p className="font-body text-sm text-destructive mt-3">{payError}</p>}
            </div>
          )
        )}
      </div>
    </div>
  );
}