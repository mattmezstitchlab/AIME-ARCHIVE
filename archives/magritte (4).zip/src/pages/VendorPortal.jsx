import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import VendorTimeline from "@/components/vendor-portal/VendorTimeline";
import VendorContribution from "@/components/vendor-portal/VendorContribution";

export default function VendorPortal() {
  const { token } = useParams(), [data, setData] = useState(null), [error, setError] = useState(""), [saving, setSaving] = useState(false);
  const call = async (payload) => { const res = await base44.functions.invoke("vendorPortal", { token, ...payload }); setData(res.data); return res.data; };
  useEffect(() => { call({ action: "get" }).catch(() => setError("Ce lien d’accès n’est pas valide.")); }, [token]);
  const saveNotes = async (notes) => { setSaving(true); await call({ action: "updateNotes", notes }); setSaving(false); };
  const updateStatus = async (item_id, status) => { setSaving(true); await call({ action: "updateTimeline", item_id, status }); setSaving(false); };
  if (error) return <main className="flex min-h-screen items-center justify-center px-6 text-muted-foreground">{error}</main>;
  if (!data) return <main className="flex min-h-screen items-center justify-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-muted border-t-foreground" /></main>;
  const canContribute = data.vendor.access_level !== "lecture", canManage = data.vendor.access_level === "regie";
  return <main className="min-h-screen px-6 py-28"><div className="mx-auto max-w-4xl"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Espace prestataire · {data.vendor.access_level}</span><h1 className="mt-4 text-4xl font-light md:text-6xl">{data.vendor.name}</h1><p className="mt-3 text-muted-foreground">{data.vendor.category}{data.wedding ? ` · ${data.wedding.partner_one} & ${data.wedding.partner_two}` : ""}</p>{canContribute && <VendorContribution notes={data.vendor.notes} onSave={saveNotes} saving={saving} />}<VendorTimeline items={data.timeline} canManage={canManage} onStatus={updateStatus} /></div></main>;
}