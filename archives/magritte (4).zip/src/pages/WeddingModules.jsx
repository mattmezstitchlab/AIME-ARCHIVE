import React from "react";
import useSiteSettings from "@/lib/useSiteSettings";
import { mergeWeddingModules } from "@/lib/weddingModuleSettings";
import WeddingModuleTile from "@/components/wedding/WeddingModuleTile";

export default function WeddingModules() {
  const { settings, isLoading } = useSiteSettings(), modules = mergeWeddingModules(settings).filter((module) => module.visible !== false);
  if (isLoading) return <main className="flex min-h-screen items-center justify-center"><span className="h-6 w-6 animate-spin rounded-full border-2 border-foreground/20 border-t-foreground"/></main>;
  return <main className="min-h-screen px-6 pb-24 pt-32 md:px-8 md:pb-36 md:pt-40"><header className="mb-16 max-w-4xl md:mb-24"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Mariage · Plateforme</p><h1 className="mt-4 text-5xl font-light tracking-tight md:text-8xl">Tous les modules</h1><p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground">Composez votre organisation à partir des outils dont vous avez besoin, du Passport Mariage jusqu’au Canevas vivant.</p></header><section className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-label="Mosaïque des modules Mariage">{modules.map((module) => <WeddingModuleTile key={module.key} module={module}/>)}</section></main>;
}