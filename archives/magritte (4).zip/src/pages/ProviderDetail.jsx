import React from "react";
import { Link, useParams } from "react-router-dom";
import { useProviders } from "@/lib/useProviders";
import { ArrowLeft, ExternalLink, Instagram, KeyRound, Mail, MapPin, Phone } from "lucide-react";

export default function ProviderDetail() {
  const { slug } = useParams();
  const { data: providers = [], isLoading } = useProviders();
  const provider = providers.find((item) => item.slug === slug);
  if (isLoading) return <div className="min-h-screen flex items-center justify-center font-mono text-xs uppercase tracking-widest">Chargement…</div>;
  if (!provider) return <div className="min-h-screen flex flex-col items-center justify-center gap-5"><p>Prestataire introuvable.</p><Link to="/mariage/registre" className="font-mono text-xs uppercase tracking-widest">Retour à l’annuaire</Link></div>;

  const links = [
    provider.website && { href: provider.website, label: "Site internet", icon: ExternalLink },
    provider.instagram && { href: provider.instagram, label: "Instagram", icon: Instagram },
    provider.email && { href: `mailto:${provider.email}`, label: provider.email, icon: Mail },
    provider.phone && { href: `tel:${provider.phone}`, label: provider.phone, icon: Phone },
  ].filter(Boolean);
  return (
    <main className="min-h-screen px-6 md:px-8 pt-32 pb-28"><div className="max-w-6xl mx-auto">
      <Link to="/mariage/registre" className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground mb-10"><ArrowLeft className="w-4 h-4" />Annuaire</Link>
      <div className="grid lg:grid-cols-2 gap-10 lg:gap-20">
        <div className="aspect-[4/3] bg-muted">{provider.image && <img src={provider.image} alt={provider.name} className="w-full h-full object-cover" />}</div>
        <div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">{provider.category}</span><h1 className="font-body text-5xl md:text-7xl font-light tracking-tight mt-3">{provider.name}</h1>
          {provider.location && <p className="flex items-center gap-2 text-muted-foreground mt-5"><MapPin className="w-4 h-4" />{provider.location}</p>}
          {provider.price_range && <p className="font-mono text-xs uppercase tracking-widest mt-5">Budget indicatif · {provider.price_range}</p>}
          <p className="font-body text-lg leading-relaxed text-muted-foreground whitespace-pre-line mt-8">{provider.description}</p>
          <div className="flex flex-col items-start gap-3 mt-10">{links.map(({ href, label, icon: Icon }) => <a key={label} href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="inline-flex items-center gap-2 underline underline-offset-4"><Icon className="w-4 h-4" />{label}</a>)}</div>
          {provider.passport_enabled && <Link to={`/passport?provider=${encodeURIComponent(provider.slug)}&name=${encodeURIComponent(provider.name)}`} className="mt-8 inline-flex items-center gap-2 border border-foreground px-5 py-3 font-mono text-xs uppercase tracking-widest"><KeyRound className="h-4 w-4"/>Accéder au Passport privé</Link>}
        </div>
      </div>
    </div></main>
  );
}