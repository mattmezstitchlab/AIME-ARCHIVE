import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import DashboardLogin from "@/components/dashboard/DashboardLogin";
import WeddingProfileCard from "@/components/dashboard/WeddingProfileCard";
import BudgetCard from "@/components/dashboard/BudgetCard";
import ChecklistCard from "@/components/dashboard/ChecklistCard";
import DashboardModeSwitch from "@/components/dashboard/DashboardModeSwitch";
import DashboardSummary from "@/components/dashboard/DashboardSummary";
import WeddingCanvas from "@/components/dashboard/WeddingCanvas";
import { useCanvasBlocks } from "@/lib/useCanvasBlocks";
import { useFinancialDocuments } from "@/lib/useFinancialDocuments";
import TreasuryEngine from "@/components/dashboard/TreasuryEngine";
import TimelineBoard from "@/components/dashboard/TimelineBoard";
import RegieBoard from "@/components/dashboard/RegieBoard";
import VendorHub from "@/components/dashboard/VendorHub";
import GuestPlanning from "@/components/dashboard/GuestPlanning";
import { useTimelineItems } from "@/lib/useTimelineItems";
import { useWeddingVendors } from "@/lib/useWeddingVendors";
import { useGuestPlanning } from "@/lib/useGuestPlanning";
import { useCoordinationNotifications } from "@/lib/useCoordinationNotifications";
import NotificationCenter from "@/components/dashboard/NotificationCenter";

export default function Dashboard() {
  const { isAuthenticated, isLoadingAuth, user } = useAuth();
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false), [mode, setMode] = useState("canvas");
  const enabled = Boolean(isAuthenticated);
  const { data: profiles = [], isLoading: loadingProfile } = useQuery({ queryKey: ["wedding-profile"], queryFn: () => base44.entities.WeddingProfile.list("-created_date", 1), enabled });
  const { data: budget = [] } = useQuery({ queryKey: ["budget-items"], queryFn: () => base44.entities.BudgetItem.list("-created_date"), enabled });
  const { data: checklist = [] } = useQuery({ queryKey: ["checklist-items"], queryFn: () => base44.entities.ChecklistItem.list("created_date"), enabled });
  const canvas = useCanvasBlocks(enabled);
  const finances = useFinancialDocuments(enabled);
  const timeline = useTimelineItems(enabled);
  const vendorHub = useWeddingVendors(enabled);
  const guestPlanning = useGuestPlanning(enabled);
  const notifications = useCoordinationNotifications(enabled);
  const refresh = (key) => queryClient.invalidateQueries({ queryKey: [key] });
  const saveProfile = async (data) => { setSaving(true); profiles[0] ? await base44.entities.WeddingProfile.update(profiles[0].id, data) : await base44.entities.WeddingProfile.create(data); await refresh("wedding-profile"); setSaving(false); };
  if (isLoadingAuth) return <div className="min-h-screen flex items-center justify-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-muted border-t-foreground" /></div>;
  if (!isAuthenticated) return <DashboardLogin />;
  return <div className="min-h-screen px-6 pb-24 pt-32 md:px-8"><div className="mx-auto max-w-7xl">
    <div className="flex items-start justify-between gap-4"><div><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Espace de {user?.full_name || "votre couple"}</span><h1 className="mb-8 mt-3 text-4xl font-light tracking-tight md:text-6xl">Vue Hélicoptère</h1></div><NotificationCenter center={notifications} /></div>
    <DashboardSummary profile={profiles[0]} checklist={checklist} budget={budget}/><DashboardModeSwitch mode={mode} onChange={setMode}/>
    {mode === "canvas" ? <WeddingCanvas profileId={profiles[0]?.id} canvas={canvas}/> : mode === "timeline" ? <TimelineBoard profile={profiles[0]} onSaveProfile={saveProfile} savingProfile={saving || loadingProfile} timeline={timeline}/> : mode === "regie" ? <RegieBoard profile={profiles[0]} onSaveProfile={saveProfile} timeline={timeline}/> : mode === "hub" ? <VendorHub profile={profiles[0]} hub={vendorHub}/> : mode === "guests" ? <GuestPlanning profile={profiles[0]} planning={guestPlanning}/> : mode === "treasury" ? <TreasuryEngine finances={finances}/> : <div className="grid gap-6"><WeddingProfileCard profile={profiles[0]} onSave={saveProfile} saving={saving || loadingProfile}/><BudgetCard items={budget} totalBudget={profiles[0]?.total_budget} onAdd={async (data) => { await base44.entities.BudgetItem.create(data); refresh("budget-items"); }} onDelete={async (id) => { await base44.entities.BudgetItem.delete(id); refresh("budget-items"); }}/><ChecklistCard items={checklist} onAdd={async (data) => { await base44.entities.ChecklistItem.create(data); refresh("checklist-items"); }} onToggle={async (item) => { await base44.entities.ChecklistItem.update(item.id, { completed: !item.completed }); refresh("checklist-items"); }} onDelete={async (id) => { await base44.entities.ChecklistItem.delete(id); refresh("checklist-items"); }}/></div>}
  </div></div>;
}