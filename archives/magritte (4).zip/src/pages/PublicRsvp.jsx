import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import RsvpResponseForm from "@/components/rsvp/RsvpResponseForm";

export default function PublicRsvp() {
  const { token } = useParams(), [data, setData] = useState(null), [error, setError] = useState(""), [saving, setSaving] = useState(false), [sent, setSent] = useState(false);
  useEffect(() => { base44.functions.invoke("guestRsvp", { action: "get", token }).then((res) => setData(res.data)).catch(() => setError("Ce lien d’invitation n’est pas valide.")); }, [token]);
  const respond = async (status, meal, note) => { setSaving(true); const res = await base44.functions.invoke("guestRsvp", { action: "respond", token, rsvp_status: status, meal_preference: meal, response_note: note }); setData(res.data); setSent(true); setSaving(false); };
  if (error) return <main className="flex min-h-screen items-center justify-center px-6"><p className="text-muted-foreground">{error}</p></main>;
  if (!data) return <main className="flex min-h-screen items-center justify-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-muted border-t-foreground" /></main>;
  const wedding = data.wedding;
  return <main className="min-h-screen px-6 py-28"><section className="mx-auto max-w-xl border border-border bg-card p-7 md:p-10"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Invitation personnelle</span><h1 className="mt-4 text-4xl font-light md:text-6xl">Bonjour {data.guest.full_name}</h1>{wedding && <p className="mt-5 text-lg text-muted-foreground">{wedding.partner_one} & {wedding.partner_two}{wedding.wedding_date ? ` · ${new Date(`${wedding.wedding_date}T12:00:00`).toLocaleDateString("fr-FR")}` : ""}{wedding.location ? ` · ${wedding.location}` : ""}</p>}<p className="mt-6">Votre invitation est prévue pour {data.guest.party_size} personne{data.guest.party_size > 1 ? "s" : ""}.</p>{sent ? <div className="mt-8 border border-cobalt p-5 text-cobalt">Merci, votre réponse a bien été enregistrée.</div> : <RsvpResponseForm guest={data.guest} onRespond={respond} saving={saving} />}</section></main>;
}