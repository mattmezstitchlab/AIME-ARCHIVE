import React, { useEffect } from "react";
import ContactSection from "@/components/contact/ContactSection";

export default function Contact() {
  useEffect(() => { window.scrollTo(0, 0); }, []);
  return <main className="min-h-screen bg-background pt-20"><ContactSection/></main>;
}