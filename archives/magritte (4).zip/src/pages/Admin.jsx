import React, { useState } from "react";
import { Link } from "react-router-dom";
import { MousePointer2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import ProjectsTab from "@/components/admin/ProjectsTab";
import FunctionalitiesTab from "@/components/admin/FunctionalitiesTab";
import FooterTab from "@/components/admin/FooterTab";
import RequestsTab from "@/components/admin/RequestsTab";
import DocumentsTab from "@/components/admin/DocumentsTab";
import AgendaTab from "@/components/admin/AgendaTab";
import ProvidersTab from "@/components/admin/ProvidersTab";
import ProfileTab from "@/components/admin/ProfileTab";
import AboutTab from "@/components/admin/AboutTab";
import HomeTab from "@/components/admin/HomeTab";
import ContactTab from "@/components/admin/ContactTab";
import WeddingModulesTab from "@/components/admin/WeddingModulesTab";
import DesignSystemTab from "@/components/admin/DesignSystemTab";
import PassportTaxonomyTab from "@/components/admin/PassportTaxonomyTab";

export default function Admin() {
  const { data: user, isLoading: loadingUser } = useQuery({ queryKey: ["me"], queryFn: () => base44.auth.me() });
  const [tab, setTab] = useState(() => new URLSearchParams(window.location.search).get("tab") || "demandes");
  const [docPrefill, setDocPrefill] = useState(null);

  if (loadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-foreground/20 border-t-foreground rounded-full animate-spin" />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <p className="font-mono text-sm text-muted-foreground">Accès réservé à l'administrateur.</p>
      </div>
    );
  }

  const handleCreateDoc = (request, docType) => {
    setDocPrefill({ request, docType });
    setTab("documents");
  };

  return (
    <div className="min-h-screen px-6 md:px-8 pt-32 pb-24 max-w-7xl">
      <div className="mb-10 flex flex-wrap items-end justify-between gap-6"><div><span className="font-mono text-xs tracking-widest uppercase text-muted-foreground">Administration</span><h1 className="mt-3 font-body text-4xl font-light tracking-tight text-foreground md:text-6xl">Mon espace</h1></div><Button asChild><Link to="/?edit=1"><MousePointer2 />Modifier sur le site</Link></Button></div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-8 flex-wrap h-auto">
          <TabsTrigger value="accueil" className="font-mono text-xs tracking-widest uppercase">Accueil</TabsTrigger>
          <TabsTrigger value="mariage" className="font-mono text-xs tracking-widest uppercase">Mariage</TabsTrigger>
          <TabsTrigger value="design" className="font-mono text-xs tracking-widest uppercase">Design System</TabsTrigger>
          <TabsTrigger value="passport" className="font-mono text-xs tracking-widest uppercase">Passport</TabsTrigger>
          <TabsTrigger value="demandes" className="font-mono text-xs tracking-widest uppercase">Demandes</TabsTrigger>
          <TabsTrigger value="agenda" className="font-mono text-xs tracking-widest uppercase">Agenda</TabsTrigger>
          <TabsTrigger value="documents" className="font-mono text-xs tracking-widest uppercase">Documents</TabsTrigger>
          <TabsTrigger value="projets" className="font-mono text-xs tracking-widest uppercase">Projets</TabsTrigger>
          <TabsTrigger value="fonctionnalites" className="font-mono text-xs tracking-widest uppercase">Fonctionnalités</TabsTrigger>
          <TabsTrigger value="prestataires" className="font-mono text-xs tracking-widest uppercase">Prestataires</TabsTrigger>
          <TabsTrigger value="profil" className="font-mono text-xs tracking-widest uppercase">Profil</TabsTrigger>
          <TabsTrigger value="a-propos" className="font-mono text-xs tracking-widest uppercase">À propos</TabsTrigger>
          <TabsTrigger value="contact" className="font-mono text-xs tracking-widest uppercase">Contact</TabsTrigger>
          <TabsTrigger value="footer" className="font-mono text-xs tracking-widest uppercase">Footer</TabsTrigger>
        </TabsList>
        <TabsContent value="accueil"><HomeTab /></TabsContent>
        <TabsContent value="mariage"><WeddingModulesTab /></TabsContent>
        <TabsContent value="design"><DesignSystemTab /></TabsContent>
        <TabsContent value="passport"><PassportTaxonomyTab /></TabsContent>
        <TabsContent value="demandes"><RequestsTab onCreateDoc={handleCreateDoc} /></TabsContent>
        <TabsContent value="agenda"><AgendaTab /></TabsContent>
        <TabsContent value="documents"><DocumentsTab prefill={docPrefill} onPrefillConsumed={() => setDocPrefill(null)} /></TabsContent>
        <TabsContent value="projets"><ProjectsTab /></TabsContent>
        <TabsContent value="fonctionnalites"><FunctionalitiesTab /></TabsContent>
        <TabsContent value="prestataires"><ProvidersTab /></TabsContent>
        <TabsContent value="profil"><ProfileTab /></TabsContent>
        <TabsContent value="a-propos"><AboutTab /></TabsContent>
        <TabsContent value="contact"><ContactTab /></TabsContent>
        <TabsContent value="footer"><FooterTab /></TabsContent>
      </Tabs>
    </div>
  );
}