import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import PassportAccessForm from "@/components/passport/PassportAccessForm";
import PassportProfile from "@/components/passport/PassportProfile";

export default function PassportAccess() {
  const params = new URLSearchParams(window.location.search);
  const providerSlug = params.get("provider") || "";
  const providerName = params.get("name") || "";
  const founderShowcase = params.get("showcase") === "1";
  const [passport, setPassport] = useState(null), [loading, setLoading] = useState(Boolean(providerSlug)), [error, setError] = useState("");
  const open = async (code, automatic = false) => {
    setLoading(true); setError("");
    try { const response = await base44.functions.invoke("getPassportByCode", { code, provider_slug: providerSlug, founder_showcase: founderShowcase, auto_access: automatic }); setPassport(response.data.passport); }
    catch (err) { if (!automatic) setError(err.response?.data?.error || "Code incorrect ou Passport indisponible."); }
    setLoading(false);
  };
  useEffect(() => { if (providerSlug) open("", true); }, [providerSlug]);
  if (passport) return <PassportProfile passport={passport}/>;
  if (providerSlug && loading) return <main className="flex min-h-screen items-center justify-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-border border-t-foreground"/></main>;
  return <main className="min-h-screen px-6 pb-24 pt-36"><PassportAccessForm providerName={providerName} loading={loading} error={error} onSubmit={open}/></main>;
}