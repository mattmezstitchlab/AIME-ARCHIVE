import React from "react";
import { Navigate } from "react-router-dom";

export default function Providers() {
  return <Navigate to="/mariage/registre" replace/>;
}