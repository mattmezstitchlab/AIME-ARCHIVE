import React, { useState } from "react";
import { FileText, Folder } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function FloatingFolder({ label, index }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative flex h-20 items-end justify-center md:h-24">
      <AnimatePresence>
        {open && [0, 1, 2].map((paper) => (
          <motion.div
            key={paper}
            initial={{ opacity: 0, y: 12, rotate: 0 }}
            animate={{ opacity: 1, y: -34 - paper * 5, x: (paper - 1) * 18, rotate: (paper - 1) * 10 }}
            exit={{ opacity: 0, y: 8, x: 0, rotate: 0 }}
            className="absolute bottom-6 z-0 flex h-12 w-10 items-center justify-center border border-border bg-card shadow-sm"
          >
            <FileText className="h-4 w-4 text-muted-foreground" />
          </motion.div>
        ))}
      </AnimatePresence>
      <motion.button
        type="button"
        aria-expanded={open}
        aria-label={`${open ? "Fermer" : "Ouvrir"} le dossier ${label}`}
        onClick={() => setOpen((value) => !value)}
        whileHover={{ y: -4 }}
        whileTap={{ scale: 0.96 }}
        className="relative z-10 flex w-full max-w-20 flex-col items-center gap-1 text-foreground focus-visible:ring-2 focus-visible:ring-ring"
      >
        <Folder className={`h-10 w-10 md:h-12 md:w-12 ${open ? "fill-primary/25 text-primary" : "fill-card text-foreground/70"}`} />
        <span className="w-full truncate text-center font-mono text-[8px] uppercase tracking-wide md:text-[9px]">{String(index + 1).padStart(2, "0")} · {label}</span>
      </motion.button>
    </div>
  );
}