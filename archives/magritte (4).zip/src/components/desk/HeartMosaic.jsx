import React from "react";
import FloatingFolder from "@/components/desk/FloatingFolder";

const folders = [
  ["Identité", 2], ["Maison", 3], ["Famille", 5], ["Santé", 6],
  ["Agenda", 1], ["Projets", 2], ["Budget", 3], ["Voyages", 4], ["Travail", 5], ["Contacts", 6], ["Notes", 7],
  ["Contrats", 1], ["Factures", 2], ["Mariage", 3], ["Équipe", 4], ["Archives", 5], ["Idées", 6], ["Médias", 7],
  ["Réservations", 2], ["Invités", 3], ["Prestataires", 4], ["Souvenirs", 5], ["Urgences", 6],
  ["À classer", 3], ["Favoris", 5]
];

export default function HeartMosaic() {
  return (
    <div className="grid w-full max-w-3xl grid-cols-7 gap-x-1 gap-y-0 md:gap-x-3" aria-label="Les 25 dossiers AIME">
      {folders.map(([label, column], index) => (
        <div key={label} style={{ gridColumn: column }}>
          <FloatingFolder label={label} index={index} />
        </div>
      ))}
    </div>
  );
}