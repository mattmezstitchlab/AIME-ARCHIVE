import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function RsvpResponseForm({ guest, onRespond, saving }) {
  const [meal, setMeal] = useState(guest.meal_preference || ""), [note, setNote] = useState("");
  return <div className="mt-8 grid gap-4"><div><label className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Préférence alimentaire</label><Input value={meal} onChange={(e) => setMeal(e.target.value)} placeholder="Végétarien, allergies…" /></div><div><label className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Message</label><Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Un mot pour les mariés" /></div><div className="grid gap-3 sm:grid-cols-2"><button disabled={saving} onClick={() => onRespond("confirme", meal, note)} className="bg-foreground px-5 py-3 text-sm text-background disabled:opacity-50">Je serai présent·e</button><button disabled={saving} onClick={() => onRespond("decline", meal, note)} className="border border-border px-5 py-3 text-sm disabled:opacity-50">Je ne pourrai pas venir</button></div></div>;
}