import React from "react";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { useTheme } from "next-themes";

export default function ModuleGuidedPreview({ feature }) {
  const { resolvedTheme } = useTheme(), dark = resolvedTheme === "dark";
  const steps = feature.steps || ["Découvrir", "Configurer", "Utiliser"], overlay = dark ? feature.overlay_dark ?? 60 : feature.overlay_light ?? 35;
  return <div className={`overflow-hidden border ${dark ? "border-gallery/20 bg-charcoal text-gallery" : "border-charcoal/15 bg-gallery text-charcoal"}`}>
    <div className="flex items-center justify-between border-b border-current/15 px-5 py-3"><span className="font-mono text-[10px] uppercase tracking-widest opacity-60">Aperçu du module</span><ArrowUpRight className="h-4 w-4 text-primary"/></div>
    <div className="relative aspect-[4/3] overflow-hidden"><img src={feature.image} alt="" className="absolute inset-0 h-full w-full object-cover"/><div className={`absolute inset-0 ${dark ? "bg-charcoal" : "bg-gallery"}`} style={{ opacity: overlay / 100 }}/><div className={`absolute inset-0 bg-gradient-to-t ${dark ? "from-charcoal via-charcoal/70 to-transparent" : "from-gallery via-gallery/70 to-transparent"}`}/>
      <div className="absolute inset-x-0 bottom-0 p-6 md:p-8"><p className="font-mono text-xs uppercase tracking-widest text-primary">{feature.title}</p><h3 className="mt-2 text-3xl font-light">Votre espace guidé</h3><div className="mt-6 grid gap-2">
        {steps.map((step, index) => <motion.div key={step} initial={{ opacity: 0, x: 24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: false }} transition={{ delay: index * .15 }} className={`flex items-center gap-3 border p-3 ${dark ? "border-gallery/20 bg-charcoal/85 text-gallery" : "border-charcoal/15 bg-gallery/90 text-charcoal"}`}><span className="font-mono text-xs text-primary">0{index + 1}</span><span className="text-sm">{step}</span></motion.div>)}
      </div></div>
    </div>
  </div>;
}