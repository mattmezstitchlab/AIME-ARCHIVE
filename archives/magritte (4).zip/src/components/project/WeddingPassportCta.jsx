import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

export default function WeddingPassportCta() {
  return <section className="px-6 py-16 md:px-8"><div className="flex flex-col justify-between gap-8 border-y border-border py-12 md:flex-row md:items-end">
    <div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Le point de départ</span><h2 className="mt-4 max-w-3xl text-4xl font-light tracking-tight md:text-6xl">Un Passport unique pour tout votre mariage.</h2><p className="mt-5 max-w-2xl text-muted-foreground">Créez l’identité commune qui reliera automatiquement la Timeline, le Registre, les Documents, le Budget et le Canevas.</p></div>
    <Link to="/mon-passport?create=mariage" className="inline-flex shrink-0 items-center gap-3 bg-primary px-6 py-4 font-mono text-xs uppercase tracking-widest text-primary-foreground">Créer mon Passport Mariage<ArrowRight className="h-4 w-4"/></Link>
  </div></section>;
}