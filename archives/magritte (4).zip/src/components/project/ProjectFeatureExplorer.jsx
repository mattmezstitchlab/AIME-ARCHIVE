import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Heart, Clock3, BookOpen, FileText, Euro, PanelsTopLeft } from "lucide-react";
import ProjectFeaturePreview from "./ProjectFeaturePreview";
import useSiteSettings from "@/lib/useSiteSettings";
import { mergeWeddingModules } from "@/lib/weddingModuleSettings";

const icons = [Heart, Clock3, BookOpen, FileText, Euro, PanelsTopLeft];

export default function ProjectFeatureExplorer({ features = [] }) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const { settings } = useSiteSettings(), moduleSettings = mergeWeddingModules(settings);
  if (!features.length) return null;
  const displayFeatures = features.map((feature) => { const key = feature.link?.split("/").filter(Boolean).pop(), module = moduleSettings.find((item) => item.key === key); return module ? { ...feature, title: module.title, description: module.description, image: module.image, overlay_light: module.overlay_light, overlay_dark: module.overlay_dark } : feature; });
  const selected = displayFeatures[Math.min(selectedIndex, displayFeatures.length - 1)];
  return (
    <section className="px-6 md:px-8 py-24 md:py-32" aria-label="Fonctionnalités du projet">
      <div className="mb-12 max-w-3xl"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">L’écosystème complet</span><h2 className="mt-4 text-4xl md:text-6xl font-light tracking-tight">Tout est inclus dans votre Passport Mariage.</h2><p className="mt-5 text-lg text-muted-foreground">Chaque module dispose de sa propre page et reste relié aux mêmes informations de référence.</p></div>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-5 divide-y divide-border border-y border-border">{displayFeatures.map((feature, index) => { const Icon = icons[index % icons.length]; return <button key={`${feature.title}-${index}`} onClick={() => setSelectedIndex(index)} className={`w-full py-6 text-left transition-colors ${selectedIndex === index ? "text-cobalt" : "text-foreground"}`}><div className="flex items-start gap-4"><Icon className="mt-1 h-5 w-5"/><div><span className="font-mono text-xs tracking-widest">{String(index + 1).padStart(2, "0")}{feature.status ? ` · ${feature.status}` : ""}</span><h3 className="mt-2 text-2xl font-light">{feature.title}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{feature.description}</p></div></div></button>; })}</div>
        <div className="lg:col-span-7"><ProjectFeaturePreview feature={selected}/>{selected.link && (selected.link.startsWith("/") ? <Link to={selected.link} className="mt-5 inline-block font-mono text-sm uppercase tracking-widest text-cobalt">{selected.link_label || "Découvrir la fonctionnalité"} →</Link> : <a href={selected.link} className="mt-5 inline-block font-mono text-sm uppercase tracking-widest text-cobalt">{selected.link_label || "Découvrir la fonctionnalité"} →</a>)}</div>
      </div>
    </section>
  );
}