import React from "react";
import ProjectHeader from "./ProjectHeader";
import ProjectMetadata from "./ProjectMetadata";
import WeddingProjectIntro from "./WeddingProjectIntro";
import WeddingPassportCta from "./WeddingPassportCta";
import ProjectFeatureExplorer from "./ProjectFeatureExplorer";
import NextProject from "./NextProject";

export default function WeddingProjectDetail({ project, nextProject, prevProject }) {
  return (
    <div>
      <ProjectHeader project={project} />
      <div className="md:hidden"><ProjectMetadata project={project} /></div>
      <WeddingProjectIntro />
      <WeddingPassportCta />
      <ProjectFeatureExplorer features={project.features} />
      <NextProject nextProject={nextProject} prevProject={prevProject} />
    </div>
  );
}