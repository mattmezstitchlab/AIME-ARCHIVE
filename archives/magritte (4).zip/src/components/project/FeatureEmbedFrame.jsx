import React from "react";

export default function FeatureEmbedFrame({ feature, compact = false }) {
  const mode = feature.embed_mode || "page";
  const interactive = feature.interactive !== false;
  const iframeClass = interactive ? "border-0" : "pointer-events-none border-0";

  if (mode === "page") {
    return (
      <div className="overflow-hidden border border-border bg-muted">
        <iframe src={feature.embed_url} title={feature.title} loading="lazy" className={`${iframeClass} w-full ${compact ? "h-96" : "h-[70vh] min-h-[520px]"}`} />
      </div>
    );
  }

  const width = feature.frame_width || 1440;
  const height = feature.frame_height || 900;
  const viewportHeight = feature.viewport_height || 560;
  const scale = feature.frame_scale || 1;
  const transform = `translate(${-Number(feature.offset_x || 0)}px, ${-Number(feature.offset_y || 0)}px) scale(${scale})`;
  return (
    <div className="relative overflow-hidden border border-border bg-muted" style={{ height: compact ? Math.min(viewportHeight, 420) : viewportHeight }}>
      <iframe src={feature.embed_url} title={feature.title} loading="lazy" className={`absolute left-0 top-0 ${iframeClass}`} style={{ width, height, transform, transformOrigin: "top left" }} />
    </div>
  );
}