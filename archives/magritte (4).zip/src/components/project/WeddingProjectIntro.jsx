import React from "react";

export default function WeddingProjectIntro() {
  return (
    <section className="px-6 md:px-8 py-24 md:py-32">
      <div className="grid gap-12 md:grid-cols-12">
        <div className="md:col-span-4"><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Le concept</span><h2 className="mt-4 text-3xl md:text-5xl font-light leading-tight">Moins de dispersion.<br/>Plus d’émotion.</h2></div>
        <div className="md:col-start-6 md:col-span-6 space-y-6 text-lg leading-relaxed text-muted-foreground"><p>Préparer un mariage implique des centaines de décisions, souvent réparties entre tableurs, messages et documents. La plateforme transforme cette complexité en un parcours simple et partagé.</p><p>Chaque fonctionnalité répond à un moment précis : définir le projet, suivre les engagements, coordonner le Jour J et fluidifier les échanges avec les prestataires.</p></div>
      </div>
    </section>
  );
}