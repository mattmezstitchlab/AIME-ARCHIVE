import React from "react";
import FeatureEmbedFrame from "./FeatureEmbedFrame";
import ModuleGuidedPreview from "./ModuleGuidedPreview";

export default function ProjectFeaturePreview({ feature }) {
  if (feature?.link?.startsWith("/mariage/")) return <ModuleGuidedPreview feature={feature} />;
  if (feature?.embed_url) return <FeatureEmbedFrame feature={feature} />;
  if (!feature?.image) return <div className="flex min-h-64 items-center justify-center border border-border bg-muted/40 px-8 text-center"><p className="max-w-md text-xl font-light text-muted-foreground">{feature?.description}</p></div>;
  const isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(feature.image);
  return (
    <div className="overflow-hidden border border-border bg-muted">
      {isVideo ? <video src={feature.image} controls className="aspect-video w-full object-cover"/> : <img src={feature.image} alt={feature.title} className="aspect-video w-full object-cover"/>}
    </div>
  );
}