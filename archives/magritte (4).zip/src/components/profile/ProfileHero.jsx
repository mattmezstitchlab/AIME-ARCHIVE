import React from "react";
import { motion } from "framer-motion";

export default function ProfileHero({ items }) {
  const get = (key) => items.find((item) => item.key === key)?.value;
  const portrait = get("identity.portrait");
  const titleLines = (get("identity.title") || "").split("\n");
  return (
    <section className="px-6 pb-24 md:px-8 md:pb-40">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 md:grid-cols-12 md:gap-8">
        {portrait && <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="md:col-span-5"><div className="aspect-[3/4] overflow-hidden"><img src={portrait} alt="Portrait du profil" className="h-full w-full object-cover" /></div></motion.div>}
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className={`${portrait ? "md:col-start-7" : "md:col-start-4"} flex flex-col justify-end md:col-span-6`}>
          {get("identity.label") && <span className="mb-4 block font-mono text-xs uppercase tracking-widest text-muted-foreground">{get("identity.label")}</span>}
          {titleLines[0] && <h1 className="mb-8 text-4xl font-light leading-tight tracking-tight md:text-5xl lg:text-6xl">{titleLines[0]}{titleLines[1] && <><br/><span className="text-muted-foreground">{titleLines.slice(1).join(" ")}</span></>}</h1>}
          {get("identity.intro") && <p className="mb-6 text-lg leading-relaxed text-muted-foreground">{get("identity.intro")}</p>}
          {get("identity.approach") && <p className="text-lg leading-relaxed text-muted-foreground">{get("identity.approach")}</p>}
        </motion.div>
      </div>
    </section>
  );
}