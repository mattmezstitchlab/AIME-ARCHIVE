import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import ProviderFormFields from "./ProviderFormFields";

const empty = { name: "", slug: "", category: "Photographe", location: "", description: "", image: "", website: "", instagram: "", email: "", phone: "", price_range: "", passport_enabled: false, featured: false, status: "brouillon" };

export default function ProviderEditor({ provider, onSave, onCancel, saving }) {
  const [form, setForm] = useState(provider || empty);
  const [error, setError] = useState("");
  const setField = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.name.trim() || !form.slug.trim()) return setError("Le nom et le slug sont obligatoires.");
    await onSave(form);
  };
  return <form onSubmit={submit} className="space-y-8">
    <ProviderFormFields form={form} setField={setField} />
    {error && <p className="text-sm text-destructive">{error}</p>}
    <div className="flex gap-3"><Button type="submit" disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer"}</Button><Button type="button" variant="outline" onClick={onCancel}>Annuler</Button></div>
  </form>;
}