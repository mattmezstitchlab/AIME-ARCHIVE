import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import MediaField from "./MediaField";
import FeatureEditorialGenerator from "./FeatureEditorialGenerator";
import FeatureEmbedSettings from "./FeatureEmbedSettings";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ProjectFeatureItem({ feature, index, projectTitle, functionalities, onChange, onRemove }) {
  const set = (key, value) => onChange({ ...feature, [key]: value });
  const linkFunctionality = (id) => { const item = functionalities.find((entry) => entry.id === id); onChange({ ...feature, functionality_id: id, title: feature.title || item?.name || "" }); };
  return (
    <div className="space-y-4 border border-border p-4 md:p-6">
      <div className="flex items-center justify-between"><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Fonctionnalité {String(index + 1).padStart(2, "0")}</span><Button type="button" variant="ghost" size="icon" onClick={onRemove} aria-label="Supprimer la fonctionnalité"><X className="h-4 w-4" /></Button></div>
      <Select value={feature.functionality_id || "unlinked"} onValueChange={(value) => value === "unlinked" ? set("functionality_id", "") : linkFunctionality(value)}><SelectTrigger><SelectValue placeholder="Lier au catalogue" /></SelectTrigger><SelectContent><SelectItem value="unlinked">Présentation sans module commun</SelectItem>{functionalities.map((item) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent></Select>
      <FeatureEditorialGenerator feature={feature} projectTitle={projectTitle} onGenerated={onChange} />
      <div className="grid gap-4 md:grid-cols-2"><Input value={feature.title || ""} onChange={(e) => set("title", e.target.value)} placeholder="Titre"/><Input value={feature.status || ""} onChange={(e) => set("status", e.target.value)} placeholder="Statut, ex. Disponible"/></div>
      <Textarea value={feature.description || ""} onChange={(e) => set("description", e.target.value)} placeholder="Présentation éditoriale" rows={3}/>
      <MediaField label="Visuel" value={feature.image || ""} onChange={(value) => set("image", value)} />
      <div className="grid gap-4 md:grid-cols-2"><Input value={feature.link || ""} onChange={(e) => set("link", e.target.value)} placeholder="Lien, ex. /mon-mariage"/><Input value={feature.link_label || ""} onChange={(e) => set("link_label", e.target.value)} placeholder="Libellé du lien"/></div>
      <FeatureEmbedSettings feature={feature} onChange={onChange} />
    </div>
  );
}