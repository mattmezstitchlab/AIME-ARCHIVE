import React from "react";
import { Button } from "@/components/ui/button";
import useSettingsSection from "./useSettingsSection";
import WeddingModuleVisualEditor from "./WeddingModuleVisualEditor";
import { mergeWeddingModules } from "@/lib/weddingModuleSettings";

export default function WeddingModulesTab() {
  const section = useSettingsSection("wedding_modules", { items: [] }), items = mergeWeddingModules({ wedding_modules: section.value });
  const update = (key, next) => section.setValue({ items: items.map((item) => item.key === key ? next : item) });
  const move = (key, step) => { const index = items.findIndex((item) => item.key === key), target = index + step; if (target < 0 || target >= items.length) return; const next = [...items]; [next[index], next[target]] = [next[target], next[index]]; section.setValue({ items: next.map((item, order) => ({ ...item, order: order + 1 })) }); };
  return <div className="space-y-8"><div><h2 className="text-3xl font-light">Modules Mariage</h2><p className="mt-2 max-w-3xl text-sm text-muted-foreground">Cet éditeur pilote dans le même ordre la grande vitrine Mariage de l’accueil, la mosaïque « Tous les modules » et chaque page outil.</p></div><div className="border-y py-4"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Ordre et contenu de la plateforme</p><p className="mt-2 text-sm text-muted-foreground">Déplacez les modules, puis réglez leur titre, texte et visuel partagé.</p></div><div className="space-y-6">{items.map((item, index) => <WeddingModuleVisualEditor key={item.key} item={item} onChange={(next) => update(item.key, next)} onMoveUp={() => move(item.key, -1)} onMoveDown={() => move(item.key, 1)} first={index === 0} last={index === items.length - 1}/>)}</div><Button onClick={section.save} disabled={section.saving}>{section.saving ? "Enregistrement…" : section.saved ? "Modules enregistrés" : "Enregistrer les modules"}</Button></div>;
}