import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { REQUEST_STATUS } from "@/lib/frLabels";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function RequestsTab({ onCreateDoc }) {
  const queryClient = useQueryClient();
  const { data: requests = [] } = useQuery({
    queryKey: ["bookingRequests"],
    queryFn: () => base44.entities.BookingRequest.list("-created_date", 200),
  });
  const [openId, setOpenId] = useState(null);
  const [notes, setNotes] = useState("");

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["bookingRequests"] });

  const setStatus = async (request, status) => {
    await base44.entities.BookingRequest.update(request.id, { status });
    refresh();
  };

  const saveNotes = async (request) => {
    await base44.entities.BookingRequest.update(request.id, { admin_notes: notes });
    refresh();
  };

  if (requests.length === 0) {
    return <p className="font-mono text-sm text-muted-foreground py-8">Aucune demande pour le moment.</p>;
  }

  return (
    <div className="border-t border-border">
      {requests.map((request) => {
        const status = REQUEST_STATUS[request.status] || REQUEST_STATUS.nouveau;
        const isOpen = openId === request.id;
        return (
          <div key={request.id} className="border-b border-border">
            <button
              className="w-full flex items-center gap-4 py-4 text-left hover:bg-muted/40 transition-colors px-2"
              onClick={() => { setOpenId(isOpen ? null : request.id); setNotes(request.admin_notes || ""); }}
            >
              <span className={`font-mono text-[10px] px-2 py-1 rounded-full whitespace-nowrap ${status.color}`}>{status.label}</span>
              <div className="flex-1 min-w-0">
                <p className="font-body text-base text-foreground truncate">{request.name} — {request.event_type}</p>
                <p className="font-mono text-xs text-muted-foreground truncate">
                  {request.event_date ? format(new Date(request.event_date), "d MMMM yyyy", { locale: fr }) : "Date non précisée"}
                  {request.location ? ` · ${request.location}` : ""}
                </p>
              </div>
              <span className="font-mono text-xs text-muted-foreground whitespace-nowrap">
                reçu le {format(new Date(request.created_date), "d MMM", { locale: fr })}
              </span>
            </button>

            {isOpen && (
              <div className="px-2 pb-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-body text-sm text-foreground">
                  <p><span className="text-muted-foreground">Email : </span><a className="underline" href={`mailto:${request.email}`}>{request.email}</a></p>
                  {request.phone && <p><span className="text-muted-foreground">Téléphone : </span><a className="underline" href={`tel:${request.phone}`}>{request.phone}</a></p>}
                  {request.guests && <p><span className="text-muted-foreground">Invités : </span>{request.guests}</p>}
                  {request.location && <p><span className="text-muted-foreground">Lieu : </span>{request.location}</p>}
                </div>
                {request.message && (
                  <p className="font-body text-sm text-muted-foreground whitespace-pre-wrap border-l-2 border-border pl-4">{request.message}</p>
                )}

                <div className="flex flex-wrap items-center gap-3">
                  <Select value={request.status || "nouveau"} onValueChange={(v) => setStatus(request, v)}>
                    <SelectTrigger className="w-44 font-mono text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(REQUEST_STATUS).map(([value, s]) => (
                        <SelectItem key={value} value={value}>{s.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button variant="outline" className="font-mono text-xs" onClick={() => onCreateDoc(request, "devis")}>Créer un devis</Button>
                  <Button variant="outline" className="font-mono text-xs" onClick={() => onCreateDoc(request, "contrat")}>Créer un contrat</Button>
                  <Button variant="outline" className="font-mono text-xs" onClick={() => onCreateDoc(request, "facture")}>Créer une facture</Button>
                  <a href={`mailto:${request.email}?subject=${encodeURIComponent(`Votre demande — ${request.event_type}`)}`} className="font-mono text-xs underline text-foreground">Répondre par email ↗</a>
                </div>

                <div>
                  <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Notes internes</label>
                  <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
                  <Button size="sm" variant="outline" className="mt-2 font-mono text-xs" onClick={() => saveNotes(request)}>Enregistrer la note</Button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}