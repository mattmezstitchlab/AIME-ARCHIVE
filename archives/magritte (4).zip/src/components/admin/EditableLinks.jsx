import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, X } from "lucide-react";

export default function EditableLinks({ title, value = [], onChange }) {
  const update = (index, key, next) => onChange(value.map((item, i) => i === index ? { ...item, [key]: next } : item));
  return <div className="space-y-3"><h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{title}</h3>{value.map((item, index) => <div key={index} className="grid grid-cols-[1fr_1fr_auto] gap-2"><Input value={item.label || ""} onChange={(e) => update(index, "label", e.target.value)} placeholder="Libellé"/><Input value={item.url || ""} onChange={(e) => update(index, "url", e.target.value)} placeholder="Lien"/><Button type="button" variant="ghost" size="icon" onClick={() => onChange(value.filter((_, i) => i !== index))}><X className="h-4 w-4"/></Button></div>)}<Button type="button" variant="outline" size="sm" onClick={() => onChange([...value, { label: "", url: "" }])}><Plus className="h-4 w-4"/>Ajouter</Button></div>;
}