import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MediaField from "./MediaField";
import HeroSlideEditor from "./HeroSlideEditor";
import HeroVisualControls from "./HeroVisualControls";
import useSettingsSection from "./useSettingsSection";

const DEFAULTS = { mode: "current", title: "", subtitle: "", height_vh: 100, overlay_opacity: 40, media: { type: "image", url: "" }, slides: [] };
export default function HeroSettingsEditor() {
  const editor = useSettingsSection("hero", DEFAULTS);
  const { data: projects = [] } = useQuery({ queryKey: ["projects"], queryFn: () => base44.entities.Project.list("number", 100) });
  const set = (key, value) => editor.setValue({ ...editor.value, [key]: value });
  const setMedia = (key, value) => set("media", { ...editor.value.media, [key]: value });
  const full = editor.value.mode === "full_image" || editor.value.mode === "full_video";
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Présentation du hero</h2><p className="mt-2 text-sm text-muted-foreground">Choisissez la composition principale de l’accueil.</p></div>
    <Select value={editor.value.mode} onValueChange={(value) => set("mode", value)}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="current">Présentation actuelle</SelectItem><SelectItem value="full_image">Visuel plein écran</SelectItem><SelectItem value="full_video">Vidéo plein écran</SelectItem><SelectItem value="carousel">Carrousel éditorial</SelectItem></SelectContent></Select>
    {full && <div className="space-y-4 border border-border p-4"><Input value={editor.value.title} onChange={(e) => set("title", e.target.value)} placeholder="Grand titre"/><Input value={editor.value.subtitle} onChange={(e) => set("subtitle", e.target.value)} placeholder="Sous-titre"/><MediaField label={editor.value.mode === "full_video" ? "Vidéo" : "Visuel"} value={editor.value.media?.url || ""} onChange={(value) => setMedia("url", value)}/></div>}
    {editor.value.mode === "carousel" && <div className="space-y-4">{editor.value.slides.map((slide, index) => <HeroSlideEditor key={index} slide={slide} projects={projects} onChange={(next) => set("slides", editor.value.slides.map((item, i) => i === index ? next : item))} onRemove={() => set("slides", editor.value.slides.filter((_, i) => i !== index))}/>)}<Button type="button" variant="outline" onClick={() => set("slides", [...editor.value.slides, { source: "custom", media: { type: "image", url: "" } }])}>Ajouter une slide</Button></div>}
    {editor.value.mode !== "current" && <HeroVisualControls value={editor.value} onChange={set}/>} 
    <Button onClick={editor.save} disabled={editor.saving}>{editor.saving ? "Enregistrement…" : "Enregistrer le hero"}</Button>{editor.saved && <span className="ml-4 font-mono text-xs text-muted-foreground">Enregistré ✓</span>}
  </section>;
}