import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { DOC_TYPES, DOC_STATUS, formatEUR } from "@/lib/frLabels";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Pencil, Trash2, Plus, Link as LinkIcon, ExternalLink } from "lucide-react";
import DocumentEditor from "./DocumentEditor";

const PREFIX = { devis: "DEV", contrat: "CON", facture: "FAC" };

export default function DocumentsTab({ prefill, onPrefillConsumed }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: documents = [] } = useQuery({
    queryKey: ["documents"],
    queryFn: () => base44.entities.Document.list("-created_date", 200),
  });
  const [editing, setEditing] = useState(null); // null | "new" | document
  const [prefillData, setPrefillData] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (prefill) {
      const { request, docType } = prefill;
      const year = new Date().getFullYear();
      const count = documents.filter((d) => d.doc_type === docType).length + 1;
      setPrefillData({
        doc_type: docType,
        number: `${PREFIX[docType]}-${year}-${String(count).padStart(3, "0")}`,
        booking_id: request.id,
        client_name: request.name,
        client_email: request.email,
        client_phone: request.phone || "",
        event_type: request.event_type || "",
        event_date: request.event_date || "",
        event_location: request.location || "",
      });
      setEditing("new");
      onPrefillConsumed();
    }
  }, [prefill]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["documents"] });

  const handleSave = async (data) => {
    setSaving(true);
    if (editing === "new") {
      await base44.entities.Document.create(data);
    } else {
      await base44.entities.Document.update(editing.id, data);
    }
    setSaving(false);
    setEditing(null);
    setPrefillData(null);
    refresh();
  };

  const handleDelete = async (doc) => {
    if (!window.confirm(`Supprimer ${DOC_TYPES[doc.doc_type]} ${doc.number} ?`)) return;
    await base44.entities.Document.delete(doc.id);
    refresh();
  };

  const copyLink = (doc) => {
    navigator.clipboard.writeText(`${window.location.origin}/document/${doc.id}`);
    toast({ title: "Lien copié ! Envoyez-le à votre client." });
  };

  if (editing) {
    return (
      <div>
        <h2 className="font-body text-2xl font-light text-foreground mb-8">
          {editing === "new" ? "Nouveau document" : `Modifier — ${DOC_TYPES[editing.doc_type]} ${editing.number}`}
        </h2>
        <DocumentEditor
          key={editing === "new" ? `new-${prefillData?.booking_id || ""}` : editing.id}
          document={editing === "new" ? prefillData : editing}
          onSave={handleSave}
          onCancel={() => { setEditing(null); setPrefillData(null); }}
          saving={saving}
        />
      </div>
    );
  }

  return (
    <div>
      {documents.length === 0 ? (
        <p className="font-mono text-sm text-muted-foreground py-8">Aucun document. Créez un devis depuis une demande, ou ici.</p>
      ) : (
        <div className="border-t border-border">
          {documents.map((doc) => {
            const status = DOC_STATUS[doc.status] || DOC_STATUS.brouillon;
            return (
              <div key={doc.id} className="flex items-center gap-3 border-b border-border py-4">
                <span className={`font-mono text-[10px] px-2 py-1 rounded-full whitespace-nowrap ${status.color}`}>{status.label}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-body text-base text-foreground truncate">
                    {DOC_TYPES[doc.doc_type]} {doc.number} — {doc.client_name}
                  </p>
                  <p className="font-mono text-xs text-muted-foreground truncate">
                    {formatEUR(doc.total)}{Number(doc.deposit_amount) > 0 ? ` · acompte ${formatEUR(doc.deposit_amount)}` : ""}
                  </p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => copyLink(doc)} aria-label="Copier le lien client" title="Copier le lien client">
                  <LinkIcon className="w-4 h-4" />
                </Button>
                <a href={`/document/${doc.id}`} target="_blank" rel="noopener noreferrer" className="p-2 text-foreground hover:text-cobalt" aria-label="Ouvrir" title="Ouvrir">
                  <ExternalLink className="w-4 h-4" />
                </a>
                <Button variant="ghost" size="icon" onClick={() => setEditing(doc)} aria-label="Modifier">
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(doc)} aria-label="Supprimer">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
      <Button onClick={() => { setPrefillData(null); setEditing("new"); }} className="mt-8 font-mono text-xs tracking-widest uppercase">
        <Plus className="w-4 h-4 mr-2" />
        Nouveau document
      </Button>
    </div>
  );
}