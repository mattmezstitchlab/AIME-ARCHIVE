import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { REQUEST_STATUS } from "@/lib/frLabels";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, addMonths, format, isSameMonth, isToday } from "date-fns";
import { fr } from "date-fns/locale";

const DOT_COLORS = {
  nouveau: "bg-amber-500",
  en_discussion: "bg-blue-500",
  confirme: "bg-green-600",
  refuse: "bg-red-400",
  archive: "bg-gray-400",
};

export default function AgendaTab() {
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const { data: requests = [] } = useQuery({
    queryKey: ["bookingRequests"],
    queryFn: () => base44.entities.BookingRequest.list("-created_date", 200),
  });

  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(month), { weekStartsOn: 1 }),
    end: endOfWeek(endOfMonth(month), { weekStartsOn: 1 }),
  });

  const eventsOn = (day) => requests.filter((r) => r.event_date === format(day, "yyyy-MM-dd") && r.status !== "archive");

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-body text-2xl font-light text-foreground capitalize">{format(month, "MMMM yyyy", { locale: fr })}</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => setMonth((m) => addMonths(m, -1))} aria-label="Mois précédent"><ChevronLeft className="w-4 h-4" /></Button>
          <Button variant="outline" size="icon" onClick={() => setMonth(startOfMonth(new Date()))} aria-label="Aujourd'hui" className="font-mono text-xs w-auto px-3">Auj.</Button>
          <Button variant="outline" size="icon" onClick={() => setMonth((m) => addMonths(m, 1))} aria-label="Mois suivant"><ChevronRight className="w-4 h-4" /></Button>
        </div>
      </div>

      <div className="grid grid-cols-7 border-l border-t border-border">
        {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((d) => (
          <div key={d} className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground p-2 border-r border-b border-border bg-muted/30">{d}</div>
        ))}
        {days.map((day) => {
          const events = eventsOn(day);
          return (
            <div key={day.toISOString()} className={`min-h-[90px] p-2 border-r border-b border-border ${isSameMonth(day, month) ? "" : "bg-muted/20 opacity-50"}`}>
              <span className={`font-mono text-xs ${isToday(day) ? "bg-cobalt text-white px-1.5 py-0.5 rounded-full" : "text-muted-foreground"}`}>
                {format(day, "d")}
              </span>
              <div className="mt-1 space-y-1">
                {events.map((ev) => (
                  <div key={ev.id} className="flex items-center gap-1.5" title={`${ev.name} — ${ev.event_type} (${REQUEST_STATUS[ev.status]?.label})`}>
                    <span className={`w-2 h-2 rounded-full flex-shrink-0 ${DOT_COLORS[ev.status] || "bg-gray-400"}`} />
                    <span className="font-body text-xs text-foreground truncate">{ev.event_type} · {ev.name}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex flex-wrap gap-4 mt-4">
        {Object.entries(REQUEST_STATUS).filter(([k]) => k !== "archive").map(([key, s]) => (
          <span key={key} className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
            <span className={`w-2 h-2 rounded-full ${DOT_COLORS[key]}`} />{s.label}
          </span>
        ))}
      </div>
    </div>
  );
}