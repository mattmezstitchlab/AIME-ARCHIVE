import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { ArrowUp, ArrowDown } from "lucide-react";
import MediaField from "./MediaField";
import ModuleVisualPreview from "./ModuleVisualPreview";

export default function WeddingModuleVisualEditor({ item, onChange, onMoveUp, onMoveDown, first, last }) {
  const set = (key, value) => onChange({ ...item, [key]: value });
  return <article className="space-y-6 border border-border p-5 md:p-6"><div className="flex flex-wrap items-center justify-between gap-4"><div><span className="font-mono text-xs text-primary">{item.number}</span><h3 className="text-2xl font-light">{item.title}</h3></div><div className="flex items-center gap-2"><label className="mr-2 flex items-center gap-2 text-sm"><input type="checkbox" checked={item.visible !== false} onChange={(event) => set("visible", event.target.checked)}/>Visible</label><Button type="button" size="icon" variant="outline" onClick={onMoveUp} disabled={first} aria-label={`Monter ${item.title}`}><ArrowUp/></Button><Button type="button" size="icon" variant="outline" onClick={onMoveDown} disabled={last} aria-label={`Descendre ${item.title}`}><ArrowDown/></Button><span className="w-8 text-center font-mono text-xs">{item.order}</span></div></div>
    <div className="grid gap-4 md:grid-cols-2"><label className="space-y-2 text-sm"><span>Titre</span><Input aria-label={`${item.key} titre`} value={item.title} onChange={(event) => set("title", event.target.value)}/></label><MediaField label="Visuel partagé" value={item.image} onChange={(value) => set("image", value)}/></div><label className="block space-y-2 text-sm"><span>Présentation</span><Textarea value={item.description} onChange={(event) => set("description", event.target.value)} rows={2}/></label>
    <div className="grid gap-5 md:grid-cols-2">{[["overlay_light", "Filtre mode jour"], ["overlay_dark", "Filtre mode nuit"]].map(([key, label]) => <label key={key} className="space-y-3"><span className="flex items-center justify-between text-sm"><span>{label}</span><Input aria-label={`${item.title} ${label}`} type="number" min="0" max="85" value={item[key]} onChange={(event) => set(key, Number(event.target.value))} className="w-20"/></span><Slider min={0} max={85} step={1} value={[item[key]]} onValueChange={([next]) => set(key, next)}/></label>)}</div><div className="grid gap-4 md:grid-cols-2"><ModuleVisualPreview item={item}/><ModuleVisualPreview item={item} dark/></div>
  </article>;
}