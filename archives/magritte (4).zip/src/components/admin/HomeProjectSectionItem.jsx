import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function HomeProjectSectionItem({ project, value, onChange }) {
  const set = (key, next) => onChange({ ...value, [key]: next });
  return (
    <article className="space-y-5 border border-border p-4 md:p-6">
      <div className="flex items-center justify-between gap-4">
        <div><span className="font-mono text-xs text-muted-foreground">{project.number}</span><h3 className="text-xl font-light">{project.title}</h3></div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={value.visible} onChange={(e) => set("visible", e.target.checked)} />Afficher</label>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <label className="space-y-2 text-sm"><span>Ordre</span><Input type="number" value={value.order} onChange={(e) => set("order", Number(e.target.value))} /></label>
        <label className="space-y-2 text-sm"><span>Mise en page</span><Select value={value.layout} onValueChange={(next) => set("layout", next)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="split">Mise en page actuelle</SelectItem><SelectItem value="full">Plein écran superposé</SelectItem><SelectItem value="editorial">Visuel puis éditorial</SelectItem></SelectContent></Select></label>
        <label className="space-y-2 text-sm"><span>Fond éditorial</span><Select value={value.theme} onValueChange={(next) => set("theme", next)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="light">Clair</SelectItem><SelectItem value="dark">Noir</SelectItem><SelectItem value="color">Cobalt</SelectItem></SelectContent></Select></label>
      </div>
      <div className="grid gap-4 md:grid-cols-2"><label className="space-y-2 text-sm"><span>Étiquette</span><Input value={value.label} onChange={(e) => set("label", e.target.value)} placeholder={project.category} /></label><label className="space-y-2 text-sm"><span>Grand titre</span><Input value={value.title} onChange={(e) => set("title", e.target.value)} placeholder={project.title} /></label></div>
      <label className="block space-y-2 text-sm"><span>Introduction</span><Textarea value={value.intro} onChange={(e) => set("intro", e.target.value)} placeholder={project.subtitle} rows={2} /></label>
      <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Le visuel provient du média principal configuré dans Projets.</p>
    </article>
  );
}