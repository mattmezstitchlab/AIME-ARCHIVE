import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import MediaField from "./MediaField";

const categories = ["Photographe", "Vidéaste", "Wedding planner", "Lieu", "Traiteur", "Fleuriste", "Musicien", "Saxophoniste", "DJ", "Décoration", "Papeterie", "Beauté", "Autre"];
const fields = [["location", "Zone géographique"], ["price_range", "Budget indicatif"], ["website", "Site internet"], ["instagram", "Instagram"], ["email", "Email"], ["phone", "Téléphone"]];

export default function ProviderFormFields({ form, setField }) {
  return <div className="space-y-5">
    <div className="grid md:grid-cols-2 gap-5">
      <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Nom<Input value={form.name} onChange={(e) => setField("name", e.target.value)} className="mt-2" required /></label>
      <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Slug<Input value={form.slug} onChange={(e) => setField("slug", e.target.value)} className="mt-2" required /></label>
      <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Catégorie<select value={form.category} onChange={(e) => setField("category", e.target.value)} className="h-9 w-full border border-input bg-background px-3 mt-2 text-sm">{categories.map((item) => <option key={item}>{item}</option>)}</select></label>
      <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Publication<select value={form.status} onChange={(e) => setField("status", e.target.value)} className="h-9 w-full border border-input bg-background px-3 mt-2 text-sm"><option value="brouillon">Brouillon</option><option value="publie">Publié</option></select></label>
      {fields.map(([key, label]) => <label key={key} className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{label}<Input value={form[key]} onChange={(e) => setField(key, e.target.value)} className="mt-2" /></label>)}
    </div>
    <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground block">Description<Textarea value={form.description} onChange={(e) => setField("description", e.target.value)} className="mt-2 min-h-32" /></label>
    <MediaField label="Photo principale" value={form.image} onChange={(value) => setField("image", value)} />
    <label className="flex items-center gap-3 font-body text-sm"><input type="checkbox" checked={form.featured} onChange={(e) => setField("featured", e.target.checked)} />Mettre en avant</label>
    <label className="flex items-center gap-3 font-body text-sm"><input type="checkbox" checked={form.passport_enabled || false} onChange={(e) => setField("passport_enabled", e.target.checked)} />Activer l’accès Passport</label>
  </div>;
}