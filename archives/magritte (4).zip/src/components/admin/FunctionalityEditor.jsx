import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export default function FunctionalityEditor({ initial, onSave, onCancel }) {
  const [value, setValue] = useState(initial || { name: "", slug: "", category: "", summary: "" });
  const set = (key, next) => setValue({ ...value, [key]: next });
  return <div className="space-y-4 border border-border p-5"><Input value={value.name || ""} onChange={(e) => set("name", e.target.value)} placeholder="Nom du module"/><Input value={value.slug || ""} onChange={(e) => set("slug", e.target.value)} placeholder="Identifiant, ex. gestion-invites"/><Input value={value.category || ""} onChange={(e) => set("category", e.target.value)} placeholder="Catégorie"/><Textarea value={value.summary || ""} onChange={(e) => set("summary", e.target.value)} placeholder="Définition commune de la fonctionnalité"/><div className="flex gap-2"><Button onClick={() => onSave(value)} disabled={!value.name || !value.slug}>Enregistrer</Button><Button variant="outline" onClick={onCancel}>Annuler</Button></div></div>;
}