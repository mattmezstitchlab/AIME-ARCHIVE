import React, { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

export default function FeatureEditorialGenerator({ feature, projectTitle, onGenerated }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const generate = async () => {
    const idea = [feature.title, feature.status, feature.description, feature.link, feature.link_label].filter(Boolean).join(" | ");
    if (!idea) return setError("Saisissez d’abord une idée, même très courte.");
    setError("");
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es directeur éditorial d’un portfolio de design haut de gamme. Pour le projet « ${projectTitle || "Mariage"} », transforme cette idée brute en fiche de fonctionnalité professionnelle en français : ${idea}. Le titre doit être clair et court. Le statut doit être « Disponible », « En conception » ou « En cours ». La description doit tenir en une ou deux phrases précises, élégantes et concrètes, sans superlatif. Conserve exactement le lien existant s’il est fourni ; sinon utilise /contact. Crée un libellé d’action concis et naturel.`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" }, status: { type: "string" }, description: { type: "string" },
            link: { type: "string" }, link_label: { type: "string" }
          },
          required: ["title", "status", "description", "link", "link_label"]
        }
      });
      onGenerated({ ...feature, ...result, image: feature.image || "" });
    } catch {
      setError("La génération a échoué. Réessayez dans un instant.");
    } finally {
      setLoading(false);
    }
  };
  return <div><Button type="button" variant="outline" onClick={generate} disabled={loading} data-testid="generate-editorial">{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}{loading ? "Rédaction en cours…" : "Générer le contenu éditorial"}</Button>{error && <p className="mt-2 text-sm text-destructive">{error}</p>}</div>;
}