import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import EditableLinks from "./EditableLinks";
import useSettingsSection from "./useSettingsSection";

const DEFAULTS = { services: ["Mariage", "Concert", "Soirée privée", "Entreprise", "Festival", "Cocktail"], navigation: [{ label: "Accueil", url: "/" }, { label: "À propos", url: "/about" }, { label: "Contact", url: "/contact" }], socials: [{ label: "Instagram", url: "https://instagram.com" }], legal_links: [{ label: "Confidentialité", url: "/privacy" }, { label: "Accessibilité", url: "/accessibility" }], email: "contact@alexmoreau.fr", location: "Paris, France", copyright: "© 2026 Alex Moreau. Créé avec Base44." };
export default function FooterTab() {
  const editor = useSettingsSection("footer", DEFAULTS);
  const set = (key, value) => editor.setValue({ ...editor.value, [key]: value });
  return <div className="space-y-8"><div><h2 className="text-2xl font-light">Footer</h2><p className="mt-2 text-sm text-muted-foreground">Navigation, contact, réseaux et mentions légales.</p></div>
    <label className="space-y-2 text-sm"><span>Services du bandeau, séparés par des virgules</span><Input value={editor.value.services.join(", ")} onChange={(e) => set("services", e.target.value.split(",").map((item) => item.trim()).filter(Boolean))}/></label>
    <div className="grid gap-4 md:grid-cols-2"><Input value={editor.value.email} onChange={(e) => set("email", e.target.value)} placeholder="Email"/><Input value={editor.value.location} onChange={(e) => set("location", e.target.value)} placeholder="Localisation"/></div>
    <EditableLinks title="Navigation" value={editor.value.navigation} onChange={(value) => set("navigation", value)}/><EditableLinks title="Réseaux" value={editor.value.socials} onChange={(value) => set("socials", value)}/><EditableLinks title="Mentions légales" value={editor.value.legal_links} onChange={(value) => set("legal_links", value)}/>
    <Input value={editor.value.copyright} onChange={(e) => set("copyright", e.target.value)} placeholder="Copyright"/>
    <Button onClick={editor.save} disabled={editor.saving}>{editor.saving ? "Enregistrement…" : "Enregistrer le footer"}</Button>{editor.saved && <span className="ml-4 font-mono text-xs text-muted-foreground">Enregistré ✓</span>}
  </div>;
}