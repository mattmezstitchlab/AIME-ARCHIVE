import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import TextsTab from "./TextsTab";
import useSettingsSection from "./useSettingsSection";
import { TEXT_GROUPS } from "@/lib/siteTexts";

const contactGroups = TEXT_GROUPS.filter((group) => group.id === "contact");

export default function ContactTab() {
  const editor = useSettingsSection("contact", { selected_passport_ids: [] });
  const { data: passports = [] } = useQuery({ queryKey: ["admin-contact-passports"], queryFn: () => base44.entities.Passport.filter({ status: "actif" }, "name", 100) });
  const selected = editor.value.selected_passport_ids || [];
  const toggle = (id) => editor.setValue({ selected_passport_ids: selected.includes(id) ? selected.filter((item) => item !== id) : [...selected, id] });
  return <div className="space-y-12"><TextsTab groups={contactGroups} saveLabel="Enregistrer les textes de contact"/><section className="space-y-5 border-t pt-10"><div><h2 className="text-2xl font-light">Passports mis en avant</h2><p className="mt-2 text-sm text-muted-foreground">Cochez les cartes à présenter sur la page Contact.</p></div><div className="grid gap-3 md:grid-cols-2">{passports.map((passport) => <label key={passport.id} className="flex items-center gap-3 border p-4"><input type="checkbox" checked={selected.includes(passport.id)} onChange={() => toggle(passport.id)}/><span><strong className="block font-normal">{passport.name}</strong><small className="text-muted-foreground">{passport.profession} · {passport.status}</small></span></label>)}</div><div className="flex items-center gap-4 border-t pt-6"><Button onClick={editor.save} disabled={editor.saving}>{editor.saving ? "Enregistrement…" : "Enregistrer la sélection"}</Button>{editor.saved && <span className="font-mono text-xs text-muted-foreground">Enregistré ✓</span>}</div></section></div>;
}