import React from "react";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";

export default function ProviderRow({ provider, onEdit, onDelete }) {
  return <div className="flex items-center gap-4 border-b border-border py-4">
    <div className="w-14 h-14 bg-muted flex-shrink-0">{provider.image && <img src={provider.image} alt="" className="w-full h-full object-cover" />}</div>
    <div className="flex-1 min-w-0"><div className="flex items-center gap-2"><p className="font-body text-lg font-light truncate">{provider.name}</p><span className="font-mono text-[10px] uppercase text-muted-foreground">{provider.status === "publie" ? "Publié" : "Brouillon"}</span></div><p className="font-mono text-xs text-muted-foreground truncate">{provider.category} · {provider.location || "Zone non renseignée"}</p></div>
    <Button variant="ghost" size="icon" onClick={() => onEdit(provider)} aria-label={`Modifier ${provider.name}`}><Pencil className="w-4 h-4" /></Button>
    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => onDelete(provider)} aria-label={`Supprimer ${provider.name}`}><Trash2 className="w-4 h-4" /></Button>
  </div>;
}