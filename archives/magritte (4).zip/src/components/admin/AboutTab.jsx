import React from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import PageSectionEditor from "./PageSectionEditor";
import { usePageSectionEditor } from "./usePageSectionEditor";

export default function AboutTab() {
  const editor = usePageSectionEditor("about");
  if (editor.isLoading) return <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground/20 border-t-foreground" />;
  return <div className="space-y-6">
    <div><h2 className="text-2xl font-light">À propos d’AIME®</h2><p className="mt-2 text-sm text-muted-foreground">Modifiez, réorganisez et ajoutez les sections de la page publique.</p></div>
    {editor.items.map((section, index) => <PageSectionEditor key={section.id} section={section} index={index} total={editor.items.length} editor={editor} />)}
    <Button type="button" variant="outline" onClick={editor.add}><Plus className="h-4 w-4" />Ajouter une section</Button>
    {editor.error && <p className="text-sm text-destructive">{editor.error}</p>}
    <div className="flex items-center gap-4 border-t pt-6"><Button onClick={editor.save} disabled={editor.saving}>{editor.saving && <Loader2 className="h-4 w-4 animate-spin" />}Enregistrer la page</Button>{editor.saved && !editor.saving && <span className="font-mono text-xs text-muted-foreground">Enregistré ✓</span>}</div>
  </div>;
}