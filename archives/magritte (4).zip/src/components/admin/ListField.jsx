import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X, Plus } from "lucide-react";

export default function ListField({ label, value = [], onChange }) {
  const [newItem, setNewItem] = useState("");

  const add = () => {
    if (!newItem.trim()) return;
    onChange([...value, newItem.trim()]);
    setNewItem("");
  };

  return (
    <div>
      <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">{label}</label>
      <div className="space-y-2">
        {value.map((item, i) => (
          <div key={i} className="flex items-center gap-2">
            <Input
              value={item}
              onChange={(e) => onChange(value.map((v, j) => (j === i ? e.target.value : v)))}
              className="text-sm"
            />
            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-destructive flex-shrink-0" onClick={() => onChange(value.filter((_, j) => j !== i))}>
              <X className="w-3 h-3" />
            </Button>
          </div>
        ))}
        <div className="flex gap-2">
          <Input
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); add(); } }}
            placeholder="Ajouter…"
            className="text-sm"
          />
          <Button type="button" variant="outline" size="icon" className="flex-shrink-0" onClick={add}><Plus className="w-4 h-4" /></Button>
        </div>
      </div>
    </div>
  );
}