import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import FunctionalityEditor from "./FunctionalityEditor";
import { Pencil, Plus, Trash2 } from "lucide-react";

export default function FunctionalitiesTab() {
  const queryClient = useQueryClient();
  const { data: items = [] } = useQuery({ queryKey: ["functionalities"], queryFn: () => base44.entities.Functionality.list("name", 200) });
  const [editing, setEditing] = useState(null);
  const save = async (value) => { if (value.id) await base44.entities.Functionality.update(value.id, value); else await base44.entities.Functionality.create(value); await queryClient.invalidateQueries({ queryKey: ["functionalities"] }); setEditing(null); };
  const remove = async (item) => { await base44.entities.Functionality.delete(item.id); await queryClient.invalidateQueries({ queryKey: ["functionalities"] }); };
  if (editing !== null) return <FunctionalityEditor initial={editing || undefined} onSave={save} onCancel={() => setEditing(null)}/>;
  return <div className="space-y-6"><div className="flex items-end justify-between gap-4"><div><h2 className="text-2xl font-light">Fonctionnalités</h2><p className="mt-2 text-sm text-muted-foreground">Catalogue commun des modules, indépendant de leur présentation dans chaque projet.</p></div><Button onClick={() => setEditing({})}><Plus className="h-4 w-4"/>Ajouter</Button></div>{items.map((item) => <div key={item.id} className="flex items-start justify-between gap-4 border-b border-border py-4"><div><h3 className="text-lg">{item.name}</h3><p className="mt-1 text-sm text-muted-foreground">{item.summary}</p></div><div className="flex"><Button variant="ghost" size="icon" aria-label={`Modifier ${item.name}`} onClick={() => setEditing(item)}><Pencil className="h-4 w-4"/></Button><Button variant="ghost" size="icon" aria-label={`Supprimer ${item.name}`} onClick={() => remove(item)}><Trash2 className="h-4 w-4"/></Button></div></div>)}</div>;
}