import React from "react";
import { Button } from "@/components/ui/button";
import useSettingsSection from "./useSettingsSection";
import PaletteEditor from "./PaletteEditor";

const defaults = { light: { background: "#F6F6F6", primary: "#2E5BFF", accent: "#A3B18A" }, dark: { background: "#121212", primary: "#5B7CFF", accent: "#A3B18A" } };
export default function DesignSystemTab() {
  const section = useSettingsSection("design_system", defaults);
  const set = (mode, key, next) => section.setValue((current) => ({ ...current, [mode]: { ...current[mode], [key]: next } }));
  return <div className="space-y-8"><div><h2 className="text-3xl font-light">Design System</h2><p className="mt-2 max-w-2xl text-sm text-muted-foreground">Pilotez les couleurs principales des modes jour et nuit. La couleur du texte est calculée automatiquement pour éviter le noir sur noir ou le blanc sur blanc.</p></div><div className="grid gap-6 lg:grid-cols-2"><PaletteEditor label="Mode jour" value={section.value.light} onChange={(key, next) => set("light", key, next)}/><PaletteEditor label="Mode nuit" value={section.value.dark} onChange={(key, next) => set("dark", key, next)}/></div><Button onClick={section.save} disabled={section.saving}>{section.saving ? "Enregistrement…" : section.saved ? "Palette enregistrée" : "Enregistrer le Design System"}</Button></div>;
}