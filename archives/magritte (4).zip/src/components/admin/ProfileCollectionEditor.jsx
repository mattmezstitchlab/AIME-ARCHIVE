import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import ProfileVisibility from "./ProfileVisibility";
import ProfileCollectionItem from "./ProfileCollectionItem";

export default function ProfileCollectionEditor({ title, heading, items, type, onChange, onRemove, onAdd }) {
  return <section className="space-y-5"><h2 className="border-b border-border pb-3 text-2xl font-light">{title}</h2>
    {heading && <div className="space-y-2"><label className="block font-mono text-xs uppercase tracking-widest text-muted-foreground">Titre de la section</label><Input value={heading.value || ""} onChange={(e) => onChange(heading, { ...heading, value: e.target.value })}/><ProfileVisibility visible={heading.visible} onChange={(visible) => onChange(heading, { ...heading, visible })}/></div>}
    <div className="space-y-4">{items.map((item) => <ProfileCollectionItem key={item.id || item.key} item={item} type={type} onChange={(next) => onChange(item, next)} onRemove={() => onRemove(item)}/>)}</div>
    <Button type="button" variant="outline" onClick={onAdd}><Plus className="h-4 w-4"/>Ajouter</Button>
  </section>;
}