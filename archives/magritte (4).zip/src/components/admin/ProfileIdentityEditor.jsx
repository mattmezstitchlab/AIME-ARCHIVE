import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import MediaField from "./MediaField";
import ProfileVisibility from "./ProfileVisibility";

export default function ProfileIdentityEditor({ items, onChange }) {
  return <section><h2 className="mb-6 border-b border-border pb-3 text-2xl font-light">À propos & identité</h2><div className="space-y-6">{items.map((item) => <div key={item.key} data-profile-key={item.key} className="space-y-2 border-b border-border pb-5">
    {item.kind === "image" ? <MediaField label={item.label} value={item.value || ""} onChange={(value) => onChange(item, { ...item, value })} /> : <><label className="block font-mono text-xs uppercase tracking-widest text-muted-foreground">{item.label}</label>{item.kind === "textarea" ? <Textarea rows={3} value={item.value || ""} onChange={(e) => onChange(item, { ...item, value: e.target.value })} /> : <Input value={item.value || ""} onChange={(e) => onChange(item, { ...item, value: e.target.value })} />}</>}
    <ProfileVisibility visible={item.visible} onChange={(visible) => onChange(item, { ...item, visible })} />
  </div>)}</div></section>;
}