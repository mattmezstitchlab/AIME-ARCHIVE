import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import ProfileVisibility from "./ProfileVisibility";

export default function ProfileCollectionItem({ item, type, onChange, onRemove }) {
  return <div className="space-y-3 border border-border p-4">
    <div className="flex justify-end"><Button type="button" variant="ghost" size="icon" onClick={onRemove} aria-label="Supprimer"><X className="h-4 w-4"/></Button></div>
    <Input value={item.label || ""} onChange={(e) => onChange({ ...item, label: e.target.value })} placeholder={type === "timeline" ? "Intitulé" : "Catégorie"} />
    {type === "timeline" ? <><Input value={item.value || ""} onChange={(e) => onChange({ ...item, value: e.target.value })} placeholder="Période"/><Textarea rows={3} value={item.description || ""} onChange={(e) => onChange({ ...item, description: e.target.value })} placeholder="Description"/></> : <Textarea rows={5} value={(item.items || []).join("\n")} onChange={(e) => onChange({ ...item, items: e.target.value.split("\n").filter(Boolean) })} placeholder="Une prestation par ligne"/>}
    <ProfileVisibility visible={item.visible} onChange={(visible) => onChange({ ...item, visible })}/>
  </div>;
}