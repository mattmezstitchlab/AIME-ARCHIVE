import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import MediaField from "./MediaField";
import GalleryField from "./GalleryField";
import ListField from "./ListField";
import ProjectFeaturesField from "./ProjectFeaturesField";
import ProjectHeroMediaEditor from "@/components/admin/ProjectHeroMediaEditor";

const TEXT_FIELDS = [
  ["number", "Numéro (ex: 01)"],
  ["title", "Titre"],
  ["slug", "Slug (URL — laissé vide = généré)"],
  ["subtitle", "Sous-titre"],
  ["role", "Rôle"],
  ["year", "Année"],
  ["category", "Catégorie"],
  ["tagline", "Accroche"],
];

const AREA_FIELDS = [
  ["objective", "Objectif"],
  ["description", "Description"],
  ["problem", "Problème"],
  ["solution", "Solution"],
  ["process", "Processus"],
];

const EMPTY = {
  number: "", title: "", slug: "", subtitle: "", role: "", year: "", category: "",
  tagline: "", objective: "", description: "", problem: "", solution: "", process: "",
  outcomes: [], deliverables: [], image: "", heroImage: "", hero_media: {}, processImage: "", images: [], features: [],
};

export default function ProjectEditor({ project, onSave, onCancel, saving }) {
  const [form, setForm] = useState({ ...EMPTY, ...project });
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    const slug = (form.slug || form.title).toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const data = {};
    Object.keys(EMPTY).forEach((k) => { data[k] = form[k]; });
    onSave({ ...data, slug });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {TEXT_FIELDS.map(([key, label]) => (
          <div key={key}>
            <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">{label}</label>
            <Input value={form[key]} onChange={(e) => set(key, e.target.value)} required={key === "title"} />
          </div>
        ))}
      </div>

      <div className="space-y-4">
        {AREA_FIELDS.map(([key, label]) => (
          <div key={key}>
            <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">{label}</label>
            <Textarea value={form[key]} onChange={(e) => set(key, e.target.value)} rows={3} />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ListField label="Résultats" value={form.outcomes} onChange={(v) => set("outcomes", v)} />
        <ListField label="Livrables" value={form.deliverables} onChange={(v) => set("deliverables", v)} />
      </div>

      <ProjectFeaturesField value={form.features} projectTitle={form.title} onChange={(v) => set("features", v)} />

      <div className="space-y-4 border-t border-border pt-8">
        <MediaField label="Vignette (liste des projets)" value={form.image} onChange={(v) => set("image", v)} />
        <ProjectHeroMediaEditor value={form.hero_media} fallbackUrl={form.heroImage} onChange={(media) => { set("hero_media", media); if (media.type === "image") set("heroImage", media.url); }} />
        <MediaField label="Image processus" value={form.processImage} onChange={(v) => set("processImage", v)} />
        <GalleryField label="Galerie (images & vidéos)" value={form.images} onChange={(v) => set("images", v)} />
      </div>

      <div className="flex gap-3 border-t border-border pt-6">
        <Button type="submit" disabled={saving} className="font-mono text-xs tracking-widest uppercase">
          {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          Enregistrer
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} className="font-mono text-xs tracking-widest uppercase">
          Annuler
        </Button>
      </div>
    </form>
  );
}