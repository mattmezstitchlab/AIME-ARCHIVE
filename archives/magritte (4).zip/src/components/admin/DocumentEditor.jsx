import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DOC_TYPES, DOC_STATUS, formatEUR } from "@/lib/frLabels";
import { Loader2, Plus, X } from "lucide-react";

const EMPTY = {
  doc_type: "devis", number: "", client_name: "", client_email: "", client_phone: "",
  event_type: "", event_date: "", event_location: "", items: [], total: 0,
  deposit_amount: 0, status: "brouillon", notes: "", booking_id: "",
};

export default function DocumentEditor({ document: doc, onSave, onCancel, saving }) {
  const [form, setForm] = useState({ ...EMPTY, ...doc });
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const items = form.items || [];
  const total = items.reduce((sum, it) => sum + (Number(it.quantity) || 0) * (Number(it.unit_price) || 0), 0);

  const setItem = (i, key, value) => {
    const next = items.map((it, j) => (j === i ? { ...it, [key]: value } : it));
    set("items", next);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {};
    Object.keys(EMPTY).forEach((k) => { data[k] = form[k]; });
    data.total = total;
    data.deposit_amount = Number(form.deposit_amount) || 0;
    data.items = items.map((it) => ({ description: it.description || "", quantity: Number(it.quantity) || 1, unit_price: Number(it.unit_price) || 0 }));
    onSave(data);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Type</label>
          <Select value={form.doc_type} onValueChange={(v) => set("doc_type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(DOC_TYPES).map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Numéro</label>
          <Input value={form.number} onChange={(e) => set("number", e.target.value)} placeholder="ex : DEV-2026-001" />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Statut</label>
          <Select value={form.status} onValueChange={(v) => set("status", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(DOC_STATUS).map(([value, s]) => <SelectItem key={value} value={value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Client *</label>
          <Input value={form.client_name} onChange={(e) => set("client_name", e.target.value)} required />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Email client</label>
          <Input type="email" value={form.client_email} onChange={(e) => set("client_email", e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Téléphone client</label>
          <Input value={form.client_phone} onChange={(e) => set("client_phone", e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Type d'événement</label>
          <Input value={form.event_type} onChange={(e) => set("event_type", e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Date de l'événement</label>
          <Input type="date" value={form.event_date} onChange={(e) => set("event_date", e.target.value)} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Lieu</label>
          <Input value={form.event_location} onChange={(e) => set("event_location", e.target.value)} />
        </div>
      </div>

      <div>
        <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Prestations</label>
        <div className="space-y-2">
          {items.map((item, i) => (
            <div key={i} className="flex gap-2 items-center">
              <Input className="flex-1" placeholder="Description" value={item.description || ""} onChange={(e) => setItem(i, "description", e.target.value)} />
              <Input className="w-20" type="number" min="0" step="1" placeholder="Qté" value={item.quantity ?? 1} onChange={(e) => setItem(i, "quantity", e.target.value)} />
              <Input className="w-32" type="number" min="0" step="0.01" placeholder="P.U. €" value={item.unit_price ?? ""} onChange={(e) => setItem(i, "unit_price", e.target.value)} />
              <Button type="button" variant="ghost" size="icon" className="text-destructive flex-shrink-0" onClick={() => set("items", items.filter((_, j) => j !== i))}><X className="w-4 h-4" /></Button>
            </div>
          ))}
          <Button type="button" variant="outline" size="sm" className="font-mono text-xs" onClick={() => set("items", [...items, { description: "", quantity: 1, unit_price: 0 }])}>
            <Plus className="w-3 h-3 mr-2" />Ajouter une ligne
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap items-end gap-6">
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Acompte demandé (€)</label>
          <Input className="w-40" type="number" min="0" step="0.01" value={form.deposit_amount} onChange={(e) => set("deposit_amount", e.target.value)} />
        </div>
        <p className="font-body text-lg text-foreground pb-2">Total : <strong>{formatEUR(total)}</strong></p>
      </div>

      <div>
        <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Conditions / Notes (visibles par le client)</label>
        <Textarea rows={4} value={form.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Conditions d'annulation, matériel fourni, horaires…" />
      </div>

      <div className="flex gap-3 border-t border-border pt-6">
        <Button type="submit" disabled={saving} className="font-mono text-xs tracking-widest uppercase">
          {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          Enregistrer
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} className="font-mono text-xs tracking-widest uppercase">Annuler</Button>
      </div>
    </form>
  );
}