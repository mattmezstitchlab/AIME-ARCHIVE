import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

export default function PageSectionItemsEditor({ items = [], onChange, onAdd, onRemove }) {
  return <div className="space-y-4 border-t border-border pt-5">
    <div className="flex items-center justify-between"><p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Éléments</p><Button type="button" variant="outline" size="sm" onClick={onAdd}>Ajouter un élément</Button></div>
    {items.map((item, index) => <div key={index} className="grid gap-3 border border-border p-4 md:grid-cols-2">
      <Input value={item.meta || ""} onChange={(e) => onChange(index, "meta", e.target.value)} placeholder="Repère ou date" />
      <div className="flex gap-2"><Input value={item.title || ""} onChange={(e) => onChange(index, "title", e.target.value)} placeholder="Titre" /><Button type="button" variant="ghost" size="icon" onClick={() => onRemove(index)} aria-label="Supprimer l’élément"><Trash2 className="h-4 w-4" /></Button></div>
      <Textarea className="md:col-span-2" rows={2} value={item.text || ""} onChange={(e) => onChange(index, "text", e.target.value)} placeholder="Description" />
    </div>)}
  </div>;
}