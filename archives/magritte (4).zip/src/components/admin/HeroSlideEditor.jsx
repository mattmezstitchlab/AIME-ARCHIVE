import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import MediaField from "./MediaField";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";

export default function HeroSlideEditor({ slide, projects, onChange, onRemove }) {
  const set = (key, value) => onChange({ ...slide, [key]: value });
  const setMedia = (key, value) => onChange({ ...slide, media: { ...slide.media, [key]: value } });
  return <div className="space-y-4 border border-border p-4">
    <div className="flex justify-between"><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Slide</span><Button type="button" variant="ghost" size="icon" onClick={onRemove}><X className="h-4 w-4"/></Button></div>
    <Select value={slide.source || "custom"} onValueChange={(value) => set("source", value)}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="custom">Contenu autonome</SelectItem><SelectItem value="project">Projet sélectionné</SelectItem><SelectItem value="media">Média uniquement</SelectItem></SelectContent></Select>
    {slide.source === "project" ? <Select value={slide.project_id || ""} onValueChange={(value) => set("project_id", value)}><SelectTrigger><SelectValue placeholder="Choisir un projet"/></SelectTrigger><SelectContent>{projects.map((project) => <SelectItem key={project.id} value={project.id}>{project.title}</SelectItem>)}</SelectContent></Select> : <><Select value={slide.media?.type || "image"} onValueChange={(value) => setMedia("type", value)}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="image">Image</SelectItem><SelectItem value="video">Vidéo</SelectItem><SelectItem value="embed">Page intégrée</SelectItem></SelectContent></Select><MediaField label="Média" value={slide.media?.url || ""} onChange={(value) => setMedia("url", value)}/></>}
    {slide.source !== "media" && <><Input value={slide.title || ""} onChange={(e) => set("title", e.target.value)} placeholder="Titre (facultatif pour un projet)"/><Input value={slide.subtitle || ""} onChange={(e) => set("subtitle", e.target.value)} placeholder="Sous-titre"/></>}
    <div className="grid gap-3 md:grid-cols-2"><Input value={slide.link || ""} onChange={(e) => set("link", e.target.value)} placeholder="Lien"/><Input value={slide.link_label || ""} onChange={(e) => set("link_label", e.target.value)} placeholder="Libellé du lien"/></div>
  </div>;
}