import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Upload, Loader2 } from "lucide-react";

const AUDIO_PATTERN = /\.(mp3|wav|m4a|aac|ogg|oga|flac)(\?|$)/i;
const VIDEO_PATTERN = /\.(mp4|webm|mov)(\?|$)/i;

export default function MediaField({ label, value, onChange, accept = "image/*,video/*" }) {
  const [uploading, setUploading] = useState(false);
  const acceptsAudio = accept.includes("audio/");
  const isAudio = acceptsAudio || AUDIO_PATTERN.test(value || "");
  const isVideo = !isAudio && VIDEO_PATTERN.test(value || "");
  const fileRef = useRef(null);

  const handleFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    onChange(file_url);
    setUploading(false);
  };

  return (
    <div>
      <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">{label}</label>
      <div className="flex gap-2 items-center">
        {value && (isAudio
          ? <audio src={value} controls preload="none" className="h-9 w-36 flex-shrink-0" />
          : isVideo
            ? <video src={value} muted className="h-10 w-10 flex-shrink-0 object-cover" />
            : <img src={value} alt="" className="h-10 w-10 flex-shrink-0 object-cover" />)}
        <Input aria-label={label} value={value || ""} onChange={(e) => onChange(e.target.value)} placeholder="https://…" className="font-mono text-xs" />
        <Button type="button" variant="outline" size="icon" onClick={() => fileRef.current?.click()} disabled={uploading}>
          {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
        </Button>
        <input ref={fileRef} type="file" accept={accept} className="hidden" onChange={handleFile} />
      </div>
    </div>
  );
}
