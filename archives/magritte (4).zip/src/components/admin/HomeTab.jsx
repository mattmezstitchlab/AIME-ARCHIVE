import React from "react";
import TextsTab from "@/components/admin/TextsTab";
import HeroSettingsEditor from "@/components/admin/HeroSettingsEditor";
import { TEXT_GROUPS } from "@/lib/siteTexts";

const homeGroups = TEXT_GROUPS.filter((group) => group.id === "home");

export default function HomeTab() {
  return (
    <div className="space-y-14">
      <HeroSettingsEditor />
      <TextsTab groups={homeGroups} saveLabel="Enregistrer l’accueil" />
      <p className="border-t border-border pt-8 text-sm text-muted-foreground">Les cartes de l’accueil reprennent désormais les modules configurés dans l’onglet Mariage.</p>
    </div>
  );
}