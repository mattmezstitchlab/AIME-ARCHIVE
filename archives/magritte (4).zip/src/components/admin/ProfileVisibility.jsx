import React from "react";

export default function ProfileVisibility({ visible, onChange }) {
  return <label className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-muted-foreground"><input type="checkbox" checked={visible} onChange={(e) => onChange(e.target.checked)} />Visible publiquement</label>;
}