import React from "react";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";

export default function HeroVisualControls({ value, onChange }) {
  const height = value.height_vh ?? 100, opacity = value.overlay_opacity ?? 40;
  return <div className="space-y-6 border border-border p-4"><div><h3 className="font-medium">Cadrage du hero d’accueil</h3><p className="mt-1 text-sm text-muted-foreground">Ces réglages s’appliquent uniquement à l’accueil.</p></div>
    <label className="block space-y-3"><span className="flex items-center justify-between text-sm"><span>Hauteur visible</span><Input aria-label="Hauteur visible" type="number" min="45" max="100" value={height} onChange={(e) => onChange("height_vh", Number(e.target.value))} className="w-20"/></span><Slider min={45} max={100} step={1} value={[height]} onValueChange={([next]) => onChange("height_vh", next)}/></label>
    <label className="block space-y-3"><span className="flex items-center justify-between text-sm"><span>Opacité du filtre noir</span><Input aria-label="Opacité du filtre noir" type="number" min="0" max="80" value={opacity} onChange={(e) => onChange("overlay_opacity", Number(e.target.value))} className="w-20"/></span><Slider min={0} max={80} step={1} value={[opacity]} onValueChange={([next]) => onChange("overlay_opacity", next)}/></label>
  </div>;
}