import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { usePageSections } from "@/lib/usePageSections";

export function usePageSectionEditor(pageKey) {
  const queryClient = useQueryClient(), query = usePageSections(pageKey, true);
  const [items, setItems] = useState([]), [removed, setRemoved] = useState([]);
  const [saving, setSaving] = useState(false), [saved, setSaved] = useState(false), [error, setError] = useState("");
  useEffect(() => { if (query.data) setItems(query.data); }, [query.data]);
  const change = (index, field, value) => setItems((all) => all.map((item, i) => i === index ? { ...item, [field]: value } : item));
  const changeItem = (sectionIndex, itemIndex, field, value) => change(sectionIndex, "items", (items[sectionIndex].items || []).map((item, i) => i === itemIndex ? { ...item, [field]: value } : item));
  const addItem = (index) => change(index, "items", [...(items[index].items || []), { meta: "", title: "Nouvel élément", text: "" }]);
  const removeItem = (sectionIndex, itemIndex) => change(sectionIndex, "items", (items[sectionIndex].items || []).filter((_, i) => i !== itemIndex));
  const add = () => setItems((all) => [...all, { id: `new-${Date.now()}`, page_key: pageKey, section_type: "text", title: "Nouvelle section", body: "", items: [], visible: true, order: all.length }]);
  const remove = (index) => { const item = items[index]; if (!item.id.startsWith("new-")) setRemoved((ids) => [...ids, item.id]); setItems((all) => all.filter((_, i) => i !== index)); };
  const move = (index, direction) => setItems((all) => { const target = index + direction; if (target < 0 || target >= all.length) return all; const next = [...all]; [next[index], next[target]] = [next[target], next[index]]; return next.map((item, order) => ({ ...item, order })); });
  const save = async () => { setSaving(true); setError(""); try { for (const id of removed) await base44.entities.PageSection.delete(id); for (const [order, item] of items.entries()) { const { id, created_date, updated_date, created_by_id, ...data } = item; const payload = { ...data, page_key: pageKey, order }; id.startsWith("new-") ? await base44.entities.PageSection.create(payload) : await base44.entities.PageSection.update(id, payload); } await queryClient.invalidateQueries({ queryKey: ["page-sections", pageKey] }); setRemoved([]); setSaved(true); } catch (e) { setError(e.message || "Enregistrement impossible."); } finally { setSaving(false); } };
  return { ...query, items, saving, saved, error, change, changeItem, addItem, removeItem, add, remove, move, save };
}