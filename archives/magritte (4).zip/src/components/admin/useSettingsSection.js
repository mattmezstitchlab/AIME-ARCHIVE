import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import useSiteSettings from "@/lib/useSiteSettings";

export default function useSettingsSection(section, defaults) {
  const { settings, isLoading } = useSiteSettings();
  const queryClient = useQueryClient();
  const [value, setValue] = useState(defaults);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  useEffect(() => { if (settings?.[section]) setValue({ ...defaults, ...settings[section] }); }, [settings]);
  const save = async (nextValue = value) => {
    if (nextValue && nextValue.nativeEvent) nextValue = value;
    setSaving(true); setValue(nextValue);
    if (settings?.id) await base44.entities.SiteSettings.update(settings.id, { [section]: nextValue });
    else await base44.entities.SiteSettings.create({ key: "main", [section]: nextValue });
    await queryClient.invalidateQueries({ queryKey: ["siteSettings"] });
    setSaving(false); setSaved(true);
  };
  return { value, setValue, save, saving, saved, isLoading };
}