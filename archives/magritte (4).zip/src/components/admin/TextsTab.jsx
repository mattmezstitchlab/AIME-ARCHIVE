import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { TEXT_GROUPS, DEFAULTS, useSiteTexts } from "@/lib/siteTexts";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import MediaField from "@/components/admin/MediaField";

const remainingGroups = TEXT_GROUPS.filter((group) => group.id !== "home");

export default function TextsTab({ groups = remainingGroups, saveLabel = "Enregistrer les textes" }) {
  const queryClient = useQueryClient();
  const { records } = useSiteTexts();
  const [edits, setEdits] = useState({});
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  const recordMap = Object.fromEntries(records.map((r) => [r.key, r]));
  const getValue = (key) => edits[key] ?? recordMap[key]?.value ?? DEFAULTS[key] ?? "";

  const handleSave = async () => {
    setSaving(true);
    for (const [key, value] of Object.entries(edits)) {
      const existing = recordMap[key];
      if (existing) {
        await base44.entities.SiteText.update(existing.id, { value });
      } else {
        await base44.entities.SiteText.create({ key, value });
      }
    }
    await queryClient.invalidateQueries({ queryKey: ["siteTexts"] });
    setEdits({});
    setSaving(false);
    setSavedAt(Date.now());
  };

  return (
    <div className="space-y-12">
      {groups.map((group) => (
        <div key={group.id}>
          <h2 className="font-body text-2xl font-light text-foreground mb-6 border-b border-border pb-3">{group.label}</h2>
          <div className="space-y-5">
            {group.fields.map((field) => (
              <div key={field.key}>
                {field.type === "image" ? (
                  <MediaField label={field.label} value={getValue(field.key)} onChange={(v) => setEdits((e) => ({ ...e, [field.key]: v }))} />
                ) : (
                  <>
                    <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">{field.label}</label>
                    {field.type === "textarea" ? (
                      <Textarea value={getValue(field.key)} rows={3} onChange={(e) => setEdits((ed) => ({ ...ed, [field.key]: e.target.value }))} />
                    ) : (
                      <Input value={getValue(field.key)} onChange={(e) => setEdits((ed) => ({ ...ed, [field.key]: e.target.value }))} />
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
      <div className="flex items-center gap-4 border-t pt-6">
        <Button onClick={handleSave} disabled={saving || Object.keys(edits).length === 0} className="font-mono text-xs tracking-widest uppercase">
          {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {saveLabel}
        </Button>
        {savedAt && Object.keys(edits).length === 0 && (
          <span className="font-mono text-xs text-muted-foreground">Enregistré ✓</span>
        )}
      </div>
    </div>
  );
}