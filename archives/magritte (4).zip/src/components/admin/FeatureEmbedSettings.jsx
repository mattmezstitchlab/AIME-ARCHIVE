import React from "react";
import { Input } from "@/components/ui/input";
import FeatureEmbedFrame from "@/components/project/FeatureEmbedFrame";

const numberFields = [
  ["frame_width", "Largeur de la page", 1440], ["frame_height", "Hauteur de la page", 900],
  ["viewport_height", "Hauteur de la fenêtre", 560], ["offset_x", "Décalage horizontal", 0],
  ["offset_y", "Décalage vertical", 0], ["frame_scale", "Zoom", 1],
];

export default function FeatureEmbedSettings({ feature, onChange }) {
  const set = (key, value) => onChange({ ...feature, [key]: value });
  const cropped = feature.embed_mode === "crop";
  return (
    <div className="space-y-4 border-t border-border pt-5">
      <div><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Intégration d’une page</span><p className="mt-2 text-sm text-muted-foreground">Le site source doit autoriser son affichage dans une frame.</p></div>
      <Input value={feature.embed_url || ""} onChange={(e) => set("embed_url", e.target.value)} placeholder="URL de la page à intégrer" />
      {feature.embed_url && <>
        <div className="grid gap-4 md:grid-cols-2">
          <label className="space-y-2 text-sm"><span>Mode d’affichage</span><select value={feature.embed_mode || "page"} onChange={(e) => set("embed_mode", e.target.value)} className="h-9 w-full border border-input bg-background px-3"><option value="page">Page complète</option><option value="crop">Zone recadrée</option></select></label>
          <label className="flex items-center gap-3 self-end border border-input px-3 h-9 text-sm"><input type="checkbox" checked={feature.interactive !== false} onChange={(e) => set("interactive", e.target.checked)} />Navigation et clics autorisés</label>
        </div>
        {cropped && <div className="grid gap-4 md:grid-cols-3">{numberFields.map(([key, label, fallback]) => <label key={key} className="space-y-2 text-sm"><span>{label}</span><Input type="number" step={key === "frame_scale" ? "0.1" : "1"} value={feature[key] ?? fallback} onChange={(e) => set(key, Number(e.target.value))} /></label>)}</div>}
        <div><p className="mb-2 font-mono text-xs uppercase tracking-widest text-muted-foreground">Aperçu du cadrage</p><FeatureEmbedFrame feature={feature} compact /></div>
      </>}
    </div>
  );
}