import React from "react";
import { Input } from "@/components/ui/input";
import { contrastHex } from "@/lib/colorUtils";

const fields = [["background", "Fond"], ["primary", "Couleur principale"], ["accent", "Couleur secondaire"]];
export default function PaletteEditor({ label, value, onChange }) {
  return <section className="space-y-5 border border-border p-5"><div><span className="font-mono text-xs uppercase tracking-widest text-primary">{label}</span><h3 className="mt-2 text-2xl font-light">Palette {label.toLowerCase()}</h3></div>
    <div className="space-y-4">{fields.map(([key, name]) => <label key={key} className="grid grid-cols-[1fr_auto] items-center gap-3 text-sm"><span>{name}</span><span className="flex items-center gap-2"><Input aria-label={`${label} ${name}`} value={value[key]} onChange={(event) => onChange(key, event.target.value)} className="w-28 font-mono text-xs"/><input aria-label={`${label} ${name} sélecteur`} type="color" value={value[key]} onChange={(event) => onChange(key, event.target.value)} className="h-9 w-12 border border-border bg-transparent"/></span></label>)}</div>
    <div className="border p-5" style={{ backgroundColor: value.background, color: contrastHex(value.background) }}><p className="font-mono text-xs uppercase tracking-widest">Contraste automatique</p><p className="mt-3 text-2xl font-light">Le texte reste lisible.</p><span className="mt-4 inline-block px-3 py-2 text-xs" style={{ backgroundColor: value.primary, color: contrastHex(value.primary) }}>Action principale</span></div>
  </section>;
}