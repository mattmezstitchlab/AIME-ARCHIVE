import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Upload, Loader2, X, ArrowUp, ArrowDown, Plus } from "lucide-react";

const isVideo = (url) => /\.(mp4|webm|mov)(\?|$)/i.test(url);

export default function GalleryField({ label, value = [], onChange }) {
  const [uploading, setUploading] = useState(false);
  const [newUrl, setNewUrl] = useState("");
  const fileRef = useRef(null);

  const handleFiles = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    const urls = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      urls.push(file_url);
    }
    onChange([...value, ...urls]);
    setUploading(false);
    e.target.value = "";
  };

  const move = (i, dir) => {
    const next = [...value];
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  const addUrl = () => {
    if (!newUrl.trim()) return;
    onChange([...value, newUrl.trim()]);
    setNewUrl("");
  };

  return (
    <div>
      <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">{label}</label>
      <div className="space-y-2">
        {value.map((url, i) => (
          <div key={`${url}-${i}`} className="flex items-center gap-2 border border-border p-2">
            {isVideo(url) ? (
              <video src={url} className="w-12 h-12 object-cover flex-shrink-0" muted />
            ) : (
              <img src={url} alt="" className="w-12 h-12 object-cover flex-shrink-0" />
            )}
            <span className="font-mono text-xs text-muted-foreground truncate flex-1">{url}</span>
            <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => move(i, -1)}><ArrowUp className="w-3 h-3" /></Button>
            <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => move(i, 1)}><ArrowDown className="w-3 h-3" /></Button>
            <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => onChange(value.filter((_, j) => j !== i))}><X className="w-3 h-3" /></Button>
          </div>
        ))}
        <div className="flex gap-2">
          <Input value={newUrl} onChange={(e) => setNewUrl(e.target.value)} placeholder="Coller une URL (image ou vidéo)…" className="font-mono text-xs" />
          <Button type="button" variant="outline" size="icon" onClick={addUrl}><Plus className="w-4 h-4" /></Button>
          <Button type="button" variant="outline" onClick={() => fileRef.current?.click()} disabled={uploading} className="font-mono text-xs">
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Upload className="w-4 h-4 mr-2" />Upload</>}
          </Button>
          <input ref={fileRef} type="file" accept="image/*,video/*" multiple className="hidden" onChange={handleFiles} />
        </div>
      </div>
    </div>
  );
}