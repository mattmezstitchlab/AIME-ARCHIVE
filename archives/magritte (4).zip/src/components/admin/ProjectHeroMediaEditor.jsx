import React from "react";
import MediaField from "@/components/admin/MediaField";
import FeatureEmbedSettings from "@/components/admin/FeatureEmbedSettings";

export default function ProjectHeroMediaEditor({ value = {}, fallbackUrl, onChange }) {
  const type = value.type || "image";
  const media = { ...value, type, url: value.url || fallbackUrl || "" };
  const setType = (nextType) => onChange({ ...media, type: nextType });
  return (
    <div className="space-y-4 border-t border-border pt-8">
      <div>
        <label className="mb-2 block font-mono text-xs uppercase tracking-widest text-muted-foreground">Média principal universel</label>
        <select value={type} onChange={(e) => setType(e.target.value)} className="h-9 w-full border border-input bg-background px-3 text-sm md:w-64">
          <option value="image">Image</option><option value="video">Vidéo</option><option value="embed">Page / frame</option>
        </select>
      </div>
      {type === "embed" ? (
        <FeatureEmbedSettings feature={{ ...media, embed_url: media.url }} onChange={(next) => onChange({ ...next, type: "embed", url: next.embed_url })} />
      ) : (
        <MediaField label={type === "video" ? "URL ou fichier vidéo" : "URL ou fichier image"} value={media.url} onChange={(url) => onChange({ ...media, url })} />
      )}
    </div>
  );
}