import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import ProjectFeatureItem from "./ProjectFeatureItem";

const EMPTY_FEATURE = { functionality_id: "", title: "", status: "", description: "", image: "", link: "", link_label: "", embed_url: "", embed_mode: "page", frame_width: 1440, frame_height: 900, viewport_height: 560, offset_x: 0, offset_y: 0, frame_scale: 1, interactive: true };

export default function ProjectFeaturesField({ value = [], projectTitle, onChange }) {
  const { data: functionalities = [] } = useQuery({ queryKey: ["functionalities"], queryFn: () => base44.entities.Functionality.list("name", 200) });
  return (
    <section className="space-y-4 border-t border-border pt-8">
      <div><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Présentations de fonctionnalités</span><p className="mt-2 text-sm text-muted-foreground">Ajoutez un visuel, un texte, un lien ou une page intégrée pour chaque outil.</p></div>
      {value.map((feature, index) => <ProjectFeatureItem key={index} feature={feature} index={index} projectTitle={projectTitle} functionalities={functionalities} onChange={(next) => onChange(value.map((item, i) => i === index ? next : item))} onRemove={() => onChange(value.filter((_, i) => i !== index))}/>) }
      <Button type="button" variant="outline" onClick={() => onChange([...value, { ...EMPTY_FEATURE }])}><Plus className="h-4 w-4"/>Ajouter une fonctionnalité</Button>
    </section>
  );
}