import React from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import ProfileIdentityEditor from "./ProfileIdentityEditor";
import ProfileCollectionEditor from "./ProfileCollectionEditor";
import { useProfileEditor } from "./useProfileEditor";
import TextsTab from "./TextsTab";
import { TEXT_GROUPS } from "@/lib/siteTexts";

const profileTextGroups = TEXT_GROUPS.filter((group) => group.id === "business");

export default function ProfileTab() {
  const editor = useProfileEditor();
  if (editor.isLoading) return <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground/20 border-t-foreground"/>;
  const identity = editor.items.filter((i) => i.section === "identity");
  const timelineHeading = editor.items.find((i) => i.key === "timeline.heading");
  const servicesHeading = editor.items.find((i) => i.key === "services.heading");
  const timeline = editor.items.filter((i) => i.kind === "timeline");
  const services = editor.items.filter((i) => i.kind === "service");
  return <div className="space-y-12">
    <ProfileIdentityEditor items={identity} onChange={editor.change}/>
    <ProfileCollectionEditor title="Parcours & Formation" heading={timelineHeading} items={timeline} type="timeline" onChange={editor.change} onRemove={editor.remove} onAdd={() => editor.add("timeline", "timeline")}/>
    <ProfileCollectionEditor title="Répertoire & Prestations" heading={servicesHeading} items={services} type="service" onChange={editor.change} onRemove={editor.remove} onAdd={() => editor.add("services", "service")}/>
    <section className="border-t border-border pt-10"><TextsTab groups={profileTextGroups} saveLabel="Enregistrer les informations" /></section>
    <div className="flex items-center gap-4 border-t pt-6"><Button onClick={editor.save} disabled={editor.saving}>{editor.saving && <Loader2 className="h-4 w-4 animate-spin"/>}Enregistrer le profil</Button>{editor.saved && <span className="font-mono text-xs text-muted-foreground">Enregistré ✓</span>}</div>
  </div>;
}