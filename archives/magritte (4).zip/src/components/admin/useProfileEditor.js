import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useProfileContent } from "@/lib/useProfileContent";

export function useProfileEditor() {
  const { records, isLoading } = useProfileContent(true);
  const queryClient = useQueryClient();
  const [items, setItems] = useState([]), [removed, setRemoved] = useState([]);
  const [saving, setSaving] = useState(false), [saved, setSaved] = useState(false);
  useEffect(() => setItems(records), [records]);
  const change = (item, next) => { setSaved(false); setItems((all) => all.map((entry) => entry === item ? next : entry)); };
  const remove = (item) => { if (item.id) setRemoved((all) => [...all, item.id]); setItems((all) => all.filter((entry) => entry !== item)); };
  const add = (section, kind) => setItems((all) => [...all, { key: `${kind}-${Date.now()}`, section, kind, label: "", value: "", description: "", items: [], order: all.filter((i) => i.section === section).length, visible: true }]);
  const save = async () => {
    setSaving(true);
    const existing = items.filter((item) => item.id).map(({ id, key, section, kind, label, value, description, items: list, order, visible }) => ({ id, key, section, kind, label, value, description, items: list, order, visible }));
    const fresh = items.filter((item) => !item.id);
    if (existing.length) await base44.entities.ProfileContent.bulkUpdate(existing);
    if (fresh.length) await base44.entities.ProfileContent.bulkCreate(fresh);
    await Promise.all(removed.map((id) => base44.entities.ProfileContent.delete(id)));
    await queryClient.invalidateQueries({ queryKey: ["profileContent"] });
    setRemoved([]); setSaving(false); setSaved(true);
  };
  return { items, isLoading, saving, saved, change, remove, add, save };
}