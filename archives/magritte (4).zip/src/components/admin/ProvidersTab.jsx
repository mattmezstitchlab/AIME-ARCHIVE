import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useProviders } from "@/lib/useProviders";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import ProviderEditor from "./ProviderEditor";
import ProviderRow from "./ProviderRow";

export default function ProvidersTab() {
  const queryClient = useQueryClient();
  const { data: providers = [] } = useProviders();
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["providers"] });
  const save = async (data) => {
    setSaving(true);
    if (editing === "new") await base44.entities.Provider.create(data);
    else await base44.entities.Provider.update(editing.id, data);
    await refresh();
    setSaving(false); setEditing(null);
  };
  const remove = async (provider) => {
    if (!window.confirm(`Supprimer « ${provider.name} » ?`)) return;
    await base44.entities.Provider.delete(provider.id); await refresh();
  };
  if (editing) return <div><h2 className="font-body text-2xl font-light mb-8">{editing === "new" ? "Nouveau prestataire" : `Modifier — ${editing.name}`}</h2><ProviderEditor key={editing === "new" ? "new" : editing.id} provider={editing === "new" ? null : editing} onSave={save} onCancel={() => setEditing(null)} saving={saving} /></div>;
  return <div><div className="border-t border-border">{providers.length ? providers.map((provider) => <ProviderRow key={provider.id} provider={provider} onEdit={setEditing} onDelete={remove} />) : <p className="py-10 text-muted-foreground">Aucun prestataire enregistré.</p>}</div><Button onClick={() => setEditing("new")} className="mt-8 font-mono text-xs uppercase tracking-widest"><Plus className="w-4 h-4 mr-2" />Nouveau prestataire</Button></div>;
}