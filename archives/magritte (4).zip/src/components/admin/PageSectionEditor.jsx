import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ArrowDown, ArrowUp, Trash2 } from "lucide-react";
import MediaField from "./MediaField";
import PageSectionItemsEditor from "./PageSectionItemsEditor";

export default function PageSectionEditor({ section, index, total, editor }) {
  const set = (field, value) => editor.change(index, field, value);
  const hasItems = section.section_type === "timeline" || section.section_type === "steps";
  return <article className="space-y-5 border border-border bg-card p-5">
    <div className="flex flex-wrap items-center gap-2">
      <select value={section.section_type} onChange={(e) => set("section_type", e.target.value)} className="h-9 border border-input bg-background px-3 text-sm"><option value="hero">Introduction</option><option value="text">Texte</option><option value="timeline">Timeline</option><option value="steps">Mode d’emploi</option></select>
      <label className="ml-auto flex items-center gap-2 text-sm"><input type="checkbox" checked={section.visible !== false} onChange={(e) => set("visible", e.target.checked)} /> Visible</label>
      <Button type="button" variant="ghost" size="icon" disabled={index === 0} onClick={() => editor.move(index, -1)} aria-label="Monter"><ArrowUp /></Button>
      <Button type="button" variant="ghost" size="icon" disabled={index === total - 1} onClick={() => editor.move(index, 1)} aria-label="Descendre"><ArrowDown /></Button>
      <Button type="button" variant="ghost" size="icon" onClick={() => editor.remove(index)} aria-label="Supprimer"><Trash2 /></Button>
    </div>
    <Input value={section.eyebrow || ""} onChange={(e) => set("eyebrow", e.target.value)} placeholder="Étiquette" />
    <Input value={section.title || ""} onChange={(e) => set("title", e.target.value)} placeholder="Titre de la section" />
    <Textarea rows={4} value={section.body || ""} onChange={(e) => set("body", e.target.value)} placeholder="Texte de la section" />
    {section.section_type === "hero" && <MediaField label="Photo d’introduction" value={section.image_url || ""} onChange={(value) => set("image_url", value)} />}
    {hasItems && <PageSectionItemsEditor items={section.items} onAdd={() => editor.addItem(index)} onRemove={(itemIndex) => editor.removeItem(index, itemIndex)} onChange={(itemIndex, field, value) => editor.changeItem(index, itemIndex, field, value)} />}
  </article>;
}