import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useProjects } from "@/lib/useProjects";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2, Plus } from "lucide-react";
import ProjectEditor from "./ProjectEditor";

export default function ProjectsTab() {
  const queryClient = useQueryClient();
  const { projects } = useProjects();
  const [editing, setEditing] = useState(null); // null | "new" | project
  const [saving, setSaving] = useState(false);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["projects"] });

  const handleSave = async (data) => {
    setSaving(true);
    if (editing === "new") {
      await base44.entities.Project.create(data);
    } else {
      await base44.entities.Project.update(editing.id, data);
    }
    setSaving(false);
    setEditing(null);
    refresh();
  };

  const handleDelete = async (project) => {
    if (!window.confirm(`Supprimer « ${project.title} » ?`)) return;
    await base44.entities.Project.delete(project.id);
    refresh();
  };

  if (editing) {
    return (
      <div>
        <h2 className="font-body text-2xl font-light text-foreground mb-8">
          {editing === "new" ? "Nouveau projet" : `Modifier — ${editing.title}`}
        </h2>
        <ProjectEditor
          key={editing === "new" ? "new" : editing.id}
          project={editing === "new" ? null : editing}
          onSave={handleSave}
          onCancel={() => setEditing(null)}
          saving={saving}
        />
      </div>
    );
  }

  return (
    <div>
      <div className="border-t border-border">
        {projects.map((project) => (
          <div key={project.id} className="flex items-center gap-4 border-b border-border py-4">
            <span className="font-mono text-xs text-muted-foreground w-8">{project.number}</span>
            {project.image && <img src={project.image} alt="" className="w-12 h-12 object-cover" />}
            <div className="flex-1 min-w-0">
              <p className="font-body text-lg font-light text-foreground truncate">{project.title}</p>
              <p className="font-mono text-xs text-muted-foreground truncate">{project.subtitle}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setEditing(project)} aria-label="Modifier">
              <Pencil className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(project)} aria-label="Supprimer">
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>
      <Button onClick={() => setEditing("new")} className="mt-8 font-mono text-xs tracking-widest uppercase">
        <Plus className="w-4 h-4 mr-2" />
        Nouveau projet
      </Button>
    </div>
  );
}