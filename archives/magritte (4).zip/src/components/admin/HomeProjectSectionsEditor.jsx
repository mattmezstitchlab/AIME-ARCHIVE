import React, { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useProjects } from "@/lib/useProjects";
import { Button } from "@/components/ui/button";
import HomeProjectSectionItem from "@/components/admin/HomeProjectSectionItem";

const defaults = (project, index) => ({ visible: index < 3, order: index + 1, label: "", title: "", intro: "", layout: "split", theme: "light", ...project.homepage });

export default function HomeProjectSectionsEditor() {
  const { projects, isLoading } = useProjects();
  const queryClient = useQueryClient();
  const [values, setValues] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => setValues(Object.fromEntries(projects.map((project, index) => [project.id, defaults(project, index)]))), [projects]);
  const save = async () => {
    setSaving(true);
    await base44.entities.Project.bulkUpdate(projects.map((project) => ({ id: project.id, homepage: values[project.id] })));
    await queryClient.invalidateQueries({ queryKey: ["projects"] });
    setSaving(false);
  };
  if (isLoading) return <p className="text-sm text-muted-foreground">Chargement de la sélection…</p>;
  return (
    <section className="space-y-5 border-t border-border pt-10">
      <div><h2 className="text-2xl font-light">Sections projets</h2><p className="mt-2 text-sm text-muted-foreground">Choisissez l’ordre et la présentation de chaque projet sur l’accueil.</p></div>
      {projects.map((project) => <HomeProjectSectionItem key={project.id} project={project} value={values[project.id] || defaults(project, 0)} onChange={(next) => setValues((current) => ({ ...current, [project.id]: next }))} />)}
      <Button onClick={save} disabled={saving || !projects.length} className="font-mono text-xs uppercase tracking-widest">{saving ? "Enregistrement…" : "Enregistrer les sections"}</Button>
    </section>
  );
}