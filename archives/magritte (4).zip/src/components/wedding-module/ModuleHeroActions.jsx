import React from "react";
import { Check, Plus } from "lucide-react";

export default function ModuleHeroActions({ type, added, onAdd }) {
  return <div className="mt-9 flex flex-wrap gap-3">
    {type !== "canevas" && <button onClick={onAdd} disabled={added} className="inline-flex items-center gap-3 bg-gallery px-5 py-3 font-mono text-xs uppercase tracking-widest text-charcoal disabled:opacity-70">{added ? "Module déjà ajouté au Canevas" : "Ajouter au Canevas"}{added ? <Check className="h-4 w-4"/> : <Plus className="h-4 w-4"/>}</button>}
  </div>;
}