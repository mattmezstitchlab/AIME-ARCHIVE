import React from "react";
import WeddingProfileCard from "@/components/dashboard/WeddingProfileCard";
import TimelineBoard from "@/components/dashboard/TimelineBoard";
import TreasuryEngine from "@/components/dashboard/TreasuryEngine";
import BudgetCard from "@/components/dashboard/BudgetCard";
import WeddingCanvas from "@/components/dashboard/WeddingCanvas";
import RegistryWorkspace from "@/components/wedding-module/RegistryWorkspace";
import ModuleCanvasSelection from "@/components/wedding-module/ModuleCanvasSelection";

export default function ModuleWorkspace({ type, data, isAuthenticated }) {
  if (type === "registre") return <RegistryWorkspace profile={data.profile} hub={data.vendors}/>;
  if (type === "canevas") return <div className="space-y-12"><ModuleCanvasSelection data={data} isAuthenticated={isAuthenticated}/>{data.profile && <WeddingCanvas profileId={data.profile.id} canvas={data.canvas}/>}</div>;
  if (type === "passport" && isAuthenticated) return <WeddingProfileCard profile={data.profile} onSave={data.saveProfile} saving={data.loadingProfile}/>;
  if (!data.profile) return null;
  if (type === "timeline") return <TimelineBoard profile={data.profile} onSaveProfile={data.saveProfile} savingProfile={data.loadingProfile} timeline={data.timeline}/>;
  if (type === "documents") return <TreasuryEngine finances={data.finances}/>;
  if (type === "budget") return <BudgetCard items={data.budget} totalBudget={data.profile?.total_budget} onAdd={data.addBudget} onDelete={data.deleteBudget}/>;
  return null;
}