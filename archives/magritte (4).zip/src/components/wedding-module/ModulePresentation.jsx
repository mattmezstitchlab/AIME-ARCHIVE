import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { getModuleStepScenes } from "@/lib/moduleStepScenes";
import ModuleStepVisual from "./ModuleStepVisual";

export default function ModulePresentation({ module, type, simulation }) {
  const [active, setActive] = useState(0), scenes = getModuleStepScenes(type, simulation);
  useEffect(() => { setActive(0); const timer = window.setInterval(() => setActive((current) => (current + 1) % module.steps.length), 3800); return () => window.clearInterval(timer); }, [type, module.steps.length]);
  return <section className="px-6 py-20 md:px-8 md:py-28"><div className="grid gap-12 md:grid-cols-12">
    <div className="md:col-span-5"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Comment ça fonctionne</span><h2 className="mt-4 text-4xl font-light tracking-tight md:text-6xl">Un parcours clair, directement dans votre projet.</h2></div>
    <ol className="md:col-start-7 md:col-span-6">{module.steps.map((step, index) => <li key={step}><button onClick={() => setActive(index)} className={`flex w-full items-center gap-5 border-t border-border py-6 text-left transition-colors ${active === index ? "text-foreground" : "text-muted-foreground"}`}><span className="font-mono text-xs text-cobalt">0{index + 1}</span><span className="text-xl font-light">{step}</span>{active === index && <motion.span layoutId="active-step" className="ml-auto h-2 w-2 bg-cobalt"/>}</button></li>)}</ol>
    <div className="md:col-span-12"><AnimatePresence mode="wait"><ModuleStepVisual key={`${type}-${active}`} scene={scenes[active]}/></AnimatePresence></div>
  </div></section>;
}