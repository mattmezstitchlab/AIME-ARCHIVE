import React, { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EMPTY_WEDDING_SIMULATION } from "@/lib/useWeddingSimulation";

export default function WeddingSimulationForm({ simulation, onSave }) {
  const [form, setForm] = useState(simulation || EMPTY_WEDDING_SIMULATION), [saved, setSaved] = useState(false);
  useEffect(() => setForm({ ...EMPTY_WEDDING_SIMULATION, ...simulation }), [simulation]);
  const update = (key, value) => { setForm((current) => ({ ...current, [key]: value })); setSaved(false); };
  const field = (key, label, type = "text", placeholder = "", required = false) => <label className="block space-y-2"><span className="text-sm">{label}{required && " *"}</span><Input type={type} value={form[key] || ""} placeholder={placeholder} required={required} onChange={(event) => update(key, type === "number" ? Number(event.target.value) : event.target.value)}/></label>;
  const submit = (event) => { event.preventDefault(); onSave(form); setSaved(true); };
  return <form onSubmit={submit} className="border border-border bg-card p-6 md:p-10">
    <div className="grid gap-8 md:grid-cols-12"><div className="md:col-span-4"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Votre simulation</p><h2 className="mt-3 text-4xl font-light tracking-tight">Votre mariage en un coup d’œil.</h2><p className="mt-4 text-sm text-muted-foreground">Ces informations personnalisent chaque démonstration jusqu’au Canevas final, sans créer votre Passport avant votre confirmation.</p></div>
    <div className="grid gap-4 md:col-start-6 md:col-span-7 md:grid-cols-2">{field("partner_one", "Premier prénom", "text", "Premier prénom", true)}{field("partner_two", "Deuxième prénom", "text", "Deuxième prénom", true)}{field("wedding_date", "Date du mariage", "date")}{field("location", "Lieu du mariage", "text", "Ville ou lieu")}{field("guest_target", "Nombre d’invités", "number", "120")}{field("total_budget", "Budget de référence (€)", "number", "32000")}<div className="md:col-span-2"><Button type="submit" className="rounded-none">{simulation?.partner_one ? "Mettre à jour ma simulation" : "Lancer ma simulation"}</Button>{saved && <p className="mt-3 text-sm text-muted-foreground">Simulation enregistrée : les autres modules utilisent maintenant vos informations.</p>}</div></div></div>
  </form>;
}