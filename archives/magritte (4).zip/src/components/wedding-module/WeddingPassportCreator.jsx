import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { defaultPassport } from "@/lib/passportDefaults";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function WeddingPassportCreator({ user, simulation, profile }) {
  const client = useQueryClient(), navigate = useNavigate();
  const couple = [simulation.partner_one, simulation.partner_two].filter(Boolean).join(" & ");
  const [name, setName] = useState(couple ? `Mariage de ${couple}` : "Notre mariage");
  const [email, setEmail] = useState(user?.email || "");
  const [saving, setSaving] = useState(false), [error, setError] = useState("");
  const create = async (event) => {
    event.preventDefault(); setError(""); setSaving(true);
    try {
      const defaults = defaultPassport(user, "mariage");
      await base44.entities.Passport.create({ ...defaults, name: name.trim(), contact_email: email.trim(), location: simulation.location || "", biography: `${simulation.guest_target || 0} invités · Budget de référence ${Number(simulation.total_budget || 0).toLocaleString("fr-FR")} €`, card_content: { ...defaults.card_content, title: name.trim(), subtitle: couple, date: simulation.wedding_date || "", city: simulation.location || "", venue: simulation.location || "" } });
      const profileData = { partner_one: simulation.partner_one.trim(), partner_two: simulation.partner_two.trim(), wedding_date: simulation.wedding_date || "", location: simulation.location || "", guest_target: Number(simulation.guest_target || 0), total_budget: Number(simulation.total_budget || 0) };
      if (profile) await base44.entities.WeddingProfile.update(profile.id, profileData); else await base44.entities.WeddingProfile.create(profileData);
      await Promise.all([client.invalidateQueries({ queryKey: ["my-passports"] }), client.invalidateQueries({ queryKey: ["wedding-profile"] })]);
      navigate("/compte");
    } catch (err) { setError(err.message || "Impossible de finaliser le Passport Mariage."); setSaving(false); }
  };
  return <form onSubmit={create} className="grid gap-8 border border-cobalt bg-card p-6 md:grid-cols-12 md:p-10">
    <div className="md:col-span-5"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Inscription finale</span><h2 className="mt-4 text-4xl font-light tracking-tight">Créez le véritable Passport Mariage.</h2><p className="mt-4 text-sm text-muted-foreground">La simulation devient votre projet réel et reste disponible dans votre Espace Compte.</p></div>
    <div className="space-y-5 md:col-start-7 md:col-span-6"><label className="block space-y-2"><span className="text-sm">Nom du Passport</span><Input required value={name} onChange={(event) => setName(event.target.value)}/></label><label className="block space-y-2"><span className="text-sm">Email de contact</span><Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="vous@exemple.fr"/></label>{error && <p className="text-sm text-destructive">{error}</p>}<Button type="submit" disabled={saving || !name.trim()} className="rounded-none">{saving ? "Finalisation…" : "Finaliser l’inscription du Passport Mariage"}</Button></div>
  </form>;
}