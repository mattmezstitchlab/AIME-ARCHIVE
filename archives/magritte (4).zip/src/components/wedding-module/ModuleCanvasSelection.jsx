import React, { useEffect, useState } from "react";
import { Check, Plus } from "lucide-react";
import { WEDDING_MODULES, WEDDING_MODULE_ORDER } from "@/lib/weddingModules";
import { getCanvasModuleKeys, onCanvasModulesChange } from "@/lib/moduleCanvasCart";

export default function ModuleCanvasSelection({ data, isAuthenticated }) {
  const [keys, setKeys] = useState(getCanvasModuleKeys), [validating, setValidating] = useState("");
  const [validated, setValidated] = useState([]);
  useEffect(() => onCanvasModulesChange(setKeys), []);
  const included = data.passport ? WEDDING_MODULE_ORDER.filter((key) => key !== "canevas") : [];
  const displayed = [...new Set([...included, ...keys])];
  const active = (key) => included.includes(key) || validated.includes(key) || data.canvas.blocks.some((block) => block.link_url === `/mariage/${key}`);
  const validate = async (key) => { const item = WEDDING_MODULES[key]; setValidating(key); await data.canvas.create({ wedding_profile_id: data.profile.id, type: "idea", title: `Module · ${item.title}`, content: item.description, link_url: `/mariage/${key}`, x: 32 + (data.canvas.blocks.length % 3) * 280, y: 32 + Math.floor(data.canvas.blocks.length / 3) * 220, width: 240 }); setValidated((current) => [...current, key]); setValidating(""); };
  if (!displayed.length) return <section className="border border-dashed border-border p-8 text-center"><h2 className="text-2xl font-light">Votre sélection est vide.</h2><p className="mt-2 text-muted-foreground">Ajoutez librement un module depuis sa page.</p></section>;
  return <section><div className="mb-5"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Votre Canevas</p><h2 className="mt-2 text-3xl font-light">Vos modules réunis au même endroit</h2></div><div className="grid gap-4 md:grid-cols-2">{displayed.map((key) => { const item = WEDDING_MODULES[key]; if (!item) return null; const done = active(key); return <article key={key} className="border border-border bg-card p-5"><p className="font-mono text-[10px] uppercase tracking-widest text-cobalt">{item.number} · {item.eyebrow}</p><h3 className="mt-2 text-2xl font-light">{item.title}</h3><p className="mt-3 text-sm text-muted-foreground">{item.description}</p>{included.includes(key) ? <p className="mt-5 inline-flex items-center gap-2 text-sm text-muted-foreground"><Check className="h-4 w-4"/>Module déjà ajouté au Canevas</p> : isAuthenticated && data.profile ? <button disabled={done || validating === key} onClick={() => validate(key)} className="mt-5 inline-flex items-center gap-2 bg-foreground px-4 py-2 text-sm text-background disabled:opacity-60">{done ? <Check className="h-4 w-4"/> : <Plus className="h-4 w-4"/>}{done ? "Module déjà ajouté au Canevas" : validating === key ? "Ajout…" : "Ajouter au Canevas"}</button> : <p className="mt-5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">À ajouter depuis votre Compte</p>}</article>; })}</div></section>;
}