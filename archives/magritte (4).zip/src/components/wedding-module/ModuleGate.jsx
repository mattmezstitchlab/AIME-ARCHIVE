import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function ModuleGate({ authenticated, onLogin }) {
  return <div className="border border-border bg-card px-6 py-16 text-center md:px-12"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Accès personnel</span><h2 className="mx-auto mt-4 max-w-2xl text-3xl font-light md:text-5xl">{authenticated ? "Créez d’abord votre Passport Mariage." : "Connectez-vous pour utiliser ce module."}</h2><p className="mx-auto mt-4 max-w-xl text-muted-foreground">Votre Passport relie votre identité, les informations du mariage et tous les outils du projet.</p>{authenticated ? <Button asChild className="mt-7"><Link to="/mon-passport?create=mariage">Créer mon Passport Mariage</Link></Button> : <Button onClick={onLogin} className="mt-7">Se connecter</Button>}</div>;
}