import React from "react";

const demos = {
  passport: { title: "Aperçu du projet", metrics: [["Couple", "Camille & Noa"], ["Date", "12 sept. 2026"], ["Invités", "120"], ["Budget", "32 000 €"]] },
  timeline: { title: "Déroulé du Jour J", metrics: [["10:00", "Préparation"], ["15:00", "Cérémonie"], ["17:00", "Cocktail"], ["20:00", "Dîner"]] },
  documents: { title: "Centre documentaire", metrics: [["Engagé", "12 500 €"], ["Payé", "4 200 €"], ["À décaisser", "8 300 €"], ["Échéance", "15 août"]] },
  budget: { title: "Pilotage du budget", metrics: [["Budget", "32 000 €"], ["Engagé", "20 800 €"], ["Disponible", "11 200 €"], ["Progression", "65%"]] },
  canevas: { title: "Canevas de démonstration", metrics: [["Idée", "Dîner sous les arbres"], ["Prestataire", "Studio Lumière"], ["Document", "Devis du lieu"], ["Budget", "65% engagé"]] }
};

export default function ModuleDemoWorkspace({ type }) {
  const demo = demos[type];
  if (!demo) return null;
  return <section className="border border-border bg-card p-6 md:p-8"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Démonstration AIME®</p><h2 className="mt-2 text-3xl font-light">{demo.title}</h2></div><span className="border border-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest">Données d’exemple</span></div><div className="mt-8 grid border border-border sm:grid-cols-2 lg:grid-cols-4">{demo.metrics.map(([label, value]) => <div key={label} className="min-h-28 border-b border-border p-5 last:border-b-0 sm:border-r lg:border-b-0"><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p><p className="mt-3 text-xl font-light">{value}</p></div>)}</div></section>;
}