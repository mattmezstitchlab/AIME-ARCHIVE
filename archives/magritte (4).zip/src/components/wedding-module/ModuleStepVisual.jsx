import React from "react";
import { motion } from "framer-motion";

const rise = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 } };

export default function ModuleStepVisual({ scene }) {
  if (!scene) return null;
  return <motion.div key={`${scene.kind}-${scene.label}`} {...rise} className="min-h-72 border border-border bg-card p-6 md:p-8">
    <p className="font-mono text-[10px] uppercase tracking-widest text-cobalt">Démonstration AIME®</p><h3 className="mt-2 text-2xl font-light">{scene.label}</h3>
    {scene.kind === "input" && <div className="mt-10"><p className="mb-2 text-xs text-muted-foreground">{scene.label}</p><div className="flex min-h-16 items-center border border-input bg-background px-5 text-xl font-light">{scene.value.split("").map((char, index) => <motion.span key={`${char}-${index}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: index * 0.055 }}>{char === " " ? " " : char}</motion.span>)}<motion.span animate={{ opacity: [1, 0, 1] }} transition={{ repeat: Infinity, duration: 0.8 }} className="ml-1 h-6 w-px bg-cobalt"/></div><motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 }} className="mt-4 text-sm text-muted-foreground">{scene.note}</motion.p></div>}
    {scene.kind === "list" && <div className="mt-7 divide-y divide-border border-y border-border">{scene.rows.map(([title, meta], index) => <motion.div key={title} initial={{ opacity: 0, x: -18 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.35 }} className="flex items-center justify-between gap-4 py-4"><span className="font-light">{title}</span><span className="font-mono text-[10px] uppercase tracking-widest text-cobalt">{meta}</span></motion.div>)}</div>}
    {scene.kind === "progress" && <div className="mt-9"><motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-3xl font-light">{scene.value}</motion.p><div className="mt-6 h-2 bg-muted"><motion.div initial={{ width: 0 }} animate={{ width: `${scene.percent}%` }} transition={{ duration: 1.4, ease: "easeOut" }} className="h-full bg-cobalt"/></div><div className="mt-7 grid grid-cols-2 border border-border">{scene.stats.map(([value, label], index) => <motion.div key={label} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 + index * 0.2 }} className="p-4 first:border-r first:border-border"><p className="text-xl font-light">{value}</p><p className="mt-1 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">{label}</p></motion.div>)}</div></div>}
  </motion.div>;
}