import React, { useMemo, useState } from "react";
import { useProviders } from "@/lib/useProviders";
import ProviderCard from "@/components/providers/ProviderCard";
import ProviderFilters from "@/components/providers/ProviderFilters";
import VendorHub from "@/components/dashboard/VendorHub";

export default function RegistryWorkspace({ profile, hub }) {
  const { data: providers = [], isLoading } = useProviders();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const categories = useMemo(() => [...new Set(providers.map((provider) => provider.category))].sort(), [providers]);
  const filtered = useMemo(() => providers.filter((provider) => {
    const term = search.trim().toLowerCase();
    const searchable = [provider.name, provider.category, provider.location, provider.description, provider.price_range].filter(Boolean).join(" ").toLowerCase();
    return (!category || provider.category === category) && (!term || searchable.includes(term));
  }), [providers, search, category]);

  return <div className="space-y-20">
    <section><header className="mb-10"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Registre AIME®</span><h2 className="mt-2 text-3xl font-light md:text-5xl">Trouver un prestataire</h2><p className="mt-3 max-w-2xl text-muted-foreground">Recherchez par nom, métier, lieu, budget ou mot-clé, puis ouvrez le profil qui correspond à votre projet.</p></header>
      <ProviderFilters search={search} category={category} categories={categories} onSearch={setSearch} onCategory={setCategory}/>
      {isLoading ? <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Chargement…</p> : filtered.length ? <div className="grid gap-x-6 gap-y-14 md:grid-cols-2 lg:grid-cols-3">{filtered.map((provider) => <ProviderCard key={provider.id} provider={provider}/>)}</div> : <p className="border-t border-border py-10 text-muted-foreground">Aucun prestataire ne correspond à votre recherche.</p>}
    </section>
    {profile && hub && <section className="border-t border-border pt-16"><VendorHub profile={profile} hub={hub}/></section>}
  </div>;
}