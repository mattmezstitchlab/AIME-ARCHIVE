import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTheme } from "next-themes";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { WEDDING_MODULE_ORDER } from "@/lib/weddingModules";
import ModuleHeroActions from "./ModuleHeroActions";

export default function ModuleHero({ type, module, added, onAdd }) {
  const navigate = useNavigate(), { resolvedTheme } = useTheme(), [slide, setSlide] = useState(0);
  const overlay = resolvedTheme === "dark" ? module.overlay_dark ?? 60 : module.overlay_light ?? 35;
  const slides = [{ eyebrow: module.eyebrow, title: module.title, description: module.description }, ...module.steps.map((step, index) => ({ eyebrow: `Mode d’emploi · 0${index + 1}`, title: step, description: module.guides?.[index] || module.description }))];
  const moduleIndex = WEDDING_MODULE_ORDER.indexOf(type), current = slides[slide];
  const move = (direction) => { const next = slide + direction; if (next >= 0 && next < slides.length) setSlide(next); else { const target = (moduleIndex + direction + WEDDING_MODULE_ORDER.length) % WEDDING_MODULE_ORDER.length; navigate(`/mariage/${WEDDING_MODULE_ORDER[target]}`); } };
  return <section className="relative flex min-h-[78vh] items-end overflow-hidden px-16 pb-16 pt-32 md:px-24"><img src={module.image} alt={`${module.title} — Mariage`} className="absolute inset-0 h-full w-full object-cover"/><div className="absolute inset-0 bg-charcoal" style={{ opacity: overlay / 100 }}/><div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-transparent to-charcoal/10"/>
    <button onClick={() => move(-1)} aria-label={slide ? "Explication précédente" : "Module précédent"} className="absolute left-3 top-1/2 z-20 -translate-y-1/2 border border-gallery/40 p-3 text-gallery md:left-8"><ArrowLeft className="h-5 w-5"/></button><button onClick={() => move(1)} aria-label={slide < slides.length - 1 ? "Explication suivante" : "Module suivant"} className="absolute right-3 top-1/2 z-20 -translate-y-1/2 border border-gallery/40 p-3 text-gallery md:right-8"><ArrowRight className="h-5 w-5"/></button>
    <div className="relative z-10 max-w-5xl text-gallery"><span className="font-mono text-xs uppercase tracking-widest text-gallery/70">{module.number} — {current.eyebrow}</span><h1 className="mt-5 text-5xl font-light tracking-tighter md:text-8xl">{current.title}</h1><p className="mt-6 max-w-2xl text-lg font-light leading-relaxed text-gallery/80 md:text-2xl">{current.description}</p><div className="mt-6 flex gap-2">{slides.map((_, index) => <span key={index} className={`h-1 w-8 ${index === slide ? "bg-gallery" : "bg-gallery/30"}`}/>)}</div><ModuleHeroActions type={type} added={added} onAdd={onAdd}/></div>
  </section>;
}