import SidebarNav from "@/components/layout/SidebarNav";
import AdminAccessMenu from "@/components/layout/AdminAccessMenu";

export default function PerimeterNav() {
  return <><SidebarNav /><AdminAccessMenu /></>;
}