import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { WEDDING_MODULES } from "@/lib/weddingModules";
import { projects } from "@/lib/projectData";

const labels = { about: "À propos", projects: "Projets", contact: "Contact", privacy: "Confidentialité", accessibility: "Accessibilité", admin: "Administration", prestataires: "Prestataires", passport: "Passport", "mon-passport": "Mon Passport", "mon-mariage": "Mon mariage", document: "Document", rsvp: "RSVP", "acces-prestataire": "Accès prestataire" };
const title = (value) => decodeURIComponent(value || "").replace(/-/g, " ").replace(/^./, (letter) => letter.toUpperCase());

export default function Breadcrumbs() {
  const { pathname } = useLocation(), navigate = useNavigate();
  if (pathname === "/") return null;
  const parts = pathname.split("/").filter(Boolean);
  let crumbs = [{ label: "Accueil", path: "/" }];
  if (parts[0] === "project") crumbs.push({ label: "Projets", path: "/projects" }, { label: projects.find((p) => p.slug === parts[1])?.title || title(parts[1]) });
  else if (parts[0] === "prestataire") crumbs.push({ label: "Prestataires", path: "/prestataires" }, { label: title(parts[1]) });
  else if (parts[0] === "mariage") crumbs.push({ label: "Mariage", path: "/project/mariage-platform" }, { label: WEDDING_MODULES[parts[1]]?.title || title(parts[1]) });
  else crumbs.push(...parts.map((part, index) => ({ label: labels[part] || title(part), path: index < parts.length - 1 ? `/${parts.slice(0, index + 1).join("/")}` : undefined })));
  return <nav aria-label="Fil d’Ariane" className="relative z-30 ml-4 mt-6 inline-flex max-w-[calc(100vw-7rem)] items-center gap-2 overflow-hidden border border-border bg-background px-3 py-2 text-foreground md:ml-8 md:mt-8">
    <button onClick={() => navigate(-1)} aria-label="Revenir à la page précédente" className="mr-1 border-r border-border pr-3"><ArrowLeft className="h-4 w-4"/></button>{crumbs.map((crumb, index) => <span className="contents" key={`${crumb.label}-${index}`}>{index > 0 && <ChevronRight className="h-3 w-3 shrink-0 text-muted-foreground"/>}{crumb.path ? <Link to={crumb.path} className="truncate font-mono text-[10px] uppercase tracking-widest hover:text-cobalt">{crumb.label}</Link> : <span className="truncate font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{crumb.label}</span>}</span>) }
  </nav>;
}