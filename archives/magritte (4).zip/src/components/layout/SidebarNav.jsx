import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { useProjects } from "@/lib/useProjects";
import { buildSidebarNav } from "@/components/layout/sidebarNavItems";
import SidebarNavItem from "@/components/layout/SidebarNavItem";
import SidebarNavPanel from "@/components/layout/SidebarNavPanel";
import "@/components/layout/sidebar-nav.css";

export default function SidebarNav() {
  const { projects } = useProjects(), { pathname } = useLocation();
  const { theme, setTheme } = useTheme();
  const [openLabel, setOpenLabel] = useState(null);
  const items = useMemo(() => buildSidebarNav(projects), [projects]);
  const openItem = items.find((item) => item.label === openLabel);
  useEffect(() => setOpenLabel(null), [pathname]);
  useEffect(() => {
    const close = (event) => event.key === "Escape" && setOpenLabel(null);
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, []);
  const isActive = (item) => item.path === pathname || item.items?.some((entry) => entry.path === pathname);
  return <nav className="sidebar-nav-shell" data-open={openItem ? "true" : undefined} aria-label="Navigation principale">
    <div className="sidebar-nav-bar">
      <Link to="/compte" className="sidebar-nav-brand" aria-label="Mon compte"><span>A</span></Link>
      <div className="sidebar-nav-divider"/>
      <ul className="sidebar-nav-group">{items.map((item) => <SidebarNavItem key={item.label} item={item} active={isActive(item)} expanded={openLabel === item.label} onToggle={() => setOpenLabel(openLabel === item.label ? null : item.label)} onNavigate={() => setOpenLabel(null)}/>)}</ul>
      <div className="sidebar-nav-divider"/>
      <button type="button" className="sidebar-nav-button" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="Changer de thème">{theme === "dark" ? <Sun/> : <Moon/>}<span className="sidebar-nav-tooltip">Thème</span></button>
    </div>
    <SidebarNavPanel item={openItem} pathname={pathname} onClose={() => setOpenLabel(null)}/>
  </nav>;
}