import React, { useEffect } from "react";
import { useTheme } from "next-themes";
import useSiteSettings from "@/lib/useSiteSettings";
import { contrastHex, hexToHsl, mixHex } from "@/lib/colorUtils";

const defaults = { light: { background: "#F6F6F6", primary: "#2E5BFF", accent: "#A3B18A" }, dark: { background: "#121212", primary: "#5B7CFF", accent: "#A3B18A" } };
export default function DynamicTheme() {
  const { resolvedTheme } = useTheme(), { settings } = useSiteSettings();
  useEffect(() => {
    const mode = resolvedTheme === "dark" ? "dark" : "light", palette = { ...defaults[mode], ...settings?.design_system?.[mode] }, foreground = contrastHex(palette.background), root = document.documentElement;
    const tokens = { background: palette.background, foreground, card: mixHex(palette.background, foreground, .03), "card-foreground": foreground, popover: mixHex(palette.background, foreground, .03), "popover-foreground": foreground, secondary: mixHex(palette.background, foreground, .08), "secondary-foreground": foreground, muted: mixHex(palette.background, foreground, .06), "muted-foreground": mixHex(palette.background, foreground, .58), border: mixHex(palette.background, foreground, .16), input: mixHex(palette.background, foreground, .16), primary: palette.primary, "primary-foreground": contrastHex(palette.primary), accent: palette.accent, "accent-foreground": contrastHex(palette.accent), ring: palette.primary, "sidebar-background": palette.background, "sidebar-foreground": foreground, "sidebar-primary": palette.primary, "sidebar-primary-foreground": contrastHex(palette.primary), "sidebar-accent": mixHex(palette.background, foreground, .06), "sidebar-accent-foreground": foreground, "sidebar-border": mixHex(palette.background, foreground, .16), "sidebar-ring": palette.primary };
    Object.entries(tokens).forEach(([key, value]) => root.style.setProperty(`--${key}`, hexToHsl(value)));
  }, [resolvedTheme, settings]);
  return null;
}