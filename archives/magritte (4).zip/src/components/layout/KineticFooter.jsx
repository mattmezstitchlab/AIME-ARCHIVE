import React from "react";
import { Link } from "react-router-dom";
import useSiteSettings from "@/lib/useSiteSettings";

const services = ["Mariage", "Concert", "Soirée privée", "Entreprise", "Festival", "Cocktail"];

function MarqueeRow({ items, direction = "left" }) {
  const doubled = [...items, ...items, ...items, ...items];
  const [hoveredIndex, setHoveredIndex] = React.useState(null);
  const trackRef = React.useRef(null);
  const savedX = React.useRef(0);

  const handleMouseEnter = (i) => {
    setHoveredIndex(i);
    if (trackRef.current) {
      const matrix = new DOMMatrix(getComputedStyle(trackRef.current).transform);
      savedX.current = matrix.m41;
      trackRef.current.style.animationPlayState = "paused";
      trackRef.current.style.transform = `translateX(${savedX.current}px)`;
      trackRef.current.style.animation = "none";
    }
  };

  const handleMouseLeave = () => {
    setHoveredIndex(null);
    if (trackRef.current) {
      const totalWidth = trackRef.current.scrollWidth / 2;
      const currentX = savedX.current;
      const progress = direction === "right" ?
      1 - Math.abs(currentX) / totalWidth :
      Math.abs(currentX) / totalWidth;
      const delay = -(progress * 60);
      trackRef.current.style.transform = "";
      trackRef.current.style.animation = `marquee 60s linear ${delay}s infinite`;
      trackRef.current.style.animationDirection = direction === "right" ? "reverse" : "normal";
    }
  };

  return (
    <div className="overflow-hidden whitespace-nowrap">
      <div
        ref={trackRef}
        className="marquee-track inline-flex"
        style={{ animationDirection: direction === "right" ? "reverse" : "normal" }}>
        {doubled.map((item, i) =>
        <span className="contents" key={i}>
            <span
            className="text-4xl md:text-6xl lg:text-8xl font-mono font-light tracking-tight uppercase select-none leading-none cursor-default transition-colors duration-200"
            onMouseEnter={() => handleMouseEnter(i)}
            onMouseLeave={handleMouseLeave}>
              <span
              className="transition-all duration-300"
              style={{
                color: hoveredIndex === i ? '#2E5BFF' : hoveredIndex !== null ? 'inherit' : undefined,
                filter: hoveredIndex !== null && hoveredIndex !== i ? 'blur(4px)' : 'none',
                opacity: hoveredIndex === i ? 1 : hoveredIndex !== null ? 0.15 : 0.1
              }}>
              {item}</span>
            </span>
            <span
            className="text-4xl md:text-6xl lg:text-8xl font-mono font-light text-foreground select-none leading-none mx-2 md:mx-4 transition-all duration-300"
            style={{ filter: hoveredIndex !== null ? 'blur(4px)' : 'none', opacity: hoveredIndex !== null ? 0.15 : 0.1 }}>
            ·</span>
          </span>
        )}
      </div>
    </div>);
}

function FooterLink({ item }) {
  const classes = "font-body text-sm text-foreground transition-colors hover:text-cobalt";
  return item.url?.startsWith("/") ? <Link to={item.url} className={classes}>{item.label}</Link> : <a href={item.url} target="_blank" rel="noopener noreferrer" className={classes}>{item.label}</a>;
}

export default function KineticFooter() {
  const { settings } = useSiteSettings();
  const footer = settings?.footer || {};
  const navigation = footer.navigation?.length ? footer.navigation : [{ label: "Accueil", url: "/" }, { label: "À propos", url: "/about" }, { label: "Contact", url: "/contact" }];
  const socials = footer.socials?.length ? footer.socials : [{ label: "Instagram", url: "https://instagram.com" }];
  const legal = footer.legal_links?.length ? footer.legal_links : [{ label: "Confidentialité", url: "/privacy" }, { label: "Accessibilité", url: "/accessibility" }];
  return <footer className="relative overflow-hidden py-16 md:pb-[26px] md:pt-24">
    <div className="mb-8 space-y-4 md:mb-24"><MarqueeRow items={footer.services?.length ? footer.services : services} direction="left" /></div>
    <div className="px-6 md:px-8 lg:px-12">
      <div className="mb-12 grid grid-cols-2 gap-8 md:mb-16 lg:grid-cols-4">
        <div><h3 className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">Navigation</h3><div className="flex flex-col gap-3">{navigation.map((item, i) => <FooterLink key={i} item={item}/>)}</div></div>
        <div><h3 className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">Réseaux</h3><div className="flex flex-col gap-3">{socials.map((item, i) => <FooterLink key={i} item={item}/>)}</div></div>
        <div><h3 className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">Contact</h3><div className="flex flex-col gap-3"><a href={`mailto:${footer.email || "contact@alexmoreau.fr"}`} className="text-sm hover:text-cobalt">{footer.email || "contact@alexmoreau.fr"}</a><span className="text-sm text-muted-foreground">{footer.location || "Paris, France"}</span></div></div>
        <div><h3 className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">Légal</h3><div className="flex flex-col gap-3">{legal.map((item, i) => <FooterLink key={i} item={item}/>)}</div></div>
      </div>
      <div className="border-t border-border pt-8"><span className="font-mono text-xs text-muted-foreground">{footer.copyright || "© 2026 Alex Moreau. Créé avec Base44."}</span></div>
    </div>
  </footer>;
}