import React from "react";
import { Link } from "react-router-dom";
import { X } from "lucide-react";

export default function SidebarNavPanel({ item, pathname, onClose }) {
  return <div className="sidebar-nav-panel" aria-hidden={!item}>
    <div className="sidebar-nav-panel-inner">
      <header className="flex items-center justify-between gap-3"><h2>{item?.label}</h2><button type="button" className="sidebar-nav-close" onClick={onClose} aria-label="Fermer le sous-menu"><X/></button></header>
      <ul className="space-y-2">{item?.items?.map((entry) => <li key={entry.path}><Link to={entry.path} onClick={onClose} className="sidebar-nav-subitem" aria-current={pathname === entry.path ? "page" : undefined}>{entry.label}</Link></li>)}</ul>
    </div>
  </div>;
}