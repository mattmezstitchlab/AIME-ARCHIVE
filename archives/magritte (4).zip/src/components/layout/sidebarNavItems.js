import { Home, Layers, IdCard, Wrench, Users, Info } from "lucide-react";

export const buildSidebarNav = () => [
  { label: "Accueil", path: "/", icon: Home },
  { label: "Univers", path: "/projects", icon: Layers },
  { label: "Passports", path: "/mon-passport", icon: IdCard },
  { label: "Modules", path: "/mariage/modules", icon: Wrench },
  { label: "Réseau", path: "/mariage/registre", icon: Users },
  { label: "AIME®", path: "/about", icon: Info },
];