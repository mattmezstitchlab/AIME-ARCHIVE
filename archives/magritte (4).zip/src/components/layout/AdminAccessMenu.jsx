import React from "react";
import { Link, useLocation } from "react-router-dom";
import { IdCard, LockKeyhole, PanelsTopLeft, Settings } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function AdminAccessMenu() {
  const { user } = useAuth(), { search } = useLocation();
  if (user?.role !== "admin" || new URLSearchParams(search).get("edit") === "1") return null;
  return <div className="fixed right-4 top-4 z-[90] md:right-8 md:top-8">
    <DropdownMenu>
      <DropdownMenuTrigger asChild><Button variant="outline" className="bg-background/90 shadow-sm backdrop-blur"><LockKeyhole />Mon espace</Button></DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="pointer-events-auto w-52">
        <DropdownMenuLabel>Espace privé</DropdownMenuLabel><DropdownMenuSeparator />
        <DropdownMenuItem asChild><Link to="/compte"><IdCard />Mon compte</Link></DropdownMenuItem>
        <DropdownMenuItem asChild><Link to="/studio"><PanelsTopLeft />Canevas du site</Link></DropdownMenuItem>
        <DropdownMenuItem asChild><Link to="/admin"><Settings />Administration</Link></DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  </div>;
}