import React from "react";
import { Link } from "react-router-dom";

export default function SidebarNavItem({ item, active, expanded, onToggle, onNavigate }) {
  const Icon = item.icon;
  const content = <><Icon aria-hidden="true"/><span className="sidebar-nav-tooltip">{item.label}</span></>;
  return <li className="relative">
    {item.items ? <button type="button" className="sidebar-nav-button" aria-label={item.label} aria-haspopup="true" aria-expanded={expanded} aria-current={active ? "page" : undefined} onClick={onToggle}>{content}</button>
      : <Link to={item.path} className="sidebar-nav-button" aria-label={item.label} aria-current={active ? "page" : undefined} onClick={onNavigate}>{content}</Link>}
  </li>;
}