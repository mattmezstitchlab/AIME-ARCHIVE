import React from "react";
import { eventPhases, getEventPhase } from "@/lib/eventPhases";

export default function EventPhaseControl({ profile, onSave, saving }) {
  const active = getEventPhase(profile), automatic = profile?.phase_mode !== "manuel";
  return <section className="border border-border bg-card p-6">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Phase de l’événement</span><h2 className="mt-2 text-2xl font-light">{eventPhases.find((phase) => phase.key === active)?.label}</h2></div>
      <button disabled={!profile || saving || automatic} onClick={() => onSave({ phase_mode: "automatique" })} className="border border-border px-3 py-2 font-mono text-xs uppercase tracking-widest disabled:opacity-40">Mode automatique</button>
    </div>
    <div className="mt-6 grid grid-cols-3 border border-border">
      {eventPhases.map((phase) => <button key={phase.key} disabled={!profile || saving} onClick={() => onSave({ phase_mode: "manuel", event_phase: phase.key })} className={`min-h-14 px-2 py-3 font-mono text-[10px] uppercase tracking-widest md:text-xs ${active === phase.key ? "bg-foreground text-background" : "text-muted-foreground"}`}>{phase.label}</button>)}
    </div>
    {!profile && <p className="mt-3 text-sm text-muted-foreground">Enregistrez d’abord les informations du mariage pour activer les phases.</p>}
  </section>;
}