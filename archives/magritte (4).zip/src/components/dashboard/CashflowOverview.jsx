import React from "react";

export default function CashflowOverview({ documents }) {
  const total = documents.reduce((sum, item) => sum + Number(item.total_amount || 0), 0);
  const paid = documents.reduce((sum, item) => sum + Number(item.paid_amount || 0), 0);
  const remaining = Math.max(0, total - paid);
  const paidPercent = total ? Math.min(100, Math.round((paid / total) * 100)) : 0;
  const values = [["Engagé", total], ["Déjà payé", paid], ["À décaisser", remaining]];
  return <section className="border border-border bg-card p-6"><div className="grid gap-6 md:grid-cols-3">{values.map(([label, value]) => <div key={label}><p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{label}</p><p className="mt-2 text-3xl font-light">{value.toLocaleString("fr-FR")} €</p></div>)}</div><div className="mt-6 h-2 bg-muted"><div className="h-full bg-cobalt transition-all" style={{ width: `${paidPercent}%` }}/></div><p className="mt-2 text-right font-mono text-xs text-muted-foreground">{paidPercent}% réglé</p></section>;
}