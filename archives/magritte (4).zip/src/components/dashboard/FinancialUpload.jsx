import React, { useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { FileUp, Loader2 } from "lucide-react";

const extractionSchema = { type: "object", properties: { vendor_name: { type: "string" }, document_type: { type: "string" }, total_amount: { type: "number" }, deposit_amount: { type: "number" }, paid_amount: { type: "number" }, next_due_date: { type: "string", format: "date" }, notes: { type: "string" } } };
export default function FinancialUpload({ onExtracted }) {
  const inputRef = useRef(null);
  const [loading, setLoading] = useState(false), [error, setError] = useState("");
  const analyze = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setLoading(true); setError("");
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri, expires_in: 300 });
      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({ file_url: signed_url, json_schema: extractionSchema });
      if (result.status !== "success") throw new Error(result.details || "Analyse impossible");
      const extracted = (Array.isArray(result.output) ? result.output[0] : result.output) || {};
      const allowedTypes = ["devis", "contrat", "facture", "autre"];
      onExtracted({ ...extracted, document_type: allowedTypes.includes(extracted.document_type?.toLowerCase()) ? extracted.document_type.toLowerCase() : "autre", total_amount: Number(extracted.total_amount || 0), deposit_amount: Number(extracted.deposit_amount || 0), paid_amount: Number(extracted.paid_amount || 0), file_uri, file_name: file.name, analysis_status: "extrait" });
    } catch (err) { setError(err.message || "Ce document n’a pas pu être analysé."); }
    setLoading(false); event.target.value = "";
  };
  return <div className="border border-dashed border-cobalt bg-card p-6"><input ref={inputRef} type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={analyze} className="hidden"/><FileUp className="h-6 w-6 text-cobalt"/><h3 className="mt-4 text-xl font-light">Déposer un devis ou un contrat</h3><p className="mt-2 max-w-xl text-sm text-muted-foreground">Le fichier reste privé. Les montants, acomptes et échéances détectés seront présentés pour vérification.</p><Button onClick={() => inputRef.current?.click()} disabled={loading} className="mt-5">{loading && <Loader2 className="h-4 w-4 animate-spin"/>}{loading ? "Lecture du document…" : "Choisir un fichier"}</Button>{error && <p className="mt-3 text-sm text-destructive">{error}</p>}</div>;
}