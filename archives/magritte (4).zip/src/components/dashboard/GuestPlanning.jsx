import React from "react";
import { Users } from "lucide-react";
import GuestComposer from "@/components/dashboard/GuestComposer";
import GuestRow from "@/components/dashboard/GuestRow";
import SeatingBoard from "@/components/dashboard/SeatingBoard";

export default function GuestPlanning({ profile, planning }) {
  const people = planning.guests.reduce((sum, guest) => sum + (guest.party_size || 1), 0), confirmed = planning.guests.filter((guest) => guest.rsvp_status === "confirme").reduce((sum, guest) => sum + (guest.party_size || 1), 0);
  return <div className="grid gap-6"><header className="flex flex-wrap items-end justify-between gap-4"><div><span className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-cobalt"><Users className="h-4 w-4" />Réception</span><h2 className="mt-2 text-3xl font-light md:text-5xl">RSVP & tables</h2><p className="mt-2 text-muted-foreground">Suivez les réponses et organisez le placement de vos invités.</p></div><p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{confirmed}/{people} personne{people > 1 ? "s" : ""} confirmée{confirmed > 1 ? "s" : ""}</p></header>
    <div className="grid gap-6 xl:grid-cols-[1fr_1.35fr]"><div className="grid content-start gap-6"><GuestComposer onCreate={(data) => planning.createGuest({ ...data, wedding_profile_id: profile?.id })} /><SeatingBoard profileId={profile?.id} tables={planning.tables} guests={planning.guests} onCreate={planning.createTable} onDelete={planning.removeTable} /></div><section className="border border-border bg-card p-6"><h3 className="mb-2 text-2xl font-light">Liste des invités</h3>{planning.isLoading ? <div className="h-32 animate-pulse bg-muted" /> : planning.guests.length ? planning.guests.map((guest) => <GuestRow key={guest.id} guest={guest} tables={planning.tables} onUpdate={planning.updateGuest} onDelete={planning.removeGuest} />) : <p className="py-8 text-center text-muted-foreground">Aucun invité ajouté.</p>}</section></div>
  </div>;
}