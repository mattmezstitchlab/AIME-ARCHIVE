import React, { useState } from "react";
import { Plus } from "lucide-react";
import { Input } from "@/components/ui/input";

const empty = { title: "", scheduled_at: "", duration_minutes: 30, category: "autre", responsible: "" };

export default function TimelineComposer({ onCreate }) {
  const [form, setForm] = useState(empty), [saving, setSaving] = useState(false);
  const update = (key, value) => setForm({ ...form, [key]: value });
  const submit = async () => { setSaving(true); await onCreate({ ...form, scheduled_at: new Date(form.scheduled_at).toISOString() }); setForm(empty); setSaving(false); };
  return <section className="border border-border bg-card p-6">
    <h3 className="mb-4 text-xl font-light">Ajouter une étape</h3>
    <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-5">
      <Input aria-label="Nom de l’étape" value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="Arrivée du traiteur" className="lg:col-span-2" />
      <Input aria-label="Date et heure de l’étape" type="datetime-local" value={form.scheduled_at} onChange={(e) => update("scheduled_at", e.target.value)} />
      <Input aria-label="Durée en minutes" type="number" min="0" value={form.duration_minutes} onChange={(e) => update("duration_minutes", Number(e.target.value))} />
      <Input aria-label="Responsable de l’étape" value={form.responsible} onChange={(e) => update("responsible", e.target.value)} placeholder="Responsable" />
      <select aria-label="Catégorie de l’étape" value={form.category} onChange={(e) => update("category", e.target.value)} className="h-9 border border-input bg-background px-3 text-sm"><option value="ceremonie">Cérémonie</option><option value="reception">Réception</option><option value="logistique">Logistique</option><option value="prestataire">Prestataire</option><option value="autre">Autre</option></select>
    </div>
    <button disabled={saving || !form.title || !form.scheduled_at} onClick={submit} className="mt-4 inline-flex items-center gap-2 bg-foreground px-4 py-2 text-sm text-background disabled:opacity-40"><Plus className="h-4 w-4" />{saving ? "Ajout…" : "Ajouter à la timeline"}</button>
  </section>;
}