import React from "react";
import { Trash2 } from "lucide-react";
import GuestMagicLink from "@/components/dashboard/GuestMagicLink";

export default function GuestRow({ guest, tables, onUpdate, onDelete }) {
  return <article className="grid gap-3 border-b border-border py-4 last:border-0 lg:grid-cols-[1fr_150px_170px_auto] lg:items-center">
    <div><h3 className="font-medium">{guest.full_name}</h3><p className="mt-1 text-sm text-muted-foreground">{guest.party_size || 1} personne{(guest.party_size || 1) > 1 ? "s" : ""}{guest.email ? ` · ${guest.email}` : ""}</p></div>
    <select aria-label={`RSVP de ${guest.full_name}`} value={guest.rsvp_status || "en_attente"} onChange={(e) => onUpdate(guest.id, { rsvp_status: e.target.value })} className="h-9 border border-input bg-background px-3 text-sm"><option value="en_attente">En attente</option><option value="confirme">Confirmé</option><option value="decline">Décliné</option></select>
    <select aria-label={`Table de ${guest.full_name}`} value={guest.table_id || ""} onChange={(e) => onUpdate(guest.id, { table_id: e.target.value })} className="h-9 border border-input bg-background px-3 text-sm"><option value="">Sans table</option>{tables.map((table) => <option key={table.id} value={table.id}>{table.name}</option>)}</select>
    <div className="flex items-center gap-2"><GuestMagicLink guest={guest} onUpdate={onUpdate} />
    <button aria-label={`Supprimer ${guest.full_name}`} onClick={() => onDelete(guest.id)} className="w-fit border border-border p-2 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button></div>
  </article>;
}