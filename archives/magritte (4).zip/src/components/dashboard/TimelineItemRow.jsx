import React from "react";
import { Clock3, Trash2, UserRound } from "lucide-react";

const labels = { a_venir: "À venir", confirme: "Confirmé", en_cours: "En cours", termine: "Terminé", retard: "Retard" };

export default function TimelineItemRow({ item, onUpdate, onDelete }) {
  const date = new Date(item.scheduled_at);
  return <article className="grid gap-4 border border-border bg-card p-5 md:grid-cols-[150px_1fr_auto] md:items-center">
    <div><p className="font-mono text-sm">{date.toLocaleDateString("fr-FR", { day: "2-digit", month: "short" })}</p><p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground"><Clock3 className="h-4 w-4" />{date.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })} · {item.duration_minutes || 0} min</p></div>
    <div><h3 className="text-lg font-medium">{item.title}</h3>{item.responsible && <p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground"><UserRound className="h-4 w-4" />{item.responsible}</p>}</div>
    <div className="flex items-center gap-2">
      <select aria-label={`Statut de ${item.title}`} value={item.status || "a_venir"} onChange={(e) => onUpdate(item.id, { status: e.target.value })} className="h-9 border border-input bg-background px-3 text-sm">{Object.entries(labels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>
      <button aria-label={`Supprimer ${item.title}`} onClick={() => onDelete(item.id)} className="border border-border p-2 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
    </div>
  </article>;
}