import React from "react";
import EventPhaseControl from "@/components/dashboard/EventPhaseControl";
import TimelineComposer from "@/components/dashboard/TimelineComposer";
import TimelineItemRow from "@/components/dashboard/TimelineItemRow";

export default function TimelineBoard({ profile, onSaveProfile, savingProfile, timeline }) {
  return <div className="grid gap-6">
    <header><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Système nerveux</span><h2 className="mt-2 text-3xl font-light md:text-4xl">Timeline dynamique</h2><p className="mt-2 max-w-2xl text-muted-foreground">Organisez les moments clés et suivez leur état jusqu’au Jour J.</p></header>
    <EventPhaseControl profile={profile} onSave={onSaveProfile} saving={savingProfile} />
    <TimelineComposer onCreate={(data) => timeline.create({ ...data, wedding_profile_id: profile?.id })} />
    <section className="grid gap-3">
      <div className="flex items-center justify-between"><h3 className="text-xl font-light">Déroulé opérationnel</h3><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{timeline.items.length} étape{timeline.items.length > 1 ? "s" : ""}</span></div>
      {timeline.isLoading ? <div className="h-24 animate-pulse bg-muted" /> : timeline.items.length ? timeline.items.map((item) => <TimelineItemRow key={item.id} item={item} onUpdate={timeline.update} onDelete={timeline.remove} />) : <div className="border border-dashed border-border p-10 text-center text-muted-foreground">Aucune étape planifiée.</div>}
    </section>
  </div>;
}