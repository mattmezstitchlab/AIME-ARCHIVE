import React, { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const empty = { partner_one: "", partner_two: "", wedding_date: "", location: "", guest_target: 0, total_budget: 0 };

export default function WeddingProfileCard({ profile, onSave, saving }) {
  const [form, setForm] = useState(empty), [errors, setErrors] = useState({});
  useEffect(() => { setForm(profile ? { ...empty, ...profile } : empty); }, [profile]);
  const update = (key, value) => { setForm({ ...form, [key]: value }); setErrors({ ...errors, [key]: "", submit: "" }); };
  const field = (key, label, type = "text", placeholder = "", required = false) => <label className="block space-y-2"><span className="text-sm">{label}{required && " *"}</span><Input type={type} value={form[key] || ""} placeholder={placeholder} required={required} aria-invalid={Boolean(errors[key])} onChange={(e) => update(key, type === "number" ? Number(e.target.value) : e.target.value)}/>{errors[key] && <p className="text-sm text-destructive">{errors[key]}</p>}</label>;
  const submit = async (event) => {
    event.preventDefault();
    const next = {};
    if (!form.partner_one.trim()) next.partner_one = "Indiquez le premier prénom.";
    if (!form.partner_two.trim()) next.partner_two = "Indiquez le deuxième prénom.";
    if (Object.keys(next).length) { setErrors(next); return; }
    try { await onSave({ ...form, partner_one: form.partner_one.trim(), partner_two: form.partner_two.trim() }); }
    catch (error) { setErrors({ submit: error.message || "Impossible d’enregistrer le profil." }); }
  };
  return <form onSubmit={submit} noValidate className="border border-border bg-card p-6 md:p-8">
    <div className="mb-6"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">01 · Votre mariage</span><h2 className="mt-2 text-2xl font-light">Les informations essentielles</h2></div>
    <div className="grid gap-4 md:grid-cols-2">
      {field("partner_one", "Premier prénom", "text", "Premier prénom", true)}{field("partner_two", "Deuxième prénom", "text", "Deuxième prénom", true)}
      {field("wedding_date", "Date du mariage", "date")}{field("location", "Lieu du mariage", "text", "Lieu du mariage")}
      {field("guest_target", "Nombre d’invités", "number", "Nombre d’invités")}{field("total_budget", "Budget total (€)", "number", "Budget total (€)")}
    </div>
    {errors.submit && <p className="mt-4 text-sm text-destructive">{errors.submit}</p>}
    <Button type="submit" disabled={saving} className="mt-5 rounded-none">{saving ? "Enregistrement…" : "Mettre à jour le Passport Mariage"}</Button>
  </form>;
}