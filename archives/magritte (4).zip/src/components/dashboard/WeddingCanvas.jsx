import React, { useState } from "react";
import { Loader2 } from "lucide-react";
import CanvasToolbar from "./CanvasToolbar";
import CanvasBlockComposer from "./CanvasBlockComposer";
import CanvasStage from "./CanvasStage";

export default function WeddingCanvas({ profileId, canvas }) {
  const [composer, setComposer] = useState(null), [saving, setSaving] = useState(false), [error, setError] = useState("");
  const save = async (form) => {
    setSaving(true); setError("");
    try {
      if (composer.block) await canvas.update(composer.block.id, form);
      else {
        const index = canvas.blocks.length;
        await canvas.create({ ...form, type: composer.type, wedding_profile_id: profileId || "", x: 32 + (index % 3) * 280, y: 32 + Math.floor(index / 3) * 220, width: 240 });
      }
      setComposer(null);
    } catch (err) { setError(err.message || "Impossible d’enregistrer ce bloc."); }
    setSaving(false);
  };
  if (canvas.isLoading) return <div className="flex h-80 items-center justify-center border border-border"><Loader2 className="h-6 w-6 animate-spin"/></div>;
  return <section><div className="mb-4 flex items-end justify-between gap-4"><div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Canvas vivant</span><h2 className="mt-2 text-3xl font-light">Tout le mariage, au même endroit</h2></div><p className="hidden max-w-sm text-right text-sm text-muted-foreground md:block">Saisissez les poignées pour organiser librement vos blocs.</p></div><CanvasToolbar onAdd={(type) => setComposer({ type })}/>{composer && <CanvasBlockComposer type={composer.type} block={composer.block} saving={saving} error={error} onSave={save} onCancel={() => setComposer(null)}/>}<CanvasStage blocks={canvas.blocks} onMove={(id, position) => canvas.update(id, position)} onEdit={(block) => setComposer({ type: block.type, block })} onDelete={canvas.remove}/></section>;
}