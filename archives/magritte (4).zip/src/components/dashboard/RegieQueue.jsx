import React from "react";
import { ArrowRight, Clock3 } from "lucide-react";

export default function RegieQueue({ items, onUpdate }) {
  return <section className="border border-border bg-card p-6">
    <div className="mb-5 flex items-center justify-between"><h3 className="text-xl font-light">Prochaines étapes</h3><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{items.length} à suivre</span></div>
    <div className="divide-y divide-border">
      {items.length ? items.slice(0, 5).map((item) => <article key={item.id} className="grid gap-3 py-4 sm:grid-cols-[90px_1fr_auto] sm:items-center">
        <span className="flex items-center gap-2 font-mono text-sm"><Clock3 className="h-4 w-4 text-cobalt" />{new Date(item.scheduled_at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span>
        <div><h4 className="font-medium">{item.title}</h4><p className="mt-1 text-sm text-muted-foreground">{item.responsible || "Responsable à définir"}</p></div>
        <button onClick={() => onUpdate(item.id, { status: "en_cours" })} className="inline-flex items-center justify-center gap-2 border border-border px-3 py-2 text-sm">Prendre en charge <ArrowRight className="h-4 w-4" /></button>
      </article>) : <p className="py-8 text-center text-muted-foreground">La file est terminée.</p>}
    </div>
  </section>;
}