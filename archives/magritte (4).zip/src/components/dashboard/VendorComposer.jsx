import React, { useState } from "react";
import { Plus } from "lucide-react";
import { Input } from "@/components/ui/input";

const empty = { name: "", category: "", contact_email: "", access_level: "lecture" };

export default function VendorComposer({ onCreate }) {
  const [form, setForm] = useState(empty), [saving, setSaving] = useState(false);
  const update = (key, value) => setForm({ ...form, [key]: value });
  const submit = async () => { setSaving(true); await onCreate(form); setForm(empty); setSaving(false); };
  return <section className="border border-border bg-card p-6">
    <h3 className="mb-4 text-xl font-light">Ajouter un prestataire</h3>
    <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
      <Input aria-label="Nom du prestataire" value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Nom ou entreprise" />
      <Input aria-label="Catégorie du prestataire" value={form.category} onChange={(e) => update("category", e.target.value)} placeholder="Traiteur, photographe…" />
      <Input aria-label="Email du prestataire" type="email" value={form.contact_email} onChange={(e) => update("contact_email", e.target.value)} placeholder="Email de contact" />
      <select aria-label="Niveau d’accès" value={form.access_level} onChange={(e) => update("access_level", e.target.value)} className="h-9 border border-input bg-background px-3 text-sm"><option value="lecture">Lecture</option><option value="contribution">Contribution</option><option value="regie">Régie</option></select>
    </div>
    <button disabled={saving || !form.name || !form.category} onClick={submit} className="mt-4 inline-flex items-center gap-2 bg-foreground px-4 py-2 text-sm text-background disabled:opacity-40"><Plus className="h-4 w-4" />{saving ? "Ajout…" : "Ajouter au Hub"}</button>
  </section>;
}