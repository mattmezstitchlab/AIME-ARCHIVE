import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

export default function BudgetCard({ items, totalBudget, onAdd, onDelete }) {
  const [form, setForm] = useState({ label: "", category: "", amount: "" });
  const spent = items.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const submit = async () => { if (!form.label || !form.amount) return; await onAdd({ ...form, amount: Number(form.amount) }); setForm({ label: "", category: "", amount: "" }); };
  return (
    <section className="border border-border bg-card p-6 md:p-8">
      <span className="font-mono text-xs uppercase tracking-widest text-cobalt">02 · Budget</span>
      <div className="mt-3 flex justify-between gap-4"><h2 className="text-2xl font-light">{spent.toLocaleString("fr-FR")} € engagés</h2><p className="font-mono text-xs text-muted-foreground">sur {Number(totalBudget || 0).toLocaleString("fr-FR")} €</p></div>
      <div className="mt-5 grid gap-3 md:grid-cols-3"><Input placeholder="Dépense" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })}/><Input placeholder="Catégorie" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}/><Input type="number" placeholder="Montant (€)" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })}/></div>
      <Button onClick={submit} className="mt-3 rounded-none" variant="outline">Ajouter une dépense</Button>
      <div className="mt-5 divide-y divide-border">{items.map((item) => <div key={item.id} className="flex items-center justify-between py-3"><div><p>{item.label}</p><p className="font-mono text-xs text-muted-foreground">{item.category || "Sans catégorie"}</p></div><div className="flex items-center gap-3"><span>{Number(item.amount).toLocaleString("fr-FR")} €</span><button aria-label={`Supprimer ${item.label}`} onClick={() => onDelete(item.id)}><Trash2 className="h-4 w-4" /></button></div></div>)}</div>
    </section>
  );
}