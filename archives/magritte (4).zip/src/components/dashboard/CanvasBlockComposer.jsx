import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import MediaField from "@/components/admin/MediaField";

const labels = { idea: "Idée", inspiration: "Inspiration", quote: "Devis", provider: "Prestataire", document: "Document" };
const empty = { title: "", content: "", image_url: "", link_url: "" };
export default function CanvasBlockComposer({ type, block, saving, error, onSave, onCancel }) {
  const [form, setForm] = useState(empty);
  useEffect(() => setForm(block ? { ...empty, ...block } : empty), [block, type]);
  const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  return <div className="border-x border-t border-border bg-card p-5"><div className="flex items-center justify-between"><div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">{block ? "Modifier" : "Nouveau bloc"}</span><h3 className="mt-1 text-xl font-light">{labels[type]}</h3></div><button onClick={onCancel} className="font-mono text-xs uppercase tracking-widest">Fermer</button></div>
    <div className="mt-5 grid gap-4 md:grid-cols-2"><Input aria-label="Titre du bloc" placeholder="Titre" value={form.title} onChange={(e) => set("title", e.target.value)}/><Input aria-label="Lien du bloc" placeholder="Lien ou référence" value={form.link_url} onChange={(e) => set("link_url", e.target.value)}/><Textarea aria-label="Contenu du bloc" placeholder="Notes, contraintes, montant…" value={form.content} onChange={(e) => set("content", e.target.value)} className="min-h-24 md:col-span-2"/><div className="md:col-span-2"><MediaField label="Visuel facultatif" value={form.image_url} onChange={(value) => set("image_url", value)}/></div></div>
    {error && <p className="mt-3 text-sm text-destructive">{error}</p>}<div className="mt-4 flex gap-3"><Button onClick={() => onSave(form)} disabled={saving || !form.title.trim()}>{saving ? "Enregistrement…" : "Enregistrer le bloc"}</Button><Button variant="ghost" onClick={onCancel}>Annuler</Button></div>
  </div>;
}