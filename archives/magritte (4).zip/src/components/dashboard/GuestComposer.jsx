import React, { useState } from "react";
import { Plus } from "lucide-react";
import { Input } from "@/components/ui/input";

const empty = { full_name: "", email: "", party_size: 1 };

export default function GuestComposer({ onCreate }) {
  const [form, setForm] = useState(empty), [saving, setSaving] = useState(false);
  const update = (key, value) => setForm({ ...form, [key]: value });
  const submit = async () => { setSaving(true); await onCreate({ ...form, party_size: Number(form.party_size) }); setForm(empty); setSaving(false); };
  return <section className="border border-border bg-card p-6"><h3 className="mb-4 text-xl font-light">Ajouter un invité</h3><div className="grid gap-3 md:grid-cols-[1fr_1fr_130px]">
    <Input aria-label="Nom de l’invité" value={form.full_name} onChange={(e) => update("full_name", e.target.value)} placeholder="Nom complet" />
    <Input aria-label="Email de l’invité" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="Email" />
    <Input aria-label="Nombre de personnes" type="number" min="1" value={form.party_size} onChange={(e) => update("party_size", e.target.value)} />
  </div><button disabled={saving || !form.full_name} onClick={submit} className="mt-4 inline-flex items-center gap-2 bg-foreground px-4 py-2 text-sm text-background disabled:opacity-40"><Plus className="h-4 w-4" />{saving ? "Ajout…" : "Ajouter à la liste"}</button></section>;
}