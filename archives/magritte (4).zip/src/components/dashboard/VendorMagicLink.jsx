import React, { useState } from "react";
import { Check, Link2 } from "lucide-react";

export default function VendorMagicLink({ vendor, onUpdate }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    let token = vendor.access_token;
    if (!token) {
      token = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
      await onUpdate(vendor.id, { access_token: token });
    }
    await navigator.clipboard.writeText(`${window.location.origin}/acces-prestataire/${token}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };
  return <button aria-label={`Copier le lien de ${vendor.name}`} onClick={copy} className="inline-flex items-center gap-2 border border-border px-3 py-2 text-xs hover:bg-muted">{copied ? <Check className="h-4 w-4 text-cobalt" /> : <Link2 className="h-4 w-4" />}{copied ? "Copié" : vendor.access_token ? "Copier l’accès" : "Créer l’accès"}</button>;
}