import React from "react";
import { Mail, Trash2 } from "lucide-react";
import VendorMagicLink from "@/components/dashboard/VendorMagicLink";

const statusLabels = { a_contacter: "À contacter", contacte: "Contacté", confirme: "Confirmé", indisponible: "Indisponible" };

export default function VendorHubRow({ vendor, onUpdate, onDelete }) {
  return <article className="grid gap-4 border border-border bg-card p-5 lg:grid-cols-[1fr_190px_160px_auto_auto] lg:items-center">
    <div><span className="font-mono text-[10px] uppercase tracking-widest text-cobalt">{vendor.category}</span><h3 className="mt-1 text-lg font-medium">{vendor.name}</h3>{vendor.contact_email && <a href={`mailto:${vendor.contact_email}`} className="mt-2 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><Mail className="h-4 w-4" />{vendor.contact_email}</a>}</div>
    <label className="grid gap-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Coordination<select aria-label={`Statut de ${vendor.name}`} value={vendor.status || "a_contacter"} onChange={(e) => onUpdate(vendor.id, { status: e.target.value })} className="h-9 border border-input bg-background px-3 font-body text-sm normal-case tracking-normal text-foreground">{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
    <label className="grid gap-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Accès<select aria-label={`Accès de ${vendor.name}`} value={vendor.access_level || "lecture"} onChange={(e) => onUpdate(vendor.id, { access_level: e.target.value })} className="h-9 border border-input bg-background px-3 font-body text-sm normal-case tracking-normal text-foreground"><option value="lecture">Lecture</option><option value="contribution">Contribution</option><option value="regie">Régie</option></select></label>
    <VendorMagicLink vendor={vendor} onUpdate={onUpdate} />
    <button aria-label={`Supprimer ${vendor.name}`} onClick={() => onDelete(vendor.id)} className="w-fit border border-border p-2 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
  </article>;
}