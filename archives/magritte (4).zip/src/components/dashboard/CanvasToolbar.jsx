import React from "react";
import { FileText, Image, Lightbulb, Paperclip, Store } from "lucide-react";

const tools = [
  { type: "idea", label: "Idée", icon: Lightbulb },
  { type: "inspiration", label: "Inspiration", icon: Image },
  { type: "quote", label: "Devis", icon: FileText },
  { type: "provider", label: "Prestataire", icon: Store },
  { type: "document", label: "Document", icon: Paperclip }
];
export default function CanvasToolbar({ onAdd }) {
  return <div className="flex gap-2 overflow-x-auto border-x border-t border-border bg-card p-3">{tools.map(({ type, label, icon: Icon }) => <button key={type} onClick={() => onAdd(type)} className="flex shrink-0 items-center gap-2 border border-border px-3 py-2 font-mono text-xs uppercase tracking-widest hover:border-foreground"><Icon className="h-4 w-4"/>{label}</button>)}</div>;
}