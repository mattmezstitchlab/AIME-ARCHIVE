import React from "react";
import { ShieldCheck, UsersRound } from "lucide-react";
import VendorComposer from "@/components/dashboard/VendorComposer";
import VendorHubRow from "@/components/dashboard/VendorHubRow";

export default function VendorHub({ profile, hub }) {
  const confirmed = hub.vendors.filter((vendor) => vendor.status === "confirme").length;
  return <div className="grid gap-6">
    <header className="flex flex-wrap items-end justify-between gap-4"><div><span className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-cobalt"><UsersRound className="h-4 w-4" />Équipe événement</span><h2 className="mt-2 text-3xl font-light md:text-5xl">Hub prestataires</h2><p className="mt-2 max-w-2xl text-muted-foreground">Centralisez les contacts, les confirmations et le niveau d’accès de chaque intervenant.</p></div><div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-muted-foreground"><ShieldCheck className="h-4 w-4 text-cobalt" />{confirmed}/{hub.vendors.length} confirmé{confirmed > 1 ? "s" : ""}</div></header>
    <VendorComposer onCreate={(data) => hub.create({ ...data, wedding_profile_id: profile?.id })} />
    <section className="grid gap-3">
      {hub.isLoading ? <div className="h-32 animate-pulse bg-muted" /> : hub.vendors.length ? hub.vendors.map((vendor) => <VendorHubRow key={vendor.id} vendor={vendor} onUpdate={hub.update} onDelete={hub.remove} />) : <div className="border border-dashed border-border p-10 text-center text-muted-foreground">Aucun prestataire dans le Hub.</div>}
    </section>
  </div>;
}