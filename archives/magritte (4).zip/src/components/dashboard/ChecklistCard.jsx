import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Check, Trash2 } from "lucide-react";

export default function ChecklistCard({ items, onAdd, onToggle, onDelete }) {
  const [title, setTitle] = useState("");
  const done = items.filter((item) => item.completed).length;
  const percent = items.length ? Math.round((done / items.length) * 100) : 0;
  const submit = async () => { if (!title.trim()) return; await onAdd({ title: title.trim(), completed: false }); setTitle(""); };
  return (
    <section className="border border-border bg-card p-6 md:p-8">
      <span className="font-mono text-xs uppercase tracking-widest text-cobalt">03 · Checklist</span>
      <div className="mt-3 flex items-end justify-between"><h2 className="text-2xl font-light">{percent}% terminé</h2><span className="font-mono text-xs text-muted-foreground">{done}/{items.length} tâches</span></div>
      <div className="mt-4 h-1 bg-muted"><div className="h-full bg-cobalt transition-all" style={{ width: `${percent}%` }} /></div>
      <div className="mt-5 flex gap-2"><Input placeholder="Nouvelle tâche" value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} /><Button onClick={submit} className="rounded-none">Ajouter</Button></div>
      <div className="mt-5 divide-y divide-border">{items.map((item) => <div key={item.id} className="flex items-center gap-3 py-3"><button aria-label={`Marquer ${item.title}`} onClick={() => onToggle(item)} className={`h-5 w-5 border flex items-center justify-center ${item.completed ? "bg-cobalt border-cobalt text-primary-foreground" : "border-border"}`}>{item.completed && <Check className="h-3 w-3" />}</button><span className={`flex-1 ${item.completed ? "line-through text-muted-foreground" : ""}`}>{item.title}</span><button aria-label={`Supprimer ${item.title}`} onClick={() => onDelete(item.id)}><Trash2 className="h-4 w-4" /></button></div>)}</div>
    </section>
  );
}