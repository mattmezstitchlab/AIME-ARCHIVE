import React, { useRef, useState } from "react";
import CanvasBlockCard from "./CanvasBlockCard";

export default function CanvasStage({ blocks, onMove, onEdit, onDelete }) {
  const boardRef = useRef(null), positionsRef = useRef({});
  const [positions, setPositions] = useState({}), [drag, setDrag] = useState(null);
  const currentPosition = (block, index = 0) => positions[block.id] || { x: block.x ?? 32 + (index % 3) * 280, y: block.y ?? 32 + Math.floor(index / 3) * 220 };
  const start = (event, block, position) => {
    const board = boardRef.current, rect = board.getBoundingClientRect();
    event.currentTarget.setPointerCapture(event.pointerId);
    setDrag({ id: block.id, dx: event.clientX - rect.left + board.scrollLeft - position.x, dy: event.clientY - rect.top + board.scrollTop - position.y });
  };
  const move = (event) => {
    if (!drag) return;
    const board = boardRef.current, rect = board.getBoundingClientRect();
    const next = { x: Math.max(12, Math.min(700, event.clientX - rect.left + board.scrollLeft - drag.dx)), y: Math.max(12, Math.min(500, event.clientY - rect.top + board.scrollTop - drag.dy)) };
    positionsRef.current[drag.id] = next;
    setPositions((current) => ({ ...current, [drag.id]: next }));
  };
  const end = async () => {
    if (!drag) return;
    const next = positionsRef.current[drag.id];
    setDrag(null);
    if (next) await onMove(drag.id, next);
  };
  return <div className="overflow-auto border border-border bg-background"><div ref={boardRef} onPointerMove={move} onPointerUp={end} onPointerCancel={end} className="relative h-[680px] min-w-[960px] bg-[radial-gradient(circle,hsl(var(--border))_1px,transparent_1px)] bg-[size:24px_24px]">{blocks.length === 0 && <div className="absolute left-8 top-8 max-w-sm border border-dashed border-border bg-card p-6"><p className="text-xl font-light">Votre espace est prêt.</p><p className="mt-2 text-sm text-muted-foreground">Ajoutez une idée, un devis ou une fiche prestataire depuis la barre ci-dessus.</p></div>}{blocks.map((block, index) => <CanvasBlockCard key={block.id} block={block} position={currentPosition(block, index)} onDragStart={start} onEdit={onEdit} onDelete={onDelete}/>)}</div></div>;
}