import React from "react";
import { Link } from "react-router-dom";
import { ExternalLink, GripHorizontal, Pencil, Trash2 } from "lucide-react";

const labels = { idea: "Idée", inspiration: "Inspiration", quote: "Devis", provider: "Prestataire", document: "Document" };
const accents = { idea: "border-t-cobalt", inspiration: "border-t-sage", quote: "border-t-foreground", provider: "border-t-accent", document: "border-t-muted-foreground" };
export default function CanvasBlockCard({ block, position, onDragStart, onEdit, onDelete }) {
  return <article className={`absolute border border-border border-t-4 bg-card shadow-sm ${accents[block.type]}`} style={{ left: position.x, top: position.y, width: block.width || 240 }}>
    <button aria-label={`Déplacer ${block.title}`} onPointerDown={(event) => onDragStart(event, block, position)} className="flex w-full touch-none cursor-grab items-center justify-between border-b border-border px-3 py-2 active:cursor-grabbing"><span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{labels[block.type]}</span><GripHorizontal className="h-4 w-4"/></button>
    {block.image_url && <img src={block.image_url} alt="" className="h-28 w-full object-cover"/>}<div className="p-4"><h3 className="text-lg font-medium leading-tight">{block.title}</h3>{block.content && <p className="mt-2 line-clamp-4 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{block.content}</p>}
      <div className="mt-4 flex items-center gap-3">{block.link_url && (block.link_url.startsWith("http") ? <a href={block.link_url} target="_blank" rel="noreferrer" aria-label={`Ouvrir ${block.title}`}><ExternalLink className="h-4 w-4"/></a> : <Link to={block.link_url} aria-label={`Ouvrir ${block.title}`}><ExternalLink className="h-4 w-4"/></Link>)}<button onClick={() => onEdit(block)} aria-label={`Modifier ${block.title}`}><Pencil className="h-4 w-4"/></button><button onClick={() => onDelete(block.id)} aria-label={`Supprimer ${block.title}`}><Trash2 className="h-4 w-4"/></button></div>
    </div>
  </article>;
}