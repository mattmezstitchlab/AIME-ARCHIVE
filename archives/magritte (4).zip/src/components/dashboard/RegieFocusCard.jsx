import React from "react";
import { AlertTriangle, Check, Play, UserRound } from "lucide-react";

export default function RegieFocusCard({ item, onUpdate }) {
  if (!item) return <div className="border border-dashed border-border p-10 text-center text-muted-foreground">Aucune étape active. Ajoutez des moments dans la Timeline.</div>;
  const time = new Date(item.scheduled_at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  return <section className="bg-foreground p-6 text-background md:p-8">
    <span className="font-mono text-xs uppercase tracking-widest text-background/60">Étape prioritaire · {time}</span>
    <h2 className="mt-3 text-3xl font-light md:text-5xl">{item.title}</h2>
    {item.responsible && <p className="mt-4 flex items-center gap-2 text-background/70"><UserRound className="h-4 w-4" />{item.responsible}</p>}
    <div className="mt-8 flex flex-wrap gap-2">
      {item.status !== "en_cours" && <button onClick={() => onUpdate(item.id, { status: "en_cours" })} className="inline-flex items-center gap-2 bg-background px-4 py-3 text-sm text-foreground"><Play className="h-4 w-4" />Démarrer</button>}
      {item.status !== "termine" && <button onClick={() => onUpdate(item.id, { status: "termine" })} className="inline-flex items-center gap-2 border border-background/40 px-4 py-3 text-sm"><Check className="h-4 w-4" />Terminer</button>}
      {item.status !== "retard" && <button onClick={() => onUpdate(item.id, { status: "retard" })} className="inline-flex items-center gap-2 border border-background/40 px-4 py-3 text-sm"><AlertTriangle className="h-4 w-4" />Signaler un retard</button>}
    </div>
  </section>;
}