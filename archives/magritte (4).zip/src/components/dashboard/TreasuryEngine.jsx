import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import FinancialUpload from "./FinancialUpload";
import FinancialReviewForm from "./FinancialReviewForm";
import CashflowOverview from "./CashflowOverview";
import TreasuryTimeline from "./TreasuryTimeline";

export default function TreasuryEngine({ finances }) {
  const [draft, setDraft] = useState(null), [saving, setSaving] = useState(false), [error, setError] = useState("");
  const save = async (data) => {
    setSaving(true); setError("");
    try { draft?.id ? await finances.update(draft.id, data) : await finances.create(data); setDraft(null); }
    catch (err) { setError(err.message || "Impossible d’enregistrer cette échéance."); }
    setSaving(false);
  };
  if (finances.isLoading) return <div className="flex h-72 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin"/></div>;
  return <div className="space-y-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Moteur financier</span><h2 className="mt-2 text-3xl font-light">Prévisionnel de trésorerie</h2></div><Button variant="outline" onClick={() => setDraft({ analysis_status: "manuel" })}><Plus className="h-4 w-4"/>Ajouter manuellement</Button></div><CashflowOverview documents={finances.documents}/>{draft ? <FinancialReviewForm draft={draft} saving={saving} error={error} onSave={save} onCancel={() => setDraft(null)}/> : <FinancialUpload onExtracted={setDraft}/>}<TreasuryTimeline documents={finances.documents} onEdit={setDraft} onDelete={finances.remove}/></div>;
}