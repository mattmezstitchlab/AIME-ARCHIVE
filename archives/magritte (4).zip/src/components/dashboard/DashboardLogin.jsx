import React from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";

export default function DashboardLogin() {
  const { navigateToLogin } = useAuth();
  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="max-w-md text-center">
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Espace personnel</span>
        <h1 className="mt-4 font-body text-4xl font-light">Organisez votre mariage</h1>
        <p className="mt-4 text-muted-foreground">Connectez-vous pour retrouver votre profil, votre budget et votre checklist.</p>
        <Button onClick={navigateToLogin} className="mt-8 rounded-none">Se connecter</Button>
      </div>
    </div>
  );
}