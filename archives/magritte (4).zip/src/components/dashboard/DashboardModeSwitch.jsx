import React from "react";
import { CalendarClock, LayoutDashboard, ListChecks, Radio, Users, UsersRound, WalletCards } from "lucide-react";

export default function DashboardModeSwitch({ mode, onChange }) {
  const options = [
    { key: "canvas", label: "Vue hélicoptère", icon: LayoutDashboard },
    { key: "tools", label: "Checklist & budget", icon: ListChecks },
    { key: "timeline", label: "Timeline", icon: CalendarClock },
    { key: "regie", label: "Régie", icon: Radio },
    { key: "hub", label: "Prestataires", icon: UsersRound },
    { key: "guests", label: "Invités", icon: Users },
    { key: "treasury", label: "Trésorerie", icon: WalletCards }
  ];
  return <div className="mb-6 grid w-full grid-cols-2 border border-border bg-background p-1 sm:grid-cols-3 md:flex md:w-fit">{options.map(({ key, label, icon: Icon }) => <button key={key} onClick={() => onChange(key)} className={`flex min-w-0 items-center justify-center gap-1 px-2 py-2 font-mono text-[10px] uppercase tracking-widest md:gap-2 md:px-4 md:text-xs ${mode === key ? "bg-foreground text-background" : "text-muted-foreground"}`}><Icon className="h-4 w-4"/>{label}</button>)}</div>;
}