import React from "react";
import { CalendarDays, CheckCircle2, Euro } from "lucide-react";

export default function DashboardSummary({ profile, checklist, budget }) {
  const completed = checklist.filter((item) => item.completed).length;
  const progress = checklist.length ? Math.round((completed / checklist.length) * 100) : 0;
  const committed = budget.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const days = profile?.wedding_date ? Math.max(0, Math.ceil((new Date(profile.wedding_date) - new Date()) / 86400000)) : null;
  const items = [
    { icon: CalendarDays, label: "Avant le mariage", value: days === null ? "Date à définir" : `${days} jours` },
    { icon: CheckCircle2, label: "Préparation", value: `${progress}% terminé` },
    { icon: Euro, label: "Budget engagé", value: `${committed.toLocaleString("fr-FR")} €` }
  ];
  return <div className="mb-8 grid border border-border bg-card md:grid-cols-3">{items.map(({ icon: Icon, label, value }) => <div key={label} className="flex items-center gap-4 border-b border-border p-5 last:border-b-0 md:border-b-0 md:border-r md:last:border-r-0"><Icon className="h-5 w-5 text-cobalt"/><div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p><p className="mt-1 text-xl font-light">{value}</p></div></div>)}</div>;
}