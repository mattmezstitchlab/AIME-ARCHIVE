import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Download, Loader2, Pencil, Trash2 } from "lucide-react";

export default function FinancialDocumentRow({ document, onEdit, onDelete }) {
  const [downloading, setDownloading] = useState(false);
  const remaining = Math.max(0, Number(document.total_amount || 0) - Number(document.paid_amount || 0));
  const download = async () => {
    if (!document.file_uri) return;
    const popup = window.open("", "_blank"); setDownloading(true);
    const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: document.file_uri, expires_in: 300 });
    if (popup) popup.location = signed_url;
    setDownloading(false);
  };
  return <article className="grid gap-4 border-b border-border py-5 md:grid-cols-[1.3fr_.8fr_.8fr_auto] md:items-center"><div><span className="font-mono text-[10px] uppercase tracking-widest text-cobalt">{document.document_type} · {document.analysis_status}</span><h3 className="mt-1 text-lg">{document.vendor_name}</h3>{document.file_name && <p className="mt-1 truncate text-xs text-muted-foreground">{document.file_name}</p>}</div><div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Prochaine échéance</p><p className="mt-1">{document.next_due_date ? new Date(`${document.next_due_date}T12:00:00`).toLocaleDateString("fr-FR") : "À définir"}</p></div><div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Reste à payer</p><p className="mt-1">{remaining.toLocaleString("fr-FR")} €</p></div><div className="flex gap-3">{document.file_uri && <button onClick={download} aria-label={`Télécharger ${document.vendor_name}`}>{downloading ? <Loader2 className="h-4 w-4 animate-spin"/> : <Download className="h-4 w-4"/>}</button>}<button onClick={() => onEdit(document)} aria-label={`Modifier ${document.vendor_name}`}><Pencil className="h-4 w-4"/></button><button onClick={() => onDelete(document.id)} aria-label={`Supprimer ${document.vendor_name}`}><Trash2 className="h-4 w-4"/></button></div></article>;
}