import React from "react";
import FinancialDocumentRow from "./FinancialDocumentRow";

export default function TreasuryTimeline({ documents, onEdit, onDelete }) {
  const ordered = [...documents].sort((a, b) => (a.next_due_date || "9999").localeCompare(b.next_due_date || "9999"));
  return <section className="border border-border bg-card p-6"><div className="flex items-end justify-between"><div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Échéancier</span><h2 className="mt-2 text-2xl font-light">Prochains décaissements</h2></div><span className="font-mono text-xs text-muted-foreground">{documents.length} document{documents.length > 1 ? "s" : ""}</span></div><div className="mt-5">{ordered.length ? ordered.map((document) => <FinancialDocumentRow key={document.id} document={document} onEdit={onEdit} onDelete={onDelete}/>) : <p className="border-t border-border py-8 text-sm text-muted-foreground">Aucune échéance enregistrée pour le moment.</p>}</div></section>;
}