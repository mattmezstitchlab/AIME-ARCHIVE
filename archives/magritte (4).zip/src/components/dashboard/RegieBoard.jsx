import React from "react";
import { Radio, TimerReset } from "lucide-react";
import RegieFocusCard from "@/components/dashboard/RegieFocusCard";
import RegieQueue from "@/components/dashboard/RegieQueue";
import { getEventPhase } from "@/lib/eventPhases";

export default function RegieBoard({ profile, onSaveProfile, timeline }) {
  const active = timeline.items.filter((item) => item.status !== "termine");
  const current = active.find((item) => item.status === "en_cours") || active[0];
  const queue = active.filter((item) => item.id !== current?.id);
  const finished = timeline.items.filter((item) => item.status === "termine").length;
  const phaseActive = getEventPhase(profile) === "regie";
  return <div className="grid gap-6">
    <header className="flex flex-wrap items-end justify-between gap-4"><div><span className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-cobalt"><Radio className="h-4 w-4" />Mode opérationnel</span><h2 className="mt-2 text-3xl font-light md:text-5xl">Régie Jour J</h2></div><div className="flex gap-6 font-mono text-xs uppercase tracking-widest text-muted-foreground"><span>{finished} terminée{finished > 1 ? "s" : ""}</span><span>{active.length} active{active.length > 1 ? "s" : ""}</span></div></header>
    {!phaseActive && <div className="flex flex-wrap items-center justify-between gap-4 border border-cobalt p-4"><p className="flex items-center gap-2 text-sm"><TimerReset className="h-4 w-4 text-cobalt" />La phase Régie n’est pas encore active.</p><button disabled={!profile} onClick={() => onSaveProfile({ phase_mode: "manuel", event_phase: "regie" })} className="bg-cobalt px-4 py-2 text-sm text-primary-foreground disabled:opacity-40">Activer la Régie</button></div>}
    {timeline.isLoading ? <div className="h-64 animate-pulse bg-muted" /> : <><RegieFocusCard item={current} onUpdate={timeline.update} /><RegieQueue items={queue} onUpdate={timeline.update} /></>}
  </div>;
}