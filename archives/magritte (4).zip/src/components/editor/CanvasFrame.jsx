import React, { useEffect, useRef, useState } from "react";
import { Monitor } from "lucide-react";
import { CANVAS_DEVICES } from "@/lib/siteCanvasPages";

export default function CanvasFrame({ page, device, index = 0, active, focused = false, onSelect, onVisibleSection, onElementSelect, elementPatch }) {
  const config = CANVAS_DEVICES[device];
  const frameRef = useRef(null);
  const [pageHeight, setPageHeight] = useState(1100);
  const [ready, setReady] = useState(index === 0 || focused);
  const [loadCount, setLoadCount] = useState(0);
  useEffect(() => { const timer = setTimeout(() => setReady(true), index * 450); return () => clearTimeout(timer); }, [index]);
  const scale = focused ? config.focusScale : config.previewScale;
  const iframeHeight = focused ? config.height : pageHeight;
  const width = Math.round(config.width * scale), height = Math.round(iframeHeight * scale);
  const query = focused ? "canvas=1&edit=1" : "canvas=1";
  const source = `${page.path}${page.path.includes("?") ? "&" : "?"}${query}`;
  const handleLoad = (event) => {
    const documentHeight = event.currentTarget.contentDocument?.documentElement?.scrollHeight;
    if (documentHeight) setPageHeight(Math.min(Math.max(documentHeight, 800), 5200));
    setLoadCount((count) => count + 1);
  };
  useEffect(() => {
    const frame = frameRef.current, win = frame?.contentWindow, doc = frame?.contentDocument;
    if (!focused || !onVisibleSection || !win || !doc) return;
    const report = () => {
      const nodes = Array.from(doc.querySelectorAll("[data-editor-key]"));
      if (!nodes.length) return;
      const center = win.innerHeight / 2;
      const visible = nodes.find((node) => { const rect = node.getBoundingClientRect(); return rect.top <= center && rect.bottom >= center; }) || nodes.reduce((nearest, node) => Math.abs(node.getBoundingClientRect().top - center) < Math.abs(nearest.getBoundingClientRect().top - center) ? node : nearest);
      onVisibleSection(visible.dataset.editorKey);
    };
    const select = (event) => { const node = event.target.closest?.("[data-editor-key]"); if (node) onVisibleSection(node.dataset.editorKey); };
    win.addEventListener("scroll", report, { passive: true }); doc.addEventListener("click", select, true); report();
    return () => { win.removeEventListener("scroll", report); doc.removeEventListener("click", select, true); };
  }, [focused, loadCount, onVisibleSection]);
  useEffect(() => {
    const receive = (event) => { if (event.source === frameRef.current?.contentWindow && event.data?.type === "aime-canvas-selection") onElementSelect?.(event.data.payload); };
    window.addEventListener("message", receive); return () => window.removeEventListener("message", receive);
  }, [onElementSelect]);
  useEffect(() => { if (elementPatch) frameRef.current?.contentWindow?.postMessage({ type: "aime-canvas-apply", payload: elementPatch }, window.location.origin); }, [elementPatch]);
  return <article className="space-y-2" style={{ width }}>
    <button type="button" className="flex w-full items-center justify-between text-left" onClick={onSelect}><span className={`text-sm ${active ? "text-primary" : "text-muted-foreground"}`}>{page.label}</span><span className="flex items-center gap-1 font-mono text-[10px] text-muted-foreground"><Monitor className="h-3 w-3" />{config.width}px</span></button>
    <div className={`relative overflow-hidden bg-background shadow-sm ${active ? "ring-2 ring-primary" : "ring-1 ring-border"}`} style={{ width, height }}>
      <iframe ref={frameRef} title={`Aperçu ${page.label}`} src={ready ? source : undefined} onLoad={handleLoad} tabIndex={focused ? 0 : -1} className={`absolute left-0 top-0 origin-top-left border-0 bg-background ${focused ? "pointer-events-auto" : "pointer-events-none"}`} style={{ width: config.width, height: iframeHeight, transform: `scale(${scale})` }} />
      {!focused && <button type="button" aria-label={`Aperçu ${page.label}`} onClick={onSelect} className="absolute inset-0" />}
    </div>
  </article>;
}