import React from "react";

const backgrounds = { inherit: "bg-transparent", muted: "bg-muted", contrast: "bg-foreground text-background" };
const alignments = { left: "text-left", center: "text-center", right: "text-right" };
const spacings = { compact: "py-0", normal: "py-6", spacious: "py-12" };
const fits = { cover: "[&_img]:object-cover [&_video]:object-cover", contain: "[&_img]:object-contain [&_video]:object-contain" };
const radii = { none: "[&_img]:rounded-none [&_video]:rounded-none", subtle: "[&_img]:rounded-md [&_video]:rounded-md", generous: "[&_img]:rounded-3xl [&_video]:rounded-3xl" };

export default function EditableSection({ section, label, editing, selected, onSelect, children }) {
  if (!section.visible && !editing) return null;
  const design = section.design || {}, designClasses = `${backgrounds[design.background] || backgrounds.inherit} ${alignments[design.text_align] || alignments.left} ${spacings[design.spacing] || spacings.normal} ${fits[design.media_fit] || fits.cover} ${radii[design.media_radius] || radii.none}`;
  return <div data-editor-key={section.key} className={`relative ${designClasses} ${editing ? "cursor-pointer outline outline-1 outline-primary/30" : ""} ${selected ? "outline-2 outline-primary" : ""}`} onClickCapture={editing ? (event) => { event.preventDefault(); event.stopPropagation(); onSelect(); } : undefined}>
    {editing && <span className="pointer-events-none absolute left-3 top-3 z-40 bg-primary px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-primary-foreground">{label}</span>}
    <div className={!section.visible && editing ? "opacity-25" : ""}>{children}</div>
  </div>;
}