import React from "react";
import { Monitor, Scan, Smartphone, Tablet, Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

const devices = [{ key: "desktop", Icon: Monitor, label: "Bureau" }, { key: "tablet", Icon: Tablet, label: "Tablette" }, { key: "mobile", Icon: Smartphone, label: "Mobile" }];

export default function CanvasToolbar({ device, onDevice, zoom, onZoom, onFit }) {
  return <div className="fixed bottom-5 left-1/2 z-[120] flex -translate-x-1/2 items-center gap-1 border border-border bg-background p-1.5 shadow-xl">
    <div className="flex border-r border-border pr-1.5">{devices.map(({ key, Icon, label }) => <Button key={key} type="button" size="icon" variant={device === key ? "secondary" : "ghost"} onClick={() => onDevice(key)} aria-label={label}><Icon /></Button>)}</div>
    <Button type="button" size="icon" variant="ghost" onClick={onFit} aria-label="Ajuster toutes les pages"><Scan /></Button>
    <Button type="button" size="icon" variant="ghost" onClick={() => onZoom(zoom - 5)} aria-label="Dézoomer"><Minus /></Button>
    <span className="w-12 text-center font-mono text-xs">{zoom}%</span>
    <Button type="button" size="icon" variant="ghost" onClick={() => onZoom(zoom + 5)} aria-label="Zoomer"><Plus /></Button>
  </div>;
}