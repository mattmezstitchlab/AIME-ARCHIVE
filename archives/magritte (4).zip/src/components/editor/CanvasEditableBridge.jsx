import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";

const selector = "main section, main h1, main h2, main h3, main h4, main p, main span, main a, main button, main label, main img, main video";
const toHex = (value, fallback) => { const parts = value?.match(/\d+/g)?.slice(0, 3); return parts?.length === 3 ? `#${parts.map((part) => Number(part).toString(16).padStart(2, "0")).join("")}` : fallback; };

export default function CanvasEditableBridge() {
  const { pathname, search } = useLocation();
  const [records, setRecords] = useState([]);
  const active = new URLSearchParams(search).get("canvas") === "1" && new URLSearchParams(search).get("edit") === "1";
  const prefix = `canvas.${encodeURIComponent(pathname)}.`;
  useEffect(() => { let live = true; base44.entities.SiteText.list("-updated_date", 500).then((items) => { if (live) setRecords(items.filter((item) => item.key.startsWith(prefix))); }); return () => { live = false; }; }, [prefix]);
  useEffect(() => {
    const root = document.querySelector("#smooth-content") || document.body;
    const overrides = Object.fromEntries(records.map((record) => { try { return [record.key.slice(prefix.length), JSON.parse(record.value)]; } catch { return [record.key.slice(prefix.length), {}]; } }));
    const apply = (element, values = {}) => {
      if (values.text !== undefined && element.dataset.canvasText === "true" && element.textContent !== values.text) element.textContent = values.text;
      if (values.src && ["IMG", "VIDEO"].includes(element.tagName)) element.src = values.src;
      if (values.href && element.tagName === "A") element.href = values.href;
      element.style.color = values.color || ""; element.style.backgroundColor = values.backgroundColor || "";
      element.style.fontSize = values.fontSize ? `${values.fontSize}px` : ""; element.style.textAlign = values.textAlign || "";
      element.style.display = values.visible === false && !active ? "none" : ""; element.style.opacity = values.visible === false && active ? "0.25" : "";
    };
    const sync = () => Array.from(root.querySelectorAll(selector)).filter((element) => !element.closest("[data-canvas-ignore]")).forEach((element, index) => {
      const sectionKey = element.closest("[data-editor-key]")?.dataset.editorKey || "page";
      const id = `${sectionKey}.${element.tagName.toLowerCase()}.${index}`;
      element.dataset.canvasId = id; element.dataset.canvasText = String(!["IMG", "VIDEO"].includes(element.tagName) && element.childElementCount === 0);
      if (active) element.dataset.canvasSelectable = "true";
      apply(element, overrides[id]);
    });
    const describe = (element) => { const style = window.getComputedStyle(element), values = overrides[element.dataset.canvasId] || {}; return { id: element.dataset.canvasId, sectionKey: element.closest("[data-editor-key]")?.dataset.editorKey || "", tag: element.tagName, label: element.getAttribute("aria-label") || element.textContent?.trim().slice(0, 42) || element.alt || element.tagName.toLowerCase(), canEditText: element.dataset.canvasText === "true", text: values.text ?? element.textContent?.trim() ?? "", src: values.src ?? element.currentSrc ?? element.src ?? "", href: values.href ?? element.getAttribute("href") ?? "", color: values.color || toHex(style.color, "#121212"), backgroundColor: values.backgroundColor || toHex(style.backgroundColor, "#ffffff"), fontSize: values.fontSize || parseFloat(style.fontSize) || 16, textAlign: values.textAlign || style.textAlign || "left", visible: values.visible !== false }; };
    const click = (event) => { if (!active) return; const element = event.target.closest?.("[data-canvas-selectable]"); if (!element) return; event.preventDefault(); event.stopPropagation(); root.querySelectorAll("[data-canvas-selected]").forEach((item) => item.removeAttribute("data-canvas-selected")); element.dataset.canvasSelected = "true"; window.parent.postMessage({ type: "aime-canvas-selection", payload: describe(element) }, window.location.origin); };
    const receive = (event) => { if (event.origin !== window.location.origin || event.data?.type !== "aime-canvas-apply") return; const { id, values } = event.data.payload || {}, element = root.querySelector(`[data-canvas-id="${id}"]`); if (element) apply(element, values); };
    sync(); const observer = new MutationObserver(sync); observer.observe(root, { childList: true, subtree: true }); document.addEventListener("click", click, true); window.addEventListener("message", receive);
    return () => { observer.disconnect(); document.removeEventListener("click", click, true); window.removeEventListener("message", receive); };
  }, [active, prefix, records]);
  if (!active) return null;
  return <style>{`[data-canvas-selectable]{cursor:crosshair!important}[data-canvas-selectable]:hover{outline:1px dashed hsl(var(--primary))!important;outline-offset:2px}[data-canvas-selected]{outline:2px solid hsl(var(--primary))!important;outline-offset:2px}`}</style>;
}