import React from "react";
import { ExternalLink, LogOut } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CANVAS_DEVICES } from "@/lib/siteCanvasPages";

export default function CanvasInspector({ page, device, focused, sectionLabel, children }) {
  const config = CANVAS_DEVICES[device];
  const editPath = page.path === "/" ? "/?edit=1" : page.path;
  return <aside className="fixed inset-y-0 right-0 z-[110] w-80 overflow-y-auto border-l border-border bg-background p-5 shadow-xl">
    <div className="flex items-center justify-between border-b border-border pb-4"><div><p className="font-mono text-[10px] uppercase tracking-widest text-primary">{focused ? "Éditeur visuel" : "Canevas du site"}</p><h1 className="mt-1 text-xl font-light">{page.label}</h1></div><Button asChild size="icon" variant="ghost"><Link to="/" aria-label="Quitter le Canevas"><LogOut /></Link></Button></div>
    <div className="mt-8 space-y-6">
      <div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{sectionLabel ? "Section à l’écran" : "Page sélectionnée"}</p><h2 className="mt-2 text-2xl font-light">{sectionLabel || page.label}</h2><p className="mt-1 font-mono text-xs text-muted-foreground">{page.path}</p></div>
      {focused && children}
      <div className="border-y border-border py-4 text-sm"><div className="flex justify-between"><span className="text-muted-foreground">Format</span><span>{config.label}</span></div><div className="mt-2 flex justify-between"><span className="text-muted-foreground">Largeur</span><span>{config.width}px</span></div></div>
      <Button asChild className="w-full"><Link to={editPath}>{page.path === "/" ? "Modifier en pleine page" : "Ouvrir la page"}<ExternalLink /></Link></Button>
      {!focused && <p className="text-xs leading-relaxed text-muted-foreground">Sélectionnez un cadre pour l’agrandir, faire défiler son contenu et afficher ses réglages.</p>}
    </div>
  </aside>;
}