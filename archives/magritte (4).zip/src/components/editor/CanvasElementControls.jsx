import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function CanvasElementControls({ element, saving, error, onSave }) {
  const [draft, setDraft] = useState(element);
  useEffect(() => setDraft(element), [element]);
  const change = (key, value) => setDraft((current) => ({ ...current, [key]: value }));
  const media = ["IMG", "VIDEO"].includes(element.tag), link = element.tag === "A";
  return <form className="space-y-5" onSubmit={(event) => { event.preventDefault(); onSave(draft); }}>
    <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Contenu</p><div className="space-y-4">
      {element.canEditText && <label className="block"><span className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Texte</span><Textarea rows={4} value={draft.text || ""} onChange={(event) => change("text", event.target.value)}/></label>}
      {media && <label className="block"><span className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Média</span><Input value={draft.src || ""} onChange={(event) => change("src", event.target.value)}/></label>}
      {link && <label className="block"><span className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Lien</span><Input value={draft.href || ""} onChange={(event) => change("href", event.target.value)}/></label>}
    </div></section>
    <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Apparence</p><div className="space-y-4"><div className="grid grid-cols-2 gap-3"><label className="text-xs text-muted-foreground">Texte<Input className="mt-2 h-10 p-1" type="color" value={draft.color || "#121212"} onChange={(event) => change("color", event.target.value)}/></label><label className="text-xs text-muted-foreground">Fond<Input className="mt-2 h-10 p-1" type="color" value={draft.backgroundColor || "#ffffff"} onChange={(event) => change("backgroundColor", event.target.value)}/></label></div><label className="block text-xs text-muted-foreground">Taille<Input className="mt-2" type="number" min="8" max="160" value={draft.fontSize || 16} onChange={(event) => change("fontSize", Number(event.target.value))}/></label><label className="block text-xs text-muted-foreground">Alignement<select className="mt-2 h-9 w-full border border-input bg-background px-3" value={draft.textAlign || "left"} onChange={(event) => change("textAlign", event.target.value)}><option value="left">Gauche</option><option value="center">Centre</option><option value="right">Droite</option></select></label><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={draft.visible !== false} onChange={(event) => change("visible", event.target.checked)}/>Élément visible</label></div></section>
    <Button type="submit" className="w-full" disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer l’élément"}</Button>{error && <p className="text-sm text-destructive">{error}</p>}
  </form>;
}