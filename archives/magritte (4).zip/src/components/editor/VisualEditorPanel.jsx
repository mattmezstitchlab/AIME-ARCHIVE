import React from "react";
import { createPortal } from "react-dom";
import { Link } from "react-router-dom";
import { ArrowDown, ArrowUp, Eye, EyeOff, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import EditorContentFields from "@/components/editor/EditorContentFields";
import EditorIdentityFields from "@/components/editor/EditorIdentityFields";
import EditorDesignFields from "@/components/editor/EditorDesignFields";

export default function VisualEditorPanel({ selected, sections, registry, saving, error, onToggle, onMove, onDesign, valueFor, contentSaving, contentError, onSaveContent, identity }) {
  const definition = registry.find((item) => item.key === selected), section = sections.find((item) => item.key === selected);
  const index = sections.findIndex((item) => item.key === selected);
  const panel = <aside className="fixed inset-y-0 right-0 z-[100] w-80 max-w-[90vw] overflow-y-auto overscroll-contain border-l border-border bg-background p-5 shadow-2xl">
    <div className="flex items-center justify-between border-b border-border pb-4"><div><p className="font-mono text-[10px] uppercase tracking-widest text-primary">Éditeur visuel</p><h2 className="mt-1 text-xl font-light">Accueil</h2></div><Button asChild variant="ghost" size="icon"><Link to="/admin?tab=accueil" aria-label="Quitter l’éditeur"><LogOut /></Link></Button></div>
    {!section ? <p className="mt-8 text-sm text-muted-foreground">Cliquez sur une section de la page pour afficher ses propriétés.</p> : <div className="mt-8 space-y-6">
      <div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Section sélectionnée</p><h3 className="mt-2 text-2xl font-light">{definition?.label}</h3></div>
      {definition?.fields?.length > 0 && <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Contenu</p><EditorContentFields key={selected} fields={definition.fields} valueFor={valueFor} saving={contentSaving} onSave={onSaveContent}/>{contentError && <p className="mt-3 text-sm text-destructive">{contentError}</p>}</section>}
      <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Identité globale</p><EditorIdentityFields {...identity}/></section>
      <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Design & média</p><EditorDesignFields value={section.design} saving={saving} onChange={(patch) => onDesign(section.key, patch)}/></section>
      <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Section</p><div className="flex gap-2"><Button type="button" variant="outline" size="icon" disabled={saving || index === 0} onClick={() => onMove(section.key, -1)} aria-label={`Monter ${definition?.label}`}><ArrowUp /></Button><Button type="button" variant="outline" size="icon" disabled={saving || index === sections.length - 1} onClick={() => onMove(section.key, 1)} aria-label={`Descendre ${definition?.label}`}><ArrowDown /></Button><Button type="button" variant="outline" className="flex-1" disabled={saving} onClick={() => onToggle(section.key)}>{section.visible ? <Eye /> : <EyeOff />}{section.visible ? "Visible" : "Masquée"}</Button></div></section>
      <Button asChild variant="outline" className="w-full"><Link to="/admin?tab=accueil">Réglages avancés</Link></Button>
      {saving && <p className="font-mono text-xs text-muted-foreground">Enregistrement…</p>}{error && <p className="text-sm text-destructive">{error}</p>}
    </div>}
  </aside>;
  return createPortal(panel, document.body);
}