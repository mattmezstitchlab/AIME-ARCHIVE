import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import MediaField from "@/components/admin/MediaField";

export default function EditorContentFields({ fields, valueFor, saving, onSave }) {
  const [draft, setDraft] = useState(() => Object.fromEntries(fields.map((field) => [field.key, valueFor(field.key)])));
  const change = (key, value) => setDraft((current) => ({ ...current, [key]: value }));
  return <form className="space-y-4" onSubmit={(event) => { event.preventDefault(); onSave(draft); }}>
    {fields.map((field) => field.type === "image" ? <MediaField key={field.key} label={field.label} value={draft[field.key]} onChange={(value) => change(field.key, value)}/> : <label key={field.key} className="block"><span className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{field.label}</span>{field.type === "textarea" ? <Textarea rows={4} value={draft[field.key] || ""} onChange={(event) => change(field.key, event.target.value)}/> : <Input value={draft[field.key] || ""} onChange={(event) => change(field.key, event.target.value)}/>}</label>)}
    <Button type="submit" className="w-full" disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer le contenu"}</Button>
  </form>;
}