import React from "react";
import { Button } from "@/components/ui/button";

const colors = [["background", "Fond"], ["primary", "Principale"], ["accent", "Accent"]];
const modes = [["light", "Mode jour"], ["dark", "Mode nuit"]];

export default function EditorIdentityFields({ value, saving, saved, onChange, onSave }) {
  return <div className="space-y-5">
    {modes.map(([mode, label]) => <div key={mode}><p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p><div className="grid grid-cols-3 gap-2">
      {colors.map(([key, name]) => <label key={key} className="text-[10px] text-muted-foreground"><span className="mb-1 block">{name}</span><input aria-label={`${label} ${name}`} type="color" value={value[mode][key]} onChange={(event) => onChange(mode, key, event.target.value)} className="h-9 w-full cursor-pointer border border-border bg-transparent"/></label>)}
    </div></div>)}
    <Button type="button" className="w-full" disabled={saving} onClick={onSave}>{saving ? "Enregistrement…" : saved ? "Identité enregistrée" : "Enregistrer l’identité"}</Button>
  </div>;
}