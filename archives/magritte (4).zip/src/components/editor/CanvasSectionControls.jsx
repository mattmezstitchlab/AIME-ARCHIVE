import React from "react";
import { ArrowDown, ArrowUp, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import EditorContentFields from "@/components/editor/EditorContentFields";
import EditorIdentityFields from "@/components/editor/EditorIdentityFields";
import EditorDesignFields from "@/components/editor/EditorDesignFields";

export default function CanvasSectionControls({ definition, section, sections, saving, error, valueFor, contentSaving, contentError, onSaveContent, identity, onDesign, onMove, onToggle }) {
  if (!section) return <p className="text-sm text-muted-foreground">Faites défiler la page pour détecter une section.</p>;
  const index = sections.findIndex((item) => item.key === section.key);
  return <div className="space-y-6">
    {definition?.fields?.length > 0 && <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Contenu</p><EditorContentFields key={section.key} fields={definition.fields} valueFor={valueFor} saving={contentSaving} onSave={onSaveContent}/>{contentError && <p className="mt-3 text-sm text-destructive">{contentError}</p>}</section>}
    <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Identité globale</p><EditorIdentityFields {...identity}/></section>
    <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-primary">Design & média</p><EditorDesignFields value={section.design} saving={saving} onChange={(patch) => onDesign(section.key, patch)}/></section>
    <section><p className="mb-4 border-b pb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Section</p><div className="flex gap-2"><Button variant="outline" size="icon" disabled={saving || index === 0} onClick={() => onMove(section.key, -1)} aria-label={`Monter ${definition?.label}`}><ArrowUp /></Button><Button variant="outline" size="icon" disabled={saving || index === sections.length - 1} onClick={() => onMove(section.key, 1)} aria-label={`Descendre ${definition?.label}`}><ArrowDown /></Button><Button variant="outline" className="flex-1" disabled={saving} onClick={() => onToggle(section.key)}>{section.visible ? <Eye /> : <EyeOff />}{section.visible ? "Visible" : "Masquée"}</Button></div></section>
    {saving && <p className="font-mono text-xs text-muted-foreground">Enregistrement…</p>}{error && <p className="text-sm text-destructive">{error}</p>}
  </div>;
}