import React from "react";

const fields = [
  ["background", "Fond", [["inherit", "Transparent"], ["muted", "Doux"], ["contrast", "Contraste"]]],
  ["text_align", "Alignement", [["left", "Gauche"], ["center", "Centré"], ["right", "Droite"]]],
  ["spacing", "Respiration", [["compact", "Compacte"], ["normal", "Normale"], ["spacious", "Généreuse"]]],
  ["media_fit", "Cadrage média", [["cover", "Remplir"], ["contain", "Contenir"]]],
  ["media_radius", "Angles média", [["none", "Droits"], ["subtle", "Subtils"], ["generous", "Arrondis"]]],
];

export default function EditorDesignFields({ value, saving, onChange }) {
  return <div className="space-y-4">{fields.map(([key, label, options]) => <label key={key} className="block"><span className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span><select aria-label={label} value={value[key]} disabled={saving} onChange={(event) => onChange({ [key]: event.target.value })} className="h-9 w-full border border-input bg-background px-3 text-sm">
    {options.map(([option, name]) => <option key={option} value={option}>{name}</option>)}
  </select></label>)}</div>;
}