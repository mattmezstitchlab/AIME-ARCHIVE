import React from "react";

const previews = {
  passport: ["12 septembre 2026", "120 invités", "Paris"],
  timeline: ["10:00 · Préparation", "15:00 · Cérémonie", "20:00 · Dîner"],
  registre: ["Photographe", "Traiteur", "Musique"],
  documents: ["3 documents", "12 500 € engagés", "2 échéances"],
  budget: ["65% engagé", "35% disponible", "6 catégories"],
  canevas: ["Idées", "Prestataires", "Documents"]
};

export default function ModuleTilePreview({ type }) {
  return <div className="absolute inset-x-4 bottom-4 translate-y-3 border border-gallery/30 bg-charcoal/85 p-4 text-gallery opacity-0 backdrop-blur-sm transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
    <p className="font-mono text-[9px] uppercase tracking-widest text-gallery/60">Aperçu interactif</p>
    <div className="mt-3 space-y-2">{previews[type]?.map((item, index) => <div key={item} className="flex items-center gap-2 text-xs"><span className={`h-1.5 w-1.5 ${index === 0 ? "bg-cobalt" : "bg-sage"}`}/><span>{item}</span></div>)}</div>
  </div>;
}