import React from "react";
import { Link } from "react-router-dom";
import ModuleTilePreview from "@/components/wedding/ModuleTilePreview";

export default function WeddingModuleTile({ module }) {
  return <Link to={`/mariage/${module.key}`} className="group block border border-border bg-card"><div className="relative aspect-square overflow-hidden bg-muted"><img src={module.image} alt={module.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"/><div className="absolute inset-0 bg-gradient-to-t from-charcoal/85 via-charcoal/10 to-transparent"/><span className="absolute left-5 top-5 bg-background px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-foreground">{module.number}</span><div className="absolute inset-x-5 bottom-5 transition-opacity group-hover:opacity-0 text-gallery"><p className="font-mono text-[9px] uppercase tracking-widest text-gallery/60">{module.eyebrow}</p><h2 className="mt-2 text-3xl font-light">{module.title}</h2></div><ModuleTilePreview type={module.key}/></div><p className="p-5 text-sm leading-relaxed text-muted-foreground">{module.description}</p></Link>;
}