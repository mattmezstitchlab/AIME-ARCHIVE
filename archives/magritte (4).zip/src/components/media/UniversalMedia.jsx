import React from "react";

const videoPattern = /\.(mp4|webm|mov|m4v)(\?|$)/i;

export default function UniversalMedia({ media, fallbackUrl, alt = "", className = "", controls = false, interactive = false }) {
  const url = media?.url || media?.embed_url || fallbackUrl;
  const type = media?.type || (videoPattern.test(url || "") ? "video" : "image");
  if (!url) return <div className={`bg-muted ${className}`} />;
  if (type === "video") return <video src={url} className={className} controls={controls} autoPlay={!controls} muted={!controls} loop={!controls} playsInline />;
  if (type !== "embed") return <img src={url} alt={alt} className={className} loading="lazy" />;

  const iframeClass = interactive ? "border-0" : "pointer-events-none border-0";
  if (media?.embed_mode !== "crop") return <iframe src={url} title={alt} loading="lazy" className={`${iframeClass} ${className}`} />;

  const scale = media?.frame_scale || 1;
  const transform = `translate(${-Number(media?.offset_x || 0)}px, ${-Number(media?.offset_y || 0)}px) scale(${scale})`;
  const positionClass = className.includes("absolute") ? "" : "relative";
  return (
    <div className={`${positionClass} overflow-hidden bg-muted ${className}`}>
      <iframe src={url} title={alt} loading="lazy" className={`absolute left-0 top-0 ${iframeClass}`} style={{ width: media?.frame_width || 1440, height: media?.frame_height || 900, transform, transformOrigin: "top left" }} />
    </div>
  );
}