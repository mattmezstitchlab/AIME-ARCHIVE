import React from "react";

export default function PassportCompletionNotice({ label, missing = [] }) {
  if (!missing.length) return <p className="border border-sage/40 bg-sage/10 px-3 py-2 text-xs">{label} prête</p>;
  return <div className="border border-border bg-background/90 px-3 py-2"><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">{label} · à compléter</p><p className="mt-1 text-xs">{missing.join(" · ")}</p></div>;
}