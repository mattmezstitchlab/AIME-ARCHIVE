import React from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import PassportMenuItem from "./PassportMenuItem";

export default function PassportMenuEditor({ items = [], onChange }) {
  const update = (index, item) => onChange(items.map((entry, i) => i === index ? item : entry));
  const add = () => onChange([...items, { key: `module-${Date.now()}`, label: "Nouveau module", type: "text", content: "", url: "", visible: true }]);
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Page profil · Menu universel</h2><p className="mt-1 text-sm text-muted-foreground">Ces rubriques structurent uniquement votre page profil et s’adaptent à votre métier ou à votre rôle.</p></div>{items.map((item, index) => <PassportMenuItem key={`${item.key}-${index}`} item={item} onChange={(next) => update(index, next)} onRemove={() => onChange(items.filter((_, i) => i !== index))}/>)}<Button type="button" variant="outline" onClick={add}><Plus className="h-4 w-4"/>Ajouter un module</Button></section>;
}