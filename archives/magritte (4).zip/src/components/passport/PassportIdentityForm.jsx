import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import MediaField from "@/components/admin/MediaField";

const fields = [["name", "Nom"], ["profession", "Métier / rôle"], ["location", "Zone géographique"], ["provider_slug", "Identifiant dans le registre"], ["contact_email", "Email de contact"]];
export default function PassportIdentityForm({ form, setField }) {
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Page profil · Identité publique</h2><p className="mt-2 text-sm text-muted-foreground">Ces informations enrichissent la page profil ; le nom et le rôle restent synchronisés avec la carte.</p></div><div className="grid gap-5 md:grid-cols-2">{fields.map(([key, label]) => <label key={key} className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{label}<Input name={key} value={form[key] || ""} onChange={(e) => setField(key, e.target.value)} className="mt-2"/></label>)}</div>
    <label className="block font-mono text-xs uppercase tracking-widest text-muted-foreground">Biographie<Textarea aria-label="Biographie" value={form.biography || ""} onChange={(e) => setField("biography", e.target.value)} className="mt-2 min-h-32"/></label>
    <div className="grid gap-5 md:grid-cols-2"><MediaField label="Photo ronde" value={form.avatar || ""} onChange={(value) => setField("avatar", value)}/><MediaField label="Image de couverture" value={form.cover_image || ""} onChange={(value) => setField("cover_image", value)}/></div>
  </section>;
}