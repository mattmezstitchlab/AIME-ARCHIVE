import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Compass, Folder, Info, Mail, Music2, PanelsTopLeft, Phone, Play, Ticket, UserRound } from "lucide-react";

const icons = { arrow: ArrowRight, compass: Compass, folder: Folder, info: Info, mail: Mail, music: Music2, play: Play, profile: UserRound, site: PanelsTopLeft, phone: Phone, ticket: Ticket };
export default function PassportCardAction({ action, onAction }) {
  const Icon = icons[action.icon] || ArrowRight;
  const content = <><Icon className="h-4 w-4"/><span className="text-[10px] font-medium">{action.label}</span></>;
  const className = "flex min-w-0 flex-1 items-center justify-center gap-2 border border-border bg-background px-2 py-2.5 text-foreground transition-colors hover:border-primary hover:text-primary";
  if (action.action) return <button type="button" onClick={() => onAction?.(action)} className={className} aria-label={action.label}>{content}</button>;
  if (!action.href) return <span className={className}>{content}</span>;
  if (action.href.startsWith("/")) return <Link to={action.href} className={className} aria-label={action.label}>{content}</Link>;
  return <a href={action.href} className={className} aria-label={action.label}>{content}</a>;
}