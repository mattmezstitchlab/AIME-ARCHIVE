import React from "react";

const types = [["person", "Personne"], ["organization", "Organisation"], ["event", "Événement"], ["project", "Projet"], ["place", "Lieu"], ["publication", "Publication / campagne"]];

export default function PassportClassificationEditor({ form, terms, setField }) {
  const available = terms.filter((term) => term.subject_type === form.subject_type && term.active !== false).sort((a, b) => (a.order || 0) - (b.order || 0));
  const chooseTerm = (slug) => {
    const term = terms.find((item) => item.slug === slug);
    setField("taxonomy_slug", slug);
    setField("taxonomy_path", term?.path || "");
  };
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Nature et taxonomie</h2><p className="mt-2 text-sm text-muted-foreground">Classez ce Passport dans un chemin lisible, sans confondre sa catégorie avec son rôle.</p></div><div className="grid gap-5 md:grid-cols-2">
    <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Nature<select aria-label="Nature du Passport" value={form.subject_type || "person"} onChange={(e) => { setField("subject_type", e.target.value); setField("taxonomy_slug", ""); setField("taxonomy_path", ""); }} className="mt-2 h-9 w-full border bg-background px-3">{types.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
    <label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Domaine et profondeur<select aria-label="Catégorie du Passport" value={form.taxonomy_slug || ""} onChange={(e) => chooseTerm(e.target.value)} className="mt-2 h-9 w-full border bg-background px-3"><option value="">À définir</option>{available.map((term) => <option key={term.slug} value={term.slug}>{term.path}</option>)}</select></label>
  </div>{form.taxonomy_path && <p className="border-l-2 border-primary pl-4 font-mono text-xs uppercase tracking-widest text-primary">{form.taxonomy_path.replaceAll("/", " › ")}</p>}<label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={form.registry?.listed || false} onChange={(e) => setField("registry", { ...(form.registry || {}), listed: e.target.checked })}/>Afficher ce Passport dans le Registre public</label></section>;
}