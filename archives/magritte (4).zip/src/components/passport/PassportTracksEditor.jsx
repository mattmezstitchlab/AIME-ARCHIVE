import React from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import PassportTrackItem from "./PassportTrackItem";

export default function PassportTracksEditor({ tracks = [], onChange }) {
  const update = (index, track) => onChange(tracks.map((item, i) => i === index ? track : item));
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Morceaux favoris</h2><p className="mt-1 text-sm text-muted-foreground">Ajoutez une cover, puis un fichier audio ou un lien Spotify pour chaque morceau.</p></div>{tracks.map((track, index) => <PassportTrackItem key={index} track={track} onChange={(next) => update(index, next)} onRemove={() => onChange(tracks.filter((_, i) => i !== index))}/>)}<Button type="button" variant="outline" onClick={() => onChange([...tracks, { title: "", artist: "", cover_url: "", audio_url: "", spotify_url: "" }])}><Plus className="h-4 w-4"/>Ajouter un morceau</Button></section>;
}
