import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { KeyRound, Loader2 } from "lucide-react";

export default function PassportAccessForm({ providerName, loading, error, onSubmit }) {
  const [code, setCode] = useState("");
  return <form onSubmit={(e) => { e.preventDefault(); onSubmit(code); }} className="mx-auto max-w-md border border-border p-6 md:p-8">
    <KeyRound className="mb-8 h-6 w-6 text-cobalt"/><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Accès privé</span>
    <h1 className="mt-3 text-4xl font-light">{providerName ? `Ouvrir ${providerName}` : "Ouvrir un Passport"}</h1>
    <p className="mt-4 text-muted-foreground">Saisissez le code transmis par le propriétaire de ce Passport ou de votre audience.</p>
    <Input aria-label="Code d’accès" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="PASS-XXXX-XXXX" className="mt-8 h-12 font-mono uppercase" required/>
    {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
    <Button className="mt-5 w-full" disabled={loading}>{loading && <Loader2 className="h-4 w-4 animate-spin"/>}Ouvrir le Passport</Button>
    <Link to="/mon-passport" className="mt-5 block text-center text-sm underline underline-offset-4">Créer ou gérer mes Passports</Link>
  </form>;
}