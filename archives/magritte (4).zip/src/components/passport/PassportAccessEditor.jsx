import React from "react";
import { Button } from "@/components/ui/button";
import PassportCodeField from "./PassportCodeField";
import PassportAudienceEditor from "./PassportAudienceEditor";

const options = [{ value: "public", label: "Public" }, { value: "private", label: "Privé par code" }, { value: "audiences", label: "Accès par audiences" }];

export default function PassportAccessEditor({ form, setField, passports }) {
  const audiences = form.audiences || [];
  const update = (index, value) => setField("audiences", audiences.map((item, i) => i === index ? value : item));
  const add = () => setField("audiences", [...audiences, { key: `audience-${crypto.randomUUID().slice(0, 6)}`, label: "Nouvelle audience", access_code: "", allowed_emails: [], allowed_passport_ids: [], menu_keys: [] }]);
  return <div className="space-y-6"><div><h3 className="text-2xl font-light">Confidentialité et audiences</h3><p className="mt-2 text-sm text-muted-foreground">Définissez qui ouvre ce Passport et quelles rubriques cette personne voit.</p></div>
    <label className="block space-y-2 text-sm"><span>Mode d’accès</span><select value={form.access_mode || "private"} onChange={(e) => setField("access_mode", e.target.value)} className="h-10 w-full border bg-background px-3"><option value="public">Public — visible par tous</option><option value="private">Privé — un code complet</option><option value="audiences">Audiences — vues différentes</option></select></label>
    {form.access_mode !== "public" && <div><p className="mb-3 text-sm">Accès complet du propriétaire</p><PassportCodeField value={form.access_code} onChange={(value) => setField("access_code", value)}/></div>}
    {form.access_mode === "public" && <p className="border p-4 text-sm text-muted-foreground">Le Passport complet est accessible sans code.</p>}
    {form.access_mode === "audiences" && <div className="space-y-4">{audiences.map((audience, index) => <PassportAudienceEditor key={audience.key} audience={audience} passports={passports.filter((item) => item.id !== form.id)} menu={form.menu || []} onChange={(value) => update(index, value)} onRemove={() => setField("audiences", audiences.filter((_, i) => i !== index))}/>)}<Button type="button" variant="outline" onClick={add}>Ajouter une audience</Button></div>}
  </div>;
}