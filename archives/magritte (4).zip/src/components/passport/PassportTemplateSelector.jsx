import React, { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PASSPORT_TYPES, findPassportType } from "@/lib/passportDefaults";

export default function PassportTemplateSelector({ onSelect }) {
  const [typeKey, setTypeKey] = useState(PASSPORT_TYPES[0].key);
  const type = findPassportType(typeKey);
  return <div className="max-w-xl space-y-5">
    <label className="block font-mono text-xs uppercase tracking-widest text-muted-foreground">
      Type de Passport
      <select aria-label="Type de Passport" name="passport_type" value={typeKey} onChange={(event) => setTypeKey(event.target.value)} className="mt-2 h-11 w-full border bg-background px-3 text-base font-normal normal-case tracking-normal text-foreground">
        {PASSPORT_TYPES.map((item) => <option key={item.key} value={item.key}>{item.label}</option>)}
      </select>
    </label>
    <p className="border-l-2 border-cobalt pl-4 text-sm text-muted-foreground">{type.description}<br/><span className="font-mono text-[11px] uppercase tracking-widest">Profession / rôle libre · ex : {type.professionHint}</span></p>
    <Button type="button" onClick={() => onSelect(typeKey)} data-testid="confirm-passport-type" className="h-12 w-full justify-between px-5">
      <span>Créer ce Passport</span><ArrowRight className="h-4 w-4"/>
    </Button>
  </div>;
}
