import React from "react";
import { Button } from "@/components/ui/button";
import { Check, Loader2, Save } from "lucide-react";

export default function PassportEditorBlock({ children, onSave, saving, saved, creating, testId }) {
  return <div className="space-y-6 border bg-background p-5 md:p-7">
    {children}
    {onSave && <div className="flex items-center justify-end gap-3 border-t pt-5">
      {saved && <span className="flex items-center gap-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground"><Check className="h-3 w-3"/>Enregistré</span>}
      <Button type="button" data-testid={testId} onClick={onSave} disabled={saving}>{saving ? <Loader2 className="h-4 w-4 animate-spin"/> : <Save className="h-4 w-4"/>}{creating ? "Ajouter au Passport" : "Enregistrer ce bloc"}</Button>
    </div>}
  </div>;
}