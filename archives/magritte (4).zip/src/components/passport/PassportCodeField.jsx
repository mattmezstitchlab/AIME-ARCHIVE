import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, RefreshCw } from "lucide-react";
import { makeAccessCode } from "@/lib/passportDefaults";

export default function PassportCodeField({ value, onChange, label = "Code d’accès privé" }) {
  return <div className="border border-cobalt p-5"><label className="font-mono text-xs uppercase tracking-widest text-cobalt">{label}</label><div className="mt-3 flex flex-col gap-2 sm:flex-row"><Input name="access_code" aria-label={label} value={value} onChange={(e) => onChange(e.target.value.toUpperCase())} className="font-mono uppercase"/><Button type="button" variant="outline" onClick={() => navigator.clipboard.writeText(value)}><Copy className="h-4 w-4"/>Copier</Button><Button type="button" variant="outline" onClick={() => onChange(makeAccessCode())}><RefreshCw className="h-4 w-4"/>Régénérer</Button></div><p className="mt-3 text-sm text-muted-foreground">Seules les personnes possédant ce code peuvent ouvrir le profil.</p></div>;
}