import React from "react";
import PassportManagerCard from "./PassportManagerCard";

export default function PassportManagerList({ passports, onConfigure }) {
  if (!passports.length) return <div className="border border-dashed p-10 text-center"><p className="text-lg">Aucun Passport pour le moment.</p><p className="mt-2 text-sm text-muted-foreground">Créez votre première identité publique.</p></div>;
  return <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{passports.map((passport) => <PassportManagerCard key={passport.id} passport={passport} onConfigure={onConfigure}/>)}</div>;
}