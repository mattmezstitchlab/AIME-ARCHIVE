import React, { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import BookingForm from "@/components/contact/BookingForm";
import PassportCollection from "@/components/passport/PassportCollection";

export default function PassportMenu({ items = [], biography, email }) {
  const visible = items.filter((item) => item.visible);
  const [active, setActive] = useState(() => window.location.hash === "#contact" && visible.some((item) => item.key === "contact") ? "contact" : visible[0]?.key);
  if (!visible.length) return null;
  const selected = visible.find((item) => item.key === active) || visible[0];
  const content = selected.key === "biographie" ? biography : selected.content;
  const href = selected.type === "email" ? `mailto:${selected.url || email}` : selected.url;
  return <section id="contact" className="border-t border-border py-10"><nav className="flex gap-2 overflow-x-auto pb-5" aria-label="Menu du Passport">{visible.map((item) => <button key={item.key} onClick={() => setActive(item.key)} className={`whitespace-nowrap border px-4 py-2 font-mono text-xs uppercase tracking-widest ${active === item.key ? "border-foreground bg-foreground text-background" : "border-border"}`}>{item.label}</button>)}</nav>
    <div className="min-h-32 border-l border-cobalt pl-5 pt-4">{selected.key === "passports" ? <PassportCollection/> : selected.key === "contact" ? <BookingForm/> : <>{content && <p className="max-w-2xl whitespace-pre-line text-lg leading-relaxed text-muted-foreground">{content}</p>}{href && <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-lg underline underline-offset-4">{selected.label}<ArrowUpRight className="h-4 w-4"/></a>}</>}</div>
  </section>;
}