import React from "react";
import { Button } from "@/components/ui/button";
import { Settings2 } from "lucide-react";

export default function PassportManagerCard({ passport, onConfigure }) {
  const media = passport.card_media, image = media?.url || passport.cover_image || passport.avatar, content = passport.card_content || {};
  return <article className="overflow-hidden border bg-card">
    <div className="relative aspect-[4/3] overflow-hidden bg-muted">{media?.type === "video" ? <video src={media.url} poster={media.poster_url} autoPlay={media.autoplay !== false} loop={media.loop !== false} muted playsInline className="h-full w-full object-cover"/> : image && <img src={image} alt="" className="h-full w-full object-cover"/>}<div className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-transparent to-transparent"/>{content.title && <div className="absolute bottom-4 left-4 right-4 text-gallery"><p className="text-xl font-light">{content.title}</p><p className="mt-1 text-xs text-gallery/80">{[content.date, content.time, content.city].filter(Boolean).join(" · ")}</p></div>}<span className="absolute right-3 top-3 bg-background px-2 py-1 font-mono text-[10px] uppercase tracking-widest">{passport.status}</span></div>
    <div className="p-5"><p className="font-mono text-[10px] uppercase tracking-widest text-cobalt">Passport</p><h2 className="mt-2 text-2xl font-light">{passport.name}</h2><p className="mt-1 text-sm text-muted-foreground">{passport.profession}</p>
      <Button className="mt-5 w-full" variant="outline" onClick={() => onConfigure(passport)} aria-label={`Configurer ${passport.name}`}><Settings2 className="h-4 w-4"/>Configurer</Button>
    </div>
  </article>;
}