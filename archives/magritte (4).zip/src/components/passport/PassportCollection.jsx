import React from "react";
import useFounderPassports from "@/lib/useFounderPassports";
import FounderPassportCarousel from "@/components/home/FounderPassportCarousel";

export default function PassportCollection() {
  const { data: passports = [], isLoading } = useFounderPassports();
  return <div><div className="mb-10 max-w-2xl"><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Collection</span><h2 className="mt-3 text-4xl font-light tracking-tight md:text-6xl">Les Passports</h2><p className="mt-4 text-muted-foreground">Chaque Passport ouvre une facette, une activité ou une identité dédiée.</p></div>{isLoading ? <div className="h-80 animate-pulse bg-muted"/> : <FounderPassportCarousel passports={passports}/>}</div>;
}