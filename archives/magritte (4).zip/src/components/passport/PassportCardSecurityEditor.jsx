import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import PassportActionRow from "./PassportActionRow";
import PassportCodeField from "./PassportCodeField";

export default function PassportCardSecurityEditor({ config: incomingConfig, profileAccess: incomingProfileAccess, onConfigChange, onProfileChange }) {
  const config = incomingConfig || {};
  const profileAccess = incomingProfileAccess || {};
  const actions = config.actions || [];
  const setConfig = (key, value) => onConfigChange({ ...config, [key]: value });
  const updateAction = (index, value) => setConfig("actions", actions.map((item, i) => i === index ? value : item));
  const addAction = () => setConfig("actions", [...actions, { key: crypto.randomUUID(), label: "Nouveau raccourci", target: "link", icon: "arrow", url: "", placement: "back", access: "protected" }]);
  return <div className="space-y-7">
    <div><h3 className="text-2xl font-light">Recto, verso et profondeurs d’accès</h3><p className="mt-2 text-sm text-muted-foreground">Placez chaque raccourci sur la face souhaitée, puis choisissez s’il est public ou protégé.</p></div>
    <div className="grid gap-4 md:grid-cols-2"><label className="space-y-2 text-sm"><span>Titre du verso</span><Input value={config.back_title || "Accès & services"} onChange={(e) => setConfig("back_title", e.target.value)}/></label><label className="space-y-2 text-sm"><span>Accès au verso</span><select aria-label="Accès au verso" value={config.back_access_mode || "private"} onChange={(e) => setConfig("back_access_mode", e.target.value)} className="h-9 w-full border bg-background px-3"><option value="public">Public</option><option value="private">Protégé par code</option></select></label></div>
    <label className="block space-y-2 text-sm"><span>Explication au verso</span><Textarea value={config.back_text || "Utilisez votre code pour ouvrir les accès réservés."} onChange={(e) => setConfig("back_text", e.target.value)}/></label>
    {(config.back_access_mode || "private") === "private" && <PassportCodeField label="Code du verso" value={config.back_access_code || ""} onChange={(value) => setConfig("back_access_code", value)}/>} 
    <div className="space-y-3"><div className="flex items-center justify-between gap-4"><h4 className="text-lg font-light">Boutons de la carte</h4><Button type="button" variant="outline" onClick={addAction}>Ajouter un bouton</Button></div>{actions.map((action, index) => <PassportActionRow key={action.key} action={action} onChange={(value) => updateAction(index, value)} onRemove={() => setConfig("actions", actions.filter((_, i) => i !== index))}/>)}</div>
    <div className="border-t pt-6"><h4 className="text-lg font-light">Sécurité supplémentaire du profil</h4><p className="mt-1 text-sm text-muted-foreground">Ce verrou intervient après la carte et protège la page détaillée.</p><select aria-label="Sécurité du profil" value={profileAccess.mode || "inherit"} onChange={(e) => onProfileChange({ ...profileAccess, mode: e.target.value })} className="mt-4 h-9 w-full border bg-background px-3"><option value="inherit">Hériter de l’accès principal</option><option value="public">Profil public</option><option value="private">Code supplémentaire</option></select>{profileAccess.mode === "private" && <div className="mt-4"><PassportCodeField label="Code du profil" value={profileAccess.code || ""} onChange={(code) => onProfileChange({ ...profileAccess, code })}/></div>}</div>
  </div>;
}