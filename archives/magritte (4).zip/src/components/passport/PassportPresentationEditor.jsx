import React from "react";
import { Input } from "@/components/ui/input";

export default function PassportPresentationEditor({ form, setField }) {
  const content = form.card_content || {}, setContent = (key, value) => setField("card_content", { ...content, [key]: value });
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Informations enrichies de la carte</h2><p className="mt-2 text-sm text-muted-foreground">Ajoutez seulement les précisions utiles à ce Passport.</p></div><div className="grid gap-5 md:grid-cols-2">{[["date", "Date", "date"], ["time", "Horaire", "time"], ["city", "Ville"], ["venue", "Lieu"]].map(([key, label, type]) => <label key={key} className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{label}<Input aria-label={label} type={type || "text"} value={content[key] || ""} onChange={(e) => setContent(key, e.target.value)} className="mt-2"/></label>)}</div></section>;
}