import React from "react";
import PassportCard from "./PassportCard";
import buildPassportCard from "@/lib/buildPassportCard";
import PassportProfilePreview from "./PassportProfilePreview";
import PassportCompletionNotice from "./PassportCompletionNotice";

export default function PassportEditorPreview({ passport }) {
  const cardMissing = [!passport.name && "nom", !passport.profession && "rôle", !passport.card_media?.url && "visuel"].filter(Boolean);
  return <aside className="xl:sticky xl:top-24"><p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-cobalt">Deux vues · une seule identité synchronisée</p><div className="grid items-start gap-4 sm:grid-cols-2"><div className="space-y-3"><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Carte Passport</p><PassportCompletionNotice label="Carte" missing={cardMissing}/><PassportCard card={buildPassportCard(passport, { preview: true })}/></div><div className="space-y-3"><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Page profil</p><PassportProfilePreview passport={passport}/></div></div></aside>;
}