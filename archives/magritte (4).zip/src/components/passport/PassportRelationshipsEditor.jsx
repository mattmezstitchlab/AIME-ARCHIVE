import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";

export default function PassportRelationshipsEditor({ passportId, passports }) {
  const queryClient = useQueryClient(), [target, setTarget] = useState(""), [role, setRole] = useState("");
  const { data: relations = [] } = useQuery({ queryKey: ["passport-relations", passportId], queryFn: () => base44.entities.PassportRelationship.filter({ source_passport_id: passportId }, "created_date"), enabled: Boolean(passportId) });
  const options = passports.filter((item) => item.id !== passportId), nameOf = (id) => passports.find((item) => item.id === id)?.name || "Passport lié";
  const add = async () => { if (!target) return; await base44.entities.PassportRelationship.create({ source_passport_id: passportId, target_passport_id: target, relation_type: "linked_to", role_title: role, visibility: "public" }); setTarget(""); setRole(""); queryClient.invalidateQueries({ queryKey: ["passport-relations", passportId] }); };
  const remove = async (id) => { await base44.entities.PassportRelationship.delete(id); queryClient.invalidateQueries({ queryKey: ["passport-relations", passportId] }); };
  return <section className="space-y-5"><div><h2 className="text-2xl font-light">Relations entre Passports</h2><p className="mt-2 text-sm text-muted-foreground">Exemple : une personne est présidente d’une association, sans transformer ce rôle en catégorie.</p></div><div className="grid gap-3 md:grid-cols-[1fr_1fr_auto]"><select aria-label="Passport lié" value={target} onChange={(e) => setTarget(e.target.value)} className="h-9 border bg-background px-3"><option value="">Choisir un Passport</option>{options.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select><Input aria-label="Rôle dans la relation" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Président, organisateur…"/><Button type="button" onClick={add} disabled={!target}>Ajouter</Button></div><div className="space-y-2">{relations.map((relation) => <div key={relation.id} className="flex items-center justify-between border p-3 text-sm"><span>{relation.role_title || "Lié à"} · {nameOf(relation.target_passport_id)}</span><Button type="button" size="icon" variant="ghost" onClick={() => remove(relation.id)} aria-label="Supprimer la relation"><Trash2 className="h-4 w-4"/></Button></div>)}</div></section>;
}