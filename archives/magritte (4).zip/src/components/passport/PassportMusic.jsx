import React from "react";
import { Music2 } from "lucide-react";
import { spotifyEmbedUrl } from "@/lib/spotify";

export default function PassportMusic({ tracks = [] }) {
  if (!tracks.length) return null;
  return <section className="border-t border-border py-10"><div className="mb-6 flex items-center gap-3"><Music2 className="h-5 w-5"/><h2 className="text-2xl font-light">Morceaux favoris</h2></div>
    <div className="space-y-4">{tracks.map((track, index) => {
      const embed = track.audio_url ? "" : spotifyEmbedUrl(track.spotify_url);
      return <div key={`${track.title}-${index}`} className="grid grid-cols-[56px_1fr] items-center gap-4 border-b border-border pb-4">
        <div className="h-14 w-14 overflow-hidden rounded-full bg-muted">{track.cover_url && <img src={track.cover_url} alt="" className="h-full w-full object-cover"/>}</div>
        <div className="min-w-0"><p className="truncate font-medium">{track.title}</p>{track.artist && <p className="text-sm text-muted-foreground">{track.artist}</p>}
          {track.audio_url && <audio controls preload="none" src={track.audio_url} className="mt-2 h-8 w-full"/>}
          {embed && <iframe src={embed} title={track.title || "Lecteur Spotify"} height="80" loading="lazy" allow="clipboard-write; encrypted-media; fullscreen; picture-in-picture" className="mt-2 block w-full border-0"/>}
        </div>
      </div>;
    })}</div>
  </section>;
}
