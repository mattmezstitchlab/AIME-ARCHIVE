import React, { useEffect, useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { spotifyEmbedUrl } from "@/lib/spotify";

export default function PassportMiniPlayer({ tracks = [] }) {
  const track = tracks[0], audioRef = useRef(null), [playing, setPlaying] = useState(false);
  useEffect(() => () => audioRef.current?.pause(), []);
  if (!track) return null;
  const embed = track.audio_url ? "" : spotifyEmbedUrl(track.spotify_url);
  if (embed) return <div className="mt-3 border border-border bg-muted/40 p-2" aria-label={`Mini-player ${track.title || "Spotify"}`}>
    <iframe src={embed} title={track.title || "Lecteur Spotify"} height="80" loading="lazy" allow="clipboard-write; encrypted-media; fullscreen; picture-in-picture" className="block w-full border-0"/>
  </div>;
  if (!track.audio_url) return null;
  const toggle = async () => { const audio = audioRef.current; if (audio.paused) { await audio.play(); setPlaying(true); } else { audio.pause(); setPlaying(false); } };
  return <div className="mt-3 flex items-center gap-3 border border-border bg-muted/40 p-3" aria-label={`Mini-player ${track.title}`}>
    <button type="button" onClick={toggle} className="flex h-9 w-9 shrink-0 items-center justify-center bg-foreground text-background" aria-label={playing ? "Mettre en pause" : "Lire le morceau"}>{playing ? <Pause className="h-4 w-4"/> : <Play className="h-4 w-4"/>}</button>
    <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{track.title}</p><p className="truncate text-xs text-muted-foreground">{track.artist || "Morceau du Passport"}</p></div>
    <span className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Player</span>
    <audio ref={audioRef} src={track.audio_url} preload="none" onEnded={() => setPlaying(false)}/>
  </div>;
}
