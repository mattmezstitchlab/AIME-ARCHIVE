import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import PassportIdentityForm from "./PassportIdentityForm";
import PassportAccessEditor from "./PassportAccessEditor";
import PassportTracksEditor from "./PassportTracksEditor";
import PassportMenuEditor from "./PassportMenuEditor";
import PassportEditorBlock from "./PassportEditorBlock";
import PassportEditorPreview from "./PassportEditorPreview";
import PassportTemplateSelector from "./PassportTemplateSelector";
import PassportCardSecurityEditor from "./PassportCardSecurityEditor";
import PassportClassificationEditor from "./PassportClassificationEditor";
import PassportPresentationEditor from "./PassportPresentationEditor";
import PassportRelationshipsEditor from "./PassportRelationshipsEditor";
import PassportCardStarter from "./PassportCardStarter";

export default function PassportEditorForm({ editor }) {
  const [showMore, setShowMore] = useState(false);
  if (editor.isChoosingTemplate) return <section className="space-y-8 border-t pt-12"><EditorHeader title="Créer un Passport" onClose={editor.closeEditor}/><p className="max-w-2xl text-muted-foreground">Choisissez qui ou quoi ce Passport représente : une personne, un événement ou une organisation. La profession / le rôle reste un champ libre.</p><PassportTemplateSelector onSelect={editor.selectType}/></section>;
  const title = editor.editingId ? `Configurer ${editor.form.name || "ce Passport"}` : "Créer un Passport";
  const block = (key, fields, content) => <PassportEditorBlock key={key} onSave={() => editor.saveBlock(key, fields)} saving={editor.savingBlock === key} saved={editor.savedBlock === key} creating={!editor.editingId} testId={`save-passport-${key}`}>{content}</PassportEditorBlock>;
  return <section className="space-y-8 border-t pt-12"><EditorHeader title={title} onClose={editor.closeEditor}/>{editor.error && <p className="border border-destructive p-4 text-sm text-destructive">{editor.error}</p>}<div className="grid items-start gap-8 xl:grid-cols-[minmax(0,1fr)_minmax(540px,0.9fr)]"><div className="space-y-6">
    {block("starter", ["name", "profession", "card_media", "card_content"], <PassportCardStarter form={editor.form} setField={editor.setField}/>)}
    <Button type="button" variant="outline" onClick={() => setShowMore((value) => !value)} aria-expanded={showMore} className="h-12 w-full justify-between px-5"><span><strong>PLUS</strong> · toutes les possibilités</span>{showMore ? <ChevronUp className="h-4 w-4"/> : <ChevronDown className="h-4 w-4"/>}</Button>
    {showMore && <div className="space-y-10"><EditorGroup label="Carte Passport · options avancées">
      {block("access", ["access_code", "access_mode", "audiences", "status"], <PassportAccessEditor form={editor.form} setField={editor.setField} passports={editor.passports}/>)}
      {block("classification", ["subject_type", "taxonomy_slug", "taxonomy_path", "registry"], <PassportClassificationEditor form={editor.form} terms={editor.taxonomyTerms} setField={editor.setField}/>)}
      {block("presentation", ["card_content"], <PassportPresentationEditor form={editor.form} setField={editor.setField}/>)}
      {block("card", ["card_config", "profile_access"], <PassportCardSecurityEditor config={editor.form.card_config} profileAccess={editor.form.profile_access} onConfigChange={(value) => editor.setField("card_config", value)} onProfileChange={(value) => editor.setField("profile_access", value)}/>)}
    </EditorGroup><EditorGroup label="Page profil Passport">
      {block("identity", ["provider_slug", "name", "profession", "location", "avatar", "cover_image", "biography", "contact_email"], <PassportIdentityForm form={editor.form} setField={editor.setField}/>)}
      {block("menu", ["menu"], <PassportMenuEditor items={editor.form.menu} onChange={(value) => editor.setField("menu", value)}/>)}
      {block("tracks", ["tracks"], <PassportTracksEditor tracks={editor.form.tracks} onChange={(value) => editor.setField("tracks", value)}/>)}
    </EditorGroup>{editor.editingId && <PassportEditorBlock><PassportRelationshipsEditor passportId={editor.editingId} passports={editor.passports}/></PassportEditorBlock>}</div>}
  </div><PassportEditorPreview passport={editor.form}/></div></section>;
}

function EditorGroup({ label, children }) {
  return <section className="space-y-6"><div className="border-b pb-3"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">{label}</p></div>{children}</section>;
}

function EditorHeader({ title, onClose }) {
  return <div className="flex flex-wrap items-center justify-between gap-4"><div><span className="font-mono text-xs uppercase tracking-widest text-cobalt">Éditeur</span><h2 className="mt-2 text-3xl font-light md:text-5xl">{title}</h2></div><Button variant="ghost" onClick={onClose}><ArrowLeft className="h-4 w-4"/>Retour à la liste</Button></div>;
}