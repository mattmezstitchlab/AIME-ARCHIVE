import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, LockKeyhole } from "lucide-react";
import PassportCardAction from "./PassportCardAction";

export default function PassportCardBack({ card, actions, unlocked, code, error, loading, onCode, onUnlock, onAction }) {
  const protectedBack = !unlocked && (card.back?.access_mode === "private" || actions.some((action) => action.locked));
  return <div className="passport-card-face passport-card-back flex min-h-full flex-col border border-border bg-card p-6 shadow-sm">
    <p className="font-mono text-[10px] uppercase tracking-widest text-primary">Verso sécurisé</p><h2 className="mt-4 text-3xl font-light">{card.back?.title || "Accès & services"}</h2><p className="mt-3 text-sm leading-relaxed text-muted-foreground">{card.back?.text || "Ouvrez les accès réservés avec votre code."}</p>
    {protectedBack && <form onSubmit={(e) => { e.preventDefault(); onUnlock(); }} className="mt-8 border p-4"><label className="text-sm"><span className="flex items-center gap-2"><LockKeyhole className="h-4 w-4"/>Code du verso</span><Input aria-label="Saisir le code du verso" value={code} onChange={(e) => onCode(e.target.value.toUpperCase())} className="mt-3 font-mono uppercase"/></label>{error && <p className="mt-2 text-xs text-destructive">{error}</p>}<Button className="mt-3 w-full" disabled={loading}>{loading && <Loader2 className="h-4 w-4 animate-spin"/>}Déverrouiller</Button></form>}
    <div className="mt-auto flex flex-wrap gap-2 pt-8">{actions.map((action) => <PassportCardAction key={action.key || action.label} action={action} onAction={onAction}/>)}</div>
  </div>;
}