import React from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";

export default function PassportLogin({ accountMode = false }) {
  const { navigateToLogin } = useAuth();
  const eyebrow = accountMode ? "Espace personnel" : "Espace prestataire";
  const title = accountMode ? "Créer ou ouvrir mon compte" : "Gérez votre Passport";
  const copy = accountMode ? "Connectez-vous ou créez votre accès pour retrouver vos Passports et votre Canevas." : "Connectez-vous pour créer votre carte profil et contrôler son accès.";
  return <div className="flex min-h-screen items-center justify-center px-6"><div className="max-w-md text-center"><span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{eyebrow}</span><h1 className="mt-4 text-4xl font-light">{title}</h1><p className="mt-4 text-muted-foreground">{copy}</p><Button onClick={navigateToLogin} className="mt-8">Continuer</Button></div></div>;
}