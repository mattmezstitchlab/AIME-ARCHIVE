import React from "react";
import { MapPin } from "lucide-react";
import PassportMusic from "./PassportMusic";
import PassportMenu from "./PassportMenu";

export default function PassportProfile({ passport }) {
  const hero = passport.cover_image || passport.avatar;
  return <main className="min-h-screen bg-background">
    <section className="relative flex min-h-[85vh] items-end overflow-hidden bg-charcoal px-6 pb-16 pt-28 text-gallery md:px-8 md:pb-20">
      {hero && <img src={hero} alt={passport.name} className="absolute inset-0 h-full w-full object-cover"/>}<div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/60 to-transparent"/>
      <header className="relative z-10 mx-auto w-full max-w-7xl"><span className="font-mono text-xs uppercase tracking-widest text-gallery/60">Passport · {passport.taxonomy_path || passport.profession}</span><h1 className="mt-4 text-6xl font-light leading-none tracking-tighter md:text-8xl lg:text-9xl">{passport.name}</h1>
        <div className="mt-8 flex flex-wrap gap-x-8 gap-y-3 text-gallery/80"><p>{passport.profession}</p>{passport.location && <p className="flex items-center gap-2"><MapPin className="h-4 w-4"/>{passport.location}</p>}</div>
      </header>
    </section>
    <div className="mx-auto max-w-7xl px-6 py-20 md:px-8 md:py-28"><PassportMusic tracks={passport.tracks}/><PassportMenu items={passport.menu} biography={passport.biography} email={passport.contact_email}/></div>
  </main>;
}