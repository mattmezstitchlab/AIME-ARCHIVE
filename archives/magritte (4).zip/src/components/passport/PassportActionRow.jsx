import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";

export default function PassportActionRow({ action, onChange, onRemove }) {
  const set = (key, value) => onChange({ ...action, [key]: value });
  return <div className="grid gap-3 border p-4 md:grid-cols-2">
    <Input aria-label="Nom du raccourci" value={action.label} onChange={(e) => set("label", e.target.value)} placeholder="Nom du bouton"/>
    <select aria-label="Action du raccourci" value={action.target} onChange={(e) => set("target", e.target.value)} className="h-9 border bg-background px-3 text-sm"><option value="profile">Ouvrir le profil</option><option value="contact">Ouvrir Contact</option><option value="player">Ouvrir le player</option><option value="link">Ouvrir un lien</option></select>
    <select aria-label="Face du raccourci" value={action.placement} onChange={(e) => set("placement", e.target.value)} className="h-9 border bg-background px-3 text-sm"><option value="front">Recto</option><option value="back">Verso</option></select>
    <select aria-label="Confidentialité du raccourci" value={action.access} onChange={(e) => set("access", e.target.value)} className="h-9 border bg-background px-3 text-sm"><option value="public">Public</option><option value="protected">Protégé par le code du verso</option></select>
    {action.target === "link" && <Input aria-label="Adresse du raccourci" value={action.url || ""} onChange={(e) => set("url", e.target.value)} placeholder="https://…" className="md:col-span-2"/>}
    <Button type="button" variant="ghost" onClick={onRemove} className="justify-self-start text-destructive"><Trash2 className="h-4 w-4"/>Supprimer</Button>
  </div>;
}