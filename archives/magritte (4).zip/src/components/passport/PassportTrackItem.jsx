import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import MediaField from "@/components/admin/MediaField";
import { spotifyEmbedUrl } from "@/lib/spotify";

export default function PassportTrackItem({ track, onChange, onRemove }) {
  const embed = spotifyEmbedUrl(track.spotify_url);
  const spotifyInvalid = Boolean(track.spotify_url) && !embed;
  return <div className="space-y-4 border border-border p-4">
    <div className="flex justify-end"><Button type="button" variant="ghost" size="icon" onClick={onRemove} aria-label="Supprimer le morceau"><X className="h-4 w-4"/></Button></div>
    <div className="grid gap-4 md:grid-cols-2">
      <Input value={track.title || ""} onChange={(e) => onChange({ ...track, title: e.target.value })} placeholder="Titre"/>
      <Input value={track.artist || ""} onChange={(e) => onChange({ ...track, artist: e.target.value })} placeholder="Artiste"/>
    </div>
    <div className="grid gap-4 md:grid-cols-2">
      <MediaField label="Cover" value={track.cover_url || ""} onChange={(cover_url) => onChange({ ...track, cover_url })}/>
      <MediaField label="Fichier audio" accept="audio/*" value={track.audio_url || ""} onChange={(audio_url) => onChange({ ...track, audio_url })}/>
    </div>
    <label className="block font-mono text-xs uppercase tracking-widest text-muted-foreground">Lien Spotify
      <Input value={track.spotify_url || ""} onChange={(e) => onChange({ ...track, spotify_url: e.target.value })} placeholder="https://open.spotify.com/track/…" className="mt-2 font-mono text-xs"/>
    </label>
    {spotifyInvalid && <p className="text-xs text-destructive">Lien Spotify non reconnu. Copiez l’URL depuis Spotify (Partager · Copier le lien).</p>}
    {embed && <iframe src={embed} title={track.title || "Aperçu Spotify"} height="80" loading="lazy" allow="clipboard-write; encrypted-media; fullscreen; picture-in-picture" className="block w-full border-0"/>}
  </div>;
}
