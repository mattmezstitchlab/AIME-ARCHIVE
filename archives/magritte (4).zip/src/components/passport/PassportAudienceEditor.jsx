import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function PassportAudienceEditor({ audience, onChange, onRemove, passports, menu }) {
  const set = (key, value) => onChange({ ...audience, [key]: value });
  const toggle = (key, value) => set(key, (audience[key] || []).includes(value) ? audience[key].filter((item) => item !== value) : [...(audience[key] || []), value]);
  const csv = (value) => value.split(",").map((item) => item.trim()).filter(Boolean);
  return <article className="space-y-5 border p-5">
    <div className="grid gap-3 md:grid-cols-2"><Input value={audience.label || ""} onChange={(e) => set("label", e.target.value)} placeholder="Nom de l’audience, ex. Invités"/><Input value={audience.access_code || ""} onChange={(e) => set("access_code", e.target.value.toUpperCase())} placeholder="Code de cette audience" className="font-mono uppercase"/></div>
    <label className="block space-y-2 text-sm"><span>Emails invités — accès automatique à la connexion</span><Input value={(audience.allowed_emails || []).join(", ")} onChange={(e) => set("allowed_emails", csv(e.target.value))} placeholder="invite@exemple.fr, famille@exemple.fr"/></label>
    <ChoiceList title="Passports autorisés" items={passports} selected={audience.allowed_passport_ids || []} getValue={(item) => item.id} getLabel={(item) => item.name} onToggle={(value) => toggle("allowed_passport_ids", value)}/>
    <ChoiceList title="Rubriques visibles pour cette audience" items={menu} selected={audience.menu_keys || []} getValue={(item) => item.key} getLabel={(item) => item.label} onToggle={(value) => toggle("menu_keys", value)}/>
    <Button type="button" variant="outline" onClick={onRemove}>Supprimer cette audience</Button>
  </article>;
}

function ChoiceList({ title, items, selected, getValue, getLabel, onToggle }) {
  return <fieldset><legend className="mb-2 text-sm">{title}</legend><div className="grid gap-2 sm:grid-cols-2">{items.map((item) => { const value = getValue(item); return <label key={value} className="flex items-center gap-2 border p-3 text-sm"><input type="checkbox" checked={selected.includes(value)} onChange={() => onToggle(value)}/><span>{getLabel(item)}</span></label>; })}</div></fieldset>;
}