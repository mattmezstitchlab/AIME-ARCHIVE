import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { RotateCcw } from "lucide-react";
import { hydratePassportActions } from "@/lib/buildPassportCard";
import PassportCardFront from "./PassportCardFront";
import PassportCardBack from "./PassportCardBack";

export default function PassportCard({ card, className = "" }) {
  const [flipped, setFlipped] = useState(false), [playerOpen, setPlayerOpen] = useState(false), [unlocked, setUnlocked] = useState(false);
  const [code, setCode] = useState(""), [error, setError] = useState(""), [loading, setLoading] = useState(false), [unlockedActions, setUnlockedActions] = useState(null);
  const actions = unlockedActions || card.actions || [], front = actions.filter((action) => action.placement !== "back"), back = actions.filter((action) => action.placement === "back");
  const handleAction = (action) => { if (action.action === "player") setPlayerOpen((open) => !open); if (action.action === "unlock") setFlipped(true); };
  const unlock = async () => {
    setLoading(true); setError("");
    try {
      if (card.preview) { if (code !== String(card.unlockCode || "").toUpperCase()) throw new Error("Code incorrect."); setUnlockedActions(hydratePassportActions(card, card.actions, true)); }
      else { const response = await base44.functions.invoke("getPassportByCode", { card_access: true, provider_slug: card.providerSlug, code }); setUnlockedActions(hydratePassportActions(card, response.data.card_config.actions, true)); }
      setUnlocked(true);
    } catch (err) { setError(err.response?.data?.error || err.message || "Code incorrect."); }
    setLoading(false);
  };
  return <article data-passport-card={card.name} className={`passport-card-scene relative ${className}`}>
    <Button type="button" size="icon" variant="outline" onClick={() => setFlipped((value) => !value)} aria-label={flipped ? "Voir le recto" : "Voir le verso"} className="absolute left-3 top-3 z-20 rounded-full bg-background/90"><RotateCcw className="h-4 w-4"/></Button>
    <div className={`passport-card-inner ${flipped ? "is-flipped" : ""}`}><PassportCardFront card={card} actions={front} playerOpen={playerOpen} onAction={handleAction}/><PassportCardBack card={card} actions={back} unlocked={unlocked} code={code} error={error} loading={loading} onCode={setCode} onUnlock={unlock} onAction={handleAction}/></div>
  </article>;
}