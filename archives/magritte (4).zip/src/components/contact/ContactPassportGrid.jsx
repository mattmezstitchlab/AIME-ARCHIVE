import React from "react";
import PassportCard from "@/components/passport/PassportCard";
import useContactPassports from "@/lib/useContactPassports";
import buildPassportCard from "@/lib/buildPassportCard";

export default function ContactPassportGrid() {
  const { data: passports = [], isLoading } = useContactPassports();
  if (isLoading) return <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{[0, 1, 2].map((item) => <div key={item} className="aspect-[1/2] animate-pulse rounded-[14px] bg-muted"/>)}</div>;
  if (!passports.length) return <p className="border py-12 text-center text-sm text-muted-foreground">Les Passports à contacter seront bientôt présentés ici.</p>;
  return <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{passports.map((passport) => <PassportCard key={passport.id} card={buildPassportCard(passport)}/>)}</div>;
}