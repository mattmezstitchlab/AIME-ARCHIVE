import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import ContactPassportGrid from "@/components/contact/ContactPassportGrid";
import { useSiteTexts } from "@/lib/siteTexts";

export default function ContactSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  const { t } = useSiteTexts();
  const titleLines = t("contact.title").split("\n");

  return <section ref={ref} className="border-t px-6 py-20 md:px-8 md:py-28" aria-label="Contact et Passports">
    <motion.div initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.6 }} className="mx-auto max-w-7xl">
      <h2 className="max-w-4xl font-body text-4xl font-light leading-tight tracking-tight md:text-6xl lg:text-7xl">{titleLines[0]}{titleLines[1] && <><br/><span className="text-muted-foreground">{titleLines[1]}</span></>}</h2>
      <p className="mb-14 mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground">{t("contact.intro")}</p>
      <ContactPassportGrid/>
    </motion.div>
  </section>;
}