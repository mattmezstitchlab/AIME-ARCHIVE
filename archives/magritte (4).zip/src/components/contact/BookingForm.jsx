import React, { useState } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

export const EVENT_TYPES = ["Mariage", "Anniversaire", "Soirée privée", "Événement d'entreprise", "Concert / Bar", "Festival", "Cocktail / Vernissage", "Autre"];

const inputClass = "bg-transparent border-0 border-b border-border rounded-none font-body text-base h-12 focus:ring-0 focus:border-b-2 focus:border-cobalt";

export default function BookingForm() {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", phone: "", event_type: "", event_date: "", location: "", guests: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const set = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.event_type) {
      toast({ title: "Merci de renseigner votre nom, votre email et le type d'événement.", variant: "destructive" });
      return;
    }
    setSending(true);
    try {
      await base44.entities.BookingRequest.create({ ...form, status: "nouveau" });
      setSubmitted(true);
    } catch {
      toast({ title: "Une erreur est survenue. Merci de réessayer.", variant: "destructive" });
    }
    setSending(false);
  };

  if (submitted) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="py-16 text-center">
        <h3 className="font-body text-2xl md:text-3xl font-light text-foreground mb-4">Merci pour votre demande !</h3>
        <p className="font-body text-base text-muted-foreground">Je vérifie ma disponibilité et je vous réponds sous 48 h.</p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Nom *</label>
          <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Votre nom complet" className={inputClass} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Email *</label>
          <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="vous@exemple.fr" className={inputClass} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Téléphone</label>
          <Input type="tel" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="06 12 34 56 78" className={inputClass} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Type d'événement *</label>
          <Select value={form.event_type} onValueChange={(v) => set("event_type", v)}>
            <SelectTrigger className={inputClass}>
              <SelectValue placeholder="Choisir un type" />
            </SelectTrigger>
            <SelectContent>
              {EVENT_TYPES.map((type) => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Date souhaitée</label>
          <Input type="date" value={form.event_date} onChange={(e) => set("event_date", e.target.value)} className={inputClass} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Lieu</label>
          <Input value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="Ville, salle, adresse…" className={inputClass} />
        </div>
        <div>
          <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Nombre d'invités</label>
          <Input value={form.guests} onChange={(e) => set("guests", e.target.value)} placeholder="ex : 80" className={inputClass} />
        </div>
      </div>

      <div>
        <label className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-2">Votre message</label>
        <Textarea value={form.message} onChange={(e) => set("message", e.target.value)} placeholder="Décrivez votre événement, l'ambiance recherchée, vos envies musicales…" className="bg-transparent border-0 border-b border-border rounded-none font-body text-base min-h-[160px] focus:ring-0 focus:border-b-2 focus:border-cobalt" />
      </div>

      <button
        type="submit"
        disabled={sending}
        className="inline-flex items-center justify-center px-10 py-4 bg-charcoal text-gallery font-mono text-xs tracking-widest uppercase hover:bg-cobalt transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-cobalt focus:ring-offset-4 disabled:opacity-60"
      >
        {sending ? "Envoi en cours…" : "Demander ma disponibilité"}
      </button>
    </form>
  );
}