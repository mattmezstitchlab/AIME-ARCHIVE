import React from "react";
import ProjectCard from "@/components/home/ProjectCard";
import HomeProjectFull from "@/components/home/HomeProjectFull";
import HomeProjectEditorial from "@/components/home/HomeProjectEditorial";

export default function HomeProjectSection({ project, index }) {
  const layout = project.homepage?.layout || "split";
  if (layout === "full") return <HomeProjectFull project={project} />;
  if (layout === "editorial") return <HomeProjectEditorial project={project} />;
  return <ProjectCard project={project} index={index} />;
}