import React from "react";
import useSiteSettings from "@/lib/useSiteSettings";
import { mergeWeddingModules } from "@/lib/weddingModuleSettings";
import WeddingHomeShowcase from "./WeddingHomeShowcase";

export default function ProjectGallery() {
  const { settings } = useSiteSettings();
  const modules = mergeWeddingModules(settings).filter((module) => module.visible !== false);
  return <WeddingHomeShowcase modules={modules}/>;
}