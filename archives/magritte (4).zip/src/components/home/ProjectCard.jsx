import React, { useRef } from "react";
import { Link } from "react-router-dom";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useTheme } from "next-themes";
import UniversalMedia from "@/components/media/UniversalMedia";

export default function ProjectCard({ project, index, href }) {
  const ref = useRef(null);
  const imageRef = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const isEven = index % 2 === 0;
  const { resolvedTheme } = useTheme();
  const overlay = resolvedTheme === "dark" ? project.homepage?.overlay_dark ?? 60 : project.homepage?.overlay_light ?? 35;

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const imageOpacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, ease: [0.65, 0, 0.35, 1], delay: 0.1 }}
      className="px-6 md:px-8"
    >
      <Link
        to={href || `/project/${project.slug}`}
        className={`group grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-8 items-start focus:outline-none`}
      >
        {/* Image — Sticky Scroll */}
        <motion.div
          ref={imageRef}
          style={{
            y: imageY,
            opacity: imageOpacity,
          }}
          className={`${
            isEven ? "md:col-start-1 md:col-span-7" : "md:col-start-5 md:col-span-8"
          } overflow-hidden relative md:sticky md:top-24`}
        >
          <div className="image-hover-zone group/img relative overflow-hidden aspect-[4/5]">
            <UniversalMedia
              media={project.hero_media}
              fallbackUrl={project.heroImage}
              alt={`${project.title} — ${project.subtitle}`}
              className="w-full h-full object-cover transition-transform duration-700 ease-out"
            />
            <div className="pointer-events-none absolute inset-0 bg-charcoal" style={{ opacity: overlay / 100 }}/>
            <div className="absolute inset-0 opacity-0 group-hover/img:opacity-100 transition-opacity duration-500 image-overlay" style={{ background: 'linear-gradient(to top, rgba(18,18,18,0.85) 0%, rgba(18,18,18,0.3) 50%, rgba(18,18,18,0) 100%)' }} />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity duration-500 image-id-label">
              <span className="font-body text-8xl md:text-9xl font-light text-white tracking-tighter select-none">
                {project.number}
              </span>
            </div>
          </div>
        </motion.div>

        {/* Info */}
        <div
          className={`${
            isEven ? "md:col-start-9 md:col-span-4" : "md:col-start-1 md:col-span-4 md:row-start-1"
          } flex flex-col justify-end py-4`}
        >
          <span className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-2">
            {project.number}/{String(6).padStart(2, "0")} — {project.year || "Inclus"}
          </span>
          <h3 className="font-body text-3xl md:text-4xl font-light tracking-tight text-foreground group-hover:text-cobalt transition-colors duration-300 mb-2">
            {project.homepage?.title || project.title}
          </h3>
          <p className="font-body text-sm text-muted-foreground mb-3">
            {project.homepage?.intro || project.subtitle}
          </p>
          <span className="font-mono text-xs tracking-widest text-muted-foreground uppercase">
            {project.homepage?.label || project.category}
          </span>
        </div>
      </Link>
    </motion.div>
  );
}