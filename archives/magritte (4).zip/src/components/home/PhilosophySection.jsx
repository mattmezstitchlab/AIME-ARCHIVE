import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useSiteTexts } from "@/lib/siteTexts";

function AnimatedParagraph({ text }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });

  return (
    <motion.p
      ref={ref}
      initial={{ opacity: 0, x: -16 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{
        duration: 0.8,
        ease: [0.65, 0, 0.35, 1],
      }}
    >
      {text}
    </motion.p>
  );
}

export default function PhilosophySection() {
  const { t } = useSiteTexts();

  return (
    <section className="py-24 md:py-40 px-6 md:px-8" aria-label="Design Philosophy">
      <div>
        <span className="font-mono text-xs tracking-widest uppercase text-muted-foreground block mb-8 md:mb-12">
          {t("home.philosophy_label")}
        </span>

        <div className="mb-16">
          <div className="font-body text-2xl md:text-4xl lg:text-5xl font-light tracking-tight text-foreground leading-loose max-w-4xl">
            <AnimatedParagraph text={t("home.philosophy_text")} />
          </div>
        </div>

      </div>
    </section>
  );
}