import React from "react";
import useFounderPassports from "@/lib/useFounderPassports";
import FounderPassportCarousel from "./FounderPassportCarousel";
import { useSiteTexts } from "@/lib/siteTexts";

export default function FounderPassportsSection() {
  const { data: passports = [], isLoading } = useFounderPassports();
  const { t } = useSiteTexts();
  return <section className="overflow-hidden border-y py-24 md:py-32" aria-labelledby="founder-passports-title"><header className="px-6 md:px-8"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">{t("home.passports_label")}</p><h2 id="founder-passports-title" className="mt-4 max-w-4xl text-4xl font-light tracking-tight md:text-6xl">{t("home.passports_title")}</h2><p className="mt-6 max-w-2xl text-sm leading-relaxed text-muted-foreground">{t("home.passports_text")}</p></header>{isLoading ? <div className="mt-14 h-96 animate-pulse bg-muted"/> : <FounderPassportCarousel passports={passports}/>}</section>;
}