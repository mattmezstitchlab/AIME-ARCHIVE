import React from "react";
import UniversalMedia from "@/components/media/UniversalMedia";

export default function FullMediaHero({ hero }) {
  return (
    <section className="relative overflow-hidden bg-charcoal text-primary-foreground" style={{ height: `${hero.height_vh ?? 100}vh` }}>
      <UniversalMedia media={hero.media} alt={hero.title || "Visuel d’accueil"} className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-charcoal" style={{ opacity: (hero.overlay_opacity ?? 40) / 100 }} />
      <div className="absolute inset-x-6 bottom-16 z-10 md:inset-x-8 md:bottom-20">
        <h1 className="max-w-5xl text-6xl font-light tracking-tighter md:text-8xl">{hero.title}</h1>
        {hero.subtitle && <p className="mt-5 max-w-2xl text-lg text-primary-foreground/80">{hero.subtitle}</p>}
      </div>
    </section>
  );
}