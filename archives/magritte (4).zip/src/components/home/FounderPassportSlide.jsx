import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, Mail } from "lucide-react";

const roleLabel = (passport) => {
  const path = (passport.taxonomy_path || "").split("/").map((part) => part.trim()).filter(Boolean);
  const values = [path[1] || path[0], path.at(-1) || passport.profession].filter(Boolean);
  return values.filter((value, index) => values.findIndex((item) => item.toLowerCase() === value.toLowerCase()) === index).join(" · ");
};

export default function FounderPassportSlide({ passport }) {
  const href = `/passport?provider=${encodeURIComponent(passport.provider_slug)}&showcase=1`;
  const image = passport.card_media?.url || passport.cover_image || passport.avatar;
  return <article className="w-[310px] shrink-0 snap-start border border-border bg-card md:w-[360px]"><Link to={href} className="block aspect-[4/3] overflow-hidden bg-muted">{image && <img src={image} alt={passport.name} className="h-full w-full object-cover transition-transform duration-500 hover:scale-[1.02]"/>}</Link><div className="p-5"><p className="font-mono text-[10px] uppercase tracking-widest text-cobalt">{roleLabel(passport)}</p><h3 className="mt-3 text-2xl font-light tracking-tight">{passport.name}</h3>{passport.location && <p className="mt-2 text-xs text-muted-foreground">{passport.location}</p>}<div className="mt-6 grid grid-cols-2 gap-2"><Link to={`${href}#contact`} className="flex items-center justify-center gap-2 border px-3 py-3 text-xs"><Mail className="h-4 w-4"/>Contact</Link><Link to={href} className="flex items-center justify-center gap-2 border px-3 py-3 text-xs">Profil<ArrowUpRight className="h-4 w-4"/></Link></div></div></article>;
}