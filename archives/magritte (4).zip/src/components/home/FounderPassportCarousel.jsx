import React, { useEffect, useRef } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import FounderPassportSlide from "./FounderPassportSlide";

export default function FounderPassportCarousel({ passports }) {
  const trackRef = useRef(null), pausedRef = useRef(false);
  useEffect(() => { let frame, last = 0; const tick = (time) => { const track = trackRef.current; if (track && !pausedRef.current && time - last > 45) { track.scrollLeft += 1; if (track.scrollLeft >= track.scrollWidth - track.clientWidth - 2) track.scrollLeft = 0; last = time; } frame = requestAnimationFrame(tick); }; frame = requestAnimationFrame(tick); return () => cancelAnimationFrame(frame); }, []);
  const move = (direction) => { const track = trackRef.current; if (!track) return; pausedRef.current = true; track.scrollBy({ left: direction * Math.min(380, track.clientWidth * 0.85), behavior: "smooth" }); window.setTimeout(() => { pausedRef.current = false; }, 1800); };
  return <div className="mt-14"><div className="mb-5 flex justify-end gap-2 px-6 md:px-8"><Button type="button" variant="outline" size="icon" onClick={() => move(-1)} aria-label="Passports précédents"><ArrowLeft/></Button><Button type="button" variant="outline" size="icon" onClick={() => move(1)} aria-label="Passports suivants"><ArrowRight/></Button></div><div ref={trackRef} data-founder-passport-track className="flex snap-x snap-mandatory gap-5 overflow-x-auto px-6 pb-4 md:px-8" onPointerDown={() => { pausedRef.current = true; }} onPointerUp={() => { pausedRef.current = false; }} onMouseEnter={() => { pausedRef.current = true; }} onMouseLeave={() => { pausedRef.current = false; }}>{passports.map((passport) => <FounderPassportSlide key={passport.provider_slug} passport={passport}/>)}</div></div>;
}