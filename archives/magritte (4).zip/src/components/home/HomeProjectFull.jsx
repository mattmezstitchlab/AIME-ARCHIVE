import React from "react";
import { Link } from "react-router-dom";
import UniversalMedia from "@/components/media/UniversalMedia";

export default function HomeProjectFull({ project }) {
  const content = project.homepage || {};
  return (
    <Link to={`/project/${project.slug}`} className="group relative block min-h-[72vh] overflow-hidden bg-charcoal">
      <UniversalMedia media={project.hero_media} fallbackUrl={project.heroImage} alt={project.title} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.02]" />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/20 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 px-6 py-10 md:px-8 md:py-16 text-gallery">
        <span className="font-mono text-xs uppercase tracking-widest text-gallery/70">{content.label || project.category}</span>
        <h3 className="mt-3 max-w-5xl text-5xl font-light tracking-tight md:text-8xl">{content.title || project.title}</h3>
        <p className="mt-5 max-w-xl text-sm text-gallery/80 md:text-base">{content.intro || project.subtitle}</p>
      </div>
    </Link>
  );
}