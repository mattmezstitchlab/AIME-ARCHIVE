import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, LockKeyhole, Network, Play } from "lucide-react";
import { useSiteTexts } from "@/lib/siteTexts";

const pillars = [
  { icon: Network, title: "Une identité structurée", text: "Personne, organisation, événement ou projet : chaque Passport trouve sa place dans une taxonomie lisible." },
  { icon: Play, title: "Photo ou vidéo", text: "Le recto devient une affiche vivante avec titre, date, horaire, ville et lieu." },
  { icon: LockKeyhole, title: "Des profondeurs choisies", text: "Recto public, verso protégé, profil privé et audiences dédiées grâce aux codes d’accès." }
];

export default function PassportInnovationSection() {
  const { t } = useSiteTexts();
  return <section className="border-y px-6 py-24 md:px-8 md:py-32" aria-labelledby="passport-innovation"><div className="mx-auto max-w-7xl"><span className="font-mono text-xs uppercase tracking-widest text-primary">{t("home.passport_label")}</span><div className="mt-5 grid gap-10 lg:grid-cols-[1.1fr_0.9fr]"><div><h2 id="passport-innovation" className="max-w-3xl text-4xl font-light tracking-tight md:text-6xl">{t("home.passport_title")}</h2><div className="mt-8 flex flex-wrap gap-5"><Link to="/mon-passport" className="inline-flex items-center gap-2 border-b pb-1 font-mono text-xs uppercase tracking-widest">{t("home.passport_cta1")} <ArrowUpRight className="h-4 w-4"/></Link><Link to="/prestataires" className="inline-flex items-center gap-2 border-b pb-1 font-mono text-xs uppercase tracking-widest">{t("home.passport_cta2")} <ArrowUpRight className="h-4 w-4"/></Link></div></div><div className="divide-y border-y">{pillars.map(({ icon: Icon, title, text }) => <article key={title} className="grid grid-cols-[auto_1fr] gap-4 py-6"><Icon className="mt-1 h-5 w-5 text-primary"/><div><h3 className="text-xl font-light">{title}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p></div></article>)}</div></div></div></section>;
}