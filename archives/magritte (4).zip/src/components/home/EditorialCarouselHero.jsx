import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import UniversalMedia from "@/components/media/UniversalMedia";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function EditorialCarouselHero({ hero, slides = [] }) {
  const [active, setActive] = useState(0);
  const { data: projects = [] } = useQuery({ queryKey: ["projects"], queryFn: () => base44.entities.Project.list("number", 100) });
  useEffect(() => { if (slides.length > 1) { const timer = setInterval(() => setActive((i) => (i + 1) % slides.length), 6000); return () => clearInterval(timer); } }, [slides.length]);
  if (!slides.length) return null;
  const slide = slides[active];
  const project = slide.source === "project" ? projects.find((item) => item.id === slide.project_id) : null;
  const media = project?.hero_media || slide.media;
  const fallback = project?.heroImage;
  const title = slide.source === "media" ? "" : slide.title || project?.title;
  const subtitle = slide.source === "media" ? "" : slide.subtitle || project?.subtitle;
  const link = slide.link || (project ? `/project/${project.slug}` : "");
  return <section className="relative overflow-hidden bg-charcoal text-primary-foreground" style={{ height: `${hero?.height_vh ?? 100}vh` }}>
    <UniversalMedia media={media} fallbackUrl={fallback} alt={title || "Slide éditoriale"} className="absolute inset-0 h-full w-full object-cover" />
    <div className="absolute inset-0 bg-charcoal" style={{ opacity: (hero?.overlay_opacity ?? 40) / 100 }} />
    {(title || subtitle) && <div className="absolute inset-x-6 bottom-20 z-10 md:inset-x-8 md:bottom-24"><h1 className="max-w-5xl text-6xl font-light tracking-tighter md:text-8xl">{title}</h1>{subtitle && <p className="mt-5 max-w-2xl text-lg text-primary-foreground/80">{subtitle}</p>}{link && <Link to={link} className="mt-8 inline-block font-mono text-xs uppercase tracking-widest">{slide.link_label || "Découvrir"} →</Link>}</div>}
    {slides.length > 1 && <div className="absolute bottom-6 right-6 z-20 flex gap-2 md:right-8"><button onClick={() => setActive((active - 1 + slides.length) % slides.length)} aria-label="Slide précédente" className="border border-primary-foreground/40 p-3"><ArrowLeft className="h-4 w-4"/></button><button onClick={() => setActive((active + 1) % slides.length)} aria-label="Slide suivante" className="border border-primary-foreground/40 p-3"><ArrowRight className="h-4 w-4"/></button></div>}
  </section>;
}