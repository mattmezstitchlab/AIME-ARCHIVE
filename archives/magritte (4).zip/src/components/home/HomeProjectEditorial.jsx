import React from "react";
import { Link } from "react-router-dom";
import UniversalMedia from "@/components/media/UniversalMedia";

const themes = {
  light: "bg-background text-foreground",
  dark: "bg-charcoal text-gallery",
  color: "bg-cobalt text-gallery",
};

export default function HomeProjectEditorial({ project }) {
  const content = project.homepage || {};
  const theme = themes[content.theme] || themes.light;
  return (
    <Link to={`/project/${project.slug}`} className={`group block ${theme}`}>
      <div className="h-[62vh] min-h-[420px] overflow-hidden">
        <UniversalMedia media={project.hero_media} fallbackUrl={project.heroImage} alt={project.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.02]" />
      </div>
      <div className="grid gap-6 px-6 py-12 md:grid-cols-12 md:px-8 md:py-20">
        <span className="font-mono text-xs uppercase tracking-widest opacity-60 md:col-span-3">{content.label || project.category}</span>
        <h3 className="text-4xl font-light tracking-tight md:col-span-6 md:text-6xl">{content.title || project.title}</h3>
        <p className="text-sm leading-relaxed opacity-70 md:col-span-3">{content.intro || project.subtitle}</p>
      </div>
    </Link>
  );
}