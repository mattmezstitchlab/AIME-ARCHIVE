import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { useSiteTexts } from "@/lib/siteTexts";

export default function FounderAboutSection() {
  const { t } = useSiteTexts();
  return <section className="border-t px-6 py-24 md:px-8 md:py-36" aria-labelledby="founder-about-title"><div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-12 md:items-end"><div className="md:col-span-7"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">{t("home.founder_label")}</p><h2 id="founder-about-title" className="mt-5 text-5xl font-light tracking-tight md:text-7xl">{t("home.founder_title")}</h2><p className="mt-8 max-w-2xl text-base leading-relaxed text-muted-foreground">{t("home.founder_text")}</p><Link to="/about" className="mt-10 inline-flex items-center gap-2 border-b pb-1 font-mono text-xs uppercase tracking-widest">{t("home.founder_cta")} <ArrowUpRight className="h-4 w-4"/></Link></div><div className="md:col-span-5">{t("home.founder_image") ? <img src={t("home.founder_image")} alt={t("home.founder_title") || "Portrait"} className="aspect-[4/5] w-full object-cover"/> : <div className="aspect-[4/5] w-full bg-muted"/>}</div></div></section>;
}