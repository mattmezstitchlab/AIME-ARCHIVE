import React, { useRef, useState, useEffect } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";

import { useSiteTexts } from "@/lib/siteTexts";
import useSiteSettings from "@/lib/useSiteSettings";
import FullMediaHero from "@/components/home/FullMediaHero";
import EditorialCarouselHero from "@/components/home/EditorialCarouselHero";

function TypewriterInfo({ isInView, texts }) {
  const INFO_TEXTS = texts;
  const [visibleTexts, setVisibleTexts] = useState([]);
  const [currentText, setCurrentText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [typing, setTyping] = useState(false);

  useEffect(() => {
    if (!isInView) return;
    const startDelay = setTimeout(() => setTyping(true), 600);
    return () => clearTimeout(startDelay);
  }, [isInView]);

  useEffect(() => {
    if (!typing || currentIndex >= INFO_TEXTS.length) return;
    const full = INFO_TEXTS[currentIndex];
    let i = 0;
    setCurrentText("");
    const timer = setInterval(() => {
      i++;
      setCurrentText(full.slice(0, i));
      if (i >= full.length) {
        clearInterval(timer);
        setTimeout(() => {
          setVisibleTexts(prev => [...prev, full]);
          setCurrentText("");
          setCurrentIndex(idx => idx + 1);
        }, 120);
      }
    }, 40);
    return () => clearInterval(timer);
  }, [typing, currentIndex]);

  return (
    <div className="contents">
      <div className="flex gap-6 leading-tight">
        {visibleTexts.slice(0, 2).map((t, i) => <span key={i}>{t}</span>)}
        {currentIndex === 2 && <span>{currentText}<span className="opacity-70">|</span></span>}
      </div>
      {visibleTexts.slice(2).map((t, i) => <div key={i + 2} className="-mt-1">{t}</div>)}
      {currentIndex > 2 && currentIndex < INFO_TEXTS.length && (
        <span>{currentText}<span className="opacity-70">|</span></span>
      )}
    </div>
  );
}
import { projects } from "@/lib/projectData";

// Pre-generate fixed hotspot positions spread across the full screen
const sizes = [
  { w: 145, h: 194 },  // small portrait
  { w: 218, h: 290 },  // medium portrait
  { w: 290, h: 363 },  // large portrait
  { w: 242, h: 169 },  // landscape
  { w: 182, h: 182 },  // square
  { w: 315, h: 218 },  // wide landscape
  { w: 121, h: 218 },  // narrow portrait
  { w: 266, h: 315 },  // tall
];

// Grid column lines at 1/12 intervals (in %)
const gridLines = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(i => (i / 12) * 100);

const generateHotspots = () => {
  const spots = [];
  const placements = [
    { col: 1,  y: 22 },
    { col: 2,  y: 68 },
    { col: 4,  y: 40 },
    { col: 5,  y: 75 },
    { col: 6,  y: 18 },
    { col: 7,  y: 55 },
    { col: 9,  y: 30 },
    { col: 10, y: 72 },
    { col: 11, y: 45 },
    { col: 3,  y: 55 },
  ];

  // 2 hotspots per project: cover image at index i, first gallery image at index i+5
  const imageAssignments = [
    ...projects.map(p => p.image),
    ...projects.map((p, i) => {
      // skip video files — use next image instead
      const img = p.images.find(src => !/\.mp4$|\.webm$|\.mov$/i.test(src));
      return img || p.image;
    }),
  ];

  // Override: 3rd hotspot from right (col 9 = placement idx 6) → The Blue Shift 3rd image
  imageAssignments[6] = "https://media.base44.com/images/public/6a0c41d815b4ff33c8825d04/e96f25aed_untitled_Gemini-3-_Nano-Banana-Pro__2026-02-25_10-10-57.png";

  // Override: 6th hotspot from left (col6 = placement idx 4) → Vexta 4th image
  imageAssignments[4] = "https://media.base44.com/images/public/6a0c41d815b4ff33c8825d04/5f3283972_Screenshot_2026-05-27_at_1428.png";
  sizes[4] = { w: Math.round(182 * 1.5), h: Math.round(182 * 1.5) }; // 50% larger

  // Override: 3rd hotspot from right (idx 6) — increase size by 200%
  sizes[6] = { w: Math.round(121 * 3), h: Math.round(218 * 3) };

  // idx 0 uses projects[0].image dynamically (no override needed)

  placements.forEach((p, i) => {
    spots.push({
      id: i,
      x: gridLines[p.col - 1],
      y: p.y,
      imageUrl: imageAssignments[i],
      size: sizes[i % sizes.length],
      contain: false,
    });
  });

  // Re-enable contain for idx 4 and 6 only
  spots[4].contain = true;
  spots[6].contain = true;

  return spots;
};

const hotspots = generateHotspots();

// Mobile: 6-column grid (5 grid lines at 1/6 intervals)
const mobileGridLines = [1,2,3,4,5].map(i => (i / 6) * 100);

const mobilePlacements = [
  { col: 1, y: 8 },
  { col: 5, y: 20 },
  { col: 2, y: 35 },
  { col: 5, y: 48 },
  { col: 3, y: 62 },
  { col: 4, y: 74 },
  { col: 2, y: 88 },
  { col: 4, y: 95 },
]

const generateMobileHotspots = () => {
  const imageAssignments = [
    ...projects.map(p => p.image),
    ...projects.map((p) => {
      const img = p.images.find(src => !/\.mp4$|\.webm$|\.mov$/i.test(src));
      return img || p.image;
    }),
  ];
  imageAssignments[6] = "https://media.base44.com/images/public/6a0c41d815b4ff33c8825d04/e96f25aed_untitled_Gemini-3-_Nano-Banana-Pro__2026-02-25_10-10-57.png";
  imageAssignments[4] = "https://media.base44.com/images/public/6a0c41d815b4ff33c8825d04/5f3283972_Screenshot_2026-05-27_at_1428.png";
  return mobilePlacements.map((p, i) => ({
    id: i,
    x: mobileGridLines[p.col - 1],
    y: p.y,
    imageUrl: imageAssignments[i],
    size: { w: Math.round(sizes[i % sizes.length].w * 0.6), h: Math.round(sizes[i % sizes.length].h * 0.6) },
    contain: i === 4 || i === 6,
  }));
};

const mobileHotspots = generateMobileHotspots();

const AI_HERO_DEFAULTS = {
  background: "#FF00A8",
  headline: "",
  placeholders: ["Générer mon jour J de A à Z…", "Trouver un photographe dispo en juillet…", "Analyser ce devis traiteur (via le +)…"],
  suggestions: ["Organiser un mariage champêtre chic pour 120 personnes", "Je cherche un fleuriste dans le Nord", "Que me reste-t-il à faire pour le Jour J ?"],
  allow_upload: true,
};

const AI_VENDOR_WORDS = { photographe: "Photographe", "vidéaste": "Vidéaste", videaste: "Vidéaste", traiteur: "Traiteur", fleuriste: "Fleuriste", dj: "DJ", musicien: "Musicien", lieu: "Lieu", salle: "Lieu", "décorateur": "Décoration", coiffeur: "Coiffure", "maquilleur": "Maquillage", "pâtissier": "Pâtisserie" };

function resolveAiIntent(text) {
  const query = (text || "").toLowerCase();
  const found = Object.keys(AI_VENDOR_WORDS).find((word) => query.includes(word));
  if (found) return { key: "find_provider", label: "Recherche dans l’annuaire", to: "/prestataires?q=" + encodeURIComponent(AI_VENDOR_WORDS[found]) };
  if (/finalis|reste|jour j|dernier/.test(query)) return { key: "finalize", label: "Finalisation du Jour J", to: "/mon-mariage" };
  if (/organis|planifi|mariage|budget|invit|checklist/.test(query)) return { key: "generate_space", label: "Création de votre espace", to: "/mariage/modules" };
  return { key: "explore", label: "Exploration des modules", to: "/mariage/modules" };
}

function AiPromptHero({ hero }) {
  const navigate = useNavigate();
  const config = { ...AI_HERO_DEFAULTS, ...(hero?.ai || {}) };
  const placeholders = (config.placeholders || []).filter(Boolean);
  const [index, setIndex] = useState(0);
  const [text, setText] = useState("");
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [opening, setOpening] = useState(false);
  const [intent, setIntent] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => {
    if (text || placeholders.length < 2) return;
    const timer = setInterval(() => setIndex((current) => (current + 1) % placeholders.length), 3500);
    return () => clearInterval(timer);
  }, [text, placeholders.length]);

  const pickFile = async (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFiles((current) => [...current, { name: file.name, url: file_url }]);
    } finally {
      setUploading(false);
      event.target.value = "";
    }
  };

  const submit = () => {
    const value = text.trim();
    if (!value && !files.length) return;
    const next = resolveAiIntent(value);
    setIntent(next);
    setOpening(true);
    try {
      sessionStorage.setItem("aime.pending_intent", JSON.stringify({ text: value, files, intent: next.key, at: Date.now() }));
    } catch (error) {
      setIntent(next);
    }
    setTimeout(() => navigate(next.to), 900);
  };

  const height = hero?.height_vh ? hero.height_vh + "vh" : "100vh";

  return (
    <section className="relative w-full overflow-hidden" style={{ height, backgroundColor: config.background }}>
      <motion.div className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.9 }} style={{ background: "radial-gradient(120% 90% at 50% 8%, rgba(255,255,255,0.38) 0%, rgba(255,255,255,0) 58%)" }} />
      <AnimatePresence>
        {opening && (
          <React.Fragment>
            <motion.div key="curtain-left" className="absolute inset-y-0 left-0 z-30 w-1/2" style={{ backgroundColor: config.background }} initial={{ x: 0 }} animate={{ x: "-100%" }} transition={{ duration: 0.75, ease: [0.76, 0, 0.24, 1] }} />
            <motion.div key="curtain-right" className="absolute inset-y-0 right-0 z-30 w-1/2" style={{ backgroundColor: config.background }} initial={{ x: 0 }} animate={{ x: "100%" }} transition={{ duration: 0.75, ease: [0.76, 0, 0.24, 1] }} />
          </React.Fragment>
        )}
      </AnimatePresence>
      <div className="relative z-20 flex h-full flex-col items-center justify-center px-6">
        {config.headline && <h1 className="mb-10 max-w-4xl text-center text-4xl font-light leading-tight text-white md:text-6xl">{config.headline}</h1>}
        <div className="w-full max-w-3xl rounded-3xl bg-white/95 p-2 shadow-2xl backdrop-blur">
          <div className="flex items-end gap-2">
            {config.allow_upload && <button type="button" onClick={() => fileRef.current && fileRef.current.click()} aria-label="Ajouter un document ou une inspiration" className="mb-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-2xl leading-none text-neutral-500 transition hover:bg-neutral-100 hover:text-neutral-900">+</button>}
            <input ref={fileRef} type="file" accept="image/*,application/pdf,.csv,.xlsx" className="hidden" onChange={pickFile} />
            <textarea value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(); } }} rows={1} placeholder={placeholders[index] || ""} aria-label="Décrivez votre projet" className="max-h-40 w-full resize-none border-0 bg-transparent px-1 py-3 text-base text-neutral-900 outline-none placeholder:text-neutral-400" />
            <button type="button" onClick={submit} disabled={uploading || opening} aria-label="Envoyer la demande" className="mb-1 flex h-11 shrink-0 items-center rounded-full px-5 text-sm font-medium text-white transition disabled:opacity-40" style={{ backgroundColor: config.background }}>{uploading ? "Analyse…" : "Envoyer"}</button>
          </div>
          {files.length > 0 && <div className="flex flex-wrap gap-2 px-3 pb-2">{files.map((item, position) => <span key={item.url + position} className="flex items-center gap-2 rounded-full bg-neutral-100 px-3 py-1 text-xs text-neutral-700">{item.name}<button type="button" onClick={() => setFiles((current) => current.filter((entry, spot) => spot !== position))} aria-label="Retirer le fichier">×</button></span>)}</div>}
        </div>
        {intent && <p className="mt-6 font-mono text-xs uppercase tracking-widest text-white">{intent.label}…</p>}
        {!intent && (config.suggestions || []).length > 0 && <div className="mt-8 flex flex-wrap justify-center gap-3">{config.suggestions.map((item) => <button key={item} type="button" onClick={() => setText(item)} className="rounded-full border border-white/60 px-4 py-2 text-sm text-white transition hover:bg-white/15">{item}</button>)}</div>}
      </div>
    </section>
  );
}

export default function HeroSection() {
  const { t } = useSiteTexts();
  const { settings } = useSiteSettings();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [isMobile, setIsMobile] = useState(() => window.innerWidth < 768);
  const [hoveredId, setHoveredId] = useState(null);
  const [autoId, setAutoId] = useState(null);
  const lastAutoIdRef = useRef(null);
  const activeHotspots = isMobile ? mobileHotspots : hotspots;

  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  useEffect(() => {
    let showTimer, hideTimer;

    const cycle = () => {
      if (hoveredId !== null) return;
      let randomId = activeHotspots[Math.floor(Math.random() * activeHotspots.length)].id;
      while (randomId === lastAutoIdRef.current) {
        randomId = activeHotspots[Math.floor(Math.random() * activeHotspots.length)].id;
      }
      lastAutoIdRef.current = randomId;
      setAutoId(randomId);
      hideTimer = setTimeout(() => {
        setAutoId(null);
        showTimer = setTimeout(cycle, 1200 + Math.random() * 1800);
      }, 1500 + Math.random() * 1000);
    };

    showTimer = setTimeout(cycle, 800);
    return () => { clearTimeout(showTimer); clearTimeout(hideTimer); };
  }, [hoveredId]);

  const hero = settings?.hero;
  if (hero?.mode === "ai_prompt") return <AiPromptHero hero={hero} />;
  if (hero?.mode === "full_image" || hero?.mode === "full_video") {
    return <FullMediaHero hero={{ ...hero, media: { ...hero.media, type: hero.mode === "full_video" ? "video" : "image" } }} />;
  }
  if (hero?.mode === "carousel" && hero.slides?.length) return <EditorialCarouselHero hero={hero} slides={hero.slides} />;

  return (
    <section
      ref={ref}
      className="relative h-screen overflow-hidden"
      aria-label="Introduction"
    >
      {/* Hotspot hit areas */}
      {activeHotspots.map((spot) => (
        <div
          key={spot.id}
          className="absolute z-20"
          style={{
            left: `${spot.x}%`,
            top: `${spot.y}%`,
            transform: "translate(-50%, -50%)",
            width: `${spot.size.w}px`,
            height: `${spot.size.h}px`,
          }}
          onMouseEnter={() => setHoveredId(spot.id)}
          onMouseLeave={() => setHoveredId(null)}
        >
          {/* Hotspot indicator dot */}
          <motion.div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none z-0 bg-cobalt"
            style={{ width: '7.7px', height: '7.7px', marginLeft: '-3px' }}
            animate={{
              y: spot.id % 3 === 0
                ? [0, -(12 + (spot.id * 7 + 3) % 26), -(12 + (spot.id * 7 + 3) % 26), 0, 0, 0]
                : spot.id % 3 === 1
                ? [0, -(12 + (spot.id * 7 + 3) % 26), 0, 0, 0]
                : [0, -(12 + (spot.id * 7 + 3) % 26), 0]
            }}
            transition={{
              duration: (spot.id % 3 === 0 ? 4.5 : spot.id % 3 === 1 ? 3.8 : 2.2) + (spot.id * 3 + 1) % 4 * 0.4,
              times: spot.id % 3 === 0
                ? [0, 0.25, 0.55, 0.75, 0.88, 1]
                : spot.id % 3 === 1
                ? [0, 0.3, 0.6, 0.82, 1]
                : [0, 0.45, 1],
              repeat: Infinity,
              ease: "easeInOut",
              delay: (spot.id * 5 + 2) % 11 * 0.28,
            }}
          />
          <AnimatePresence>
            {(hoveredId === spot.id || (hoveredId === null && autoId === spot.id)) && (
              <motion.div
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1, transition: { duration: 0.25 } }}
                exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
                className="w-full h-full overflow-hidden pointer-events-none relative z-10"
              >
                <img
                  src={spot.imageUrl}
                  alt="Project preview"
                  className={`w-full h-full ${spot.contain ? 'object-contain' : 'object-cover'}`}
                />
                {!spot.contain && <div className="absolute inset-0 bg-charcoal/10" />}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}

      {/* Name + Info */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
        transition={{ duration: 0.8 }}
        className="absolute left-8 top-1/2 -translate-y-1/2 z-0"
      >
        <h1 className="font-body text-[106px] md:text-[141px] min-[1440px]:text-[9.8vw] font-light tracking-tighter whitespace-nowrap text-left text-foreground" style={{ lineHeight: 0.82 }}>
          {t("home.hero_name").split("\n").map((line, i, arr) => (
            <span key={i}>{line}{i < arr.length - 1 && <br />}</span>
          ))}
        </h1>
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.3, delay: 0.6 }}
          className="flex flex-col md:flex-row gap-2 md:gap-6 text-xs md:text-sm font-mono tracking-widest uppercase text-muted-foreground mt-8 leading-none"
        >
          <TypewriterInfo isInView={isInView} texts={[t("home.hero_info1"), t("home.hero_info2"), t("home.hero_info3")]} />
        </motion.div>
      </motion.div>
    </section>
  );
}