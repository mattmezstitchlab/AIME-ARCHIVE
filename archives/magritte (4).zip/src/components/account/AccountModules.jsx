import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { WEDDING_MODULES, WEDDING_MODULE_ORDER } from "@/lib/weddingModules";

export default function AccountModules({ blocks, passports = [] }) {
  const hasWeddingPassport = passports.some((item) => item.taxonomy_slug === "event-mariage" || item.provider_slug?.startsWith("passport-mariage-") || item.profession === "Mariage");
  const selected = blocks.map((block) => block.link_url?.match(/^\/mariage\/([^/]+)$/)?.[1]);
  const included = hasWeddingPassport ? WEDDING_MODULE_ORDER.filter((key) => key !== "canevas") : [];
  const modules = [...new Set([...included, ...selected].filter((key) => key && key !== "canevas"))];
  if (!modules.length) return null;
  return <section><div className="mb-4"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Modules activés</p><h2 className="mt-2 text-3xl font-light">Vos outils dans l’Espace Compte</h2></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{modules.map((key) => { const item = WEDDING_MODULES[key]; return item && <Link key={key} to={`/mariage/${key}`} className="group border border-border bg-card p-5"><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{item.number} · {item.eyebrow}</p><div className="mt-2 flex items-center justify-between"><h3 className="text-xl font-light">{item.title}</h3><ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1"/></div></Link>; })}</div></section>;
}