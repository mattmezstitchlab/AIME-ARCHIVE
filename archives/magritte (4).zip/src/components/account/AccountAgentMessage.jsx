import React from "react";
import ReactMarkdown from "react-markdown";
import { Check, Loader2, XCircle } from "lucide-react";

const markdownComponents = {
  h1: ({ children }) => <h2 className="border-b border-border pb-2 text-xl font-medium">{children}</h2>,
  h2: ({ children }) => <h3 className="border-b border-border pb-2 text-lg font-medium">{children}</h3>,
  h3: ({ children }) => <h4 className="text-base font-medium text-cobalt">{children}</h4>,
  p: ({ children }) => <p className="leading-relaxed text-muted-foreground">{children}</p>,
  ul: ({ children }) => <ul className="space-y-2 pl-5 text-muted-foreground marker:text-cobalt">{children}</ul>,
  ol: ({ children }) => <ol className="space-y-3 pl-5 text-muted-foreground marker:font-mono marker:text-cobalt">{children}</ol>,
  li: ({ children }) => <li className="pl-1 leading-relaxed">{children}</li>,
  strong: ({ children }) => <strong className="font-medium text-foreground">{children}</strong>,
};

export default function AccountAgentMessage({ message }) {
  const user = message.role === "user";
  return <div className={user ? "flex justify-end" : "flex justify-start"}><div className={user ? "max-w-[85%] bg-foreground p-3 text-sm text-background" : "w-full max-w-[95%] border border-border bg-background p-4 text-sm"}>
    {message.content && (user ? <p>{message.content}</p> : <div className="space-y-4"><ReactMarkdown components={markdownComponents}>{message.content}</ReactMarkdown></div>)}
    {message.tool_calls?.map((tool, index) => <ToolState key={index} tool={tool}/>)}
  </div></div>;
}

function ToolState({ tool }) {
  const failed = ["failed", "error"].includes(tool.status), active = ["pending", "running", "in_progress"].includes(tool.status);
  const hidden = tool.display_projection?.hide_details && tool.display_projection?.details_redacted;
  const label = failed ? tool.display_projection?.error_label || "Action impossible" : active ? tool.display_projection?.active_label || "Action en cours" : tool.display_projection?.label || "Action terminée";
  const Icon = failed ? XCircle : active ? Loader2 : Check;
  return <div className="mt-2 flex items-center gap-2 border-t border-border pt-2 font-mono text-[10px] uppercase tracking-widest"><Icon className={active ? "h-3 w-3 animate-spin" : "h-3 w-3"}/>{hidden ? label : `${label} · ${tool.name}`}</div>;
}