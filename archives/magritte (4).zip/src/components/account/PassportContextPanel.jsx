import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, Link2, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PassportContextPanel({ passport, relations, onConfigure }) {
  if (!passport) return null;
  const passportRelations = relations.filter((relation) => [relation.source_passport_id, relation.target_passport_id].includes(passport.id));
  const related = passportRelations.length, suggested = passportRelations.filter((relation) => relation.inferred).length;
  const missing = [[passport.location, "Ajouter la localisation"], [passport.biography, "Compléter la biographie"], [passport.contact_email, "Ajouter un contact"], [passport.status === "actif", "Activer le Passport"]].filter(([done]) => !done).map(([, label]) => label);
  return <section className="grid gap-5 border border-border bg-card p-5 lg:grid-cols-[1fr_auto]"><div><div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-cobalt"><Link2 className="h-3 w-3"/>{related} connexion{related > 1 ? "s" : ""}{suggested > 0 && ` · ${suggested} suggérée${suggested > 1 ? "s" : ""}`}</div><h2 className="mt-2 text-3xl font-light">{passport.name}</h2><p className="mt-1 text-sm text-muted-foreground">{[passport.profession, passport.location].filter(Boolean).join(" · ")}</p>{missing.length > 0 && <div className="mt-4 flex flex-wrap gap-2">{missing.map((item) => <span key={item} className="border border-border bg-background px-2 py-1 text-xs">{item}</span>)}</div>}</div><div className="flex flex-wrap items-start gap-2"><Button variant="outline" asChild><Link to={`/passport?provider=${encodeURIComponent(passport.provider_slug || "")}`}><ArrowUpRight className="h-4 w-4"/>Ouvrir</Link></Button><Button onClick={() => onConfigure(passport)}><Settings2 className="h-4 w-4"/>Configurer</Button></div></section>;
}