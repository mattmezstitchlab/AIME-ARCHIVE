import React from "react";

export default function PassportNetworkLines({ relations, positions, selectedId }) {
  return <svg className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true">{relations.map((relation) => {
    const start = positions[relation.source_passport_id], end = positions[relation.target_passport_id];
    if (!start || !end) return null;
    const active = selectedId && [relation.source_passport_id, relation.target_passport_id].includes(selectedId);
    const x1 = start.x + 100, y1 = start.y + 62, x2 = end.x + 100, y2 = end.y + 62, curve = Math.abs(x2 - x1) * 0.45;
    return <path key={relation.id} d={`M ${x1} ${y1} C ${x1 + curve} ${y1}, ${x2 - curve} ${y2}, ${x2} ${y2}`} fill="none" stroke={active ? "hsl(var(--primary))" : "hsl(var(--border))"} strokeWidth={active ? 3 : 1.5} strokeDasharray={relation.inferred ? "4 7" : active ? "8 6" : "none"} opacity={selectedId && !active ? 0.25 : relation.inferred ? 0.55 : 0.8}/>;
  })}</svg>;
}