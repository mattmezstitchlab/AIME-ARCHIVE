import React from "react";
import { CalendarClock, CheckSquare2, Euro, FileText } from "lucide-react";

export default function AccountOverview({ overview }) {
  const items = [
    { label: "Documents", value: overview.documents, icon: FileText },
    { label: "Actions ouvertes", value: overview.tasks, icon: CheckSquare2 },
    { label: "Échéances", value: overview.timeline, icon: CalendarClock },
    { label: "Budget suivi", value: `${overview.budget.toLocaleString("fr-FR")} €`, icon: Euro }
  ];
  return <div className="grid border border-border sm:grid-cols-2 xl:grid-cols-4">{items.map(({ label, value, icon: Icon }) => <div key={label} className="flex items-center gap-3 border-b border-border p-4 last:border-b-0 sm:border-r xl:border-b-0"><Icon className="h-4 w-4 text-cobalt"/><div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p><p className="mt-1 text-xl font-light">{value}</p></div></div>)}</div>;
}