import React, { useRef, useState } from "react";
import PassportNetworkCard from "./PassportNetworkCard";
import PassportNetworkLines from "./PassportNetworkLines";

export default function PassportNetworkStage({ passports, relations, positions, selected, mode, onSelect, onMove }) {
  const boardRef = useRef(null), liveRef = useRef({}), [live, setLive] = useState({}), [drag, setDrag] = useState(null);
  const shown = { ...positions, ...live };
  const relatedIds = new Set(relations.flatMap((relation) => [relation.source_passport_id, relation.target_passport_id].includes(selected?.id) ? [relation.source_passport_id, relation.target_passport_id] : []));
  const start = (event, passport, position) => {
    const rect = boardRef.current.getBoundingClientRect();
    event.currentTarget.setPointerCapture(event.pointerId);
    setDrag({ id: passport.id, dx: event.clientX - rect.left + boardRef.current.scrollLeft - position.x, dy: event.clientY - rect.top + boardRef.current.scrollTop - position.y });
  };
  const move = (event) => {
    if (!drag) return;
    const rect = boardRef.current.getBoundingClientRect(), next = { x: Math.max(15, Math.min(900, event.clientX - rect.left + boardRef.current.scrollLeft - drag.dx)), y: Math.max(15, Math.min(520, event.clientY - rect.top + boardRef.current.scrollTop - drag.dy)) };
    liveRef.current[drag.id] = next; setLive((current) => ({ ...current, [drag.id]: next }));
  };
  const end = async () => { if (!drag) return; const next = liveRef.current[drag.id]; setDrag(null); if (next) await onMove(drag.id, next); };
  return <div className="overflow-auto border border-border bg-background"><div ref={boardRef} data-testid="passport-network-stage" onPointerMove={move} onPointerUp={end} onPointerCancel={end} className="relative h-[680px] min-w-[1120px] bg-[radial-gradient(circle,hsl(var(--border))_1px,transparent_1px)] bg-[size:24px_24px]"><PassportNetworkLines relations={relations} positions={shown} selectedId={selected?.id}/>{passports.map((passport) => <PassportNetworkCard key={passport.id} passport={passport} position={shown[passport.id]} active={selected?.id === passport.id} related={relatedIds.has(passport.id) && selected?.id !== passport.id} movable={mode === "free"} onSelect={onSelect} onPointerDown={start}/>)}</div></div>;
}