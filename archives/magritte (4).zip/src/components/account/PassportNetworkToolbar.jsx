import React from "react";
import { Focus, LayoutGrid, Move, Orbit } from "lucide-react";

const modes = [
  { key: "automatic", label: "Organisation automatique", icon: Orbit },
  { key: "groups", label: "Regroupements", icon: LayoutGrid },
  { key: "free", label: "Placement libre", icon: Move }
];
export default function PassportNetworkToolbar({ mode, onMode, onRecenter }) {
  return <div className="flex gap-2 overflow-x-auto border-x border-t border-border bg-card p-3">{modes.map(({ key, label, icon: Icon }) => <button key={key} onClick={() => onMode(key)} className={`flex shrink-0 items-center gap-2 border px-3 py-2 font-mono text-[10px] uppercase tracking-widest ${mode === key ? "border-foreground bg-foreground text-background" : "border-border hover:border-foreground"}`}><Icon className="h-4 w-4"/>{label}</button>)}<button onClick={onRecenter} className="ml-auto flex shrink-0 items-center gap-2 border border-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest hover:border-foreground"><Focus className="h-4 w-4"/>Recentrer</button></div>;
}