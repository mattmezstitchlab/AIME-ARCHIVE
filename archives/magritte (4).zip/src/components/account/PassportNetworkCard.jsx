import React from "react";
import { Grip, Link2 } from "lucide-react";

export default function PassportNetworkCard({ passport, position, active, related, movable, onSelect, onPointerDown }) {
  const image = passport.card_media?.url || passport.avatar || passport.cover_image;
  return <button type="button" data-passport-node={passport.id} onClick={() => onSelect(passport)} onPointerDown={(event) => movable && onPointerDown(event, passport, position)} style={{ transform: `translate(${position.x}px, ${position.y}px)` }} className={`absolute left-0 top-0 w-[200px] touch-none border bg-card p-3 text-left shadow-sm transition-[border-color,opacity] ${active ? "border-cobalt ring-2 ring-cobalt/20" : related ? "border-cobalt/60" : "border-border"}`}>
    <div className="flex items-center gap-3">{image ? <img src={image} alt="" className="h-11 w-11 shrink-0 object-cover"/> : <div className="flex h-11 w-11 shrink-0 items-center justify-center bg-muted font-mono text-xs">A</div>}<div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{passport.name}</p><p className="truncate text-xs text-muted-foreground">{passport.profession}</p></div>{movable && <Grip className="h-4 w-4 text-muted-foreground"/>}</div>
    <div className="mt-3 flex items-center justify-between border-t border-border pt-2 font-mono text-[9px] uppercase tracking-widest text-muted-foreground"><span>{passport.subject_type || "personne"}</span>{related && <Link2 className="h-3 w-3 text-cobalt"/>}</div>
  </button>;
}