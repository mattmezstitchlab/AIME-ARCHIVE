import React, { useMemo, useState } from "react";
import { Loader2 } from "lucide-react";
import { useAccountCanvas } from "@/lib/useAccountCanvas";
import { buildCanvasPositions, buildNetworkRelations } from "@/lib/accountCanvasLayout";
import AccountAgentPanel from "./AccountAgentPanel";
import AccountOverview from "./AccountOverview";
import PassportContextPanel from "./PassportContextPanel";
import PassportNetworkToolbar from "./PassportNetworkToolbar";
import PassportNetworkStage from "./PassportNetworkStage";
import AccountModules from "./AccountModules";
import { useCanvasBlocks } from "@/lib/useCanvasBlocks";
import { useWeddingSimulation } from "@/lib/useWeddingSimulation";
import SimulationCanvasPreview from "@/components/wedding-module/SimulationCanvasPreview";

export default function AccountCanvasHome({ passports, onConfigure }) {
  const canvas = useAccountCanvas(true), moduleCanvas = useCanvasBlocks(true), { simulation, hasSimulation } = useWeddingSimulation(), [mode, setMode] = useState("automatic"), [selectedId, setSelectedId] = useState(passports[0]?.id || "");
  const selected = passports.find((passport) => passport.id === selectedId) || passports[0];
  const hasWeddingPassport = passports.some((passport) => passport.taxonomy_slug === "event-mariage" || passport.profession === "Mariage");
  const positions = useMemo(() => buildCanvasPositions(passports, canvas.nodes, mode), [passports, canvas.nodes, mode]);
  const relations = useMemo(() => buildNetworkRelations(passports, canvas.relations), [passports, canvas.relations]);
  if (canvas.isLoading) return <div className="flex h-80 items-center justify-center border border-border"><Loader2 className="h-6 w-6 animate-spin"/></div>;
  return <div className="space-y-6"><AccountAgentPanel/><AccountOverview overview={canvas.overview}/><AccountModules blocks={moduleCanvas.blocks} passports={passports}/>{hasWeddingPassport && hasSimulation && <SimulationCanvasPreview simulation={simulation} accountMode/>}{passports.length === 0 ? <div className="border border-dashed p-10 text-center"><p className="text-lg">Créez un Passport pour démarrer votre Canevas.</p></div> : <><PassportContextPanel passport={selected} relations={relations} onConfigure={onConfigure}/><section><div className="mb-4"><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Canevas universel</p><h2 className="mt-2 text-3xl font-light">Le réseau vivant de vos Passports</h2><p className="mt-2 max-w-2xl text-sm text-muted-foreground">Sélectionnez une carte pour révéler son cheminement. En placement libre, déplacez-la pour enregistrer sa position.</p></div><PassportNetworkToolbar mode={mode} onMode={setMode} onRecenter={() => setSelectedId(passports[0]?.id || "")}/><PassportNetworkStage passports={passports} relations={relations} positions={positions} selected={selected} mode={mode} onSelect={(passport) => setSelectedId(passport.id)} onMove={canvas.savePosition}/></section></>}</div>;
}