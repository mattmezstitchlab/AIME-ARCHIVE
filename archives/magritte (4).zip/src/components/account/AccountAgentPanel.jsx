import React, { useEffect, useState } from "react";
import { Bot, Loader2, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AccountAgentMessage from "./AccountAgentMessage";

export default function AccountAgentPanel() {
  const [conversation, setConversation] = useState(null), [messages, setMessages] = useState([]), [text, setText] = useState(""), [sending, setSending] = useState(false), [error, setError] = useState("");
  useEffect(() => {
    if (!conversation?.id) return undefined;
    return base44.agents.subscribeToConversation(conversation.id, (data) => setMessages(data.messages || []));
  }, [conversation?.id]);
  const send = async (content) => {
    if (!content.trim() || sending) return;
    setSending(true); setError("");
    try {
      const current = conversation || await base44.agents.createConversation({ agent_name: "aime_account_agent", metadata: { name: "Briefing de mon compte", description: "Analyse du Canevas AIME" } });
      if (!conversation) setConversation(current);
      await base44.agents.addMessage(current, { role: "user", content });
      setText("");
    } catch (err) { setError(err.message || "Agent AIME est momentanément indisponible."); }
    setSending(false);
  };
  return <section id="agent-aime" className="border border-cobalt/30 bg-cobalt/5 p-5 md:p-6"><div className="flex flex-wrap items-start justify-between gap-4"><div className="flex gap-3"><Bot className="mt-1 h-5 w-5 text-cobalt"/><div><p className="font-mono text-xs uppercase tracking-widest text-cobalt">Agent AIME</p><h2 className="mt-1 text-2xl font-light">Votre briefing du compte</h2><p className="mt-1 text-sm text-muted-foreground">Il analyse d’abord, puis demande votre confirmation avant toute modification.</p></div></div><button onClick={() => send("Analyse mon compte, mon Canevas et mes Passports sans rien modifier. Structure ta réponse en Synthèse, Priorités, Actions recommandées et Prochaine étape.")} className="border border-cobalt px-4 py-2 text-sm text-cobalt hover:bg-cobalt hover:text-primary-foreground">Analyser mon compte</button></div>
    {messages.length > 0 && <div className="mt-5 max-h-80 space-y-3 overflow-y-auto border-t border-cobalt/20 pt-5">{messages.map((message, index) => <AccountAgentMessage key={index} message={message}/>)}</div>}
    <div className="mt-4 flex gap-2"><input value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => event.key === "Enter" && send(text)} placeholder="Demander à Agent AIME…" className="h-11 flex-1 border border-border bg-background px-3 text-sm"/><button aria-label="Envoyer à Agent AIME" onClick={() => send(text)} disabled={sending} className="flex h-11 w-11 items-center justify-center bg-foreground text-background disabled:opacity-50">{sending ? <Loader2 className="h-4 w-4 animate-spin"/> : <Send className="h-4 w-4"/>}</button></div>{error && <p className="mt-2 text-sm text-destructive">{error}</p>}
  </section>;
}