import React, { useEffect, useState } from "react";
import { Textarea } from "@/components/ui/textarea";

export default function VendorContribution({ notes, onSave, saving }) {
  const [value, setValue] = useState(notes || ""), [saved, setSaved] = useState(false);
  useEffect(() => setValue(notes || ""), [notes]);
  const save = async () => { await onSave(value); setSaved(true); setTimeout(() => setSaved(false), 1800); };
  return <section className="mt-8 border border-border p-5"><label className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Note de coordination</label><Textarea aria-label="Note de coordination" value={value} onChange={(e) => setValue(e.target.value)} className="mt-3 min-h-28" placeholder="Informations utiles pour l’équipe…" /><button disabled={saving} onClick={save} className="mt-3 bg-foreground px-4 py-2 text-sm text-background disabled:opacity-50">{saved ? "Enregistré" : saving ? "Enregistrement…" : "Enregistrer la note"}</button></section>;
}