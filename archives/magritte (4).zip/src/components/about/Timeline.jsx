import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";

function FadeRow({ item, index }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.6, delay: index * 0.1 }} className="grid grid-cols-1 gap-4 py-8 md:grid-cols-12 md:gap-8">
      <div className="md:col-span-3"><span className="font-mono text-xs tracking-widest text-muted-foreground">{item.value}</span></div>
      <div className="md:col-span-9"><h3 className="mb-2 text-lg font-medium">{item.label}</h3>{item.description && <p className="text-base leading-relaxed text-muted-foreground">{item.description}</p>}</div>
    </motion.div>
  );
}

export default function Timeline({ items = [] }) {
  return <div>{items.map((item, index) => <FadeRow key={item.id || item.key} item={item} index={index}/>)}</div>;
}