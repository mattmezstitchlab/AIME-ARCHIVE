import React from "react";

export default function AboutTextSection({ section, index }) {
  return <section className="border-t border-border px-6 py-20 md:px-8 md:py-28">
    <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-12">
      <p className="font-mono text-xs tracking-widest text-muted-foreground md:col-span-3">{String(index + 1).padStart(2, "0")}</p>
      <div className="md:col-span-8">
        {section.eyebrow && <p className="mb-4 font-mono text-xs uppercase tracking-widest text-cobalt">{section.eyebrow}</p>}
        <h2 className="text-3xl font-light tracking-tight md:text-5xl">{section.title}</h2>
        {section.body && <div className="mt-8 max-w-3xl whitespace-pre-line text-base font-light leading-relaxed text-muted-foreground md:text-lg">{section.body}</div>}
      </div>
    </div>
  </section>;
}