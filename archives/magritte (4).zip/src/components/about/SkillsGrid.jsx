import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";

export default function SkillsGrid({ items = [] }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.6 }} className="grid grid-cols-1 gap-12 sm:grid-cols-2">
      {items.map((group) => <div key={group.id || group.key}>
        <span className="mb-4 block font-mono text-xs uppercase tracking-widest text-muted-foreground">{group.label}</span>
        <div className="space-y-2">{(group.items || []).map((tool) => <div key={tool} className="flex items-center gap-3 py-2"><div className="h-1.5 w-1.5 flex-shrink-0 rounded-full bg-sage"/><span className="text-sm">{tool}</span></div>)}</div>
      </div>)}
    </motion.div>
  );
}