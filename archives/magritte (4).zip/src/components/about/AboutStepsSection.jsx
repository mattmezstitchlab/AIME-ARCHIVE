import React from "react";

export default function AboutStepsSection({ section, index }) {
  return <section className="border-t border-border bg-charcoal px-6 py-20 text-gallery md:px-8 md:py-28">
    <div className="mx-auto max-w-7xl">
      <p className="font-mono text-xs tracking-widest text-gallery/50">{String(index + 1).padStart(2, "0")}</p>
      <h2 className="mt-6 text-3xl font-light tracking-tight md:text-5xl">{section.title}</h2>
      {section.body && <p className="mt-6 max-w-2xl leading-relaxed text-gallery/60">{section.body}</p>}
      <div className="mt-14 grid border-l border-t border-gallery/20 md:grid-cols-3">
        {(section.items || []).map((item, itemIndex) => <article key={`${item.title}-${itemIndex}`} className="border-b border-r border-gallery/20 p-7">
          <p className="font-mono text-xs tracking-widest text-cobalt">{item.meta || String(itemIndex + 1).padStart(2, "0")}</p>
          <h3 className="mt-8 text-xl font-light">{item.title}</h3>
          <p className="mt-4 text-sm leading-relaxed text-gallery/60">{item.text}</p>
        </article>)}
      </div>
    </div>
  </section>;
}