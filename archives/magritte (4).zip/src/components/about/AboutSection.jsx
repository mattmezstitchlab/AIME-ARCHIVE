import React from "react";
import AboutHeroSection from "@/components/about/AboutHeroSection";
import AboutTextSection from "@/components/about/AboutTextSection";
import AboutTimelineSection from "@/components/about/AboutTimelineSection";
import AboutStepsSection from "@/components/about/AboutStepsSection";

const sectionComponents = {
  hero: AboutHeroSection,
  text: AboutTextSection,
  timeline: AboutTimelineSection,
  steps: AboutStepsSection,
};

export default function AboutSection({ section, index }) {
  const Section = sectionComponents[section.section_type] || AboutTextSection;
  return <Section section={section} index={index} />;
}