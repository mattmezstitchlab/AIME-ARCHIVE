import React from "react";

export default function AboutHeroSection({ section }) {
  return <section className="px-6 pb-24 pt-32 md:px-8 md:pb-32 md:pt-36">
    <div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-12 md:items-end">
      <div className="md:col-span-7">
        {section.eyebrow && <p className="mb-6 font-mono text-xs uppercase tracking-widest text-cobalt">{section.eyebrow}</p>}
        <h1 className="text-5xl font-light leading-[0.95] tracking-tight md:text-7xl lg:text-8xl">{section.title}</h1>
        {section.body && <p className="mt-10 max-w-2xl whitespace-pre-line text-lg font-light leading-relaxed text-muted-foreground md:text-xl">{section.body}</p>}
      </div>
      {section.image_url && <div className="md:col-span-5"><img src={section.image_url} alt="Matt Mez, créateur d’AIME®" className="aspect-[4/5] w-full object-cover" /></div>}
    </div>
  </section>;
}