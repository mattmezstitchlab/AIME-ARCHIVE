import React from "react";

export default function AboutTimelineSection({ section, index }) {
  return <section className="border-t border-border px-6 py-20 md:px-8 md:py-28">
    <div className="mx-auto max-w-7xl">
      <p className="font-mono text-xs tracking-widest text-muted-foreground">{String(index + 1).padStart(2, "0")}</p>
      <h2 className="mt-6 text-3xl font-light tracking-tight md:text-5xl">{section.title}</h2>
      {section.body && <p className="mt-6 max-w-2xl leading-relaxed text-muted-foreground">{section.body}</p>}
      <div className="mt-14 border-t border-border">
        {(section.items || []).map((item, itemIndex) => <article key={`${item.title}-${itemIndex}`} className="grid gap-3 border-b border-border py-8 md:grid-cols-12">
          <p className="font-mono text-xs uppercase tracking-widest text-cobalt md:col-span-2">{item.meta}</p>
          <h3 className="text-xl font-light md:col-span-4">{item.title}</h3>
          <p className="leading-relaxed text-muted-foreground md:col-span-6">{item.text}</p>
        </article>)}
      </div>
    </div>
  </section>;
}