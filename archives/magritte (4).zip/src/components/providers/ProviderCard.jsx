import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, MapPin } from "lucide-react";

export default function ProviderCard({ provider }) {
  return (
    <Link to={`/prestataire/${provider.slug}`} className="group block border-t border-border pt-4">
      <div className="aspect-[4/3] bg-muted overflow-hidden mb-4">
        {provider.image ? (
          <img src={provider.image} alt={provider.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="w-full h-full flex items-center justify-center font-mono text-xs uppercase tracking-widest text-muted-foreground">Image à venir</div>
        )}
      </div>
      <div className="flex items-start justify-between gap-4">
        <div>
          <span className="font-mono text-xs uppercase tracking-widest text-cobalt">{provider.category}</span>
          <h2 className="font-body text-2xl font-light text-foreground mt-1">{provider.name}</h2>
          {provider.location && <p className="font-body text-sm text-muted-foreground mt-1 flex items-center gap-1"><MapPin className="w-3 h-3" />{provider.location}</p>}
        </div>
        <ArrowUpRight className="w-5 h-5 mt-1 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
      </div>
    </Link>
  );
}