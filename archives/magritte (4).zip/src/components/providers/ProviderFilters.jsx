import React from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function ProviderFilters({ search, category, categories, onSearch, onCategory }) {
  return (
    <div className="grid md:grid-cols-2 gap-4 mb-12">
      <label className="relative">
        <span className="sr-only">Rechercher un prestataire</span>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="Nom ou ville…" className="pl-10 h-11" />
      </label>
      <label>
        <span className="sr-only">Filtrer par catégorie</span>
        <select value={category} onChange={(e) => onCategory(e.target.value)} className="h-11 w-full border border-input bg-background px-3 text-sm text-foreground">
          <option value="">Toutes les catégories</option>
          {categories.map((item) => <option key={item} value={item}>{item}</option>)}
        </select>
      </label>
    </div>
  );
}