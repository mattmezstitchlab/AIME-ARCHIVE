import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { ThemeProvider } from 'next-themes';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import Layout from '@/components/layout/Layout';
import Home from '@/pages/Home';
import ProjectDetail from '@/pages/ProjectDetail';
import About from '@/pages/About';
import Projects from '@/pages/Projects';
import Contact from '@/pages/Contact';
import Privacy from '@/pages/Privacy';
import Accessibility from '@/pages/Accessibility';
import Admin from '@/pages/Admin';
import DocumentView from '@/pages/DocumentView';
import Providers from '@/pages/Providers';
import ProviderDetail from '@/pages/ProviderDetail';
import Dashboard from '@/pages/Dashboard';
import PassportAccess from '@/pages/PassportAccess';
import MyPassport from '@/pages/MyPassport';
import PublicRsvp from '@/pages/PublicRsvp';
import VendorPortal from '@/pages/VendorPortal';
import PassportDesignSystem from '@/pages/PassportDesignSystem';
import WeddingModule from '@/pages/WeddingModule';
import WeddingModules from '@/pages/WeddingModules';
import SiteCanvas from '@/pages/SiteCanvas';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-6 h-6 border-2 border-foreground/20 border-t-foreground rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/project/:slug" element={<ProjectDetail />} />
        <Route path="/about" element={<About />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/accessibility" element={<Accessibility />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/document/:id" element={<DocumentView />} />
        <Route path="/prestataires" element={<Providers />} />
        <Route path="/prestataire/:slug" element={<ProviderDetail />} />
        <Route path="/mon-mariage" element={<Dashboard />} />
        <Route path="/mariage/modules" element={<WeddingModules />} />
        <Route path="/mariage/:module" element={<WeddingModule />} />
        <Route path="/passport" element={<PassportAccess />} />
        <Route path="/compte" element={<MyPassport accountMode />} />
        <Route path="/mon-passport" element={<MyPassport />} />
        <Route path="/rsvp/:token" element={<PublicRsvp />} />
        <Route path="/acces-prestataire/:token" element={<VendorPortal />} />
      </Route>
      <Route path="/passport-design-system" element={<PassportDesignSystem />} />
      <Route path="/studio" element={<SiteCanvas />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
    </ThemeProvider>
  )
}

export default App