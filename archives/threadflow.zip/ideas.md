# ThreadFlow — Brainstorm Design

## Approches de design

<response>
<idea>
**Design Movement**: Neumorphisme Artisanal — "Tissu Numérique"

**Core Principles**:
1. Surfaces douces et tactiles qui évoquent la texture du tissu Aida
2. Hiérarchie visuelle par la profondeur, pas par la couleur
3. Typographie contrastée : serif élégant pour les titres, sans-serif lisible pour le corps
4. Asymétrie organique : les sections "respirent" comme un projet en cours

**Color Philosophy**: Palette naturelle inspirée du fil DMC — ivoire chaud (#F5F0E8), sauge (#7A9E7E), terracotta (#C4714A), lin (#D4C5A9), ardoise (#3D4A3E). Les couleurs évoquent l'atelier d'une artisane, pas un logiciel tech.

**Layout Paradigm**: Sections en décalage horizontal, contenu qui "déborde" légèrement des colonnes pour créer du mouvement. Navigation fixe minimaliste avec logo à gauche et CTA à droite.

**Signature Elements**:
1. Motif de grille point de croix en arrière-plan (très subtil, opacity 3-5%)
2. Séparateurs de section en forme de fil qui traverse la page
3. Boutons avec ombre portée neumorphique, légèrement en relief

**Interaction Philosophy**: Chaque hover révèle une profondeur supplémentaire. Les animations sont lentes et apaisantes, comme le rythme d'une session de broderie.

**Animation**: Fade-in + slide-up à l'entrée dans le viewport (0.6s ease-out). Hover sur les cartes : élévation douce (translateY -4px, shadow +). Pas d'animations agressives.

**Typography System**: Cormorant Garamond (display, titres H1-H2) + DM Sans (corps, UI). Contraste fort entre les deux pour créer une tension élégante.
</idea>
<probability>0.08</probability>
</response>

<response>
<idea>
**Design Movement**: Editorial Craft — "Magazine de Broderie Haut de Gamme"

**Core Principles**:
1. Mise en page éditoriale inspirée des magazines de mode/craft
2. Grandes typographies expressives qui occupent l'espace
3. Photos et illustrations en pleine largeur avec texte en surimpression
4. Contraste fort entre zones denses et zones de respiration

**Color Philosophy**: Fond blanc cassé (#FAFAF7), texte charbon (#1A1A18), accents terracotta (#C4714A) et sauge (#5C7A5E). Minimalisme chromatique qui laisse les images parler.

**Layout Paradigm**: Grille éditoriale à 12 colonnes avec des éléments qui cassent la grille intentionnellement. Titres qui débordent, images qui saignent sur les bords.

**Signature Elements**:
1. Numérotation des sections en grand (01, 02, 03) à gauche
2. Lignes de séparation fines en terracotta
3. Citations en grand format avec guillemets stylisés

**Interaction Philosophy**: Scroll storytelling — chaque section révèle son contenu comme on tourne les pages d'un magazine.

**Animation**: Parallaxe subtile sur les images hero. Texte qui entre par le bas en stagger. Curseur personnalisé avec aiguille.

**Typography System**: Playfair Display (titres) + Source Sans 3 (corps). Utilisation expressive des tailles : H1 à 96px, corps à 18px.
</idea>
<probability>0.07</probability>
</response>

<response>
<idea>
**Design Movement**: Organic Warmth — "Atelier de Brodeuse Moderne"

**Core Principles**:
1. Chaleur organique sans être rustique — moderne mais humain
2. Sections à fond alterné (ivoire / sauge pâle) pour créer du rythme
3. Illustrations et photos intégrées naturellement dans le contenu
4. CTA généreux et invitants, jamais agressifs

**Color Philosophy**: Ivoire (#F7F3EC) comme fond principal, sauge doux (#8FAF8F) pour les sections alternées, terracotta (#C4714A) pour les accents et CTA, lin (#DDD5C5) pour les bordures. Palette chaude et cohérente du début à la fin.

**Layout Paradigm**: Sections pleine largeur avec contenu centré (max-w-6xl). Alternance gauche/droite pour les features. Hero asymétrique avec texte à gauche et illustration à droite.

**Signature Elements**:
1. Fond en texture de tissu Aida très subtil (SVG pattern)
2. Badges "pill" en terracotta pour les labels (Pro, Nouveau, IA)
3. Cards avec coins légèrement arrondis et ombre chaude

**Interaction Philosophy**: Micro-interactions douces sur tous les éléments interactifs. Le site doit sembler vivant mais jamais distrayant.

**Animation**: Intersection Observer pour les entrées en viewport. Compteurs animés pour les statistiques. Slider de démonstration interactif pour Confetti Cleaner.

**Typography System**: Lora (titres, serif élégant) + Nunito Sans (corps, lisible). Lora apporte le côté artisanal, Nunito la modernité.
</idea>
<probability>0.09</probability>
</response>

## Choix retenu

**Approche 1 — Neumorphisme Artisanal "Tissu Numérique"** avec des éléments de l'approche 3 (chaleur organique).

Typographie : Cormorant Garamond + DM Sans
Palette : Ivoire #F5F0E8, Sauge #7A9E7E, Terracotta #C4714A, Lin #D4C5A9, Ardoise #3D4A3E
