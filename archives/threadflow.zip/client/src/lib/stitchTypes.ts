// ─── Types et utilitaires de points de broderie ───────────────────────────────
// Ce fichier est séparé d'Editor.tsx pour respecter la règle Fast Refresh de Vite
// (un fichier de composant React ne doit pas exporter de fonctions utilitaires)

export type StitchType =
  | "full"             // Croix complète ✕
  | "half_fwd"         // Demi-point /
  | "half_bwd"         // Demi-point \
  | "quarter_tl"       // Quart ↖
  | "quarter_tr"       // Quart ↗
  | "quarter_bl"       // Quart ↙
  | "quarter_br"       // Quart ↘
  | "three_quarter_tl" | "three_quarter_tr" | "three_quarter_bl" | "three_quarter_br"
  | "backstitch_h"     // Arrière horizontal
  | "backstitch_v"     // Arrière vertical
  | "backstitch_d1"    // Arrière diagonal /
  | "backstitch_d2"    // Arrière diagonal \
  | "french_knot";     // Nœud français

export type StitchGroup = "fill" | "three_quarter" | "backstitch" | "french_knot";

export function getStitchGroup(type: StitchType): StitchGroup {
  if (type.startsWith("three_quarter")) return "three_quarter";
  if (type.startsWith("backstitch")) return "backstitch";
  if (type === "french_knot") return "french_knot";
  return "fill";
}

export interface GridCell {
  dmc: string | null;
  hex: string | null;
  done?: boolean;
  stitchType?: StitchType;
}

// ─── Smart Pathing™ — ordre d'exécution correct ───────────────────────────────
export function computeSmartPathOrdered(cells: GridCell[][], targetDmc: string): {
  fillPath: [number, number][];
  threeQuarterPath: [number, number][];
  backstitchPath: [number, number][];
  frenchKnotPath: [number, number][];
} {
  const fill: [number, number][] = [];
  const threeQ: [number, number][] = [];
  const bs: [number, number][] = [];
  const fk: [number, number][] = [];

  for (let r = 0; r < cells.length; r++) {
    for (let c = 0; c < (cells[r]?.length ?? 0); c++) {
      const cell = cells[r]?.[c];
      if (!cell || cell.dmc !== targetDmc || cell.done) continue;
      const group = getStitchGroup(cell.stitchType ?? "full");
      if (group === "fill") fill.push([r, c]);
      else if (group === "three_quarter") threeQ.push([r, c]);
      else if (group === "backstitch") bs.push([r, c]);
      else fk.push([r, c]);
    }
  }

  // Nearest-neighbor pour chaque groupe
  const nnSort = (pts: [number, number][]): [number, number][] => {
    if (pts.length === 0) return [];
    const path: [number, number][] = [pts[0]!];
    const remaining = pts.slice(1);
    while (remaining.length > 0) {
      const last = path[path.length - 1]!;
      let minDist = Infinity, minIdx = 0;
      remaining.forEach(([r, c], i) => {
        const dist = Math.abs(r - last[0]) + Math.abs(c - last[1]);
        if (dist < minDist) { minDist = dist; minIdx = i; }
      });
      path.push(remaining[minIdx]!);
      remaining.splice(minIdx, 1);
    }
    return path;
  };

  return {
    fillPath: nnSort(fill),
    threeQuarterPath: nnSort(threeQ),
    backstitchPath: nnSort(bs),
    frenchKnotPath: nnSort(fk),
  };
}
