/**
 * ConfettiSplitOverlay — Diviseur glissable avant/après pour Confetti Cleaner™
 *
 * Rend deux copies de la grille sur Canvas :
 *  - Gauche (AVANT) : grille originale avec confettis surlignés en rouge
 *  - Droite (APRÈS) : grille nettoyée (confettis remplacés par la couleur dominante voisine)
 *
 * Le diviseur est glissable horizontalement pour comparer les deux états.
 */
import { useRef, useEffect, useCallback, useState, useMemo } from "react";
import type { GridCell } from "@/lib/stitchTypes";

interface Props {
  grid: GridCell[][];
  rows: number;
  cols: number;
  zoom: number;
  threshold: number; // min voisins pour garder un point (confettiThreshold)
  splitPos: number; // position du diviseur en % (0-100)
  onSplitPosChange: (pos: number) => void;
  confettiCount: number;
  onApply: () => void;
}

// Constantes de layout (doivent correspondre à Editor.tsx)
const RULER_H = 20; // hauteur règle colonnes
const RULER_W = 20; // largeur règle lignes
const PADDING = 16; // padding du conteneur (p-4 = 16px)

/** Calcule la grille nettoyée : remplace chaque confetti par la couleur voisine dominante */
function computeCleanGrid(
  grid: GridCell[][],
  rows: number,
  cols: number,
  threshold: number
): GridCell[][] {
  const cleaned: GridCell[][] = grid.map(row => row.map(cell => ({ ...cell })));

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = grid[r]?.[c];
      if (!cell?.dmc) continue;

      const neighbors = [[-1, 0], [1, 0], [0, -1], [0, 1]].filter(([dr, dc]) => {
        const nr = r + (dr ?? 0), nc = c + (dc ?? 0);
        return nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr]?.[nc]?.dmc === cell.dmc;
      }).length;

      if (neighbors < threshold) {
        // Trouver la couleur voisine dominante (y compris diagonales)
        const neighborColors: Record<string, { count: number; hex: string }> = {};
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            const nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
              const n = grid[nr]?.[nc];
              if (n?.dmc && n.dmc !== cell.dmc) {
                if (!neighborColors[n.dmc]) neighborColors[n.dmc] = { count: 0, hex: n.hex ?? "#e8e3da" };
                neighborColors[n.dmc]!.count++;
              }
            }
          }
        }
        const dominant = Object.values(neighborColors).sort((a, b) => b.count - a.count)[0];
        if (dominant) {
          cleaned[r]![c] = { ...cell, hex: dominant.hex, dmc: Object.keys(neighborColors).find(k => neighborColors[k] === dominant) ?? "" };
        } else {
          // Pas de voisin coloré → effacer
          cleaned[r]![c] = { hex: null, dmc: null, stitchType: "full" };
        }
      }
    }
  }
  return cleaned;
}

/** Dessine la grille sur un Canvas 2D */
function drawGrid(
  ctx: CanvasRenderingContext2D,
  grid: GridCell[][],
  rows: number,
  cols: number,
  zoom: number,
  confettiCells?: Set<string> // clés "r-c" des confettis à surligner
) {
  const offsetX = RULER_W;
  const offsetY = RULER_H;

  // Fond
  ctx.fillStyle = "#e8e3da";
  ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

  // Cellules
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = grid[r]?.[c];
      const x = offsetX + c * zoom;
      const y = offsetY + r * zoom;

      if (cell?.hex) {
        ctx.fillStyle = cell.hex;
        ctx.fillRect(x, y, zoom, zoom);

        // Croix (X) pour les points complets
        if (zoom >= 14) {
          ctx.strokeStyle = "rgba(0,0,0,0.35)";
          ctx.lineWidth = Math.max(0.8, zoom * 0.07);
          ctx.beginPath();
          const pad = zoom * 0.18;
          ctx.moveTo(x + pad, y + pad);
          ctx.lineTo(x + zoom - pad, y + zoom - pad);
          ctx.moveTo(x + zoom - pad, y + pad);
          ctx.lineTo(x + pad, y + zoom - pad);
          ctx.stroke();
        }

        // Surligné confetti (rouge semi-transparent avec bordure)
        if (confettiCells?.has(`${r}-${c}`)) {
          ctx.fillStyle = "rgba(196, 113, 74, 0.72)";
          ctx.fillRect(x, y, zoom, zoom);
          ctx.strokeStyle = "#C4714A";
          ctx.lineWidth = 2;
          ctx.strokeRect(x + 1, y + 1, zoom - 2, zoom - 2);
        }
      } else {
        // Cellule vide
        ctx.fillStyle = "transparent";
        ctx.clearRect(x, y, zoom, zoom);
      }

      // Grille
      ctx.strokeStyle = `rgba(180,170,160,${zoom < 20 ? 0.25 : 0.45})`;
      ctx.lineWidth = 0.5;
      ctx.strokeRect(x, y, zoom, zoom);
    }
  }

  // Règle colonnes
  ctx.fillStyle = "#9aaa9b";
  ctx.font = `${zoom < 24 ? 7 : 9}px monospace`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  for (let c = 0; c < cols; c++) {
    if ((c + 1) % 5 === 0) {
      ctx.fillText(String(c + 1), offsetX + c * zoom + zoom / 2, RULER_H / 2);
    }
  }

  // Règle lignes
  ctx.textAlign = "right";
  for (let r = 0; r < rows; r++) {
    if ((r + 1) % 5 === 0) {
      ctx.fillText(String(r + 1), RULER_W - 2, offsetY + r * zoom + zoom / 2);
    }
  }
}

export default function ConfettiSplitOverlay({
  grid, rows, cols, zoom, threshold, splitPos, onSplitPosChange, confettiCount, onApply,
}: Props) {
  const beforeCanvasRef = useRef<HTMLCanvasElement>(null);
  const afterCanvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const [isHoveringDivider, setIsHoveringDivider] = useState(false);

  const canvasW = RULER_W + cols * zoom;
  const canvasH = RULER_H + rows * zoom;

  // Calcul des confettis (avant)
  const confettiSet = useCallback((): Set<string> => {
    const s = new Set<string>();
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cell = grid[r]?.[c];
        if (!cell?.dmc) continue;
        const neighbors = [[-1, 0], [1, 0], [0, -1], [0, 1]].filter(([dr, dc]) => {
          const nr = r + (dr ?? 0), nc = c + (dc ?? 0);
          return nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr]?.[nc]?.dmc === cell.dmc;
        }).length;
        if (neighbors < threshold) s.add(`${r}-${c}`);
      }
    }
    return s;
  }, [grid, rows, cols, threshold]);

  // Calcul des confettis restants après nettoyage
  const afterConfettiCount = useMemo(() => {
    const cleanGrid = computeCleanGrid(grid, rows, cols, threshold);
    let count = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cell = cleanGrid[r]?.[c];
        if (!cell?.dmc) continue;
        const neighbors = [[-1, 0], [1, 0], [0, -1], [0, 1]].filter(([dr, dc]) => {
          const nr = r + (dr ?? 0), nc = c + (dc ?? 0);
          return nr >= 0 && nr < rows && nc >= 0 && nc < cols && cleanGrid[nr]?.[nc]?.dmc === cell.dmc;
        }).length;
        if (neighbors < threshold) count++;
      }
    }
    return count;
  }, [grid, rows, cols, threshold]);

  // Dessiner les deux Canvas
  useEffect(() => {
    const beforeCtx = beforeCanvasRef.current?.getContext("2d");
    const afterCtx = afterCanvasRef.current?.getContext("2d");
    if (!beforeCtx || !afterCtx) return;

    const cSet = confettiSet();
    const cleanGrid = computeCleanGrid(grid, rows, cols, threshold);

    drawGrid(beforeCtx, grid, rows, cols, zoom, cSet);
    drawGrid(afterCtx, cleanGrid, rows, cols, zoom);
  }, [grid, rows, cols, zoom, threshold, confettiSet]);

  // Gestion du drag
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;

    const onMove = (ev: MouseEvent) => {
      if (!isDragging.current || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const pct = Math.max(5, Math.min(95, ((ev.clientX - rect.left) / rect.width) * 100));
      onSplitPosChange(pct);
    };
    const onUp = () => {
      isDragging.current = false;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }, [onSplitPosChange]);

  // Touch support
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    const onMove = (ev: TouchEvent) => {
      if (!containerRef.current) return;
      const touch = ev.touches[0];
      if (!touch) return;
      const rect = containerRef.current.getBoundingClientRect();
      const pct = Math.max(5, Math.min(95, ((touch.clientX - rect.left) / rect.width) * 100));
      onSplitPosChange(pct);
    };
    const onEnd = () => {
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onEnd);
    };
    window.addEventListener("touchmove", onMove, { passive: false });
    window.addEventListener("touchend", onEnd);
  }, [onSplitPosChange]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 rounded-2xl overflow-hidden z-30"
      style={{
        border: "2px solid rgba(196,113,74,0.5)",
        boxShadow: "0 0 0 4px rgba(196,113,74,0.08)",
        cursor: isDragging.current ? "col-resize" : "default",
      }}
    >
      {/* Canvas AVANT (gauche) — clippé à droite du diviseur */}
      <div
        className="absolute inset-0"
        style={{ clipPath: `inset(0 ${100 - splitPos}% 0 0)` }}
      >
        <canvas
          ref={beforeCanvasRef}
          width={canvasW}
          height={canvasH}
          style={{ display: "block", imageRendering: "pixelated" }}
        />
        {/* Label AVANT */}
        <div
          className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded-full select-none"
          style={{ background: "#C4714A", color: "white", boxShadow: "0 2px 6px rgba(196,113,74,0.4)" }}
        >
          AVANT — {confettiCount} confetti{confettiCount !== 1 ? "s" : ""}
        </div>
      </div>

      {/* Canvas APRÈS (droite) — clippé à gauche du diviseur */}
      <div
        className="absolute inset-0"
        style={{ clipPath: `inset(0 0 0 ${splitPos}%)` }}
      >
        <canvas
          ref={afterCanvasRef}
          width={canvasW}
          height={canvasH}
          style={{ display: "block", imageRendering: "pixelated" }}
        />
        {/* Label APRÈS */}
        <div
          className="absolute top-3 right-3 text-[10px] font-bold px-2.5 py-1 rounded-full select-none"
          style={{ background: "#7A9E7E", color: "white", boxShadow: "0 2px 6px rgba(122,158,126,0.4)" }}
        >
          APRÈS — {afterConfettiCount} confetti{afterConfettiCount !== 1 ? "s" : ""}
        </div>
      </div>

      {/* Diviseur glissable */}
      <div
        className="absolute top-0 bottom-0 z-40"
        style={{
          left: `calc(${splitPos}% - 2px)`,
          width: 4,
          background: isHoveringDivider
            ? "#C4714A"
            : "rgba(196,113,74,0.8)",
          cursor: "col-resize",
          transition: "background 0.15s",
        }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        onMouseEnter={() => setIsHoveringDivider(true)}
        onMouseLeave={() => setIsHoveringDivider(false)}
      >
        {/* Poignée centrale */}
        <div
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex items-center justify-center rounded-full select-none"
          style={{
            width: 32,
            height: 32,
            background: "#C4714A",
            boxShadow: "0 2px 10px rgba(196,113,74,0.6), 0 0 0 3px white",
            fontSize: 12,
            color: "white",
            fontWeight: "bold",
          }}
        >
          ◄►
        </div>
      </div>

      {/* Bouton Appliquer — flottant en bas au centre */}
      <div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2"
      >
        <button
          onClick={onApply}
          className="flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all"
          style={{
            background: "linear-gradient(135deg, #C4714A, #a85a38)",
            color: "white",
            boxShadow: "0 4px 14px rgba(196,113,74,0.5)",
          }}
        >
          ✂ Appliquer — éliminer {confettiCount} confetti{confettiCount !== 1 ? "s" : ""}
        </button>
      </div>
    </div>
  );
}
