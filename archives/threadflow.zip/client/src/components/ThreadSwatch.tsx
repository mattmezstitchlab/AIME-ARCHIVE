import React from 'react';

/**
 * ThreadSwatch — Bobine de fil réaliste
 * Rendu SVG avec fibres torsadées, reflets soyeux et ombre neumorphique
 * Respecte la couleur DMC exacte passée en prop
 */

interface ThreadSwatchProps {
  color: string;        // Couleur hex DMC ex: "#C4714A"
  name?: string;        // Nom DMC ex: "Terracotta"
  number?: string;      // Numéro DMC ex: "356"
  selected?: boolean;
  size?: "sm" | "md" | "lg";
  onClick?: () => void;
  showLabel?: boolean;
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) }
    : { r: 122, g: 158, b: 126 };
}

function lighten(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  const lr = Math.min(255, r + amount);
  const lg = Math.min(255, g + amount);
  const lb = Math.min(255, b + amount);
  return `rgb(${lr},${lg},${lb})`;
}

function darken(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  const dr = Math.max(0, r - amount);
  const dg = Math.max(0, g - amount);
  const db = Math.max(0, b - amount);
  return `rgb(${dr},${dg},${db})`;
}

export function ThreadSwatch({
  color,
  name,
  number,
  selected = false,
  size = "md",
  onClick,
  showLabel = false,
}: ThreadSwatchProps) {
  const sizes = {
    sm: { w: 44, h: 44, r: 10 },
    md: { w: 60, h: 60, r: 14 },
    lg: { w: 80, h: 80, r: 18 },
  };
  const { w, h, r } = sizes[size];

  const light = lighten(color, 55);
  const mid = lighten(color, 20);
  const dark = darken(color, 30);
  const vdark = darken(color, 55);
  const { r: cr, g: cg, b: cb } = hexToRgb(color);

  // Génère des lignes de fibres torsadées
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const fibers: React.ReactElement<any>[] = [];
  const numFibers = 12;
  for (let i = 0; i < numFibers; i++) {
    const y = (h / numFibers) * i + h / (numFibers * 2);
    const amplitude = 2.5;
    const freq = 0.18;
    const phase = (i * Math.PI * 2) / numFibers;
    // Courbe sinusoïdale pour simuler la torsion du fil
    const points: string[] = [];
    for (let x = 0; x <= w; x += 2) {
      const py = y + Math.sin(x * freq + phase) * amplitude;
      points.push(`${x},${py}`);
    }
    const opacity = 0.12 + (i % 3) * 0.06;
    const strokeColor = i % 2 === 0 ? light : dark;
    fibers.push(
      <polyline
        key={i}
        points={points.join(" ")}
        fill="none"
        stroke={strokeColor}
        strokeWidth={0.8}
        opacity={opacity}
      />
    );
  }

  return (
    <div
      className={`thread-swatch ${selected ? "selected" : ""}`}
      style={{
        width: w,
        height: h,
        borderRadius: r,
        cursor: onClick ? "pointer" : "default",
        flexShrink: 0,
      }}
      onClick={onClick}
      title={number ? `DMC ${number} — ${name}` : name}
    >
      <svg
        width={w}
        height={h}
        viewBox={`0 0 ${w} ${h}`}
        style={{ display: "block", borderRadius: r }}
      >
        <defs>
          {/* Gradient principal — couleur du fil */}
          <linearGradient id={`grad-${number || color.replace("#", "")}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={light} />
            <stop offset="30%" stopColor={mid} />
            <stop offset="60%" stopColor={color} />
            <stop offset="100%" stopColor={vdark} />
          </linearGradient>

          {/* Reflet soyeux en haut-gauche */}
          <radialGradient id={`shine-${number || color.replace("#", "")}`} cx="30%" cy="25%" r="50%">
            <stop offset="0%" stopColor="rgba(255,255,255,0.45)" />
            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
          </radialGradient>

          {/* Ombre en bas-droite */}
          <radialGradient id={`shadow-${number || color.replace("#", "")}`} cx="75%" cy="80%" r="50%">
            <stop offset="0%" stopColor={`rgba(${Math.max(0,cr-80)},${Math.max(0,cg-80)},${Math.max(0,cb-80)},0.5)`} />
            <stop offset="100%" stopColor="rgba(0,0,0,0)" />
          </radialGradient>

          {/* Clip pour arrondir */}
          <clipPath id={`clip-${number || color.replace("#", "")}`}>
            <rect width={w} height={h} rx={r} ry={r} />
          </clipPath>
        </defs>

        <g clipPath={`url(#clip-${number || color.replace("#", "")})`}>
          {/* Fond couleur principale */}
          <rect
            width={w}
            height={h}
            fill={`url(#grad-${number || color.replace("#", "")})`}
          />

          {/* Fibres torsadées */}
          {fibers}

          {/* Reflet soyeux */}
          <rect
            width={w}
            height={h}
            fill={`url(#shine-${number || color.replace("#", "")})`}
          />

          {/* Ombre douce */}
          <rect
            width={w}
            height={h}
            fill={`url(#shadow-${number || color.replace("#", "")})`}
          />

          {/* Lignes de fil horizontales (texture bobine) */}
          {Array.from({ length: Math.floor(h / 5) }).map((_, i) => (
            <line
              key={`hline-${i}`}
              x1={0}
              y1={i * 5 + 2.5}
              x2={w}
              y2={i * 5 + 2.5}
              stroke={i % 2 === 0 ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)"}
              strokeWidth={0.5}
            />
          ))}

          {/* Bord intérieur pour effet de profondeur */}
          <rect
            width={w}
            height={h}
            rx={r}
            ry={r}
            fill="none"
            stroke="rgba(255,255,255,0.25)"
            strokeWidth={1.5}
          />
        </g>

        {/* Numéro DMC si petit */}
        {number && size === "lg" && (
          <text
            x={w / 2}
            y={h - 8}
            textAnchor="middle"
            fontSize={10}
            fontWeight="600"
            fontFamily="DM Sans, sans-serif"
            fill="rgba(255,255,255,0.85)"
            style={{ textShadow: "0 1px 2px rgba(0,0,0,0.5)" }}
          >
            {number}
          </text>
        )}
      </svg>

      {/* Label sous le swatch */}
      {showLabel && (name || number) && (
        <div
          style={{
            textAlign: "center",
            fontSize: "0.65rem",
            fontWeight: 600,
            color: "var(--neu-slate)",
            marginTop: "0.25rem",
            lineHeight: 1.2,
          }}
        >
          {number && <div style={{ opacity: 0.7 }}>DMC {number}</div>}
          {name && <div>{name}</div>}
        </div>
      )}
    </div>
  );
}

export default ThreadSwatch;
