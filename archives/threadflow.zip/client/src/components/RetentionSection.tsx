import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { BookOpen, TrendingUp, Library, Heart, LucideIcon } from "lucide-react";

const N = {
  bg: "#e8e3da",
  raised: "8px 8px 20px #c4bfb6, -8px -8px 20px #ffffff",
  raisedSm: "4px 4px 10px #c4bfb6, -4px -4px 10px #ffffff",
  raisedLg: "14px 14px 32px #c4bfb6, -14px -14px 32px #ffffff",
  inset: "inset 4px 4px 10px #c4bfb6, inset -4px -4px 10px #ffffff",
  terracotta: "#C4714A",
  sage: "#7A9E7E",
  slate: "#3D4A3E",
  muted: "#6b7a6c",
  gold: "#C9A84C",
};

const retentionMechanics = [
  {
    icon: TrendingUp,
    title: "L'Inventaire Vivant et Prédictif",
    description:
      "Chaque point coché déduit automatiquement la longueur de fil consommée. Après 6 mois, ThreadFlow prédit vos besoins avant même que vous les ressentiez.",
    value: "Précision prédictive sur les stocks",
    cost: "Perte de données sur des mois de suivi",
    color: N.sage,
  },
  {
    icon: BookOpen,
    title: "Stitch Diary™ — Le Journal Émotionnel",
    description:
      "Chaque session est enregistrée automatiquement. À la fin d'un projet, ThreadFlow génère un timelapse vidéo de votre progression, prêt à partager sur Instagram ou TikTok.",
    value: "Archive visuelle et émotionnelle",
    cost: "Perte de l'historique de toutes vos créations",
    color: N.terracotta,
  },
  {
    icon: Library,
    title: "La Bibliothèque Annotée",
    description:
      "Chaque patron importé s'enrichit au fil du temps : notes personnelles, substitutions de couleurs, photos du résultat final. Un catalogue personnel irremplaçable.",
    value: "Notes, substitutions, photos",
    cost: "Perte d'un catalogue personnel unique",
    color: N.gold,
  },
  {
    icon: Heart,
    title: "Les Connexions Sociales",
    description:
      "Vos amies, vos SALs en cours, votre statut dans la communauté. ThreadFlow tisse des liens qui vont bien au-delà du logiciel.",
    value: "Amies, SALs en cours",
    cost: "Rupture des liens communautaires",
    color: "#9B7FA8",
  },
];

type RetentionItem = typeof retentionMechanics[0];

function RetentionCard({ item, index }: { item: RetentionItem; index: number }) {
  const { ref, isVisible } = useIntersectionObserver();
  const Icon = item.icon as LucideIcon;
  return (
    <div
      ref={ref as React.RefObject<HTMLDivElement>}
      style={{
        borderRadius: 24, padding: "1.5rem",
        background: N.bg, boxShadow: N.raised,
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(24px)",
        transition: `all 0.6s ease ${index * 0.1}s`,
      }}
    >
      <div style={{
        width: 44, height: 44, borderRadius: 14,
        background: N.bg, boxShadow: N.raisedSm,
        display: "flex", alignItems: "center", justifyContent: "center",
        marginBottom: "1rem",
      }}>
        <Icon size={20} color={item.color} />
      </div>
      <h3 style={{
        fontFamily: "'Cormorant Garamond', Georgia, serif",
        fontSize: "1.2rem", fontWeight: 700,
        color: N.slate, marginBottom: "0.5rem",
      }}>
        {item.title}
      </h3>
      <p style={{ fontSize: "0.875rem", color: N.muted, lineHeight: 1.65, marginBottom: "1rem" }}>
        {item.description}
      </p>
      <div style={{
        padding: "8px 12px", borderRadius: 10,
        background: N.bg, boxShadow: N.inset,
        borderLeft: `3px solid ${item.color}`,
        fontSize: "0.78rem", fontWeight: 600, color: item.color,
      }}>
        ✓ {item.value}
      </div>
    </div>
  );
}

export default function RetentionSection() {
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();
  const { ref: imgRef, isVisible: imgVisible } = useIntersectionObserver();

  return (
    <section style={{ background: N.bg, padding: "6rem 0" }}>
      <div className="container">
        {/* Header */}
        <div
          ref={titleRef as React.RefObject<HTMLDivElement>}
          style={{
            textAlign: "center", marginBottom: "4rem",
            opacity: titleVisible ? 1 : 0,
            transform: titleVisible ? "translateY(0)" : "translateY(24px)",
            transition: "all 0.7s ease",
          }}
        >
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 8,
            padding: "8px 18px", borderRadius: 50,
            background: N.bg, boxShadow: N.raisedSm,
            marginBottom: "1.5rem",
          }}>
            <span style={{ fontSize: "0.78rem", fontWeight: 700, color: N.sage, letterSpacing: "0.06em", textTransform: "uppercase" }}>
              Rétention Éthique
            </span>
          </div>
          <h2 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: "clamp(2.2rem, 4vw, 3.5rem)",
            fontWeight: 700, color: N.slate,
            lineHeight: 1.15, marginBottom: "1rem",
          }}>
            ThreadFlow devient votre{" "}
            <em style={{ fontStyle: "normal", color: N.terracotta }}>
              cerveau externe
            </em>
            .
          </h2>
          <p style={{ fontSize: "1rem", color: N.muted, maxWidth: 560, margin: "0 auto", lineHeight: 1.7 }}>
            Plus vous utilisez ThreadFlow, plus vous y stockez de valeur. Le lock-in est éthique —
            il repose sur la valeur accumulée, pas sur des obstacles contractuels.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "3rem", alignItems: "center" }}>
          {/* Cards */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
            {retentionMechanics.map((item, i) => (
              <RetentionCard key={item.title} item={item} index={i} />
            ))}
          </div>

          {/* Stitch Diary illustration */}
          <div
            ref={imgRef as React.RefObject<HTMLDivElement>}
            style={{
              opacity: imgVisible ? 1 : 0,
              transform: imgVisible ? "translateX(0)" : "translateX(24px)",
              transition: "all 0.7s ease 0.2s",
            }}
          >
            <div style={{ borderRadius: 28, overflow: "hidden", boxShadow: N.raisedLg }}>
              <img
                src="/manus-storage/feature_stitch_diary_c90e4156.png"
                alt="Stitch Diary — journal de broderie ThreadFlow"
                style={{ width: "100%", height: "auto", display: "block" }}
              />
            </div>

            {/* Quote */}
            <div style={{
              marginTop: "1.5rem", padding: "1.25rem 1.5rem",
              borderRadius: 20, background: N.bg, boxShadow: N.raised,
              borderLeft: `4px solid ${N.terracotta}`,
            }}>
              <p style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: "1.15rem", fontStyle: "italic", fontWeight: 600, color: N.slate,
              }}>
                "Quitter ThreadFlow, c'est abandonner son histoire de brodeuse."
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
