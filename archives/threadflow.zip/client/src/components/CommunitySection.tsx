import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { Share2, MessageCircle, Gift, LucideIcon } from "lucide-react";

const N = {
  bg: "#e8e3da",
  raised: "8px 8px 20px #c4bfb6, -8px -8px 20px #ffffff",
  raisedSm: "4px 4px 10px #c4bfb6, -4px -4px 10px #ffffff",
  raisedLg: "14px 14px 32px #c4bfb6, -14px -14px 32px #ffffff",
  inset: "inset 4px 4px 10px #c4bfb6, inset -4px -4px 10px #ffffff",
  terracotta: "#C4714A",
  sage: "#7A9E7E",
  slate: "#3D4A3E",
  muted: "#6b7a6c",
  gold: "#C9A84C",
};

const communityFeatures = [
  {
    icon: Share2,
    title: "WIP Card Automatique",
    description:
      "Après chaque session, ThreadFlow génère une carte élégante avec votre photo, les stats de la session et le pourcentage de complétion. Partagez en un clic sur Instagram avec #ThreadFlow.",
    color: N.terracotta,
  },
  {
    icon: MessageCircle,
    title: "Stitch Hub Contextuel",
    description:
      "Plutôt qu'un flux social générique, le Stitch Hub est contextuel au patron. Voyez combien de brodeuses travaillent sur le même patron en ce moment dans le monde.",
    color: N.sage,
  },
  {
    icon: Gift,
    title: "Needle Points — Parrainage Généreux",
    description:
      "Partagez une WIP Card, une amie télécharge ThreadFlow : vous recevez toutes les deux un mois de Pro offert. Transparent, généreux, aligné avec la culture de partage de la communauté.",
    color: N.gold,
  },
];

type CommunityFeature = typeof communityFeatures[0];

function CommunityFeatureItem({ feat, index }: { feat: CommunityFeature; index: number }) {
  const { ref, isVisible } = useIntersectionObserver();
  const Icon = feat.icon as LucideIcon;
  return (
    <div
      ref={ref as React.RefObject<HTMLDivElement>}
      style={{
        display: "flex", gap: 16, padding: "1.25rem", borderRadius: 18,
        background: N.bg, boxShadow: N.raisedSm,
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateX(0)" : "translateX(24px)",
        transition: `all 0.6s ease ${index * 0.12}s`,
      }}
    >
      <div style={{
        width: 44, height: 44, borderRadius: 14, flexShrink: 0,
        background: N.bg, boxShadow: N.raisedSm,
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <Icon size={20} color={feat.color} />
      </div>
      <div>
        <h3 style={{
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontSize: "1.2rem", fontWeight: 700,
          color: N.slate, marginBottom: 4,
        }}>
          {feat.title}
        </h3>
        <p style={{ fontSize: "0.875rem", color: N.muted, lineHeight: 1.65 }}>
          {feat.description}
        </p>
      </div>
    </div>
  );
}

export default function CommunitySection() {
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();
  const { ref: imgRef, isVisible: imgVisible } = useIntersectionObserver();

  return (
    <section id="community" style={{ background: N.bg, padding: "6rem 0" }}>
      <div className="container">
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: "4rem",
          alignItems: "center",
        }}>
          {/* WIP Card showcase */}
          <div
            ref={imgRef as React.RefObject<HTMLDivElement>}
            style={{
              position: "relative",
              opacity: imgVisible ? 1 : 0,
              transform: imgVisible ? "translateY(0)" : "translateY(24px)",
              transition: "all 0.7s ease",
            }}
          >
            <div style={{ borderRadius: 28, overflow: "hidden", boxShadow: N.raisedLg, maxWidth: 380, margin: "0 auto" }}>
              <img
                src="/manus-storage/wip_card_example_8f51a281.png"
                alt="WIP Card ThreadFlow — exemple de partage Instagram"
                style={{ width: "100%", height: "auto", display: "block" }}
              />
            </div>

            {/* Community stats floating */}
            <div style={{
              position: "absolute", bottom: -16, right: 0,
              padding: "12px 18px", borderRadius: 18,
              background: N.bg, boxShadow: N.raised,
            }}>
              <div style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: "1.8rem", fontWeight: 700, color: N.terracotta,
              }}>
                102k
              </div>
              <div style={{ fontSize: "0.75rem", color: N.muted }}>
                membres r/CrossStitch
              </div>
            </div>
          </div>

          {/* Text */}
          <div>
            <div
              ref={titleRef as React.RefObject<HTMLDivElement>}
              style={{
                opacity: titleVisible ? 1 : 0,
                transform: titleVisible ? "translateY(0)" : "translateY(24px)",
                transition: "all 0.7s ease",
              }}
            >
              <div style={{
                display: "inline-flex", alignItems: "center", gap: 8,
                padding: "8px 18px", borderRadius: 50,
                background: N.bg, boxShadow: N.raisedSm,
                marginBottom: "1.5rem",
              }}>
                <span style={{ fontSize: "0.78rem", fontWeight: 700, color: N.sage, letterSpacing: "0.06em", textTransform: "uppercase" }}>
                  Communauté Sans Forçage
                </span>
              </div>
              <h2 style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: "clamp(2.2rem, 4vw, 3.5rem)",
                fontWeight: 700, color: N.slate,
                lineHeight: 1.15, marginBottom: "1rem",
              }}>
                Brodez seule à 23h, mais ne soyez{" "}
                <em style={{ fontStyle: "normal", color: N.terracotta }}>
                  jamais vraiment seule.
                </em>
              </h2>
              <p style={{ fontSize: "1rem", color: N.muted, lineHeight: 1.7, marginBottom: "2rem" }}>
                La communauté des brodeuses existe déjà, massivement, sur Reddit, Instagram, Facebook
                et FlossTube. ThreadFlow s'insère dans ces rituels existants et les amplifie.
              </p>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
              {communityFeatures.map((feat, i) => (
                <CommunityFeatureItem key={feat.title} feat={feat} index={i} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
