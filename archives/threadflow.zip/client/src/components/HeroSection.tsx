import { useEffect, useState } from "react";
import { ArrowRight, Star, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

const N = {
  bg: "#e8e3da",
  raised: "8px 8px 20px #c4bfb6, -8px -8px 20px #ffffff",
  raisedSm: "4px 4px 10px #c4bfb6, -4px -4px 10px #ffffff",
  raisedLg: "14px 14px 32px #c4bfb6, -14px -14px 32px #ffffff",
  inset: "inset 4px 4px 10px #c4bfb6, inset -4px -4px 10px #ffffff",
  terracotta: "#C4714A",
  terracottaGrad: "linear-gradient(145deg, #d4845d, #C4714A)",
  sage: "#7A9E7E",
  slate: "#3D4A3E",
  muted: "#6b7a6c",
  gold: "#C9A84C",
};

export default function HeroSection() {
  const [visible, setVisible] = useState(false);
  const { data: user } = trpc.auth.me.useQuery();
  const { data: countData } = trpc.waitlist.count.useQuery(undefined, { refetchInterval: 60000 });
  const waitlistCount = countData?.count ?? 0;

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section style={{
      minHeight: "100vh",
      background: N.bg,
      display: "flex",
      alignItems: "center",
      paddingTop: 80,
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Aida grid texture */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none", opacity: 0.35,
        backgroundImage: `
          linear-gradient(rgba(196,191,182,0.6) 1px, transparent 1px),
          linear-gradient(90deg, rgba(196,191,182,0.6) 1px, transparent 1px)
        `,
        backgroundSize: "20px 20px",
      }} />

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 1.5rem", width: "100%", position: "relative", zIndex: 1 }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
          gap: "4rem",
          alignItems: "center",
          padding: "5rem 0 3rem",
        }}>

          {/* LEFT — Text */}
          <div style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(28px)",
            transition: "all 0.7s ease",
          }}>
            {/* Badge pill */}
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 8,
              padding: "8px 18px", borderRadius: 50,
              background: N.bg, boxShadow: N.raisedSm,
              marginBottom: "1.75rem",
            }}>
              <Sparkles size={14} color={N.sage} />
              <span style={{ fontSize: "0.78rem", fontWeight: 700, color: N.sage, letterSpacing: "0.06em", textTransform: "uppercase" }}>
                Bêta ouverte — Mai 2026
              </span>
            </div>

            {/* H1 */}
            <h1 style={{
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              fontSize: "clamp(3.2rem, 6vw, 5.5rem)",
              fontWeight: 700, lineHeight: 1.04,
              color: N.slate, marginBottom: "1.5rem",
              letterSpacing: "-0.025em",
            }}>
              Le <span style={{ color: N.terracotta }}>Figma</span><br />du point de croix.
            </h1>

            {/* Subtitle */}
            <p style={{
              fontSize: "1.1rem", color: N.muted, lineHeight: 1.75,
              marginBottom: "2rem", maxWidth: 480,
            }}>
              ThreadFlow est le premier compagnon de broderie avec IA. Scannez vos fils en 45 secondes,
              optimisez vos patrons, brodez en communauté.
            </p>

            {/* Social proof card */}
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 14,
              padding: "12px 20px", borderRadius: 16,
              background: N.bg, boxShadow: N.raisedSm,
              marginBottom: "2rem",
            }}>
              <div style={{ display: "flex" }}>
                {[N.terracotta, N.sage, N.gold, "#8B7355"].map((c, i) => (
                  <div key={i} style={{
                    width: 34, height: 34, borderRadius: "50%",
                    background: c, border: `3px solid ${N.bg}`,
                    marginLeft: i > 0 ? -10 : 0,
                    boxShadow: "2px 2px 6px #c4bfb6",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "white", fontSize: "0.7rem", fontWeight: 700,
                  }}>
                    {["M","S","A","L"][i]}
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", gap: 2, marginRight: 4 }}>
                {[1,2,3,4,5].map(i => <Star key={i} size={13} fill={N.gold} color={N.gold} />)}
              </div>
              <span style={{ fontSize: "0.875rem", color: N.muted }}>
                {waitlistCount > 0
                  ? <><strong style={{ color: N.slate }}>{waitlistCount.toLocaleString("fr-FR")}</strong> brodeuses inscrites</>
                  : <><strong style={{ color: N.slate }}>Soyez la première</strong> à rejoindre</>
                }
              </span>
            </div>

            {/* CTAs */}
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
              <a
                href={user ? "/app" : "#waitlist"}
                style={{
                  display: "inline-flex", alignItems: "center", gap: 10,
                  padding: "14px 28px", borderRadius: 16,
                  background: N.terracottaGrad,
                  boxShadow: "6px 6px 16px #c4bfb6, -2px -2px 8px #ffffff",
                  color: "white", fontWeight: 700, fontSize: "1rem",
                  textDecoration: "none", transition: "all 0.2s ease",
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; }}
              >
                {user ? "Mon espace broderie" : "Rejoindre la liste d'attente"}
                <ArrowRight size={18} />
              </a>
              <a
                href="/demo"
                style={{
                  display: "inline-flex", alignItems: "center", gap: 8,
                  padding: "14px 24px", borderRadius: 16,
                  background: N.bg, boxShadow: N.raised,
                  color: N.slate, fontWeight: 600, fontSize: "1rem",
                  textDecoration: "none", transition: "all 0.2s ease",
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = N.inset; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = N.raised; }}
              >
                ✨ Essayer la démo
              </a>
            </div>

            <p style={{ marginTop: "1.25rem", fontSize: "0.8rem", color: N.muted }}>
              Sans carte bancaire · iOS, Android &amp; Web · Synchronisation multi-appareils
            </p>
          </div>

          {/* RIGHT — Neumorphic app mockup */}
          <div style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(32px)",
            transition: "all 0.9s ease 0.2s",
            display: "flex", justifyContent: "center",
          }}>
            <div style={{ position: "relative", width: "100%", maxWidth: 460 }}>
              {/* Main card */}
              <div style={{
                borderRadius: 28, background: N.bg,
                boxShadow: N.raisedLg, padding: "1.75rem",
              }}>
                {/* App top bar */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.25rem" }}>
                  <div style={{
                    padding: "7px 16px", borderRadius: 50,
                    background: N.bg, boxShadow: N.inset,
                    fontSize: "0.78rem", fontWeight: 600, color: N.sage,
                  }}>
                    🌿 Smart Pathing™ actif
                  </div>
                  <div style={{
                    width: 36, height: 36, borderRadius: 10,
                    background: N.bg, boxShadow: N.raisedSm,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: N.muted, fontSize: "1rem",
                  }}>⚙</div>
                </div>

                {/* Grid preview — inset */}
                <div style={{
                  borderRadius: 20, background: N.bg,
                  boxShadow: N.inset, padding: "1rem",
                  marginBottom: "1.25rem", aspectRatio: "1",
                  overflow: "hidden", position: "relative",
                }}>
                  <img
                    src="/manus-storage/hero_illustration_58aa4ed4.png"
                    alt="Patron de broderie ThreadFlow"
                    style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 12 }}
                  />
                  {/* Neon path effect */}
                  <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
                    <defs>
                      <filter id="neon">
                        <feGaussianBlur stdDeviation="3" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                      </filter>
                    </defs>
                    <polyline
                      points="20,80 40,80 40,60 80,60 80,40 120,40 120,60 160,60 160,80 200,80 200,100 240,100"
                      fill="none" stroke="#C9A84C" strokeWidth="2.5"
                      strokeLinecap="round" strokeLinejoin="round"
                      filter="url(#neon)" opacity="0.9"
                    />
                    <circle cx="240" cy="100" r="4" fill="#C9A84C" filter="url(#neon)" />
                  </svg>
                </div>

                {/* Thread savings */}
                <div style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "12px 16px", borderRadius: 14,
                  background: N.bg, boxShadow: N.raisedSm,
                  marginBottom: "1rem",
                }}>
                  <div style={{
                    width: 38, height: 38, borderRadius: 10,
                    background: N.bg, boxShadow: N.inset,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "1.1rem",
                  }}>🌿</div>
                  <div>
                    <div style={{ fontWeight: 700, color: N.slate, fontSize: "0.95rem" }}>Économisez 3,2m de fil</div>
                    <div style={{ fontSize: "0.75rem", color: N.muted }}>chemin optimal calculé par l'IA</div>
                  </div>
                </div>

                {/* Thread palette row */}
                <div style={{
                  display: "flex", gap: 8,
                  padding: "10px 14px", borderRadius: 14,
                  background: N.bg, boxShadow: N.inset,
                  alignItems: "center",
                }}>
                  {[
                    { color: "#C4714A", active: true },
                    { color: "#7A9E7E", active: false },
                    { color: "#4a7a4e", active: false },
                    { color: "#b8a882", active: false },
                    { color: "#C9A84C", active: false },
                  ].map((t, i) => (
                    <div key={i} style={{
                      flex: 1, aspectRatio: "1", borderRadius: 10,
                      background: N.bg,
                      boxShadow: t.active
                        ? `inset 3px 3px 8px #c4bfb6, inset -3px -3px 8px #ffffff, 0 0 0 2.5px ${t.color}`
                        : N.raisedSm,
                      overflow: "hidden", position: "relative",
                    }}>
                      <svg width="100%" height="100%" viewBox="0 0 40 40" style={{ position: "absolute", inset: 0 }}>
                        <defs>
                          <linearGradient id={`g${i}`} x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor={t.color} stopOpacity="0.85" />
                            <stop offset="50%" stopColor={t.color} stopOpacity="1" />
                            <stop offset="100%" stopColor={t.color} stopOpacity="0.65" />
                          </linearGradient>
                        </defs>
                        <rect width="40" height="40" fill={`url(#g${i})`} rx="8" />
                        {[0,5,10,15,20,25,30,35].map(y => (
                          <line key={y} x1="0" y1={y} x2="40" y2={y+5} stroke="rgba(255,255,255,0.18)" strokeWidth="1.5" />
                        ))}
                        {[0,5,10,15,20,25,30,35].map(y => (
                          <line key={`s${y}`} x1="0" y1={y+2.5} x2="40" y2={y+7.5} stroke="rgba(0,0,0,0.07)" strokeWidth="0.8" />
                        ))}
                      </svg>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating badge — top right */}
              <div style={{
                position: "absolute", top: -14, right: -14,
                padding: "10px 16px", borderRadius: 14,
                background: N.bg,
                boxShadow: "6px 6px 16px #c4bfb6, -4px -4px 12px #ffffff",
                fontSize: "0.78rem", color: N.slate, fontWeight: 600,
                whiteSpace: "nowrap",
                animation: "float 4s ease-in-out infinite",
              }}>
                ✅ Scan IA — 147 couleurs
              </div>

              {/* Floating badge — bottom left */}
              <div style={{
                position: "absolute", bottom: -14, left: -14,
                padding: "10px 16px", borderRadius: 14,
                background: N.bg,
                boxShadow: "6px 6px 16px #c4bfb6, -4px -4px 12px #ffffff",
                fontSize: "0.78rem", color: N.slate, fontWeight: 600,
                whiteSpace: "nowrap",
                animation: "float 4s ease-in-out infinite 2s",
              }}>
                🎉 89% des fils déjà en stock
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{ display: "flex", justifyContent: "center", paddingBottom: "2rem" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, opacity: 0.5 }}>
            <span style={{ fontSize: "0.7rem", letterSpacing: "0.15em", textTransform: "uppercase", color: N.muted }}>Découvrir</span>
            <div style={{
              width: 2, height: 32, borderRadius: 2,
              background: N.terracotta,
              animation: "pulse 2s ease-in-out infinite",
            }} />
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
      `}</style>
    </section>
  );
}
