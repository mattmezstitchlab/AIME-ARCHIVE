/*
 * ThreadFlow — Section Manifeste
 * Design: Fond ardoise foncé, typographie Cormorant Garamond en grand, citation centrale
 * Contraste fort, émotionnel
 */
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";

export default function ManifestoSection() {
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();
  const { ref: quoteRef, isVisible: quoteVisible } = useIntersectionObserver();
  const { ref: textRef, isVisible: textVisible } = useIntersectionObserver();

  return (
    <section
      className="py-24 lg:py-40 relative overflow-hidden"
      style={{ background: "#3D4A3E" }}
    >
      {/* Decorative grid */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage:
            "linear-gradient(#d4cfc6 1px, transparent 1px), linear-gradient(90deg, #d4cfc6 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }}
      />

      {/* Decorative blob */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full opacity-5 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, #C4714A, transparent)" }}
      />

      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Label */}
          <div
            ref={titleRef as React.RefObject<HTMLDivElement>}
            className={`transition-all duration-700 ${
              titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <span
              className="pill-badge mb-8 inline-block"
              style={{
                background: "#C4714A33",
                color: "#C4714A",
                border: "1px solid #C4714A66",
              }}
            >
              Notre Manifeste
            </span>
          </div>

          {/* Main quote */}
          <div
            ref={quoteRef as React.RefObject<HTMLDivElement>}
            className={`transition-all duration-1000 delay-100 ${
              quoteVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
            }`}
          >
            <h2
              className="font-['Cormorant_Garamond'] text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-light italic leading-tight mb-12"
              style={{ color: "#F5F0E8" }}
            >
              Pour l'amour du point.
            </h2>
          </div>

          {/* Manifesto text */}
          <div
            ref={textRef as React.RefObject<HTMLDivElement>}
            className={`space-y-6 transition-all duration-700 delay-200 ${
              textVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <p
              className="text-lg md:text-xl leading-relaxed font-light"
              style={{ color: "#D4C5A9" }}
            >
              Nous croyons que la broderie est l'un des derniers actes de résistance contre
              l'immédiateté du monde moderne. Chaque point est une décision consciente.
              Chaque projet est une méditation.
            </p>

            <p
              className="text-lg md:text-xl leading-relaxed font-light"
              style={{ color: "#D4C5A9" }}
            >
              Mais nous croyons aussi que la technologie ne doit pas remplacer l'artisanat —
              elle doit en enlever la friction. Pas la friction qui donne du sens (la patience,
              la précision, la répétition apaisante), mais la friction inutile : les heures perdues
              à vérifier des stocks, à nettoyer des patrons, à chercher le prochain point.
            </p>

            <div
              className="py-8 px-6 rounded-2xl my-8"
              style={{ background: "#3D4A3E80" }}
            >
              <p
                className="font-['Cormorant_Garamond'] text-2xl md:text-3xl font-medium leading-relaxed"
                style={{ color: "#F5F0E8" }}
              >
                ThreadFlow est conçu pour les brodeuses qui veulent passer plus de temps à broder
                et moins de temps à gérer. Pour celles qui brodent seules à 23h, mais ne sont
                jamais vraiment seules.
              </p>
            </div>

            <p
              className="text-lg md:text-xl leading-relaxed font-light"
              style={{ color: "#D4C5A9" }}
            >
              Pour celles qui savent que le prochain point est toujours le plus beau.
            </p>
          </div>

          {/* Divider */}
          <div className="thread-divider my-12 opacity-30" />

          {/* Market context */}
          <div className="grid sm:grid-cols-3 gap-6 text-center">
            {[
              { value: "3,17 Md$", label: "Marché en 2023" },
              { value: "8,07 Md$", label: "Marché prévu en 2032" },
              { value: "+9,8%", label: "Croissance annuelle (CAGR)" },
            ].map((stat) => (
              <div key={stat.value}>
                <div
                  className="font-['Cormorant_Garamond'] text-4xl font-bold mb-1"
                  style={{ color: "#C4714A" }}
                >
                  {stat.value}
                </div>
                <div className="text-sm" style={{ color: "#a09890" }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
