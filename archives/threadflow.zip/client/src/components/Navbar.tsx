import { useState, useEffect } from "react";
import { Menu, X, Scissors } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";

const N = {
  bg: "#e8e3da",
  shadow: "6px 6px 14px #c4bfb6, -6px -6px 14px #ffffff",
  shadowSm: "3px 3px 8px #c4bfb6, -3px -3px 8px #ffffff",
  inset: "inset 3px 3px 8px #c4bfb6, inset -3px -3px 8px #ffffff",
  terracotta: "#C4714A",
  terracottaLight: "#d4845d",
  slate: "#3D4A3E",
  muted: "#6b7a6c",
};

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { data: user } = trpc.auth.me.useQuery();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { window.location.href = "/"; },
  });

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Fonctionnalités", href: "/#features" },
    { label: "Comment ça marche", href: "/#how-it-works" },
    { label: "Démo", href: "/demo" },
    { label: "Blog", href: "/blog" },
    { label: "Tarifs", href: "/#pricing" },
  ];

  return (
    <nav style={{
      position: "fixed",
      top: 0, left: 0, right: 0,
      zIndex: 1000,
      background: N.bg,
      boxShadow: scrolled ? "0 4px 20px #c4bfb6, 0 -2px 8px #ffffff" : "0 2px 10px #c4bfb6, 0 -1px 4px #ffffff",
      transition: "box-shadow 0.3s ease",
    }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 1.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 68 }}>

          {/* Logo */}
          <Link href="/">
            <div style={{ display: "flex", alignItems: "center", gap: 12, cursor: "pointer", textDecoration: "none" }}>
              <div style={{
                width: 42, height: 42,
                borderRadius: 12,
                background: N.bg,
                boxShadow: N.shadowSm,
                display: "flex", alignItems: "center", justifyContent: "center",
                color: N.terracotta,
              }}>
                <Scissors size={20} />
              </div>
              <span style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: "1.5rem",
                fontWeight: 700,
                color: N.slate,
                letterSpacing: "-0.02em",
              }}>
                Thread<span style={{ color: N.terracotta }}>Flow</span>
              </span>
            </div>
          </Link>

          {/* Desktop nav links */}
          <div style={{ display: "flex", alignItems: "center", gap: 6 }} className="hidden md:flex">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                style={{
                  padding: "7px 15px",
                  borderRadius: 10,
                  background: N.bg,
                  boxShadow: "2px 2px 6px #c4bfb6, -2px -2px 6px #ffffff",
                  color: N.slate,
                  fontSize: "0.875rem",
                  fontWeight: 500,
                  textDecoration: "none",
                  transition: "all 0.2s ease",
                  display: "inline-block",
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.boxShadow = "inset 2px 2px 5px #c4bfb6, inset -2px -2px 5px #ffffff";
                  (e.currentTarget as HTMLElement).style.color = N.terracotta;
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.boxShadow = "2px 2px 6px #c4bfb6, -2px -2px 6px #ffffff";
                  (e.currentTarget as HTMLElement).style.color = N.slate;
                }}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA buttons */}
          <div style={{ display: "flex", alignItems: "center", gap: 10 }} className="hidden md:flex">
            {user ? (
              <>
                <Link href="/app">
                  <div style={{
                    padding: "8px 20px",
                    borderRadius: 12,
                    background: `linear-gradient(145deg, ${N.terracottaLight}, ${N.terracotta})`,
                    boxShadow: "4px 4px 10px #c4bfb6, -2px -2px 6px #ffffff",
                    color: "white",
                    fontWeight: 600,
                    fontSize: "0.875rem",
                    cursor: "pointer",
                    textDecoration: "none",
                    display: "inline-block",
                  }}>
                    🧵 Mon espace
                  </div>
                </Link>
                <button
                  onClick={() => logoutMutation.mutate()}
                  style={{
                    padding: "8px 16px",
                    borderRadius: 10,
                    background: N.bg,
                    boxShadow: "2px 2px 6px #c4bfb6, -2px -2px 6px #ffffff",
                    color: N.muted,
                    fontSize: "0.875rem",
                    fontWeight: 500,
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Déconnexion
                </button>
              </>
            ) : (
              <>
                <a
                  href={getLoginUrl()}
                  style={{
                    padding: "8px 18px",
                    borderRadius: 10,
                    background: N.bg,
                    boxShadow: "3px 3px 8px #c4bfb6, -3px -3px 8px #ffffff",
                    color: N.slate,
                    fontSize: "0.875rem",
                    fontWeight: 500,
                    textDecoration: "none",
                    display: "inline-block",
                  }}
                >
                  Se connecter
                </a>
                <a
                  href="/#waitlist"
                  style={{
                    padding: "8px 22px",
                    borderRadius: 12,
                    background: `linear-gradient(145deg, ${N.terracottaLight}, ${N.terracotta})`,
                    boxShadow: "4px 4px 10px #c4bfb6, -2px -2px 6px #ffffff",
                    color: "white",
                    fontWeight: 600,
                    fontSize: "0.875rem",
                    textDecoration: "none",
                    display: "inline-block",
                    transition: "all 0.2s ease",
                  }}
                >
                  Essai gratuit 30 jours
                </a>
              </>
            )}
          </div>

          {/* Mobile burger */}
          <button
            className="md:hidden"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{
              width: 42, height: 42,
              borderRadius: 10,
              background: N.bg,
              boxShadow: menuOpen ? N.inset : N.shadowSm,
              border: "none",
              cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
              color: N.slate,
              transition: "all 0.2s ease",
            }}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div style={{
            padding: "1rem 0 1.5rem",
            borderTop: `1px solid #c4bfb6`,
            display: "flex",
            flexDirection: "column",
            gap: 8,
          }}>
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                style={{
                  padding: "10px 16px",
                  borderRadius: 10,
                  background: N.bg,
                  boxShadow: "2px 2px 6px #c4bfb6, -2px -2px 6px #ffffff",
                  color: N.slate,
                  fontWeight: 500,
                  textDecoration: "none",
                  display: "block",
                }}
              >
                {link.label}
              </a>
            ))}
            <a
              href={user ? "/app" : getLoginUrl()}
              style={{
                padding: "12px 16px",
                borderRadius: 12,
                background: `linear-gradient(145deg, ${N.terracottaLight}, ${N.terracotta})`,
                boxShadow: "4px 4px 10px #c4bfb6",
                color: "white",
                fontWeight: 600,
                textDecoration: "none",
                textAlign: "center",
                marginTop: 4,
                display: "block",
              }}
            >
              {user ? "🧵 Mon espace" : "Commencer gratuitement"}
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
