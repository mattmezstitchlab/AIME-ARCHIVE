/*
 * ThreadFlow — Section Stratégie de Lancement
 * Design: Timeline horizontale, 3 phases, fond ivoire avec accents
 */
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { Users, Zap, Award, LucideIcon } from "lucide-react";

const phases = [
  {
    phase: "Pré-lancement",
    timing: "Mois −3 à −1",
    icon: Users,
    title: "Partenariats Designers",
    description:
      "15 créatrices de patrons soigneusement sélectionnées reçoivent un accès gratuit à vie à ThreadFlow Studio. En échange, elles proposent à leurs clientes un lien d'accès anticipé.",
    kpi: "500 inscriptions en liste d'attente",
    color: "#7A9E7E",
    detail: "Une designer Etsy avec 5 000 abonnés Instagram a plus d'impact qu'une campagne publicitaire à 10 000 €.",
  },
  {
    phase: "Lancement",
    timing: "Semaine J",
    icon: Zap,
    title: 'SAL "First Stitch"',
    description:
      "Un Stitch-Along de lancement gratuit, exclusif et magnifique. Le patron est créé avec une artiste reconnue. La première partie se débloque le jour du lancement.",
    kpi: "1 000 téléchargements J+7",
    color: "#C4714A",
    detail: '"Le 15 mars, quelque chose commence. Téléchargez ThreadFlow pour être là."',
  },
  {
    phase: "Post-lancement",
    timing: "Ongoing",
    icon: Award,
    title: 'Programme "Golden Needle"',
    description:
      "Les 1 000 premières utilisatrices reçoivent un badge virtuel permanent \"Golden Needle\" — un statut de fondatrice visible par toute la communauté, avec 3 invitations coupe-file.",
    kpi: "NPS > 70, conversion Free→Pro > 15%",
    color: "#C9A84C",
    detail: "Viralité basée sur l'exclusivité et la générosité — deux valeurs profondément ancrées dans la culture broderie.",
  },
];

type Phase = typeof phases[0];

function PhaseCard({ phase, index }: { phase: Phase; index: number }) {
  const { ref, isVisible } = useIntersectionObserver();
  const Icon = phase.icon as LucideIcon;
  return (
    <div
      ref={ref as React.RefObject<HTMLDivElement>}
      className={`relative transition-all duration-700 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
      }`}
      style={{ transitionDelay: `${index * 150}ms` }}
    >
      {/* Phase icon */}
      <div className="flex justify-center mb-6">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg relative z-10"
          style={{
            background: phase.color,
            boxShadow: `0 8px 24px ${phase.color}40`,
          }}
        >
          <Icon size={24} className="text-white" />
        </div>
      </div>

      {/* Card */}
      <div className="neuro-card p-6 text-center">
        <div
          className="pill-badge mb-3 mx-auto inline-block text-white"
          style={{ background: phase.color }}
        >
          {phase.phase}
        </div>
        <div
          className="text-xs mb-3 font-medium"
          style={{ color: "#6b7a6c" }}
        >
          {phase.timing}
        </div>
        <h3
          className="font-['Cormorant_Garamond'] text-2xl font-semibold mb-3"
          style={{ color: "#3D4A3E" }}
        >
          {phase.title}
        </h3>
        <p className="text-sm leading-relaxed mb-4" style={{ color: "#6b7a6c" }}>
          {phase.description}
        </p>
        <div
          className="text-xs italic p-3 rounded-lg mb-4"
          style={{
            background: `${phase.color}10`,
            color: "#3D4A3E",
          }}
        >
          {phase.detail}
        </div>
        <div
          className="text-xs font-semibold px-3 py-1.5 rounded-lg inline-block"
          style={{
            background: `${phase.color}15`,
            color: phase.color,
          }}
        >
          KPI : {phase.kpi}
        </div>
      </div>
    </div>
  );
}

export default function LaunchSection() {
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();

  return (
    <section
      className="py-24 lg:py-32"
      style={{ background: "#e8e3da" }}
    >
      <div className="container">
        {/* Header */}
        <div
          ref={titleRef as React.RefObject<HTMLDivElement>}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span
            className="pill-badge mb-4 text-white"
            style={{ background: "#7A9E7E" }}
          >
            Stratégie de Lancement
          </span>
          <h2
            className="font-['Cormorant_Garamond'] text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
            style={{ color: "#3D4A3E" }}
          >
            Recruter les 1 000 premières{" "}
            <em className="not-italic" style={{ color: "#C4714A" }}>
              ambassadrices fondatrices.
            </em>
          </h2>
          <p
            className="text-lg max-w-2xl mx-auto leading-relaxed"
            style={{ color: "#6b7a6c" }}
          >
            Les 1 000 premières utilisatrices ne sont pas des utilisatrices ordinaires.
            Ce sont des ambassadrices dont l'engagement initial déterminera la trajectoire virale du produit.
          </p>
        </div>

        {/* Timeline */}
        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connecting line */}
          <div
            className="absolute top-16 left-1/6 right-1/6 h-0.5 hidden md:block"
            style={{
              background: "linear-gradient(90deg, #7A9E7E, #C4714A, #C9A84C)",
            }}
          />

          {phases.map((phase, i) => (
            <PhaseCard key={phase.phase} phase={phase} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
