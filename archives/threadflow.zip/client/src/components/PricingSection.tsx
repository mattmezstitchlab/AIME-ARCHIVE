/*
 * ThreadFlow — Section Pricing
 * Design: 3 cards neumorphiques, Pro mis en avant, ancrage "3 échevettes"
 * Toggle mensuel/annuel
 */
import { useState } from "react";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { Check, Sparkles, Crown, Palette } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";

const plans = [
  {
    id: "free",
    name: "ThreadFlow Free",
    icon: Palette,
    price: { monthly: 0, annual: 0 },
    description: "Pour découvrir et créer l'habitude",
    features: [
      "5 patrons actifs",
      "Inventaire manuel de fils",
      "Suivi de progression basique",
      "Grille interactive",
      "Import PDF & image",
    ],
    cta: "Commencer gratuitement",
    ctaStyle: "outline",
    highlight: false,
    badge: null,
    color: "#7A9E7E",
  },
  {
    id: "pro",
    name: "ThreadFlow Pro",
    icon: Sparkles,
    price: { monthly: 4.99, annual: 44.99 },
    description: "Le prix de 3 échevettes DMC par mois",
    features: [
      "Patrons illimités",
      "Scan IA des fils (45 secondes)",
      "Smart Pathing™",
      "Confetti Cleaner™",
      "SAL Sync™",
      "Stitch Diary™ avec timelapse vidéo",
      "Synchronisation multi-appareils",
      "Export PDF professionnel",
      "Bibliothèque annotée",
    ],
    cta: "Essai gratuit 30 jours",
    ctaStyle: "primary",
    highlight: true,
    badge: "Le plus populaire",
    color: "#C4714A",
  },
  {
    id: "studio",
    name: "ThreadFlow Studio",
    icon: Crown,
    price: { monthly: 14.99, annual: 149.99 },
    description: "Pour les créatrices et designers",
    features: [
      "Tout ThreadFlow Pro",
      "Outils de création de patrons avancés",
      "Export professionnel (PDF, XSD, OXS)",
      "Vente de patrons intégrée",
      "Page Designer Officiel",
      "Analytics de ventes",
      "Support prioritaire",
    ],
    cta: "Démarrer Studio",
    ctaStyle: "outline",
    highlight: false,
    badge: "Pour les créatrices",
    color: "#C9A84C",
  },
];

export default function PricingSection() {
  const [annual, setAnnual] = useState(false);
  const { data: user } = trpc.auth.me.useQuery();
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();

  return (
    <section
      id="pricing"
      className="py-24 lg:py-32"
      style={{ background: "#e8e3da" }}
    >
      <div className="container">
        {/* Header */}
        <div
          ref={titleRef as React.RefObject<HTMLDivElement>}
          className={`text-center mb-14 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span
            className="pill-badge mb-4 text-white"
            style={{ background: "#C4714A" }}
          >
            Tarifs
          </span>
          <h2
            className="font-['Cormorant_Garamond'] text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4"
            style={{ color: "#3D4A3E" }}
          >
            Le prix de{" "}
            <em className="not-italic" style={{ color: "#C4714A" }}>
              3 échevettes DMC
            </em>{" "}
            par mois.
          </h2>
          <p className="text-lg mb-8" style={{ color: "#6b7a6c" }}>
            Une échevette DMC coûte environ 1,50 €. ThreadFlow Pro coûte 4,99 €/mois.
          </p>

          {/* Toggle */}
          <div className="inline-flex items-center gap-3 neuro-card p-1.5 rounded-2xl">
            <button
              onClick={() => setAnnual(false)}
              className={`px-5 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                !annual ? "text-white shadow-sm" : ""
              }`}
              style={
                !annual
                  ? { background: "#C4714A", color: "white" }
                  : { color: "#6b7a6c" }
              }
            >
              Mensuel
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={`px-5 py-2 rounded-xl text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
                annual ? "text-white shadow-sm" : ""
              }`}
              style={
                annual
                  ? { background: "#C4714A", color: "white" }
                  : { color: "#6b7a6c" }
              }
            >
              Annuel
              <span
                className="text-xs px-1.5 py-0.5 rounded-md font-bold"
                style={{ background: "#7A9E7E", color: "white" }}
              >
                −25%
              </span>
            </button>
          </div>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
          {plans.map((plan, i) => {
            const { ref, isVisible } = useIntersectionObserver();
            const Icon = plan.icon;
            const price = annual ? plan.price.annual : plan.price.monthly;
            const priceLabel = annual ? "/an" : "/mois";

            return (
              <div
                key={plan.id}
                ref={ref as React.RefObject<HTMLDivElement>}
                className={`relative flex flex-col transition-all duration-700 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
                } ${plan.highlight ? "scale-105 z-10" : ""}`}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                {/* Highlight ring */}
                {plan.highlight && (
                  <div
                    className="absolute -inset-0.5 rounded-[1.4rem]"
                    style={{
                      background: `linear-gradient(135deg, ${plan.color}, #7A9E7E)`,
                      zIndex: -1,
                    }}
                  />
                )}

                <div
                  className={`flex flex-col flex-1 p-7 rounded-3xl ${
                    plan.highlight ? "bg-[#e8e3da]" : "neuro-card"
                  }`}
                >
                  {/* Badge */}
                  {plan.badge && (
                    <div
                      className="pill-badge mb-4 self-start text-white text-xs"
                      style={{ background: plan.color }}
                    >
                      {plan.badge}
                    </div>
                  )}

                  {/* Icon + name */}
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: `${plan.color}15` }}
                    >
                      <Icon size={20} style={{ color: plan.color }} />
                    </div>
                    <h3
                      className="font-['Cormorant_Garamond'] text-xl font-semibold"
                      style={{ color: "#3D4A3E" }}
                    >
                      {plan.name}
                    </h3>
                  </div>

                  {/* Price */}
                  <div className="mb-3">
                    <span
                      className="font-['Cormorant_Garamond'] text-5xl font-bold"
                      style={{ color: "#3D4A3E" }}
                    >
                      {price === 0 ? "Gratuit" : `${price} €`}
                    </span>
                    {price > 0 && (
                      <span className="text-sm ml-1" style={{ color: "#6b7a6c" }}>
                        {priceLabel}
                      </span>
                    )}
                  </div>

                  <p className="text-sm mb-6 italic" style={{ color: "#6b7a6c" }}>
                    {plan.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.features.map((feat) => (
                      <li key={feat} className="flex items-start gap-2.5">
                        <Check
                          size={16}
                          className="flex-shrink-0 mt-0.5"
                          style={{ color: plan.color }}
                        />
                        <span className="text-sm" style={{ color: "#3D4A3E" }}>
                          {feat}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <a
                    href={user ? "/app" : (plan.id === "free" ? getLoginUrl() : "#waitlist")}
                    className={`w-full text-center py-3.5 rounded-2xl font-semibold text-sm transition-all duration-200 hover:-translate-y-0.5 ${
                      plan.ctaStyle === "primary" ? "text-white hover:opacity-90" : "neuro-btn"
                    }`}
                    style={
                      plan.ctaStyle === "primary"
                        ? {
                            background: `linear-gradient(135deg, ${plan.color}, #8B5E3C)`,
                            boxShadow: `0 4px 16px ${plan.color}40`,
                            color: "white",
                          }
                        : { color: "#3D4A3E" }
                    }
                  >
                    {plan.cta}
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Conversion trigger */}
        <div
          className="mt-14 max-w-2xl mx-auto text-center p-8 rounded-3xl border"
          style={{
            background: "#e8e3da",
            borderColor: "#C4714A44",
          }}
        >
          <p
            className="font-['Cormorant_Garamond'] text-2xl font-semibold mb-3"
            style={{ color: "#3D4A3E" }}
          >
            Le déclencheur de conversion
          </p>
          <p className="text-base leading-relaxed" style={{ color: "#6b7a6c" }}>
            Au 6ème patron, ThreadFlow n'affiche pas un mur payant frustrant. Elle affiche :{" "}
            <em
              className="not-italic font-medium"
              style={{ color: "#C4714A" }}
            >
              "Vous avez créé votre 5ème projet sur ThreadFlow. Votre bibliothèque grandit —
              passez à Pro pour ne jamais avoir à choisir entre vos projets."
            </em>
          </p>
          <p className="text-sm mt-4" style={{ color: "#6b7a6c" }}>
            Positif, célébratoire, ancré dans la valeur déjà créée.
          </p>
        </div>
      </div>
    </section>
  );
}
