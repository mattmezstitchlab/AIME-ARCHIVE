import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { Route, Scissors, Users } from "lucide-react";

const N = {
  bg: "#e8e3da",
  raised: "8px 8px 20px #c4bfb6, -8px -8px 20px #ffffff",
  raisedSm: "4px 4px 10px #c4bfb6, -4px -4px 10px #ffffff",
  raisedLg: "14px 14px 32px #c4bfb6, -14px -14px 32px #ffffff",
  inset: "inset 4px 4px 10px #c4bfb6, inset -4px -4px 10px #ffffff",
  terracotta: "#C4714A",
  sage: "#7A9E7E",
  slate: "#3D4A3E",
  muted: "#6b7a6c",
  gold: "#C9A84C",
};

const features = [
  {
    id: "smart-pathing",
    badge: "Smart Pathing™",
    badgeIcon: Route,
    title: "L'itinéraire de broderie intelligent",
    subtitle: "Économisez du fil. Gagnez du temps. Impressionnez la communauté.",
    description:
      "Un bouton « Optimiser le chemin » analyse votre grille entière et génère un itinéraire lumineux, couleur par couleur, qui minimise les déplacements à l'arrière du tissu.",
    highlight:
      "Avec ce chemin, vous économiserez environ 3,2 m de fil sur cette couleur.",
    detail:
      "Le mode « Dos Parfait » privilégie l'esthétique du verso — une fierté culturelle forte dans la communauté des brodeuses.",
    wom: "La heatmap du chemin est visuellement spectaculaire et partageable sur Instagram.",
    img: "/manus-storage/feature_smart_pathing_54ad2a60.png",
    imgAlt: "Smart Pathing — itinéraire de broderie optimisé",
    color: "#7A9E7E",
    reversed: false,
  },
  {
    id: "confetti-cleaner",
    badge: "Confetti Cleaner™",
    badgeIcon: Scissors,
    title: "Le chirurgien des patrons",
    subtitle: "Éliminez des heures de travail en un glissement de curseur.",
    description:
      "Un slider avec prévisualisation en temps réel. L'IA fusionne intelligemment les points isolés avec les couleurs adjacentes les plus proches, sans dénaturer l'image finale.",
    highlight: "Nettoyage à 60 % : 847 points confetti éliminés. Temps de broderie estimé réduit de 4h30.",
    detail:
      "Le « confetti » est la bête noire absolue des brodeuses. Chaque point isolé oblige à couper le fil, faire un nœud, recommencer. ThreadFlow l'élimine en un geste.",
    wom: "La première fois qu'une brodeuse voit ce slider, elle ressent un soulagement physique.",
    img: "/manus-storage/feature_confetti_cleaner_bade3ccb.png",
    imgAlt: "Confetti Cleaner — nettoyage des points isolés",
    color: "#C4714A",
    reversed: true,
  },
  {
    id: "sal-sync",
    badge: "SAL Sync™",
    badgeIcon: Users,
    title: "Le Stitch-Along augmenté",
    subtitle: "Brodez seule à 23h, mais ne soyez jamais vraiment seule.",
    description:
      "ThreadFlow devient la plateforme officielle des Stitch-Alongs. Les nouvelles parties se débloquent automatiquement. Une heatmap communautaire montre en temps réel où en sont les autres participantes.",
    highlight:
      "Un fil de discussion contextuel est attaché à chaque zone du patron — appuyez longtemps pour voir les astuces de la communauté.",
    detail:
      "Les SALs sont déjà viraux par nature. En devenant la plateforme de référence, ThreadFlow est recommandée par les créateurs à leurs milliers d'abonnés.",
    wom: "Les SALs génèrent une activité sociale intense sur Instagram, Reddit et FlossTube.",
    img: "/manus-storage/feature_sal_sync_5fe9d8ed.png",
    imgAlt: "SAL Sync — Stitch-Along communautaire",
    color: "#C9A84C",
    reversed: false,
  },
];

function FeatureCard({ feature }: { feature: typeof features[0] }) {
  const { ref, isVisible } = useIntersectionObserver();
  const Icon = feature.badgeIcon;

  return (
    <div
      ref={ref as React.RefObject<HTMLDivElement>}
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
        gap: "3rem",
        alignItems: "center",
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(32px)",
        transition: "all 0.7s ease",
      }}
    >
      {/* Image */}
      <div style={{ order: feature.reversed ? 2 : 1 }}>
        <div style={{ borderRadius: 28, overflow: "hidden", boxShadow: N.raisedLg }}>
          <img
            src={feature.img}
            alt={feature.imgAlt}
            style={{ width: "100%", height: "auto", objectFit: "cover", display: "block" }}
          />
        </div>
      </div>

      {/* Text */}
      <div style={{ order: feature.reversed ? 1 : 2 }}>
        {/* Badge */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 8,
          padding: "7px 16px", borderRadius: 50,
          background: N.bg, boxShadow: N.raisedSm,
          marginBottom: "1.25rem",
        }}>
          <Icon size={13} color={feature.color} />
          <span style={{ fontSize: "0.78rem", fontWeight: 700, color: feature.color }}>
            {feature.badge}
          </span>
        </div>

        <h3 style={{
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontSize: "clamp(1.8rem, 3vw, 2.6rem)",
          fontWeight: 700, color: N.slate,
          lineHeight: 1.15, marginBottom: "0.75rem",
        }}>
          {feature.title}
        </h3>

        <p style={{ fontSize: "1rem", fontWeight: 600, color: feature.color, marginBottom: "1rem" }}>
          {feature.subtitle}
        </p>

        <p style={{ fontSize: "0.95rem", color: N.muted, lineHeight: 1.7, marginBottom: "1.25rem" }}>
          {feature.description}
        </p>

        {/* Highlight quote */}
        <div style={{
          borderRadius: 14, padding: "1rem 1.25rem", marginBottom: "1.25rem",
          background: N.bg, boxShadow: N.inset,
          borderLeft: `4px solid ${feature.color}`,
          fontSize: "0.85rem", fontStyle: "italic", color: N.slate, lineHeight: 1.65,
        }}>
          "{feature.highlight}"
        </div>

        <p style={{ fontSize: "0.85rem", color: N.muted, lineHeight: 1.6, marginBottom: "0.75rem" }}>
          {feature.detail}
        </p>

        {/* WOM badge */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "6px 14px", borderRadius: 50,
          background: N.bg, boxShadow: N.raisedSm,
          fontSize: "0.75rem", color: N.muted,
        }}>
          <span>💬</span>
          <span>{feature.wom}</span>
        </div>
      </div>
    </div>
  );
}

export default function FeaturesSection() {
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();

  return (
    <section id="features" style={{ background: N.bg, padding: "6rem 0" }}>
      <div className="container">
        {/* Header */}
        <div
          ref={titleRef as React.RefObject<HTMLDivElement>}
          style={{
            textAlign: "center", marginBottom: "4rem",
            opacity: titleVisible ? 1 : 0,
            transform: titleVisible ? "translateY(0)" : "translateY(24px)",
            transition: "all 0.7s ease",
          }}
        >
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 8,
            padding: "8px 20px", borderRadius: 50,
            background: N.bg, boxShadow: N.raisedSm,
            marginBottom: "1.5rem",
          }}>
            <span style={{ fontSize: "0.78rem", fontWeight: 700, color: N.sage, letterSpacing: "0.06em", textTransform: "uppercase" }}>
              3 Fonctionnalités Magiques
            </span>
          </div>
          <h2 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: "clamp(2.2rem, 4vw, 3.5rem)",
            fontWeight: 700, color: N.slate,
            lineHeight: 1.15, marginBottom: "1rem",
          }}>
            Conçues pour faire dire :<br />
            <em style={{ fontStyle: "normal", color: N.terracotta }}>
              "Tu connais ThreadFlow ?"
            </em>
          </h2>
          <p style={{ fontSize: "1.05rem", color: N.muted, maxWidth: 560, margin: "0 auto" }}>
            Ces fonctionnalités sont si inattendues et si utiles qu'elles génèrent du bouche-à-oreille
            spontané. Chaque brodeuse qui les découvre veut immédiatement les montrer à ses amies.
          </p>
        </div>

        {/* Feature cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: "5rem" }}>
          {features.map((feature) => (
            <FeatureCard key={feature.id} feature={feature} />
          ))}
        </div>
      </div>
    </section>
  );
}
