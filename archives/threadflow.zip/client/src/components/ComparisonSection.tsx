/*
 * ThreadFlow — Section Comparaison Concurrents
 * Design: Tableau comparatif neumorphique, ThreadFlow mis en avant
 */
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { Check, X, Minus } from "lucide-react";

const features = [
  "Scan IA des fils",
  "Smart Pathing™",
  "Confetti Cleaner™",
  "SAL Sync communautaire",
  "Stitch Diary vidéo",
  "Synchronisation multi-appareils",
  "Inventaire prédictif",
  "Export PDF natif",
  "iOS + Android + Web",
  "Création de patrons",
];

const competitors = [
  {
    name: "ThreadFlow",
    highlight: true,
    values: [true, true, true, true, true, true, true, true, true, true],
    price: "4,99 €/mois",
    color: "#C4714A",
  },
  {
    name: "PCStitch",
    highlight: false,
    values: [false, false, false, false, false, false, false, false, false, true],
    price: "~50 €",
    color: "#6b7a6c",
  },
  {
    name: "Pattern Keeper",
    highlight: false,
    values: [false, false, false, false, false, false, false, false, null, false],
    price: "~9 USD",
    color: "#6b7a6c",
  },
  {
    name: "Stitch Fiddle",
    highlight: false,
    values: [false, false, false, false, false, false, false, null, true, true],
    price: "Freemium",
    color: "#6b7a6c",
  },
];

function ValueIcon({ value }: { value: boolean | null }) {
  if (value === true) return <Check size={16} style={{ color: "#7A9E7E" }} />;
  if (value === false) return <X size={16} style={{ color: "#C4714A" }} />;
  return <Minus size={16} style={{ color: "#6b7a6c" }} />;
}

export default function ComparisonSection() {
  const { ref: titleRef, isVisible: titleVisible } = useIntersectionObserver();
  const { ref: tableRef, isVisible: tableVisible } = useIntersectionObserver();

  return (
    <section
      className="py-24 lg:py-32"
      style={{ background: "#e8e3da" }}
    >
      <div className="container">
        {/* Header */}
        <div
          ref={titleRef as React.RefObject<HTMLDivElement>}
          className={`text-center mb-14 transition-all duration-700 ${
            titleVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span
            className="pill-badge mb-4 text-white"
            style={{ background: "#C4714A" }}
          >
            Comparaison
          </span>
          <h2
            className="font-['Cormorant_Garamond'] text-4xl md:text-5xl font-bold leading-tight mb-4"
            style={{ color: "#3D4A3E" }}
          >
            Pourquoi ThreadFlow{" "}
            <em className="not-italic" style={{ color: "#C4714A" }}>
              va gagner
            </em>
            .
          </h2>
          <p
            className="text-lg max-w-2xl mx-auto"
            style={{ color: "#6b7a6c" }}
          >
            Le marché des logiciels de point de croix souffre d'un déficit d'ambition.
            Les acteurs existants ont conçu des outils pour des ordinateurs des années 2000.
          </p>
        </div>

        {/* Table */}
        <div
          ref={tableRef as React.RefObject<HTMLDivElement>}
          className={`overflow-x-auto transition-all duration-700 ${
            tableVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <table className="w-full min-w-[640px]">
            <thead>
              <tr>
                <th
                  className="text-left py-4 px-4 text-sm font-medium"
                  style={{ color: "#6b7a6c" }}
                >
                  Fonctionnalité
                </th>
                {competitors.map((comp) => (
                  <th
                    key={comp.name}
                    className="py-4 px-4 text-center"
                  >
                    <div
                      className={`inline-flex flex-col items-center gap-1 px-4 py-2 rounded-xl ${
                        comp.highlight ? "text-white" : ""
                      }`}
                      style={
                        comp.highlight
                          ? {
                              background: "linear-gradient(135deg, #C4714A, #8B5E3C)",
                              boxShadow: "0 4px 16px #C4714A44",
                            }
                          : {}
                      }
                    >
                      <span
                        className="font-['Cormorant_Garamond'] text-lg font-semibold"
                        style={comp.highlight ? { color: "white" } : { color: "#3D4A3E" }}
                      >
                        {comp.name}
                      </span>
                      <span
                        className="text-xs"
                        style={comp.highlight ? { color: "#F5F0E8" } : { color: "#6b7a6c" }}
                      >
                        {comp.price}
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {features.map((feat, i) => (
                <tr
                  key={feat}
                  className="border-t"
                  style={{ borderColor: "#d4cfc6" }}
                >
                  <td
                    className="py-3.5 px-4 text-sm"
                    style={{ color: "#3D4A3E" }}
                  >
                    {feat}
                  </td>
                  {competitors.map((comp) => (
                    <td
                      key={comp.name}
                      className={`py-3.5 px-4 text-center ${
                        comp.highlight ? "rounded-sm" : ""
                      }`}
                      style={
                        comp.highlight
                          ? { background: "#C4714A0d" }
                          : {}
                      }
                    >
                      <div className="flex justify-center">
                        <ValueIcon value={comp.values[i]} />
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Conclusion */}
        <div
          className="mt-12 text-center p-8 rounded-3xl"
          style={{
            background: "linear-gradient(135deg, #C4714A14, #7A9E7E14)",
            border: "1px solid #C4714A33",
          }}
        >
          <p
            className="font-['Cormorant_Garamond'] text-2xl font-semibold"
            style={{ color: "#3D4A3E" }}
          >
            ThreadFlow ne construit pas un meilleur logiciel de grille.
          </p>
          <p className="mt-2 text-base" style={{ color: "#6b7a6c" }}>
            Il construit le compagnon de broderie que les brodeuses méritent — dans un marché à 8 milliards
            de dollars habité par des utilisatrices passionnées et sous-servies.
          </p>
        </div>
      </div>
    </section>
  );
}
