/**
 * CrossStitchCell — Rendu SVG réaliste d'un point de croix
 * Simule deux fils croisés avec texture fibreuse, ombre portée et reflet
 * Mode "réaliste" : rendu fil texturé
 * Mode "grille" : simple carré coloré pour l'édition
 */

interface CrossStitchCellProps {
  color: string | null;       // Couleur hex ou null (case vide)
  size: number;               // Taille de la cellule en px
  realisticMode?: boolean;    // true = rendu fil réaliste, false = édition simple
  isHovered?: boolean;
  isSelected?: boolean;
}

function hexToRgb(hex: string) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) }
    : { r: 122, g: 158, b: 126 };
}

function lighten(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  return `rgb(${Math.min(255, r + amount)},${Math.min(255, g + amount)},${Math.min(255, b + amount)})`;
}

function darken(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  return `rgb(${Math.max(0, r - amount)},${Math.max(0, g - amount)},${Math.max(0, b - amount)})`;
}

export function CrossStitchCell({
  color,
  size,
  realisticMode = false,
  isHovered = false,
  isSelected = false,
}: CrossStitchCellProps) {
  const s = size;
  const pad = s * 0.08; // marge intérieure
  const id = color ? color.replace("#", "") + s : "empty" + s;

  if (!color) {
    // Case vide — fond tissu Aida
    return (
      <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} style={{ display: "block" }}>
        <rect width={s} height={s} fill={isHovered ? "rgba(196,113,74,0.12)" : "transparent"} />
        {/* Lignes de grille Aida subtiles */}
        <line x1={0} y1={s/2} x2={s} y2={s/2} stroke="rgba(196,191,182,0.4)" strokeWidth={0.3} />
        <line x1={s/2} y1={0} x2={s/2} y2={s} stroke="rgba(196,191,182,0.4)" strokeWidth={0.3} />
      </svg>
    );
  }

  if (!realisticMode || s < 10) {
    // Mode édition — carré coloré simple avec léger relief
    const light = lighten(color, 40);
    const dark = darken(color, 25);
    return (
      <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} style={{ display: "block" }}>
        <defs>
          <linearGradient id={`eg-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={light} />
            <stop offset="100%" stopColor={dark} />
          </linearGradient>
        </defs>
        <rect width={s} height={s} fill={`url(#eg-${id})`} />
        {/* Croix simple pour identifier le point */}
        {s >= 8 && (
          <>
            <line x1={pad} y1={pad} x2={s-pad} y2={s-pad} stroke="rgba(255,255,255,0.35)" strokeWidth={Math.max(0.8, s*0.06)} strokeLinecap="round" />
            <line x1={s-pad} y1={pad} x2={pad} y2={s-pad} stroke="rgba(255,255,255,0.35)" strokeWidth={Math.max(0.8, s*0.06)} strokeLinecap="round" />
          </>
        )}
        {isSelected && (
          <rect width={s} height={s} fill="none" stroke="rgba(196,113,74,0.8)" strokeWidth={1.5} />
        )}
      </svg>
    );
  }

  // ============================================================
  // MODE RÉALISTE — Rendu fil texturé avec fibres
  // ============================================================
  const light = lighten(color, 60);
  const mid = lighten(color, 25);
  const dark = darken(color, 35);
  const vdark = darken(color, 60);
  const { r: cr, g: cg, b: cb } = hexToRgb(color);

  // Points du fil diagonal 1 (haut-gauche → bas-droite) avec légère ondulation
  const d1Points: string[] = [];
  const d2Points: string[] = [];
  const steps = Math.max(6, Math.floor(s / 2));
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x1 = pad + t * (s - 2 * pad);
    const y1 = pad + t * (s - 2 * pad) + Math.sin(t * Math.PI * 3) * (s * 0.04);
    d1Points.push(`${x1},${y1}`);

    const x2 = (s - pad) - t * (s - 2 * pad);
    const y2 = pad + t * (s - 2 * pad) + Math.sin(t * Math.PI * 3 + Math.PI) * (s * 0.04);
    d2Points.push(`${x2},${y2}`);
  }

  const strokeW = Math.max(1.5, s * 0.18);
  const strokeW2 = strokeW * 0.6;

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} style={{ display: "block" }}>
      <defs>
        {/* Gradient fond tissu Aida */}
        <linearGradient id={`aida-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f0ebe2" />
          <stop offset="100%" stopColor="#e4dfd6" />
        </linearGradient>

        {/* Gradient fil diagonal 1 */}
        <linearGradient id={`fd1-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={light} />
          <stop offset="40%" stopColor={mid} />
          <stop offset="70%" stopColor={color} />
          <stop offset="100%" stopColor={dark} />
        </linearGradient>

        {/* Gradient fil diagonal 2 (légèrement plus sombre — passe en dessous) */}
        <linearGradient id={`fd2-${id}`} x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={mid} />
          <stop offset="50%" stopColor={color} />
          <stop offset="100%" stopColor={vdark} />
        </linearGradient>

        {/* Filtre ombre portée pour le fil */}
        <filter id={`shadow-${id}`} x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0.5" dy="0.8" stdDeviation="0.6"
            floodColor={`rgba(${Math.max(0,cr-80)},${Math.max(0,cg-80)},${Math.max(0,cb-80)},0.5)`} />
        </filter>

        {/* Filtre ombre plus légère pour le fil du dessus */}
        <filter id={`shadow2-${id}`} x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0.3" dy="0.5" stdDeviation="0.4"
            floodColor={`rgba(${Math.max(0,cr-60)},${Math.max(0,cg-60)},${Math.max(0,cb-60)},0.4)`} />
        </filter>
      </defs>

      {/* Fond tissu Aida */}
      <rect width={s} height={s} fill={`url(#aida-${id})`} />

      {/* Lignes de trame Aida très subtiles */}
      {Array.from({ length: Math.floor(s / 4) }).map((_, i) => (
        <line
          key={`h${i}`}
          x1={0} y1={i * 4 + 2} x2={s} y2={i * 4 + 2}
          stroke="rgba(196,191,182,0.2)" strokeWidth={0.3}
        />
      ))}
      {Array.from({ length: Math.floor(s / 4) }).map((_, i) => (
        <line
          key={`v${i}`}
          x1={i * 4 + 2} y1={0} x2={i * 4 + 2} y2={s}
          stroke="rgba(196,191,182,0.2)" strokeWidth={0.3}
        />
      ))}

      {/* Fil diagonal 2 (passe EN DESSOUS) — haut-droite → bas-gauche */}
      {/* Ombre */}
      <polyline
        points={d2Points.join(" ")}
        fill="none"
        stroke={`rgba(${Math.max(0,cr-80)},${Math.max(0,cg-80)},${Math.max(0,cb-80)},0.3)`}
        strokeWidth={strokeW + 1.5}
        strokeLinecap="round"
      />
      {/* Corps du fil */}
      <polyline
        points={d2Points.join(" ")}
        fill="none"
        stroke={`url(#fd2-${id})`}
        strokeWidth={strokeW}
        strokeLinecap="round"
      />
      {/* Reflet soyeux fil 2 */}
      <polyline
        points={d2Points.join(" ")}
        fill="none"
        stroke="rgba(255,255,255,0.22)"
        strokeWidth={strokeW2}
        strokeLinecap="round"
        strokeDasharray={`${s * 0.15} ${s * 0.1}`}
      />

      {/* Fil diagonal 1 (passe AU DESSUS) — haut-gauche → bas-droite */}
      {/* Ombre */}
      <polyline
        points={d1Points.join(" ")}
        fill="none"
        stroke={`rgba(${Math.max(0,cr-80)},${Math.max(0,cg-80)},${Math.max(0,cb-80)},0.35)`}
        strokeWidth={strokeW + 1.5}
        strokeLinecap="round"
      />
      {/* Corps du fil */}
      <polyline
        points={d1Points.join(" ")}
        fill="none"
        stroke={`url(#fd1-${id})`}
        strokeWidth={strokeW}
        strokeLinecap="round"
      />
      {/* Reflet soyeux fil 1 */}
      <polyline
        points={d1Points.join(" ")}
        fill="none"
        stroke="rgba(255,255,255,0.30)"
        strokeWidth={strokeW2}
        strokeLinecap="round"
        strokeDasharray={`${s * 0.12} ${s * 0.08}`}
      />

      {/* Hover highlight */}
      {isHovered && (
        <rect width={s} height={s} fill="rgba(255,255,255,0.15)" />
      )}
    </svg>
  );
}

export default CrossStitchCell;
