import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Loader2, LayoutDashboard, FolderOpen, Package, BookOpen, Users, Grid3X3, LogOut, Menu, X, Scissors, UserCircle2 } from "lucide-react";
import { useState } from "react";

const NAV_ITEMS = [
  { href: "/app", label: "Dashboard", icon: LayoutDashboard },
  { href: "/app/projects", label: "Projets", icon: FolderOpen },
  { href: "/app/inventory", label: "Inventaire DMC", icon: Package },
  { href: "/app/diary", label: "Stitch Diary", icon: BookOpen },
  { href: "/app/sal-sync", label: "SAL Sync", icon: Users },
  { href: "/app/editor", label: "Éditeur", icon: Grid3X3 },
  { href: "/app/profile", label: "Mon profil", icon: UserCircle2 },
];

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function AppLayout({ children, title }: AppLayoutProps) {
  const [location] = useLocation();
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--app-bg)" }}>
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--terracotta)" }} />
          <p style={{ color: "var(--text-muted)", fontFamily: "DM Sans, sans-serif" }}>Chargement…</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  const initials = user?.name
    ? user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)
    : "TF";

  return (
    <div className="min-h-screen flex" style={{ background: "var(--app-bg)", fontFamily: "DM Sans, sans-serif" }}>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 lg:hidden"
          style={{ background: "rgba(61,74,62,0.4)" }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-64 flex flex-col transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}
        style={{
          background: "var(--ivory)",
          boxShadow: "6px 0 20px rgba(61,74,62,0.08)",
          borderRight: "1px solid rgba(212,197,169,0.3)",
        }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b" style={{ borderColor: "rgba(212,197,169,0.3)" }}>
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)" }}
          >
            <Scissors className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-bold text-lg" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              ThreadFlow
            </span>
            <div className="text-xs" style={{ color: "var(--text-muted)" }}>Espace brodeuse</div>
          </div>
          <button
            className="ml-auto lg:hidden p-1 rounded"
            onClick={() => setSidebarOpen(false)}
            style={{ color: "var(--text-muted)" }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const isActive = location === href || (href !== "/app" && location.startsWith(href));
            return (
              <Link
                key={href}
                href={href}
                className="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer"
                style={{
                  background: isActive
                    ? "linear-gradient(135deg, rgba(196,113,74,0.12), rgba(122,158,126,0.08))"
                    : "transparent",
                  color: isActive ? "var(--terracotta)" : "var(--text-muted)",
                  fontWeight: isActive ? "600" : "400",
                  boxShadow: isActive
                    ? "inset 2px 2px 5px rgba(196,113,74,0.1), inset -2px -2px 5px rgba(255,255,255,0.8)"
                    : "none",
                  textDecoration: "none",
                }}
                onClick={() => setSidebarOpen(false)}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span>{label}</span>
                {isActive && (
                  <div
                    className="ml-auto w-1.5 h-1.5 rounded-full"
                    style={{ background: "var(--terracotta)" }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        <div className="px-3 py-4 border-t" style={{ borderColor: "rgba(212,197,169,0.3)" }}>
          <div
            className="flex items-center gap-3 px-4 py-3 rounded-xl"
            style={{
              background: "rgba(212,197,169,0.15)",
              boxShadow: "inset 2px 2px 5px rgba(0,0,0,0.04), inset -2px -2px 5px rgba(255,255,255,0.8)",
            }}
          >
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
              style={{ background: "linear-gradient(135deg, var(--sage), #5a7e5e)", color: "white" }}
            >
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold truncate" style={{ color: "var(--slate)" }}>
                {user?.name ?? "Brodeuse"}
              </div>
              <div className="text-xs truncate" style={{ color: "var(--text-muted)" }}>
                {user?.email ?? ""}
              </div>
            </div>
            <button
              onClick={() => logout()}
              className="p-1.5 rounded-lg transition-colors"
              style={{ color: "var(--text-muted)" }}
              title="Se déconnecter"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar (mobile) */}
        <header
          className="lg:hidden flex items-center gap-4 px-4 py-3 border-b"
          style={{ background: "var(--ivory)", borderColor: "rgba(212,197,169,0.3)" }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg"
            style={{ color: "var(--slate)" }}
          >
            <Menu className="w-5 h-5" />
          </button>
          {title && (
            <h1 className="font-semibold text-lg" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              {title}
            </h1>
          )}
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
