/*
 * ThreadFlow Footer
 * Design: Fond ardoise, colonnes de liens, manifeste court, copyright
 * Tous les liens pointent vers des pages réelles
 */
import { Link } from "wouter";

const SOCIAL_LINKS = [
  { label: "Instagram", href: "https://instagram.com/threadflow.app" },
  { label: "Reddit", href: "https://reddit.com/r/CrossStitch" },
  { label: "YouTube", href: "https://youtube.com/@threadflow" },
];

const FOOTER_LINKS = {
  Produit: [
    { label: "Fonctionnalités", href: "/#features" },
    { label: "Smart Pathing™", href: "/#features" },
    { label: "Confetti Cleaner™", href: "/#features" },
    { label: "SAL Sync™", href: "/#features" },
    { label: "Stitch Diary™", href: "/#features" },
    { label: "Tarifs", href: "/#pricing" },
  ],
  Communauté: [
    { label: "Stitch Hub", href: "/#community" },
    { label: "WIP Cards", href: "/#community" },
    { label: "Stitch-Alongs", href: "/#community" },
    { label: "Programme Golden Needle", href: "/#waitlist" },
    { label: "r/CrossStitch", href: "https://reddit.com/r/CrossStitch", external: true },
  ],
  Ressources: [
    { label: "Blog", href: "/blog" },
    { label: "Démo interactive", href: "/demo" },
    { label: "Tutoriels", href: "/blog" },
    { label: "FAQ", href: "/faq" },
    { label: "Formats supportés", href: "/faq" },
  ],
  Entreprise: [
    { label: "À propos", href: "/a-propos" },
    { label: "Manifeste", href: "/#manifeste" },
    { label: "Presse", href: "/a-propos" },
    { label: "Partenaires Designers", href: "/a-propos" },
    { label: "Contact", href: "/a-propos" },
  ],
};

const LEGAL_LINKS = [
  { label: "Confidentialité", href: "/confidentialite" },
  { label: "CGU", href: "/cgu" },
  { label: "Cookies", href: "/cookies" },
];

export default function Footer() {
  return (
    <footer
      className="pt-16 pb-8"
      style={{ background: "#2A3329" }}
    >
      <div className="container">
        {/* Top */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-14">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" style={{ textDecoration: "none" }}>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-xl overflow-hidden">
                  <img
                    src="/manus-storage/logo_threadflow_cb2361aa.png"
                    alt="ThreadFlow"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
                <span
                  className="font-['Cormorant_Garamond'] text-xl font-semibold"
                  style={{ color: "#F5F0E8" }}
                >
                  Thread<span style={{ color: "#C4714A" }}>Flow</span>
                </span>
              </div>
            </Link>
            <p className="text-sm leading-relaxed mb-4" style={{ color: "#a09890" }}>
              Le compagnon de broderie intelligent. Pour l'amour du point.
            </p>
            <div className="flex gap-3 flex-wrap">
              {SOCIAL_LINKS.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs px-3 py-1.5 rounded-lg transition-opacity hover:opacity-80"
                  style={{
                    background: "#364035",
                    color: "#b5a99a",
                  }}
                >
                  {social.label}
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(FOOTER_LINKS).map(([category, items]) => (
            <div key={category}>
              <h4
                className="font-semibold text-sm mb-4 uppercase tracking-wider"
                style={{ color: "#D4C5A9" }}
              >
                {category}
              </h4>
              <ul className="space-y-2.5">
                {items.map((item) => (
                  <li key={item.label}>
                    {'external' in item && item.external ? (
                      <a
                        href={item.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm transition-opacity hover:opacity-80"
                        style={{ color: "#a09890" }}
                      >
                        {item.label}
                      </a>
                    ) : item.href.startsWith("http") ? (
                      <a
                        href={item.href}
                        className="text-sm transition-opacity hover:opacity-80"
                        style={{ color: "#a09890" }}
                      >
                        {item.label}
                      </a>
                    ) : (
                      <Link
                        href={item.href}
                        className="text-sm transition-opacity hover:opacity-80"
                        style={{ color: "#a09890", textDecoration: "none" }}
                      >
                        {item.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div
          className="h-px mb-8"
          style={{ background: "#364035" }}
        />

        {/* Bottom */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs" style={{ color: "#7a706a" }}>
            © 2026 ThreadFlow. Fait avec ♥ pour les brodeuses du monde entier.
          </p>
          <div className="flex gap-6 flex-wrap justify-center">
            {LEGAL_LINKS.map(({ label, href }) => (
              <Link
                key={label}
                href={href}
                className="text-xs transition-opacity hover:opacity-80"
                style={{ color: "#7a706a", textDecoration: "none" }}
              >
                {label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
