/*
 * ThreadFlow — Section Liste d'Attente (CTA Final)
 * Connecté à la base de données via tRPC
 * Design: Fond dégradé terracotta/sauge, formulaire email neumorphique
 */
import { useState } from "react";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { ArrowRight, CheckCircle2, Sparkles, Medal } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function WaitlistSection() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [goldenNeedle, setGoldenNeedle] = useState(false);
  const [alreadyRegistered, setAlreadyRegistered] = useState(false);
  const { ref, isVisible } = useIntersectionObserver();

  // Compteur en temps réel depuis la DB
  const { data: countData } = trpc.waitlist.count.useQuery(undefined, {
    refetchInterval: 30000, // Rafraîchir toutes les 30 secondes
  });
  const waitlistCount = countData?.count ?? 0;

  const joinMutation = trpc.waitlist.join.useMutation({
    onSuccess: (data) => {
      setSubmitted(true);
      setGoldenNeedle(data.goldenNeedle);
      setAlreadyRegistered(data.alreadyRegistered);
      if (data.goldenNeedle && !data.alreadyRegistered) {
        toast.success("🏅 Badge Golden Needle obtenu !", {
          description: "Vous faites partie des 1000 premières fondatrices ThreadFlow.",
          duration: 6000,
        });
      }
    },
    onError: (error) => {
      toast.error("Une erreur est survenue", {
        description: error.message || "Veuillez réessayer.",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    joinMutation.mutate({ email: email.trim(), source: "homepage-waitlist" });
  };

  return (
    <section
      id="waitlist"
      className="py-24 lg:py-32 relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #C4714A 0%, #3D4A3E 100%)",
      }}
    >
      {/* Decorative aida grid */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage:
            "linear-gradient(#d4cfc680 1px, transparent 1px), linear-gradient(90deg, #d4cfc680 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }}
      />

      <div className="container relative z-10">
        <div
          ref={ref as React.RefObject<HTMLDivElement>}
          className={`max-w-2xl mx-auto text-center transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
          }`}
        >
          {/* Badge */}
          <div
            className="inline-flex items-center gap-2 pill-badge mb-6"
            style={{
              background: "#e8e3da33",
              color: "#e8e3da",
              border: "1px solid #e8e3da4d",
            }}
          >
            <Sparkles size={12} />
            Accès anticipé — Essai 30 jours sans carte bancaire
          </div>

          <h2
            className="font-['Cormorant_Garamond'] text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 text-white"
          >
            Rejoignez les fondatrices ThreadFlow.
          </h2>

          <p className="text-lg leading-relaxed mb-10" style={{ color: "#F5F0E8" }}>
            En 30 jours, vous aurez brodé des milliers de points, géré votre inventaire complet
            et économisé des heures de préparation. Continuez pour 4,99 €/mois — ou pas.
            Aucune obligation.
          </p>

          {!submitted ? (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                required
                disabled={joinMutation.isPending}
                className="flex-1 px-5 py-4 rounded-2xl text-sm outline-none transition-all duration-200 disabled:opacity-60"
                style={{
                  background: "#e8e3daf2",
                  color: "#3D4A3E",
                  border: "2px solid transparent",
                }}
                onFocus={(e) => {
                  e.target.style.border = "2px solid #C4714A";
                }}
                onBlur={(e) => {
                  e.target.style.border = "2px solid transparent";
                }}
              />
              <button
                type="submit"
                disabled={joinMutation.isPending}
                className="px-6 py-4 rounded-2xl font-semibold text-sm transition-all duration-200 hover:opacity-90 hover:-translate-y-0.5 flex items-center justify-center gap-2 flex-shrink-0 disabled:opacity-60 disabled:cursor-not-allowed"
                style={{
                  background: "#e8e3da",
                  color: "#8B5E3C",
                  boxShadow: "0 4px 16px #3D4A3E33",
                }}
              >
                {joinMutation.isPending ? (
                  <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    Rejoindre
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>
          ) : (
            <div
              className="flex flex-col items-center gap-4 p-8 rounded-3xl"
              style={{ background: "#e8e3da26" }}
            >
              {goldenNeedle && !alreadyRegistered ? (
                <Medal size={52} className="text-yellow-300" />
              ) : (
                <CheckCircle2 size={48} className="text-white" />
              )}
              <h3 className="font-['Cormorant_Garamond'] text-2xl font-semibold text-white">
                {alreadyRegistered
                  ? "Vous êtes déjà sur la liste !"
                  : goldenNeedle
                  ? "🏅 Badge Golden Needle obtenu !"
                  : "Bienvenue dans la communauté ThreadFlow !"}
              </h3>
              <p style={{ color: "#F5F0E8" }}>
                {alreadyRegistered
                  ? "Votre adresse est déjà enregistrée. Nous vous enverrons votre accès très bientôt."
                  : goldenNeedle
                  ? "Vous faites partie des 1000 premières fondatrices. Votre badge Golden Needle vous sera remis à l'ouverture."
                  : "Vous êtes sur la liste. Nous vous enverrons votre accès anticipé très bientôt."}
              </p>
            </div>
          )}

          {/* Trust signals */}
          <div className="mt-8 flex flex-wrap justify-center gap-6">
            {[
              "✓ Sans carte bancaire",
              "✓ Annulation à tout moment",
              "✓ iOS, Android & Web",
              "✓ Données sécurisées",
            ].map((trust) => (
              <span
                key={trust}
                className="text-sm"
                style={{ color: "#D4C5A9" }}
              >
                {trust}
              </span>
            ))}
          </div>

          {/* Social proof counter — données réelles */}
          <div className="mt-10 pt-8 border-t border-white/20">
            <p className="text-sm" style={{ color: "#D4C5A9" }}>
              <strong className="text-white">
                {waitlistCount.toLocaleString("fr-FR")} brodeuses
              </strong>{" "}
              {waitlistCount > 0 ? (
                <>sont déjà sur la liste d'attente. Le badge{" "}</>
              ) : (
                <>Soyez parmi les premières. Le badge{" "}</>
              )}
              <strong className="text-white">Golden Needle</strong> attend les 1 000 premières.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
