import { useEffect, useRef, useState } from "react";
import { Scan, Upload, CheckCircle2, ShoppingCart, Route, Users } from "lucide-react";

const N = {
  bg: "#e8e3da",
  raised: "8px 8px 20px #c4bfb6, -8px -8px 20px #ffffff",
  raisedSm: "4px 4px 10px #c4bfb6, -4px -4px 10px #ffffff",
  raisedLg: "14px 14px 32px #c4bfb6, -14px -14px 32px #ffffff",
  inset: "inset 4px 4px 10px #c4bfb6, inset -4px -4px 10px #ffffff",
  terracotta: "#C4714A",
  sage: "#7A9E7E",
  slate: "#3D4A3E",
  muted: "#6b7a6c",
  gold: "#C9A84C",
};

const steps = [
  {
    number: "01",
    icon: Scan,
    title: "Montrez-moi vos fils",
    description: "Pointez votre smartphone vers votre boîte DMC. L'IA identifie chaque couleur en 45 secondes.",
    highlight: "147 couleurs enregistrées.",
    color: N.sage,
  },
  {
    number: "02",
    icon: Upload,
    title: "Importez votre patron",
    description: "PDF, image, fichier XSD ou OXS — ThreadFlow convertit automatiquement votre patron en grille interactive.",
    highlight: null,
    color: N.terracotta,
  },
  {
    number: "03",
    icon: CheckCircle2,
    title: "Le message pivot",
    description: "ThreadFlow croise votre inventaire avec les besoins du patron et vous dit exactement ce qu'il manque.",
    highlight: "Bonne nouvelle — vous avez déjà 89 % des fils. Il vous manque seulement : DMC 3750, DMC 223, DMC 677.",
    color: N.sage,
  },
  {
    number: "04",
    icon: ShoppingCart,
    title: "Liste de courses générée",
    description: "En un clic, ThreadFlow génère votre liste de courses exacte. Ce que vous faisiez en une heure, accompli en 5 minutes.",
    highlight: null,
    color: N.gold,
  },
];

function StepCard({ step, index, visible }: { step: typeof steps[0]; index: number; visible: boolean }) {
  const Icon = step.icon;
  return (
    <div style={{
      display: "flex", gap: 20, marginBottom: "1.5rem",
      opacity: visible ? 1 : 0,
      transform: visible ? "translateX(0)" : "translateX(24px)",
      transition: `all 0.6s ease ${index * 0.12}s`,
    }}>
      {/* Number + line */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
        <div style={{
          width: 48, height: 48, borderRadius: 16, flexShrink: 0,
          background: N.bg, boxShadow: N.raised,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontSize: "1.1rem", fontWeight: 700, color: step.color,
        }}>
          {step.number}
        </div>
        {index < steps.length - 1 && (
          <div style={{
            width: 2, flex: 1, marginTop: 8,
            background: `linear-gradient(to bottom, ${step.color}60, transparent)`,
            minHeight: 40,
          }} />
        )}
      </div>

      {/* Content card */}
      <div style={{
        flex: 1, paddingBottom: "1.5rem",
        borderRadius: 20, background: N.bg,
        boxShadow: N.raisedSm, padding: "1.25rem 1.5rem",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 10,
            background: N.bg, boxShadow: N.inset,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Icon size={16} color={step.color} />
          </div>
          <h3 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: "1.3rem", fontWeight: 700, color: N.slate,
          }}>
            {step.title}
          </h3>
        </div>
        <p style={{ fontSize: "0.9rem", color: N.muted, lineHeight: 1.65, marginBottom: step.highlight ? 12 : 0 }}>
          {step.description}
        </p>
        {step.highlight && (
          <div style={{
            borderRadius: 12, padding: "12px 16px",
            background: N.bg, boxShadow: N.inset,
            borderLeft: `4px solid ${step.color}`,
            fontSize: "0.85rem", fontStyle: "italic",
            color: N.slate, lineHeight: 1.6,
          }}>
            "{step.highlight}"
          </div>
        )}
      </div>
    </div>
  );
}

export default function AhaMomentSection() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section id="how-it-works" ref={ref} style={{ background: N.bg, padding: "6rem 0" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 1.5rem" }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: "4rem", alignItems: "start",
        }}>
          {/* Left — sticky intro */}
          <div style={{
            position: "sticky", top: 100,
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(24px)",
            transition: "all 0.7s ease",
          }}>
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 8,
              padding: "8px 18px", borderRadius: 50,
              background: N.bg, boxShadow: N.raisedSm,
              marginBottom: "1.5rem",
            }}>
              <span style={{ fontSize: "0.78rem", fontWeight: 700, color: N.sage, letterSpacing: "0.06em", textTransform: "uppercase" }}>
                Le moment "Aha"
              </span>
            </div>

            <h2 style={{
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              fontSize: "clamp(2.2rem, 4vw, 3.5rem)",
              fontWeight: 700, color: N.slate,
              lineHeight: 1.15, marginBottom: "1rem",
            }}>
              5 minutes pour changer votre façon de broder.
            </h2>
            <p style={{ fontSize: "1rem", color: N.muted, lineHeight: 1.7, marginBottom: "2rem" }}>
              Avant de piquer la première aiguille, vous passiez 30 minutes à 2 heures à préparer un projet.
              ThreadFlow réduit cette friction à néant.
            </p>

            {/* Stats grid */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
              {[
                { value: "45s", label: "Pour scanner l'inventaire" },
                { value: "89%", label: "Des fils déjà présents" },
                { value: "−6h", label: "De préparation économisées" },
                { value: "5 min", label: "Pour être prête à broder" },
              ].map((stat, i) => (
                <div key={i} style={{
                  borderRadius: 16, padding: "1rem 1.25rem",
                  background: N.bg, boxShadow: N.raisedSm,
                }}>
                  <div style={{
                    fontFamily: "'Cormorant Garamond', Georgia, serif",
                    fontSize: "2rem", fontWeight: 700, color: N.terracotta,
                    lineHeight: 1.1, marginBottom: 4,
                  }}>
                    {stat.value}
                  </div>
                  <div style={{ fontSize: "0.78rem", color: N.muted, lineHeight: 1.4 }}>
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right — steps */}
          <div style={{ paddingTop: "0.5rem" }}>
            {steps.map((step, i) => (
              <StepCard key={step.number} step={step} index={i} visible={visible} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
