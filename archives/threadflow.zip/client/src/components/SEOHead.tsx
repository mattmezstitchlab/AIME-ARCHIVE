/*
 * ThreadFlow — SEOHead
 * Injecte dynamiquement les balises <title>, <meta>, Open Graph et Twitter Card
 * dans le <head> du document pour chaque page.
 */
import { useEffect } from "react";

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: "website" | "article";
  publishedAt?: string;
  author?: string;
  noIndex?: boolean;
}

const SITE_NAME = "ThreadFlow";
const DEFAULT_TITLE = "ThreadFlow — Le Figma du point de croix";
const DEFAULT_DESCRIPTION =
  "ThreadFlow est le premier compagnon de broderie point de croix avec IA. Scannez vos fils DMC en 45 secondes, optimisez vos patrons avec Smart Pathing™, et brodez en communauté.";
const DEFAULT_IMAGE = "https://threadflow-u5ppwkeo.manus.space/og-image.png";
const SITE_URL = "https://threadflow-u5ppwkeo.manus.space";
const TWITTER_HANDLE = "@threadflow_app";

function setMeta(name: string, content: string, property = false) {
  const attr = property ? "property" : "name";
  let el = document.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

export default function SEOHead({
  title,
  description = DEFAULT_DESCRIPTION,
  image = DEFAULT_IMAGE,
  url,
  type = "website",
  publishedAt,
  author,
  noIndex = false,
}: SEOProps) {
  const fullTitle = title ? `${title} — ${SITE_NAME}` : DEFAULT_TITLE;
  const canonicalUrl = url ? `${SITE_URL}${url}` : SITE_URL;

  useEffect(() => {
    // Title
    document.title = fullTitle;

    // Description
    setMeta("description", description);

    // Canonical
    setLink("canonical", canonicalUrl);

    // Robots
    setMeta("robots", noIndex ? "noindex,nofollow" : "index,follow");

    // Open Graph
    setMeta("og:site_name", SITE_NAME, true);
    setMeta("og:title", fullTitle, true);
    setMeta("og:description", description, true);
    setMeta("og:image", image, true);
    setMeta("og:image:width", "1200", true);
    setMeta("og:image:height", "630", true);
    setMeta("og:image:alt", fullTitle, true);
    setMeta("og:url", canonicalUrl, true);
    setMeta("og:type", type, true);
    setMeta("og:locale", "fr_FR", true);

    if (type === "article") {
      if (publishedAt) setMeta("article:published_time", publishedAt, true);
      if (author) setMeta("article:author", author, true);
      setMeta("article:publisher", SITE_URL, true);
    }

    // Twitter Card
    setMeta("twitter:card", "summary_large_image");
    setMeta("twitter:site", TWITTER_HANDLE);
    setMeta("twitter:creator", TWITTER_HANDLE);
    setMeta("twitter:title", fullTitle);
    setMeta("twitter:description", description);
    setMeta("twitter:image", image);
    setMeta("twitter:image:alt", fullTitle);

    // Schema.org JSON-LD
    const existingLd = document.querySelector('script[type="application/ld+json"]');
    if (existingLd) existingLd.remove();

    const ld = document.createElement("script");
    ld.type = "application/ld+json";
    ld.textContent = JSON.stringify(
      type === "article"
        ? {
            "@context": "https://schema.org",
            "@type": "Article",
            headline: fullTitle,
            description,
            image,
            url: canonicalUrl,
            datePublished: publishedAt,
            author: { "@type": "Organization", name: SITE_NAME },
            publisher: {
              "@type": "Organization",
              name: SITE_NAME,
              logo: { "@type": "ImageObject", url: `${SITE_URL}/logo.png` },
            },
          }
        : {
            "@context": "https://schema.org",
            "@type": "WebApplication",
            name: SITE_NAME,
            description,
            url: canonicalUrl,
            applicationCategory: "UtilitiesApplication",
            operatingSystem: "iOS, Android, Web",
            offers: {
              "@type": "Offer",
              price: "0",
              priceCurrency: "EUR",
              description: "Plan gratuit disponible",
            },
          }
    );
    document.head.appendChild(ld);
  }, [fullTitle, description, image, canonicalUrl, type, publishedAt, author, noIndex]);

  return null;
}
