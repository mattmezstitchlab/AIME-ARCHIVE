import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Users, Calendar, CheckCircle2, Clock, Save, Trophy, Layers } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface SALForm {
  name: string;
  designer: string;
  description: string;
  startDate: string;
  endDate: string;
  totalParts: string;
}

const EMPTY_FORM: SALForm = {
  name: "", designer: "", description: "",
  startDate: new Date().toISOString().split("T")[0]!,
  endDate: "", totalParts: "4",
};

const STATUS_CONFIG = {
  upcoming: { label: "À venir", color: "#C4714A" },
  active: { label: "En cours", color: "#7A9E7E" },
  completed: { label: "Terminé", color: "#3D4A3E" },
};

export default function SAL() {
  const utils = trpc.useUtils();
  const { data: sals, isLoading } = trpc.sal.list.useQuery();
  const joinMutation = trpc.sal.join.useMutation({
    onSuccess: () => { utils.sal.list.invalidate(); toast.success("Vous avez rejoint ce SAL !"); },
    onError: (e: { message: string }) => toast.error(e.message),
  });
  const leaveMutation = trpc.sal.leave.useMutation({
    onSuccess: () => { utils.sal.list.invalidate(); toast.success("Vous avez quitté ce SAL"); },
    onError: (e: { message: string }) => toast.error(e.message),
  });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<SALForm>(EMPTY_FORM);

  const handleSubmit = () => {
    if (!form.name.trim()) { toast.error("Le nom du SAL est requis"); return; }
    toast.info("La création de SAL sera disponible prochainement.");
    setShowForm(false);
  };

  return (
    <AppLayout title="SAL Sync">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              SAL Sync™
            </h1>
            <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>
              Stitch-Alongs — brodez ensemble, à votre rythme
            </p>
          </div>
          <button
            onClick={() => { setForm(EMPTY_FORM); setShowForm(true); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white", boxShadow: "0 4px 12px rgba(196,113,74,0.3)" }}
          >
            <Plus className="w-4 h-4" /> Créer un SAL
          </button>
        </div>

        {/* Liste des SAL */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: "var(--terracotta)", borderTopColor: "transparent" }} />
          </div>
        ) : (sals ?? []).length === 0 ? (
          <div className="text-center py-16 rounded-2xl" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
            <Users className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--text-muted)" }} />
            <p className="text-lg font-semibold mb-2" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              Aucun SAL pour l'instant
            </p>
            <p className="text-sm mb-6" style={{ color: "var(--text-muted)" }}>
              Créez un Stitch-Along et invitez d'autres brodeuses à vous rejoindre
            </p>
            <button
              onClick={() => { setForm(EMPTY_FORM); setShowForm(true); }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold"
              style={{ background: "var(--terracotta)", color: "white" }}
            >
              <Plus className="w-4 h-4" /> Créer un SAL
            </button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {(sals ?? []).map(sal => {
              const statusCfg = STATUS_CONFIG[sal.status as keyof typeof STATUS_CONFIG] ?? STATUS_CONFIG.upcoming;
              const parts: Array<{ part: number; completedAt: string | null }> = (() => {
                try { return JSON.parse(sal.parts ?? "[]"); } catch { return []; }
              })();
              const completedParts = parts.filter(p => p.completedAt).length;
              const progress = sal.totalParts > 0 ? Math.round(completedParts / sal.totalParts * 100) : 0;

              return (
                <div
                  key={sal.id}
                  className="rounded-2xl p-5 flex flex-col gap-4"
                  style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif", fontSize: "1.1rem" }}>
                        {sal.title}
                      </h3>
                      {sal.designer && (
                        <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>par {sal.designer}</p>
                      )}
                    </div>
                    <span
                      className="text-xs px-2.5 py-1 rounded-full font-medium flex-shrink-0 ml-2"
                      style={{ background: `${statusCfg.color}18`, color: statusCfg.color }}
                    >
                      {statusCfg.label}
                    </span>
                  </div>

                  {sal.description && (
                    <p className="text-sm line-clamp-2" style={{ color: "var(--text-muted)" }}>{sal.description}</p>
                  )}

                  {/* Infos */}
                  <div className="flex flex-wrap gap-3 text-xs" style={{ color: "var(--text-muted)" }}>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {new Date(sal.startDate + "T12:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}
                    </span>
                    <span className="flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5" />
                      {sal.totalParts} parties
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {sal.participantsCount} participant{sal.participantsCount !== 1 ? "s" : ""}
                    </span>
                  </div>

                  {/* Progression des parties */}
                  {sal.isJoined && sal.totalParts > 0 && (
                    <div>
                      <div className="flex justify-between text-xs mb-1.5" style={{ color: "var(--text-muted)" }}>
                        <span>Ma progression</span>
                        <span className="font-semibold" style={{ color: "var(--terracotta)" }}>
                          {completedParts}/{sal.totalParts} parties
                        </span>
                      </div>
                      <div className="h-1.5 rounded-full overflow-hidden mb-2" style={{ background: "rgba(212,197,169,0.3)" }}>
                        <div className="h-full rounded-full" style={{ width: `${progress}%`, background: "linear-gradient(90deg, var(--terracotta), var(--sage))" }} />
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {Array.from({ length: sal.totalParts }, (_, i) => {
                          const partData = parts.find(p => p.part === i + 1);
                          const isDone = !!partData?.completedAt;
                          return (
                            <button
                              key={i}
                              onClick={() => !isDone && toast.info("Marquer une partie sera disponible prochainement.")}
                              disabled={isDone}
                              className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs transition-all"
                              style={{
                                background: isDone ? "rgba(122,158,126,0.15)" : "rgba(212,197,169,0.2)",
                                color: isDone ? "var(--sage)" : "var(--text-muted)",
                                cursor: isDone ? "default" : "pointer",
                              }}
                            >
                              {isDone ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                              P{i + 1}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2 mt-auto">
                    {sal.isJoined ? (
                      <button
                        onClick={() => leaveMutation.mutate({ salId: sal.id })}
                        disabled={leaveMutation.isPending}
                        className="flex-1 py-2 rounded-xl text-sm font-medium"
                        style={{ background: "rgba(212,197,169,0.3)", color: "var(--slate)" }}
                      >
                        Quitter
                      </button>
                    ) : (
                      <button
                        onClick={() => joinMutation.mutate({ salId: sal.id })}
                        disabled={joinMutation.isPending}
                        className="flex-1 py-2 rounded-xl text-sm font-semibold"
                        style={{ background: "linear-gradient(135deg, var(--sage), #5a7e5e)", color: "white" }}
                      >
                        Rejoindre
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal formulaire */}
      <Dialog open={showForm} onOpenChange={open => { if (!open) { setShowForm(false); setForm(EMPTY_FORM); } }}>
        <DialogContent className="max-w-md" style={{ background: "var(--ivory)" }}>
          <DialogHeader>
            <DialogTitle style={{ fontFamily: "Cormorant Garamond, serif", color: "var(--slate)" }}>
              Créer un SAL
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Nom du SAL *</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Ex: SAL Jardin de Versailles 2025" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Designer</Label>
                <Input value={form.designer} onChange={e => setForm(f => ({ ...f, designer: e.target.value }))}
                  placeholder="Ex: Isabelle Vautier" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Nombre de parties</Label>
                <Input type="number" min="1" max="52" value={form.totalParts}
                  onChange={e => setForm(f => ({ ...f, totalParts: e.target.value }))}
                  className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Date de début</Label>
                <Input type="date" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))}
                  className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Date de fin</Label>
                <Input type="date" value={form.endDate} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))}
                  className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Description</Label>
              <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Décrivez ce SAL…" rows={3} className="mt-1 resize-none" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => { setShowForm(false); setForm(EMPTY_FORM); }}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                style={{ background: "rgba(212,197,169,0.3)", color: "var(--slate)" }}
              >
                Annuler
              </button>
              <button
                onClick={handleSubmit}
                disabled={false}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white" }}
              >
                <Save className="w-4 h-4" /> Créer
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
