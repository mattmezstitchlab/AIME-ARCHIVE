import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import {
  Scissors, Clock, Target, CheckCircle2, TrendingUp, Plus,
  Package, BookOpen, Users, ArrowRight, Flame, Award
} from "lucide-react";

function StatCard({ label, value, unit, icon: Icon, color }: {
  label: string; value: number | string; unit?: string;
  icon: React.ElementType; color: string;
}) {
  return (
    <div
      className="rounded-2xl p-5 flex items-center gap-4"
      style={{
        background: "var(--ivory)",
        boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)",
      }}
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}18` }}
      >
        <Icon className="w-6 h-6" style={{ color }} />
      </div>
      <div>
        <div className="text-2xl font-bold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
          {typeof value === "number" ? value.toLocaleString("fr-FR") : value}
          {unit && <span className="text-base font-normal ml-1" style={{ color: "var(--text-muted)" }}>{unit}</span>}
        </div>
        <div className="text-sm" style={{ color: "var(--text-muted)" }}>{label}</div>
      </div>
    </div>
  );
}

function ProjectCard({ project }: { project: {
  id: number; name: string; status: string;
  completedStitches: number | null; totalStitches: number | null;
  designer: string | null; patternName: string | null;
} }) {
  const progress = project.totalStitches && project.totalStitches > 0
    ? Math.round((project.completedStitches ?? 0) / project.totalStitches * 100)
    : 0;

  const statusColors: Record<string, string> = {
    in_progress: "#7A9E7E",
    not_started: "#C4714A",
    paused: "#D4C5A9",
    completed: "#3D4A3E",
  };
  const statusLabels: Record<string, string> = {
    in_progress: "En cours",
    not_started: "Non démarré",
    paused: "En pause",
    completed: "Terminé",
  };

  return (
    <Link href={`/app/projects`}>
      <a
        className="block rounded-2xl p-5 cursor-pointer transition-all duration-200 hover:-translate-y-0.5"
        style={{
          background: "var(--ivory)",
          boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)",
        }}
      >
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-semibold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif", fontSize: "1.1rem" }}>
              {project.name}
            </h3>
            {project.designer && (
              <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>par {project.designer}</p>
            )}
          </div>
          <span
            className="text-xs px-2.5 py-1 rounded-full font-medium"
            style={{
              background: `${statusColors[project.status] ?? "#D4C5A9"}18`,
              color: statusColors[project.status] ?? "#D4C5A9",
            }}
          >
            {statusLabels[project.status] ?? project.status}
          </span>
        </div>

        {project.totalStitches && project.totalStitches > 0 ? (
          <div>
            <div className="flex justify-between text-xs mb-1.5" style={{ color: "var(--text-muted)" }}>
              <span>{(project.completedStitches ?? 0).toLocaleString("fr-FR")} pts</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: "rgba(212,197,169,0.3)" }}>
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${progress}%`,
                  background: "linear-gradient(90deg, var(--terracotta), var(--sage))",
                }}
              />
            </div>
          </div>
        ) : (
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            {project.patternName ?? "Patron non défini"}
          </p>
        )}
      </a>
    </Link>
  );
}

export default function Dashboard() {
  const { data: stats } = trpc.sessions.stats.useQuery();
  const { data: projects } = trpc.projects.list.useQuery();
  const { data: inventory } = trpc.inventory.list.useQuery();

  const activeProjects = projects?.filter(p => p.status === "in_progress") ?? [];
  const recentProjects = projects?.slice(0, 4) ?? [];

  // Shopping list intelligente : fils manquants pour les projets actifs
  const shoppingList = (() => {
    if (!projects || !inventory) return [];
    const inventoryMap: Record<string, number> = {};
    inventory.forEach(item => {
      inventoryMap[item.dmcNumber] = item.metersRemaining ?? 0;
    });

    const needed: Record<string, { dmc: string; name: string; hex: string; needed: number; have: number }> = {};
    projects
      .filter(p => p.status === "in_progress" || p.status === "not_started")
      .forEach(p => {
        if (!p.threadsRequired) return;
        try {
          const threads = JSON.parse(p.threadsRequired) as Array<{
            dmc: string; name: string; hex: string; needed_meters: number;
          }>;
          threads.forEach(t => {
            const have = inventoryMap[t.dmc] ?? 0;
            if (have < t.needed_meters) {
              if (!needed[t.dmc]) {
                needed[t.dmc] = { dmc: t.dmc, name: t.name, hex: t.hex ?? "#C4956A", needed: 0, have };
              }
              needed[t.dmc].needed = Math.max(needed[t.dmc].needed, t.needed_meters);
            }
          });
        } catch {}
      });
    return Object.values(needed).slice(0, 6);
  })();

  const totalMinutes = stats?.totalMinutes ?? 0;
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  return (
    <AppLayout title="Dashboard">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1
              className="text-3xl font-bold"
              style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}
            >
              Bonjour, brodeuse 🧵
            </h1>
            <p className="mt-1 text-sm" style={{ color: "var(--text-muted)" }}>
              Voici votre tableau de bord ThreadFlow
            </p>
          </div>
          <Link href="/app/projects">
            <a
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
              style={{
                background: "linear-gradient(135deg, var(--terracotta), #a85a35)",
                color: "white",
                boxShadow: "0 4px 12px rgba(196,113,74,0.3)",
              }}
            >
              <Plus className="w-4 h-4" />
              Nouveau projet
            </a>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Points brodés"
            value={stats?.totalStitches ?? 0}
            icon={Scissors}
            color="#C4714A"
          />
          <StatCard
            label="Temps total"
            value={hours > 0 ? `${hours}h${minutes > 0 ? ` ${minutes}m` : ""}` : `${minutes}m`}
            icon={Clock}
            color="#7A9E7E"
          />
          <StatCard
            label="Sessions"
            value={stats?.totalSessions ?? 0}
            icon={Flame}
            color="#C4714A"
          />
          <StatCard
            label="Projets terminés"
            value={stats?.completedProjects ?? 0}
            icon={Award}
            color="#7A9E7E"
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Projets actifs */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
                Projets récents
              </h2>
              <Link href="/app/projects">
                <a className="flex items-center gap-1 text-sm font-medium" style={{ color: "var(--terracotta)" }}>
                  Voir tout <ArrowRight className="w-4 h-4" />
                </a>
              </Link>
            </div>

            {recentProjects.length === 0 ? (
              <div
                className="rounded-2xl p-8 text-center"
                style={{
                  background: "var(--ivory)",
                  boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)",
                }}
              >
                <Scissors className="w-10 h-10 mx-auto mb-3" style={{ color: "var(--text-muted)" }} />
                <p className="font-medium mb-1" style={{ color: "var(--slate)" }}>Aucun projet encore</p>
                <p className="text-sm mb-4" style={{ color: "var(--text-muted)" }}>
                  Créez votre premier projet de broderie
                </p>
                <Link href="/app/projects">
                  <a
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold"
                    style={{ background: "var(--terracotta)", color: "white" }}
                  >
                    <Plus className="w-4 h-4" /> Créer un projet
                  </a>
                </Link>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {recentProjects.map(p => (
                  <ProjectCard key={p.id} project={p} />
                ))}
              </div>
            )}
          </div>

          {/* Panneau latéral */}
          <div className="space-y-4">
            {/* Shopping list intelligente */}
            <div
              className="rounded-2xl p-5"
              style={{
                background: "var(--ivory)",
                boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)",
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
                  🛒 Liste de courses
                </h3>
                <Link href="/app/inventory">
                  <a className="text-xs" style={{ color: "var(--terracotta)" }}>Inventaire</a>
                </Link>
              </div>

              {shoppingList.length === 0 ? (
                <div className="text-center py-4">
                  <CheckCircle2 className="w-8 h-8 mx-auto mb-2" style={{ color: "var(--sage)" }} />
                  <p className="text-sm font-medium" style={{ color: "var(--slate)" }}>Tout est en stock !</p>
                  <p className="text-xs mt-1" style={{ color: "var(--text-muted)" }}>
                    {inventory && inventory.length > 0
                      ? "Votre inventaire couvre tous vos projets"
                      : "Ajoutez des fils à votre inventaire"}
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {shoppingList.map(item => (
                    <div key={item.dmc} className="flex items-center gap-3">
                      <div
                        className="w-5 h-5 rounded-full flex-shrink-0 border-2 border-white"
                        style={{ background: item.hex, boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate" style={{ color: "var(--slate)" }}>
                          DMC {item.dmc}
                        </div>
                        <div className="text-xs" style={{ color: "var(--text-muted)" }}>
                          {item.have.toFixed(1)}m / {item.needed.toFixed(1)}m requis
                        </div>
                      </div>
                      <div
                        className="text-xs px-2 py-0.5 rounded-full"
                        style={{ background: "rgba(196,113,74,0.1)", color: "var(--terracotta)" }}
                      >
                        -{(item.needed - item.have).toFixed(1)}m
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Liens rapides */}
            <div
              className="rounded-2xl p-5"
              style={{
                background: "var(--ivory)",
                boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)",
              }}
            >
              <h3 className="font-semibold mb-4" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
                Accès rapide
              </h3>
              <div className="space-y-2">
                {[
                  { href: "/app/diary", label: "Ajouter une session", icon: BookOpen, color: "#7A9E7E" },
                  { href: "/app/inventory", label: "Gérer l'inventaire", icon: Package, color: "#C4714A" },
                  { href: "/app/sal", label: "SAL Sync", icon: Users, color: "#3D4A3E" },
                  { href: "/app/editor", label: "Éditeur de patron", icon: Target, color: "#7A9E7E" },
                ].map(({ href, label, icon: Icon, color }) => (
                  <Link key={href} href={href}>
                    <a
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all hover:opacity-80"
                      style={{
                        background: `${color}10`,
                        color: "var(--slate)",
                      }}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" style={{ color }} />
                      <span className="text-sm font-medium">{label}</span>
                      <ArrowRight className="w-3.5 h-3.5 ml-auto" style={{ color: "var(--text-muted)" }} />
                    </a>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
