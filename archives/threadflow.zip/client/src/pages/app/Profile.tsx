/**
 * Profil brodeuse — Collection DMC publique, géolocalisation, disponibilité échange
 * Accessible depuis SAL Sync et la navigation principale
 */
import { useState, useEffect } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { DMC_FULL_PALETTE, DMC_BY_CODE } from "@shared/dmcColors";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  MapPin, Package, Globe, Eye, EyeOff, Save, Plus, Minus,
  ArrowLeftRight, Search, Check, Loader2, User
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface CollectionItem {
  dmcCode: string;
  quantity: number;
  forExchange: boolean;
}

// ─── Composant principal ──────────────────────────────────────────────────────

export default function Profile() {
  const { user, isAuthenticated } = useAuth();

  // Profil
  const [bio, setBio] = useState("");
  const [city, setCity] = useState("");
  const [country, setCountry] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [availableForExchange, setAvailableForExchange] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [locationSet, setLocationSet] = useState(false);
  const [profileSaved, setProfileSaved] = useState(false);

  // Collection DMC
  const [searchDmc, setSearchDmc] = useState("");
  const [collectionMap, setCollectionMap] = useState<Record<string, CollectionItem>>({});
  const [addingDmc, setAddingDmc] = useState<string | null>(null);

  // Données
  const { data: myProfile, refetch: refetchProfile } = trpc.profile.me.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: myCollection, refetch: refetchCollection } = trpc.community.myCollection.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const upsertProfileMutation = trpc.profile.update.useMutation({
    onSuccess: () => {
      toast.success("Profil sauvegardé !");
      setProfileSaved(true);
      refetchProfile();
      setTimeout(() => setProfileSaved(false), 2000);
    },
    onError: () => toast.error("Erreur lors de la sauvegarde"),
  });

  const upsertItemMutation = trpc.community.upsertItem.useMutation({
    onSuccess: () => refetchCollection(),
    onError: () => toast.error("Erreur lors de la mise à jour"),
  });

  const removeItemMutation = trpc.community.removeItem.useMutation({
    onSuccess: () => refetchCollection(),
  });

  // Charger les données du profil
  useEffect(() => {
    if (myProfile) {
      setBio(myProfile.bio ?? "");
      setCity(myProfile.city ?? "");
      setCountry(myProfile.country ?? "");
      setIsPublic(myProfile.isPublic);
      setAvailableForExchange(myProfile.availableForExchange);
      if (myProfile.lat && myProfile.lng) setLocationSet(true);
    }
  }, [myProfile]);

  // Charger la collection
  useEffect(() => {
    if (myCollection) {
      const map: Record<string, CollectionItem> = {};
      myCollection.forEach(item => {
        map[item.dmcCode] = {
          dmcCode: item.dmcCode,
          quantity: item.quantity,
          forExchange: item.forExchange,
        };
      });
      setCollectionMap(map);
    }
  }, [myCollection]);

  // ─── Géolocalisation ────────────────────────────────────────────────────────

  const handleGeolocate = () => {
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        upsertProfileMutation.mutate({
          bio,
          city,
          country,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          isPublic,
          availableForExchange,
        });
        setLocationSet(true);
        setIsLocating(false);
        toast.success("Position enregistrée !");
      },
      () => {
        setIsLocating(false);
        toast.error("Impossible d'obtenir la position. Vérifiez les permissions.");
      }
    );
  };

  // ─── Sauvegarde profil ───────────────────────────────────────────────────────

  const handleSaveProfile = () => {
    upsertProfileMutation.mutate({
      bio,
      city,
      country,
      lat: myProfile?.lat ?? undefined,
      lng: myProfile?.lng ?? undefined,
      isPublic,
      availableForExchange,
    });
  };

  // ─── Collection DMC ──────────────────────────────────────────────────────────

  const filteredDmc = DMC_FULL_PALETTE.filter(c =>
    c.dmc.toLowerCase().includes(searchDmc.toLowerCase()) ||
    c.name.toLowerCase().includes(searchDmc.toLowerCase())
  ).slice(0, 30);

  const handleToggleItem = (dmcCode: string) => {
    const existing = collectionMap[dmcCode];
    if (existing) {
      // Retirer
      removeItemMutation.mutate({ dmcCode });
      const next = { ...collectionMap };
      delete next[dmcCode];
      setCollectionMap(next);
    } else {
      // Ajouter avec quantité 1
      upsertItemMutation.mutate({ dmcCode, quantity: 1, forExchange: false });
      setCollectionMap(prev => ({
        ...prev,
        [dmcCode]: { dmcCode, quantity: 1, forExchange: false },
      }));
    }
  };

  const handleUpdateQuantity = (dmcCode: string, delta: number) => {
    const existing = collectionMap[dmcCode];
    if (!existing) return;
    const newQty = Math.max(0, existing.quantity + delta);
    if (newQty === 0) {
      removeItemMutation.mutate({ dmcCode });
      const next = { ...collectionMap };
      delete next[dmcCode];
      setCollectionMap(next);
    } else {
      upsertItemMutation.mutate({ dmcCode, quantity: newQty, forExchange: existing.forExchange });
      setCollectionMap(prev => ({ ...prev, [dmcCode]: { ...existing, quantity: newQty } }));
    }
  };

  const handleToggleExchange = (dmcCode: string) => {
    const existing = collectionMap[dmcCode];
    if (!existing) return;
    upsertItemMutation.mutate({ dmcCode, quantity: existing.quantity, forExchange: !existing.forExchange });
    setCollectionMap(prev => ({
      ...prev,
      [dmcCode]: { ...existing, forExchange: !existing.forExchange },
    }));
  };

  const collectionItems = Object.values(collectionMap);
  const exchangeItems = collectionItems.filter(i => i.forExchange);

  // ─── Rendu ───────────────────────────────────────────────────────────────────

  return (
    <AppLayout>
      <div style={{ padding: "24px 28px", maxWidth: 900, margin: "0 auto" }}>

        {/* ── En-tête ── */}
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#3D4A3E", margin: "0 0 4px" }}>
            Mon profil brodeuse
          </h1>
          <p style={{ fontSize: 13, color: "#6b7a6c", margin: 0 }}>
            Apparaissez sur la carte SAL Sync et partagez votre collection DMC avec la communauté
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>

          {/* ── Colonne gauche : Infos profil ── */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

            {/* Avatar + nom */}
            <div style={{
              background: "#e8e3da",
              borderRadius: 16,
              padding: 20,
              boxShadow: "4px 4px 10px rgba(61,74,62,0.08), -2px -2px 6px rgba(255,255,255,0.7)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
                <div style={{
                  width: 64, height: 64, borderRadius: "50%",
                  background: "#ddd8cf",
                  border: "3px solid #7A9E7E",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 24, fontWeight: 700, color: "#3D4A3E",
                }}>
                  {user?.name?.[0]?.toUpperCase() ?? <User className="w-6 h-6" />}
                </div>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: "#3D4A3E" }}>
                    {user?.name ?? "Brodeuse anonyme"}
                  </div>
                  <div style={{ fontSize: 12, color: "#6b7a6c" }}>{user?.email}</div>
                  <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
                    {isPublic && (
                      <Badge style={{ fontSize: 10, background: "#7A9E7E", color: "white", border: "none" }}>
                        Visible sur la carte
                      </Badge>
                    )}
                    {availableForExchange && (
                      <Badge style={{ fontSize: 10, background: "#C4714A", color: "white", border: "none" }}>
                        Échange disponible
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              {/* Bio */}
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E", display: "block", marginBottom: 4 }}>
                  À propos de moi
                </label>
                <Textarea
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  placeholder="Brodeuse passionnée depuis 10 ans, spécialisée dans les motifs floraux…"
                  rows={3}
                  style={{
                    background: "#f0ebe2", border: "1px solid rgba(61,74,62,0.15)",
                    borderRadius: 8, resize: "none", fontSize: 13,
                  }}
                />
              </div>

              {/* Ville / Pays */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E", display: "block", marginBottom: 4 }}>
                    Ville
                  </label>
                  <Input
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    placeholder="Paris"
                    style={{ background: "#f0ebe2", border: "1px solid rgba(61,74,62,0.15)", borderRadius: 8, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E", display: "block", marginBottom: 4 }}>
                    Pays
                  </label>
                  <Input
                    value={country}
                    onChange={e => setCountry(e.target.value)}
                    placeholder="France"
                    style={{ background: "#f0ebe2", border: "1px solid rgba(61,74,62,0.15)", borderRadius: 8, fontSize: 13 }}
                  />
                </div>
              </div>

              {/* Visibilité & échange */}
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
                <button
                  onClick={() => setIsPublic(v => !v)}
                  style={{
                    display: "flex", alignItems: "center", gap: 8,
                    padding: "8px 12px", borderRadius: 8,
                    background: isPublic ? "rgba(122,158,126,0.15)" : "#f0ebe2",
                    border: `1px solid ${isPublic ? "#7A9E7E" : "rgba(61,74,62,0.15)"}`,
                    cursor: "pointer", textAlign: "left",
                  }}
                >
                  {isPublic ? <Eye className="w-4 h-4" style={{ color: "#7A9E7E" }} /> : <EyeOff className="w-4 h-4" style={{ color: "#6b7a6c" }} />}
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E" }}>
                      {isPublic ? "Profil visible sur la carte" : "Profil masqué"}
                    </div>
                    <div style={{ fontSize: 11, color: "#6b7a6c" }}>
                      {isPublic ? "Les autres brodeuses peuvent vous trouver" : "Vous n'apparaissez pas sur SAL Sync"}
                    </div>
                  </div>
                  <div style={{
                    marginLeft: "auto", width: 32, height: 18, borderRadius: 9,
                    background: isPublic ? "#7A9E7E" : "#D4C5A9",
                    position: "relative", transition: "background 0.2s",
                  }}>
                    <div style={{
                      position: "absolute", top: 2,
                      left: isPublic ? 16 : 2,
                      width: 14, height: 14, borderRadius: "50%",
                      background: "white", transition: "left 0.2s",
                      boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    }} />
                  </div>
                </button>

                <button
                  onClick={() => setAvailableForExchange(v => !v)}
                  style={{
                    display: "flex", alignItems: "center", gap: 8,
                    padding: "8px 12px", borderRadius: 8,
                    background: availableForExchange ? "rgba(196,113,74,0.12)" : "#f0ebe2",
                    border: `1px solid ${availableForExchange ? "#C4714A" : "rgba(61,74,62,0.15)"}`,
                    cursor: "pointer", textAlign: "left",
                  }}
                >
                  <ArrowLeftRight className="w-4 h-4" style={{ color: availableForExchange ? "#C4714A" : "#6b7a6c" }} />
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E" }}>
                      {availableForExchange ? "Disponible pour échange" : "Pas d'échange pour l'instant"}
                    </div>
                    <div style={{ fontSize: 11, color: "#6b7a6c" }}>
                      Les brodeuses cherchant vos couleurs pourront vous contacter
                    </div>
                  </div>
                  <div style={{
                    marginLeft: "auto", width: 32, height: 18, borderRadius: 9,
                    background: availableForExchange ? "#C4714A" : "#D4C5A9",
                    position: "relative", transition: "background 0.2s",
                  }}>
                    <div style={{
                      position: "absolute", top: 2,
                      left: availableForExchange ? 16 : 2,
                      width: 14, height: 14, borderRadius: "50%",
                      background: "white", transition: "left 0.2s",
                      boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    }} />
                  </div>
                </button>
              </div>

              {/* Géolocalisation */}
              <div style={{ display: "flex", gap: 8 }}>
                <Button
                  onClick={handleGeolocate}
                  disabled={isLocating}
                  variant="outline"
                  style={{
                    flex: 1, fontSize: 12, height: 36,
                    background: locationSet ? "rgba(122,158,126,0.1)" : "#f0ebe2",
                    border: `1px solid ${locationSet ? "#7A9E7E" : "rgba(61,74,62,0.2)"}`,
                    color: locationSet ? "#7A9E7E" : "#3D4A3E",
                  }}
                >
                  {isLocating ? <Loader2 className="w-3.5 h-3.5 mr-2 animate-spin" /> : <MapPin className="w-3.5 h-3.5 mr-2" />}
                  {locationSet ? "Position enregistrée ✓" : "Me géolocaliser"}
                </Button>

                <Button
                  onClick={handleSaveProfile}
                  disabled={upsertProfileMutation.isPending}
                  style={{
                    flex: 1, fontSize: 12, height: 36,
                    background: profileSaved ? "#7A9E7E" : "#C4714A",
                    color: "white", border: "none",
                  }}
                >
                  {upsertProfileMutation.isPending ? <Loader2 className="w-3.5 h-3.5 mr-2 animate-spin" /> : <Save className="w-3.5 h-3.5 mr-2" />}
                  {profileSaved ? "Sauvegardé !" : "Sauvegarder"}
                </Button>
              </div>
            </div>

            {/* Résumé collection */}
            <div style={{
              background: "#e8e3da",
              borderRadius: 16, padding: 16,
              boxShadow: "4px 4px 10px rgba(61,74,62,0.08), -2px -2px 6px rgba(255,255,255,0.7)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <Package className="w-4 h-4" style={{ color: "#7A9E7E" }} />
                <span style={{ fontSize: 13, fontWeight: 600, color: "#3D4A3E" }}>
                  Ma collection ({collectionItems.length} couleurs)
                </span>
              </div>

              <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
                <div style={{
                  flex: 1, background: "#f0ebe2", borderRadius: 10, padding: "10px 14px",
                  textAlign: "center",
                }}>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#3D4A3E" }}>
                    {collectionItems.length}
                  </div>
                  <div style={{ fontSize: 11, color: "#6b7a6c" }}>couleurs</div>
                </div>
                <div style={{
                  flex: 1, background: "#f0ebe2", borderRadius: 10, padding: "10px 14px",
                  textAlign: "center",
                }}>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#C4714A" }}>
                    {exchangeItems.length}
                  </div>
                  <div style={{ fontSize: 11, color: "#6b7a6c" }}>à échanger</div>
                </div>
                <div style={{
                  flex: 1, background: "#f0ebe2", borderRadius: 10, padding: "10px 14px",
                  textAlign: "center",
                }}>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#7A9E7E" }}>
                    {collectionItems.reduce((s, i) => s + i.quantity, 0)}
                  </div>
                  <div style={{ fontSize: 11, color: "#6b7a6c" }}>pelotes</div>
                </div>
              </div>

              {/* Aperçu des couleurs */}
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                {collectionItems.slice(0, 24).map(item => {
                  const color = DMC_BY_CODE[item.dmcCode];
                  return (
                    <div
                      key={item.dmcCode}
                      title={`DMC ${item.dmcCode} — ${color?.name ?? ""} (×${item.quantity})`}
                      style={{
                        width: 20, height: 20, borderRadius: 4,
                        background: color?.hex ?? "#ccc",
                        border: item.forExchange ? "2px solid #C4714A" : "1px solid rgba(61,74,62,0.1)",
                        cursor: "default",
                      }}
                    />
                  );
                })}
                {collectionItems.length > 24 && (
                  <div style={{
                    width: 20, height: 20, borderRadius: 4,
                    background: "#ddd8cf",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 9, color: "#6b7a6c",
                  }}>
                    +{collectionItems.length - 24}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ── Colonne droite : Gestion collection DMC ── */}
          <div style={{
            background: "#e8e3da",
            borderRadius: 16, padding: 20,
            boxShadow: "4px 4px 10px rgba(61,74,62,0.08), -2px -2px 6px rgba(255,255,255,0.7)",
            display: "flex", flexDirection: "column", gap: 12,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Globe className="w-4 h-4" style={{ color: "#7A9E7E" }} />
              <span style={{ fontSize: 13, fontWeight: 600, color: "#3D4A3E" }}>
                Gérer ma collection DMC
              </span>
            </div>

            {/* Recherche */}
            <div style={{ position: "relative" }}>
              <Search className="w-3.5 h-3.5" style={{
                position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)",
                color: "#6b7a6c",
              }} />
              <Input
                value={searchDmc}
                onChange={e => setSearchDmc(e.target.value)}
                placeholder="Rechercher DMC 321, Rouge cerise…"
                style={{
                  paddingLeft: 30, background: "#f0ebe2",
                  border: "1px solid rgba(61,74,62,0.15)", borderRadius: 8, fontSize: 12,
                }}
              />
            </div>

            {/* Liste des couleurs à ajouter */}
            <div style={{
              flex: 1, overflowY: "auto", maxHeight: 280,
              display: "flex", flexDirection: "column", gap: 2,
            }}>
              {filteredDmc.map(color => {
                const inCollection = !!collectionMap[color.dmc];
                return (
                  <div
                    key={color.dmc}
                    style={{
                      display: "flex", alignItems: "center", gap: 8,
                      padding: "6px 8px", borderRadius: 8,
                      background: inCollection ? "rgba(122,158,126,0.1)" : "transparent",
                      transition: "background 0.15s",
                    }}
                  >
                    <div style={{
                      width: 24, height: 24, borderRadius: 6,
                      background: color.hex,
                      border: "1px solid rgba(61,74,62,0.1)",
                      flexShrink: 0,
                    }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E" }}>
                        DMC {color.dmc}
                      </div>
                      <div style={{ fontSize: 11, color: "#6b7a6c", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" as const }}>
                        {color.name}
                      </div>
                    </div>

                    {inCollection ? (
                      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                        {/* Quantité */}
                        <button
                          onClick={() => handleUpdateQuantity(color.dmc, -1)}
                          style={{ width: 22, height: 22, borderRadius: 5, background: "#ddd8cf", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
                        >
                          <Minus className="w-3 h-3" style={{ color: "#6b7a6c" }} />
                        </button>
                        <span style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E", width: 20, textAlign: "center" }}>
                          {collectionMap[color.dmc]?.quantity ?? 1}
                        </span>
                        <button
                          onClick={() => handleUpdateQuantity(color.dmc, 1)}
                          style={{ width: 22, height: 22, borderRadius: 5, background: "#ddd8cf", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
                        >
                          <Plus className="w-3 h-3" style={{ color: "#6b7a6c" }} />
                        </button>

                        {/* Toggle échange */}
                        <button
                          onClick={() => handleToggleExchange(color.dmc)}
                          title="Disponible pour échange"
                          style={{
                            width: 22, height: 22, borderRadius: 5,
                            background: collectionMap[color.dmc]?.forExchange ? "#C4714A" : "#ddd8cf",
                            border: "none", cursor: "pointer",
                            display: "flex", alignItems: "center", justifyContent: "center",
                          }}
                        >
                          <ArrowLeftRight className="w-3 h-3" style={{ color: collectionMap[color.dmc]?.forExchange ? "white" : "#6b7a6c" }} />
                        </button>

                        {/* Retirer */}
                        <button
                          onClick={() => handleToggleItem(color.dmc)}
                          style={{
                            width: 22, height: 22, borderRadius: 5,
                            background: "#7A9E7E", border: "none", cursor: "pointer",
                            display: "flex", alignItems: "center", justifyContent: "center",
                          }}
                        >
                          <Check className="w-3 h-3" style={{ color: "white" }} />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleToggleItem(color.dmc)}
                        style={{
                          width: 28, height: 28, borderRadius: 7,
                          background: "#ddd8cf", border: "none", cursor: "pointer",
                          display: "flex", alignItems: "center", justifyContent: "center",
                        }}
                      >
                        <Plus className="w-3.5 h-3.5" style={{ color: "#6b7a6c" }} />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Collection actuelle */}
            {collectionItems.length > 0 && (
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E", marginBottom: 8 }}>
                  Ma collection ({collectionItems.length})
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 2, maxHeight: 200, overflowY: "auto" }}>
                  {collectionItems.map(item => {
                    const color = DMC_BY_CODE[item.dmcCode];
                    return (
                      <div key={item.dmcCode} style={{
                        display: "flex", alignItems: "center", gap: 8,
                        padding: "5px 8px", borderRadius: 7,
                        background: item.forExchange ? "rgba(196,113,74,0.08)" : "#f0ebe2",
                      }}>
                        <div style={{
                          width: 18, height: 18, borderRadius: 4,
                          background: color?.hex ?? "#ccc",
                          border: "1px solid rgba(61,74,62,0.1)", flexShrink: 0,
                        }} />
                        <span style={{ fontSize: 11, fontWeight: 600, color: "#3D4A3E", flex: 1 }}>
                          DMC {item.dmcCode}
                        </span>
                        <span style={{ fontSize: 11, color: "#6b7a6c" }}>×{item.quantity}</span>
                        {item.forExchange && (
                          <Badge style={{ fontSize: 9, padding: "1px 5px", background: "#C4714A", color: "white", border: "none" }}>
                            échange
                          </Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
