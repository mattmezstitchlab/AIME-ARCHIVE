/**
 * SAL Sync — Carte mondiale des brodeuses
 * Carte Google Maps avec vignettes géolocalisées, pixel art collaboratif,
 * filtrage par couleur DMC et système de mise en relation
 */
import { useState, useRef, useCallback, useEffect, useMemo } from "react";
import { MapView } from "@/components/Map.tsx";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { DMC_FULL_PALETTE, DMC_BY_CODE } from "@shared/dmcColors";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  MapPin, Search, Filter, Users, MessageCircle, Palette,
  Globe, Zap, RefreshCw, X, Send, ChevronRight, Star
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface NearbyUser {
  profile: {
    userId: number;
    lat: number | null;
    lng: number | null;
    city: string | null;
    country: string | null;
    bio: string | null;
    avatarUrl: string | null;
    availableForExchange: boolean;
    lastActiveAt: Date;
    isPublic: boolean;
  };
  user: {
    id: number;
    name: string | null;
    email: string | null;
  };
}

interface SelectedUser {
  userId: number;
  name: string;
  city: string | null;
  country: string | null;
  bio: string | null;
  avatarUrl: string | null;
  availableForExchange: boolean;
  lastActiveAt: Date;
}

// ─── Constantes ───────────────────────────────────────────────────────────────

const PALETTE_COLORS = Object.entries(DMC_FULL_PALETTE).slice(0, 60).map(([code, info]) => ({
  code,
  name: info.name,
  hex: info.hex,
}));

// Couleurs populaires pour le filtre rapide
const POPULAR_COLORS = [
  { code: "321", name: "Rouge cerise", hex: "#C51B1B" },
  { code: "700", name: "Vert brillant", hex: "#008000" },
  { code: "820", name: "Bleu royal", hex: "#00008B" },
  { code: "310", name: "Noir", hex: "#000000" },
  { code: "3078", name: "Jaune pâle", hex: "#FFFF99" },
  { code: "3354", name: "Rose poudré", hex: "#E8A0A0" },
  { code: "522", name: "Vert sauge", hex: "#7A9E7E" },
  { code: "3826", name: "Doré", hex: "#C4714A" },
];

// ─── Composant principal ──────────────────────────────────────────────────────

export default function SalSync() {
  const { user, isAuthenticated } = useAuth();
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);

  // État de la carte
  const [mapCenter, setMapCenter] = useState({ lat: 48.8566, lng: 2.3522 }); // Paris par défaut
  const [mapZoom, setMapZoom] = useState(4);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Filtres
  const [filterDmc, setFilterDmc] = useState<string | null>(null);
  const [filterRadius, setFilterRadius] = useState(500);
  const [searchCity, setSearchCity] = useState("");
  const [showOnlyExchange, setShowOnlyExchange] = useState(false);
  const [activeTab, setActiveTab] = useState<"map" | "canvas" | "messages">("map");

  // Sélection d'utilisateur
  const [selectedUser, setSelectedUser] = useState<SelectedUser | null>(null);
  const [showContactDialog, setShowContactDialog] = useState(false);
  const [contactMessage, setContactMessage] = useState("");
  const [contactSubject, setContactSubject] = useState("");

  // Canvas pixel art
  const [canvasZoom, setCanvasZoom] = useState(1);
  const [canvasOffset, setCanvasOffset] = useState({ x: 0, y: 0 });
  const [selectedPixelColor, setSelectedPixelColor] = useState<{ code: string; hex: string } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDragging = useRef(false);
  const lastPos = useRef({ x: 0, y: 0 });

  // Données
  const { data: allProfiles } = trpc.profile.allPublic.useQuery();
  const { data: mapPixels, refetch: refetchPixels } = trpc.salMap.getPixels.useQuery({
    xMin: 0, xMax: 999, yMin: 0, yMax: 499,
  });
  const { data: myMessages } = trpc.community.myMessages.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const sendMessageMutation = trpc.community.sendMessage.useMutation({
    onSuccess: () => {
      toast.success("Message envoyé !");
      setShowContactDialog(false);
      setContactMessage("");
      setContactSubject("");
    },
    onError: () => toast.error("Erreur lors de l'envoi"),
  });

  const placePixelMutation = trpc.salMap.placePixel.useMutation({
    onSuccess: () => refetchPixels(),
    onError: () => toast.error("Impossible de placer ce pixel"),
  });

  // ─── Géolocalisation ────────────────────────────────────────────────────────

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setUserLocation(loc);
          setMapCenter(loc);
          setMapZoom(8);
        },
        () => {
          // Pas de géolocalisation — garder Paris
        }
      );
    }
  }, []);

  // ─── Filtrage des profils ────────────────────────────────────────────────────

  const filteredProfiles = useMemo(() => {
    if (!allProfiles) return [];
    return allProfiles.filter((p) => {
      if (!p.profile.lat || !p.profile.lng) return false;
      if (showOnlyExchange && !p.profile.availableForExchange) return false;
      return true;
    });
  }, [allProfiles, showOnlyExchange]);

  // ─── Marqueurs Google Maps ───────────────────────────────────────────────────

  const updateMarkers = useCallback((map: google.maps.Map) => {
    // Supprimer les anciens marqueurs
    markersRef.current.forEach(m => { m.map = null; });
    markersRef.current = [];

    filteredProfiles.forEach(({ profile, user: u }) => {
      if (!profile.lat || !profile.lng) return;

      // Créer un marqueur personnalisé avec avatar
      const markerEl = document.createElement("div");
      markerEl.className = "sal-marker";
      const isActive = Date.now() - new Date(profile.lastActiveAt).getTime() < 7 * 24 * 60 * 60 * 1000;

      markerEl.innerHTML = `
        <div style="
          position: relative;
          width: 44px;
          height: 44px;
          cursor: pointer;
          transition: transform 0.2s;
        " onmouseenter="this.style.transform='scale(1.2)'" onmouseleave="this.style.transform='scale(1)'">
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 3px solid ${profile.availableForExchange ? '#7A9E7E' : '#C4714A'};
            overflow: hidden;
            background: #e8e3da;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
          ">
            ${profile.avatarUrl
              ? `<img src="${profile.avatarUrl}" style="width:100%;height:100%;object-fit:cover;" />`
              : `<span style="color:#3D4A3E;font-weight:700;">${(u.name ?? "?")[0].toUpperCase()}</span>`
            }
          </div>
          ${isActive ? `<div style="
            position: absolute;
            bottom: 0;
            right: 0;
            width: 12px;
            height: 12px;
            background: #7A9E7E;
            border-radius: 50%;
            border: 2px solid white;
            animation: pulse 2s infinite;
          "></div>` : ""}
        </div>
      `;

      const marker = new google.maps.marker.AdvancedMarkerElement({
        map,
        position: { lat: profile.lat, lng: profile.lng },
        content: markerEl,
        title: u.name ?? "Brodeuse",
      });

      marker.addListener("click", () => {
        setSelectedUser({
          userId: profile.userId,
          name: u.name ?? "Brodeuse anonyme",
          city: profile.city,
          country: profile.country,
          bio: profile.bio,
          avatarUrl: profile.avatarUrl,
          availableForExchange: profile.availableForExchange,
          lastActiveAt: new Date(profile.lastActiveAt),
        });
      });

      markersRef.current.push(marker);
    });
  }, [filteredProfiles]);

  const handleMapReady = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    updateMarkers(map);

    // Ajouter le style CSS pour l'animation pulse
    const style = document.createElement("style");
    style.textContent = `
      @keyframes pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.7; transform: scale(1.3); }
      }
    `;
    document.head.appendChild(style);
  }, [updateMarkers]);

  useEffect(() => {
    if (mapRef.current) {
      updateMarkers(mapRef.current);
    }
  }, [filteredProfiles, updateMarkers]);

  // ─── Canvas pixel art ────────────────────────────────────────────────────────

  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const CELL = 4 * canvasZoom;
    const W = 1000;
    const H = 500;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Fond
    ctx.fillStyle = "#e8e3da";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grille légère
    ctx.strokeStyle = "rgba(61,74,62,0.08)";
    ctx.lineWidth = 0.5;
    for (let x = 0; x <= W; x += 10) {
      const px = canvasOffset.x + x * CELL;
      if (px < 0 || px > canvas.width) continue;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y <= H; y += 10) {
      const py = canvasOffset.y + y * CELL;
      if (py < 0 || py > canvas.height) continue;
      ctx.beginPath();
      ctx.moveTo(0, py);
      ctx.lineTo(canvas.width, py);
      ctx.stroke();
    }

    // Pixels placés
    if (mapPixels) {
      mapPixels.forEach((pixel) => {
        const px = canvasOffset.x + pixel.x * CELL;
        const py = canvasOffset.y + pixel.y * CELL;
        if (px < -CELL || px > canvas.width || py < -CELL || py > canvas.height) return;
        ctx.fillStyle = pixel.hexColor;
        ctx.fillRect(px, py, CELL - 0.5, CELL - 0.5);

        // Croix X si assez grand
        if (CELL >= 8) {
          ctx.strokeStyle = "rgba(0,0,0,0.3)";
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(px + 1, py + 1);
          ctx.lineTo(px + CELL - 2, py + CELL - 2);
          ctx.moveTo(px + CELL - 2, py + 1);
          ctx.lineTo(px + 1, py + CELL - 2);
          ctx.stroke();
        }
      });
    }

    // Vignettes brodeuses sur la carte
    filteredProfiles.forEach(({ profile, user: u }) => {
      if (!profile.lat || !profile.lng) return;
      // Convertir lat/lng en coordonnées canvas (projection Mercator simple)
      const x = ((profile.lng + 180) / 360) * W;
      const latRad = (profile.lat * Math.PI) / 180;
      const y = ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * H;
      const px = canvasOffset.x + x * CELL;
      const py = canvasOffset.y + y * CELL;
      if (px < 0 || px > canvas.width || py < 0 || py > canvas.height) return;

      // Cercle de présence
      const isActive = Date.now() - new Date(profile.lastActiveAt).getTime() < 7 * 24 * 60 * 60 * 1000;
      ctx.beginPath();
      ctx.arc(px, py, Math.max(3, CELL), 0, Math.PI * 2);
      ctx.fillStyle = profile.availableForExchange ? "#7A9E7E" : "#C4714A";
      ctx.globalAlpha = isActive ? 0.9 : 0.4;
      ctx.fill();
      ctx.globalAlpha = 1;
    });
  }, [mapPixels, filteredProfiles, canvasZoom, canvasOffset]);

  useEffect(() => {
    drawCanvas();
  }, [drawCanvas]);

  const handleCanvasClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!selectedPixelColor || !isAuthenticated) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const CELL = 4 * canvasZoom;
    const x = Math.floor((e.clientX - rect.left - canvasOffset.x) / CELL);
    const y = Math.floor((e.clientY - rect.top - canvasOffset.y) / CELL);
    if (x < 0 || x > 999 || y < 0 || y > 499) return;

    placePixelMutation.mutate({
      x,
      y,
      dmcCode: selectedPixelColor.code,
      hexColor: selectedPixelColor.hex,
    });
  }, [selectedPixelColor, isAuthenticated, canvasZoom, canvasOffset, placePixelMutation]);

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || e.altKey) {
      isDragging.current = true;
      lastPos.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    const dx = e.clientX - lastPos.current.x;
    const dy = e.clientY - lastPos.current.y;
    setCanvasOffset(prev => ({ x: prev.x + dx, y: prev.y + dy }));
    lastPos.current = { x: e.clientX, y: e.clientY };
  };

  const handleCanvasMouseUp = () => { isDragging.current = false; };

  const handleCanvasWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.8 : 1.25;
    setCanvasZoom(z => Math.max(0.5, Math.min(8, z * delta)));
  };

  // ─── Recherche ville ─────────────────────────────────────────────────────────

  const handleCitySearch = useCallback(() => {
    if (!mapRef.current || !searchCity) return;
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: searchCity }, (results, status) => {
      if (status === "OK" && results?.[0]) {
        mapRef.current!.setCenter(results[0].geometry.location);
        mapRef.current!.setZoom(8);
      }
    });
  }, [searchCity]);

  // ─── Envoi message ───────────────────────────────────────────────────────────

  const handleSendMessage = () => {
    if (!selectedUser || !contactMessage.trim()) return;
    sendMessageMutation.mutate({
      toUserId: selectedUser.userId,
      subject: contactSubject || `Demande d'échange DMC${filterDmc ? ` ${filterDmc}` : ""}`,
      content: contactMessage,
      dmcCode: filterDmc ?? undefined,
    });
  };

  const unreadCount = myMessages?.filter(m => !m.read).length ?? 0;

  // ─── Rendu ───────────────────────────────────────────────────────────────────

  return (
    <div style={{ background: "#f0ebe2", minHeight: "100vh", fontFamily: "'Lora', serif" }}>

      {/* ── Header ── */}
      <div style={{
        background: "#e8e3da",
        borderBottom: "1px solid rgba(61,74,62,0.1)",
        padding: "16px 24px",
        display: "flex",
        alignItems: "center",
        gap: 16,
        flexWrap: "wrap",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Globe className="w-6 h-6" style={{ color: "#7A9E7E" }} />
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 700, color: "#3D4A3E", margin: 0 }}>SAL Sync</h1>
            <p style={{ fontSize: 12, color: "#6b7a6c", margin: 0 }}>
              {filteredProfiles.length} brodeuse{filteredProfiles.length > 1 ? "s" : ""} sur la carte
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, background: "#ddd8cf", borderRadius: 10, padding: 4, marginLeft: "auto" }}>
          {([
            { id: "map", label: "Carte", icon: MapPin },
            { id: "canvas", label: "Pixel Art", icon: Palette },
            { id: "messages", label: "Messages", icon: MessageCircle },
          ] as const).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                padding: "6px 14px", borderRadius: 8, border: "none",
                background: activeTab === id ? "#e8e3da" : "transparent",
                color: activeTab === id ? "#3D4A3E" : "#6b7a6c",
                fontWeight: activeTab === id ? 600 : 400,
                cursor: "pointer", fontSize: 13,
                boxShadow: activeTab === id ? "0 2px 8px rgba(61,74,62,0.12)" : "none",
                transition: "all 0.2s",
                position: "relative",
              }}
            >
              <Icon className="w-4 h-4" />
              {label}
              {id === "messages" && unreadCount > 0 && (
                <span style={{
                  position: "absolute", top: 2, right: 2,
                  background: "#C4714A", color: "white",
                  borderRadius: "50%", width: 16, height: 16,
                  fontSize: 10, display: "flex", alignItems: "center", justifyContent: "center",
                  fontWeight: 700,
                }}>{unreadCount}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── Filtres ── */}
      <div style={{
        background: "#e8e3da",
        borderBottom: "1px solid rgba(61,74,62,0.08)",
        padding: "10px 24px",
        display: "flex",
        alignItems: "center",
        gap: 12,
        flexWrap: "wrap",
      }}>
        {/* Recherche ville */}
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <Input
            placeholder="Rechercher une ville…"
            value={searchCity}
            onChange={e => setSearchCity(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleCitySearch()}
            style={{
              width: 200, height: 32, fontSize: 13,
              background: "#f0ebe2", border: "1px solid rgba(61,74,62,0.15)",
              borderRadius: 8,
            }}
          />
          <Button size="sm" variant="ghost" onClick={handleCitySearch} style={{ height: 32, padding: "0 10px" }}>
            <Search className="w-3.5 h-3.5" />
          </Button>
        </div>

        {/* Filtre couleur DMC */}
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <span style={{ fontSize: 12, color: "#6b7a6c", whiteSpace: "nowrap" }}>Fil DMC :</span>
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {POPULAR_COLORS.map(c => (
              <button
                key={c.code}
                onClick={() => setFilterDmc(filterDmc === c.code ? null : c.code)}
                title={`DMC ${c.code} — ${c.name}`}
                style={{
                  width: 22, height: 22, borderRadius: 6,
                  background: c.hex,
                  border: filterDmc === c.code ? "2px solid #3D4A3E" : "2px solid transparent",
                  cursor: "pointer",
                  boxShadow: filterDmc === c.code ? "0 0 0 2px rgba(61,74,62,0.3)" : "none",
                  transition: "all 0.15s",
                }}
              />
            ))}
            {filterDmc && (
              <button onClick={() => setFilterDmc(null)} style={{
                width: 22, height: 22, borderRadius: 6,
                background: "#ddd8cf", border: "none", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <X className="w-3 h-3" style={{ color: "#6b7a6c" }} />
              </button>
            )}
          </div>
        </div>

        {/* Filtre échange */}
        <button
          onClick={() => setShowOnlyExchange(v => !v)}
          style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "4px 12px", borderRadius: 8,
            background: showOnlyExchange ? "#7A9E7E" : "#ddd8cf",
            color: showOnlyExchange ? "white" : "#6b7a6c",
            border: "none", cursor: "pointer", fontSize: 12, fontWeight: 500,
            transition: "all 0.2s",
          }}
        >
          <Zap className="w-3.5 h-3.5" />
          Disponibles pour échange
        </button>

        {/* Géolocalisation */}
        {userLocation && (
          <button
            onClick={() => {
              if (mapRef.current) {
                mapRef.current.setCenter(userLocation);
                mapRef.current.setZoom(8);
              }
            }}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "4px 12px", borderRadius: 8,
              background: "#ddd8cf", color: "#6b7a6c",
              border: "none", cursor: "pointer", fontSize: 12,
            }}
          >
            <MapPin className="w-3.5 h-3.5" />
            Ma position
          </button>
        )}

        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#7A9E7E" }} />
          <span style={{ fontSize: 11, color: "#6b7a6c" }}>Disponible pour échange</span>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#C4714A", marginLeft: 8 }} />
          <span style={{ fontSize: 11, color: "#6b7a6c" }}>Brodeuse active</span>
        </div>
      </div>

      {/* ── Contenu principal ── */}
      <div style={{ display: "flex", height: "calc(100vh - 140px)" }}>

        {/* ── Panneau gauche : liste des brodeuses ── */}
        <div style={{
          width: 280,
          background: "#e8e3da",
          borderRight: "1px solid rgba(61,74,62,0.1)",
          overflowY: "auto",
          flexShrink: 0,
        }}>
          <div style={{ padding: "12px 16px", borderBottom: "1px solid rgba(61,74,62,0.08)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Users className="w-4 h-4" style={{ color: "#7A9E7E" }} />
              <span style={{ fontSize: 13, fontWeight: 600, color: "#3D4A3E" }}>
                Brodeuses ({filteredProfiles.length})
              </span>
            </div>
          </div>

          {filteredProfiles.length === 0 ? (
            <div style={{ padding: 24, textAlign: "center", color: "#6b7a6c", fontSize: 13 }}>
              <Globe className="w-8 h-8 mx-auto mb-2" style={{ opacity: 0.4 }} />
              <p>Aucune brodeuse trouvée</p>
              <p style={{ fontSize: 11, marginTop: 4 }}>Modifiez les filtres ou créez votre profil</p>
            </div>
          ) : (
            filteredProfiles.map(({ profile, user: u }) => {
              const isActive = Date.now() - new Date(profile.lastActiveAt).getTime() < 7 * 24 * 60 * 60 * 1000;
              return (
                <button
                  key={profile.userId}
                  onClick={() => {
                    setSelectedUser({
                      userId: profile.userId,
                      name: u.name ?? "Brodeuse anonyme",
                      city: profile.city,
                      country: profile.country,
                      bio: profile.bio,
                      avatarUrl: profile.avatarUrl,
                      availableForExchange: profile.availableForExchange,
                      lastActiveAt: new Date(profile.lastActiveAt),
                    });
                    if (mapRef.current && profile.lat && profile.lng) {
                      mapRef.current.setCenter({ lat: profile.lat, lng: profile.lng });
                      mapRef.current.setZoom(10);
                    }
                  }}
                  style={{
                    width: "100%", textAlign: "left",
                    padding: "10px 16px",
                    background: selectedUser?.userId === profile.userId ? "rgba(122,158,126,0.1)" : "transparent",
                    border: "none", borderBottom: "1px solid rgba(61,74,62,0.06)",
                    cursor: "pointer", display: "flex", alignItems: "center", gap: 10,
                    transition: "background 0.15s",
                  }}
                >
                  {/* Avatar */}
                  <div style={{
                    width: 36, height: 36, borderRadius: "50%",
                    background: "#ddd8cf",
                    border: `2px solid ${profile.availableForExchange ? "#7A9E7E" : "#D4C5A9"}`,
                    overflow: "hidden", flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    position: "relative",
                  }}>
                    {profile.avatarUrl
                      ? <img src={profile.avatarUrl} style={{ width: "100%", height: "100%", objectFit: "cover" }} alt="" />
                      : <span style={{ fontSize: 14, fontWeight: 700, color: "#3D4A3E" }}>
                          {(u.name ?? "?")[0].toUpperCase()}
                        </span>
                    }
                    {isActive && (
                      <div style={{
                        position: "absolute", bottom: 0, right: 0,
                        width: 10, height: 10, background: "#7A9E7E",
                        borderRadius: "50%", border: "1.5px solid #e8e3da",
                      }} />
                    )}
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#3D4A3E", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" as const }}>
                      {u.name ?? "Brodeuse anonyme"}
                    </div>
                    <div style={{ fontSize: 11, color: "#6b7a6c" }}>
                      {[profile.city, profile.country].filter(Boolean).join(", ") || "Localisation inconnue"}
                    </div>
                  </div>

                  {profile.availableForExchange && (
                    <Badge style={{ fontSize: 9, padding: "1px 5px", background: "#7A9E7E", color: "white", border: "none" }}>
                      Échange
                    </Badge>
                  )}
                </button>
              );
            })
          )}
        </div>

        {/* ── Zone principale ── */}
        <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>

          {/* Tab : Carte Google Maps */}
          {activeTab === "map" && (
            <div style={{ width: "100%", height: "100%", position: "relative" }}>
              <MapView
                className="w-full h-full"
                initialCenter={mapCenter}
                initialZoom={mapZoom}
                onMapReady={handleMapReady}
              />

              {/* Compteur flottant */}
              <div style={{
                position: "absolute", bottom: 24, left: "50%", transform: "translateX(-50%)",
                background: "rgba(232,227,218,0.95)",
                borderRadius: 12, padding: "8px 20px",
                boxShadow: "0 4px 20px rgba(61,74,62,0.15)",
                display: "flex", alignItems: "center", gap: 10,
                backdropFilter: "blur(8px)",
              }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#7A9E7E", animation: "pulse 2s infinite" }} />
                <span style={{ fontSize: 13, color: "#3D4A3E", fontWeight: 500 }}>
                  {filteredProfiles.length} brodeuse{filteredProfiles.length > 1 ? "s" : ""} sur la carte
                  {filterDmc && ` · DMC ${filterDmc}`}
                </span>
                {!isAuthenticated && (
                  <span style={{ fontSize: 11, color: "#C4714A" }}>
                    · Connectez-vous pour apparaître sur la carte
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Tab : Canvas pixel art collaboratif */}
          {activeTab === "canvas" && (
            <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column" }}>
              {/* Barre d'outils canvas */}
              <div style={{
                background: "#e8e3da",
                borderBottom: "1px solid rgba(61,74,62,0.1)",
                padding: "8px 16px",
                display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap",
              }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: "#3D4A3E" }}>
                  🌍 Carte mondiale collaborative — {mapPixels?.length ?? 0} pixels placés
                </span>

                {/* Sélecteur de couleur */}
                <div style={{ display: "flex", gap: 4, flexWrap: "wrap", alignItems: "center" }}>
                  <span style={{ fontSize: 11, color: "#6b7a6c" }}>Couleur :</span>
                  {POPULAR_COLORS.map(c => (
                    <button
                      key={c.code}
                      onClick={() => setSelectedPixelColor(selectedPixelColor?.code === c.code ? null : { code: c.code, hex: c.hex })}
                      title={`DMC ${c.code}`}
                      style={{
                        width: 24, height: 24, borderRadius: 6,
                        background: c.hex,
                        border: selectedPixelColor?.code === c.code ? "2px solid #3D4A3E" : "2px solid transparent",
                        cursor: "pointer",
                        boxShadow: selectedPixelColor?.code === c.code ? "0 0 0 2px rgba(61,74,62,0.3)" : "none",
                      }}
                    />
                  ))}
                </div>

                {/* Zoom */}
                <div style={{ display: "flex", gap: 4, alignItems: "center", marginLeft: "auto" }}>
                  <button onClick={() => setCanvasZoom(z => Math.max(0.5, z / 1.3))}
                    style={{ width: 28, height: 28, borderRadius: 6, background: "#ddd8cf", border: "none", cursor: "pointer", fontSize: 16 }}>−</button>
                  <span style={{ fontSize: 12, color: "#3D4A3E", width: 40, textAlign: "center" }}>{Math.round(canvasZoom * 100)}%</span>
                  <button onClick={() => setCanvasZoom(z => Math.min(8, z * 1.3))}
                    style={{ width: 28, height: 28, borderRadius: 6, background: "#ddd8cf", border: "none", cursor: "pointer", fontSize: 16 }}>+</button>
                  <button onClick={() => { setCanvasZoom(1); setCanvasOffset({ x: 0, y: 0 }); }}
                    style={{ width: 28, height: 28, borderRadius: 6, background: "#ddd8cf", border: "none", cursor: "pointer" }}>
                    <RefreshCw className="w-3.5 h-3.5 mx-auto" style={{ color: "#6b7a6c" }} />
                  </button>
                </div>
              </div>

              {/* Canvas */}
              <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
                <canvas
                  ref={canvasRef}
                  style={{
                    width: "100%", height: "100%",
                    cursor: selectedPixelColor ? "crosshair" : isDragging.current ? "grabbing" : "grab",
                    display: "block",
                  }}
                  onClick={handleCanvasClick}
                  onMouseDown={handleCanvasMouseDown}
                  onMouseMove={handleCanvasMouseMove}
                  onMouseUp={handleCanvasMouseUp}
                  onMouseLeave={handleCanvasMouseUp}
                  onWheel={handleCanvasWheel}
                />

                {!isAuthenticated && (
                  <div style={{
                    position: "absolute", bottom: 16, left: "50%", transform: "translateX(-50%)",
                    background: "rgba(196,113,74,0.9)", color: "white",
                    borderRadius: 10, padding: "8px 20px", fontSize: 13,
                  }}>
                    Connectez-vous pour placer des pixels
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Tab : Messages */}
          {activeTab === "messages" && (
            <div style={{ padding: 24, overflowY: "auto", height: "100%" }}>
              <h2 style={{ fontSize: 16, fontWeight: 700, color: "#3D4A3E", marginBottom: 16 }}>
                Mes messages ({myMessages?.length ?? 0})
              </h2>

              {!isAuthenticated ? (
                <div style={{ textAlign: "center", color: "#6b7a6c", padding: 40 }}>
                  <MessageCircle className="w-12 h-12 mx-auto mb-3" style={{ opacity: 0.3 }} />
                  <p>Connectez-vous pour accéder à vos messages</p>
                </div>
              ) : myMessages?.length === 0 ? (
                <div style={{ textAlign: "center", color: "#6b7a6c", padding: 40 }}>
                  <MessageCircle className="w-12 h-12 mx-auto mb-3" style={{ opacity: 0.3 }} />
                  <p>Aucun message pour l'instant</p>
                  <p style={{ fontSize: 12, marginTop: 4 }}>Cliquez sur une brodeuse sur la carte pour la contacter</p>
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {myMessages?.map(msg => (
                    <div key={msg.id} style={{
                      background: msg.read ? "#e8e3da" : "#fff",
                      border: `1px solid ${msg.read ? "rgba(61,74,62,0.1)" : "#7A9E7E"}`,
                      borderRadius: 12, padding: 16,
                      boxShadow: msg.read ? "none" : "0 2px 12px rgba(122,158,126,0.15)",
                    }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                        <span style={{ fontSize: 13, fontWeight: 600, color: "#3D4A3E" }}>
                          {msg.subject ?? "Message"}
                        </span>
                        <span style={{ fontSize: 11, color: "#6b7a6c" }}>
                          {new Date(msg.createdAt).toLocaleDateString("fr-FR")}
                        </span>
                      </div>
                      {msg.dmcCode && (
                        <div style={{ marginBottom: 6 }}>
                          <Badge style={{
                            fontSize: 10,
                            background: DMC_BY_CODE[msg.dmcCode]?.hex ?? "#ccc",
                            color: "white", border: "none",
                          }}>
                            DMC {msg.dmcCode}
                          </Badge>
                        </div>
                      )}
                      <p style={{ fontSize: 13, color: "#3D4A3E", margin: 0, lineHeight: 1.5 }}>
                        {msg.content}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Panneau profil sélectionné ── */}
      {selectedUser && (
        <div style={{
          position: "fixed", right: 0, top: 0, bottom: 0,
          width: 320, background: "#e8e3da",
          boxShadow: "-4px 0 24px rgba(61,74,62,0.15)",
          zIndex: 100, overflowY: "auto",
          display: "flex", flexDirection: "column",
        }}>
          {/* Header */}
          <div style={{
            padding: "20px 20px 16px",
            borderBottom: "1px solid rgba(61,74,62,0.1)",
            display: "flex", alignItems: "flex-start", gap: 12,
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: "50%",
              background: "#ddd8cf",
              border: `3px solid ${selectedUser.availableForExchange ? "#7A9E7E" : "#D4C5A9"}`,
              overflow: "hidden", flexShrink: 0,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              {selectedUser.avatarUrl
                ? <img src={selectedUser.avatarUrl} style={{ width: "100%", height: "100%", objectFit: "cover" }} alt="" />
                : <span style={{ fontSize: 22, fontWeight: 700, color: "#3D4A3E" }}>
                    {selectedUser.name[0].toUpperCase()}
                  </span>
              }
            </div>
            <div style={{ flex: 1 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "#3D4A3E", margin: "0 0 2px" }}>
                {selectedUser.name}
              </h3>
              <p style={{ fontSize: 12, color: "#6b7a6c", margin: 0 }}>
                {[selectedUser.city, selectedUser.country].filter(Boolean).join(", ") || "Localisation non renseignée"}
              </p>
              {selectedUser.availableForExchange && (
                <Badge style={{ marginTop: 4, fontSize: 10, background: "#7A9E7E", color: "white", border: "none" }}>
                  ✓ Disponible pour échange
                </Badge>
              )}
            </div>
            <button
              onClick={() => setSelectedUser(null)}
              style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}
            >
              <X className="w-5 h-5" style={{ color: "#6b7a6c" }} />
            </button>
          </div>

          {/* Bio */}
          {selectedUser.bio && (
            <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(61,74,62,0.08)" }}>
              <p style={{ fontSize: 13, color: "#3D4A3E", lineHeight: 1.6, margin: 0, fontStyle: "italic" }}>
                "{selectedUser.bio}"
              </p>
            </div>
          )}

          {/* Dernière activité */}
          <div style={{ padding: "12px 20px", borderBottom: "1px solid rgba(61,74,62,0.08)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{
                width: 8, height: 8, borderRadius: "50%",
                background: Date.now() - selectedUser.lastActiveAt.getTime() < 7 * 24 * 60 * 60 * 1000
                  ? "#7A9E7E" : "#D4C5A9",
              }} />
              <span style={{ fontSize: 12, color: "#6b7a6c" }}>
                Active {selectedUser.lastActiveAt.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })}
              </span>
            </div>
          </div>

          {/* Bouton contacter */}
          <div style={{ padding: 20 }}>
            {isAuthenticated ? (
              <Button
                onClick={() => setShowContactDialog(true)}
                style={{
                  width: "100%", background: "#C4714A", color: "white",
                  border: "none", borderRadius: 10, padding: "10px 0",
                  fontWeight: 600, cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                }}
              >
                <MessageCircle className="w-4 h-4" />
                Contacter
                {filterDmc && ` · DMC ${filterDmc}`}
              </Button>
            ) : (
              <p style={{ fontSize: 12, color: "#6b7a6c", textAlign: "center" }}>
                Connectez-vous pour contacter cette brodeuse
              </p>
            )}
          </div>
        </div>
      )}

      {/* ── Dialog contact ── */}
      <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
        <DialogContent style={{ background: "#e8e3da", border: "none", borderRadius: 16 }}>
          <DialogHeader>
            <DialogTitle style={{ color: "#3D4A3E" }}>
              Contacter {selectedUser?.name}
            </DialogTitle>
          </DialogHeader>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {filterDmc && (
              <div style={{
                background: "#f0ebe2", borderRadius: 8, padding: "8px 12px",
                display: "flex", alignItems: "center", gap: 8,
              }}>
                <div style={{
                  width: 16, height: 16, borderRadius: 4,
                  background: DMC_BY_CODE[filterDmc!]?.hex ?? "#ccc",
                }} />
                <span style={{ fontSize: 13, color: "#3D4A3E" }}>
                  Demande d'échange : DMC {filterDmc} — {DMC_BY_CODE[filterDmc!]?.name}
                </span>
              </div>
            )}
            <Input
              placeholder="Sujet (optionnel)"
              value={contactSubject}
              onChange={e => setContactSubject(e.target.value)}
              style={{ background: "#f0ebe2", border: "1px solid rgba(61,74,62,0.15)", borderRadius: 8 }}
            />
            <Textarea
              placeholder="Votre message…"
              value={contactMessage}
              onChange={e => setContactMessage(e.target.value)}
              rows={4}
              style={{ background: "#f0ebe2", border: "1px solid rgba(61,74,62,0.15)", borderRadius: 8, resize: "none" }}
            />
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <Button variant="ghost" onClick={() => setShowContactDialog(false)} style={{ color: "#6b7a6c" }}>
                Annuler
              </Button>
              <Button
                onClick={handleSendMessage}
                disabled={!contactMessage.trim() || sendMessageMutation.isPending}
                style={{ background: "#C4714A", color: "white", border: "none", borderRadius: 8 }}
              >
                <Send className="w-4 h-4 mr-2" />
                {sendMessageMutation.isPending ? "Envoi…" : "Envoyer"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
