import { useState, useRef } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Trash2, BookOpen, Clock, Scissors, Smile, Save, Camera, X, Image } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const MOODS = [
  { value: "relaxed", label: "Détendue", emoji: "😌" },
  { value: "focused", label: "Concentrée", emoji: "🎯" },
  { value: "creative", label: "Créative", emoji: "✨" },
  { value: "tired", label: "Fatiguée", emoji: "😴" },
  { value: "happy", label: "Heureuse", emoji: "😊" },
] as const;

type Mood = typeof MOODS[number]["value"];

interface SessionForm {
  projectId: string;
  date: string;
  durationMinutes: string;
  stitchesCompleted: string;
  mood: Mood;
  notes: string;
  photoUrl: string;
}

const today = new Date().toISOString().split("T")[0];
const EMPTY_FORM: SessionForm = {
  projectId: "", date: today!, durationMinutes: "30",
  stitchesCompleted: "0", mood: "focused", notes: "", photoUrl: "",
};

export default function Diary() {
  const utils = trpc.useUtils();
  const { data: sessions, isLoading } = trpc.sessions.list.useQuery({});
  const { data: stats } = trpc.sessions.stats.useQuery();
  const { data: projects } = trpc.projects.list.useQuery();

  const uploadPhotoMutation = trpc.upload.photo.useMutation({
    onError: (e) => toast.error(`Upload échoué : ${e.message}`),
  });

  const createMutation = trpc.sessions.create.useMutation({
    onSuccess: () => {
      utils.sessions.list.invalidate();
      utils.sessions.stats.invalidate();
      utils.projects.list.invalidate();
      toast.success("Session enregistrée !");
      setShowForm(false);
      setForm(EMPTY_FORM);
      setPhotoPreview(null);
    },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.sessions.delete.useMutation({
    onSuccess: () => { utils.sessions.list.invalidate(); utils.sessions.stats.invalidate(); toast.success("Session supprimée"); },
    onError: (e) => toast.error(e.message),
  });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<SessionForm>(EMPTY_FORM);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [expandedPhoto, setExpandedPhoto] = useState<string | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // ── Upload photo ────────────────────────────────────────────────────────────
  const handlePhotoSelect = async (file: File) => {
    if (!file.type.startsWith("image/")) { toast.error("Fichier image requis"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("Image trop grande (max 5 Mo)"); return; }

    // Afficher preview immédiatement
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      setPhotoPreview(base64);
      setUploadingPhoto(true);
      try {
        const result = await uploadPhotoMutation.mutateAsync({
          base64,
          filename: file.name,
          mimeType: file.type,
        });
        setForm(f => ({ ...f, photoUrl: result.url }));
        toast.success("Photo uploadée !");
      } catch {
        setPhotoPreview(null);
      } finally {
        setUploadingPhoto(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = () => {
    if (!form.projectId) { toast.error("Sélectionnez un projet"); return; }
    createMutation.mutate({
      projectId: parseInt(form.projectId),
      date: form.date,
      durationMinutes: parseInt(form.durationMinutes) || 0,
      stitchesCompleted: parseInt(form.stitchesCompleted) || 0,
      mood: form.mood,
      notes: form.notes || undefined,
      photoUrl: form.photoUrl || undefined,
    });
  };

  const totalHours = Math.floor((stats?.totalMinutes ?? 0) / 60);
  const totalMins = (stats?.totalMinutes ?? 0) % 60;

  // Grouper les sessions par mois
  const grouped: Record<string, typeof sessions> = {};
  (sessions ?? []).forEach(s => {
    const month = s.date.slice(0, 7);
    if (!grouped[month]) grouped[month] = [];
    grouped[month]!.push(s);
  });

  const projectMap = Object.fromEntries((projects ?? []).map(p => [p.id, p.name]));
  const moodMap = Object.fromEntries(MOODS.map(m => [m.value, m]));

  return (
    <AppLayout title="Stitch Diary">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              Stitch Diary™
            </h1>
            <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>
              {stats?.totalSessions ?? 0} sessions · {totalHours}h{totalMins > 0 ? ` ${totalMins}m` : ""} de broderie
            </p>
          </div>
          <button
            onClick={() => { setForm({ ...EMPTY_FORM, projectId: projects?.[0]?.id?.toString() ?? "" }); setShowForm(true); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white", boxShadow: "0 4px 12px rgba(196,113,74,0.3)" }}
          >
            <Plus className="w-4 h-4" /> Nouvelle session
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: "Points totaux", value: (stats?.totalStitches ?? 0).toLocaleString("fr-FR"), icon: Scissors, color: "#C4714A" },
            { label: "Temps total", value: `${totalHours}h${totalMins > 0 ? totalMins + "m" : ""}`, icon: Clock, color: "#7A9E7E" },
            { label: "Sessions", value: stats?.totalSessions ?? 0, icon: BookOpen, color: "#C4714A" },
            { label: "Projets terminés", value: stats?.completedProjects ?? 0, icon: Smile, color: "#7A9E7E" },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="rounded-2xl p-4 text-center" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
              <Icon className="w-5 h-5 mx-auto mb-2" style={{ color }} />
              <div className="text-xl font-bold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>{value}</div>
              <div className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Sessions timeline */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: "var(--terracotta)", borderTopColor: "transparent" }} />
          </div>
        ) : (sessions ?? []).length === 0 ? (
          <div className="text-center py-16 rounded-2xl" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
            <BookOpen className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--text-muted)" }} />
            <p className="text-lg font-semibold mb-2" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>Aucune session encore</p>
            <p className="text-sm mb-6" style={{ color: "var(--text-muted)" }}>Enregistrez votre première session de broderie</p>
            <button
              onClick={() => { setForm({ ...EMPTY_FORM, projectId: projects?.[0]?.id?.toString() ?? "" }); setShowForm(true); }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold"
              style={{ background: "var(--terracotta)", color: "white" }}
            >
              <Plus className="w-4 h-4" /> Ajouter une session
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(grouped).sort(([a], [b]) => b.localeCompare(a)).map(([month, monthSessions]) => {
              const [year, m] = month.split("-");
              const monthName = new Date(parseInt(year!), parseInt(m!) - 1).toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
              const monthStitches = (monthSessions ?? []).reduce((s, r) => s + (r.stitchesCompleted ?? 0), 0);
              const monthMinutes = (monthSessions ?? []).reduce((s, r) => s + (r.durationMinutes ?? 0), 0);
              return (
                <div key={month}>
                  <div className="flex items-center gap-3 mb-3">
                    <h2 className="text-base font-semibold capitalize" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
                      {monthName}
                    </h2>
                    <div className="h-px flex-1" style={{ background: "rgba(212,197,169,0.4)" }} />
                    <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                      {monthStitches.toLocaleString("fr-FR")} pts · {Math.floor(monthMinutes / 60)}h{monthMinutes % 60 > 0 ? `${monthMinutes % 60}m` : ""}
                    </span>
                  </div>
                  <div className="space-y-3">
                    {(monthSessions ?? []).map(session => {
                      const mood = moodMap[session.mood ?? "focused"];
                      const projectName = projectMap[session.projectId] ?? "Projet inconnu";
                      return (
                        <div
                          key={session.id}
                          className="rounded-2xl p-4"
                          style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}
                        >
                          <div className="flex items-center gap-4">
                            <div
                              className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                              style={{ background: "rgba(212,197,169,0.2)" }}
                            >
                              {mood?.emoji ?? "🧵"}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-semibold text-sm truncate" style={{ color: "var(--slate)" }}>{projectName}</div>
                              <div className="flex flex-wrap gap-3 mt-1">
                                <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                                  📅 {new Date(session.date + "T12:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}
                                </span>
                                {session.durationMinutes ? (
                                  <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                                    ⏱ {session.durationMinutes >= 60 ? `${Math.floor(session.durationMinutes / 60)}h${session.durationMinutes % 60 > 0 ? `${session.durationMinutes % 60}m` : ""}` : `${session.durationMinutes}m`}
                                  </span>
                                ) : null}
                                {session.stitchesCompleted ? (
                                  <span className="text-xs" style={{ color: "var(--terracotta)" }}>
                                    ✂️ {session.stitchesCompleted.toLocaleString("fr-FR")} pts
                                  </span>
                                ) : null}
                                {mood && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{mood.label}</span>}
                              </div>
                              {session.notes && (
                                <p className="text-xs mt-1 italic" style={{ color: "var(--text-muted)" }}>{session.notes}</p>
                              )}
                            </div>
                            {/* Photo thumbnail */}
                            {session.photoUrl && (
                              <button
                                onClick={() => setExpandedPhoto(session.photoUrl!)}
                                className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all hover:scale-105"
                                style={{ borderColor: "rgba(196,113,74,0.3)" }}
                              >
                                <img src={session.photoUrl} alt="Photo de session" className="w-full h-full object-cover" />
                              </button>
                            )}
                            <button
                              onClick={() => { if (confirm("Supprimer cette session ?")) deleteMutation.mutate({ id: session.id }); }}
                              className="p-1.5 rounded-lg flex-shrink-0"
                              style={{ color: "#e57373" }}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Lightbox photo */}
      {expandedPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.85)" }}
          onClick={() => setExpandedPhoto(null)}
        >
          <button className="absolute top-4 right-4 p-2 rounded-full" style={{ background: "rgba(255,255,255,0.2)", color: "white" }}>
            <X className="w-5 h-5" />
          </button>
          <img src={expandedPhoto} alt="Photo de session" className="max-w-full max-h-full rounded-2xl object-contain" style={{ maxHeight: "80vh" }} />
        </div>
      )}

      {/* Modal formulaire */}
      <Dialog open={showForm} onOpenChange={open => { if (!open) { setShowForm(false); setForm(EMPTY_FORM); setPhotoPreview(null); } }}>
        <DialogContent className="max-w-md" style={{ background: "var(--ivory)" }}>
          <DialogHeader>
            <DialogTitle style={{ fontFamily: "Cormorant Garamond, serif", color: "var(--slate)" }}>
              Nouvelle session de broderie
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Projet *</Label>
              {(projects ?? []).length === 0 ? (
                <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>Créez d'abord un projet dans l'onglet Projets</p>
              ) : (
                <select
                  value={form.projectId}
                  onChange={e => setForm(f => ({ ...f, projectId: e.target.value }))}
                  className="w-full mt-1 px-3 py-2 rounded-lg text-sm border-0 outline-none"
                  style={{ background: "rgba(212,197,169,0.15)", color: "var(--slate)" }}
                >
                  <option value="">Sélectionner un projet…</option>
                  {(projects ?? []).map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Date</Label>
                <Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Durée (minutes)</Label>
                <Input type="number" min="0" value={form.durationMinutes}
                  onChange={e => setForm(f => ({ ...f, durationMinutes: e.target.value }))}
                  className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Points complétés</Label>
              <Input type="number" min="0" value={form.stitchesCompleted}
                onChange={e => setForm(f => ({ ...f, stitchesCompleted: e.target.value }))}
                className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div>
              <Label className="text-sm font-medium mb-2 block" style={{ color: "var(--slate)" }}>Humeur</Label>
              <div className="flex flex-wrap gap-2">
                {MOODS.map(m => (
                  <button
                    key={m.value}
                    onClick={() => setForm(f => ({ ...f, mood: m.value }))}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm transition-all"
                    style={{
                      background: form.mood === m.value ? "var(--terracotta)" : "rgba(212,197,169,0.2)",
                      color: form.mood === m.value ? "white" : "var(--slate)",
                    }}
                  >
                    {m.emoji} {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Upload photo */}
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Photo de progression</Label>
              {photoPreview ? (
                <div className="mt-1 relative">
                  <img src={photoPreview} alt="Aperçu" className="w-full h-32 object-cover rounded-xl" />
                  {uploadingPhoto && (
                    <div className="absolute inset-0 flex items-center justify-center rounded-xl" style={{ background: "rgba(0,0,0,0.5)" }}>
                      <div className="w-6 h-6 rounded-full border-2 animate-spin" style={{ borderColor: "white", borderTopColor: "transparent" }} />
                    </div>
                  )}
                  {!uploadingPhoto && (
                    <button
                      onClick={() => { setPhotoPreview(null); setForm(f => ({ ...f, photoUrl: "" })); }}
                      className="absolute top-2 right-2 p-1 rounded-full"
                      style={{ background: "rgba(0,0,0,0.6)", color: "white" }}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              ) : (
                <div
                  className="mt-1 border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all"
                  style={{ borderColor: "rgba(196,113,74,0.3)" }}
                  onClick={() => photoInputRef.current?.click()}
                  onDragOver={e => e.preventDefault()}
                  onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handlePhotoSelect(f); }}
                >
                  <Camera className="w-6 h-6 mx-auto mb-1" style={{ color: "var(--terracotta)" }} />
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>Glissez une photo ou cliquez</p>
                  <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)", fontSize: "0.6rem" }}>JPG, PNG · max 5 Mo</p>
                </div>
              )}
              <input ref={photoInputRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handlePhotoSelect(f); }} />
            </div>

            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Notes</Label>
              <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Comment s'est passée cette session ?" rows={2} className="mt-1 resize-none"
                style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => { setShowForm(false); setForm(EMPTY_FORM); setPhotoPreview(null); }}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                style={{ background: "rgba(212,197,169,0.3)", color: "var(--slate)" }}
              >
                Annuler
              </button>
              <button
                onClick={handleSubmit}
                disabled={createMutation.isPending || !form.projectId || uploadingPhoto}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
                style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white" }}
              >
                <Save className="w-4 h-4" />
                {uploadingPhoto ? "Upload en cours…" : "Enregistrer"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
