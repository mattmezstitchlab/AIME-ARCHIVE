import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Trash2, Edit3, ShoppingCart, Search, Package, Save, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

// Palette DMC simplifiée (couleurs représentatives)
const DMC_COLORS: Record<string, { name: string; hex: string }> = {
  "blanc": { name: "Blanc", hex: "#FFFFFF" },
  "ecru": { name: "Ecru", hex: "#F5F0E0" },
  "310": { name: "Noir", hex: "#1A1A1A" },
  "321": { name: "Rouge", hex: "#CC2222" },
  "666": { name: "Rouge vif", hex: "#FF2222" },
  "700": { name: "Vert", hex: "#006600" },
  "742": { name: "Jaune", hex: "#FFB300" },
  "798": { name: "Bleu", hex: "#3366CC" },
  "899": { name: "Rose", hex: "#FF9999" },
  "3750": { name: "Bleu marine", hex: "#1A2B5E" },
};

interface InventoryForm {
  dmcNumber: string;
  colorName: string;
  hexColor: string;
  skeinsOwned: string;
  skeinsUsed: string;
  notes: string;
}

const EMPTY_FORM: InventoryForm = {
  dmcNumber: "", colorName: "", hexColor: "#C4956A",
  skeinsOwned: "1", skeinsUsed: "0", notes: "",
};

export default function Inventory() {
  const utils = trpc.useUtils();
  const { data: inventory, isLoading } = trpc.inventory.list.useQuery();
  const addMutation = trpc.inventory.add.useMutation({
    onSuccess: () => { utils.inventory.list.invalidate(); toast.success("Fil ajouté !"); setShowForm(false); setForm(EMPTY_FORM); },
    onError: (e) => toast.error(e.message),
  });
  const updateMutation = trpc.inventory.update.useMutation({
    onSuccess: () => { utils.inventory.list.invalidate(); toast.success("Mis à jour !"); setEditId(null); setShowForm(false); setForm(EMPTY_FORM); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.inventory.delete.useMutation({
    onSuccess: () => { utils.inventory.list.invalidate(); toast.success("Fil supprimé"); },
    onError: (e) => toast.error(e.message),
  });

  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<InventoryForm>(EMPTY_FORM);
  const [search, setSearch] = useState("");
  const [shoppingOnly, setShoppingOnly] = useState(false);

  const handleDmcChange = (dmc: string) => {
    const known = DMC_COLORS[dmc.toLowerCase()];
    setForm(f => ({
      ...f,
      dmcNumber: dmc,
      colorName: known?.name ?? f.colorName,
      hexColor: known?.hex ?? f.hexColor,
    }));
  };

  const handleSubmit = () => {
    if (!form.dmcNumber.trim()) { toast.error("Le numéro DMC est requis"); return; }
    const payload = {
      dmcNumber: form.dmcNumber.trim().toUpperCase(),
      colorName: form.colorName || undefined,
      hexColor: form.hexColor || undefined,
      skeinsOwned: parseFloat(form.skeinsOwned) || 0,
      skeinsUsed: parseFloat(form.skeinsUsed) || 0,
      notes: form.notes || undefined,
    };
    if (editId !== null) {
      updateMutation.mutate({ id: editId, ...payload });
    } else {
      addMutation.mutate(payload);
    }
  };

  const filtered = (inventory ?? []).filter(item => {
    const q = search.toLowerCase();
    const matchSearch = !q || item.dmcNumber.toLowerCase().includes(q) || (item.colorName ?? "").toLowerCase().includes(q);
    const matchShopping = !shoppingOnly || item.onShoppingList;
    return matchSearch && matchShopping;
  });

  const shoppingCount = (inventory ?? []).filter(i => i.onShoppingList).length;
  const totalSkeinValue = (inventory ?? []).reduce((s, i) => s + (i.skeinsOwned ?? 0), 0);

  return (
    <AppLayout title="Inventaire DMC">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              Inventaire DMC
            </h1>
            <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>
              {(inventory ?? []).length} couleurs · {totalSkeinValue.toFixed(1)} écheveaux
            </p>
          </div>
          <button
            onClick={() => { setForm(EMPTY_FORM); setEditId(null); setShowForm(true); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white", boxShadow: "0 4px 12px rgba(196,113,74,0.3)" }}
          >
            <Plus className="w-4 h-4" /> Ajouter un fil
          </button>
        </div>

        {/* Stats rapides */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {[
            { label: "Couleurs", value: (inventory ?? []).length, color: "#C4714A" },
            { label: "En liste de courses", value: shoppingCount, color: "#7A9E7E" },
            { label: "Mètres estimés", value: Math.round((inventory ?? []).reduce((s, i) => s + (i.metersRemaining ?? 0), 0)), color: "#3D4A3E" },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-2xl p-4 text-center" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
              <div className="text-2xl font-bold" style={{ color, fontFamily: "Cormorant Garamond, serif" }}>{value.toLocaleString("fr-FR")}</div>
              <div className="text-xs mt-1" style={{ color: "var(--text-muted)" }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Filtres */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "var(--text-muted)" }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher DMC, couleur…"
              className="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm border-0 outline-none"
              style={{ background: "var(--ivory)", color: "var(--slate)", boxShadow: "inset 2px 2px 5px rgba(0,0,0,0.06), inset -2px -2px 5px rgba(255,255,255,0.8)" }}
            />
          </div>
          <button
            onClick={() => setShoppingOnly(!shoppingOnly)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all"
            style={{
              background: shoppingOnly ? "var(--sage)" : "var(--ivory)",
              color: shoppingOnly ? "white" : "var(--slate)",
              boxShadow: shoppingOnly ? "0 4px 12px rgba(122,158,126,0.3)" : "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)",
            }}
          >
            <ShoppingCart className="w-4 h-4" />
            Liste de courses {shoppingCount > 0 && `(${shoppingCount})`}
          </button>
        </div>

        {/* Inventory list */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: "var(--terracotta)", borderTopColor: "transparent" }} />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 rounded-2xl" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
            <Package className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--text-muted)" }} />
            <p className="text-lg font-semibold mb-2" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              {search || shoppingOnly ? "Aucun résultat" : "Inventaire vide"}
            </p>
            <p className="text-sm mb-6" style={{ color: "var(--text-muted)" }}>
              {search || shoppingOnly ? "Modifiez votre recherche" : "Ajoutez vos fils DMC pour commencer"}
            </p>
            {!search && !shoppingOnly && (
              <button
                onClick={() => { setForm(EMPTY_FORM); setEditId(null); setShowForm(true); }}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold"
                style={{ background: "var(--terracotta)", color: "white" }}
              >
                <Plus className="w-4 h-4" /> Ajouter un fil
              </button>
            )}
          </div>
        ) : (
          <div className="rounded-2xl overflow-hidden" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
            <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-0 text-xs font-semibold px-4 py-3 border-b" style={{ color: "var(--text-muted)", borderColor: "rgba(212,197,169,0.3)" }}>
              <div className="w-8" />
              <div>Couleur</div>
              <div className="text-right pr-4">Possédé</div>
              <div className="text-right pr-4">Utilisé</div>
              <div className="text-right pr-4">Restant</div>
              <div className="w-20" />
            </div>
            {filtered.map((item, i) => (
              <div
                key={item.id}
                className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] items-center gap-0 px-4 py-3 border-b hover:bg-white/40 transition-colors"
                style={{ borderColor: "rgba(212,197,169,0.2)", borderBottomWidth: i === filtered.length - 1 ? 0 : 1 }}
              >
                <div className="w-8 flex items-center">
                  <div
                    className="w-6 h-6 rounded-full border-2 border-white flex-shrink-0"
                    style={{ background: item.hexColor ?? "#C4956A", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }}
                  />
                </div>
                <div>
                  <div className="font-semibold text-sm" style={{ color: "var(--slate)" }}>DMC {item.dmcNumber}</div>
                  <div className="text-xs" style={{ color: "var(--text-muted)" }}>{item.colorName ?? "—"}</div>
                </div>
                <div className="text-sm text-right pr-4" style={{ color: "var(--slate)" }}>{item.skeinsOwned}×</div>
                <div className="text-sm text-right pr-4" style={{ color: "var(--text-muted)" }}>{item.skeinsUsed}×</div>
                <div className="text-sm text-right pr-4 font-medium" style={{ color: (item.metersRemaining ?? 0) < 2 ? "#e57373" : "var(--sage)" }}>
                  {(item.metersRemaining ?? 0).toFixed(1)}m
                </div>
                <div className="flex items-center gap-1 w-20 justify-end">
                  <button
                    onClick={() => updateMutation.mutate({ id: item.id, onShoppingList: !item.onShoppingList })}
                    className="p-1.5 rounded-lg transition-colors"
                    style={{ color: item.onShoppingList ? "var(--sage)" : "var(--text-muted)" }}
                    title={item.onShoppingList ? "Retirer de la liste" : "Ajouter à la liste"}
                  >
                    <ShoppingCart className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setEditId(item.id);
                      setForm({
                        dmcNumber: item.dmcNumber,
                        colorName: item.colorName ?? "",
                        hexColor: item.hexColor ?? "#C4956A",
                        skeinsOwned: String(item.skeinsOwned),
                        skeinsUsed: String(item.skeinsUsed),
                        notes: item.notes ?? "",
                      });
                      setShowForm(true);
                    }}
                    className="p-1.5 rounded-lg transition-colors"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { if (confirm(`Supprimer DMC ${item.dmcNumber} ?`)) deleteMutation.mutate({ id: item.id }); }}
                    className="p-1.5 rounded-lg transition-colors"
                    style={{ color: "#e57373" }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal formulaire */}
      <Dialog open={showForm} onOpenChange={open => { if (!open) { setShowForm(false); setEditId(null); setForm(EMPTY_FORM); } }}>
        <DialogContent className="max-w-md" style={{ background: "var(--ivory)" }}>
          <DialogHeader>
            <DialogTitle style={{ fontFamily: "Cormorant Garamond, serif", color: "var(--slate)" }}>
              {editId !== null ? "Modifier le fil" : "Ajouter un fil DMC"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="flex gap-3">
              <div className="flex-1">
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Numéro DMC *</Label>
                <Input
                  value={form.dmcNumber}
                  onChange={e => handleDmcChange(e.target.value)}
                  placeholder="Ex: 310, blanc, ecru…"
                  className="mt-1"
                  style={{ background: "rgba(212,197,169,0.15)" }}
                />
              </div>
              <div className="flex flex-col gap-1">
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Couleur</Label>
                <input
                  type="color"
                  value={form.hexColor}
                  onChange={e => setForm(f => ({ ...f, hexColor: e.target.value }))}
                  className="mt-1 h-10 w-14 rounded-lg border-0 cursor-pointer"
                  style={{ background: "rgba(212,197,169,0.15)" }}
                />
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Nom de la couleur</Label>
              <Input value={form.colorName} onChange={e => setForm(f => ({ ...f, colorName: e.target.value }))}
                placeholder="Ex: Noir, Rouge vif…" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Écheveaux possédés</Label>
                <Input value={form.skeinsOwned} onChange={e => setForm(f => ({ ...f, skeinsOwned: e.target.value }))}
                  type="number" min="0" step="0.5" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Écheveaux utilisés</Label>
                <Input value={form.skeinsUsed} onChange={e => setForm(f => ({ ...f, skeinsUsed: e.target.value }))}
                  type="number" min="0" step="0.5" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div className="text-xs px-3 py-2 rounded-lg" style={{ background: "rgba(122,158,126,0.1)", color: "var(--sage)" }}>
              Mètres restants estimés : <strong>
                {Math.max(0, (parseFloat(form.skeinsOwned) || 0) - (parseFloat(form.skeinsUsed) || 0)) * 8 * 0.9 > 0
                  ? `${(Math.max(0, (parseFloat(form.skeinsOwned) || 0) - (parseFloat(form.skeinsUsed) || 0)) * 8 * 0.9).toFixed(1)}m`
                  : "0m"}
              </strong> (1 écheveau ≈ 8m utilisables)
            </div>
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Notes</Label>
              <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Notes sur ce fil…" rows={2} className="mt-1 resize-none" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => { setShowForm(false); setEditId(null); setForm(EMPTY_FORM); }}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                style={{ background: "rgba(212,197,169,0.3)", color: "var(--slate)" }}
              >
                Annuler
              </button>
              <button
                onClick={handleSubmit}
                disabled={addMutation.isPending || updateMutation.isPending}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white" }}
              >
                <Save className="w-4 h-4" />
                {editId !== null ? "Enregistrer" : "Ajouter"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
