/*
 * ThreadFlow — Éditeur de patron point de croix
 * Basé sur la démo interactive, enrichi avec :
 *   - Types de points multiples (full, half, quarter, three-quarter, backstitch, french knot)
 *   - Générateur IA (DALL-E 3 + quantification DMC)
 *   - Sauvegarde/chargement en base de données
 *   - Import PNG/JPEG/PDF
 *   - Smart Pathing™ avec ordre d'exécution correct
 */
import { useState, useCallback, useRef, useEffect, useMemo } from "react";
import ConfettiSplitOverlay from "@/components/ConfettiSplitOverlay";
import {
  Download, RotateCcw, ZoomIn, ZoomOut, Sparkles, Info, Upload,
  X, AlertCircle, Save, FolderOpen, Wand2, Loader2, Eye, Scissors,
  Users, Link, Copy, Check, ChevronRight, ChevronLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useImageImport } from "@/hooks/useImageImport";
import { DMC_COLORS } from "@/hooks/usePDFImport";
import { StitchType, StitchGroup, GridCell, getStitchGroup, computeSmartPathOrdered } from "@/lib/stitchTypes";

// ─── Types ────────────────────────────────────────────────────────────────────

type Tool = "paint" | "erase" | "fill";

// ─── Palette DMC (hex) depuis le hook usePDFImport ───────────────────────────
const DMC_PALETTE: Record<string, { name: string; hex: string }> = Object.fromEntries(
  Object.entries(DMC_COLORS).map(([code, { r, g, b, name }]) => [
    code,
    {
      name,
      hex: `#${Math.round(r).toString(16).padStart(2, "0")}${Math.round(g).toString(16).padStart(2, "0")}${Math.round(b).toString(16).padStart(2, "0")}`,
    },
  ])
);

// ─── Patron initial "Rose Sauvage" 20×20 ─────────────────────────────────────
const INITIAL_PATTERN: (string | null)[][] = [
  [null,null,null,null,null,null,null,null,null,"3354","3354",null,null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null,"3354","3733","3733","3354",null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,"3354","3733","3731","3731","3733","3354",null,null,null,null,null,null,null],
  [null,null,null,null,null,null,"3354","3733","3731","3726","3726","3731","3733","3354",null,null,null,null,null,null],
  [null,null,null,null,null,"3354","3733","3731","3726","3727","3727","3726","3731","3733","3354",null,null,null,null,null],
  [null,null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null,null],
  [null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null],
  [null,null,"524","3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354","524",null,null],
  [null,"524","522","524","3354","3733","3731","3726","3727","3733","3733","3727","3726","3731","3733","3354","524","522","524",null],
  ["524","522","520","522","524","3354","3733","3731","3726","3727","3727","3726","3731","3733","3354","524","522","520","522","524"],
  ["524","522","520","522","524","3354","3733","3731","3726","3727","3727","3726","3731","3733","3354","524","522","520","522","524"],
  [null,"524","522","524","3354","3733","3731","3726","3727","3733","3733","3727","3726","3731","3733","3354","524","522","524",null],
  [null,null,"524","3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354","524",null,null],
  [null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null],
  [null,null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null,null],
  [null,null,null,null,null,"3354","3733","3731","3726","3727","3727","3726","3731","3733","3354",null,null,null,null,null],
  [null,null,null,null,null,null,"3354","3733","3731","3726","3726","3731","3733","3354",null,null,null,null,null,null],
  [null,null,null,null,null,null,null,"3354","3733","3731","3731","3733","3354",null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null,"3354","3733","3733","3354",null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null,null,"3354","3354",null,null,null,null,null,null,null,null,null],
];

const DEFAULT_ROWS = 20;
const DEFAULT_COLS = 20;
const MAX_UNDO = 25;


// ─── Rendu SVG d'un point ─────────────────────────────────────────────────────
function StitchSVG({ type, color, size }: { type: StitchType; color: string; size: number }) {
  const stroke = "rgba(0,0,0,0.45)";
  const sw = Math.max(0.8, size * 0.06);
  const p = size * 0.15;
  const m = size / 2;

  switch (type) {
    case "full":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={p} x2={size - p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
          <line x1={size - p} y1={p} x2={p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "half_fwd":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={size - p} x2={size - p} y2={p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "half_bwd":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={p} x2={size - p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "quarter_tl":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "quarter_tr":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={size - p} y1={p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "quarter_bl":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={size - p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "quarter_br":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={size - p} y1={size - p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "three_quarter_tl":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={p} x2={size - p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
          <line x1={size - p} y1={p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "three_quarter_tr":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={p} y1={p} x2={size - p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
          <line x1={p} y1={size - p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "three_quarter_bl":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={size - p} y1={p} x2={p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
          <line x1={p} y1={p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "three_quarter_br":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.55 }}>
          <line x1={size - p} y1={p} x2={p} y2={size - p} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
          <line x1={size - p} y1={size - p} x2={m} y2={m} stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        </svg>
      );
    case "backstitch_h":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.7 }}>
          <line x1={0} y1={m} x2={size} y2={m} stroke={stroke} strokeWidth={sw * 1.5} strokeLinecap="square" />
        </svg>
      );
    case "backstitch_v":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.7 }}>
          <line x1={m} y1={0} x2={m} y2={size} stroke={stroke} strokeWidth={sw * 1.5} strokeLinecap="square" />
        </svg>
      );
    case "backstitch_d1":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.7 }}>
          <line x1={0} y1={size} x2={size} y2={0} stroke={stroke} strokeWidth={sw * 1.5} strokeLinecap="square" />
        </svg>
      );
    case "backstitch_d2":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.7 }}>
          <line x1={0} y1={0} x2={size} y2={size} stroke={stroke} strokeWidth={sw * 1.5} strokeLinecap="square" />
        </svg>
      );
    case "french_knot":
      return (
        <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 w-full h-full" style={{ opacity: 0.75 }}>
          <circle cx={m} cy={m} r={size * 0.18} fill={stroke} />
        </svg>
      );
    default:
      return null;
  }
}

// ─── Icône miniature pour le sélecteur de type de point ──────────────────────
function StitchIcon({ type, active }: { type: StitchType; active: boolean }) {
  const stroke = active ? "#C4714A" : "rgba(0,0,0,0.5)";
  const sw = 1.5;
  return (
    <svg viewBox="0 0 16 16" width="16" height="16">
      {type === "full" && (<>
        <line x1="2" y1="2" x2="14" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        <line x1="14" y1="2" x2="2" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </>)}
      {type === "half_fwd" && <line x1="2" y1="14" x2="14" y2="2" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />}
      {type === "half_bwd" && <line x1="2" y1="2" x2="14" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />}
      {type === "quarter_tl" && <line x1="2" y1="2" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />}
      {type === "quarter_tr" && <line x1="14" y1="2" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />}
      {type === "quarter_bl" && <line x1="2" y1="14" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />}
      {type === "quarter_br" && <line x1="14" y1="14" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />}
      {type === "three_quarter_tl" && (<>
        <line x1="2" y1="2" x2="14" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        <line x1="14" y1="2" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </>)}
      {type === "three_quarter_tr" && (<>
        <line x1="2" y1="2" x2="14" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        <line x1="2" y1="14" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </>)}
      {type === "three_quarter_bl" && (<>
        <line x1="14" y1="2" x2="2" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        <line x1="2" y1="2" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </>)}
      {type === "three_quarter_br" && (<>
        <line x1="14" y1="2" x2="2" y2="14" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        <line x1="14" y1="14" x2="8" y2="8" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </>)}
      {type === "backstitch_h" && <line x1="0" y1="8" x2="16" y2="8" stroke={stroke} strokeWidth={sw * 1.3} strokeLinecap="square" />}
      {type === "backstitch_v" && <line x1="8" y1="0" x2="8" y2="16" stroke={stroke} strokeWidth={sw * 1.3} strokeLinecap="square" />}
      {type === "backstitch_d1" && <line x1="0" y1="16" x2="16" y2="0" stroke={stroke} strokeWidth={sw * 1.3} strokeLinecap="square" />}
      {type === "backstitch_d2" && <line x1="0" y1="0" x2="16" y2="16" stroke={stroke} strokeWidth={sw * 1.3} strokeLinecap="square" />}
      {type === "french_knot" && <circle cx="8" cy="8" r="3" fill={stroke} />}
    </svg>
  );
}

// ─── Composant principal ───────────────────────────────────────────────────────
export default function Editor() {
  // ── Grille ──────────────────────────────────────────────────────────────────
  const [grid, setGrid] = useState<GridCell[][]>(() =>
    INITIAL_PATTERN.map(row =>
      row.map(dmc => ({
        dmc,
        hex: dmc ? (DMC_PALETTE[dmc]?.hex ?? "#cccccc") : null,
        stitchType: "full" as StitchType,
      }))
    )
  );
  const [rows, setRows] = useState(DEFAULT_ROWS);
  const [cols, setCols] = useState(DEFAULT_COLS);
  const [patternName, setPatternName] = useState("Rose Sauvage");
  const [currentGridId, setCurrentGridId] = useState<number | null>(null);

  // ── Outils ──────────────────────────────────────────────────────────────────
  const [selectedColor, setSelectedColor] = useState<string>("3731");
  const [tool, setTool] = useState<Tool>("paint");
  const [stitchType, setStitchType] = useState<StitchType>("full");
  const [zoom, setZoom] = useState<number>(28);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number } | null>(null);

  // ── Smart Pathing™ ──────────────────────────────────────────────────────────
  const [showSmartPath, setShowSmartPath] = useState(false);

  // ── Mode aperçu réaliste ─────────────────────────────────────────────────────
  const [realisticMode, setRealisticMode] = useState(false);

  // ── Confetti Cleaner™ ────────────────────────────────────────────────────────
  const [showConfettiCleaner, setShowConfettiCleaner] = useState(false);
  const [confettiThreshold, setConfettiThreshold] = useState(3); // min voisins pour garder un point
  const [confettiSplitPos, setConfettiSplitPos] = useState(50); // position du diviseur avant/après (%)

  // ── Import ──────────────────────────────────────────────────────────────────
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showImportPanel, setShowImportPanel] = useState(false);
  const [importGridSize, setImportGridSize] = useState<{ rows: number; cols: number }>({ rows: 40, cols: 40 });
  const [importMaxColors, setImportMaxColors] = useState<number>(24);
  const [pendingImportFile, setPendingImportFile] = useState<File | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const { importFile, loadPdfPreviews, importPdfPage, resetPdf, pdfPreviews, pdfPageCount, status: importStatus, error: importError, progress: importProgress } = useImageImport();
  const [selectedPdfPage, setSelectedPdfPage] = useState(1);
  const [isPdfMode, setIsPdfMode] = useState(false);
  const [isLoadingPdfPreviews, setIsLoadingPdfPreviews] = useState(false);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  // ── Undo ────────────────────────────────────────────────────────────────────
  const undoStack = useRef<GridCell[][][]>([]);

  // ── Générateur IA ────────────────────────────────────────────────────────────
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [aiPrompt, setAIPrompt] = useState("");
  const [aiStyle, setAIStyle] = useState<"pixel-art" | "flat-illustration" | "realistic" | "watercolor" | "minimalist">("pixel-art");
  const [aiGridSize, setAIGridSize] = useState<"20" | "40" | "80">("40");
  const [aiMaxColors, setAIMaxColors] = useState<string>("12");
  const [aiStep, setAIStep] = useState<"prompt" | "generating" | "preview" | "converting">("prompt");
  const [aiGeneratedImageUrl, setAIGeneratedImageUrl] = useState<string | null>(null);

  // ── Sauvegarde ───────────────────────────────────────────────────────────────
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [showLoadDialog, setShowLoadDialog] = useState(false);
  // Panneau droit
  const [showRightPanel, setShowRightPanel] = useState(true);
  // Partage & Collaboration
  const [shareLink, setShareLink] = useState<string | null>(null);
  const [isGeneratingShare, setIsGeneratingShare] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);

  // ── tRPC ─────────────────────────────────────────────────────────────────────
  const utils = trpc.useUtils();
  const savedGrids = trpc.grids.list.useQuery();
  const saveMutation = trpc.grids.save.useMutation({
    onSuccess: () => {
      toast.success("Patron sauvegardé !");
      utils.grids.list.invalidate();
      setShowSaveDialog(false);
    },
    onError: (err) => toast.error(`Erreur : ${err.message}`),
  });
  const updateMutation = trpc.grids.update.useMutation({
    onSuccess: () => {
      toast.success("Patron mis à jour !");
      utils.grids.list.invalidate();
    },
    onError: (err) => toast.error(`Erreur : ${err.message}`),
  });
  // Extraire le token du shareLink pour la query
  const currentShareToken = shareLink ? shareLink.split('/patron/')[1] : null;
  const shareViewers = trpc.grids.getShareViewers.useQuery(
    { shareToken: currentShareToken! },
    { enabled: !!currentShareToken, refetchInterval: 30000 }
  );

  const createShareMutation = trpc.grids.createShareLink.useMutation({
    onSuccess: (data) => {
      const url = `${window.location.origin}/patron/${data.token}`;
      setShareLink(url);
      setIsGeneratingShare(false);
    },
    onError: () => {
      setIsGeneratingShare(false);
      toast.error("Impossible de créer le lien de partage");
    },
  });

  const handleCreateShare = () => {
    if (!currentGridId) {
      toast.error("Sauvegardez d'abord votre patron pour le partager");
      return;
    }
    setIsGeneratingShare(true);
    createShareMutation.mutate({ gridId: currentGridId, canEdit: false });
  };

  const handleCopyShareLink = () => {
    if (!shareLink) return;
    navigator.clipboard.writeText(shareLink);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2000);
    toast.success("Lien copié !");
  };

  const generateAI = trpc.grids.generateAI.useMutation({
    onSuccess: (data) => {
      // Le serveur retourne juste l'URL de l'image — la conversion se fait côté client
      setAIGeneratedImageUrl(data.imageUrl);
      setAIStep("preview");
    },
    onError: (err) => {
      toast.error(`Erreur IA : ${err.message}`);
      setAIStep("prompt");
    },
  });

  // Conversion Canvas → grille DMC (côté client, comme StitchLab)
  const convertAIImageToGrid = useCallback(async () => {
    if (!aiGeneratedImageUrl) return;
    setAIStep("converting");
    try {
      const img = new Image();
      img.crossOrigin = "anonymous";
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("Impossible de charger l'image générée"));
        img.src = aiGeneratedImageUrl;
      });

      const targetW = parseInt(aiGridSize);
      const targetH = parseInt(aiGridSize);
      const maxC = parseInt(aiMaxColors);

      // Redimensionner via canvas
      const canvas = document.createElement("canvas");
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, targetW, targetH);
      const imageData = ctx.getImageData(0, 0, targetW, targetH);

      // Quantifier chaque pixel vers la couleur DMC la plus proche
      const dmcEntries = Object.entries(DMC_COLORS);
      const findClosestDMCLocal = (r: number, g: number, b: number): string => {
        let best = "blanc";
        let minDist = Infinity;
        for (const [code, color] of dmcEntries) {
          const dr = r - color.r, dg = g - color.g, db = b - color.b;
          const dist = dr * dr + dg * dg + db * db;
          if (dist < minDist) { minDist = dist; best = code; }
        }
        return best;
      }

      // Première passe : mapper tous les pixels
      const rawGrid: (string | null)[][] = [];
      const colorCount: Record<string, number> = {};
      for (let y = 0; y < targetH; y++) {
        const row: (string | null)[] = [];
        for (let x = 0; x < targetW; x++) {
          const idx = (y * targetW + x) * 4;
          const r = imageData.data[idx]!;
          const g = imageData.data[idx + 1]!;
          const b = imageData.data[idx + 2]!;
          const a = imageData.data[idx + 3]!;
          if (a < 30 || (r > 245 && g > 245 && b > 245)) {
            row.push(null);
          } else {
            const dmc = findClosestDMCLocal(r, g, b);
            colorCount[dmc] = (colorCount[dmc] ?? 0) + 1;
            row.push(dmc);
          }
        }
        rawGrid.push(row);
      }

      // Limiter au nombre de couleurs max
      const sortedColors = Object.entries(colorCount).sort((a, b) => b[1] - a[1]);
      const keptColors = new Set(sortedColors.slice(0, maxC).map(([code]) => code));
      const keptEntries = dmcEntries.filter(([code]) => keptColors.has(code));

      // Deuxième passe : remplacer les couleurs non gardées
      const newGrid: GridCell[][] = rawGrid.map(row =>
        row.map(dmc => {
          let finalDmc = dmc;
          if (dmc && !keptColors.has(dmc)) {
            const dmcColor = DMC_COLORS[dmc];
            if (dmcColor) {
              let best = dmc;
              let minDist = Infinity;
              for (const [code, color] of keptEntries) {
                const dr = dmcColor.r - color.r, dg = dmcColor.g - color.g, db = dmcColor.b - color.b;
                const dist = dr * dr + dg * dg + db * db;
                if (dist < minDist) { minDist = dist; best = code; }
              }
              finalDmc = best;
            }
          }
          return {
            dmc: finalDmc,
            hex: finalDmc ? (DMC_PALETTE[finalDmc]?.hex ?? "#cccccc") : null,
            stitchType: "full" as StitchType,
          };
        })
      );

      setGrid(newGrid);
      setRows(targetH);
      setCols(targetW);
      setPatternName(`Patron IA — ${aiPrompt.slice(0, 30)}`);
      setCurrentGridId(null);
      const usedCount = new Set(newGrid.flat().filter(c => c.dmc).map(c => c.dmc)).size;
      if (usedCount > 0) {
        const firstColor = newGrid.flat().find(c => c.dmc)?.dmc;
        if (firstColor) setSelectedColor(firstColor);
      }
      // Conserver l'image source : revenir à preview pour permettre une re-conversion
      setAIStep("preview");
      // NB : aiGeneratedImageUrl est conservé intentionnellement
      toast.success(`✓ Patron généré — ${usedCount} couleurs DMC · Ajustez les couleurs et reconvertissez si besoin`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erreur lors de la conversion";
      toast.error(msg);
      setAIStep("preview");
    }
  }, [aiGeneratedImageUrl, aiGridSize, aiMaxColors, aiPrompt]);

  // ── Dérivés ──────────────────────────────────────────────────────────────────
  const filledCount = useMemo(() => grid.flat().filter(c => c.dmc).length, [grid]);
  const totalPoints = rows * cols;

  // Couleurs présentes dans la grille (triées par nombre de points décroissant)
  const threadCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    grid.flat().forEach(cell => {
      if (cell.dmc) counts[cell.dmc] = (counts[cell.dmc] ?? 0) + 1;
    });
    return counts;
  }, [grid]);

  const gridColors = useMemo(
    () => Object.keys(threadCounts).sort((a, b) => (threadCounts[b] ?? 0) - (threadCounts[a] ?? 0)),
    [threadCounts]
  );

  // Smart Pathing™
  const smartPathResult = useMemo(() => {
    if (!showSmartPath) return null;
    return computeSmartPathOrdered(grid, selectedColor);
  }, [showSmartPath, grid, selectedColor]);

  const allSmartPath = useMemo(() => {
    if (!smartPathResult) return [];
    return [
      ...smartPathResult.fillPath,
      ...smartPathResult.threeQuarterPath,
      ...smartPathResult.backstitchPath,
      ...smartPathResult.frenchKnotPath,
    ];
  }, [smartPathResult]);

  const smartPathSet = useMemo(
    () => new Set(allSmartPath.map(([r, c]) => `${r}-${c}`)),
    [allSmartPath]
  );

  const smartPathIndex = useMemo(() => {
    const map: Record<string, number> = {};
    allSmartPath.forEach(([r, c], i) => { map[`${r}-${c}`] = i; });
    return map;
  }, [allSmartPath]);

  // ── Peinture ─────────────────────────────────────────────────────────────────
  const pushUndo = useCallback((current: GridCell[][]) => {
    undoStack.current.push(current.map(r => r.map(c => ({ ...c }))));
    if (undoStack.current.length > MAX_UNDO) undoStack.current.shift();
  }, []);

  const paintCell = useCallback(
    (row: number, col: number) => {
      setGrid(prev => {
        const next = prev.map(r => r.map(c => ({ ...c })));
        if (tool === "erase") {
          next[row]![col] = { dmc: null, hex: null };
        } else if (tool === "fill") {
          const targetDmc = prev[row]?.[col]?.dmc ?? null;
          const fillColor = { dmc: selectedColor, hex: DMC_PALETTE[selectedColor]?.hex ?? "#ccc", stitchType };
          const visited = new Set<string>();
          const queue: [number, number][] = [[row, col]];
          while (queue.length > 0) {
            const [r, c] = queue.shift()!;
            const key = `${r}-${c}`;
            if (visited.has(key)) continue;
            if (r < 0 || r >= next.length || c < 0 || c >= (next[r]?.length ?? 0)) continue;
            if (next[r]![c]!.dmc !== targetDmc) continue;
            visited.add(key);
            next[r]![c] = { ...fillColor };
            queue.push([r - 1, c], [r + 1, c], [r, c - 1], [r, c + 1]);
          }
        } else {
          next[row]![col] = {
            dmc: selectedColor,
            hex: DMC_PALETTE[selectedColor]?.hex ?? "#ccc",
            stitchType,
          };
        }
        return next;
      });
    },
    [tool, selectedColor, stitchType]
  );

  const handleMouseDown = (row: number, col: number) => {
    pushUndo(grid);
    setIsDrawing(true);
    paintCell(row, col);
  };

  const handleMouseEnter = (row: number, col: number) => {
    setHoveredCell({ row, col });
    if (isDrawing && tool !== "fill") paintCell(row, col);
  };

  const handleMouseUp = () => setIsDrawing(false);

  const handleUndo = () => {
    const prev = undoStack.current.pop();
    if (prev) setGrid(prev);
  };

  // ── Réinitialisation ─────────────────────────────────────────────────────────
  const resetGrid = () => {
    pushUndo(grid);
    setGrid(INITIAL_PATTERN.map(row =>
      row.map(dmc => ({
        dmc,
        hex: dmc ? (DMC_PALETTE[dmc]?.hex ?? "#cccccc") : null,
        stitchType: "full" as StitchType,
      }))
    ));
    setRows(DEFAULT_ROWS);
    setCols(DEFAULT_COLS);
    setPatternName("Rose Sauvage");
    setCurrentGridId(null);
  };

  const loadEmptyGrid = () => {
    pushUndo(grid);
    setGrid(Array.from({ length: rows }, () =>
      Array.from({ length: cols }, () => ({ dmc: null, hex: null, stitchType: "full" as StitchType }))
    ));
    setPatternName("Nouveau patron");
    setCurrentGridId(null);
  }  // ── Confetti Cleaner™ ──────────────────────────────────────────────────────────────────
  // Compte les points "confetti" = cellules isolées (< confettiThreshold voisins de même couleur)
  const confettiCount = useMemo(() => {
    let count = 0;
    grid.forEach((row, r) => {
      row.forEach((cell, c) => {
        if (!cell.dmc) return;
        const neighbors = [
          grid[r - 1]?.[c]?.dmc, grid[r + 1]?.[c]?.dmc,
          grid[r]?.[c - 1]?.dmc, grid[r]?.[c + 1]?.dmc,
        ].filter(d => d === cell.dmc).length;
        if (neighbors < confettiThreshold) count++;
      });
    });
    return count;
  }, [grid, confettiThreshold]);

  const applyConfettiCleaner = useCallback(() => {
    pushUndo(grid);
    setGrid(prev => {
      const next = prev.map(r => r.map(c => ({ ...c })));
      prev.forEach((row, r) => {
        row.forEach((cell, c) => {
          if (!cell.dmc) return;
          const neighbors = [
            prev[r - 1]?.[c]?.dmc, prev[r + 1]?.[c]?.dmc,
            prev[r]?.[c - 1]?.dmc, prev[r]?.[c + 1]?.dmc,
          ].filter(d => d === cell.dmc).length;
          if (neighbors < confettiThreshold) {
            // Remplacer par la couleur voisine la plus fréquente
            const neighborColors = [
              prev[r - 1]?.[c], prev[r + 1]?.[c],
              prev[r]?.[c - 1], prev[r]?.[c + 1],
            ].filter(Boolean) as GridCell[];
            const colorFreq: Record<string, number> = {};
            neighborColors.forEach(n => { if (n.dmc) colorFreq[n.dmc] = (colorFreq[n.dmc] ?? 0) + 1; });
            const bestColor = Object.entries(colorFreq).sort((a, b) => b[1] - a[1])[0]?.[0];
            if (bestColor) {
              next[r]![c] = { dmc: bestColor, hex: DMC_PALETTE[bestColor]?.hex ?? "#ccc", stitchType: cell.stitchType };
            } else {
              next[r]![c] = { dmc: null, hex: null };
            }
          }
        });
      });
      return next;
    });
    toast.success(`✓ ${confettiCount} confettis éliminés`);
    setShowConfettiCleaner(false);
  }, [grid, confettiThreshold, confettiCount, pushUndo]);

  // ── Import fichier ──────────────────────────────────────────────────────────────────
  const handleFileImport = useCallback(async (file: File) => {
    const isPDF = file.type === "application/pdf" || file.name.endsWith(".pdf");
    const isImage = file.type.startsWith("image/") || file.name.match(/\.(png|jpe?g|webp)$/i);
    if (!isPDF && !isImage) {
      toast.error("Format non supporté. Utilisez PNG, JPEG ou PDF.");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error("Fichier trop volumineux (max 20 Mo).");
      return;
    }
    setPendingImportFile(file);
    setSelectedPdfPage(1);
    resetPdf();
    // Nettoyer l'URL de prévisualisation précédente
    setImagePreviewUrl(prev => { if (prev) URL.revokeObjectURL(prev); return null; });
    if (isPDF) {
      // Pour les PDF, charger les miniatures et détecter automatiquement la meilleure page
      setIsPdfMode(true);
      setIsLoadingPdfPreviews(true);
      setShowImportDialog(true);
      const { bestPage } = await loadPdfPreviews(file);
      // Présélectionner automatiquement la page de grille détectée
      setSelectedPdfPage(bestPage);
      setIsLoadingPdfPreviews(false);
    } else {
      // Générer une URL de prévisualisation pour l'image
      const previewUrl = URL.createObjectURL(file);
      setImagePreviewUrl(previewUrl);
      setIsPdfMode(false);
      setShowImportDialog(true);
    }
  }, [loadPdfPreviews, resetPdf]);

  const handleImportConfirm = useCallback(async () => {
    if (!pendingImportFile) return;
    setShowImportDialog(false);
    toast.info(`Import de "${pendingImportFile.name}" (page ${isPdfMode ? selectedPdfPage : 1}) en cours…`);
    const result = isPdfMode
      ? await importPdfPage(selectedPdfPage, importGridSize.rows, importGridSize.cols, pendingImportFile.name)
      : await importFile(pendingImportFile, importGridSize.rows, importGridSize.cols);
    if (result) {
      pushUndo(grid);
      // Filtrer les couleurs si importMaxColors est défini
      let filteredGrid = result.grid;
      if (importMaxColors < 48) {
        // Compter les couleurs et garder les N plus fréquentes
        const freq: Record<string, number> = {};
        result.grid.flat().filter(Boolean).forEach(d => { freq[d!] = (freq[d!] ?? 0) + 1; });
        const topColors = new Set(
          Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, importMaxColors).map(([k]) => k)
        );
        filteredGrid = result.grid.map(row =>
          row.map(dmc => (dmc && topColors.has(dmc) ? dmc : null))
        );
      }
      const newGrid: GridCell[][] = filteredGrid.map(row =>
        row.map(dmc => ({
          dmc,
          hex: dmc ? (DMC_PALETTE[dmc]?.hex ?? "#cccccc") : null,
          stitchType: "full" as StitchType,
        }))
      );
      setGrid(newGrid);
      setRows(result.rows);
      setCols(result.cols);
      setPatternName(pendingImportFile.name.replace(/\.(pdf|png|jpe?g|webp)$/i, ""));
      setCurrentGridId(null);
      setShowImportPanel(false);
      setPendingImportFile(null);
      const usedColors = new Set(newGrid.flat().filter(c => c.dmc).map(c => c.dmc!)).size;
      toast.success(`✓ Patron importé — ${usedColors} couleurs DMC sur ${result.rows}×${result.cols} points`);
    } else {
      toast.error("Impossible d'importer ce fichier.");
    }
  }, [pendingImportFile, importFile, importPdfPage, isPdfMode, selectedPdfPage, importGridSize, importMaxColors, grid, pushUndo]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileImport(file);
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileImport(file);
  };

  // ── Export PNG ────────────────────────────────────────────────────────────────
  const exportAsPNG = () => {
    const canvas = document.createElement("canvas");
    const cellSize = 20;
    canvas.width = cols * cellSize;
    canvas.height = rows * cellSize;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#F5F0E8";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    grid.forEach((row, r) => {
      row.forEach((cell, c) => {
        if (cell.dmc && cell.hex) {
          ctx.fillStyle = cell.hex;
          ctx.fillRect(c * cellSize + 1, r * cellSize + 1, cellSize - 2, cellSize - 2);
          ctx.strokeStyle = "rgba(0,0,0,0.3)";
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(c * cellSize + 2, r * cellSize + 2);
          ctx.lineTo(c * cellSize + cellSize - 2, r * cellSize + cellSize - 2);
          ctx.moveTo(c * cellSize + cellSize - 2, r * cellSize + 2);
          ctx.lineTo(c * cellSize + 2, r * cellSize + cellSize - 2);
          ctx.stroke();
        }
      });
    });
    ctx.strokeStyle = "rgba(0,0,0,0.1)";
    ctx.lineWidth = 0.5;
    for (let r = 0; r <= rows; r++) {
      ctx.beginPath(); ctx.moveTo(0, r * cellSize); ctx.lineTo(cols * cellSize, r * cellSize); ctx.stroke();
    }
    for (let c = 0; c <= cols; c++) {
      ctx.beginPath(); ctx.moveTo(c * cellSize, 0); ctx.lineTo(c * cellSize, rows * cellSize); ctx.stroke();
    }
    const link = document.createElement("a");
    link.download = `threadflow-${patternName.toLowerCase().replace(/\s+/g, "-")}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  // ── Sauvegarde ────────────────────────────────────────────────────────────────
  const serializeGrid = () => {
    const sparse: Record<string, { dmc: string; stitchType?: StitchType }> = {};
    grid.forEach((row, r) => {
      row.forEach((cell, c) => {
        if (cell.dmc) {
          sparse[`${r},${c}`] = { dmc: cell.dmc, stitchType: cell.stitchType ?? "full" };
        }
      });
    });
    return JSON.stringify(sparse);
  };

  const deserializeGrid = (data: string, w: number, h: number): GridCell[][] => {
    const sparse = JSON.parse(data) as Record<string, { dmc: string; stitchType?: StitchType }>;
    return Array.from({ length: h }, (_, r) =>
      Array.from({ length: w }, (_, c) => {
        const entry = sparse[`${r},${c}`];
        if (!entry) return { dmc: null, hex: null, stitchType: "full" as StitchType };
        return {
          dmc: entry.dmc,
          hex: DMC_PALETTE[entry.dmc]?.hex ?? "#ccc",
          stitchType: entry.stitchType ?? "full",
        };
      })
    );
  };

  const handleSave = () => {
    const gridData = serializeGrid();
    if (currentGridId) {
      updateMutation.mutate({ id: currentGridId, name: patternName, gridData, width: cols, height: rows });
    } else {
      setSaveName(patternName);
      setShowSaveDialog(true);
    }
  };

  const handleSaveConfirm = () => {
    saveMutation.mutate({
      name: saveName || patternName,
      width: cols,
      height: rows,
      gridData: serializeGrid(),
    });
  };

  const handleLoadGrid = (g: { id: number; name: string; width: number; height: number; gridData: string | null }) => {
    if (!g.gridData) return;
    pushUndo(grid);
    const loaded = deserializeGrid(g.gridData, g.width, g.height);
    setGrid(loaded);
    setRows(g.height);
    setCols(g.width);
    setPatternName(g.name);
    setCurrentGridId(g.id);
    setShowLoadDialog(false);
    toast.success(`Patron "${g.name}" chargé`);
  };

  // ── Keyboard shortcuts ──────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z") { e.preventDefault(); handleUndo(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); handleSave(); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [grid]);

  // ── Molette souris pour zoom fluide (Ctrl+molette) ─────────────────────────────────────
  const gridContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = gridContainerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const delta = e.deltaY > 0 ? -2 : 2;
        setZoom(z => Math.min(56, Math.max(12, z + delta)));
      }
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);  // ─── Sélecteur de type de point ───────────────────────────────────────────────
  const FILL_TYPES: { type: StitchType; label: string }[] = [
    { type: "full", label: "Croix complète" },
    { type: "half_fwd", label: "Demi /" },
    { type: "half_bwd", label: "Demi \\" },
    { type: "quarter_tl", label: "¼ ↖" },
    { type: "quarter_tr", label: "¼ ↗" },
    { type: "quarter_bl", label: "¼ ↙" },
    { type: "quarter_br", label: "¼ ↘" },
    { type: "three_quarter_tl", label: "¾ ↖" },
    { type: "three_quarter_tr", label: "¾ ↗" },
    { type: "three_quarter_bl", label: "¾ ↙" },
    { type: "three_quarter_br", label: "¾ ↘" },
  ];
  const OUTLINE_TYPES: { type: StitchType; label: string }[] = [
    { type: "backstitch_h", label: "Arrière —" },
    { type: "backstitch_v", label: "Arrière |" },
    { type: "backstitch_d1", label: "Arrière /" },
    { type: "backstitch_d2", label: "Arrière \\" },
    { type: "french_knot", label: "Nœud fr." },
  ];

  // ─── JSX ──────────────────────────────────────────────────────────────────────
  return (
    <div
      className="flex flex-col h-full min-h-screen"
      style={{ background: "#e8e3da" }}
      onMouseUp={handleMouseUp}
    >
      {/* Barre d'outils principale */}
      <div
        className="sticky top-0 z-40 border-b px-4 h-12 flex items-center justify-between gap-2"
        style={{ background: "#e8e3daf5", borderColor: "#d4c5a9", backdropFilter: "blur(8px)" }}
      >
        <div className="flex items-center gap-2">
          <span
            className="font-bold text-base hidden sm:block"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            {patternName}
          </span>
          <Badge className="text-xs" style={{ background: "#7A9E7E22", color: "#3D4A3E" }}>
            {rows}×{cols}
          </Badge>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Zoom fluide */}
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom(z => Math.max(12, z - 4))}>
            <ZoomOut className="w-3.5 h-3.5" />
          </Button>
          <div className="flex items-center gap-1.5">
            <Slider
              value={[zoom]}
              onValueChange={([v]) => setZoom(v)}
              min={12} max={56} step={2}
              className="w-24 h-4"
            />
            <span className="text-xs tabular-nums w-8 text-right" style={{ color: "#6b7a6c" }}>{zoom}px</span>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom(z => Math.min(56, z + 4))}>
            <ZoomIn className="w-3.5 h-3.5" />
          </Button>

          <div className="w-px h-5 mx-1" style={{ background: "#d4c5a9" }} />

          {/* Undo */}
          <Button variant="ghost" size="sm" onClick={handleUndo} title="Annuler (Ctrl+Z)">
            <RotateCcw className="w-3.5 h-3.5" />
          </Button>

          {/* Mode aperçu réaliste */}
          <Button
            variant="ghost" size="sm"
            onClick={() => setRealisticMode(p => !p)}
            className="gap-1.5"
            style={{ color: realisticMode ? "#7A9E7E" : undefined }}
            title="Mode aperçu réaliste"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-xs">Aperçu fil</span>
          </Button>

          {/* Import */}
          <Button
            variant="ghost" size="sm"
            onClick={() => setShowImportPanel(p => !p)}
            className="gap-1.5"
            style={{ color: showImportPanel ? "#C4714A" : undefined }}
          >
            <Upload className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-xs">Importer</span>
          </Button>

          {/* Générateur IA */}
          <Button
            size="sm"
            onClick={() => setShowAIDialog(true)}
            className="gap-1.5 hidden sm:flex"
            style={{ background: "linear-gradient(135deg, #7A9E7E, #C4714A)", color: "white", border: "none" }}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span className="text-xs">Générer avec IA</span>
          </Button>

          {/* Export PNG */}
          <Button
            size="sm" onClick={exportAsPNG}
            className="gap-1.5"
            style={{ background: "#C4714A", color: "white", border: "none" }}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-xs">Exporter PNG</span>
          </Button>

          {/* Sauvegarder */}
          <Button
            size="sm" onClick={handleSave}
            disabled={saveMutation.isPending || updateMutation.isPending}
            className="gap-1.5"
            style={{ background: "#3D4A3E", color: "white", border: "none" }}
          >
            <Save className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-xs">Sauvegarder</span>
          </Button>
        </div>
      </div>

      {/* Panneau import */}
      {showImportPanel && (
        <div className="border-b px-4 py-4" style={{ background: "#F5F0E8", borderColor: "#d4c5a9" }}>
          <div className="max-w-2xl mx-auto">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-sm" style={{ color: "#3D4A3E" }}>
                  Importer un patron (PNG, JPEG ou PDF)
                </h3>
                <p className="text-xs mt-0.5" style={{ color: "#6b7a6c" }}>
                  ThreadFlow extrait les pixels et les convertit automatiquement en codes DMC.
                </p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowImportPanel(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            {/* Taille cible */}
            <div className="flex items-center gap-3 mb-3">
              <span className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Résolution :</span>
              {[{ label: "20×20", v: 20 }, { label: "40×40", v: 40 }, { label: "60×60", v: 60 }, { label: "80×80", v: 80 }].map(opt => (
                <button
                  key={opt.label}
                  onClick={() => setImportGridSize({ rows: opt.v, cols: opt.v })}
                  className="text-xs px-3 py-1 rounded-lg transition-all"
                  style={{
                    background: importGridSize.rows === opt.v ? "#C4714A" : "#e8e3da",
                    color: importGridSize.rows === opt.v ? "white" : "#6b7a6c",
                  }}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            {/* Zone de drop */}
            <div
              ref={dropZoneRef}
              onDrop={handleDrop}
              onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
              onDragLeave={() => setIsDragOver(false)}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all"
              style={{
                borderColor: isDragOver ? "#C4714A" : "#d4c5a9",
                background: isDragOver ? "#C4714A0a" : "#e8e3da",
              }}
            >
              {importStatus === "loading" ? (
                <div className="space-y-3">
                  <div className="text-sm font-medium" style={{ color: "#6b7a6c" }}>
                    Extraction en cours… {importProgress}%
                  </div>
                  <div className="h-2 rounded-full overflow-hidden mx-auto max-w-xs" style={{ background: "#d4c5a9" }}>
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{ width: `${importProgress}%`, background: "linear-gradient(90deg, #7A9E7E, #C4714A)" }}
                    />
                  </div>
                </div>
              ) : importStatus === "error" ? (
                <div className="space-y-2">
                  <AlertCircle className="w-8 h-8 mx-auto" style={{ color: "#C4714A" }} />
                  <p className="text-sm font-medium" style={{ color: "#3D4A3E" }}>{importError}</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="w-10 h-10 mx-auto" style={{ color: "#7A9E7E" }} />
                  <p className="text-sm font-medium" style={{ color: "#3D4A3E" }}>
                    Glissez votre patron ici
                  </p>
                  <p className="text-xs" style={{ color: "#6b7a6c" }}>
                    PNG, JPEG, PDF · max 20 Mo
                  </p>
                </div>
              )}
            </div>
            <input ref={fileInputRef} type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/*" className="hidden" onChange={handleFileInput} />
          </div>
        </div>
      )}

      {/* Corps principal */}
      <div className="flex flex-1 gap-0 relative">
        {/* ── Panneau gauche ─────────────────────────────────────────────────── */}
        <aside
          className="w-60 flex-shrink-0 overflow-y-auto p-3 space-y-3"
          style={{ background: "#e8e3da", borderRight: "1px solid #d4c5a9" }}
        >
          {/* Progression */}
          <div className="rounded-2xl p-3" style={{ background: "#e8e3da", boxShadow: "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2" }}>
            <div className="flex justify-between text-xs mb-1.5">
              <span style={{ color: "#6b7a6c" }}>Points brodés</span>
              <span className="font-bold" style={{ color: "#C4714A" }}>{filledCount} / {totalPoints}</span>
            </div>
            <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "#d4c5a9" }}>
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{ width: `${totalPoints > 0 ? (filledCount / totalPoints) * 100 : 0}%`, background: "linear-gradient(90deg, #7A9E7E, #C4714A)" }}
              />
            </div>
            <div className="text-xs mt-1" style={{ color: "#6b7a6c" }}>
              {totalPoints > 0 ? Math.round((filledCount / totalPoints) * 100) : 0}% complété
            </div>
          </div>

          {/* Outil */}
          <div className="rounded-2xl p-3" style={{ background: "#e8e3da", boxShadow: "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2" }}>
            <h3 className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "#6b7a6c" }}>Outil</h3>
            <div className="flex gap-1.5">
              {(["paint", "erase", "fill"] as Tool[]).map(t => (
                <button
                  key={t}
                  onClick={() => setTool(t)}
                  className="flex-1 py-1.5 rounded-xl text-xs font-medium transition-all"
                  style={{
                    background: tool === t ? "#C4714A" : "#d4c5a9",
                    color: tool === t ? "white" : "#6b7a6c",
                  }}
                >
                  {t === "paint" ? "✕ Broder" : t === "erase" ? "○ Effacer" : "▣ Remplir"}
                </button>
              ))}
            </div>
          </div>

          {/* Type de point */}
          <div className="rounded-2xl p-3" style={{ background: "#e8e3da", boxShadow: "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2" }}>
            <h3 className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "#6b7a6c" }}>Type de point</h3>
            <div className="mb-1.5">
              <p className="text-xs mb-1" style={{ color: "#9aaa9b" }}>Remplissage</p>
              <div className="grid grid-cols-4 gap-1">
                {FILL_TYPES.map(({ type, label }) => (
                  <Tooltip key={type}>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => setStitchType(type)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center transition-all"
                        style={{
                          background: stitchType === type ? "#C4714A22" : "#d4c5a9",
                          border: stitchType === type ? "1.5px solid #C4714A" : "1.5px solid transparent",
                          boxShadow: stitchType === type ? "inset 2px 2px 4px #b8b3aa, inset -1px -1px 3px #faf7f2" : "2px 2px 4px #c8c3ba, -1px -1px 3px #faf7f2",
                        }}
                      >
                        <StitchIcon type={type} active={stitchType === type} />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent><p className="text-xs">{label}</p></TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs mb-1" style={{ color: "#9aaa9b" }}>Contours & Texture</p>
              <div className="grid grid-cols-4 gap-1">
                {OUTLINE_TYPES.map(({ type, label }) => (
                  <Tooltip key={type}>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => setStitchType(type)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center transition-all"
                        style={{
                          background: stitchType === type ? "#C4714A22" : "#d4c5a9",
                          border: stitchType === type ? "1.5px solid #C4714A" : "1.5px solid transparent",
                          boxShadow: stitchType === type ? "inset 2px 2px 4px #b8b3aa, inset -1px -1px 3px #faf7f2" : "2px 2px 4px #c8c3ba, -1px -1px 3px #faf7f2",
                        }}
                      >
                        <StitchIcon type={type} active={stitchType === type} />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent><p className="text-xs">{label}</p></TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
            <div className="mt-2 px-2 py-1 rounded-lg text-xs" style={{ background: "#d4c5a9", color: "#6b7a6c" }}>
              Actif : <strong style={{ color: "#3D4A3E" }}>{[...FILL_TYPES, ...OUTLINE_TYPES].find(t => t.type === stitchType)?.label}</strong>
            </div>
          </div>

          {/* Palette DMC */}
          <div className="rounded-2xl p-3" style={{ background: "#e8e3da", boxShadow: "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2" }}>
            <h3 className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "#6b7a6c" }}>
              Palette DMC ({gridColors.length} couleurs)
            </h3>
            <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
              {gridColors.map(code => (
                <button
                  key={code}
                  onClick={() => { setSelectedColor(code); setTool("paint"); }}
                  className="w-full flex items-center gap-2 px-2 py-1.5 rounded-xl text-xs transition-all"
                  style={{
                    background: selectedColor === code ? "#C4714A11" : "transparent",
                    border: selectedColor === code ? "1px solid #C4714A4d" : "1px solid transparent",
                  }}
                >
                  <span
                    className="w-8 h-8 rounded-lg flex-shrink-0 border"
                    style={{
                      background: realisticMode
                        ? `repeating-linear-gradient(135deg, ${DMC_PALETTE[code]?.hex ?? "#ccc"}ee 0px, ${DMC_PALETTE[code]?.hex ?? "#ccc"}aa 2px, ${DMC_PALETTE[code]?.hex ?? "#ccc"}ee 4px)`
                        : (DMC_PALETTE[code]?.hex ?? "#ccc"),
                      borderColor: "#d4c5a9",
                      borderRadius: "8px",
                      boxShadow: selectedColor === code
                        ? `0 0 0 2px #C4714A66, 3px 3px 6px #c8c3ba, -2px -2px 4px #faf7f2`
                        : `2px 2px 4px #c8c3ba, -1px -1px 3px #faf7f2`,
                    }}
                  />
                  <span className="flex-1 text-left truncate" style={{ color: "#3D4A3E" }}>
                    DMC {code}
                    {DMC_PALETTE[code]?.name && (
                      <span className="ml-1 opacity-60 truncate">{DMC_PALETTE[code].name}</span>
                    )}
                  </span>
                  {threadCounts[code] !== undefined && (
                    <span
                      className="text-xs font-medium px-1.5 py-0.5 rounded-full flex-shrink-0"
                      style={{ background: "#d4c5a9", color: "#6b7a6c" }}
                    >
                      {threadCounts[code]}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Patrons */}
          <div className="rounded-2xl p-3" style={{ background: "#e8e3da", boxShadow: "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2" }}>
            <h3 className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "#6b7a6c" }}>Patrons</h3>
            <div className="space-y-1.5">
              <button
                onClick={resetGrid}
                className="w-full text-left px-2.5 py-2 rounded-xl text-xs transition-all"
                style={{ background: "#7A9E7E18", color: "#3D4A3E", border: "1px solid #7A9E7E33" }}
              >
                🌹 Rose Sauvage (20×20)
              </button>
              <button
                onClick={loadEmptyGrid}
                className="w-full text-left px-2.5 py-2 rounded-xl text-xs transition-all"
                style={{ background: "#d4c5a9", color: "#6b7a6c" }}
              >
                ⬜ Grille vierge ({rows}×{cols})
              </button>
              <button
                onClick={() => setShowLoadDialog(true)}
                className="w-full text-left px-2.5 py-2 rounded-xl text-xs transition-all flex items-center gap-1.5"
                style={{ background: "#3D4A3E18", color: "#3D4A3E", border: "1px solid #3D4A3E33" }}
              >
                <FolderOpen className="w-3 h-3" />
                Mes patrons sauvegardés
              </button>
              <button
                onClick={() => setShowImportPanel(p => !p)}
                className="w-full text-left px-2.5 py-2 rounded-xl text-xs transition-all flex items-center gap-1.5"
                style={{ background: "#C4714A11", color: "#C4714A", border: "1px solid #C4714A33" }}
              >
                <Upload className="w-3 h-3" />
                Importer PNG / JPEG / PDF
              </button>
            </div>
          </div>
        </aside>        {/* ── Zone grille ────────────────────────────────────────────────────────────────── */}
        <main ref={gridContainerRef} className="flex-1 min-w-0 overflow-auto">
          <div className="min-h-full flex flex-col items-center justify-center p-4">
          <div className="w-full mb-3 flex items-center justify-between">
            <p className="text-sm" style={{ color: "#6b7a6c" }}>
              Patron point de croix · {rows}×{cols} · {gridColors.length} couleurs DMC
            </p>
            {hoveredCell && (
              <div
                className="text-xs px-3 py-1 rounded-full"
                style={{ background: "#d4c5a9", color: "#6b7a6c" }}
              >
                Col {hoveredCell.col + 1}, Ligne {hoveredCell.row + 1}
                {grid[hoveredCell.row]?.[hoveredCell.col]?.dmc && (
                  <> · DMC {grid[hoveredCell.row]![hoveredCell.col]!.dmc}</>
                )}
              </div>
            )}
          </div>

          {/* Grille */}
          <div
            className="inline-block rounded-2xl p-4 overflow-auto"
            style={{ background: "#e8e3da", boxShadow: "6px 6px 16px #c8c3ba, -4px -4px 12px #faf7f2", position: "relative" }}
          >
            {/* ── Overlay Confetti Cleaner™ split-screen — diviseur glissable sur la vraie grille ── */}
            {showConfettiCleaner && (
              <ConfettiSplitOverlay
                grid={grid}
                rows={rows}
                cols={cols}
                zoom={zoom}
                threshold={confettiThreshold}
                splitPos={confettiSplitPos}
                onSplitPosChange={setConfettiSplitPos}
                confettiCount={confettiCount}
                onApply={applyConfettiCleaner}
              />
            )}
            {/* Numéros de colonnes */}
            <div className="flex mb-1 ml-6">
              {Array.from({ length: cols }, (_, c) => (
                <div
                  key={c}
                  className="flex-shrink-0 text-center select-none"
                  style={{ width: zoom, color: "#9aaa9b", fontSize: zoom < 24 ? "7px" : "9px" }}
                >
                  {(c + 1) % 5 === 0 ? c + 1 : ""}
                </div>
              ))}
            </div>

            {/* Lignes de la grille */}
            <div
              className="select-none"
              style={{ cursor: tool === "erase" ? "cell" : tool === "fill" ? "copy" : "crosshair" }}
            >
              {grid.map((row, r) => (
                <div key={r} className="flex items-center">
                  {/* Numéro de ligne */}
                  <div
                    className="flex-shrink-0 text-right pr-1 select-none"
                    style={{ width: 20, color: "#9aaa9b", fontSize: zoom < 24 ? "7px" : "9px" }}
                  >
                    {(r + 1) % 5 === 0 ? r + 1 : ""}
                  </div>

                  {row.map((cell, c) => {
                    const isInPath = smartPathSet.has(`${r}-${c}`);
                    const pathIdx = smartPathIndex[`${r}-${c}`];
                    const isHovered = hoveredCell?.row === r && hoveredCell?.col === c;
                    const previewColor = isHovered && tool === "paint" && !cell.dmc
                      ? (DMC_PALETTE[selectedColor]?.hex ?? "#ccc") + "55"
                      : undefined;

                    return (
                      <div
                        key={c}
                        className="flex-shrink-0 relative transition-colors duration-75"
                        style={{
                          width: zoom,
                          height: zoom,
                          background: cell.hex
                            ? (realisticMode
                              ? `repeating-linear-gradient(135deg, ${cell.hex}ee 0px, ${cell.hex}cc 2px, ${cell.hex}ee 4px)`
                              : cell.hex)
                            : (previewColor ?? "transparent"),
                          border: `0.5px solid rgba(180,170,160,${zoom < 20 ? 0.3 : 0.5})`,
                          boxShadow: isInPath
                            ? "inset 0 0 0 2px #7A9E7E"
                            : isHovered
                            ? "inset 0 0 0 1.5px #C4714A"
                            : "none",
                          cursor: tool === "erase" ? "cell" : tool === "fill" ? "copy" : "crosshair",
                        }}
                        onMouseDown={() => handleMouseDown(r, c)}
                        onMouseEnter={() => handleMouseEnter(r, c)}
                      >
                        {/* Rendu du type de point */}
                        {cell.dmc && zoom >= 18 && (
                          <StitchSVG
                            type={cell.stitchType ?? "full"}
                            color={cell.hex ?? "#000"}
                            size={zoom}
                          />
                        )}

                        {/* Numéro Smart Pathing™ + halo néon */}
                        {isInPath && (
                          <>
                            {/* Halo néon sur la cellule */}
                            <div
                              className="absolute inset-0 pointer-events-none"
                              style={{
                                background: "rgba(122,158,126,0.25)",
                                boxShadow: "inset 0 0 0 1.5px #7A9E7E, 0 0 6px #7A9E7E88",
                                zIndex: 1,
                              }}
                            />
                            {pathIdx !== undefined && zoom >= 22 && (
                              <span
                                className="absolute inset-0 flex items-center justify-center font-bold pointer-events-none"
                                style={{
                                  fontSize: Math.max(7, zoom * 0.30),
                                  color: "white",
                                  textShadow: "0 0 4px #3D4A3E, 0 1px 2px rgba(0,0,0,0.8)",
                                  zIndex: 3,
                                }}
                              >
                                {pathIdx + 1}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
            {/* Chemin néon Smart Pathing™ — SVG superposé en absolute */}
            {showSmartPath && allSmartPath.length > 1 && (() => {
              const svgW = 20 + cols * zoom;
              const svgH = rows * zoom;
              const segments: { color: string; pts: string }[] = [];
              let curColor = "";
              let curPts: string[] = [];
              for (let i = 0; i < allSmartPath.length; i++) {
                const [r, c] = allSmartPath[i]!;
                const cellHex = grid[r]?.[c]?.hex ?? "#7A9E7E";
                const px = 20 + c * zoom + zoom / 2;
                const py = 4 + 20 + r * zoom + zoom / 2; // 4px padding-top + 20px header colonnes
                if (cellHex !== curColor) {
                  if (curPts.length > 1) segments.push({ color: curColor, pts: curPts.join(" ") });
                  curColor = cellHex;
                  curPts = [`${px},${py}`];
                } else {
                  curPts.push(`${px},${py}`);
                }
              }
              if (curPts.length > 1) segments.push({ color: curColor, pts: curPts.join(" ") });
              const sw = Math.max(2, zoom * 0.14);
              const [r0, c0] = allSmartPath[0]!;
              const [rN, cN] = allSmartPath[allSmartPath.length - 1]!;
              const startX = 20 + c0 * zoom + zoom / 2;
              const startY = 4 + 20 + r0 * zoom + zoom / 2;
              const endX = 20 + cN * zoom + zoom / 2;
              const endY = 4 + 20 + rN * zoom + zoom / 2;
              return (
                <svg
                  className="pointer-events-none"
                  style={{ position: "absolute", top: 0, left: 0, width: svgW + 32, height: svgH + 32, zIndex: 20 }}
                  viewBox={`0 0 ${svgW + 32} ${svgH + 32}`}
                >
                  <defs>
                    <filter id="neon-glow" x="-50%" y="-50%" width="200%" height="200%">
                      <feGaussianBlur stdDeviation="2" result="blur" />
                      <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                  </defs>
                  {segments.map((s, i) => (
                    <polyline key={`h${i}`} points={s.pts} fill="none" stroke={s.color} strokeWidth={sw * 3} strokeLinecap="round" strokeLinejoin="round" opacity={0.2} />
                  ))}
                  {segments.map((s, i) => (
                    <polyline key={`l${i}`} points={s.pts} fill="none" stroke={s.color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" opacity={0.88} filter="url(#neon-glow)" />
                  ))}
                  {segments.map((s, i) => (
                    <polyline key={`w${i}`} points={s.pts} fill="none" stroke="white" strokeWidth={sw * 0.35} strokeLinecap="round" strokeLinejoin="round" opacity={0.55} />
                  ))}
                  <circle cx={startX} cy={startY} r={zoom * 0.36} fill="#7A9E7E" opacity={0.95} />
                  <text x={startX} y={startY + zoom * 0.13} textAnchor="middle" fontSize={zoom * 0.32} fill="white" fontWeight="bold">1</text>
                  <circle cx={endX} cy={endY} r={zoom * 0.36} fill="#C4714A" opacity={0.95} />
                  <text x={endX} y={endY + zoom * 0.13} textAnchor="middle" fontSize={zoom * 0.32} fill="white" fontWeight="bold">{allSmartPath.length}</text>
                </svg>
              );
            })()}
          </div>
          {/* Inventaire de fils */}
          {gridColors.length > 0 && (
            <div
              className="mt-4 rounded-2xl p-4"
              style={{ background: "#e8e3da", boxShadow: "4px 4px 12px #c8c3ba, -3px -3px 8px #faf7f2" }}
            >
              <h3 className="font-semibold mb-3 text-sm" style={{ color: "#6b7a6c" }}>
                Inventaire de fils nécessaires
              </h3>
              <div className="flex flex-wrap gap-2">
                {gridColors.map(code => (
                  <div
                    key={code}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs"
                    style={{ background: "#d4c5a9", color: "#3D4A3E" }}
                  >
                    <span className="w-3 h-3 rounded-sm flex-shrink-0" style={{ background: DMC_PALETTE[code]?.hex ?? "#ccc" }} />
                    <span className="font-medium">DMC {code}</span>
                    <span style={{ color: "#6b7a6c" }}>
                      · {threadCounts[code]} pts · ~{Math.ceil((threadCounts[code] ?? 0) * 0.4)} cm
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>{/* fin wrapper centré */}
        </main>

        {/* ── Panneau droit : Smart Pathing™ + Confetti Cleaner™ + Collaboration ── */}
        {showRightPanel && (
          <aside
            className="w-64 flex-shrink-0 overflow-y-auto p-3 space-y-3"
            style={{ background: "#e8e3da", borderLeft: "1px solid #d4c5a9" }}
          >
            {/* Smart Pathing™ — mis en valeur */}
            <div
              className="rounded-2xl p-3"
              style={{
                background: showSmartPath
                  ? "linear-gradient(135deg, #7A9E7E18, #3D4A3E08)"
                  : "#e8e3da",
                boxShadow: showSmartPath
                  ? "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2, inset 0 0 0 1.5px #7A9E7E55"
                  : "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2",
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" style={{ color: "#7A9E7E" }} />
                  <span className="text-xs font-bold" style={{ color: "#3D4A3E" }}>Smart Pathing™</span>
                  {showSmartPath && (
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase tracking-wide"
                      style={{ background: "#7A9E7E", color: "white" }}
                    >
                      ACTIF
                    </span>
                  )}
                </div>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="w-3 h-3" style={{ color: "#9aaa9b" }} />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-48 text-xs">Calcule l'ordre optimal pour broder chaque couleur en minimisant les déplacements de fil.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-[11px] mb-2.5 leading-relaxed" style={{ color: "#6b7a6c" }}>
                Optimise l'ordre de broderie pour économiser du fil et du temps.
              </p>
              <button
                onClick={() => setShowSmartPath(p => !p)}
                className="w-full py-2 rounded-xl text-xs font-semibold transition-all"
                style={{
                  background: showSmartPath
                    ? "linear-gradient(135deg, #7A9E7E, #52725e)"
                    : "#d4c5a9",
                  color: showSmartPath ? "white" : "#6b7a6c",
                  boxShadow: showSmartPath
                    ? "2px 2px 6px #c8c3ba, -1px -1px 4px #faf7f2, 0 0 12px #7A9E7E44"
                    : "2px 2px 4px #c8c3ba, -1px -1px 3px #faf7f2",
                }}
              >
                {showSmartPath ? "✓ Désactiver le chemin" : "Activer le chemin optimal"}
              </button>
              {showSmartPath && allSmartPath.length > 0 && (
                <div className="mt-2.5 space-y-1.5">
                  <div
                    className="flex items-center justify-between px-2.5 py-2 rounded-xl text-xs"
                    style={{ background: "#7A9E7E18", border: "1px solid #7A9E7E33" }}
                  >
                    <span style={{ color: "#52725e" }}>Points optimisés</span>
                    <span className="font-bold" style={{ color: "#7A9E7E" }}>{allSmartPath.length}</span>
                  </div>
                  <div
                    className="flex items-center justify-between px-2.5 py-2 rounded-xl text-xs"
                    style={{ background: "#7A9E7E18", border: "1px solid #7A9E7E33" }}
                  >
                    <span style={{ color: "#52725e" }}>Économie fil ≈</span>
                    <span className="font-bold" style={{ color: "#7A9E7E" }}>{Math.round(allSmartPath.length * 0.8)} cm</span>
                  </div>
                  {smartPathResult && (
                    <div className="text-[10px] space-y-0.5 px-1" style={{ color: "#9aaa9b" }}>
                      {smartPathResult.fillPath.length > 0 && <div>① Remplissage : {smartPathResult.fillPath.length} pts</div>}
                      {smartPathResult.threeQuarterPath.length > 0 && <div>② Trois-quarts : {smartPathResult.threeQuarterPath.length} pts</div>}
                      {smartPathResult.backstitchPath.length > 0 && <div>③ Arrière-points : {smartPathResult.backstitchPath.length} pts</div>}
                      {smartPathResult.frenchKnotPath.length > 0 && <div>④ Nœuds français : {smartPathResult.frenchKnotPath.length} pts</div>}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Confetti Cleaner™ — inline (pas de dialog) */}
            <div
              className="rounded-2xl p-3"
              style={{
                background: showConfettiCleaner ? "#C4714A08" : "#e8e3da",
                boxShadow: showConfettiCleaner
                  ? "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2, inset 0 0 0 1.5px #C4714A44"
                  : "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2",
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Scissors className="w-4 h-4" style={{ color: "#C4714A" }} />
                  <span className="text-xs font-bold" style={{ color: "#3D4A3E" }}>Confetti Cleaner™</span>
                </div>
                {confettiCount > 0 && (
                  <span
                    className="text-[9px] px-1.5 py-0.5 rounded-full font-bold"
                    style={{ background: "#C4714A", color: "white" }}
                  >
                    {confettiCount}
                  </span>
                )}
              </div>
              <p className="text-[11px] mb-2.5 leading-relaxed" style={{ color: "#6b7a6c" }}>
                Élimine les points isolés qui rendent le patron difficile à broder.
              </p>

              {/* Slider sensibilité */}
              <div className="mb-2.5">
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-[10px]" style={{ color: "#9aaa9b" }}>Sensibilité</span>
                  <span className="text-[10px] font-medium" style={{ color: "#C4714A" }}>
                    {confettiThreshold === 1 ? "Agressive" : confettiThreshold === 2 ? "Modérée" : confettiThreshold === 3 ? "Douce" : "Très douce"}
                  </span>
                </div>
                <Slider
                  value={[confettiThreshold]}
                  onValueChange={([v]) => setConfettiThreshold(v)}
                  min={1} max={4} step={1}
                  className="w-full"
                />
              </div>

              {/* Bouton activer l'overlay ou appliquer */}
              <div className="space-y-1.5">
                <button
                  onClick={() => setShowConfettiCleaner(p => !p)}
                  className="w-full py-1.5 rounded-xl text-xs font-medium transition-all"
                  style={{
                    background: showConfettiCleaner ? "#C4714A22" : "#d4c5a9",
                    color: showConfettiCleaner ? "#C4714A" : "#6b7a6c",
                    border: showConfettiCleaner ? "1px solid #C4714A44" : "1px solid transparent",
                  }}
                >
                  {showConfettiCleaner ? "✕ Masquer l'aperçu" : "Voir avant / après sur la grille"}
                </button>
                <button
                  onClick={applyConfettiCleaner}
                  disabled={confettiCount === 0}
                  className="w-full py-2 rounded-xl text-xs font-semibold transition-all"
                  style={{
                    background: confettiCount > 0
                      ? "linear-gradient(135deg, #C4714A, #a05a3a)"
                      : "#d4c5a9",
                    color: confettiCount > 0 ? "white" : "#9aaa9b",
                    boxShadow: confettiCount > 0
                      ? "2px 2px 6px #c8c3ba, -1px -1px 4px #faf7f2"
                      : "none",
                  }}
                >
                  {confettiCount > 0
                    ? `✂ Éliminer ${confettiCount} confetti${confettiCount !== 1 ? "s" : ""}`
                    : "✓ Aucun confetti détecté"}
                </button>
              </div>
            </div>

            {/* Collaboration — Inviter des brodeuses */}
            <div
              className="rounded-2xl p-3"
              style={{ background: "#e8e3da", boxShadow: "4px 4px 10px #c8c3ba, -3px -3px 8px #faf7f2" }}
            >
              <div className="flex items-center gap-1.5 mb-2">
                <Users className="w-4 h-4" style={{ color: "#7A9E7E" }} />
                <span className="text-xs font-bold" style={{ color: "#3D4A3E" }}>Inviter des brodeuses</span>
              </div>
              <p className="text-[11px] mb-2.5 leading-relaxed" style={{ color: "#6b7a6c" }}>
                Partagez ce patron avec d'autres brodeuses pour qu'elles puissent le consulter.
              </p>

              {shareLink ? (
                <div className="space-y-2">
                  <div
                    className="flex items-center gap-1.5 px-2 py-1.5 rounded-xl text-[10px] break-all"
                    style={{ background: "#d4c5a9", color: "#3D4A3E" }}
                  >
                    <Link className="w-3 h-3 flex-shrink-0" style={{ color: "#7A9E7E" }} />
                    <span className="flex-1 truncate">{shareLink}</span>
                  </div>
                  <button
                    onClick={handleCopyShareLink}
                    className="w-full py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                    style={{
                      background: shareCopied ? "#7A9E7E" : "#3D4A3E",
                      color: "white",
                    }}
                  >
                    {shareCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {shareCopied ? "Copié !" : "Copier le lien"}
                  </button>

                  {/* Avatars des brodeuses qui ont consulté le patron */}
                  {shareViewers.data && shareViewers.data.length > 0 && (
                    <div className="pt-1">
                      <p className="text-[10px] mb-1.5 font-medium" style={{ color: "#6b7a6c" }}>
                        {shareViewers.data.length} brodeuse{shareViewers.data.length > 1 ? 's' : ''} ont consulté ce patron
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {shareViewers.data.map((viewer, idx) => (
                          <div
                            key={idx}
                            className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px]"
                            style={{ background: "#d4c5a9", color: "#3D4A3E" }}
                            title={new Date(viewer.viewedAt).toLocaleString()}
                          >
                            <span>{viewer.viewerEmoji}</span>
                            <span className="max-w-[60px] truncate">{viewer.viewerName}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => setShareLink(null)}
                    className="w-full py-1 rounded-xl text-[10px] transition-all"
                    style={{ color: "#9aaa9b" }}
                  >
                    Générer un nouveau lien
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleCreateShare}
                  disabled={isGeneratingShare}
                  className="w-full py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                  style={{
                    background: "linear-gradient(135deg, #7A9E7E, #3D4A3E)",
                    color: "white",
                    boxShadow: "2px 2px 6px #c8c3ba, -1px -1px 4px #faf7f2",
                  }}
                >
                  {isGeneratingShare ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Link className="w-3 h-3" />
                  )}
                  {isGeneratingShare ? "Génération…" : "Créer un lien de partage"}
                </button>
              )}
            </div>
          </aside>
        )}

        {/* Bouton toggle panneau droit */}
        <button
          onClick={() => setShowRightPanel(p => !p)}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-50 w-5 h-12 flex items-center justify-center rounded-l-lg transition-all"
          style={{
            background: "#d4c5a9",
            color: "#6b7a6c",
            boxShadow: "-2px 0 6px #c8c3ba",
          }}
          title={showRightPanel ? "Masquer le panneau" : "Afficher Smart Pathing™ + Confetti + Partage"}
        >
          {showRightPanel ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>
      </div>

      {/* ── Dialog Générateur IA ─────────────────────────────────────────────── */}
      <Dialog open={showAIDialog} onOpenChange={(open) => {
        if (!open) { setShowAIDialog(false); setAIStep("prompt"); setAIGeneratedImageUrl(null); }
      }}>
        <DialogContent style={{ background: "#F5F0E8", borderColor: "#d4c5a9", maxWidth: "520px" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "#3D4A3E", fontFamily: "'Cormorant Garamond', serif" }}>
              <span className="flex items-center gap-2">
                <Wand2 className="w-5 h-5" style={{ color: "#C4714A" }} />
                Créer un patron avec l'IA
              </span>
            </DialogTitle>
          </DialogHeader>

          {/* Étape 1 : Formulaire */}
          {aiStep === "prompt" && (
            <div className="space-y-4 py-2">
              <div>
                <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>
                  Décrivez votre motif
                </Label>
                <Input
                  value={aiPrompt}
                  onChange={e => setAIPrompt(e.target.value)}
                  placeholder="Ex: un chat roux sur fond de feuilles d'automne"
                  className="mt-1.5"
                  style={{ background: "#e8e3da", borderColor: "#d4c5a9", color: "#3D4A3E" }}
                  onKeyDown={e => {
                    if (e.key === "Enter" && aiPrompt.trim()) {
                      setAIStep("generating");
                      generateAI.mutate({ prompt: aiPrompt, style: aiStyle });
                    }
                  }}
                />
              </div>

              {/* Suggestions */}
              <div>
                <p className="text-xs font-medium mb-2" style={{ color: "#6b7a6c" }}>Suggestions :</p>
                <div className="flex flex-wrap gap-1.5">
                  {["Un chat roux endormi", "Une rose rouge", "Un papillon coloré", "Un bouquet de lavande", "Un renard dans la forêt", "Une tasse de thé fumante"].map(s => (
                    <button
                      key={s}
                      onClick={() => setAIPrompt(s)}
                      className="text-[11px] px-2.5 py-1 rounded-full transition-colors"
                      style={{ background: "#e8e3da", border: "1px solid #d4c5a9", color: "#6b7a6c" }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Style */}
              <div>
                <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Style</Label>
                <div className="grid grid-cols-3 gap-2 mt-1.5">
                  {([
                    { value: "pixel-art", label: "Pixel Art", emoji: "🎮" },
                    { value: "flat-illustration", label: "Illustration", emoji: "🎨" },
                    { value: "realistic", label: "Réaliste", emoji: "📷" },
                    { value: "watercolor", label: "Aquarelle", emoji: "💧" },
                    { value: "minimalist", label: "Minimaliste", emoji: "◻️" },
                  ] as const).map(s => (
                    <button
                      key={s.value}
                      onClick={() => setAIStyle(s.value)}
                      className="p-2 rounded-xl text-left transition-all"
                      style={{
                        background: aiStyle === s.value ? "#C4714A" : "#e8e3da",
                        color: aiStyle === s.value ? "white" : "#6b7a6c",
                        border: aiStyle === s.value ? "none" : "1px solid #d4c5a9",
                      }}
                    >
                      <span className="text-base">{s.emoji}</span>
                      <p className="text-[11px] font-semibold mt-0.5">{s.label}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Paramètres grille */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Taille de la grille</Label>
                  <div className="flex gap-1.5 mt-1.5">
                    {(["20", "40", "80"] as const).map(s => (
                      <button key={s} onClick={() => setAIGridSize(s)} className="flex-1 py-1.5 rounded-lg text-xs font-medium transition-all"
                        style={{ background: aiGridSize === s ? "#C4714A" : "#e8e3da", color: aiGridSize === s ? "white" : "#6b7a6c", border: aiGridSize === s ? "none" : "1px solid #d4c5a9" }}>
                        {s}×{s}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Couleurs max</Label>
                  <div className="flex gap-1.5 mt-1.5">
                    {(["6", "12", "24"] as const).map(n => (
                      <button key={n} onClick={() => setAIMaxColors(n)} className="flex-1 py-1.5 rounded-lg text-xs font-medium transition-all"
                        style={{ background: aiMaxColors === n ? "#7A9E7E" : "#e8e3da", color: aiMaxColors === n ? "white" : "#6b7a6c", border: aiMaxColors === n ? "none" : "1px solid #d4c5a9" }}>
                        {n}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="ghost" onClick={() => setShowAIDialog(false)} style={{ color: "#6b7a6c" }}>
                  Annuler
                </Button>
                <Button
                  onClick={() => {
                    if (!aiPrompt.trim()) { toast.error("Décrivez votre motif"); return; }
                    setAIStep("generating");
                    generateAI.mutate({ prompt: aiPrompt, style: aiStyle });
                  }}
                  disabled={!aiPrompt.trim()}
                  style={{ background: "linear-gradient(135deg, #7A9E7E, #C4714A)", color: "white", border: "none" }}
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Générer le motif
                </Button>
              </DialogFooter>
            </div>
          )}

          {/* Étape 2 : Génération en cours */}
          {aiStep === "generating" && (
            <div className="py-12 text-center space-y-4">
              <div className="w-16 h-16 mx-auto rounded-2xl flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, #7A9E7E22, #C4714A22)" }}>
                <Loader2 className="w-8 h-8 animate-spin" style={{ color: "#C4714A" }} />
              </div>
              <div>
                <p className="text-sm font-semibold" style={{ color: "#3D4A3E" }}>Génération en cours…</p>
                <p className="text-xs mt-1" style={{ color: "#6b7a6c" }}>
                  L'IA crée votre motif « {aiPrompt.slice(0, 35)}{aiPrompt.length > 35 ? "…" : ""} »
                </p>
              </div>
              <div className="flex justify-center gap-1">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-2 h-2 rounded-full animate-bounce"
                    style={{ background: "#C4714A", animationDelay: `${i * 150}ms` }} />
                ))}
              </div>
            </div>
          )}

          {/* Étape 3 : Aperçu de l'image générée */}
          {aiStep === "preview" && aiGeneratedImageUrl && (
            <div className="space-y-4 py-2">
              <div className="rounded-xl overflow-hidden" style={{ border: "1px solid #d4c5a9" }}>
                <img
                  src={aiGeneratedImageUrl}
                  alt="Motif généré"
                  className="w-full h-56 object-contain"
                  style={{ background: "white" }}
                />
              </div>
              {/* Contrôles de conversion */}
              <div className="rounded-xl p-4 space-y-4" style={{ background: "#e8e3da", border: "1px solid #d4c5a9" }}>
                {/* Résumé grille */}
                <div className="flex items-center justify-between text-xs">
                  <span style={{ color: "#6b7a6c" }}>Grille</span>
                  <span className="font-semibold" style={{ color: "#3D4A3E" }}>
                    {aiGridSize}×{aiGridSize} = {(parseInt(aiGridSize) * parseInt(aiGridSize)).toLocaleString("fr-FR")} points
                  </span>
                </div>

                {/* Contrôle nombre de couleurs DMC */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>
                      Couleurs DMC maximum
                    </Label>
                    <span
                      className="text-sm font-bold px-2.5 py-0.5 rounded-full"
                      style={{ background: "#C4714A", color: "white", minWidth: "2.5rem", textAlign: "center" }}
                    >
                      {aiMaxColors}
                    </span>
                  </div>

                  {/* Slider continu */}
                  <Slider
                    min={2}
                    max={48}
                    step={1}
                    value={[parseInt(aiMaxColors)]}
                    onValueChange={([v]) => setAIMaxColors(String(v) as typeof aiMaxColors)}
                    className="w-full"
                  />
                  <div className="flex justify-between text-[10px]" style={{ color: "#9aab9b" }}>
                    <span>2</span>
                    <span>12</span>
                    <span>24</span>
                    <span>36</span>
                    <span>48</span>
                  </div>

                  {/* Boutons rapides */}
                  <div className="flex gap-1.5 mt-1">
                    {(["6", "12", "18", "24", "36"] as const).map(n => (
                      <button
                        key={n}
                        onClick={() => setAIMaxColors(n)}
                        className="flex-1 py-1 rounded-lg text-xs font-semibold transition-all"
                        style={{
                          background: aiMaxColors === n ? "#C4714A" : "#d4c5a9",
                          color: aiMaxColors === n ? "white" : "#6b7a6c",
                          border: "none",
                        }}
                      >
                        {n}
                      </button>
                    ))}
                  </div>

                  {/* Aide contextuelle */}
                  <p className="text-[10px] leading-relaxed" style={{ color: "#9aab9b" }}>
                    {parseInt(aiMaxColors) <= 6
                      ? "Très peu de couleurs — motif très simplifié, idéal pour débutants."
                      : parseInt(aiMaxColors) <= 12
                      ? "Palette réduite — bon équilibre entre simplicité et détail."
                      : parseInt(aiMaxColors) <= 24
                      ? "Palette standard — rendu fidèle à l'image générée."
                      : "Palette riche — rendu très détaillé, plus de fils nécessaires."}
                  </p>
                </div>
              </div>
              <DialogFooter className="flex-col sm:flex-row gap-2">
                <div className="flex gap-2 w-full sm:w-auto">
                  <Button variant="ghost" size="sm"
                    onClick={() => { setAIStep("prompt"); setAIGeneratedImageUrl(null); }}
                    style={{ color: "#6b7a6c", flex: 1 }}>
                    Nouveau motif
                  </Button>
                  <Button variant="ghost" size="sm"
                    onClick={() => { setShowAIDialog(false); }}
                    style={{ color: "#6b7a6c", flex: 1 }}>
                    Fermer
                  </Button>
                </div>
                <Button
                  onClick={convertAIImageToGrid}
                  style={{ background: "linear-gradient(135deg, #7A9E7E, #C4714A)", color: "white", border: "none" }}
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Appliquer ({aiMaxColors} couleurs)
                </Button>
              </DialogFooter>
            </div>
          )}

          {/* Étape 4 : Conversion en cours */}
          {aiStep === "converting" && (
            <div className="py-12 text-center space-y-4">
              <div className="w-16 h-16 mx-auto rounded-2xl flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, #7A9E7E22, #3D4A3E22)" }}>
                <Loader2 className="w-8 h-8 animate-spin" style={{ color: "#7A9E7E" }} />
              </div>
              <div>
                <p className="text-sm font-semibold" style={{ color: "#3D4A3E" }}>Conversion en grille…</p>
                <p className="text-xs mt-1" style={{ color: "#6b7a6c" }}>
                  Quantification des couleurs DMC en cours
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
            {/* ── Dialog Sauvegarder ───────────────────────────────────────────────── */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent style={{ background: "#F5F0E8", borderColor: "#d4c5a9" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "#3D4A3E" }}>Sauvegarder le patron</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Nom du patron</Label>
            <Input
              value={saveName}
              onChange={e => setSaveName(e.target.value)}
              placeholder="Ex: Rose Sauvage"
              className="mt-1.5"
              style={{ background: "#e8e3da", borderColor: "#d4c5a9", color: "#3D4A3E" }}
              onKeyDown={e => { if (e.key === "Enter") handleSaveConfirm(); }}
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowSaveDialog(false)} style={{ color: "#6b7a6c" }}>Annuler</Button>
            <Button
              onClick={handleSaveConfirm}
              disabled={saveMutation.isPending}
              style={{ background: "#3D4A3E", color: "white", border: "none" }}
            >
              {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Sauvegarder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog Import avec paramètres ────────────────────────────────────────────────────────────────── */}
      <Dialog open={showImportDialog} onOpenChange={open => { setShowImportDialog(open); if (!open) { setPendingImportFile(null); resetPdf(); setIsPdfMode(false); setImagePreviewUrl(prev => { if (prev) URL.revokeObjectURL(prev); return null; }); } }}>
        <DialogContent className="max-w-lg" style={{ background: "#F5F0E8", borderColor: "#d4c5a9" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "#3D4A3E", fontFamily: "'Cormorant Garamond', serif" }}>
              {isPdfMode
                ? `Importer un patron PDF (${pdfPageCount} pages)`
                : pendingImportFile?.type.startsWith("image/") || pendingImportFile?.name.match(/\.(png|jpe?g|webp)$/i)
                  ? "Importer une image"
                  : "Paramètres d'import"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {pendingImportFile && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: "#e8e3da", border: "1px solid #d4c5a9" }}>
                <Upload className="w-4 h-4 flex-shrink-0" style={{ color: "#7A9E7E" }} />
                <span className="text-sm truncate" style={{ color: "#3D4A3E" }}>{pendingImportFile.name}</span>
                <span className="text-xs ml-auto flex-shrink-0" style={{ color: "#9aaa9b" }}>
                  {(pendingImportFile.size / 1024 / 1024).toFixed(1)} Mo
                </span>
              </div>
            )}

            {/* Aperçu de l'image importée (mode non-PDF) */}
            {!isPdfMode && imagePreviewUrl && (
              <div className="flex flex-col items-center gap-2">
                <div className="relative rounded-xl overflow-hidden" style={{ border: "2px solid #d4c5a9", background: "#e8e3da" }}>
                  <img
                    src={imagePreviewUrl}
                    alt="Aperçu"
                    className="block"
                    style={{ maxWidth: "100%", maxHeight: 200, objectFit: "contain", display: "block" }}
                  />
                </div>
                <p className="text-xs" style={{ color: "#9aaa9b" }}>
                  L'image sera redimensionnée et convertie en couleurs DMC.
                </p>
              </div>
            )}

            {/* Sélecteur de page PDF */}
            {isPdfMode && (
              <div>
                <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>
                  Page à importer
                  {pdfPageCount > 0 && <span className="ml-1" style={{ color: "#9aaa9b" }}>({pdfPageCount} pages disponibles)</span>}
                </Label>
                {isLoadingPdfPreviews ? (
                  <div className="flex items-center gap-2 mt-2 py-4 justify-center">
                    <Loader2 className="w-5 h-5 animate-spin" style={{ color: "#7A9E7E" }} />
                    <span className="text-sm" style={{ color: "#6b7a6c" }}>Chargement des pages… {importProgress}%</span>
                  </div>
                ) : pdfPreviews.length > 0 ? (
                  <div className="mt-2 overflow-x-auto">
                    <div className="flex gap-2 pb-2" style={{ minWidth: "max-content" }}>
                      {pdfPreviews.map(preview => {
                        const isSelected = selectedPdfPage === preview.pageNum;
                        const isBest = preview.isGridCandidate && preview.gridScore === Math.max(...pdfPreviews.map(p => p.gridScore));
                        return (
                          <button
                            key={preview.pageNum}
                            onClick={() => setSelectedPdfPage(preview.pageNum)}
                            className="flex-shrink-0 flex flex-col items-center gap-1 p-1.5 rounded-lg transition-all relative"
                            title={`Page ${preview.pageNum} — Score grille : ${Math.round(preview.gridScore * 100)}%`}
                            style={{
                              background: isSelected ? "#C4714A" : preview.isGridCandidate ? "#e8f0e9" : "#e8e3da",
                              border: isSelected ? "2px solid #C4714A" : preview.isGridCandidate ? "2px solid #7A9E7E" : "2px solid transparent",
                            }}
                          >
                            {/* Badge "Grille" sur les pages candidates */}
                            {preview.isGridCandidate && (
                              <span
                                className="absolute -top-1.5 -right-1.5 text-[9px] font-bold px-1 py-0.5 rounded-full leading-none"
                                style={{
                                  background: isBest ? "#7A9E7E" : "#a8c4aa",
                                  color: "white",
                                }}
                              >
                                {isBest ? "★" : "✓"}
                              </span>
                            )}
                            <img
                              src={preview.dataUrl}
                              alt={`Page ${preview.pageNum}`}
                              className="rounded"
                              style={{ width: 72, height: 96, objectFit: "contain", background: "white" }}
                            />
                            <span className="text-xs font-medium" style={{ color: isSelected ? "white" : preview.isGridCandidate ? "#3D4A3E" : "#6b7a6c" }}>
                              P.{preview.pageNum}
                            </span>
                            {/* Barre de score */}
                            <div className="w-full rounded-full overflow-hidden" style={{ height: 3, background: isSelected ? "rgba(255,255,255,0.3)" : "#d4c5a9" }}>
                              <div
                                style={{
                                  width: `${Math.round(preview.gridScore * 100)}%`,
                                  height: "100%",
                                  background: isSelected ? "white" : preview.isGridCandidate ? "#7A9E7E" : "#C4714A",
                                  transition: "width 0.3s",
                                }}
                              />
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : null}
                <p className="text-xs mt-1.5" style={{ color: "#9aaa9b" }}>
                  ★ = grille détectée automatiquement — vous pouvez choisir une autre page si besoin.
                </p>
              </div>
            )}

            <div>
              <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Taille de la grille</Label>
              <div className="flex gap-2 mt-1.5">
                {[{ label: "20×20", v: 20 }, { label: "40×40", v: 40 }, { label: "60×60", v: 60 }, { label: "80×80", v: 80 }].map(opt => (
                  <button
                    key={opt.label}
                    onClick={() => setImportGridSize({ rows: opt.v, cols: opt.v })}
                    className="flex-1 py-2 rounded-xl text-sm font-medium transition-all"
                    style={{
                      background: importGridSize.rows === opt.v ? "#C4714A" : "#e8e3da",
                      color: importGridSize.rows === opt.v ? "white" : "#6b7a6c",
                      border: importGridSize.rows === opt.v ? "none" : "1px solid #d4c5a9",
                    }}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-xs font-medium" style={{ color: "#6b7a6c" }}>Nombre de couleurs DMC max</Label>
                <span className="text-sm font-bold px-2 py-0.5 rounded-full" style={{ background: "#C4714A", color: "white", minWidth: 36, textAlign: "center" }}>
                  {importMaxColors}
                </span>
              </div>
              {/* Boutons rapides */}
              <div className="flex gap-1.5 mb-2">
                {[6, 12, 18, 24, 36].map(v => (
                  <button
                    key={v}
                    onClick={() => setImportMaxColors(v)}
                    className="flex-1 py-1.5 rounded-lg text-xs font-medium transition-all"
                    style={{
                      background: importMaxColors === v ? "#7A9E7E" : "#e8e3da",
                      color: importMaxColors === v ? "white" : "#6b7a6c",
                      border: importMaxColors === v ? "none" : "1px solid #d4c5a9",
                    }}
                  >
                    {v}
                  </button>
                ))}
              </div>
              {/* Slider */}
              <input
                type="range"
                min={2}
                max={48}
                step={1}
                value={importMaxColors}
                onChange={e => setImportMaxColors(Number(e.target.value))}
                className="w-full accent-[#C4714A]"
                style={{ cursor: "pointer" }}
              />
              <div className="flex justify-between text-xs mt-0.5" style={{ color: "#9aaa9b" }}>
                <span>2 (simple)</span>
                <span>48 (riche)</span>
              </div>
              <p className="text-xs mt-1" style={{ color: "#9aaa9b" }}>
                {importMaxColors <= 8
                  ? "Palette réduite — idéal pour les débutants."
                  : importMaxColors <= 18
                  ? "Palette standard — bon équilibre simplicité/fidélité."
                  : importMaxColors <= 30
                  ? "Palette riche — rendu détaillé et nuancé."
                  : "Palette complète — maximum de détails DMC."}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setShowImportDialog(false); setPendingImportFile(null); resetPdf(); setIsPdfMode(false); setImagePreviewUrl(prev => { if (prev) URL.revokeObjectURL(prev); return null; }); }} style={{ color: "#6b7a6c" }}>
              Annuler
            </Button>
            <Button
              onClick={handleImportConfirm}
              disabled={importStatus === "loading" || isLoadingPdfPreviews}
              style={{ background: "linear-gradient(135deg, #7A9E7E, #C4714A)", color: "white", border: "none" }}
            >
              {importStatus === "loading" ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Conversion en cours…</>
              ) : isLoadingPdfPreviews ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Chargement PDF…</>
              ) : isPdfMode ? (
                <><Upload className="w-4 h-4 mr-2" />Importer page {selectedPdfPage} en {importGridSize.rows}×{importGridSize.cols}</>
              ) : (
                <><Upload className="w-4 h-4 mr-2" />Importer en {importGridSize.rows}×{importGridSize.cols}</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confetti Cleaner™ : overlay inline sur la grille (pas de dialog) */}

      {/* ── Dialog Charger ────────────────────────────────────────────────────────────────── */}
      <Dialog open={showLoadDialog} onOpenChange={setShowLoadDialog}><DialogContent style={{ background: "#F5F0E8", borderColor: "#d4c5a9" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "#3D4A3E" }}>Mes patrons sauvegardés</DialogTitle>
          </DialogHeader>
          <div className="py-2 max-h-80 overflow-y-auto space-y-2">
            {savedGrids.isLoading && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin" style={{ color: "#7A9E7E" }} />
              </div>
            )}
            {savedGrids.data?.length === 0 && (
              <p className="text-sm text-center py-8" style={{ color: "#9aaa9b" }}>
                Aucun patron sauvegardé
              </p>
            )}
            {savedGrids.data?.map(g => (
              <button
                key={g.id}
                onClick={() => handleLoadGrid(g as { id: number; name: string; width: number; height: number; gridData: string | null })}
                className="w-full text-left px-3 py-2.5 rounded-xl transition-all"
                style={{ background: "#e8e3da", border: "1px solid #d4c5a9", color: "#3D4A3E" }}
              >
                <div className="font-medium text-sm">{g.name}</div>
                <div className="text-xs mt-0.5" style={{ color: "#6b7a6c" }}>
                  {g.width}×{g.height} points
                </div>
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowLoadDialog(false)} style={{ color: "#6b7a6c" }}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
