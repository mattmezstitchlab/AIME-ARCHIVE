import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Plus, Trash2, Edit3, CheckCircle2, Clock, PauseCircle,
  Circle, MoreVertical, Scissors, X, Save, ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const STATUS_CONFIG = {
  not_started: { label: "Non démarré", icon: Circle, color: "#C4714A" },
  in_progress: { label: "En cours", icon: Clock, color: "#7A9E7E" },
  paused: { label: "En pause", icon: PauseCircle, color: "#D4C5A9" },
  completed: { label: "Terminé", icon: CheckCircle2, color: "#3D4A3E" },
};

type ProjectStatus = keyof typeof STATUS_CONFIG;

interface ProjectForm {
  name: string;
  patternName: string;
  designer: string;
  fabricType: string;
  fabricCount: string;
  gridWidth: string;
  gridHeight: string;
  totalStitches: string;
  estimatedHours: string;
  notes: string;
  status: ProjectStatus;
}

const EMPTY_FORM: ProjectForm = {
  name: "", patternName: "", designer: "", fabricType: "Aida",
  fabricCount: "14", gridWidth: "", gridHeight: "", totalStitches: "",
  estimatedHours: "", notes: "", status: "not_started",
};

export default function Projects() {
  const utils = trpc.useUtils();
  const { data: projects, isLoading } = trpc.projects.list.useQuery();
  const createMutation = trpc.projects.create.useMutation({
    onSuccess: () => { utils.projects.list.invalidate(); toast.success("Projet créé !"); setShowForm(false); setForm(EMPTY_FORM); },
    onError: (e) => toast.error(e.message),
  });
  const updateMutation = trpc.projects.update.useMutation({
    onSuccess: () => { utils.projects.list.invalidate(); toast.success("Projet mis à jour !"); setEditId(null); setForm(EMPTY_FORM); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.projects.delete.useMutation({
    onSuccess: () => { utils.projects.list.invalidate(); toast.success("Projet supprimé"); },
    onError: (e) => toast.error(e.message),
  });

  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<ProjectForm>(EMPTY_FORM);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const handleSubmit = () => {
    if (!form.name.trim()) { toast.error("Le nom du projet est requis"); return; }
    const payload = {
      name: form.name.trim(),
      patternName: form.patternName || undefined,
      designer: form.designer || undefined,
      fabricType: form.fabricType || undefined,
      fabricCount: form.fabricCount ? parseInt(form.fabricCount) : undefined,
      gridWidth: form.gridWidth ? parseInt(form.gridWidth) : 0,
      gridHeight: form.gridHeight ? parseInt(form.gridHeight) : 0,
      totalStitches: form.totalStitches ? parseInt(form.totalStitches) : 0,
      estimatedHours: form.estimatedHours ? parseFloat(form.estimatedHours) : undefined,
      notes: form.notes || undefined,
      status: form.status,
    };
    if (editId !== null) {
      updateMutation.mutate({ id: editId, ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const startEdit = (p: typeof projects extends (infer T)[] | undefined ? T : never) => {
    if (!p) return;
    setEditId((p as { id: number }).id);
    setForm({
      name: (p as { name: string }).name ?? "",
      patternName: (p as { patternName: string | null }).patternName ?? "",
      designer: (p as { designer: string | null }).designer ?? "",
      fabricType: (p as { fabricType: string | null }).fabricType ?? "Aida",
      fabricCount: String((p as { fabricCount: number | null }).fabricCount ?? "14"),
      gridWidth: String((p as { gridWidth: number | null }).gridWidth ?? ""),
      gridHeight: String((p as { gridHeight: number | null }).gridHeight ?? ""),
      totalStitches: String((p as { totalStitches: number | null }).totalStitches ?? ""),
      estimatedHours: String((p as { estimatedHours: number | null }).estimatedHours ?? ""),
      notes: (p as { notes: string | null }).notes ?? "",
      status: ((p as { status: string }).status as ProjectStatus) ?? "not_started",
    });
    setShowForm(true);
  };

  const filtered = projects?.filter(p => filterStatus === "all" || p.status === filterStatus) ?? [];

  return (
    <AppLayout title="Projets">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h1 className="text-3xl font-bold" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
            Mes Projets
          </h1>
          <div className="flex items-center gap-3">
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="px-3 py-2 rounded-xl text-sm border-0 outline-none cursor-pointer"
              style={{
                background: "var(--ivory)",
                color: "var(--slate)",
                boxShadow: "inset 2px 2px 5px rgba(0,0,0,0.06), inset -2px -2px 5px rgba(255,255,255,0.8)",
              }}
            >
              <option value="all">Tous les statuts</option>
              {Object.entries(STATUS_CONFIG).map(([k, v]) => (
                <option key={k} value={k}>{v.label}</option>
              ))}
            </select>
            <button
              onClick={() => { setForm(EMPTY_FORM); setEditId(null); setShowForm(true); }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
              style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white", boxShadow: "0 4px 12px rgba(196,113,74,0.3)" }}
            >
              <Plus className="w-4 h-4" /> Nouveau projet
            </button>
          </div>
        </div>

        {/* Projects grid */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: "var(--terracotta)", borderTopColor: "transparent" }} />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 rounded-2xl" style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}>
            <Scissors className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--text-muted)" }} />
            <p className="text-lg font-semibold mb-2" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif" }}>
              {filterStatus === "all" ? "Aucun projet encore" : "Aucun projet dans ce statut"}
            </p>
            <p className="text-sm mb-6" style={{ color: "var(--text-muted)" }}>
              {filterStatus === "all" ? "Créez votre premier projet de broderie" : "Changez le filtre ou créez un nouveau projet"}
            </p>
            <button
              onClick={() => { setForm(EMPTY_FORM); setEditId(null); setShowForm(true); }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold"
              style={{ background: "var(--terracotta)", color: "white" }}
            >
              <Plus className="w-4 h-4" /> Créer un projet
            </button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(project => {
              const progress = project.totalStitches && project.totalStitches > 0
                ? Math.round((project.completedStitches ?? 0) / project.totalStitches * 100) : 0;
              const cfg = STATUS_CONFIG[project.status as ProjectStatus] ?? STATUS_CONFIG.not_started;
              const StatusIcon = cfg.icon;
              return (
                <div
                  key={project.id}
                  className="rounded-2xl p-5 flex flex-col gap-3"
                  style={{ background: "var(--ivory)", boxShadow: "6px 6px 16px rgba(0,0,0,0.07), -4px -4px 12px rgba(255,255,255,0.9)" }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold truncate" style={{ color: "var(--slate)", fontFamily: "Cormorant Garamond, serif", fontSize: "1.1rem" }}>
                        {project.name}
                      </h3>
                      {project.designer && (
                        <p className="text-xs mt-0.5 truncate" style={{ color: "var(--text-muted)" }}>par {project.designer}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1 ml-2">
                      <button
                        onClick={() => startEdit(project)}
                        className="p-1.5 rounded-lg hover:opacity-70 transition-opacity"
                        style={{ color: "var(--text-muted)" }}
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Supprimer "${project.name}" ?`)) deleteMutation.mutate({ id: project.id });
                        }}
                        className="p-1.5 rounded-lg hover:opacity-70 transition-opacity"
                        style={{ color: "#e57373" }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <StatusIcon className="w-4 h-4 flex-shrink-0" style={{ color: cfg.color }} />
                    <span className="text-xs font-medium" style={{ color: cfg.color }}>{cfg.label}</span>
                    {project.fabricType && (
                      <span className="text-xs ml-auto" style={{ color: "var(--text-muted)" }}>
                        {project.fabricType} {project.fabricCount ? `${project.fabricCount}ct` : ""}
                      </span>
                    )}
                  </div>

                  {project.totalStitches && project.totalStitches > 0 ? (
                    <div>
                      <div className="flex justify-between text-xs mb-1" style={{ color: "var(--text-muted)" }}>
                        <span>{(project.completedStitches ?? 0).toLocaleString("fr-FR")} / {project.totalStitches.toLocaleString("fr-FR")} pts</span>
                        <span className="font-semibold" style={{ color: "var(--terracotta)" }}>{progress}%</span>
                      </div>
                      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(212,197,169,0.3)" }}>
                        <div className="h-full rounded-full" style={{ width: `${progress}%`, background: "linear-gradient(90deg, var(--terracotta), var(--sage))" }} />
                      </div>
                    </div>
                  ) : null}

                  {project.gridWidth && project.gridHeight ? (
                    <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                      Grille : {project.gridWidth} × {project.gridHeight} pts
                    </p>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal formulaire */}
      <Dialog open={showForm} onOpenChange={open => { if (!open) { setShowForm(false); setEditId(null); setForm(EMPTY_FORM); } }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" style={{ background: "var(--ivory)" }}>
          <DialogHeader>
            <DialogTitle style={{ fontFamily: "Cormorant Garamond, serif", color: "var(--slate)" }}>
              {editId !== null ? "Modifier le projet" : "Nouveau projet"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Nom du projet *</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Ex: Jardin fleuri" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Nom du patron</Label>
                <Input value={form.patternName} onChange={e => setForm(f => ({ ...f, patternName: e.target.value }))}
                  placeholder="Ex: Rose Sauvage" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Designer</Label>
                <Input value={form.designer} onChange={e => setForm(f => ({ ...f, designer: e.target.value }))}
                  placeholder="Ex: Thea Gouverneur" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Tissu</Label>
                <Input value={form.fabricType} onChange={e => setForm(f => ({ ...f, fabricType: e.target.value }))}
                  placeholder="Aida, Lin…" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Compte</Label>
                <Input value={form.fabricCount} onChange={e => setForm(f => ({ ...f, fabricCount: e.target.value }))}
                  placeholder="14" type="number" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Largeur (pts)</Label>
                <Input value={form.gridWidth} onChange={e => setForm(f => ({ ...f, gridWidth: e.target.value }))}
                  placeholder="0" type="number" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Hauteur (pts)</Label>
                <Input value={form.gridHeight} onChange={e => setForm(f => ({ ...f, gridHeight: e.target.value }))}
                  placeholder="0" type="number" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Total pts</Label>
                <Input value={form.totalStitches} onChange={e => setForm(f => ({ ...f, totalStitches: e.target.value }))}
                  placeholder="0" type="number" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Heures estimées</Label>
                <Input value={form.estimatedHours} onChange={e => setForm(f => ({ ...f, estimatedHours: e.target.value }))}
                  placeholder="Ex: 40" type="number" className="mt-1" style={{ background: "rgba(212,197,169,0.15)" }} />
              </div>
              <div>
                <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Statut</Label>
                <select
                  value={form.status}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value as ProjectStatus }))}
                  className="w-full mt-1 px-3 py-2 rounded-lg text-sm border-0 outline-none"
                  style={{ background: "rgba(212,197,169,0.15)", color: "var(--slate)" }}
                >
                  {Object.entries(STATUS_CONFIG).map(([k, v]) => (
                    <option key={k} value={k}>{v.label}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium" style={{ color: "var(--slate)" }}>Notes</Label>
              <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Vos notes sur ce projet…" rows={3} className="mt-1 resize-none" style={{ background: "rgba(212,197,169,0.15)" }} />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => { setShowForm(false); setEditId(null); setForm(EMPTY_FORM); }}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                style={{ background: "rgba(212,197,169,0.3)", color: "var(--slate)" }}
              >
                Annuler
              </button>
              <button
                onClick={handleSubmit}
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, var(--terracotta), #a85a35)", color: "white" }}
              >
                <Save className="w-4 h-4" />
                {editId !== null ? "Enregistrer" : "Créer"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
