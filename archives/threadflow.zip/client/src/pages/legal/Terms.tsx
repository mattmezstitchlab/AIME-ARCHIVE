/**
 * Page Conditions Générales d'Utilisation — ThreadFlow
 * Mise à jour : mai 2026
 */
import { Link } from "wouter";
import { Scissors, ArrowLeft } from "lucide-react";
import SEOHead from "@/components/SEOHead";

const N = {
  bg: "#F5F0E8",
  text: "#3D4A3E",
  accent: "#7A9E7E",
  terra: "#C4714A",
  muted: "#6b7a6c",
  border: "#d4c5a9",
  card: "white",
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-10">
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>
        {title}
      </h2>
      <div style={{ color: N.muted, lineHeight: 1.8, fontSize: 15 }}>{children}</div>
    </section>
  );
}

export default function Terms() {
  return (
    <div style={{ background: N.bg, minHeight: "100vh" }}>
      <SEOHead
        title="Conditions Générales d'Utilisation"
        description="Lisez les conditions générales d'utilisation du service ThreadFlow avant d'utiliser notre application."
        url="/cgu"
        noIndex={false}
      />

      {/* Header */}
      <header style={{ background: N.bg, borderBottom: `1px solid ${N.border}`, padding: "16px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, color: N.muted, textDecoration: "none", fontSize: 14 }}>
          <ArrowLeft style={{ width: 16, height: 16 }} />
          Retour
        </Link>
        <span style={{ color: N.border }}>·</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Scissors style={{ width: 18, height: 18, color: N.accent }} />
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, color: N.text, fontWeight: 600 }}>ThreadFlow</span>
        </div>
      </header>

      {/* Contenu */}
      <main style={{ maxWidth: 760, margin: "0 auto", padding: "48px 24px 80px" }}>
        <div style={{ marginBottom: 40 }}>
          <p style={{ color: N.accent, fontSize: 12, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>
            Légal
          </p>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 40, fontWeight: 600, marginBottom: 12 }}>
            Conditions Générales d'Utilisation
          </h1>
          <p style={{ color: N.muted, fontSize: 14 }}>
            Dernière mise à jour : 11 mai 2026
          </p>
        </div>

        <div style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "40px 48px", boxShadow: "0 4px 20px rgba(61,74,62,0.08)" }}>

          <Section title="1. Objet">
            <p>Les présentes Conditions Générales d'Utilisation (CGU) régissent l'accès et l'utilisation du service ThreadFlow, accessible à l'adresse <strong>threadflow-u5ppwkeo.manus.space</strong>. En utilisant ThreadFlow, vous acceptez sans réserve les présentes CGU.</p>
          </Section>

          <Section title="2. Description du service">
            <p>ThreadFlow est une application web de gestion de broderie point de croix. Elle permet notamment de :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li>Créer et gérer des patrons de broderie interactifs</li>
              <li>Gérer un inventaire de fils DMC</li>
              <li>Suivre la progression de ses projets</li>
              <li>Partager des patrons avec d'autres brodeuses</li>
              <li>Participer à des Stitch-Alongs communautaires</li>
            </ul>
          </Section>

          <Section title="3. Accès au service">
            <p>L'accès à ThreadFlow nécessite la création d'un compte via l'authentification OAuth Manus. Vous devez avoir au moins 16 ans pour utiliser le service. L'inscription est gratuite pour le plan Free.</p>
          </Section>

          <Section title="4. Compte utilisateur">
            <p>Vous êtes responsable de la confidentialité de vos identifiants de connexion et de toutes les activités réalisées depuis votre compte. Vous vous engagez à :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li>Fournir des informations exactes lors de l'inscription</li>
              <li>Maintenir vos informations à jour</li>
              <li>Notifier ThreadFlow de toute utilisation non autorisée de votre compte</li>
              <li>Ne pas partager vos identifiants avec des tiers</li>
            </ul>
          </Section>

          <Section title="5. Contenu utilisateur">
            <p>Vous conservez la propriété intellectuelle de vos patrons et créations. En les partageant sur ThreadFlow, vous accordez à ThreadFlow une licence limitée, non exclusive et révocable pour afficher ce contenu dans le cadre du service.</p>
            <p style={{ marginTop: 8 }}>Vous vous engagez à ne pas publier de contenu illicite, offensant, ou portant atteinte aux droits de tiers.</p>
          </Section>

          <Section title="6. Plans et tarification">
            <p>ThreadFlow propose plusieurs plans :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li><strong>Free</strong> : gratuit, fonctionnalités limitées</li>
              <li><strong>Pro</strong> : 4,99 €/mois ou 44,91 €/an (−25%)</li>
              <li><strong>Studio</strong> : 14,99 €/mois ou 134,91 €/an (−25%)</li>
            </ul>
            <p style={{ marginTop: 8 }}>Les prix sont TTC. ThreadFlow se réserve le droit de modifier ses tarifs avec un préavis de 30 jours.</p>
          </Section>

          <Section title="7. Résiliation">
            <p>Vous pouvez résilier votre compte à tout moment depuis les paramètres de l'application. ThreadFlow peut suspendre ou résilier votre accès en cas de violation des présentes CGU, avec notification préalable sauf en cas de violation grave.</p>
          </Section>

          <Section title="8. Limitation de responsabilité">
            <p>ThreadFlow est fourni « en l'état ». Nous ne garantissons pas une disponibilité ininterrompue du service. Notre responsabilité est limitée au montant des sommes versées au cours des 12 derniers mois précédant l'événement dommageable.</p>
          </Section>

          <Section title="9. Propriété intellectuelle">
            <p>ThreadFlow, ses logos, interfaces, fonctionnalités (Smart Pathing™, Confetti Cleaner™, SAL Sync™, Stitch Diary™) sont la propriété exclusive de ThreadFlow. Toute reproduction sans autorisation est interdite.</p>
          </Section>

          <Section title="10. Droit applicable">
            <p>Les présentes CGU sont soumises au droit français. En cas de litige, les tribunaux français seront compétents. Avant tout recours judiciaire, nous vous invitons à nous contacter à <strong>legal@threadflow.app</strong> pour trouver une solution amiable.</p>
          </Section>

          <Section title="11. Contact">
            <p>Pour toute question relative aux présentes CGU : <strong>legal@threadflow.app</strong></p>
          </Section>
        </div>
      </main>

      {/* Footer minimal */}
      <footer style={{ borderTop: `1px solid ${N.border}`, padding: "24px", textAlign: "center" }}>
        <div style={{ display: "flex", gap: 24, justifyContent: "center", flexWrap: "wrap" }}>
          {[
            { label: "Accueil", href: "/" },
            { label: "Confidentialité", href: "/confidentialite" },
            { label: "Cookies", href: "/cookies" },
            { label: "FAQ", href: "/faq" },
          ].map(({ label, href }) => (
            <Link key={href} href={href} style={{ color: N.muted, fontSize: 13, textDecoration: "none" }}>
              {label}
            </Link>
          ))}
        </div>
        <p style={{ color: N.border, fontSize: 12, marginTop: 12 }}>© 2026 ThreadFlow. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
