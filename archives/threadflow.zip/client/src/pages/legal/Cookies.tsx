/**
 * Page Politique de Cookies — ThreadFlow
 * Mise à jour : mai 2026
 */
import { Link } from "wouter";
import { Scissors, ArrowLeft } from "lucide-react";
import SEOHead from "@/components/SEOHead";

const N = {
  bg: "#F5F0E8",
  text: "#3D4A3E",
  accent: "#7A9E7E",
  terra: "#C4714A",
  muted: "#6b7a6c",
  border: "#d4c5a9",
  card: "white",
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-10">
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>
        {title}
      </h2>
      <div style={{ color: N.muted, lineHeight: 1.8, fontSize: 15 }}>{children}</div>
    </section>
  );
}

const cookieTable = [
  { name: "threadflow_session", type: "Essentiel", durée: "Session", finalité: "Maintien de la session d'authentification. Requis pour accéder à votre espace personnel." },
  { name: "_umami", type: "Analytique (sans PII)", durée: "13 mois", finalité: "Mesure d'audience anonymisée via Umami Analytics. Aucune donnée personnelle identifiable collectée." },
];

export default function Cookies() {
  return (
    <div style={{ background: N.bg, minHeight: "100vh" }}>
      <SEOHead
        title="Politique de cookies"
        description="ThreadFlow utilise uniquement des cookies essentiels et une analytique anonymisée. Aucun cookie publicitaire ou de tracking tiers."
        url="/cookies"
        noIndex={false}
      />

      {/* Header */}
      <header style={{ background: N.bg, borderBottom: `1px solid ${N.border}`, padding: "16px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, color: N.muted, textDecoration: "none", fontSize: 14 }}>
          <ArrowLeft style={{ width: 16, height: 16 }} />
          Retour
        </Link>
        <span style={{ color: N.border }}>·</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Scissors style={{ width: 18, height: 18, color: N.accent }} />
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, color: N.text, fontWeight: 600 }}>ThreadFlow</span>
        </div>
      </header>

      {/* Contenu */}
      <main style={{ maxWidth: 760, margin: "0 auto", padding: "48px 24px 80px" }}>
        <div style={{ marginBottom: 40 }}>
          <p style={{ color: N.accent, fontSize: 12, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>
            Légal
          </p>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 40, fontWeight: 600, marginBottom: 12 }}>
            Politique de cookies
          </h1>
          <p style={{ color: N.muted, fontSize: 14 }}>
            Dernière mise à jour : 11 mai 2026
          </p>
        </div>

        <div style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "40px 48px", boxShadow: "0 4px 20px rgba(61,74,62,0.08)" }}>

          {/* Résumé visuel */}
          <div style={{ background: "#f0f7f0", border: `1px solid ${N.accent}30`, borderRadius: 12, padding: "20px 24px", marginBottom: 32 }}>
            <p style={{ color: N.accent, fontWeight: 600, fontSize: 15, marginBottom: 4 }}>🌿 Notre engagement cookies</p>
            <p style={{ color: N.muted, fontSize: 14, lineHeight: 1.7 }}>
              ThreadFlow utilise <strong>uniquement 2 cookies</strong> : un cookie de session essentiel et une mesure d'audience anonymisée. Aucun cookie publicitaire, aucun tracking tiers, aucune revente de données.
            </p>
          </div>

          <Section title="1. Qu'est-ce qu'un cookie ?">
            <p>Un cookie est un petit fichier texte déposé sur votre appareil lors de la visite d'un site web. Il permet au site de mémoriser vos préférences ou votre état de connexion lors de vos visites ultérieures.</p>
          </Section>

          <Section title="2. Les cookies utilisés par ThreadFlow">
            <p style={{ marginBottom: 16 }}>Voici la liste exhaustive des cookies déposés par ThreadFlow :</p>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                <thead>
                  <tr style={{ background: N.bg }}>
                    {["Nom", "Type", "Durée", "Finalité"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", textAlign: "left", color: N.text, fontWeight: 600, borderBottom: `2px solid ${N.border}` }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cookieTable.map((row, i) => (
                    <tr key={i} style={{ borderBottom: `1px solid ${N.border}` }}>
                      <td style={{ padding: "12px 14px", fontFamily: "monospace", fontSize: 12, color: N.terra }}>{row.name}</td>
                      <td style={{ padding: "12px 14px", color: N.muted }}>{row.type}</td>
                      <td style={{ padding: "12px 14px", color: N.muted, whiteSpace: "nowrap" }}>{row.durée}</td>
                      <td style={{ padding: "12px 14px", color: N.muted, lineHeight: 1.6 }}>{row.finalité}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>

          <Section title="3. Cookies tiers">
            <p>ThreadFlow n'intègre <strong>aucun cookie tiers</strong> à des fins publicitaires ou de tracking comportemental. Nous n'utilisons pas Google Analytics, Facebook Pixel, ou tout autre outil de surveillance publicitaire.</p>
          </Section>

          <Section title="4. Analytique Umami">
            <p>Nous utilisons <strong>Umami Analytics</strong>, une solution d'analyse d'audience respectueuse de la vie privée. Umami :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li>Ne collecte aucune donnée personnelle identifiable</li>
              <li>N'utilise pas de cookies de tracking cross-site</li>
              <li>Ne partage aucune donnée avec des tiers</li>
              <li>Est hébergé sur notre propre infrastructure</li>
            </ul>
          </Section>

          <Section title="5. Gestion des cookies">
            <p>Vous pouvez contrôler et supprimer les cookies via les paramètres de votre navigateur :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li><strong>Chrome</strong> : Paramètres → Confidentialité et sécurité → Cookies</li>
              <li><strong>Firefox</strong> : Paramètres → Vie privée et sécurité → Cookies</li>
              <li><strong>Safari</strong> : Préférences → Confidentialité → Cookies</li>
            </ul>
            <p style={{ marginTop: 12 }}>Notez que la suppression du cookie de session vous déconnectera de ThreadFlow.</p>
          </Section>

          <Section title="6. Contact">
            <p>Pour toute question : <strong>privacy@threadflow.app</strong></p>
          </Section>
        </div>
      </main>

      {/* Footer minimal */}
      <footer style={{ borderTop: `1px solid ${N.border}`, padding: "24px", textAlign: "center" }}>
        <div style={{ display: "flex", gap: 24, justifyContent: "center", flexWrap: "wrap" }}>
          {[
            { label: "Accueil", href: "/" },
            { label: "Confidentialité", href: "/confidentialite" },
            { label: "CGU", href: "/cgu" },
            { label: "FAQ", href: "/faq" },
          ].map(({ label, href }) => (
            <Link key={href} href={href} style={{ color: N.muted, fontSize: 13, textDecoration: "none" }}>
              {label}
            </Link>
          ))}
        </div>
        <p style={{ color: N.border, fontSize: 12, marginTop: 12 }}>© 2026 ThreadFlow. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
