/**
 * Page Politique de Confidentialité — ThreadFlow
 * Conforme RGPD — Mise à jour : mai 2026
 */
import { Link } from "wouter";
import { Scissors, ArrowLeft } from "lucide-react";
import SEOHead from "@/components/SEOHead";

const N = {
  bg: "#F5F0E8",
  text: "#3D4A3E",
  accent: "#7A9E7E",
  terra: "#C4714A",
  muted: "#6b7a6c",
  border: "#d4c5a9",
  card: "white",
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-10">
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>
        {title}
      </h2>
      <div style={{ color: N.muted, lineHeight: 1.8, fontSize: 15 }}>{children}</div>
    </section>
  );
}

export default function Privacy() {
  return (
    <div style={{ background: N.bg, minHeight: "100vh" }}>
      <SEOHead
        title="Politique de confidentialité"
        description="Découvrez comment ThreadFlow collecte, utilise et protège vos données personnelles conformément au RGPD."
        url="/confidentialite"
        noIndex={false}
      />

      {/* Header */}
      <header style={{ background: N.bg, borderBottom: `1px solid ${N.border}`, padding: "16px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, color: N.muted, textDecoration: "none", fontSize: 14 }}>
          <ArrowLeft style={{ width: 16, height: 16 }} />
          Retour
        </Link>
        <span style={{ color: N.border }}>·</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Scissors style={{ width: 18, height: 18, color: N.accent }} />
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, color: N.text, fontWeight: 600 }}>ThreadFlow</span>
        </div>
      </header>

      {/* Contenu */}
      <main style={{ maxWidth: 760, margin: "0 auto", padding: "48px 24px 80px" }}>
        <div style={{ marginBottom: 40 }}>
          <p style={{ color: N.accent, fontSize: 12, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>
            Légal
          </p>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 40, fontWeight: 600, marginBottom: 12 }}>
            Politique de confidentialité
          </h1>
          <p style={{ color: N.muted, fontSize: 14 }}>
            Dernière mise à jour : 11 mai 2026
          </p>
        </div>

        <div style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "40px 48px", boxShadow: "0 4px 20px rgba(61,74,62,0.08)" }}>

          <Section title="1. Responsable du traitement">
            <p>ThreadFlow (ci-après « nous », « notre », « nos ») est responsable du traitement de vos données personnelles. Pour toute question relative à la présente politique, vous pouvez nous contacter à l'adresse : <strong>privacy@threadflow.app</strong></p>
          </Section>

          <Section title="2. Données collectées">
            <p className="mb-3">Nous collectons les données suivantes :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc" }} className="space-y-2">
              <li><strong>Données de compte</strong> : adresse e-mail, prénom, identifiant OAuth (via Manus)</li>
              <li><strong>Données d'utilisation</strong> : patrons créés, inventaire DMC, sessions de broderie, projets</li>
              <li><strong>Données de navigation</strong> : pages visitées, durée de session (via Umami Analytics, sans cookies tiers)</li>
              <li><strong>Données de liste d'attente</strong> : adresse e-mail, prénom (si renseigné)</li>
              <li><strong>Données de partage</strong> : nom et emoji fournis volontairement lors de la consultation d'un patron partagé</li>
            </ul>
          </Section>

          <Section title="3. Finalités du traitement">
            <ul style={{ paddingLeft: 20, listStyle: "disc" }} className="space-y-2">
              <li>Fourniture et amélioration du service ThreadFlow</li>
              <li>Authentification et sécurité des comptes</li>
              <li>Communication sur les mises à jour du service (avec consentement)</li>
              <li>Analyse anonymisée de l'utilisation pour améliorer l'expérience</li>
              <li>Respect de nos obligations légales</li>
            </ul>
          </Section>

          <Section title="4. Base légale">
            <p>Le traitement de vos données repose sur :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li><strong>L'exécution du contrat</strong> : pour fournir le service ThreadFlow</li>
              <li><strong>Votre consentement</strong> : pour les communications marketing</li>
              <li><strong>Notre intérêt légitime</strong> : pour l'amélioration du service et la sécurité</li>
            </ul>
          </Section>

          <Section title="5. Conservation des données">
            <p>Vos données sont conservées :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li>Données de compte : pendant la durée de votre abonnement + 3 ans</li>
              <li>Données de liste d'attente : 2 ans après l'inscription</li>
              <li>Données de navigation anonymisées : 13 mois</li>
            </ul>
          </Section>

          <Section title="6. Partage des données">
            <p>Nous ne vendons jamais vos données personnelles. Nous pouvons les partager avec :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li><strong>Manus</strong> : pour l'authentification OAuth et l'hébergement</li>
              <li><strong>Prestataires techniques</strong> : hébergement, base de données, stockage (sous contrat de traitement)</li>
              <li><strong>Autorités légales</strong> : si requis par la loi</li>
            </ul>
          </Section>

          <Section title="7. Vos droits (RGPD)">
            <p>Conformément au Règlement Général sur la Protection des Données (RGPD), vous disposez des droits suivants :</p>
            <ul style={{ paddingLeft: 20, listStyle: "disc", marginTop: 8 }} className="space-y-2">
              <li><strong>Droit d'accès</strong> : obtenir une copie de vos données</li>
              <li><strong>Droit de rectification</strong> : corriger des données inexactes</li>
              <li><strong>Droit à l'effacement</strong> : demander la suppression de vos données</li>
              <li><strong>Droit à la portabilité</strong> : recevoir vos données dans un format structuré</li>
              <li><strong>Droit d'opposition</strong> : vous opposer à certains traitements</li>
              <li><strong>Droit à la limitation</strong> : limiter le traitement dans certains cas</li>
            </ul>
            <p style={{ marginTop: 12 }}>Pour exercer ces droits, contactez-nous à <strong>privacy@threadflow.app</strong>. Vous pouvez également déposer une réclamation auprès de la <strong>CNIL</strong> (Commission Nationale de l'Informatique et des Libertés).</p>
          </Section>

          <Section title="8. Cookies">
            <p>ThreadFlow utilise uniquement des cookies strictement nécessaires au fonctionnement du service (session d'authentification). Nous n'utilisons pas de cookies publicitaires ou de tracking tiers. Pour plus d'informations, consultez notre <Link href="/cookies" style={{ color: N.accent }}>politique de cookies</Link>.</p>
          </Section>

          <Section title="9. Sécurité">
            <p>Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour protéger vos données : chiffrement en transit (HTTPS/TLS), accès restreint aux données, surveillance des accès.</p>
          </Section>

          <Section title="10. Modifications">
            <p>Nous pouvons mettre à jour cette politique. En cas de modification substantielle, nous vous en informerons par e-mail ou via l'application. La date de dernière mise à jour est indiquée en haut de cette page.</p>
          </Section>

          <Section title="11. Contact">
            <p>Pour toute question : <strong>privacy@threadflow.app</strong></p>
            <p style={{ marginTop: 8 }}>ThreadFlow — Le Compagnon de Broderie Intelligent</p>
          </Section>
        </div>
      </main>

      {/* Footer minimal */}
      <footer style={{ borderTop: `1px solid ${N.border}`, padding: "24px", textAlign: "center" }}>
        <div style={{ display: "flex", gap: 24, justifyContent: "center", flexWrap: "wrap" }}>
          {[
            { label: "Accueil", href: "/" },
            { label: "CGU", href: "/cgu" },
            { label: "Cookies", href: "/cookies" },
            { label: "FAQ", href: "/faq" },
          ].map(({ label, href }) => (
            <Link key={href} href={href} style={{ color: N.muted, fontSize: 13, textDecoration: "none" }}>
              {label}
            </Link>
          ))}
        </div>
        <p style={{ color: N.border, fontSize: 12, marginTop: 12 }}>© 2026 ThreadFlow. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
