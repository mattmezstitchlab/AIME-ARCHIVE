/**
 * Page FAQ — ThreadFlow
 * 12 questions fréquentes des brodeuses
 */
import { useState } from "react";
import { Link } from "wouter";
import { Scissors, ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import SEOHead from "@/components/SEOHead";

const N = {
  bg: "#F5F0E8",
  text: "#3D4A3E",
  accent: "#7A9E7E",
  terra: "#C4714A",
  muted: "#6b7a6c",
  border: "#d4c5a9",
  card: "white",
  lin: "#D4C5A9",
};

const FAQ_ITEMS = [
  {
    category: "Démarrage",
    q: "ThreadFlow est-il vraiment gratuit ?",
    a: "Oui, le plan Free est gratuit sans limite de durée. Il vous donne accès à 5 patrons actifs, un inventaire manuel de fils, et la grille interactive. Pour les fonctionnalités avancées (scan IA, Smart Pathing™, patrons illimités), le plan Pro est disponible à 4,99 €/mois — soit le prix de 3 échevettes DMC.",
  },
  {
    category: "Démarrage",
    q: "Dois-je installer une application ?",
    a: "Non ! ThreadFlow fonctionne entièrement dans votre navigateur web (Chrome, Firefox, Safari, Edge). Aucune installation requise. Une application mobile native est prévue pour fin 2026.",
  },
  {
    category: "Démarrage",
    q: "Mes données sont-elles sauvegardées automatiquement ?",
    a: "Oui. Toutes vos modifications (patrons, inventaire, sessions) sont sauvegardées en temps réel dans le cloud. Vous pouvez reprendre votre travail depuis n'importe quel appareil, à tout moment.",
  },
  {
    category: "Fonctionnalités",
    q: "Comment fonctionne le scan IA des fils DMC ?",
    a: "Pointez votre smartphone vers votre boîte de fils DMC. L'IA identifie chaque couleur en 45 secondes et met à jour automatiquement votre inventaire. Elle reconnaît plus de 500 couleurs DMC et peut traiter jusqu'à 50 fils en une seule prise. Cette fonctionnalité est disponible sur le plan Pro.",
  },
  {
    category: "Fonctionnalités",
    q: "Qu'est-ce que le Smart Pathing™ ?",
    a: "Smart Pathing™ est notre algorithme d'optimisation du chemin de broderie. Il calcule l'ordre optimal pour broder vos points afin de minimiser les déplacements à l'arrière de la toile — ce qui réduit la consommation de fil et accélère votre travail. En moyenne, nos utilisatrices économisent 3,2m de fil par patron.",
  },
  {
    category: "Fonctionnalités",
    q: "Qu'est-ce que le Confetti Cleaner™ ?",
    a: "Les confettis sont ces points isolés éparpillés sur tout le patron — la bête noire des brodeuses ! Confetti Cleaner™ les détecte automatiquement et vous propose de les regrouper intelligemment pour optimiser votre ordre de broderie. Résultat : moins de fils coupés, moins de nœuds, plus de fluidité.",
  },
  {
    category: "Fonctionnalités",
    q: "Puis-je importer mes patrons existants ?",
    a: "Oui ! ThreadFlow accepte les formats PDF, image (JPG, PNG), XSD (PC Stitch) et OXS (Cross Stitch Pro). L'IA convertit automatiquement votre patron en grille interactive avec la palette DMC correspondante. L'import est disponible sur tous les plans.",
  },
  {
    category: "Partage & Communauté",
    q: "Comment partager un patron avec une amie ?",
    a: "Depuis l'éditeur, cliquez sur l'icône de partage. ThreadFlow génère un lien unique que vous pouvez envoyer par message, e-mail ou réseau social. Votre amie pourra consulter le patron sans créer de compte. Vous recevrez une notification lorsqu'elle l'ouvrira pour la première fois.",
  },
  {
    category: "Partage & Communauté",
    q: "Qu'est-ce qu'un SAL (Stitch-Along) ?",
    a: "Un SAL (Stitch-Along) est un projet broderie collectif où plusieurs brodeuses brodent le même patron en même temps. ThreadFlow propose des SALs officiels avec des patrons exclusifs, et vous permet de créer vos propres SALs privés avec vos amies via SAL Sync™.",
  },
  {
    category: "Abonnement",
    q: "Puis-je annuler mon abonnement à tout moment ?",
    a: "Oui, sans engagement et sans frais. Vous pouvez annuler depuis les paramètres de votre compte. Votre accès Pro reste actif jusqu'à la fin de la période payée. Après annulation, votre compte passe en Free et vos données sont conservées.",
  },
  {
    category: "Abonnement",
    q: "Proposez-vous une réduction annuelle ?",
    a: "Oui ! En choisissant la facturation annuelle, vous économisez 25% : Pro à 44,91 €/an (au lieu de 59,88 €) et Studio à 134,91 €/an (au lieu de 179,88 €). Le paiement annuel est prélevé en une seule fois.",
  },
  {
    category: "Technique",
    q: "ThreadFlow fonctionne-t-il hors connexion ?",
    a: "Pas encore. ThreadFlow nécessite une connexion internet pour synchroniser vos données. Un mode hors-ligne partiel (consultation des patrons téléchargés) est prévu dans une prochaine version. Nous vous tiendrons informées via notre newsletter.",
  },
];

const categories = Array.from(new Set(FAQ_ITEMS.map(f => f.category)));

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      style={{
        borderBottom: `1px solid ${N.border}`,
        cursor: "pointer",
      }}
      onClick={() => setOpen(!open)}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 0", gap: 16 }}>
        <p style={{ color: N.text, fontWeight: 500, fontSize: 16, lineHeight: 1.5, margin: 0 }}>{q}</p>
        {open
          ? <ChevronUp style={{ width: 18, height: 18, color: N.accent, flexShrink: 0 }} />
          : <ChevronDown style={{ width: 18, height: 18, color: N.muted, flexShrink: 0 }} />
        }
      </div>
      {open && (
        <div style={{ paddingBottom: 18 }}>
          <p style={{ color: N.muted, fontSize: 15, lineHeight: 1.8, margin: 0 }}>{a}</p>
        </div>
      )}
    </div>
  );
}

export default function FAQ() {
  return (
    <div style={{ background: N.bg, minHeight: "100vh" }}>
      <SEOHead
        title="FAQ — Questions fréquentes"
        description="Trouvez les réponses à toutes vos questions sur ThreadFlow : fonctionnalités, tarifs, partage de patrons, scan IA des fils DMC."
        url="/faq"
      />

      {/* Header */}
      <header style={{ background: N.bg, borderBottom: `1px solid ${N.border}`, padding: "16px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, color: N.muted, textDecoration: "none", fontSize: 14 }}>
          <ArrowLeft style={{ width: 16, height: 16 }} />
          Retour
        </Link>
        <span style={{ color: N.border }}>·</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Scissors style={{ width: 18, height: 18, color: N.accent }} />
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, color: N.text, fontWeight: 600 }}>ThreadFlow</span>
        </div>
      </header>

      {/* Hero */}
      <div style={{ textAlign: "center", padding: "56px 24px 40px" }}>
        <p style={{ color: N.accent, fontSize: 12, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>
          Support
        </p>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 48, fontWeight: 600, marginBottom: 16 }}>
          Questions fréquentes
        </h1>
        <p style={{ color: N.muted, fontSize: 17, maxWidth: 520, margin: "0 auto 0" }}>
          Tout ce que vous devez savoir sur ThreadFlow. Une question sans réponse ?{" "}
          <Link href="/a-propos" style={{ color: N.accent }}>Contactez-nous</Link>.
        </p>
      </div>

      {/* Contenu */}
      <main style={{ maxWidth: 720, margin: "0 auto", padding: "0 24px 80px" }}>
        {categories.map(cat => (
          <div key={cat} style={{ marginBottom: 48 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
              <div style={{ height: 2, width: 32, background: N.accent, borderRadius: 2 }} />
              <p style={{ color: N.accent, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", margin: 0 }}>
                {cat}
              </p>
            </div>
            <div style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "0 28px", boxShadow: "0 2px 12px rgba(61,74,62,0.06)" }}>
              {FAQ_ITEMS.filter(f => f.category === cat).map((item, i) => (
                <FAQItem key={i} q={item.q} a={item.a} />
              ))}
            </div>
          </div>
        ))}

        {/* CTA */}
        <div style={{ background: N.terra, borderRadius: 20, padding: "40px 48px", textAlign: "center", color: "white" }}>
          <p style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 8 }}>
            Vous n'avez pas trouvé votre réponse ?
          </p>
          <p style={{ opacity: 0.85, fontSize: 15, marginBottom: 24 }}>
            Notre équipe répond sous 24h en semaine.
          </p>
          <Link
            href="/a-propos"
            style={{
              display: "inline-block",
              background: "white",
              color: N.terra,
              padding: "12px 28px",
              borderRadius: 50,
              fontWeight: 600,
              fontSize: 15,
              textDecoration: "none",
            }}
          >
            Nous contacter →
          </Link>
        </div>
      </main>

      {/* Footer minimal */}
      <footer style={{ borderTop: `1px solid ${N.border}`, padding: "24px", textAlign: "center" }}>
        <div style={{ display: "flex", gap: 24, justifyContent: "center", flexWrap: "wrap" }}>
          {[
            { label: "Accueil", href: "/" },
            { label: "Blog", href: "/blog" },
            { label: "Confidentialité", href: "/confidentialite" },
            { label: "CGU", href: "/cgu" },
          ].map(({ label, href }) => (
            <Link key={href} href={href} style={{ color: N.muted, fontSize: 13, textDecoration: "none" }}>
              {label}
            </Link>
          ))}
        </div>
        <p style={{ color: N.border, fontSize: 12, marginTop: 12 }}>© 2026 ThreadFlow. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
