/**
 * Page 404 — ThreadFlow
 * Design cohérent avec la charte Neumorphisme Artisanal
 */
import { Link } from "wouter";
import { Scissors, Home, ArrowLeft } from "lucide-react";
import SEOHead from "@/components/SEOHead";

const N = {
  bg: "#F5F0E8",
  text: "#3D4A3E",
  accent: "#7A9E7E",
  terra: "#C4714A",
  muted: "#6b7a6c",
  border: "#d4c5a9",
  card: "white",
};

const QUICK_LINKS = [
  { label: "Accueil", href: "/" },
  { label: "Démo interactive", href: "/demo" },
  { label: "Blog broderie", href: "/blog" },
  { label: "FAQ", href: "/faq" },
];

export default function NotFound() {
  return (
    <div style={{ background: N.bg, minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <SEOHead title="Page introuvable" noIndex={true} />

      {/* Header minimal */}
      <header style={{ padding: "20px 32px", display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${N.border}` }}>
        <Scissors style={{ width: 20, height: 20, color: N.accent }} />
        <Link href="/" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, color: N.text, fontWeight: 600, textDecoration: "none" }}>
          ThreadFlow
        </Link>
      </header>

      {/* Contenu centré */}
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 24px" }}>
        <div style={{ textAlign: "center", maxWidth: 520 }}>

          {/* Illustration grille point de croix */}
          <div style={{ marginBottom: 32, display: "inline-block" }}>
            <div style={{
              width: 120, height: 120,
              background: N.card,
              border: `2px solid ${N.border}`,
              borderRadius: 20,
              display: "grid",
              gridTemplateColumns: "repeat(5, 1fr)",
              gridTemplateRows: "repeat(5, 1fr)",
              gap: 3,
              padding: 12,
              margin: "0 auto",
              boxShadow: "4px 4px 0 rgba(61,74,62,0.08)",
            }}>
              {[0,1,1,1,0, 0,0,0,1,0, 0,0,1,1,0, 0,0,0,0,0, 0,0,1,0,0].map((filled, i) => (
                <div
                  key={i}
                  style={{
                    background: filled ? N.terra : "transparent",
                    borderRadius: 2,
                    border: filled ? "none" : `1px solid ${N.border}`,
                    opacity: filled ? 1 : 0.2,
                  }}
                />
              ))}
            </div>
          </div>

          <p style={{ color: N.accent, fontSize: 13, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 12 }}>
            Erreur 404
          </p>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 44, fontWeight: 600, lineHeight: 1.2, marginBottom: 16 }}>
            Ce patron n'existe pas.
          </h1>
          <p style={{ color: N.muted, fontSize: 16, lineHeight: 1.7, marginBottom: 40 }}>
            La page que vous cherchez a peut-être été déplacée, renommée ou supprimée.
            Pas de panique — votre fil n'est pas perdu.
          </p>

          {/* Actions */}
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginBottom: 40 }}>
            <Link
              href="/"
              style={{
                display: "flex", alignItems: "center", gap: 8,
                background: N.terra, color: "white",
                padding: "12px 24px", borderRadius: 50,
                fontWeight: 600, fontSize: 15, textDecoration: "none",
              }}
            >
              <Home style={{ width: 16, height: 16 }} />
              Retour à l'accueil
            </Link>
            <button
              onClick={() => window.history.back()}
              style={{
                display: "flex", alignItems: "center", gap: 8,
                background: "transparent", color: N.muted,
                padding: "12px 24px", borderRadius: 50,
                border: `1px solid ${N.border}`, cursor: "pointer",
                fontWeight: 500, fontSize: 15,
              }}
            >
              <ArrowLeft style={{ width: 16, height: 16 }} />
              Page précédente
            </button>
          </div>

          {/* Liens rapides */}
          <div style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "24px 32px" }}>
            <p style={{ color: N.muted, fontSize: 13, marginBottom: 16 }}>Peut-être cherchiez-vous :</p>
            <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
              {QUICK_LINKS.map(({ label, href }) => (
                <Link
                  key={href}
                  href={href}
                  style={{
                    color: N.accent, fontSize: 14, fontWeight: 500,
                    textDecoration: "none", padding: "6px 16px",
                    background: "#f0f7f0", borderRadius: 50,
                    border: `1px solid ${N.accent}30`,
                  }}
                >
                  {label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer minimal */}
      <footer style={{ borderTop: `1px solid ${N.border}`, padding: "20px 32px", textAlign: "center" }}>
        <p style={{ color: N.border, fontSize: 12 }}>© 2026 ThreadFlow. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
