/*
 * ThreadFlow — Page Admin
 * Protégée par authentification + rôle admin
 * Liste des inscrits, statistiques, export CSV
 */
import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Download, Search, RefreshCw, Users, Star, Bell, TrendingUp, CheckCircle2, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import SEOHead from "@/components/SEOHead";
import { toast } from "sonner";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatDate(d: Date | string) {
  return new Date(d).toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function downloadCSV(csv: string, filename: string) {
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

// ─── Composant principal ───────────────────────────────────────────────────────
export default function Admin() {
  const { user, loading } = useAuth();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [goldenNeedleOnly, setGoldenNeedleOnly] = useState(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  const { data: stats, refetch: refetchStats } = trpc.admin.stats.useQuery();
  const { data: listData, isLoading: listLoading, refetch: refetchList } = trpc.admin.waitlistList.useQuery({
    page,
    limit: 50,
    search: search || undefined,
    goldenNeedleOnly: goldenNeedleOnly || undefined,
  });

  const exportMutation = trpc.admin.exportCsv.useMutation({
    onSuccess: (data) => {
      const date = new Date().toISOString().split("T")[0];
      downloadCSV(data.csv, `threadflow-waitlist-${date}.csv`);
      toast.success(`${data.count} inscrits exportés en CSV`);
    },
    onError: () => toast.error("Erreur lors de l'export"),
  });

  const markNotifiedMutation = trpc.admin.markNotified.useMutation({
    onSuccess: () => {
      toast.success(`${selectedIds.length} inscrit(s) marqué(s) comme notifié(s)`);
      setSelectedIds([]);
      refetchList();
      refetchStats();
    },
  });

  const handleRefresh = () => {
    refetchList();
    refetchStats();
    toast.info("Données actualisées");
  };

  const toggleSelect = (id: number) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    const ids = listData?.items.map(e => e.id) ?? [];
    if (selectedIds.length === ids.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(ids);
    }
  };

  // ─── Garde d'authentification ──────────────────────────────────────────────
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#e8e3da" }}>
        <div className="text-center space-y-3">
          <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin mx-auto"
            style={{ borderColor: "#C4714A", borderTopColor: "transparent" }} />
          <p className="text-sm" style={{ color: "#6b7a6c" }}>Vérification de l'accès...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#e8e3da" }}>
        <div className="text-center space-y-4 max-w-sm">
          <div className="text-4xl">🔒</div>
          <h1 className="text-xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}>
            Accès restreint
          </h1>
          <p className="text-sm" style={{ color: "#6b7a6c" }}>
            Vous devez être connecté pour accéder à cette page.
          </p>
          <a href={getLoginUrl()}>
            <Button style={{ background: "#C4714A", color: "white" }}>
              Se connecter
            </Button>
          </a>
        </div>
      </div>
    );
  }

  if (user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#e8e3da" }}>
        <div className="text-center space-y-4 max-w-sm">
          <div className="text-4xl">🚫</div>
          <h1 className="text-xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}>
            Accès non autorisé
          </h1>
          <p className="text-sm" style={{ color: "#6b7a6c" }}>
            Cette page est réservée aux administrateurs ThreadFlow.
          </p>
          <Link href="/">
            <Button variant="outline">Retour à l'accueil</Button>
          </Link>
        </div>
      </div>
    );
  }

  // ─── Interface admin ───────────────────────────────────────────────────────
  return (
    <div className="min-h-screen" style={{ background: "#e8e3da" }}>
      <SEOHead
        title="Administration — Gestion de la liste d'attente"
        description="Tableau de bord administrateur ThreadFlow"
        url="/admin"
        noIndex={true}
      />
      {/* Header */}
      <header
        className="sticky top-0 z-50 border-b"
        style={{
          background: "#e8e3daf2",
          borderColor: "oklch(0.88 0.025 75)",
          backdropFilter: "blur(12px)",
        }}
      >
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Retour
              </Button>
            </Link>
            <div className="h-5 w-px" style={{ background: "oklch(0.82 0.025 75)" }} />
            <span className="font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E", fontSize: "1.1rem" }}>
              ThreadFlow Admin
            </span>
            <Badge style={{ background: "oklch(0.62 0.12 40 / 0.12)", color: "oklch(0.52 0.10 40)" }}>
              {user.name ?? user.email}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleRefresh} className="gap-2">
              <RefreshCw className="w-4 h-4" />
              <span className="hidden sm:inline">Actualiser</span>
            </Button>
            <Button
              size="sm"
              onClick={() => exportMutation.mutate()}
              disabled={exportMutation.isPending}
              className="gap-2"
              style={{ background: "#7A9E7E", color: "white" }}
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exporter CSV</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Statistiques */}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                icon: <Users className="w-5 h-5" />,
                label: "Total inscrits",
                value: stats.total,
                color: "#7A9E7E",
              },
              {
                icon: <Star className="w-5 h-5" />,
                label: "Golden Needle 🏅",
                value: stats.goldenNeedle,
                color: "oklch(0.72 0.15 60)",
              },
              {
                icon: <Bell className="w-5 h-5" />,
                label: "Notifiés",
                value: stats.notified,
                color: "#C4714A",
              },
              {
                icon: <TrendingUp className="w-5 h-5" />,
                label: "Non notifiés",
                value: stats.total - stats.notified,
                color: "oklch(0.55 0.18 25)",
              },
            ].map((stat, i) => (
              <div
                key={i}
                className="rounded-2xl p-4"
                style={{
                  background: "#e8e3da",
                  boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
                }}
              >
                <div className="flex items-center gap-2 mb-2" style={{ color: stat.color }}>
                  {stat.icon}
                  <span className="text-xs font-medium" style={{ color: "#6b7a6c" }}>
                    {stat.label}
                  </span>
                </div>
                <div
                  className="text-3xl font-bold"
                  style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
                >
                  {stat.value.toLocaleString("fr-FR")}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Sources */}
        {stats && Object.keys(stats.bySource).length > 0 && (
          <div
            className="rounded-2xl p-4"
            style={{
              background: "#e8e3da",
              boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.4), -3px -3px 8px oklch(1 0 0 / 0.6)",
            }}
          >
            <h3 className="font-semibold text-sm mb-3" style={{ color: "#6b7a6c" }}>
              Répartition par source
            </h3>
            <div className="flex flex-wrap gap-2">
              {Object.entries(stats.bySource)
                .sort(([, a], [, b]) => (b as number) - (a as number))
                .map(([source, count]) => (
                  <div
                    key={source}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs"
                    style={{ background: "oklch(0.93 0.018 80)", color: "#3D4A3E" }}
                  >
                    <span className="font-medium">{source}</span>
                    <span
                      className="px-1.5 py-0.5 rounded-full font-bold"
                      style={{ background: "oklch(0.65 0.07 145 / 0.15)", color: "#3D4A3E" }}
                    >
                      {count as number}
                    </span>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Barre de recherche et filtres */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search
              className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
              style={{ color: "oklch(0.62 0.04 145)" }}
            />
            <input
              type="text"
              placeholder="Rechercher par email ou prénom..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-4 py-2 rounded-xl text-sm border outline-none transition-all"
              style={{
                background: "#e8e3da",
                borderColor: "oklch(0.88 0.025 75)",
                color: "#3D4A3E",
                boxShadow: "inset 2px 2px 5px oklch(0.88 0.025 75 / 0.5)",
              }}
            />
          </div>
          <button
            onClick={() => { setGoldenNeedleOnly(p => !p); setPage(1); }}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all"
            style={{
              background: goldenNeedleOnly ? "oklch(0.72 0.15 60)" : "oklch(0.93 0.018 80)",
              color: goldenNeedleOnly ? "white" : "#6b7a6c",
            }}
          >
            <Star className="w-4 h-4" />
            Golden Needle uniquement
          </button>
          {selectedIds.length > 0 && (
            <button
              onClick={() => markNotifiedMutation.mutate({ ids: selectedIds })}
              disabled={markNotifiedMutation.isPending}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all"
              style={{ background: "#7A9E7E", color: "white" }}
            >
              <CheckCircle2 className="w-4 h-4" />
              Marquer notifié ({selectedIds.length})
            </button>
          )}
        </div>

        {/* Tableau des inscrits */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{
            background: "#e8e3da",
            boxShadow: "6px 6px 16px oklch(0.82 0.025 75 / 0.5), -4px -4px 12px oklch(1 0 0 / 0.7)",
          }}
        >
          {/* En-tête tableau */}
          <div
            className="grid grid-cols-12 gap-2 px-4 py-3 text-xs font-semibold uppercase tracking-wide border-b"
            style={{
              color: "#6b7a6c",
              borderColor: "oklch(0.88 0.025 75)",
              background: "oklch(0.95 0.015 80)",
            }}
          >
            <div className="col-span-1 flex items-center">
              <input
                type="checkbox"
                checked={selectedIds.length === (listData?.items.length ?? 0) && (listData?.items.length ?? 0) > 0}
                onChange={toggleSelectAll}
                className="rounded"
              />
            </div>
            <div className="col-span-1 text-center">#</div>
            <div className="col-span-4">Email</div>
            <div className="col-span-2">Prénom</div>
            <div className="col-span-2">Source</div>
            <div className="col-span-1 text-center">🏅</div>
            <div className="col-span-1 text-center">Notifié</div>
          </div>

          {/* Lignes */}
          {listLoading ? (
            <div className="py-12 text-center">
              <div
                className="w-6 h-6 rounded-full border-2 border-t-transparent animate-spin mx-auto"
                style={{ borderColor: "#C4714A", borderTopColor: "transparent" }}
              />
            </div>
          ) : listData?.items.length === 0 ? (
            <div className="py-12 text-center text-sm" style={{ color: "oklch(0.62 0.04 145)" }}>
              Aucun inscrit trouvé
            </div>
          ) : (
            listData?.items.map((entry, idx) => (
              <div
                key={entry.id}
                className="grid grid-cols-12 gap-2 px-4 py-3 text-sm border-b transition-colors"
                style={{
                  borderColor: "oklch(0.92 0.018 80)",
                  background: selectedIds.includes(entry.id)
                    ? "oklch(0.62 0.12 40 / 0.05)"
                    : idx % 2 === 0
                    ? "transparent"
                    : "oklch(0.96 0.010 80 / 0.5)",
                }}
              >
                <div className="col-span-1 flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(entry.id)}
                    onChange={() => toggleSelect(entry.id)}
                    className="rounded"
                  />
                </div>
                <div
                  className="col-span-1 text-center font-mono text-xs"
                  style={{ color: "oklch(0.62 0.04 145)" }}
                >
                  {(listData.page - 1) * 50 + idx + 1}
                </div>
                <div className="col-span-4 truncate font-medium" style={{ color: "#3D4A3E" }}>
                  {entry.email}
                </div>
                <div className="col-span-2 truncate" style={{ color: "#6b7a6c" }}>
                  {entry.firstName ?? "—"}
                </div>
                <div className="col-span-2">
                  <span
                    className="text-xs px-2 py-0.5 rounded-full"
                    style={{ background: "oklch(0.93 0.018 80)", color: "#6b7a6c" }}
                  >
                    {entry.source ?? "website"}
                  </span>
                </div>
                <div className="col-span-1 text-center">
                  {entry.goldenNeedle ? (
                    <span title="Golden Needle">🏅</span>
                  ) : (
                    <span style={{ color: "oklch(0.82 0.025 75)" }}>—</span>
                  )}
                </div>
                <div className="col-span-1 text-center">
                  {entry.notified ? (
                    <CheckCircle2 className="w-4 h-4 mx-auto" style={{ color: "#7A9E7E" }} />
                  ) : (
                    <span
                      className="inline-block w-2 h-2 rounded-full mx-auto"
                      style={{ background: "oklch(0.72 0.15 60)" }}
                    />
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Pagination */}
        {listData && listData.totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-sm" style={{ color: "#6b7a6c" }}>
              {listData.total} inscrit(s) · Page {listData.page} / {listData.totalPages}
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
              >
                ← Précédent
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.min(listData.totalPages, p + 1))}
                disabled={page === listData.totalPages}
              >
                Suivant →
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
