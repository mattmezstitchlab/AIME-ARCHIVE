/**
 * Page À propos & Contact — ThreadFlow
 */
import { useState } from "react";
import { Link } from "wouter";
import { Scissors, ArrowLeft, Mail, Twitter, Instagram, Heart, Sparkles, Users, Loader2 } from "lucide-react";
import SEOHead from "@/components/SEOHead";
import { trpc } from "@/lib/trpc";

const N = {
  bg: "#F5F0E8",
  text: "#3D4A3E",
  accent: "#7A9E7E",
  terra: "#C4714A",
  muted: "#6b7a6c",
  border: "#d4c5a9",
  card: "white",
  lin: "#D4C5A9",
};

const TEAM = [
  {
    emoji: "🧵",
    name: "Sophie L.",
    role: "Fondatrice & CEO",
    bio: "Brodeuse depuis l'âge de 12 ans, frustrée par les logiciels existants. A tout quitté pour construire le compagnon qu'elle aurait voulu avoir.",
  },
  {
    emoji: "⚙️",
    name: "Marc D.",
    role: "CTO",
    bio: "Ingénieur passionné par les interfaces qui disparaissent. Convaincu que la technologie doit servir l'artisanat, pas le remplacer.",
  },
  {
    emoji: "🎨",
    name: "Léa M.",
    role: "Design Lead",
    bio: "Ancienne designeuse chez des studios créatifs parisiens. Brodeuse le week-end. Obsédée par la beauté des détails.",
  },
];

const VALUES = [
  { icon: Heart, title: "L'artisanat d'abord", desc: "Nous construisons des outils qui amplifient le savoir-faire, jamais des raccourcis qui le remplacent." },
  { icon: Users, title: "La communauté au centre", desc: "ThreadFlow est conçu pour les brodeuses, par des brodeuses. Chaque fonctionnalité naît d'un vrai besoin." },
  { icon: Sparkles, title: "La beauté comme standard", desc: "Un outil de broderie doit être aussi beau que ce qu'il aide à créer. Nous ne faisons aucun compromis sur le design." },
];

export default function About() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [error, setError] = useState<string | null>(null);

  const sendContact = trpc.contact.send.useMutation({
    onSuccess: () => setSent(true),
    onError: (err) => setError(err.message || "Une erreur est survenue. Veuillez réessayer."),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    sendContact.mutate(form);
  };

  return (
    <div style={{ background: N.bg, minHeight: "100vh" }}>
      <SEOHead
        title="À propos — Notre histoire"
        description="Découvrez l'histoire de ThreadFlow, l'équipe derrière le compagnon de broderie intelligent, et comment nous contacter."
        url="/a-propos"
      />

      {/* Header */}
      <header style={{ background: N.bg, borderBottom: `1px solid ${N.border}`, padding: "16px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, color: N.muted, textDecoration: "none", fontSize: 14 }}>
          <ArrowLeft style={{ width: 16, height: 16 }} />
          Retour
        </Link>
        <span style={{ color: N.border }}>·</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Scissors style={{ width: 18, height: 18, color: N.accent }} />
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, color: N.text, fontWeight: 600 }}>ThreadFlow</span>
        </div>
      </header>

      <main>
        {/* Hero */}
        <div style={{ maxWidth: 760, margin: "0 auto", padding: "64px 24px 48px", textAlign: "center" }}>
          <p style={{ color: N.accent, fontSize: 12, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>
            Notre histoire
          </p>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 52, fontWeight: 600, lineHeight: 1.15, marginBottom: 24 }}>
            Construits par des brodeuses,<br />pour des brodeuses.
          </h1>
          <p style={{ color: N.muted, fontSize: 17, lineHeight: 1.8, maxWidth: 580, margin: "0 auto" }}>
            ThreadFlow est né d'une frustration simple : pourquoi les outils de broderie sont-ils si laids, si lents, si peu intelligents ? En 2024, nous avons décidé de changer ça.
          </p>
        </div>

        {/* Notre histoire */}
        <div style={{ background: N.card, borderTop: `1px solid ${N.border}`, borderBottom: `1px solid ${N.border}` }}>
          <div style={{ maxWidth: 720, margin: "0 auto", padding: "56px 24px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
              <div>
                <p style={{ color: N.accent, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>2024</p>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>L'idée</h3>
                <p style={{ color: N.muted, fontSize: 15, lineHeight: 1.8 }}>
                  Sophie, après 20 ans de broderie et des heures perdues à gérer ses fils dans des tableurs Excel, décide de construire l'outil qu'elle aurait voulu avoir. Elle rencontre Marc et Léa, et ThreadFlow commence à prendre forme.
                </p>
              </div>
              <div>
                <p style={{ color: N.accent, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>2025</p>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>La construction</h3>
                <p style={{ color: N.muted, fontSize: 15, lineHeight: 1.8 }}>
                  18 mois de développement, 200 brodeuses en bêta privée, des centaines de retours intégrés. Smart Pathing™, Confetti Cleaner™, le scan IA — chaque fonctionnalité est née d'un vrai besoin exprimé par la communauté.
                </p>
              </div>
              <div>
                <p style={{ color: N.accent, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>Mai 2026</p>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>Le lancement</h3>
                <p style={{ color: N.muted, fontSize: 15, lineHeight: 1.8 }}>
                  ThreadFlow ouvre ses portes au public. Bêta ouverte, accès gratuit, badge Golden Needle pour les 1 000 premières. La communauté grandit. L'aventure commence vraiment.
                </p>
              </div>
              <div>
                <p style={{ color: N.accent, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>Demain</p>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 22, fontWeight: 600, marginBottom: 12 }}>La vision</h3>
                <p style={{ color: N.muted, fontSize: 15, lineHeight: 1.8 }}>
                  Devenir la référence mondiale du compagnon de broderie. Application mobile, marketplace de patrons, IA générative de patrons personnalisés, partenariats avec les grandes marques DMC et Anchor.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Valeurs */}
        <div style={{ maxWidth: 760, margin: "0 auto", padding: "64px 24px" }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 36, fontWeight: 600, textAlign: "center", marginBottom: 48 }}>
            Ce en quoi nous croyons
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
            {VALUES.map(({ icon: Icon, title, desc }) => (
              <div key={title} style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "28px 24px", textAlign: "center" }}>
                <div style={{ width: 48, height: 48, background: "#f0f7f0", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                  <Icon style={{ width: 22, height: 22, color: N.accent }} />
                </div>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 18, fontWeight: 600, marginBottom: 8 }}>{title}</h3>
                <p style={{ color: N.muted, fontSize: 14, lineHeight: 1.7 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Équipe */}
        <div style={{ background: N.card, borderTop: `1px solid ${N.border}`, borderBottom: `1px solid ${N.border}` }}>
          <div style={{ maxWidth: 760, margin: "0 auto", padding: "64px 24px" }}>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 36, fontWeight: 600, textAlign: "center", marginBottom: 48 }}>
              L'équipe
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
              {TEAM.map(({ emoji, name, role, bio }) => (
                <div key={name} style={{ textAlign: "center" }}>
                  <div style={{ width: 72, height: 72, background: N.bg, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 32, border: `2px solid ${N.border}` }}>
                    {emoji}
                  </div>
                  <p style={{ color: N.text, fontWeight: 600, fontSize: 16, marginBottom: 4 }}>{name}</p>
                  <p style={{ color: N.accent, fontSize: 13, marginBottom: 12 }}>{role}</p>
                  <p style={{ color: N.muted, fontSize: 14, lineHeight: 1.7 }}>{bio}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Contact */}
        <div style={{ maxWidth: 640, margin: "0 auto", padding: "64px 24px 80px" }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", color: N.text, fontSize: 36, fontWeight: 600, textAlign: "center", marginBottom: 8 }}>
            Nous contacter
          </h2>
          <p style={{ color: N.muted, textAlign: "center", fontSize: 15, marginBottom: 40 }}>
            Nous répondons sous 24h en semaine.
          </p>

          {/* Canaux */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 40 }}>
            {[
              { icon: Mail, label: "Support général", value: "hello@threadflow.app" },
              { icon: Mail, label: "Presse", value: "presse@threadflow.app" },
              { icon: Instagram, label: "Instagram", value: "@threadflow.app" },
              { icon: Twitter, label: "Twitter/X", value: "@ThreadFlowApp" },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 12, padding: "16px 20px", display: "flex", alignItems: "center", gap: 12 }}>
                <Icon style={{ width: 18, height: 18, color: N.accent, flexShrink: 0 }} />
                <div>
                  <p style={{ color: N.muted, fontSize: 12, marginBottom: 2 }}>{label}</p>
                  <p style={{ color: N.text, fontSize: 14, fontWeight: 500 }}>{value}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Formulaire */}
          {sent ? (
            <div style={{ background: "#f0f7f0", border: `1px solid ${N.accent}40`, borderRadius: 16, padding: "32px", textAlign: "center" }}>
              <p style={{ fontSize: 32, marginBottom: 12 }}>🧵</p>
              <p style={{ color: N.text, fontWeight: 600, fontSize: 18, marginBottom: 8 }}>Message envoyé !</p>
              <p style={{ color: N.muted, fontSize: 15 }}>Nous vous répondrons sous 24h. Merci pour votre message.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} style={{ background: N.card, border: `1px solid ${N.border}`, borderRadius: 16, padding: "32px 36px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                {[
                  { label: "Votre prénom", key: "name", type: "text", placeholder: "Sophie" },
                  { label: "Votre e-mail", key: "email", type: "email", placeholder: "sophie@exemple.fr" },
                ].map(({ label, key, type, placeholder }) => (
                  <div key={key}>
                    <label style={{ display: "block", color: N.text, fontSize: 13, fontWeight: 500, marginBottom: 6 }}>{label}</label>
                    <input
                      type={type}
                      placeholder={placeholder}
                      required
                      value={form[key as keyof typeof form]}
                      onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                      style={{ width: "100%", padding: "10px 14px", border: `1px solid ${N.border}`, borderRadius: 8, background: N.bg, color: N.text, fontSize: 14, outline: "none", boxSizing: "border-box" }}
                    />
                  </div>
                ))}
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: "block", color: N.text, fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Sujet</label>
                <input
                  type="text"
                  placeholder="Question sur les fonctionnalités..."
                  required
                  value={form.subject}
                  onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                  style={{ width: "100%", padding: "10px 14px", border: `1px solid ${N.border}`, borderRadius: 8, background: N.bg, color: N.text, fontSize: 14, outline: "none", boxSizing: "border-box" }}
                />
              </div>
              <div style={{ marginBottom: 24 }}>
                <label style={{ display: "block", color: N.text, fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Message</label>
                <textarea
                  placeholder="Décrivez votre question ou retour..."
                  required
                  rows={5}
                  value={form.message}
                  onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                  style={{ width: "100%", padding: "10px 14px", border: `1px solid ${N.border}`, borderRadius: 8, background: N.bg, color: N.text, fontSize: 14, outline: "none", resize: "vertical", boxSizing: "border-box" }}
                />
              </div>
              {error && (
                <p style={{ color: N.terra, fontSize: 13, marginBottom: 12, textAlign: "center" }}>{error}</p>
              )}
              <button
                type="submit"
                disabled={sendContact.isPending}
                style={{ width: "100%", padding: "13px", background: sendContact.isPending ? "#b5a99a" : N.terra, color: "white", border: "none", borderRadius: 50, fontWeight: 600, fontSize: 15, cursor: sendContact.isPending ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
              >
                {sendContact.isPending ? (
                  <><Loader2 style={{ width: 16, height: 16, animation: "spin 1s linear infinite" }} /> Envoi en cours...</>
                ) : "Envoyer le message →"}
              </button>
            </form>
          )}
        </div>
      </main>

      {/* Footer minimal */}
      <footer style={{ borderTop: `1px solid ${N.border}`, padding: "24px", textAlign: "center" }}>
        <div style={{ display: "flex", gap: 24, justifyContent: "center", flexWrap: "wrap" }}>
          {[
            { label: "Accueil", href: "/" },
            { label: "FAQ", href: "/faq" },
            { label: "Blog", href: "/blog" },
            { label: "Confidentialité", href: "/confidentialite" },
            { label: "CGU", href: "/cgu" },
          ].map(({ label, href }) => (
            <Link key={href} href={href} style={{ color: N.muted, fontSize: 13, textDecoration: "none" }}>
              {label}
            </Link>
          ))}
        </div>
        <p style={{ color: N.border, fontSize: 12, marginTop: 12 }}>© 2026 ThreadFlow. Tous droits réservés.</p>
      </footer>
    </div>
  );
}
