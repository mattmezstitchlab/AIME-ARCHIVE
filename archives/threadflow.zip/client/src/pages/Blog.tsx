/*
 * ThreadFlow Blog — Articles SEO
 * 3 articles complets ciblant les requêtes brodeuses francophones
 */
import { type ReactElement } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Clock, Tag, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import SEOHead from "@/components/SEOHead";

// ─── Articles statiques (fallback si DB vide) ─────────────────────────────────
const STATIC_POSTS = [
  {
    slug: "logiciel-broderie-point-de-croix-guide-complet",
    title: "Quel logiciel de broderie point de croix choisir en 2026 ? Le guide complet",
    excerpt:
      "PCStitch, Pattern Keeper, Stitch Fiddle, ThreadFlow... Nous comparons les 4 logiciels les plus utilisés par les brodeuses pour vous aider à choisir celui qui correspond à votre pratique.",
    category: "Guide",
    readingTime: 8,
    publishedAt: new Date("2026-04-15"),
    coverImage: null,
    tags: JSON.stringify(["logiciel broderie", "point de croix", "comparatif"]),
    content: `
# Quel logiciel de broderie point de croix choisir en 2026 ?

La broderie point de croix connaît un renouveau spectaculaire depuis 2020. Avec lui, une nouvelle génération de logiciels est apparue — mais le marché reste fragmenté, confus, et souvent décevant. Ce guide compare honnêtement les 4 solutions principales.

## Le problème avec les logiciels actuels

Avant de comparer, il faut nommer le problème central : **aucun logiciel existant n'a été conçu pour la brodeuse moderne**. Ils ont été créés dans les années 2000 pour des utilisatrices de PC, et n'ont jamais vraiment évolué.

Résultat : vous passez plus de temps à gérer votre logiciel qu'à broder.

## PCStitch — Le vétéran

**Prix :** 49,99 $ (licence perpétuelle, Windows uniquement)

PCStitch est le logiciel de référence depuis 25 ans. Sa bibliothèque de points est exhaustive, son moteur de conversion photo-vers-patron est solide, et sa communauté est vaste.

**Avantages :**
- Bibliothèque de 100 000+ patrons
- Conversion photo très précise
- Communauté active sur les forums

**Inconvénients :**
- Interface datée (Windows XP era)
- Pas d'application mobile
- Pas de gestion d'inventaire de fils
- Pas de synchronisation cloud

**Pour qui ?** Les brodeuses avancées qui travaillent exclusivement sur PC et ont besoin de la bibliothèque de patrons.

## Pattern Keeper — Le mobile-first

**Prix :** 9,99 $/an (iOS uniquement)

Pattern Keeper a révolutionné la broderie mobile en 2018. Son interface de suivi de patron sur iPad est excellente, et son système de marquage des points complétés est fluide.

**Avantages :**
- Interface mobile excellente
- Suivi de progression très intuitif
- Import de patrons PDF et XSD

**Inconvénients :**
- iOS uniquement (pas d'Android, pas de web)
- Pas de gestion d'inventaire
- Pas de fonctionnalités communautaires
- Pas d'IA ni d'optimisation

**Pour qui ?** Les brodeuses sur iPad qui veulent simplement suivre leur progression.

## Stitch Fiddle — Le gratuit en ligne

**Prix :** Gratuit (fonctionnalités limitées) / 2,99 $/mois

Stitch Fiddle est l'option gratuite par défaut. Son éditeur de patron en ligne est fonctionnel, et sa bibliothèque de patrons partagés est intéressante.

**Avantages :**
- Gratuit pour les fonctionnalités de base
- Accessible depuis n'importe quel navigateur
- Communauté de partage de patrons

**Inconvénients :**
- Performances lentes
- Interface peu intuitive
- Pas de gestion d'inventaire
- Publicités intrusives en version gratuite

**Pour qui ?** Les débutantes qui veulent tester sans investir.

## ThreadFlow — La nouvelle génération

**Prix :** Gratuit 30 jours, puis 4,99 €/mois

ThreadFlow est le seul logiciel conçu pour la brodeuse de 2026 : mobile-first, IA-powered, et centré sur la communauté.

**Ce qui change tout :**

**1. Le Scan IA en 45 secondes.** Pointez votre smartphone vers votre boîte de fils DMC. L'IA identifie automatiquement chaque couleur et crée votre inventaire. Fini les heures de saisie manuelle.

**2. Le Smart Pathing™.** Un algorithme analyse votre patron et génère l'itinéraire optimal couleur par couleur, minimisant les déplacements à l'arrière du tissu. Économie moyenne : 3,2 m de fil par projet.

**3. Le Confetti Cleaner™.** L'IA regroupe intelligemment les points isolés (les fameux "confettis") pour les broder en une seule session. Fini la frustration des points éparpillés.

**Avantages :**
- iOS, Android et Web
- IA intégrée (scan, optimisation, nettoyage)
- Gestion d'inventaire complète
- Communauté et partage de WIP
- Synchronisation multi-appareils

**Inconvénients :**
- Nouveau sur le marché (bêta ouverte)
- Bibliothèque de patrons en construction

**Pour qui ?** Toute brodeuse qui veut passer moins de temps à gérer et plus de temps à broder.

## Tableau comparatif

| Critère | PCStitch | Pattern Keeper | Stitch Fiddle | ThreadFlow |
|---|---|---|---|---|
| Prix | 49,99 $ | 9,99 $/an | Gratuit/2,99 $ | 4,99 €/mois |
| Mobile | ✗ | iOS seulement | ✓ | iOS + Android + Web |
| Scan IA | ✗ | ✗ | ✗ | ✓ |
| Inventaire fils | ✗ | ✗ | ✗ | ✓ |
| Smart Pathing | ✗ | ✗ | ✗ | ✓ |
| Communauté | Forums | ✗ | Partage | Stitch Hub |
| Synchronisation | ✗ | iCloud | ✓ | ✓ |

## Conclusion

Si vous cherchez un logiciel pour **aujourd'hui**, Pattern Keeper reste le meilleur choix pour les utilisatrices iOS. Pour **demain**, ThreadFlow est la seule solution qui adresse vraiment les problèmes des brodeuses modernes.

La bonne nouvelle : ThreadFlow propose 30 jours d'essai gratuit, sans carte bancaire. Vous n'avez rien à perdre.
    `,
  },
  {
    slug: "gerer-fils-dmc-inventaire-brodeuse",
    title: "Comment gérer son inventaire de fils DMC sans perdre la tête",
    excerpt:
      "Tableur Excel, application, boîte à fils numérotée... Nous avons testé toutes les méthodes pour gérer son stock de fils DMC. Voici ce qui fonctionne vraiment.",
    category: "Organisation",
    readingTime: 6,
    publishedAt: new Date("2026-04-28"),
    coverImage: null,
    tags: JSON.stringify(["fils DMC", "inventaire", "organisation broderie"]),
    content: `
# Comment gérer son inventaire de fils DMC sans perdre la tête

Vous avez 200, 300, peut-être 500 fils DMC. Vous commencez un nouveau projet, vous cherchez le DMC 3726, et vous passez 20 minutes à fouiller dans vos boîtes avant de commander un fil que vous aviez déjà. Ça vous parle ?

La gestion d'inventaire est le problème n°1 des brodeuses sérieuses. Voici les méthodes qui existent, leurs limites, et ce qui change vraiment la donne.

## Méthode 1 : Le tableur Excel

La méthode classique. Vous créez un fichier avec les colonnes : numéro DMC, nom, quantité, emplacement.

**Ce qui marche :** C'est gratuit, personnalisable, et vous contrôlez tout.

**Ce qui ne marche pas :** Vous devez le mettre à jour manuellement à chaque achat et chaque utilisation. En pratique, après 3 mois, le tableur est obsolète et vous ne lui faites plus confiance.

**Verdict :** Bon pour démarrer, insoutenable à long terme.

## Méthode 2 : Les applications de liste

Des applications comme Notion, Airtable ou même des apps spécialisées comme DMC Color Card permettent de tenir une liste numérique.

**Ce qui marche :** Accessible depuis votre téléphone, synchronisé.

**Ce qui ne marche pas :** La saisie initiale. Entrer 300 fils à la main, c'est 2-3 heures de travail. Et comme pour Excel, la mise à jour régulière est fastidieuse.

**Verdict :** Mieux qu'Excel, mais le problème de saisie reste entier.

## Méthode 3 : La boîte physique numérotée

Certaines brodeuses organisent leurs fils dans des boîtes numérotées (1-50, 51-100, etc.) et mémorisent l'emplacement. Pas de numérique, juste de l'organisation physique.

**Ce qui marche :** Zéro friction, pas de mise à jour à faire.

**Ce qui ne marche pas :** Vous ne savez jamais ce que vous avez vraiment. Impossible de vérifier avant d'acheter.

**Verdict :** Pratique au quotidien, inutile pour la planification.

## Méthode 4 : Le scan IA (ThreadFlow)

ThreadFlow a résolu le problème de la saisie initiale avec une fonctionnalité unique : **le scan IA en 45 secondes**.

Voici comment ça fonctionne :

1. Vous ouvrez ThreadFlow sur votre smartphone
2. Vous pointez la caméra vers votre boîte de fils DMC
3. L'IA lit les étiquettes et identifie chaque couleur automatiquement
4. En 45 secondes, votre inventaire est créé

Pas de saisie manuelle. Pas d'erreur. Et le système se met à jour automatiquement quand vous utilisez un fil dans un projet.

**Le message pivot.** Quand vous importez un nouveau patron, ThreadFlow croise automatiquement les besoins du patron avec votre inventaire et vous dit exactement ce qu'il vous manque. "Bonne nouvelle — vous avez déjà 89 % des fils. Il vous manque seulement : DMC 3750, DMC 223, DMC 677."

## Les 5 règles d'or de la gestion d'inventaire

Quelle que soit la méthode choisie, ces règles s'appliquent :

**1. Saisir à l'achat, pas après.** Chaque nouveau fil doit être enregistré au moment où vous l'achetez, pas quand vous avez le temps.

**2. Déduire à l'utilisation.** Quand vous terminez une pelote, notez-le immédiatement.

**3. Faire un inventaire annuel.** Une fois par an, vérifiez physiquement ce que vous avez.

**4. Photographier vos boîtes.** Une photo de chaque boîte vous permet de vérifier visuellement sans tout sortir.

**5. Utiliser un système que vous aimez.** Le meilleur système est celui que vous utiliserez vraiment.

## Conclusion

La gestion d'inventaire n'est pas glamour, mais elle est la différence entre une session de broderie fluide et une session frustrante. Investissez 30 minutes pour mettre en place un système solide — vous vous remercierez à chaque nouveau projet.

Si vous voulez tester le scan IA de ThreadFlow, l'essai gratuit de 30 jours vous permettra de numériser tout votre inventaire sans engagement.
    `,
  },
  {
    slug: "confetti-cross-stitch-technique-broder-points-isoles",
    title: "Confetti en point de croix : la technique pour ne plus les redouter",
    excerpt:
      "Les confettis — ces points isolés éparpillés sur tout le patron — sont la bête noire des brodeuses. Voici les meilleures techniques pour les gérer, et comment l'IA peut les éliminer automatiquement.",
    category: "Technique",
    readingTime: 7,
    publishedAt: new Date("2026-05-05"),
    coverImage: null,
    tags: JSON.stringify(["confetti cross stitch", "technique broderie", "points isolés"]),
    content: `
# Confetti en point de croix : la technique pour ne plus les redouter

Si vous avez déjà brodé un patron de paysage, un portrait réaliste ou un motif de style "painting", vous connaissez les confettis. Ces points isolés, éparpillés sur tout le patron, qui vous obligent à changer de fil toutes les 2-3 mailles. La bête noire des brodeuses.

Dans cet article, nous allons voir pourquoi les confettis existent, les techniques pour les gérer, et comment la technologie peut les éliminer.

## Qu'est-ce qu'un confetti en point de croix ?

Un "confetti" désigne un point (ou un groupe de 2-3 points) d'une couleur donnée, isolé au milieu d'une zone de couleur différente. Le terme vient de l'anglais "confetti cross stitch" et est universellement utilisé dans la communauté.

Les confettis apparaissent surtout dans :
- Les patrons de style réaliste (portraits, paysages)
- Les conversions photo-vers-patron
- Les patrons avec dégradés complexes
- Les œuvres de designers comme Haed (Heaven and Earth Designs)

## Pourquoi les confettis sont-ils si frustrants ?

Le problème n'est pas le point lui-même — c'est le **changement de fil**. Pour broder un confetti, vous devez :
1. Terminer votre fil en cours
2. Chercher le bon fil dans votre boîte
3. Enfiler l'aiguille
4. Broder 1-2 points
5. Terminer le fil
6. Reprendre votre fil précédent

Pour un patron avec 50 confettis de couleurs différentes, ça représente 100 changements de fil supplémentaires. Soit 2-3 heures de travail pur de gestion.

## Technique 1 : Broder par couleur, pas par zone

La technique la plus efficace est de **ne jamais broder par zone géographique**, mais par couleur.

Principe : vous prenez une couleur (par exemple le DMC 3726), et vous brodez TOUS les points de cette couleur sur tout le patron, y compris les confettis. Puis vous passez à la couleur suivante.

**Avantages :** Vous ne changez de fil qu'une seule fois par couleur.
**Inconvénients :** Beaucoup de déplacements à l'arrière du tissu, ce qui peut créer des fils flottants disgracieux.

## Technique 2 : La méthode "parking"

Le "parking" (ou stationnement) est une technique avancée qui consiste à laisser vos fils "garés" à l'endroit où vous en aurez besoin.

Principe : quand vous terminez une zone d'une couleur, au lieu de terminer le fil, vous le laissez "garé" à l'endroit du prochain confetti de cette couleur. Quand vous arrivez à ce confetti, le fil est déjà là.

**Avantages :** Aucun changement de fil inutile, déplacements minimaux.
**Inconvénients :** Technique complexe à maîtriser, beaucoup de fils qui pendent à l'arrière.

## Technique 3 : Regrouper les confettis par session

Une approche pragmatique : dédier des sessions entières aux confettis. Vous identifiez tous les confettis du patron, vous les regroupez par couleur, et vous les brodez tous en une seule session intensive.

**Avantages :** Vous "liquidez" les confettis d'un coup.
**Inconvénients :** Nécessite une cartographie préalable du patron.

## Comment ThreadFlow élimine les confettis avec l'IA

ThreadFlow a développé une fonctionnalité unique : le **Confetti Cleaner™**.

Voici comment ça fonctionne :

1. Vous importez votre patron dans ThreadFlow
2. L'IA analyse la distribution de chaque couleur
3. Elle identifie automatiquement tous les confettis
4. Elle génère un plan de broderie optimisé qui regroupe les confettis par session
5. Elle vous indique l'ordre optimal pour minimiser les changements de fil

Le résultat : ce qui prenait 3 heures de gestion prend maintenant 20 minutes.

La fonctionnalité va plus loin : le Confetti Cleaner peut aussi **suggérer des substitutions de couleur** pour les confettis les plus isolés. Si vous avez 1 point de DMC 3726 entouré de 50 points de DMC 3727, l'IA peut vous proposer de substituer ce point par le 3727 — la différence sera imperceptible à l'œil, mais vous économiserez un changement de fil.

## Les patrons les plus "confetti-friendly"

Si vous débutez et voulez éviter les confettis, voici les types de patrons à privilégier :

- **Patrons géométriques** : très peu de confettis
- **Patrons floraux stylisés** : quelques confettis, gérables
- **Patrons de lettrages** : presque aucun confetti
- **Patrons de paysages simplifiés** : quelques confettis

À éviter si vous êtes débutante :
- Portraits réalistes
- Conversions photo directes
- Patrons Haed (Heaven and Earth Designs)

## Conclusion

Les confettis font partie de la broderie point de croix — ils sont souvent ce qui donne aux patrons leur richesse et leur réalisme. Avec les bonnes techniques (broderie par couleur, parking, sessions dédiées), ils deviennent gérables.

Et si vous voulez éliminer la friction complètement, le Confetti Cleaner™ de ThreadFlow est la solution la plus efficace du marché. Essayez-le gratuitement pendant 30 jours.
    `,
  },
];

// ─── Page Blog (liste) ─────────────────────────────────────────────────────────
function BlogList() {
  const { data: dbPosts } = trpc.blog.list.useQuery();
  const posts = (dbPosts && dbPosts.length > 0) ? dbPosts : STATIC_POSTS;

  return (
    <div className="min-h-screen" style={{ background: "#e8e3da" }}>
      <SEOHead
        title="Blog — Guides et conseils broderie point de croix"
        description="Guides pratiques, comparatifs de logiciels et techniques pour les brodeuses point de croix. Apprenez à gérer votre inventaire DMC, optimiser vos patrons et rejoindre la communauté ThreadFlow."
        url="/blog"
      />
      {/* Header */}
      <header
        className="border-b"
        style={{
          background: "#e8e3da",
          borderColor: "oklch(0.88 0.025 75)",
        }}
      >
        <div className="container mx-auto px-4 h-14 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Retour
            </Button>
          </Link>
          <div className="h-5 w-px" style={{ background: "oklch(0.82 0.025 75)" }} />
          <span
            className="font-bold text-lg"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            ThreadFlow Blog
          </span>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        {/* Hero */}
        <div className="mb-12 text-center">
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider mb-4"
            style={{ background: "oklch(0.62 0.12 40 / 0.1)", color: "oklch(0.52 0.10 40)" }}
          >
            Ressources pour brodeuses
          </div>
          <h1
            className="text-4xl md:text-5xl font-bold mb-4"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            Le blog de la broderie moderne
          </h1>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: "#6b7a6c" }}>
            Guides pratiques, comparatifs et techniques pour les brodeuses point de croix qui veulent passer plus de temps à broder.
          </p>
        </div>

        {/* Articles */}
        <div className="space-y-6">
          {posts.map((post) => {
            const tags = (() => {
              try { return JSON.parse(post.tags ?? "[]") as string[]; }
              catch { return []; }
            })();
            const date = post.publishedAt instanceof Date
              ? post.publishedAt
              : new Date(post.publishedAt);

            return (
              <Link key={post.slug} href={`/blog/${post.slug}`}>
                <article
                  className="rounded-2xl p-6 cursor-pointer transition-all duration-200 hover:-translate-y-0.5"
                  style={{
                    background: "#e8e3da",
                    boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
                  }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          className="text-xs"
                          style={{
                            background: "oklch(0.65 0.07 145 / 0.12)",
                            color: "#3D4A3E",
                            border: "none",
                          }}
                        >
                          {post.category}
                        </Badge>
                        <span className="flex items-center gap-1 text-xs" style={{ color: "oklch(0.62 0.04 145)" }}>
                          <Clock className="w-3 h-3" />
                          {post.readingTime} min de lecture
                        </span>
                        <span className="text-xs" style={{ color: "oklch(0.72 0.025 75)" }}>
                          {date.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                        </span>
                      </div>
                      <h2
                        className="text-xl font-bold mb-2 leading-snug"
                        style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
                      >
                        {post.title}
                      </h2>
                      <p className="text-sm leading-relaxed mb-3" style={{ color: "#6b7a6c" }}>
                        {post.excerpt}
                      </p>
                      <div className="flex items-center gap-2 flex-wrap">
                        {tags.slice(0, 3).map((tag: string) => (
                          <span
                            key={tag}
                            className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                            style={{ background: "oklch(0.93 0.018 80)", color: "#6b7a6c" }}
                          >
                            <Tag className="w-2.5 h-2.5" />
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 flex-shrink-0 mt-1" style={{ color: "oklch(0.72 0.025 75)" }} />
                  </div>
                </article>
              </Link>
            );
          })}
        </div>

        {/* CTA */}
        <div
          className="mt-12 rounded-2xl p-8 text-center"
          style={{
            background: "linear-gradient(135deg, oklch(0.62 0.12 40 / 0.06), oklch(0.65 0.07 145 / 0.06))",
            border: "1px solid oklch(0.62 0.12 40 / 0.1)",
          }}
        >
          <h3
            className="text-2xl font-bold mb-2"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            Prête à essayer ThreadFlow ?
          </h3>
          <p className="text-sm mb-4" style={{ color: "#6b7a6c" }}>
            30 jours gratuits, sans carte bancaire. Découvrez le logiciel de broderie de la prochaine génération.
          </p>
          <Link href="/#waitlist">
            <Button style={{ background: "#C4714A", color: "white" }}>
              Rejoindre la liste d'attente →
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

// ─── Page Article individuel ───────────────────────────────────────────────────
function BlogPost({ slug }: { slug: string }) {
  const { data: dbPost } = trpc.blog.bySlug.useQuery({ slug });
  const post = dbPost ?? STATIC_POSTS.find(p => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#e8e3da" }}>
        <div className="text-center">
          <p className="text-lg mb-4" style={{ color: "#6b7a6c" }}>Article introuvable</p>
          <Link href="/blog">
            <Button variant="outline">Retour au blog</Button>
          </Link>
        </div>
      </div>
    );
  }

  const tags = (() => {
    try { return JSON.parse(post.tags ?? "[]") as string[]; }
    catch { return []; }
  })();
  const date = post.publishedAt instanceof Date
    ? post.publishedAt
    : new Date(post.publishedAt);

  // Rendu Markdown simplifié
  const renderMarkdown = (md: string) => {
    const lines = md.trim().split("\n");
    const elements: ReactElement[] = [];
    let i = 0;
    let tableBuffer: string[] = [];

    const flushTable = () => {
      if (tableBuffer.length < 2) { tableBuffer = []; return; }
      const rows = tableBuffer.map(r => r.split("|").map(c => c.trim()).filter(Boolean));
      const header = rows[0];
      const body = rows.slice(2);
      elements.push(
        <div key={`table-${i}`} className="overflow-x-auto my-6">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr style={{ background: "oklch(0.93 0.018 80)" }}>
                {header.map((h, hi) => (
                  <th key={hi} className="px-3 py-2 text-left font-semibold border" style={{ borderColor: "oklch(0.88 0.025 75)", color: "#3D4A3E" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {body.map((row, ri) => (
                <tr key={ri} style={{ background: ri % 2 === 0 ? "transparent" : "oklch(0.97 0.012 80 / 0.5)" }}>
                  {row.map((cell, ci) => (
                    <td key={ci} className="px-3 py-2 border" style={{ borderColor: "oklch(0.88 0.025 75)", color: "#6b7a6c" }}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      tableBuffer = [];
    };

    while (i < lines.length) {
      const line = lines[i];

      if (line.startsWith("|")) {
        tableBuffer.push(line);
        i++;
        continue;
      } else if (tableBuffer.length > 0) {
        flushTable();
      }

      if (line.startsWith("## ")) {
        elements.push(<h2 key={i} className="text-2xl font-bold mt-8 mb-3" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}>{line.slice(3)}</h2>);
      } else if (line.startsWith("# ")) {
        elements.push(<h1 key={i} className="text-3xl font-bold mt-6 mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}>{line.slice(2)}</h1>);
      } else if (line.startsWith("**") && line.endsWith("**") && line.length > 4) {
        elements.push(<p key={i} className="font-semibold mt-4 mb-1" style={{ color: "#3D4A3E" }}>{line.slice(2, -2)}</p>);
      } else if (line.startsWith("- ")) {
        const items: string[] = [line.slice(2)];
        while (i + 1 < lines.length && lines[i + 1].startsWith("- ")) {
          i++;
          items.push(lines[i].slice(2));
        }
        elements.push(
          <ul key={i} className="my-3 space-y-1.5 pl-4">
            {items.map((item, ii) => (
              <li key={ii} className="flex items-start gap-2 text-sm" style={{ color: "#6b7a6c" }}>
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "#C4714A" }} />
                <span dangerouslySetInnerHTML={{ __html: item.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
              </li>
            ))}
          </ul>
        );
      } else if (line.trim() === "") {
        // skip empty lines
      } else {
        elements.push(
          <p key={i} className="text-sm leading-relaxed my-3" style={{ color: "#6b7a6c" }}
            dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g, '<strong style="color:#3D4A3E">$1</strong>') }}
          />
        );
      }
      i++;
    }
    if (tableBuffer.length > 0) flushTable();
    return elements;
  };

  return (
    <div className="min-h-screen" style={{ background: "#e8e3da" }}>
      <SEOHead
        title={post.title}
        description={post.excerpt ?? undefined}
        url={`/blog/${post.slug}`}
        type="article"
        publishedAt={date.toISOString()}
      />
      {/* Header */}
      <header
        className="border-b"
        style={{ background: "#e8e3da", borderColor: "oklch(0.88 0.025 75)" }}
      >
        <div className="container mx-auto px-4 h-14 flex items-center gap-4">
          <Link href="/blog">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Blog
            </Button>
          </Link>
          <div className="h-5 w-px" style={{ background: "oklch(0.82 0.025 75)" }} />
          <Link href="/">
            <span className="font-bold text-lg" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}>
              ThreadFlow
            </span>
          </Link>
        </div>
      </header>

      <article className="container mx-auto px-4 py-12 max-w-3xl">
        {/* Meta */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            <Badge style={{ background: "oklch(0.65 0.07 145 / 0.12)", color: "#3D4A3E", border: "none" }}>
              {post.category}
            </Badge>
            <span className="flex items-center gap-1 text-xs" style={{ color: "oklch(0.62 0.04 145)" }}>
              <Clock className="w-3 h-3" />
              {post.readingTime} min de lecture
            </span>
            <span className="text-xs" style={{ color: "oklch(0.72 0.025 75)" }}>
              {date.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
            </span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-bold mb-4 leading-tight"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            {post.title}
          </h1>
          <p className="text-base leading-relaxed" style={{ color: "#6b7a6c" }}>
            {post.excerpt}
          </p>
          <div className="flex gap-2 mt-3 flex-wrap">
            {tags.map((tag: string) => (
              <span key={tag} className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                style={{ background: "oklch(0.93 0.018 80)", color: "#6b7a6c" }}>
                <Tag className="w-2.5 h-2.5" />{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Séparateur */}
        <hr className="thread-divider mb-8" />

        {/* Contenu */}
        <div
          className="rounded-2xl p-6 md:p-8"
          style={{
            background: "#e8e3da",
            boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.4), -3px -3px 8px oklch(1 0 0 / 0.6)",
          }}
        >
          {renderMarkdown(post.content)}
        </div>

        {/* CTA */}
        <div
          className="mt-8 rounded-2xl p-6 text-center"
          style={{
            background: "linear-gradient(135deg, oklch(0.62 0.12 40 / 0.06), oklch(0.65 0.07 145 / 0.06))",
            border: "1px solid oklch(0.62 0.12 40 / 0.1)",
          }}
        >
          <p className="font-semibold mb-1" style={{ color: "#3D4A3E" }}>
            Essayez ThreadFlow gratuitement pendant 30 jours
          </p>
          <p className="text-sm mb-4" style={{ color: "#6b7a6c" }}>
            Sans carte bancaire · iOS, Android & Web
          </p>
          <Link href="/#waitlist">
            <Button style={{ background: "#C4714A", color: "white" }}>
              Rejoindre la liste d'attente →
            </Button>
          </Link>
        </div>

        {/* Navigation entre articles */}
        <div className="mt-8 flex justify-between gap-4">
          <Link href="/blog">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Tous les articles
            </Button>
          </Link>
          <Link href="/demo">
            <Button
              className="gap-2"
              style={{ background: "#7A9E7E", color: "white" }}
            >
              Essayer la démo →
            </Button>
          </Link>
        </div>
      </article>
    </div>
  );
}

// ─── Router Blog ───────────────────────────────────────────────────────────────
export default function BlogRouter() {
  const [location] = useLocation();
  const match = location.match(/^\/blog\/(.+)$/);

  if (match) {
    return <BlogPost slug={match[1]} />;
  }
  return <BlogList />;
}
