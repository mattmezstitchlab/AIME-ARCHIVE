/*
 * ThreadFlow Demo — Grille de broderie interactive avec import PDF réel
 * PDF.js extrait les pixels du patron et les mappe vers la palette DMC
 */
import { useState, useCallback, useRef, useEffect } from "react";
import { Link } from "wouter";
import { ArrowLeft, Download, RotateCcw, ZoomIn, ZoomOut, Sparkles, Info, Upload, FileText, X, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { usePDFImport, DMC_COLORS } from "@/hooks/usePDFImport";
import SEOHead from "@/components/SEOHead";
import { toast } from "sonner";

// ─── Palette DMC pour l'affichage (hex) ───────────────────────────────────────
function oklchToHex(r: number, g: number, b: number): string {
  const toHex = (n: number) => Math.round(Math.max(0, Math.min(255, n))).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

const DMC_PALETTE: Record<string, { name: string; hex: string }> = Object.fromEntries(
  Object.entries(DMC_COLORS).map(([code, { r, g, b, name }]) => [
    code,
    { name, hex: oklchToHex(r, g, b) },
  ])
);

// ─── Patron "Rose Sauvage" 20×20 ──────────────────────────────────────────────
const INITIAL_PATTERN: (string | null)[][] = [
  [null,null,null,null,null,null,null,null,null,"3354","3354",null,null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null,"3354","3733","3733","3354",null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,"3354","3733","3731","3731","3733","3354",null,null,null,null,null,null,null],
  [null,null,null,null,null,null,"3354","3733","3731","3726","3726","3731","3733","3354",null,null,null,null,null,null],
  [null,null,null,null,null,"3354","3733","3731","3726","3727","3727","3726","3731","3733","3354",null,null,null,null,null],
  [null,null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null,null],
  [null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null],
  [null,null,"524","3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354","524",null,null],
  [null,"524","522","524","3354","3733","3731","3726","3727","3733","3733","3727","3726","3731","3733","3354","524","522","524",null],
  ["524","522","520","522","524","3354","3733","3731","3726","3727","3727","3726","3731","3733","3354","524","522","520","522","524"],
  ["524","522","520","522","524","3354","3733","3731","3726","3727","3727","3726","3731","3733","3354","524","522","520","522","524"],
  [null,"524","522","524","3354","3733","3731","3726","3727","3733","3733","3727","3726","3731","3733","3354","524","522","524",null],
  [null,null,"524","3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354","524",null,null],
  [null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null],
  [null,null,null,null,"3354","3733","3731","3726","3727","ECRU","ECRU","3727","3726","3731","3733","3354",null,null,null,null],
  [null,null,null,null,null,"3354","3733","3731","3726","3727","3727","3726","3731","3733","3354",null,null,null,null,null],
  [null,null,null,null,null,null,"3354","3733","3731","3726","3726","3731","3733","3354",null,null,null,null,null,null],
  [null,null,null,null,null,null,null,"3354","3733","3731","3731","3733","3354",null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null,"3354","3733","3733","3354",null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null,null,"3354","3354",null,null,null,null,null,null,null,null,null],
];

const DEFAULT_ROWS = 20;
const DEFAULT_COLS = 20;

// ─── Composant principal ───────────────────────────────────────────────────────
export default function Demo() {
  const [grid, setGrid] = useState<(string | null)[][]>(
    INITIAL_PATTERN.map(row => [...row])
  );
  const [rows, setRows] = useState(DEFAULT_ROWS);
  const [cols, setCols] = useState(DEFAULT_COLS);
  const [patternName, setPatternName] = useState("Rose Sauvage");
  const [selectedColor, setSelectedColor] = useState<string>("3731");
  const [tool, setTool] = useState<"paint" | "erase">("paint");
  const [zoom, setZoom] = useState<number>(28);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number } | null>(null);
  const [showSmartPath, setShowSmartPath] = useState(false);
  const [showPDFPanel, setShowPDFPanel] = useState(false);
  const [pdfGridSize, setPdfGridSize] = useState<{ rows: number; cols: number }>({ rows: 40, cols: 40 });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const { importPDF, status: pdfStatus, error: pdfError, progress: pdfProgress } = usePDFImport();

  // Compter les points remplis
  const filledCount = grid.flat().filter(Boolean).length;
  const totalPoints = rows * cols;

  // Couleurs présentes dans la grille
  const gridColors = Array.from(new Set(grid.flat().filter(Boolean) as string[]));
  const threadCounts: Record<string, number> = {};
  grid.flat().forEach(cell => {
    if (cell) threadCounts[cell] = (threadCounts[cell] || 0) + 1;
  });

  const paintCell = useCallback(
    (row: number, col: number) => {
      setGrid(prev => {
        const next = prev.map(r => [...r]);
        if (tool === "erase") {
          next[row][col] = null;
        } else {
          next[row][col] = selectedColor;
        }
        return next;
      });
    },
    [tool, selectedColor]
  );

  const handleMouseDown = (row: number, col: number) => {
    setIsDrawing(true);
    paintCell(row, col);
  };

  const handleMouseEnter = (row: number, col: number) => {
    setHoveredCell({ row, col });
    if (isDrawing) paintCell(row, col);
  };

  const handleMouseUp = () => setIsDrawing(false);

  const resetGrid = () => {
    setGrid(INITIAL_PATTERN.map(row => [...row]));
    setRows(DEFAULT_ROWS);
    setCols(DEFAULT_COLS);
    setPatternName("Rose Sauvage");
  };

  const loadEmptyGrid = () => {
    setGrid(Array.from({ length: rows }, () => Array(cols).fill(null)));
  };

  // ─── Import PDF réel ──────────────────────────────────────────────────────────
  const handleFileImport = useCallback(async (file: File) => {
    if (!file.type.includes("pdf")) {
      toast.error("Format non supporté. Veuillez importer un fichier PDF.");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error("Fichier trop volumineux (max 20 Mo).");
      return;
    }

    toast.info(`Import de "${file.name}" en cours...`);
    const result = await importPDF(file, pdfGridSize.rows, pdfGridSize.cols);

    if (result) {
      setGrid(result.grid);
      setRows(result.rows);
      setCols(result.cols);
      setPatternName(file.name.replace(".pdf", ""));
      setShowPDFPanel(false);
      toast.success(
        `✓ Patron importé — ${result.colorCount} couleurs DMC détectées sur ${result.rows}×${result.cols} points`
      );
    } else {
      toast.error("Impossible d'importer ce PDF. Vérifiez qu'il contient bien un patron de broderie.");
    }
  }, [importPDF, pdfGridSize]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileImport(file);
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileImport(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => setIsDragOver(false);

  // Smart Pathing — chemin optimal nearest-neighbor
  const getSmartPathOrder = (color: string): Array<[number, number]> => {
    const cells: Array<[number, number]> = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (grid[r]?.[c] === color) cells.push([r, c]);
      }
    }
    if (cells.length === 0) return [];
    const path: Array<[number, number]> = [cells[0]];
    const remaining = cells.slice(1);
    while (remaining.length > 0) {
      const last = path[path.length - 1];
      let minDist = Infinity;
      let minIdx = 0;
      remaining.forEach(([r, c], i) => {
        const dist = Math.abs(r - last[0]) + Math.abs(c - last[1]);
        if (dist < minDist) { minDist = dist; minIdx = i; }
      });
      path.push(remaining[minIdx]);
      remaining.splice(minIdx, 1);
    }
    return path;
  };

  const smartPath = showSmartPath ? getSmartPathOrder(selectedColor) : [];
  const smartPathSet = new Set(smartPath.map(([r, c]) => `${r}-${c}`));

  const exportAsPNG = () => {
    const canvas = document.createElement("canvas");
    const cellSize = 20;
    canvas.width = cols * cellSize;
    canvas.height = rows * cellSize;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#F5F0E8";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    grid.forEach((row, r) => {
      row.forEach((cell, c) => {
        if (cell && DMC_PALETTE[cell]) {
          ctx.fillStyle = DMC_PALETTE[cell].hex;
          ctx.fillRect(c * cellSize + 1, r * cellSize + 1, cellSize - 2, cellSize - 2);
          ctx.strokeStyle = "rgba(0,0,0,0.3)";
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(c * cellSize + 2, r * cellSize + 2);
          ctx.lineTo(c * cellSize + cellSize - 2, r * cellSize + cellSize - 2);
          ctx.moveTo(c * cellSize + cellSize - 2, r * cellSize + 2);
          ctx.lineTo(c * cellSize + 2, r * cellSize + cellSize - 2);
          ctx.stroke();
        }
      });
    });
    ctx.strokeStyle = "rgba(0,0,0,0.1)";
    ctx.lineWidth = 0.5;
    for (let r = 0; r <= rows; r++) {
      ctx.beginPath(); ctx.moveTo(0, r * cellSize); ctx.lineTo(cols * cellSize, r * cellSize); ctx.stroke();
    }
    for (let c = 0; c <= cols; c++) {
      ctx.beginPath(); ctx.moveTo(c * cellSize, 0); ctx.lineTo(c * cellSize, rows * cellSize); ctx.stroke();
    }
    const link = document.createElement("a");
    link.download = `threadflow-${patternName.toLowerCase().replace(/\s+/g, "-")}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div
      className="min-h-screen"
      style={{ background: "#e8e3da" }}
      onMouseUp={handleMouseUp}
    >
      <SEOHead
        title="Démo interactive — Grille de broderie point de croix"
        description="Essayez ThreadFlow gratuitement : brodez la Rose Sauvage en point de croix, importez votre propre patron PDF, activez le Smart Pathing™ et exportez votre création en PNG."
        url="/demo"
      />
      {/* Header */}
      <header
        className="sticky top-0 z-50 border-b"
        style={{
          background: "#e8e3daf2",
          borderColor: "oklch(0.88 0.025 75)",
          backdropFilter: "blur(12px)",
        }}
      >
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Retour
              </Button>
            </Link>
            <div className="h-5 w-px" style={{ background: "oklch(0.82 0.025 75)" }} />
            <div className="flex items-center gap-2">
              <span
                className="font-bold text-lg"
                style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
              >
                ThreadFlow
              </span>
              <Badge
                className="text-xs"
                style={{ background: "oklch(0.62 0.12 40 / 0.12)", color: "oklch(0.52 0.10 40)" }}
              >
                Démo interactive
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPDFPanel(p => !p)}
              className="gap-2 hidden sm:flex"
              style={{ color: showPDFPanel ? "#C4714A" : undefined }}
            >
              <Upload className="w-4 h-4" />
              Importer PDF
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setZoom(z => Math.max(12, z - 4))}
              title="Zoom arrière"
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-xs tabular-nums w-10 text-center" style={{ color: "#6b7a6c" }}>
              {zoom}px
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setZoom(z => Math.min(48, z + 4))}
              title="Zoom avant"
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={resetGrid} title="Réinitialiser">
              <RotateCcw className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              onClick={exportAsPNG}
              className="gap-2"
              style={{ background: "#C4714A", color: "white" }}
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exporter PNG</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Panneau import PDF */}
      {showPDFPanel && (
        <div
          className="border-b px-4 py-4"
          style={{
            background: "#F5F0E8",
            borderColor: "oklch(0.88 0.025 75)",
          }}
        >
          <div className="container mx-auto max-w-3xl">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-sm" style={{ color: "#3D4A3E" }}>
                  Importer un patron PDF
                </h3>
                <p className="text-xs mt-0.5" style={{ color: "#6b7a6c" }}>
                  ThreadFlow extrait les pixels du PDF et les convertit automatiquement en codes DMC.
                  Fonctionne avec tous les patrons PDF couleur (PCStitch, Stitch Fiddle, etc.)
                </p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowPDFPanel(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* Taille de grille cible */}
            <div className="flex items-center gap-4 mb-3">
              <span className="text-xs font-medium" style={{ color: "#6b7a6c" }}>
                Résolution :
              </span>
              {[
                { label: "20×20", rows: 20, cols: 20 },
                { label: "40×40", rows: 40, cols: 40 },
                { label: "60×60", rows: 60, cols: 60 },
                { label: "80×80", rows: 80, cols: 80 },
              ].map(opt => (
                <button
                  key={opt.label}
                  onClick={() => setPdfGridSize({ rows: opt.rows, cols: opt.cols })}
                  className="text-xs px-3 py-1 rounded-lg transition-all"
                  style={{
                    background: pdfGridSize.rows === opt.rows
                      ? "#C4714A"
                      : "oklch(0.93 0.018 80)",
                    color: pdfGridSize.rows === opt.rows ? "white" : "#6b7a6c",
                  }}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Zone de drop */}
            <div
              ref={dropZoneRef}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all"
              style={{
                borderColor: isDragOver
                  ? "#C4714A"
                  : "oklch(0.82 0.025 75)",
                background: isDragOver
                  ? "oklch(0.62 0.12 40 / 0.05)"
                  : "#e8e3da",
              }}
            >
              {pdfStatus === "loading" ? (
                <div className="space-y-3">
                  <div className="text-sm font-medium" style={{ color: "#6b7a6c" }}>
                    Extraction en cours... {pdfProgress}%
                  </div>
                  <div
                    className="h-2 rounded-full overflow-hidden mx-auto max-w-xs"
                    style={{ background: "oklch(0.88 0.025 75)" }}
                  >
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${pdfProgress}%`,
                        background: "linear-gradient(90deg, #7A9E7E, #C4714A)",
                      }}
                    />
                  </div>
                  <p className="text-xs" style={{ color: "oklch(0.62 0.04 145)" }}>
                    Analyse des pixels et correspondance DMC...
                  </p>
                </div>
              ) : pdfStatus === "error" ? (
                <div className="space-y-2">
                  <AlertCircle className="w-8 h-8 mx-auto" style={{ color: "oklch(0.55 0.18 25)" }} />
                  <p className="text-sm font-medium" style={{ color: "oklch(0.35 0.12 25)" }}>
                    {pdfError}
                  </p>
                  <p className="text-xs" style={{ color: "#6b7a6c" }}>
                    Cliquez pour réessayer avec un autre fichier
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <FileText className="w-10 h-10 mx-auto" style={{ color: "oklch(0.72 0.025 75)" }} />
                  <p className="text-sm font-medium" style={{ color: "#3D4A3E" }}>
                    Glissez votre patron PDF ici
                  </p>
                  <p className="text-xs" style={{ color: "oklch(0.62 0.04 145)" }}>
                    ou cliquez pour sélectionner un fichier · PDF couleur · max 20 Mo
                  </p>
                </div>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,application/pdf"
              className="hidden"
              onChange={handleFileInput}
            />
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 py-6 flex gap-6 flex-col lg:flex-row">
        {/* Panneau gauche — Outils */}
        <aside className="lg:w-64 flex-shrink-0 space-y-4">
          {/* Stats */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: "#e8e3da",
              boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
            }}
          >
            <h3
              className="font-semibold mb-3 text-sm uppercase tracking-wide"
              style={{ color: "#6b7a6c" }}
            >
              Progression
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span style={{ color: "#6b7a6c" }}>Points brodés</span>
                <span className="font-bold" style={{ color: "#C4714A" }}>
                  {filledCount} / {totalPoints}
                </span>
              </div>
              <div
                className="h-2 rounded-full overflow-hidden"
                style={{ background: "oklch(0.88 0.025 75)" }}
              >
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${totalPoints > 0 ? (filledCount / totalPoints) * 100 : 0}%`,
                    background: "linear-gradient(90deg, #7A9E7E, #C4714A)",
                  }}
                />
              </div>
              <div className="text-xs" style={{ color: "oklch(0.62 0.04 145)" }}>
                {totalPoints > 0 ? Math.round((filledCount / totalPoints) * 100) : 0}% complété
              </div>
            </div>
          </div>

          {/* Outils */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: "#e8e3da",
              boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
            }}
          >
            <h3
              className="font-semibold mb-3 text-sm uppercase tracking-wide"
              style={{ color: "#6b7a6c" }}
            >
              Outil
            </h3>
            <div className="flex gap-2">
              <button
                onClick={() => setTool("paint")}
                className="flex-1 py-2 rounded-xl text-sm font-medium transition-all"
                style={{
                  background: tool === "paint" ? "#C4714A" : "oklch(0.93 0.018 80)",
                  color: tool === "paint" ? "white" : "#6b7a6c",
                }}
              >
                ✕ Broder
              </button>
              <button
                onClick={() => setTool("erase")}
                className="flex-1 py-2 rounded-xl text-sm font-medium transition-all"
                style={{
                  background: tool === "erase" ? "#C4714A" : "oklch(0.93 0.018 80)",
                  color: tool === "erase" ? "white" : "#6b7a6c",
                }}
              >
                ○ Effacer
              </button>
            </div>
          </div>

          {/* Smart Pathing */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: showSmartPath ? "oklch(0.65 0.07 145 / 0.08)" : "#e8e3da",
              boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
              border: showSmartPath ? "1px solid oklch(0.65 0.07 145 / 0.3)" : "1px solid transparent",
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" style={{ color: "#7A9E7E" }} />
                <h3 className="font-semibold text-sm" style={{ color: "#6b7a6c" }}>
                  Smart Pathing™
                </h3>
              </div>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="w-3.5 h-3.5" style={{ color: "oklch(0.62 0.04 145)" }} />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-48 text-xs">
                    Affiche l'ordre optimal pour broder la couleur sélectionnée en minimisant les déplacements à l'arrière du tissu.
                  </p>
                </TooltipContent>
              </Tooltip>
            </div>
            <button
              onClick={() => setShowSmartPath(p => !p)}
              className="w-full py-2 rounded-xl text-sm font-medium transition-all"
              style={{
                background: showSmartPath ? "#7A9E7E" : "oklch(0.93 0.018 80)",
                color: showSmartPath ? "white" : "#6b7a6c",
              }}
            >
              {showSmartPath ? "Désactiver" : "Activer le chemin"}
            </button>
            {showSmartPath && smartPath.length > 0 && (
              <p className="text-xs mt-2" style={{ color: "oklch(0.52 0.07 145)" }}>
                {smartPath.length} points — économie estimée ≈{" "}
                <strong>{Math.round(smartPath.length * 0.8)} cm</strong> de fil
              </p>
            )}
          </div>

          {/* Palette de couleurs — dynamique selon la grille */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: "#e8e3da",
              boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
            }}
          >
            <h3
              className="font-semibold mb-3 text-sm uppercase tracking-wide"
              style={{ color: "#6b7a6c" }}
            >
              Palette DMC ({gridColors.length} couleurs)
            </h3>
            <div className="space-y-1.5 max-h-64 overflow-y-auto">
              {gridColors.map(code => (
                <button
                  key={code}
                  onClick={() => { setSelectedColor(code); setTool("paint"); }}
                  className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl text-xs transition-all"
                  style={{
                    background: selectedColor === code ? "oklch(0.62 0.12 40 / 0.1)" : "transparent",
                    border: selectedColor === code
                      ? "1px solid #C4714A4d"
                      : "1px solid transparent",
                  }}
                >
                  <span
                    className="w-5 h-5 rounded-md flex-shrink-0 border"
                    style={{
                      background: DMC_PALETTE[code]?.hex ?? "#ccc",
                      borderColor: "oklch(0.82 0.025 75)",
                      boxShadow: selectedColor === code ? `0 0 0 2px #C4714A66` : "none",
                    }}
                  />
                  <span className="flex-1 text-left truncate" style={{ color: "#3D4A3E" }}>
                    DMC {code}
                    {DMC_PALETTE[code]?.name && (
                      <span className="ml-1 opacity-60">{DMC_PALETTE[code].name}</span>
                    )}
                  </span>
                  {threadCounts[code] && (
                    <span
                      className="text-xs font-medium px-1.5 py-0.5 rounded-full flex-shrink-0"
                      style={{ background: "oklch(0.88 0.025 75)", color: "#6b7a6c" }}
                    >
                      {threadCounts[code]}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Patrons */}
          <div
            className="rounded-2xl p-4"
            style={{
              background: "#e8e3da",
              boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.5), -3px -3px 8px oklch(1 0 0 / 0.7)",
            }}
          >
            <h3
              className="font-semibold mb-3 text-sm uppercase tracking-wide"
              style={{ color: "#6b7a6c" }}
            >
              Patrons
            </h3>
            <div className="space-y-2">
              <button
                onClick={resetGrid}
                className="w-full text-left px-3 py-2 rounded-xl text-sm transition-all"
                style={{
                  background: "oklch(0.65 0.07 145 / 0.1)",
                  color: "#3D4A3E",
                  border: "1px solid oklch(0.65 0.07 145 / 0.2)",
                }}
              >
                🌹 Rose Sauvage (20×20)
              </button>
              <button
                onClick={loadEmptyGrid}
                className="w-full text-left px-3 py-2 rounded-xl text-sm transition-all"
                style={{
                  background: "oklch(0.93 0.018 80)",
                  color: "#6b7a6c",
                }}
              >
                ⬜ Grille vierge ({rows}×{cols})
              </button>
              <button
                onClick={() => setShowPDFPanel(p => !p)}
                className="w-full text-left px-3 py-2 rounded-xl text-sm transition-all flex items-center gap-2"
                style={{
                  background: "oklch(0.62 0.12 40 / 0.08)",
                  color: "oklch(0.52 0.10 40)",
                  border: "1px solid #C4714A33",
                }}
              >
                <Upload className="w-3.5 h-3.5" />
                Importer un PDF
              </button>
            </div>
          </div>
        </aside>

        {/* Zone principale — Grille */}
        <main className="flex-1 min-w-0">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h1
                className="text-2xl font-bold"
                style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
              >
                {patternName}
              </h1>
              <p className="text-sm" style={{ color: "#6b7a6c" }}>
                Patron point de croix · {rows}×{cols} points · {gridColors.length} couleurs DMC
              </p>
            </div>
            {hoveredCell && (
              <div
                className="text-xs px-3 py-1.5 rounded-full"
                style={{ background: "oklch(0.88 0.025 75)", color: "#6b7a6c" }}
              >
                Col {hoveredCell.col + 1}, Ligne {hoveredCell.row + 1}
                {grid[hoveredCell.row]?.[hoveredCell.col] && (
                  <> · DMC {grid[hoveredCell.row][hoveredCell.col]}</>
                )}
              </div>
            )}
          </div>

          {/* Grille de broderie */}
          <div
            className="overflow-auto rounded-2xl p-4"
            style={{
              background: "#e8e3da",
              boxShadow: "6px 6px 16px oklch(0.82 0.025 75 / 0.5), -4px -4px 12px oklch(1 0 0 / 0.7)",
            }}
          >
            {/* Numéros de colonnes */}
            <div className="flex mb-1 ml-6">
              {Array.from({ length: cols }, (_, c) => (
                <div
                  key={c}
                  className="flex-shrink-0 text-center text-xs select-none"
                  style={{
                    width: zoom,
                    color: "oklch(0.72 0.025 75)",
                    fontSize: zoom < 24 ? "8px" : "10px",
                  }}
                >
                  {(c + 1) % 5 === 0 ? c + 1 : ""}
                </div>
              ))}
            </div>

            <div
              ref={gridRef}
              className="select-none"
              style={{ cursor: tool === "erase" ? "cell" : "crosshair" }}
            >
              {grid.map((row, r) => (
                <div key={r} className="flex items-center">
                  <div
                    className="flex-shrink-0 text-right pr-1 text-xs select-none"
                    style={{
                      width: 20,
                      color: "oklch(0.72 0.025 75)",
                      fontSize: zoom < 24 ? "8px" : "10px",
                    }}
                  >
                    {(r + 1) % 5 === 0 ? r + 1 : ""}
                  </div>
                  {row.map((cell, c) => {
                    const isSmartPath = smartPathSet.has(`${r}-${c}`);
                    const pathIndex = smartPath.findIndex(([pr, pc]) => pr === r && pc === c);
                    const isHovered = hoveredCell?.row === r && hoveredCell?.col === c;

                    return (
                      <div
                        key={c}
                        className="flex-shrink-0 relative transition-all duration-75"
                        style={{
                          width: zoom,
                          height: zoom,
                          background: cell
                            ? DMC_PALETTE[cell]?.hex ?? "#ccc"
                            : isHovered && tool === "paint"
                            ? (DMC_PALETTE[selectedColor]?.hex ?? "#ccc") + "55"
                            : "transparent",
                          border: `0.5px solid oklch(0.82 0.025 75 / ${zoom < 20 ? 0.3 : 0.5})`,
                          boxShadow: isSmartPath
                            ? `inset 0 0 0 2px #7A9E7E`
                            : isHovered
                            ? `inset 0 0 0 1.5px #C4714A`
                            : "none",
                          cursor: tool === "erase" ? "cell" : "crosshair",
                        }}
                        onMouseDown={() => handleMouseDown(r, c)}
                        onMouseEnter={() => handleMouseEnter(r, c)}
                      >
                        {cell && zoom >= 20 && (
                          <svg
                            viewBox="0 0 10 10"
                            className="absolute inset-0 w-full h-full"
                            style={{ opacity: 0.5 }}
                          >
                            <line x1="1.5" y1="1.5" x2="8.5" y2="8.5" stroke="rgba(0,0,0,0.35)" strokeWidth="1.2" strokeLinecap="round" />
                            <line x1="8.5" y1="1.5" x2="1.5" y2="8.5" stroke="rgba(0,0,0,0.35)" strokeWidth="1.2" strokeLinecap="round" />
                          </svg>
                        )}
                        {isSmartPath && zoom >= 28 && (
                          <span
                            className="absolute inset-0 flex items-center justify-center text-white font-bold"
                            style={{ fontSize: zoom * 0.3, textShadow: "0 1px 2px rgba(0,0,0,0.5)" }}
                          >
                            {pathIndex + 1}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>

          {/* Inventaire de fils */}
          {Object.keys(threadCounts).length > 0 && (
            <div
              className="mt-4 rounded-2xl p-4"
              style={{
                background: "#e8e3da",
                boxShadow: "4px 4px 12px oklch(0.82 0.025 75 / 0.4), -3px -3px 8px oklch(1 0 0 / 0.6)",
              }}
            >
              <h3
                className="font-semibold mb-3 text-sm"
                style={{ color: "#6b7a6c" }}
              >
                Inventaire de fils nécessaires
              </h3>
              <div className="flex flex-wrap gap-2">
                {Object.entries(threadCounts)
                  .sort(([, a], [, b]) => b - a)
                  .map(([code, count]) => (
                    <div
                      key={code}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs"
                      style={{ background: "oklch(0.93 0.018 80)", color: "#3D4A3E" }}
                    >
                      <span
                        className="w-3 h-3 rounded-sm"
                        style={{ background: DMC_PALETTE[code]?.hex ?? "#ccc" }}
                      />
                      <span className="font-medium">DMC {code}</span>
                      <span style={{ color: "#6b7a6c" }}>
                        · {count} pts · ~{Math.ceil(count * 0.4)} cm
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* CTA vers l'app */}
          <div
            className="mt-4 rounded-2xl p-5 flex items-center justify-between"
            style={{
              background: "linear-gradient(135deg, oklch(0.62 0.12 40 / 0.08), oklch(0.65 0.07 145 / 0.08))",
              border: "1px solid oklch(0.62 0.12 40 / 0.15)",
            }}
          >
            <div>
              <p className="font-semibold text-sm" style={{ color: "#3D4A3E" }}>
                Vous aimez la démo ?
              </p>
              <p className="text-xs mt-0.5" style={{ color: "#6b7a6c" }}>
                La vraie app ThreadFlow inclut le scan IA de vos fils DMC, la synchronisation multi-appareils, et le Stitch Diary™.
              </p>
            </div>
            <Link href="/#waitlist">
              <Button
                size="sm"
                className="ml-4 flex-shrink-0"
                style={{ background: "#C4714A", color: "white" }}
              >
                Rejoindre la bêta →
              </Button>
            </Link>
          </div>
        </main>
      </div>
    </div>
  );
}
