/*
 * ThreadFlow — Page d'accueil principale
 * Assemblage de toutes les sections dans l'ordre narratif optimal
 * Design: Neumorphisme Artisanal "Tissu Numérique"
 */
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AhaMomentSection from "@/components/AhaMomentSection";
import FeaturesSection from "@/components/FeaturesSection";
import RetentionSection from "@/components/RetentionSection";
import CommunitySection from "@/components/CommunitySection";
import ComparisonSection from "@/components/ComparisonSection";
import ManifestoSection from "@/components/ManifestoSection";
import PricingSection from "@/components/PricingSection";
import LaunchSection from "@/components/LaunchSection";
import WaitlistSection from "@/components/WaitlistSection";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";

export default function Home() {
  return (
    <div className="min-h-screen">
      <SEOHead url="/" />
      <Navbar />
      <main>
        <HeroSection />
        <AhaMomentSection />
        <FeaturesSection />
        <RetentionSection />
        <CommunitySection />
        <ComparisonSection />
        <ManifestoSection />
        <PricingSection />
        <LaunchSection />
        <WaitlistSection />
      </main>
      <Footer />
    </div>
  );
}
