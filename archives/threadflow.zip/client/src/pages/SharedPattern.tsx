/**
 * SharedPattern — Page publique pour visualiser un patron partagé via lien unique
 * Route : /patron/:token
 * Accessible sans authentification (lecture seule)
 *
 * Flux :
 *  1. Chargement du patron (getByShareToken)
 *  2. Formulaire de bienvenue (nom + emoji) — stocké en localStorage
 *  3. Enregistrement de la vue (recordShareView) → notification à la propriétaire
 *  4. Affichage du patron en lecture seule
 */
import { useEffect, useRef, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2, AlertCircle, ExternalLink, Copy, Check, Scissors } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import type { GridCell } from "@/lib/stitchTypes";

// ─── Constantes ───────────────────────────────────────────────────────────────
const VIEWER_EMOJIS = ['🧵', '🪡', '🌿', '🌸', '🌻', '🌼', '🦋', '🐝', '✨', '🌟', '🎀', '🍃'];
const LS_KEY = "threadflow_viewer_identity";

interface ViewerIdentity {
  name: string;
  emoji: string;
}

function loadIdentity(): ViewerIdentity | null {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as ViewerIdentity;
  } catch {
    return null;
  }
}

function saveIdentity(identity: ViewerIdentity) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(identity));
  } catch {
    // Silencieux si localStorage indisponible
  }
}

// ─── Mini-rendu de la grille (lecture seule) ──────────────────────────────────
function ReadOnlyGrid({ gridData, width, height }: { gridData: string; width: number; height: number }) {
  let grid: GridCell[][] = [];
  try {
    grid = JSON.parse(gridData) as GridCell[][];
  } catch {
    return <div className="text-sm text-red-500">Données de grille invalides</div>;
  }

  const cellSize = Math.max(6, Math.min(20, Math.floor(600 / Math.max(width, height))));

  return (
    <div
      className="inline-block border rounded-xl overflow-hidden shadow-inner"
      style={{ background: "#F5F0E8", borderColor: "#d4c5a9" }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: `repeat(${width}, ${cellSize}px)`,
          gridTemplateRows: `repeat(${height}, ${cellSize}px)`,
        }}
      >
        {Array.from({ length: height }, (_, r) =>
          Array.from({ length: width }, (_, c) => {
            const cell = grid[r]?.[c];
            const hex = cell?.hex ?? null;
            return (
              <div
                key={`${r}-${c}`}
                style={{
                  width: cellSize,
                  height: cellSize,
                  background: hex ?? "transparent",
                  borderRight: "0.5px solid rgba(0,0,0,0.06)",
                  borderBottom: "0.5px solid rgba(0,0,0,0.06)",
                }}
              />
            );
          })
        )}
      </div>
    </div>
  );
}

// ─── Formulaire de bienvenue ──────────────────────────────────────────────────
interface WelcomeFormProps {
  patternName: string;
  onSubmit: (name: string, emoji: string) => void;
  isLoading: boolean;
}

function WelcomeForm({ patternName, onSubmit, isLoading }: WelcomeFormProps) {
  const [name, setName] = useState("");
  const [selectedEmoji, setSelectedEmoji] = useState(VIEWER_EMOJIS[0]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      toast.error("Veuillez entrer votre prénom pour accéder au patron.");
      return;
    }
    onSubmit(trimmed, selectedEmoji);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4" style={{ background: "#F5F0E8" }}>
      {/* Logo */}
      <div className="mb-8 flex items-center gap-2">
        <Scissors className="w-6 h-6" style={{ color: "#7A9E7E" }} />
        <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, color: "#3D4A3E", fontWeight: 600 }}>
          ThreadFlow
        </span>
      </div>

      {/* Carte de bienvenue */}
      <div
        className="w-full max-w-md rounded-2xl p-8"
        style={{
          background: "white",
          border: "1px solid #d4c5a9",
          boxShadow: "0 8px 32px rgba(61,74,62,0.12)",
        }}
      >
        <div className="text-center mb-6">
          <div className="text-4xl mb-3">🧵</div>
          <h1
            className="text-2xl font-semibold mb-2"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            Vous êtes invitée !
          </h1>
          <p className="text-sm" style={{ color: "#6b7a6c" }}>
            Une brodeuse partage son patron{" "}
            <span className="font-medium" style={{ color: "#3D4A3E" }}>
              « {patternName} »
            </span>{" "}
            avec vous.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Champ prénom */}
          <div>
            <label
              htmlFor="viewer-name"
              className="block text-sm font-medium mb-1.5"
              style={{ color: "#3D4A3E" }}
            >
              Votre prénom <span style={{ color: "#C4714A" }}>*</span>
            </label>
            <Input
              id="viewer-name"
              ref={inputRef}
              type="text"
              placeholder="Ex : Marie, Sophie, Léa…"
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 50))}
              maxLength={50}
              required
              style={{
                borderColor: "#d4c5a9",
                background: "#faf8f5",
                color: "#3D4A3E",
              }}
            />
            <p className="text-xs mt-1" style={{ color: "#9aaa9b" }}>
              Votre prénom sera visible par la créatrice du patron.
            </p>
          </div>

          {/* Sélecteur d'emoji */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: "#3D4A3E" }}>
              Choisissez votre emoji
            </label>
            <div className="flex flex-wrap gap-2">
              {VIEWER_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setSelectedEmoji(emoji)}
                  className="w-10 h-10 rounded-xl text-xl flex items-center justify-center transition-all"
                  style={{
                    background: selectedEmoji === emoji ? "#7A9E7E" : "#e8e3da",
                    border: selectedEmoji === emoji ? "2px solid #5a7e5e" : "2px solid transparent",
                    transform: selectedEmoji === emoji ? "scale(1.15)" : "scale(1)",
                    boxShadow: selectedEmoji === emoji ? "0 2px 8px rgba(122,158,126,0.4)" : "none",
                  }}
                  aria-label={`Choisir l'emoji ${emoji}`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Bouton de soumission */}
          <Button
            type="submit"
            className="w-full"
            disabled={isLoading || !name.trim()}
            style={{
              background: name.trim() ? "#7A9E7E" : "#d4c5a9",
              color: "white",
              border: "none",
              height: 44,
              fontSize: 15,
              fontWeight: 600,
            }}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Chargement…
              </>
            ) : (
              <>
                {selectedEmoji} Accéder au patron
              </>
            )}
          </Button>
        </form>
      </div>

      {/* Note de confidentialité */}
      <p className="mt-4 text-xs text-center max-w-xs" style={{ color: "#9aaa9b" }}>
        Aucun compte requis. Votre prénom est uniquement partagé avec la créatrice du patron.
      </p>
    </div>
  );
}

// ─── Page principale ──────────────────────────────────────────────────────────
export default function SharedPattern() {
  const [, params] = useRoute("/patron/:token");
  const [, navigate] = useLocation();
  const token = params?.token ?? "";
  const [copied, setCopied] = useState(false);

  // Identité de la visiteuse (nom + emoji)
  const [identity, setIdentity] = useState<ViewerIdentity | null>(() => loadIdentity());
  const [hasRecordedView, setHasRecordedView] = useState(false);

  // Chargement du patron (toujours actif pour afficher le nom dans le formulaire)
  const { data, isLoading, error } = trpc.grids.getByShareToken.useQuery(
    { token },
    { enabled: !!token, retry: false }
  );

  const recordViewMutation = trpc.grids.recordShareView.useMutation({
    onSuccess: (result) => {
      if (result.isFirstVisit) {
        // Première visite : la notification a été envoyée à la propriétaire
        console.info("[ThreadFlow] Première visite enregistrée, notification envoyée.");
      }
    },
    onError: () => {
      // Silencieux — ne pas bloquer l'accès au patron
    },
  });

  // Enregistrer la vue dès que l'identité est connue et le patron chargé
  useEffect(() => {
    if (data && token && identity && !hasRecordedView) {
      recordViewMutation.mutate({
        shareToken: token,
        viewerName: identity.name,
        viewerEmoji: identity.emoji,
      });
      setHasRecordedView(true);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, token, identity]);

  const handleWelcomeSubmit = (name: string, emoji: string) => {
    const newIdentity: ViewerIdentity = { name, emoji };
    saveIdentity(newIdentity);
    setIdentity(newIdentity);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    toast.success("Lien copié !");
    setTimeout(() => setCopied(false), 2000);
  };

  // ── Cas : token manquant ────────────────────────────────────────────────────
  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#F5F0E8" }}>
        <div className="text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: "#C4714A" }} />
          <p style={{ color: "#3D4A3E", fontFamily: "'Cormorant Garamond', serif", fontSize: 20 }}>
            Lien de partage invalide
          </p>
        </div>
      </div>
    );
  }

  // ── Cas : chargement ────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#F5F0E8" }}>
        <div className="text-center">
          <Loader2 className="w-10 h-10 animate-spin mx-auto mb-4" style={{ color: "#7A9E7E" }} />
          <p className="text-sm" style={{ color: "#6b7a6c" }}>Chargement du patron…</p>
        </div>
      </div>
    );
  }

  // ── Cas : patron introuvable ────────────────────────────────────────────────
  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#F5F0E8" }}>
        <div className="text-center max-w-sm px-6">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: "#C4714A" }} />
          <h2 className="text-xl font-semibold mb-2" style={{ color: "#3D4A3E", fontFamily: "'Cormorant Garamond', serif" }}>
            Patron introuvable
          </h2>
          <p className="text-sm mb-6" style={{ color: "#6b7a6c" }}>
            Ce lien de partage est invalide ou a expiré. Demandez un nouveau lien à la créatrice du patron.
          </p>
          <Button
            onClick={() => navigate("/")}
            style={{ background: "#7A9E7E", color: "white", border: "none" }}
          >
            Retour à l'accueil
          </Button>
        </div>
      </div>
    );
  }

  // ── Cas : formulaire de bienvenue (identité non encore saisie) ──────────────
  if (!identity) {
    return (
      <WelcomeForm
        patternName={data.grid.name || "Patron sans titre"}
        onSubmit={handleWelcomeSubmit}
        isLoading={recordViewMutation.isPending}
      />
    );
  }

  // ── Affichage du patron ─────────────────────────────────────────────────────
  const { grid } = data;
  const colorCount = grid.gridData
    ? (() => {
        try {
          const g = JSON.parse(grid.gridData) as GridCell[][];
          const colors = new Set<string>();
          g.forEach(row => row.forEach(cell => { if (cell?.dmc) colors.add(cell.dmc); }));
          return colors.size;
        } catch { return 0; }
      })()
    : 0;

  return (
    <div className="min-h-screen" style={{ background: "#F5F0E8" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 px-6 py-4 flex items-center justify-between"
        style={{ background: "#F5F0E8", borderBottom: "1px solid #d4c5a9", boxShadow: "0 2px 8px rgba(61,74,62,0.08)" }}
      >
        <div className="flex items-center gap-3">
          <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, color: "#3D4A3E", fontWeight: 600 }}>
            ThreadFlow
          </span>
          <Badge style={{ background: "#e8e3da", color: "#6b7a6c", border: "1px solid #d4c5a9", fontSize: 11 }}>
            Patron partagé
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          {/* Identité de la visiteuse */}
          <div
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm"
            style={{ background: "#e8e3da", color: "#3D4A3E" }}
          >
            <span>{identity.emoji}</span>
            <span className="font-medium">{identity.name}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopyLink}
            style={{ color: "#6b7a6c" }}
          >
            {copied ? <Check className="w-4 h-4 mr-1.5" /> : <Copy className="w-4 h-4 mr-1.5" />}
            {copied ? "Copié !" : "Copier le lien"}
          </Button>
          <Button
            size="sm"
            onClick={() => navigate("/app/editor")}
            style={{ background: "#7A9E7E", color: "white", border: "none" }}
          >
            <ExternalLink className="w-4 h-4 mr-1.5" />
            Ouvrir dans l'éditeur
          </Button>
        </div>
      </header>

      {/* Contenu principal */}
      <main className="max-w-4xl mx-auto px-6 py-10">
        {/* Titre du patron */}
        <div className="mb-8 text-center">
          <h1
            className="text-4xl font-semibold mb-3"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            {grid.name || "Patron sans titre"}
          </h1>
          <div className="flex items-center justify-center gap-4 text-sm" style={{ color: "#6b7a6c" }}>
            <span>{grid.width} × {grid.height} points</span>
            <span>·</span>
            <span>{colorCount} couleur{colorCount !== 1 ? "s" : ""} DMC</span>
          </div>
        </div>

        {/* Grille en lecture seule */}
        <div className="flex justify-center mb-10">
          {grid.gridData ? (
            <ReadOnlyGrid gridData={grid.gridData} width={grid.width} height={grid.height} />
          ) : (
            <div
              className="flex items-center justify-center rounded-xl"
              style={{ width: 300, height: 300, background: "#e8e3da", border: "1px solid #d4c5a9", color: "#9aaa9b" }}
            >
              Grille vide
            </div>
          )}
        </div>

        {/* CTA inscription */}
        <div
          className="rounded-2xl p-8 text-center"
          style={{ background: "white", border: "1px solid #d4c5a9", boxShadow: "0 4px 20px rgba(61,74,62,0.08)" }}
        >
          <h2
            className="text-2xl font-semibold mb-3"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#3D4A3E" }}
          >
            Envie de créer vos propres patrons ?
          </h2>
          <p className="text-sm mb-6 max-w-sm mx-auto" style={{ color: "#6b7a6c" }}>
            ThreadFlow est l'outil de broderie point de croix qui transforme vos idées en patrons DMC en quelques secondes, grâce à l'IA.
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Button
              onClick={() => navigate("/")}
              style={{ background: "#C4714A", color: "white", border: "none" }}
            >
              Découvrir ThreadFlow
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/app/editor")}
              style={{ borderColor: "#d4c5a9", color: "#3D4A3E" }}
            >
              Essayer l'éditeur
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
