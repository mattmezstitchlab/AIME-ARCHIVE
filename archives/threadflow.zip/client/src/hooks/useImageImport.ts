/*
 * useImageImport — Importe PNG, JPEG ou PDF et les convertit en grille DMC
 * PNG/JPEG : traitement direct via canvas
 * PDF : utilise PDF.js pour rendre la page choisie (avec sélecteur de page)
 *        + détection automatique des pages de grille par analyse pixel
 */
import { useState, useCallback } from "react";
import { DMC_COLORS } from "./usePDFImport";

export type ImportResult = {
  grid: (string | null)[][];
  rows: number;
  cols: number;
  colorCount: number;
  fileName: string;
};

export type ImportStatus = "idle" | "loading" | "success" | "error";

/** Miniature d'une page PDF avec score de détection de grille */
export type PdfPagePreview = {
  pageNum: number;
  dataUrl: string;
  /** Score de 0 à 1 indiquant la probabilité que cette page soit une grille de broderie */
  gridScore: number;
  /** true si cette page est détectée comme une grille candidate */
  isGridCandidate: boolean;
};

// Trouver la couleur DMC la plus proche (distance euclidienne RGB)
function findClosestDMC(r: number, g: number, b: number): string {
  let minDist = Infinity;
  let closest = "blanc";
  for (const [code, color] of Object.entries(DMC_COLORS)) {
    const dist =
      (r - color.r) * (r - color.r) +
      (g - color.g) * (g - color.g) +
      (b - color.b) * (b - color.b);
    if (dist < minDist) {
      minDist = dist;
      closest = code;
    }
  }
  return closest;
}

// Convertir un ImageData en grille DMC
function imageDataToGrid(
  imageData: ImageData,
  targetRows: number,
  targetCols: number
): (string | null)[][] {
  const { data, width, height } = imageData;
  const cellW = width / targetCols;
  const cellH = height / targetRows;
  const grid: (string | null)[][] = [];

  for (let row = 0; row < targetRows; row++) {
    const gridRow: (string | null)[] = [];
    for (let col = 0; col < targetCols; col++) {
      let rSum = 0, gSum = 0, bSum = 0, aSum = 0, count = 0;
      const x0 = Math.floor(col * cellW);
      const y0 = Math.floor(row * cellH);
      const x1 = Math.min(Math.ceil((col + 1) * cellW), width);
      const y1 = Math.min(Math.ceil((row + 1) * cellH), height);
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const idx = (y * width + x) * 4;
          rSum += data[idx]!;
          gSum += data[idx + 1]!;
          bSum += data[idx + 2]!;
          aSum += data[idx + 3]!;
          count++;
        }
      }
      const alpha = count > 0 ? aSum / count : 0;
      if (alpha < 30) {
        gridRow.push(null);
      } else {
        const r = rSum / count;
        const g = gSum / count;
        const b = bSum / count;
        // Ignorer les pixels quasi-blancs (fond)
        if (r > 245 && g > 245 && b > 245) {
          gridRow.push(null);
        } else {
          gridRow.push(findClosestDMC(r, g, b));
        }
      }
    }
    grid.push(gridRow);
  }

  return grid;
}

/**
 * Analyse un canvas rendu pour estimer si la page est une grille de broderie.
 *
 * Algorithme v2 — compatible patrons N&B ET patrons en couleur :
 *
 * Critère A — Structure de grille (indépendant de la palette) :
 *   Divise l'image en blocs de ~8px et mesure la variance intra-bloc.
 *   Une grille a des blocs de couleur uniforme (variance faible) avec des
 *   transitions abruptes entre blocs (bords nets). Une photo a des gradients
 *   continus (variance intra-bloc élevée, peu de bords nets).
 *
 * Critère B — Palette limitée et discrète :
 *   Un patron de broderie a 5-80 couleurs distinctes bien séparées.
 *   Une photo en a des milliers avec des nuances continues.
 *   On quantifie en 64 niveaux (réduction 2 bits/canal) et on compte les
 *   couleurs uniques : une distribution picée = patron, une distribution plate = photo.
 *
 * Critère C — Fond clair dominant (commun N&B et couleur) :
 *   Les patrons ont généralement un fond blanc ou très clair.
 *
 * Critère D — Présence de lignes de grille :
 *   Détecte les lignes horizontales/verticales de pixels sombres répétitifs
 *   (lignes de séparation de cellules).
 *
 * Retourne un score de 0 à 1.
 */
function scoreGridPage(canvas: HTMLCanvasElement): number {
  const ctx = canvas.getContext("2d");
  if (!ctx) return 0;

  const w = canvas.width;
  const h = canvas.height;
  if (w < 10 || h < 10) return 0;

  const imageData = ctx.getImageData(0, 0, w, h);
  const data = imageData.data;
  const totalPixels = w * h;

  // ─── Critère A : Uniformité intra-bloc (blocs de 8px) ───────────────────────
  // Un patron a des blocs uniformes. On mesure la variance moyenne des blocs.
  const BLOCK = 8;
  const bCols = Math.floor(w / BLOCK);
  const bRows = Math.floor(h / BLOCK);
  let totalBlockVar = 0;
  let blockCount = 0;

  for (let br = 0; br < bRows; br++) {
    for (let bc = 0; bc < bCols; bc++) {
      let sumR = 0, sumG = 0, sumB = 0;
      let sumR2 = 0, sumG2 = 0, sumB2 = 0;
      let n = 0;
      for (let dy = 0; dy < BLOCK; dy++) {
        for (let dx = 0; dx < BLOCK; dx++) {
          const px = bc * BLOCK + dx;
          const py = br * BLOCK + dy;
          if (px >= w || py >= h) continue;
          const idx = (py * w + px) * 4;
          const r = data[idx]!;
          const g = data[idx + 1]!;
          const b = data[idx + 2]!;
          sumR += r; sumG += g; sumB += b;
          sumR2 += r * r; sumG2 += g * g; sumB2 += b * b;
          n++;
        }
      }
      if (n === 0) continue;
      const varR = sumR2 / n - (sumR / n) ** 2;
      const varG = sumG2 / n - (sumG / n) ** 2;
      const varB = sumB2 / n - (sumB / n) ** 2;
      totalBlockVar += (varR + varG + varB) / 3;
      blockCount++;
    }
  }

  const avgBlockVar = blockCount > 0 ? totalBlockVar / blockCount : 1000;
  // Variance faible (< 200) = blocs uniformes = patron
  // Variance élevée (> 800) = gradients = photo
  const uniformityScore = Math.max(0, Math.min(1, 1 - (avgBlockVar - 50) / 750));

  // ─── Critère B : Palette discrète (couleurs quantifiées) ───────────────────
  // Quantifier en 32 niveaux par canal (5 bits) et compter les couleurs uniques
  const colorBuckets = new Set<number>();
  let sampleStep = Math.max(1, Math.floor(totalPixels / 2000)); // échantillonnage
  for (let i = 0; i < totalPixels; i += sampleStep) {
    const idx = i * 4;
    const r = Math.floor(data[idx]! / 8);    // 0-31
    const g = Math.floor(data[idx + 1]! / 8);
    const b = Math.floor(data[idx + 2]! / 8);
    colorBuckets.add((r << 10) | (g << 5) | b);
  }
  const uniqueColors = colorBuckets.size;
  // Patron : 5-200 couleurs quantifiées (N&B : 5-30, couleur : 30-200)
  // Photo : > 500 couleurs quantifiées
  let paletteScore: number;
  if (uniqueColors <= 5) {
    paletteScore = uniqueColors / 5; // trop peu (page blanche)
  } else if (uniqueColors <= 200) {
    paletteScore = 1.0; // idéal pour un patron
  } else if (uniqueColors <= 600) {
    paletteScore = Math.max(0, 1 - (uniqueColors - 200) / 400);
  } else {
    paletteScore = 0; // photo
  }

  // ─── Critère C : Fond clair dominant ────────────────────────────────────────
  let lightPixels = 0;
  for (let i = 0; i < totalPixels; i += sampleStep) {
    const idx = i * 4;
    const r = data[idx]!;
    const g = data[idx + 1]!;
    const b = data[idx + 2]!;
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    if (lum > 200) lightPixels++;
  }
  const sampledTotal = Math.ceil(totalPixels / sampleStep);
  const lightRatio = lightPixels / sampledTotal;
  // Un patron a généralement > 30% de fond clair (N&B > 60%, couleur > 30%)
  const lightScore = Math.min(1, lightRatio / 0.35);

  // ─── Critère D : Lignes de grille (pixels sombres répétitifs) ──────────────
  // Compter les pixels sombres par ligne et par colonne
  const darkRowCount = new Float32Array(h);
  const darkColCount = new Float32Array(w);
  let totalDark = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = data[idx]!;
      const g = data[idx + 1]!;
      const b = data[idx + 2]!;
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      if (lum < 100) {
        darkRowCount[y]++;
        darkColCount[x]++;
        totalDark++;
      }
    }
  }

  // Régularité des lignes sombres (coefficient de variation)
  const avgDarkRow = totalDark / h;
  const avgDarkCol2 = totalDark / w;
  let varRow = 0, varCol = 0;
  for (let y = 0; y < h; y++) varRow += (darkRowCount[y]! - avgDarkRow) ** 2;
  for (let x = 0; x < w; x++) varCol += (darkColCount[x]! - avgDarkCol2) ** 2;
  varRow /= h; varCol /= w;
  const cvRow = avgDarkRow > 0 ? Math.sqrt(varRow) / avgDarkRow : 10;
  const cvCol = avgDarkCol2 > 0 ? Math.sqrt(varCol) / avgDarkCol2 : 10;
  const avgCV = (cvRow + cvCol) / 2;
  // CV faible = lignes régulières = grille, CV élevé = irrégulier = photo/texte
  const gridLineScore = Math.max(0, Math.min(1, 1 - (avgCV - 0.4) / 2.6));

  // ─── Score final pondéré ────────────────────────────────────────────────────
  // Uniformité et palette sont les critères les plus discriminants
  const score =
    uniformityScore * 0.35 +
    paletteScore    * 0.30 +
    lightScore      * 0.20 +
    gridLineScore   * 0.15;

  return Math.max(0, Math.min(1, score));
}

/**
 * Rend une page PDF sur un canvas avec fond blanc et retourne l'ImageData.
 */
async function renderPdfPage(
  page: import("pdfjs-dist").PDFPageProxy,
  targetCols: number,
  targetRows: number,
  highRes = true
): Promise<ImageData> {
  const viewport = page.getViewport({ scale: 1 });

  const baseScale = Math.min(
    (targetCols * 8) / viewport.width,
    (targetRows * 8) / viewport.height,
    4
  );
  const scale = highRes ? Math.max(baseScale, 2) : baseScale;
  const scaledViewport = page.getViewport({ scale });

  const canvas = document.createElement("canvas");
  canvas.width = scaledViewport.width;
  canvas.height = scaledViewport.height;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // pdfjs-dist v5 : utiliser `canvas` comme paramètre principal (canvasContext est déprécié)
  await page.render({ canvas, viewport: scaledViewport }).promise;

  return ctx.getImageData(0, 0, canvas.width, canvas.height);
}

/**
 * Génère des miniatures pour toutes les pages d'un PDF,
 * avec scoring automatique pour détecter les pages de grille.
 */
async function generatePdfPreviews(
  pdf: import("pdfjs-dist").PDFDocumentProxy,
  onProgress?: (pct: number) => void
): Promise<{ previews: PdfPagePreview[]; bestPageNum: number }> {
  const previews: PdfPagePreview[] = [];
  const total = pdf.numPages;

  for (let i = 1; i <= total; i++) {
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale: 1 });
    // Miniature à 150px de large pour avoir assez de détails pour le scoring
    const scale = 150 / viewport.width;
    const scaledViewport = page.getViewport({ scale });

    const canvas = document.createElement("canvas");
    canvas.width = scaledViewport.width;
    canvas.height = scaledViewport.height;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    // pdfjs-dist v5 : utiliser `canvas` comme paramètre principal
    await page.render({ canvas, viewport: scaledViewport }).promise;

    // Calculer le score de grille pour cette page
    const gridScore = scoreGridPage(canvas);

    previews.push({
      pageNum: i,
      dataUrl: canvas.toDataURL("image/jpeg", 0.7),
      gridScore,
      isGridCandidate: false, // sera mis à jour après
    });

    onProgress?.(Math.round((i / total) * 100));
  }

  // Trouver la meilleure page et marquer les candidates (score > 60% du max)
  const maxScore = Math.max(...previews.map(p => p.gridScore));
  const threshold = Math.max(0.4, maxScore * 0.6); // au moins 40% et 60% du max

  for (const p of previews) {
    p.isGridCandidate = p.gridScore >= threshold && p.gridScore > 0.3;
  }

  // La meilleure page = score max (si ex-aequo, prendre la première)
  const bestIdx = previews.reduce(
    (best, p, i) => (p.gridScore > previews[best]!.gridScore ? i : best),
    0
  );
  const bestPageNum = previews[bestIdx]?.pageNum ?? 1;

  return { previews, bestPageNum };
}

export function useImageImport() {
  const [status, setStatus] = useState<ImportStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  // État pour le sélecteur de page PDF
  const [pdfPreviews, setPdfPreviews] = useState<PdfPagePreview[]>([]);
  const [pdfPageCount, setPdfPageCount] = useState(0);
  const [pdfInstance, setPdfInstance] = useState<import("pdfjs-dist").PDFDocumentProxy | null>(null);
  const [bestPdfPage, setBestPdfPage] = useState<number>(1);

  /**
   * Charge un PDF, génère ses miniatures et détecte automatiquement
   * la meilleure page de grille.
   * Retourne le numéro de la page recommandée.
   */
  const loadPdfPreviews = useCallback(async (file: File): Promise<{ pageCount: number; bestPage: number }> => {
    setStatus("loading");
    setError(null);
    setProgress(0);
    setPdfPreviews([]);
    setPdfInstance(null);
    setBestPdfPage(1);

    try {
      const pdfjsLib = await import("pdfjs-dist");
      pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
        "pdfjs-dist/build/pdf.worker.mjs",
        import.meta.url
      ).toString();

      setProgress(10);
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      setPdfPageCount(pdf.numPages);
      setPdfInstance(pdf);
      setProgress(20);

      const { previews, bestPageNum } = await generatePdfPreviews(pdf, (pct) => {
        setProgress(20 + Math.round(pct * 0.7));
      });

      setPdfPreviews(previews);
      setBestPdfPage(bestPageNum);
      setProgress(100);
      setStatus("idle");
      return { pageCount: pdf.numPages, bestPage: bestPageNum };
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erreur lors du chargement du PDF";
      setError(msg);
      setStatus("error");
      return { pageCount: 0, bestPage: 1 };
    }
  }, []);

  /**
   * Convertit une page PDF spécifique en grille DMC.
   */
  const importPdfPage = useCallback(
    async (
      pageNum: number,
      targetRows = 40,
      targetCols = 40,
      fileName = "patron.pdf"
    ): Promise<ImportResult | null> => {
      if (!pdfInstance) {
        setError("Aucun PDF chargé");
        return null;
      }

      setStatus("loading");
      setError(null);
      setProgress(0);

      try {
        setProgress(20);
        const page = await pdfInstance.getPage(pageNum);
        setProgress(40);

        const imageData = await renderPdfPage(page, targetCols, targetRows, true);
        setProgress(70);

        const grid = imageDataToGrid(imageData, targetRows, targetCols);
        setProgress(95);

        const colorSet = new Set(grid.flat().filter(Boolean));
        setProgress(100);
        setStatus("success");

        return {
          grid,
          rows: targetRows,
          cols: targetCols,
          colorCount: colorSet.size,
          fileName,
        };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Erreur lors de la conversion";
        setError(msg);
        setStatus("error");
        return null;
      }
    },
    [pdfInstance]
  );

  /**
   * Import générique : image (PNG/JPEG) ou PDF (page 1 par défaut si pas de previews).
   */
  const importFile = useCallback(
    async (file: File, targetRows = 40, targetCols = 40): Promise<ImportResult | null> => {
      setStatus("loading");
      setError(null);
      setProgress(0);

      try {
        let imageData: ImageData;

        if (file.type === "application/pdf" || file.name.endsWith(".pdf")) {
          const pdfjsLib = await import("pdfjs-dist");
          pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
            "pdfjs-dist/build/pdf.worker.mjs",
            import.meta.url
          ).toString();
          setProgress(10);
          const arrayBuffer = await file.arrayBuffer();
          const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
          setProgress(25);

          const page = await pdf.getPage(1);
          setProgress(40);

          imageData = await renderPdfPage(page, targetCols, targetRows, true);
          setProgress(65);
        } else if (
          file.type.startsWith("image/") ||
          file.name.match(/\.(png|jpe?g|webp|gif|bmp)$/i)
        ) {
          setProgress(20);
          const bitmap = await createImageBitmap(file);
          setProgress(50);
          const canvas = document.createElement("canvas");
          canvas.width = bitmap.width;
          canvas.height = bitmap.height;
          const ctx = canvas.getContext("2d")!;
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(bitmap, 0, 0);
          setProgress(65);
          imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        } else {
          throw new Error("Format non supporté. Utilisez PNG, JPEG ou PDF.");
        }

        setProgress(70);
        const grid = imageDataToGrid(imageData, targetRows, targetCols);
        setProgress(95);
        const colorSet = new Set(grid.flat().filter(Boolean));
        setProgress(100);
        setStatus("success");

        return {
          grid,
          rows: targetRows,
          cols: targetCols,
          colorCount: colorSet.size,
          fileName: file.name,
        };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Erreur lors de l'import";
        setError(msg);
        setStatus("error");
        return null;
      }
    },
    []
  );

  const resetPdf = useCallback(() => {
    setPdfPreviews([]);
    setPdfPageCount(0);
    setPdfInstance(null);
    setBestPdfPage(1);
  }, []);

  return {
    importFile,
    loadPdfPreviews,
    importPdfPage,
    resetPdf,
    pdfPreviews,
    pdfPageCount,
    bestPdfPage,
    status,
    error,
    progress,
  };
}
