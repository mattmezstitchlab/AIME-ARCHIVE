/**
 * usePDFImport — Extrait les pixels d'un PDF et les mappe vers la palette DMC
 * Utilise PDF.js côté client, aucune dépendance serveur
 */
import { useState, useCallback } from "react";

// Palette DMC complète avec valeurs RGB
const DMC_COLORS: Record<string, { r: number; g: number; b: number; name: string }> = {
  "blanc": { r: 255, g: 255, b: 255, name: "Blanc" },
  "ECRU":  { r: 240, g: 234, b: 214, name: "Ecru" },
  "310":   { r: 26,  g: 26,  b: 26,  name: "Black" },
  "318":   { r: 163, g: 168, b: 172, name: "Light Steel Gray" },
  "415":   { r: 199, g: 202, b: 205, name: "Pearl Gray" },
  "762":   { r: 229, g: 231, b: 232, name: "Very Light Pearl Gray" },
  "321":   { r: 183, g: 40,  b: 49,  name: "Red" },
  "498":   { r: 155, g: 27,  b: 48,  name: "Dark Red" },
  "666":   { r: 204, g: 36,  b: 52,  name: "Bright Red" },
  "816":   { r: 163, g: 30,  b: 45,  name: "Garnet" },
  "347":   { r: 175, g: 38,  b: 46,  name: "Very Dark Salmon" },
  "350":   { r: 204, g: 85,  b: 68,  name: "Medium Coral" },
  "351":   { r: 217, g: 113, b: 97,  name: "Coral" },
  "352":   { r: 232, g: 145, b: 130, name: "Light Coral" },
  "353":   { r: 242, g: 179, b: 163, name: "Peach" },
  "3354":  { r: 240, g: 176, b: 190, name: "Light Dusty Rose" },
  "3733":  { r: 232, g: 130, b: 154, name: "Dusty Rose" },
  "3731":  { r: 196, g: 78,  b: 110, name: "Very Dark Dusty Rose" },
  "3727":  { r: 196, g: 132, b: 158, name: "Light Antique Mauve" },
  "3726":  { r: 139, g: 74,  b: 107, name: "Antique Mauve" },
  "223":   { r: 186, g: 119, b: 112, name: "Light Shell Pink" },
  "224":   { r: 214, g: 158, b: 148, name: "Very Light Shell Pink" },
  "225":   { r: 237, g: 205, b: 196, name: "Ultra Very Light Shell Pink" },
  "760":   { r: 234, g: 143, b: 136, name: "Salmon" },
  "761":   { r: 243, g: 179, b: 174, name: "Light Salmon" },
  "3712":  { r: 228, g: 115, b: 105, name: "Medium Salmon" },
  "741":   { r: 255, g: 163, b: 51,  name: "Medium Tangerine" },
  "742":   { r: 255, g: 185, b: 85,  name: "Light Tangerine" },
  "743":   { r: 255, g: 209, b: 119, name: "Medium Yellow" },
  "744":   { r: 255, g: 228, b: 153, name: "Pale Yellow" },
  "745":   { r: 255, g: 240, b: 187, name: "Light Pale Yellow" },
  "726":   { r: 255, g: 214, b: 85,  name: "Light Topaz" },
  "727":   { r: 255, g: 230, b: 136, name: "Very Light Topaz" },
  "725":   { r: 255, g: 198, b: 68,  name: "Topaz" },
  "783":   { r: 204, g: 153, b: 51,  name: "Medium Topaz" },
  "782":   { r: 181, g: 130, b: 34,  name: "Dark Topaz" },
  "780":   { r: 143, g: 96,  b: 17,  name: "Ultra Very Dark Topaz" },
  "3822":  { r: 242, g: 214, b: 119, name: "Light Straw" },
  "3821":  { r: 237, g: 198, b: 85,  name: "Straw" },
  "3820":  { r: 219, g: 172, b: 51,  name: "Dark Straw" },
  "472":   { r: 204, g: 219, b: 153, name: "Ultra Light Avocado Green" },
  "471":   { r: 179, g: 198, b: 119, name: "Very Light Avocado Green" },
  "470":   { r: 153, g: 181, b: 85,  name: "Light Avocado Green" },
  "469":   { r: 119, g: 153, b: 51,  name: "Avocado Green" },
  "937":   { r: 102, g: 136, b: 51,  name: "Medium Avocado Green" },
  "936":   { r: 85,  g: 119, b: 34,  name: "Very Dark Avocado Green" },
  "524":   { r: 184, g: 201, b: 160, name: "Very Light Fern Green" },
  "522":   { r: 142, g: 168, b: 122, name: "Fern Green" },
  "520":   { r: 90,  g: 122, b: 82,  name: "Dark Fern Green" },
  "3347":  { r: 136, g: 170, b: 102, name: "Medium Yellow Green" },
  "3346":  { r: 102, g: 153, b: 68,  name: "Hunter Green" },
  "3345":  { r: 68,  g: 119, b: 34,  name: "Dark Hunter Green" },
  "704":   { r: 136, g: 204, b: 68,  name: "Bright Chartreuse" },
  "703":   { r: 119, g: 187, b: 85,  name: "Chartreuse" },
  "702":   { r: 85,  g: 170, b: 68,  name: "Kelly Green" },
  "701":   { r: 68,  g: 153, b: 51,  name: "Light Green" },
  "700":   { r: 34,  g: 136, b: 34,  name: "Bright Green" },
  "699":   { r: 0,   g: 119, b: 17,  name: "Green" },
  "3750":  { r: 34,  g: 68,  b: 102, name: "Very Dark Antique Blue" },
  "336":   { r: 34,  g: 68,  b: 119, name: "Navy Blue" },
  "823":   { r: 34,  g: 51,  b: 136, name: "Dark Navy Blue" },
  "820":   { r: 34,  g: 68,  b: 153, name: "Very Dark Royal Blue" },
  "791":   { r: 68,  g: 85,  b: 153, name: "Very Dark Cornflower Blue" },
  "792":   { r: 85,  g: 102, b: 170, name: "Dark Cornflower Blue" },
  "793":   { r: 119, g: 136, b: 187, name: "Medium Cornflower Blue" },
  "794":   { r: 153, g: 170, b: 204, name: "Light Cornflower Blue" },
  "800":   { r: 187, g: 204, b: 221, name: "Pale Delft Blue" },
  "809":   { r: 153, g: 187, b: 214, name: "Delft Blue" },
  "826":   { r: 102, g: 153, b: 187, name: "Medium Blue" },
  "825":   { r: 68,  g: 136, b: 170, name: "Dark Blue" },
  "824":   { r: 51,  g: 119, b: 153, name: "Very Dark Blue" },
  "3766":  { r: 102, g: 187, b: 204, name: "Light Peacock Blue" },
  "807":   { r: 85,  g: 170, b: 187, name: "Peacock Blue" },
  "3765":  { r: 51,  g: 136, b: 153, name: "Very Dark Peacock Blue" },
  "747":   { r: 204, g: 238, b: 242, name: "Very Light Sky Blue" },
  "3761":  { r: 170, g: 221, b: 230, name: "Light Sky Blue" },
  "519":   { r: 136, g: 196, b: 213, name: "Sky Blue" },
  "518":   { r: 85,  g: 170, b: 196, name: "Light Wedgwood" },
  "517":   { r: 51,  g: 136, b: 170, name: "Dark Wedgwood" },
  "3753":  { r: 204, g: 217, b: 230, name: "Ultra Very Light Antique Blue" },
  "932":   { r: 153, g: 179, b: 204, name: "Light Antique Blue" },
  "931":   { r: 119, g: 153, b: 187, name: "Medium Antique Blue" },
  "930":   { r: 85,  g: 119, b: 153, name: "Dark Antique Blue" },
  "3756":  { r: 221, g: 238, b: 247, name: "Ultra Very Light Baby Blue" },
  "775":   { r: 204, g: 225, b: 238, name: "Very Light Baby Blue" },
  "3325":  { r: 170, g: 204, b: 225, name: "Light Baby Blue" },
  "334":   { r: 102, g: 153, b: 196, name: "Medium Baby Blue" },
  "322":   { r: 68,  g: 119, b: 170, name: "Dark Baby Blue" },
  "312":   { r: 51,  g: 85,  b: 136, name: "Very Dark Baby Blue" },
  "677":   { r: 238, g: 228, b: 187, name: "Very Light Old Gold" },
  "676":   { r: 221, g: 204, b: 153, name: "Light Old Gold" },
  "729":   { r: 187, g: 162, b: 85,  name: "Medium Old Gold" },
  "680":   { r: 162, g: 128, b: 34,  name: "Dark Old Gold" },
  "3045":  { r: 196, g: 162, b: 102, name: "Dark Yellow Beige" },
  "3046":  { r: 213, g: 187, b: 136, name: "Medium Yellow Beige" },
  "3047":  { r: 230, g: 213, b: 179, name: "Light Yellow Beige" },
  "422":   { r: 196, g: 162, b: 119, name: "Light Hazel Nut Brown" },
  "420":   { r: 153, g: 102, b: 51,  name: "Dark Hazel Nut Brown" },
  "869":   { r: 136, g: 85,  b: 34,  name: "Very Dark Hazel Nut Brown" },
  "3826":  { r: 179, g: 119, b: 51,  name: "Golden Brown" },
  "3827":  { r: 213, g: 162, b: 85,  name: "Pale Golden Brown" },
  "977":   { r: 196, g: 136, b: 51,  name: "Light Golden Brown" },
  "976":   { r: 179, g: 119, b: 34,  name: "Medium Golden Brown" },
  "975":   { r: 153, g: 85,  b: 17,  name: "Dark Golden Brown" },
  "3857":  { r: 102, g: 51,  b: 17,  name: "Dark Rosewood" },
  "3858":  { r: 153, g: 85,  b: 68,  name: "Medium Rosewood" },
  "3859":  { r: 196, g: 153, b: 136, name: "Light Rosewood" },
  "3860":  { r: 119, g: 85,  b: 85,  name: "Cocoa" },
  "3861":  { r: 170, g: 136, b: 136, name: "Light Cocoa" },
  "632":   { r: 136, g: 85,  b: 68,  name: "Ultra Very Dark Desert Sand" },
  "3064":  { r: 196, g: 136, b: 102, name: "Desert Sand" },
  "407":   { r: 179, g: 119, b: 85,  name: "Dark Desert Sand" },
  "3772":  { r: 153, g: 102, b: 68,  name: "Very Dark Desert Sand" },
  "758":   { r: 221, g: 162, b: 136, name: "Very Light Terra Cotta" },
  "3778":  { r: 204, g: 136, b: 102, name: "Light Terra Cotta" },
  "356":   { r: 187, g: 102, b: 68,  name: "Medium Terra Cotta" },
  "355":   { r: 162, g: 68,  b: 34,  name: "Dark Terra Cotta" },
  "3830":  { r: 187, g: 85,  b: 51,  name: "Terra Cotta" },
  "608":   { r: 255, g: 102, b: 34,  name: "Bright Orange" },
  "606":   { r: 255, g: 68,  b: 17,  name: "Bright Orange-Red" },
  "900":   { r: 204, g: 68,  b: 0,   name: "Dark Burnt Orange" },
  "947":   { r: 255, g: 119, b: 51,  name: "Burnt Orange" },
  "946":   { r: 230, g: 102, b: 17,  name: "Medium Burnt Orange" },
  "3824":  { r: 255, g: 187, b: 162, name: "Light Apricot" },
  "3341":  { r: 255, g: 153, b: 119, name: "Apricot" },
  "3340":  { r: 255, g: 119, b: 85,  name: "Medium Apricot" },
  "3716":  { r: 255, g: 170, b: 179, name: "Very Light Dusty Rose" },
  "894":   { r: 255, g: 153, b: 162, name: "Very Light Carnation" },
  "893":   { r: 247, g: 119, b: 136, name: "Light Carnation" },
  "892":   { r: 238, g: 85,  b: 102, name: "Medium Carnation" },
  "891":   { r: 221, g: 51,  b: 68,  name: "Dark Carnation" },
  "957":   { r: 255, g: 179, b: 196, name: "Pale Geranium" },
  "956":   { r: 255, g: 136, b: 153, name: "Geranium" },
  "309":   { r: 196, g: 51,  b: 68,  name: "Dark Rose" },
  "326":   { r: 170, g: 34,  b: 51,  name: "Very Dark Rose" },
  "3685":  { r: 136, g: 17,  b: 51,  name: "Very Dark Mauve" },
  "3687":  { r: 187, g: 85,  b: 102, name: "Mauve" },
  "3688":  { r: 213, g: 145, b: 153, name: "Medium Mauve" },
  "3689":  { r: 238, g: 187, b: 196, name: "Light Mauve" },
  "3803":  { r: 153, g: 34,  b: 85,  name: "Dark Mauve" },
  "3804":  { r: 213, g: 34,  b: 119, name: "Dark Cyclamen Pink" },
  "3805":  { r: 238, g: 68,  b: 153, name: "Cyclamen Pink" },
  "3806":  { r: 255, g: 136, b: 187, name: "Light Cyclamen Pink" },
  "718":   { r: 170, g: 34,  b: 102, name: "Plum" },
  "917":   { r: 187, g: 34,  b: 119, name: "Medium Plum" },
  "915":   { r: 153, g: 0,   b: 85,  name: "Dark Plum" },
  "553":   { r: 136, g: 85,  b: 153, name: "Violet" },
  "552":   { r: 102, g: 51,  b: 136, name: "Medium Violet" },
  "550":   { r: 68,  g: 17,  b: 102, name: "Very Dark Violet" },
  "554":   { r: 196, g: 170, b: 213, name: "Light Violet" },
  "210":   { r: 196, g: 162, b: 213, name: "Medium Lavender" },
  "209":   { r: 170, g: 119, b: 196, name: "Dark Lavender" },
  "208":   { r: 136, g: 85,  b: 170, name: "Very Dark Lavender" },
  "211":   { r: 221, g: 196, b: 230, name: "Light Lavender" },
  "3747":  { r: 204, g: 204, b: 230, name: "Very Light Blue Violet" },
  "341":   { r: 153, g: 153, b: 204, name: "Light Blue Violet" },
  "340":   { r: 119, g: 119, b: 187, name: "Medium Blue Violet" },
  "333":   { r: 85,  g: 68,  b: 153, name: "Very Dark Blue Violet" },
  "3746":  { r: 102, g: 85,  b: 170, name: "Dark Blue Violet" },
  "327":   { r: 68,  g: 34,  b: 119, name: "Very Dark Violet" },
  "3835":  { r: 153, g: 102, b: 153, name: "Medium Grape" },
  "3836":  { r: 196, g: 153, b: 196, name: "Light Grape" },
  "3837":  { r: 102, g: 51,  b: 119, name: "Ultra Dark Lavender" },
  "3834":  { r: 119, g: 68,  b: 119, name: "Dark Grape" },
};

// Trouver la couleur DMC la plus proche (distance euclidienne dans l'espace RGB)
function findClosestDMC(r: number, g: number, b: number): string {
  let minDist = Infinity;
  let closest = "blanc";

  for (const [code, color] of Object.entries(DMC_COLORS)) {
    const dist =
      Math.pow(r - color.r, 2) +
      Math.pow(g - color.g, 2) +
      Math.pow(b - color.b, 2);
    if (dist < minDist) {
      minDist = dist;
      closest = code;
    }
  }
  return closest;
}

export type ImportResult = {
  grid: (string | null)[][];
  rows: number;
  cols: number;
  colorCount: number;
  fileName: string;
};

export type ImportStatus = "idle" | "loading" | "success" | "error";

export function usePDFImport() {
  const [status, setStatus] = useState<ImportStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const importPDF = useCallback(
    async (file: File, targetRows = 40, targetCols = 40): Promise<ImportResult | null> => {
      setStatus("loading");
      setError(null);
      setProgress(0);

      try {
        // Charger PDF.js dynamiquement
        const pdfjsLib = await import("pdfjs-dist");
        // Utiliser le worker bundlé
        pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
          "pdfjs-dist/build/pdf.worker.min.mjs",
          import.meta.url
        ).toString();

        setProgress(10);

        // Lire le fichier comme ArrayBuffer
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        setProgress(25);

        // Prendre la première page
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 1 });

        // Calculer l'échelle pour obtenir la résolution souhaitée
        const scale = Math.min(
          (targetCols * 8) / viewport.width,
          (targetRows * 8) / viewport.height,
          3 // max scale pour éviter les PDFs trop grands
        );
        const scaledViewport = page.getViewport({ scale });

        setProgress(35);

        // Rendre sur un canvas
        const canvas = document.createElement("canvas");
        canvas.width = scaledViewport.width;
        canvas.height = scaledViewport.height;
        const ctx = canvas.getContext("2d")!;

        // pdfjs-dist v5 : utiliser `canvas` comme paramètre principal
        await page.render({
          canvas,
          viewport: scaledViewport,
        }).promise;

        setProgress(60);

        // Extraire les pixels
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const { data, width, height } = imageData;

        // Sous-échantillonner vers la grille cible
        const cellW = width / targetCols;
        const cellH = height / targetRows;

        const grid: (string | null)[][] = [];

        for (let row = 0; row < targetRows; row++) {
          const gridRow: (string | null)[] = [];
          for (let col = 0; col < targetCols; col++) {
            // Moyenne des pixels dans cette cellule
            let rSum = 0, gSum = 0, bSum = 0, aSum = 0, count = 0;
            const x0 = Math.floor(col * cellW);
            const y0 = Math.floor(row * cellH);
            const x1 = Math.min(Math.ceil((col + 1) * cellW), width);
            const y1 = Math.min(Math.ceil((row + 1) * cellH), height);

            for (let y = y0; y < y1; y++) {
              for (let x = x0; x < x1; x++) {
                const idx = (y * width + x) * 4;
                rSum += data[idx];
                gSum += data[idx + 1];
                bSum += data[idx + 2];
                aSum += data[idx + 3];
                count++;
              }
            }

            const alpha = aSum / count;
            if (alpha < 30) {
              // Pixel transparent → vide
              gridRow.push(null);
            } else {
              const r = rSum / count;
              const g = gSum / count;
              const b = bSum / count;

              // Ignorer les pixels quasi-blancs (fond du PDF)
              if (r > 245 && g > 245 && b > 245) {
                gridRow.push(null);
              } else {
                gridRow.push(findClosestDMC(r, g, b));
              }
            }
          }
          grid.push(gridRow);
          if (row % 5 === 0) {
            setProgress(60 + Math.round((row / targetRows) * 35));
          }
        }

        setProgress(98);

        // Compter les couleurs uniques
        const colorSet = new Set(grid.flat().filter(Boolean));

        setProgress(100);
        setStatus("success");

        return {
          grid,
          rows: targetRows,
          cols: targetCols,
          colorCount: colorSet.size,
          fileName: file.name,
        };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Erreur lors de l'import";
        setError(msg);
        setStatus("error");
        return null;
      }
    },
    []
  );

  return { importPDF, status, error, progress };
}

export { DMC_COLORS };
