import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import DemoPage from "./pages/Demo";
import Blog from "./pages/Blog";
import Admin from "./pages/Admin";
import AppDashboard from "./pages/app/Dashboard";
import AppProjects from "./pages/app/Projects";
import AppInventory from "./pages/app/Inventory";
import AppDiary from "./pages/app/Diary";
import AppSAL from "./pages/app/SAL";
import SalSyncPage from "./pages/app/SalSync";
import ProfilePage from "./pages/app/Profile";
import AppEditor from "./pages/app/Editor";
import SharedPattern from "./pages/SharedPattern";
import Privacy from "./pages/legal/Privacy";
import Terms from "./pages/legal/Terms";
import Cookies from "./pages/legal/Cookies";
import FAQ from "./pages/FAQ";
import About from "./pages/About";

function Router() {
  return (
    <Switch>
      {/* Site marketing */}
      <Route path="/" component={Home} />
      <Route path="/demo" component={DemoPage} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={Blog} />
      <Route path="/admin" component={Admin} />

      {/* Application brodeuse */}
      <Route path="/app" component={AppDashboard} />
      <Route path="/app/projects" component={AppProjects} />
      <Route path="/app/inventory" component={AppInventory} />
      <Route path="/app/diary" component={AppDiary} />
      <Route path="/app/sal" component={AppSAL} />
      <Route path="/app/sal-sync" component={SalSyncPage} />
      <Route path="/app/profile" component={ProfilePage} />
      <Route path="/app/editor" component={AppEditor} />

      {/* Patrons partagés (accès public via lien) */}
      <Route path="/patron/:token" component={SharedPattern} />

      {/* Pages légales & informations */}
      <Route path="/confidentialite" component={Privacy} />
      <Route path="/cgu" component={Terms} />
      <Route path="/cookies" component={Cookies} />
      <Route path="/faq" component={FAQ} />
      <Route path="/a-propos" component={About} />

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
