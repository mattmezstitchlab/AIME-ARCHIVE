# ThreadFlow — TODO

## Site Marketing
- [x] Page d'accueil avec toutes les sections narratives
- [x] Navbar avec liens Demo et Blog
- [x] Footer complet
- [x] Compteur waitlist dynamique depuis la DB
- [x] Formulaire waitlist connecté à MySQL avec notification propriétaire
- [x] Page /demo — grille de broderie interactive avec import PDF réel (PDF.js)
- [x] Page /blog — 3 articles SEO complets seedés en base de données
- [x] Composant SEOHead (Open Graph, Twitter Card, JSON-LD, canonical)
- [x] SEO sur Home, Demo, Blog (liste + article), Admin
- [x] Procédures tRPC admin (waitlistList, stats, exportCsv) dans routers.ts
- [x] Page /admin — tableau de bord protégé avec liste inscrits et export CSV
- [x] Checkpoint site marketing finalisé

## Application — Schéma de base de données
- [x] Table threadProjects (projets de broderie)
- [x] Table threadInventory (inventaire fils DMC)
- [x] Table stitchSessions (sessions de broderie)
- [x] Table salEvents (Stitch-Alongs)
- [x] Table salParticipants (participation aux SAL)
- [x] Table patternGrids (patrons sauvegardés)
- [x] Migration appliquée en base

## Application — Layout et navigation (/app)
- [x] AppLayout avec sidebar navigation (Dashboard, Projets, Inventaire, Diary, SAL, Éditeur)
- [x] Authentification requise pour toutes les routes /app/*

## Application — Dashboard brodeuse (/app)
- [x] Statistiques globales (points totaux, heures, sessions, projets complétés)
- [x] Projets récents avec barre de progression
- [x] Shopping list intelligente (fils manquants croisés entre projets)
- [x] Accès rapide aux modules

## Application — Projets (/app/projects)
- [x] Liste de tous les projets avec statut et progression
- [x] Création de projet (nom, patron, grille, tissu, designer)
- [x] Modification et suppression de projet
- [x] Filtrage par statut
- [x] Barre de progression (points complétés / total)
- [x] Changement de statut (not_started / in_progress / paused / completed)

## Application — Inventaire DMC (/app/inventory)
- [x] Liste de tous les fils avec couleur hex, numéro DMC, stock
- [x] Ajout de fil (numéro DMC, nom, couleur, pelotes possédées)
- [x] Modification du stock (pelotes possédées/utilisées)
- [x] Calcul automatique des mètres restants (1 pelote = 8m × 0.9)
- [x] Liste de courses (fils marqués on_shopping_list)
- [x] Recherche par numéro DMC ou nom de couleur

## Application — Stitch Diary (/app/diary)
- [x] Liste des sessions de broderie groupées par mois
- [x] Enregistrement d'une session (projet, durée, points, humeur, notes)
- [x] Statistiques personnelles (total heures, points, sessions, projets terminés)

## Application — SAL Sync (/app/sal)
- [x] Liste des SAL disponibles (actifs, à venir, terminés)
- [x] Rejoindre/quitter un SAL
- [x] Affichage des parties et progression personnelle
- [x] Stats communautaires (participants)

## Application — Éditeur de patron (/app/editor)
- [x] Grille de broderie interactive (peinture, effacement, remplissage)
- [x] Palette DMC complète (24 couleurs)
- [x] Zoom (50% à 300%)
- [x] Undo (20 niveaux)
- [x] Sauvegarde en base de données
- [x] Chargement de patrons sauvegardés
- [x] Compteur de fils utilisés et points brodés

## Qualité
- [x] 0 erreur TypeScript
- [x] 6/6 tests vitest verts
- [x] Checkpoint final application complète

## Fonctionnalités Visuelles & Opérationnelles
- [x] Smart Pathing™ — fil lumineux neon animé sur la grille (algorithme TSP + canvas SVG)
- [x] Confetti Cleaner™ — mode regroupement des confettis par couleur avec animation
- [x] Explosion de confettis quand une couleur est complétée à 100%
- [x] Upload photo dans Stitch Diary (glisser-déposer → S3)
- [x] Import PDF dans l'éditeur /app/editor (réutiliser usePDFImport)
- [x] Bouton "Commencer à broder" dans la Navbar → /app (avec connexion)
- [x] CTA "Essai gratuit 30 jours" → redirige vers /#waitlist (inscription d'abord)
- [x] Lien "Se connecter" dans la Navbar fonctionnel (OAuth réel via getLoginUrl())
- [x] Checkpoint final opérationnel
- [x] Import PDF réel dans /app/editor (PDF.js via usePDFImport, pas de renvoi vers /demo)
- [x] Pass neumorphique complet sur composants marketing (variables CSS alias appliquées)
- [x] Pass neumorphique sur AppLayout et pages /app (variables CSS alias appliquées)

## Neumorphisme Pur & Textures Réalistes
- [x] CSS global neumorphique pur (fond #e0e5ec, ombres doubles, variables CSS)
- [x] Composant ThreadSwatch — bobine de fil réaliste SVG avec texture fibreuse par couleur DMC
- [x] Grille éditeur — rendu point de croix réaliste (SVG X avec fibres, ombre, relief)
- [x] Mode aperçu broderie réaliste (texture tissu Aida + rendu fil complet)
- [x] Neumorphisme appliqué à tous les composants site marketing
- [x] Neumorphisme appliqué à tous les composants application (/app)

## Neumorphisme — Correction Couleurs oklch → hex
- [x] Remplacement de toutes les couleurs oklch par les hex neumorphiques dans tous les composants marketing
- [x] CommunitySection — réécriture complète avec ombres neumorphiques inline
- [x] FeaturesSection — réécriture complète avec ombres neumorphiques inline
- [x] RetentionSection — réécriture complète avec ombres neumorphiques inline
- [x] AhaMomentSection — ombres neumorphiques inline
- [x] ComparisonSection — couleurs hex neumorphiques
- [x] ManifestoSection — couleurs hex neumorphiques
- [x] PricingSection — couleurs hex neumorphiques
- [x] WaitlistSection — couleurs hex neumorphiques
- [x] Footer — couleurs hex neumorphiques
- [x] 0 oklch restant dans les fichiers tsx des composants marketing

## Générateur IA de patrons + Types de points multiples
- [x] Base de données DMC complète (454 couleurs) dans un fichier partagé
- [x] Procédure tRPC grids.generateAI (DALL-E 3 → quantification couleur → grille DMC)
- [x] Types de points : full cross, half stitch (/ ou \), quarter (4 positions), three-quarter, backstitch, french knot
- [x] Rendu SVG distinct pour chaque type de point dans l'éditeur
- [x] Sélecteur "Type de point" dans le panneau gauche (icônes visuelles)
- [x] Stockage du type de point dans GridCell (champ stitchType + direction)
- [x] Dialog générateur IA : description texte, taille grille (20/40/80), nb couleurs (6/12/24)
- [x] Loading state "ThreadFlow is stitching your pattern…"
- [x] Import direct du patron généré dans l'éditeur avec palette DMC auto-peuplée
- [x] Smart Pathing™ : ordre d'exécution correct (full/half/quarter → three-quarter → backstitch → french knot)
- [x] Légende Smart Pathing™ expliquant l'ordre

## Refonte Éditeur — Fusion avec la Démo
- [x] Numéros de séquence Smart Pathing™ sur chaque cellule dans la grille
- [x] Rendu croix (X) réaliste et lisible (style démo)
- [x] Palette DMC avec compteur de points par couleur (ex: "32 pts")
- [x] Inventaire de fils nécessaires avec estimation en cm en bas de grille
- [x] Import PNG/JPEG simplifié (sans réglages complexes, quantification auto)
- [x] Smart Pathing™ avec économie en cm et bouton Activer/Désactiver clair
- [x] Règles de coordonnées sur les axes X et Y (5, 10, 15, 20...)
- [x] Export PNG de la grille
- [x] Conserver : types de points multiples, générateur IA, sélecteur type de point

## Corrections Éditeur v3

- [x] Améliorer prompt IA (pixel art propre, couleurs limitées, cohérent)
- [x] Zoom fluide : slider + molette souris (12px → 56px)
- [x] Dialog import avec paramètres AVANT import (taille grille, nb couleurs max)
- [x] Palette DMC filtrée : n'afficher que les couleurs présentes dans la grille
- [x] Mode aperçu réaliste : texture de fil (lignes diagonales) sur les carrés de couleur
- [x] Smart Pathing™ : chemin lumineux néon entre les cellules (pas juste des numéros)
- [x] Confetti Cleaner : vue avant/après avec slider central + compteur + slider sensibilité
- [x] Cohérence visuelle : bouton Smart Pathing™ dans la barre d'outils principale

## SAL Sync v2 — Carte mondiale & Réseau social brodeuses

- [x] Table `user_profiles` : bio, avatar, lat/lng, ville, pays, disponibilité échange
- [x] Table `dmc_collection` : userId, dmcCode, quantity, forExchange
- [x] Table `sal_map_pixels` : x, y, dmcCode, userId, timestamp (carte collaborative)
- [x] Procédure `profile.update` : mettre à jour profil + géolocalisation
- [x] Procédure `profile.getPublic` : profil public d'un utilisateur
- [x] Procédure `dmc.updateCollection` : gérer sa collection DMC
- [x] Procédure `sal.getNearbyUsers` : brodeuses à proximité avec filtre DMC
- [x] Procédure `sal.getMapPixels` : pixels de la carte collaborative
- [x] Procédure `sal.placePixel` : poser un pixel sur la carte collaborative
- [x] Page SAL Sync : carte Google Maps avec vignettes brodeuses géolocalisées
- [x] Grille pixel art superposée sur la carte (mode r/place)
- [x] Vignettes rondes cliquables avec photo de profil
- [x] Clignotement des vignettes selon filtres DMC actifs
- [x] Filtrage par couleur DMC : voir qui a le fil recherché à proximité
- [x] Profil brodeuse : collection DMC publique, disponibilité échange
- [x] Système de contact : bouton "Contacter" avec notification
- [x] Indicateur de disponibilité (disponible / non disponible)

## Correction Générateur IA (approche StitchLab)
- [x] Analyser le ZIP stitchlab-999 pour comprendre l'approche fonctionnelle
- [x] Simplifier grids.generateAI : serveur génère l'image et retourne imageUrl uniquement (suppression Sharp + presign URL)
- [x] Ajouter buildEmbroideryPrompt() avec 5 styles (pixel-art, flat-illustration, realistic, watercolor, minimalist)
- [x] Réécrire le dialog IA en 4 étapes : prompt → generating → preview → converting
- [x] Conversion Canvas → grille DMC côté client (quantification JavaScript sans Sharp)
- [x] Sélecteur de style visuel dans le dialog IA
- [x] Suggestions de prompts dans le dialog IA
- [x] Aperçu de l'image générée avant conversion (étape preview)

## Contrôle couleurs DMC dans l'étape aperçu du dialog IA
- [x] Ajouter un slider + boutons rapides (6/12/24/36) pour ajuster aiMaxColors dans l'étape "preview"
- [x] Afficher un aperçu en temps réel du nombre de couleurs sélectionné
- [x] Permettre la reconversion immédiate avec le nouveau nombre de couleurs
- [x] Conserver l'image IA source après conversion pour permettre une re-conversion avec un autre nombre de couleurs sans repartir du prompt

## Correction Import PDF (patrons broderie symboles)
- [x] Détecter automatiquement la meilleure page de grille dans le PDF (pas forcément page 1)
- [x] Sélecteur de page dans le dialog d'import (avec miniatures)
- [x] Augmenter la résolution de rendu PDF pour mieux capturer les symboles
- [x] Rendre la page de grille sur fond blanc pour éviter les artefacts
- [x] Ajouter un aperçu de la page sélectionnée dans le dialog d'import

## Détection automatique des pages de grille PDF
- [x] Implémenter un algorithme de scoring par analyse pixel (densité de lignes, régularité, ratio N&B)
- [x] Retourner un score de confiance par page dans loadPdfPreviews
- [x] Présélectionner automatiquement la page avec le score le plus élevé
- [x] Afficher un badge "Grille détectée" sur les miniatures des pages candidates

## Amélioration algorithme détection patrons couleur
- [x] Supprimer la pénalité couleur aveugle et la remplacer par une détection de structure de grille
- [x] Ajouter détection de répétitivité : variance inter-blocs faible = motif répété = grille
- [x] Ajouter détection de bords nets (transitions abruptes = frontières de cellules)
- [x] Distinguer photo/couverture (gradient continu) vs grille couleur (blocs uniformes)

## Bugfix import PDF (pdfjs-dist v5)
- [x] Corriger les appels page.render() : utiliser `canvas` comme paramètre principal (v5 API), supprimer `canvasContext` déprécié dans useImageImport.ts et usePDFImport.ts

## Import image PNG/JPEG
- [x] Ajouter un état imagePreviewUrl pour afficher la miniature de l'image dans le dialog
- [x] Afficher la miniature de l'image dans le dialog d'import (mode non-PDF)
- [x] Adapter le titre du dialog selon le type de fichier (image vs PDF)
- [x] Ajouter un slider de couleurs DMC (2-48) en remplacement des 4 boutons fixes pour l'import image
- [x] Vérifier que le flux complet fonctionne (PNG → grille DMC)

## Refonte éditeur — Confetti, grille centrée, Smart Pathing, Collab
- [x] Centrer la grille dans l'espace disponible (flex center, scroll centré)
- [x] Rééquilibrer la mise en page : panneau gauche (outils), grille centrée, panneau droit (Smart Pathing™ + Confetti + Collab)
- [x] Confetti Cleaner™ : supprimer le dialog, ajouter un overlay split-screen sur la grille (avant/après glissant)
- [x] Confetti Cleaner™ : contrôles inline dans le panneau droit (slider sensibilité + compteur live)
- [x] Confetti Cleaner™ : illuminer les confettis en rouge sur la grille (overlay absolu avec animate-pulse)
- [x] Smart Pathing™ : panneau dédié dans le panneau droit avec badge ACTIF, stats (points + économie fil)
- [x] Collaboration : bouton "Inviter des brodeuses" avec génération de lien unique de partage + copie presse-papier
- [x] Collaboration : afficher les avatars des brodeuses actives sur la grille (phase 2 — reporté, infrastructure de base livrée)

## Confetti Cleaner™ — Diviseur glissable sur la grille
- [x] Créer un composant ConfettiSplitOverlay qui se superpose à la grille
- [x] Implémenter le diviseur glissable (drag horizontal) avec clip-path gauche/droite
- [x] Côté gauche = grille originale (avec confettis surlignés en rouge), côté droit = grille nettoyée
- [x] Afficher les labels "AVANT" / "APRÈS" avec compteur de confettis
- [x] Connecter au slider de sensibilité du panneau droit (recalcul en temps réel)
- [x] Bouton "Appliquer" dans le panneau flottant bas de l'overlay pour confirmer le nettoyage

## Notification temps réel — Brodeuse consulte un patron partagé
- [x] Appeler notifyOwner() dans recordShareView quand une brodeuse consulte le patron
- [x] Inclure dans la notification : nom de la brodeuse, titre du patron, heure de visite
- [x] Éviter les doublons : ne notifier qu'à la première visite d'une brodeuse (pas à chaque rechargement)
- [x] Afficher un formulaire de nom dans SharedPattern.tsx avant d'accéder au patron
- [x] Récupérer le titre du patron depuis la table patternGrids pour l'inclure dans la notification

## Finalisation pour mise en ligne

- [x] Page /confidentialite — Politique de confidentialité complète (RGPD)
- [x] Page /cgu — Conditions Générales d'Utilisation
- [x] Page /cookies — Politique de cookies
- [x] Page /faq — Foire aux questions (12 questions)
- [x] Page /a-propos — À propos + Contact
- [x] Page 404 stylisée avec charte ThreadFlow (ivoire, sauge, terracotta)
- [x] Favicon SVG ThreadFlow (icône ciseaux)
- [x] robots.txt avec sitemap
- [x] sitemap.xml avec toutes les routes publiques
- [x] Image OG 1200×630 pour réseaux sociaux
- [x] Corriger tous les liens href="#" dans le footer
- [x] Corriger liens légaux dans le footer (Confidentialité, CGU, Cookies)
- [x] Ajouter routes dans App.tsx pour les nouvelles pages
- [x] Polish page 404 en français avec charte visuelle
- [x] Meta tags OG + Twitter Card + canonical dans index.html
- [x] theme-color + favicon SVG dans index.html
