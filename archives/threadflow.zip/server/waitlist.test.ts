import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the db module
vi.mock("./db", () => ({
  addToWaitlist: vi.fn().mockResolvedValue({
    alreadyRegistered: false,
    entry: { id: 1, email: "test@example.com", goldenNeedle: true },
    goldenNeedle: true,
  }),
  getWaitlistCount: vi.fn().mockResolvedValue(42),
  getWaitlistPosition: vi.fn().mockResolvedValue({ position: 5, total: 42, goldenNeedle: true }),
  getAllBlogPosts: vi.fn().mockResolvedValue([]),
  getBlogPostBySlug: vi.fn().mockResolvedValue(null),
}));

// Mock notification
vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("waitlist.join", () => {
  it("should accept a valid email and return success", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.waitlist.join({ email: "brodeuse@example.com" });

    expect(result.success).toBe(true);
    expect(result.alreadyRegistered).toBe(false);
    expect(result.goldenNeedle).toBe(true);
    expect(result.message).toContain("Golden Needle");
  });

  it("should reject an invalid email", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.waitlist.join({ email: "not-an-email" })
    ).rejects.toThrow();
  });
});

describe("waitlist.count", () => {
  it("should return the waitlist count", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.waitlist.count();
    expect(result.count).toBe(42);
  });
});

describe("blog.list", () => {
  it("should return an array of blog posts", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.blog.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("blog.bySlug", () => {
  it("should return null for unknown slug", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.blog.bySlug({ slug: "unknown-slug" });
    expect(result).toBeNull();
  });
});
