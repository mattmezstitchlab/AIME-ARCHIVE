import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users, waitlist, blogPosts, InsertWaitlistEntry, InsertBlogPost,
  threadInventory, InsertThreadInventoryItem,
  threadProjects, InsertThreadProject,
  stitchSessions, InsertStitchSession,
  salEvents, InsertSalEvent,
  salParticipants, InsertSalParticipant,
  patternGrids, InsertPatternGrid,
  patternShares,
  patternShareViews,
  userProfiles, InsertUserProfile,
  dmcCollection, InsertDmcCollectionItem,
  salMapPixels, InsertSalMapPixel,
  salMessages, InsertSalMessage,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Waitlist ─────────────────────────────────────────────────────────────────

export async function addToWaitlist(entry: InsertWaitlistEntry) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(waitlist)
    .where(eq(waitlist.email, entry.email))
    .limit(1);

  if (existing.length > 0) {
    return { alreadyRegistered: true, entry: existing[0], goldenNeedle: existing[0].goldenNeedle };
  }

  const countResult = await db.select().from(waitlist);
  const isGoldenNeedle = countResult.length < 1000;

  await db.insert(waitlist).values({
    ...entry,
    goldenNeedle: isGoldenNeedle,
  });

  const inserted = await db
    .select()
    .from(waitlist)
    .where(eq(waitlist.email, entry.email))
    .limit(1);

  return { alreadyRegistered: false, entry: inserted[0], goldenNeedle: isGoldenNeedle };
}

export async function getWaitlistCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(waitlist);
  return result.length;
}

export async function getWaitlistPosition(email: string) {
  const db = await getDb();
  if (!db) return null;
  const entry = await db.select().from(waitlist).where(eq(waitlist.email, email)).limit(1);
  if (entry.length === 0) return null;
  const allEntries = await db.select().from(waitlist);
  const sorted = allEntries.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  const position = sorted.findIndex((e) => e.email === email) + 1;
  return { position, total: sorted.length, goldenNeedle: entry[0].goldenNeedle };
}

// ─── Blog ─────────────────────────────────────────────────────────────────────

export async function getAllBlogPosts() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(blogPosts)
    .where(eq(blogPosts.published, true))
    .orderBy(desc(blogPosts.publishedAt));
}

export async function getBlogPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(blogPosts)
    .where(and(eq(blogPosts.slug, slug), eq(blogPosts.published, true)))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function upsertBlogPost(post: InsertBlogPost) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(blogPosts).values(post).onDuplicateKeyUpdate({
    set: {
      title: post.title,
      excerpt: post.excerpt,
      content: post.content,
      coverImage: post.coverImage,
      category: post.category,
      tags: post.tags,
      readingTime: post.readingTime,
      published: post.published,
    },
  });
}

// ─── Admin helpers ────────────────────────────────────────────────────────────

export async function getAdminWaitlistEntries(params: {
  page: number;
  limit: number;
  search?: string;
  goldenNeedleOnly?: boolean;
}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0, page: params.page, totalPages: 0 };

  let all = await db.select().from(waitlist).orderBy(desc(waitlist.createdAt));

  // Filtres
  if (params.search) {
    const q = params.search.toLowerCase();
    all = all.filter(
      e =>
        e.email.toLowerCase().includes(q) ||
        (e.firstName ?? "").toLowerCase().includes(q)
    );
  }
  if (params.goldenNeedleOnly) {
    all = all.filter(e => e.goldenNeedle);
  }

  const total = all.length;
  const totalPages = Math.ceil(total / params.limit);
  const offset = (params.page - 1) * params.limit;
  const items = all.slice(offset, offset + params.limit);

  return { items, total, page: params.page, totalPages };
}

export async function getWaitlistStats() {
  const db = await getDb();
  if (!db) return { total: 0, goldenNeedle: 0, notified: 0, bySource: {} };

  const all = await db.select().from(waitlist);
  const goldenNeedle = all.filter(e => e.goldenNeedle).length;
  const notified = all.filter(e => e.notified).length;

  const bySource: Record<string, number> = {};
  all.forEach(e => {
    const src = e.source ?? "website";
    bySource[src] = (bySource[src] ?? 0) + 1;
  });

  // Inscriptions par jour (7 derniers jours)
  const now = Date.now();
  const sevenDaysAgo = now - 7 * 24 * 60 * 60 * 1000;
  const recentByDay: Record<string, number> = {};
  all
    .filter(e => e.createdAt.getTime() > sevenDaysAgo)
    .forEach(e => {
      const day = e.createdAt.toISOString().split("T")[0];
      recentByDay[day] = (recentByDay[day] ?? 0) + 1;
    });

  return { total: all.length, goldenNeedle, notified, bySource, recentByDay };
}

export async function markWaitlistNotified(ids: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  for (const id of ids) {
    await db.update(waitlist).set({ notified: true }).where(eq(waitlist.id, id));
  }
}

// ─── Thread Inventory ─────────────────────────────────────────────────────────
import { sql, inArray } from "drizzle-orm";

export async function getUserInventory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(threadInventory).where(eq(threadInventory.userId, userId))
    .orderBy(threadInventory.dmcNumber);
}

export async function addInventoryItem(item: InsertThreadInventoryItem) {
  const db = await getDb();
  if (!db) return null;
  const metersRemaining = ((item.skeinsOwned ?? 0) - (item.skeinsUsed ?? 0)) * 8 * 0.9;
  await db.insert(threadInventory).values({ ...item, metersRemaining: Math.max(0, metersRemaining) });
}

export async function updateInventoryItem(id: number, userId: number, data: Partial<InsertThreadInventoryItem>) {
  const db = await getDb();
  if (!db) return;
  const updateData: Record<string, unknown> = { ...data };
  if (data.skeinsOwned !== undefined || data.skeinsUsed !== undefined) {
    const existing = await db.select().from(threadInventory)
      .where(and(eq(threadInventory.id, id), eq(threadInventory.userId, userId))).limit(1);
    if (existing.length) {
      const owned = data.skeinsOwned ?? existing[0].skeinsOwned;
      const used = data.skeinsUsed ?? existing[0].skeinsUsed;
      updateData.metersRemaining = Math.max(0, (owned - used) * 8 * 0.9);
    }
  }
  await db.update(threadInventory).set(updateData)
    .where(and(eq(threadInventory.id, id), eq(threadInventory.userId, userId)));
}

export async function deleteInventoryItem(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(threadInventory).where(and(eq(threadInventory.id, id), eq(threadInventory.userId, userId)));
}

// ─── Thread Projects ──────────────────────────────────────────────────────────

export async function getUserProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(threadProjects).where(eq(threadProjects.userId, userId))
    .orderBy(desc(threadProjects.updatedAt));
}

export async function getProjectById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(threadProjects)
    .where(and(eq(threadProjects.id, id), eq(threadProjects.userId, userId))).limit(1);
  return result[0] ?? null;
}

export async function createProject(project: InsertThreadProject) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(threadProjects).values(project);
}

export async function updateProject(id: number, userId: number, data: Partial<InsertThreadProject>) {
  const db = await getDb();
  if (!db) return;
  await db.update(threadProjects).set(data)
    .where(and(eq(threadProjects.id, id), eq(threadProjects.userId, userId)));
}

export async function deleteProject(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(threadProjects).where(and(eq(threadProjects.id, id), eq(threadProjects.userId, userId)));
}

// ─── Stitch Sessions ──────────────────────────────────────────────────────────

export async function getUserSessions(userId: number, projectId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = projectId
    ? and(eq(stitchSessions.userId, userId), eq(stitchSessions.projectId, projectId))
    : eq(stitchSessions.userId, userId);
  return db.select().from(stitchSessions).where(conditions).orderBy(desc(stitchSessions.date));
}

export async function createSession(session: InsertStitchSession) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(stitchSessions).values(session);
  if (session.stitchesCompleted && session.stitchesCompleted > 0) {
    await db.update(threadProjects)
      .set({ completedStitches: sql`completedStitches + ${session.stitchesCompleted}` })
      .where(and(eq(threadProjects.id, session.projectId), eq(threadProjects.userId, session.userId)));
  }
}

export async function deleteSession(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(stitchSessions).where(and(eq(stitchSessions.id, id), eq(stitchSessions.userId, userId)));
}

export async function getUserStats(userId: number) {
  const db = await getDb();
  if (!db) return { totalStitches: 0, totalMinutes: 0, totalSessions: 0, completedProjects: 0 };
  const sessions = await db.select().from(stitchSessions).where(eq(stitchSessions.userId, userId));
  const totalStitches = sessions.reduce((s, r) => s + (r.stitchesCompleted ?? 0), 0);
  const totalMinutes = sessions.reduce((s, r) => s + (r.durationMinutes ?? 0), 0);
  const projects = await db.select().from(threadProjects).where(eq(threadProjects.userId, userId));
  const completedProjects = projects.filter(p => p.status === "completed").length;
  return { totalStitches, totalMinutes, totalSessions: sessions.length, completedProjects };
}

// ─── SAL Events ───────────────────────────────────────────────────────────────

export async function getAllSalEvents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(salEvents).orderBy(desc(salEvents.createdAt));
}

export async function getSalEventById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(salEvents).where(eq(salEvents.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getUserSalParticipations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(salParticipants).where(eq(salParticipants.userId, userId));
}

export async function joinSal(salId: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(salParticipants)
    .where(and(eq(salParticipants.salId, salId), eq(salParticipants.userId, userId))).limit(1);
  if (existing.length) return;
  await db.insert(salParticipants).values({ salId, userId, currentPart: 0 });
  await db.update(salEvents)
    .set({ participantsCount: sql`participantsCount + 1` })
    .where(eq(salEvents.id, salId));
}

export async function leaveSal(salId: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(salParticipants)
    .where(and(eq(salParticipants.salId, salId), eq(salParticipants.userId, userId)));
  await db.update(salEvents)
    .set({ participantsCount: sql`GREATEST(participantsCount - 1, 0)` })
    .where(eq(salEvents.id, salId));
}

// ─── Pattern Grids ────────────────────────────────────────────────────────────

export async function getUserGrids(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(patternGrids).where(eq(patternGrids.userId, userId))
    .orderBy(desc(patternGrids.updatedAt));
}

export async function getGridById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(patternGrids)
    .where(and(eq(patternGrids.id, id), eq(patternGrids.userId, userId))).limit(1);
  return result[0] ?? null;
}

export async function saveGrid(grid: InsertPatternGrid) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(patternGrids).values(grid);
}

export async function updateGrid(id: number, userId: number, data: Partial<InsertPatternGrid>) {
  const db = await getDb();
  if (!db) return;
  await db.update(patternGrids).set(data)
    .where(and(eq(patternGrids.id, id), eq(patternGrids.userId, userId)));
}

export async function deleteGrid(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(patternGrids).where(and(eq(patternGrids.id, id), eq(patternGrids.userId, userId)));
}

// ─── Pattern Shares ──────────────────────────────────────────────────────────────────────────────────

export async function createPatternShare(gridId: number, ownerId: number, canEdit = false) {
  const db = await getDb();
  if (!db) return null;
  const token = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  await db.insert(patternShares).values({ gridId, ownerId, shareToken: token, canEdit });
  return token;
}

export async function getGridByShareToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(patternShares).where(eq(patternShares.shareToken, token)).limit(1);
  const share = rows[0];
  if (!share) return null;
  if (share.expiresAt && share.expiresAt < new Date()) return null;
  const gridRows = await db.select().from(patternGrids).where(eq(patternGrids.id, share.gridId)).limit(1);
  const grid = gridRows[0];
  if (!grid) return null;
  return { grid, share };
}

export async function deletePatternShare(token: string, ownerId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(patternShares).where(and(eq(patternShares.shareToken, token), eq(patternShares.ownerId, ownerId)));
}

// ─── Pattern Share Views ──────────────────────────────────────────────────────

/**
 * Vérifie si une brodeuse (par nom normalisé) a déjà consulté ce patron.
 * Utilisé pour la déduplication des notifications.
 */
export async function hasShareViewByName(shareToken: string, viewerName: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const normalized = viewerName.toLowerCase().trim();
  // Récupérer toutes les vues pour ce token (limit 500 pour couvrir les cas réels)
  const rows = await db
    .select({ viewerName: patternShareViews.viewerName })
    .from(patternShareViews)
    .where(eq(patternShareViews.shareToken, shareToken))
    .limit(500);
  // Comparaison normalisée côté JS (LOWER() nécessite du SQL brut avec Drizzle)
  return rows.some(r => r.viewerName.toLowerCase().trim() === normalized);
}

export async function recordShareView(shareToken: string, viewerName: string, viewerEmoji: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(patternShareViews).values({ shareToken, viewerName, viewerEmoji });
}

export async function getShareViewers(shareToken: string) {
  const db = await getDb();
  if (!db) return [];
  // Retourner les 20 dernières vues uniques (par nom)
  const rows = await db
    .select()
    .from(patternShareViews)
    .where(eq(patternShareViews.shareToken, shareToken))
    .orderBy(patternShareViews.viewedAt)
    .limit(50);
  // Dédupliquer par viewerName, garder la vue la plus récente
  const seen = new Map<string, typeof rows[0]>();
  for (const row of rows) {
    seen.set(row.viewerName, row);
  }
  return Array.from(seen.values()).slice(-20);
}

// ─── User Profiles ────────────────────────────────────────────────────────────────────────────────────────────────────

export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return rows[0] ?? null;
}

export async function upsertUserProfile(userId: number, data: Partial<InsertUserProfile>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getUserProfile(userId);
  if (existing) {
    await db.update(userProfiles).set({ ...data, updatedAt: new Date() }).where(eq(userProfiles.userId, userId));
  } else {
    await db.insert(userProfiles).values({ userId, ...data } as InsertUserProfile);
  }
}

export async function getPublicProfiles(limit = 200) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({
    profile: userProfiles,
    user: users,
  }).from(userProfiles)
    .innerJoin(users, eq(users.id, userProfiles.userId))
    .where(eq(userProfiles.isPublic, true))
    .orderBy(desc(userProfiles.lastActiveAt))
    .limit(limit);
  return rows;
}

export async function getProfileWithUser(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select({
    profile: userProfiles,
    user: users,
  }).from(userProfiles)
    .innerJoin(users, eq(users.id, userProfiles.userId))
    .where(eq(userProfiles.userId, userId))
    .limit(1);
  return rows[0] ?? null;
}

export async function getNearbyUsers(lat: number, lng: number, radiusKm = 100, dmcCode?: string) {
  const db = await getDb();
  if (!db) return [];
  // Récupérer tous les profils publics avec géolocalisation
  const profiles = await db.select({
    profile: userProfiles,
    user: users,
  }).from(userProfiles)
    .innerJoin(users, eq(users.id, userProfiles.userId))
    .where(eq(userProfiles.isPublic, true));

  // Filtrer par distance (formule haversine simplifiée)
  const nearby = profiles.filter(({ profile }) => {
    if (!profile.lat || !profile.lng) return false;
    const dLat = (profile.lat - lat) * Math.PI / 180;
    const dLng = (profile.lng - lng) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 +
      Math.cos(lat * Math.PI / 180) * Math.cos(profile.lat * Math.PI / 180) *
      Math.sin(dLng / 2) ** 2;
    const distKm = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return distKm <= radiusKm;
  });

  if (!dmcCode) return nearby;

  // Filtrer par possession du fil DMC
  const userIds = nearby.map(({ profile }) => profile.userId);
  if (userIds.length === 0) return [];

  const collections = await db.select().from(dmcCollection)
    .where(and(eq(dmcCollection.dmcCode, dmcCode), eq(dmcCollection.forExchange, true)));

  const hasColor = new Set(collections.map(c => c.userId));
  return nearby.filter(({ profile }) => hasColor.has(profile.userId));
}

// ─── DMC Collection ───────────────────────────────────────────────────────────

export async function getUserDmcCollection(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dmcCollection).where(eq(dmcCollection.userId, userId)).orderBy(dmcCollection.dmcCode);
}

export async function upsertDmcCollectionItem(userId: number, dmcCode: string, quantity: number, forExchange: boolean) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(dmcCollection)
    .where(and(eq(dmcCollection.userId, userId), eq(dmcCollection.dmcCode, dmcCode)))
    .limit(1);
  if (existing.length > 0) {
    await db.update(dmcCollection).set({ quantity, forExchange, updatedAt: new Date() })
      .where(and(eq(dmcCollection.userId, userId), eq(dmcCollection.dmcCode, dmcCode)));
  } else {
    await db.insert(dmcCollection).values({ userId, dmcCode, quantity, forExchange } as InsertDmcCollectionItem);
  }
}

export async function removeDmcCollectionItem(userId: number, dmcCode: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(dmcCollection).where(and(eq(dmcCollection.userId, userId), eq(dmcCollection.dmcCode, dmcCode)));
}

// ─── SAL Map Pixels (Carte collaborative) ────────────────────────────────────

export async function getSalMapPixels(xMin = 0, xMax = 999, yMin = 0, yMax = 499) {
  const db = await getDb();
  if (!db) return [];
  // Récupérer les pixels dans la zone demandée
  const { between } = await import("drizzle-orm");
  return db.select().from(salMapPixels)
    .where(and(
      between(salMapPixels.x, xMin, xMax),
      between(salMapPixels.y, yMin, yMax),
    ))
    .orderBy(desc(salMapPixels.placedAt))
    .limit(50000);
}

export async function placeMapPixel(data: InsertSalMapPixel) {
  const db = await getDb();
  if (!db) return;
  // Upsert : un seul pixel par case (x,y)
  const existing = await db.select().from(salMapPixels)
    .where(and(eq(salMapPixels.x, data.x), eq(salMapPixels.y, data.y)))
    .limit(1);
  if (existing.length > 0) {
    await db.update(salMapPixels).set({
      dmcCode: data.dmcCode,
      hexColor: data.hexColor,
      userId: data.userId,
      userName: data.userName,
      placedAt: new Date(),
    }).where(and(eq(salMapPixels.x, data.x), eq(salMapPixels.y, data.y)));
  } else {
    await db.insert(salMapPixels).values(data);
  }
}

// ─── SAL Messages (Système de contact) ───────────────────────────────────────

export async function sendSalMessage(data: InsertSalMessage) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(salMessages).values(data);
  return result;
}

export async function getUserMessages(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(salMessages)
    .where(eq(salMessages.toUserId, userId))
    .orderBy(desc(salMessages.createdAt))
    .limit(50);
}

export async function markMessageRead(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(salMessages).set({ read: true })
    .where(and(eq(salMessages.id, id), eq(salMessages.toUserId, userId)));
}
