/**
 * Tests pour les types de points et le Smart Pathing™ ordonné
 */
import { describe, it, expect } from "vitest";
import { getStitchGroup, computeSmartPathOrdered } from "../client/src/lib/stitchTypes";
import type { StitchType, GridCell } from "../client/src/lib/stitchTypes";

// ─── getStitchGroup ───────────────────────────────────────────────────────────
describe("getStitchGroup", () => {
  it("retourne 'fill' pour les points de remplissage", () => {
    const fillTypes: StitchType[] = ["full", "half_fwd", "half_bwd", "quarter_tl", "quarter_tr", "quarter_bl", "quarter_br"];
    for (const t of fillTypes) {
      expect(getStitchGroup(t)).toBe("fill");
    }
  });

  it("retourne 'three_quarter' pour les trois-quarts", () => {
    const threeQ: StitchType[] = ["three_quarter_tl", "three_quarter_tr", "three_quarter_bl", "three_quarter_br"];
    for (const t of threeQ) {
      expect(getStitchGroup(t)).toBe("three_quarter");
    }
  });

  it("retourne 'backstitch' pour les arrière-points", () => {
    const bs: StitchType[] = ["backstitch_h", "backstitch_v", "backstitch_d1", "backstitch_d2"];
    for (const t of bs) {
      expect(getStitchGroup(t)).toBe("backstitch");
    }
  });

  it("retourne 'french_knot' pour le nœud français", () => {
    expect(getStitchGroup("french_knot")).toBe("french_knot");
  });
});

// ─── computeSmartPathOrdered ──────────────────────────────────────────────────
function makeGrid(specs: { r: number; c: number; dmc: string; type?: StitchType }[]): GridCell[][] {
  const rows = Math.max(...specs.map(s => s.r)) + 1;
  const cols = Math.max(...specs.map(s => s.c)) + 1;
  const grid: GridCell[][] = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => ({ dmc: null, hex: null }))
  );
  for (const s of specs) {
    grid[s.r]![s.c] = { dmc: s.dmc, hex: "#000000", stitchType: s.type ?? "full" };
  }
  return grid;
}

describe("computeSmartPathOrdered", () => {
  it("sépare les points dans les bons groupes", () => {
    const grid = makeGrid([
      { r: 0, c: 0, dmc: "310", type: "full" },
      { r: 0, c: 1, dmc: "310", type: "three_quarter_tl" },
      { r: 0, c: 2, dmc: "310", type: "backstitch_h" },
      { r: 0, c: 3, dmc: "310", type: "french_knot" },
    ]);
    const result = computeSmartPathOrdered(grid, "310");
    expect(result.fillPath).toHaveLength(1);
    expect(result.threeQuarterPath).toHaveLength(1);
    expect(result.backstitchPath).toHaveLength(1);
    expect(result.frenchKnotPath).toHaveLength(1);
  });

  it("ignore les cellules d'une autre couleur", () => {
    const grid = makeGrid([
      { r: 0, c: 0, dmc: "310", type: "full" },
      { r: 0, c: 1, dmc: "321", type: "full" },
    ]);
    const result = computeSmartPathOrdered(grid, "310");
    expect(result.fillPath).toHaveLength(1);
  });

  it("ignore les cellules déjà marquées comme brodées", () => {
    const grid = makeGrid([
      { r: 0, c: 0, dmc: "310", type: "full" },
    ]);
    grid[0]![0]!.done = true;
    const result = computeSmartPathOrdered(grid, "310");
    expect(result.fillPath).toHaveLength(0);
  });

  it("retourne des tableaux vides si aucun point de la couleur", () => {
    const grid = makeGrid([{ r: 0, c: 0, dmc: "321", type: "full" }]);
    const result = computeSmartPathOrdered(grid, "310");
    expect(result.fillPath).toHaveLength(0);
    expect(result.threeQuarterPath).toHaveLength(0);
    expect(result.backstitchPath).toHaveLength(0);
    expect(result.frenchKnotPath).toHaveLength(0);
  });

  it("l'ordre global est fill → three_quarter → backstitch → french_knot", () => {
    const grid = makeGrid([
      { r: 0, c: 0, dmc: "310", type: "full" },
      { r: 1, c: 0, dmc: "310", type: "three_quarter_tl" },
      { r: 2, c: 0, dmc: "310", type: "backstitch_v" },
      { r: 3, c: 0, dmc: "310", type: "french_knot" },
    ]);
    const result = computeSmartPathOrdered(grid, "310");
    // Les fill viennent en premier
    expect(result.fillPath[0]).toEqual([0, 0]);
    // Les three_quarter après
    expect(result.threeQuarterPath[0]).toEqual([1, 0]);
    // Les backstitch après
    expect(result.backstitchPath[0]).toEqual([2, 0]);
    // Les french_knot en dernier
    expect(result.frenchKnotPath[0]).toEqual([3, 0]);
  });
});

// ─── DMC color database ───────────────────────────────────────────────────────
import { DMC_FULL_PALETTE, findNearestDmc } from "../shared/dmcColors";

describe("DMC_FULL_PALETTE", () => {
  it("contient au moins 400 couleurs", () => {
    expect(DMC_FULL_PALETTE.length).toBeGreaterThanOrEqual(400);
  });

  it("chaque couleur a un code DMC, un nom et un hex valide", () => {
    for (const color of DMC_FULL_PALETTE) {
      expect(color.dmc).toBeTruthy();
      expect(color.name).toBeTruthy();
      expect(color.hex).toMatch(/^#[0-9A-Fa-f]{6}$/);
    }
  });

  it("findNearestDmc retourne la couleur DMC la plus proche du blanc", () => {
    const result = findNearestDmc(255, 255, 255);
    expect(result).toBeTruthy();
    expect(result.hex).toBeTruthy();
  });

  it("findNearestDmc retourne la couleur DMC la plus proche du noir", () => {
    const result = findNearestDmc(0, 0, 0);
    expect(result).toBeTruthy();
    // Le noir DMC 310 a hex #1A1A1A — la distance doit être très faible
    const r = parseInt(result.hex.slice(1, 3), 16);
    const g = parseInt(result.hex.slice(3, 5), 16);
    const b = parseInt(result.hex.slice(5, 7), 16);
    const dist = Math.sqrt(r * r + g * g + b * b);
    expect(dist).toBeLessThan(60);
  });
});
