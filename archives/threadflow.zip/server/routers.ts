import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, adminProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";
import { generateImage } from "./_core/imageGeneration";
import { notifyOwner } from "./_core/notification";
import {
  addToWaitlist, getWaitlistCount, getWaitlistPosition,
  getAllBlogPosts, getBlogPostBySlug,
  getAdminWaitlistEntries, getWaitlistStats, markWaitlistNotified,
  getUserInventory, addInventoryItem, updateInventoryItem, deleteInventoryItem,
  getUserProjects, getProjectById, createProject, updateProject, deleteProject,
  getUserSessions, createSession, deleteSession, getUserStats,
  getAllSalEvents, getSalEventById, getUserSalParticipations, joinSal, leaveSal,
  getUserGrids, getGridById, saveGrid, updateGrid, deleteGrid,
  createPatternShare, getGridByShareToken, deletePatternShare, recordShareView, getShareViewers, hasShareViewByName,
  // SAL Sync v2
  getUserProfile, upsertUserProfile, getPublicProfiles, getProfileWithUser, getNearbyUsers,
  getUserDmcCollection, upsertDmcCollectionItem, removeDmcCollectionItem,
  getSalMapPixels, placeMapPixel,
  sendSalMessage, getUserMessages, markMessageRead,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Waitlist ───────────────────────────────────────────────────────────────
  waitlist: router({
    join: publicProcedure
      .input(z.object({
        email: z.string().email("Email invalide"),
        firstName: z.string().max(100).optional(),
        source: z.string().max(100).optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await addToWaitlist({
          email: input.email.toLowerCase().trim(),
          firstName: input.firstName,
          source: input.source ?? "website",
        });
        if (!result.alreadyRegistered) {
          await notifyOwner({
            title: "🧵 Nouvelle inscription ThreadFlow",
            content: `${input.email} vient de rejoindre la liste d'attente.${result.goldenNeedle ? " 🏅 Badge Golden Needle !" : ""}`,
          }).catch(() => {});
        }
        return {
          success: true,
          alreadyRegistered: result.alreadyRegistered,
          goldenNeedle: result.goldenNeedle ?? false,
          message: result.alreadyRegistered
            ? "Vous êtes déjà sur la liste d'attente !"
            : result.goldenNeedle
            ? "Bienvenue ! Vous faites partie des 1000 premières — badge Golden Needle 🏅"
            : "Bienvenue dans la communauté ThreadFlow !",
        };
      }),
    count: publicProcedure.query(async () => {
      const count = await getWaitlistCount();
      return { count };
    }),
    position: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input }) => getWaitlistPosition(input.email.toLowerCase().trim())),
  }),

  // ─── Blog ───────────────────────────────────────────────────────────────────
  blog: router({
    list: publicProcedure.query(async () => getAllBlogPosts()),
    bySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => getBlogPostBySlug(input.slug)),
  }),

  // ─── Admin ──────────────────────────────────────────────────────────────────
  admin: router({
    waitlistList: adminProcedure
      .input(z.object({
        page: z.number().min(1).default(1),
        limit: z.number().min(1).max(200).default(50),
        search: z.string().optional(),
        goldenNeedleOnly: z.boolean().optional(),
      }))
      .query(async ({ input }) => getAdminWaitlistEntries(input)),
    stats: adminProcedure.query(async () => getWaitlistStats()),
    exportCsv: adminProcedure.mutation(async () => {
      const entries = await getAdminWaitlistEntries({ page: 1, limit: 10000 });
      const header = "Position,Email,Prénom,Source,Golden Needle,Date d'inscription,Notifié";
      const rows = entries.items.map((e, i) =>
        [i + 1, `"${e.email}"`, `"${e.firstName ?? ""}"`, `"${e.source ?? ""}"`,
          e.goldenNeedle ? "Oui" : "Non",
          new Date(e.createdAt).toISOString().split("T")[0],
          e.notified ? "Oui" : "Non"].join(",")
      );
      return { csv: [header, ...rows].join("\n"), count: entries.items.length };
    }),
    markNotified: adminProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .mutation(async ({ input }) => {
        await markWaitlistNotified(input.ids);
        return { success: true };
      }),
  }),

  // ─── Inventory ──────────────────────────────────────────────────────────────
  inventory: router({
    list: protectedProcedure.query(async ({ ctx }) => getUserInventory(ctx.user.id)),
    add: protectedProcedure
      .input(z.object({
        dmcNumber: z.string().min(1).max(20),
        colorName: z.string().max(100).optional(),
        hexColor: z.string().max(7).optional(),
        skeinsOwned: z.number().min(0).default(1),
        skeinsUsed: z.number().min(0).default(0),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await addInventoryItem({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        dmcNumber: z.string().max(20).optional(),
        colorName: z.string().max(100).optional(),
        hexColor: z.string().max(7).optional(),
        skeinsOwned: z.number().min(0).optional(),
        skeinsUsed: z.number().min(0).optional(),
        onShoppingList: z.boolean().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await updateInventoryItem(id, ctx.user.id, data);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteInventoryItem(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── Projects ───────────────────────────────────────────────────────────────
  projects: router({
    list: protectedProcedure.query(async ({ ctx }) => getUserProjects(ctx.user.id)),
    byId: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => getProjectById(input.id, ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(200),
        patternName: z.string().max(200).optional(),
        patternImageUrl: z.string().max(500).optional(),
        coverImageUrl: z.string().max(500).optional(),
        gridWidth: z.number().min(0).default(0),
        gridHeight: z.number().min(0).default(0),
        totalStitches: z.number().min(0).default(0),
        fabricType: z.string().max(100).optional(),
        fabricCount: z.number().optional(),
        designer: z.string().max(200).optional(),
        estimatedHours: z.number().optional(),
        notes: z.string().optional(),
        threadsRequired: z.string().optional(),
        tags: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await createProject({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().max(200).optional(),
        patternName: z.string().max(200).optional(),
        patternImageUrl: z.string().max(500).optional(),
        coverImageUrl: z.string().max(500).optional(),
        gridWidth: z.number().optional(),
        gridHeight: z.number().optional(),
        totalStitches: z.number().optional(),
        completedStitches: z.number().optional(),
        status: z.enum(["not_started", "in_progress", "completed", "paused"]).optional(),
        fabricType: z.string().max(100).optional(),
        fabricCount: z.number().optional(),
        designer: z.string().max(200).optional(),
        estimatedHours: z.number().optional(),
        notes: z.string().optional(),
        threadsRequired: z.string().optional(),
        tags: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await updateProject(id, ctx.user.id, data);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteProject(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── Stitch Sessions ────────────────────────────────────────────────────────
  sessions: router({
    list: protectedProcedure
      .input(z.object({ projectId: z.number().optional() }))
      .query(async ({ ctx, input }) => getUserSessions(ctx.user.id, input.projectId)),
    stats: protectedProcedure.query(async ({ ctx }) => getUserStats(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        durationMinutes: z.number().min(0).default(0),
        stitchesCompleted: z.number().min(0).default(0),
        photoUrl: z.string().max(500).optional(),
        mood: z.enum(["relaxed", "focused", "creative", "tired", "happy"]).optional(),
        notes: z.string().optional(),
        threadsUsed: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await createSession({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteSession(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── SAL Events ─────────────────────────────────────────────────────────────
  sal: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const [events, participations] = await Promise.all([
        getAllSalEvents(),
        getUserSalParticipations(ctx.user.id),
      ]);
      const joinedIds = new Set(participations.map(p => p.salId));
      return events.map(e => ({ ...e, isJoined: joinedIds.has(e.id) }));
    }),
    byId: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const [event, participations] = await Promise.all([
          getSalEventById(input.id),
          getUserSalParticipations(ctx.user.id),
        ]);
        if (!event) return null;
        const isJoined = participations.some(p => p.salId === input.id);
        return { ...event, isJoined };
      }),
    join: protectedProcedure
      .input(z.object({ salId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await joinSal(input.salId, ctx.user.id);
        return { success: true };
      }),
    leave: protectedProcedure
      .input(z.object({ salId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await leaveSal(input.salId, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── File Upload ────────────────────────────────────────────────────────────
  upload: router({
    photo: protectedProcedure
      .input(z.object({
        base64: z.string(), // data:image/...;base64,...
        filename: z.string().max(200),
        mimeType: z.string().max(100),
      }))
      .mutation(async ({ ctx, input }) => {
        // Decode base64 data URL
        const base64Data = input.base64.replace(/^data:[^;]+;base64,/, "");
        const buffer = Buffer.from(base64Data, "base64");
        const key = `diary-photos/${ctx.user.id}/${Date.now()}-${input.filename}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        return { url };
      }),
  }),

  // ─── Pattern Grids ──────────────────────────────────────────────────────────
  // ─── Profile brodeuse ──────────────────────────────────────────────────────
  profile: router({
    me: protectedProcedure.query(async ({ ctx }) => {
      const profile = await getUserProfile(ctx.user.id);
      return profile;
    }),

    update: protectedProcedure
      .input(z.object({
        bio: z.string().max(500).optional(),
        avatarUrl: z.string().url().optional().or(z.literal("")),
        city: z.string().max(100).optional(),
        country: z.string().max(100).optional(),
        lat: z.number().min(-90).max(90).optional(),
        lng: z.number().min(-180).max(180).optional(),
        availableForExchange: z.boolean().optional(),
        shareRadius: z.number().min(0).max(5000).optional(),
        isPublic: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await upsertUserProfile(ctx.user.id, {
          ...input,
          lastActiveAt: new Date(),
        });
        return { success: true };
      }),

    getPublic: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return getProfileWithUser(input.userId);
      }),

    allPublic: publicProcedure.query(async () => {
      return getPublicProfiles(500);
    }),
  }),

  // ─── Collection DMC publique ──────────────────────────────────────────────
  community: router({
    myCollection: protectedProcedure.query(async ({ ctx }) => {
      return getUserDmcCollection(ctx.user.id);
    }),

    upsertItem: protectedProcedure
      .input(z.object({
        dmcCode: z.string().max(20),
        quantity: z.number().min(0).max(999),
        forExchange: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        await upsertDmcCollectionItem(ctx.user.id, input.dmcCode, input.quantity, input.forExchange);
        return { success: true };
      }),

    removeItem: protectedProcedure
      .input(z.object({ dmcCode: z.string().max(20) }))
      .mutation(async ({ ctx, input }) => {
        await removeDmcCollectionItem(ctx.user.id, input.dmcCode);
        return { success: true };
      }),

    nearbyUsers: publicProcedure
      .input(z.object({
        lat: z.number(),
        lng: z.number(),
        radiusKm: z.number().min(1).max(5000).default(100),
        dmcCode: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return getNearbyUsers(input.lat, input.lng, input.radiusKm, input.dmcCode);
      }),

    sendMessage: protectedProcedure
      .input(z.object({
        toUserId: z.number(),
        subject: z.string().max(200).optional(),
        content: z.string().max(2000),
        dmcCode: z.string().max(20).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await sendSalMessage({
          fromUserId: ctx.user.id,
          toUserId: input.toUserId,
          subject: input.subject,
          content: input.content,
          dmcCode: input.dmcCode,
        });
        // Notifier le destinataire
        await notifyOwner({
          title: `🧵 Nouveau message ThreadFlow`,
          content: `Message de ${ctx.user.name ?? "une brodeuse"} : ${input.content.slice(0, 100)}`,
        }).catch(() => {});
        return { success: true };
      }),

    myMessages: protectedProcedure.query(async ({ ctx }) => {
      return getUserMessages(ctx.user.id);
    }),

    markRead: protectedProcedure
      .input(z.object({ messageId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await markMessageRead(input.messageId, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── Carte collaborative mondiale ─────────────────────────────────────────
  salMap: router({
    getPixels: publicProcedure
      .input(z.object({
        xMin: z.number().min(0).max(999).default(0),
        xMax: z.number().min(0).max(999).default(999),
        yMin: z.number().min(0).max(499).default(0),
        yMax: z.number().min(0).max(499).default(499),
      }))
      .query(async ({ input }) => {
        return getSalMapPixels(input.xMin, input.xMax, input.yMin, input.yMax);
      }),

    placePixel: protectedProcedure
      .input(z.object({
        x: z.number().min(0).max(999),
        y: z.number().min(0).max(499),
        dmcCode: z.string().max(20),
        hexColor: z.string().max(7),
      }))
      .mutation(async ({ ctx, input }) => {
        await placeMapPixel({
          x: input.x,
          y: input.y,
          dmcCode: input.dmcCode,
          hexColor: input.hexColor,
          userId: ctx.user.id,
          userName: ctx.user.name ?? undefined,
        });
        return { success: true };
      }),
  }),

  grids: router({
    list: protectedProcedure.query(async ({ ctx }) => getUserGrids(ctx.user.id)),
    byId: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => getGridById(input.id, ctx.user.id)),
    save: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(200),
        width: z.number().min(5).max(200).default(20),
        height: z.number().min(5).max(200).default(20),
        gridData: z.string().optional(),
        projectId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await saveGrid({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().max(200).optional(),
        gridData: z.string().optional(),
        width: z.number().optional(),
        height: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await updateGrid(id, ctx.user.id, data);
        return { success: true };
      }),
     delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteGrid(input.id, ctx.user.id);
        return { success: true };
      }),
    // ─── Partage & Collaboration
    createShareLink: protectedProcedure
      .input(z.object({ gridId: z.number(), canEdit: z.boolean().default(false) }))
      .mutation(async ({ ctx, input }) => {
        const token = await createPatternShare(input.gridId, ctx.user.id, input.canEdit);
        if (!token) throw new Error('Impossible de créer le lien de partage');
        return { token };
      }),
    getByShareToken: publicProcedure
      .input(z.object({ token: z.string() }))
      .query(async ({ input }) => {
        const result = await getGridByShareToken(input.token);
        if (!result) return null;
        return { grid: result.grid, canEdit: result.share.canEdit };
      }),
    deleteShareLink: protectedProcedure
      .input(z.object({ token: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await deletePatternShare(input.token, ctx.user.id);
        return { success: true };
      }),
    recordShareView: publicProcedure
      .input(z.object({
        shareToken: z.string(),
        viewerName: z.string().max(100).default('Brodeuse anonyme'),
        viewerEmoji: z.string().max(8).default('🧵'),
      }))
      .mutation(async ({ input }) => {
        // Vérifier si c'est une première visite pour cette brodeuse (déduplication robuste)
        const alreadyVisited = await hasShareViewByName(input.shareToken, input.viewerName);
        const isFirstVisit = !alreadyVisited;

        // Enregistrer la vue en base
        await recordShareView(input.shareToken, input.viewerName, input.viewerEmoji);

        // Notifier la propriétaire uniquement à la première visite
        if (isFirstVisit) {
          const shareData = await getGridByShareToken(input.shareToken);
          const patternTitle = shareData?.grid?.name || 'Patron sans titre';
          const visitTime = new Date().toLocaleString('fr-FR', {
            timeZone: 'Europe/Paris',
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
          });
          // Notification asynchrone (ne bloque pas la réponse)
          notifyOwner({
            title: `${input.viewerEmoji} ${input.viewerName} consulte votre patron`,
            content: `**${input.viewerName}** vient d'ouvrir votre patron « **${patternTitle}** » pour la première fois.\n\n⏰ ${visitTime}\n\nRetrouvez toutes les brodeuses qui ont consulté ce patron dans l'éditeur ThreadFlow.`,
          }).catch(() => {}); // Erreur silencieuse — ne pas bloquer la visite
        }

        return { success: true, isFirstVisit };
      }),
    getShareViewers: protectedProcedure
      .input(z.object({ shareToken: z.string() }))
      .query(async ({ input }) => {
        const viewers = await getShareViewers(input.shareToken);
        return viewers;
      }),
    // ─── Générateur IA ─────────────────────────────────────────────────────────
    // Approche simplifiée : le serveur génère l'image et retourne l'URL.
    // La conversion Canvas → grille DMC est faite côté client (comme StitchLab).
    generateAI: protectedProcedure
      .input(z.object({
        prompt: z.string().min(3).max(500),
        style: z.enum(["pixel-art", "flat-illustration", "realistic", "watercolor", "minimalist"]).default("pixel-art"),
      }))
      .mutation(async ({ input }) => {
        const enrichedPrompt = buildEmbroideryPrompt(input.prompt, input.style);
        const { url: imageUrl } = await generateImage({ prompt: enrichedPrompt });
        if (!imageUrl) throw new Error("La génération d'image a échoué");
        return { imageUrl };
      }),
   }),

  // ─── Contact ───────────────────────────────────────────────────────────────────────────────────
  contact: router({
    send: publicProcedure
      .input(z.object({
        name: z.string().min(1).max(100),
        email: z.string().email(),
        subject: z.string().min(1).max(200),
        message: z.string().min(10).max(2000),
      }))
      .mutation(async ({ input }) => {
        const sent = await notifyOwner({
          title: `📬 Nouveau message de contact — ${input.subject}`,
          content: `**De :** ${input.name} (${input.email})\n\n**Sujet :** ${input.subject}\n\n**Message :**\n${input.message}`,
        });
        return { success: true, notified: sent };
      }),
  }),
});
export type AppRouter = typeof appRouter;


/**
 * Construit un prompt optimisé pour la génération d'images destinées à la broderie.
 * Inspiré de l'approche StitchLab.
 */
function buildEmbroideryPrompt(userPrompt: string, style: string): string {
  const styleInstructions: Record<string, string> = {
    'pixel-art': 'pixel art style, low resolution grid, clear distinct colors, no gradients, sharp edges, 8-bit aesthetic',
    'flat-illustration': 'flat illustration style, solid colors, minimal shading, clean outlines, vector-like, simple shapes',
    'realistic': 'simplified realistic style, reduced color palette, clear shapes, minimal background detail, suitable for cross-stitch',
    'watercolor': 'soft watercolor style with limited palette, gentle color transitions, simple composition, floral aesthetic',
    'minimalist': 'minimalist design, very few colors, geometric shapes, clean lines, modern aesthetic, simple composition',
  };
  const styleGuide = styleInstructions[style] || styleInstructions['pixel-art'];
  return `Create an image for a cross-stitch embroidery pattern: ${userPrompt}. Style: ${styleGuide}. The image should have a limited color palette (max 15-20 distinct colors), clear shapes, no text, no watermarks, centered composition on a plain background. The design should be easily convertible to a grid-based pattern.`;
}
