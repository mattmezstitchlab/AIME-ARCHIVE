ALTER TABLE `pattern_grids` MODIFY COLUMN `gridData` text;--> statement-breakpoint
ALTER TABLE `sal_events` MODIFY COLUMN `parts` text;--> statement-breakpoint
ALTER TABLE `sal_events` MODIFY COLUMN `tags` text;--> statement-breakpoint
ALTER TABLE `stitch_sessions` MODIFY COLUMN `threadsUsed` text;--> statement-breakpoint
ALTER TABLE `thread_projects` MODIFY COLUMN `threadsRequired` text;--> statement-breakpoint
ALTER TABLE `thread_projects` MODIFY COLUMN `tags` text;