CREATE TABLE `pattern_share_views` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shareToken` varchar(64) NOT NULL,
	`viewerName` varchar(100) NOT NULL DEFAULT 'Brodeuse anonyme',
	`viewerEmoji` varchar(8) NOT NULL DEFAULT '🧵',
	`viewedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pattern_share_views_id` PRIMARY KEY(`id`)
);
