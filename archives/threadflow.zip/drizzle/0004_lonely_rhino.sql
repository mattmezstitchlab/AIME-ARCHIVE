CREATE TABLE `dmc_collection` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dmcCode` varchar(20) NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`forExchange` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dmc_collection_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sal_map_pixels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`x` int NOT NULL,
	`y` int NOT NULL,
	`dmcCode` varchar(20) NOT NULL,
	`hexColor` varchar(7) NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(200),
	`placedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sal_map_pixels_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sal_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fromUserId` int NOT NULL,
	`toUserId` int NOT NULL,
	`subject` varchar(200),
	`content` text NOT NULL,
	`dmcCode` varchar(20),
	`read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sal_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bio` text,
	`avatarUrl` varchar(500),
	`city` varchar(100),
	`country` varchar(100),
	`lat` float,
	`lng` float,
	`availableForExchange` boolean NOT NULL DEFAULT false,
	`shareRadius` int NOT NULL DEFAULT 50,
	`isPublic` boolean NOT NULL DEFAULT true,
	`lastActiveAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_profiles_userId_unique` UNIQUE(`userId`)
);
