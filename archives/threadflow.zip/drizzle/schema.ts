import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  float,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Waitlist ─────────────────────────────────────────────────────────────────
export const waitlist = mysqlTable("waitlist", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  firstName: varchar("firstName", { length: 100 }),
  source: varchar("source", { length: 100 }).default("website"),
  referralCode: varchar("referralCode", { length: 32 }),
  goldenNeedle: boolean("goldenNeedle").default(false).notNull(),
  notified: boolean("notified").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WaitlistEntry = typeof waitlist.$inferSelect;
export type InsertWaitlistEntry = typeof waitlist.$inferInsert;

// ─── Blog Posts ───────────────────────────────────────────────────────────────
export const blogPosts = mysqlTable("blog_posts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: varchar("title", { length: 300 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImage: varchar("coverImage", { length: 500 }),
  category: varchar("category", { length: 100 }),
  tags: text("tags"),
  readingTime: int("readingTime").default(5),
  published: boolean("published").default(true).notNull(),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;

// ─── Thread Inventory (Inventaire DMC) ───────────────────────────────────────
export const threadInventory = mysqlTable("thread_inventory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  dmcNumber: varchar("dmcNumber", { length: 20 }).notNull(),
  colorName: varchar("colorName", { length: 100 }),
  hexColor: varchar("hexColor", { length: 7 }).default("#C4956A"),
  skeinsOwned: float("skeinsOwned").default(0).notNull(),
  skeinsUsed: float("skeinsUsed").default(0).notNull(),
  metersRemaining: float("metersRemaining").default(0).notNull(),
  onShoppingList: boolean("onShoppingList").default(false).notNull(),
  notes: text("notes"),
  photoUrl: varchar("photoUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ThreadInventoryItem = typeof threadInventory.$inferSelect;
export type InsertThreadInventoryItem = typeof threadInventory.$inferInsert;

// ─── Thread Projects (Projets de broderie) ────────────────────────────────────
export const threadProjects = mysqlTable("thread_projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  patternName: varchar("patternName", { length: 200 }),
  patternImageUrl: varchar("patternImageUrl", { length: 500 }),
  coverImageUrl: varchar("coverImageUrl", { length: 500 }),
  gridWidth: int("gridWidth").default(0),
  gridHeight: int("gridHeight").default(0),
  totalStitches: int("totalStitches").default(0),
  completedStitches: int("completedStitches").default(0),
  status: mysqlEnum("status", ["not_started", "in_progress", "completed", "paused"])
    .default("not_started")
    .notNull(),
  fabricType: varchar("fabricType", { length: 100 }),
  fabricCount: int("fabricCount"),
  designer: varchar("designer", { length: 200 }),
  estimatedHours: float("estimatedHours"),
  notes: text("notes"),
  // JSON array: [{ dmc: "310", name: "Black", needed_meters: 8, hex: "#000000" }]
  threadsRequired: text("threadsRequired"),
  tags: text("tags"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ThreadProject = typeof threadProjects.$inferSelect;
export type InsertThreadProject = typeof threadProjects.$inferInsert;

// ─── Stitch Sessions (Journal de broderie) ────────────────────────────────────
export const stitchSessions = mysqlTable("stitch_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId").notNull(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  durationMinutes: int("durationMinutes").default(0).notNull(),
  stitchesCompleted: int("stitchesCompleted").default(0).notNull(),
  photoUrl: varchar("photoUrl", { length: 500 }),
  mood: mysqlEnum("mood", ["relaxed", "focused", "creative", "tired", "happy"]).default("focused"),
  notes: text("notes"),
  // JSON array: [{ dmc: "310", name: "Black" }]
  threadsUsed: text("threadsUsed"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StitchSession = typeof stitchSessions.$inferSelect;
export type InsertStitchSession = typeof stitchSessions.$inferInsert;

// ─── SAL Events (Stitch-Alongs) ───────────────────────────────────────────────
export const salEvents = mysqlTable("sal_events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  designer: varchar("designer", { length: 200 }),
  description: text("description"),
  coverImageUrl: varchar("coverImageUrl", { length: 500 }),
  startDate: varchar("startDate", { length: 10 }),
  totalParts: int("totalParts").default(1).notNull(),
  currentPart: int("currentPart").default(1).notNull(),
  participantsCount: int("participantsCount").default(0).notNull(),
  status: mysqlEnum("status", ["upcoming", "active", "completed"]).default("upcoming").notNull(),
  // JSON array of parts: [{ part: 1, title: "...", releaseDate: "...", pdfUrl: "..." }]
  parts: text("parts"),
  tags: text("tags"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SalEvent = typeof salEvents.$inferSelect;
export type InsertSalEvent = typeof salEvents.$inferInsert;

// ─── SAL Participants ─────────────────────────────────────────────────────────
export const salParticipants = mysqlTable("sal_participants", {
  id: int("id").autoincrement().primaryKey(),
  salId: int("salId").notNull(),
  userId: int("userId").notNull(),
  currentPart: int("currentPart").default(0).notNull(),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

export type SalParticipant = typeof salParticipants.$inferSelect;
export type InsertSalParticipant = typeof salParticipants.$inferInsert;

// ─── Pattern Grids (Patrons sauvegardés) ─────────────────────────────────────
export const patternGrids = mysqlTable("pattern_grids", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId"),
  name: varchar("name", { length: 200 }).notNull(),
  width: int("width").default(20).notNull(),
  height: int("height").default(20).notNull(),
  // JSON: { "x,y": "dmcNumber" } — sparse map of filled cells
  gridData: text("gridData"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PatternGrid = typeof patternGrids.$inferSelect;
export type InsertPatternGrid = typeof patternGrids.$inferInsert;

// ─── Pattern Shares (Liens de partage de patrons) ───────────────────────────
export const patternShares = mysqlTable("pattern_shares", {
  id: int("id").autoincrement().primaryKey(),
  gridId: int("gridId").notNull(),
  ownerId: int("ownerId").notNull(),
  shareToken: varchar("shareToken", { length: 64 }).notNull().unique(),
  canEdit: boolean("canEdit").default(false).notNull(),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PatternShare = typeof patternShares.$inferSelect;

// ─── Pattern Share Views (Brodeuses ayant consulté un patron partagé) ────
export const patternShareViews = mysqlTable("pattern_share_views", {
  id: int("id").autoincrement().primaryKey(),
  shareToken: varchar("shareToken", { length: 64 }).notNull(),
  viewerName: varchar("viewerName", { length: 100 }).notNull().default("Brodeuse anonyme"),
  viewerEmoji: varchar("viewerEmoji", { length: 8 }).notNull().default("🧵"),
  viewedAt: timestamp("viewedAt").defaultNow().notNull(),
});
export type PatternShareView = typeof patternShareViews.$inferSelect;

// ─── User Profiles (Profils brodeuses publics) ────────────────────────────
export const userProfiles = mysqlTable("user_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  bio: text("bio"),
  avatarUrl: varchar("avatarUrl", { length: 500 }),
  city: varchar("city", { length: 100 }),
  country: varchar("country", { length: 100 }),
  lat: float("lat"),
  lng: float("lng"),
  // Disponibilité pour échange/dépannage de fils
  availableForExchange: boolean("availableForExchange").default(false).notNull(),
  // Rayon de partage en km (0 = pas de limite)
  shareRadius: int("shareRadius").default(50).notNull(),
  // Profil public ou privé
  isPublic: boolean("isPublic").default(true).notNull(),
  // Dernière activité (pour le clignotement sur la carte)
  lastActiveAt: timestamp("lastActiveAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

// ─── DMC Collection publique (fils disponibles pour échange) ─────────────────
export const dmcCollection = mysqlTable("dmc_collection", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  dmcCode: varchar("dmcCode", { length: 20 }).notNull(),
  quantity: int("quantity").default(1).notNull(), // nombre de pelotes
  forExchange: boolean("forExchange").default(false).notNull(), // disponible pour échange
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DmcCollectionItem = typeof dmcCollection.$inferSelect;
export type InsertDmcCollectionItem = typeof dmcCollection.$inferInsert;

// ─── SAL Map Pixels (Carte collaborative mondiale pixel art) ──────────────────
// La carte est une grille de 1000×500 représentant le monde entier
// Chaque pixel correspond à une zone géographique
export const salMapPixels = mysqlTable("sal_map_pixels", {
  id: int("id").autoincrement().primaryKey(),
  x: int("x").notNull(), // 0-999
  y: int("y").notNull(), // 0-499
  dmcCode: varchar("dmcCode", { length: 20 }).notNull(),
  hexColor: varchar("hexColor", { length: 7 }).notNull(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 200 }),
  placedAt: timestamp("placedAt").defaultNow().notNull(),
});

export type SalMapPixel = typeof salMapPixels.$inferSelect;
export type InsertSalMapPixel = typeof salMapPixels.$inferInsert;

// ─── SAL Messages (Système de contact entre brodeuses) ───────────────────────
export const salMessages = mysqlTable("sal_messages", {
  id: int("id").autoincrement().primaryKey(),
  fromUserId: int("fromUserId").notNull(),
  toUserId: int("toUserId").notNull(),
  subject: varchar("subject", { length: 200 }),
  content: text("content").notNull(),
  dmcCode: varchar("dmcCode", { length: 20 }), // fil concerné (si échange)
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SalMessage = typeof salMessages.$inferSelect;
export type InsertSalMessage = typeof salMessages.$inferInsert;
