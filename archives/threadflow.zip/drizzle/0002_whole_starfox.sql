CREATE TABLE `pattern_grids` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`projectId` int,
	`name` varchar(200) NOT NULL,
	`width` int NOT NULL DEFAULT 20,
	`height` int NOT NULL DEFAULT 20,
	`gridData` text DEFAULT ('{}'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pattern_grids_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sal_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`designer` varchar(200),
	`description` text,
	`coverImageUrl` varchar(500),
	`startDate` varchar(10),
	`totalParts` int NOT NULL DEFAULT 1,
	`currentPart` int NOT NULL DEFAULT 1,
	`participantsCount` int NOT NULL DEFAULT 0,
	`status` enum('upcoming','active','completed') NOT NULL DEFAULT 'upcoming',
	`parts` text DEFAULT ('[]'),
	`tags` text DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sal_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sal_participants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`salId` int NOT NULL,
	`userId` int NOT NULL,
	`currentPart` int NOT NULL DEFAULT 0,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sal_participants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stitch_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`projectId` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`durationMinutes` int NOT NULL DEFAULT 0,
	`stitchesCompleted` int NOT NULL DEFAULT 0,
	`photoUrl` varchar(500),
	`mood` enum('relaxed','focused','creative','tired','happy') DEFAULT 'focused',
	`notes` text,
	`threadsUsed` text DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stitch_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `thread_inventory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dmcNumber` varchar(20) NOT NULL,
	`colorName` varchar(100),
	`hexColor` varchar(7) DEFAULT '#C4956A',
	`skeinsOwned` float NOT NULL DEFAULT 0,
	`skeinsUsed` float NOT NULL DEFAULT 0,
	`metersRemaining` float NOT NULL DEFAULT 0,
	`onShoppingList` boolean NOT NULL DEFAULT false,
	`notes` text,
	`photoUrl` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `thread_inventory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `thread_projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(200) NOT NULL,
	`patternName` varchar(200),
	`patternImageUrl` varchar(500),
	`coverImageUrl` varchar(500),
	`gridWidth` int DEFAULT 0,
	`gridHeight` int DEFAULT 0,
	`totalStitches` int DEFAULT 0,
	`completedStitches` int DEFAULT 0,
	`status` enum('not_started','in_progress','completed','paused') NOT NULL DEFAULT 'not_started',
	`fabricType` varchar(100),
	`fabricCount` int,
	`designer` varchar(200),
	`estimatedHours` float,
	`notes` text,
	`threadsRequired` text DEFAULT ('[]'),
	`tags` text DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `thread_projects_id` PRIMARY KEY(`id`)
);
