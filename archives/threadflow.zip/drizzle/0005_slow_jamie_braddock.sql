CREATE TABLE `pattern_shares` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gridId` int NOT NULL,
	`ownerId` int NOT NULL,
	`shareToken` varchar(64) NOT NULL,
	`canEdit` boolean NOT NULL DEFAULT false,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pattern_shares_id` PRIMARY KEY(`id`),
	CONSTRAINT `pattern_shares_shareToken_unique` UNIQUE(`shareToken`)
);
