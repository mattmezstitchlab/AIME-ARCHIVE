import { createConnection } from "mysql2/promise";
import { config } from "dotenv";
config();

const conn = await createConnection(process.env.DATABASE_URL);

const tables = [
  `CREATE TABLE IF NOT EXISTS \`pattern_grids\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`userId\` int NOT NULL,
    \`projectId\` int,
    \`name\` varchar(200) NOT NULL,
    \`width\` int NOT NULL DEFAULT 20,
    \`height\` int NOT NULL DEFAULT 20,
    \`gridData\` text,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    \`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT \`pattern_grids_id\` PRIMARY KEY(\`id\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`sal_events\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`title\` varchar(200) NOT NULL,
    \`designer\` varchar(200),
    \`description\` text,
    \`coverImageUrl\` varchar(500),
    \`startDate\` varchar(10),
    \`totalParts\` int NOT NULL DEFAULT 1,
    \`currentPart\` int NOT NULL DEFAULT 1,
    \`participantsCount\` int NOT NULL DEFAULT 0,
    \`status\` enum('upcoming','active','completed') NOT NULL DEFAULT 'upcoming',
    \`parts\` text,
    \`tags\` text,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    \`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT \`sal_events_id\` PRIMARY KEY(\`id\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`stitch_sessions\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`userId\` int NOT NULL,
    \`projectId\` int NOT NULL,
    \`date\` varchar(10) NOT NULL,
    \`durationMinutes\` int NOT NULL DEFAULT 0,
    \`stitchesCompleted\` int NOT NULL DEFAULT 0,
    \`photoUrl\` varchar(500),
    \`mood\` enum('relaxed','focused','creative','tired','happy') DEFAULT 'focused',
    \`notes\` text,
    \`threadsUsed\` text,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    CONSTRAINT \`stitch_sessions_id\` PRIMARY KEY(\`id\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`thread_projects\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`userId\` int NOT NULL,
    \`name\` varchar(200) NOT NULL,
    \`patternName\` varchar(200),
    \`patternImageUrl\` varchar(500),
    \`coverImageUrl\` varchar(500),
    \`gridWidth\` int DEFAULT 0,
    \`gridHeight\` int DEFAULT 0,
    \`totalStitches\` int DEFAULT 0,
    \`completedStitches\` int DEFAULT 0,
    \`status\` enum('not_started','in_progress','completed','paused') NOT NULL DEFAULT 'not_started',
    \`fabricType\` varchar(100),
    \`fabricCount\` int,
    \`designer\` varchar(200),
    \`estimatedHours\` float,
    \`notes\` text,
    \`threadsRequired\` text,
    \`tags\` text,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    \`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT \`thread_projects_id\` PRIMARY KEY(\`id\`)
  )`
];

for (const sql of tables) {
  try {
    await conn.execute(sql);
    const name = sql.match(/TABLE IF NOT EXISTS `(\w+)`/)?.[1];
    console.log("✓ Created:", name);
  } catch (e) {
    console.error("✗", e.message.slice(0, 100));
  }
}

await conn.end();
console.log("✅ Done");
