import { createConnection } from "mysql2/promise";
import { readFileSync } from "fs";
import { config } from "dotenv";

config();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

const sql = readFileSync("./drizzle/0002_whole_starfox.sql", "utf-8");

// Split on statement-breakpoint comments and filter empty
const statements = sql
  .split("--> statement-breakpoint")
  .map(s => s.trim())
  .filter(Boolean);

const conn = await createConnection(DATABASE_URL);

for (const stmt of statements) {
  try {
    await conn.execute(stmt);
    console.log("✓", stmt.slice(0, 60).replace(/\n/g, " ") + "...");
  } catch (err) {
    if (err.code === "ER_TABLE_EXISTS_ERROR") {
      console.log("⚠ Table already exists, skipping:", stmt.slice(7, 40));
    } else {
      console.error("✗ Error:", err.message);
      console.error("  Statement:", stmt.slice(0, 100));
    }
  }
}

// Mark migration as applied in drizzle journal table
try {
  await conn.execute(`
    INSERT IGNORE INTO __drizzle_migrations (hash, created_at)
    VALUES ('0002_whole_starfox', ${Date.now()})
  `);
} catch (e) {
  // journal table may not exist yet, ignore
}

await conn.end();
console.log("\n✅ Migration complete");
