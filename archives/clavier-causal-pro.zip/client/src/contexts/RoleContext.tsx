import { createContext, useContext, useState, ReactNode } from "react";

export type RoleId = "couple" | "temoin" | "famille" | "invite" | "coordo" | "dj" | "photo" | "traiteur" | "lieu" | "officiant";

export interface RoleConfig {
  id: RoleId;
  key: string;
  label: string;
  color: string;
  colorClass: string;
  icon: string;
  greeting: string;
  modules: string[];
}

export const ROLES: Record<RoleId, RoleConfig> = {
  couple: {
    id: "couple",
    key: "1",
    label: "Couple",
    color: "oklch(0.78 0.12 75)",
    colorClass: "role-couple",
    icon: "💍",
    greeting: "Votre mariage commence ici",
    modules: ["budget", "timeline", "rsvp", "checklist", "agent", "memoire"],
  },
  temoin: {
    id: "temoin",
    key: "2",
    label: "Témoin",
    color: "oklch(0.7 0.14 10)",
    colorClass: "role-temoin",
    icon: "🎭",
    greeting: "On compte sur vous",
    modules: ["surprises", "discours", "cagnotte", "timeline", "agent"],
  },
  famille: {
    id: "famille",
    key: "3",
    label: "Famille",
    color: "oklch(0.72 0.1 65)",
    colorClass: "role-famille",
    icon: "👨‍👩‍👧‍👦",
    greeting: "Bienvenue dans la famille élargie",
    modules: ["hebergement", "roles", "navettes", "programme"],
  },
  invite: {
    id: "invite",
    key: "4",
    label: "Invité",
    color: "oklch(0.75 0.08 160)",
    colorClass: "role-invite",
    icon: "✉️",
    greeting: "Vous êtes attendu(e)",
    modules: ["rsvp", "menu", "transport", "programme", "galerie"],
  },
  coordo: {
    id: "coordo",
    key: "5",
    label: "Coordo",
    color: "oklch(0.65 0.15 260)",
    colorClass: "role-coordo",
    icon: "🎯",
    greeting: "Votre tableau de bord est prêt",
    modules: ["ondes", "parefeu", "alertes", "timeline", "prestataires", "agent"],
  },
  dj: {
    id: "dj",
    key: "6",
    label: "DJ",
    color: "oklch(0.6 0.18 290)",
    colorClass: "role-dj",
    icon: "🎵",
    greeting: "La piste vous attend",
    modules: ["playlist", "timeline", "signaux", "bpm"],
  },
  photo: {
    id: "photo",
    key: "7",
    label: "Photo",
    color: "oklch(0.7 0.12 200)",
    colorClass: "role-photo",
    icon: "📷",
    greeting: "Les moments vous attendent",
    modules: ["shotlist", "timeline", "galerie", "lumiere"],
  },
  traiteur: {
    id: "traiteur",
    key: "8",
    label: "Traiteur",
    color: "oklch(0.65 0.1 140)",
    colorClass: "role-traiteur",
    icon: "🍽️",
    greeting: "Les couverts vous attendent",
    modules: ["menu", "allergies", "services", "budget"],
  },
  lieu: {
    id: "lieu",
    key: "9",
    label: "Lieu",
    color: "oklch(0.6 0.08 90)",
    colorClass: "role-lieu",
    icon: "🏛️",
    greeting: "Votre espace accueille vos invités",
    modules: ["capacite", "horaires", "meteo", "plan"],
  },
  officiant: {
    id: "officiant",
    key: "0",
    label: "Officiant",
    color: "oklch(0.8 0.06 60)",
    colorClass: "role-officiant",
    icon: "📜",
    greeting: "Le Verbe vous appartient",
    modules: ["ceremonie", "textes", "signaux", "rituel"],
  },
};

interface RoleContextType {
  activeRole: RoleId;
  setActiveRole: (role: RoleId) => void;
  userName: string;
  setUserName: (name: string) => void;
  eventName: string;
  setEventName: (name: string) => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [activeRole, setActiveRole] = useState<RoleId>("couple");
  const [userName, setUserName] = useState("");
  const [eventName, setEventName] = useState("");

  return (
    <RoleContext.Provider
      value={{
        activeRole,
        setActiveRole,
        userName,
        setUserName,
        eventName,
        setEventName,
      }}
    >
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (!context) throw new Error("useRole must be used within RoleProvider");
  return context;
}
