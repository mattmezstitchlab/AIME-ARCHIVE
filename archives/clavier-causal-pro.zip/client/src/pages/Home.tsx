import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";

/**
 * Landing principale AIME® — design unifié avec clavier.html
 * Fond noir, logo concentrique doré SVG, typo Inter, CTA vers /desktop
 */
export default function Home() {
  const [, navigate] = useLocation();
  const [visible, setVisible] = useState(false);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    // Fade-in décalé après montage
    const t = setTimeout(() => setVisible(true), 80);
    return () => {
      clearTimeout(t);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#000",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Fond abstrait dégradé radial */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse 80% 60% at 50% 60%, rgba(201,178,126,.07) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Contenu centré */}
      <div
        style={{
          position: "relative",
          zIndex: 10,
          textAlign: "center",
          padding: "0 1.5rem",
          maxWidth: 560,
          opacity: visible ? 1 : 0,
          transform: visible ? "none" : "translateY(16px)",
          transition: "opacity .6s cubic-bezier(.23,1,.32,1), transform .6s cubic-bezier(.23,1,.32,1)",
        }}
      >
        {/* Logo concentrique SVG */}
        <div style={{ marginBottom: "1.8rem" }}>
          <svg
            width="64"
            height="64"
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            style={{ margin: "0 auto", display: "block" }}
          >
            <circle cx="32" cy="32" r="30" stroke="rgba(201,178,126,.25)" strokeWidth="1.5" />
            <circle cx="32" cy="32" r="22" stroke="rgba(201,178,126,.45)" strokeWidth="1.5" />
            <circle cx="32" cy="32" r="14" stroke="rgba(201,178,126,.7)" strokeWidth="1.5" />
            <circle cx="32" cy="32" r="6" fill="rgba(201,178,126,.9)" />
          </svg>
        </div>

        {/* Surtitre */}
        <p
          style={{
            fontSize: ".6rem",
            fontWeight: 600,
            letterSpacing: ".45em",
            textTransform: "uppercase",
            color: "rgba(201,178,126,.5)",
            marginBottom: "1rem",
          }}
        >
          AIME® — AI + ME
        </p>

        {/* H1 */}
        <h1
          style={{
            fontSize: "clamp(1.8rem, 5vw, 2.8rem)",
            fontWeight: 700,
            color: "#fff",
            letterSpacing: "-.03em",
            lineHeight: 1.15,
            marginBottom: ".9rem",
          }}
        >
          Le Premier Système<br />
          d'Exploitation{" "}
          <span style={{ color: "rgba(201,178,126,1)" }}>Causal</span>
          <br />
          pour le Mariage
        </h1>

        {/* Sous-titre */}
        <p
          style={{
            fontSize: ".9rem",
            color: "rgba(255,255,255,.4)",
            lineHeight: 1.6,
            marginBottom: "2.2rem",
            maxWidth: 400,
            margin: "0 auto 2.2rem",
          }}
        >
          Un geste chez l'un ondule chez tous les autres.
          Dix rôles, un clavier, une mémoire causale partagée.
        </p>

        {/* CTA */}
        <button
          onClick={() => navigate("/desktop")}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: ".5rem",
            padding: ".85rem 2rem",
            borderRadius: "10px",
            background: "rgba(201,178,126,1)",
            color: "#000",
            fontSize: ".75rem",
            fontWeight: 700,
            letterSpacing: ".15em",
            textTransform: "uppercase",
            border: "none",
            cursor: "pointer",
            transition: "all .18s cubic-bezier(.23,1,.32,1)",
            fontFamily: "inherit",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.03)";
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 8px 32px rgba(201,178,126,.3)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "";
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "";
          }}
          onMouseDown={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(.97)";
          }}
          onMouseUp={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.03)";
          }}
        >
          SE BRANCHER À L'ÉVÉNEMENT →
        </button>

        {/* Baseline */}
        <p
          style={{
            marginTop: "3rem",
            fontSize: ".5rem",
            color: "rgba(255,255,255,.15)",
            letterSpacing: ".35em",
            textTransform: "uppercase",
            opacity: visible ? 1 : 0,
            transition: "opacity .8s ease .4s",
          }}
        >
          Un geste · Mille échos
        </p>
      </div>
    </div>
  );
}
