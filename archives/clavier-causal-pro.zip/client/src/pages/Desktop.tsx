import { useEffect, useRef } from "react";

/**
 * Desktop — intègre le Clavier Causal Pro complet via iframe.
 * Le fichier /clavier.html contient :
 *  - L'écran supérieur avec fond floral abstrait cuivré (wallpaper bureau)
 *  - Les cartes glassmorphism flottantes avec paramètres par rôle
 *  - Tous les effets ripple / propagation causale
 *  - Le pare-feu causal (pointillés champagne)
 *  - Le Kill Switch (Maj+Échap)
 *  - La mémoire causale
 *  - La couche EAA complète F1-F12
 *  - Le menu déroulant de rôle (chiffres 1-0)
 */
export default function Desktop() {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Transmettre les événements clavier physiques à l'iframe
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!iframeRef.current?.contentWindow) return;
      try {
        iframeRef.current.contentWindow.dispatchEvent(
          new KeyboardEvent(e.type, {
            key: e.key,
            code: e.code,
            shiftKey: e.shiftKey,
            ctrlKey: e.ctrlKey,
            altKey: e.altKey,
            bubbles: true,
          })
        );
      } catch (_) {}
    };
    window.addEventListener("keydown", handler);
    window.addEventListener("keyup", handler);
    return () => {
      window.removeEventListener("keydown", handler);
      window.removeEventListener("keyup", handler);
    };
  }, []);

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        background: "#000",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <iframe
        ref={iframeRef}
        src="/clavier.html"
        title="AIME® — Clavier Causal Pro"
        style={{
          width: "100%",
          height: "100%",
          border: "none",
          display: "block",
          background: "#000",
        }}
        allow="autoplay; clipboard-write"
        sandbox="allow-scripts allow-same-origin allow-forms"
      />
    </div>
  );
}
