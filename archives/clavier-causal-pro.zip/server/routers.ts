import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { events, eventMembers, decisions, waves, folders, jourJSignals, moduleData } from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  events: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        date: z.string().optional(),
        location: z.string().optional(),
        guestCount: z.number().optional(),
        budget: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const result = await db.insert(events).values({
          ownerId: ctx.user.id,
          name: input.name,
          date: input.date,
          location: input.location,
          guestCount: input.guestCount ?? 0,
          budget: input.budget ?? 0,
        });
        return { id: result[0].insertId };
      }),
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(events).where(eq(events.ownerId, ctx.user.id)).orderBy(desc(events.createdAt));
    }),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const result = await db.select().from(events).where(eq(events.id, input.id)).limit(1);
        return result[0] ?? null;
      }),
    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.enum(["planning", "jourj", "past"]) }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.update(events).set({ status: input.status }).where(eq(events.id, input.id));
        return { success: true };
      }),
  }),

  members: router({
    join: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        weddingRole: z.enum(["couple", "temoin", "famille", "invite", "coordo", "dj", "photo", "traiteur", "lieu", "officiant"]),
        displayName: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.insert(eventMembers).values({
          eventId: input.eventId,
          userId: ctx.user.id,
          weddingRole: input.weddingRole,
          displayName: input.displayName,
        });
        return { success: true };
      }),
    listByEvent: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(eventMembers).where(eq(eventMembers.eventId, input.eventId));
      }),
  }),

  decisions: router({
    create: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        authorRole: z.string(),
        title: z.string(),
        description: z.string().optional(),
        impactedRoles: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const result = await db.insert(decisions).values({
          eventId: input.eventId,
          authorId: ctx.user.id,
          authorRole: input.authorRole,
          title: input.title,
          description: input.description,
          impactedRoles: input.impactedRoles ?? [],
        });
        return { id: result[0].insertId };
      }),
    listByEvent: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(decisions).where(eq(decisions.eventId, input.eventId)).orderBy(desc(decisions.createdAt));
      }),
    validate: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.update(decisions).set({ status: "validated" }).where(eq(decisions.id, input.id));
        return { success: true };
      }),
  }),

  waves: router({
    create: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        sourceRole: z.string(),
        targetRole: z.string(),
        message: z.string(),
        waveType: z.enum(["info", "action", "alert", "secret"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const result = await db.insert(waves).values({
          eventId: input.eventId,
          sourceRole: input.sourceRole,
          targetRole: input.targetRole,
          message: input.message,
          waveType: input.waveType ?? "info",
        });
        return { id: result[0].insertId };
      }),
    listByEvent: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(waves).where(eq(waves.eventId, input.eventId)).orderBy(desc(waves.createdAt));
      }),
    killAll: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.update(waves)
          .set({ status: "killed", resolvedAt: new Date() })
          .where(and(eq(waves.eventId, input.eventId), eq(waves.status, "propagating")));
        return { success: true };
      }),
  }),

  folders: router({
    create: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        name: z.string(),
        accessType: z.enum(["open", "role", "private", "secret", "ephemeral", "circle"]).optional(),
        allowedRoles: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const result = await db.insert(folders).values({
          eventId: input.eventId,
          name: input.name,
          accessType: input.accessType ?? "open",
          allowedRoles: input.allowedRoles ?? [],
          ownerId: ctx.user.id,
        });
        return { id: result[0].insertId };
      }),
    listByEvent: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(folders).where(eq(folders.eventId, input.eventId));
      }),
  }),

  jourJ: router({
    sendSignal: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        senderRole: z.string(),
        senderName: z.string().optional(),
        signalType: z.enum(["ready", "delay", "emergency", "next", "pause", "resume", "custom"]),
        message: z.string().optional(),
        targetRoles: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const result = await db.insert(jourJSignals).values({
          eventId: input.eventId,
          senderRole: input.senderRole,
          senderName: input.senderName,
          signalType: input.signalType,
          message: input.message,
          targetRoles: input.targetRoles ?? [],
        });
        return { id: result[0].insertId };
      }),
    listByEvent: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(jourJSignals).where(eq(jourJSignals.eventId, input.eventId)).orderBy(desc(jourJSignals.createdAt));
      }),
    acknowledge: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.update(jourJSignals).set({ acknowledged: true }).where(eq(jourJSignals.id, input.id));
        return { success: true };
      }),
  }),

  causal: router({
    // Traduction causale d'un geste clavier en langage naturel
    translateGesture: publicProcedure
      .input(z.object({
        role: z.string(),        // rôle actif (ex: "Couple", "DJ", "Traiteur")
        key: z.string(),         // touche pressée (ex: "R", "B", "V")
        gesture: z.string(),     // libellé du geste (ex: "Rituel", "Budget", "Vision")
        context: z.string().optional(), // contexte de la mémoire causale
        eventName: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const systemPrompt = `Tu es l'Agent IA Causal d'AIME®, le système d'exploitation du mariage.
Tu traduis en temps réel les gestes du clavier causal en messages naturels, chaleureux et précis.
Tu connais les 10 rôles : Couple (1), Témoin (2), Famille (3), Invité (4), Coordo (5), DJ (6), Photo (7), Traiteur (8), Lieu (9), Officiant (0).
Chaque touche déclenche une onde causale qui se propage aux autres rôles selon la logique de dépendance.
Tu réponds TOUJOURS en français, en 1 à 3 phrases maximum, de façon naturelle et contextuelle.
Tu décris : QUI a fait QUOI, et QUELS rôles sont impactés et COMMENT.
Ton ton est professionnel mais humain — comme un chef d'orchestre bienveillant.`;

        const userPrompt = `Rôle actif : ${input.role}
Touche pressée : ${input.key}
Geste : ${input.gesture}
${input.eventName ? `Événement : ${input.eventName}` : ''}
${input.context ? `Mémoire causale récente : ${input.context}` : ''}

Traduis ce geste causal en une phrase naturelle qui explique ce qui vient de se passer et qui est impacté.`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
        });

        const text = (response as any)?.choices?.[0]?.message?.content ?? "Geste enregistré dans la mémoire causale.";
        return { translation: text };
      }),

    // Chat avec l'agent IA en contexte causal complet
    chat: publicProcedure
      .input(z.object({
        message: z.string(),
        role: z.string(),
        history: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).optional(),
        context: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const systemPrompt = `Tu es AIME®, l'Agent IA Chef d'Orchestre du mariage — un assistant causal intelligent.
Tu connais les 10 rôles du mariage : Couple, Témoin, Famille, Invité, Coordo, DJ, Photo, Traiteur, Lieu, Officiant.
L'utilisateur actuel a le rôle : ${input.role}.
Tu réponds en français, de façon naturelle, concise et utile.
Tu peux suggérer des actions, anticiper des conflits causaux, et coordonner les rôles.
${input.context ? `Contexte de la mémoire causale : ${input.context}` : ''}`;

        const messages = [
          { role: "system" as const, content: systemPrompt },
          ...(input.history ?? []).map(h => ({ role: h.role as "user" | "assistant", content: h.content })),
          { role: "user" as const, content: input.message },
        ];

        const response = await invokeLLM({ messages });
        const text = (response as any)?.choices?.[0]?.message?.content ?? "Je suis là pour vous aider.";
        return { reply: text };
      }),
  }),

  modules: router({
    save: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        moduleKey: z.string(),
        roleScope: z.string().optional(),
        data: z.any(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.insert(moduleData).values({
          eventId: input.eventId,
          moduleKey: input.moduleKey,
          roleScope: input.roleScope,
          data: input.data,
        });
        return { success: true };
      }),
    get: protectedProcedure
      .input(z.object({ eventId: z.number(), moduleKey: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const result = await db.select().from(moduleData)
          .where(and(eq(moduleData.eventId, input.eventId), eq(moduleData.moduleKey, input.moduleKey)))
          .limit(1);
        return result[0] ?? null;
      }),
  }),
});

export type AppRouter = typeof appRouter;
