import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  date: varchar("date", { length: 20 }),
  location: varchar("location", { length: 255 }),
  guestCount: int("guestCount").default(0),
  budget: int("budget").default(0),
  status: mysqlEnum("status", ["planning", "jourj", "past"]).default("planning").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const eventMembers = mysqlTable("event_members", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  userId: int("userId").notNull(),
  weddingRole: mysqlEnum("weddingRole", [
    "couple", "temoin", "famille", "invite", "coordo", "dj", "photo", "traiteur", "lieu", "officiant"
  ]).notNull(),
  displayName: varchar("displayName", { length: 100 }),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const decisions = mysqlTable("decisions", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  authorId: int("authorId").notNull(),
  authorRole: varchar("authorRole", { length: 20 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  reason: text("reason"),
  alternatives: text("alternatives"),
  consequences: text("consequences"),
  impactedRoles: json("impactedRoles"),
  status: mysqlEnum("status", ["pending", "validated", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const waves = mysqlTable("waves", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  sourceDecisionId: int("sourceDecisionId"),
  sourceRole: varchar("sourceRole", { length: 20 }).notNull(),
  targetRole: varchar("targetRole", { length: 20 }).notNull(),
  message: text("message").notNull(),
  waveType: mysqlEnum("waveType", ["info", "action", "alert", "secret"]).default("info").notNull(),
  status: mysqlEnum("status", ["propagating", "delivered", "blocked", "absorbed", "killed"]).default("propagating").notNull(),
  blockedBy: varchar("blockedBy", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export const moduleData = mysqlTable("module_data", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  moduleKey: varchar("moduleKey", { length: 50 }).notNull(),
  roleScope: varchar("roleScope", { length: 20 }),
  data: json("data"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const folders = mysqlTable("folders", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  accessType: mysqlEnum("accessType", ["open", "role", "private", "secret", "ephemeral", "circle"]).default("open").notNull(),
  allowedRoles: json("allowedRoles"),
  ownerId: int("ownerId"),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const jourJSignals = mysqlTable("jourj_signals", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  senderRole: varchar("senderRole", { length: 20 }).notNull(),
  senderName: varchar("senderName", { length: 100 }),
  signalType: mysqlEnum("signalType", ["ready", "delay", "emergency", "next", "pause", "resume", "custom"]).default("custom").notNull(),
  message: text("message"),
  targetRoles: json("targetRoles"),
  acknowledged: boolean("acknowledged").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;
export type EventMember = typeof eventMembers.$inferSelect;
export type Decision = typeof decisions.$inferSelect;
export type Wave = typeof waves.$inferSelect;
export type ModuleData = typeof moduleData.$inferSelect;
export type Folder = typeof folders.$inferSelect;
export type JourJSignal = typeof jourJSignals.$inferSelect;
