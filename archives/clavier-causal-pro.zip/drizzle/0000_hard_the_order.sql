CREATE TABLE `decisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`authorId` int NOT NULL,
	`authorRole` varchar(20) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`reason` text,
	`alternatives` text,
	`consequences` text,
	`impactedRoles` json,
	`status` enum('pending','validated','cancelled') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `decisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `event_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`userId` int NOT NULL,
	`weddingRole` enum('couple','temoin','famille','invite','coordo','dj','photo','traiteur','lieu','officiant') NOT NULL,
	`displayName` varchar(100),
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `event_members_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`date` varchar(20),
	`location` varchar(255),
	`guestCount` int DEFAULT 0,
	`budget` int DEFAULT 0,
	`status` enum('planning','jourj','past') NOT NULL DEFAULT 'planning',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `folders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`accessType` enum('open','role','private','secret','ephemeral','circle') NOT NULL DEFAULT 'open',
	`allowedRoles` json,
	`ownerId` int,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `folders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `jourj_signals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`senderRole` varchar(20) NOT NULL,
	`senderName` varchar(100),
	`signalType` enum('ready','delay','emergency','next','pause','resume','custom') NOT NULL DEFAULT 'custom',
	`message` text,
	`targetRoles` json,
	`acknowledged` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `jourj_signals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `module_data` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`moduleKey` varchar(50) NOT NULL,
	`roleScope` varchar(20),
	`data` json,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `module_data_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE TABLE `waves` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`sourceDecisionId` int,
	`sourceRole` varchar(20) NOT NULL,
	`targetRole` varchar(20) NOT NULL,
	`message` text NOT NULL,
	`waveType` enum('info','action','alert','secret') NOT NULL DEFAULT 'info',
	`status` enum('propagating','delivered','blocked','absorbed','killed') NOT NULL DEFAULT 'propagating',
	`blockedBy` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `waves_id` PRIMARY KEY(`id`)
);
