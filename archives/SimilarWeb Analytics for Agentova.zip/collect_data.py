import sys
import json
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

client = ApiClient()
domain = 'agentova.ai'
results = {}

# Global Rank
try:
    r = client.call_api('SimilarWeb/get_global_rank', path_params={'domain': domain})
    results['global_rank'] = r
    print("global_rank OK:", json.dumps(r)[:300])
except Exception as e:
    results['global_rank'] = {'error': str(e)}
    print("global_rank ERROR:", e)

# Visits Total
try:
    r = client.call_api('SimilarWeb/get_visits_total',
        path_params={'domain': domain},
        query={'country': 'world', 'granularity': 'monthly', 'start_date': '2024-11', 'end_date': '2025-04'})
    results['visits_total'] = r
    print("visits_total OK:", json.dumps(r)[:300])
except Exception as e:
    results['visits_total'] = {'error': str(e)}
    print("visits_total ERROR:", e)

# Unique Visits
try:
    r = client.call_api('SimilarWeb/get_unique_visit',
        path_params={'domain': domain},
        query={'start_date': '2024-11', 'end_date': '2025-04'})
    results['unique_visits'] = r
    print("unique_visits OK:", json.dumps(r)[:300])
except Exception as e:
    results['unique_visits'] = {'error': str(e)}
    print("unique_visits ERROR:", e)

# Bounce Rate
try:
    r = client.call_api('SimilarWeb/get_bounce_rate',
        path_params={'domain': domain},
        query={'country': 'world', 'granularity': 'monthly', 'start_date': '2024-11', 'end_date': '2025-04'})
    results['bounce_rate'] = r
    print("bounce_rate OK:", json.dumps(r)[:300])
except Exception as e:
    results['bounce_rate'] = {'error': str(e)}
    print("bounce_rate ERROR:", e)

# Traffic Sources Desktop
try:
    r = client.call_api('SimilarWeb/get_traffic_sources_desktop',
        path_params={'domain': domain},
        query={'country': 'world', 'granularity': 'monthly', 'start_date': '2025-02', 'end_date': '2025-04'})
    results['traffic_sources_desktop'] = r
    print("traffic_sources_desktop OK:", json.dumps(r)[:300])
except Exception as e:
    results['traffic_sources_desktop'] = {'error': str(e)}
    print("traffic_sources_desktop ERROR:", e)

# Traffic Sources Mobile
try:
    r = client.call_api('SimilarWeb/get_traffic_sources_mobile',
        path_params={'domain': domain},
        query={'country': 'world', 'granularity': 'monthly', 'start_date': '2025-02', 'end_date': '2025-04'})
    results['traffic_sources_mobile'] = r
    print("traffic_sources_mobile OK:", json.dumps(r)[:300])
except Exception as e:
    results['traffic_sources_mobile'] = {'error': str(e)}
    print("traffic_sources_mobile ERROR:", e)

# Traffic by Country
try:
    r = client.call_api('SimilarWeb/get_total_traffic_by_country',
        path_params={'domain': domain},
        query={'start_date': '2025-02', 'end_date': '2025-04', 'limit': '10'})
    results['traffic_by_country'] = r
    print("traffic_by_country OK:", json.dumps(r)[:300])
except Exception as e:
    results['traffic_by_country'] = {'error': str(e)}
    print("traffic_by_country ERROR:", e)

# Save all results
with open('/home/ubuntu/similarweb_agentova/data.json', 'w') as f:
    json.dump(results, f, indent=2)

print("\n=== ALL DATA SAVED ===")
