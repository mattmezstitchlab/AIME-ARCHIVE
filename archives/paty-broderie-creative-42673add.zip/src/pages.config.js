import Home from './pages/Home';
import MyGrids from './pages/MyGrids';
import CreateGrid from './pages/CreateGrid';
import WorkSettings from './pages/WorkSettings';
import RelaxMode from './pages/RelaxMode';
import GridReader from './pages/GridReader';
import Profile from './pages/Profile';
import Ranking from './pages/Ranking';
import Tutorials from './pages/Tutorials';
import Community from './pages/Community';
import Shop from './pages/Shop';
import Layout from './Layout.jsx';


export const PAGES = {
    "Home": Home,
    "MyGrids": MyGrids,
    "CreateGrid": CreateGrid,
    "WorkSettings": WorkSettings,
    "RelaxMode": RelaxMode,
    "GridReader": GridReader,
    "Profile": Profile,
    "Ranking": Ranking,
    "Tutorials": Tutorials,
    "Community": Community,
    "Shop": Shop,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: Layout,
};