import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, User, Award, TrendingUp, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';

export default function Profile() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: stats } = useQuery({
    queryKey: ['userStats'],
    queryFn: async () => {
      const list = await base44.entities.UserStats.list();
      return list.length > 0 ? list[0] : null;
    }
  });

  const handleLogout = () => {
    base44.auth.logout();
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#C5B6FF] mb-2">
            Mon Profil
          </h1>
          <p className="text-gray-600">
            Tes informations et statistiques
          </p>
        </div>

        <div className="space-y-6">
          
          {/* Carte profil */}
          <div className="bg-[#C5B6FF]/15 border-2 border-[#C5B6FF]/40 rounded-3xl p-8">
            <div className="flex items-center gap-6 mb-6">
              <div className="w-24 h-24 rounded-full bg-[#C5B6FF]/30 flex items-center justify-center">
                <User className="w-12 h-12 text-[#C5B6FF]" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-800">
                  {user?.full_name || 'Utilisateur'}
                </h2>
                <p className="text-gray-600">{user?.email}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Award className="w-5 h-5 text-[#C5B6FF]" />
                  <span className="font-semibold text-[#C5B6FF]">
                    Niveau {stats?.level || 1}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Statistiques */}
          <div className="bg-white border-2 border-[#C5B6FF]/40 rounded-3xl p-8">
            <h3 className="text-xl font-bold text-[#C5B6FF] mb-6 flex items-center gap-2">
              <TrendingUp className="w-6 h-6" />
              Statistiques Globales
            </h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-[#C5B6FF]/10 rounded-2xl">
                <div className="text-4xl font-bold text-[#6B3EFF] mb-2">
                  {stats?.total_stitches || 0}
                </div>
                <div className="text-gray-600">Points brodés</div>
              </div>
              
              <div className="text-center p-6 bg-[#C5B6FF]/10 rounded-2xl">
                <div className="text-4xl font-bold text-[#6B3EFF] mb-2">
                  {stats?.total_hours || 0}
                </div>
                <div className="text-gray-600">Heures de broderie</div>
              </div>
              
              <div className="text-center p-6 bg-[#C5B6FF]/10 rounded-2xl">
                <div className="text-4xl font-bold text-[#6B3EFF] mb-2">
                  {stats?.completed_projects || 0}
                </div>
                <div className="text-gray-600">Projets terminés</div>
              </div>
            </div>
          </div>

          {/* Badges */}
          {stats?.badges && stats.badges.length > 0 && (
            <div className="bg-white border-2 border-[#C5B6FF]/40 rounded-3xl p-8">
              <h3 className="text-xl font-bold text-[#C5B6FF] mb-6 flex items-center gap-2">
                <Award className="w-6 h-6" />
                Mes Badges
              </h3>
              <div className="flex flex-wrap gap-4">
                {stats.badges.map((badge, idx) => (
                  <div 
                    key={idx}
                    className="px-4 py-2 bg-[#C5B6FF]/20 rounded-full text-[#C5B6FF] font-semibold"
                  >
                    {badge}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Déconnexion */}
          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full h-12 text-red-600 border-red-200 hover:bg-red-50"
          >
            <LogOut className="w-5 h-5 mr-2" />
            Se déconnecter
          </Button>

        </div>

      </div>
    </div>
  );
}