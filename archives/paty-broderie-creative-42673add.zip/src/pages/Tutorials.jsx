import React from 'react';
import { ArrowLeft, Lightbulb, Video, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';

export default function Tutorials() {
  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#6CF1C5] mb-2">
            Inspiration & Tutoriels
          </h1>
          <p className="text-gray-600">
            Apprends de nouvelles techniques de broderie
          </p>
        </div>

        <div className="bg-[#6CF1C5]/10 border-2 border-[#6CF1C5]/30 rounded-3xl p-12 text-center">
          <Lightbulb className="w-24 h-24 text-[#6CF1C5] mx-auto mb-6" />
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Tutoriels à venir
          </h3>
          <p className="text-gray-600 leading-relaxed max-w-md mx-auto">
            Une bibliothèque complète de tutoriels vidéo et d'astuces sera bientôt disponible pour t'aider à progresser.
          </p>
        </div>

      </div>
    </div>
  );
}