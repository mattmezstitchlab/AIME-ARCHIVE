import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, ZoomIn, ZoomOut, Grid3x3 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

export default function GridReader() {
  const urlParams = new URLSearchParams(window.location.search);
  const gridId = urlParams.get('gridId');
  const [zoom, setZoom] = useState(100);

  const { data: grid, isLoading } = useQuery({
    queryKey: ['grid', gridId],
    queryFn: async () => {
      if (!gridId) return null;
      const grids = await base44.entities.Grid.filter({ id: gridId });
      return grids[0] || null;
    },
    enabled: !!gridId
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-[#6B3EFF] border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-gray-600">Chargement de la grille...</p>
        </div>
      </div>
    );
  }

  if (!grid) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Grid3x3 className="w-20 h-20 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">
            Grille introuvable
          </h3>
          <Link to={createPageUrl('MyGrids')}>
            <Button className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mt-4">
              Retour aux grilles
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[1200px] mx-auto">
        
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <Link to={createPageUrl('MyGrids')}>
              <Button 
                variant="secondary"
                className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-4"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-800">
              {grid.title}
            </h1>
            <p className="text-gray-600">
              {grid.width} × {grid.height} points • {grid.progress || 0}% complété
            </p>
          </div>

          {/* Contrôles de zoom */}
          <div className="flex items-center gap-4">
            <Button
              size="icon"
              variant="outline"
              onClick={() => setZoom(Math.max(50, zoom - 10))}
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-semibold min-w-12 text-center">
              {zoom}%
            </span>
            <Button
              size="icon"
              variant="outline"
              onClick={() => setZoom(Math.min(200, zoom + 10))}
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Viewer de la grille */}
        <div className="bg-white border-2 border-gray-200 rounded-3xl p-8 overflow-auto">
          <div 
            className="mx-auto bg-gray-50 border border-gray-300 rounded-lg"
            style={{
              width: `${zoom}%`,
              aspectRatio: `${grid.width} / ${grid.height}`
            }}
          >
            {grid.image_url ? (
              <img 
                src={grid.image_url} 
                alt={grid.title}
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Grid3x3 className="w-20 h-20 text-gray-300" />
              </div>
            )}
          </div>
        </div>

        {/* Légende DMC */}
        {grid.dmc_colors && grid.dmc_colors.length > 0 && (
          <div className="mt-8 bg-white border-2 border-gray-200 rounded-3xl p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">
              Légende DMC
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {grid.dmc_colors.map((color, idx) => (
                <div 
                  key={idx}
                  className="flex items-center gap-3 p-3 rounded-lg border border-gray-200"
                >
                  <div 
                    className="w-8 h-8 rounded-lg border-2 border-gray-300"
                    style={{ backgroundColor: color.hex }}
                  />
                  <div>
                    <div className="font-semibold text-sm">{color.code}</div>
                    <div className="text-xs text-gray-600">{color.count} pts</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}