import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Palette, Scissors, Grid3x3, Lightbulb } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';
import SectionCard from '../components/home/SectionCard';

export default function WorkSettings() {
  const queryClient = useQueryClient();

  const { data: settings } = useQuery({
    queryKey: ['workSettings'],
    queryFn: async () => {
      const list = await base44.entities.WorkSettings.list();
      if (list.length > 0) return list[0];
      
      return await base44.entities.WorkSettings.create({
        use_full_palette: true,
        stitch_types: {
          full_cross: true,
          half_stitch: true,
          quarter_stitch: false,
          back_stitch: true,
          french_knot: false,
          beads: false,
          special_stitches: false
        },
        grid_appearance: {
          symbol_size: 'medium',
          grid_lines: true,
          dark_mode: false,
          colorblind_mode: false,
          high_contrast: false
        },
        comfort_settings: {
          auto_highlight: true,
          tooltips: true,
          paty_messages: true,
          focus_mode: false
        }
      });
    }
  });

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        {/* Header */}
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#5FB3FF] mb-2">
            Paramètres de Travail
          </h1>
          <p className="text-gray-600">
            Configure ton environnement de broderie
          </p>
        </div>

        {/* 4 cartes de paramètres */}
        <div className="grid md:grid-cols-2 gap-6">
          
          <SectionCard
            title="Couleurs DMC"
            description="Gestion des couleurs utilisées."
            icon={Palette}
            color="#5FB3FF"
            linkTo="DmcColors"
            size="medium"
          />

          <SectionCard
            title="Types de points"
            description="Active les points que tu utilises."
            icon={Scissors}
            color="#5FB3FF"
            linkTo="StitchTypes"
            size="medium"
          />

          <SectionCard
            title="Apparence de la grille"
            description="Symboles, contrastes, zoom."
            icon={Grid3x3}
            color="#5FB3FF"
            linkTo="GridAppearance"
            size="medium"
          />

          <SectionCard
            title="Confort & aide"
            description="Aides visuelles et suggestions."
            icon={Lightbulb}
            color="#5FB3FF"
            linkTo="ComfortSettings"
            size="medium"
          />

        </div>

      </div>
    </div>
  );
}