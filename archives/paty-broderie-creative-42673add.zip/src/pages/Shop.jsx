import React from 'react';
import { ArrowLeft, ShoppingBag, Package, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';

export default function Shop() {
  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#D6316D] mb-2">
            Boutique
          </h1>
          <p className="text-gray-600">
            Tout le matériel pour tes créations
          </p>
        </div>

        <div className="bg-[#D6316D]/10 border-2 border-[#D6316D]/30 rounded-3xl p-12 text-center">
          <ShoppingBag className="w-24 h-24 text-[#D6316D] mx-auto mb-6" />
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Boutique prochainement
          </h3>
          <p className="text-gray-600 leading-relaxed max-w-md mx-auto">
            Fils DMC, toiles, aiguilles, perles et kits complets seront bientôt disponibles. Paty te suggérera même le matériel adapté à tes projets !
          </p>
        </div>

      </div>
    </div>
  );
}