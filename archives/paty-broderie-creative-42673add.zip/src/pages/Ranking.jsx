import React from 'react';
import { ArrowLeft, Trophy, Medal, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';

export default function Ranking() {
  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#1D5BFF] mb-2">
            Classement Mondial
          </h1>
          <p className="text-gray-600">
            Compare tes performances avec la communauté
          </p>
        </div>

        <div className="bg-[#1D5BFF]/10 border-2 border-[#1D5BFF]/30 rounded-3xl p-12 text-center">
          <Trophy className="w-24 h-24 text-[#1D5BFF] mx-auto mb-6" />
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Classement à venir
          </h3>
          <p className="text-gray-600 leading-relaxed max-w-md mx-auto">
            Le système de classement mondial sera bientôt disponible. Continue à broder pour améliorer ton score !
          </p>
        </div>

      </div>
    </div>
  );
}