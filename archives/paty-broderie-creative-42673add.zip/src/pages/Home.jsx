import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  Grid3x3, 
  ImagePlus, 
  Settings, 
  Flower2, 
  Gamepad2, 
  Leaf,
  Trophy,
  Lightbulb,
  Users,
  ShoppingBag,
  Target,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { createPageUrl } from '../components/utils';
import SectionCard from '../components/home/SectionCard';
import StatCard from '../components/home/StatCard';
import PatySuggestion from '../components/home/PatySuggestion';

export default function Home() {
  const { data: stats } = useQuery({
    queryKey: ['userStats'],
    queryFn: async () => {
      const statsList = await base44.entities.UserStats.list();
      if (statsList.length > 0) {
        return statsList[0];
      }
      // Créer des stats par défaut si elles n'existent pas
      return await base44.entities.UserStats.create({
        total_stitches: 0,
        total_hours: 0,
        completed_projects: 0
      });
    },
    initialData: null
  });

  const suggestions = [
    "Commence un nouveau projet pour rester créative !",
    "N'oublie pas de sauvegarder tes grilles favorites.",
    "Essaie le Mode Relax pour une pause créative.",
    "Ta dernière grille attend d'être terminée !"
  ];

  const [currentSuggestion, setCurrentSuggestion] = useState(suggestions[0]);

  useEffect(() => {
    const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
    setCurrentSuggestion(randomSuggestion);
  }, []);

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto space-y-10">
        
        {/* SECTION A - ENTRÉES ESSENTIELLES */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-center text-[#6B3EFF] mb-8">
            Tes Outils Essentiels
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <SectionCard
              title="Mes grilles"
              description="Accède à tes grilles."
              icon={Grid3x3}
              color="#FFC845"
              linkTo="MyGrids"
            />
            <SectionCard
              title="Créer une grille"
              description="Crée une grille à partir d'une photo."
              icon={ImagePlus}
              color="#FF6CAB"
              linkTo="CreateGrid"
            />
            <SectionCard
              title="Paramètres de travail"
              description="Configure ton environnement."
              icon={Settings}
              color="#5FB3FF"
              linkTo="WorkSettings"
            />
          </div>
        </section>

        {/* SECTION B - MODE RELAX */}
        <section className="space-y-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-[#FFBFD9] mb-2">
              Mode Relax
            </h2>
            <p className="text-gray-600">Détends-toi et crée en toute sérénité</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <SectionCard
              title="Broderie Zen"
              description="Brode virtuellement en toute tranquillité."
              icon={Flower2}
              color="#FFBFD9"
              linkTo="RelaxMode"
              size="medium"
            />
            <SectionCard
              title="Jeu Relax"
              description="Mini-motifs rapides et apaisants."
              icon={Gamepad2}
              color="#FFBFD9"
              linkTo="RelaxMode"
              size="medium"
            />
            <SectionCard
              title="Anti-Stress"
              description="Ambiances visuelles relaxantes."
              icon={Leaf}
              color="#FFBFD9"
              linkTo="RelaxMode"
              size="medium"
            />
          </div>
        </section>

        {/* SECTION C - SECTIONS SECONDAIRES */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-center text-[#6B3EFF] mb-8">
            Explorer & Partager
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <SectionCard
              title="Classement mondial"
              description="Compare tes performances avec la communauté."
              icon={Trophy}
              color="#1D5BFF"
              linkTo="Ranking"
              size="medium"
            />
            <SectionCard
              title="Inspiration & Tutoriels"
              description="Apprends de nouvelles techniques."
              icon={Lightbulb}
              color="#6CF1C5"
              linkTo="Tutorials"
              size="medium"
            />
            <SectionCard
              title="Communauté"
              description="Découvre les créations des autres."
              icon={Users}
              color="#FFA44A"
              linkTo="Community"
              size="medium"
            />
            <SectionCard
              title="Boutique"
              description="Tout le matériel dont tu as besoin."
              icon={ShoppingBag}
              color="#D6316D"
              linkTo="Shop"
              size="medium"
            />
          </div>
        </section>

        {/* SECTION D - STATISTIQUES RAPIDES */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-center text-[#C5B6FF] mb-8">
            Tes Statistiques
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <StatCard
              icon={Target}
              label="Points brodés"
              value={stats?.total_stitches || 0}
            />
            <StatCard
              icon={Clock}
              label="Heures brodées"
              value={stats?.total_hours || 0}
            />
            <StatCard
              icon={CheckCircle2}
              label="Projets terminés"
              value={stats?.completed_projects || 0}
            />
          </div>
        </section>

        {/* SECTION E - SUGGESTION PATY */}
        <section>
          <PatySuggestion message={currentSuggestion} />
        </section>

      </div>
    </div>
  );
}