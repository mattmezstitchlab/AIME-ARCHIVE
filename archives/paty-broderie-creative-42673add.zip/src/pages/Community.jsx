import React from 'react';
import { ArrowLeft, Users, Heart, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';

export default function Community() {
  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#FFA44A] mb-2">
            Communauté
          </h1>
          <p className="text-gray-600">
            Découvre les créations des autres brodeuses
          </p>
        </div>

        <div className="bg-[#FFA44A]/10 border-2 border-[#FFA44A]/30 rounded-3xl p-12 text-center">
          <Users className="w-24 h-24 text-[#FFA44A] mx-auto mb-6" />
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Communauté en construction
          </h3>
          <p className="text-gray-600 leading-relaxed max-w-md mx-auto">
            Bientôt tu pourras partager tes créations et découvrir celles des autres membres de la communauté PATY.
          </p>
        </div>

      </div>
    </div>
  );
}