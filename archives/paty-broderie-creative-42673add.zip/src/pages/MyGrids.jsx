import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  Search, 
  Filter, 
  Grid3x3, 
  List,
  ArrowLeft,
  Folder,
  Clock,
  CheckCircle2,
  Maximize,
  Sparkles,
  Gem
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function MyGrids() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollection, setSelectedCollection] = useState('all');
  const [viewMode, setViewMode] = useState('gallery');

  const { data: grids, isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
    initialData: []
  });

  const collections = [
    { value: 'all', label: 'Toutes les grilles', icon: Grid3x3 },
    { value: 'in_progress', label: 'En cours', icon: Clock },
    { value: 'completed', label: 'Terminés', icon: CheckCircle2 },
    { value: 'large_format', label: 'Grand format', icon: Maximize },
    { value: 'small_projects', label: 'Petits projets', icon: Folder },
    { value: 'with_beads', label: 'Avec perles', icon: Gem },
    { value: 'created_with_paty', label: 'Créés avec Paty', icon: Sparkles }
  ];

  const filteredGrids = grids.filter(grid => {
    const matchesSearch = grid.title?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCollection = selectedCollection === 'all' || grid.collection === selectedCollection;
    return matchesSearch && matchesCollection;
  });

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        {/* Header avec bouton retour */}
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#FFC845] mb-2">
            Mes Grilles
          </h1>
          <p className="text-gray-600">
            Retrouve toutes tes créations
          </p>
        </div>

        {/* Barre de recherche et filtres */}
        <div className="bg-[#FFC845]/10 border-2 border-[#FFC845]/30 rounded-3xl p-6 mb-8">
          <div className="space-y-4">
            {/* Recherche */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#FFC845]" />
              <Input
                placeholder="Rechercher une grille..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 border-2 border-[#FFC845]/30 rounded-xl focus:border-[#FFC845]"
              />
            </div>

            {/* Filtres */}
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-[#FFC845]" />
                <span className="text-sm font-semibold text-gray-700">Collections :</span>
              </div>
              <Select value={selectedCollection} onValueChange={setSelectedCollection}>
                <SelectTrigger className="w-64 border-2 border-[#FFC845]/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {collections.map(col => {
                    const Icon = col.icon;
                    return (
                      <SelectItem key={col.value} value={col.value}>
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" />
                          {col.label}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>

              {/* Toggle vue */}
              <div className="ml-auto flex gap-2">
                <Button
                  variant={viewMode === 'gallery' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('gallery')}
                  className={viewMode === 'gallery' ? 'bg-[#FFC845] hover:bg-[#E5B03D]' : ''}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className={viewMode === 'list' ? 'bg-[#FFC845] hover:bg-[#E5B03D]' : ''}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Grilles */}
        {isLoading ? (
          <div className="text-center py-20">
            <div className="animate-spin w-12 h-12 border-4 border-[#FFC845] border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-gray-600">Chargement de tes grilles...</p>
          </div>
        ) : filteredGrids.length === 0 ? (
          <div className="text-center py-20">
            <Grid3x3 className="w-20 h-20 text-[#FFC845]/30 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Aucune grille trouvée
            </h3>
            <p className="text-gray-600 mb-6">
              {searchQuery || selectedCollection !== 'all' 
                ? 'Essaie de modifier tes filtres'
                : 'Crée ta première grille pour commencer !'}
            </p>
            <Link to={createPageUrl('CreateGrid')}>
              <Button className="bg-[#FF6CAB] hover:bg-[#E55B99] text-white">
                Créer une grille
              </Button>
            </Link>
          </div>
        ) : (
          <div className={
            viewMode === 'gallery' 
              ? 'grid md:grid-cols-2 lg:grid-cols-3 gap-6' 
              : 'space-y-4'
          }>
            {filteredGrids.map(grid => (
              <Link 
                key={grid.id}
                to={createPageUrl('GridReader', `?gridId=${grid.id}`)}
              >
                <div className="bg-white border-2 border-[#FFC845]/30 rounded-2xl overflow-hidden hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer">
                  {/* Image de la grille */}
                  <div className="aspect-square bg-gradient-to-br from-[#FFC845]/20 to-[#FFC845]/5 flex items-center justify-center">
                    {grid.image_url ? (
                      <img 
                        src={grid.image_url} 
                        alt={grid.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Grid3x3 className="w-16 h-16 text-[#FFC845]/50" />
                    )}
                  </div>
                  
                  {/* Infos */}
                  <div className="p-4">
                    <h3 className="font-bold text-lg text-gray-800 mb-2 truncate">
                      {grid.title}
                    </h3>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span>{grid.width} × {grid.height}</span>
                      <span className="font-semibold text-[#FFC845]">
                        {grid.progress || 0}%
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}