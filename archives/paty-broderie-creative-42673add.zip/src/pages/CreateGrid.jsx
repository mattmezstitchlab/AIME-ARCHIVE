import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  ArrowLeft, 
  Upload, 
  Camera, 
  FileText,
  Grid3x3,
  Sparkles,
  Save,
  RefreshCw
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

export default function CreateGrid() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [uploadedFile, setUploadedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [gridSettings, setGridSettings] = useState({
    title: '',
    width: 50,
    height: 50,
    colors_count: 20,
    stitch_types: {
      full_cross: true,
      half_stitch: false,
      quarter_stitch: false,
      back_stitch: true,
      french_knot: false,
      beads: false
    }
  });
  const [isGenerating, setIsGenerating] = useState(false);

  const createGridMutation = useMutation({
    mutationFn: async (gridData) => {
      return await base44.entities.Grid.create(gridData);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries(['grids']);
      toast.success('Grille créée avec succès !');
      navigate(createPageUrl('MyGrids'));
    }
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);

    // Upload du fichier
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setUploadedFile(file_url);
  };

  const handleGenerate = async () => {
    if (!uploadedFile || !gridSettings.title) {
      toast.error('Ajoute une image et un titre pour ta grille');
      return;
    }

    setIsGenerating(true);

    try {
      // Simuler la génération de la grille
      // Dans une vraie app, tu utiliserais une IA pour convertir l'image en grille de point de croix
      
      await createGridMutation.mutateAsync({
        title: gridSettings.title,
        image_url: uploadedFile,
        width: gridSettings.width,
        height: gridSettings.height,
        colors_count: gridSettings.colors_count,
        stitch_types: gridSettings.stitch_types,
        progress: 0,
        collection: 'in_progress',
        created_with_ai: true,
        grid_data: {
          // Les données de la grille seraient générées ici
          pixels: [],
          symbols: []
        },
        dmc_colors: []
      });
    } catch (error) {
      toast.error('Erreur lors de la création de la grille');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        {/* Header */}
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#FF6CAB] mb-2">
            Créer une Grille
          </h1>
          <p className="text-gray-600">
            Transforme une photo en grille de point de croix
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          
          {/* Colonne gauche - Upload et aperçu */}
          <div className="space-y-6">
            
            {/* Zone d'upload */}
            <div className="bg-[#FF6CAB]/10 border-2 border-[#FF6CAB]/30 rounded-3xl p-6">
              <h3 className="text-xl font-bold text-[#FF6CAB] mb-4 flex items-center gap-2">
                <Upload className="w-6 h-6" />
                Importer une image
              </h3>

              <div className="space-y-4">
                <label className="cursor-pointer">
                  <div className="border-2 border-dashed border-[#FF6CAB]/40 rounded-2xl p-8 text-center hover:bg-[#FF6CAB]/5 transition-all">
                    {previewUrl ? (
                      <img 
                        src={previewUrl} 
                        alt="Preview" 
                        className="max-h-64 mx-auto rounded-lg"
                      />
                    ) : (
                      <>
                        <Upload className="w-12 h-12 text-[#FF6CAB] mx-auto mb-3" />
                        <p className="text-gray-600">
                          Clique pour choisir une image
                        </p>
                      </>
                    )}
                  </div>
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

          </div>

          {/* Colonne droite - Paramètres */}
          <div className="space-y-6">
            
            <div className="bg-[#FF6CAB]/10 border-2 border-[#FF6CAB]/30 rounded-3xl p-6">
              <h3 className="text-xl font-bold text-[#FF6CAB] mb-6 flex items-center gap-2">
                <Grid3x3 className="w-6 h-6" />
                Paramètres
              </h3>

              <div className="space-y-6">
                
                {/* Titre */}
                <div>
                  <Label htmlFor="title" className="text-gray-700 font-semibold mb-2 block">
                    Titre de la grille
                  </Label>
                  <Input
                    id="title"
                    value={gridSettings.title}
                    onChange={(e) => setGridSettings({...gridSettings, title: e.target.value})}
                    placeholder="Ma belle grille..."
                    className="border-2 border-[#FF6CAB]/30"
                  />
                </div>

                {/* Dimensions */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-700 font-semibold mb-2 block">
                      Largeur : {gridSettings.width}
                    </Label>
                    <Slider
                      value={[gridSettings.width]}
                      onValueChange={(val) => setGridSettings({...gridSettings, width: val[0]})}
                      min={20}
                      max={200}
                      step={5}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-700 font-semibold mb-2 block">
                      Hauteur : {gridSettings.height}
                    </Label>
                    <Slider
                      value={[gridSettings.height]}
                      onValueChange={(val) => setGridSettings({...gridSettings, height: val[0]})}
                      min={20}
                      max={200}
                      step={5}
                      className="mt-2"
                    />
                  </div>
                </div>

                {/* Nombre de couleurs */}
                <div>
                  <Label className="text-gray-700 font-semibold mb-2 block">
                    Nombre de couleurs : {gridSettings.colors_count}
                  </Label>
                  <Slider
                    value={[gridSettings.colors_count]}
                    onValueChange={(val) => setGridSettings({...gridSettings, colors_count: val[0]})}
                    min={5}
                    max={50}
                    step={1}
                    className="mt-2"
                  />
                </div>

                {/* Types de points */}
                <div>
                  <Label className="text-gray-700 font-semibold mb-3 block">
                    Types de broderie
                  </Label>
                  <div className="space-y-3">
                    {Object.entries({
                      full_cross: 'Croix pleine',
                      half_stitch: 'Demi-points',
                      quarter_stitch: 'Quart / Trois-quarts',
                      back_stitch: 'Points arrière',
                      french_knot: 'Nœuds français',
                      beads: 'Perles'
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between">
                        <span className="text-sm text-gray-700">{label}</span>
                        <Switch
                          checked={gridSettings.stitch_types[key]}
                          onCheckedChange={(checked) => 
                            setGridSettings({
                              ...gridSettings,
                              stitch_types: {
                                ...gridSettings.stitch_types,
                                [key]: checked
                              }
                            })
                          }
                        />
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>

            {/* Boutons d'action */}
            <div className="flex gap-4">
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !uploadedFile || !gridSettings.title}
                className="flex-1 bg-[#FF6CAB] hover:bg-[#E55B99] text-white h-12 text-lg"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                    Génération...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    Générer la grille
                  </>
                )}
              </Button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}