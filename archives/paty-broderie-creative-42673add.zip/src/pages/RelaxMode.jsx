import React from 'react';
import { ArrowLeft, Flower2, Gamepad2, Leaf } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../components/utils';
import { Button } from '@/components/ui/button';

export default function RelaxMode() {
  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-[900px] mx-auto">
        
        <div className="mb-8">
          <Link to={createPageUrl('Home')}>
            <Button 
              variant="secondary"
              className="bg-[#6B3EFF] hover:bg-[#5829CC] text-white mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold text-[#FFBFD9] mb-2">
            Mode Relax
          </h1>
          <p className="text-gray-600">
            Détends-toi et laisse-toi porter par la créativité
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          
          {/* Broderie Zen */}
          <div className="bg-[#FFBFD9]/15 border-2 border-[#FFBFD9]/40 rounded-3xl p-8 hover:shadow-2xl transition-all">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="p-6 bg-[#FFBFD9]/20 rounded-3xl">
                <Flower2 className="w-16 h-16 text-[#FFBFD9]" strokeWidth={1.5} />
              </div>
              <h3 className="text-2xl font-bold text-[#FFBFD9]">Broderie Zen</h3>
              <p className="text-gray-600 leading-relaxed">
                Brode virtuellement avec des motifs aléatoires et des sons apaisants.
              </p>
              <Button className="w-full mt-4 bg-[#FFBFD9] hover:bg-[#FFAAC9] text-white">
                Commencer
              </Button>
            </div>
          </div>

          {/* Jeu Relax */}
          <div className="bg-[#FFBFD9]/15 border-2 border-[#FFBFD9]/40 rounded-3xl p-8 hover:shadow-2xl transition-all">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="p-6 bg-[#FFBFD9]/20 rounded-3xl">
                <Gamepad2 className="w-16 h-16 text-[#FFBFD9]" strokeWidth={1.5} />
              </div>
              <h3 className="text-2xl font-bold text-[#FFBFD9]">Jeu Relax</h3>
              <p className="text-gray-600 leading-relaxed">
                Mini-motifs rapides de 20 à 50 points, en 1 à 3 minutes.
              </p>
              <Button className="w-full mt-4 bg-[#FFBFD9] hover:bg-[#FFAAC9] text-white">
                Jouer
              </Button>
            </div>
          </div>

          {/* Anti-Stress */}
          <div className="bg-[#FFBFD9]/15 border-2 border-[#FFBFD9]/40 rounded-3xl p-8 hover:shadow-2xl transition-all">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="p-6 bg-[#FFBFD9]/20 rounded-3xl">
                <Leaf className="w-16 h-16 text-[#FFBFD9]" strokeWidth={1.5} />
              </div>
              <h3 className="text-2xl font-bold text-[#FFBFD9]">Anti-Stress</h3>
              <p className="text-gray-600 leading-relaxed">
                Ambiances visuelles, sons relaxants et cercle de respiration.
              </p>
              <Button className="w-full mt-4 bg-[#FFBFD9] hover:bg-[#FFAAC9] text-white">
                Découvrir
              </Button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}