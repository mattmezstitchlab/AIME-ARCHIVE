import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Home, Settings, User } from 'lucide-react';
import { createPageUrl } from './components/utils';

export default function Layout({ children, currentPageName }) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <style>{`
        :root {
          --violet-prune: #6B3EFF;
          --jaune-ambre: #FFC845;
          --rose-coton: #FF6CAB;
          --bleu-glace: #5FB3FF;
          --rose-poudre: #FFBFD9;
          --bleu-royal: #1D5BFF;
          --vert-menthe: #6CF1C5;
          --orange-mangue: #FFA44A;
          --framboise: #D6316D;
          --lavande: #C5B6FF;
        }
        
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        * {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        body {
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }
      `}</style>

      {/* Header fixe */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#6B3EFF] shadow-lg">
        <div className="h-16 flex items-center justify-between px-6 max-w-[900px] mx-auto">
          {/* Icône Accueil à gauche */}
          <Link 
            to={createPageUrl('Home')}
            className="text-white hover:bg-white/10 p-2 rounded-lg transition-all"
          >
            <Home className="w-6 h-6" />
          </Link>

          {/* Titre centré */}
          <h1 className="text-white text-2xl font-extrabold tracking-wider">
            PATY
          </h1>

          {/* Icônes à droite */}
          <div className="flex items-center gap-2">
            <Link 
              to={createPageUrl('WorkSettings')}
              className="text-white hover:bg-white/10 p-2 rounded-lg transition-all"
            >
              <Settings className="w-6 h-6" />
            </Link>
            <Link 
              to={createPageUrl('Profile')}
              className="text-white hover:bg-white/10 p-2 rounded-lg transition-all"
            >
              <User className="w-6 h-6" />
            </Link>
          </div>
        </div>
      </header>

      {/* Contenu principal avec padding-top pour le header */}
      <main className="pt-16">
        {children}
      </main>
    </div>
  );
}