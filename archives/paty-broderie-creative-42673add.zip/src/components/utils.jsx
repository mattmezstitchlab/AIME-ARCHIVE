/**
 * Creates a URL for navigating to a page in the app
 * @param {string} pageName - Name of the page
 * @param {string} query - Optional query string
 * @returns {string} - URL path for the page
 */
export function createPageUrl(pageName, query = '') {
  const path = `/${pageName}`;
  return query ? `${path}${query}` : path;
}