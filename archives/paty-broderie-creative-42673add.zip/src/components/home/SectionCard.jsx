import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { cn } from '@/lib/utils';

export default function SectionCard({ 
  title, 
  description, 
  icon: Icon, 
  color, 
  linkTo,
  onClick,
  size = 'large' 
}) {
  const content = (
    <div
      className={cn(
        "group relative overflow-hidden rounded-3xl transition-all duration-500 cursor-pointer",
        "hover:scale-[1.02] hover:shadow-2xl",
        size === 'large' ? 'p-8' : size === 'medium' ? 'p-6' : 'p-4',
        "border-2"
      )}
      style={{
        backgroundColor: `${color}15`,
        borderColor: `${color}40`
      }}
    >
      {/* Cercle décoratif en arrière-plan */}
      <div 
        className="absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-10 transition-transform duration-500 group-hover:scale-110"
        style={{ backgroundColor: color }}
      />

      <div className="relative z-10 flex flex-col items-center text-center gap-4">
        {/* Icône */}
        <div 
          className="p-4 rounded-2xl transition-transform duration-300 group-hover:scale-110"
          style={{ backgroundColor: `${color}20` }}
        >
          <Icon 
            className={cn(
              "transition-all duration-300",
              size === 'large' ? 'w-12 h-12' : size === 'medium' ? 'w-10 h-10' : 'w-8 h-8'
            )}
            style={{ color: color }}
            strokeWidth={2}
          />
        </div>

        {/* Texte */}
        <div>
          <h3 
            className={cn(
              "font-bold mb-2 transition-colors",
              size === 'large' ? 'text-2xl' : size === 'medium' ? 'text-xl' : 'text-lg'
            )}
            style={{ color: color }}
          >
            {title}
          </h3>
          <p className="text-gray-600 text-sm leading-relaxed">
            {description}
          </p>
        </div>
      </div>
    </div>
  );

  if (linkTo) {
    return (
      <Link to={createPageUrl(linkTo)}>
        {content}
      </Link>
    );
  }

  return <div onClick={onClick}>{content}</div>;
}