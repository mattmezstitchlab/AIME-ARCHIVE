import React from 'react';
import { cn } from '@/lib/utils';

export default function StatCard({ icon: Icon, label, value }) {
  return (
    <div className="bg-[#C5B6FF]/15 border-2 border-[#C5B6FF]/40 rounded-2xl p-6 hover:shadow-lg transition-all duration-300 hover:scale-105">
      <div className="flex flex-col items-center gap-3">
        <div className="p-3 bg-[#C5B6FF]/20 rounded-xl">
          <Icon className="w-8 h-8 text-[#C5B6FF]" strokeWidth={2} />
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold text-[#6B3EFF] mb-1">
            {value || 0}
          </div>
          <div className="text-sm text-gray-600">
            {label}
          </div>
        </div>
      </div>
    </div>
  );
}