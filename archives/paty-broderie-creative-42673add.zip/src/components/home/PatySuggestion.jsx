import React from 'react';
import { Sparkles } from 'lucide-react';

export default function PatySuggestion({ message }) {
  return (
    <div className="bg-[#6B3EFF]/20 border-2 border-[#6B3EFF]/30 rounded-2xl p-5 hover:shadow-lg transition-all duration-300">
      <div className="flex items-start gap-3">
        <div className="p-2 bg-[#6B3EFF]/30 rounded-lg flex-shrink-0">
          <Sparkles className="w-5 h-5 text-[#6B3EFF]" />
        </div>
        <div>
          <p className="text-sm font-semibold text-[#6B3EFF] mb-1">
            Paty te conseille :
          </p>
          <p className="text-sm text-gray-700 leading-relaxed">
            {message}
          </p>
        </div>
      </div>
    </div>
  );
}