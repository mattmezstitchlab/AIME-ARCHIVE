import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Generate illustrations for all scenes of a story using InvokeLLM
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { story_project_id } = await req.json();
    if (!story_project_id) return Response.json({ error: 'story_project_id required' }, { status: 400 });

    const stories = await base44.asServiceRole.entities.StoryProject.filter({ id: story_project_id });
    const story = stories[0];
    if (!story) return Response.json({ error: 'Story not found' }, { status: 404 });

    const scenes = await base44.asServiceRole.entities.StoryScene.filter({ story_project_id: story_project_id }, 'scene_number');
    if (scenes.length === 0) {
      return Response.json({ error: 'No scenes found for this story', status: 400 });
    }

    const illustrationStyle = story.illustration_style || 'watercolor storybook illustration, soft edges, warm colors, children book style';
    const results = [];

    for (const scene of scenes) {
      if (scene.illustration_url) {
        results.push({ scene_id: scene.id, success: true, skipped: true });
        continue;
      }

      const prompt = `${scene.illustration_prompt || scene.scene_text}. Art style: ${illustrationStyle}. Full scene illustration, no text, high quality digital art.`;

      try {
        const llmResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
          prompt: `Generate an image prompt for: ${prompt}. Return JSON: {"image_prompt": "detailed english prompt for image generation"}`,
          response_json_schema: {
            type: "object",
            properties: {
              image_prompt: { type: "string" }
            }
          },
        });

        const imageResult = await base44.asServiceRole.integrations.Core.GenerateImage({
          prompt: llmResult.image_prompt || prompt,
        });

        await base44.asServiceRole.entities.StoryScene.update(scene.id, {
          illustration_url: imageResult.url,
        });

        results.push({ scene_id: scene.id, success: true, illustration_url: imageResult.url });
      } catch (error) {
        results.push({ scene_id: scene.id, success: false, error: error.message });
      }
    }

    const successCount = results.filter(r => r.success).length;
    return Response.json({ 
      message: `Generated ${successCount}/${scenes.length} illustrations`,
      generated: successCount,
      total: scenes.length,
      results 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});