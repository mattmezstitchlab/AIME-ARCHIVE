import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Generate a story with exactly 3 scenes (2 paragraphs each) for the Coloria format
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { title, description, audience, story_type, illustration_style, voice_profile_id } = await req.json();
    if (!title) return Response.json({ error: 'title required' }, { status: 400 });

    // 1. Generate story structure via LLM — exactly 3 scenes, 2 paragraphs each
    const storyData = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Tu es un auteur de contes pour ${audience || 'enfants'}. Crée un conte intitulé "${title}".
Description / intention : ${description || ''}
Type : ${story_type || 'conte'}
Style d'illustration souhaité : ${illustration_style || 'aquarelle douce, livre illustré pour enfants'}

IMPORTANT : Génère exactement 3 scènes. Chaque scène doit contenir exactement 2 paragraphes narratifs (séparés par une ligne vide). Le texte de chaque scène doit faire entre 80 et 130 mots — c'est court, rythmé, pensé pour être lu à voix haute pendant qu'un enfant colorie.

Retourne un JSON avec :
- "subtitle": string (sous-titre poétique)
- "tagline": string (accroche courte, 1 phrase)
- "text_content": string (le conte complet, concatenation des 3 scènes)
- "themes": string[] (2-4 thèmes)
- "scenes": array de exactement 3 objets { "scene_number": 1|2|3, "chapter_title": string (titre court de la scène), "scene_text": string (2 paragraphes, 80-130 mots), "illustration_prompt": string (prompt anglais détaillé, style coloring book line art, clean outlines, no color fill, for children) }`,
      response_json_schema: {
        type: "object",
        properties: {
          subtitle: { type: "string" },
          tagline: { type: "string" },
          text_content: { type: "string" },
          themes: { type: "array", items: { type: "string" } },
          scenes: {
            type: "array",
            items: {
              type: "object",
              properties: {
                scene_number: { type: "number" },
                chapter_title: { type: "string" },
                scene_text: { type: "string" },
                illustration_prompt: { type: "string" }
              }
            }
          }
        },
        required: ["text_content", "scenes"]
      }
    });

    // 2. Lookup author_presence_id for this user
    let authorPresenceId = null;
    try {
      const presences = await base44.asServiceRole.entities.AuthorPresence.filter({ user_id: user.id });
      authorPresenceId = presences[0]?.id || null;
    } catch (_) {}

    // 3. Create StoryProject
    const story = await base44.asServiceRole.entities.StoryProject.create({
      user_id: user.id,
      author_presence_id: authorPresenceId,
      title,
      subtitle: storyData.subtitle || '',
      tagline: storyData.tagline || '',
      target_audience: audience || 'enfants',
      story_type: story_type || 'conte',
      themes: storyData.themes || [],
      text_content: storyData.text_content,
      illustration_style: illustration_style || "aquarelle douce, livre illustré pour enfants",
      voice_profile_id: voice_profile_id || null,
      status: 'generated',
      visibility: 'private'
    });

    // 3. Create exactly 3 StoryScenes
    const scenes = (storyData.scenes || []).slice(0, 3);
    for (const scene of scenes) {
      await base44.asServiceRole.entities.StoryScene.create({
        story_project_id: story.id,
        scene_number: scene.scene_number,
        chapter_title: scene.chapter_title,
        scene_text: scene.scene_text,
        illustration_prompt: scene.illustration_prompt,
      });
    }

    return Response.json({ success: true, story_id: story.id, scene_count: scenes.length });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});