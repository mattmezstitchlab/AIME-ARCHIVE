import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { depositId, directionId } = await req.json();
    if (!depositId || !directionId) {
      return Response.json({ error: 'Missing depositId or directionId' }, { status: 400 });
    }

    const deposits = await base44.asServiceRole.entities.LabDeposit.filter({ id: depositId });
    const deposit = deposits[0];
    if (!deposit) {
      return Response.json({ error: 'Deposit not found' }, { status: 404 });
    }

    const direction = deposit.directions?.find((d) => d.id === directionId);
    if (!direction) {
      return Response.json({ error: 'Direction not found' }, { status: 404 });
    }

    // Update direction status to selected
    const updatedDirections = deposit.directions.map((d) =>
      d.id === directionId ? { ...d, status: "selected" } : d
    );

    await base44.asServiceRole.entities.LabDeposit.update(depositId, {
      directions: updatedDirections,
      selected_direction_id: directionId,
      status: "generating"
    });

    let generatedEntity = null;
    let entityType = "";
    let redirectUrl = "";

    if (direction.type === "conte_mode") {
      entityType = "FashionTale";
      const storyPrompt = `Crée un conte de mode basé sur: "${deposit.title}". ${deposit.text_content?.substring(0, 200) || ""}. Génère JSON: {"title": string, "subtitle": string, "theme": "mariage|anniversaire|enfance|famille|fete|romantique|urbain", "target_audience": "enfants|ados|adultes|famille|tous", "summary": string, "full_story": string (500-1000 mots), "narrative_style": string, "music_style": string, "scenes": [{"scene_number": number, "title": string, "text": string, "illustration_prompt": string}], "characters": [{"name": string, "role": string, "description": string, "style": string}]}`;

      const storyData = await base44.integrations.Core.InvokeLLM({
        prompt: storyPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            subtitle: { type: "string" },
            theme: { type: "string" },
            target_audience: { type: "string" },
            summary: { type: "string" },
            full_story: { type: "string" },
            narrative_style: { type: "string" },
            music_style: { type: "string" },
            scenes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  scene_number: { type: "number" },
                  title: { type: "string" },
                  text: { type: "string" },
                  illustration_prompt: { type: "string" }
                }
              }
            },
            characters: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  role: { type: "string" },
                  description: { type: "string" },
                  style: { type: "string" }
                }
              }
            }
          },
          required: ["title", "theme", "target_audience", "summary"]
        }
      });

      generatedEntity = await base44.entities.FashionTale.create({
        ...storyData,
        cover_image_url: deposit.image_urls?.[0] || "",
        status: "draft",
        created_by_id: user.id
      });
      redirectUrl = `/contes-de-mode/${generatedEntity.id}`;

    } else if (direction.type === "conte_immobilier") {
      entityType = "StoryProject";
      const storyPrompt = `Crée un conte immobilier pour: "${deposit.title}". ${deposit.text_content?.substring(0, 200) || ""}. Génère JSON: {"title": string, "subtitle": string, "tagline": string, "target_audience": "adultes|famille", "story_type": "recit_familial", "themes": string[], "text_content": string (500-800 mots), "scene_breakdown": [{"scene_number": number, "chapter_title": string, "scene_text": string, "illustration_prompt": string}]}`;

      const storyData = await base44.integrations.Core.InvokeLLM({
        prompt: storyPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            subtitle: { type: "string" },
            tagline: { type: "string" },
            target_audience: { type: "string" },
            story_type: { type: "string" },
            themes: { type: "array", items: { type: "string" } },
            text_content: { type: "string" },
            scene_breakdown: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  scene_number: { type: "number" },
                  chapter_title: { type: "string" },
                  scene_text: { type: "string" },
                  illustration_prompt: { type: "string" }
                }
              }
            }
          },
          required: ["title", "target_audience"]
        }
      });

      generatedEntity = await base44.entities.StoryProject.create({
        ...storyData,
        user_id: user.id,
        hero_image_url: deposit.image_urls?.[0] || "",
        status: "draft",
        visibility: "private"
      });
      redirectUrl = `/conte/${generatedEntity.id}`;

    } else if (direction.type === "capsule_memoire") {
      entityType = "StoryProject";
      const storyPrompt = `Crée une capsule mémoire pour: "${deposit.title}". ${deposit.text_content?.substring(0, 200) || ""}. Génère JSON: {"title": string, "subtitle": string, "target_audience": "famille", "story_type": "recit_familial", "themes": ["mémoire", "famille", "transmission"], "text_content": string}`;

      const storyData = await base44.integrations.Core.InvokeLLM({
        prompt: storyPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            subtitle: { type: "string" },
            target_audience: { type: "string" },
            story_type: { type: "string" },
            themes: { type: "array", items: { type: "string" } },
            text_content: { type: "string" }
          },
          required: ["title", "target_audience"]
        }
      });

      generatedEntity = await base44.entities.StoryProject.create({
        ...storyData,
        user_id: user.id,
        hero_image_url: deposit.image_urls?.[0] || "",
        status: "draft",
        visibility: "private"
      });
      redirectUrl = `/conte/${generatedEntity.id}`;
    }

    // Update deposit with generated entity
    const finalDirections = updatedDirections.map((d) =>
      d.id === directionId ? { ...d, status: "ready", generated_content: generatedEntity } : d
    );

    await base44.asServiceRole.entities.LabDeposit.update(depositId, {
      created_for_entity: entityType,
      generated_entity_id: generatedEntity?.id || null,
      directions: finalDirections,
      status: "ready"
    });

    return Response.json({
      success: true,
      entityType,
      entityId: generatedEntity?.id,
      redirectUrl
    });

  } catch (error) {
    console.error("Error generating entity:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});