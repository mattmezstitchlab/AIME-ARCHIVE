import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Generate audio for a single story scene using ElevenLabs
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { scene_id, scene_text, voice_model_id } = await req.json();
    if (!scene_id || !scene_text) return Response.json({ error: 'scene_id and scene_text required' }, { status: 400 });

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');

    // Use provided voice or fall back to a default ElevenLabs voice (Rachel)
    const voiceId = voice_model_id || '21m00Tcm4TlvDq8ikWAM';

    const ttsRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: scene_text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.75 }
      })
    });

    if (!ttsRes.ok) {
      const errBody = await ttsRes.text();
      return Response.json({ error: `ElevenLabs TTS error: ${errBody}` }, { status: ttsRes.status });
    }

    // Upload the audio
    const audioBlob = await ttsRes.blob();
    const audioFile = new File([audioBlob], `scene_${scene_id}.mp3`, { type: 'audio/mpeg' });
    const uploaded = await base44.asServiceRole.integrations.Core.UploadFile({ file: audioFile });

    // Save audio URL to scene
    await base44.asServiceRole.entities.StoryScene.update(scene_id, {
      audio_segment_url: uploaded.file_url
    });

    return Response.json({ success: true, audio_url: uploaded.file_url });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});