import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Clone a voice on ElevenLabs from an audio sample URL
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { audio_url, voice_name, voice_description } = await req.json();
    if (!audio_url) return Response.json({ error: 'audio_url required' }, { status: 400 });

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');

    // Fetch the audio file from the URL
    const audioRes = await fetch(audio_url);
    if (!audioRes.ok) return Response.json({ error: 'Failed to fetch audio file' }, { status: 400 });
    const audioBlob = await audioRes.blob();

    // Build multipart form data for ElevenLabs
    const formData = new FormData();
    formData.append('name', voice_name || `Voix de ${user.full_name || 'utilisateur'}`);
    formData.append('description', voice_description || 'Voix clonée via SLAÂME');
    formData.append('files', audioBlob, 'voice_sample.webm');

    const elRes = await fetch('https://api.elevenlabs.io/v1/voices/add', {
      method: 'POST',
      headers: { 'xi-api-key': apiKey },
      body: formData,
    });

    if (!elRes.ok) {
      const err = await elRes.text();
      return Response.json({ error: `ElevenLabs error: ${err}` }, { status: elRes.status });
    }

    const data = await elRes.json();
    return Response.json({ voice_id: data.voice_id, name: data.name });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});