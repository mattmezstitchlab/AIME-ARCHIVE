import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// List and delete voices on ElevenLabs account
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');
    const { action, voice_id } = await req.json();

    // List all voices
    if (action === 'list') {
      const res = await fetch('https://api.elevenlabs.io/v1/voices', {
        headers: { 'xi-api-key': apiKey }
      });
      if (!res.ok) return Response.json({ error: 'Failed to list voices' }, { status: 500 });
      const data = await res.json();
      // Filter only cloned voices (not premade)
      const cloned = (data.voices || []).filter(v => v.category === 'cloned');
      return Response.json({ voices: cloned });
    }

    // Delete a voice
    if (action === 'delete') {
      if (!voice_id) return Response.json({ error: 'voice_id required' }, { status: 400 });
      const res = await fetch(`https://api.elevenlabs.io/v1/voices/${voice_id}`, {
        method: 'DELETE',
        headers: { 'xi-api-key': apiKey }
      });
      if (!res.ok) {
        const err = await res.text();
        return Response.json({ error: `ElevenLabs error: ${err}` }, { status: res.status });
      }
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});