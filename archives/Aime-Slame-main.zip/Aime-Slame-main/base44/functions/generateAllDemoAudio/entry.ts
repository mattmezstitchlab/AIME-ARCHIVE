import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// ElevenLabs built-in French-friendly voices (rotated for variety)
const DEMO_VOICES = [
  { id: "XB0fDUnXU5powFXDhCwa", name: "Charlotte" },
  { id: "TxGEqnHWrfWFTfGW9XjX", name: "Josh" },
  { id: "VR6AewLTigWG4xSOukaG", name: "Arnold" },
  { id: "pNInz6obpgDQGcFmaJgB", name: "Adam" },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Fetch all demo stories without audio
    const allStories = await base44.asServiceRole.entities.StoryProject.filter({});
    const demoStories = allStories.filter(s => {
      const isDemo = s.user_id === 'demo' || s.visibility === 'public';
      const noAudio = !s.audio_url || s.audio_url === '';
      return isDemo && noAudio;
    });

    if (demoStories.length === 0) {
      return Response.json({ message: 'No demo stories need audio', generated: 0 });
    }

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');
    const results = [];

    for (let i = 0; i < demoStories.length; i++) {
      const story = demoStories[i];
      const voice = DEMO_VOICES[i % DEMO_VOICES.length];
      const text = story.text_content || story.tagline || story.title;

      try {
        const elRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice.id}`, {
          method: 'POST',
          headers: {
            'xi-api-key': apiKey,
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg',
          },
          body: JSON.stringify({
            text: text.slice(0, 4000),
            model_id: 'eleven_multilingual_v2',
            voice_settings: {
              stability: 0.6,
              similarity_boost: 0.8,
              style: 0.4,
              use_speaker_boost: true,
            },
          }),
        });

        if (!elRes.ok) {
          const err = await elRes.text();
          results.push({ id: story.id, title: story.title, success: false, error: err });
          continue;
        }

        const audioBuffer = await elRes.arrayBuffer();
        const audioFile = new File([audioBuffer], `narration_${story.id}.mp3`, { type: 'audio/mpeg' });
        const uploadRes = await base44.asServiceRole.integrations.Core.UploadFile({ file: audioFile });

        await base44.asServiceRole.entities.StoryProject.update(story.id, {
          audio_url: uploadRes.file_url,
          status: 'audio_ready',
          narrator_name: voice.name,
        });

        results.push({ id: story.id, title: story.title, success: true, audio_url: uploadRes.file_url });
      } catch (error) {
        results.push({ id: story.id, title: story.title, success: false, error: error.message });
      }
    }

    const successCount = results.filter(r => r.success).length;
    return Response.json({ 
      message: `Generated ${successCount}/${demoStories.length} audio tracks`,
      generated: successCount,
      total: demoStories.length,
      results 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});