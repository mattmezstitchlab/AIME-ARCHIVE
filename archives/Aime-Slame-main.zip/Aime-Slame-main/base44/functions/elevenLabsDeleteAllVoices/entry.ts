import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Delete ALL cloned voices from ElevenLabs account to free up slots
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');

    // List all voices
    const listRes = await fetch('https://api.elevenlabs.io/v1/voices', {
      headers: { 'xi-api-key': apiKey }
    });
    const data = await listRes.json();
    const cloned = (data.voices || []).filter(v => v.category === 'cloned');

    const results = [];
    for (const voice of cloned) {
      const delRes = await fetch(`https://api.elevenlabs.io/v1/voices/${voice.voice_id}`, {
        method: 'DELETE',
        headers: { 'xi-api-key': apiKey }
      });
      results.push({ voice_id: voice.voice_id, name: voice.name, deleted: delRes.ok });
    }

    return Response.json({ deleted: results.length, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});