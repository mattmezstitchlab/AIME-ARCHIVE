import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { story_project_id } = await req.json();
    if (!story_project_id) return Response.json({ error: 'story_project_id required' }, { status: 400 });

    // Get all scenes for this story
    const scenes = await base44.asServiceRole.entities.StoryScene.filter({ story_project_id });
    if (!scenes.length) return Response.json({ error: 'No scenes found' }, { status: 404 });

    // Get story for style context (filter by id is broken — use list + find)
    const allStories = await base44.asServiceRole.entities.StoryProject.list();
    const story = allStories.find(s => s.id === story_project_id);
    const styleHint = story?.illustration_style || "children's book illustration, painterly, magical";

    const results = [];

    for (const scene of scenes) {
      // Skip if already has a unique illustration (not the shared placeholder)
      const prompt = scene.illustration_prompt || scene.chapter_title || "magical scene";
      
      // Generate illustration
      const imgResult = await base44.asServiceRole.integrations.Core.GenerateImage({
        prompt: `${prompt}. Style: ${styleHint}, high quality digital illustration, warm cinematic lighting, detailed, vibrant colors, no text, no watermark`,
      });

      if (imgResult?.url) {
        await base44.asServiceRole.entities.StoryScene.update(scene.id, {
          illustration_url: imgResult.url,
        });
        results.push({ scene_id: scene.id, chapter_title: scene.chapter_title, url: imgResult.url });
      }
    }

    return Response.json({ success: true, generated: results.length, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});