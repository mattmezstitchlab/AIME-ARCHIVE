import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// ElevenLabs built-in French-friendly voices (no cloning needed)
// "Charlotte" - warm, narrative, French-compatible
const DEMO_VOICE_ID = "XB0fDUnXU5powFXDhCwa"; // Charlotte

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { story_project_id } = await req.json();
    if (!story_project_id) return Response.json({ error: 'story_project_id required' }, { status: 400 });

    const stories = await base44.asServiceRole.entities.StoryProject.filter({ id: story_project_id });
    const story = stories[0];
    if (!story) return Response.json({ error: 'Story not found' }, { status: 404 });

    const text = story.text_content || story.tagline || story.title;
    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');

    const elRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${DEMO_VOICE_ID}`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg',
      },
      body: JSON.stringify({
        text: text.slice(0, 4000),
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.6,
          similarity_boost: 0.8,
          style: 0.4,
          use_speaker_boost: true,
        },
      }),
    });

    if (!elRes.ok) {
      const err = await elRes.text();
      return Response.json({ error: `ElevenLabs error: ${err}` }, { status: elRes.status });
    }

    const audioBuffer = await elRes.arrayBuffer();
    const audioFile = new File([audioBuffer], 'narration.mp3', { type: 'audio/mpeg' });
    const uploadRes = await base44.asServiceRole.integrations.Core.UploadFile({ file: audioFile });

    await base44.asServiceRole.entities.StoryProject.update(story_project_id, {
      audio_url: uploadRes.file_url,
      status: 'audio_ready',
    });

    return Response.json({ audio_url: uploadRes.file_url });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});