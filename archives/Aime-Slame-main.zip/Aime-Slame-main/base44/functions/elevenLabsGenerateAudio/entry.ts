import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Generate story narration audio using a cloned voice on ElevenLabs
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { text, voice_id, story_project_id } = await req.json();
    if (!text) return Response.json({ error: 'text required' }, { status: 400 });
    if (!voice_id) return Response.json({ error: 'voice_id required' }, { status: 400 });

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');

    // Call ElevenLabs TTS
    const elRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice_id}`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.85,
          style: 0.3,
          use_speaker_boost: true,
        },
      }),
    });

    if (!elRes.ok) {
      const err = await elRes.text();
      return Response.json({ error: `ElevenLabs error: ${err}` }, { status: elRes.status });
    }

    const audioBuffer = await elRes.arrayBuffer();

    // Upload to Base44 storage using SDK
    const audioFile = new File([audioBuffer], 'narration.mp3', { type: 'audio/mpeg' });
    const uploadRes = await base44.asServiceRole.integrations.Core.UploadFile({ file: audioFile });
    const file_url = uploadRes.file_url;

    // Optionally update the StoryProject with the audio_url
    if (story_project_id) {
      await base44.asServiceRole.entities.StoryProject.update(story_project_id, {
        audio_url: file_url,
        status: 'audio_ready',
      });
    }

    return Response.json({ audio_url: file_url });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});