import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { depositId, directionId } = await req.json();
    if (!depositId || !directionId) {
      return Response.json({ error: 'Missing depositId or directionId' }, { status: 400 });
    }

    const deposits = await base44.asServiceRole.entities.LabDeposit.filter({ id: depositId });
    const deposit = deposits[0];
    if (!deposit) {
      return Response.json({ error: 'Deposit not found' }, { status: 404 });
    }

    const direction = deposit.directions?.find((d) => d.id === directionId);
    if (!direction) {
      return Response.json({ error: 'Direction not found' }, { status: 404 });
    }

    // Update direction status
    const updatedDirections = deposit.directions.map((d) =>
      d.id === directionId ? { ...d, status: "selected" } : d
    );

    await base44.asServiceRole.entities.LabDeposit.update(depositId, {
      directions: updatedDirections,
      selected_direction_id: directionId,
      status: "generating"
    });

    // Generate content based on direction type
    let generatedEntity = null;
    let entityType = "";

    if (direction.type === "conte_mode") {
      // Create FashionTale
      entityType = "FashionTale";
      const storyPrompt = `
Crée un conte de mode basé sur ce dépôt:
- Titre: ${deposit.title}
- Texte: ${deposit.text_content?.substring(0, 300) || ""}
- Direction: ${direction.title}

Génère un JSON avec:
{
  "title": "Titre du conte",
  "subtitle": "Sous-titre",
  "theme": "mariage|anniversaire|enfance|famille|fete|romantique|urbain|saison",
  "target_audience": "enfants|ados|adultes|famille|tous",
  "summary": "Résumé court",
  "full_story": "Histoire complète (500-1000 mots)",
  "narrative_style": "Style narratif",
  "music_style": "Style musical",
  "scenes": [
    {
      "scene_number": 1,
      "title": "Titre scène",
      "text": "Texte scène",
      "illustration_prompt": "Prompt pour illustration"
    }
  ],
  "characters": [
    {
      "name": "Nom",
      "role": "Rôle",
      "description": "Description",
      "style": "Style vestimentaire"
    }
  ]
}
`;

      const storyData = await base44.integrations.Core.InvokeLLM({
        prompt: storyPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            subtitle: { type: "string" },
            theme: { type: "string" },
            target_audience: { type: "string" },
            summary: { type: "string" },
            full_story: { type: "string" },
            narrative_style: { type: "string" },
            music_style: { type: "string" },
            scenes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  scene_number: { type: "number" },
                  title: { type: "string" },
                  text: { type: "string" },
                  illustration_prompt: { type: "string" }
                }
              }
            },
            characters: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  role: { type: "string" },
                  description: { type: "string" },
                  style: { type: "string" }
                }
              }
            }
          },
          required: ["title", "theme", "target_audience", "summary"]
        }
      });

      generatedEntity = await base44.entities.FashionTale.create({
        ...storyData,
        cover_image_url: deposit.image_urls?.[0] || "",
        status: "draft",
        created_by_id: user.id
      });

    } else if (direction.type === "conte_immobilier") {
      // Create StoryProject
      entityType = "StoryProject";
      const storyPrompt = `
Crée un conte immobilier basé sur ce dépôt:
- Titre: ${deposit.title}
- Texte: ${deposit.text_content?.substring(0, 300) || ""}

Génère un JSON avec:
{
  "title": "Titre",
  "subtitle": "Sous-titre",
  "tagline": "Phrase d'accroche",
  "target_audience": "adultes|famille",
  "story_type": "recit_familial|conte_initiatique",
  "themes": ["immobilier", "mémoire", "transmission"],
  "summary": "Résumé",
  "text_content": "Histoire complète",
  "scene_breakdown": [
    {
      "scene_number": 1,
      "chapter_title": "Titre",
      "scene_text": "Texte",
      "illustration_prompt": "Prompt"
    }
  ]
}
`;

      const storyData = await base44.integrations.Core.InvokeLLM({
        prompt: storyPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            subtitle: { type: "string" },
            tagline: { type: "string" },
            target_audience: { type: "string" },
            story_type: { type: "string" },
            themes: { type: "array", items: { type: "string" } },
            summary: { type: "string" },
            text_content: { type: "string" },
            scene_breakdown: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  scene_number: { type: "number" },
                  chapter_title: { type: "string" },
                  scene_text: { type: "string" },
                  illustration_prompt: { type: "string" }
                }
              }
            }
          },
          required: ["title", "target_audience"]
        }
      });

      generatedEntity = await base44.entities.StoryProject.create({
        ...storyData,
        user_id: user.id,
        hero_image_url: deposit.image_urls?.[0] || "",
        status: "draft",
        visibility: "private"
      });

    } else if (direction.type === "page_evenement") {
      entityType = "Event";
      // V1: Create Event entity
    } else if (direction.type === "jingle") {
      entityType = "AudioTrack";
      // V1: Generate audio script
    } else if (direction.type === "capsule_memoire") {
      entityType = "StoryProject";
      // V1: Create memory capsule
    }

    // Update deposit with generated entity
    await base44.asServiceRole.entities.LabDeposit.update(depositId, {
      created_for_entity: entityType,
      generated_entity_id: generatedEntity?.id || null,
      directions: updatedDirections.map((d) =>
        d.id === directionId ? { ...d, status: "ready", generated_content: generatedEntity } : d
      ),
      status: "ready"
    });

    return Response.json({
      success: true,
      entityType,
      entityId: generatedEntity?.id,
      direction: direction
    });

  } catch (error) {
    console.error("Error creating direction:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});