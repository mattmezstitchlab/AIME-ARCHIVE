import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { depositId } = await req.json();
    if (!depositId) {
      return Response.json({ error: 'Missing depositId' }, { status: 400 });
    }

    const deposits = await base44.asServiceRole.entities.LabDeposit.filter({ id: depositId });
    const deposit = deposits[0];
    if (!deposit) {
      return Response.json({ error: 'Deposit not found' }, { status: 404 });
    }

    // Analyze with LLM
    const textPreview = deposit.text_content ? deposit.text_content.substring(0, 500) : 'N/A';
    const keywordsStr = deposit.keywords && deposit.keywords.length > 0 ? deposit.keywords.join(', ') : 'N/A';
    const objectivesStr = deposit.objectives && deposit.objectives.length > 0 ? deposit.objectives.join(', ') : 'N/A';
    const linksCount = deposit.links ? deposit.links.length : 0;
    const imagesCount = deposit.image_urls ? deposit.image_urls.length : 0;
    
    const analysisPrompt = `Analyse ce depot SLAAME Lab et genere des directions creatives pertinentes.

DEPOT:
- Titre: ${deposit.title}
- Description: ${deposit.description || 'N/A'}
- Texte: ${textPreview}
- Mots-cles: ${keywordsStr}
- Objectifs: ${objectivesStr}
- Liens: ${linksCount} lien(s)
- Images: ${imagesCount} image(s)

Genere 3-7 directions creatives avec cette structure JSON:
{
  "directions": [
    {
      "id": "dir_1",
      "type": "conte_immobilier|visite_audio|page_evenement|conte_mode|direction_solidaire|jingle|annonce_sensible|lookbook|marketplace|capsule_memoire|livre_souvenir",
      "title": "Titre accrocheur",
      "category": "Categorie principale",
      "why_relevant": "Pourquoi cette direction est pertinente pour ce depot",
      "possible_outputs": ["sortie1", "sortie2"],
      "complexity": "simple|medium|complex",
      "estimated_time": "10-15 min",
      "is_confidential": false,
      "commission_estimate": 0,
      "solidarity_percentage": 0
    }
  ],
  "theme_detected": "Theme principal detecte",
  "emotion_detected": "Emotion dominante"
}

Regles:
- Adapter les directions aux mots-cles et objectifs
- Si "maison/immobilier/vente" -> conte_immobilier
- Si "mode/produit" -> conte_mode
- Si "evenement/mariage" -> page_evenement
- Si "audio/voix" -> jingle ou visite_audio
- Si "solidarite/aide" -> direction_solidaire
- Si "souvenir/memoire" -> capsule_memoire
- Inclure commission_estimate (5-15%) pour les directions commerce
- Inclure solidarity_percentage (3-10%) pour les directions solidaires`;

    const analysisResult = await base44.integrations.Core.InvokeLLM({
      prompt: analysisPrompt,
      response_json_schema: {
        type: "object",
        properties: {
          directions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "string" },
                type: { type: "string" },
                title: { type: "string" },
                category: { type: "string" },
                why_relevant: { type: "string" },
                possible_outputs: { type: "array", items: { type: "string" } },
                complexity: { type: "string" },
                estimated_time: { type: "string" },
                is_confidential: { type: "boolean" },
                commission_estimate: { type: "number" },
                solidarity_percentage: { type: "number" }
              },
              required: ["id", "type", "title", "category", "why_relevant"]
            }
          },
          theme_detected: { type: "string" },
          emotion_detected: { type: "string" }
        },
        required: ["directions"]
      }
    });

    // Format directions with status
    const formattedDirections = analysisResult.directions.map((d, i) => ({
      ...d,
      id: `dir_${Date.now()}_${i}`,
      status: "proposed"
    }));

    // Update deposit with analysis
    await base44.asServiceRole.entities.LabDeposit.update(depositId, {
      directions: formattedDirections,
      theme_detected: analysisResult.theme_detected || "",
      emotion_detected: analysisResult.emotion_detected || "",
      analysis_data: analysisResult,
      status: "directions_proposed"
    });

    return Response.json({
      success: true,
      directions: formattedDirections,
      theme: analysisResult.theme_detected,
      emotion: analysisResult.emotion_detected
    });

  } catch (error) {
    console.error("Error analyzing deposit:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});