import { useState, useRef, useEffect } from "react";
import { Play, Pause, Loader2 } from "lucide-react";

// globalAudio: shared Audio instance passed from parent to prevent overlapping playback
export default function ColoriaSceneCard({ scene, index, globalAudio, setGlobalAudio }) {
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const audioRef = useRef(null);

  // Stop this card when another card starts playing
  useEffect(() => {
    if (globalAudio && globalAudio !== audioRef.current && playing) {
      audioRef.current?.pause();
      setPlaying(false);
    }
  }, [globalAudio]);

  const handlePlay = async () => {
    if (!scene.audio_segment_url) return;

    if (!audioRef.current) {
      audioRef.current = new Audio(scene.audio_segment_url);
      audioRef.current.onended = () => setPlaying(false);
    }

    if (playing) {
      audioRef.current.pause();
      setPlaying(false);
    } else {
      // Stop any other playing audio
      if (globalAudio && globalAudio !== audioRef.current) {
        globalAudio.pause();
      }
      setGlobalAudio(audioRef.current);
      setLoading(true);
      try {
        await audioRef.current.play();
        setPlaying(true);
      } finally {
        setLoading(false);
      }
    }
  };

  const sceneLabels = ["Scène 1", "Scène 2", "Scène 3"];

  return (
    <div className="bg-white/3 border border-white/10 rounded-2xl overflow-hidden">
      {/* Illustration */}
      {scene.illustration_url ? (
        <div className="relative aspect-[4/3] bg-white/5">
          <img
            src={scene.illustration_url}
            alt={scene.chapter_title}
            className="w-full h-full object-cover"
          />
          {/* Audio play overlay */}
          {scene.audio_segment_url && (
            <button
              onClick={handlePlay}
              className="absolute bottom-3 right-3 w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 flex items-center justify-center shadow-lg transition-colors"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : playing ? (
                <Pause className="w-4 h-4 text-white" />
              ) : (
                <Play className="w-4 h-4 text-white ml-0.5" />
              )}
            </button>
          )}
        </div>
      ) : (
        <div className="aspect-[4/3] bg-white/5 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-white/20" />
        </div>
      )}

      {/* Text */}
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-red-500 text-[10px] tracking-widest uppercase">{sceneLabels[index] || `Scène ${index + 1}`}</span>
          <span className="text-white/30 text-xs">{scene.chapter_title}</span>
        </div>
        <p className="text-white/70 text-sm leading-relaxed whitespace-pre-line">{scene.scene_text}</p>
      </div>
    </div>
  );
}