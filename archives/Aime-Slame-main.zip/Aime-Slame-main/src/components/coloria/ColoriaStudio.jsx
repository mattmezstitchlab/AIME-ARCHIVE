import { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import {
  ArrowLeft, Paintbrush, Droplets, Eraser, Undo2, Download, Play,
  Loader2, Palette, Wand2, Sun, Layers, CircleDot
} from "lucide-react";

const BRUSH_MODES = [
  { key: "solid", label: "Solide" },
  { key: "gradient", label: "Dégradé" },
  { key: "light", label: "Lumière" },
  { key: "shadow", label: "Ombre" },
];

const TOOLS = [
  { key: "brush", Icon: Paintbrush, label: "Pinceau" },
  { key: "fill", Icon: Droplets, label: "Remplir" },
  { key: "eraser", Icon: Eraser, label: "Gomme" },
];

const FALLBACK_PALETTE = [
  "#F2E8D5","#E8C9A0","#D4956A","#A0522D","#7C3D1E",
  "#8FBC8F","#5F9B5F","#3A7A3A","#2D5A2D","#1A3A1A",
  "#87CEEB","#4A9FD4","#2171B5","#0D4F8B","#08306B",
  "#FFD700","#FFA500","#FF6B35","#E84855","#9B2335",
  "#DDA0DD","#9370DB","#6A4C93","#4A1F7C","#FFFFFF",
];

// Hex to rgb helper
const hexToRgb = (hex) => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return { r, g, b };
};

export default function ColoriaStudio({ project, onBack, onSave }) {
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);
  const maskRef = useRef(null);
  const liveCanvasRef = useRef(null); // offscreen for live motion

  const [tool, setTool] = useState("brush");
  const [brushMode, setBrushMode] = useState("solid");
  const [color, setColor] = useState("#D4956A");
  const [color2, setColor2] = useState("#FFD700"); // gradient second color
  const [brushSize, setBrushSize] = useState(14);
  const [opacity, setOpacity] = useState(1);
  const [drawing, setDrawing] = useState(false);
  const [history, setHistory] = useState([]);
  const [strokes, setStrokes] = useState(project.canvas_strokes || []);
  const [saving, setSaving] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [palette, setPalette] = useState(FALLBACK_PALETTE);
  const [loadingPalette, setLoadingPalette] = useState(false);

  const strokesRef = useRef(strokes);
  const currentStrokeRef = useRef(null);
  const maskImageRef = useRef(null); // keep Image ref for reuse
  const lineArtImageRef = useRef(null);
  const rafRef = useRef(null);

  useEffect(() => { strokesRef.current = strokes; }, [strokes]);

  // AI palette
  useEffect(() => {
    const prompt = project.prompt || project.title || "";
    if (!prompt) return;
    setLoadingPalette(true);
    base44.integrations.Core.InvokeLLM({
      prompt: `Tu es un directeur artistique spécialisé en illustration jeunesse.
Génère une palette harmonique de 25 couleurs pour colorier cette illustration : "${prompt}".
Style : illustration pour enfants, couleurs chaudes et poétiques, harmonie professionnelle.
Retourne uniquement un objet JSON { colors: [...25 codes hex] }.`,
      response_json_schema: {
        type: "object",
        properties: { colors: { type: "array", items: { type: "string" } } }
      }
    }).then((res) => {
      if (res?.colors?.length >= 10) {
        setPalette(res.colors.slice(0, 25));
        setColor(res.colors[2] || "#D4956A");
        setColor2(res.colors[5] || "#FFD700");
      }
    }).catch(() => {}).finally(() => setLoadingPalette(false));
  }, [project.id]);

  // Load line art
  useEffect(() => {
    if (!project.line_art_url) return;
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      lineArtImageRef.current = img;

      // Draw overlay
      const overlay = overlayRef.current;
      if (overlay) {
        const octx = overlay.getContext("2d");
        octx.clearRect(0, 0, overlay.width, overlay.height);
        octx.drawImage(img, 0, 0, overlay.width, overlay.height);
      }

      // Build mask
      const mask = maskRef.current;
      if (mask) {
        const mctx = mask.getContext("2d");
        mctx.clearRect(0, 0, mask.width, mask.height);
        mctx.drawImage(img, 0, 0, mask.width, mask.height);
        const imgData = mctx.getImageData(0, 0, mask.width, mask.height);
        const d = imgData.data;
        for (let i = 0; i < d.length; i += 4) {
          const brightness = (d[i] + d[i + 1] + d[i + 2]) / 3;
          if (brightness > 128) {
            d[i] = 255; d[i + 1] = 255; d[i + 2] = 255; d[i + 3] = 255;
          } else {
            d[i] = 0; d[i + 1] = 0; d[i + 2] = 0; d[i + 3] = 0;
          }
        }
        mctx.putImageData(imgData, 0, 0);
        maskImageRef.current = mask;
      }

      setImageLoaded(true);
    };
    img.src = project.line_art_url;
  }, [project.line_art_url]);

  // Replay saved strokes on mount
  useEffect(() => {
    if (strokes.length > 0 && canvasRef.current && imageLoaded) {
      const ctx = canvasRef.current.getContext("2d");
      replayAllStrokes(ctx, strokes);
    }
  }, [imageLoaded]);

  // ─── Drawing helpers ───────────────────────────────────────────────

  const applyMask = (ctx) => {
    if (maskImageRef.current) {
      ctx.globalCompositeOperation = "destination-in";
      ctx.drawImage(maskImageRef.current, 0, 0);
      ctx.globalCompositeOperation = "source-over";
    }
  };

  const buildStrokeStyle = (ctx, stroke) => {
    const { brushMode: mode = "solid", color, color2: c2 = color, points, opacity: op = 1 } = stroke;
    ctx.globalAlpha = op;

    if (mode === "solid") {
      ctx.strokeStyle = color;
      return;
    }
    if (mode === "gradient" && points.length >= 2) {
      const p0 = points[0], p1 = points[points.length - 1];
      const grad = ctx.createLinearGradient(p0.x, p0.y, p1.x, p1.y);
      grad.addColorStop(0, color);
      grad.addColorStop(1, c2);
      ctx.strokeStyle = grad;
      return;
    }
    if (mode === "light") {
      const { r, g, b } = hexToRgb(color);
      ctx.strokeStyle = `rgba(${r},${g},${b},${op * 0.6})`;
      ctx.shadowColor = `rgba(${r},${g},${b},0.8)`;
      ctx.shadowBlur = stroke.size * 2;
      return;
    }
    if (mode === "shadow") {
      const { r, g, b } = hexToRgb(color);
      ctx.strokeStyle = `rgba(${Math.floor(r * 0.3)},${Math.floor(g * 0.3)},${Math.floor(b * 0.3)},${op})`;
      return;
    }
    ctx.strokeStyle = color;
  };

  const drawStroke = (ctx, stroke) => {
    ctx.save();
    if (stroke.tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.globalAlpha = 1;
      ctx.strokeStyle = "rgba(0,0,0,1)";
    } else {
      ctx.globalCompositeOperation = "source-over";
      buildStrokeStyle(ctx, stroke);
    }
    ctx.lineWidth = stroke.size;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.shadowBlur = 0;

    // For light mode set glow
    if (stroke.brushMode === "light" && stroke.tool !== "eraser") {
      ctx.shadowColor = stroke.color;
      ctx.shadowBlur = stroke.size * 1.5;
    }

    ctx.beginPath();
    stroke.points.forEach((pt, i) => {
      if (i === 0) ctx.moveTo(pt.x, pt.y); else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();
    ctx.restore();

    // Anti-overflow
    if (stroke.tool !== "eraser") applyMask(ctx);
  };

  const floodFill = (ctx, startX, startY, fillColor) => {
    // Check outline
    if (overlayRef.current) {
      const ovCtx = overlayRef.current.getContext("2d");
      const px = ovCtx.getImageData(startX, startY, 1, 1).data;
      if ((px[0] + px[1] + px[2]) / 3 < 80) return;
    }

    const canvas = ctx.canvas;
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;
    const idx = (startY * canvas.width + startX) * 4;
    const targetR = data[idx], targetG = data[idx + 1], targetB = data[idx + 2], targetA = data[idx + 3];

    const { r, g, b } = hexToRgb(fillColor);
    if (targetR === r && targetG === g && targetB === b) return;

    const ovCtx = overlayRef.current?.getContext("2d");
    const ovData = ovCtx ? ovCtx.getImageData(0, 0, canvas.width, canvas.height).data : null;

    const matches = (i) =>
      Math.abs(data[i] - targetR) < 40 &&
      Math.abs(data[i + 1] - targetG) < 40 &&
      Math.abs(data[i + 2] - targetB) < 40 &&
      Math.abs(data[i + 3] - targetA) < 40;

    const isOutline = (x, y) => {
      if (!ovData) return false;
      const i = (y * canvas.width + x) * 4;
      return (ovData[i] + ovData[i + 1] + ovData[i + 2]) / 3 < 80;
    };

    const stack = [[startX, startY]];
    const visited = new Uint8Array(canvas.width * canvas.height);

    while (stack.length) {
      const [x, y] = stack.pop();
      if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height) continue;
      const vi = y * canvas.width + x;
      if (visited[vi]) continue;
      visited[vi] = 1;
      if (isOutline(x, y)) continue;
      const i = vi * 4;
      if (!matches(i)) continue;
      data[i] = r; data[i + 1] = g; data[i + 2] = b; data[i + 3] = 255;
      stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
    }
    ctx.putImageData(imgData, 0, 0);
  };

  const replayAllStrokes = (ctx, strokesToReplay) => {
    strokesToReplay.forEach((stroke) => {
      if (stroke.type === "fill") floodFill(ctx, stroke.x, stroke.y, stroke.color);
      else drawStroke(ctx, stroke);
    });
  };

  const getPos = (e, canvas) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: Math.round((clientX - rect.left) * scaleX),
      y: Math.round((clientY - rect.top) * scaleY),
    };
  };

  // ─── Pointer handlers ──────────────────────────────────────────────

  const onPointerDown = useCallback((e) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const pos = getPos(e, canvas);

    if (tool === "fill") {
      setHistory((h) => [...h.slice(-9), ctx.getImageData(0, 0, canvas.width, canvas.height)]);
      floodFill(ctx, pos.x, pos.y, color);
      setStrokes((s) => [...s, { type: "fill", x: pos.x, y: pos.y, color }]);
      return;
    }

    setHistory((h) => [...h.slice(-9), ctx.getImageData(0, 0, canvas.width, canvas.height)]);
    currentStrokeRef.current = { tool, brushMode, color, color2, size: brushSize, opacity, points: [pos] };
    setDrawing(true);

    ctx.save();
    if (tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.globalAlpha = 1;
      ctx.strokeStyle = "rgba(0,0,0,1)";
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.globalAlpha = opacity;
      ctx.strokeStyle = color;
      if (brushMode === "light") {
        ctx.shadowColor = color;
        ctx.shadowBlur = brushSize * 1.5;
      }
    }
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    ctx.restore();
  }, [tool, brushMode, color, color2, brushSize, opacity]);

  const onPointerMove = useCallback((e) => {
    if (!drawing || tool === "fill") return;
    e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const pos = getPos(e, canvas);

    ctx.save();
    if (tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.globalAlpha = 1;
      ctx.strokeStyle = "rgba(0,0,0,1)";
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.globalAlpha = opacity;
      ctx.strokeStyle = color;
      if (brushMode === "light") {
        ctx.shadowColor = color;
        ctx.shadowBlur = brushSize * 1.5;
      }
    }
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (currentStrokeRef.current?.points?.length > 0) {
      const last = currentStrokeRef.current.points[currentStrokeRef.current.points.length - 1];
      ctx.beginPath();
      ctx.moveTo(last.x, last.y);
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    }
    ctx.restore();

    if (currentStrokeRef.current) currentStrokeRef.current.points.push(pos);
  }, [drawing, tool, brushMode, color, brushSize, opacity]);

  const onPointerUp = useCallback(() => {
    if (!drawing) return;
    if (tool !== "eraser") applyMask(canvasRef.current.getContext("2d"));
    setDrawing(false);
    if (currentStrokeRef.current) {
      // For gradient, do a clean redraw of just this stroke
      if (brushMode === "gradient" && currentStrokeRef.current.points.length >= 2) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext("2d");
        const stroke = currentStrokeRef.current;
        const p0 = stroke.points[0], p1 = stroke.points[stroke.points.length - 1];
        ctx.save();
        ctx.globalAlpha = opacity;
        const grad = ctx.createLinearGradient(p0.x, p0.y, p1.x, p1.y);
        grad.addColorStop(0, color);
        grad.addColorStop(1, color2);
        ctx.strokeStyle = grad;
        ctx.lineWidth = brushSize;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.beginPath();
        stroke.points.forEach((pt, i) => { if (i === 0) ctx.moveTo(pt.x, pt.y); else ctx.lineTo(pt.x, pt.y); });
        ctx.stroke();
        ctx.restore();
        applyMask(ctx);
      }
      setStrokes((s) => [...s, currentStrokeRef.current]);
      currentStrokeRef.current = null;
    }
  }, [drawing, tool, brushMode, color, color2, brushSize, opacity]);

  const undo = () => {
    if (history.length === 0) return;
    canvasRef.current.getContext("2d").putImageData(history[history.length - 1], 0, 0);
    setHistory((h) => h.slice(0, -1));
    setStrokes((s) => s.slice(0, -1));
  };

  // ─── Live Motion ───────────────────────────────────────────────────
  const liveMotionReplay = () => {
    const allStrokes = strokesRef.current;
    if (allStrokes.length === 0) return;
    if (rafRef.current) cancelAnimationFrame(rafRef.current);

    setPlaying(true);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let i = 0;
    const msPerStroke = Math.max(20, 4000 / allStrokes.length);
    let lastTime = null;

    const step = (timestamp) => {
      if (!lastTime) lastTime = timestamp;
      const elapsed = timestamp - lastTime;

      if (elapsed >= msPerStroke) {
        lastTime = timestamp;
        if (i >= allStrokes.length) {
          setPlaying(false);
          return;
        }
        const stroke = allStrokes[i];
        if (stroke) {
          if (stroke.type === "fill") floodFill(ctx, stroke.x, stroke.y, stroke.color);
          else drawStroke(ctx, stroke);
        }
        i++;
      }
      rafRef.current = requestAnimationFrame(step);
    };

    rafRef.current = requestAnimationFrame(step);
  };

  // cleanup RAF on unmount
  useEffect(() => () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); }, []);

  // ─── Save / Export ─────────────────────────────────────────────────

  const compositeExport = () => {
    // Merge color layer + line art for export
    const offscreen = document.createElement("canvas");
    offscreen.width = 800; offscreen.height = 800;
    const ctx = offscreen.getContext("2d");
    ctx.drawImage(canvasRef.current, 0, 0);
    ctx.drawImage(overlayRef.current, 0, 0);
    return offscreen;
  };

  const save = async () => {
    setSaving(true);
    const composite = compositeExport();
    const blob = await new Promise((resolve) => composite.toBlob(resolve, "image/png"));
    const uploadRes = await base44.integrations.Core.UploadFile({ file: blob });
    const updated = await base44.entities.ColoringProject.update(project.id, {
      colored_snapshot_url: uploadRes.file_url,
      canvas_strokes: strokesRef.current,
      status: "colored",
    });
    setSaving(false);
    onSave(updated);
  };

  const downloadPNG = () => {
    const composite = compositeExport();
    const link = document.createElement("a");
    link.download = `${project.title}-coloria.png`;
    link.href = composite.toDataURL("image/png");
    link.click();
  };

  // ─── Render ────────────────────────────────────────────────────────

  return (
    <div className="fixed inset-0 bg-[#111] text-white flex flex-col z-50">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-black flex-shrink-0">
        <button onClick={onBack} className="flex items-center gap-2 text-white/40 hover:text-white text-xs tracking-widest uppercase transition-colors">
          <ArrowLeft className="w-3 h-3" /> Retour
        </button>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.5rem" }} className="text-amber-400">
          COLORIA — {project.title}
        </h1>
        <div className="flex items-center gap-2">
          <button onClick={liveMotionReplay} disabled={playing || strokes.length === 0}
            className="flex items-center gap-2 border border-amber-500/50 text-amber-400 px-3 py-2 text-xs tracking-widest uppercase hover:bg-amber-500/10 transition-colors disabled:opacity-40 rounded-full">
            <Play className="w-3 h-3" /> {playing ? "En cours..." : "Live Motion"}
          </button>
          <button onClick={downloadPNG}
            className="flex items-center gap-2 border border-white/20 text-white/60 px-3 py-2 text-xs tracking-widest uppercase hover:text-white transition-colors rounded-full">
            <Download className="w-3 h-3" /> PNG
          </button>
          <button onClick={save} disabled={saving}
            className="bg-amber-500 text-black px-4 py-2 text-xs tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-50 flex items-center gap-2 rounded-full">
            {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : null} Sauvegarder
          </button>
        </div>
      </div>

      {/* Workspace */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left toolbar */}
        <div className="w-14 bg-black border-r border-white/10 flex flex-col items-center py-4 gap-3 flex-shrink-0">
          {TOOLS.map(({ key, Icon, label }) => (
            <button key={key} onClick={() => setTool(key)} title={label}
              className={`w-10 h-10 flex items-center justify-center transition-colors ${tool === key ? "bg-amber-500 text-black" : "text-white/40 hover:text-white hover:bg-white/10"}`}>
              <Icon className="w-4 h-4" />
            </button>
          ))}
          <div className="w-8 h-px bg-white/10 my-1" />
          <button onClick={undo} title="Annuler" disabled={history.length === 0}
            className="w-10 h-10 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-colors disabled:opacity-20">
            <Undo2 className="w-4 h-4" />
          </button>
        </div>

        {/* Canvas */}
        <div className="flex-1 flex items-center justify-center bg-[#1a1a1a] overflow-hidden p-4">
          <div className="relative shadow-2xl" style={{ width: "min(800px, calc(100vw - 240px))", height: "min(800px, calc(100vh - 80px))" }}>
            <canvas ref={maskRef} width={800} height={800} className="hidden" />
            {/* Color layer (bottom) */}
            <canvas ref={canvasRef} width={800} height={800}
              className="absolute inset-0"
              style={{ width: "100%", height: "100%", touchAction: "none", cursor: "crosshair", background: "#fff" }}
              onMouseDown={onPointerDown} onMouseMove={onPointerMove}
              onMouseUp={onPointerUp} onMouseLeave={onPointerUp}
              onTouchStart={onPointerDown} onTouchMove={onPointerMove} onTouchEnd={onPointerUp} />
            {/* Line art on top (pointer-events none) */}
            <canvas ref={overlayRef} width={800} height={800}
              className="absolute inset-0 pointer-events-none"
              style={{ width: "100%", height: "100%" }} />
          </div>
        </div>

        {/* Right panel */}
        <div className="w-56 bg-black border-l border-white/10 flex flex-col p-4 gap-4 flex-shrink-0 overflow-y-auto">
          {/* Brush mode */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-2 flex items-center gap-1">
              <Layers className="w-3 h-3" /> Mode
            </p>
            <div className="grid grid-cols-2 gap-1">
              {BRUSH_MODES.map((m) => (
                <button key={m.key} onClick={() => setBrushMode(m.key)}
                  className={`py-1.5 text-xs tracking-wider uppercase transition-colors rounded-full ${brushMode === m.key ? "bg-amber-500 text-black" : "border border-white/10 text-white/40 hover:text-white"}`}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Brush size */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-2">Taille — {brushSize}px</p>
            <input type="range" min={2} max={60} value={brushSize}
              onChange={(e) => setBrushSize(Number(e.target.value))}
              className="w-full accent-amber-500" />
          </div>

          {/* Opacity */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-2">Opacité — {Math.round(opacity * 100)}%</p>
            <input type="range" min={5} max={100} value={Math.round(opacity * 100)}
              onChange={(e) => setOpacity(Number(e.target.value) / 100)}
              className="w-full accent-amber-500" />
          </div>

          {/* Colors */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-2 flex items-center gap-1">
              <Palette className="w-3 h-3" /> Couleur
            </p>
            <div className="flex gap-2 mb-2">
              <div className="flex-1">
                <p className="text-white/30 text-xs mb-1">A</p>
                <div className="h-8 border border-white/20 rounded mb-1" style={{ background: color }} />
                <input type="color" value={color} onChange={(e) => setColor(e.target.value)}
                  className="w-full h-6 cursor-pointer bg-transparent border-0" />
              </div>
              {(brushMode === "gradient") && (
                <div className="flex-1">
                  <p className="text-white/30 text-xs mb-1">B</p>
                  <div className="h-8 border border-white/20 rounded mb-1" style={{ background: color2 }} />
                  <input type="color" value={color2} onChange={(e) => setColor2(e.target.value)}
                    className="w-full h-6 cursor-pointer bg-transparent border-0" />
                </div>
              )}
            </div>
            {brushMode === "gradient" && (
              <div className="h-4 rounded w-full mb-2"
                style={{ background: `linear-gradient(to right, ${color}, ${color2})` }} />
            )}
          </div>

          {/* AI Palette */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-2 flex items-center gap-1">
              <Wand2 className="w-3 h-3" /> {loadingPalette ? "Génération..." : "Palette IA"}
            </p>
            {loadingPalette ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-5 gap-1">
                {palette.map((c, i) => (
                  <button key={i} onClick={() => setColor(c)}
                    style={{ background: c }} title={c}
                    className={`w-9 h-9 rounded-sm border-2 transition-all ${color === c ? "border-amber-400 scale-110 shadow-lg shadow-amber-500/20" : "border-transparent hover:border-white/40"}`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}