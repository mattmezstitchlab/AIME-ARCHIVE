import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Sparkles, Loader2, RefreshCw } from "lucide-react";

const STYLES = [
  { key: "classique", label: "Classique" },
  { key: "kawaii", label: "Kawaii" },
  { key: "conte", label: "Conte" },
  { key: "mandala", label: "Mandala" },
  { key: "bd", label: "BD enfant" },
  { key: "nature", label: "Nature" },
];

const AGES = [
  { key: "3-5", label: "3–5 ans" },
  { key: "6-8", label: "6–8 ans" },
  { key: "9-12", label: "9–12 ans" },
  { key: "adulte", label: "Adulte" },
];

export default function ColoriaGenerator({ stories, initialStory, onBack, onCreated }) {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("classique");
  const [age, setAge] = useState("6-8");
  const [scenes, setScenes] = useState([]);
  const [selectedScene, setSelectedScene] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (initialStory?.scene_breakdown?.length) {
      setScenes(initialStory.scene_breakdown);
    }
  }, [initialStory]);

  const buildPrompt = () => {
    const base = selectedScene?.scene_text || prompt;
    const styleMap = {
      classique: "classic children's coloring book style",
      kawaii: "kawaii cute style",
      conte: "fairy tale illustration style",
      mandala: "simple mandala pattern style",
      bd: "comic book children style",
      nature: "nature botanical style",
    };
    return `${base}. Style: ${styleMap[style]}. Black and white only, thick clean outlines, NO color, NO shading, NO gray tones, white background, closed shapes easy to fill, like a professional children's coloring book page. Simple clear composition, joyful, no text in image, no complex details.`;
  };

  const generate = async () => {
    if (!prompt && !selectedScene) return;
    setGenerating(true);
    setGeneratedUrl(null);
    const result = await base44.integrations.Core.GenerateImage({ prompt: buildPrompt() });
    setGeneratedUrl(result.url);
    setGenerating(false);
  };

  const save = async () => {
    setSaving(true);
    const title = selectedScene?.chapter_title || prompt.slice(0, 50) || "Mon coloriage";
    const project = await base44.entities.ColoringProject.create({
      title,
      prompt: selectedScene?.scene_text || prompt,
      line_art_url: generatedUrl,
      story_project_id: initialStory?.id || null,
      story_scene_id: selectedScene?.id || null,
      style,
      age_level: age,
      status: "ready",
      canvas_strokes: [],
    });
    setSaving(false);
    onCreated(project);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <section className="max-w-3xl mx-auto px-6 pt-32 pb-20">
        <button onClick={onBack} className="flex items-center gap-2 text-white/40 hover:text-white text-xs tracking-widest uppercase mb-10 transition-colors">
          <ArrowLeft className="w-3 h-3" /> Retour
        </button>

        <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Nouveau coloriage</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)", lineHeight: 1 }}>
          Génère ton illustration
        </h1>

        <div className="mt-10 space-y-8">
          {/* Scene picker from story */}
          {initialStory && scenes.length > 0 && (
            <div>
              <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">
                Scène du conte — {initialStory.title}
              </label>
              <div className="space-y-2">
                {scenes.map((sc, i) => (
                  <button
                    key={i}
                    onClick={() => { setSelectedScene(sc); setPrompt(sc.scene_text?.slice(0, 150) || ""); }}
                    className={`w-full text-left p-4 border transition-colors text-sm ${selectedScene === sc ? "border-amber-500 bg-amber-500/10" : "border-white/10 hover:border-white/30"}`}
                  >
                    <p className="text-amber-400 text-xs tracking-widest uppercase mb-1">{sc.chapter_title || `Scène ${i + 1}`}</p>
                    <p className="text-white/70 line-clamp-2">{sc.scene_text}</p>
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-4 my-6">
                <div className="flex-1 h-px bg-white/10" />
                <span className="text-white/30 text-xs">ou</span>
                <div className="flex-1 h-px bg-white/10" />
              </div>
            </div>
          )}

          {/* Custom prompt */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">
              Décris ce que tu veux colorier
            </label>
            <textarea
              value={prompt}
              onChange={(e) => { setPrompt(e.target.value); setSelectedScene(null); }}
              placeholder={initialStory ? "Ou écris ta propre scène..." : "Ex : un dragon qui garde un trésor dans une caverne dorée..."}
              rows={3}
              className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-amber-500 resize-none"
            />
          </div>

          {/* Style */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Style</label>
            <div className="flex flex-wrap gap-2">
              {STYLES.map((s) => (
                <button key={s.key} onClick={() => setStyle(s.key)}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${style === s.key ? "bg-amber-500 text-black" : "border border-white/20 text-white/60 hover:text-white"}`}>
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Age */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Âge</label>
            <div className="flex flex-wrap gap-2">
              {AGES.map((a) => (
                <button key={a.key} onClick={() => setAge(a.key)}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${age === a.key ? "bg-amber-500 text-black" : "border border-white/20 text-white/60 hover:text-white"}`}>
                  {a.label}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generate}
            disabled={generating || (!prompt && !selectedScene)}
            className="w-full bg-amber-500 text-black py-4 text-sm font-medium tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-30 flex items-center justify-center gap-2 rounded-full"
          >
            {generating ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération...</> : <><Sparkles className="w-4 h-4" /> Générer le coloriage</>}
          </button>
        </div>

        {/* Generated result */}
        {generatedUrl && (
          <div className="mt-12">
            <p className="text-amber-400 text-xs tracking-widest uppercase mb-4">Ton coloriage est prêt !</p>
            <div className="bg-white p-4 border border-white/10">
              <img src={generatedUrl} alt="Coloriage généré" className="w-full max-h-96 object-contain" />
            </div>
            <div className="flex gap-4 mt-6">
              <button
                onClick={save}
                disabled={saving}
                className="flex-1 bg-amber-500 text-black py-3 text-sm font-medium tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-50 flex items-center justify-center gap-2 rounded-full"
              >
                {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Enregistrement...</> : "Colorier ce dessin →"}
              </button>
              <button
                onClick={generate}
                disabled={generating}
                className="border border-white/20 text-white px-6 py-3 text-xs tracking-widest uppercase hover:border-white/60 transition-colors flex items-center gap-2 rounded-full"
              >
                <RefreshCw className="w-3 h-3" /> Régénérer
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}