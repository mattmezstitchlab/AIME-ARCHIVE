import { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Mic, Square, Loader2, ChevronRight, X } from "lucide-react";

// Standalone hero experience: record voice → generate mini-tale + cover → signup CTA
export default function HeroVoiceExperience({ onClose }) {
  const [phase, setPhase] = useState("idle"); // idle | recording | generating | result
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [story, setStory] = useState(null); // { title, tagline, text, imageUrl }
  const [error, setError] = useState(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);

  const startRecording = async () => {
    setError(null);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];
    recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      setAudioBlob(blob);
      stream.getTracks().forEach((t) => t.stop());
    };
    recorder.start();
    recorderRef.current = recorder;
    setRecording(true);
    setPhase("recording");
  };

  const stopAndGenerate = async () => {
    recorderRef.current?.stop();
    setRecording(false);
    setPhase("generating");
    // Generate mini-tale via LLM
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: "Génère un micro-conte poétique en français pour enfants (4-6 ans), environ 80 mots, avec un titre évocateur et une phrase d'accroche. Retourne un JSON avec: title (string), tagline (string), text (string), image_prompt (string décrivant une illustration de couverture cinématographique, style aquarelle douce, personnages enfantins).",
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          tagline: { type: "string" },
          text: { type: "string" },
          image_prompt: { type: "string" },
        },
      },
    });

    // Generate cover illustration
    let imageUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80";
    if (result.image_prompt) {
      const imgRes = await base44.integrations.Core.GenerateImage({
        prompt: result.image_prompt + ", illustration couverture de livre pour enfants, style aquarelle, tons chauds, magie et douceur",
      });
      if (imgRes?.url) imageUrl = imgRes.url;
    }

    setStory({ title: result.title, tagline: result.tagline, text: result.text, imageUrl });
    setPhase("result");
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center px-6">
      <div className="relative w-full max-w-lg">
        {onClose && (
          <button onClick={onClose} className="absolute -top-12 right-0 text-white/40 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        )}

        {/* IDLE */}
        {phase === "idle" && (
          <div className="text-center">
            <div className="w-24 h-24 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto mb-8">
            <Mic className="w-10 h-10 text-red-500" />
            </div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 7vw, 4rem)", lineHeight: 1 }} className="text-white mb-4">
              Parlez.<br />Un conte naît.
            </h2>
            <p className="text-white/50 mb-8 leading-relaxed">
              Enregistrez quelques secondes de votre voix. L'IA génère un conte illustré pour vous — instantanément.
            </p>
            <button onClick={startRecording}
              className="bg-red-600 text-white px-10 py-4 text-sm font-medium tracking-widest uppercase hover:bg-red-500 transition-colors rounded-full flex items-center gap-3 mx-auto">
              <Mic className="w-4 h-4" /> Commencer l'expérience
            </button>
            <p className="text-white/20 text-xs mt-4">Aucun compte requis pour essayer</p>
          </div>
        )}

        {/* RECORDING */}
        {phase === "recording" && (
          <div className="text-center">
            <p className="text-red-500 tracking-widest uppercase text-xs mb-8">Enregistrement en cours</p>
            <div className="w-32 h-32 rounded-full bg-red-500/10 border-2 border-red-500/40 flex items-center justify-center mx-auto mb-8 animate-pulse">
              <Mic className="w-12 h-12 text-red-400" />
            </div>
            <p className="text-white/70 italic mb-4 text-sm leading-relaxed max-w-sm mx-auto">
              « Il était une fois, dans un village au bord de la forêt, une petite lumière… »
            </p>
            <p className="text-white/30 text-xs mb-10">Lisez ce texte ou parlez librement</p>
            <button onClick={stopAndGenerate}
              className="bg-white text-black px-10 py-4 text-sm font-medium tracking-widest uppercase hover:bg-white/90 transition-colors rounded-full flex items-center gap-3 mx-auto">
              <Square className="w-4 h-4" /> Arrêter et générer mon conte
            </button>
          </div>
        )}

        {/* GENERATING */}
        {phase === "generating" && (
          <div className="text-center">
            <div className="w-24 h-24 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-8">
            <Loader2 className="w-10 h-10 text-red-500 animate-spin" />
            </div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="text-white mb-3">Votre conte naît…</h2>
            <p className="text-white/40 text-sm">L'IA rédige l'histoire et génère l'illustration de couverture.</p>
          </div>
        )}

        {/* RESULT */}
        {phase === "result" && story && (
          <div>
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden mb-6">
              <img src={story.imageUrl} alt={story.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <p className="text-red-500 text-xs tracking-widest uppercase mb-1">Votre conte</p>
                <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(1.8rem, 5vw, 2.5rem)", lineHeight: 1 }} className="text-white">
                  {story.title}
                </h2>
              </div>
            </div>

            <p className="text-white/60 italic text-sm mb-4 leading-relaxed">« {story.tagline} »</p>
            <p className="text-white/80 text-sm leading-relaxed mb-8">{story.text}</p>

            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-5 mb-6">
              <p className="text-red-500 text-xs tracking-widest uppercase mb-2">Créez votre compte pour :</p>
              <ul className="text-white/70 text-sm space-y-1.5">
                <li>✦ Sauvegarder et écouter ce conte avec votre voix clonée</li>
                <li>✦ Générer des illustrations pour chaque scène</li>
                <li>✦ Partager votre bibliothèque de contes</li>
              </ul>
            </div>

            <div className="flex gap-3">
              <Link to="/register"
                className="flex-1 bg-red-600 text-white py-3.5 text-sm font-medium tracking-widest uppercase hover:bg-red-500 transition-colors rounded-full flex items-center justify-center gap-2">
                Créer mon compte gratuit
              </Link>
              <button onClick={() => { setPhase("idle"); setStory(null); setAudioBlob(null); }}
                className="border border-white/20 text-white/60 px-5 py-3.5 text-xs tracking-widest uppercase hover:border-white/60 hover:text-white transition-colors rounded-full">
                Réessayer
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}