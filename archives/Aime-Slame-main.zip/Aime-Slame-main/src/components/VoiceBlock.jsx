import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { elevenLabsCloneVoice } from "@/functions/elevenLabsCloneVoice";
import { elevenLabsManageVoices } from "@/functions/elevenLabsManageVoices";
import { Mic, Square, Check, ChevronRight, Loader2, Plus, Trash2, AlertTriangle } from "lucide-react";

// Reusable voice recording + cloning block
// Props:
//   voiceProfiles: array of existing profiles
//   onNewVoice: (newProfile) => void
//   compact: bool — compact display mode

export default function VoiceBlock({ voiceProfiles = [], onNewVoice, compact = false }) {
  const [step, setStep] = useState(0); // 0=idle, 1=consent, 2=record, 3=listen, 4=config, 5=saving, 6=limitReached, 7=done
  const [consent, setConsent] = useState(false);
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [voiceName, setVoiceName] = useState("");
  const [saving, setSaving] = useState(false);
  const [pendingSampleUrl, setPendingSampleUrl] = useState(null);
  const [elVoices, setElVoices] = useState([]);
  const [loadingElVoices, setLoadingElVoices] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];
    recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      setAudioBlob(blob);
      setAudioUrl(URL.createObjectURL(blob));
      stream.getTracks().forEach((t) => t.stop());
      setStep(3);
    };
    recorder.start();
    recorderRef.current = recorder;
    setRecording(true);
  };

  const stopRecording = () => {
    recorderRef.current?.stop();
    setRecording(false);
  };

  const attemptClone = async (sampleUrl, name) => {
    try {
      const cloneRes = await elevenLabsCloneVoice({ audio_url: sampleUrl, voice_name: name || "Ma voix SLAÂME" });
      if (cloneRes.data?.voice_id) return { voice_id: cloneRes.data.voice_id };
      const errMsg = cloneRes.data?.error || "";
      if (errMsg.includes("voice_limit_reached") || errMsg.includes("maximum amount")) {
        return { limitReached: true };
      }
      return { failed: true, error: errMsg };
    } catch (e) {
      // Axios throws on 4xx/5xx — extract the error message from the response
      const errMsg = e.response?.data?.error || e.message || "";
      if (errMsg.includes("voice_limit_reached") || errMsg.includes("maximum amount")) {
        return { limitReached: true };
      }
      return { failed: true, error: errMsg };
    }
  };

  const saveVoice = async () => {
    setSaving(true);
    let sampleUrl = null;

    if (audioBlob) {
      const audioFile = new File([audioBlob], "voice-sample.webm", { type: "audio/webm" });
      const uploadRes = await base44.integrations.Core.UploadFile({ file: audioFile });
      sampleUrl = uploadRes.file_url;
    }

    const result = await attemptClone(sampleUrl, voiceName);
    setSaving(false);

    if (result.limitReached) {
      // Store sample URL for retry after freeing space
      setPendingSampleUrl(sampleUrl);
      setLoadingElVoices(true);
      setStep(6);
      const res = await elevenLabsManageVoices({ action: "list" });
      setElVoices(res.data?.voices || []);
      setLoadingElVoices(false);
      return;
    }

    // Save profile (with or without voice_id)
    const newVoice = await base44.entities.VoiceProfile.create({
      display_name: voiceName || "Ma voix",
      consent_accepted: true,
      voice_status: result.voice_id ? "ready" : "recording",
      audio_sample_url: sampleUrl,
      voice_model_id: result.voice_id || null,
      visibility: "private",
    });
    setStep(7);
    onNewVoice?.(newVoice);
  };

  const deleteElVoiceAndRetry = async (elVoiceId) => {
    setDeletingId(elVoiceId);
    await elevenLabsManageVoices({ action: "delete", voice_id: elVoiceId });
    setDeletingId(null);

    // Retry cloning
    setSaving(true);
    const result = await attemptClone(pendingSampleUrl, voiceName);
    setSaving(false);

    const newVoice = await base44.entities.VoiceProfile.create({
      display_name: voiceName || "Ma voix",
      consent_accepted: true,
      voice_status: result.voice_id ? "ready" : "recording",
      audio_sample_url: pendingSampleUrl,
      voice_model_id: result.voice_id || null,
      visibility: "private",
    });
    setStep(7);
    onNewVoice?.(newVoice);
  };

  const hasVoices = voiceProfiles.length > 0;

  return (
    <div>
      {/* Existing voices */}
      {hasVoices && step === 0 && (
        <div className="space-y-3 mb-6">
          {voiceProfiles.map((v) => (
            <div key={v.id} className="flex items-center gap-4 p-4 bg-white/5 rounded-xl">
              <div className="w-9 h-9 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                <Mic className="w-4 h-4 text-red-500" />
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-medium">{v.display_name}</p>
                <p className="text-white/30 text-xs mt-0.5">{v.voice_status === "ready" ? "✓ Clonée et prête" : "En traitement"}</p>
              </div>
              {v.audio_sample_url && <audio src={v.audio_sample_url} controls className="h-8" />}
            </div>
          ))}
          <button onClick={() => setStep(1)} className="flex items-center gap-2 text-xs tracking-widest uppercase text-white/40 hover:text-red-500 transition-colors mt-1">
            <Plus className="w-3.5 h-3.5" /> Ajouter une voix
          </button>
        </div>
      )}

      {/* Empty state */}
      {!hasVoices && step === 0 && (
        <div className={compact ? "flex items-center gap-4" : "text-center py-8"}>
          {!compact && (
            <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-5">
              <Mic className="w-7 h-7 text-red-500" />
            </div>
          )}
          <div className={compact ? "flex-1" : ""}>
            {!compact && (
              <>
                <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }}>Votre voix, vos contes</h3>
                <p className="text-white/40 text-sm mt-2 mb-6 max-w-sm mx-auto">Enregistrez votre voix une seule fois. L'IA la clone pour narrer tous vos projets.</p>
              </>
            )}
            {compact && <p className="text-white/50 text-sm mb-3">Aucune voix enregistrée — l'IA utilisera une voix par défaut.</p>}
            <button
              onClick={() => setStep(1)}
              className={compact
                ? "text-xs tracking-widest uppercase text-red-500 hover:text-red-400 transition-colors flex items-center gap-1"
                : "bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors rounded-full"
              }
            >
              <Mic className={compact ? "w-3 h-3 mr-1" : "hidden"} />
              Enregistrer ma voix
            </button>
          </div>
        </div>
      )}

      {/* Steps 1-5 */}
      {step >= 1 && step <= 5 && (
        <div className="max-w-lg">
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={`h-0.5 flex-1 transition-all ${i <= step ? "bg-red-600" : "bg-white/10"}`} />
            ))}
          </div>

          {step === 1 && (
            <div>
              <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.6rem" }}>Consentement</h3>
              <p className="text-white/60 mt-3 text-sm leading-relaxed">En enregistrant votre voix, vous acceptez qu'elle soit utilisée pour générer des narrations audio personnalisées. Elle ne sera jamais partagée avec des tiers.</p>
              <label className="flex items-start gap-3 mt-5 cursor-pointer">
                <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1" />
                <span className="text-white/80 text-sm">J'accepte les conditions d'utilisation de ma voix.</span>
              </label>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(0)} className="border border-white/20 text-white/60 px-5 py-2.5 text-xs tracking-widest uppercase rounded-full hover:border-white/40 transition-colors">Annuler</button>
                <button onClick={() => setStep(2)} disabled={!consent}
                  className="bg-red-600 text-white px-7 py-2.5 text-xs font-medium tracking-widest uppercase hover:bg-red-500 transition-colors disabled:opacity-30 rounded-full flex items-center gap-2">
                  Continuer <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="text-center">
              <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.6rem" }}>Enregistrement</h3>
              <p className="text-white/60 mt-3 mb-6 text-sm">Lisez ce texte à voix haute :</p>
              <blockquote className="border-l-2 border-red-500 pl-4 text-white/70 italic text-left mb-8 text-sm">
                "Il était une fois, dans un village au bord de la forêt, une petite lumière qui dansait entre les arbres. Les enfants l'appelaient Luciole, et chaque soir, elle venait leur chuchoter des histoires venues de loin."
              </blockquote>
              <div className="flex justify-center">
                {!recording
                  ? <button onClick={startRecording} className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center hover:bg-red-500 transition-colors"><Mic className="w-7 h-7 text-black" /></button>
                  : <button onClick={stopRecording} className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center hover:bg-red-400 transition-colors animate-pulse"><Square className="w-7 h-7 text-white" /></button>
                }
              </div>
              <p className="text-white/40 text-xs mt-4">{recording ? "Enregistrement en cours…" : "Appuyez pour commencer"}</p>
            </div>
          )}

          {step === 3 && (
            <div>
              <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.6rem" }}>Écoute</h3>
              <p className="text-white/60 mt-3 mb-6 text-sm">Écoutez et validez votre enregistrement.</p>
              {audioUrl && <audio src={audioUrl} controls className="w-full mb-6" />}
              <div className="flex gap-3">
                <button onClick={() => { setAudioBlob(null); setAudioUrl(null); setStep(2); }} className="border border-white/20 text-white px-5 py-2.5 text-xs tracking-widest uppercase hover:border-white/60 transition-colors rounded-full">Recommencer</button>
                <button onClick={() => setStep(4)} className="bg-red-600 text-white px-7 py-2.5 text-xs font-medium tracking-widest uppercase hover:bg-red-500 transition-colors rounded-full flex items-center gap-2">Valider <ChevronRight className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div>
              <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.6rem" }}>Configuration</h3>
              <div className="mt-6">
                <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Nom de la voix</label>
                <input type="text" value={voiceName} onChange={(e) => setVoiceName(e.target.value)} placeholder="Ex : Voix de Papa"
                  className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500 rounded-lg" />
              </div>
              <button onClick={saveVoice} disabled={saving}
                className="mt-6 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-widest uppercase hover:bg-red-500 transition-colors disabled:opacity-50 rounded-full">
                {saving ? <><Loader2 className="w-4 h-4 animate-spin inline mr-2" />Traitement en cours…</> : "Enregistrer ma voix"}
              </button>
            </div>
          )}

          {step === 5 && (
            <div className="text-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-red-500 mx-auto mb-4" />
              <p className="text-white/60 text-sm">Clonage de votre voix en cours…</p>
            </div>
          )}
        </div>
      )}

      {/* Step 6 — Limit reached: free a slot */}
      {step === 6 && (
        <div className="max-w-lg space-y-5">
          <div className="flex items-start gap-3 bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
            <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white text-sm font-medium">Limite de voix atteinte (10/10)</p>
              <p className="text-white/50 text-xs mt-1">Supprimez une ancienne voix pour libérer une place et cloner la vôtre.</p>
            </div>
          </div>

          {loadingElVoices ? (
            <div className="flex items-center gap-3 text-white/40 text-sm py-4">
              <Loader2 className="w-4 h-4 animate-spin" /> Chargement des voix…
            </div>
          ) : (
            <div className="space-y-2">
              {elVoices.map((v) => (
                <div key={v.voice_id} className="flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-xl">
                  <div>
                    <p className="text-white text-sm">{v.name}</p>
                    {v.description && <p className="text-white/30 text-xs mt-0.5">{v.description}</p>}
                  </div>
                  <button
                    onClick={() => deleteElVoiceAndRetry(v.voice_id)}
                    disabled={!!deletingId || saving}
                    className="flex items-center gap-1.5 text-xs text-red-400 hover:text-red-300 border border-red-500/30 hover:border-red-400/50 px-3 py-1.5 rounded-full transition-colors disabled:opacity-40"
                  >
                    {deletingId === v.voice_id || saving
                      ? <Loader2 className="w-3 h-3 animate-spin" />
                      : <Trash2 className="w-3 h-3" />
                    }
                    {deletingId === v.voice_id ? "Suppression…" : saving ? "Clonage…" : "Supprimer"}
                  </button>
                </div>
              ))}
              {elVoices.length === 0 && (
                <p className="text-white/40 text-sm">Aucune voix clonée trouvée. Contactez le support.</p>
              )}
            </div>
          )}
        </div>
      )}

      {/* Step 7 — Done */}
      {step === 7 && (
        <div className={compact ? "flex items-center gap-4" : "text-center py-6"}>
          <div className={`${compact ? "w-8 h-8" : "w-14 h-14 mx-auto mb-4"} rounded-full bg-red-600 flex items-center justify-center`}>
            <Check className={`${compact ? "w-4 h-4" : "w-7 h-7"} text-black`} />
          </div>
          <div>
            {compact
              ? <p className="text-white text-sm font-medium">Voix enregistrée !</p>
              : <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }}>Voix enregistrée !</span>
            }
            {!compact && <p className="text-white/40 text-sm mt-1 mb-5">Votre profil vocal est prêt.</p>}
            <button onClick={() => setStep(0)} className="text-xs tracking-widest uppercase text-white/40 hover:text-red-500 transition-colors mt-2 block">Voir mes voix</button>
          </div>
        </div>
      )}
    </div>
  );
}