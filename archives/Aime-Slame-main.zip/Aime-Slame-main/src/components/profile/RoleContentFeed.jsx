import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { BookOpen, Palette, Heart, Star, TrendingUp, Users, Sparkles } from "lucide-react";

const ROLE_FEED_CONFIG = {
  conteur: {
    title: "Inspiration Conteur",
    sections: [
      { key: "trending", label: "Tendances", icon: TrendingUp, filter: { visibility: "public" } },
      { key: "community", label: "Communauté", icon: Users, filter: { presence_type: "conteur" } },
      { key: "favorites", label: "Vos favoris", icon: Heart, filter: null },
    ],
  },
  parent: {
    title: "Pour Vos Enfants",
    sections: [
      { key: "age_appropriate", label: "Recommandé par âge", icon: Star, filter: { target_audience: "enfants" } },
      { key: "bedtime", label: "Histoires du soir", icon: BookOpen, filter: { story_type: "histoire_du_soir" } },
      { key: "coloring", label: "À colorier", icon: Palette, filter: null },
    ],
  },
  enseignant: {
    title: "Ressources Pédagogiques",
    sections: [
      { key: "educational", label: "Éducatif", icon: BookOpen, filter: { themes: "educatif" } },
      { key: "class_activities", label: "Activités classe", icon: Users, filter: { target_audience: "enfants" } },
      { key: "popular", label: "Populaire en classe", icon: TrendingUp, filter: null },
    ],
  },
  therapeute: {
    title: "Outils Thérapeutiques",
    sections: [
      { key: "emotional", label: "Gestion émotions", icon: Heart, filter: { themes: "emotions" } },
      { key: "confidence", label: "Confiance en soi", icon: Star, filter: { themes: "confiance" } },
      { key: "calming", label: "Apaisant", icon: Sparkles, filter: { story_type: "berceuse" } },
    ],
  },
  auteur: {
    title: "Découvertes & Tendances",
    sections: [
      { key: "featured", label: "Mis en avant", icon: Star, filter: { visibility: "public" } },
      { key: "new_voices", label: "Nouvelles voix", icon: TrendingUp, filter: null },
      { key: "collaborations", label: "Collaborations", icon: Users, filter: null },
    ],
  },
  grand_parent: {
    title: "Héritage Familial",
    sections: [
      { key: "family", label: "Histoires familiales", icon: Heart, filter: { visibility: "family" } },
      { key: "classics", label: "Classiques", icon: BookOpen, filter: { story_type: "conte" } },
      { key: "shared", label: "Partagés", icon: Users, filter: null },
    ],
  },
  enfant: {
    title: "Tes Histoires",
    sections: [
      { key: "favorites", label: "Favoris", icon: Heart, filter: null },
      { key: "adventure", label: "Aventures", icon: Sparkles, filter: { story_type: "aventure" } },
      { key: "coloring", label: "Coloriages", icon: Palette, filter: null },
    ],
  },
  futur_marie: {
    title: "Inspiration Événement",
    sections: [
      { key: "wedding_stories", label: "Histoires mariage", icon: Heart, filter: { story_type: "recit_familial" } },
      { key: "event_examples", label: "Exemples", icon: BookOpen, filter: null },
      { key: "popular", label: "Populaires", icon: TrendingUp, filter: null },
    ],
  },
};

export default function RoleContentFeed({ profile }) {
  const [activeSection, setActiveSection] = useState("trending");
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(false);

  const config = ROLE_FEED_CONFIG[profile?.profile_type] || ROLE_FEED_CONFIG.parent;
  const currentSection = config.sections.find((s) => s.key === activeSection) || config.sections[0];

  useEffect(() => {
    if (!currentSection?.filter) {
      setContent([]);
      return;
    }

    setLoading(true);
    base44.entities.StoryProject.filter(
      { ...currentSection.filter, status: "published" },
      "-created_date",
      12
    ).then((stories) => {
      setContent(stories);
      setLoading(false);
    });
  }, [activeSection, currentSection]);

  return (
    <div className="border border-white/10 rounded-2xl p-6 mb-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white">
          {config.title}
        </h3>
        <Link to="/collections" className="text-amber-400 text-xs tracking-widest uppercase hover:text-amber-300">
          Voir tout
        </Link>
      </div>

      {/* Section Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-6">
        {config.sections.map((section) => {
          const Icon = section.icon;
          return (
            <button
              key={section.key}
              onClick={() => setActiveSection(section.key)}
              className={`flex items-center gap-2 px-4 py-2 text-xs tracking-widest uppercase whitespace-nowrap transition-colors rounded-full ${
                activeSection === section.key
                  ? "bg-amber-500 text-black"
                  : "border border-white/20 text-white/60 hover:text-white"
              }`}
            >
              <Icon className="w-3 h-3" />
              {section.label}
            </button>
          );
        })}
      </div>

      {/* Content Grid */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : content.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {content.map((story) => (
            <Link
              key={story.id}
              to={`/conte/${story.id}`}
              className="group relative overflow-hidden rounded-xl aspect-[3/4]"
            >
              <img
                src={story.hero_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400&q=80"}
                alt={story.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-3">
                <p className="text-amber-400 text-xs tracking-widest uppercase mb-1 truncate">
                  {story.story_type?.replace(/_/g, " ")}
                </p>
                <h4 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.1rem" }} className="text-white truncate">
                  {story.title}
                </h4>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <BookOpen className="w-12 h-12 text-white/20 mx-auto mb-4" />
          <p className="text-white/40 text-sm">Aucun contenu dans cette section pour le moment.</p>
        </div>
      )}
    </div>
  );
}