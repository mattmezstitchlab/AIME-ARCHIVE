import { useState, useEffect } from "react";
import { Check, TrendingUp, Award, Target, Calendar } from "lucide-react";

const ROLE_GOALS = {
  conteur: {
    title: "Objectifs Conteur",
    milestones: [
      { id: "first_story", label: "Premier conte publié", icon: Target, xp: 100 },
      { id: "five_stories", label: "5 contes créés", icon: TrendingUp, xp: 250 },
      { id: "voice_cloned", label: "Voix clonée", icon: Award, xp: 150 },
      { id: "first_audience", label: "100 écoutes", icon: Calendar, xp: 300 },
      { id: "public_profile", label: "Profil public", icon: Target, xp: 100 },
    ],
  },
  parent: {
    title: "Moments en Famille",
    milestones: [
      { id: "first_bedtime", label: "Première histoire du soir", icon: Target, xp: 50 },
      { id: "ten_stories", label: "10 histoires écoutées", icon: TrendingUp, xp: 200 },
      { id: "first_coloring", label: "Premier coloriage", icon: Award, xp: 100 },
      { id: "favorites", label: "5 favoris", icon: Calendar, xp: 150 },
      { id: "family_share", label: "Partagé en famille", icon: Target, xp: 200 },
    ],
  },
  enseignant: {
    title: "Progression Pédagogique",
    milestones: [
      { id: "first_class_story", label: "Premier conte pour la classe", icon: Target, xp: 150 },
      { id: "five_activities", label: "5 activités créées", icon: TrendingUp, xp: 300 },
      { id: "student_engagement", label: "20 élèves engagés", icon: Award, xp: 400 },
      { id: "resource_shared", label: "Ressource partagée", icon: Calendar, xp: 200 },
      { id: "collection_created", label: "Collection thématique", icon: Target, xp: 250 },
    ],
  },
  therapeute: {
    title: "Accompagnement",
    milestones: [
      { id: "first_session", label: "Première séance", icon: Target, xp: 150 },
      { id: "emotional_stories", label: "5 histoires émotions", icon: TrendingUp, xp: 300 },
      { id: "patient_progress", label: "Suivi patient", icon: Award, xp: 400 },
      { id: "calming_collection", label: "Collection apaisante", icon: Calendar, xp: 250 },
      { id: "specialized", label: "Spécialisation", icon: Target, xp: 350 },
    ],
  },
  auteur: {
    title: "Parcours Auteur",
    milestones: [
      { id: "first_published", label: "Première publication", icon: Target, xp: 200 },
      { id: "portfolio", label: "Portfolio complété", icon: TrendingUp, xp: 300 },
      { id: "hundred_reads", label: "100 lectures", icon: Award, xp: 400 },
      { id: "featured", label: "Mis en avant", icon: Calendar, xp: 500 },
      { id: "collaboration", label: "Collaboration", icon: Target, xp: 350 },
    ],
  },
  grand_parent: {
    title: "Héritage",
    milestones: [
      { id: "first_family_story", label: "Première histoire familiale", icon: Target, xp: 150 },
      { id: "five_memories", label: "5 souvenirs racontés", icon: TrendingUp, xp: 300 },
      { id: "voice_preserved", label: "Voix préservée", icon: Award, xp: 400 },
      { id: "shared_grandkids", label: "Partagé aux petits-enfants", icon: Calendar, xp: 350 },
      { id: "legacy_collection", label: "Collection héritage", icon: Target, xp: 500 },
    ],
  },
  enfant: {
    title: "Tes Aventures",
    milestones: [
      { id: "first_story", label: "Première histoire", icon: Target, xp: 50 },
      { id: "five_favorites", label: "5 favoris", icon: TrendingUp, xp: 100 },
      { id: "first_coloring", label: "Premier coloriage", icon: Award, xp: 150 },
      { id: "ten_stories", label: "10 histoires écoutées", icon: Calendar, xp: 200 },
      { id: "star_reader", label: "Lecteur étoile", icon: Target, xp: 300 },
    ],
  },
  futur_marie: {
    title: "Préparation Événement",
    milestones: [
      { id: "event_created", label: "Événement créé", icon: Target, xp: 200 },
      { id: "story_generated", label: "Histoire générée", icon: TrendingUp, xp: 300 },
      { id: "voice_recorded", label: "Voix enregistrée", icon: Award, xp: 250 },
      { id: "page_shared", label: "Page partagée", icon: Calendar, xp: 300 },
      { id: "cockpit_complete", label: "Cockpit complet", icon: Target, xp: 400 },
    ],
  },
};

export default function RoleGoals({ profile, completedGoals = [] }) {
  const [expanded, setExpanded] = useState(false);
  const config = ROLE_GOALS[profile?.profile_type] || ROLE_GOALS.parent;
  
  const totalXP = completedGoals.reduce((sum, id) => {
    const milestone = config.milestones.find((m) => m.id === id);
    return sum + (milestone?.xp || 0);
  }, 0);

  const completedCount = completedGoals.filter((id) => 
    config.milestones.some((m) => m.id === id)
  ).length;

  const progress = Math.round((completedCount / config.milestones.length) * 100);

  return (
    <div className="border border-white/10 rounded-2xl p-6 mb-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white mb-1">
            {config.title}
          </h3>
          <p className="text-white/40 text-xs tracking-widest uppercase">
            {completedCount}/{config.milestones.length} objectifs • {totalXP} XP
          </p>
        </div>
        <div className="text-right">
          <p className="text-amber-400 text-2xl font-bold">{progress}%</p>
          <p className="text-white/30 text-xs">Complété</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 bg-white/10 rounded-full mb-6 overflow-hidden">
        <div 
          className="h-full bg-amber-500 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Milestones */}
      <div className="space-y-3">
        {config.milestones.slice(0, expanded ? config.milestones.length : 3).map((milestone) => {
          const isCompleted = completedGoals.includes(milestone.id);
          const Icon = milestone.icon;
          
          return (
            <div
              key={milestone.id}
              className={`flex items-center gap-4 p-4 rounded-xl transition-all ${
                isCompleted ? "bg-amber-500/10 border border-amber-500/30" : "bg-white/5 border border-white/10"
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                isCompleted ? "bg-amber-500 text-black" : "bg-white/10 text-white/40"
              }`}>
                {isCompleted ? <Check className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
              </div>
              <div className="flex-1">
                <p className={`text-sm ${isCompleted ? "text-white" : "text-white/60"}`}>
                  {milestone.label}
                </p>
                <p className="text-amber-400 text-xs tracking-widest uppercase mt-0.5">
                  +{milestone.xp} XP
                </p>
              </div>
              {isCompleted && (
                <div className="text-right">
                  <p className="text-amber-400 text-xs tracking-widest uppercase">Complété</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {config.milestones.length > 3 && (
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full mt-4 text-white/40 hover:text-white text-xs tracking-widest uppercase transition-colors"
        >
          {expanded ? "Voir moins" : `Voir ${config.milestones.length - 3} autres objectifs`}
        </button>
      )}
    </div>
  );
}