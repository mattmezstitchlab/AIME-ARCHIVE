import { useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Sparkles, BookOpen, Heart, Star, Users, Palette, Mic } from "lucide-react";

const ROLE_TEMPLATES = {
  conteur: {
    title: "Modèles de Contes",
    subtitle: "Commencez avec une structure éprouvée",
    templates: [
      {
        id: "bedtime_classic",
        title: "Conte du Soir Classique",
        desc: "Structure traditionnelle en 4 scènes",
        icon: BookOpen,
        preset: { story_type: "conte", target_audience: "enfants", themes: ["magie", "aventure"] },
      },
      {
        id: "fable_morale",
        title: "Fable avec Morale",
        desc: "Histoire courte avec enseignement",
        icon: Star,
        preset: { story_type: "fable", target_audience: "famille", themes: ["sagesse"] },
      },
      {
        id: "adventure_journey",
        title: "Aventure Initiatique",
        desc: "Parcours du héros en 6 chapitres",
        icon: Sparkles,
        preset: { story_type: "aventure", target_audience: "ados", themes: ["courage", "decouverte"] },
      },
      {
        id: "slam_poetry",
        title: "Slam Doux",
        desc: "Narration rythmée et poétique",
        icon: Mic,
        preset: { story_type: "slam_doux", target_audience: "adultes", themes: ["emotions"] },
      },
    ],
  },
  parent: {
    title: "Histoires Personnalisées",
    subtitle: "Créez des contes avec vos enfants",
    templates: [
      {
        id: "child_hero",
        title: "Mon Enfant Héros",
        desc: "Votre enfant comme personnage principal",
        icon: Star,
        preset: { story_type: "aventure", target_audience: "enfants", personalize: true },
      },
      {
        id: "bedtime_routine",
        title: "Rituel du Soir",
        desc: "Histoire apaisante pour dormir",
        icon: Heart,
        preset: { story_type: "berceuse", target_audience: "enfants", themes: ["calme"] },
      },
      {
        id: "family_pet",
        title: "L'Histoire de [Animal]",
        desc: "Avec le nom de votre animal",
        icon: Users,
        preset: { story_type: "conte", target_audience: "enfants", personalize: true },
      },
      {
        id: "coloring_story",
        title: "Conte à Colorier",
        desc: "Histoire + pages de coloriage",
        icon: Palette,
        preset: { story_type: "conte", target_audience: "enfants", include_coloring: true },
      },
    ],
  },
  enseignant: {
    title: "Ressources Pédagogiques",
    subtitle: "Outils pour votre classe",
    templates: [
      {
        id: "lesson_story",
        title: "Leçon en Conte",
        desc: "Intégrez une notion scolaire",
        icon: BookOpen,
        preset: { story_type: "conte", target_audience: "enfants", educational: true },
      },
      {
        id: "moral_tale",
        title: "Conte Moral",
        desc: "Valeurs et citoyenneté",
        icon: Star,
        preset: { story_type: "fable", target_audience: "enfants", themes: ["valeurs"] },
      },
      {
        id: "historical",
        title: "Voyage Historique",
        desc: "Découverte d'une époque",
        icon: Sparkles,
        preset: { story_type: "aventure", target_audience: "enfants", themes: ["histoire"] },
      },
      {
        id: "science_story",
        title: "Science & Merveille",
        desc: "Concepts scientifiques en conte",
        icon: Users,
        preset: { story_type: "conte", target_audience: "enfants", themes: ["science"] },
      },
    ],
  },
  therapeute: {
    title: "Outils Thérapeutiques",
    subtitle: "Histoires pour accompagner",
    templates: [
      {
        id: "emotions",
        title: "Gestion des Émotions",
        desc: "Identifier et exprimer",
        icon: Heart,
        preset: { story_type: "conte", target_audience: "enfants", themes: ["emotions"] },
      },
      {
        id: "confidence",
        title: "Confiance en Soi",
        desc: "Renforcer l'estime personnelle",
        icon: Star,
        preset: { story_type: "aventure", target_audience: "enfants", themes: ["confiance"] },
      },
      {
        id: "change",
        title: "Accepter le Changement",
        desc: "Transitions et adaptations",
        icon: Sparkles,
        preset: { story_type: "conte", target_audience: "enfants", themes: ["changement"] },
      },
      {
        id: "calming",
        title: "Histoire Apaisante",
        desc: "Réduire l'anxiété",
        icon: Users,
        preset: { story_type: "berceuse", target_audience: "enfants", themes: ["calme"] },
      },
    ],
  },
  auteur: {
    title: "Formats de Publication",
    subtitle: "Structurez vos œuvres",
    templates: [
      {
        id: "series",
        title: "Série en Épisodes",
        desc: "Multiple chapitres liés",
        icon: BookOpen,
        preset: { story_type: "aventure", visibility: "public", series: true },
      },
      {
        id: "anthology",
        title: "Recueil de Contes",
        desc: "Plusieurs histoires indépendantes",
        icon: Star,
        preset: { story_type: "conte", visibility: "public", anthology: true },
      },
      {
        id: "interactive",
        title: "Histoire Interactive",
        desc: "Choix multiples pour le lecteur",
        icon: Sparkles,
        preset: { story_type: "aventure", visibility: "public", interactive: true },
      },
      {
        id: "collaborative",
        title: "Création Collaborative",
        desc: "À plusieurs auteurs",
        icon: Users,
        preset: { story_type: "conte", visibility: "public", collaborative: true },
      },
    ],
  },
  grand_parent: {
    title: "Héritage Familial",
    subtitle: "Transmettez vos histoires",
    templates: [
      {
        id: "family_memory",
        title: "Souvenir de Famille",
        desc: "Racontez un moment vécu",
        icon: Heart,
        preset: { story_type: "recit_familial", visibility: "family", personal: true },
      },
      {
        id: "childhood_tale",
        title: "Conte de Mon Enfance",
        desc: "Histoire d'autrefois",
        icon: BookOpen,
        preset: { story_type: "conte", target_audience: "famille" },
      },
      {
        id: "legacy_letter",
        title: "Lettre Racontée",
        desc: "Message aux générations futures",
        icon: Star,
        preset: { story_type: "lettre_racontee", visibility: "family" },
      },
      {
        id: "grandkids_adventure",
        title: "Aventure avec [Prénom]",
        desc: "Personnalisez pour vos petits-enfants",
        icon: Users,
        preset: { story_type: "aventure", target_audience: "enfants", personalize: true },
      },
    ],
  },
  enfant: {
    title: "Crée Ton Histoire",
    subtitle: "Amuse-toi !",
    templates: [
      {
        id: "my_adventure",
        title: "Mon Aventure",
        desc: "Tu es le héros",
        icon: Star,
        preset: { story_type: "aventure", target_audience: "enfants" },
      },
      {
        id: "magic_world",
        title: "Monde Magique",
        desc: "Crée un univers fantastique",
        icon: Sparkles,
        preset: { story_type: "conte", target_audience: "enfants", themes: ["magie"] },
      },
      {
        id: "animal_friend",
        title: "Mon Ami Animal",
        desc: "Invente un compagnon",
        icon: Heart,
        preset: { story_type: "conte", target_audience: "enfants", themes: ["amitie"] },
      },
      {
        id: "coloring_fun",
        title: "Dessine & Raconte",
        desc: "Colorie ton histoire",
        icon: Palette,
        preset: { story_type: "conte", target_audience: "enfants", include_coloring: true },
      },
    ],
  },
  futur_marie: {
    title: "Événement Storytelling",
    subtitle: "Racontez votre journée",
    templates: [
      {
        id: "love_story",
        title: "Notre Histoire d'Amour",
        desc: "De la rencontre au mariage",
        icon: Heart,
        preset: { story_type: "recit_familial", visibility: "public", event_type: "mariage" },
      },
      {
        id: "wedding_day",
        title: "Le Jour J en Contes",
        desc: "4 scènes de votre mariage",
        icon: BookOpen,
        preset: { story_type: "conte", visibility: "public", event_type: "mariage" },
      },
      {
        id: "baptism",
        title: "Bienvenue [Prénom]",
        desc: "Histoire de baptême",
        icon: Star,
        preset: { story_type: "conte", visibility: "public", event_type: "bapteme" },
      },
      {
        id: "birthday",
        title: "Anniversaire Spécial",
        desc: "Célébrez en musique",
        icon: Sparkles,
        preset: { story_type: "aventure", visibility: "public", event_type: "anniversaire" },
      },
    ],
  },
};

export default function RoleTemplates({ profile }) {
  const config = ROLE_TEMPLATES[profile?.profile_type] || ROLE_TEMPLATES.parent;

  return (
    <div className="border border-white/10 rounded-2xl p-6 mb-8">
      {/* Header */}
      <div className="mb-6">
        <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white mb-1">
          {config.title}
        </h3>
        <p className="text-white/40 text-sm">{config.subtitle}</p>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {config.templates.map((template) => {
          const Icon = template.icon;
          return (
            <Link
              key={template.id}
              to="/creer"
              state={{ template: template.preset }}
              className="group p-5 border border-white/10 rounded-xl hover:border-amber-500/50 hover:bg-amber-500/5 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 group-hover:bg-amber-500/20 transition-colors flex items-center justify-center">
                  <Icon className="w-5 h-5 text-white/40 group-hover:text-amber-400 transition-colors" />
                </div>
                <div className="flex-1">
                  <h4 className="text-white font-medium mb-1">{template.title}</h4>
                  <p className="text-white/40 text-sm">{template.desc}</p>
                </div>
                <Plus className="w-5 h-5 text-white/20 group-hover:text-amber-400 transition-colors mt-1" />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}