import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Check, User, Edit2, Trash2 } from "lucide-react";

const PROFILE_TYPES = [
  { value: "parent", label: "Parent", icon: "👨‍👩‍👧" },
  { value: "grand_parent", label: "Grand-parent", icon: "👴👵" },
  { value: "enfant", label: "Enfant", icon: "🧒" },
  { value: "conteur", label: "Conteur", icon: "📖" },
  { value: "enseignant", label: "Enseignant", icon: "👨‍🏫" },
  { value: "therapeute", label: "Thérapeute", icon: "🌿" },
  { value: "auteur", label: "Auteur", icon: "✍️" },
  { value: "futur_marie", label: "Futur·e Marié·e", icon: "💍" },
  { value: "anniversaire", label: "Anniversaire", icon: "🎂" },
  { value: "bapteme", label: "Baptême", icon: "✨" },
];

export default function ProfileSwitcher({ currentProfileId, onSwitchProfile }) {
  const [profiles, setProfiles] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");
  const [newProfileType, setNewProfileType] = useState("parent");
  const [creating, setCreating] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    Promise.all([base44.auth.me(), base44.entities.UserProfile.filter({ is_active: true })]).then(([me, profs]) => {
      setUser(me);
      setProfiles(profs);
    });
  }, []);

  const createProfile = async () => {
    if (!newProfileName.trim()) return;
    setCreating(true);
    const profile = await base44.entities.UserProfile.create({
      user_id: user.id,
      profile_name: newProfileName,
      profile_type: newProfileType,
      is_default: profiles.length === 0,
    });
    setProfiles([...profiles, profile]);
    setNewProfileName("");
    setCreating(false);
    setShowModal(false);
    onSwitchProfile?.(profile);
  };

  const setDefault = async (profileId) => {
    await Promise.all(
      profiles.map((p) => base44.entities.UserProfile.update(p.id, { is_default: p.id === profileId }))
    );
    setProfiles(profiles.map((p) => ({ ...p, is_default: p.id === profileId })));
  };

  const deactivate = async (profileId) => {
    await base44.entities.UserProfile.update(profileId, { is_active: false });
    setProfiles(profiles.filter((p) => p.id !== profileId));
  };

  const currentProfile = profiles.find((p) => p.id === currentProfileId) || profiles.find((p) => p.is_default) || profiles[0];

  return (
    <>
      {/* Profile Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-white/40 text-xs tracking-widest uppercase">Profil</span>
            <div className="flex gap-2">
              {profiles.map((profile) => (
                <button
                  key={profile.id}
                  onClick={() => onSwitchProfile?.(profile)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                    currentProfile?.id === profile.id
                      ? "bg-amber-500 text-black"
                      : "border border-white/20 text-white/60 hover:text-white"
                  }`}
                >
                  <span className="text-sm">
                    {PROFILE_TYPES.find((t) => t.value === profile.profile_type)?.icon || "👤"}
                  </span>
                  <span className="text-xs font-medium tracking-wider uppercase">{profile.profile_name}</span>
                  {profile.is_default && <Check className="w-3 h-3" />}
                </button>
              ))}
              <button
                onClick={() => setShowModal(true)}
                className="w-9 h-9 rounded-full border border-white/20 text-white/60 hover:text-white hover:border-white/60 transition-colors flex items-center justify-center"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="bg-black border border-white/10 rounded-2xl p-8 max-w-md w-full">
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="mb-6">
              Nouveau profil
            </h2>

            <div className="space-y-4">
              <div>
                <label className="text-white/60 text-xs tracking-widest uppercase block mb-2">Nom du profil</label>
                <input
                  type="text"
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  placeholder="Ex : Papa, Profils de Léa, Classe de CM2..."
                  className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-amber-500 rounded-full"
                />
              </div>

              <div>
                <label className="text-white/60 text-xs tracking-widest uppercase block mb-2">Type de profil</label>
                <div className="grid grid-cols-2 gap-2">
                  {PROFILE_TYPES.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => setNewProfileType(type.value)}
                      className={`flex items-center gap-2 px-3 py-2 text-xs tracking-wider uppercase transition-colors rounded-full ${
                        newProfileType === type.value
                          ? "bg-amber-500 text-black"
                          : "border border-white/20 text-white/60 hover:text-white"
                      }`}
                    >
                      <span>{type.icon}</span>
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button
                onClick={() => setShowModal(false)}
                className="flex-1 border border-white/20 text-white px-6 py-3 text-xs tracking-widest uppercase hover:border-white/60 transition-colors rounded-full"
              >
                Annuler
              </button>
              <button
                onClick={createProfile}
                disabled={creating || !newProfileName.trim()}
                className="flex-1 bg-amber-500 text-black px-6 py-3 text-xs font-medium tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-50 rounded-full"
              >
                {creating ? "Création..." : "Créer"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}