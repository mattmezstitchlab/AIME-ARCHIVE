import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronRight, BookOpen, Mic, Palette, Users, GraduationCap, Heart, PenTool, Baby, Cake, Sparkles } from "lucide-react";

const ROLE_OPTIONS = [
  { value: "parent", label: "Parent", icon: Users, desc: "Créer des contes pour mes enfants" },
  { value: "grand_parent", label: "Grand-parent", icon: Heart, desc: "Transmettre des histoires familiales" },
  { value: "enfant", label: "Enfant", icon: Baby, desc: "Écouter et colorier des histoires" },
  { value: "conteur", label: "Conteur", icon: BookOpen, desc: "Raconter des histoires à un public" },
  { value: "enseignant", label: "Enseignant", icon: GraduationCap, desc: "Créer du contenu pédagogique" },
  { value: "therapeute", label: "Thérapeute", icon: Heart, desc: "Utiliser les contes comme outil" },
  { value: "auteur", label: "Auteur", icon: PenTool, desc: "Publier mes créations" },
  { value: "futur_marie", label: "Futur·e Marié·e", icon: Sparkles, desc: "Créer l'histoire de mon événement" },
  { value: "anniversaire", label: "Anniversaire", icon: Cake, desc: "Célébrer un moment spécial" },
];

export default function RoleOnboarding({ onComplete }) {
  const [step, setStep] = useState(0);
  const [selectedRole, setSelectedRole] = useState(null);
  const [profileName, setProfileName] = useState("");
  const [creating, setCreating] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  const createProfile = async () => {
    if (!selectedRole || !profileName.trim()) return;
    setCreating(true);
    const profile = await base44.entities.UserProfile.create({
      user_id: user.id,
      profile_name: profileName,
      profile_type: selectedRole,
      is_default: true,
      created_for_role: selectedRole,
    });
    setCreating(false);
    onComplete?.(profile);
  };

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-6">
      <div className="max-w-2xl mx-auto w-full">
        {/* Progress */}
        <div className="flex gap-2 mb-12">
          {[0, 1, 2].map((i) => (
            <div key={i} className={`h-1 flex-1 transition-all ${i <= step ? "bg-amber-500" : "bg-white/10"}`} />
          ))}
        </div>

        {/* Step 0: Welcome */}
        {step === 0 && (
          <div className="text-center">
            <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Bienvenue sur SLAÂME</p>
            <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 8vw, 5rem)", lineHeight: 1 }} className="mb-6">
              Quel est votre rôle ?
            </h1>
            <p className="text-white/60 text-lg mb-10 max-w-xl mx-auto">
              Chaque profil offre une expérience personnalisée. Choisissez comment vous souhaitez utiliser SLAÂME.
            </p>
            <button
              onClick={() => setStep(1)}
              className="bg-amber-500 text-black px-8 py-4 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full inline-flex items-center gap-2"
            >
              Commencer <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Step 1: Select Role */}
        {step === 1 && (
          <div>
            <p className="text-amber-400 tracking-widest uppercase text-xs mb-4 text-center">Étape 1/2</p>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2rem, 5vw, 3rem)" }} className="mb-2 text-center">
              Choisissez votre rôle
            </h2>
            <p className="text-white/50 text-center mb-10">Nous adapterons l'expérience en conséquence.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10 max-h-[60vh] overflow-y-auto">
              {ROLE_OPTIONS.map((role) => {
                const Icon = role.icon;
                return (
                  <button
                    key={role.value}
                    onClick={() => setSelectedRole(role.value)}
                    className={`p-6 border rounded-2xl text-left transition-all ${
                      selectedRole === role.value
                        ? "border-amber-500 bg-amber-500/10"
                        : "border-white/10 hover:border-white/30"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        selectedRole === role.value ? "bg-amber-500 text-black" : "bg-white/5 text-white/40"
                      }`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium text-lg">{role.label}</h3>
                        <p className="text-white/40 text-sm mt-1">{role.desc}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setStep(0)}
                className="flex-1 border border-white/20 text-white/60 hover:text-white px-6 py-3 text-sm tracking-wider uppercase transition-colors rounded-full"
              >
                Retour
              </button>
              <button
                onClick={() => setStep(2)}
                disabled={!selectedRole}
                className="flex-1 bg-amber-500 text-black px-6 py-3 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed rounded-full"
              >
                Continuer
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Profile Name */}
        {step === 2 && (
          <div>
            <p className="text-amber-400 tracking-widest uppercase text-xs mb-4 text-center">Étape 2/2</p>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2rem, 5vw, 3rem)" }} className="mb-2 text-center">
              Nommez votre profil
            </h2>
            <p className="text-white/50 text-center mb-10">
              Ce nom apparaîtra dans votre espace personnel.
            </p>

            <div className="max-w-md mx-auto mb-10">
              <input
                type="text"
                value={profileName}
                onChange={(e) => setProfileName(e.target.value)}
                placeholder={`Ex : ${ROLE_OPTIONS.find((r) => r.value === selectedRole)?.label || "Mon profil"}`}
                className="w-full bg-white/5 border border-white/20 text-white px-6 py-4 text-lg focus:outline-none focus:border-amber-500 rounded-full"
                autoFocus
              />
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setStep(1)}
                className="flex-1 border border-white/20 text-white/60 hover:text-white px-6 py-3 text-sm tracking-wider uppercase transition-colors rounded-full"
              >
                Retour
              </button>
              <button
                onClick={createProfile}
                disabled={!profileName.trim() || creating}
                className="flex-1 bg-amber-500 text-black px-6 py-3 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed rounded-full"
              >
                {creating ? "Création..." : "Créer mon profil"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}