import { Link } from "react-router-dom";
import { BookOpen, Mic, Palette, Users, Calendar, GraduationCap, Heart, Sparkles, ArrowRight, Plus } from "lucide-react";

const ROLE_CONFIGS = {
  conteur: {
    title: "Studio Conteur",
    subtitle: "Créez et narrateur vos contes",
    primaryAction: { label: "Créer un conte", to: "/creer", icon: Plus },
    secondaryActions: [
      { label: "Ma voix", to: "/ma-voix", icon: Mic },
      { label: "Mes publications", to: "/registre", icon: BookOpen },
    ],
    quickStats: ["Contes créés", "Auditeurs", "Temps d'écoute"],
    featuredSections: ["Mes contes", "Voix disponibles", "Statistiques"],
    gradient: "from-amber-900/20 to-black",
  },
  parent: {
    title: "Espace Famille",
    subtitle: "Histoires pour vos enfants",
    primaryAction: { label: "Nouvelle histoire", to: "/creer", icon: Plus },
    secondaryActions: [
      { label: "Coloria", to: "/coloria", icon: Palette },
      { label: "Collections", to: "/collections", icon: BookOpen },
    ],
    quickStats: ["Histoires écoutées", "Coloriages", "Temps passé"],
    featuredSections: ["Favoris", "Récentes", "À colorier"],
    gradient: "from-blue-900/20 to-black",
  },
  enseignant: {
    title: "Classe & Pédagogie",
    subtitle: "Outils éducatifs et contes",
    primaryAction: { label: "Créer pour la classe", to: "/creer", icon: Plus },
    secondaryActions: [
      { label: "Collections pédagogiques", to: "/collections", icon: BookOpen },
      { label: "Partager avec élèves", to: "/mes-histoires", icon: Users },
    ],
    quickStats: ["Élèves", "Contes créés", "Activités"],
    featuredSections: ["Ma classe", "Ressources", "Progression"],
    gradient: "from-green-900/20 to-black",
  },
  therapeute: {
    title: "Accompagnement",
    subtitle: "Histoires thérapeutiques",
    primaryAction: { label: "Créer une séance", to: "/creer", icon: Plus },
    secondaryActions: [
      { label: "Mes patients", to: "/mes-histoires", icon: Users },
      { label: "Bibliothèque", to: "/collections", icon: BookOpen },
    ],
    quickStats: ["Patients", "Séances", "Progression"],
    featuredSections: ["Suivi", "Ressources", "Notes"],
    gradient: "from-purple-900/20 to-black",
  },
  auteur: {
    title: "Studio Auteur",
    subtitle: "Publiez vos créations",
    primaryAction: { label: "Nouvelle œuvre", to: "/creer", icon: Plus },
    secondaryActions: [
      { label: "Mon portfolio", to: "/registre", icon: BookOpen },
      { label: "Statistiques", to: "/mes-histoires", icon: Users },
    ],
    quickStats: ["Œuvres", "Lecteurs", "Vues"],
    featuredSections: ["Portfolio", "Audience", "Revenus"],
    gradient: "from-rose-900/20 to-black",
  },
  futur_marie: {
    title: "Mon Événement",
    subtitle: "Créez l'histoire de votre mariage",
    primaryAction: { label: "Créer l'événement", to: "/histoire-evenement", icon: Plus },
    secondaryActions: [
      { label: "Cockpit", to: "/histoire-evenement", icon: Calendar },
      { label: "Page publique", to: "/histoire-evenement", icon: Users },
    ],
    quickStats: ["Invités", "Tâches", "Jours restants"],
    featuredSections: ["Timeline", "Prestataires", "Souvenirs"],
    gradient: "from-gold-900/20 to-black",
  },
  grand_parent: {
    title: "Espace Grands-Parents",
    subtitle: "Transmettez vos histoires",
    primaryAction: { label: "Raconter un conte", to: "/creer", icon: Plus },
    secondaryActions: [
      { label: "Mes petits-enfants", to: "/mes-histoires", icon: Heart },
      { label: "Collections", to: "/collections", icon: BookOpen },
    ],
    quickStats: ["Petits-enfants", "Histoires", "Moments"],
    featuredSections: ["Famille", "Héritage", "Souvenirs"],
    gradient: "from-amber-800/20 to-black",
  },
  enfant: {
    title: "Mon Monde",
    subtitle: "Amuse-toi avec les histoires",
    primaryAction: { label: "Écouter un conte", to: "/collections", icon: BookOpen },
    secondaryActions: [
      { label: "Colorier", to: "/coloria", icon: Palette },
      { label: "Mes favoris", to: "/mes-histoires", icon: Heart },
    ],
    quickStats: ["Contes écoutés", "Coloriages", "Étoiles"],
    featuredSections: ["Favoris", "Nouveautés", "Jeux"],
    gradient: "from-pink-900/20 to-black",
  },
};

export default function RoleAdaptedDashboard({ profile, stories, events }) {
  const config = ROLE_CONFIGS[profile?.profile_type] || ROLE_CONFIGS.parent;
  const PrimaryIcon = config.primaryAction.icon;

  return (
    <div className={`bg-gradient-to-br ${config.gradient} border border-white/10 rounded-2xl p-8 mb-8`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-2">{config.subtitle}</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="text-white mb-2">
            {config.title}
          </h2>
          <p className="text-white/40 text-sm">Profil : {profile?.profile_name || "Mon profil"}</p>
        </div>
        <Link
          to={config.primaryAction.to}
          className="bg-amber-500 text-black px-6 py-4 text-xs font-medium tracking-widest uppercase hover:bg-amber-400 transition-colors rounded-full flex items-center gap-2"
        >
          <PrimaryIcon className="w-4 h-4" />
          {config.primaryAction.label}
        </Link>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {config.quickStats.map((stat, i) => (
          <div key={stat} className="bg-black/40 border border-white/10 rounded-xl p-4 text-center">
            <p className="text-amber-400 text-xs tracking-widest uppercase mb-1">{stat}</p>
            <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }} className="text-white">
              {i === 0 ? stories?.length || 0 : i === 1 ? (events?.length || 0) + 2 : "2h"}
            </p>
          </div>
        ))}
      </div>

      {/* Secondary Actions */}
      <div className="flex gap-3">
        {config.secondaryActions.map((action) => {
          const ActionIcon = action.icon;
          return (
            <Link
              key={action.label}
              to={action.to}
              className="flex items-center gap-2 border border-white/20 text-white/60 hover:text-white hover:border-white/60 transition-colors px-4 py-2 text-xs tracking-widest uppercase rounded-full"
            >
              <ActionIcon className="w-3 h-3" />
              {action.label}
            </Link>
          );
        })}
      </div>

      {/* Featured Sections Preview */}
      <div className="mt-8 pt-8 border-t border-white/10">
        <p className="text-white/40 text-xs tracking-widest uppercase mb-4">Sections</p>
        <div className="grid grid-cols-3 gap-4">
          {config.featuredSections.map((section) => (
            <div key={section} className="bg-black/40 border border-white/10 rounded-xl p-4">
              <p className="text-white/60 text-sm">{section}</p>
              <ArrowRight className="w-3 h-3 text-white/20 mt-2" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}