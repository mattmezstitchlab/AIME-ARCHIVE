import { Play } from "lucide-react";
import { Link } from "react-router-dom";

export default function StoryCard({ story, index, onPlay }) {
  return (
    <div className="group relative cursor-pointer">
      <Link to={`/conte/${story.id}`}>
        <div className="relative overflow-hidden" style={{ aspectRatio: "2/3" }}>
          <img
            src={story.hero_image_url}
            alt={story.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />

          {/* Order number */}
          <div className="absolute top-3 left-3 text-white/20 leading-none select-none" style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "3rem" }}>
            {String(index + 1).padStart(2, "0")}
          </div>

          {/* Play button hover */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={(e) => { e.preventDefault(); onPlay && onPlay(story); }}
              className="w-14 h-14 rounded-full bg-red-600/90 flex items-center justify-center hover:bg-red-500 transition-colors"
            >
              <Play className="w-6 h-6 text-black ml-0.5" />
            </button>
          </div>

          {/* Bottom content */}
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <p className="text-red-500 text-xs tracking-widest uppercase mb-1">{story.subtitle}</p>
            <h3 className="text-white leading-tight mb-2" style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(1.1rem, 2.5vw, 1.4rem)" }}>
              {story.title}
            </h3>
            <p className="text-white/60 text-xs leading-relaxed line-clamp-2">{story.tagline}</p>
          </div>
        </div>
      </Link>
    </div>
  );
}