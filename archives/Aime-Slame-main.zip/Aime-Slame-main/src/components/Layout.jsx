import { useState, useRef, useEffect } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown, User } from "lucide-react";

const NAV = [
  { label: "Collections", href: "/collections" },
  { label: "Lab", href: "/slaame-lab" },
  { label: "Registre", href: "/registre" },
  { label: "Coloria", href: "/coloria" },
];

const MON_ESPACE = [
  { label: "Mon Espace", href: "/mon-espace", icon: User },
];

export default function Layout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [espaceOpen, setEspaceOpen] = useState(false);
  const location = useLocation();
  const dropdownRef = useRef(null);

  const isEspacePage = MON_ESPACE.some((n) => location.pathname === n.href);

  useEffect(() => {
    const handleClick = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setEspaceOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div className="min-h-screen" style={{ background: "#0a0806" }}>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-6 py-4 bg-black">
        <Link to="/" className="text-white" style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem", letterSpacing: "0.1em" }}>
          SLAÂME
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV.map((n) => (
            <Link
              key={n.href}
              to={n.href}
              className={`text-xs tracking-widest uppercase transition-colors ${
                location.pathname === n.href ? "text-red-500" : "text-white/60 hover:text-white"
              }`}
            >
              {n.label}
            </Link>
          ))}

          {/* Mon Espace dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setEspaceOpen(!espaceOpen)}
              className={`flex items-center gap-1 text-xs tracking-widest uppercase transition-colors ${
                isEspacePage ? "text-red-500" : "text-white/60 hover:text-white"
              }`}
            >
              Mon Espace
              <ChevronDown className={`w-3 h-3 transition-transform ${espaceOpen ? "rotate-180" : ""}`} />
            </button>

            {espaceOpen && (
              <div className="absolute right-0 top-full mt-3 w-48 bg-black border border-white/10 rounded-xl overflow-hidden shadow-2xl">
                {MON_ESPACE.map((n) => {
                  const Icon = n.icon;
                  return (
                    <Link
                      key={n.href}
                      to={n.href}
                      onClick={() => setEspaceOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 text-xs tracking-widest uppercase transition-colors border-b border-white/5 last:border-0 ${
                        location.pathname === n.href ? "text-red-500 bg-red-500/5" : "text-white/60 hover:text-white hover:bg-white/5"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {n.label}
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </nav>

        {/* Mobile menu button */}
        <button onClick={() => setMenuOpen(true)} className="md:hidden text-white/60 hover:text-white">
          <Menu className="w-5 h-5" />
        </button>
      </header>

      {/* Mobile menu overlay */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col px-8 py-8">
          <div className="flex items-center justify-between mb-12">
            <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem", letterSpacing: "0.1em" }}>SLAÂME</span>
            <button onClick={() => setMenuOpen(false)} className="text-white/60 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
          <nav className="flex flex-col gap-6">
            {NAV.map((n) => (
              <Link
                key={n.href}
                to={n.href}
                onClick={() => setMenuOpen(false)}
                style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }}
                className={
                  location.pathname === n.href ? "text-red-500" : "text-white/80"
                      }
              >
                {n.label}
              </Link>
            ))}

            {/* Mon Espace section mobile */}
            <div className="border-t border-white/10 pt-6 mt-2">
              <p className="text-white/30 text-xs tracking-widest uppercase mb-4">Mon Espace</p>
              {MON_ESPACE.map((n) => {
                const Icon = n.icon;
                return (
                  <Link
                    key={n.href}
                    to={n.href}
                    onClick={() => setMenuOpen(false)}
                    style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}
                    className={`flex items-center gap-3 mb-4 ${
                      location.pathname === n.href ? "text-red-500" : "text-white/80"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {n.label}
                  </Link>
                );
              })}
            </div>
          </nav>
        </div>
      )}



      <Outlet />
    </div>
  );
}