import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX, X } from "lucide-react";

export default function AudioBar({ story, onClose }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [muted, setMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(story?.duration || 480);
  const audioRef = useRef(null);

  const fmt = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

  // Sync when story changes — auto-play on new story
  useEffect(() => {
    setPlaying(false);
    setProgress(0);
    setCurrentTime(0);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    if (story?.audio_url) {
      setTimeout(() => {
        if (audioRef.current) {
          audioRef.current.play().catch(() => {});
          setPlaying(true);
        }
      }, 100);
    }
  }, [story?.id]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = muted;
  }, [muted]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
    } else {
      audio.play().catch(() => {});
    }
    setPlaying(!playing);
  };

  const handleTimeUpdate = () => {
    const audio = audioRef.current;
    if (!audio) return;
    setCurrentTime(audio.currentTime);
    setProgress((audio.currentTime / (audio.duration || 1)) * 100);
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) setDuration(audioRef.current.duration);
  };

  const handleEnded = () => setPlaying(false);

  const seek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    if (audioRef.current && audioRef.current.duration) {
      audioRef.current.currentTime = pct * audioRef.current.duration;
    }
    setProgress(pct * 100);
  };

  if (!story) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-md border-t border-white/10">
      {story.audio_url && (
        <audio
          ref={audioRef}
          src={story.audio_url}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onEnded={handleEnded}
          preload="metadata"
        />
      )}

      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-4">
        {/* Cover */}
        <div className="w-10 h-10 flex-shrink-0 overflow-hidden">
          <img src={story.hero_image_url} alt={story.title} className="w-full h-full object-cover" />
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "0.85rem", letterSpacing: "0.05em" }}
            className="text-white truncate">
            {story.title}
          </p>
          {story.narrator_name && (
            <p className="text-white/40 text-xs truncate">raconté avec {story.narrator_name}</p>
          )}
        </div>

        {/* Play button */}
        <button
          onClick={togglePlay}
          disabled={!story.audio_url}
          className="w-9 h-9 rounded-full bg-red-600 flex items-center justify-center hover:bg-red-500 transition-colors disabled:opacity-40"
        >
          {playing ? <Pause className="w-4 h-4 text-black" /> : <Play className="w-4 h-4 text-black ml-0.5" />}
        </button>

        {/* Progress */}
        <div className="flex items-center gap-2 flex-1 max-w-xs">
          <span className="text-white/40 text-xs w-8 text-right">{fmt(currentTime)}</span>
          <div className="flex-1 h-1 bg-white/10 cursor-pointer relative" onClick={seek}>
            <div className="h-full bg-red-600 transition-all" style={{ width: `${progress}%` }} />
          </div>
          <span className="text-white/40 text-xs w-8">{fmt(duration)}</span>
        </div>

        {/* Volume */}
        <button onClick={() => setMuted(!muted)} className="text-white/40 hover:text-white transition-colors">
          {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Close */}
        <button onClick={onClose} className="text-white/30 hover:text-white transition-colors ml-1">
          <X className="w-4 h-4" />
        </button>
      </div>


    </div>
  );
}