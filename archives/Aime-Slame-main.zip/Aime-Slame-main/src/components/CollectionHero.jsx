export default function CollectionHero({ collection }) {
  return (
    <section className="relative h-[60vh] flex items-end pb-12 overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={collection.hero_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=1400&q=80"}
          alt={collection.title}
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
        {collection.mood_color && (
          <div className="absolute bottom-0 left-0 right-0 h-1" style={{ background: collection.mood_color }} />
        )}
      </div>
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <p className="text-amber-400 text-xs tracking-widest uppercase mb-2">{collection.audience}</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 6rem)", lineHeight: 1 }}>
          {collection.title}
        </h1>
        <p className="text-white/60 mt-3 max-w-xl">{collection.tagline || collection.description}</p>
      </div>
    </section>
  );
}