import {
  Calendar, Users, CheckSquare, Briefcase, FileText, Mic,
  Image, Download, Settings, BarChart3
} from "lucide-react";

const MODULES = [
  { icon: Calendar, name: "Timeline", desc: "Chronologie de la journée" },
  { icon: Users, name: "Invités", desc: "Liste & RSVP" },
  { icon: CheckSquare, name: "Tâches", desc: "À faire & faites" },
  { icon: Briefcase, name: "Prestataires", desc: "Contacts & contrats" },
  { icon: FileText, name: "Documents", desc: "Devis, factures, notes" },
  { icon: Mic, name: "Audio", desc: "Invitations & messages" },
  { icon: Image, name: "Illustrations", desc: "Contenu visuel généré" },
  { icon: Download, name: "Export PDF", desc: "Livre souvenir" },
  { icon: BarChart3, name: "Budget", desc: "Suivi optionnel" },
  { icon: Settings, name: "Paramètres", desc: "Confidentialité & accès" },
];

export default function EventPrivateCockpit() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Cockpit privé</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            L'organisation reste privée
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Tout ce dont vous avez besoin pour piloter votre événement, en toute confidentialité.
          </p>
        </div>

        {/* Preview du cockpit */}
        <div className="bg-gradient-to-br from-amber-900/10 to-black border border-white/10 rounded-2xl p-8 mb-12">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {MODULES.map((module) => (
              <div
                key={module.name}
                className="bg-black/40 border border-white/10 rounded-xl p-4 text-center hover:border-amber-500/50 transition-colors cursor-pointer group"
              >
                <module.icon className="w-6 h-6 text-amber-400 mx-auto mb-3" />
                <h4 className="text-white font-medium text-sm mb-1">{module.name}</h4>
                <p className="text-white/30 text-xs">{module.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Info boxes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border border-white/10 rounded-xl p-6">
            <h3 className="text-amber-400 font-medium mb-3">Contenus générés</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>✓ Histoires & contes</li>
              <li>✓ Illustrations par scène</li>
              <li>✓ Audio d'invitation</li>
              <li>✓ Pages de coloriage</li>
            </ul>
          </div>

          <div className="border border-white/10 rounded-xl p-6">
            <h3 className="text-amber-400 font-medium mb-3">Organisation</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>✓ Timeline détaillée</li>
              <li>✓ Suivi des invités</li>
              <li>✓ Checklist tâches</li>
              <li>✓ Contacts prestataires</li>
            </ul>
          </div>

          <div className="border border-white/10 rounded-xl p-6">
            <h3 className="text-amber-400 font-medium mb-3">Export & souvenirs</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>✓ Livre souvenir PDF</li>
              <li>✓ Album illustré</li>
              <li>✓ Capsule audio</li>
              <li>✓ Messages invités</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}