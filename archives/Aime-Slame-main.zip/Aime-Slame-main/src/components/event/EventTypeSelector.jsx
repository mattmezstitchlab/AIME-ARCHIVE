import { Heart, Gift, Baby, GraduationCap, Home, Music, Cake, Users, Sparkles } from "lucide-react";

const EVENT_TYPES = [
  { icon: Heart, label: "Mariage", desc: "Votre histoire d'amour" },
  { icon: Cake, label: "Anniversaire", desc: "Cap symbolique" },
  { icon: Baby, label: "Naissance / Baptême", desc: "Arrivée d'un enfant" },
  { icon: GraduationCap, label: "Diplôme", desc: "Réussite académique" },
  { icon: Home, label: "Crémaillère", desc: "Nouveau chez-soi" },
  { icon: Music, label: "Concert / Spectacle", desc: "Événement artistique" },
  { icon: Users, label: "Famille", desc: "Retrouvailles" },
  { icon: Gift, label: "Autre", desc: "Tout autre moment" },
];

export default function EventTypeSelector() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Types d'événements</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            Quel événement racontez-vous ?
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Chaque événement a sa propre magie. Choisissez le vôtre.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {EVENT_TYPES.map((type) => (
            <button
              key={type.label}
              className="group bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-amber-500/50 hover:bg-amber-500/10 transition-all text-left"
            >
              <type.icon className="w-6 h-6 text-amber-400 mb-4" />
              <h3 className="text-white font-medium mb-1">{type.label}</h3>
              <p className="text-white/40 text-xs">{type.desc}</p>
            </button>
          ))}

          {/* Custom event */}
          <button className="group border border-amber-500/30 rounded-2xl p-6 hover:border-amber-500 transition-all text-left">
            <Sparkles className="w-6 h-6 text-amber-400 mb-4" />
            <h3 className="text-white font-medium mb-1">Personnalisé</h3>
            <p className="text-white/40 text-xs">Votre idée unique</p>
          </button>
        </div>
      </div>
    </section>
  );
}