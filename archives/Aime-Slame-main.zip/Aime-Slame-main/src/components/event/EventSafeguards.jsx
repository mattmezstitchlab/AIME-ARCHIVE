import { Shield, Lock, Eye, EyeOff, CheckCircle, AlertCircle } from "lucide-react";

const SAFEGUARDS = [
  {
    icon: Lock,
    title: "Données privées protégées",
    desc: "Les données privées ne sont jamais publiques par défaut.",
  },
  {
    icon: Eye,
    title: "Profils enfants protégés",
    desc: "Aucune donnée sensible sur les mineurs sans consentement parental.",
  },
  {
    icon: CheckCircle,
    title: "Consentement voix & images",
    desc: "Toutes les voix et images nécessitent un consentement explicite.",
  },
  {
    icon: AlertCircle,
    title: "Validation humaine",
    desc: "La publication doit être validée manuellement par l'utilisateur.",
  },
  {
    icon: EyeOff,
    title: "Contrôle total",
    desc: "Possibilité de modifier, masquer, exporter ou supprimer à tout moment.",
  },
  {
    icon: Shield,
    title: "Visibilité contrôlée",
    desc: "Les invités ne voient que ce qui est volontairement partagé.",
  },
];

export default function EventSafeguards() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Confidentialité</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            Garde-fous et confidentialité
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto mb-8">
            Créer une histoire ne doit jamais exposer ce qui doit rester privé.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SAFEGUARDS.map((safeguard) => (
            <div
              key={safeguard.title}
              className="bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-xl p-6"
            >
              <div className="flex items-start gap-3">
                <safeguard.icon className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-white font-medium text-sm mb-2">{safeguard.title}</h3>
                  <p className="text-white/40 text-xs leading-relaxed">{safeguard.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Note finale */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-full px-4 py-2">
            <Shield className="w-3 h-3 text-amber-400" />
            <span className="text-amber-400 text-xs tracking-wider uppercase">
              Cockpit d'organisation 100% privé
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}