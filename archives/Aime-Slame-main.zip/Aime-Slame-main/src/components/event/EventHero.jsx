import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Play, ChevronLeft, ChevronRight } from "lucide-react";

const SLIDES = [
  {
    title: "Racontez",
    subtitle: "Décrivez votre événement en quelques mots",
    description: "L'IA crée une histoire unique basée sur vos souvenirs.",
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1600&q=80",
  },
  {
    title: "Générez",
    subtitle: "Contenu automatique",
    description: "Illustrations, audio narré, pages de coloriage… tout le contenu est généré automatiquement.",
    image: "https://images.unsplash.com/photo-1536240478700-b869070f9279?w=1600&q=80",
  },
  {
    title: "Organisez",
    subtitle: "Cockpit privé",
    description: "Accédez à un cockpit privé pour gérer invités, timeline, prestataires et documents.",
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=1600&q=80",
  },
];

export default function EventHero() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);

  return (
    <section className="relative h-[90vh] overflow-hidden bg-black">
      {/* Slides */}
      {SLIDES.map((slide, index) => (
        <div
          key={slide.title}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          {/* Background image */}
          <div className="absolute inset-0">
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black" />
          </div>

          {/* Content */}
          <div className="relative z-10 h-full flex items-center justify-center">
            <div className="max-w-5xl mx-auto px-6 text-center">
              <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">
                {slide.subtitle}
              </p>
              <h1
                style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(4rem, 12vw, 8rem)", lineHeight: 1 }}
                className="text-white mb-6"
              >
                {slide.title}
              </h1>
              <p className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
                {slide.description}
              </p>

              {index === 0 && (
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Link
                    to="/creer"
                    state={{ preset: "event" }}
                    className="inline-flex items-center gap-2 bg-amber-500 text-black px-8 py-4 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full"
                  >
                    Créer mon événement <ArrowRight className="w-4 h-4" />
                  </Link>
                  <button className="inline-flex items-center gap-2 border border-white/20 text-white px-8 py-4 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-full">
                    <Play className="w-4 h-4" /> Voir la démo
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}

      {/* Navigation arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-6 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full border border-white/20 text-white/60 hover:text-white hover:border-white/60 transition-colors flex items-center justify-center"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-6 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full border border-white/20 text-white/60 hover:text-white hover:border-white/60 transition-colors flex items-center justify-center"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Dots indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex gap-3">
        {SLIDES.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentSlide ? "bg-amber-400 w-8" : "bg-white/30"
            }`}
          />
        ))}
      </div>
    </section>
  );
}