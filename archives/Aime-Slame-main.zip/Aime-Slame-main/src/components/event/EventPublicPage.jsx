import { Share2, MessageSquare, Image, BookOpen } from "lucide-react";

export default function EventPublicPage() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Partage</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            Page publique de l'événement
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Une vitrine élégante à partager avec vos invités.
          </p>
        </div>

        {/* Mockup de la page publique */}
        <div className="bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-2xl overflow-hidden">
          {/* Header */}
          <div className="relative h-64 bg-gradient-to-br from-amber-900/30 to-black flex items-center justify-center">
            <div className="text-center">
              <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "3rem" }} className="text-white mb-2">
                Marie & Thomas
              </h3>
              <p className="text-amber-400 text-sm tracking-widest uppercase">15 Juin 2026 — Château de Versailles</p>
            </div>
          </div>

          {/* Sections */}
          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-amber-400" />
                  Notre histoire
                </h4>
                <p className="text-white/50 text-sm leading-relaxed">
                  Tout a commencé par un regard échangé dans un café parisien. Cinq ans plus tard, nous vous invitons à célébrer notre union…
                </p>
              </div>
              <div>
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <Image className="w-4 h-4 text-amber-400" />
                  Galerie
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="aspect-square bg-amber-500/20 rounded-lg" />
                  <div className="aspect-square bg-amber-500/20 rounded-lg" />
                </div>
              </div>
            </div>

            <div className="border-t border-white/10 pt-8">
              <h4 className="text-white font-medium mb-4 flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-amber-400" />
                Messages des invités
              </h4>
              <div className="space-y-3">
                <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                  <p className="text-white/70 text-sm mb-2">"Tous nos vœux de bonheur !"</p>
                  <p className="text-white/40 text-xs">— Sophie & Marc</p>
                </div>
                <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                  <p className="text-white/70 text-sm mb-2">"Vivement la célébration !"</p>
                  <p className="text-white/40 text-xs">— La famille Dupont</p>
                </div>
              </div>
            </div>

            <div className="mt-8 flex justify-center">
              <button className="inline-flex items-center gap-2 bg-amber-500 text-black px-6 py-3 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full">
                <Share2 className="w-4 h-4" /> Partager cette page
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}