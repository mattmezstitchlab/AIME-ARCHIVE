import { BookOpen, Image, Mic, Palette, MessageSquare, Archive } from "lucide-react";

const AFTER_ELEMENTS = [
  { icon: BookOpen, name: "Livre souvenir", desc: "Album complet de l'événement" },
  { icon: Image, name: "Album illustré", desc: "Illustrations de chaque scène" },
  { icon: Mic, name: "Capsule audio", desc: "Messages et ambiances sonores" },
  { icon: MessageSquare, name: "Recueil de messages", desc: "Souhaits des invités" },
  { icon: Palette, name: "Coloriages souvenir", desc: "Pour les enfants" },
  { icon: Archive, name: "Page archive", desc: "Privée ou publique" },
];

export default function EventAfterStory() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Après le jour J</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            L'événement ne disparaît pas
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto mb-8">
            Il devient une mémoire vivante à revisiter.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {AFTER_ELEMENTS.map((element) => (
            <div
              key={element.name}
              className="bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-2xl p-6 hover:border-amber-500/50 transition-colors"
            >
              <element.icon className="w-8 h-8 text-amber-400 mb-4" />
              <h3 className="text-white font-medium mb-2">{element.name}</h3>
              <p className="text-white/40 text-sm">{element.desc}</p>
            </div>
          ))}
        </div>

        {/* Citation */}
        <div className="text-center">
          <blockquote className="border-l-2 border-amber-500 pl-6 text-left inline-block">
            <p className="text-white/70 text-lg italic max-w-xl">
              "L'événement ne disparaît pas. Il devient une mémoire vivante."
            </p>
          </blockquote>
        </div>
      </div>
    </section>
  );
}