import { Palette, Briefcase } from "lucide-react";

export default function EventDualFace() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Double approche</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            Créatif & Organisation
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Deux facettes d'un même événement. L'émotion d'un côté, la logistique de l'autre.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Créatif */}
          <div className="border border-white/10 rounded-2xl p-8">
            <div className="flex items-center gap-4 mb-6">
              <Palette className="w-8 h-8 text-amber-400" />
              <h3 className="text-white font-medium text-xl">Face créative</h3>
            </div>
            <div className="space-y-4">
              <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                <p className="text-white/80 text-sm mb-2">Scène 1 : La Rencontre</p>
                <p className="text-white/40 text-xs">Illustration : couple sous les arbres, lumière dorée</p>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                <p className="text-white/80 text-sm mb-2">Scène 2 : Les Préparatifs</p>
                <p className="text-white/40 text-xs">Illustration : famille réunie, préparations festives</p>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                <p className="text-white/80 text-sm mb-2">Scène 3 : Le Jour J</p>
                <p className="text-white/40 text-xs">Illustration : cérémonie, émotions partagées</p>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                <p className="text-white/80 text-sm mb-2">Scène 4 : La Célébration</p>
                <p className="text-white/40 text-xs">Illustration : fête, danse, joie collective</p>
              </div>
            </div>
          </div>

          {/* Organisation */}
          <div className="border border-white/10 rounded-2xl p-8">
            <div className="flex items-center gap-4 mb-6">
              <Briefcase className="w-8 h-8 text-amber-400" />
              <h3 className="text-white font-medium text-xl">Face organisation</h3>
            </div>
            <div className="space-y-4">
              <div className="bg-black/40 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-white/80 text-sm mb-1">Timeline</p>
                  <p className="text-white/40 text-xs">14:00 Cérémonie → 16:00 Cocktail → 20:00 Dîner</p>
                </div>
                <span className="text-amber-400 text-xs">✓ Planifié</span>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-white/80 text-sm mb-1">Invités</p>
                  <p className="text-white/40 text-xs">48 confirmés / 52 invités</p>
                </div>
                <span className="text-amber-400 text-xs">92%</span>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-white/80 text-sm mb-1">Prestataires</p>
                  <p className="text-white/40 text-xs">Photographe, Traiteur, DJ</p>
                </div>
                <span className="text-amber-400 text-xs">✓ Contactés</span>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-white/80 text-sm mb-1">Budget</p>
                  <p className="text-white/40 text-xs">Suivi des dépenses en cours</p>
                </div>
                <span className="text-amber-400 text-xs">En suivi</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}