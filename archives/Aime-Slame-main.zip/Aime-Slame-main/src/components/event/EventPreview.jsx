import { BookOpen, Globe, Lock } from "lucide-react";

export default function EventPreview() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Résultat</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            Ce qui est généré
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Trois dimensions complémentaires pour votre événement.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Histoire */}
          <div className="border border-white/10 rounded-2xl p-8">
            <BookOpen className="w-8 h-8 text-amber-400 mb-6" />
            <h3 className="text-white font-medium text-lg mb-3">L'histoire</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>• Récit personnalisé en 4-6 scènes</li>
              <li>• Illustrations par chapitre</li>
              <li>• Audio narré avec votre voix</li>
              <li>• Pages de coloriage associées</li>
            </ul>
          </div>

          {/* Page publique */}
          <div className="border border-white/10 rounded-2xl p-8">
            <Globe className="w-8 h-8 text-amber-400 mb-6" />
            <h3 className="text-white font-medium text-lg mb-3">Page publique</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>• URL unique à partager</li>
              <li>• Présentation de l'événement</li>
              <li>• Contenus accessibles aux invités</li>
              <li>• Messages & souhaits</li>
            </ul>
          </div>

          {/* Cockpit privé */}
          <div className="border border-white/10 rounded-2xl p-8">
            <Lock className="w-8 h-8 text-amber-400 mb-6" />
            <h3 className="text-white font-medium text-lg mb-3">Cockpit privé</h3>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>• Timeline détaillée</li>
              <li>• Gestion des invités</li>
              <li>• Suivi prestataires</li>
              <li>• Documents & exports</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}