import { BookOpen, Sparkles, Calendar } from "lucide-react";

const STEPS = [
  {
    icon: BookOpen,
    title: "Racontez",
    desc: "Décrivez votre événement en quelques mots. L'IA crée une histoire unique basée sur vos souvenirs.",
  },
  {
    icon: Sparkles,
    title: "Générez",
    desc: "Illustrations, audio narré, pages de coloriage… tout le contenu est généré automatiquement.",
  },
  {
    icon: Calendar,
    title: "Organisez",
    desc: "Accédez à un cockpit privé pour gérer invités, timeline, prestataires et documents.",
  },
];

export default function EventPrinciple() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Le concept</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            De l'histoire à l'organisation
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Un événement ne se résume pas à une date. C'est une histoire à raconter, encore et encore.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {STEPS.map((step, index) => (
            <div key={step.title} className="relative">
              {/* Connector line */}
              {index < STEPS.length - 1 && (
                <div className="hidden md:block absolute top-12 left-1/2 w-full h-px bg-gradient-to-r from-amber-500/50 to-transparent" />
              )}
              
              <div className="relative bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-2xl p-8 text-center hover:border-amber-500/50 transition-colors">
                <step.icon className="w-12 h-12 text-amber-400 mx-auto mb-6" />
                <h3 className="text-white font-medium text-lg mb-3">{step.title}</h3>
                <p className="text-white/40 text-sm leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}