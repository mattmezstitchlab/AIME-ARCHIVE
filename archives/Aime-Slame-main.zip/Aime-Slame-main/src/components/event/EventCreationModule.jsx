import { useState } from "react";
import { Sparkles, Mic, BookOpen, FileText, Palette, Calendar, ArrowRight } from "lucide-react";

const STYLES = [
  { key: "conte", label: "Conte", icon: BookOpen },
  { key: "slam", label: "Slam", icon: Mic },
  { key: "invitation", label: "Invitation", icon: FileText },
  { key: "programme", label: "Programme", icon: Calendar },
  { key: "coloriage", label: "Coloriage", icon: Palette },
  { key: "tout", label: "Tout générer", icon: Sparkles },
];

const TONES = ["tendre", "drôle", "poétique", "solennel", "familial"];
const PUBLICS = ["enfants", "adultes", "famille", "invités"];
const AMBIANCES = ["chic", "champêtre", "féerique", "moderne", "intime"];

export default function EventCreationModule() {
  const [inputValue, setInputValue] = useState("");
  const [selectedStyle, setSelectedStyle] = useState(null);
  const [tone, setTone] = useState("tendre");
  const [publicValue, setPublicValue] = useState("famille");
  const [ambiance, setAmbiance] = useState("champêtre");

  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Commencer</p>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-4">
            Commencer par une phrase.
          </h2>
          <p className="text-white/50 text-lg">
            Décrivez votre événement en une phrase. L'IA s'occupe du reste.
          </p>
        </div>

        {/* Input principal */}
        <div className="bg-gradient-to-br from-amber-900/20 to-black border border-white/10 rounded-2xl p-8 mb-8">
          <textarea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Exemple : Nous voulons raconter notre mariage comme un conte solaire dans un jardin, avec nos familles, de la musique et une soirée joyeuse."
            className="w-full bg-black/50 border border-white/20 text-white px-4 py-4 text-sm focus:outline-none focus:border-amber-500 rounded-xl min-h-[120px] resize-none mb-6"
          />

          {/* Boutons de style */}
          <div className="flex flex-wrap gap-2 mb-6">
            {STYLES.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setSelectedStyle(key)}
                className={`flex items-center gap-2 px-4 py-2 text-xs tracking-widest uppercase transition-all rounded-full ${
                  selectedStyle === key
                    ? "bg-amber-500 text-black"
                    : "border border-white/20 text-white/60 hover:text-white hover:border-white/60"
                }`}
              >
                <Icon className="w-3 h-3" /> {label}
              </button>
            ))}
          </div>

          {/* Réglages */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Ton</label>
              <div className="flex flex-wrap gap-2">
                {TONES.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTone(t)}
                    className={`px-3 py-1.5 text-xs tracking-wider uppercase transition-colors rounded-full ${
                      tone === t
                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/50"
                        : "border border-white/20 text-white/40 hover:text-white"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Public</label>
              <div className="flex flex-wrap gap-2">
                {PUBLICS.map((p) => (
                  <button
                    key={p}
                    onClick={() => setPublicValue(p)}
                    className={`px-3 py-1.5 text-xs tracking-wider uppercase transition-colors rounded-full ${
                      publicValue === p
                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/50"
                        : "border border-white/20 text-white/40 hover:text-white"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Ambiance</label>
              <div className="flex flex-wrap gap-2">
                {AMBIANCES.map((a) => (
                  <button
                    key={a}
                    onClick={() => setAmbiance(a)}
                    className={`px-3 py-1.5 text-xs tracking-wider uppercase transition-colors rounded-full ${
                      ambiance === a
                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/50"
                        : "border border-white/20 text-white/40 hover:text-white"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* CTA */}
          <button
            disabled={!inputValue.trim()}
            className="w-full bg-amber-500 text-black py-4 text-sm font-medium tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2 rounded-full"
          >
            <Sparkles className="w-4 h-4" />
            Générer l'histoire
          </button>
        </div>

        {/* Note */}
        <p className="text-white/30 text-xs text-center">
          Ce module est une démonstration. La génération complète sera disponible prochainement.
        </p>
      </div>
    </section>
  );
}