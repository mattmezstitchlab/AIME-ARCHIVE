import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { elevenLabsGenerateAudio } from "@/functions/elevenLabsGenerateAudio";
import { generateStoryIllustrations } from "@/functions/generateStoryIllustrations";
import { Loader2, Mic, Volume2 } from "lucide-react";

const AUDIENCES = ["enfants", "ados", "adultes", "famille"];
const TYPES = ["conte", "fable", "histoire_du_soir", "berceuse", "aventure", "slam_doux", "lettre_racontee"];
const THEMES = ["amour", "courage", "amitié", "nature", "famille", "magie", "voyage", "identité", "peur", "joie"];

export default function StoryDirectForm({ voiceProfiles = [] }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: "", target_audience: "", story_type: "", themes: [], custom_keywords: "" });
  const [generating, setGenerating] = useState(false);
  const [done, setDone] = useState(null);
  const [selectedVoiceId, setSelectedVoiceId] = useState(voiceProfiles[0]?.voice_model_id || null);
  const [generatingAudio, setGeneratingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState(null);

  useEffect(() => {
    const withModel = voiceProfiles.filter((p) => p.voice_model_id);
    if (withModel.length > 0 && !selectedVoiceId) setSelectedVoiceId(withModel[0].voice_model_id);
  }, [voiceProfiles]);

  const toggle = (field, val) => {
    setForm((f) => ({
      ...f,
      [field]: f[field].includes(val) ? f[field].filter((x) => x !== val) : [...f[field], val],
    }));
  };

  const generate = async () => {
    if (!form.title || !form.target_audience || !form.story_type) return;
    setGenerating(true);
    const prompt = `Écris un ${form.story_type} pour ${form.target_audience} intitulé "${form.title}". Thèmes : ${form.themes.join(", ") || "libre"}. Mots-clés : ${form.custom_keywords || "aucun"}. Structure en 4 scènes avec un titre de chapitre par scène. Retourne un JSON avec: title, subtitle, tagline, text_content, scene_breakdown (array of {scene_number, chapter_title, scene_text, illustration_prompt}).`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          subtitle: { type: "string" },
          tagline: { type: "string" },
          text_content: { type: "string" },
          scene_breakdown: { type: "array", items: { type: "object" } },
        },
      },
    });

    const project = await base44.entities.StoryProject.create({
      title: result.title || form.title,
      subtitle: result.subtitle,
      tagline: result.tagline,
      target_audience: form.target_audience,
      story_type: form.story_type,
      themes: form.themes,
      custom_keywords: form.custom_keywords,
      text_content: result.text_content,
      scene_breakdown: result.scene_breakdown,
      status: "generated",
      visibility: "private",
    });

    if (result.scene_breakdown?.length) {
      await base44.entities.StoryScene.bulkCreate(
        result.scene_breakdown.map((s) => ({ ...s, story_project_id: project.id }))
      );
      generateStoryIllustrations({ story_project_id: project.id }).catch(console.error);
    }

    setDone(project);
    setGenerating(false);
  };

  const generateAudio = async () => {
    if (!done || !selectedVoiceId) return;
    setGeneratingAudio(true);
    const text = done.text_content || done.tagline || done.title;
    const res = await elevenLabsGenerateAudio({
      text: text.slice(0, 4000),
      voice_id: selectedVoiceId,
      story_project_id: done.id,
    });
    if (res.data?.audio_url) setAudioUrl(res.data.audio_url);
    setGeneratingAudio(false);
  };

  if (done) return (
    <div className="text-center py-12">
      <div className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center mx-auto mb-6">
        <Mic className="w-8 h-8 text-white" />
      </div>
      <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="text-white">{done.title}</h3>
      <p className="text-white/50 mt-2 mb-8">{done.tagline}</p>

      {voiceProfiles.filter(p => p.voice_model_id).length > 0 && (
        <div className="max-w-sm mx-auto mb-8 p-6 bg-white/5 border border-white/10 rounded-2xl text-left">
          <p className="text-red-500 text-xs tracking-widest uppercase mb-3 flex items-center gap-2">
            <Mic className="w-3 h-3" /> Narration avec votre voix
          </p>
          {voiceProfiles.filter(p => p.voice_model_id).length > 1 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {voiceProfiles.filter(p => p.voice_model_id).map((p) => (
                <button key={p.id} onClick={() => setSelectedVoiceId(p.voice_model_id)}
                  className={`px-3 py-1 text-xs tracking-wider uppercase transition-colors rounded-full ${selectedVoiceId === p.voice_model_id ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
                  {p.display_name}
                </button>
              ))}
            </div>
          )}
          {audioUrl ? (
            <audio src={audioUrl} controls className="w-full" />
          ) : (
            <button onClick={generateAudio} disabled={generatingAudio}
              className="w-full bg-white/10 text-white px-6 py-3 text-xs tracking-widest uppercase hover:bg-white/20 transition-colors disabled:opacity-50 flex items-center justify-center gap-2 rounded-full">
              {generatingAudio ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération...</> : <><Volume2 className="w-4 h-4" /> Générer l'audio</>}
            </button>
          )}
        </div>
      )}

      <div className="flex gap-4 justify-center">
        <button onClick={() => navigate(`/conte/${done.id}`)}
          className="bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors rounded-full">
          Lire le conte
        </button>
        <button onClick={() => { setDone(null); setAudioUrl(null); setForm({ title: "", target_audience: "", story_type: "", themes: [], custom_keywords: "" }); }}
          className="border border-white/20 text-white px-6 py-3 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-full">
          Nouveau conte
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Title */}
      <div>
        <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Titre du conte *</label>
        <input
          type="text"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="Ex : La Forêt des Murmures"
          className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500 rounded-lg"
        />
      </div>

      {/* Audience */}
      <div>
        <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Public *</label>
        <div className="flex flex-wrap gap-2">
          {AUDIENCES.map((a) => (
            <button key={a} onClick={() => setForm({ ...form, target_audience: a })}
              className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${form.target_audience === a ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
              {a}
            </button>
          ))}
        </div>
      </div>

      {/* Type */}
      <div>
        <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Type de récit *</label>
        <div className="flex flex-wrap gap-2">
          {TYPES.map((t) => (
            <button key={t} onClick={() => setForm({ ...form, story_type: t })}
              className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${form.story_type === t ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
              {t.replace(/_/g, " ")}
            </button>
          ))}
        </div>
      </div>

      {/* Themes */}
      <div>
        <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Thèmes</label>
        <div className="flex flex-wrap gap-2">
          {THEMES.map((t) => (
            <button key={t} onClick={() => toggle("themes", t)}
              className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${form.themes.includes(t) ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Keywords */}
      <div>
        <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Mots-clés libres</label>
        <input
          type="text"
          value={form.custom_keywords}
          onChange={(e) => setForm({ ...form, custom_keywords: e.target.value })}
          placeholder="Ex : grand-mère, chêne centenaire, étoile filante..."
          className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500 rounded-lg"
        />
      </div>

      <button
        onClick={generate}
        disabled={generating || !form.title || !form.target_audience || !form.story_type}
        className="w-full bg-red-600 text-white py-4 text-sm font-medium tracking-widest uppercase hover:bg-red-500 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2 rounded-full"
      >
        {generating ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération en cours...</> : "Générer le conte"}
      </button>
    </div>
  );
}