import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import Login from './pages/Login';
import Register from './pages/Register';
import Home from './pages/Home.jsx';
import Collections from './pages/Collections.jsx';
import CollectionPage from './pages/CollectionPage';
import ConteDetail from './pages/ConteDetail';
import MaVoix from './pages/MaVoix';

import Registre from './pages/Registre.jsx';
import MesHistoires from './pages/MesHistoires';
import Coloria from './pages/Coloria';

import ConteurPublic from './pages/ConteurPublic';
import Admin from './pages/Admin';
import HistoireEvenement from '@/pages/HistoireEvenement';
import AdminContesDeMode from '@/pages/AdminContesDeMode';
import SlaameLab from '@/pages/SlaameLab.jsx';
import SlaameLabDetail from '@/pages/SlaameLabDetail';
import AdminLabDeposits from '@/pages/AdminLabDeposits';
import MonEspace from '@/pages/MonEspace';
import Slaame18Detail from '@/pages/Slaame18Detail';
import AdminSlaame18 from '@/pages/AdminSlaame18';
import SlaameStudio from '@/pages/SlaameStudio';
import Layout from './components/Layout.jsx';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black">
        <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') return <UserNotRegisteredError />;
    else if (authError.type === 'auth_required') { navigateToLogin(); return null; }
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/collections" element={<Collections />} />
        <Route path="/collections/:slug" element={<CollectionPage />} />
        <Route path="/conte/:id" element={<ConteDetail />} />
        <Route path="/ma-voix" element={<MaVoix />} />

        <Route path="/registre" element={<Registre />} />
        <Route path="/mes-histoires" element={<MesHistoires />} />
        <Route path="/coloria" element={<Coloria />} />
        <Route path="/conteur/:id" element={<ConteurPublic />} />
        <Route path="/histoire-evenement" element={<HistoireEvenement />} />
        <Route path="/admin/contes-de-mode" element={<AdminContesDeMode />} />
        <Route path="/slaame-lab" element={<SlaameLab />} />
        <Route path="/slaame-lab/:id" element={<SlaameLabDetail />} />
        <Route path="/admin/lab" element={<AdminLabDeposits />} />
        <Route path="/admin/slaame-adulte" element={<AdminSlaame18 />} />
        <Route path="/slaame-studio" element={<SlaameStudio />} />
        <Route path="/mon-espace" element={<MonEspace />} />
        <Route path="/admin" element={<Admin />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;