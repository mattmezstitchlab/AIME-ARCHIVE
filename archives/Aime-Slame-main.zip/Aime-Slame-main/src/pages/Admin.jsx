import { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { generateAllDemoAudio } from "@/functions/generateAllDemoAudio";
import { generateStoryIllustrations } from "@/functions/generateStoryIllustrations";
import { Loader2, Mic, Palette, Check, X, BookOpen, ShoppingBag, Shield, Heart } from "lucide-react";

export default function Admin() {
  const [generatingAudio, setGeneratingAudio] = useState(false);
  const [generatingImages, setGeneratingImages] = useState(false);
  const [result, setResult] = useState(null);

  const runDemoAudio = async () => {
    setGeneratingAudio(true);
    setResult(null);
    try {
      const res = await generateAllDemoAudio({});
      setResult(res.data);
    } catch (error) {
      setResult({ error: error.message });
    }
    setGeneratingAudio(false);
  };

  const runIllustrations = async () => {
    const storyId = prompt("ID du conte (StoryProject) :");
    if (!storyId) return;
    setGeneratingImages(true);
    setResult(null);
    try {
      const res = await generateStoryIllustrations({ story_project_id: storyId });
      setResult(res.data);
    } catch (error) {
      setResult({ error: error.message });
    }
    setGeneratingImages(false);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <section className="max-w-3xl mx-auto px-6 pt-32 pb-20">
        <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Administration</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 5rem)", lineHeight: 1 }}>
          Outils SLAÂME
        </h1>

        <div className="mt-12 mb-12">
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }} className="mb-6">Sections Admin</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link
              to="/admin/contes-de-mode"
              className="bg-white/5 border border-white/10 rounded-xl p-6 hover:border-amber-500/30 transition-colors"
            >
              <ShoppingBag className="w-8 h-8 text-amber-500 mb-4" />
              <h3 className="text-white font-medium mb-2">Contes de Mode</h3>
              <p className="text-white/50 text-sm">Gérez les contes et produits associés</p>
            </Link>
            <Link
              to="/admin/lab"
              className="bg-white/5 border border-white/10 rounded-xl p-6 hover:border-amber-500/30 transition-colors"
            >
              <Shield className="w-8 h-8 text-amber-500 mb-4" />
              <h3 className="text-white font-medium mb-2">SLAÂME Lab</h3>
              <p className="text-white/50 text-sm">Dépôts et directions générées</p>
            </Link>
            <Link
              to="/admin/slaame-adulte"
              className="bg-white/5 border border-white/10 rounded-xl p-6 hover:border-red-500/30 transition-colors"
            >
              <Shield className="w-8 h-8 text-red-500 mb-4" />
              <h3 className="text-white font-medium mb-2">SLAÂME 18+</h3>
              <p className="text-white/50 text-sm">Capsules éducatives adultes</p>
            </Link>
          </div>
        </div>

        <div className="space-y-6">
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }} className="mb-6">Outils de génération</h2>
          {/* Generate Demo Audio */}
          <div className="p-6 border border-white/10 bg-white/5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-amber-500 flex items-center justify-center flex-shrink-0">
                <Mic className="w-5 h-5 text-black" />
              </div>
              <div className="flex-1">
                <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.5rem" }}>Générer l'audio des contes démo</h3>
                <p className="text-white/50 text-sm mt-1">Crée des narrations ElevenLabs pour tous les contes démo sans audio.</p>
                <button
                  onClick={runDemoAudio}
                  disabled={generatingAudio}
                  className="mt-4 bg-amber-500 text-black px-6 py-3 text-xs tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-50 flex items-center gap-2 rounded-full"
                >
                  {generatingAudio ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération...</> : "Lancer la génération audio"}
                </button>
              </div>
            </div>
          </div>

          {/* Generate Illustrations */}
          <div className="p-6 border border-white/10 bg-white/5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-amber-500 flex items-center justify-center flex-shrink-0">
                <Palette className="w-5 h-5 text-black" />
              </div>
              <div className="flex-1">
                <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.5rem" }}>Générer les illustrations d'un conte</h3>
                <p className="text-white/50 text-sm mt-1">Crée les images de toutes les scènes d'un conte spécifique.</p>
                <button
                  onClick={runIllustrations}
                  disabled={generatingImages}
                  className="mt-4 bg-amber-500 text-black px-6 py-3 text-xs tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-50 flex items-center gap-2 rounded-full"
                >
                  {generatingImages ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération...</> : "Choisir un conte"}
                </button>
              </div>
            </div>
          </div>

          {/* Result */}
          {result && (
            <div className={`p-6 border ${result.error ? "border-red-500/30 bg-red-500/10" : "border-green-500/30 bg-green-500/10"}`}>
              <div className="flex items-start gap-3">
                {result.error ? <X className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" /> : <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />}
                <div className="flex-1">
                  <p className="text-white/80 text-sm">
                    {result.error || result.message || "Terminé"}
                  </p>
                  {result.results && (
                    <div className="mt-3 max-h-40 overflow-y-auto text-xs text-white/40 space-y-1">
                      {result.results.map((r, i) => (
                        <div key={i} className="flex justify-between">
                          <span>{r.title || `Scène ${r.scene_id}`}</span>
                          <span className={r.success ? "text-green-400" : "text-red-400"}>
                            {r.success ? (r.skipped ? "Déjà fait" : "OK") : r.error}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}