import { useState, useEffect, useRef } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Play, Pause, SkipBack, SkipForward, Shield, AlertTriangle, Share2, Flag, ArrowLeft } from "lucide-react";

const CATEGORIES = {
  consentement: { label: "Consentement", color: "text-red-400" },
  dialogue: { label: "Dialogue", color: "text-blue-400" },
  limites: { label: "Limites", color: "text-purple-400" },
  repair: { label: "Réparation", color: "text-green-400" },
  humour: { label: "Humour", color: "text-amber-400" },
  slam: { label: "Slam", color: "text-pink-400" },
  prevention: { label: "Prévention", color: "text-cyan-400" },
};

export default function Slaame18Detail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [capsule, setCapsule] = useState(null);
  const [loading, setLoading] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef(null);

  useEffect(() => {
    base44.entities.AdultCapsule.get(id).then((c) => {
      if (!c || c.status !== "published") {
        navigate("/slaame-adulte");
        return;
      }
      setCapsule(c);
      setDuration(c.duration || 0);
      setLoading(false);
    });
  }, [id, navigate]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (playing) audioRef.current.pause();
      else audioRef.current.play();
      setPlaying(!playing);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) setCurrentTime(audioRef.current.currentTime);
  };

  const handleSeek = (e) => {
    const time = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const formatTime = (s) => {
    if (!s || isNaN(s)) return "0:00";
    return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
  };

  const getCurrentText = () => {
    if (!capsule?.timecoded_text) return null;
    return capsule.timecoded_text.find((t) => currentTime >= t.start_time && currentTime <= t.end_time);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  if (!capsule) return null;

  const catConfig = CATEGORIES[capsule.editorial_category] || { label: capsule.editorial_category, color: "text-white" };
  const currentText = getCurrentText();

  return (
    <div className="min-h-screen bg-black text-white pb-16">
      {/* Nav */}
      <div className="pt-24 px-6 max-w-3xl mx-auto">
        <Link to="/slaame-adulte" className="inline-flex items-center gap-2 text-white/40 hover:text-white text-xs tracking-widest uppercase mb-10 transition-colors">
          <ArrowLeft className="w-3 h-3" /> Retour
        </Link>

        {/* Header */}
        <p className={`text-xs tracking-widest uppercase mb-3 ${catConfig.color}`}>{catConfig.label}</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 7vw, 4.5rem)", lineHeight: 1 }} className="text-white mb-3">
          {capsule.title}
        </h1>
        {capsule.subtitle && <p className="text-white/50 text-lg mb-8">{capsule.subtitle}</p>}

        {/* Audio player */}
        {capsule.audio_url && (
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8">
            <audio
              ref={audioRef}
              src={capsule.audio_url}
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={(e) => setDuration(e.target.duration)}
              onEnded={() => setPlaying(false)}
            />

            {/* Texte synchronisé */}
            <div className="min-h-[60px] flex items-center justify-center mb-6">
              {currentText ? (
                <p className={`text-center text-xl leading-snug ${currentText.emphasis ? "text-white font-semibold" : "text-white/70"}`}>
                  {currentText.text}
                </p>
              ) : (
                <p className="text-white/20 text-sm italic">Appuyez sur lecture pour commencer</p>
              )}
            </div>

            {/* Progress */}
            <input
              type="range" min="0" max={duration || 100} value={currentTime}
              onChange={handleSeek}
              className="w-full accent-white mb-2"
            />
            <div className="flex justify-between text-xs text-white/30 mb-4">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-6">
              <button onClick={() => audioRef.current && (audioRef.current.currentTime = Math.max(0, currentTime - 10))} className="text-white/40 hover:text-white">
                <SkipBack className="w-5 h-5" />
              </button>
              <button onClick={togglePlay} className="w-14 h-14 bg-white rounded-full flex items-center justify-center hover:bg-white/90 transition-colors">
                {playing ? <Pause className="w-6 h-6 text-black" /> : <Play className="w-6 h-6 text-black ml-1" />}
              </button>
              <button onClick={() => audioRef.current && (audioRef.current.currentTime = Math.min(duration, currentTime + 10))} className="text-white/40 hover:text-white">
                <SkipForward className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Transcript */}
        {capsule.full_transcript && (
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8">
            <h3 className="text-white/40 text-xs tracking-widest uppercase mb-4">Transcription</h3>
            <p className="text-white/70 text-sm leading-relaxed whitespace-pre-wrap">{capsule.full_transcript}</p>
          </div>
        )}

        {/* Fiche éditoriale */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8">
          <h3 className="text-white/40 text-xs tracking-widest uppercase mb-4 flex items-center gap-2">
            <Shield className="w-3.5 h-3.5" /> Fiche éditoriale
          </h3>
          <div className="space-y-3 text-sm">
            {capsule.editorial_intent && (
              <div>
                <span className="text-white/30 block mb-1">Intention</span>
                <p className="text-white/70">{capsule.editorial_intent}</p>
              </div>
            )}
            {capsule.educational_goal && (
              <div>
                <span className="text-white/30 block mb-1">Objectif pédagogique</span>
                <p className="text-white/70">{capsule.educational_goal}</p>
              </div>
            )}
            {capsule.warnings?.length > 0 && (
              <div className="flex items-start gap-2 text-amber-400 pt-2">
                <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <div>
                  <span className="block mb-1 text-xs tracking-widest uppercase">Avertissements</span>
                  <ul className="list-disc list-inside text-white/60 text-xs space-y-1">
                    {capsule.warnings.map((w, i) => <li key={i}>{w}</li>)}
                  </ul>
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 text-green-400 text-xs pt-2 border-t border-white/5">
              <Shield className="w-3 h-3" />
              <span>Contenu licencié · Consentement vérifié · Performers majeurs</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <button className="flex items-center gap-2 text-white/40 hover:text-white text-sm transition-colors">
            <Share2 className="w-4 h-4" /> Partager
          </button>
          <button className="flex items-center gap-2 text-white/40 hover:text-red-400 text-sm transition-colors">
            <Flag className="w-4 h-4" /> Signaler
          </button>
        </div>
      </div>
    </div>
  );
}