import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Edit2, Save, X, Upload, Shield, AlertTriangle, Check, Clock, Eye, Mic } from "lucide-react";

const EDITORIAL_CATEGORIES = [
  { value: "consentement", label: "Consentement" },
  { value: "dialogue", label: "Dialogue" },
  { value: "limites", label: "Limites" },
  { value: "repair", label: "Réparation" },
  { value: "humour", label: "Humour" },
  { value: "slam", label: "Slam" },
  { value: "prevention", label: "Prévention" },
  { value: "ecoute", label: "Écoute" },
  { value: "pouvoir", label: "Pouvoir" },
  { value: "maladresse", label: "Maladresse" },
  { value: "excuses", label: "Excuses" },
];

const SCRIPT_MODES = [
  { value: "consentement", label: "Consentement" },
  { value: "dialogue", label: "Dialogue" },
  { value: "humour", label: "Humour" },
  { value: "slam", label: "Slam" },
  { value: "repair", label: "Réparation" },
  { value: "prevention", label: "Prévention" },
];

const VOICE_TYPES = [
  { value: "feminine", label: "Voix féminine" },
  { value: "masculine", label: "Voix masculine" },
  { value: "neutre", label: "Voix neutre" },
  { value: "grave", label: "Voix grave" },
  { value: "douce", label: "Voix douce" },
  { value: "directe", label: "Voix directe" },
  { value: "poetique", label: "Voix poétique" },
];

const SENSITIVITY_LEVELS = [
  { value: "low", label: "Faible" },
  { value: "medium", label: "Moyen" },
  { value: "high", label: "Élevé" },
  { value: "very_high", label: "Très élevé" },
];

const STATUSES = [
  { value: "draft", label: "Brouillon" },
  { value: "rights_incomplete", label: "Droits incomplets" },
  { value: "pending_verification", label: "À vérifier" },
  { value: "verified", label: "Validé" },
  { value: "published", label: "Publié" },
  { value: "archived", label: "Archivé" },
  { value: "removed", label: "Retiré" },
];

export default function AdminSlaame18() {
  const navigate = useNavigate();
  const [capsules, setCapsules] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [view, setView] = useState("list");

  const emptyCapsule = {
    title: "",
    subtitle: "",
    editorial_category: "consentement",
    video_url: "",
    video_thumbnail_url: "",
    video_source: "",
    video_license: "",
    license_documentation_url: "",
    performers_consent_verified: false,
    performers_age_verified: false,
    duration: 0,
    sensitivity_level: "medium",
    script_mode: "consentement",
    voice_type: "douce",
    audio_url: "",
    music_style: "none",
    timecoded_text: [],
    full_transcript: "",
    editorial_intent: "",
    educational_goal: "",
    warnings: [],
    status: "draft",
    is_blur_by_default: true,
    allow_text_only_mode: true,
  };

  useEffect(() => {
    base44.entities.AdultCapsule.list("-created_date", 50).then((c) => {
      setCapsules(c);
      setLoading(false);
    });
  }, []);

  const createCapsule = () => {
    setEditing({ ...emptyCapsule });
    setView("edit");
  };

  const saveCapsule = async () => {
    setSaving(true);
    try {
      if (editing.id) {
        await base44.entities.AdultCapsule.update(editing.id, editing);
      } else {
        await base44.entities.AdultCapsule.create(editing);
      }
      const updated = await base44.entities.AdultCapsule.list("-created_date", 50);
      setCapsules(updated);
      setView("list");
      setEditing(null);
    } catch (error) {
      console.error("Error saving capsule:", error);
    }
    setSaving(false);
  };

  const deleteCapsule = async (id) => {
    if (!confirm("Supprimer cette capsule ?")) return;
    await base44.entities.AdultCapsule.delete(id);
    setCapsules(capsules.filter((c) => c.id !== id));
  };

  const addTimecodedText = () => {
    setEditing({
      ...editing,
      timecoded_text: [
        ...editing.timecoded_text,
        { start_time: 0, end_time: 5, text: "", emphasis: false },
      ],
    });
  };

  const updateVideoFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const res = await base44.integrations.Core.UploadFile({ file });
    setEditing({ ...editing, video_url: res.file_url });
  };

  const updateThumbnailFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const res = await base44.integrations.Core.UploadFile({ file });
    setEditing({ ...editing, video_thumbnail_url: res.file_url });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (view === "edit" && editing) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div>
              <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-gray-900">
                {editing.id ? "Modifier la capsule" : "Nouvelle capsule 18+"}
              </h1>
              <p className="text-gray-500 text-sm">{editing.title || "Sans titre"}</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setView("list")}
                className="flex items-center gap-2 border border-gray-300 text-gray-700 px-4 py-2 text-xs tracking-widest uppercase hover:bg-gray-50 transition-colors rounded-full"
              >
                <X className="w-3 h-3" />
                Annuler
              </button>
              <button
                onClick={saveCapsule}
                disabled={saving}
                className="flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors disabled:opacity-50 rounded-full"
              >
                <Save className="w-3 h-3" />
                {saving ? "Enregistrement..." : "Enregistrer"}
              </button>
            </div>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-6 py-8 space-y-8">
          {/* Basic info */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-red-500" />
              Informations de base
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Titre *</label>
                <input
                  type="text"
                  value={editing.title}
                  onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                  placeholder="Ex : Le silence n'est pas une réponse"
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Sous-titre</label>
                <input
                  type="text"
                  value={editing.subtitle}
                  onChange={(e) => setEditing({ ...editing, subtitle: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                  placeholder="Ex : On ne devine pas une limite"
                />
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Catégorie éditoriale *</label>
                <select
                  value={editing.editorial_category}
                  onChange={(e) => setEditing({ ...editing, editorial_category: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                >
                  {EDITORIAL_CATEGORIES.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Niveau de sensibilité</label>
                <select
                  value={editing.sensitivity_level}
                  onChange={(e) => setEditing({ ...editing, sensitivity_level: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                >
                  {SENSITIVITY_LEVELS.map((s) => (
                    <option key={s.value} value={s.value}>{s.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </section>

          {/* Video */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <Upload className="w-4 h-4 text-red-500" />
              Vidéo
            </h2>
            <div className="space-y-4">
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Fichier vidéo</label>
                <input type="file" accept="video/*" onChange={updateVideoFile} className="text-sm" />
                {editing.video_url && (
                  <p className="text-green-600 text-xs mt-2 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Vidéo importée
                  </p>
                )}
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Miniature</label>
                <input type="file" accept="image/*" onChange={updateThumbnailFile} className="text-sm" />
                {editing.video_thumbnail_url && (
                  <div className="mt-2 w-32 h-20 overflow-hidden rounded border">
                    <img src={editing.video_thumbnail_url} alt="Thumbnail" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Source</label>
                  <input
                    type="text"
                    value={editing.video_source}
                    onChange={(e) => setEditing({ ...editing, video_source: e.target.value })}
                    className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                    placeholder="Nom du producteur/studio"
                  />
                </div>
                <div>
                  <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Licence</label>
                  <input
                    type="text"
                    value={editing.video_license}
                    onChange={(e) => setEditing({ ...editing, video_license: e.target.value })}
                    className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                    placeholder="Type de licence"
                  />
                </div>
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">URL documentation licence</label>
                <input
                  type="text"
                  value={editing.license_documentation_url}
                  onChange={(e) => setEditing({ ...editing, license_documentation_url: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                  placeholder="https://..."
                />
              </div>
            </div>
          </section>

          {/* Compliance */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              Conformité et droits
            </h2>
            <div className="space-y-3">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={editing.performers_consent_verified}
                  onChange={(e) => setEditing({ ...editing, performers_consent_verified: e.target.checked })}
                  className="w-4 h-4"
                />
                <span className="text-gray-700 text-sm">Consentement des performers vérifié et documenté</span>
              </label>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={editing.performers_age_verified}
                  onChange={(e) => setEditing({ ...editing, performers_age_verified: e.target.checked })}
                  className="w-4 h-4"
                />
                <span className="text-gray-700 text-sm">Majorité des performers vérifiée et documentée</span>
              </label>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mt-4">
                <p className="text-amber-800 text-xs">
                  <strong>Important :</strong> Ne publiez jamais de contenu sans preuves documentées de consentement 
                  et de majorité. Conservez les documents dans un endroit sécurisé.
                </p>
              </div>
            </div>
          </section>

          {/* Script */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <Mic className="w-4 h-4 text-red-500" />
              Script et voix
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Mode de script</label>
                <select
                  value={editing.script_mode}
                  onChange={(e) => setEditing({ ...editing, script_mode: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                >
                  {SCRIPT_MODES.map((m) => (
                    <option key={m.value} value={m.value}>{m.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Type de voix</label>
                <select
                  value={editing.voice_type}
                  onChange={(e) => setEditing({ ...editing, voice_type: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                >
                  {VOICE_TYPES.map((v) => (
                    <option key={v.value} value={v.value}>{v.label}</option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Intention éditoriale</label>
                <textarea
                  value={editing.editorial_intent}
                  onChange={(e) => setEditing({ ...editing, editorial_intent: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                  placeholder="Ce que cette capsule veut faire comprendre..."
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Objectif pédagogique</label>
                <textarea
                  value={editing.educational_goal}
                  onChange={(e) => setEditing({ ...editing, educational_goal: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 rounded-lg"
                  placeholder="Ce que l'utilisateur doit retenir..."
                />
              </div>
            </div>
          </section>

          {/* Timecoded text */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-gray-900 font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-red-500" />
                Texte synchronisé
              </h2>
              <button
                onClick={addTimecodedText}
                className="flex items-center gap-2 text-red-600 hover:text-red-700 text-xs tracking-widest uppercase"
              >
                <Plus className="w-3 h-3" />
                Ajouter
              </button>
            </div>
            {editing.timecoded_text.length === 0 ? (
              <p className="text-gray-500 text-sm">Aucun texte synchronisé. Ajoutez des phrases avec timecodes.</p>
            ) : (
              <div className="space-y-3">
                {editing.timecoded_text.map((t, i) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <input
                          type="number"
                          value={t.start_time}
                          onChange={(e) => {
                            const newText = [...editing.timecoded_text];
                            newText[i].start_time = parseFloat(e.target.value);
                            setEditing({ ...editing, timecoded_text: newText });
                          }}
                          className="w-20 border border-gray-300 px-2 py-1 text-sm rounded"
                          placeholder="Début (s)"
                        />
                        <span className="text-gray-400">→</span>
                        <input
                          type="number"
                          value={t.end_time}
                          onChange={(e) => {
                            const newText = [...editing.timecoded_text];
                            newText[i].end_time = parseFloat(e.target.value);
                            setEditing({ ...editing, timecoded_text: newText });
                          }}
                          className="w-20 border border-gray-300 px-2 py-1 text-sm rounded"
                          placeholder="Fin (s)"
                        />
                      </div>
                      <label className="flex items-center gap-2 text-xs">
                        <input
                          type="checkbox"
                          checked={t.emphasis}
                          onChange={(e) => {
                            const newText = [...editing.timecoded_text];
                            newText[i].emphasis = e.target.checked;
                            setEditing({ ...editing, timecoded_text: newText });
                          }}
                          className="w-3 h-3"
                        />
                        <span className="text-gray-600">Accentué</span>
                      </label>
                      <button
                        onClick={() => {
                          const newText = editing.timecoded_text.filter((_, idx) => idx !== i);
                          setEditing({ ...editing, timecoded_text: newText });
                        }}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    <textarea
                      value={t.text}
                      onChange={(e) => {
                        const newText = [...editing.timecoded_text];
                        newText[i].text = e.target.value;
                        setEditing({ ...editing, timecoded_text: newText });
                      }}
                      rows={2}
                      className="w-full border border-gray-300 px-3 py-2 text-sm rounded focus:outline-none focus:border-red-500"
                      placeholder="Texte à afficher..."
                    />
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Status */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <Eye className="w-4 h-4 text-red-500" />
              Statut
            </h2>
            <div className="flex flex-wrap gap-3">
              {STATUSES.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setEditing({ ...editing, status: s.value })}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${
                    editing.status === s.value
                      ? "bg-gray-900 text-white"
                      : "border border-gray-300 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
            <div className="mt-4 space-y-2">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={editing.is_blur_by_default}
                  onChange={(e) => setEditing({ ...editing, is_blur_by_default: e.target.checked })}
                  className="w-4 h-4"
                />
                <span className="text-gray-700 text-sm">Flou activé par défaut</span>
              </label>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={editing.allow_text_only_mode}
                  onChange={(e) => setEditing({ ...editing, allow_text_only_mode: e.target.checked })}
                  className="w-4 h-4"
                />
                <span className="text-gray-700 text-sm">Mode texte seul autorisé</span>
              </label>
            </div>
          </section>
        </main>
      </div>
    );
  }

  // List view
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div>
            <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-gray-900">
              SLAÂME 18+ — Admin
            </h1>
            <p className="text-gray-500 text-sm">Gérez les capsules adultes éducatives</p>
          </div>
          <button
            onClick={createCapsule}
            className="flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
          >
            <Plus className="w-3 h-3" />
            Nouvelle capsule
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        {capsules.length === 0 ? (
          <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
            <Shield className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 mb-6">Aucune capsule pour l'instant.</p>
            <button
              onClick={createCapsule}
              className="inline-flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
            >
              <Plus className="w-3 h-3" />
              Créer ma première capsule
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Titre</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Catégorie</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Statut</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Droits</th>
                  <th className="text-right text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {capsules.map((capsule) => (
                  <tr key={capsule.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="text-gray-900 font-medium">{capsule.title}</p>
                      {capsule.subtitle && <p className="text-gray-500 text-sm">{capsule.subtitle}</p>}
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-600 text-sm">{capsule.editorial_category}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-xs px-2 py-1 rounded ${
                        capsule.status === "published" ? "text-green-700 bg-green-100" :
                        capsule.status === "verified" ? "text-blue-700 bg-blue-100" :
                        capsule.status === "draft" ? "text-gray-500 bg-gray-100" :
                        "text-amber-700 bg-amber-100"
                      }`}>
                        {STATUSES.find((s) => s.value === capsule.status)?.label || capsule.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {capsule.performers_consent_verified && (
                          <span className="text-green-600 text-xs" title="Consentement vérifié">✓</span>
                        )}
                        {capsule.performers_age_verified && (
                          <span className="text-green-600 text-xs" title="Majorité vérifiée">✓</span>
                        )}
                        {!capsule.performers_consent_verified && !capsule.performers_age_verified && (
                          <span className="text-red-600 text-xs">⚠</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          to={`/slaame-18/${capsule.id}`}
                          className="text-gray-400 hover:text-blue-500 transition-colors"
                          target="_blank"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                        <button
                          onClick={() => { setEditing(capsule); setView("edit"); }}
                          className="text-gray-400 hover:text-amber-500 transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteCapsule(capsule.id)}
                          className="text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}