import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

export default function Collections() {
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Collection.list("order_index", 20).then((c) => {
      setCollections(c);
      setLoading(false);
    });
  }, []);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      {/* Header */}
      <section className="pt-32 pb-16 px-6 max-w-6xl mx-auto">
        <p className="text-red-500 tracking-widest uppercase text-xs mb-4">Bibliothèque</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 6rem)", lineHeight: 1 }}>
          Collections
        </h1>
        <p className="text-white/50 mt-4 max-w-xl">
          Des univers narratifs soigneusement composés — berceuses, aventures, fables, récits familiaux. Des thèmes, des émotions, des moments.
        </p>
      </section>

      {/* Grid */}
      <section className="max-w-6xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {collections.map((col) => (
            <Link key={col.id} to={`/collections/${col.slug}`} className="group relative overflow-hidden" style={{ aspectRatio: "16/9" }}>
              <img
                src={col.hero_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=800&q=80"}
                alt={col.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
              {col.mood_color && (
                <div className="absolute bottom-0 left-0 right-0 h-1" style={{ background: col.mood_color }} />
              )}
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <p className="text-red-500 text-xs tracking-widest uppercase mb-1">{col.audience}</p>
                <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}>
                  {col.title}
                </h2>
                <p className="text-white/60 text-sm mt-1 line-clamp-2">{col.tagline || col.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}