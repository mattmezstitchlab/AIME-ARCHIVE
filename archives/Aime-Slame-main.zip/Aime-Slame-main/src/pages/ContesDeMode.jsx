import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { BookOpen, ShoppingBag, Heart, Music, Palette, Users, Sparkles, ArrowRight } from "lucide-react";

const THEMES = {
  mariage: { label: "Mariage", icon: Heart, color: "text-pink-400" },
  anniversaire: { label: "Anniversaire", icon: Sparkles, color: "text-amber-400" },
  enfance: { label: "Enfance", icon: Users, color: "text-blue-400" },
  precarite: { label: "Précarité", icon: Heart, color: "text-slate-400" },
  solidarite: { label: "Solidarité", icon: Heart, color: "text-green-400" },
  famille: { label: "Famille", icon: Users, color: "text-purple-400" },
  bal: { label: "Bal", icon: Music, color: "text-rose-400" },
  rentree: { label: "Rentrée", icon: BookOpen, color: "text-indigo-400" },
  fete: { label: "Fête", icon: Sparkles, color: "text-yellow-400" },
  feerique: { label: "Féerique", icon: Sparkles, color: "text-cyan-400" },
  urbain: { label: "Urbain", icon: ShoppingBag, color: "text-gray-400" },
  social: { label: "Social", icon: Users, color: "text-emerald-400" },
  romantique: { label: "Romantique", icon: Heart, color: "text-red-400" },
  drole: { label: "Drôle", icon: Sparkles, color: "text-orange-400" },
  musical: { label: "Musical", icon: Music, color: "text-violet-400" },
  saison: { label: "Saison", icon: Sparkles, color: "text-teal-400" },
};

export default function ContesDeMode() {
  const [tales, setTales] = useState([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.FashionTale.filter({ status: "published" }, "-created_date", 50),
      base44.auth.me().catch(() => null),
    ]).then(([t, u]) => {
      setTales(t);
      setUser(u);
      setLoading(false);
    });
  }, []);

  const filtered = filter === "all" ? tales : tales.filter((t) => t.theme === filter || (filter === "solidarity" && t.is_solidarity));

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-96 h-96 bg-amber-500 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-pink-500 rounded-full blur-3xl" />
        </div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Magazine vivant</p>
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(4rem, 10vw, 7rem)", lineHeight: 1 }} className="mb-6 text-white">
            Contes de Mode
          </h1>
          <p className="text-xl text-white/60 max-w-3xl mb-8 leading-relaxed">
            Des histoires illustrées où les vêtements existent vraiment. Chaque conte devient un univers visuel, sonore et habillable.
          </p>
          
          <div className="flex flex-wrap gap-4 mb-12">
            <a href="#contes" className="bg-amber-500 text-black px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full">
              Découvrir les contes
            </a>
            {user?.role === "admin" && (
              <Link to="/admin/contes-de-mode" className="border border-white/20 text-white px-8 py-3 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-full">
                Créer depuis l'admin
              </Link>
            )}
          </div>

          {/* Example preview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-16">
            {[
              { img: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&q=80", title: "Robes de mariée", count: "8 contes" },
              { img: "https://images.unsplash.com/photo-1594911727969-845b84e15397?w=600&q=80", title: "Costumes", count: "5 contes" },
              { img: "https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=600&q=80", title: "Enfance", count: "12 contes" },
              { img: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=600&q=80", title: "Solidaire", count: "3 contes" },
            ].map((cat, i) => (
              <div key={i} className="relative overflow-hidden rounded-2xl aspect-[3/4] group cursor-pointer">
                <img src={cat.img} alt={cat.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.5rem" }} className="text-white">{cat.title}</h3>
                  <p className="text-white/60 text-xs">{cat.count}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Filtres — menu déroulant */}
      <section className="px-6 py-8 border-y border-white/10">
        <div className="max-w-6xl mx-auto">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-white/5 border border-white/20 text-white text-sm px-4 py-2.5 rounded-full focus:outline-none focus:border-amber-500 cursor-pointer appearance-none pr-8"
            style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 12px center" }}
          >
            <option value="all" className="bg-black">Tous les thèmes</option>
            {Object.entries(THEMES).map(([key, theme]) => (
              <option key={key} value={key} className="bg-black">{theme.label}</option>
            ))}
            <option value="solidarity" className="bg-black">Solidaire</option>
          </select>
        </div>
      </section>

      {/* Grille des contes */}
      <section id="contes" className="max-w-6xl mx-auto px-6 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="text-white">
              {filter === "all" ? "Tous les contes" : THEMES[filter]?.label || "Contes"}
            </h2>
            <p className="text-white/40 text-sm mt-2">
              {filtered.length} {filtered.length === 1 ? "conte" : "contes"} disponible{filtered.length > 1 ? "s" : ""}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
          </div>
        ) : filtered.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map((tale) => {
              const ThemeIcon = THEMES[tale.theme]?.icon || BookOpen;
              const themeConfig = THEMES[tale.theme] || { label: tale.theme, color: "text-gray-400" };
              
              return (
                <div key={tale.id} className="group bg-white/5 border border-white/10 rounded-2xl overflow-hidden hover:border-amber-500/30 transition-all duration-300">
                  {/* Cover */}
                  <div className="relative overflow-hidden aspect-[3/4]">
                    <img
                      src={tale.cover_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600&q=80"}
                      alt={tale.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      onError={(e) => { e.target.src = "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600&q=80"; }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    
                    {/* Badges */}
                    <div className="absolute top-4 left-4 flex flex-col gap-2">
                      <span className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${themeConfig.color} bg-black/60 backdrop-blur`}>
                        <ThemeIcon className="w-3 h-3" />
                        {themeConfig.label}
                      </span>
                      {tale.is_solidarity && (
                        <span className="px-3 py-1 rounded-full text-xs font-medium text-green-400 bg-green-900/60 backdrop-blur">
                          Solidaire
                        </span>
                      )}
                    </div>

                    {/* Quick stats */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white/80 text-xs">
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        {tale.scenes?.length || 0} scènes
                      </span>
                      <span className="flex items-center gap-1">
                        <ShoppingBag className="w-3 h-3" />
                        {tale.characters?.reduce((sum, c) => sum + (c.product_ids?.length || 0), 0) || 0} articles
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }} className="text-white mb-2 truncate">
                      {tale.title}
                    </h3>
                    {tale.subtitle && (
                      <p className="text-white/40 text-sm mb-4 line-clamp-2">{tale.subtitle}</p>
                    )}
                    <p className="text-white/30 text-xs mb-4">{tale.target_audience}</p>
                    
                    <div className="flex gap-3">
                      <Link
                        to={`/contes-de-mode/${tale.id}`}
                        className="flex-1 bg-amber-500 text-black text-center px-4 py-2.5 text-xs tracking-widest uppercase hover:bg-amber-400 transition-colors rounded-full"
                      >
                        Lire le conte
                      </Link>
                      <Link
                        to={`/contes-de-mode/${tale.id}#looks`}
                        className="flex items-center gap-2 border border-white/20 text-white px-4 py-2.5 text-xs tracking-widest uppercase hover:border-white/60 transition-colors rounded-full"
                      >
                        <ShoppingBag className="w-3 h-3" />
                        Looks
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-white/20 mx-auto mb-6" />
            <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="text-white mb-2">
              Aucun conte pour l'instant
            </h3>
            <p className="text-white/40 mb-8 max-w-md mx-auto">
              Les premiers contes de mode seront bientôt disponibles. Découvrez des histoires où les vêtements existent vraiment.
            </p>
            {user?.role === "admin" && (
              <Link to="/admin/contes-de-mode" className="inline-flex items-center gap-2 bg-amber-500 text-black px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full">
                <Sparkles className="w-4 h-4" />
                Créer le premier conte
              </Link>
            )}
          </div>
        )}
      </section>

      {/* Transparence */}
      <section className="border-t border-white/10 py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-white/40 text-sm leading-relaxed">
            Les vêtements présentés sont des articles réels proposés par des partenaires ou via des liens affiliés. 
            Les prix, tailles et disponibilités peuvent évoluer. Les illustrations sont inspirées de produits réels, 
            les détails exacts peuvent varier.
          </p>
        </div>
      </section>
    </div>
  );
}