import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { analyzeLabDeposit } from "@/functions/analyzeLabDeposit";
import {
  Plus, Image, Link as LinkIcon,
  Sparkles, Shield, Loader2, ArrowRight
} from "lucide-react";

const OBJECTIVES = [
  { value: "vendre", label: "Vendre un bien ou service" },
  { value: "transmettre", label: "Transmettre un souvenir" },
  { value: "inviter", label: "Inviter à un événement" },
  { value: "creer_souvenir", label: "Créer un souvenir" },
  { value: "generer_audio", label: "Générer un audio" },
  { value: "generer_page", label: "Générer une page" },
  { value: "aider", label: "Aider ou sensibiliser" },
  { value: "generer_annonce", label: "Générer une annonce" },
];

const KEYWORDS_SUGGESTIONS = [
  "mariage", "maison", "événement", "solidarité",
  "mémoire", "anniversaire", "famille", "mode", "immobilier",
];

export default function SlaameStudio() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [linkInput, setLinkInput] = useState("");
  const [showLinkInput, setShowLinkInput] = useState(false);
  const attachRef = useRef(null);

  const [deposit, setDeposit] = useState({
    title: "",
    text_content: "",
    image_urls: [],
    links: [],
    keywords: [],
    objectives: [],
  });

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  useEffect(() => {
    const handleClick = (e) => {
      if (attachRef.current && !attachRef.current.contains(e.target)) setShowAttachMenu(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setShowAttachMenu(false);
    const res = await base44.integrations.Core.UploadFile({ file });
    setDeposit((d) => ({ ...d, image_urls: [...d.image_urls, res.file_url] }));
  };

  const handleAddLink = () => {
    if (linkInput.trim()) {
      setDeposit((d) => ({ ...d, links: [...d.links, linkInput.trim()] }));
      setLinkInput("");
      setShowLinkInput(false);
    }
  };

  const toggleObjective = (val) => {
    setDeposit((d) => ({
      ...d,
      objectives: d.objectives.includes(val)
        ? d.objectives.filter((o) => o !== val)
        : [...d.objectives, val],
    }));
  };

  const toggleKeyword = (kw) => {
    setDeposit((d) => ({
      ...d,
      keywords: d.keywords.includes(kw)
        ? d.keywords.filter((k) => k !== kw)
        : [...d.keywords, kw],
    }));
  };

  const analyzeAndGenerate = async () => {
    if (!deposit.text_content.trim() && deposit.image_urls.length === 0 && deposit.links.length === 0) return;
    setAnalyzing(true);
    try {
      const newDeposit = await base44.entities.LabDeposit.create({
        ...deposit,
        title: deposit.title || deposit.text_content.slice(0, 60) || "Dépôt sans titre",
        user_id: user?.id,
        status: "analyzing",
      });
      await analyzeLabDeposit({ depositId: newDeposit.id });
      navigate(`/slaame-lab/${newDeposit.id}`);
    } catch (error) {
      setAnalyzing(false);
    }
  };

  const canSubmit = deposit.text_content.trim() || deposit.image_urls.length > 0 || deposit.links.length > 0;

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      {/* HERO */}
      <section className="relative h-[40vh] min-h-[300px] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1600&q=80"
            alt="SLAÂME Studio"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0806] via-black/30 to-transparent" />
        </div>
        <div className="relative z-10 max-w-5xl mx-auto px-6 pb-10 w-full">
          <p className="text-red-500 tracking-widest uppercase text-xs mb-2">Atelier créatif</p>
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 8vw, 6rem)", lineHeight: 1 }}>
            SLAÂME Studio
          </h1>
          <p className="text-white/50 text-sm mt-2">
            Immobilier, événements, mode, capsules mémoire — déposez votre projet.
          </p>
        </div>
      </section>

      {/* FORM */}
      <section className="max-w-3xl mx-auto px-6 py-10 pb-28">
        <div className="space-y-8">

          {/* Objectifs */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-3">Votre objectif</p>
            <div className="grid grid-cols-2 gap-2">
              {OBJECTIVES.map((obj) => {
                const selected = deposit.objectives.includes(obj.value);
                return (
                  <button
                    key={obj.value}
                    onClick={() => toggleObjective(obj.value)}
                    className={`px-4 py-3 rounded-xl text-sm text-left transition-all border ${
                      selected
                        ? "bg-red-600/20 border-red-500 text-white"
                        : "border-white/10 text-white/60 hover:border-white/30 hover:text-white"
                    }`}
                  >
                    {obj.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mots-clés */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-3">Mots-clés</p>
            <div className="flex flex-wrap gap-2">
              {KEYWORDS_SUGGESTIONS.map((kw) => (
                <button
                  key={kw}
                  onClick={() => toggleKeyword(kw)}
                  className={`px-3 py-1.5 text-xs rounded-full transition-colors ${
                    deposit.keywords.includes(kw)
                      ? "bg-red-600 text-white"
                      : "bg-white/5 text-white/50 hover:text-white border border-white/10"
                  }`}
                >
                  {kw}
                </button>
              ))}
            </div>
          </div>

          {/* Matière brute */}
          <div>
            <p className="text-white/40 text-xs tracking-widest uppercase mb-3">Décrivez votre projet</p>
            <div className="border border-white/15 rounded-2xl overflow-hidden focus-within:border-white/30 transition-colors">
              {deposit.image_urls.length > 0 && (
                <div className="flex gap-2 p-3 border-b border-white/10 overflow-x-auto">
                  {deposit.image_urls.map((url, i) => (
                    <div key={i} className="relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={url} alt="" className="w-full h-full object-cover" />
                      <button
                        onClick={() => setDeposit(d => ({ ...d, image_urls: d.image_urls.filter((_, j) => j !== i) }))}
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/70 flex items-center justify-center text-white text-[10px]"
                      >×</button>
                    </div>
                  ))}
                </div>
              )}

              {deposit.links.length > 0 && (
                <div className="flex flex-wrap gap-2 px-4 pt-3 pb-3 border-b border-white/10">
                  {deposit.links.map((link, i) => (
                    <span key={i} className="flex items-center gap-1.5 bg-white/5 border border-white/10 px-3 py-1 rounded-full text-xs text-white/60">
                      <LinkIcon className="w-3 h-3 text-red-400" />
                      {link.length > 35 ? link.slice(0, 35) + "…" : link}
                      <button onClick={() => setDeposit(d => ({ ...d, links: d.links.filter((_, j) => j !== i) }))} className="hover:text-white ml-1">×</button>
                    </span>
                  ))}
                </div>
              )}

              {showLinkInput && (
                <div className="flex gap-2 px-4 py-3 border-b border-white/10">
                  <input
                    autoFocus
                    type="url"
                    value={linkInput}
                    onChange={(e) => setLinkInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleAddLink(); } if (e.key === "Escape") setShowLinkInput(false); }}
                    placeholder="Coller un lien…"
                    className="flex-1 bg-transparent text-sm text-white placeholder-white/30 focus:outline-none"
                  />
                  <button onClick={handleAddLink} className="text-xs text-red-400 hover:text-red-300">Ajouter</button>
                  <button onClick={() => setShowLinkInput(false)} className="text-xs text-white/30 hover:text-white">Annuler</button>
                </div>
              )}

              <textarea
                value={deposit.text_content}
                onChange={(e) => setDeposit({ ...deposit, text_content: e.target.value })}
                placeholder="Décrivez votre bien, votre événement, votre projet…"
                rows={6}
                className="w-full bg-transparent text-white text-sm px-4 py-4 focus:outline-none resize-none placeholder-white/25"
              />

              <div className="flex items-center justify-between px-3 py-2 border-t border-white/10">
                <div className="flex items-center gap-1" ref={attachRef}>
                  <div className="relative">
                    <button
                      onClick={() => setShowAttachMenu(!showAttachMenu)}
                      className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white/50 hover:text-white hover:border-white/50 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    {showAttachMenu && (
                      <div className="absolute bottom-full mb-2 left-0 bg-[#1a1512] border border-white/10 rounded-xl overflow-hidden shadow-2xl w-44 z-50">
                        <label className="flex items-center gap-3 px-4 py-3 text-sm text-white/70 hover:bg-white/5 cursor-pointer border-b border-white/5">
                          <Image className="w-4 h-4 text-red-400" /> Importer une image
                          <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                        </label>
                        <button
                          onClick={() => { setShowLinkInput(true); setShowAttachMenu(false); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white/70 hover:bg-white/5"
                        >
                          <LinkIcon className="w-4 h-4 text-red-400" /> Ajouter un lien
                        </button>
                      </div>
                    )}
                  </div>
                  <span className="text-white/20 text-xs ml-2">Photo · Lien</span>
                </div>

                <button
                  onClick={analyzeAndGenerate}
                  disabled={analyzing || !canSubmit}
                  className="flex items-center gap-2 bg-red-600 hover:bg-red-500 disabled:opacity-30 text-white text-xs tracking-wider uppercase px-5 py-2 rounded-full transition-colors"
                >
                  {analyzing
                    ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Analyse…</>
                    : <><ArrowRight className="w-3.5 h-3.5" /> Révéler</>
                  }
                </button>
              </div>
            </div>
          </div>

          <p className="text-white/25 text-xs flex items-center gap-1.5">
            <Shield className="w-3 h-3" /> Rien n'est publié sans votre validation.
          </p>
        </div>
      </section>
    </div>
  );
}