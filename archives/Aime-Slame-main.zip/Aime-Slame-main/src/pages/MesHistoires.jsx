import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Eye, EyeOff, Archive, Trash2, Plus, Camera, Edit2, Check, X, User, BookOpen } from "lucide-react";
import ProfileSwitcher from "@/components/profile/ProfileSwitcher";
import RoleAdaptedDashboard from "@/components/profile/RoleAdaptedDashboard";
import RoleOnboarding from "@/components/profile/RoleOnboarding";
import RoleTemplates from "@/components/profile/RoleTemplates";
import RoleContentFeed from "@/components/profile/RoleContentFeed";
import RoleGoals from "@/components/profile/RoleGoals";

const STATUS_LABELS = { draft: "Brouillon", generated: "Généré", audio_ready: "Audio prêt", published: "Publié", archived: "Archivé" };
const STATUS_COLORS = { draft: "text-white/40", generated: "text-blue-400", audio_ready: "text-green-400", published: "text-red-400", archived: "text-white/20" };

export default function MesHistoires() {
  const [user, setUser] = useState(null);
  const [stories, setStories] = useState([]);
  const [authorPresence, setAuthorPresence] = useState(null);
  const [currentProfile, setCurrentProfile] = useState(null);
  const [userProfiles, setUserProfiles] = useState([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [editingBio, setEditingBio] = useState(false);
  const [bio, setBio] = useState("");
  const [savingBio, setSavingBio] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [creatingProfile, setCreatingProfile] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.StoryProject.list("-created_date", 50),
      base44.entities.UserProfile.filter({ is_active: true }),
    ]).then(([me, s, profiles]) => {
      setUser(me);
      setBio(me?.bio || "");
      setStories(s);
      setUserProfiles(profiles);
      const defaultProfile = profiles.find((p) => p.is_default) || profiles[0];
      setCurrentProfile(defaultProfile || null);
      // Fetch user's AuthorPresence
      if (me?.id) {
        base44.entities.AuthorPresence.filter({ user_id: me.id }).then((profiles) => {
          setAuthorPresence(profiles[0] || null);
        });
      }
      setLoading(false);
    });
  }, []);

  const update = async (id, data) => {
    await base44.entities.StoryProject.update(id, data);
    setStories((s) => s.map((x) => (x.id === id ? { ...x, ...data } : x)));
  };

  const remove = async (id) => {
    await base44.entities.StoryProject.delete(id);
    setStories((s) => s.filter((x) => x.id !== id));
  };

  const saveBio = async () => {
    setSavingBio(true);
    await base44.auth.updateMe({ bio });
    setUser((u) => ({ ...u, bio }));
    setSavingBio(false);
    setEditingBio(false);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    const res = await base44.integrations.Core.UploadFile({ file });
    await base44.auth.updateMe({ avatar_url: res.file_url });
    setUser((u) => ({ ...u, avatar_url: res.file_url }));
    setUploadingAvatar(false);
  };

  const createAuthorProfile = async () => {
    setCreatingProfile(true);
    const profile = await base44.entities.AuthorPresence.create({
      user_id: user.id,
      public_name: user.full_name || user.email?.split("@")[0] || "Conteur",
      presence_type: "conteur",
      visibility: "public",
      short_bio: bio || "",
      portrait_url: user.avatar_url || "",
    });
    setAuthorPresence(profile);
    setCreatingProfile(false);
  };

  const filtered = filter === "all" ? stories : stories.filter((s) => s.status === filter);
  const publishedCount = stories.filter((s) => s.visibility === "public" && s.status === "published").length;

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
    </div>
  );

  // Show onboarding if no profiles exist
  if (!loading && userProfiles.length === 0) {
    return <RoleOnboarding onComplete={(profile) => { setUserProfiles([profile]); setCurrentProfile(profile); }} />;
  }

  return (
    <div className="min-h-screen text-white pt-16" style={{ background: "#0a0806" }}>
      {/* Profile Switcher */}
      <ProfileSwitcher currentProfileId={currentProfile?.id} onSwitchProfile={setCurrentProfile} />

      {/* Profile Hero */}
      <section className="pt-12 pb-12 px-6 border-b border-white/5">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-start md:items-end gap-8">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-24 h-24 md:w-32 md:h-32 overflow-hidden bg-white/5 border border-white/10">
              {user?.avatar_url ? (
                <img src={user.avatar_url} alt={user.full_name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="text-white/20">
                    {user?.full_name?.[0] || "?"}
                  </span>
                </div>
              )}
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadingAvatar}
              className="absolute -bottom-2 -right-2 w-8 h-8 bg-red-600 flex items-center justify-center hover:bg-red-500 transition-colors"
            >
              {uploadingAvatar
                ? <div className="w-3 h-3 border border-black/40 border-t-black rounded-full animate-spin" />
                : <Camera className="w-3.5 h-3.5 text-black" />
              }
            </button>
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
          </div>

          {/* Identity */}
          <div className="flex-1">
            <p className="text-red-500 tracking-widest uppercase text-xs mb-1">
              {currentProfile ? `Profil ${currentProfile.profile_type.replace("_", " ")}` : "Mon espace"}
            </p>
            <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)", lineHeight: 1 }}>
              {currentProfile?.profile_name || user?.full_name || user?.email?.split("@")[0] || "Conteur"}
            </h1>

            {/* Bio */}
            <div className="mt-3 max-w-xl">
              {editingBio ? (
                <div className="flex gap-2 items-start">
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Qui êtes-vous en tant que conteur ?"
                    rows={2}
                    className="flex-1 bg-white/5 border border-red-500/50 text-white text-sm px-3 py-2 focus:outline-none resize-none"
                  />
                  <div className="flex flex-col gap-1">
                    <button onClick={saveBio} disabled={savingBio} className="p-1.5 bg-red-600 hover:bg-red-500 text-white transition-colors">
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => { setEditingBio(false); setBio(user?.bio || ""); }} className="p-1.5 border border-white/20 text-white/60 hover:text-white transition-colors">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-2 group/bio">
                  <p className="text-white/50 text-sm leading-relaxed">
                    {user?.bio || <span className="italic text-white/30">Ajoutez une courte présentation…</span>}
                  </p>
                  <button onClick={() => setEditingBio(true)} className="opacity-0 group-hover/bio:opacity-100 transition-opacity mt-0.5 flex-shrink-0">
                    <Edit2 className="w-3 h-3 text-white/40 hover:text-red-500" />
                  </button>
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex gap-6 mt-4">
              <div>
                <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }} className="text-red-500">{stories.length}</span>
                <p className="text-white/30 text-xs tracking-widest uppercase">Contes</p>
              </div>
              <div>
                <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem" }} className="text-white">{publishedCount}</span>
                <p className="text-white/30 text-xs tracking-widest uppercase">Publiés</p>
              </div>
            </div>

            {/* Author Profile CTA */}
            {!authorPresence && (
              <div className="mt-6 p-4 border border-white/10 bg-white/5">
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-white/80 text-sm mb-2">Créez votre profil public de conteur pour apparaître dans le Registre.</p>
                    <button
                      onClick={createAuthorProfile}
                      disabled={creatingProfile}
                      className="bg-red-600 text-white px-4 py-2 text-xs tracking-widest uppercase hover:bg-red-500 transition-colors disabled:opacity-50 rounded-full"
                    >
                      {creatingProfile ? "Création..." : "Créer mon profil"}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-3 flex-shrink-0">
            {authorPresence && (
              <Link to={`/conteur/${authorPresence.id}`} className="flex items-center gap-2 border border-white/20 text-white px-6 py-3 text-xs tracking-widest uppercase hover:border-white/60 transition-colors rounded-full">
                <User className="w-4 h-4" /> Voir mon profil
              </Link>
            )}
            <Link to="/slaame-lab" className="flex items-center gap-2 bg-red-600 text-white px-6 py-3 text-xs font-medium tracking-widest uppercase hover:bg-red-500 transition-colors rounded-full">
              <Plus className="w-4 h-4" /> Nouveau conte
            </Link>
          </div>
        </div>
      </section>

      {/* Role-Adapted Dashboard */}
      {currentProfile && (
        <>
          <section className="max-w-5xl mx-auto px-6 pt-8">
            <RoleAdaptedDashboard profile={currentProfile} stories={stories} events={[]} />
          </section>

          {/* Role Templates */}
          <section className="max-w-5xl mx-auto px-6 pt-8">
            <RoleTemplates profile={currentProfile} />
          </section>

          {/* Content Feed */}
          <section className="max-w-5xl mx-auto px-6 pt-8">
            <RoleContentFeed profile={currentProfile} />
          </section>

          {/* Goals & Progress */}
          <section className="max-w-5xl mx-auto px-6 pt-8 pb-12">
            <RoleGoals profile={currentProfile} stories={stories} />
          </section>
        </>
      )}

      {/* Stories */}
      <section className="max-w-5xl mx-auto px-6 pt-8 pb-20">
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
          {["all", ...Object.keys(STATUS_LABELS)].map((s) => (
            <button key={s} onClick={() => setFilter(s)}
              className={`px-4 py-2 text-xs tracking-widest uppercase whitespace-nowrap transition-colors rounded-full ${filter === s ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
              {s === "all" ? "Tous" : STATUS_LABELS[s]}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-6">
            <BookOpen className="w-8 h-8 text-red-500" />
            </div>
            <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white mb-2">
              {filter === "all" ? "Aucun conte pour l'instant" : `Aucun conte ${STATUS_LABELS[filter]}`}
            </h3>
            <p className="text-white/40 mb-6 max-w-md mx-auto">
              {filter === "all" 
                ? "Créez votre premier conte illustré en quelques clics. L'IA rédige l'histoire, génère les illustrations et l'audio avec votre voix."
                : "Changez de filtre ou créez un nouveau conte."}
            </p>
            {filter === "all" && (
              <Link to="/slaame-lab" className="inline-flex items-center gap-2 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors rounded-full">
                <Plus className="w-4 h-4" /> Créer mon premier conte
              </Link>
            )}
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            {filtered.map((story) => (
              <div key={story.id} className="flex items-center gap-4 py-4 group">
                <div className="w-14 h-20 flex-shrink-0 overflow-hidden">
                  <img
                    src={story.hero_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=200&q=80"}
                    alt={story.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <Link to={`/conte/${story.id}`} className="hover:text-red-500 transition-colors">
                    <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.2rem" }} className="truncate">{story.title}</h3>
                  </Link>
                  {story.tagline && <p className="text-white/40 text-xs truncate mt-0.5">{story.tagline}</p>}
                  <div className="flex gap-3 mt-1">
                    <span className={`text-xs ${STATUS_COLORS[story.status]}`}>{STATUS_LABELS[story.status]}</span>
                    {story.story_type && <span className="text-white/20 text-xs">{story.story_type.replace(/_/g, " ")}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => update(story.id, { visibility: story.visibility === "public" ? "private" : "public" })}
                    className="text-white/40 hover:text-white transition-colors p-1" title="Changer la visibilité">
                    {story.visibility === "public" ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button onClick={() => update(story.id, { status: "archived" })}
                    className="text-white/40 hover:text-red-500 transition-colors p-1" title="Archiver">
                    <Archive className="w-4 h-4" />
                  </button>
                  <button onClick={() => remove(story.id)}
                    className="text-white/40 hover:text-red-400 transition-colors p-1" title="Supprimer">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}