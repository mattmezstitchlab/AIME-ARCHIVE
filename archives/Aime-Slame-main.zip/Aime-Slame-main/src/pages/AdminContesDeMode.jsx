import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Edit2, Save, X, Upload, Link as LinkIcon, Users, BookOpen, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";

const THEMES = [
  { value: "mariage", label: "Mariage" },
  { value: "anniversaire", label: "Anniversaire" },
  { value: "enfance", label: "Enfance" },
  { value: "precarite", label: "Précarité" },
  { value: "solidarite", label: "Solidarité" },
  { value: "famille", label: "Famille" },
  { value: "bal", label: "Bal" },
  { value: "rentree", label: "Rentrée" },
  { value: "fete", label: "Fête" },
  { value: "feerique", label: "Féerique" },
  { value: "urbain", label: "Urbain" },
  { value: "social", label: "Social" },
  { value: "romantique", label: "Romantique" },
  { value: "drole", label: "Drôle" },
  { value: "musical", label: "Musical" },
  { value: "saison", label: "Saison" },
];

const AUDIENCES = [
  { value: "enfants", label: "Enfants" },
  { value: "ados", label: "Ados" },
  { value: "adultes", label: "Adultes" },
  { value: "famille", label: "Famille" },
  { value: "tous", label: "Tous" },
];

export default function AdminContesDeMode() {
  const navigate = useNavigate();
  const [tales, setTales] = useState([]);
  const [editing, setEditing] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [view, setView] = useState("list"); // list | edit | products

  const emptyTale = {
    title: "",
    subtitle: "",
    theme: "mariage",
    target_audience: "famille",
    summary: "",
    full_story: "",
    narrative_style: "",
    music_style: "",
    cover_image_url: "",
    scenes: [],
    characters: [],
    is_solidarity: false,
    solidarity_description: "",
    status: "draft",
  };

  const emptyProduct = {
    title: "",
    description: "",
    price: null,
    partner_url: "",
    partner_name: "",
    image_url: "",
    category: "robe",
    colors: [],
    sizes: [],
    character_name: "",
    scene_number: null,
    purpose: "achat_perso",
    is_affiliate: true,
  };

  useEffect(() => {
    Promise.all([
      base44.entities.FashionTale.list("-created_date", 50),
      base44.entities.FashionProduct.list("-created_date", 200),
    ]).then(([t, p]) => {
      setTales(t);
      setProducts(p);
      setLoading(false);
    });
  }, []);

  const createTale = async () => {
    setEditing({ ...emptyTale });
    setView("edit");
  };

  const saveTale = async () => {
    setSaving(true);
    try {
      if (editing.id) {
        await base44.entities.FashionTale.update(editing.id, editing);
      } else {
        await base44.entities.FashionTale.create(editing);
      }
      const updated = await base44.entities.FashionTale.list("-created_date", 50);
      setTales(updated);
      setView("list");
      setEditing(null);
    } catch (error) {
      console.error("Error saving tale:", error);
    }
    setSaving(false);
  };

  const deleteTale = async (id) => {
    if (!confirm("Supprimer ce conte ?")) return;
    await base44.entities.FashionTale.delete(id);
    setTales(tales.filter((t) => t.id !== id));
  };

  const addScene = () => {
    setEditing({
      ...editing,
      scenes: [
        ...editing.scenes,
        {
          scene_number: editing.scenes.length + 1,
          title: `Scène ${editing.scenes.length + 1}`,
          text: "",
          illustration_url: "",
          illustration_prompt: "",
          characters: [],
          product_ids: [],
        },
      ],
    });
  };

  const addCharacter = () => {
    setEditing({
      ...editing,
      characters: [
        ...editing.characters,
        { name: "", role: "", age_category: "", description: "", style: "", product_ids: [] },
      ],
    });
  };

  const filteredProducts = editing ? products.filter((p) => p.fashion_tale_id === editing.id) : [];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (view === "edit" && editing) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div>
              <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-gray-900">
                {editing.id ? "Modifier le conte" : "Nouveau conte de mode"}
              </h1>
              <p className="text-gray-500 text-sm">{editing.title || "Sans titre"}</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setView("products")}
                className="flex items-center gap-2 border border-gray-300 text-gray-700 px-4 py-2 text-xs tracking-widest uppercase hover:bg-gray-50 transition-colors rounded-full"
              >
                <LinkIcon className="w-3 h-3" />
                Produits ({filteredProducts.length})
              </button>
              <button
                onClick={() => setView("list")}
                className="flex items-center gap-2 border border-gray-300 text-gray-700 px-4 py-2 text-xs tracking-widest uppercase hover:bg-gray-50 transition-colors rounded-full"
              >
                <X className="w-3 h-3" />
                Annuler
              </button>
              <button
                onClick={saveTale}
                disabled={saving}
                className="flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors disabled:opacity-50 rounded-full"
              >
                <Save className="w-3 h-3" />
                {saving ? "Enregistrement..." : "Enregistrer"}
              </button>
            </div>
          </div>
        </header>

        {/* Form */}
        <main className="max-w-5xl mx-auto px-6 py-8 space-y-8">
          {/* Basic info */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-500" />
              Informations de base
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Titre *</label>
                <input
                  type="text"
                  value={editing.title}
                  onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Ex : La Robe du Jardin Bleu"
                />
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Sous-titre</label>
                <input
                  type="text"
                  value={editing.subtitle}
                  onChange={(e) => setEditing({ ...editing, subtitle: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Ex : Un mariage poétique"
                />
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Thème *</label>
                <select
                  value={editing.theme}
                  onChange={(e) => setEditing({ ...editing, theme: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                >
                  {THEMES.map((t) => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Public cible *</label>
                <select
                  value={editing.target_audience}
                  onChange={(e) => setEditing({ ...editing, target_audience: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                >
                  {AUDIENCES.map((a) => (
                    <option key={a.value} value={a.value}>{a.label}</option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Résumé</label>
                <textarea
                  value={editing.summary}
                  onChange={(e) => setEditing({ ...editing, summary: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Court résumé du conte..."
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Histoire complète</label>
                <textarea
                  value={editing.full_story}
                  onChange={(e) => setEditing({ ...editing, full_story: e.target.value })}
                  rows={8}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Le conte complet..."
                />
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Style narratif</label>
                <input
                  type="text"
                  value={editing.narrative_style}
                  onChange={(e) => setEditing({ ...editing, narrative_style: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Ex : Poétique, romantique, contemporain..."
                />
              </div>
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Style musical</label>
                <input
                  type="text"
                  value={editing.music_style}
                  onChange={(e) => setEditing({ ...editing, music_style: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Ex : Piano doux, jazz, orchestral..."
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">URL image couverture</label>
                <input
                  type="text"
                  value={editing.cover_image_url}
                  onChange={(e) => setEditing({ ...editing, cover_image_url: e.target.value })}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="https://..."
                />
              </div>
            </div>
          </section>

          {/* Solidarity */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4">Conte solidaire</h2>
            <label className="flex items-center gap-3 mb-4">
              <input
                type="checkbox"
                checked={editing.is_solidarity}
                onChange={(e) => setEditing({ ...editing, is_solidarity: e.target.checked })}
                className="w-4 h-4"
              />
              <span className="text-gray-700 text-sm">Ce conte propose des articles solidaires (manteaux, vêtements chauds, etc.)</span>
            </label>
            {editing.is_solidarity && (
              <div>
                <label className="text-gray-700 text-xs tracking-widest uppercase block mb-2">Description solidaire</label>
                <textarea
                  value={editing.solidarity_description}
                  onChange={(e) => setEditing({ ...editing, solidarity_description: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 rounded-lg"
                  placeholder="Expliquez l'objectif solidaire de ce conte..."
                />
              </div>
            )}
          </section>

          {/* Scenes */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-gray-900 font-medium">Scènes</h2>
              <button
                onClick={addScene}
                className="flex items-center gap-2 text-amber-600 hover:text-amber-700 text-xs tracking-widest uppercase"
              >
                <Plus className="w-3 h-3" />
                Ajouter
              </button>
            </div>
            {editing.scenes.length === 0 ? (
              <p className="text-gray-500 text-sm">Aucune scène. Ajoutez des scènes pour structurer votre conte.</p>
            ) : (
              <div className="space-y-4">
                {editing.scenes.map((scene, i) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <input
                        type="text"
                        value={scene.title}
                        onChange={(e) => {
                          const newScenes = [...editing.scenes];
                          newScenes[i].title = e.target.value;
                          setEditing({ ...editing, scenes: newScenes });
                        }}
                        className="flex-1 border border-gray-300 px-3 py-1.5 text-sm focus:outline-none focus:border-amber-500 rounded"
                      />
                      <button
                        onClick={() => {
                          const newScenes = editing.scenes.filter((_, idx) => idx !== i);
                          setEditing({ ...editing, scenes: newScenes });
                        }}
                        className="ml-3 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    <textarea
                      value={scene.text}
                      onChange={(e) => {
                        const newScenes = [...editing.scenes];
                        newScenes[i].text = e.target.value;
                        setEditing({ ...editing, scenes: newScenes });
                      }}
                      rows={4}
                      className="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded mb-3"
                      placeholder="Texte de la scène..."
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        value={scene.illustration_prompt}
                        onChange={(e) => {
                          const newScenes = [...editing.scenes];
                          newScenes[i].illustration_prompt = e.target.value;
                          setEditing({ ...editing, scenes: newScenes });
                        }}
                        className="border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded"
                        placeholder="Prompt illustration..."
                      />
                      <input
                        type="text"
                        value={scene.illustration_url}
                        onChange={(e) => {
                          const newScenes = [...editing.scenes];
                          newScenes[i].illustration_url = e.target.value;
                          setEditing({ ...editing, scenes: newScenes });
                        }}
                        className="border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded"
                        placeholder="URL illustration..."
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Characters */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-gray-900 font-medium flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-500" />
                Personnages
              </h2>
              <button
                onClick={addCharacter}
                className="flex items-center gap-2 text-amber-600 hover:text-amber-700 text-xs tracking-widest uppercase"
              >
                <Plus className="w-3 h-3" />
                Ajouter
              </button>
            </div>
            {editing.characters.length === 0 ? (
              <p className="text-gray-500 text-sm">Aucun personnage. Ajoutez les personnages de votre conte.</p>
            ) : (
              <div className="space-y-4">
                {editing.characters.map((char, i) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <input
                        type="text"
                        value={char.name}
                        onChange={(e) => {
                          const newChars = [...editing.characters];
                          newChars[i].name = e.target.value;
                          setEditing({ ...editing, characters: newChars });
                        }}
                        className="flex-1 border border-gray-300 px-3 py-1.5 text-sm focus:outline-none focus:border-amber-500 rounded"
                        placeholder="Nom du personnage"
                      />
                      <button
                        onClick={() => {
                          const newChars = editing.characters.filter((_, idx) => idx !== i);
                          setEditing({ ...editing, characters: newChars });
                        }}
                        className="ml-3 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <input
                        type="text"
                        value={char.role}
                        onChange={(e) => {
                          const newChars = [...editing.characters];
                          newChars[i].role = e.target.value;
                          setEditing({ ...editing, characters: newChars });
                        }}
                        className="border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded"
                        placeholder="Rôle (ex : La mariée)"
                      />
                      <input
                        type="text"
                        value={char.age_category}
                        onChange={(e) => {
                          const newChars = [...editing.characters];
                          newChars[i].age_category = e.target.value;
                          setEditing({ ...editing, characters: newChars });
                        }}
                        className="border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded"
                        placeholder="Âge (ex : Adulte, Enfant)"
                      />
                    </div>
                    <textarea
                      value={char.description}
                      onChange={(e) => {
                        const newChars = [...editing.characters];
                        newChars[i].description = e.target.value;
                        setEditing({ ...editing, characters: newChars });
                      }}
                      rows={2}
                      className="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded mb-3"
                      placeholder="Description du personnage..."
                    />
                    <input
                      type="text"
                      value={char.style}
                      onChange={(e) => {
                        const newChars = [...editing.characters];
                        newChars[i].style = e.target.value;
                        setEditing({ ...editing, characters: newChars });
                      }}
                      className="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-amber-500 rounded"
                      placeholder="Style vestimentaire (ex : Robe fluide ivoire, romantique)"
                    />
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Status */}
          <section className="bg-white rounded-xl p-6 border border-gray-200">
            <h2 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Statut
            </h2>
            <div className="flex gap-3">
              {["draft", "ready", "published"].map((s) => (
                <button
                  key={s}
                  onClick={() => setEditing({ ...editing, status: s })}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${
                    editing.status === s
                      ? "bg-gray-900 text-white"
                      : "border border-gray-300 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {s === "draft" ? "Brouillon" : s === "ready" ? "Prêt" : "Publié"}
                </button>
              ))}
            </div>
          </section>
        </main>
      </div>
    );
  }

  if (view === "products" && editing) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div>
              <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-gray-900">
                Produits associés
              </h1>
              <p className="text-gray-500 text-sm">{editing.title}</p>
            </div>
            <button
              onClick={() => setView("edit")}
              className="flex items-center gap-2 border border-gray-300 text-gray-700 px-4 py-2 text-xs tracking-widest uppercase hover:bg-gray-50 transition-colors rounded-full"
            >
              <X className="w-3 h-3" />
              Retour
            </button>
          </div>
        </header>
        <main className="max-w-5xl mx-auto px-6 py-8">
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <p className="text-gray-500 text-sm">
              Interface d'ajout de produits — MVP : collez les liens produits manuellement.
              <br />
              Phase 2 : import automatique via API d'affiliation.
            </p>
            <div className="mt-6 text-center py-12">
              <LinkIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Fonctionnalité à implémenter</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // List view
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div>
            <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-gray-900">
              Contes de Mode — Admin
            </h1>
            <p className="text-gray-500 text-sm">Gérez vos contes et produits associés</p>
          </div>
          <button
            onClick={createTale}
            className="flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
          >
            <Plus className="w-3 h-3" />
            Nouveau conte
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        {tales.length === 0 ? (
          <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
            <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 mb-6">Aucun conte de mode pour l'instant.</p>
            <button
              onClick={createTale}
              className="inline-flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
            >
              <Plus className="w-3 h-3" />
              Créer mon premier conte
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Titre</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Thème</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Public</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Statut</th>
                  <th className="text-left text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Solidaire</th>
                  <th className="text-right text-xs tracking-widest uppercase text-gray-500 font-medium px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {tales.map((tale) => (
                  <tr key={tale.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="text-gray-900 font-medium">{tale.title}</p>
                      {tale.subtitle && <p className="text-gray-500 text-sm">{tale.subtitle}</p>}
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-600 text-sm capitalize">{tale.theme}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-600 text-sm">{tale.target_audience}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-xs px-2 py-1 rounded ${
                        tale.status === "published" ? "text-green-700 bg-green-100" :
                        tale.status === "ready" ? "text-amber-700 bg-amber-100" :
                        "text-gray-500 bg-gray-100"
                      }`}>
                        {tale.status === "published" ? "Publié" : tale.status === "ready" ? "Prêt" : "Brouillon"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {tale.is_solidarity ? (
                        <span className="text-green-600 text-xs">✓</span>
                      ) : (
                        <span className="text-gray-300 text-xs">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => { setEditing(tale); setView("edit"); }}
                          className="text-gray-400 hover:text-amber-500 transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteTale(tale.id)}
                          className="text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}