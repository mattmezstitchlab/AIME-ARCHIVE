import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  Camera, Edit2, Check, X, Plus, Eye, EyeOff, Archive, Trash2,
  User, BookOpen, ChevronRight
} from "lucide-react";

const TABS = ["Profil", "Mes Histoires", "Registre public"];
const ROLES = ["parent", "grand_parent", "conteur", "enseignant", "therapeute", "auteur"];
const ROLE_LABELS = { parent: "Parent", grand_parent: "Grand-parent", conteur: "Conteur", enseignant: "Enseignant", therapeute: "Thérapeute", auteur: "Auteur" };
const STATUS_LABELS = { draft: "Brouillon", generated: "Généré", audio_ready: "Audio prêt", published: "Publié", archived: "Archivé" };
const STATUS_COLORS = { draft: "text-white/40", generated: "text-blue-400", audio_ready: "text-green-400", published: "text-red-400", archived: "text-white/20" };

export default function MonEspace() {
  const [tab, setTab] = useState("Profil");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stories, setStories] = useState([]);
  const [voiceProfiles, setVoiceProfiles] = useState([]);
  const [authorPresence, setAuthorPresence] = useState(null);

  // Profil
  const [editingBio, setEditingBio] = useState(false);
  const [bio, setBio] = useState("");
  const [editingRole, setEditingRole] = useState(false);
  const [selectedRole, setSelectedRole] = useState("");
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [savingBio, setSavingBio] = useState(false);
  const fileInputRef = useRef(null);

  const recorderRef = useRef(null);

  // Registre
  const [creatingPresence, setCreatingPresence] = useState(false);
  const [editingPresence, setEditingPresence] = useState(false);
  const [presenceForm, setPresenceForm] = useState({ public_name: "", presence_type: "conteur", signature_phrase: "", short_bio: "", visibility: "public" });
  const [savingPresence, setSavingPresence] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.StoryProject.list("-created_date", 50),
      base44.entities.VoiceProfile.filter({ voice_status: "ready" }),
    ]).then(([me, s, voices]) => {
      setUser(me);
      setBio(me?.bio || "");
      setSelectedRole(me?.role_label || "");
      setStories(s);
      setVoiceProfiles(voices);
      if (me?.id) {
        base44.entities.AuthorPresence.filter({ user_id: me.id }).then((a) => {
          const p = a[0] || null;
          setAuthorPresence(p);
          if (p) setPresenceForm({ public_name: p.public_name || "", presence_type: p.presence_type || "conteur", signature_phrase: p.signature_phrase || "", short_bio: p.short_bio || "", visibility: p.visibility || "public" });
        });
      }
      setLoading(false);
    });
  }, []);

  // ---- Profil ----
  const saveBio = async () => {
    setSavingBio(true);
    await base44.auth.updateMe({ bio });
    setUser((u) => ({ ...u, bio }));
    setSavingBio(false);
    setEditingBio(false);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    const res = await base44.integrations.Core.UploadFile({ file });
    await base44.auth.updateMe({ avatar_url: res.file_url });
    setUser((u) => ({ ...u, avatar_url: res.file_url }));
    setUploadingAvatar(false);
  };



  // ---- Registre ----
  const savePresence = async () => {
    setSavingPresence(true);
    if (authorPresence) {
      const updated = await base44.entities.AuthorPresence.update(authorPresence.id, { ...presenceForm, portrait_url: user?.avatar_url || "" });
      setAuthorPresence(updated);
    } else {
      const created = await base44.entities.AuthorPresence.create({ ...presenceForm, user_id: user.id, portrait_url: user?.avatar_url || "" });
      setAuthorPresence(created);
    }
    setSavingPresence(false);
    setCreatingPresence(false);
    setEditingPresence(false);
  };

  // ---- Stories ----
  const updateStory = async (id, data) => {
    await base44.entities.StoryProject.update(id, data);
    setStories((s) => s.map((x) => (x.id === id ? { ...x, ...data } : x)));
  };
  const removeStory = async (id) => {
    await base44.entities.StoryProject.delete(id);
    setStories((s) => s.filter((x) => x.id !== id));
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen text-white pt-24" style={{ background: "#0a0806" }}>
      <div className="max-w-4xl mx-auto px-6">
        {/* Header compte */}
        <div className="flex items-center gap-5 mb-10">
          <div className="relative">
            <div className="w-20 h-20 rounded-full overflow-hidden bg-white/5 flex-shrink-0">
              {user?.avatar_url
                ? <img src={user.avatar_url} alt={user.full_name} className="w-full h-full object-cover" />
                : <div className="w-full h-full flex items-center justify-center">
                    <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white/30">{user?.full_name?.[0] || "?"}</span>
                  </div>
              }
            </div>
            <button onClick={() => fileInputRef.current?.click()} disabled={uploadingAvatar}
              className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-red-600 flex items-center justify-center hover:bg-red-500 transition-colors">
              {uploadingAvatar ? <div className="w-3 h-3 border border-black/40 border-t-black rounded-full animate-spin" /> : <Camera className="w-3 h-3 text-black" />}
            </button>
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
          </div>
          <div>
            <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2rem, 5vw, 3rem)", lineHeight: 1 }}>
              {user?.full_name || user?.email?.split("@")[0] || "Mon espace"}
            </h1>
            <p className="text-white/40 text-sm mt-0.5">{user?.email}</p>
          </div>
        </div>

        {/* Onglets */}
        <div className="flex gap-1 mb-10 border-b border-white/10">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-5 py-3 text-xs tracking-widest uppercase transition-colors ${tab === t ? "text-red-500 border-b-2 border-red-500 -mb-px" : "text-white/40 hover:text-white"}`}>
              {t}
            </button>
          ))}
        </div>

        {/* ═══ TAB: PROFIL ═══ */}
        {tab === "Profil" && (
          <div className="space-y-8 pb-20">
            <div>
              <p className="text-white/40 text-xs tracking-widest uppercase mb-2">Présentation</p>
              {editingBio ? (
                <div className="flex gap-2 items-start">
                  <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3}
                    placeholder="Qui êtes-vous en tant que conteur ?"
                    className="flex-1 bg-white/5 border border-red-500/50 text-white text-sm px-3 py-2 focus:outline-none resize-none rounded-lg" />
                  <div className="flex flex-col gap-1">
                    <button onClick={saveBio} disabled={savingBio} className="p-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-colors">
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => { setEditingBio(false); setBio(user?.bio || ""); }} className="p-2 border border-white/20 text-white/60 hover:text-white rounded-lg transition-colors">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-2 group/bio">
                  <p className="text-white/60 text-sm leading-relaxed">
                    {user?.bio || <span className="italic text-white/30">Ajoutez une courte présentation…</span>}
                  </p>
                  <button onClick={() => setEditingBio(true)} className="opacity-0 group-hover/bio:opacity-100 transition-opacity flex-shrink-0">
                    <Edit2 className="w-3 h-3 text-white/40 hover:text-red-500" />
                  </button>
                </div>
              )}
            </div>

            <div>
              <p className="text-white/40 text-xs tracking-widest uppercase mb-3">Mon rôle</p>
              {editingRole ? (
                <div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {ROLES.map((r) => (
                      <button key={r} onClick={() => setSelectedRole(r)}
                        className={`px-4 py-2 text-xs tracking-widest uppercase rounded-full transition-colors ${selectedRole === r ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
                        {ROLE_LABELS[r]}
                      </button>
                    ))}
                  </div>
                  <button onClick={async () => { await base44.auth.updateMe({ role_label: selectedRole }); setUser(u => ({ ...u, role_label: selectedRole })); setEditingRole(false); }}
                    className="bg-red-600 text-white px-6 py-2 text-xs tracking-widest uppercase rounded-full hover:bg-red-500 transition-colors">
                    Enregistrer
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <span className="text-white/70 text-sm">{selectedRole ? ROLE_LABELS[selectedRole] : <span className="italic text-white/30">Non défini</span>}</span>
                  <button onClick={() => setEditingRole(true)} className="text-white/30 hover:text-red-500 transition-colors">
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            <div className="flex gap-4 pt-4 border-t border-white/5">
              <div className="text-center">
                <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-red-500">{stories.length}</span>
                <p className="text-white/30 text-xs tracking-widest uppercase">Contes</p>
              </div>
              <div className="text-center">
                <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white">{voiceProfiles.length}</span>
                <p className="text-white/30 text-xs tracking-widest uppercase">Voix</p>
              </div>
              <div className="text-center">
                <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white">{stories.filter(s => s.status === "published").length}</span>
                <p className="text-white/30 text-xs tracking-widest uppercase">Publiés</p>
              </div>
            </div>
          </div>
        )}

        {/* ═══ TAB: MES HISTOIRES ═══ */}
        {tab === "Mes Histoires" && (
          <div className="pb-20">
            <div className="flex items-center justify-between mb-6">
              <p className="text-white/40 text-xs tracking-widest uppercase">{stories.length} conte{stories.length !== 1 ? "s" : ""}</p>
              <Link to="/slaame-lab" className="flex items-center gap-2 bg-red-600 text-white px-5 py-2 text-xs font-medium tracking-widest uppercase hover:bg-red-500 transition-colors rounded-full">
                <Plus className="w-3.5 h-3.5" /> Nouveau conte
              </Link>
            </div>

            {stories.length === 0 ? (
              <div className="text-center py-20">
                <BookOpen className="w-12 h-12 text-red-500/30 mx-auto mb-4" />
                <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="mb-2">Aucun conte pour l'instant</h3>
                <p className="text-white/40 mb-6 text-sm max-w-sm mx-auto">Créez votre premier conte illustré. L'IA rédige, génère les illustrations et l'audio avec votre voix.</p>
                <Link to="/slaame-lab" className="inline-flex items-center gap-2 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors rounded-full">
                  <Plus className="w-4 h-4" /> Créer mon premier conte
                </Link>
              </div>
            ) : (
              <div className="divide-y divide-white/5">
                {stories.map((story) => (
                  <div key={story.id} className="flex items-center gap-4 py-4 group">
                    <div className="w-12 h-16 flex-shrink-0 overflow-hidden rounded">
                      <img src={story.hero_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=200&q=80"} alt={story.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link to={`/conte/${story.id}`} className="hover:text-red-500 transition-colors">
                        <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.1rem" }} className="truncate">{story.title}</h3>
                      </Link>
                      <div className="flex gap-3 mt-1">
                        <span className={`text-xs ${STATUS_COLORS[story.status]}`}>{STATUS_LABELS[story.status]}</span>
                        {story.story_type && <span className="text-white/20 text-xs">{story.story_type.replace(/_/g, " ")}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => updateStory(story.id, { visibility: story.visibility === "public" ? "private" : "public" })} className="text-white/40 hover:text-white transition-colors p-1">
                        {story.visibility === "public" ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button onClick={() => updateStory(story.id, { status: "archived" })} className="text-white/40 hover:text-red-500 transition-colors p-1">
                        <Archive className="w-4 h-4" />
                      </button>
                      <button onClick={() => removeStory(story.id)} className="text-white/40 hover:text-red-400 transition-colors p-1">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ═══ TAB: REGISTRE PUBLIC ═══ */}
        {tab === "Registre public" && (
          <div className="pb-20">
            {!authorPresence && !creatingPresence && (
              <div className="text-center py-16">
                <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
                  <User className="w-9 h-9 text-white/30" />
                </div>
                <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }}>Rejoindre le Registre</h2>
                <p className="text-white/40 mt-3 mb-8 max-w-sm mx-auto text-sm">Créez votre profil public de conteur pour apparaître dans le Registre et partager vos œuvres.</p>
                <button onClick={() => { setPresenceForm({ public_name: user?.full_name || "", presence_type: "conteur", signature_phrase: "", short_bio: "", visibility: "public" }); setCreatingPresence(true); }}
                  className="bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors rounded-full">
                  Créer mon profil public
                </button>
              </div>
            )}

            {(creatingPresence || editingPresence) && (
              <div className="max-w-xl space-y-6">
                <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}>{editingPresence ? "Modifier mon profil" : "Mon profil public"}</h2>
                <div>
                  <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Nom public</label>
                  <input type="text" value={presenceForm.public_name} onChange={(e) => setPresenceForm(f => ({ ...f, public_name: e.target.value }))}
                    className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500 rounded-lg" />
                </div>
                <div>
                  <label className="text-white/40 text-xs tracking-widest uppercase block mb-3">Rôle</label>
                  <div className="flex flex-wrap gap-2">
                    {ROLES.map((r) => (
                      <button key={r} onClick={() => setPresenceForm(f => ({ ...f, presence_type: r }))}
                        className={`px-4 py-2 text-xs tracking-widest uppercase rounded-full transition-colors ${presenceForm.presence_type === r ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"}`}>
                        {ROLE_LABELS[r]}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Phrase signature</label>
                  <input type="text" value={presenceForm.signature_phrase} onChange={(e) => setPresenceForm(f => ({ ...f, signature_phrase: e.target.value }))}
                    placeholder="Ex : Je raconte pour que les enfants rêvent plus grand."
                    className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500 rounded-lg" />
                </div>
                <div>
                  <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Bio courte</label>
                  <textarea value={presenceForm.short_bio} onChange={(e) => setPresenceForm(f => ({ ...f, short_bio: e.target.value }))} rows={3}
                    className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500 resize-none rounded-lg" />
                </div>
                <div className="flex gap-4">
                  <button onClick={savePresence} disabled={savingPresence}
                    className="bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors disabled:opacity-50 rounded-full">
                    {savingPresence ? "Enregistrement..." : "Publier mon profil"}
                  </button>
                  <button onClick={() => { setCreatingPresence(false); setEditingPresence(false); }} className="border border-white/20 text-white px-6 py-3 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-full">
                    Annuler
                  </button>
                </div>
              </div>
            )}

            {authorPresence && !creatingPresence && !editingPresence && (
              <div>
                <div className="flex items-start gap-5 mb-8 p-6 bg-white/5 rounded-xl">
                  <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0 bg-white/10">
                    <img src={authorPresence.portrait_url || user?.avatar_url || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80"} alt={authorPresence.public_name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="text-red-500 text-xs tracking-widest uppercase mb-1">{ROLE_LABELS[authorPresence.presence_type]}</p>
                    <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem", lineHeight: 1 }}>{authorPresence.public_name}</h3>
                    {authorPresence.signature_phrase && <p className="text-white/50 italic text-sm mt-2">« {authorPresence.signature_phrase} »</p>}
                    {authorPresence.short_bio && <p className="text-white/40 text-xs mt-2 leading-relaxed">{authorPresence.short_bio}</p>}
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setEditingPresence(true)} className="border border-white/20 text-white px-6 py-3 text-xs tracking-widest uppercase hover:border-white/60 transition-colors rounded-full flex items-center gap-2">
                    <Edit2 className="w-3.5 h-3.5" /> Modifier
                  </button>
                  <Link to={`/conteur/${authorPresence.id}`} className="flex items-center gap-2 text-white/40 hover:text-red-500 text-xs tracking-widest uppercase transition-colors px-4 py-3">
                    Voir ma page publique <ChevronRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}