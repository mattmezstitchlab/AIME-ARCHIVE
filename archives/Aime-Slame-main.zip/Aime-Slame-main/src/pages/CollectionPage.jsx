import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import CollectionHero from "@/components/CollectionHero";
import StoryCard from "@/components/StoryCard";
import AudioBar from "@/components/AudioBar";

export default function CollectionPage() {
  const { slug } = useParams();
  const [collection, setCollection] = useState(null);
  const [stories, setStories] = useState([]);
  const [playingStory, setPlayingStory] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Collection.filter({ slug }).then(async (cols) => {
      if (cols.length === 0) { setLoading(false); return; }
      const col = cols[0];
      setCollection(col);
      const s = await base44.entities.StoryProject.filter({ collection_id: col.id }, "order_num", 50);
      setStories(s);
      setLoading(false);
    });
  }, [slug]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
    </div>
  );

  if (!collection) return (
    <div className="min-h-screen text-white flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="text-center">
        <p className="text-white/40 mb-4">Collection introuvable.</p>
        <Link to="/collections" className="text-red-500 underline">Retour aux collections</Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen text-white pb-32" style={{ background: "#0a0806" }}>
      <CollectionHero collection={collection} />
      <section className="max-w-6xl mx-auto px-6 py-16">
        {stories.length === 0 ? (
          <p className="text-white/40 text-center py-10">Aucun conte dans cette collection.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stories.map((story, i) => (
              <StoryCard key={story.id} story={story} index={i} onPlay={setPlayingStory} />
            ))}
          </div>
        )}
      </section>
      <AudioBar story={playingStory} onClose={() => setPlayingStory(null)} />
    </div>
  );
}