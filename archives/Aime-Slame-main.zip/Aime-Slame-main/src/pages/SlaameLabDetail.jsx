import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { generateLabEntity } from "@/functions/generateLabEntity";
import { ArrowLeft, BookOpen, Music, ShoppingBag, Heart, Calendar, Megaphone, Film, Clock, Shield, TrendingUp, Check, Loader2 } from "lucide-react";

const TYPE_ICONS = {
  conte_immobilier: { icon: BookOpen, color: "text-blue-400", label: "Conte immobilier" },
  visite_audio: { icon: Music, color: "text-purple-400", label: "Visite audio" },
  page_evenement: { icon: Calendar, color: "text-pink-400", label: "Page événement" },
  conte_mode: { icon: ShoppingBag, color: "text-amber-400", label: "Conte de mode" },
  direction_solidaire: { icon: Heart, color: "text-green-400", label: "Direction solidaire" },
  jingle: { icon: Music, color: "text-cyan-400", label: "Jingle" },
  annonce_sensible: { icon: Megaphone, color: "text-rose-400", label: "Annonce sensible" },
  lookbook: { icon: Film, color: "text-violet-400", label: "Lookbook" },
  marketplace: { icon: ShoppingBag, color: "text-orange-400", label: "Marketplace" },
  capsule_memoire: { icon: Heart, color: "text-red-400", label: "Capsule mémoire" },
  livre_souvenir: { icon: BookOpen, color: "text-indigo-400", label: "Livre souvenir" },
};

const COMPLEXITY_LABELS = {
  simple: { label: "Simple", color: "text-green-400" },
  medium: { label: "Moyen", color: "text-yellow-400" },
  complex: { label: "Complexe", color: "text-red-400" },
};

export default function SlaameLabDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [deposit, setDeposit] = useState(null);
  const [selectedDirection, setSelectedDirection] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    base44.entities.LabDeposit.get(id).then((d) => {
      setDeposit(d);
      setLoading(false);
    });
  }, [id]);

  const handleSelectDirection = (direction) => {
    setSelectedDirection(direction);
  };

  const handleCreate = async () => {
    if (!selectedDirection) return;
    setGenerating(true);
    
    try {
      // Call backend function to generate entity
      const result = await generateLabEntity({
        depositId: id,
        directionId: selectedDirection.id
      });
      
      if (result.success && result.redirectUrl) {
        navigate(result.redirectUrl);
      } else {
        alert("Direction générée !");
      }
    } catch (error) {
      console.error("Error generating entity:", error);
      alert("Erreur lors de la génération. Veuillez réessayer.");
    }
    
    setGenerating(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
        <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!deposit) {
    return (
      <div className="min-h-screen text-white flex items-center justify-center" style={{ background: "#0a0806" }}>
        <div className="text-center">
          <Shield className="w-16 h-16 text-white/20 mx-auto mb-4" />
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="mb-2">
            Dépôt introuvable
          </h2>
          <Link to="/slaame-lab" className="text-red-500 hover:text-red-400 text-sm">
            ← Retour au Lab
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-white pb-32" style={{ background: "#0a0806" }}>
      {/* Header */}
      <section className="pt-32 pb-12 px-6">
        <div className="max-w-5xl mx-auto">
          <Link
            to="/slaame-lab"
            className="flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Retour</span>
          </Link>

          <h1
            style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }}
            className="mb-4"
          >
            {deposit.title}
          </h1>
          <p className="text-white/60">
            {deposit.directions?.length || 0} direction{deposit.directions?.length > 1 ? "s" : ""} possible{deposit.directions?.length > 1 ? "s" : ""}
          </p>
        </div>
      </section>

      {/* Directions Grid */}
      <section className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {deposit.directions?.map((direction) => {
            const TypeConfig = TYPE_ICONS[direction.type] || { icon: BookOpen, color: "text-white", label: direction.type };
            const TypeIcon = TypeConfig.icon;
            const complexity = COMPLEXITY_LABELS[direction.complexity] || COMPLEXITY_LABELS.medium;
            const isSelected = selectedDirection?.id === direction.id;

            return (
              <div
                key={direction.id}
                onClick={() => handleSelectDirection(direction)}
                className={`bg-white/5 border rounded-2xl p-6 cursor-pointer transition-all ${
                  isSelected
                    ? "border-red-500 bg-red-500/10"
                    : "border-white/10 hover:border-white/20"
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full bg-white/5 flex items-center justify-center ${TypeConfig.color}`}>
                      <TypeIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">{direction.title}</h3>
                      <p className="text-white/40 text-xs">{direction.category}</p>
                    </div>
                  </div>
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-red-600 flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                  {direction.is_confidential && !isSelected && (
                    <Shield className="w-4 h-4 text-white/30" title="Confidentiel" />
                  )}
                </div>

                {/* Why relevant */}
                <p className="text-white/60 text-sm mb-4 leading-relaxed">
                  {direction.why_relevant}
                </p>

                {/* Possible outputs */}
                <div className="mb-4">
                  <p className="text-white/40 text-xs mb-2">Sorties possibles :</p>
                  <div className="flex flex-wrap gap-1.5">
                    {direction.possible_outputs.map((output, i) => (
                      <span key={i} className="px-2 py-1 bg-white/5 border border-white/10 text-white/50 text-xs rounded">
                        {output}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Meta info */}
                <div className="flex items-center gap-4 mb-4 text-xs">
                  <span className={`flex items-center gap-1 ${complexity.color}`}>
                    <TrendingUp className="w-3 h-3" />
                    {complexity.label}
                  </span>
                  <span className="flex items-center gap-1 text-white/40">
                    <Clock className="w-3 h-3" />
                    {direction.estimated_time}
                  </span>
                  {direction.commission_estimate !== undefined && direction.commission_estimate > 0 && (
                    <span className="flex items-center gap-1 text-red-400">
                      <TrendingUp className="w-3 h-3" />
                      ~{direction.commission_estimate}%
                    </span>
                  )}
                  {direction.solidarity_percentage !== undefined && direction.solidarity_percentage > 0 && (
                    <span className="flex items-center gap-1 text-green-400">
                      <Heart className="w-3 h-3" />
                      {direction.solidarity_percentage}% reversé
                    </span>
                  )}
                </div>

                {/* Status */}
                {direction.status !== "proposed" && (
                  <div className="pt-4 border-t border-white/10">
                    <span className={`text-xs px-2 py-1 rounded ${
                      direction.status === "selected" ? "text-red-400 bg-red-500/10" :
                      direction.status === "generating" ? "text-blue-400 bg-blue-500/10" :
                      direction.status === "ready" ? "text-green-400 bg-green-500/10" :
                      "text-white/40 bg-white/5"
                    }`}>
                      {direction.status === "selected" ? "Sélectionnée" :
                       direction.status === "generating" ? "Génération en cours..." :
                       direction.status === "ready" ? "Prête" :
                       direction.status}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Action Bar */}
      {selectedDirection && (
        <div className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur border-t border-white/10 px-6 py-4">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div>
              <p className="text-white/60 text-sm">Direction sélectionnée</p>
              <p className="text-white font-medium">{selectedDirection.title}</p>
            </div>
            <button
              onClick={handleCreate}
              disabled={generating}
              className="flex items-center gap-2 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors disabled:opacity-50 rounded-full"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Génération...
                </>
              ) : (
                <>
                  Créer {TYPE_ICONS[selectedDirection.type]?.label || "cette direction"}
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <section className="max-w-5xl mx-auto px-6 mt-20 pt-8 border-t border-white/10">
        <div className="flex items-start gap-3 text-white/40 text-xs">
          <Shield className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <p>
            Les estimations (commissions, temps, complexité) sont indicatives.
            Chaque sortie nécessite une validation humaine avant publication.
            Confidentialité garantie — rien n'est publié automatiquement.
          </p>
        </div>
      </section>
    </div>
  );
}