import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { 
  ArrowLeft, BookOpen, ShoppingBag, Heart, Music, Play, Pause, 
  Palette, Users, Sparkles, ExternalLink, Info
} from "lucide-react";

const THEMES = {
  mariage: "Mariage", anniversaire: "Anniversaire", enfance: "Enfance",
  precarite: "Précarité", solidarite: "Solidarité", famille: "Famille",
  bal: "Bal", rentree: "Rentrée", fete: "Fête", feerique: "Féerique",
  urbain: "Urbain", social: "Social", romantique: "Romantique",
  drole: "Drôle", musical: "Musical", saison: "Saison",
};

export default function ConteDeModeDetail() {
  const { id } = useParams();
  const [tale, setTale] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeScene, setActiveScene] = useState(0);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    if (!id) return;
    Promise.all([
      base44.entities.FashionTale.get(id),
      base44.entities.FashionProduct.filter({ fashion_tale_id: id }, "display_order"),
    ]).then(([t, p]) => {
      setTale(t);
      setProducts(p);
      setLoading(false);
    });
  }, [id]);

  const toggleAudio = () => {
    if (!audioRef.current) return;
    if (playing) audioRef.current.pause();
    else audioRef.current.play();
    setPlaying(!playing);
  };

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
    </div>
  );

  if (!tale) return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <div className="text-center">
        <BookOpen className="w-16 h-16 text-white/20 mx-auto mb-4" />
        <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="text-white mb-2">
          Conte introuvable
        </h2>
        <Link to="/contes-de-mode" className="text-amber-400 text-sm">← Retour aux contes</Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Nav fixe */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/contes-de-mode" className="flex items-center gap-2 text-white/40 hover:text-white transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-xs tracking-widest uppercase">Retour</span>
          </Link>
          <div className="flex items-center gap-4">
            {tale.audio_url && (
              <button
                onClick={toggleAudio}
                className="flex items-center gap-2 bg-white text-black px-5 py-2 text-xs tracking-widest uppercase rounded-full hover:bg-white/90 transition-colors"
              >
                {playing ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                <span className="hidden md:inline">{playing ? "Pause" : "Écouter"}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {tale.audio_url && <audio ref={audioRef} src={tale.audio_url} onEnded={() => setPlaying(false)} />}

      {/* Hero cover plein écran */}
      <section className="relative h-[75vh] flex items-end pb-14 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={tale.cover_image_url || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=1400&q=80"}
            alt={tale.title}
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 w-full">
          <div className="flex flex-wrap gap-3 mb-4">
            <span className="px-3 py-1 rounded-full text-xs text-amber-400 bg-amber-500/10">
              {THEMES[tale.theme] || tale.theme}
            </span>
            {tale.is_solidarity && (
              <span className="px-3 py-1 rounded-full text-xs text-green-400 bg-green-500/10">Solidaire</span>
            )}
            <span className="text-white/40 text-xs self-center">{tale.target_audience}</span>
          </div>
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 8vw, 6rem)", lineHeight: 1 }} className="text-white mb-3">
            {tale.title}
          </h1>
          {tale.subtitle && <p className="text-white/60 text-xl">{tale.subtitle}</p>}
          <div className="flex flex-wrap gap-6 text-white/40 text-xs mt-5">
            <span className="flex items-center gap-1.5"><BookOpen className="w-3.5 h-3.5" />{tale.scenes?.length || 0} scènes</span>
            <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5" />{tale.characters?.length || 0} personnages</span>
            <span className="flex items-center gap-1.5"><ShoppingBag className="w-3.5 h-3.5" />{products.length} articles</span>
            {tale.duration && <span className="flex items-center gap-1.5"><Music className="w-3.5 h-3.5" />{Math.round(tale.duration / 60)} min</span>}
          </div>
        </div>
      </section>

      {/* Story Content */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Texte */}
          <div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-white mb-6">
              L'histoire
            </h2>

            {tale.scenes && tale.scenes.length > 1 && (
              <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                {tale.scenes.map((scene, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveScene(i)}
                    className={`px-4 py-2 text-xs tracking-widest uppercase whitespace-nowrap transition-colors rounded-full ${
                      activeScene === i ? "bg-white text-black" : "text-white/50 hover:text-white"
                    }`}
                  >
                    Scène {i + 1}
                  </button>
                ))}
              </div>
            )}

            <div>
              {tale.scenes && tale.scenes[activeScene] ? (
                <>
                  <h3 className="text-white text-xl mb-4">
                    {tale.scenes[activeScene].title || `Scène ${activeScene + 1}`}
                  </h3>
                  <p className="text-white/70 leading-relaxed whitespace-pre-line">
                    {tale.scenes[activeScene].text}
                  </p>
                </>
              ) : (
                <p className="text-white/70 leading-relaxed whitespace-pre-line">
                  {tale.full_story || tale.summary}
                </p>
              )}
            </div>

            {tale.is_solidarity && tale.solidarity_description && (
              <div className="mt-8 flex items-start gap-3 text-green-400">
                <Heart className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-green-400 font-medium mb-2 text-sm uppercase tracking-widest">Dimension solidaire</h4>
                  <p className="text-white/60 text-sm leading-relaxed">{tale.solidarity_description}</p>
                </div>
              </div>
            )}
          </div>

          {/* Illustration */}
          <div className="relative">
            <div className="sticky top-24">
              <div className="overflow-hidden aspect-[3/4]">
                <img
                  src={tale.scenes?.[activeScene]?.illustration_url || tale.cover_image_url}
                  alt="Illustration"
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-white/20 text-xs text-center mt-3">
                Illustration inspirée de produits réels. Les détails exacts peuvent varier.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Looks */}
      <section id="looks" className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2rem, 5vw, 3.5rem)" }} className="text-white">
                Looks du conte
              </h2>
              <p className="text-white/40 text-sm mt-1">Les vêtements portés par les personnages existent vraiment</p>
            </div>
            <div className="flex items-center gap-2 text-white/30 text-xs">
              <Info className="w-3.5 h-3.5" />
              <span>Liens affiliés</span>
            </div>
          </div>

          {products.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <div key={product.id} className="group overflow-hidden">
                  <div className="relative aspect-[4/5] overflow-hidden mb-4">
                    <img
                      src={product.image_url || "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&q=80"}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {product.character_name && (
                      <div className="absolute top-3 left-3 px-2 py-1 bg-black/70 backdrop-blur rounded text-xs text-white/70">
                        Porté par {product.character_name}
                      </div>
                    )}
                    {product.availability && (
                      <div className={`absolute top-3 right-3 px-2 py-1 rounded text-xs ${
                        product.availability === "in_stock" ? "text-green-400 bg-green-500/20" :
                        product.availability === "low_stock" ? "text-amber-400 bg-amber-500/20" :
                        "text-white/40 bg-black/40"
                      }`}>
                        {product.availability === "in_stock" ? "Dispo" :
                         product.availability === "low_stock" ? "Stock faible" :
                         product.availability === "out_of_stock" ? "Épuisé" : ""}
                      </div>
                    )}
                  </div>
                  <h3 className="text-white font-medium mb-1 truncate">{product.title}</h3>
                  {product.partner_name && <p className="text-white/40 text-xs mb-2">{product.partner_name}</p>}
                  {product.price && (
                    <p className="text-white/70 text-sm mb-3">{product.price} {product.currency}</p>
                  )}
                  <a
                    href={product.partner_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-white text-black px-5 py-2 text-xs tracking-widest uppercase hover:bg-white/90 transition-colors rounded-full"
                  >
                    Voir l'article <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <ShoppingBag className="w-12 h-12 text-white/10 mx-auto mb-4" />
              <p className="text-white/30">Aucun produit associé pour le moment.</p>
            </div>
          )}
        </div>
      </section>

      {/* Personnages */}
      {tale.characters && tale.characters.length > 0 && (
        <section className="max-w-6xl mx-auto px-6 py-12 pb-16">
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2rem, 5vw, 3.5rem)" }} className="text-white mb-8">
            Personnages
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tale.characters.map((char, i) => (
              <div key={i}>
                <h3 className="text-white text-lg mb-1">{char.name}</h3>
                <p className="text-white/40 text-sm mb-2">{char.role}</p>
                {char.description && <p className="text-white/60 text-sm leading-relaxed mb-2">{char.description}</p>}
                {char.style && <p className="text-amber-400 text-xs italic">{char.style}</p>}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Pied de page */}
      <section className="border-t border-white/10 py-8 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-white/20 text-xs leading-relaxed">
            Les vêtements présentés sont des articles réels proposés par des partenaires ou via des liens affiliés.
            Les prix, tailles et disponibilités peuvent évoluer sans préavis.
          </p>
        </div>
      </section>
    </div>
  );
}