import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { BookOpen, Music, ShoppingBag, Heart, Calendar, Megaphone, Film, Clock, Shield, TrendingUp, ExternalLink, Trash2 } from "lucide-react";

const TYPE_ICONS = {
  conte_immobilier: { icon: BookOpen, color: "text-blue-400" },
  visite_audio: { icon: Music, color: "text-purple-400" },
  page_evenement: { icon: Calendar, color: "text-pink-400" },
  conte_mode: { icon: ShoppingBag, color: "text-amber-400" },
  direction_solidaire: { icon: Heart, color: "text-green-400" },
  jingle: { icon: Music, color: "text-cyan-400" },
  annonce_sensible: { icon: Megaphone, color: "text-rose-400" },
  lookbook: { icon: Film, color: "text-violet-400" },
  marketplace: { icon: ShoppingBag, color: "text-orange-400" },
  capsule_memoire: { icon: Heart, color: "text-red-400" },
  livre_souvenir: { icon: BookOpen, color: "text-indigo-400" },
};

const STATUS_COLORS = {
  draft: "text-white/40",
  analyzed: "text-blue-400",
  directions_proposed: "text-amber-400",
  generating: "text-purple-400",
  ready: "text-green-400",
  published: "text-white",
  archived: "text-white/20",
};

export default function AdminLabDeposits() {
  const [deposits, setDeposits] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.LabDeposit.list("-created_date", 50).then((d) => {
      setDeposits(d);
      setLoading(false);
    });
  }, []);

  const remove = async (id) => {
    if (!confirm("Supprimer ce dépôt ?")) return;
    await base44.entities.LabDeposit.delete(id);
    setDeposits(deposits.filter((d) => d.id !== id));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="text-gray-900">
              SLAÂME Lab — Admin
            </h1>
            <p className="text-gray-500 text-sm">Gérez les dépôts et directions générées</p>
          </div>
          <Link
            to="/slaame-lab"
            className="flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
          >
            <ExternalLink className="w-3 h-3" />
            Voir le Lab
          </Link>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {deposits.length === 0 ? (
          <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
            <Shield className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 mb-6">Aucun dépôt pour l'instant.</p>
            <Link
              to="/slaame-lab"
              className="inline-flex items-center gap-2 bg-gray-900 text-white px-6 py-2 text-xs tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
            >
              Créer un dépôt
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {deposits.map((deposit) => (
              <div key={deposit.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                {/* Header */}
                <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                  <div>
                    <h3 className="text-gray-900 font-medium">{deposit.title}</h3>
                    <p className="text-gray-500 text-sm">
                      {deposit.created_for_entity ? `Entité: ${deposit.created_for_entity}` : "Aucune entité générée"}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`text-xs px-2 py-1 rounded ${
                      deposit.status === "ready" ? "text-green-700 bg-green-100" :
                      deposit.status === "generating" ? "text-purple-700 bg-purple-100" :
                      deposit.status === "directions_proposed" ? "text-amber-700 bg-amber-100" :
                      "text-gray-500 bg-gray-100"
                    }`}>
                      {deposit.status}
                    </span>
                    <Link
                      to={`/slaame-lab/${deposit.id}`}
                      className="text-gray-400 hover:text-amber-500 transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Link>
                    <button
                      onClick={() => remove(deposit.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Meta */}
                <div className="px-6 py-3 bg-gray-50 flex items-center gap-4 text-xs text-gray-500">
                  {deposit.theme_detected && (
                    <span>Thème: {deposit.theme_detected}</span>
                  )}
                  {deposit.emotion_detected && (
                    <span>Émotion: {deposit.emotion_detected}</span>
                  )}
                  {deposit.keywords && deposit.keywords.length > 0 && (
                    <span>Mots-clés: {deposit.keywords.slice(0, 3).join(", ")}{deposit.keywords.length > 3 ? "..." : ""}</span>
                  )}
                  {deposit.objectives && deposit.objectives.length > 0 && (
                    <span>Objectifs: {deposit.objectives.join(", ")}</span>
                  )}
                </div>

                {/* Directions */}
                {deposit.directions && deposit.directions.length > 0 && (
                  <div className="px-6 py-4 border-t border-gray-100">
                    <p className="text-gray-700 font-medium text-sm mb-3">
                      {deposit.directions.length} direction{deposit.directions.length > 1 ? "s" : ""} générée{deposit.directions.length > 1 ? "s" : ""}
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {deposit.directions.map((dir, i) => {
                        const TypeConfig = TYPE_ICONS[dir.type] || { icon: BookOpen, color: "text-gray-400" };
                        const TypeIcon = TypeConfig.icon;
                        return (
                          <div key={i} className="border border-gray-200 rounded-lg p-3">
                            <div className="flex items-center gap-2 mb-2">
                              <TypeIcon className={`w-4 h-4 ${TypeConfig.color}`} />
                              <span className="text-gray-900 font-medium text-sm">{dir.title}</span>
                            </div>
                            <p className="text-gray-500 text-xs mb-2 line-clamp-2">{dir.why_relevant}</p>
                            <div className="flex items-center justify-between">
                              <span className={`text-xs px-2 py-1 rounded ${
                                dir.status === "ready" ? "text-green-700 bg-green-100" :
                                dir.status === "generating" ? "text-purple-700 bg-purple-100" :
                                dir.status === "selected" ? "text-amber-700 bg-amber-100" :
                                "text-gray-500 bg-gray-100"
                              }`}>
                                {dir.status}
                              </span>
                              {deposit.generated_entity_id && dir.status === "ready" && (
                                <Link
                                  to={dir.type === "conte_mode" ? `/contes-de-mode/${deposit.generated_entity_id}` : `/conte/${deposit.generated_entity_id}`}
                                  className="text-gray-400 hover:text-amber-500 text-xs"
                                >
                                  Voir →
                                </Link>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}