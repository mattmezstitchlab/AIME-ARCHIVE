import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { elevenLabsCloneVoice } from "@/functions/elevenLabsCloneVoice";
import { Mic, Square, Check, ChevronRight, Loader2 } from "lucide-react";

const STEPS = ["consentement", "enregistrement", "ecoute", "configuration"];

export default function MaVoix() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [consent, setConsent] = useState(false);
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [visibility, setVisibility] = useState("private");
  const [displayName, setDisplayName] = useState("");
  const [saving, setSaving] = useState(false);

  const recorderRef = useRef(null);
  const chunksRef = useRef([]);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];
    recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      setAudioBlob(blob);
      setAudioUrl(URL.createObjectURL(blob));
      stream.getTracks().forEach((t) => t.stop());
    };
    recorder.start();
    recorderRef.current = recorder;
    setRecording(true);
  };

  const stopRecording = () => {
    recorderRef.current?.stop();
    setRecording(false);
    setStep(2);
  };

  const save = async () => {
    setSaving(true);
    let sampleUrl = null;
    let voiceModelId = null;

    if (audioBlob) {
      // Convert blob to file with proper name and type
      const audioFile = new File([audioBlob], "voice-sample.webm", { type: "audio/webm" });
      
      // Upload sample
      const uploadRes = await base44.integrations.Core.UploadFile({ file: audioFile });
      sampleUrl = uploadRes.file_url;

      // Clone voice on ElevenLabs
      const cloneRes = await elevenLabsCloneVoice({
        audio_url: sampleUrl,
        voice_name: displayName || "Ma voix SLAÂME",
      });
      if (cloneRes.data?.voice_id) {
        voiceModelId = cloneRes.data.voice_id;
      }
    }

    await base44.entities.VoiceProfile.create({
      display_name: displayName || "Ma voix",
      consent_accepted: true,
      voice_status: voiceModelId ? "ready" : "recording",
      audio_sample_url: sampleUrl,
      voice_model_id: voiceModelId,
      visibility,
    });
    setSaving(false);
    navigate("/mon-espace");
  };

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      <section className="max-w-2xl mx-auto px-6 pt-32 pb-20">
        <p className="text-red-500 tracking-widest uppercase text-xs mb-4">Voix Source</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 5rem)", lineHeight: 1 }}>
          Ma Voix
        </h1>

        {/* Step indicator */}
        <div className="flex gap-2 mt-8 mb-12">
          {STEPS.map((s, i) => (
            <div key={s} className={`h-0.5 flex-1 transition-all ${i <= step ? "bg-red-600" : "bg-white/10"}`} />
          ))}
        </div>

        {/* Step 0: Consent */}
        {step === 0 && (
          <div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}>Consentement</h2>
            <p className="text-white/60 mt-4 leading-relaxed">
              En enregistrant votre voix, vous acceptez qu'elle soit utilisée pour générer des narrations audio personnalisées dans cette application. Votre voix ne sera jamais partagée avec des tiers.
            </p>
            <label className="flex items-start gap-3 mt-6 cursor-pointer">
              <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1" />
              <span className="text-white/80 text-sm">J'accepte les conditions d'utilisation de ma voix.</span>
            </label>
            <button
              onClick={() => setStep(1)}
              disabled={!consent}
              className="mt-8 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-2 rounded-full"
            >
              Continuer <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Step 1: Recording */}
        {step === 1 && (
          <div className="text-center">
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}>Enregistrement</h2>
            <p className="text-white/60 mt-4 mb-10">Lisez ce texte à voix haute de façon naturelle :</p>
            <blockquote className="border-l-2 border-red-500 pl-4 text-white/80 italic text-left mb-10">
              "Il était une fois, dans un village au bord de la forêt, une petite lumière qui dansait entre les arbres. Les enfants l'appelaient Luciole, et chaque soir, elle venait leur chuchoter des histoires venues de loin."
            </blockquote>
            <div className="flex justify-center">
              {!recording ? (
                <button onClick={startRecording} className="w-20 h-20 rounded-full bg-red-600 flex items-center justify-center hover:bg-red-500 transition-colors">
                  <Mic className="w-8 h-8 text-black" />
                </button>
              ) : (
                <button onClick={stopRecording} className="w-20 h-20 rounded-full bg-red-500 flex items-center justify-center hover:bg-red-400 transition-colors animate-pulse">
                  <Square className="w-8 h-8 text-white" />
                </button>
              )}
            </div>
            <p className="text-white/40 text-xs mt-4">{recording ? "Enregistrement en cours..." : "Appuyez pour commencer"}</p>
          </div>
        )}

        {/* Step 2: Playback */}
        {step === 2 && (
          <div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}>Écoute</h2>
            <p className="text-white/60 mt-4 mb-8">Écoutez votre enregistrement et validez.</p>
            {audioUrl && <audio src={audioUrl} controls className="w-full mb-8" />}
            <div className="flex gap-4">
              <button onClick={() => { setAudioBlob(null); setAudioUrl(null); setStep(1); }} className="border border-white/20 text-white px-6 py-3 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-full">
                Recommencer
              </button>
              <button onClick={() => setStep(3)} className="bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors flex items-center gap-2 rounded-full">
                Valider <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Config */}
        {step === 3 && (
          <div>
            <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}>Configuration</h2>
            <div className="mt-8 space-y-6">
              <div>
                <label className="text-white/60 text-xs tracking-widest uppercase block mb-2">Nom de la voix</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Ex : Voix de Papa"
                  className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-red-500"
                />
              </div>
              <div>
                <label className="text-white/60 text-xs tracking-widest uppercase block mb-2">Visibilité</label>
                <div className="flex gap-3">
                  {["private", "family", "public"].map((v) => (
                    <button
                      key={v}
                      onClick={() => setVisibility(v)}
                      className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${
                        visibility === v ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"
                      }`}
                    >
                      {v === "private" ? "Privée" : v === "family" ? "Famille" : "Publique"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <button
              onClick={save}
              disabled={saving}
              className="mt-10 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors disabled:opacity-50 rounded-full"
            >
              {saving ? <><Loader2 className="w-4 h-4 animate-spin inline mr-2" />Clonage en cours...</> : "Enregistrer et cloner ma voix"}
            </button>
          </div>
        )}
      </section>
    </div>
  );
}