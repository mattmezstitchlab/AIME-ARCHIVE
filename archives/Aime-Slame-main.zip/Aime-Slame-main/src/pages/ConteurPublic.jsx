import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, BookOpen } from "lucide-react";

const PRESENCE_LABELS = {
  parent: "Parent",
  grand_parent: "Grand-parent",
  conteur: "Conteur",
  enseignant: "Enseignant",
  therapeute: "Thérapeute",
  auteur: "Auteur",
  profil_demo: "Profil démo",
};

export default function ConteurPublic() {
  const { id } = useParams();
  const [author, setAuthor] = useState(null);
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.AuthorPresence.filter({ id: id }),
      base44.entities.StoryProject.filter({ author_presence_id: id, visibility: "public", status: "published" }, "-created_date", 20),
    ]).then(([a, s]) => {
      setAuthor(a[0] || null);
      setStories(s);
      setLoading(false);
    });
  }, [id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
    </div>
  );

  if (!author) return (
    <div className="min-h-screen text-white flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="text-center">
        <p className="text-white/40 mb-4">Conteur introuvable.</p>
        <Link to="/registre" className="text-red-500 underline">Retour au Registre</Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      {/* Hero — grand visuel généré représentant le rôle */}
      <section className="relative pt-0 overflow-hidden" style={{ height: "85vh", minHeight: 500 }}>
        <div className="absolute inset-0">
          <img
            src={author.hero_image_url || "https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=1600&q=80"}
            alt={author.public_name}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/20" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-between px-6 max-w-5xl mx-auto">
          <div className="pt-24">
            <Link to="/registre" className="inline-flex items-center gap-2 text-white/40 hover:text-white text-xs tracking-widest uppercase transition-colors">
              <ArrowLeft className="w-3 h-3" /> Registre
            </Link>
          </div>
          <div className="pb-16">
            <p className="text-red-500 text-xs tracking-widest uppercase mb-3">{PRESENCE_LABELS[author.presence_type] || author.presence_type}</p>
            <div className="flex items-center gap-5 mb-3">
              <div className="w-16 h-16 rounded-full overflow-hidden ring-2 ring-white/20 flex-shrink-0">
                <img
                  src={author.portrait_url || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80"}
                  alt={author.public_name}
                  className="w-full h-full object-cover object-top"
                />

              </div>
              <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 8vw, 6rem)", lineHeight: 1 }}>
                {author.public_name}
              </h1>
            </div>
            {author.signature_phrase && (
              <p className="text-white/70 italic text-lg max-w-xl">« {author.signature_phrase} »</p>
            )}
          </div>
        </div>
      </section>

      {/* Bio + stats */}
      <section className="max-w-5xl mx-auto px-6 py-10 border-b border-white/5 flex flex-col md:flex-row gap-10">
        <div className="flex-1">
          {author.short_bio ? (
            <p className="text-white/70 leading-relaxed">{author.short_bio}</p>
          ) : (
            <p className="text-white/30 italic">Ce conteur n'a pas encore partagé sa présentation.</p>
          )}
        </div>
        <div className="flex gap-8 flex-shrink-0 items-start">
          <div className="text-center">
            <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.5rem" }} className="text-red-500">{stories.length}</span>
            <p className="text-white/30 text-xs tracking-widest uppercase mt-0.5">Contes publics</p>
          </div>
        </div>
      </section>

      {/* Public stories */}
      <section className="max-w-5xl mx-auto px-6 py-12 pb-24">
        <p className="text-white/40 text-xs tracking-widest uppercase mb-6 flex items-center gap-2">
          <BookOpen className="w-3 h-3" /> Œuvres publiées
        </p>

        {stories.length === 0 ? (
          <p className="text-white/30 italic">Aucun conte public pour l'instant.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stories.map((story) => (
              <Link key={story.id} to={`/conte/${story.id}`} className="group block">
                <div className="aspect-[3/4] overflow-hidden mb-3 bg-white/5">
                  <img
                    src={story.hero_image_url || "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&q=80"}
                    alt={story.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
                  />
                </div>
                {story.subtitle && <p className="text-red-500 text-xs tracking-widest uppercase mb-1">{story.subtitle}</p>}
                <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.4rem", lineHeight: 1.1 }}>
                  {story.title}
                </h3>
                {story.tagline && <p className="text-white/40 text-xs mt-1 line-clamp-2">{story.tagline}</p>}
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}