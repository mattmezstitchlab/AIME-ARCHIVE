import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Play, Eye, EyeOff, Shield, AlertTriangle, BookOpen, Mic, Heart, Zap, Clock, Info } from "lucide-react";

const CATEGORIES = {
  consentement: { icon: Shield, color: "text-red-400", label: "Consentement" },
  dialogue: { icon: Mic, color: "text-blue-400", label: "Dialogue" },
  limites: { icon: Shield, color: "text-purple-400", label: "Limites" },
  repair: { icon: Heart, color: "text-green-400", label: "Réparation" },
  humour: { icon: Zap, color: "text-amber-400", label: "Humour" },
  slam: { icon: Mic, color: "text-pink-400", label: "Slam" },
  prevention: { icon: Info, color: "text-cyan-400", label: "Prévention" },
};

export default function SlaameAdulte() {
  const navigate = useNavigate();
  const [ageVerified, setAgeVerified] = useState(false);
  const [capsules, setCapsules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [blurEnabled, setBlurEnabled] = useState(true);

  useEffect(() => {
    const verified = localStorage.getItem("slaame18_age_verified");
    if (verified === "true") {
      setAgeVerified(true);
    }
    base44.entities.AdultCapsule.filter({ status: "published" }, "-published_at", 20).then((c) => {
      setCapsules(c);
      setLoading(false);
    });
  }, []);

  const handleAgeVerification = () => {
    localStorage.setItem("slaame18_age_verified", "true");
    setAgeVerified(true);
  };

  const handleExit = () => {
    navigate("/");
  };

  if (!ageVerified) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-6">
        <div className="max-w-2xl mx-auto text-center">
          <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-6" />
          <h1
            style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }}
            className="text-white mb-4"
          >
            SLAÂME Adulte
          </h1>
          <p className="text-red-400 text-lg mb-6 font-medium">
            Espace adulte — Contenu réservé aux personnes majeures
          </p>
          <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-8 text-left">
            <p className="text-white/70 text-sm mb-4">
              Cette page propose des vidéos adultes muettes accompagnées de textes éducatifs sur le consentement, 
              le respect, le dialogue et les limites.
            </p>
            <p className="text-white/70 text-sm mb-4">
              <strong className="text-white">Objectif :</strong> Créer une expérience adulte culturelle et responsable, 
              où la voix et le texte remettent du langage là où l'image a tout pris.
            </p>
            <p className="text-white/70 text-sm mb-4">
              <strong className="text-white">Contenu :</strong> Uniquement des vidéos licenciées, autorisées, 
              documentées et consenties. Preuves de majorité et de consentement vérifiées.
            </p>
            <p className="text-white/50 text-xs italic">
              Avertissement : Cette page contient du contenu destiné aux adultes. En continuant, vous confirmez 
              avoir plus de 18 ans et accepter les conditions d'utilisation.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={handleExit}
              className="border border-white/20 text-white px-8 py-3 text-sm tracking-widest uppercase hover:border-white/60 transition-colors rounded-full"
            >
              Quitter
            </button>
            <button
              onClick={handleAgeVerification}
              className="bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-widest uppercase hover:bg-red-700 transition-colors rounded-full"
            >
              J'ai plus de 18 ans — Continuer
            </button>
          </div>
          <p className="text-white/30 text-xs mt-8">
            Un système de vérification d'âge conforme sera intégré prochainement via un prestataire spécialisé.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1
              style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.8rem", letterSpacing: "0.1em" }}
              className="text-red-500"
            >
              SLAÂME Adulte
            </h1>
            <p className="text-white/40 text-xs">Paroles intimes & Dialogue</p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setBlurEnabled(!blurEnabled)}
              className="flex items-center gap-2 text-white/60 hover:text-white text-xs"
            >
              {blurEnabled ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {blurEnabled ? "Flou activé" : "Flou désactivé"}
            </button>
            <Link
              to="/"
              className="border border-white/20 text-white px-4 py-2 text-xs tracking-widest uppercase hover:border-white/60 transition-colors rounded-full"
            >
              Quitter
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-16 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <p className="text-red-400 tracking-widest uppercase text-xs mb-4">Paroles intimes</p>
          <h1
            style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 8vw, 5rem)", lineHeight: 1 }}
            className="mb-6"
          >
            Des capsules de parole. Des voix pour dire ce qui est difficile.
          </h1>
          <p className="text-xl text-white/60 max-w-3xl mx-auto mb-8 leading-relaxed">
            Consentement, réparation, limites, dialogue. Le slam et la voix au service de la parole adulte.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {Object.entries(CATEGORIES).map(([key, config]) => {
              const Icon = config.icon;
              return (
                <button
                  key={key}
                  className={`flex items-center gap-2 px-4 py-2 text-xs tracking-widest uppercase border border-white/10 hover:border-white/40 transition-colors rounded-full ${
                    config.color
                  }`}
                >
                  <Icon className="w-3 h-3" />
                  {config.label}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="max-w-7xl mx-auto px-6 pb-20">
        {capsules.length === 0 ? (
          <div className="text-center py-20">
            <Shield className="w-16 h-16 text-white/20 mx-auto mb-6" />
            <h3
              style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }}
              className="text-white mb-2"
            >
              Aucune capsule pour l'instant
            </h3>
            <p className="text-white/40 max-w-md mx-auto">
              Les premières capsules seront ajoutées prochainement. Revenez bientôt.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {capsules.map((capsule) => {
              const CatConfig = CATEGORIES[capsule.editorial_category] || CATEGORIES.consentement;
              const CatIcon = CatConfig.icon;
              return (
                <Link
                  key={capsule.id}
                  to={`/slaame-adulte/${capsule.id}`}
                  className="group relative bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:border-red-500/30 transition-colors"
                >
                  {/* Thumbnail */}
                  <div className="aspect-video relative overflow-hidden bg-black">
                    {capsule.video_thumbnail_url ? (
                      <img
                        src={capsule.video_thumbnail_url}
                        alt={capsule.title}
                        className={`w-full h-full object-cover transition-all ${
                          blurEnabled || capsule.is_blur_by_default ? "blur-md" : ""
                        } group-hover:scale-105`}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-red-900/20 to-black">
                        <Play className="w-12 h-12 text-white/20" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    
                    {/* Badge */}
                    <div className="absolute top-3 left-3">
                      <span className="flex items-center gap-1.5 bg-black/60 backdrop-blur-sm px-2.5 py-1.5 rounded-full text-xs">
                        <CatIcon className={`w-3 h-3 ${CatConfig.color}`} />
                        <span className="text-white/80">{CatConfig.label}</span>
                      </span>
                    </div>

                    {/* Duration */}
                    {capsule.duration && (
                      <div className="absolute bottom-3 right-3 flex items-center gap-1.5 text-white/60 text-xs">
                        <Clock className="w-3 h-3" />
                        {Math.floor(capsule.duration / 60)}:{String(capsule.duration % 60).padStart(2, "0")}
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    <h3
                      style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.3rem" }}
                      className="text-white mb-1 group-hover:text-red-400 transition-colors"
                    >
                      {capsule.title}
                    </h3>
                    {capsule.subtitle && (
                      <p className="text-white/40 text-xs mb-3 line-clamp-2">{capsule.subtitle}</p>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-white/30 text-xs">
                        {capsule.script_mode ? capsulMode(capsule.script_mode) : "Consentement"}
                      </span>
                      <span className="text-white/30 text-xs">
                        {capsule.voice_type ? voiceLabel(capsule.voice_type) : "Voix douce"}
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* Footer */}
      <section className="border-t border-white/10 py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-white/40 text-sm mb-4">
            La vidéo montre. La voix questionne. Le texte remet du langage.
          </p>
          <p className="text-white/30 text-xs leading-relaxed">
            Rien n'est publié sans droits, consentement et validation. Les vidéos sont utilisées uniquement si elles 
            sont licenciées et autorisées. Preuves de majorité et de consentement vérifiées pour chaque contenu.
          </p>
          <p className="text-white/20 text-xs mt-4 italic">
            Un système de vérification d'âge conforme sera intégré prochainement.
          </p>
        </div>
      </section>
    </div>
  );
}

function capsulMode(mode) {
  const labels = {
    consentement: "Mode consentement",
    dialogue: "Mode dialogue",
    humour: "Mode humour",
    slam: "Mode slam",
    repair: "Mode réparation",
    prevention: "Mode prévention",
  };
  return labels[mode] || mode;
}

function voiceLabel(voice) {
  const labels = {
    feminine: "Voix féminine",
    masculine: "Voix masculine",
    neutre: "Voix neutre",
    grave: "Voix grave",
    douce: "Voix douce",
    directe: "Voix directe",
    poetique: "Voix poétique",
  };
  return labels[voice] || voice;
}