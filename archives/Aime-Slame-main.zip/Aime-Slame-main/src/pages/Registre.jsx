import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

const PRESENCE_LABELS = {
  parent: "Parent",
  grand_parent: "Grand-parent",
  conteur: "Conteur",
  enseignant: "Enseignant",
  therapeute: "Thérapeute",
  auteur: "Auteur",
  profil_demo: "Profil démo",
};

const FILTERS = [
  { key: "all", label: "Tous" },
  { key: "parent", label: "Parent" },
  { key: "grand_parent", label: "Grand-parent" },
  { key: "conteur", label: "Conteur" },
  { key: "enseignant", label: "Enseignant" },
  { key: "therapeute", label: "Thérapeute" },
  { key: "auteur", label: "Auteur" },
];

// Vrais portraits humains diversifiés (format vertical portrait)
const DEFAULT_PORTRAITS = [
  "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=600&h=800&fit=crop&q=80",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&h=800&fit=crop&q=80",
];

export default function Registre() {
  const [authors, setAuthors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState("all");

  useEffect(() => {
    base44.entities.AuthorPresence.filter({ visibility: "public" }).then((a) => {
      setAuthors(a);
      setLoading(false);
    });
  }, []);

  const filtered = activeFilter === "all"
    ? authors
    : authors.filter((a) => a.presence_type === activeFilter);

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      {/* Header */}
      <section className="pt-32 pb-10 px-6 max-w-7xl mx-auto">
        <p className="text-red-500 tracking-widest uppercase text-xs mb-4">Présences</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 6rem)", lineHeight: 1 }}>
          Registre
        </h1>
        <p className="text-white/50 mt-4 max-w-xl">
          Les voix qui habitent SLAÂME — parents, conteurs, enseignants.
        </p>
      </section>

      {/* Filter bar */}
      <section className="px-6 max-w-7xl mx-auto mb-10">
        <div className="flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setActiveFilter(f.key)}
              className={`px-5 py-2 text-xs tracking-widest uppercase transition-all rounded-full ${
                activeFilter === f.key
                  ? "bg-red-600 text-white"
                  : "border border-white/15 text-white/50 hover:text-white hover:border-white/40"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </section>

      {/* Cards grid */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <p className="text-white/40 text-center py-20">Aucun conteur public pour l'instant.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filtered.map((a, i) => (
              <AuthorCard key={a.id} author={a} index={i} />
            ))}
          </div>
        )}
      </section>

      {/* Join CTA */}
      <section className="border-t border-white/10 py-16 text-center px-6">
        <p className="text-white/40 text-sm mb-2">Vous voulez apparaître dans le registre ?</p>
        <p className="text-white/25 text-xs mb-6 max-w-sm mx-auto">Créez votre premier projet dans le Lab — votre profil vocal sera enregistré à la fin du parcours.</p>
        <Link
          to="/slaame-lab"
          className="border border-red-500 text-red-400 px-8 py-3 text-xs tracking-widest uppercase hover:bg-red-600 hover:text-white transition-colors rounded-full"
        >
          Rejoindre via le Lab
        </Link>
      </section>
    </div>
  );
}

function AuthorCard({ author, index }) {
  const portrait = author.portrait_url || DEFAULT_PORTRAITS[index % DEFAULT_PORTRAITS.length];

  return (
    <Link to={`/conteur/${author.id}`} className="group relative block overflow-hidden rounded-2xl aspect-[3/4] flex-shrink-0">
      {/* Photo plein format */}
      <img
        src={portrait}
        alt={author.public_name}
        className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
      />
      {/* Gradient bas */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
      {/* Texte en bas à gauche */}
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <p className="text-red-400 text-[10px] tracking-widest uppercase mb-1">
          {PRESENCE_LABELS[author.presence_type] || author.presence_type}
        </p>
        <h3 className="text-white font-semibold text-sm leading-snug">
          {author.public_name}
        </h3>
        {author.signature_phrase && (
          <p className="text-white/50 text-xs mt-0.5 line-clamp-2">{author.signature_phrase}</p>
        )}
      </div>
    </Link>
  );
}