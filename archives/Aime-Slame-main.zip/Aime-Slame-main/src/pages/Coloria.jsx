import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Palette, BookOpen, Plus, Loader2, Check } from "lucide-react";
import ColoriaStudio from "@/components/coloria/ColoriaStudio";
import ColoriaGenerator from "@/components/coloria/ColoriaGenerator";

export default function Coloria() {
  const location = useLocation();
  const [stories, setStories] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeProject, setActiveProject] = useState(null);
  const [showGenerator, setShowGenerator] = useState(false);
  const [selectedStory, setSelectedStory] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.StoryProject.list("-created_date", 30),
      base44.entities.ColoringProject.list("-created_date", 20),
    ]).then(([s, p]) => {
      setStories(s);
      setProjects(p);
      setLoading(false);
      // Auto-open project if coming from ConteDetail
      const openId = location.state?.openProject;
      if (openId) {
        const found = p.find((proj) => proj.id === openId);
        if (found) setActiveProject(found);
      }
    });
  }, []);

  const handleProjectCreated = (project) => {
    setProjects((prev) => [project, ...prev]);
    setShowGenerator(false);
    setActiveProject(project);
  };

  if (activeProject) {
    return (
      <ColoriaStudio
        project={activeProject}
        onBack={() => setActiveProject(null)}
        onSave={(updated) => {
          setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
          setActiveProject(null);
        }}
      />
    );
  }

  if (showGenerator) {
    return (
      <ColoriaGenerator
        stories={stories}
        initialStory={selectedStory}
        onBack={() => { setShowGenerator(false); setSelectedStory(null); }}
        onCreated={handleProjectCreated}
      />
    );
  }

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      {/* Hero */}
      <section className="max-w-5xl mx-auto px-6 pt-32 pb-12">
        <p className="text-red-500 tracking-widest uppercase text-xs mb-4">Coloriage Narratif</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(4rem, 10vw, 8rem)", lineHeight: 0.9 }}>
          COLORIA
        </h1>
        <p className="text-white/50 mt-4 max-w-xl text-sm leading-relaxed">
          Transforme les scènes de tes contes en illustrations à colorier. Chaque coup de pinceau est enregistré et rejoué en animation.
        </p>
        <button
          onClick={() => setShowGenerator(true)}
          className="mt-8 bg-red-600 text-white px-8 py-3 text-sm font-medium tracking-widest uppercase hover:bg-red-500 transition-colors flex items-center gap-2 rounded-full"
        >
          <Plus className="w-4 h-4" /> Nouveau coloriage
        </button>
      </section>

      {/* Stories as source */}
      {stories.length > 0 && (
        <section className="max-w-5xl mx-auto px-6 pb-12">
          <h2 className="text-white/40 text-xs tracking-widest uppercase mb-6">Colorier une scène de conte</h2>
          <div className="flex gap-3 overflow-x-auto pb-3 scrollbar-hide">
            {stories.map((story) => (
              <button
                key={story.id}
                onClick={() => { setSelectedStory(story); setShowGenerator(true); }}
                className="flex-shrink-0 group relative w-36 h-48 overflow-hidden border border-white/10 hover:border-red-500/50 transition-all"
              >
                <img
                  src={story.hero_image_url || "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&q=60"}
                  alt={story.title}
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "0.9rem" }}>{story.title}</p>
                  <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                    <BookOpen className="w-2.5 h-2.5" /> Colorier
                  </p>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* My colorings */}
      <section className="max-w-5xl mx-auto px-6 pb-20">
        <h2 className="text-white/40 text-xs tracking-widest uppercase mb-6">Mes coloriages</h2>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-red-500" />
          </div>
        ) : projects.length === 0 ? (
          <div className="border border-white/10 p-12 text-center">
            <Palette className="w-10 h-10 text-white/20 mx-auto mb-4" />
            <p className="text-white/40 text-sm">Aucun coloriage créé. Lance-toi !</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {projects.map((project) => (
              <button
                key={project.id}
                onClick={() => setActiveProject(project)}
                className="group relative aspect-square overflow-hidden border border-white/10 hover:border-red-500/50 transition-all bg-white"
              >
                {project.line_art_url ? (
                  <img src={project.line_art_url} alt={project.title} className="w-full h-full object-contain p-2" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                  <Loader2 className="w-6 h-6 animate-spin text-red-500/50" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <span className="text-white text-xs tracking-widest uppercase font-medium">Colorier</span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-2">
                  <p className="text-white text-xs truncate">{project.title}</p>
                  {project.status === "colored" && (
                    <span className="text-red-400 text-xs flex items-center gap-1 mt-0.5">
                      <Check className="w-2.5 h-2.5" /> Colorié
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}