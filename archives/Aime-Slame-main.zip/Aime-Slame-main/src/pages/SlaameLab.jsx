import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { generateStoryFromLab } from "@/functions/generateStoryFromLab";
import { generateSceneIllustrations } from "@/functions/generateSceneIllustrations";
import { generateSceneAudio } from "@/functions/generateSceneAudio";
import VoiceBlock from "@/components/VoiceBlock";
import ColoriaSceneCard from "@/components/ColoriaSceneCard";
import { ArrowRight, Check, Loader2, Mic, BookOpen, Palette, Users } from "lucide-react";

const STEPS = [
  { id: "voix", label: "Ma voix", num: 1 },
  { id: "conte", label: "Mon conte", num: 2 },
  { id: "generation", label: "Génération", num: 3 },
  { id: "coloria", label: "Coloria", num: 4 },
];

const AUDIENCES = [
  { value: "enfants", label: "Enfants" },
  { value: "famille", label: "Famille" },
  { value: "ados", label: "Ados" },
  { value: "adultes", label: "Adultes" },
];

const STORY_TYPES = [
  { value: "conte", label: "Conte" },
  { value: "fable", label: "Fable" },
  { value: "histoire_du_soir", label: "Histoire du soir" },
  { value: "aventure", label: "Aventure" },
  { value: "recit_familial", label: "Récit familial" },
  { value: "berceuse", label: "Berceuse" },
];

const ILLUSTRATION_STYLES = [
  { value: "coloring book line art, clean outlines, children's book style, no fill, simple", label: "Coloriage classique" },
  { value: "coloring book, fairy tale style, detailed line art, magical creatures, no fill", label: "Conte de fées" },
  { value: "coloring book, adventure style, bold outlines, jungle and nature, no fill", label: "Aventure nature" },
  { value: "coloring book, dreamlike, soft outlines, stars and clouds, children, no fill", label: "Onirique" },
];

// ElevenLabs preset voices (IDs publics stables)
const PRESET_VOICES = [
  { id: "21m00Tcm4TlvDq8ikWAM", label: "Rachel", gender: "Femme", desc: "Douce, narrative" },
  { id: "AZnzlk1XvdvUeBnXmlld", label: "Domi", gender: "Femme", desc: "Chaleureuse, expressive" },
  { id: "EXAVITQu4vr4xnSDxMaL", label: "Bella", gender: "Femme", desc: "Posée, poétique" },
  { id: "ErXwobaYiN019PkySvjV", label: "Antoni", gender: "Homme", desc: "Grave, enveloppante" },
  { id: "VR6AewLTigWG4xSOukaG", label: "Arnold", gender: "Homme", desc: "Profonde, conteur" },
  { id: "pNInz6obpgDQGcFmaJgB", label: "Adam", gender: "Homme", desc: "Calme, bienveillante" },
];

const GENERATION_STEPS = [
  { id: "story", label: "Écriture du conte (3 scènes)" },
  { id: "illustrations", label: "Génération des illustrations à colorier" },
  { id: "audio", label: "Narration audio par scène" },
];

export default function SlaameLab() {
  const navigate = useNavigate();
  const [voiceProfiles, setVoiceProfiles] = useState([]);
  const [selectedVoiceModelId, setSelectedVoiceModelId] = useState("21m00Tcm4TlvDq8ikWAM");
  const [currentStep, setCurrentStep] = useState(0);

  const [form, setForm] = useState({
    title: "",
    description: "",
    audience: "enfants",
    story_type: "conte",
    illustration_style: "coloring book line art, clean outlines, children's book style, no fill, simple",
  });

  const [generating, setGenerating] = useState(false);
  const [genStep, setGenStep] = useState(null);
  const [error, setError] = useState(null);
  const [storyId, setStoryId] = useState(null);
  const [scenes, setScenes] = useState([]);
  const [globalAudio, setGlobalAudio] = useState(null);

  useEffect(() => {
    base44.entities.VoiceProfile.filter({ voice_status: "ready" }).then((profiles) => {
      setVoiceProfiles(profiles);
      // Auto-select the exact cloned ElevenLabs voice if available
      const cloned = profiles.find(p => p.voice_model_id);
      setSelectedVoiceModelId(cloned?.voice_model_id || "21m00Tcm4TlvDq8ikWAM");
    });
  }, []);

  const voiceReady = voiceProfiles.length > 0;
  const formValid = form.title.trim().length > 0;

  const handleGenerate = async () => {
    if (!formValid) return;
    setGenerating(true);
    setError(null);

    try {
      // Step 1: generate story + 3 scenes
      setGenStep("story");
      const selectedVoiceProfile = voiceProfiles.find(vp => vp.voice_model_id === selectedVoiceModelId);
      const result = await generateStoryFromLab({
        title: form.title,
        description: form.description,
        audience: form.audience,
        story_type: form.story_type,
        illustration_style: form.illustration_style,
        voice_profile_id: selectedVoiceProfile?.id || null,
      });
      if (!result?.data?.story_id) throw new Error("Génération du conte échouée");
      const sid = result.data.story_id;
      setStoryId(sid);

      // Step 2: wait for scenes to be persisted (up to 15s), then generate illustrations
      setGenStep("illustrations");
      let retries = 0;
      let scenesReady = [];
      while (scenesReady.length < 3 && retries < 10) {
        await new Promise(r => setTimeout(r, 2000));
        scenesReady = await base44.entities.StoryScene.filter({ story_project_id: sid });
        retries++;
      }
      if (scenesReady.length === 0) throw new Error("Les scènes n'ont pas pu être créées. Veuillez réessayer.");

      // Retry illustrations up to 2 times in case of transient 404
      let illErr = null;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          await generateSceneIllustrations({ story_project_id: sid });
          illErr = null;
          break;
        } catch (e) {
          illErr = e;
          await new Promise(r => setTimeout(r, 2000));
        }
      }
      if (illErr) throw illErr;

      // Step 3: generate audio per scene
      setGenStep("audio");
      const freshScenes = await base44.entities.StoryScene.filter({ story_project_id: sid });
      // Use the exact selected ElevenLabs voice ID
      const voiceModelId = selectedVoiceModelId || "21m00Tcm4TlvDq8ikWAM";
      for (const scene of freshScenes) {
        const text = scene.scene_text?.trim();
        if (!text) continue;
        await generateSceneAudio({ scene_id: scene.id, scene_text: text, voice_model_id: voiceModelId });
      }

      // Load final scenes with illustrations + audio
      const finalScenes = await base44.entities.StoryScene.filter({ story_project_id: sid });
      finalScenes.sort((a, b) => a.scene_number - b.scene_number);
      setScenes(finalScenes);

      setGenStep("done");
      setGenerating(false);
      setCurrentStep(3);

    } catch (err) {
      const msg = err.response?.data?.error || err.message || "Une erreur est survenue";
      setError(msg);
      setGenerating(false);
      setGenStep(null);
    }
  };

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>

      {/* HERO */}
      <section className="relative h-[55vh] min-h-[380px] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=1600&q=80"
            alt="SLAÂME Lab"
            className="w-full h-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0806] via-black/30 to-transparent" />
        </div>
        <div className="relative z-10 max-w-5xl mx-auto px-6 pb-12 w-full text-center">
          <p className="text-red-500 tracking-widest uppercase text-xs mb-3">Voix · Conte · Coloriage</p>
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(4rem, 10vw, 8rem)", lineHeight: 1 }}>
            SLAÂME Lab
          </h1>
          <p className="text-white/50 text-base max-w-lg mt-3 mx-auto">
            Enregistrez votre voix — l'IA écrit un conte en 3 scènes illustrées à colorier, avec votre narration sur chaque planche.
          </p>
        </div>
      </section>

      {/* CONTENT */}
      <section className="max-w-2xl mx-auto px-6 py-10 pb-28">

        {/* STEP INDICATORS */}
        <div className="flex items-center justify-center gap-3 mb-10">
          {STEPS.map((s, i) => {
            const isDone = (i === 0 && voiceReady) || (i === 1 && formValid && currentStep > 1) || (i === 2 && genStep === "done") || (i === 3 && currentStep === 3);
            const isActive = currentStep === i;
            return (
              <button
                key={s.id}
                onClick={() => { if (!generating && i < currentStep) setCurrentStep(i); }}
                className="flex items-center gap-2 group"
                disabled={generating}
              >
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
                  isDone ? "bg-red-600 text-white" :
                  isActive ? "border-2 border-red-500 text-red-400" :
                  "border border-white/20 text-white/30"
                }`}>
                  {isDone && i !== 3 ? <Check className="w-3.5 h-3.5" /> : s.num}
                </div>
                <span className={`text-xs tracking-widest uppercase transition-colors hidden sm:inline ${isActive ? "text-white" : "text-white/30"}`}>
                  {s.label}
                </span>
                {i < STEPS.length - 1 && <div className="w-6 h-px bg-white/10 ml-1" />}
              </button>
            );
          })}
        </div>

        {/* ─── ÉTAPE 1 : MA VOIX ─── */}
        {currentStep === 0 && (
          <div className="space-y-6">
            <div className="text-center">
              <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.4rem" }} className="mb-1">Votre voix source</h2>
              <p className="text-white/40 text-sm">Enregistrez votre voix une fois — elle narrera chaque scène du conte.</p>
            </div>
            <VoiceBlock voiceProfiles={voiceProfiles} onNewVoice={(v) => { setVoiceProfiles((prev) => [...prev, v]); if (v.voice_model_id) setSelectedVoiceModelId(v.voice_model_id); }} compact={voiceProfiles.length > 0} />

            {/* Sélecteur de voix */}
            <div className="space-y-3">
              <p className="text-white/40 text-xs tracking-widest uppercase">Voix narratrice</p>

              {/* Voix clonée en premier si dispo */}
              {voiceProfiles.length > 0 && voiceProfiles.map((vp) => (
                <button
                  key={vp.id}
                  onClick={() => setSelectedVoiceModelId(vp.voice_model_id)}
                  disabled={!vp.voice_model_id}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all text-left ${
                    selectedVoiceModelId === vp.voice_model_id && vp.voice_model_id
                      ? "border-red-500 bg-red-500/10"
                      : !vp.voice_model_id
                      ? "border-white/5 opacity-50 cursor-not-allowed"
                      : "border-white/10 bg-white/3 hover:border-white/25"
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${selectedVoiceModelId === vp.voice_model_id && vp.voice_model_id ? "bg-red-600" : "bg-white/10"}`}>
                    <Mic className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">{vp.display_name || "Ma voix"}</p>
                    <p className="text-white/40 text-xs mt-0.5">
                      {vp.voice_model_id ? "Ma voix clonée ✓" : "Clonage non finalisé — ré-enregistrez votre voix"}
                    </p>
                  </div>
                  {selectedVoiceModelId === vp.voice_model_id && vp.voice_model_id && <Check className="w-4 h-4 text-red-400 flex-shrink-0" />}
                </button>
              ))}

              {/* Voix prédéfinies */}
              <div className="grid grid-cols-2 gap-2">
                {PRESET_VOICES.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => setSelectedVoiceModelId(v.id)}
                    className={`flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${
                      selectedVoiceModelId === v.id || (!selectedVoiceModelId && v.id === "21m00Tcm4TlvDq8ikWAM")
                        ? "border-red-500 bg-red-500/10"
                        : "border-white/10 bg-white/3 hover:border-white/25"
                    }`}
                  >
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-medium ${
                      selectedVoiceModelId === v.id || (!selectedVoiceModelId && v.id === "21m00Tcm4TlvDq8ikWAM")
                        ? "bg-red-600 text-white"
                        : "bg-white/10 text-white/50"
                    }`}>
                      {v.gender === "Femme" ? "F" : "H"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-xs font-medium">{v.label}</p>
                      <p className="text-white/40 text-xs truncate">{v.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              {!voiceReady && <p className="text-white/30 text-xs">Sans voix, une narration par défaut sera utilisée.</p>}
              <div className="ml-auto">
                <button onClick={() => setCurrentStep(1)} className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white text-xs tracking-wider uppercase px-6 py-2.5 rounded-full transition-colors">
                  {voiceReady ? "Continuer" : "Passer"} <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ─── ÉTAPE 2 : MON CONTE ─── */}
        {currentStep === 1 && (
          <div className="space-y-8">
            <div className="text-center">
              <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.4rem" }} className="mb-1">Votre conte</h2>
              <p className="text-white/40 text-sm">Quelques mots suffisent — l'IA crée 3 scènes illustrées à colorier.</p>
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Titre du conte <span className="text-red-500">*</span></label>
              <input type="text" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Ex : La petite étoile qui avait peur du noir"
                className="w-full bg-white/5 border border-white/10 focus:border-red-500 text-white px-4 py-3 text-sm rounded-xl focus:outline-none placeholder-white/25 transition-colors" />
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-2">Intention ou contexte</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Pour qui est ce conte ? Qu'est-ce que vous voulez transmettre ?"
                rows={3} className="w-full bg-white/5 border border-white/10 focus:border-red-500 text-white px-4 py-3 text-sm rounded-xl focus:outline-none resize-none placeholder-white/25 transition-colors" />
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-3"><Users className="w-3 h-3 inline mr-1.5" />Public</label>
              <div className="flex flex-wrap gap-2">
                {AUDIENCES.map((a) => (
                  <button key={a.value} onClick={() => setForm({ ...form, audience: a.value })}
                    className={`px-4 py-2 text-xs rounded-full transition-colors border ${form.audience === a.value ? "bg-red-600 border-red-600 text-white" : "border-white/15 text-white/50 hover:text-white hover:border-white/40"}`}>
                    {a.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-3"><BookOpen className="w-3 h-3 inline mr-1.5" />Type de récit</label>
              <div className="flex flex-wrap gap-2">
                {STORY_TYPES.map((t) => (
                  <button key={t.value} onClick={() => setForm({ ...form, story_type: t.value })}
                    className={`px-4 py-2 text-xs rounded-full transition-colors border ${form.story_type === t.value ? "bg-red-600 border-red-600 text-white" : "border-white/15 text-white/50 hover:text-white hover:border-white/40"}`}>
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-white/40 text-xs tracking-widest uppercase block mb-3"><Palette className="w-3 h-3 inline mr-1.5" />Style de coloriage</label>
              <div className="flex flex-wrap gap-2">
                {ILLUSTRATION_STYLES.map((s) => (
                  <button key={s.value} onClick={() => setForm({ ...form, illustration_style: s.value })}
                    className={`px-4 py-2 text-xs rounded-full transition-colors border ${form.illustration_style === s.value ? "bg-red-600 border-red-600 text-white" : "border-white/15 text-white/50 hover:text-white hover:border-white/40"}`}>
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button onClick={() => setCurrentStep(0)} className="text-white/30 hover:text-white text-xs tracking-widest uppercase transition-colors">← Retour</button>
              <button onClick={() => setCurrentStep(2)} disabled={!formValid}
                className="flex items-center gap-2 bg-red-600 hover:bg-red-500 disabled:opacity-30 text-white text-xs tracking-wider uppercase px-6 py-2.5 rounded-full transition-colors">
                Suivant <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* ─── ÉTAPE 3 : GÉNÉRATION ─── */}
        {currentStep === 2 && (
          <div className="space-y-8">
            <div className="text-center">
              <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.4rem" }} className="mb-1">Génération</h2>
              <p className="text-white/40 text-sm">L'IA écrit, illustre et narre votre conte en 3 scènes.</p>
            </div>

            {/* Résumé */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-white font-medium">{form.title}</p>
                  {form.description && <p className="text-white/40 text-xs mt-1">{form.description}</p>}
                </div>
                <button onClick={() => setCurrentStep(1)} className="text-white/30 text-xs hover:text-white">Modifier</button>
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                {[form.audience, form.story_type].map((v) => (
                  <span key={v} className="px-2.5 py-1 text-xs bg-white/5 border border-white/10 rounded-full text-white/50">{v}</span>
                ))}
                {(() => {
                  const selectedVoiceProfile = voiceProfiles.find(vp => vp.voice_model_id === selectedVoiceModelId);
                  const voiceLabel = selectedVoiceProfile?.display_name || PRESET_VOICES.find(v => v.id === selectedVoiceModelId)?.label || "Rachel";
                  return (
                    <span className="px-2.5 py-1 text-xs bg-red-500/10 border border-red-500/30 rounded-full text-red-400 flex items-center gap-1">
                      <Mic className="w-2.5 h-2.5" /> {voiceLabel}
                    </span>
                  );
                })()}
              </div>
            </div>

            {/* Progress */}
            {generating && (
              <div className="space-y-3">
                {GENERATION_STEPS.map((s) => {
                  const isActive = genStep === s.id;
                  const isDone = genStep === "done" ||
                    (s.id === "story" && (genStep === "illustrations" || genStep === "audio")) ||
                    (s.id === "illustrations" && genStep === "audio");
                  return (
                    <div key={s.id} className={`flex items-center gap-3 py-3 px-4 rounded-xl transition-all ${
                      isActive ? "bg-red-500/10 border border-red-500/30" :
                      isDone ? "bg-white/5 border border-white/5" :
                      "border border-white/5 opacity-30"
                    }`}>
                      <div className="w-5 h-5 flex-shrink-0 flex items-center justify-center">
                        {isDone ? <Check className="w-4 h-4 text-red-400" /> :
                         isActive ? <Loader2 className="w-4 h-4 animate-spin text-red-400" /> :
                         <div className="w-4 h-4 rounded-full border border-white/20" />}
                      </div>
                      <p className={`text-sm ${isActive ? "text-white" : isDone ? "text-white/50" : "text-white/20"}`}>{s.label}</p>
                    </div>
                  );
                })}
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                <p className="text-red-400 text-sm">{error}</p>
                <button onClick={() => { setError(null); setGenerating(false); setGenStep(null); }} className="text-xs text-white/40 hover:text-white mt-2">Réessayer</button>
              </div>
            )}

            {!generating && !error && (
              <div className="flex items-center justify-between">
                <button onClick={() => setCurrentStep(1)} className="text-white/30 hover:text-white text-xs tracking-widest uppercase transition-colors">← Retour</button>
                <button onClick={handleGenerate}
                  className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white text-sm tracking-wider uppercase px-8 py-3 rounded-full transition-colors">
                  Créer mon conte <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ─── ÉTAPE 4 : COLORIA ─── */}
        {currentStep === 3 && (
          <div className="space-y-8">
            <div className="text-center">
              <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2.4rem" }} className="mb-1">Votre Coloria</h2>
              <p className="text-white/40 text-sm">3 scènes à colorier — appuyez sur ▶ pour écouter la narration.</p>
            </div>

            <div className="space-y-6">
              {scenes.map((scene, i) => (
                <ColoriaSceneCard key={scene.id} scene={scene} index={i} globalAudio={globalAudio} setGlobalAudio={setGlobalAudio} />
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <button
                onClick={() => navigate(`/conte/${storyId}`)}
                className="flex-1 border border-white/20 text-white px-6 py-3 text-xs tracking-widest uppercase hover:border-white/50 transition-colors rounded-full text-center"
              >
                Lire le conte complet
              </button>
              <button
                onClick={() => { setCurrentStep(0); setForm({ title: "", description: "", audience: "enfants", story_type: "conte", illustration_style: ILLUSTRATION_STYLES[0].value }); setScenes([]); setStoryId(null); setGenStep(null); }}
                className="flex-1 bg-red-600 hover:bg-red-500 text-white px-6 py-3 text-xs tracking-wider uppercase rounded-full transition-colors text-center"
              >
                Créer un nouveau conte
              </button>
            </div>
          </div>
        )}

      </section>
    </div>
  );
}