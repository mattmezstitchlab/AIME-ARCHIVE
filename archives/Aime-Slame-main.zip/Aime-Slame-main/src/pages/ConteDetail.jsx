import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, BookOpen, Headphones, Baby, Palette, Loader2, Volume2, User, Share2, Check } from "lucide-react";
import { generateDemoAudio } from "@/functions/generateDemoAudio";

export default function ConteDetail() {
  const { id } = useParams();
  const [story, setStory] = useState(null);
  const [scenes, setScenes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [mode, setMode] = useState("lecture"); // lecture | audio | enfant
  const [coloringProjects, setColoringProjects] = useState([]);
  const [author, setAuthor] = useState(null);
  const [generatingAudio, setGeneratingAudio] = useState(false);
  const [copied, setCopied] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    Promise.all([
      base44.entities.StoryProject.filter({ id: id }),
      base44.entities.StoryScene.filter({ story_project_id: id }, "scene_number"),
      base44.entities.ColoringProject.filter({ story_project_id: id }),
    ]).then(([s, sc, cp]) => {
      const story = s[0] || null;
      setStory(story);
      setScenes(sc);
      setColoringProjects(cp);
      if (story?.author_presence_id) {
        base44.entities.AuthorPresence.list().then((all) => {
          setAuthor(all.find(a => a.id === story.author_presence_id) || null);
        });
      }
      setLoading(false);
    });
  }, [id]);

  useEffect(() => {
    if (!playing) { clearInterval(timerRef.current); return; }
    const dur = story?.duration || 300;
    timerRef.current = setInterval(() => {
      setProgress((p) => { if (p >= 100) { setPlaying(false); return 100; } return p + (100 / dur / 2); });
    }, 500);
    return () => clearInterval(timerRef.current);
  }, [playing, story]);

  const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const elapsed = Math.floor((progress / 100) * (story?.duration || 300));

  const copyShareLink = () => {
    const url = `${window.location.origin}/conte/${story.id}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="w-8 h-8 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
    </div>
  );

  if (!story) return (
    <div className="min-h-screen text-white flex items-center justify-center" style={{ background: "#0a0806" }}>
      <div className="text-center">
        <p className="text-white/40 mb-4">Conte introuvable.</p>
        <Link to="/" className="text-red-500 underline">Retour à l'accueil</Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen text-white" style={{ background: "#0a0806" }}>
      {/* Hero */}
      <section className="relative h-[70vh] flex items-end pb-12 overflow-hidden">
        <div className="absolute inset-0">
          <img src={story.hero_image_url || "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400&q=80"} alt={story.title} className="w-full h-full object-cover opacity-50" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 w-full">
          <button onClick={() => window.history.back()} className="flex items-center gap-2 text-white/40 hover:text-white text-xs tracking-widest uppercase mb-6 transition-colors">
            <ArrowLeft className="w-3 h-3" /> Retour
          </button>
          <p className="text-red-500 text-xs tracking-widest uppercase mb-2">{story.subtitle}</p>
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 6rem)", lineHeight: 1 }}>
            {story.title}
          </h1>
          {story.tagline && <p className="text-white/60 mt-3 max-w-xl">{story.tagline}</p>}
          <div className="flex items-center gap-4 mt-4">
            {author && (
              <Link to={`/conteur/${author.id}`} className="inline-flex items-center gap-2 text-white/40 hover:text-red-500 text-xs tracking-widest uppercase transition-colors">
                <User className="w-3 h-3" /> {author.public_name}
              </Link>
            )}
            <button onClick={copyShareLink} className="inline-flex items-center gap-2 text-white/40 hover:text-red-500 text-xs tracking-widest uppercase transition-colors">
              {copied ? <Check className="w-3 h-3" /> : <Share2 className="w-3 h-3" />}
              {copied ? "Copié" : "Partager"}
            </button>
          </div>
        </div>
      </section>

      {/* Mode selector */}
      <section className="max-w-4xl mx-auto px-6 py-8">
        <div className="flex gap-2 mb-10">
          {[
            { key: "lecture", icon: BookOpen, label: "Lecture" },
            { key: "audio", icon: Headphones, label: "Audio" },
            { key: "enfant", icon: Baby, label: "Mode enfant" },
          ].map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              onClick={() => setMode(key)}
              className={`flex items-center gap-2 px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${
                mode === key ? "bg-red-600 text-white" : "border border-white/20 text-white/60 hover:text-white"
              }`}
            >
              <Icon className="w-3 h-3" /> {label}
            </button>
          ))}
        </div>

        {/* Audio controls */}
        {mode === "audio" && (
          <div className="mb-10 p-6 bg-white/5 rounded-2xl">
            {story.audio_url ? (
              <>
                <audio
                  src={story.audio_url}
                  controls
                  className="w-full mb-3"
                  style={{ accentColor: "#dc2626" }}
                />
                {story.narrator_name && <p className="text-white/40 text-xs">Narré avec {story.narrator_name}</p>}
              </>
            ) : (
              <div className="text-center py-4">
                <p className="text-white/40 text-sm mb-4">Aucun audio disponible pour ce conte.</p>
                <button
                  onClick={async () => {
                    setGeneratingAudio(true);
                    const res = await generateDemoAudio({ story_project_id: story.id });
                    if (res.data?.audio_url) setStory({ ...story, audio_url: res.data.audio_url });
                    setGeneratingAudio(false);
                  }}
                  disabled={generatingAudio}
                  className="flex items-center gap-2 mx-auto bg-red-600 text-white px-6 py-3 text-xs tracking-widest uppercase hover:bg-red-500 transition-colors disabled:opacity-50 rounded-full"
                >
                  {generatingAudio ? <Loader2 className="w-4 h-4 animate-spin" /> : <Volume2 className="w-4 h-4" />}
                  {generatingAudio ? "Génération en cours..." : "Générer l'audio"}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Scenes */}
        {scenes.length > 0 && mode !== "audio" && (
          <div className="space-y-12 pb-20">
            {scenes.map((scene) => (
              <div key={scene.id} className={`${mode === "enfant" ? "text-xl leading-loose" : ""}`}>
                {scene.chapter_title && (
                  <h3 className="text-red-500 text-xs tracking-widest uppercase mb-4">{scene.chapter_title}</h3>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                  {scene.illustration_url && (
                    <img src={scene.illustration_url} alt="" className="w-full object-cover" />
                  )}
                  <div>
                    <p className="text-white/80 leading-relaxed">{scene.scene_text}</p>
                    {scene.audio_segment_url && (
                      <audio src={scene.audio_segment_url} controls className="w-full mt-4 h-8" style={{ accentColor: "#dc2626" }} />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Fallback text */}
        {scenes.length === 0 && story.text_content && (
          <div className="pb-20">
            <p className={`text-white/80 leading-relaxed whitespace-pre-wrap ${mode === "enfant" ? "text-xl leading-loose" : ""}`}>
              {story.text_content}
            </p>
          </div>
        )}

        {/* COLORIA section */}
        {coloringProjects.length > 0 && (
          <section className="border-t border-white/10 pt-12 pb-20">
            <p className="text-red-500 text-xs tracking-widest uppercase mb-2 flex items-center gap-2">
              <Palette className="w-3 h-3" /> Coloria — Coloriage Narratif
            </p>
            <h3 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "2rem" }} className="mb-6">
              Colorier les scènes de ce conte
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {coloringProjects.map((cp) => (
                <Link
                  key={cp.id}
                  to={`/coloria`}
                  state={{ openProject: cp.id }}
                  className="group relative aspect-square overflow-hidden border border-white/10 hover:border-red-500/50 transition-all bg-white"
                >
                  <img src={cp.line_art_url} alt={cp.title} className="w-full h-full object-contain p-2 group-hover:scale-105 transition-transform duration-300" />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <span className="text-white text-xs tracking-widest uppercase font-medium bg-red-600 px-3 py-1">Colorier</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-2">
                    <p className="text-white text-xs truncate">{cp.title}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </section>
    </div>
  );
}