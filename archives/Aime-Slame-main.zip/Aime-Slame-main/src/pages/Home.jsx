import { Link } from "react-router-dom";
import { ChevronRight, Mic } from "lucide-react";

const MODULES = [
  {
    href: "/collections",
    label: "Collections",
    tag: "Bibliothèque narrative",
    title: "Histoires\npour tous",
    description: "Des univers soigneusement composés — berceuses, aventures, fables, récits familiaux. Pour chaque âge, chaque moment.",
    cta: "Explorer",
    image: "https://media.base44.com/images/public/6a2d5f4e5c8199fdddef5036/a81c8edfd_generated_image.png",
    accent: "amber",
  },
  {
    href: "/slaame-lab",
    label: "SLAÂME Lab",
    tag: "Laboratoire créatif",
    title: "Transforme\nton idée",
    description: "Dépose un texte, des images, des liens. Le Lab analyse, propose des directions créatives et génère vos contenus.",
    cta: "Entrer dans le Lab",
    image: "https://media.base44.com/images/public/6a2d5f4e5c8199fdddef5036/4fec329ac_generated_image.png",
    accent: "amber",
  },

];

const accentClasses = {
  amber: { tag: "text-red-500", cta: "bg-red-600 hover:bg-red-500 text-white", border: "border-red-500/20" },
  pink: { tag: "text-red-400", cta: "bg-red-600 hover:bg-red-500 text-white", border: "border-red-500/20" },
  red: { tag: "text-red-500", cta: "bg-red-600 hover:bg-red-500 text-white", border: "border-red-500/20" },
};

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero plein écran */}
      <section className="relative h-screen flex items-end pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1800&q=80"
            alt="SLAÂME"
            className="w-full h-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
        </div>
        <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
          <p className="text-red-500 tracking-widest uppercase text-xs mb-4">La plateforme narrative</p>
          <h1
            className="text-white leading-none mb-6"
            style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(5rem, 14vw, 12rem)" }}
          >
            SLAÂME
          </h1>
          <p className="text-white/60 text-xl max-w-2xl mb-8 leading-relaxed">
            Enregistrez votre voix une fois. L'IA écrit un conte en 3 scènes illustrées — chaque planche devient un coloriage avec votre narration à écouter.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/slaame-lab"
              className="bg-red-600 text-white px-8 py-3.5 text-sm font-medium tracking-wider uppercase hover:bg-red-500 transition-colors rounded-full flex items-center gap-2"
            >
              <Mic className="w-4 h-4" /> Créer mon conte
            </Link>
            <a href="#modules" className="border border-white/20 text-white px-8 py-3.5 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-full text-center">
              Explorer
            </a>
          </div>
        </div>
      </section>

      {/* Modules — une section par univers */}
      <div id="modules">
        {MODULES.map((mod, i) => {
          const ac = accentClasses[mod.accent];
          const isEven = i % 2 === 0;
          return (
            <section
              key={mod.href}
              className="relative min-h-screen flex items-center overflow-hidden"
            >
              {/* Image fond */}
              <div className="absolute inset-0">
              <img
                src={mod.image}
                alt={mod.label}
                className="w-full h-full object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-black/40" />
              </div>

              <div className="relative z-10 max-w-6xl mx-auto px-6 w-full py-32 flex items-center justify-center">
                <div className="text-center max-w-2xl">
                  <p className={`${ac.tag} tracking-widest uppercase text-xs mb-3`}>{mod.tag}</p>
                  <h2
                    className="text-white leading-none mb-6 whitespace-pre-line"
                    style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(4rem, 9vw, 8rem)" }}
                  >
                    {mod.title}
                  </h2>
                  <p className="text-white/70 text-lg leading-relaxed mb-10">
                    {mod.description}
                  </p>
                  <Link
                    to={mod.href}
                    className={`inline-flex items-center gap-2 px-8 py-3.5 text-sm font-medium tracking-wider uppercase transition-colors rounded-full ${ac.cta}`}
                  >
                    {mod.cta}
                    <ChevronRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </section>
          );
        })}
      </div>

      {/* Ticker */}
      <div className="overflow-hidden border-t border-b border-white/10 py-4 bg-black/30">
        <div className="flex whitespace-nowrap animate-[ticker_20s_linear_infinite]">
          {Array(6).fill(null).map((_, i) => (
            <span key={i} className="inline-flex items-center gap-6 px-6 text-white/20 text-sm tracking-widest uppercase font-heading">
              SLAÂME <span className="text-red-600">·</span> CONTE <span className="text-red-600">·</span> VOIX <span className="text-red-600">·</span> HISTOIRE <span className="text-red-600">·</span> COLORIA <span className="text-red-600">·</span> LAB <span className="text-red-600">·</span>
            </span>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-[#0a0806] px-6 pt-14 pb-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-12">
            <div>
              <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "1.4rem", letterSpacing: "0.15em" }} className="text-white mb-4">SLAÂME</p>
              <p className="text-white/30 text-xs leading-relaxed">La voix qui raconte.<br />L'histoire qui reste.</p>
            </div>
            <div>
              <p className="text-white/50 text-xs tracking-widest uppercase mb-4">Explorer</p>
              <ul className="space-y-2.5">
                {[{ label: "Collections", href: "/collections" }, { label: "Registre", href: "/registre" }, { label: "Coloria", href: "/coloria" }].map(l => (
                  <li key={l.href}><Link to={l.href} className="text-white/40 hover:text-white text-xs transition-colors">{l.label}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-white/50 text-xs tracking-widest uppercase mb-4">Créer</p>
              <ul className="space-y-2.5">
                {[{ label: "Lab", href: "/slaame-lab" }, { label: "Coloria", href: "/coloria" }, { label: "Mes Histoires", href: "/mes-histoires" }].map(l => (
                  <li key={l.href}><Link to={l.href} className="text-white/40 hover:text-white text-xs transition-colors">{l.label}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-white/50 text-xs tracking-widest uppercase mb-4">Accès</p>
              <ul className="space-y-2.5">
                {[{ label: "Connexion", href: "/login" }, { label: "Inscription", href: "/register" }].map(l => (
                  <li key={l.href}><Link to={l.href} className="text-white/40 hover:text-white text-xs transition-colors">{l.label}</Link></li>
                ))}
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between gap-3">
            <p className="text-white/20 text-xs">© 2026 SLAÂME — Tous droits réservés</p>
            <p className="text-white/20 text-xs">La plateforme narrative</p>
          </div>
        </div>
      </footer>
    </div>
  );
}