import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { elevenLabsGenerateAudio } from "@/functions/elevenLabsGenerateAudio";
import { generateStoryIllustrations } from "@/functions/generateStoryIllustrations";
import { Loader2, Sparkles, Mic, Volume2, AlertTriangle } from "lucide-react";

const AUDIENCES = ["enfants", "ados", "adultes", "famille"];
const TYPES = ["conte", "fable", "histoire_du_soir", "berceuse", "aventure", "slam_doux", "lettre_racontee"];
const THEMES = ["amour", "courage", "amitié", "nature", "famille", "magie", "voyage", "identité", "peur", "joie"];

export default function Studio() {
  const [form, setForm] = useState({ title: "", target_audience: "", story_type: "", themes: [], custom_keywords: "", music_style: "" });
  const navigate = useNavigate();
  const [generating, setGenerating] = useState(false);
  const [done, setDone] = useState(null);
  const [voiceProfiles, setVoiceProfiles] = useState([]);
  const [selectedVoiceId, setSelectedVoiceId] = useState(null);
  const [generatingAudio, setGeneratingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState(null);
  const [hasVoice, setHasVoice] = useState(null); // null=loading, true/false

  useEffect(() => {
    base44.entities.VoiceProfile.filter({ voice_status: "ready" }).then((profiles) => {
      const withModel = profiles.filter((p) => p.voice_model_id);
      setVoiceProfiles(withModel);
      setHasVoice(withModel.length > 0);
      if (withModel.length > 0) setSelectedVoiceId(withModel[0].voice_model_id);
    });
  }, []);

  const generateAudio = async () => {
    if (!done || !selectedVoiceId) return;
    setGeneratingAudio(true);
    const text = done.text_content || done.tagline || done.title;
    const res = await elevenLabsGenerateAudio({
      text: text.slice(0, 4000), // ElevenLabs limit
      voice_id: selectedVoiceId,
      story_project_id: done.id,
    });
    if (res.data?.audio_url) setAudioUrl(res.data.audio_url);
    setGeneratingAudio(false);
  };

  const toggle = (field, val) => {
    setForm((f) => ({
      ...f,
      [field]: f[field].includes(val) ? f[field].filter((x) => x !== val) : [...f[field], val],
    }));
  };

  const generate = async () => {
    if (!form.title || !form.target_audience || !form.story_type) return;
    setGenerating(true);
    const prompt = `Écris un ${form.story_type} pour ${form.target_audience} intitulé "${form.title}". Thèmes : ${form.themes.join(", ") || "libre"}. Mots-clés : ${form.custom_keywords || "aucun"}. Structure en 4 scènes avec un titre de chapitre par scène. Retourne un JSON avec: title, subtitle, tagline, text_content, scene_breakdown (array of {scene_number, chapter_title, scene_text, illustration_prompt}).`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          subtitle: { type: "string" },
          tagline: { type: "string" },
          text_content: { type: "string" },
          scene_breakdown: { type: "array", items: { type: "object" } },
        },
      },
    });

    const project = await base44.entities.StoryProject.create({
      title: result.title || form.title,
      subtitle: result.subtitle,
      tagline: result.tagline,
      target_audience: form.target_audience,
      story_type: form.story_type,
      themes: form.themes,
      custom_keywords: form.custom_keywords,
      music_style: form.music_style,
      text_content: result.text_content,
      scene_breakdown: result.scene_breakdown,
      status: "generated",
      visibility: "private",
    });

    if (result.scene_breakdown?.length) {
      await base44.entities.StoryScene.bulkCreate(
        result.scene_breakdown.map((s) => ({ ...s, story_project_id: project.id }))
      );
      // Generate illustrations in background (non-blocking)
      generateStoryIllustrations({ story_project_id: project.id }).catch(console.error);
    }

    setDone(project);
    setGenerating(false);
    navigate(`/conte/${project.id}`);
  };

  if (done) return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 rounded-full bg-amber-500 flex items-center justify-center mx-auto mb-6">
          <Sparkles className="w-8 h-8 text-black" />
        </div>
        <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "3rem" }}>{done.title}</h2>
        <p className="text-white/50 mt-2 mb-8">{done.tagline}</p>
        {/* Audio generation section */}
        {voiceProfiles.length > 0 && (
          <div className="mt-8 p-6 border border-white/10 text-left">
            <p className="text-amber-400 text-xs tracking-widest uppercase mb-3 flex items-center gap-2">
              <Mic className="w-3 h-3" /> Narration avec votre voix
            </p>
            {voiceProfiles.length > 1 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {voiceProfiles.map((p) => (
                  <button key={p.id} onClick={() => setSelectedVoiceId(p.voice_model_id)}
                    className={`px-3 py-1 text-xs tracking-wider uppercase transition-colors rounded-full ${selectedVoiceId === p.voice_model_id ? "bg-amber-500 text-black" : "border border-white/20 text-white/60 hover:text-white"}`}>
                    {p.display_name}
                  </button>
                ))}
              </div>
            )}
            {audioUrl ? (
              <div>
                <audio src={audioUrl} controls className="w-full mb-3" />
                <p className="text-white/40 text-xs">Audio généré avec votre voix clonée.</p>
              </div>
            ) : (
              <button onClick={generateAudio} disabled={generatingAudio}
                className="bg-white/10 text-white px-6 py-3 text-sm tracking-widest uppercase hover:bg-white/20 transition-colors disabled:opacity-50 flex items-center gap-2 rounded-full">
                {generatingAudio ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération audio...</> : <><Volume2 className="w-4 h-4" /> Générer l'audio</>}
              </button>
            )}
          </div>
        )}

        <div className="flex gap-4 justify-center mt-6">
          <Link to={`/conte/${done.id}`} className="bg-amber-500 text-black px-8 py-3 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full">
            Lire le conte
          </Link>
          <button onClick={() => { setDone(null); setAudioUrl(null); setForm({ title: "", target_audience: "", story_type: "", themes: [], custom_keywords: "", music_style: "" }); }} className="border border-white/20 text-white px-6 py-3 text-sm tracking-wider uppercase hover:border-white/60 transition-colors rounded-fullion-colors">
            Nouveau conte
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white">
      <section className="max-w-3xl mx-auto px-6 pt-32 pb-20">
        <p className="text-amber-400 tracking-widest uppercase text-xs mb-4">Atelier de création</p>
        <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(3rem, 7vw, 5rem)", lineHeight: 1 }}>
          Studio
        </h1>
        <p className="text-white/50 mt-4 mb-12">Configurez votre conte et laissez l'IA le rédiger pour vous.</p>

        {/* Voice banner */}
        {hasVoice === false && (
          <div className="flex items-start gap-4 p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl mb-10">
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-amber-300 text-sm font-medium mb-1">Aucune voix enregistrée</p>
              <p className="text-white/50 text-xs mb-3">Enregistrez votre voix pour que l'IA puisse narrer vos contes avec votre propre timbre.</p>
              <Link to="/mon-espace" className="text-xs tracking-widest uppercase text-amber-400 hover:text-amber-300 transition-colors flex items-center gap-1">
                Enregistrer ma voix <Mic className="w-3 h-3" />
              </Link>
            </div>
          </div>
        )}

        <div className="space-y-10">
          {/* Title */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Titre du conte *</label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Ex : La Forêt des Murmures"
              className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Audience */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Public *</label>
            <div className="flex flex-wrap gap-2">
              {AUDIENCES.map((a) => (
                <button key={a} onClick={() => setForm({ ...form, target_audience: a })}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${form.target_audience === a ? "bg-amber-500 text-black" : "border border-white/20 text-white/60 hover:text-white"}`}>
                  {a}
                </button>
              ))}
            </div>
          </div>

          {/* Type */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Type de récit *</label>
            <div className="flex flex-wrap gap-2">
              {TYPES.map((t) => (
                <button key={t} onClick={() => setForm({ ...form, story_type: t })}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${form.story_type === t ? "bg-amber-500 text-black" : "border border-white/20 text-white/60 hover:text-white"}`}>
                  {t.replace(/_/g, " ")}
                </button>
              ))}
            </div>
          </div>

          {/* Themes */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Thèmes</label>
            <div className="flex flex-wrap gap-2">
              {THEMES.map((t) => (
                <button key={t} onClick={() => toggle("themes", t)}
                  className={`px-4 py-2 text-xs tracking-widest uppercase transition-colors rounded-full ${form.themes.includes(t) ? "bg-amber-500 text-black" : "border border-white/20 text-white/60 hover:text-white"}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Keywords */}
          <div>
            <label className="text-white/60 text-xs tracking-widest uppercase block mb-3">Mots-clés libres</label>
            <input
              type="text"
              value={form.custom_keywords}
              onChange={(e) => setForm({ ...form, custom_keywords: e.target.value })}
              placeholder="Ex : grand-mère, chêne centenaire, étoile filante..."
              className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            onClick={generate}
            disabled={generating || !form.title || !form.target_audience || !form.story_type}
            className="w-full bg-amber-500 text-black py-4 text-sm font-medium tracking-widest uppercase hover:bg-amber-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2 rounded-full"
          >
            {generating ? <><Loader2 className="w-4 h-4 animate-spin" /> Génération en cours...</> : <><Sparkles className="w-4 h-4" /> Générer le conte</>}
          </button>
        </div>
      </section>
    </div>
  );
}