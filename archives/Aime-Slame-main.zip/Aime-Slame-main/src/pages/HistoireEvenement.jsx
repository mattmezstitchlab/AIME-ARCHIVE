import { Link } from "react-router-dom";
import {
  BookOpen, Mic, Palette, Calendar, Users, CheckCircle,
  Heart, Music, Gift, Sparkles, ArrowRight, Play, Shield, Lock
} from "lucide-react";
import EventHero from "@/components/event/EventHero";
import EventPrinciple from "@/components/event/EventPrinciple";
import EventTypeSelector from "@/components/event/EventTypeSelector";
import EventCreationModule from "@/components/event/EventCreationModule";
import EventPreview from "@/components/event/EventPreview";
import EventDualFace from "@/components/event/EventDualFace";
import EventPublicPage from "@/components/event/EventPublicPage";
import EventPrivateCockpit from "@/components/event/EventPrivateCockpit";
import EventAfterStory from "@/components/event/EventAfterStory";
import EventSafeguards from "@/components/event/EventSafeguards";

export default function HistoireEvenement() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <EventHero />

      {/* Le Principe */}
      <EventPrinciple />

      {/* Sélecteur de type d'événement */}
      <EventTypeSelector />

      {/* Module de création guidée */}
      <EventCreationModule />

      {/* Résultat généré — Aperçu */}
      <EventPreview />

      {/* Double face : créatif / organisation */}
      <EventDualFace />

      {/* Page publique événement */}
      <EventPublicPage />

      {/* Cockpit privé */}
      <EventPrivateCockpit />

      {/* Après l'événement */}
      <EventAfterStory />

      {/* Garde-fous et confidentialité */}
      <EventSafeguards />

      {/* Footer CTA */}
      <section className="py-20 px-6 bg-gradient-to-b from-black to-amber-950/20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(2.5rem, 6vw, 4rem)" }} className="mb-6">
            Tout commence par une histoire.
          </h2>
          <p className="text-white/50 text-lg mb-8 max-w-2xl mx-auto">
            Puis l'histoire devient votre événement.
          </p>
          <Link
            to="/creer"
            state={{ preset: "event" }}
            className="inline-flex items-center gap-2 bg-amber-500 text-black px-10 py-4 text-sm font-medium tracking-wider uppercase hover:bg-amber-400 transition-colors rounded-full"
          >
            Créer l'histoire de mon événement <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}