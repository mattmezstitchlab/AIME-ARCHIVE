# L'Éden du Mont Noir - Événements Privés

## Architecture & Infrastructure

- [ ] Schéma de base de données : tables events, event_statuses, event_types, users
- [ ] Procédures tRPC pour CRUD événements
- [ ] Procédures tRPC pour gestion des statuts (admin)
- [ ] Procédures tRPC pour notifications propriétaire
- [ ] Système de génération de codes d'accès uniques (EDEN-XXXX)
- [ ] Middleware d'authentification pour pages privées par code

## Design Système & Landing Page

- [ ] Configurer palette de couleurs (vert #0A3D2E, or #C69B3C, ivoire #F4EADE, charcoal #2B2B2B)
- [ ] Importer typographies élégantes (Playfair Display pour headings, Inter pour body)
- [ ] Créer composants réutilisables : Card, Badge, Button variants
- [ ] Landing page : Hero section avec image du gîte
- [ ] Landing page : Section "Capacité & Équipements" avec icônes
- [ ] Landing page : Section "Tarifs" avec transparence
- [ ] Landing page : CTA principal "Créer mon événement"
- [ ] Landing page : CTA secondaire "Voir les formats"
- [ ] Landing page : Section "Formats d'événements" avec 6 cartes
- [ ] Landing page : Section "Fonctionnement" avec 3 étapes

## Assistant de Création d'Événement

- [ ] Page créateur : formulaire en 5-6 étapes avec progress bar
- [ ] Étape 1 : Type d'événement (anniversaire, EVJF, EVG, cousinade, retraite, séjour créatif)
- [ ] Étape 2 : Dates (date_debut, date_fin)
- [ ] Étape 3 : Nombre de personnes et couchages
- [ ] Étape 4 : Options (ménage, petit-déjeuner, décoration)
- [ ] Étape 5 : Ambiance, repas, musique, besoins prestataires
- [ ] Étape 6 : Message personnalisé de l'organisateur
- [ ] Résumé final avant soumission
- [ ] Génération automatique du code d'accès (EDEN-XXXX)
- [ ] Envoi de la fiche récapitulative au visiteur (email)
- [ ] Notification au propriétaire de la nouvelle demande

## Page Événement Privée (Accès par Code)

- [ ] Route /event/:code avec validation du code d'accès
- [ ] Affichage du récapitulatif complet de l'événement
- [ ] Affichage du statut en temps réel (en attente / confirmé / refusé)
- [ ] Section "Infos pratiques" (capacité, équipements, tarifs)
- [ ] Section "Invités" (liste des participants si fournie)
- [ ] Section "Couchages" (détails des arrangements)
- [ ] Section "Repas & Allergies" (informations alimentaires)
- [ ] Section "Prestataires" (services nécessaires)
- [ ] Bouton "Copier la fiche" (copie du texte dans le presse-papiers)
- [ ] Bouton "Préparer le message au gîte" (génère un email pré-rempli)
- [ ] Mention "Demande sous réserve de validation par le lieu"

## Dashboard Propriétaire (Admin)

- [ ] Page /admin/dashboard (accès admin uniquement)
- [ ] Liste de toutes les demandes d'événements
- [ ] Filtres : par statut, par date, par type d'événement
- [ ] Recherche par code d'accès ou nom d'organisateur
- [ ] Colonne "Statut" avec badges colorés (En attente, Confirmé, Refusé)
- [ ] Colonne "Date" avec formatage lisible
- [ ] Colonne "Nombre de personnes"
- [ ] Colonne "Actions" avec boutons : Voir détails, Valider, Refuser, Ajouter note
- [ ] Modal de détails : affichage complet de la demande
- [ ] Formulaire pour modifier le statut (dropdown + confirmation)
- [ ] Champ "Notes internes" pour ajouter des remarques
- [ ] Bouton "Contacter l'organisateur" (génère un email pré-rempli)
- [ ] Pagination ou scroll infini
- [ ] Statistiques : nombre de demandes par statut, par type

## Notifications & Emails

- [ ] Notification propriétaire à chaque nouvelle soumission
- [ ] Email au visiteur avec la fiche récapitulative et le code d'accès
- [ ] Email au propriétaire avec les détails de la demande
- [ ] Email au visiteur quand le statut change (confirmé/refusé)
- [ ] Template d'email élégant et responsive

## Tests & Validation

- [ ] Test unitaire : génération de code d'accès (format EDEN-XXXX)
- [ ] Test unitaire : validation du code d'accès
- [ ] Test unitaire : création d'événement avec toutes les données
- [ ] Test unitaire : modification du statut par admin
- [ ] Test d'intégration : flux complet de création → notification → accès privé
- [ ] Test responsive : landing page, formulaire, page privée, dashboard
- [ ] Test d'accessibilité : contraste, navigation au clavier

## Finalisation & Déploiement

- [ ] Vérifier tous les liens et CTAs
- [ ] Optimiser les images du gîte
- [ ] Tester les formulaires sur mobile
- [ ] Vérifier les notifications emails
- [ ] Checkpoint final avant publication
- [ ] Déploiement et publication

---

## Notes Importantes

- **Contrainte d'accès** : La page événement n'est accessible que via le code unique généré
- **Pas de réservation automatique** : Le site prépare une demande, pas une réservation confirmée
- **Validation propriétaire** : Tous les événements sont sous réserve de validation
- **Design premium** : Respecter la palette de couleurs et les principes de spacing
- **Notifications** : Automatiques, sans action manuelle du propriétaire
