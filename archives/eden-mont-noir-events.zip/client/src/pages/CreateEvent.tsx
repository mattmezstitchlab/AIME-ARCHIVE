import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";

/**
 * Event creation wizard with step-by-step form
 */
export default function CreateEvent() {
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;
  const progressPercent = (currentStep / totalSteps) * 100;

  const [formData, setFormData] = useState({
    organizerName: "",
    organizerEmail: "",
    organizerPhone: "",
    eventType: "",
    eventTitle: "",
    dateStart: "",
    dateEnd: "",
    numberOfGuests: "",
    numberOfSleepingGuests: "",
    atmosphere: "",
    meals: "",
    music: "",
    vendorNeeds: "",
    organizerMessage: "",
  });

  const createEventMutation = trpc.events.create.useMutation();

  const handleInputChange = (field: string, value: string | number) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    try {
      const result = await createEventMutation.mutateAsync({
        organizerName: formData.organizerName,
        organizerEmail: formData.organizerEmail,
        organizerPhone: formData.organizerPhone || undefined,
        eventType: formData.eventType as any,
        eventTitle: formData.eventTitle,
        dateStart: new Date(formData.dateStart),
        dateEnd: new Date(formData.dateEnd),
        numberOfGuests: parseInt(formData.numberOfGuests),
        numberOfSleepingGuests: parseInt(formData.numberOfSleepingGuests),
        atmosphere: formData.atmosphere || undefined,
        meals: formData.meals || undefined,
        music: formData.music || undefined,
        vendorNeeds: formData.vendorNeeds || undefined,
        organizerMessage: formData.organizerMessage || undefined,
      });

      toast.success("Événement créé avec succès!");
      navigate(`/event/${result.accessCode}`);
    } catch (error: any) {
      toast.error(error.message || "Erreur lors de la création de l'événement");
    }
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.organizerName && formData.organizerEmail;
      case 2:
        return formData.eventType && formData.eventTitle;
      case 3:
        return formData.dateStart && formData.dateEnd;
      case 4:
        return formData.numberOfGuests && formData.numberOfSleepingGuests;
      case 5:
        return true;
      case 6:
        return true;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-serif font-bold text-primary">
              Créer votre événement
            </h1>
            <p className="text-sm text-muted-foreground">
              Étape {currentStep} sur {totalSteps}
            </p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="border-b border-border bg-background/50">
        <div className="container py-4">
          <Progress value={progressPercent} className="h-2" />
        </div>
      </div>

      {/* Form Container */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="p-8">
            {/* Step 1: Contact Info */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-serif font-bold text-primary mb-4">
                    Vos informations
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Commençons par vos coordonnées pour préparer votre demande
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nom complet *</Label>
                    <Input
                      id="name"
                      value={formData.organizerName}
                      onChange={(e) => handleInputChange("organizerName", e.target.value)}
                      placeholder="Jean Dupont"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.organizerEmail}
                      onChange={(e) => handleInputChange("organizerEmail", e.target.value)}
                      placeholder="jean@example.com"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.organizerPhone}
                      onChange={(e) => handleInputChange("organizerPhone", e.target.value)}
                      placeholder="+33 6 12 34 56 78"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Event Type */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-serif font-bold text-primary mb-4">
                    Type d'événement
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Quel type d'événement souhaitez-vous organiser?
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="eventType">Type d'événement *</Label>
                    <Select value={formData.eventType} onValueChange={(v) => handleInputChange("eventType", v)}>
                      <SelectTrigger id="eventType">
                        <SelectValue placeholder="Choisissez un type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="anniversaire">Anniversaire privé</SelectItem>
                        <SelectItem value="evjf">EVJF</SelectItem>
                        <SelectItem value="evg">EVG</SelectItem>
                        <SelectItem value="cousinade">Cousinade</SelectItem>
                        <SelectItem value="retraite_bien_etre">Retraite bien-être</SelectItem>
                        <SelectItem value="sejour_creatif">Séjour créatif</SelectItem>
                        <SelectItem value="mini_mariage">Mini-mariage</SelectItem>
                        <SelectItem value="seminaire">Séminaire</SelectItem>
                        <SelectItem value="autre">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="title">Titre de l'événement *</Label>
                    <Input
                      id="title"
                      value={formData.eventTitle}
                      onChange={(e) => handleInputChange("eventTitle", e.target.value)}
                      placeholder="Ex: Anniversaire de Marie"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Dates */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-serif font-bold text-primary mb-4">
                    Dates
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Quand souhaitez-vous organiser votre événement?
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="dateStart">Date de début *</Label>
                    <Input
                      id="dateStart"
                      type="date"
                      value={formData.dateStart}
                      onChange={(e) => handleInputChange("dateStart", e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="dateEnd">Date de fin *</Label>
                    <Input
                      id="dateEnd"
                      type="date"
                      value={formData.dateEnd}
                      onChange={(e) => handleInputChange("dateEnd", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Guests */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-serif font-bold text-primary mb-4">
                    Nombre de personnes
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Combien de personnes participeront à votre événement?
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="guests">Nombre total de personnes *</Label>
                    <Input
                      id="guests"
                      type="number"
                      min="1"
                      value={formData.numberOfGuests}
                      onChange={(e) => handleInputChange("numberOfGuests", e.target.value)}
                      placeholder="20"
                    />
                  </div>

                  <div>
                    <Label htmlFor="sleeping">Nombre de personnes dormant sur place *</Label>
                    <Input
                      id="sleeping"
                      type="number"
                      min="0"
                      value={formData.numberOfSleepingGuests}
                      onChange={(e) => handleInputChange("numberOfSleepingGuests", e.target.value)}
                      placeholder="10"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Details */}
            {currentStep === 5 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-serif font-bold text-primary mb-4">
                    Détails de votre événement
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Décrivez l'ambiance, les repas et autres détails
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="atmosphere">Ambiance souhaitée</Label>
                    <Textarea
                      id="atmosphere"
                      value={formData.atmosphere}
                      onChange={(e) => handleInputChange("atmosphere", e.target.value)}
                      placeholder="Ex: Relaxante, festive, intime..."
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="meals">Repas</Label>
                    <Textarea
                      id="meals"
                      value={formData.meals}
                      onChange={(e) => handleInputChange("meals", e.target.value)}
                      placeholder="Ex: Petit-déjeuner, déjeuner, dîner..."
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="music">Musique</Label>
                    <Input
                      id="music"
                      value={formData.music}
                      onChange={(e) => handleInputChange("music", e.target.value)}
                      placeholder="Ex: DJ, playlist, silence..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="vendors">Prestataires nécessaires</Label>
                    <Textarea
                      id="vendors"
                      value={formData.vendorNeeds}
                      onChange={(e) => handleInputChange("vendorNeeds", e.target.value)}
                      placeholder="Ex: Traiteur, photographe, décorateur..."
                      rows={3}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 6: Message */}
            {currentStep === 6 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-serif font-bold text-primary mb-4">
                    Message personnalisé
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Ajoutez un message pour le propriétaire du gîte
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="message">Votre message</Label>
                    <Textarea
                      id="message"
                      value={formData.organizerMessage}
                      onChange={(e) => handleInputChange("organizerMessage", e.target.value)}
                      placeholder="Parlez-nous de votre événement, vos attentes, vos envies..."
                      rows={6}
                    />
                  </div>

                  <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">
                      <strong>Important:</strong> Tous les événements sont sous réserve de validation par le lieu. Vous recevrez une confirmation par email.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex gap-4 mt-8 pt-6 border-t border-border">
              <Button
                variant="outline"
                onClick={handlePrev}
                disabled={currentStep === 1}
              >
                Précédent
              </Button>

              <div className="flex-1" />

              {currentStep < totalSteps ? (
                <Button
                  onClick={handleNext}
                  disabled={!isStepValid()}
                  className="bg-secondary text-secondary-foreground hover:opacity-90"
                >
                  Suivant
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={!isStepValid() || createEventMutation.isPending}
                  className="bg-secondary text-secondary-foreground hover:opacity-90"
                >
                  {createEventMutation.isPending ? "Création..." : "Créer mon événement"}
                </Button>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
