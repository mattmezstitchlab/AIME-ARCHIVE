import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Sparkles, Users, Heart, Cake, Wine, Leaf } from "lucide-react";

/**
 * Premium landing page for L'Éden du Mont Noir
 * Showcases the venue and guides visitors to create events
 */
export default function Home() {
  const [, navigate] = useLocation();

  const eventFormats = [
    {
      icon: Cake,
      title: "Anniversaire Privé",
      description: "Célébrez vos moments importants dans un cadre d'exception",
    },
    {
      icon: Sparkles,
      title: "EVJF / EVG",
      description: "Un week-end inoubliable entre proches avec spa et détente",
    },
    {
      icon: Heart,
      title: "Mini-Mariage",
      description: "Échangez vos vœux en petit comité dans une ambiance intime",
    },
    {
      icon: Users,
      title: "Cousinade",
      description: "Réunissez la famille pour un week-end de partage et convivialité",
    },
    {
      icon: Leaf,
      title: "Retraite Bien-Être",
      description: "Ressourcez-vous avec yoga, spa et moments de sérénité",
    },
    {
      icon: Wine,
      title: "Séjour Créatif",
      description: "Ateliers, créativité et inspiration au cœur des Flandres",
    },
  ];

  const steps = [
    {
      number: "01",
      title: "Décrivez votre événement",
      description: "Répondez à quelques questions simples pour préparer votre demande",
    },
    {
      number: "02",
      title: "Recevez une fiche claire",
      description: "Nous générons un récapitulatif complet de votre événement",
    },
    {
      number: "03",
      title: "Transmettez la demande",
      description: "Envoyez votre demande au gîte pour validation",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="text-lg font-serif font-bold text-primary">
            L'Éden du Mont Noir
          </div>
          <Button
            onClick={() => navigate("/create")}
            className="bg-secondary text-secondary-foreground hover:opacity-90"
          >
            Créer mon événement
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="container">
          <div className="max-w-3xl">
            <h1 className="text-xl text-xl font-serif font-bold text-primary mb-6">
              Organisez un événement intime au sommet des Flandres
            </h1>
            <p className="text-lg text-xl text-muted-foreground mb-8 leading-relaxed">
              L'Éden du Mont Noir accueille vos moments privés : anniversaires, EVJF, cousinades, mini-mariages, retraites et séjours entre proches.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => navigate("/create")}
                size="lg"
                className="bg-secondary text-secondary-foreground hover:opacity-90 text-sm"
              >
                Créer mon événement
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  document.getElementById("formats")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="text-sm"
              >
                Voir les formats
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="divider-premium" />

      {/* About Section */}
      <section className="py-16 lg:py-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-xl text-xl font-serif font-bold text-primary mb-6">
                Un gîte d'exception
              </h2>
              <p className="text-lg text-muted-foreground mb-4 leading-relaxed">
                Niché au cœur des Flandres, L'Éden du Mont Noir offre un cadre unique pour vos événements privés. Avec vue à 360° sur la région, notre gîte combine confort haut de gamme et intimité.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="text-secondary font-bold text-lg">✓</div>
                  <div>
                    <h3 className="font-semibold text-foreground">Capacité : 8 à 10 personnes</h3>
                    <p className="text-muted-foreground text-sm">Selon la configuration</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="text-secondary font-bold text-lg">✓</div>
                  <div>
                    <h3 className="font-semibold text-foreground">Spa Privatif</h3>
                    <p className="text-muted-foreground text-sm">Jacuzzi et espace détente</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="text-secondary font-bold text-lg">✓</div>
                  <div>
                    <h3 className="font-semibold text-foreground">Terrasse Panoramique</h3>
                    <p className="text-muted-foreground text-sm">Vue sur le coucher de soleil</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-lg h-96 flex items-center justify-center border border-border">
              <div className="text-center text-muted-foreground">
                <p className="text-sm">Galerie photos du gîte</p>
                <p className="text-xs">(À ajouter)</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="divider-premium" />

      {/* Event Formats Section */}
      <section id="formats" className="py-16 lg:py-24">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-xl text-xl font-serif font-bold text-primary mb-4">
              Formats d'événements
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Découvrez les différentes façons de célébrer vos moments importants à L'Éden du Mont Noir
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {eventFormats.map((format, idx) => {
              const Icon = format.icon;
              return (
                <Card key={idx} className="p-6 hover:shadow-lg transition-shadow">
                  <Icon className="w-10 h-10 text-secondary mb-4" />
                  <h3 className="text-xl font-serif font-bold text-primary mb-2">
                    {format.title}
                  </h3>
                  <p className="text-muted-foreground">{format.description}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="divider-premium" />

      {/* How It Works Section */}
      <section className="py-16 lg:py-24">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-xl text-xl font-serif font-bold text-primary mb-4">
              Comment ça fonctionne
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Trois étapes simples pour préparer votre événement
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, idx) => (
              <div key={idx} className="relative">
                <div className="flex items-start gap-4">
                  <div className="text-xl font-serif font-bold text-secondary/20">
                    {step.number}
                  </div>
                  <div>
                    <h3 className="text-xl font-serif font-bold text-primary mb-2">
                      {step.title}
                    </h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
                {idx < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 -right-4 w-8 h-0.5 bg-gradient-to-r from-secondary/50 to-transparent" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="divider-premium" />

      {/* CTA Section */}
      <section className="py-16 lg:py-24 bg-primary/5">
        <div className="container text-center">
          <h2 className="text-xl text-xl font-serif font-bold text-primary mb-6">
            Prêt à organiser votre événement ?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Préparez votre demande en quelques minutes. Tous les événements sont sous réserve de validation par le lieu.
          </p>
          <Button
            onClick={() => navigate("/create")}
            size="lg"
            className="bg-secondary text-secondary-foreground hover:opacity-90 text-sm"
          >
            Commencer maintenant
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 bg-background/50">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
              <p className="font-serif font-bold text-primary">L'Éden du Mont Noir</p>
              <p className="text-sm text-muted-foreground">
                87 chemin du Mont Noir, 59270 Saint-Jans-Cappel
              </p>
            </div>
            <p className="text-sm text-muted-foreground text-center md:text-right">
              Demande sous réserve de validation par le lieu
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
