import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Event types enum
 */
export const eventTypeEnum = mysqlEnum("eventType", [
  "anniversaire",
  "evjf",
  "evg",
  "cousinade",
  "retraite_bien_etre",
  "sejour_creatif",
  "mini_mariage",
  "seminaire",
  "autre",
]);

/**
 * Event status enum
 */
export const eventStatusEnum = mysqlEnum("eventStatus", [
  "brouillon",
  "demande_prete",
  "envoyee",
  "validee",
  "refusee",
]);

/**
 * Events table
 */
export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  accessCode: varchar("accessCode", { length: 20 }).notNull().unique(), // EDEN-XXXX format
  organizerName: varchar("organizerName", { length: 255 }).notNull(),
  organizerEmail: varchar("organizerEmail", { length: 320 }).notNull(),
  organizerPhone: varchar("organizerPhone", { length: 20 }),
  eventType: eventTypeEnum.notNull(),
  eventTitle: varchar("eventTitle", { length: 255 }).notNull(),
  dateStart: timestamp("dateStart").notNull(),
  dateEnd: timestamp("dateEnd").notNull(),
  numberOfGuests: int("numberOfGuests").notNull(),
  numberOfSleepingGuests: int("numberOfSleepingGuests").notNull(),
  atmosphere: text("atmosphere"), // Description de l'ambiance souhaitée
  meals: text("meals"), // Détails sur les repas
  music: text("music"), // Détails sur la musique
  vendorNeeds: text("vendorNeeds"), // Besoins en prestataires
  organizerMessage: text("organizerMessage"), // Message personnalisé
  status: eventStatusEnum.default("brouillon").notNull(),
  internalNotes: text("internalNotes"), // Notes du propriétaire
  additionalOptions: text("additionalOptions"), // JSON: cleaning, breakfast, decoration, etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;