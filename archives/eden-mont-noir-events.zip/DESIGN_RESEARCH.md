# Recherche Visuelle & Inspiration - L'Éden du Mont Noir

## 1. Principes de Design Premium pour Gîtes/Hôtels

### Caractéristiques clés des sites haut de gamme :
- **Imagerie immersive** : galeries photos haute résolution, vidéos de tours virtuels
- **Approche visuelle hautement développée** : images de qualité hôtellerie
- **Navigation intuitive** : accès facile aux informations sur les installations, tarifs, disponibilités
- **Appels à l'action clairs** : boutons de réservation/demande bien visibles
- **Responsive design** : optimisé mobile et desktop
- **Contenu respirant** : beaucoup d'espace blanc, pas de surcharge

## 2. Palettes de Couleurs Luxury (Hex Codes)

### Palette recommandée pour L'Éden (Brut Champagne + Mayfair Racing Green)
- **Anchor (Profond)** : #0A3D2E (Mayfair Racing Green - heritage, nature, calme)
- **Accent Métallique** : #C69B3C (24-Karat Gold - prestige, chaleur)
- **Neutre Chaud** : #F4EADE (Ivory Cream - luxe, calme, sophistication)
- **Neutre Sombre** : #2B2B2B (Charcoal - contraste, lisibilité)

**Justification** : Le vert évoque les Flandres et la nature, le doré apporte la chaleur et le prestige, l'ivoire crème crée la sérénité.

### Principes de couleur luxury :
- Restraint over saturation : tons désaturés, pas de couleurs vives
- Depth over brightness : ancrage avec une teinte profonde
- Un seul accent métallique (OR, pas platine + or)
- Beaucoup d'espace blanc comme matériau
- Contraste élevé pour la lisibilité

## 3. Typographie Premium

### Recommandations :
- **Heading** : Serif élégante (ex: Playfair Display, Cormorant Garamond)
- **Body** : Sans-serif épurée (ex: Inter, Poppins, Lato)
- **Accent** : Serif classique pour les citations/messages

### Traits :
- Espacements généreux entre lettres et lignes
- Tailles de police hiérarchisées clairement
- Poids de police limités (regular, medium, bold)

## 4. Principes de Spacing & Layout

### Grille & Whitespace :
- Grille 12 colonnes avec padding généreux
- Whitespace traité comme matériau, pas comme absence
- Marges minimales : 32px, 48px, 64px (multiples de 16)
- Sections bien séparées par du vide

### Layouts asymétriques :
- Éviter les layouts centrés génériques
- Préférer des compositions asymétriques (image + texte côte à côte)
- Utiliser la règle des tiers pour placer les éléments clés

## 5. Patterns de Dashboard Admin Premium

### Caractéristiques observées :
- **Clarté hiérarchique** : données au bon niveau de hiérarchie avec bruit visuel minimal
- **Cartes structurées** : information groupée en cartes avec ombres douces
- **Données visuelles** : graphiques épurés, pas surchargés
- **Palette restreinte** : 2-3 couleurs d'accent max
- **Typographie claire** : contraste élevé, tailles bien différenciées

### Patterns pour gestion de demandes :
- Liste avec statut visuel (badges colorés)
- Détails en modal ou drawer
- Actions secondaires en menu dropdown
- Filtres et recherche en haut
- Pagination ou scroll infini

## 6. Assistants & Formulaires Guidés

### Best practices :
- **Étapes visuelles** : progress bar ou numérotation claire
- **Une question par écran** : réduire la charge cognitive
- **Validation progressive** : feedback immédiat
- **CTA clairs** : "Suivant", "Retour", "Soumettre"
- **Résumé final** : afficher ce qui a été saisi avant soumission

### Transitions :
- Animations douces (200-300ms) entre étapes
- Pas d'animations sur actions clavier (commandes)
- Transitions scale + opacity pour entrées/sorties

## 7. Inspiration Visuelle Collectée

### Sources principales :
- Muzli Dashboard Design 2026 : dashboards élégants avec palettes restreintes
- Zoviz Luxury Colors : guide complet des palettes prestige
- Dribbble Event UI : interfaces de gestion d'événements

### Éléments à retenir :
- Glassmorphism subtil (transparence légère, flou)
- Ombres douces (box-shadow: 0 2px 8px rgba(0,0,0,0.08))
- Coins arrondis modérés (8px-12px)
- Gradients chauds et subtils (pas de dégradés criards)
- Micro-interactions : hover states, loading states

## 8. Recommandations pour L'Éden

### Landing Page :
- Hero avec image immersive du gîte au coucher de soleil
- Section "Capacité & Équipements" avec icônes
- Section "Tarifs" avec transparence
- CTA "Créer mon événement" bien visible

### Assistant de Création :
- Formulaire en 5-6 étapes
- Progress bar en haut
- Champs simples, une question par écran
- Résumé final avant soumission

### Dashboard Propriétaire :
- Liste des demandes avec statut (badges)
- Détails en modal
- Filtres par statut, date, type
- Actions : Valider, Refuser, Ajouter note, Contacter

### Page Événement Privée :
- Récapitulatif clair et lisible
- Statut bien visible
- Boutons "Copier la fiche", "Préparer message"
- Design responsive (mobile-first)

---

**Prochaine étape** : Créer le schéma de base de données et les procédures tRPC basées sur ces principes.
