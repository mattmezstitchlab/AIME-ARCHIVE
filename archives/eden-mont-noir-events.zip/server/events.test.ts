import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("events.create", () => {
  it("generates a unique access code in EDEN-XXXX format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.events.create({
      organizerName: "John Doe",
      organizerEmail: "john@example.com",
      eventType: "anniversaire",
      eventTitle: "Birthday Party",
      dateStart: new Date("2026-06-15"),
      dateEnd: new Date("2026-06-16"),
      numberOfGuests: 20,
      numberOfSleepingGuests: 10,
    });

    expect(result.accessCode).toMatch(/^EDEN-[A-Z0-9]{8}$/);
    expect(result.status).toBe("brouillon");
    expect(result.organizerName).toBe("John Doe");
    expect(result.organizerEmail).toBe("john@example.com");
  });

  it("stores all event details correctly", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const eventInput = {
      organizerName: "Jane Smith",
      organizerEmail: "jane@example.com",
      organizerPhone: "+33612345678",
      eventType: "evjf" as const,
      eventTitle: "EVJF Weekend",
      dateStart: new Date("2026-07-01"),
      dateEnd: new Date("2026-07-03"),
      numberOfGuests: 15,
      numberOfSleepingGuests: 15,
      atmosphere: "Relaxed and fun",
      meals: "Breakfast and dinner",
      music: "DJ",
      vendorNeeds: "Spa services",
      organizerMessage: "Looking forward to this!",
    };

    const result = await caller.events.create(eventInput);

    expect(result.organizerName).toBe(eventInput.organizerName);
    expect(result.organizerEmail).toBe(eventInput.organizerEmail);
    expect(result.organizerPhone).toBe(eventInput.organizerPhone);
    expect(result.eventType).toBe(eventInput.eventType);
    expect(result.eventTitle).toBe(eventInput.eventTitle);
    expect(result.numberOfGuests).toBe(eventInput.numberOfGuests);
    expect(result.atmosphere).toBe(eventInput.atmosphere);
  });
});

describe("events.getByAccessCode", () => {
  it("retrieves an event by its access code", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Create an event
    const created = await caller.events.create({
      organizerName: "Test User",
      organizerEmail: "test@example.com",
      eventType: "cousinade",
      eventTitle: "Family Gathering",
      dateStart: new Date("2026-08-01"),
      dateEnd: new Date("2026-08-03"),
      numberOfGuests: 30,
      numberOfSleepingGuests: 20,
    });

    // Retrieve it by access code
    const retrieved = await caller.events.getByAccessCode({ code: created.accessCode });

    expect(retrieved.id).toBe(created.id);
    expect(retrieved.accessCode).toBe(created.accessCode);
    expect(retrieved.organizerName).toBe("Test User");
  });

  it("throws NOT_FOUND for invalid access code", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.events.getByAccessCode({ code: "EDEN-INVALID" });
      expect.fail("Should have thrown");
    } catch (error: any) {
      expect(error.code).toBe("NOT_FOUND");
    }
  });
});
