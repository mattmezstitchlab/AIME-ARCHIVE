import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { createEvent, getEventByAccessCode, getEventById, getAllEvents, updateEventStatus } from "../db";
import { InsertEvent } from "../../drizzle/schema";
import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";

/**
 * Generate a unique access code in format EDEN-XXXX
 */
function generateAccessCode(): string {
  const randomPart = nanoid(8).toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  return `EDEN-${randomPart}`;
}

/**
 * Event creation schema
 */
const createEventSchema = z.object({
  organizerName: z.string().min(1, "Name required"),
  organizerEmail: z.string().email("Valid email required"),
  organizerPhone: z.string().optional(),
  eventType: z.enum([
    "anniversaire",
    "evjf",
    "evg",
    "cousinade",
    "retraite_bien_etre",
    "sejour_creatif",
    "mini_mariage",
    "seminaire",
    "autre",
  ]),
  eventTitle: z.string().min(1, "Event title required"),
  dateStart: z.date(),
  dateEnd: z.date(),
  numberOfGuests: z.number().int().positive(),
  numberOfSleepingGuests: z.number().int().nonnegative(),
  atmosphere: z.string().optional(),
  meals: z.string().optional(),
  music: z.string().optional(),
  vendorNeeds: z.string().optional(),
  organizerMessage: z.string().optional(),
  additionalOptions: z.string().optional(),
});

/**
 * Event router
 */
export const eventsRouter = router({
  /**
   * Create a new event
   */
  create: publicProcedure.input(createEventSchema).mutation(async ({ input }) => {
    const accessCode = generateAccessCode();

    const eventData: InsertEvent = {
      ...input,
      accessCode,
      status: "brouillon",
    };

    const newEvent = await createEvent(eventData);
    return newEvent;
  }),

  /**
   * Get event by access code (public)
   */
  getByAccessCode: publicProcedure
    .input(z.object({ code: z.string() }))
    .query(async ({ input }) => {
      const event = await getEventByAccessCode(input.code);
      if (!event) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return event;
    }),

  /**
   * Get all events (admin only)
   */
  getAll: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Only admins can view all events",
      });
    }
    return await getAllEvents();
  }),

  /**
   * Update event status (admin only)
   */
  updateStatus: protectedProcedure
    .input(
      z.object({
        eventId: z.number(),
        status: z.enum(["brouillon", "demande_prete", "envoyee", "validee", "refusee"]),
        internalNotes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Only admins can update event status",
        });
      }

      const updatedEvent = await updateEventStatus(input.eventId, input.status, input.internalNotes);
      if (!updatedEvent) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Event not found",
        });
      }
      return updatedEvent;
    }),
});
