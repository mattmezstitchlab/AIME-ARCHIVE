import React from "react";
import { motion } from "framer-motion";

/**
 * SpaceHowItWorks — Section pédagogique "comment ça marche".
 * Explique le système de dossiers / fenêtres entre les acteurs (mariés, invités, prestataires, lieux).
 * Configurable via la prop `actors` pour réutilisation sur d'autres fenêtres.
 */
export default function SpaceHowItWorks({
  eyebrow = "Comment ça marche",
  title,
  italic,
  description,
  accent = "#D4A574",
  actors = []
}) {
  return (
    <section className="relative py-20 md:py-24 px-6 border-t border-white/5">
      <div className="max-w-5xl mx-auto">
        {/* Header section */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div
            className="font-sans text-[11px] tracking-[0.3em] uppercase mb-4"
            style={{ color: accent }}
          >
            {eyebrow}
          </div>
          <h2 className="apple-headline text-white text-3xl md:text-4xl lg:text-5xl">
            {title}
            <br />
            <span className="text-white/70">
              {italic}
            </span>
          </h2>
          {description && (
            <p className="mt-5 font-sans text-white/60 text-[15px] leading-relaxed">
              {description}
            </p>
          )}
        </div>

        {/* Grille des acteurs (dossiers/fenêtres) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {actors.map((a, i) => (
            <motion.div
              key={a.name}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: 0.05 + i * 0.08 }}
              className="rounded-2xl bg-white/[0.03] border border-white/10 p-6 hover:bg-white/[0.05] transition-colors"
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center mb-4 text-[15px]"
                style={{
                  backgroundColor: `${accent}20`,
                  color: accent
                }}
              >
                {a.glyph || "✦"}
              </div>
              <div className="text-white/95 text-[15px] font-medium font-sans mb-2">
                {a.name}
              </div>
              <div className="text-white/55 text-[13px] font-sans leading-relaxed mb-4">
                {a.desc}
              </div>
              {a.folders && (
                <div className="pt-3 border-t border-white/10">
                  <div className="text-[9.5px] tracking-[0.25em] uppercase text-white/35 mb-2">
                    Dossiers
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {a.folders.map((f) => (
                      <span
                        key={f}
                        className="px-2 py-0.5 rounded-md text-[10.5px] font-sans bg-white/[0.05] text-white/65 border border-white/10"
                      >
                        {f}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Phrase de liaison */}
        <div className="text-center mt-12">
          <p className="font-serif italic text-white/55 text-[15px] md:text-[16px] max-w-xl mx-auto leading-relaxed">
            Chaque acteur a sa fenêtre, ses dossiers, sa voix. Aïma les relie — sans qu'aucun ne perde la sienne.
          </p>
        </div>
      </div>
    </section>
  );
}