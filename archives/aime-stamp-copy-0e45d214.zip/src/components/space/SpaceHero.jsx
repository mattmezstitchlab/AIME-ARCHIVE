import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useAimaModal } from "@/lib/AimaModalContext";

/**
 * SpaceHero — Gabarit de hero pour chaque page fenêtre AIME®.
 * Props : eyebrow, title, italic, description, accent, bgUrl
 * CTA "Parler à Aïma" ouvre la modal globale.
 */
export default function SpaceHero({
  eyebrow,
  title,
  italic,
  description,
  accent = "#D4A574",
  bgUrl
}) {
  const { openAima } = useAimaModal();

  return (
    <section className="relative pt-32 md:pt-36 pb-16 md:pb-20 px-6 overflow-hidden">
      {/* Image de fond optionnelle */}
      {bgUrl && (
        <div className="absolute inset-0">
          <img
            src={bgUrl}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 w-full h-full object-cover opacity-50"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, rgba(10,10,11,0.65) 0%, rgba(10,10,11,0.55) 50%, #0A0A0B 100%)"
            }}
          />
        </div>
      )}

      {/* Glow d'accent */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse 60% 40% at 50% 0%, ${accent}22, transparent 60%)`
        }}
      />

      <div className="relative max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-white/65 mb-5"
        >
          <span
            className="w-1.5 h-1.5 rounded-full"
            style={{ backgroundColor: accent }}
          />
          {eyebrow}
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="apple-headline text-white text-4xl md:text-5xl lg:text-6xl"
        >
          {title}
          <br />
          <span className="text-white/75">
            {italic}
          </span>
        </motion.h1>

        {description && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.7 }}
            className="mt-6 font-sans text-white/65 text-[15px] md:text-[16px] leading-relaxed max-w-xl mx-auto"
          >
            {description}
          </motion.p>
        )}

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="mt-9 flex flex-wrap items-center justify-center gap-3"
        >
          <button
            onClick={openAima}
            className="px-7 py-3 rounded-full text-[11px] tracking-[0.25em] uppercase font-medium transition-all hover:scale-[1.02]"
            style={{
              background: accent,
              color: "#1A1208"
            }}
          >
            Parler à Aïma
          </button>
          <Link
            to="/"
            className="px-6 py-3 rounded-full border text-[11px] tracking-[0.25em] uppercase text-white/65 hover:text-white border-white/20 hover:border-white/40 transition-colors"
          >
            ← L'écosystème
          </Link>
        </motion.div>
      </div>
    </section>
  );
}