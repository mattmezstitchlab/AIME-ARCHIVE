import React from "react";
import { motion } from "framer-motion";

/**
 * NoyauPhaseCard — Carte sobre pour présenter une des 4 phases NOYAU.
 * Numéro · titre · italic · description · 3 puces.
 */
export default function NoyauPhaseCard({ n, title, italic, description, bullets = [], delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay }}
      className="rounded-3xl bg-white/[0.03] border border-[#B89A52]/20 p-7 md:p-8 hover:border-[#B89A52]/40 transition-colors"
    >
      <div className="flex items-baseline gap-3 mb-3">
        <span className="text-[10px] tracking-[0.35em] uppercase text-[#B89A52]">Phase {n}</span>
        <span className="h-px flex-1 bg-[#B89A52]/20" />
      </div>
      <h3 className="apple-headline text-white text-2xl md:text-3xl mb-2">
        {title}
      </h3>
      <p
        className="text-white/55 italic text-[15px] mb-4 leading-snug"
        style={{ fontFamily: "'Playfair Display', serif" }}
      >
        {italic}
      </p>
      <p className="text-white/65 text-[13.5px] leading-relaxed mb-5">{description}</p>
      {bullets.length > 0 && (
        <ul className="space-y-2 mt-5 pt-5 border-t border-white/10">
          {bullets.map((b) => (
            <li key={b} className="flex items-start gap-2.5 text-[13px] text-white/70 leading-relaxed">
              <span className="mt-1.5 w-1 h-1 rounded-full bg-[#B89A52] flex-shrink-0" />
              <span>{b}</span>
            </li>
          ))}
        </ul>
      )}
    </motion.div>
  );
}