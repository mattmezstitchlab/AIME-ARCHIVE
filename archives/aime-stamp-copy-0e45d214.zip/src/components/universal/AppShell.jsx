import React from "react";
import { useLocation } from "react-router-dom";
import GlobalHeader from "./GlobalHeader";
import AimaFloatingButton from "./AimaFloatingButton";
import AimaModal from "./AimaModal";
import { AimaModalProvider, useAimaModal } from "@/lib/AimaModalContext";

/**
 * AppShell — Wrapper global de l'app.
 * - Header persistant (transparent sur la home, solide ailleurs)
 * - Bouton flottant Aïma (toujours visible, sauf admin)
 * - Modal Aïma (s'ouvre via context : useAimaModal().openAima())
 */
function ShellInner({ children }) {
  const location = useLocation();
  const { open, openAima, closeAima } = useAimaModal();

  const isAdmin = location.pathname.startsWith("/admin");
  const isHome = location.pathname === "/";
  const headerVariant = isHome ? "transparent" : "solid";
  const headerWrapperClass = isHome ? "absolute top-0 inset-x-0 z-30" : "relative";

  // Admin : header global affiché, mais pas le bouton flottant Aïma
  if (isAdmin) {
    return (
      <>
        <GlobalHeader variant="solid" />
        {children}
      </>
    );
  }

  return (
    <>
      <div className={headerWrapperClass}>
        <GlobalHeader variant={headerVariant} />
      </div>
      {children}
      <AimaFloatingButton onClick={openAima} hidden={open} />
      <AimaModal open={open} onClose={closeAima} />
    </>
  );
}

export default function AppShell({ children }) {
  return (
    <AimaModalProvider>
      <ShellInner>{children}</ShellInner>
    </AimaModalProvider>
  );
}