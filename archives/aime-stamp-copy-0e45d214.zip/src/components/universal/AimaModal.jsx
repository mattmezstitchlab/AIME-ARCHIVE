import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AimaConversation from "./AimaConversation";
import AimaIcon from "@/components/design-system/AimaIcons";

const MODE_WRAPPERS = {
  min: "w-full max-w-md",
  mid: "w-full max-w-2xl",
  full: "w-full h-full max-w-[1400px]"
};

/**
 * AimaModal — Overlay centré qui ouvre la fenêtre AimaConversation.
 * Backdrop noir flouté · ESC pour fermer · clic backdrop pour fermer.
 * 3 modes d'affichage : minimal · confort · plein écran (accessibilité & preuve légale).
 */
export default function AimaModal({ open, onClose }) {
  const [mode, setMode] = useState("mid");
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className={`fixed inset-0 z-[60] flex items-center justify-center ${
            mode === "full" ? "p-2 md:p-6" : "p-4"
          }`}
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Conversation */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.96 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className={`relative ${MODE_WRAPPERS[mode]}`}
          >
            <button
              onClick={onClose}
              className="absolute -top-12 right-0 w-9 h-9 rounded-full bg-white/10 backdrop-blur hover:bg-white/20 border border-white/20 text-white flex items-center justify-center transition-colors z-10"
              aria-label="Fermer"
            >
              <AimaIcon name="close" size={16} />
            </button>
            <AimaConversation mode={mode} onModeChange={setMode} />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}