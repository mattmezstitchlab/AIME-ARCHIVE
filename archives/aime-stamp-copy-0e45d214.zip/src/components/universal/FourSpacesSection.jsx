import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import FolderCard from "./FolderCard";

// Pages dédiées par slug (laboratoire)
const SPACE_PAGES = {
  agriculteurs: { path: "/agriculteurs", label: "Entrer dans la fenêtre Agriculteurs →" }
};

/**
 * FourSpacesSection — Fenêtres dynamiques chargées depuis l'entité Space.
 * Visibilité, ordre, contenu pilotés depuis l'admin (/admin → Fenêtres · espaces).
 */

const FALLBACK_SPACES = [
  {
    id: "couples",
    label: "Couples",
    eyebrow: "Espace Couples",
    title: "Vous deux,",
    italic: "et tout le reste suit.",
    desc: "Vous lui parlez. Aïma compose le carnet, choisit les bons prestataires, protège la cohérence — vous restez sur l'émotion.",
    bg: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg",
    accent: "#D4A574",
    folders: [
      { name: "Le carnet", count: 1, palette: "kraft" },
      { name: "Prestataires", count: 7, palette: "wine" },
      { name: "Invités", count: 84, palette: "moss" },
      { name: "Sceau", count: 1, palette: "ink" }
    ],
    modules: [
      { icon: "compose", t: "Carnet du couple", d: "Tout le mariage en une mémoire vivante" },
      { icon: "spark", t: "Prestataires curés", d: "Trois propositions, jamais une liste" },
      { icon: "calendar", t: "Timeline du jour J", d: "Aïma orchestre, vous improvisez" },
      { icon: "seal", t: "Sceau d'union", d: "Une signature qui reste, gravée" }
    ]
  },
  {
    id: "guests",
    label: "Invités",
    eyebrow: "Espace Invités",
    title: "Un code,",
    italic: "et la porte s'ouvre.",
    desc: "Tu reçois un code. Tu réponds à Aïma. Tu déposes ta chanson, ton mot, ton souvenir — sans formulaire, sans application à installer.",
    bg: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-soner-gorkem-9756539-6119578_tbwgba.jpg",
    accent: "#A8B5C9",
    folders: [
      { name: "Mon RSVP", count: 1, palette: "navy" },
      { name: "Ma chanson", count: 1, palette: "plum" },
      { name: "Livre d'or", count: 12, palette: "moss" },
      { name: "Infos jour J", count: 6, palette: "kraft" }
    ],
    modules: [
      { icon: "bubble", t: "RSVP conversationnel", d: "« Tu viens ? Avec qui ? Allergies ? »" },
      { icon: "note", t: "Playlist collaborative", d: "Ta chanson, glissée dans la nuit" },
      { icon: "memory", t: "Livre d'or vivant", d: "Un mot, une vidéo — Aïma tisse l'écho" },
      { icon: "compose", t: "Co-voiturage doux", d: "Aïma relie les invités voisins" }
    ]
  },
  {
    id: "pros",
    label: "Prestataires",
    eyebrow: "Espace Pros · intermittents",
    title: "Le geste,",
    italic: "pas la paperasse.",
    desc: "DJ, photographes, traiteurs, comédiens, intermittents du spectacle — Aïma parle pour vous, qualifie, négocie, et prend en charge la paperasse française qu'aucune autre plateforme ne touche.",
    bg: "https://res.cloudinary.com/divou1vcx/image/upload/v1772843090/mainpiano_mjh543.jpg",
    accent: "#E08A5A",
    badge: "Une première en France",
    folders: [
      { name: "Mon agenda", count: 14, palette: "ink" },
      { name: "Demandes", count: 5, palette: "moss" },
      { name: "Devis", count: 8, palette: "kraft" },
      { name: "Intermittent", count: 23, palette: "wine" }
    ],
    modules: [
      { icon: "bubble", t: "Onboarding 7 questions", d: "Aïma devient votre voix" },
      { icon: "spark", t: "Inbox pré-qualifiée", d: "Plus de demandes mal alignées" },
      { icon: "compose", t: "Devis pré-rédigés", d: "À votre voix, à votre tarif" },
      { icon: "seal", t: "Dossier intermittent", d: "Cachets, AEM, CDDU, 507h, Audiens" }
    ]
  },
  {
    id: "venues",
    label: "Lieux",
    eyebrow: "Espace Lieux",
    title: "Vos murs,",
    italic: "respirent à votre rythme.",
    desc: "Châteaux, domaines, salles. Aïma remplit les creux, protège les saisons, briefe les prestataires. Vous gardez la main, elle gère le tempo.",
    bg: "https://res.cloudinary.com/divou1vcx/image/upload/v1777700210/pexels-jwfotografia-12103484_cdnpdw.jpg",
    accent: "#9DA88B",
    folders: [
      { name: "Calendrier", count: 47, palette: "moss" },
      { name: "Réservations", count: 12, palette: "navy" },
      { name: "Partenaires", count: 18, palette: "kraft" },
      { name: "Réglementation", count: 4, palette: "ink" }
    ],
    modules: [
      { icon: "calendar", t: "Yield doux", d: "Aïma remplit les saisons creuses" },
      { icon: "image", t: "Visites guidées", d: "Aïma présente, vous accueillez" },
      { icon: "compose", t: "Carnet de pros", d: "DJ, traiteurs, fleuristes complices" },
      { icon: "seal", t: "ERP & sécurité", d: "Sonorisation, accès, rappels auto" }
    ]
  }
];

// Map DB Space → shape utilisée par la section
const fromDb = (s) => ({
  id: s.slug,
  label: s.label,
  eyebrow: s.eyebrow,
  title: s.title,
  italic: s.italic,
  desc: s.description,
  bg: s.bg_url,
  accent: s.accent_color,
  badge: s.badge,
  phase: s.phase || "live",
  folders: s.folders || [],
  modules: s.modules || []
});

export default function FourSpacesSection() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const [spaces, setSpaces] = useState(FALLBACK_SPACES);

  // Charge TOUTES les fenêtres (live + soon + lab) — l'admin contrôle is_visible
  // mais on les affiche toutes pour donner un aperçu de l'écosystème complet.
  useEffect(() => {
    base44.entities.Space.list("order_index", 20)
      .then((rows) => {
        if (rows && rows.length) {
          // visibles d'abord, puis bientôt, puis lab
          const order = { live: 0, soon: 1, lab: 2 };
          const sorted = [...rows].sort((a, b) => {
            const pa = order[a.phase || "live"] ?? 0;
            const pb = order[b.phase || "live"] ?? 0;
            if (pa !== pb) return pa - pb;
            return (a.order_index || 0) - (b.order_index || 0);
          });
          setSpaces(sorted.map(fromDb));
        }
      })
      .catch(() => { /* fallback en place */ });
  }, []);

  const space = spaces[active] || spaces[0];
  const liveCount = spaces.filter((s) => s.phase === "live" || !s.phase).length;

  // Auto-advance entre les fenêtres LIVE uniquement
  useEffect(() => {
    if (paused || liveCount <= 1) return;
    const t = setInterval(() => setActive((a) => ((a + 1) % liveCount)), 7000);
    return () => clearInterval(t);
  }, [paused, liveCount]);

  // Reset si l'index courant dépasse la nouvelle liste
  useEffect(() => {
    if (active >= spaces.length) setActive(0);
  }, [spaces.length, active]);

  if (!space) return null;

  return (
    <section
      className="relative bg-[#0A0A0B] overflow-hidden pt-20 md:pt-24"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* FULL-BLEED background image — sort à gauche et à droite jusqu'aux extrémités */}
      <AnimatePresence mode="wait">
        <motion.div
          key={space.id + "-bg"}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0"
        >
          <img
            src={space.bg}
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
            aria-hidden="true"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, rgba(10,10,11,0.75) 0%, rgba(10,10,11,0.55) 35%, rgba(10,10,11,0.7) 70%, rgba(10,10,11,0.95) 100%)"
            }}
          />
          <svg className="absolute inset-0 w-full h-full opacity-[0.05] mix-blend-overlay pointer-events-none">
            <filter id={`fs-grain-${space.id}`}>
              <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
              <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.5 0" />
            </filter>
            <rect width="100%" height="100%" filter={`url(#fs-grain-${space.id})`} />
          </svg>
        </motion.div>
      </AnimatePresence>

      <div className="relative max-w-6xl mx-auto py-6 md:py-8 px-6">
        {/* STAGE — content only, background is full-bleed above */}
        <div className="relative min-h-[440px]">
          <div className="relative z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={space.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.45 }}
                className="text-center flex flex-col items-center"
              >
                {/* Eyebrow */}
                <div className="flex flex-wrap items-center justify-center gap-3 mb-4">
                  <span
                    className="inline-block w-1.5 h-1.5 rounded-full animate-pulse"
                    style={{ backgroundColor: space.accent }}
                  />
                  <span className="font-sans text-[11px] tracking-[0.25em] uppercase text-white/55">
                    {space.eyebrow}
                  </span>
                  {space.phase === "soon" && (
                    <span
                      className="px-2.5 py-0.5 rounded-full text-[10px] font-medium font-sans border"
                      style={{
                        backgroundColor: "rgba(255,255,255,0.06)",
                        borderColor: "rgba(255,255,255,0.15)",
                        color: "rgba(255,255,255,0.7)"
                      }}
                    >
                      ✦ Bientôt disponible
                    </span>
                  )}
                  {space.phase === "lab" && (
                    <span
                      className="px-2.5 py-0.5 rounded-full text-[10px] font-medium font-sans border"
                      style={{
                        backgroundColor: "rgba(255,255,255,0.04)",
                        borderColor: "rgba(255,255,255,0.1)",
                        color: "rgba(255,255,255,0.55)"
                      }}
                    >
                      Laboratoire AIME®
                    </span>
                  )}
                  {space.badge && (
                    <span
                      className="px-2.5 py-0.5 rounded-full text-[10px] font-medium font-sans border"
                      style={{
                        backgroundColor: `${space.accent}20`,
                        borderColor: `${space.accent}50`,
                        color: space.accent
                      }}
                    >
                      ✦ {space.badge}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h3 className="apple-headline text-white text-4xl md:text-5xl lg:text-6xl max-w-3xl mx-auto">
                  {space.title}<br />
                  <span className="text-white/75">{space.italic}</span>
                </h3>
                <p className="mt-5 font-sans text-white/65 text-[15px] md:text-[16px] leading-relaxed max-w-xl mx-auto">
                  {space.desc}
                </p>

                {/* CTA vers la page dédiée si elle existe */}
                {SPACE_PAGES[space.id] && (
                  <Link
                    to={SPACE_PAGES[space.id].path}
                    className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-[11px] tracking-[0.2em] uppercase border transition-colors"
                    style={{
                      borderColor: `${space.accent}55`,
                      color: space.accent,
                      backgroundColor: `${space.accent}10`
                    }}
                  >
                    {SPACE_PAGES[space.id].label}
                  </Link>
                )}

                {/* Folders strip — compact, sur une ligne, centrée */}
                <div className="mt-8 w-full">
                  <div className="font-sans text-[10px] tracking-[0.3em] uppercase text-white/40 mb-3 text-center">
                    Tes dossiers
                  </div>
                  <div className="flex flex-wrap gap-3 md:gap-4 justify-center">
                    {space.folders.map((f, i) => (
                      <FolderCard
                        key={f.name}
                        name={f.name}
                        count={f.count}
                        palette={f.palette}
                        size="sm"
                        delay={0.1 + i * 0.06}
                      />
                    ))}
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Navigation 9 fenêtres — en bas, horizontale, avec point coloré accent */}
        <div className="mt-10 flex flex-wrap gap-1.5 justify-center">
          {spaces.map((s, i) => {
            const isLive = !s.phase || s.phase === "live";
            const phaseLabel = s.phase === "soon" ? "bientôt" : s.phase === "lab" ? "labo" : null;
            const HOVER_TOOLTIPS = {
              agriculteurs: "Pour ceux qui nourrissent le monde."
            };
            const isActive = active === i;
            return (
              <button
                key={s.id}
                onClick={() => setActive(i)}
                title={HOVER_TOOLTIPS[s.slug] || ""}
                className={`group px-3 py-1.5 rounded-full text-[11.5px] font-medium transition-all flex items-center gap-2 ${
                  isActive
                    ? "bg-white text-stone-900 shadow-lg"
                    : isLive
                    ? "bg-white/[0.06] text-white/60 hover:bg-white/[0.12] hover:text-white/90 border border-white/10"
                    : "bg-white/[0.02] text-white/40 hover:bg-white/[0.06] hover:text-white/60 border border-white/5"
                }`}
              >
                {/* Point coloré accent — comme dans le menu fenêtre */}
                <span
                  className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                  style={{
                    backgroundColor: s.accent || s.accent_color || "rgba(255,255,255,0.4)",
                    opacity: isActive ? 1 : 0.75
                  }}
                />
                {s.label}
                {phaseLabel && (
                  <span
                    className="text-[8px] tracking-wider uppercase px-1 py-0.5 rounded-full"
                    style={{
                      backgroundColor:
                        isActive ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.08)",
                      color: isActive ? "#666" : "rgba(255,255,255,0.5)"
                    }}
                  >
                    {phaseLabel}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}