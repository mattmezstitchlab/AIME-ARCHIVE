import React from "react";
import { motion } from "framer-motion";
import GrainedSection from "@/components/design-system/GrainedSection";

export default function ManifestoFooter() {
  return (
    <GrainedSection gradient="radial-gradient(ellipse at 50% 0%, rgba(255,107,53,0.12) 0%, transparent 55%), radial-gradient(ellipse at 50% 100%, rgba(76,82,255,0.12) 0%, transparent 55%), linear-gradient(180deg, #0A0A0B 0%, #050507 100%)">
      {/* Aïma portrait — fond du manifeste */}
      <img
        src="https://res.cloudinary.com/divou1vcx/image/upload/v1777316714/pexels-josue-velasquez-282193995-16791483_z8qo8m.jpg"
        alt=""
        aria-hidden="true"
        className="absolute inset-0 w-full h-full object-cover opacity-60 pointer-events-none"
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(180deg, rgba(10,10,11,0.35) 0%, rgba(10,10,11,0.2) 50%, rgba(10,10,11,0.2) 100%)"
        }}
      />
      <div className="relative max-w-3xl mx-auto px-6 py-24 md:py-32 text-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <div className="font-sans text-[12px] font-medium text-orange-300 mb-5">
            Manifeste
          </div>
          <p
            className="font-serif italic text-white/90 text-2xl md:text-4xl leading-tight"
            style={{ letterSpacing: "-0.02em" }}
          >
            « Je suis Aïma.
            <br />
            Je n'organise pas vos vies —
            <br />
            je les écoute, je les relie, je les compose avec vous. »
          </p>
          <div className="mt-10 font-sans text-white/50 text-[13px]">
            AIME · une présence, déjà là.
          </div>
        </motion.div>

        <div className="mt-16 pt-10 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-white/40 font-sans text-[12px]">
          <div>© AIME® · 2026 · www.aime-wedding.com</div>
          <div className="flex gap-6">
            <span>Charte</span>
            <span>Mentions légales</span>
            <span>Contact</span>
          </div>
        </div>
        <div className="mt-4 text-center text-[10px] tracking-[2px] text-white/30 uppercase">
          AIME® · Marque française déposée à l'INPI · n° 5164817 · n° 5226732 · Brevet en cours
        </div>
      </div>
    </GrainedSection>
  );
}