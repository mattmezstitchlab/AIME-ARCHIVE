import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AimaIcon from "@/components/design-system/AimaIcons";
import AimaToolDrawer from "./AimaToolDrawer";
import AimaModeSwitcher, { MODE_HEIGHTS } from "./AimaModeSwitcher";
import AimaProfileSwitcher, { getProfile } from "./AimaProfileSwitcher";
import { base44 } from "@/api/base44Client";
import { getAnonymousId, getConversationId, setConversationId } from "@/lib/aimaSession";
import AimeLogoIcon from "./AimeLogoIcon";
import { detectAimaContext } from "@/lib/aimaContextActions";

/**
 * AimaConversation — La fenêtre unique de discussion avec Aïma.
 * Connectée à Claude Sonnet via la fonction backend `aimaChat`.
 * Persiste dans l'entité `Conversation` (DB) — Aïma se souvient.
 */
const WELCOME_MESSAGE = {
  role: "aima",
  text:
    "Bonjour. Je suis Aïma, votre présence.\nDis-moi simplement ce que tu cherches — un mariage, un invité, un métier, un lieu, une mémoire. Je m'occupe du reste.",
  choices: [
    "Je me marie",
    "Je suis invité·e",
    "Je suis prestataire",
    "Je suis un lieu",
    "Je suis intermittent·e",
    "Je suis agriculteur·rice",
    "Je suis une mairie",
    "J'ai besoin d'aide (Inclusive)",
    "Je découvre"
  ]
};

export default function AimaConversation({ mode = "mid", onModeChange }) {
  const [messages, setMessages] = useState([WELCOME_MESSAGE]);
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState(false);
  const [openTool, setOpenTool] = useState(null);
  const [conversationId, setConvId] = useState(null);
  const [internalMode, setInternalMode] = useState(mode);
  const [manualProfile, setManualProfile] = useState(null); // override par le switcher
  const scrollerRef = useRef(null);
  const inputRef = useRef(null);

  // Mode contrôlé par parent si onModeChange fourni, sinon interne
  const activeMode = onModeChange ? mode : internalMode;
  const setMode = onModeChange || setInternalMode;

  const heights = MODE_HEIGHTS[activeMode] || MODE_HEIGHTS.mid;
  const isFull = activeMode === "full";
  const messageTextSize = activeMode === "min" ? "text-[13px]" : isFull ? "text-[16.5px]" : "text-[14.5px]";
  const inputTextSize = activeMode === "min" ? "text-[14px]" : isFull ? "text-[17px]" : "text-[15px]";

  // Le switcher manuel gagne sur la détection auto.
  // Aïma peut détecter un nouveau rôle via le dernier message ; si elle en trouve un
  // différent du défaut, il prend le pas (sauf override manuel explicite).
  const detected = detectAimaContext(messages);
  const context = manualProfile || detected;
  const contextColor = getProfile(context).color;

  // Restore prior conversation if any
  useEffect(() => {
    const existingId = getConversationId();
    if (!existingId) return;
    base44.entities.Conversation.filter({ id: existingId })
      .then((rows) => {
        const conv = rows?.[0];
        if (conv && Array.isArray(conv.messages) && conv.messages.length > 0) {
          setMessages([WELCOME_MESSAGE, ...conv.messages]);
          setConvId(conv.id);
        }
      })
      .catch(() => { /* silent */ });
  }, []);

  const toggleTool = (kind) => {
    setOpenTool((cur) => (cur === kind ? null : kind));
  };

  const handleDrawerPick = (item) => {
    if (item?.type === "prompt") {
      send(item.text);
      setOpenTool(null);
    }
  };

  // Auto-scroll on new message
  useEffect(() => {
    const el = scrollerRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const persist = async (allMessages, currentId) => {
    // Strip the WELCOME (it's static) before saving
    const toSave = allMessages
      .filter((m) => m !== WELCOME_MESSAGE && m.text !== WELCOME_MESSAGE.text)
      .map((m) => ({ role: m.role, text: m.text, ts: new Date().toISOString() }));
    const last_at = new Date().toISOString();
    try {
      if (currentId) {
        await base44.entities.Conversation.update(currentId, { messages: toSave, last_at });
        return currentId;
      } else {
        const created = await base44.entities.Conversation.create({
          anonymous_id: getAnonymousId(),
          space: "discover",
          messages: toSave,
          last_at
        });
        setConvId(created.id);
        setConversationId(created.id);
        return created.id;
      }
    } catch (_) {
      return currentId;
    }
  };

  const send = async (text) => {
    const value = (text ?? draft).trim();
    if (!value) return;
    const newUserMsg = { role: "user", text: value };
    const nextMessages = [...messages, newUserMsg];
    setMessages(nextMessages);
    setDraft("");
    setTyping(true);

    let convId = conversationId;
    try {
      const apiMessages = nextMessages
        .filter((m) => m.text !== WELCOME_MESSAGE.text)
        .map((m) => ({
          role: m.role === "user" ? "user" : "assistant",
          content: m.text
        }));

      const response = await base44.functions.invoke("aimaChat", {
        messages: apiMessages
      });

      const reply = response?.data?.reply || "Je tisse en silence. Dis-moi un mot de plus.";
      const finalMessages = [...nextMessages, { role: "aima", text: reply }];
      setMessages(finalMessages);
      // persist after both messages exist
      await persist(finalMessages, convId);
    } catch (err) {
      setMessages((m) => [...m, { role: "aima", text: "Un instant — je reprends mon souffle. Réessaie." }]);
    } finally {
      setTyping(false);
    }
  };

  const onChoice = (label) => {
    send(label);
    inputRef.current?.focus();
  };

  return (
    <div
      className={`relative w-full rounded-[26px] bg-black/35 backdrop-blur-2xl border border-white/15 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.65)] overflow-hidden ${
        isFull ? "h-full flex flex-col" : ""
      }`}
    >
      {/* Header : logo · profil switcher · mode switcher */}
      <div className="px-4 py-3 flex items-center justify-between border-b border-white/10 gap-2">
        <div className="flex items-center gap-2 text-[12px] min-w-0 flex-shrink-0">
          <AimeLogoIcon size={14} color={contextColor} />
          <span className="text-white/90 font-medium hidden md:inline">Aïma</span>
        </div>
        <div className="flex items-center gap-2">
          <AimaProfileSwitcher
            profileId={context}
            onChange={(id) => setManualProfile(id === "default" ? null : id)}
          />
          <AimaModeSwitcher mode={activeMode} onChange={setMode} />
        </div>
      </div>

      {/* Messages */}
      <div
        ref={scrollerRef}
        className={`px-5 py-5 overflow-y-auto space-y-3 ${isFull ? "flex-1" : ""}`}
        style={
          isFull
            ? { scrollbarWidth: "thin" }
            : { scrollbarWidth: "thin", maxHeight: heights.max, minHeight: heights.min }
        }
      >
        <AnimatePresence initial={false}>
          {messages.map((m, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[88%] px-1 py-1 ${messageTextSize} leading-relaxed whitespace-pre-line ${
                  m.role === "user"
                    ? "text-white/95 font-sans"
                    : "text-white/85 font-serif italic"
                }`}
                style={{ letterSpacing: m.role === "aima" ? "-0.01em" : "-0.012em" }}
              >
                {m.text}
                {m.role === "aima" && m.choices && (
                  <div className="mt-3 flex flex-wrap gap-1.5 not-italic font-sans">
                    {m.choices.map((c) => (
                      <button
                        key={c}
                        onClick={() => onChoice(c)}
                        className="px-3 py-1.5 rounded-full bg-white/[0.06] hover:bg-white/[0.14] border border-white/15 text-white/80 text-[12px] transition-colors"
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {typing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="px-1 py-2 flex gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </motion.div>
        )}
      </div>

      {/* Composer : champ blanc + bandeau pictos coloré pleine largeur */}
      <div className="p-3 bg-gradient-to-b from-transparent to-black/20">
        <div className="rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.06),0_8px_32px_rgba(0,0,0,0.28),0_24px_64px_rgba(0,0,0,0.22)] overflow-hidden">
          {/* Champ de saisie — toujours blanc */}
          <div className="bg-white focus-within:ring-2 focus-within:ring-stone-300/60 transition-all">
            <div className="flex items-center gap-2 px-3 py-2.5">
              <div className="w-7 h-7 rounded-lg bg-stone-100 flex items-center justify-center text-stone-600 font-serif text-[12px] flex-shrink-0">
                ◇
              </div>
              <input
                ref={inputRef}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="Dis-moi ce que tu cherches…"
                className={`flex-1 bg-transparent outline-none ${inputTextSize} text-stone-900 placeholder:text-stone-400 font-sans`}
                style={{ letterSpacing: "-0.012em" }}
              />
              <button
                onClick={() => send()}
                disabled={!draft.trim()}
                className="w-9 h-9 rounded-full bg-stone-900 hover:bg-black disabled:bg-stone-300 disabled:cursor-not-allowed text-white flex items-center justify-center transition-colors flex-shrink-0 shadow-md"
                aria-label="Envoyer à Aïma"
              >
                <AimaIcon name="arrow" size={15} className="text-white" strokeWidth={2.2} />
              </button>
            </div>
          </div>

          {/* Bandeau pictos — pleine largeur, couleur du mode actif, pictos blancs */}
          <div
            className="flex items-center justify-around px-3 py-2.5 transition-colors duration-300"
            style={{ backgroundColor: contextColor }}
          >
            <ToolBtn icon="spark" label="Aïma peut" active={openTool === "tools"} onClick={() => toggleTool("tools")} />
            <ToolBtn icon="memory" label="Dossiers" active={openTool === "folders"} onClick={() => toggleTool("folders")} />
            <ToolBtn icon="compose" label="Prestataires" active={openTool === "vendors"} onClick={() => toggleTool("vendors")} />
            <ToolBtn icon="image" label="Photos" active={openTool === "files"} onClick={() => toggleTool("files")} />
            <ToolBtn icon="attach" label="Joindre" active={openTool === "files"} onClick={() => toggleTool("files")} />
            <ToolBtn icon="voice" label="Voix" active={openTool === "voice"} onClick={() => toggleTool("voice")} />
          </div>
        </div>

      </div>

      {/* Tool drawer — overlay absolu au-dessus du composer, fenêtre fixe */}
      <AnimatePresence>
        {openTool && (
          <div className="absolute left-0 right-0 bottom-0 z-20 px-3 pb-3 pointer-events-none">
            <div className="rounded-2xl bg-black border border-white/15 shadow-[0_-12px_48px_rgba(0,0,0,0.7)] pointer-events-auto max-h-[55%] overflow-y-auto">
              <AimaToolDrawer
                key={openTool + context}
                kind={openTool}
                context={context}
                onPick={handleDrawerPick}
                onClose={() => setOpenTool(null)}
              />
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ToolBtn({ icon, label, active, onClick }) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      onClick={onClick}
      className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
        active
          ? "bg-white/95 text-stone-900 scale-105 shadow-md"
          : "text-white hover:bg-white/20"
      }`}
    >
      <AimaIcon name={icon} size={20} strokeWidth={1.8} />
    </button>
  );
}