import React from "react";
import { motion } from "framer-motion";

/**
 * FolderCard — un vrai dossier physique (chemise / suspendu).
 * - Onglet replié en haut (tab) avec étiquette manuscrite (Instrument Serif)
 * - Texture papier (grain SVG)
 * - Coin replié bas-droite (corner fold)
 * - Hover : se soulève, montre l'épaisseur
 *
 * Props:
 *   name: string (ex. "Invités")
 *   count: number (ex. 84) — affiché sur l'étiquette
 *   palette: "kraft" | "moss" | "navy" | "wine" | "plum" | "ink"
 *   icon: optional ReactNode (un petit pictogramme dans l'onglet)
 *   delay: animation delay (s)
 */

const PALETTES = {
  kraft:  { base: "#A56A3E", deep: "#6E3E1E", edge: "#D9A36A", tab: "#8B5A33", paper: "#F4E5CE" },
  moss:   { base: "#3F5E48", deep: "#1F3A2A", edge: "#7A9985", tab: "#2E4938", paper: "#E2E7DC" },
  navy:   { base: "#2E4566", deep: "#152843", edge: "#6B83A6", tab: "#22344F", paper: "#DDE4EE" },
  wine:   { base: "#7A2E3C", deep: "#3F1620", edge: "#B0707D", tab: "#5A1F2A", paper: "#EFD9DD" },
  plum:   { base: "#4A2E5C", deep: "#28163A", edge: "#7E5E94", tab: "#36204A", paper: "#E5DAEC" },
  ink:    { base: "#2A2A2E", deep: "#0E0E10", edge: "#5C5C62", tab: "#1B1B1F", paper: "#DEDEE2" }
};

export default function FolderCard({
  name,
  count,
  palette = "kraft",
  size = "md",
  delay = 0
}) {
  const c = PALETTES[palette] || PALETTES.kraft;
  const dims = size === "xs"
    ? { w: 100, h: 78, tabW: 44, tabH: 13 }
    : size === "sm"
    ? { w: 130, h: 100, tabW: 56, tabH: 16 }
    : size === "lg"
    ? { w: 220, h: 170, tabW: 96, tabH: 24 }
    : { w: 180, h: 140, tabW: 78, tabH: 20 };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -4 }}
      className="relative inline-flex flex-col items-center cursor-default group"
      style={{ width: dims.w }}
    >
      {/* Folder body wrapper — provides the stacked depth illusion */}
      <div
        className="relative"
        style={{ width: dims.w, height: dims.h }}
      >
        {/* Back papers (peek behind) */}
        <div
          className="absolute rounded-[3px]"
          style={{
            top: dims.tabH + 4,
            left: 6,
            right: 6,
            bottom: -2,
            background: c.paper,
            opacity: 0.55,
            transform: "rotate(-1deg)"
          }}
        />
        <div
          className="absolute rounded-[3px]"
          style={{
            top: dims.tabH + 6,
            left: 3,
            right: 3,
            bottom: -1,
            background: c.paper,
            opacity: 0.85,
            transform: "rotate(0.6deg)"
          }}
        />

        {/* The tab */}
        <div
          className="absolute"
          style={{
            top: 0,
            left: 14,
            width: dims.tabW,
            height: dims.tabH + 6,
            background: c.tab,
            borderTopLeftRadius: 4,
            borderTopRightRadius: 4,
            boxShadow: "inset 0 1px 0 rgba(255,255,255,0.08)"
          }}
        >
          {/* Tab label (manuscrite) */}
          <div
            className="absolute inset-0 flex items-center justify-center px-2"
            style={{
              fontFamily: "var(--font-serif)",
              fontStyle: "italic",
              fontSize: size === "xs" ? 8 : size === "sm" ? 9 : size === "lg" ? 13 : 11,
              color: "rgba(255,255,255,0.92)",
              letterSpacing: "-0.01em",
              lineHeight: 1
            }}
          >
            {name}
          </div>
        </div>

        {/* Folder front face */}
        <div
          className="absolute overflow-hidden"
          style={{
            top: dims.tabH,
            left: 0,
            right: 0,
            bottom: 0,
            background: `linear-gradient(180deg, ${c.base} 0%, ${c.deep} 100%)`,
            borderRadius: "4px 6px 4px 4px",
            boxShadow: `0 1px 0 ${c.edge} inset, 0 -2px 4px rgba(0,0,0,0.25) inset, 0 6px 18px -8px rgba(0,0,0,0.6), 0 1px 2px rgba(0,0,0,0.4)`
          }}
        >
          {/* Paper grain */}
          <svg className="absolute inset-0 w-full h-full opacity-[0.18] mix-blend-overlay pointer-events-none">
            <filter id={`folder-grain-${palette}-${name}`}>
              <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" />
              <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.6 0" />
            </filter>
            <rect width="100%" height="100%" filter={`url(#folder-grain-${palette}-${name})`} />
          </svg>

          {/* Top edge highlight */}
          <div
            className="absolute top-0 left-0 right-0 h-px"
            style={{ background: `linear-gradient(90deg, transparent, ${c.edge}, transparent)`, opacity: 0.7 }}
          />

          {/* Subtle horizontal crease line (folded fold) */}
          <div
            className="absolute left-2 right-2"
            style={{
              top: "55%",
              height: 1,
              background: `linear-gradient(90deg, transparent, rgba(0,0,0,0.25), transparent)`
            }}
          />

          {/* Count badge — paper sticker */}
          {count !== undefined && (
            <div
              className="absolute"
              style={{
                bottom: size === "xs" ? 7 : size === "sm" ? 10 : 14,
                left: size === "xs" ? 7 : size === "sm" ? 10 : 14,
                background: c.paper,
                color: c.deep,
                fontFamily: "var(--font-serif)",
                fontStyle: "italic",
                fontSize: size === "xs" ? 9 : size === "sm" ? 11 : size === "lg" ? 16 : 13,
                padding: size === "xs" ? "1.5px 6px" : size === "sm" ? "2px 8px" : "3px 10px",
                borderRadius: 999,
                boxShadow: "0 1px 0 rgba(255,255,255,0.5) inset, 0 1px 2px rgba(0,0,0,0.2)",
                lineHeight: 1
              }}
            >
              {count}
            </div>
          )}

          {/* Corner fold (bottom-right) */}
          <svg
            className="absolute bottom-0 right-0 pointer-events-none"
            width={size === "xs" ? 11 : size === "sm" ? 14 : size === "lg" ? 22 : 18}
            height={size === "xs" ? 11 : size === "sm" ? 14 : size === "lg" ? 22 : 18}
            viewBox="0 0 20 20"
          >
            <polygon
              points="20,20 0,20 20,0"
              fill={c.deep}
            />
            <polygon
              points="20,20 6,20 20,6"
              fill={c.paper}
              opacity="0.9"
            />
            <line x1="20" y1="6" x2="6" y2="20" stroke={c.deep} strokeWidth="0.5" opacity="0.4" />
          </svg>
        </div>
      </div>

      {/* Caption below */}
      <div className="mt-2 text-center">
        <div className={`text-white/85 font-sans font-medium leading-tight ${size === "xs" ? "text-[10px]" : "text-[12.5px]"}`}>{name}</div>
      </div>
    </motion.div>
  );
}