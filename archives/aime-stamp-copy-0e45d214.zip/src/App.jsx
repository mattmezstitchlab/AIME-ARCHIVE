import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Home from '@/pages/Home';
import Mariage from '@/pages/Mariage';
import TimbreNouveau from '@/pages/TimbreNouveau';
import MonTimbre from '@/pages/MonTimbre';
import Registre from '@/pages/Registre';
import Admin from '@/pages/Admin';
import MusicRights from '@/pages/MusicRights';
import RightAttestation from '@/pages/RightAttestation';
import MonCabinet from '@/pages/MonCabinet';
import Agriculteurs from '@/pages/Agriculteurs';
import Intermittents from '@/pages/Intermittents';
import Inclusive from '@/pages/Inclusive';
import Mairies from '@/pages/Mairies';
import Memoire from '@/pages/Memoire';
import Noyau from '@/pages/Noyau';
import AppShell from '@/components/universal/AppShell';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/mariage" element={<Mariage />} />
        <Route path="/timbre/nouveau" element={<TimbreNouveau />} />
        <Route path="/timbre" element={<MonTimbre />} />
        <Route path="/registre" element={<Registre />} />
        <Route path="/music-rights" element={<MusicRights />} />
        <Route path="/music-rights/:slug" element={<RightAttestation />} />
        <Route path="/mon-cabinet" element={<MonCabinet />} />
        <Route path="/agriculteurs" element={<Agriculteurs />} />
        <Route path="/intermittents" element={<Intermittents />} />
        <Route path="/inclusive" element={<Inclusive />} />
        <Route path="/mairies" element={<Mairies />} />
        <Route path="/memoire" element={<Memoire />} />
        <Route path="/noyau" element={<Noyau />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </AppShell>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App