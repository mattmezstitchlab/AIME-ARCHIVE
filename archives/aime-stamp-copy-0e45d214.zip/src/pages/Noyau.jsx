import React from "react";
import { motion } from "framer-motion";
import { useAimaModal } from "@/lib/AimaModalContext";
import NoyauIcon from "@/components/noyau/NoyauIcon";
import NoyauPhaseCard from "@/components/noyau/NoyauPhaseCard";

/**
 * Noyau — Page dédiée à l'outil NOYAU.
 * Pour les personnes atteintes de SLA — et tous ceux qui veulent transmettre.
 * Fond noir #0A0806, accents dorés #B89A52.
 */

const PHASES = [
  {
    n: "01",
    title: "Capture",
    italic: "Une question à la fois.",
    description:
      "Aïma pose des questions douces, à ton rythme. Chaque réponse est gardée — en voix et en texte. Tu valides, tu reformules, tu choisis ce qui reste.",
    bullets: [
      "« Raconte-moi quelque chose que tes enfants devraient entendre dans 10 ans. »",
      "« Quel est le souvenir qui te fait encore sourire ? »",
      "« Y a-t-il quelque chose que tu n'as jamais dit et que tu voudrais dire ? »"
    ]
  },
  {
    n: "02",
    title: "Voix",
    italic: "Pour qu'on t'entende toujours.",
    description:
      "Plus tu enregistres, plus le clone vocal s'affine. Au-delà de 80% de qualité, Aïma peut prêter ta voix à tes futurs messages — ceux que tu veux transmettre.",
    bullets: [
      "Lecture progressive de phrases courtes — 5 minutes par jour suffisent",
      "Modèle stocké en Europe, chiffré, jamais utilisé commercialement",
      "Disponible aussi pour celles et ceux qui ne sont pas malades — anniversaire, mariage, naissance"
    ]
  },
  {
    n: "03",
    title: "Mémoire",
    italic: "Tout ce que tu as déjà confié.",
    description:
      "Ta bibliothèque vivante — joie, fierté, amour, sagesse, regret. Aïma classe, propose des liens entre les souvenirs, et te laisse choisir qui peut y accéder : toi seul·e, ton cercle proche, ou le futur.",
    bullets: [
      "Chaque entrée taggée par émotion détectée",
      "Visibilité : Privé · Cercle proche · Futur",
      "Liens automatiques entre souvenirs proches"
    ]
  },
  {
    n: "04",
    title: "Transmission",
    italic: "Des mots qui arrivent à l'heure.",
    description:
      "Tu écris des messages déclenchés par des événements futurs : un anniversaire, une naissance, un mariage, un jour de doute. Aïma garde, et délivre le moment venu — texte, voix réelle, ou voix clonée.",
    bullets: [
      "« À la naissance de mon premier petit-enfant »",
      "« Le jour où ma fille doutera d'elle »",
      "Aïma t'aide à formuler — tu valides, tu signes."
    ]
  }
];

export default function Noyau() {
  const { openAima } = useAimaModal();

  return (
    <div className="min-h-screen font-sans" style={{ backgroundColor: "#0A0806" }}>
      {/* HERO */}
      <section className="relative pt-28 md:pt-32 pb-16 md:pb-20 px-6 overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 60% 40% at 50% 0%, rgba(184,154,82,0.18), transparent 60%)"
          }}
        />
        <div className="relative max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center mb-7"
          >
            <NoyauIcon size={72} color="#B89A52" />
          </motion.div>

          <div className="text-[10px] tracking-[0.4em] uppercase text-[#B89A52] mb-5">
            Une innovation AIME® · Inclusive
          </div>

          <motion.h1
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="apple-headline text-white text-5xl md:text-6xl lg:text-7xl mb-5"
          >
            NOYAU
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="text-[18px] md:text-[20px] italic text-white/85 mb-7 leading-snug"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Ce que tu es ne peut pas être effacé.
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.45 }}
            className="text-[14.5px] md:text-[15.5px] text-white/60 max-w-xl mx-auto leading-relaxed mb-8"
          >
            Capturer la voix, les histoires, les valeurs d'une personne — avant que la maladie ne progresse.
            <br />
            Aïma garde le Noyau. Pour toujours.
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-wrap justify-center gap-2 mb-9"
          >
            {["Gratuit", "Confidentiel", "Conçu avec des familles SLA"].map((b) => (
              <span
                key={b}
                className="px-3 py-1 rounded-full border border-[#B89A52]/30 text-[10px] tracking-[2.5px] uppercase text-[#B89A52]/85"
              >
                {b}
              </span>
            ))}
          </motion.div>

          <motion.button
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.75 }}
            onClick={openAima}
            className="px-9 py-4 rounded-full bg-[#B89A52] text-[#0A0806] text-[10px] tracking-[0.3em] uppercase font-medium hover:bg-[#D4B66E] transition-colors"
          >
            Commencer avec Aïma
          </motion.button>

          <p
            className="mt-6 text-[13px] text-white/55 italic max-w-md mx-auto leading-relaxed"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            « Pour les proches atteints de SLA — et tous ceux qui veulent transmettre. »
          </p>
        </div>
      </section>

      {/* PHRASE D'ACCUEIL D'AÏMA */}
      <section className="px-6 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mx-auto rounded-3xl border border-[#B89A52]/25 bg-gradient-to-br from-[#1a1208]/60 to-[#0F0A05]/60 p-7 md:p-9"
        >
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-full bg-[#B89A52] text-[#0A0806] flex items-center justify-center font-serif text-[16px] flex-shrink-0">
              A
            </div>
            <div className="flex-1">
              <div className="text-[10px] tracking-[0.3em] uppercase text-[#B89A52] mb-3 font-medium">
                Aïma
              </div>
              <p
                className="text-white/85 text-[14.5px] md:text-[15.5px] leading-relaxed italic"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                Bonjour. Je suis Aïma.
                <br />
                Je ne suis pas un outil médical. Je suis une présence.
                <br />
                Je suis là pour garder ce que tu es — ta voix, tes histoires, ce que tu veux transmettre.
                <br />
                On commence quand tu veux. À ton rythme. Sans pression.
                <br />
                <span className="text-[#B89A52] not-italic font-sans text-[13px] tracking-wide mt-3 block">
                  → Dis-moi juste ton prénom.
                </span>
              </p>
            </div>
          </div>
        </motion.div>
      </section>

      {/* LES 4 PHASES */}
      <section className="px-6 py-16 md:py-20 border-t border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="text-[10px] tracking-[0.35em] uppercase text-[#B89A52] mb-4">
              Le chemin du Noyau
            </div>
            <h2 className="apple-headline text-white text-3xl md:text-4xl lg:text-5xl mb-4">
              QUATRE PHASES,
              <br />
              <span className="text-white/60">une seule mémoire.</span>
            </h2>
            <p className="text-white/55 text-[14.5px] leading-relaxed">
              Tu n'as pas à tout faire d'un coup. Aïma t'accompagne phase par phase, à ton rythme, et garde tout en lieu sûr.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {PHASES.map((p, i) => (
              <NoyauPhaseCard key={p.n} {...p} delay={i * 0.08} />
            ))}
          </div>
        </div>
      </section>

      {/* CONFIDENTIALITÉ */}
      <section className="px-6 py-14 border-t border-white/5">
        <div className="max-w-3xl mx-auto text-center">
          <div className="text-[10px] tracking-[0.35em] uppercase text-[#B89A52] mb-5">
            Confidentialité absolue
          </div>
          <p
            className="text-white/75 text-[16px] md:text-[18px] italic leading-relaxed mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            « Tes données sont chiffrées. Stockées en Europe.
            <br />
            Jamais utilisées commercialement. Tu peux tout supprimer à tout moment. »
          </p>
          <div className="flex flex-wrap justify-center gap-2 text-[10px] tracking-[2.5px] uppercase text-white/45">
            <span>Chiffrement E2E</span>
            <span>·</span>
            <span>Hébergement Europe</span>
            <span>·</span>
            <span>Zéro usage commercial</span>
            <span>·</span>
            <span>Droit à l'oubli</span>
          </div>
        </div>
      </section>

      {/* CTA FOOTER */}
      <section className="px-6 py-20 border-t border-white/5">
        <div className="max-w-2xl mx-auto text-center">
          <p
            className="text-white/85 text-[20px] md:text-[24px] italic leading-snug mb-3"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            « Charcot prend le corps.
            <br />
            <span className="text-[#B89A52]">NOYAU garde l'âme.</span> »
          </p>
          <div className="text-[9px] tracking-[0.35em] uppercase text-white/35 mt-8">
            AIME® Noyau · 🕊️
          </div>
        </div>
      </section>
    </div>
  );
}