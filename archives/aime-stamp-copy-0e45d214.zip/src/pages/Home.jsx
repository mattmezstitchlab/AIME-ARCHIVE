import React from "react";
import FourSpacesSection from "@/components/universal/FourSpacesSection";
import ContextAwareSection from "@/components/universal/ContextAwareSection";
import ManifestoFooter from "@/components/universal/ManifestoFooter";

export default function Home() {
  return (
    <div className="bg-[#0A0A0B] font-sans">
      {/* 1. Hero = section des 9 fenêtres — le cœur de l'expérience */}
      <FourSpacesSection />

      {/* 2. Context aware — démontre que tout passe par cette fenêtre */}
      <ContextAwareSection />

      {/* 3. Manifeste / footer */}
      <ManifestoFooter />
    </div>
  );
}