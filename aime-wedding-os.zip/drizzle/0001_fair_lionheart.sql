CREATE TABLE `budget_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`category` varchar(100) NOT NULL,
	`label` varchar(255) NOT NULL,
	`estimatedAmount` int,
	`actualAmount` int,
	`isPaid` boolean DEFAULT false,
	`providerId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `budget_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`providerId` int,
	`type` enum('devis','contrat','brief','facture','planning','autre') NOT NULL,
	`title` varchar(255) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileKey` varchar(500) NOT NULL,
	`mimeType` varchar(100),
	`fileSize` int,
	`status` enum('draft','sent','signed','archived') NOT NULL DEFAULT 'draft',
	`backgroundTheme` enum('floral','cosmic','minimal','warm') DEFAULT 'floral',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(50),
	`group` enum('family_bride','family_groom','friends','colleagues','other') DEFAULT 'other',
	`rsvpStatus` enum('pending','confirmed','declined','maybe') DEFAULT 'pending',
	`dietaryNeeds` text,
	`plusOne` boolean DEFAULT false,
	`tableNumber` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `intermittent_docs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingProviderId` int NOT NULL,
	`docType` enum('contrat_engagement','dpae','aem','fiche_paie','attestation_conges','certificat_conges','declaration_guso','ordre_mission','feuille_route','autre') NOT NULL,
	`status` enum('to_prepare','draft','to_verify','sent','signed','archived') DEFAULT 'to_prepare',
	`fileUrl` text,
	`fileKey` varchar(500),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `intermittent_docs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `memories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`type` enum('decision','milestone','emotion','detail','quote') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text,
	`source` varchar(100),
	`importance` enum('low','medium','high') DEFAULT 'medium',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `memories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`parsedData` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `providers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` enum('traiteur','photographe','videaste','fleuriste','musicien','dj','decorateur','officiant','wedding_planner','lieu','patissier','coiffeur','maquilleur','sono','autre') NOT NULL,
	`description` text,
	`city` varchar(255),
	`priceRange` varchar(100),
	`isIntermittent` boolean DEFAULT false,
	`intermittentType` enum('artiste','technicien','association','societe','auto_entrepreneur','guso','unknown'),
	`contactEmail` varchar(320),
	`contactPhone` varchar(50),
	`website` varchar(500),
	`imageUrl` text,
	`rating` int,
	`tags` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `providers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `spaces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`type` enum('couple','invites','prestataires','timeline','budget','documents','memoire') NOT NULL,
	`data` text,
	`status` enum('empty','in_progress','complete') NOT NULL DEFAULT 'empty',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `spaces_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `timeline_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`eventDate` timestamp,
	`category` enum('preparation','ceremony','reception','after','admin') DEFAULT 'preparation',
	`isCompleted` boolean DEFAULT false,
	`order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `timeline_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_providers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`weddingId` int NOT NULL,
	`providerId` int NOT NULL,
	`status` enum('shortlisted','contacted','confirmed','rejected') NOT NULL DEFAULT 'shortlisted',
	`mission` text,
	`depositAmount` int,
	`totalAmount` int,
	`depositPaid` boolean DEFAULT false,
	`totalPaid` boolean DEFAULT false,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_providers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weddings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`partnerName` varchar(255),
	`city` varchar(255),
	`venue` varchar(255),
	`weddingDate` timestamp,
	`guestCount` int,
	`estimatedBudget` int,
	`ambiance` text,
	`needs` text,
	`status` enum('planning','confirmed','completed') NOT NULL DEFAULT 'planning',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weddings_id` PRIMARY KEY(`id`)
);
