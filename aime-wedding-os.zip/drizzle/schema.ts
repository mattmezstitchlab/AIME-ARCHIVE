import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Weddings — one per couple
 */
export const weddings = mysqlTable("weddings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // owner (couple member 1)
  partnerName: varchar("partnerName", { length: 255 }),
  city: varchar("city", { length: 255 }),
  venue: varchar("venue", { length: 255 }),
  weddingDate: timestamp("weddingDate"),
  guestCount: int("guestCount"),
  estimatedBudget: int("estimatedBudget"), // in cents
  ambiance: text("ambiance"), // JSON array of style keywords
  needs: text("needs"), // JSON array of detected needs
  status: mysqlEnum("status", ["planning", "confirmed", "completed"]).default("planning").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Wedding = typeof weddings.$inferSelect;
export type InsertWedding = typeof weddings.$inferInsert;

/**
 * Messages — conversation history with AIME
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  parsedData: text("parsedData"), // JSON: extracted entities from this message
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Spaces — the 7 dynamic spaces for each wedding
 */
export const spaces = mysqlTable("spaces", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  type: mysqlEnum("type", ["couple", "invites", "prestataires", "timeline", "budget", "documents", "memoire"]).notNull(),
  data: text("data"), // JSON: space-specific structured data
  status: mysqlEnum("status", ["empty", "in_progress", "complete"]).default("empty").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Space = typeof spaces.$inferSelect;
export type InsertSpace = typeof spaces.$inferInsert;

/**
 * Providers — marketplace prestataires
 */
export const providers = mysqlTable("providers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", [
    "traiteur", "photographe", "videaste", "fleuriste", "musicien",
    "dj", "decorateur", "officiant", "wedding_planner", "lieu",
    "patissier", "coiffeur", "maquilleur", "sono", "autre"
  ]).notNull(),
  description: text("description"),
  city: varchar("city", { length: 255 }),
  priceRange: varchar("priceRange", { length: 100 }), // e.g. "2000-5000"
  isIntermittent: boolean("isIntermittent").default(false),
  intermittentType: mysqlEnum("intermittentType", [
    "artiste", "technicien", "association", "societe", "auto_entrepreneur", "guso", "unknown"
  ]),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  website: varchar("website", { length: 500 }),
  imageUrl: text("imageUrl"),
  rating: int("rating"), // 1-5
  tags: text("tags"), // JSON array
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Provider = typeof providers.$inferSelect;
export type InsertProvider = typeof providers.$inferInsert;

/**
 * Wedding-Provider relationships
 */
export const weddingProviders = mysqlTable("wedding_providers", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId").notNull(),
  status: mysqlEnum("status", ["shortlisted", "contacted", "confirmed", "rejected"]).default("shortlisted").notNull(),
  mission: text("mission"), // what they're hired for
  depositAmount: int("depositAmount"), // in cents
  totalAmount: int("totalAmount"), // in cents
  depositPaid: boolean("depositPaid").default(false),
  totalPaid: boolean("totalPaid").default(false),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingProvider = typeof weddingProviders.$inferSelect;
export type InsertWeddingProvider = typeof weddingProviders.$inferInsert;

/**
 * Documents — uploaded files (devis, contrats, briefs)
 */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  providerId: int("providerId"), // optional: linked to a provider
  type: mysqlEnum("type", ["devis", "contrat", "brief", "facture", "planning", "autre"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(), // S3 storage URL
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"), // bytes
  status: mysqlEnum("status", ["draft", "sent", "signed", "archived"]).default("draft").notNull(),
  backgroundTheme: mysqlEnum("backgroundTheme", ["floral", "geometric", "watercolor", "cosmic", "minimal", "warm"]).default("floral"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

/**
 * Memory — capsules of important moments and decisions
 */
export const memories = mysqlTable("memories", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  type: mysqlEnum("type", ["decision", "milestone", "emotion", "detail", "quote"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  source: varchar("source", { length: 100 }), // which space/conversation generated this
  importance: mysqlEnum("importance", ["low", "medium", "high"]).default("medium"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Memory = typeof memories.$inferSelect;
export type InsertMemory = typeof memories.$inferInsert;

/**
 * Timeline events
 */
export const timelineEvents = mysqlTable("timeline_events", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  eventDate: timestamp("eventDate"),
  category: mysqlEnum("category", ["preparation", "ceremony", "reception", "after", "admin"]).default("preparation"),
  isCompleted: boolean("isCompleted").default(false),
  order: int("order").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TimelineEvent = typeof timelineEvents.$inferSelect;
export type InsertTimelineEvent = typeof timelineEvents.$inferInsert;

/**
 * Guests — invités management
 */
export const guests = mysqlTable("guests", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  group: mysqlEnum("group", ["family_bride", "family_groom", "friends", "colleagues", "other"]).default("other"),
  rsvpStatus: mysqlEnum("rsvpStatus", ["pending", "confirmed", "declined", "maybe"]).default("pending"),
  dietaryNeeds: text("dietaryNeeds"),
  plusOne: boolean("plusOne").default(false),
  tableNumber: int("tableNumber"),
  inviteToken: varchar("inviteToken", { length: 64 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Guest = typeof guests.$inferSelect;
export type InsertGuest = typeof guests.$inferInsert;

/**
 * Budget items
 */
export const budgetItems = mysqlTable("budget_items", {
  id: int("id").autoincrement().primaryKey(),
  weddingId: int("weddingId").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  estimatedAmount: int("estimatedAmount"), // in cents
  actualAmount: int("actualAmount"), // in cents
  isPaid: boolean("isPaid").default(false),
  providerId: int("providerId"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BudgetItem = typeof budgetItems.$inferSelect;
export type InsertBudgetItem = typeof budgetItems.$inferInsert;

/**
 * Intermittent documents — specific to spectacle workers
 */
export const intermittentDocs = mysqlTable("intermittent_docs", {
  id: int("id").autoincrement().primaryKey(),
  weddingProviderId: int("weddingProviderId").notNull(),
  docType: mysqlEnum("docType", [
    "contrat_engagement", "dpae", "aem", "fiche_paie",
    "attestation_conges", "certificat_conges",
    "declaration_guso", "ordre_mission", "feuille_route", "autre"
  ]).notNull(),
  status: mysqlEnum("status", ["to_prepare", "draft", "to_verify", "sent", "signed", "archived"]).default("to_prepare"),
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type IntermittentDoc = typeof intermittentDocs.$inferSelect;
export type InsertIntermittentDoc = typeof intermittentDocs.$inferInsert;
