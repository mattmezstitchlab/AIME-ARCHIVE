# AIME Wedding OS — TODO

## Architecture & Backend
- [x] Schéma DB complet (weddings, messages, spaces, providers, documents, memory, invites)
- [x] Migration SQL appliquée
- [x] Routes tRPC : chat AIME avec LLM (parsing + réponse naturelle)
- [x] Routes tRPC : espaces (list + get, remplis automatiquement par le chat)
- [x] Routes tRPC : marketplace prestataires (list, get, add, updateStatus, myProviders)
- [x] Routes tRPC : upload documents (S3 + métadonnées DB)
- [x] Routes tRPC : mémoire centrale (historique horodaté)
- [x] Routes tRPC : timeline, guests, budget CRUD
- [x] Seed data : 24 prestataires fictifs dans la DB

## Frontend — Design & Layout
- [x] Design system neumorphique blanc/ivoire/fuchsia
- [x] Toolbar latérale gauche avec pictos-ancres (inspiré runey.app)
- [x] Thème clair premium (Tailwind CSS variables)
- [x] Typographie élégante (Playfair Display + Inter)

## Frontend — Pages & Composants
- [x] Page d'accueil immersive (hero plein écran, visuels astronautes/mariage)
- [x] Chat AIME conversationnel (champ central, réponses LLM, parsing intelligent)
- [x] 7 espaces dynamiques avec panneaux détaillés au clic
- [x] Marketplace prestataires avec filtres catégorie + recherche
- [x] Fiches prestataires (dialog détail, badge intermittent)
- [x] Upload documents réels (base64 → S3)
- [x] Documents affichés sur fond artistique/floral
- [x] Mémoire centrale avec capsules visuelles horodatées
- [x] Sélecteur de type document dans l'UI d'upload (devis/contrat/brief)
- [x] Auto-filtrage marketplace basé sur besoins détectés
- [x] Commentaire/recommandation AIME dans fiche prestataire

## Multi-rôles
- [x] Interface Invités (RSVP, infos pratiques, accès filtré) — /guest portal
- [x] Interface Prestataires (missions, documents, paiements) — /provider portal

## Tests & Livraison
- [x] Tests unitaires (vitest) — 14 tests passants
- [x] Checkpoint final

## Corrections
- [x] Home ne redirige plus automatiquement vers /dashboard quand connecté — afficher les visuels astronautes
- [x] Header transparent sur la Home avec logo AIME et lien dashboard
- [x] Animations au scroll (fade-in/slide-up) sur chaque section de la Home
- [x] Choix de motifs personnalisables (floral, géométrique, aquarelle) pour fond des documents
- [x] Toggle dark/light mode dans le header et AppLayout
- [x] Drag & drop pour l'upload de documents
- [x] Partage de lien invité unique (token-based RSVP sans compte)
- [x] Toggle dark/light dans le header transparent de la Home
- [x] UI de génération/copier/partage des liens invités dans la gestion des invités
- [x] Corriger InviteRSVP.tsx pour afficher le vrai statut soumis
- [x] Refonte Home : visuel plein écran cosmonaute + chat AIME centré style Perplexity
- [x] Icônes d'ancrage sous le champ de saisie (timeline, traiteur, photographe, etc.)
- [x] Header : coeur blanc battant au lieu du rond rose avec A
- [x] Supprimer visuels indépendants et filtres blancs — sections immersives plein écran
- [x] Cockpit unique : bloc conversation central + pictos + contenu contextuel en dessous
- [x] Pictos adaptés par rôle (marié : timeline/budget/prestataires/docs ; invité : RSVP/infos ; prestataire : missions/docs)
- [x] Supprimer la sidebar — tout vit dans le cockpit glassmorphism
- [x] Le cockpit est l'interface unifiée pour les 3 rôles depuis un seul point d'entrée
- [x] Supprimer les routes séparées /marketplace, /documents, /memory — tout passe par le cockpit
- [x] Retirer AppLayout (sidebar) qui n'est plus utilisé
- [x] Home reste accessible (landing) mais le cockpit /dashboard est le seul espace de travail
- [x] Carrousel prestataires style Runey (photo plein cadre + overlay texte + défilement lent + coche pour timeline)
- [x] Upload documents directement depuis le panneau Documents du cockpit (drag & drop)
- [x] Animations de transition fade/slide entre panneaux du cockpit
- [x] Badges notifications sur les pictos (actions en attente)
- [x] Audit de cohérence globale du site (structure OK, providers ont imageUrl/category/description/city/priceRange)
- [x] Fond animé multi-visuels défilant lentement sur le dashboard (filtre léger, toutes les images)
- [x] Filtres par catégorie dans le carrousel prestataires (onglets Photographe, Traiteur, etc.)
- [x] Modal détail prestataire au clic (description complète, tags, avis, bouton contact)
- [x] Export PDF de la timeline partageable avec les prestataires
- [x] Remplacer le picto Sparkles (étoile) par Heart (cœur) pour le bouton AIME dans le cockpit
- [x] Supprimer le modal détail prestataire — l'agent AIME est l'unique interlocuteur pour parler des prestataires
- [ ] Audit opérationnel complet (DB, auth, routes, edge cases) pour utilisation réelle
- [ ] Enrichir les réponses AIME pour expliquer pourquoi un prestataire correspond au couple (points communs, style, valeurs)
- [ ] Ajouter un match score visuel sur les cartes prestataires (calculé par AIME selon besoins du couple)
- [ ] Intégrer un bouton "Demander à AIME" dans le panneau Prestataires pour recommandations personnalisées
