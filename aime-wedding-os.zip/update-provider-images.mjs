import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;
const conn = await mysql.createConnection(DATABASE_URL);

// Map categories to images
const categoryImages = {
  photographe: "/manus-storage/TyuLEbFj4bzr_d82f4910.jpg",
  videaste: "/manus-storage/4rxVuCglsM3a_66a0648b.jpg",
  traiteur: "/manus-storage/rIjhGlXBlD9L_f65f97ed.jpg",
  fleuriste: "/manus-storage/HtGlbW2E6EIT_e1eb7a3d.jpg",
  musicien: "/manus-storage/tp4zyYhjv92f_772211c0.jpg",
  dj: "/manus-storage/Z5gJT3dceuVt_02f13811.jpeg",
  decorateur: "/manus-storage/D8Ns7j9mgCeK_ebd36388.jpg",
  officiant: "/manus-storage/WZgT8UUsE24e_6b47042a.jpg",
  lieu: "/manus-storage/p9GpPDzZt1BL_92e5870c.jpg",
  patissier: "/manus-storage/5zuYpg860ZYE_782b3bb1.jpg",
  coiffeur: "/manus-storage/LvwP6BNDN9CZ_ef068dff.jpg",
  maquilleur: "/manus-storage/LvwP6BNDN9CZ_ef068dff.jpg",
  wedding_planner: "/manus-storage/4rxVuCglsM3a_66a0648b.jpg",
  sono: "/manus-storage/Z5gJT3dceuVt_02f13811.jpeg",
  autre: "/manus-storage/WZgT8UUsE24e_6b47042a.jpg",
};

for (const [category, imageUrl] of Object.entries(categoryImages)) {
  await conn.execute(
    "UPDATE providers SET imageUrl = ? WHERE category = ? AND (imageUrl IS NULL OR imageUrl = '')",
    [imageUrl, category]
  );
  console.log(`Updated ${category} -> ${imageUrl}`);
}

console.log("Done!");
await conn.end();
