import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('DATABASE_URL not set');
  process.exit(1);
}

const providers = [
  // Traiteurs
  { name: "Maison Delacroix", category: "traiteur", description: "Cuisine gastronomique française raffinée pour événements d'exception. Menus personnalisés et service à table impeccable.", city: "Paris", priceRange: "8000-15000", isIntermittent: false, rating: 5, tags: JSON.stringify(["gastronomique", "français", "premium"]) },
  { name: "L'Atelier Gourmand", category: "traiteur", description: "Traiteur créatif spécialisé dans les buffets élégants et les cocktails dînatoires. Produits locaux et de saison.", city: "Lyon", priceRange: "5000-10000", isIntermittent: false, rating: 4, tags: JSON.stringify(["buffet", "cocktail", "local"]) },
  { name: "Saveurs du Monde", category: "traiteur", description: "Fusion culinaire internationale. Spécialités libanaises, japonaises et méditerranéennes pour mariages multiculturels.", city: "Marseille", priceRange: "4000-8000", isIntermittent: false, rating: 4, tags: JSON.stringify(["fusion", "international", "multiculturel"]) },

  // Photographes
  { name: "Studio Lumière", category: "photographe", description: "Photographie de mariage artistique et émotionnelle. Style documentaire et portraits cinématiques.", city: "Paris", priceRange: "3000-6000", isIntermittent: true, intermittentType: "artiste", rating: 5, tags: JSON.stringify(["artistique", "documentaire", "cinématique"]) },
  { name: "Iris & Objectif", category: "photographe", description: "Duo de photographes spécialisés dans les mariages intimes et les elopements. Style naturel et lumineux.", city: "Bordeaux", priceRange: "2500-4500", isIntermittent: true, intermittentType: "auto_entrepreneur", rating: 4, tags: JSON.stringify(["intime", "naturel", "elopement"]) },
  { name: "Capturer l'Instant", category: "photographe", description: "Reportage photo complet du mariage. Approche discrète et résultats authentiques.", city: "Nice", priceRange: "2000-4000", isIntermittent: true, intermittentType: "auto_entrepreneur", rating: 4, tags: JSON.stringify(["reportage", "discret", "authentique"]) },

  // Vidéastes
  { name: "Cinéma d'Amour", category: "videaste", description: "Films de mariage cinématographiques avec drone. Montage narratif et bande sonore sur mesure.", city: "Paris", priceRange: "4000-8000", isIntermittent: true, intermittentType: "technicien", rating: 5, tags: JSON.stringify(["cinématique", "drone", "narratif"]) },
  { name: "Motion Wedding", category: "videaste", description: "Vidéo de mariage moderne et dynamique. Clips courts pour réseaux sociaux inclus.", city: "Toulouse", priceRange: "2500-5000", isIntermittent: true, intermittentType: "artiste", rating: 4, tags: JSON.stringify(["moderne", "dynamique", "social media"]) },

  // Fleuristes
  { name: "Pétales & Poésie", category: "fleuriste", description: "Art floral poétique et éco-responsable. Compositions sauvages et romantiques avec fleurs de saison.", city: "Paris", priceRange: "2000-5000", isIntermittent: false, rating: 5, tags: JSON.stringify(["poétique", "éco-responsable", "sauvage"]) },
  { name: "Bloom Studio", category: "fleuriste", description: "Design floral contemporain et architectural. Installations spectaculaires et arches fleuries.", city: "Lyon", priceRange: "3000-7000", isIntermittent: false, rating: 4, tags: JSON.stringify(["contemporain", "architectural", "spectaculaire"]) },

  // Musiciens
  { name: "Quatuor Étoile", category: "musicien", description: "Quatuor à cordes classique pour cérémonies. Répertoire classique et arrangements pop/variété.", city: "Paris", priceRange: "1500-3000", isIntermittent: true, intermittentType: "artiste", rating: 5, tags: JSON.stringify(["classique", "cérémonie", "cordes"]) },
  { name: "Jazz & Soul Collective", category: "musicien", description: "Groupe de jazz et soul pour cocktails et soirées. Ambiance feutrée et élégante.", city: "Paris", priceRange: "2000-4000", isIntermittent: true, intermittentType: "artiste", rating: 4, tags: JSON.stringify(["jazz", "soul", "cocktail"]) },
  { name: "Acoustic Duo", category: "musicien", description: "Duo guitare-voix pour cérémonies laïques et vins d'honneur. Reprises folk et pop acoustique.", city: "Nantes", priceRange: "800-1500", isIntermittent: true, intermittentType: "artiste", rating: 4, tags: JSON.stringify(["acoustique", "folk", "cérémonie laïque"]) },

  // DJs
  { name: "DJ Maxime Laurent", category: "dj", description: "DJ professionnel spécialisé mariages haut de gamme. Mix éclectique, sono premium et éclairage.", city: "Paris", priceRange: "1500-3500", isIntermittent: true, intermittentType: "technicien", rating: 5, tags: JSON.stringify(["haut de gamme", "éclectique", "éclairage"]) },
  { name: "SoundWave Events", category: "dj", description: "DJ et MC pour soirées de mariage animées. Matériel professionnel et playlist personnalisée.", city: "Lille", priceRange: "1000-2500", isIntermittent: true, intermittentType: "technicien", rating: 4, tags: JSON.stringify(["animé", "MC", "personnalisé"]) },

  // Décorateurs
  { name: "Atelier Déco & Style", category: "decorateur", description: "Décoration de mariage sur mesure. Scénographie complète : tables, cérémonie, photobooth.", city: "Paris", priceRange: "3000-8000", isIntermittent: false, rating: 5, tags: JSON.stringify(["sur mesure", "scénographie", "complet"]) },
  { name: "Bohème Déco", category: "decorateur", description: "Location et installation de décoration bohème et champêtre. Mobilier vintage et macramé.", city: "Aix-en-Provence", priceRange: "1500-4000", isIntermittent: false, rating: 4, tags: JSON.stringify(["bohème", "champêtre", "vintage"]) },

  // Officiants
  { name: "Cérémonies d'Ailleurs", category: "officiant", description: "Officiant de cérémonie laïque bilingue. Cérémonies personnalisées et émouvantes.", city: "Paris", priceRange: "800-1500", isIntermittent: true, intermittentType: "auto_entrepreneur", rating: 5, tags: JSON.stringify(["laïque", "bilingue", "personnalisé"]) },

  // Lieux
  { name: "Château de Versigny", category: "lieu", description: "Château du XVIIIe siècle avec parc de 5 hectares. Capacité 200 personnes. Hébergement sur place.", city: "Senlis", priceRange: "8000-15000", isIntermittent: false, rating: 5, tags: JSON.stringify(["château", "parc", "hébergement"]) },
  { name: "Domaine des Oliviers", category: "lieu", description: "Mas provençal avec oliveraie et piscine. Vue panoramique sur les collines. 150 personnes max.", city: "Aix-en-Provence", priceRange: "6000-12000", isIntermittent: false, rating: 4, tags: JSON.stringify(["provençal", "oliveraie", "vue"]) },
  { name: "Le Loft Industriel", category: "lieu", description: "Espace industriel réhabilité au cœur de Paris. 300m², verrière, briques apparentes. 120 personnes.", city: "Paris", priceRange: "4000-8000", isIntermittent: false, rating: 4, tags: JSON.stringify(["industriel", "loft", "urbain"]) },

  // Pâtissiers
  { name: "Maison Sucrée", category: "patissier", description: "Wedding cakes et pièces montées d'exception. Créations artistiques et saveurs raffinées.", city: "Paris", priceRange: "500-2000", isIntermittent: false, rating: 5, tags: JSON.stringify(["wedding cake", "artistique", "raffiné"]) },

  // Coiffeurs
  { name: "Hair by Camille", category: "coiffeur", description: "Coiffure de mariée à domicile. Chignons, tresses et coiffures bohèmes. Essai inclus.", city: "Paris", priceRange: "300-600", isIntermittent: true, intermittentType: "auto_entrepreneur", rating: 5, tags: JSON.stringify(["à domicile", "bohème", "chignon"]) },

  // Maquilleurs
  { name: "Glow Beauty", category: "maquilleur", description: "Maquillage mariée naturel et lumineux. Produits haut de gamme et longue tenue.", city: "Paris", priceRange: "250-500", isIntermittent: true, intermittentType: "auto_entrepreneur", rating: 4, tags: JSON.stringify(["naturel", "lumineux", "longue tenue"]) },
];

async function seed() {
  const connection = await mysql.createConnection(DATABASE_URL);

  console.log('Seeding providers...');

  for (const p of providers) {
    await connection.execute(
      `INSERT INTO providers (name, category, description, city, priceRange, isIntermittent, intermittentType, rating, tags)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE description = VALUES(description)`,
      [p.name, p.category, p.description, p.city, p.priceRange, p.isIntermittent ? 1 : 0, p.intermittentType || null, p.rating, p.tags]
    );
    console.log(`  ✓ ${p.name}`);
  }

  console.log(`\nDone! ${providers.length} providers seeded.`);
  await connection.end();
}

seed().catch(err => {
  console.error('Seed failed:', err);
  process.exit(1);
});
