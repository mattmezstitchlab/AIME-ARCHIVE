import { useState, useRef, useEffect } from "react";
import type React from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Heart, Users, Store, Clock, Wallet, FileText, Brain,
  Send, Camera, Music, Flower2, UtensilsCrossed, Sparkles,
  Briefcase, CreditCard, MapPin, Calendar, PartyPopper,
  CheckCircle2, XCircle, HelpCircle, Moon, Sun, Download
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

// ─── Role-specific picto configurations ─────────────────────────────────────
const MARRIED_PICTOS = [
  { id: "chat", icon: Heart, label: "AIME" },
  { id: "timeline", icon: Clock, label: "Timeline" },
  { id: "budget", icon: Wallet, label: "Budget" },
  { id: "guests", icon: Users, label: "Invités" },
  { id: "providers", icon: Store, label: "Prestataires" },
  { id: "documents", icon: FileText, label: "Documents" },
  { id: "memory", icon: Brain, label: "Mémoire" },
];

const GUEST_PICTOS = [
  { id: "info", icon: MapPin, label: "Infos" },
  { id: "rsvp", icon: PartyPopper, label: "RSVP" },
  { id: "program", icon: Clock, label: "Programme" },
];

const PROVIDER_PICTOS = [
  { id: "missions", icon: Briefcase, label: "Missions" },
  { id: "documents", icon: FileText, label: "Documents" },
  { id: "payments", icon: CreditCard, label: "Paiements" },
];

// ─── Main Cockpit Component ─────────────────────────────────────────────────
interface CockpitProps {
  role: "married" | "guest" | "provider";
  initialMessage?: string;
  initialFocus?: string;
}

export default function Cockpit({ role, initialMessage, initialFocus }: CockpitProps) {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [activePanel, setActivePanel] = useState<string>(initialFocus || (role === "married" ? "chat" : role === "guest" ? "info" : "missions"));
  const [input, setInput] = useState(initialMessage || "");
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Chat data
  const { data: history } = trpc.chat.history.useQuery(undefined, { enabled: role === "married" });
  const utils = trpc.useUtils();
  const sendMutation = trpc.chat.send.useMutation({
    onSuccess: () => {
      utils.chat.history.invalidate();
      utils.spaces.list.invalidate();
      utils.wedding.get.invalidate();
    },
  });

  // Married data
  const { data: timeline } = trpc.timeline.list.useQuery(undefined, { enabled: role === "married" });
  const { data: budget } = trpc.budget.list.useQuery(undefined, { enabled: role === "married" });
  const { data: guests } = trpc.guests.list.useQuery(undefined, { enabled: role === "married" });
  const { data: wedding } = trpc.wedding.get.useQuery(undefined, { enabled: role === "married" || role === "guest" });
  const { data: documents } = trpc.documents.list.useQuery(undefined, { enabled: role === "married" });
  const { data: memories } = trpc.memory.list.useQuery(undefined, { enabled: role === "married" });
  const { data: myProviders } = trpc.providers.myProviders.useQuery(undefined, { enabled: role === "married" });

  // Guest data
  const { data: guestWedding } = trpc.guestPortal.myWedding.useQuery(undefined, { enabled: role === "guest" });
  const { data: guestRecord } = trpc.guestPortal.myRecord.useQuery(undefined, { enabled: role === "guest" });
  const { data: guestTimeline } = trpc.guestPortal.timeline.useQuery(undefined, { enabled: role === "guest" });

  // Provider data
  const { data: providerProfile } = trpc.providerPortal.myProfile.useQuery(undefined, { enabled: role === "provider" });
  const { data: providerMissions } = trpc.providerPortal.myMissions.useQuery(undefined, { enabled: role === "provider" });
  const { data: providerDocs } = trpc.providerPortal.myDocuments.useQuery(undefined, { enabled: role === "provider" });

  // Guest RSVP mutation
  const rsvpMutation = trpc.guestPortal.rsvp.useMutation({
    onSuccess: () => toast.success("Réponse enregistrée !"),
  });

  const pictos = role === "married" ? MARRIED_PICTOS : role === "guest" ? GUEST_PICTOS : PROVIDER_PICTOS;

  // Notification badges
  const getBadgeCount = (pictoId: string): number => {
    if (role === "married") {
      if (pictoId === "guests") {
        return guests?.filter(g => g.rsvpStatus === "pending").length || 0;
      }
      if (pictoId === "documents") {
        // Documents uploaded in last 24h as "new"
        const recent = documents?.filter(d => {
          const diff = Date.now() - new Date(d.createdAt).getTime();
          return diff < 86400000;
        });
        return recent?.length || 0;
      }
      if (pictoId === "providers") {
        // Providers still in "shortlisted" status (not yet confirmed)
        const pending = myProviders?.filter((p: any) => p.status === "shortlisted" || p.status === "contacted");
        return pending?.length || 0;
      }
      if (pictoId === "chat" && history && history.length > 0) {
        const last = history[history.length - 1];
        if (last?.role === "assistant" && last?.createdAt) {
          const diff = Date.now() - new Date(last.createdAt).getTime();
          if (diff < 60000) return 1;
        }
      }
    }
    if (role === "guest" && pictoId === "rsvp" && guestRecord?.rsvpStatus === "pending") return 1;
    if (role === "provider" && pictoId === "missions") {
      const pending = providerMissions?.filter((m: any) => m.status !== "confirmed");
      return pending?.length || 0;
    }
    return 0;
  };

  const handleSend = () => {
    const msg = input.trim();
    if (!msg || sendMutation.isPending) return;
    setInput("");
    setActivePanel("chat");
    sendMutation.mutate({ message: msg });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, sendMutation.isPending]);

  useEffect(() => {
    if (initialFocus) setActivePanel(initialFocus);
  }, [initialFocus]);

  return (
    <div className="w-full max-w-3xl mx-auto px-4">
      {/* ─── Glassmorphism Cockpit Block ─── */}
      <div className="bg-white/8 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-2xl overflow-hidden">
        
        {/* Chat Input Bar */}
        <div className="px-5 pt-5 pb-3">
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-2xl px-4 py-3 border border-white/10">
            <Heart size={18} className="text-white/50 shrink-0 animate-pulse" fill="currentColor" />
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                role === "married" ? "Parlez à AIME de votre mariage..." :
                role === "guest" ? "Une question sur l'événement ?" :
                "Une question sur votre mission ?"
              }
              className="flex-1 bg-transparent text-white placeholder:text-white/35 text-sm outline-none"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || sendMutation.isPending}
              className="w-8 h-8 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors disabled:opacity-30 shrink-0"
            >
              <Send size={14} />
            </button>
          </div>
        </div>

        {/* Picto Buttons */}
        <div className="flex items-center justify-center gap-1 px-5 pb-3">
          {pictos.map((p) => {
            const badgeCount = getBadgeCount(p.id);
            return (
              <button
                key={p.id}
                onClick={() => setActivePanel(p.id)}
                className={`group relative flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all ${
                  activePanel === p.id
                    ? "bg-white/15 text-white"
                    : "text-white/40 hover:text-white/80 hover:bg-white/5"
                }`}
              >
                <p.icon size={18} />
                <span className="text-[9px] font-medium">{p.label}</span>
                {badgeCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-rose-500 text-white text-[8px] font-bold flex items-center justify-center shadow-lg">
                    {badgeCount > 9 ? "9+" : badgeCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Contextual Content Panel */}
        <div className="border-t border-white/10 max-h-[50vh] overflow-y-auto" ref={scrollRef}>
          <div className="p-5 panel-enter" key={activePanel}>
            {/* ─── MARRIED PANELS ─── */}
            {role === "married" && activePanel === "chat" && (
              <ChatPanel history={history} isPending={sendMutation.isPending} />
            )}
            {role === "married" && activePanel === "timeline" && (
              <TimelinePanel items={timeline} />
            )}
            {role === "married" && activePanel === "budget" && (
              <BudgetPanel items={budget} wedding={wedding} />
            )}
            {role === "married" && activePanel === "guests" && (
              <GuestsPanel items={guests} />
            )}
            {role === "married" && activePanel === "providers" && (
              <ProvidersPanel />
            )}
            {role === "married" && activePanel === "documents" && (
              <DocumentsPanel items={documents} />
            )}
            {role === "married" && activePanel === "memory" && (
              <MemoryPanel items={memories} />
            )}

            {/* ─── GUEST PANELS ─── */}
            {role === "guest" && activePanel === "info" && (
              <GuestInfoPanel wedding={guestWedding} />
            )}
            {role === "guest" && activePanel === "rsvp" && (
              <GuestRsvpPanel record={guestRecord} onRsvp={(status) => rsvpMutation.mutate({ rsvpStatus: status as "confirmed" | "pending" | "declined" | "maybe" })} isPending={rsvpMutation.isPending} />
            )}
            {role === "guest" && activePanel === "program" && (
              <TimelinePanel items={guestTimeline} />
            )}

            {/* ─── PROVIDER PANELS ─── */}
            {role === "provider" && activePanel === "missions" && (
              <ProviderMissionsPanel missions={providerMissions} />
            )}
            {role === "provider" && activePanel === "documents" && (
              <DocumentsPanel items={providerDocs} />
            )}
            {role === "provider" && activePanel === "payments" && (
              <ProviderPaymentsPanel missions={providerMissions} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Sub-panels ─────────────────────────────────────────────────────────────

function ChatPanel({ history, isPending }: { history: any[] | undefined; isPending: boolean }) {
  if (!history || history.length === 0) {
    return (
      <div className="text-center py-6">
        <Sparkles size={28} className="text-white/40 mx-auto mb-3" />
        <p className="text-white/60 text-sm">Commencez à parler à AIME pour organiser votre mariage.</p>
      </div>
    );
  }
  return (
    <div className="space-y-3 max-h-[35vh] overflow-y-auto">
      {history.slice(-10).map((msg) => (
        <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
          <div className={`max-w-[80%] px-3 py-2 rounded-xl text-xs leading-relaxed ${
            msg.role === "user"
              ? "bg-white/20 text-white"
              : "bg-white/5 text-white/80 border border-white/10"
          }`}>
            {msg.content}
          </div>
        </div>
      ))}
      {isPending && (
        <div className="flex justify-start">
          <div className="bg-white/5 border border-white/10 px-3 py-2 rounded-xl">
            <div className="flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-pulse" />
              <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-pulse [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-pulse [animation-delay:0.4s]" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TimelinePanel({ items }: { items: any[] | undefined }) {
  if (!items || items.length === 0) {
    return <EmptyState text="Aucun événement dans la timeline." />;
  }

  const handleExportPDF = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      toast.error("Impossible d'ouvrir la fenêtre d'impression.");
      return;
    }
    const rows = items.map((item) => {
      const date = item.dueDate ? new Date(item.dueDate).toLocaleDateString("fr-FR") : "—";
      const status = item.done ? "✓" : "○";
      return `<tr>
        <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:center;font-size:16px;">${status}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:500;">${item.title}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #eee;color:#666;">${date}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #eee;color:#888;font-size:12px;">${item.description || ""}</td>
      </tr>`;
    }).join("");

    printWindow.document.write(`<!DOCTYPE html><html><head><title>Timeline Mariage - AIME</title>
      <style>
        body { font-family: 'Inter', -apple-system, sans-serif; padding: 40px; color: #1a1a2e; }
        h1 { font-family: 'Playfair Display', serif; font-size: 24px; margin-bottom: 4px; }
        .subtitle { color: #666; font-size: 13px; margin-bottom: 24px; }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 10px 12px; background: #f8f6f4; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #666; }
        .footer { margin-top: 32px; text-align: center; color: #aaa; font-size: 11px; }
        @media print { body { padding: 20px; } }
      </style>
    </head><body>
      <h1>❤ Timeline de Mariage</h1>
      <p class="subtitle">Généré par AIME Wedding OS — ${new Date().toLocaleDateString("fr-FR")}</p>
      <table>
        <thead><tr><th style="width:40px;"></th><th>Événement</th><th style="width:100px;">Date</th><th>Détails</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <p class="footer">AIME Wedding OS — Votre intelligence de mariage</p>
    </body></html>`);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.print();
    }, 300);
  };

  return (
    <div className="space-y-2">
      {/* Export button */}
      <div className="flex justify-end mb-1">
        <button
          onClick={handleExportPDF}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white/60 hover:text-white/90 text-[10px] font-medium transition-colors border border-white/10"
        >
          <Download size={12} />
          Exporter PDF
        </button>
      </div>
      {items.map((item) => (
        <div key={item.id} className="flex items-start gap-3 py-2 border-b border-white/5 last:border-0">
          <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${item.done ? "bg-emerald-400" : "bg-white/30"}`} />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-white/90 font-medium">{item.title}</p>
            {item.dueDate && (
              <p className="text-[10px] text-white/40 mt-0.5">
                {new Date(item.dueDate).toLocaleDateString("fr-FR")}
              </p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function BudgetPanel({ items, wedding }: { items: any[] | undefined; wedding: any }) {
  const total = items?.reduce((sum, i) => sum + (i.amount || 0), 0) || 0;
  const estimated = wedding?.estimatedBudget || 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/50">Dépensé</span>
        <span className="text-sm text-white font-semibold">{(total / 100).toLocaleString("fr-FR")}€</span>
      </div>
      {estimated > 0 && (
        <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-emerald-300"
            style={{ width: `${Math.min((total / estimated) * 100, 100)}%` }}
          />
        </div>
      )}
      {items && items.length > 0 && (
        <div className="space-y-1.5 mt-3">
          {items.slice(0, 8).map((item) => (
            <div key={item.id} className="flex items-center justify-between text-xs">
              <span className="text-white/70 truncate flex-1">{item.label}</span>
              <span className="text-white/90 font-medium ml-2">{(item.amount / 100).toLocaleString("fr-FR")}€</span>
            </div>
          ))}
        </div>
      )}
      {(!items || items.length === 0) && <EmptyState text="Aucune dépense enregistrée." />}
    </div>
  );
}

function GuestsPanel({ items }: { items: any[] | undefined }) {
  if (!items || items.length === 0) {
    return <EmptyState text="Aucun invité ajouté." />;
  }
  const confirmed = items.filter(g => g.rsvpStatus === "confirmed").length;
  return (
    <div className="space-y-3">
      <div className="flex gap-4 text-xs">
        <span className="text-white/50">Total: <strong className="text-white">{items.length}</strong></span>
        <span className="text-white/50">Confirmés: <strong className="text-emerald-400">{confirmed}</strong></span>
        <span className="text-white/50">En attente: <strong className="text-amber-400">{items.length - confirmed}</strong></span>
      </div>
      <div className="space-y-1.5">
        {items.slice(0, 10).map((g) => (
          <div key={g.id} className="flex items-center justify-between text-xs py-1">
            <span className="text-white/80">{g.name}</span>
            <Badge variant="secondary" className="text-[9px] bg-white/10 text-white/60 border-0">
              {g.rsvpStatus}
            </Badge>
          </div>
        ))}
        {items.length > 10 && <p className="text-[10px] text-white/30 text-center">+{items.length - 10} autres</p>}
      </div>
    </div>
  );
}

const CATEGORY_FILTERS = [
  { value: "all", label: "Tous" },
  { value: "photographe", label: "Photographe" },
  { value: "traiteur", label: "Traiteur" },
  { value: "fleuriste", label: "Fleuriste" },
  { value: "musicien", label: "Musicien" },
  { value: "decorateur", label: "Décoration" },
  { value: "lieu", label: "Lieu" },
  { value: "videaste", label: "Vidéaste" },
  { value: "dj", label: "DJ" },
  { value: "patissier", label: "Pâtissier" },
  { value: "autre", label: "Autre" },
];

function ProvidersPanel() {
  const { data: allProviders } = trpc.providers.list.useQuery();
  const { data: myProviders } = trpc.providers.myProviders.useQuery();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const utils = trpc.useUtils();
  const addMutation = trpc.providers.add.useMutation({
    onSuccess: () => {
      toast.success("Prestataire ajouté à votre timeline !");
      utils.providers.myProviders.invalidate();
      utils.timeline.list.invalidate();
    },
  });

  const myProviderIds = new Set(myProviders?.map((p: any) => p.providerId) || []);
  const allList = allProviders || [];
  const providers = selectedCategory === "all"
    ? allList
    : allList.filter((p) => p.category === selectedCategory);

  if (allList.length === 0) {
    return <EmptyState text="Aucun prestataire disponible." />;
  }

  return (
    <div className="space-y-3">
      {/* Category filter tabs */}
      <div className="overflow-x-auto scrollbar-hide -mx-2 px-2 pb-1">
        <div className="flex gap-1.5" style={{ width: "max-content" }}>
          {CATEGORY_FILTERS.map((cat) => {
            const count = cat.value === "all" ? allList.length : allList.filter(p => p.category === cat.value).length;
            if (count === 0 && cat.value !== "all") return null;
            return (
              <button
                key={cat.value}
                onClick={() => setSelectedCategory(cat.value)}
                className={`px-3 py-1.5 rounded-full text-[10px] font-medium transition-all whitespace-nowrap ${
                  selectedCategory === cat.value
                    ? "bg-white/20 text-white border border-white/30 shadow-sm"
                    : "bg-white/5 text-white/50 border border-white/10 hover:bg-white/10 hover:text-white/70"
                }`}
              >
                {cat.label}
                <span className="ml-1 text-[8px] opacity-60">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Slow auto-scroll carousel */}
      {providers.length === 0 ? (
        <EmptyState text="Aucun prestataire dans cette catégorie." />
      ) : (
        <div className="overflow-x-auto pb-2 -mx-2 px-2 scrollbar-hide">
          <div className="flex gap-3 animate-[scroll_60s_linear_infinite] hover:[animation-play-state:paused]" style={{ width: "max-content" }}>
            {[...providers, ...providers].map((p, idx) => (
              <div
                key={`${p.id}-${idx}`}
                className="relative w-44 h-56 rounded-2xl overflow-hidden shrink-0 group cursor-pointer"
                onClick={() => {
                  if (!myProviderIds.has(p.id)) {
                    addMutation.mutate({ providerId: p.id, mission: p.category });
                  }
                }}
              >
                {/* Full-bleed image */}
                <img
                  src={p.imageUrl || "/manus-storage/WZgT8UUsE24e_6b47042a.jpg"}
                  alt={p.name}
                  className="absolute inset-0 w-full h-full object-cover"
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                {/* Check badge if selected */}
                {myProviderIds.has(p.id) && (
                  <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center shadow-lg">
                    <CheckCircle2 size={14} className="text-white" />
                  </div>
                )}
                {/* Text overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <p className="text-white text-xs font-semibold leading-tight">{p.name}</p>
                  <p className="text-white/70 text-[10px] mt-0.5">{p.city} — {p.priceRange}€</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Badge variant="secondary" className="text-[8px] bg-white/20 text-white/90 border-0 px-1.5 py-0">
                      {p.category}
                    </Badge>
                    {p.rating && (
                      <span className="text-[9px] text-amber-300">{'★'.repeat(p.rating)}</span>
                    )}
                  </div>
                </div>
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Selected count */}
      {myProviders && myProviders.length > 0 && (
        <p className="text-[10px] text-white/40 text-center">
          {myProviders.length} prestataire{myProviders.length > 1 ? "s" : ""} sélectionné{myProviders.length > 1 ? "s" : ""}
        </p>
      )}

    </div>
  );
}



function DocumentsPanel({ items }: { items: any[] | undefined }) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadMutation = trpc.documents.upload.useMutation({
    onSuccess: () => {
      toast.success("Document ajouté !");
      utils.documents.list.invalidate();
    },
    onError: () => toast.error("Erreur lors de l'upload"),
  });
  const utils = trpc.useUtils();

  const handleFiles = async (files: FileList) => {
    for (const file of Array.from(files)) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(",")[1];
        uploadMutation.mutate({
          title: file.name,
          type: "autre",
          backgroundTheme: "minimal",
          fileBase64: base64,
          fileName: file.name,
          mimeType: file.type,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files.length > 0) handleFiles(e.dataTransfer.files);
  };

  return (
    <div className="space-y-3">
      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
          isDragging ? "border-white/50 bg-white/10" : "border-white/15 hover:border-white/30 hover:bg-white/5"
        }`}
      >
        <FileText size={18} className="text-white/30 mx-auto mb-1" />
        <p className="text-[10px] text-white/40">
          {uploadMutation.isPending ? "Upload en cours..." : "Glissez un fichier ou cliquez"}
        </p>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          multiple
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
      </div>

      {/* File list */}
      {items && items.length > 0 && (
        <div className="space-y-1.5">
          {items.map((doc) => (
            <div key={doc.id} className="flex items-center gap-3 py-1.5 border-b border-white/5 last:border-0">
              <FileText size={14} className="text-white/40 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-white/90 font-medium truncate">{doc.name}</p>
                <p className="text-[10px] text-white/40">{doc.type} — {new Date(doc.createdAt).toLocaleDateString("fr-FR")}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      {(!items || items.length === 0) && !isDragging && (
        <p className="text-[10px] text-white/30 text-center">Aucun document pour le moment</p>
      )}
    </div>
  );
}

function MemoryPanel({ items }: { items: any[] | undefined }) {
  if (!items || items.length === 0) {
    return <EmptyState text="Aucune capsule mémoire." />;
  }
  return (
    <div className="space-y-2">
      {items.map((m) => (
        <div key={m.id} className="bg-white/5 border border-white/10 rounded-xl p-3">
          <p className="text-xs text-white/90 font-medium">{m.title}</p>
          <p className="text-[10px] text-white/50 mt-1 line-clamp-2">{m.content}</p>
        </div>
      ))}
    </div>
  );
}

// ─── Guest-specific panels ──────────────────────────────────────────────────

function GuestInfoPanel({ wedding }: { wedding: any }) {
  if (!wedding) return <EmptyState text="Informations non disponibles." />;
  return (
    <div className="space-y-3">
      <InfoRow icon={MapPin} label="Lieu" value={wedding.venue || "Non communiqué"} />
      <InfoRow icon={Calendar} label="Date" value={wedding.weddingDate ? new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "Non communiquée"} />
      <InfoRow icon={Users} label="Invités" value={wedding.guestCount ? `${wedding.guestCount} personnes` : "—"} />
      {wedding.city && <InfoRow icon={MapPin} label="Ville" value={wedding.city} />}
    </div>
  );
}

function GuestRsvpPanel({ record, onRsvp, isPending }: { record: any; onRsvp: (s: "confirmed" | "pending" | "declined" | "maybe") => void; isPending: boolean }) {
  if (!record) return <EmptyState text="Votre invitation n'a pas été trouvée." />;

  if (record.rsvpStatus && record.rsvpStatus !== "pending") {
    return (
      <div className="text-center py-4">
        <CheckCircle2 size={24} className="text-emerald-400 mx-auto mb-2" />
        <p className="text-xs text-white/80">Vous avez répondu : <strong className="text-white">{record.rsvpStatus}</strong></p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-xs text-white/60 text-center">Confirmez votre présence :</p>
      <div className="flex gap-2 justify-center">
        <button onClick={() => onRsvp("confirmed")} disabled={isPending} className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-medium hover:bg-emerald-500/30 transition-colors disabled:opacity-50">
          <CheckCircle2 size={14} /> Présent
        </button>
        <button onClick={() => onRsvp("maybe")} disabled={isPending} className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 text-xs font-medium hover:bg-amber-500/30 transition-colors disabled:opacity-50">
          <HelpCircle size={14} /> Peut-être
        </button>
        <button onClick={() => onRsvp("declined")} disabled={isPending} className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-500/20 text-red-300 text-xs font-medium hover:bg-red-500/30 transition-colors disabled:opacity-50">
          <XCircle size={14} /> Absent
        </button>
      </div>
    </div>
  );
}

// ─── Provider-specific panels ───────────────────────────────────────────────

function ProviderMissionsPanel({ missions }: { missions: any[] | undefined }) {
  if (!missions || missions.length === 0) {
    return <EmptyState text="Aucune mission assignée." />;
  }
  return (
    <div className="space-y-2">
      {missions.map((m) => (
        <div key={m.id} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
          <Briefcase size={14} className="text-white/40 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-white/90 font-medium">{m.weddingTitle || "Mission"}</p>
            <p className="text-[10px] text-white/40">{m.status}</p>
          </div>
          {m.amount && <span className="text-xs text-white/70 font-medium">{(m.amount / 100).toLocaleString("fr-FR")}€</span>}
        </div>
      ))}
    </div>
  );
}

function ProviderPaymentsPanel({ missions }: { missions: any[] | undefined }) {
  if (!missions || missions.length === 0) {
    return <EmptyState text="Aucun paiement." />;
  }
  const total = missions.reduce((sum, m) => sum + (m.amount || 0), 0);
  const paid = missions.filter(m => m.status === "paid").reduce((sum, m) => sum + (m.amount || 0), 0);

  return (
    <div className="space-y-3">
      <div className="flex justify-between text-xs">
        <span className="text-white/50">Total missions</span>
        <span className="text-white font-semibold">{(total / 100).toLocaleString("fr-FR")}€</span>
      </div>
      <div className="flex justify-between text-xs">
        <span className="text-white/50">Payé</span>
        <span className="text-emerald-400 font-semibold">{(paid / 100).toLocaleString("fr-FR")}€</span>
      </div>
      <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-emerald-300"
          style={{ width: total > 0 ? `${(paid / total) * 100}%` : "0%" }}
        />
      </div>
    </div>
  );
}

// ─── Shared utilities ───────────────────────────────────────────────────────

function EmptyState({ text }: { text: string }) {
  return (
    <div className="text-center py-6">
      <p className="text-xs text-white/40">{text}</p>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <Icon size={14} className="text-white/30 shrink-0" />
      <span className="text-[10px] text-white/40 w-16">{label}</span>
      <span className="text-xs text-white/80">{value}</span>
    </div>
  );
}
