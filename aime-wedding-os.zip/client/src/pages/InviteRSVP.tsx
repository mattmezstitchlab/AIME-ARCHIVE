import { trpc } from "@/lib/trpc";
import { useRoute } from "wouter";
import { useState } from "react";
import { Heart, MapPin, Calendar, Check, X as XIcon, HelpCircle } from "lucide-react";
import { toast } from "sonner";

const HERO_IMAGE = "/manus-storage/Twoastronautsfloatingtogetherinspace,wearingelegantweddingoutfits,connectedbysoftlight,emotional,poetic,cinematiclighting,cloudsandstars,darkbackground,luxuryeditorialstyle,4k_ce791586.jpg";

export default function InviteRSVP() {
  const [, params] = useRoute("/invite/:token");
  const token = params?.token || "";

  const { data, isLoading, error } = trpc.invite.getByToken.useQuery(
    { token },
    { enabled: !!token }
  );

  const rsvpMutation = trpc.invite.rsvp.useMutation({
    onSuccess: (res) => {
      toast.success(`Merci ${res.name} ! Votre réponse a été enregistrée.`);
    },
    onError: () => {
      toast.error("Erreur lors de l'envoi de votre réponse.");
    },
  });

  const [dietaryNeeds, setDietaryNeeds] = useState("");
  const [plusOne, setPlusOne] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submittedStatus, setSubmittedStatus] = useState<"confirmed" | "declined" | "maybe" | null>(null);

  const handleRsvp = (status: "confirmed" | "declined" | "maybe") => {
    rsvpMutation.mutate(
      { token, rsvpStatus: status, dietaryNeeds: dietaryNeeds || undefined, plusOne },
      { onSuccess: () => { setSubmitted(true); setSubmittedStatus(status); } }
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
            <XIcon size={24} className="text-destructive" />
          </div>
          <h1 className="font-display text-2xl font-semibold mb-2">Lien invalide</h1>
          <p className="text-sm text-muted-foreground">
            Ce lien d'invitation n'est pas valide ou a expiré. Contactez les mariés pour obtenir un nouveau lien.
          </p>
        </div>
      </div>
    );
  }

  const { guest, wedding } = data;

  if (submitted || (guest.rsvpStatus && guest.rsvpStatus !== "pending")) {
    const status = submittedStatus || guest.rsvpStatus;
    return (
      <div className="min-h-screen bg-background">
        <div className="relative h-48 overflow-hidden">
          <img src={HERO_IMAGE} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-black/60" />
        </div>
        <div className="max-w-md mx-auto px-6 -mt-12 relative z-10">
          <div className="neu-card p-8 text-center">
            <div className="w-16 h-16 rounded-full gradient-fuchsia flex items-center justify-center mx-auto mb-4">
              <Check size={28} className="text-white" />
            </div>
            <h1 className="font-display text-2xl font-semibold mb-2">Merci, {guest.name} !</h1>
            <p className="text-sm text-muted-foreground mb-4">
              {status === "confirmed" && "Votre présence est confirmée. Nous avons hâte de vous voir !"}
              {status === "declined" && "Nous comprenons. Vous nous manquerez ce jour-là."}
              {status === "maybe" && "Nous avons noté votre hésitation. N'hésitez pas à revenir confirmer."}
            </p>
            {wedding && (
              <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
                {wedding.city && (
                  <span className="flex items-center gap-1">
                    <MapPin size={12} /> {wedding.city}
                  </span>
                )}
                {wedding.date && (
                  <span className="flex items-center gap-1">
                    <Calendar size={12} /> {new Date(wedding.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative h-56 overflow-hidden">
        <img src={HERO_IMAGE} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-black/70" />
        <div className="absolute bottom-6 left-6 right-6 text-white">
          <p className="text-xs text-white/70 mb-1">Vous êtes invité(e) au mariage</p>
          <h1 className="font-display text-2xl font-semibold">
            {wedding?.partnerName || "Un mariage unique"}
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto px-6 py-8">
        {/* Guest greeting */}
        <div className="neu-card p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full gradient-fuchsia flex items-center justify-center">
              <Heart size={18} className="text-white" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold">Bonjour, {guest.name}</h2>
              <p className="text-xs text-muted-foreground">Confirmez votre présence</p>
            </div>
          </div>

          {wedding && (
            <div className="flex flex-wrap gap-3 mb-4">
              {wedding.city && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary text-xs">
                  <MapPin size={12} className="text-primary" /> {wedding.city}
                </span>
              )}
              {wedding.venue && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary text-xs">
                  {wedding.venue}
                </span>
              )}
              {wedding.date && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary text-xs">
                  <Calendar size={12} className="text-primary" />
                  {new Date(wedding.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Options */}
        <div className="space-y-4 mb-6">
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">Régime alimentaire ou allergies</label>
            <input
              type="text"
              value={dietaryNeeds}
              onChange={(e) => setDietaryNeeds(e.target.value)}
              placeholder="Végétarien, sans gluten, allergies..."
              className="w-full px-4 py-2.5 rounded-xl bg-secondary/50 border border-border/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          <label className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30 cursor-pointer">
            <input
              type="checkbox"
              checked={plusOne}
              onChange={(e) => setPlusOne(e.target.checked)}
              className="w-4 h-4 rounded accent-primary"
            />
            <span className="text-sm">Je viendrai accompagné(e) (+1)</span>
          </label>
        </div>

        {/* RSVP Buttons */}
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handleRsvp("confirmed")}
            disabled={rsvpMutation.isPending}
            className="flex flex-col items-center gap-2 p-4 rounded-xl gradient-fuchsia text-white shadow-lg hover:scale-105 transition-transform disabled:opacity-50"
          >
            <Check size={22} />
            <span className="text-xs font-medium">Je serai là</span>
          </button>
          <button
            onClick={() => handleRsvp("maybe")}
            disabled={rsvpMutation.isPending}
            className="flex flex-col items-center gap-2 p-4 rounded-xl bg-secondary border border-border/50 text-foreground hover:scale-105 transition-transform disabled:opacity-50"
          >
            <HelpCircle size={22} />
            <span className="text-xs font-medium">Peut-être</span>
          </button>
          <button
            onClick={() => handleRsvp("declined")}
            disabled={rsvpMutation.isPending}
            className="flex flex-col items-center gap-2 p-4 rounded-xl bg-secondary border border-border/50 text-foreground hover:scale-105 transition-transform disabled:opacity-50"
          >
            <XIcon size={22} />
            <span className="text-xs font-medium">Absent(e)</span>
          </button>
        </div>

        {rsvpMutation.isPending && (
          <div className="flex items-center justify-center gap-2 mt-4">
            <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <span className="text-xs text-muted-foreground">Envoi en cours...</span>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="text-center py-6 border-t border-border/30">
        <div className="flex items-center justify-center gap-2">
          <div className="w-6 h-6 rounded-full gradient-fuchsia flex items-center justify-center">
            <span className="text-white font-bold text-[9px] font-display">A</span>
          </div>
          <span className="text-xs text-muted-foreground">Propulsé par AIME</span>
        </div>
      </footer>
    </div>
  );
}
