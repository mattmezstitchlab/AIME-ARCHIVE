import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import Cockpit from "@/components/Cockpit";
import { trpc } from "@/lib/trpc";
import { useTheme } from "@/contexts/ThemeContext";
import { Moon, Sun, LogOut, Heart } from "lucide-react";
import { Link, useSearch } from "wouter";
import { useState, useEffect } from "react";

const BG_IMAGES = [
  "/manus-storage/Acinematicastronautfloatingindeepspacewearingaflowingweddingdress,surroundedbysoftcloudsandstars,poetic,emotional,dreamyatmosphere,elegantlighting,darkbackground,luxuryeditorialstyle,highdetail,4k_0f048e14.jpg",
  "/manus-storage/Twoastronautsfloatingtogetherinspace,wearingelegantweddingoutfits,connectedbysoftlight,emotional,poetic,cinematiclighting,cloudsandstars,darkbackground,luxuryeditorialstyle,4k_ce791586.jpg",
  "/manus-storage/Anatural,elegantweddingmomentwithguestsarrivingorgatheringinawarmoutdoorsetting.Softgoldenlight,candidmovement,peopleslightlyblurredtocapturelifeandpresence.Emotional,human,authenticatmosphere.Premiumeditori_39d25237.jpg",
  "/manus-storage/group-luminous-wedding_f49109f3.jpg",
  "/manus-storage/abrideastronautfloatinginspace,wearinganelegantfuturisticweddingdress,softcosmicclouds,glowingstars,romanticatmosphere,cinematiclighting,ultrarealistic,luxuryaesthetic,darkbackground,emotionalandpoetic(1)_17bf7be5.jpg",
  "/manus-storage/Apoeticrepresentationofglobalweddingdiversity.Multipleculturessuggestedthroughsubtlevisualelements,fabrics,silhouettes,orenvironments.Keepcompositionminimalandelegant,notoverloaded.Softlighting,neutraltones,bala_29e76af9.jpg",
  "/manus-storage/Ateamofastronautsworkingtogetherinspace,eachwithdifferentroles(musician,chef,technician),connectedbylightstructures,representingcoordinationandexpertise,futuristic,cinematiclighting,darkbackground,4k_8b016550.jpg",
];

export default function Dashboard() {
  const { user, loading, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const initialMessage = params.get("msg") || undefined;
  const initialFocus = params.get("focus") || undefined;

  // Background slideshow state
  const [currentBg, setCurrentBg] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % BG_IMAGES.length);
    }, 8000); // Change every 8 seconds
    return () => clearInterval(interval);
  }, []);

  const { data: guestRecord } = trpc.guestPortal.myRecord.useQuery(undefined, {
    enabled: !!user,
    retry: false,
  });
  const { data: providerProfile } = trpc.providerPortal.myProfile.useQuery(undefined, {
    enabled: !!user,
    retry: false,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Heart size={32} className="text-white/40 animate-pulse" fill="currentColor" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  // Determine role based on user data
  const role: "married" | "guest" | "provider" =
    providerProfile ? "provider" :
    guestRecord ? "guest" :
    "married";

  // Map focus param to cockpit panel id
  const focusMap: Record<string, string> = {
    timeline: "timeline",
    traiteur: "providers",
    photographe: "providers",
    fleuriste: "providers",
    musicien: "providers",
    budget: "budget",
    documents: "documents",
    guests: "guests",
    memory: "memory",
  };
  const mappedFocus = initialFocus ? (focusMap[initialFocus] || initialFocus) : undefined;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated multi-image background with slow crossfade */}
      <div className="absolute inset-0">
        {BG_IMAGES.map((src, idx) => (
          <img
            key={idx}
            src={src}
            alt=""
            className="absolute inset-0 w-full h-full object-cover transition-opacity duration-[3000ms] ease-in-out"
            style={{ opacity: idx === currentBg ? 1 : 0 }}
          />
        ))}
        {/* Lighter overlay - reduced from 60% to 40% */}
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/30" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <Heart size={18} className="text-white animate-pulse" fill="currentColor" />
          <span className="text-white font-display text-lg font-semibold tracking-wide">AIME</span>
        </Link>
        <div className="flex items-center gap-3">
          <span className="text-white/50 text-xs hidden sm:block">{user.name}</span>
          <button
            onClick={toggleTheme}
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/20 transition-colors"
          >
            {theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
          </button>
          <button
            onClick={() => logout()}
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/20 transition-colors"
          >
            <LogOut size={14} />
          </button>
        </div>
      </header>

      {/* Cockpit centered */}
      <main className="relative z-10 flex items-center justify-center min-h-[calc(100vh-80px)] px-4 pb-8">
        <Cockpit role={role} initialMessage={initialMessage} initialFocus={mappedFocus} />
      </main>
    </div>
  );
}
