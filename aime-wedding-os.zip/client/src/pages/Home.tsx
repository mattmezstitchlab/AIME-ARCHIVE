import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  Heart, Users, Store, Clock, Wallet, FileText, Brain,
  Moon, Sun, ArrowRight, Send, Camera, Music, Flower2, UtensilsCrossed
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

const HERO_IMAGE = "/manus-storage/Acinematicastronautfloatingindeepspacewearingaflowingweddingdress,surroundedbysoftcloudsandstars,poetic,emotional,dreamyatmosphere,elegantlighting,darkbackground,luxuryeditorialstyle,highdetail,4k_0f048e14.jpg";
const COUPLE_IMAGE = "/manus-storage/Twoastronautsfloatingtogetherinspace,wearingelegantweddingoutfits,connectedbysoftlight,emotional,poetic,cinematiclighting,cloudsandstars,darkbackground,luxuryeditorialstyle,4k_ce791586.jpg";
const GUESTS_IMAGE = "/manus-storage/Anatural,elegantweddingmomentwithguestsarrivingorgatheringinawarmoutdoorsetting.Softgoldenlight,candidmovement,peopleslightlyblurredtocapturelifeandpresence.Emotional,human,authenticatmosphere.Premiumeditori_d1be2c4a.jpg";
const DIVERSITY_IMAGE = "/manus-storage/Apoeticrepresentationofglobalweddingdiversity.Multipleculturessuggestedthroughsubtlevisualelements,fabrics,silhouettes,orenvironments.Keepcompositionminimalandelegant,notoverloaded.Softlighting,neutraltones,bala_e9a9b78a.jpg";

// Anchor icons for the chat input bar
const ANCHORS = [
  { icon: Clock, label: "Timeline", section: "timeline" },
  { icon: UtensilsCrossed, label: "Traiteur", section: "traiteur" },
  { icon: Camera, label: "Photographe", section: "photographe" },
  { icon: Flower2, label: "Fleuriste", section: "fleuriste" },
  { icon: Music, label: "Musicien", section: "musicien" },
  { icon: Wallet, label: "Budget", section: "budget" },
  { icon: FileText, label: "Documents", section: "documents" },
];

export default function Home() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [scrolled, setScrolled] = useState(false);
  const [message, setMessage] = useState("");
  const [, setLocation] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSend = () => {
    if (!message.trim()) return;
    if (!user) {
      window.location.href = getLoginUrl();
      return;
    }
    // Navigate to dashboard with the message as a query param to pre-fill chat
    setLocation(`/dashboard?msg=${encodeURIComponent(message)}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleAnchorClick = (section: string) => {
    if (!user) {
      window.location.href = getLoginUrl();
      return;
    }
    setLocation(`/dashboard?focus=${section}`);
  };

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* ─── Floating Header ─── */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-black/60 backdrop-blur-xl border-b border-white/10"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <Heart size={20} className="text-white animate-pulse" fill="white" />
            <span className="font-display text-lg font-semibold text-white">
              AIME
            </span>
          </Link>

          <nav className="flex items-center gap-4">
            {toggleTheme && (
              <button
                onClick={toggleTheme}
                className="w-8 h-8 rounded-full flex items-center justify-center text-white/70 hover:text-white transition-colors"
              >
                {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
              </button>
            )}
            {user ? (
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white text-sm font-medium hover:bg-white/20 transition-all"
              >
                Mon espace
                <ArrowRight size={14} />
              </Link>
            ) : (
              <a
                href={getLoginUrl()}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white text-sm font-medium hover:bg-white/20 transition-all"
              >
                Se connecter
                <ArrowRight size={14} />
              </a>
            )}
          </nav>
        </div>
      </header>

      {/* ─── Section 1: Hero Full-Screen with Chat ─── */}
      <section className="relative h-screen flex flex-col items-center justify-center">
        {/* Full-screen background */}
        <img
          src={HERO_IMAGE}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/30" />

        {/* Content */}
        <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
          <h1 className="font-display text-4xl md:text-6xl font-semibold text-white mb-4 leading-tight">
            Un mariage commence<br />
            <em className="text-white/90">par une phrase.</em>
          </h1>
          <p className="text-white/70 text-base md:text-lg mb-10 max-w-xl mx-auto">
            Dites à AIME ce que vous imaginez. Elle organise tout le reste.
          </p>

          {/* Chat Input — Perplexity style */}
          <div className="w-full max-w-2xl mx-auto">
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-1.5 shadow-2xl">
              <div className="flex items-center gap-2 px-4 py-3">
                <Heart size={18} className="text-white/60 shrink-0 animate-pulse" fill="currentColor" />
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="On rêve d'un mariage en bord de mer, intime, 60 personnes..."
                  className="flex-1 bg-transparent text-white placeholder:text-white/40 text-sm md:text-base outline-none"
                />
                <button
                  onClick={handleSend}
                  className="w-9 h-9 rounded-xl bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors shrink-0"
                >
                  <Send size={16} />
                </button>
              </div>

              {/* Anchor Icons */}
              <div className="flex items-center justify-center gap-1 px-3 pb-2 pt-1 border-t border-white/10">
                {ANCHORS.map((anchor) => (
                  <button
                    key={anchor.section}
                    onClick={() => handleAnchorClick(anchor.section)}
                    className="group flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-lg hover:bg-white/10 transition-colors"
                    title={anchor.label}
                  >
                    <anchor.icon size={16} className="text-white/50 group-hover:text-white/90 transition-colors" />
                    <span className="text-[9px] text-white/40 group-hover:text-white/70 transition-colors hidden sm:block">
                      {anchor.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-1.5">
            <div className="w-1.5 h-2.5 rounded-full bg-white/60 animate-pulse" />
          </div>
        </div>
      </section>

      {/* ─── Section 2: Couple — Full-screen immersive ─── */}
      <section className="relative h-screen flex items-center justify-center">
        <img
          src={COUPLE_IMAGE}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 text-center px-6 max-w-2xl">
          <h2 className="font-display text-3xl md:text-5xl font-semibold text-white mb-4">
            Votre histoire, votre rythme.
          </h2>
          <p className="text-white/70 text-base md:text-lg mb-8">
            AIME apprend vos envies, vos contraintes, votre style. Chaque décision est guidée par votre conversation.
          </p>
          {user ? (
            <Link
              href="/spaces/couple"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white text-sm font-medium hover:bg-white/20 transition-all"
            >
              <Heart size={16} />
              Explorer l'espace Couple
            </Link>
          ) : null}
        </div>
      </section>

      {/* ─── Section 3: Prestataires — Full-screen immersive ─── */}
      <section className="relative h-screen flex items-center justify-center">
        <img
          src={GUESTS_IMAGE}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 text-center px-6 max-w-2xl">
          <h2 className="font-display text-3xl md:text-5xl font-semibold text-white mb-4">
            Les bons prestataires, au bon moment.
          </h2>
          <p className="text-white/70 text-base md:text-lg mb-8">
            Marketplace intelligente avec gestion de l'intermittence du spectacle. AIME recommande selon vos besoins détectés.
          </p>
          {user ? (
            <Link
              href="/marketplace"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white text-sm font-medium hover:bg-white/20 transition-all"
            >
              <Store size={16} />
              Voir la marketplace
            </Link>
          ) : null}
        </div>
      </section>

      {/* ─── Section 4: Diversité — Full-screen immersive ─── */}
      <section className="relative h-screen flex items-center justify-center">
        <img
          src={DIVERSITY_IMAGE}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 text-center px-6 max-w-2xl">
          <h2 className="font-display text-3xl md:text-5xl font-semibold text-white mb-4">
            Chaque mariage est unique.
          </h2>
          <p className="text-white/70 text-base md:text-lg mb-8">
            Toutes les cultures, tous les formats, toutes les tailles. AIME s'adapte à votre vision sans imposer de modèle.
          </p>
          {!user && (
            <a
              href={getLoginUrl()}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full gradient-fuchsia text-white text-sm font-medium shadow-lg hover:scale-105 transition-transform"
            >
              Commencer avec AIME
              <ArrowRight size={14} />
            </a>
          )}
        </div>
      </section>

      {/* ─── Footer ─── */}
      <footer className="bg-black py-12 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Heart size={16} className="text-white animate-pulse" fill="white" />
          <span className="font-display text-lg text-white font-semibold">AIME</span>
        </div>
        <p className="text-white/40 text-xs">
          Intelligence de mariage — Votre agent personnel pour un jour parfait.
        </p>
      </footer>
    </div>
  );
}
