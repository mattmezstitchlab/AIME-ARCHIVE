import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

describe("appRouter", () => {
  it("should have all expected routers defined", () => {
    expect(appRouter).toBeDefined();
    expect(appRouter._def.procedures).toBeDefined();
  });

  it("should have auth procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["auth.me"]).toBeDefined();
    expect(procedures["auth.logout"]).toBeDefined();
  });

  it("should have chat procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["chat.send"]).toBeDefined();
    expect(procedures["chat.history"]).toBeDefined();
  });

  it("should have wedding procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["wedding.get"]).toBeDefined();
    expect(procedures["wedding.update"]).toBeDefined();
  });

  it("should have spaces procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["spaces.list"]).toBeDefined();
    expect(procedures["spaces.get"]).toBeDefined();
  });

  it("should have providers procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["providers.list"]).toBeDefined();
    expect(procedures["providers.get"]).toBeDefined();
    expect(procedures["providers.myProviders"]).toBeDefined();
    expect(procedures["providers.add"]).toBeDefined();
    expect(procedures["providers.updateStatus"]).toBeDefined();
  });

  it("should have documents procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["documents.list"]).toBeDefined();
    expect(procedures["documents.upload"]).toBeDefined();
  });

  it("should have memory procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["memory.list"]).toBeDefined();
    expect(procedures["memory.add"]).toBeDefined();
  });

  it("should have timeline procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["timeline.list"]).toBeDefined();
    expect(procedures["timeline.add"]).toBeDefined();
    expect(procedures["timeline.toggle"]).toBeDefined();
  });

  it("should have guests procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["guests.list"]).toBeDefined();
    expect(procedures["guests.add"]).toBeDefined();
    expect(procedures["guests.update"]).toBeDefined();
  });

  it("should have budget procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["budget.list"]).toBeDefined();
    expect(procedures["budget.add"]).toBeDefined();
    expect(procedures["budget.update"]).toBeDefined();
  });

  it("should have guestPortal procedures for guest-specific access", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["guestPortal.myWedding"]).toBeDefined();
    expect(procedures["guestPortal.myRecord"]).toBeDefined();
    expect(procedures["guestPortal.rsvp"]).toBeDefined();
    expect(procedures["guestPortal.timeline"]).toBeDefined();
  });

  it("should have providerPortal procedures for provider-specific access", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["providerPortal.myProfile"]).toBeDefined();
    expect(procedures["providerPortal.myMissions"]).toBeDefined();
    expect(procedures["providerPortal.myDocuments"]).toBeDefined();
  });

  it("should have invite procedures (public RSVP by token)", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["invite.getByToken"]).toBeDefined();
    expect(procedures["invite.rsvp"]).toBeDefined();
  });

  it("should have generateInviteLinks in guests router", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures["guests.generateInviteLinks"]).toBeDefined();
  });
});
