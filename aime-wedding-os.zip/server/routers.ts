import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import * as db from "./db";

// ─── AIME Chat Router ────────────────────────────────────────────────────────

const AIME_SYSTEM_PROMPT = `Tu es AIME, une intelligence centrale de mariage. Tu es douce, naturelle, élégante et précise.

Ton rôle :
- Comprendre ce que le couple décrit (ville, date, nombre d'invités, ambiance, besoins, prestataires)
- Répondre de manière chaleureuse et humaine, jamais robotique
- Extraire les informations clés pour alimenter les 7 espaces : Couple, Invités, Prestataires, Timeline, Budget, Documents, Mémoire
- Poser des questions pertinentes quand il manque des informations
- Ne jamais surcharger de questions — une ou deux maximum par réponse
- Utiliser un ton premium, comme une wedding planner attentionnée

Format de réponse JSON :
{
  "response": "Ta réponse naturelle au couple",
  "parsed": {
    "city": null ou "ville détectée",
    "date": null ou "date détectée (ISO)",
    "guestCount": null ou nombre,
    "ambiance": [] ou ["élégant", "festif"],
    "needs": [] ou ["traiteur", "dj", "photographe"],
    "venue": null ou "lieu détecté",
    "budget": null ou nombre estimé en euros,
    "partnerName": null ou "prénom détecté",
    "providers_mentioned": [] ou ["nom du prestataire mentionné"]
  },
  "memories": [] ou [{"title": "titre court", "content": "détail", "type": "decision|milestone|emotion|detail|quote"}],
  "suggested_question": null ou "question de suivi suggérée"
}

Important : Réponds TOUJOURS en JSON valide. La clé "response" contient ta réponse visible au couple.`;

const chatRouter = router({
  send: protectedProcedure
    .input(z.object({ message: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      // Get or create wedding for this user
      let wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) {
        const weddingId = await db.createWedding({ userId: ctx.user.id });
        wedding = { id: weddingId, userId: ctx.user.id } as any;
      }

      // Save user message
      await db.createMessage({
        weddingId: wedding!.id,
        role: "user",
        content: input.message,
      });

      // Get conversation history (last 20 messages for context)
      const history = await db.getMessagesByWedding(wedding!.id, 20);

      // Build LLM messages
      const llmMessages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
        { role: "system", content: AIME_SYSTEM_PROMPT },
      ];

      // Add conversation history
      for (const msg of history) {
        llmMessages.push({
          role: msg.role as "user" | "assistant",
          content: msg.role === "assistant" ? (tryExtractResponse(msg.content) || msg.content) : msg.content,
        });
      }

      // Call LLM
      let llmResponse: any;
      try {
        llmResponse = await invokeLLM({
          messages: llmMessages,
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "aime_response",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  response: { type: "string" },
                  parsed: {
                    type: "object",
                    properties: {
                      city: { type: ["string", "null"] },
                      date: { type: ["string", "null"] },
                      guestCount: { type: ["number", "null"] },
                      ambiance: { type: "array", items: { type: "string" } },
                      needs: { type: "array", items: { type: "string" } },
                      venue: { type: ["string", "null"] },
                      budget: { type: ["number", "null"] },
                      partnerName: { type: ["string", "null"] },
                      providers_mentioned: { type: "array", items: { type: "string" } },
                    },
                    required: ["city", "date", "guestCount", "ambiance", "needs", "venue", "budget", "partnerName", "providers_mentioned"],
                    additionalProperties: false,
                  },
                  memories: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        content: { type: "string" },
                        type: { type: "string" },
                      },
                      required: ["title", "content", "type"],
                      additionalProperties: false,
                    },
                  },
                  suggested_question: { type: ["string", "null"] },
                },
                required: ["response", "parsed", "memories", "suggested_question"],
                additionalProperties: false,
              },
            },
          },
        });
      } catch (e) {
        // Fallback if LLM fails
        const fallbackResponse = JSON.stringify({
          response: "Je suis là pour vous aider à organiser votre mariage. Pouvez-vous me donner plus de détails ?",
          parsed: { city: null, date: null, guestCount: null, ambiance: [], needs: [], venue: null, budget: null, partnerName: null, providers_mentioned: [] },
          memories: [],
          suggested_question: null,
        });
        await db.createMessage({ weddingId: wedding!.id, role: "assistant", content: fallbackResponse });
        return { response: "Je suis là pour vous aider à organiser votre mariage. Pouvez-vous me donner plus de détails ?", parsed: null };
      }

      const content = llmResponse.choices?.[0]?.message?.content || "";
      let parsed: any = null;

      try {
        parsed = JSON.parse(content);
      } catch {
        parsed = { response: content, parsed: null, memories: [], suggested_question: null };
      }

      // Save assistant message with full JSON
      await db.createMessage({
        weddingId: wedding!.id,
        role: "assistant",
        content: JSON.stringify(parsed),
        parsedData: parsed.parsed ? JSON.stringify(parsed.parsed) : null,
      });

      // Update wedding data from parsed info
      if (parsed.parsed) {
        const updates: any = {};
        if (parsed.parsed.city) updates.city = parsed.parsed.city;
        if (parsed.parsed.date) updates.weddingDate = new Date(parsed.parsed.date);
        if (parsed.parsed.guestCount) updates.guestCount = parsed.parsed.guestCount;
        if (parsed.parsed.ambiance?.length) updates.ambiance = JSON.stringify(parsed.parsed.ambiance);
        if (parsed.parsed.needs?.length) updates.needs = JSON.stringify(parsed.parsed.needs);
        if (parsed.parsed.venue) updates.venue = parsed.parsed.venue;
        if (parsed.parsed.budget) updates.estimatedBudget = parsed.parsed.budget * 100;
        if (parsed.parsed.partnerName) updates.partnerName = parsed.parsed.partnerName;

        if (Object.keys(updates).length > 0) {
          await db.updateWedding(wedding!.id, updates);
        }

        // Update spaces based on parsed data
        await updateSpacesFromParsed(wedding!.id, parsed.parsed);
      }

      // Save memories
      if (parsed.memories?.length) {
        for (const mem of parsed.memories) {
          await db.createMemory({
            weddingId: wedding!.id,
            type: mem.type as any || "detail",
            title: mem.title,
            content: mem.content,
            source: "chat",
          });
        }
      }

      return {
        response: parsed.response || content,
        parsed: parsed.parsed,
        suggestedQuestion: parsed.suggested_question,
      };
    }),

  history: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    const msgs = await db.getMessagesByWedding(wedding.id, 100);
    return msgs.map(m => ({
      id: m.id,
      role: m.role,
      content: m.role === "assistant" ? (tryExtractResponse(m.content) || m.content) : m.content,
      createdAt: m.createdAt,
    }));
  }),
});

// ─── Spaces Router ───────────────────────────────────────────────────────────

const spacesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getSpacesByWedding(wedding.id);
  }),

  get: protectedProcedure
    .input(z.object({ type: z.string() }))
    .query(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) return null;
      const allSpaces = await db.getSpacesByWedding(wedding.id);
      return allSpaces.find(s => s.type === input.type) || null;
    }),
});

// ─── Wedding Router ──────────────────────────────────────────────────────────

const weddingRouter = router({
  get: protectedProcedure.query(async ({ ctx }) => {
    return db.getWeddingByUserId(ctx.user.id);
  }),

  update: protectedProcedure
    .input(z.object({
      city: z.string().optional(),
      venue: z.string().optional(),
      weddingDate: z.string().optional(),
      guestCount: z.number().optional(),
      estimatedBudget: z.number().optional(),
      partnerName: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const updates: any = { ...input };
      if (input.weddingDate) updates.weddingDate = new Date(input.weddingDate);
      if (input.estimatedBudget) updates.estimatedBudget = input.estimatedBudget * 100;
      await db.updateWedding(wedding.id, updates);
      return { success: true };
    }),
});

// ─── Providers Router ────────────────────────────────────────────────────────

const providersRouter = router({
  list: protectedProcedure
    .input(z.object({ category: z.string().optional() }).optional())
    .query(async ({ input }) => {
      if (input?.category) {
        return db.getProvidersByCategory(input.category);
      }
      return db.getAllProviders();
    }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return db.getProviderById(input.id);
    }),

  myProviders: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getWeddingProviders(wedding.id);
  }),

  add: protectedProcedure
    .input(z.object({
      providerId: z.number(),
      mission: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const id = await db.addWeddingProvider({
        weddingId: wedding.id,
        providerId: input.providerId,
        mission: input.mission,
      });
      // Also create a timeline event for this provider selection
      const provider = await db.getProviderById(input.providerId);
      if (provider) {
        await db.createTimelineEvent({
          weddingId: wedding.id,
          title: `Prestataire sélectionné : ${provider.name}`,
          description: `${provider.category} — ${provider.city || ""} ${provider.priceRange ? provider.priceRange + "€" : ""}`,
          category: "preparation",
        });
      }
      return { id };
    }),

  updateStatus: protectedProcedure
    .input(z.object({
      id: z.number(),
      status: z.enum(["shortlisted", "contacted", "confirmed", "rejected"]),
    }))
    .mutation(async ({ input }) => {
      await db.updateWeddingProvider(input.id, { status: input.status });
      return { success: true };
    }),
});

// ─── Documents Router ────────────────────────────────────────────────────────

const documentsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getDocumentsByWedding(wedding.id);
  }),

  upload: protectedProcedure
    .input(z.object({
      title: z.string(),
      type: z.enum(["devis", "contrat", "brief", "facture", "planning", "autre"]),
      fileBase64: z.string(),
      fileName: z.string(),
      mimeType: z.string(),
      providerId: z.number().optional(),
      backgroundTheme: z.enum(["floral", "geometric", "watercolor", "cosmic", "minimal", "warm"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");

      // Upload to S3
      const buffer = Buffer.from(input.fileBase64, "base64");
      const fileKey = `wedding-${wedding.id}/docs/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(fileKey, buffer, input.mimeType);

      // Save to DB
      const id = await db.createDocument({
        weddingId: wedding.id,
        providerId: input.providerId || null,
        type: input.type,
        title: input.title,
        fileUrl: url,
        fileKey,
        mimeType: input.mimeType,
        fileSize: buffer.length,
        backgroundTheme: input.backgroundTheme || "floral",
      });

      return { id, url };
    }),
});

// ─── Memory Router ───────────────────────────────────────────────────────────

const memoryRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getMemoriesByWedding(wedding.id);
  }),

  add: protectedProcedure
    .input(z.object({
      title: z.string(),
      content: z.string(),
      type: z.enum(["decision", "milestone", "emotion", "detail", "quote"]),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const id = await db.createMemory({
        weddingId: wedding.id,
        ...input,
        source: "manual",
      });
      return { id };
    }),
});

// ─── Timeline Router ─────────────────────────────────────────────────────────

const timelineRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getTimelineByWedding(wedding.id);
  }),

  add: protectedProcedure
    .input(z.object({
      title: z.string(),
      description: z.string().optional(),
      eventDate: z.string().optional(),
      category: z.enum(["preparation", "ceremony", "reception", "after", "admin"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const id = await db.createTimelineEvent({
        weddingId: wedding.id,
        title: input.title,
        description: input.description,
        eventDate: input.eventDate ? new Date(input.eventDate) : undefined,
        category: input.category,
      });
      return { id };
    }),

  toggle: protectedProcedure
    .input(z.object({ id: z.number(), isCompleted: z.boolean() }))
    .mutation(async ({ input }) => {
      await db.updateTimelineEvent(input.id, { isCompleted: input.isCompleted });
      return { success: true };
    }),
});

// ─── Guests Router ───────────────────────────────────────────────────────────

const guestsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getGuestsByWedding(wedding.id);
  }),

  add: protectedProcedure
    .input(z.object({
      name: z.string(),
      email: z.string().optional(),
      phone: z.string().optional(),
      group: z.enum(["family_bride", "family_groom", "friends", "colleagues", "other"]).optional(),
      plusOne: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const id = await db.createGuest({ weddingId: wedding.id, ...input });
      return { id };
    }),

  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      rsvpStatus: z.enum(["pending", "confirmed", "declined", "maybe"]).optional(),
      tableNumber: z.number().optional(),
      dietaryNeeds: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateGuest(id, data);
      return { success: true };
    }),

  // Generate invite links for all guests
  generateInviteLinks: protectedProcedure
    .input(z.object({ origin: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const tokens = await db.generateInviteTokensForWedding(wedding.id);
      return tokens.map(t => ({
        guestId: t.guestId,
        name: t.name,
        link: `${input.origin}/invite/${t.token}`,
      }));
    }),
});

// ─── Public Invite Router (no auth needed) ──────────────────────────────────

const inviteRouter = router({
  // Get guest info by token (public)
  getByToken: publicProcedure
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      const guest = await db.getGuestByToken(input.token);
      if (!guest) return null;
      const wedding = await db.getWeddingById(guest.weddingId);
      return {
        guest: { id: guest.id, name: guest.name, rsvpStatus: guest.rsvpStatus, dietaryNeeds: guest.dietaryNeeds, plusOne: guest.plusOne },
        wedding: wedding ? { city: wedding.city, date: wedding.weddingDate, venue: wedding.venue, partnerName: wedding.partnerName } : null,
      };
    }),

  // RSVP by token (public - no login required)
  rsvp: publicProcedure
    .input(z.object({
      token: z.string(),
      rsvpStatus: z.enum(["confirmed", "declined", "maybe"]),
      dietaryNeeds: z.string().optional(),
      plusOne: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const { token, ...data } = input;
      const updated = await db.updateGuestRsvpByToken(token, data);
      if (!updated) throw new Error("Invalid invite link");
      return { success: true, name: updated.name };
    }),
});

// ─── Budget Router ───────────────────────────────────────────────────────────

const budgetRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];
    return db.getBudgetByWedding(wedding.id);
  }),

  add: protectedProcedure
    .input(z.object({
      category: z.string(),
      label: z.string(),
      estimatedAmount: z.number().optional(),
      providerId: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const wedding = await db.getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("No wedding found");
      const id = await db.createBudgetItem({
        weddingId: wedding.id,
        ...input,
        estimatedAmount: input.estimatedAmount ? input.estimatedAmount * 100 : undefined,
      });
      return { id };
    }),

  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      actualAmount: z.number().optional(),
      isPaid: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const updates: any = { ...data };
      if (data.actualAmount) updates.actualAmount = data.actualAmount * 100;
      await db.updateBudgetItem(id, updates);
      return { success: true };
    }),
});

// ─── Guest Portal Router ─────────────────────────────────────────────────────────

const guestPortalRouter = router({
  // Get wedding info for this guest (by their email)
  myWedding: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.user.email;
    if (!email) return null;
    const guest = await db.getGuestByEmail(email);
    if (!guest) return null;
    const wedding = await db.getWeddingById(guest.weddingId);
    return wedding;
  }),

  // Get my guest record
  myRecord: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.user.email;
    if (!email) return null;
    return db.getGuestByEmail(email);
  }),

  // RSVP update
  rsvp: protectedProcedure
    .input(z.object({
      rsvpStatus: z.enum(["pending", "confirmed", "declined", "maybe"]),
      dietaryNeeds: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const email = ctx.user.email;
      if (!email) throw new Error("No email");
      const guest = await db.getGuestByEmail(email);
      if (!guest) throw new Error("Guest not found");
      await db.updateGuest(guest.id, input);
      return { success: true };
    }),

  // Get timeline events for the wedding (filtered: only public events)
  timeline: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.user.email;
    if (!email) return [];
    const guest = await db.getGuestByEmail(email);
    if (!guest) return [];
    const events = await db.getTimelineByWedding(guest.weddingId);
    // Only show ceremony and reception events to guests
    return events.filter(e => e.category === "ceremony" || e.category === "reception");
  }),
});

// ─── Provider Portal Router ──────────────────────────────────────────────────────

const providerPortalRouter = router({
  // Get my provider profile (by email)
  myProfile: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.user.email;
    if (!email) return null;
    return db.getProviderByEmail(email);
  }),

  // Get my missions (wedding assignments)
  myMissions: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.user.email;
    if (!email) return [];
    const provider = await db.getProviderByEmail(email);
    if (!provider) return [];
    return db.getWeddingProvidersByProviderId(provider.id);
  }),

  // Get documents linked to me
  myDocuments: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.user.email;
    if (!email) return [];
    const provider = await db.getProviderByEmail(email);
    if (!provider) return [];
    return db.getDocumentsByProvider(provider.id);
  }),
});

// ─── Main Router ─────────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  chat: chatRouter,
  wedding: weddingRouter,
  spaces: spacesRouter,
  providers: providersRouter,
  documents: documentsRouter,
  memory: memoryRouter,
  timeline: timelineRouter,
  guests: guestsRouter,
  budget: budgetRouter,
  guestPortal: guestPortalRouter,
  providerPortal: providerPortalRouter,
  invite: inviteRouter,
});
export type AppRouter = typeof appRouter;

// ─── Helpers ─────────────────────────────────────────────────────────────────

function tryExtractResponse(content: string): string | null {
  try {
    const parsed = JSON.parse(content);
    return parsed.response || null;
  } catch {
    return null;
  }
}

async function updateSpacesFromParsed(weddingId: number, parsed: any) {
  // Update Couple space
  if (parsed.ambiance?.length || parsed.partnerName) {
    const data = JSON.stringify({ ambiance: parsed.ambiance, partnerName: parsed.partnerName });
    await db.upsertSpace(weddingId, "couple", data, "in_progress");
  }

  // Update Invités space
  if (parsed.guestCount) {
    const data = JSON.stringify({ guestCount: parsed.guestCount });
    await db.upsertSpace(weddingId, "invites", data, "in_progress");
  }

  // Update Prestataires space
  if (parsed.needs?.length || parsed.providers_mentioned?.length) {
    const data = JSON.stringify({ needs: parsed.needs, mentioned: parsed.providers_mentioned });
    await db.upsertSpace(weddingId, "prestataires", data, "in_progress");
  }

  // Update Timeline space
  if (parsed.date || parsed.city || parsed.venue) {
    const data = JSON.stringify({ date: parsed.date, city: parsed.city, venue: parsed.venue });
    await db.upsertSpace(weddingId, "timeline", data, "in_progress");
  }

  // Update Budget space
  if (parsed.budget) {
    const data = JSON.stringify({ estimated: parsed.budget });
    await db.upsertSpace(weddingId, "budget", data, "in_progress");
  }

  // Always update Mémoire
  await db.upsertSpace(weddingId, "memoire", JSON.stringify({ lastUpdate: new Date().toISOString() }), "in_progress");
}
