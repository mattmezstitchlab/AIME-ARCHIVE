import { eq, and, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  weddings, InsertWedding, Wedding,
  messages, InsertMessage,
  spaces, InsertSpace,
  providers, Provider, InsertProvider,
  weddingProviders, InsertWeddingProvider,
  documents, InsertDocument,
  memories, InsertMemory,
  timelineEvents, InsertTimelineEvent,
  guests, InsertGuest,
  budgetItems, InsertBudgetItem,
  intermittentDocs, InsertIntermittentDoc,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Weddings ────────────────────────────────────────────────────────────────

export async function getWeddingByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(weddings).where(eq(weddings.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createWedding(data: InsertWedding) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(weddings).values(data);
  return result[0].insertId;
}

export async function updateWedding(id: number, data: Partial<InsertWedding>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(weddings).set(data).where(eq(weddings.id, id));
}

// ─── Messages ────────────────────────────────────────────────────────────────

export async function getMessagesByWedding(weddingId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages).where(eq(messages.weddingId, weddingId)).orderBy(asc(messages.createdAt)).limit(limit);
}

export async function createMessage(data: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(messages).values(data);
  return result[0].insertId;
}

// ─── Spaces ──────────────────────────────────────────────────────────────────

export async function getSpacesByWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(spaces).where(eq(spaces.weddingId, weddingId));
}

export async function upsertSpace(weddingId: number, type: string, data: string, status: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db.select().from(spaces)
    .where(and(eq(spaces.weddingId, weddingId), eq(spaces.type, type as any)))
    .limit(1);
  if (existing.length > 0) {
    await db.update(spaces).set({ data, status: status as any }).where(eq(spaces.id, existing[0].id));
    return existing[0].id;
  } else {
    const result = await db.insert(spaces).values({ weddingId, type: type as any, data, status: status as any });
    return result[0].insertId;
  }
}

// ─── Providers ───────────────────────────────────────────────────────────────

export async function getAllProviders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(providers);
}

export async function getProvidersByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(providers).where(eq(providers.category, category as any));
}

export async function getProviderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(providers).where(eq(providers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createProvider(data: InsertProvider) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(providers).values(data);
  return result[0].insertId;
}

// ─── Wedding Providers ───────────────────────────────────────────────────────

export async function getWeddingProviders(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(weddingProviders).where(eq(weddingProviders.weddingId, weddingId));
}

export async function addWeddingProvider(data: InsertWeddingProvider) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(weddingProviders).values(data);
  return result[0].insertId;
}

export async function updateWeddingProvider(id: number, data: Partial<InsertWeddingProvider>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(weddingProviders).set(data).where(eq(weddingProviders.id, id));
}

// ─── Documents ───────────────────────────────────────────────────────────────

export async function getDocumentsByWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documents).where(eq(documents.weddingId, weddingId)).orderBy(desc(documents.createdAt));
}

export async function createDocument(data: InsertDocument) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(documents).values(data);
  return result[0].insertId;
}

// ─── Memories ────────────────────────────────────────────────────────────────

export async function getMemoriesByWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(memories).where(eq(memories.weddingId, weddingId)).orderBy(desc(memories.createdAt));
}

export async function createMemory(data: InsertMemory) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(memories).values(data);
  return result[0].insertId;
}

// ─── Timeline ────────────────────────────────────────────────────────────────

export async function getTimelineByWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(timelineEvents).where(eq(timelineEvents.weddingId, weddingId)).orderBy(asc(timelineEvents.order));
}

export async function createTimelineEvent(data: InsertTimelineEvent) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(timelineEvents).values(data);
  return result[0].insertId;
}

export async function updateTimelineEvent(id: number, data: Partial<InsertTimelineEvent>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(timelineEvents).set(data).where(eq(timelineEvents.id, id));
}

// ─── Guests ──────────────────────────────────────────────────────────────────

export async function getGuestsByWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(guests).where(eq(guests.weddingId, weddingId)).orderBy(asc(guests.name));
}

export async function createGuest(data: InsertGuest) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(guests).values(data);
  return result[0].insertId;
}

export async function updateGuest(id: number, data: Partial<InsertGuest>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(guests).set(data).where(eq(guests.id, id));
}

// ─── Budget ──────────────────────────────────────────────────────────────────

export async function getBudgetByWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(budgetItems).where(eq(budgetItems.weddingId, weddingId));
}

export async function createBudgetItem(data: InsertBudgetItem) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(budgetItems).values(data);
  return result[0].insertId;
}

export async function updateBudgetItem(id: number, data: Partial<InsertBudgetItem>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(budgetItems).set(data).where(eq(budgetItems.id, id));
}

// ─── Intermittent Docs ───────────────────────────────────────────────────────

export async function getIntermittentDocsByProvider(weddingProviderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(intermittentDocs).where(eq(intermittentDocs.weddingProviderId, weddingProviderId));
}

export async function createIntermittentDoc(data: InsertIntermittentDoc) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(intermittentDocs).values(data);
  return result[0].insertId;
}

export async function updateIntermittentDoc(id: number, data: Partial<InsertIntermittentDoc>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(intermittentDocs).set(data).where(eq(intermittentDocs.id, id));
}

// ─── Guest Portal Access ────────────────────────────────────────────────────

export async function getGuestByEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const results = await db.select().from(guests).where(eq(guests.email, email)).limit(1);
  return results[0] || null;
}

export async function getWeddingById(weddingId: number) {
  const db = await getDb();
  if (!db) return null;
  const results = await db.select().from(weddings).where(eq(weddings.id, weddingId)).limit(1);
  return results[0] || null;
}

// ─── Provider Portal Access ─────────────────────────────────────────────────

export async function getProviderByEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const results = await db.select().from(providers).where(eq(providers.contactEmail, email)).limit(1);
  return results[0] || null;
}

export async function getWeddingProvidersByProviderId(providerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(weddingProviders).where(eq(weddingProviders.providerId, providerId));
}

export async function getDocumentsByProvider(providerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documents).where(eq(documents.providerId, providerId)).orderBy(desc(documents.createdAt));
}

// ─── Invite Token Helpers ─────────────────────────────────────────────────────

export async function getGuestByToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const results = await db.select().from(guests).where(eq(guests.inviteToken, token)).limit(1);
  return results[0] || null;
}

export async function setGuestInviteToken(guestId: number, token: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(guests).set({ inviteToken: token }).where(eq(guests.id, guestId));
}

export async function generateInviteTokensForWedding(weddingId: number) {
  const db = await getDb();
  if (!db) return [];
  const guestList = await db.select().from(guests).where(eq(guests.weddingId, weddingId));
  const results: { guestId: number; name: string; token: string }[] = [];
  for (const guest of guestList) {
    if (!guest.inviteToken) {
      const token = crypto.randomUUID().replace(/-/g, "").slice(0, 32);
      await db.update(guests).set({ inviteToken: token }).where(eq(guests.id, guest.id));
      results.push({ guestId: guest.id, name: guest.name, token });
    } else {
      results.push({ guestId: guest.id, name: guest.name, token: guest.inviteToken });
    }
  }
  return results;
}

export async function updateGuestRsvpByToken(token: string, data: { rsvpStatus: "confirmed" | "declined" | "maybe"; dietaryNeeds?: string; plusOne?: boolean }) {
  const db = await getDb();
  if (!db) return null;
  const guest = await getGuestByToken(token);
  if (!guest) return null;
  await db.update(guests).set(data).where(eq(guests.id, guest.id));
  return { ...guest, ...data };
}
