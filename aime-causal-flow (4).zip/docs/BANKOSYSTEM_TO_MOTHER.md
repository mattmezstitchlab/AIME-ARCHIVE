# BANKOSYSTEM → AIME mère

## 1. Entités universelles transférables
Identity, PublicProfile (+ME), Intention (Point Zéro), Project, Seed, OraState, ConsentReceipt, MatchParticipant, Decision, Simulation, CausalSignal, CausalEffect, Evidence, Document, AuditEntry et LastPoint. Need, Offer, Capital, Commitment et MatchProposal gardent des extensions BANKOSYSTEM.

## 2. Fonctions backend transférables
`recordConsent`, `revealIdentity`, `transitionOra`, `simulateRipple`, `applySimulation`, `discardSimulation` et `bankosystemCausalAdapter`. `computeMatchProposals` reste spécialisé mais son empreinte et son explication sont transférables.

## 3. Machines d’état
- Consentement participant : pending → accepted | refused | revoked. Toute nouvelle action incrémente la version.
- Reçu : pending → granted | refused | revoked | expired.
- ORA : observing → feeling → acting. Si Ressentir est ignoré, la transition observing → acting persiste `feeling_status: skipped`; un ressenti fourni persiste `provided`.
- Simulation : calculated → applied | discarded | expired | conflict.
- Décision : pending → committed | failed.
- Seed : sown/detected/recognized/proposed/awaiting_consent/mutually_accepted/activated/completed/suspended/revoked/archived.

## 4. Règles de consentement
L’utilisateur vient exclusivement de la session serveur. Chaque participant reçoit un reçu dès la proposition. Une identité exige au moins deux participants uniques, tous accepted, un reçu granted v2 par participant et une égalité entre version du reçu et version du participant. La vérification est répétée avant la réponse, les réponses privées portent `Cache-Control: no-store`, et refus/révocation effacent les drapeaux et l’affichage. Aucun score global et aucune identité privée ne participent au matching.

## 5. Règles RLS
Project est lisible par son créateur mais non modifiable directement. MatchProposal, ConsentReceipt, OraState, Decision et AuditEntry sont mutés uniquement côté serveur ; les lectures de reçus, ORA, décisions et audits sont limitées à leur utilisateur/auteur. Simulation est limitée à `user_id`. Les espaces real/demo/test sont filtrés explicitement dans les fonctions sensibles.

## 6. Contrat BankosystemCausalAdapter
Version `bankosystem-causal-radial/v1` : `{project,nodes,relations,capitalTypes,generatedAt}`. Chaque nœud expose type, état, causes, effets, incertitudes, barrières, décisions humaines, preuves et droits d’action. Aucune dépendance à AIME Event. Les six capitaux restent : financial, time, skills, experience, relational, material_territorial.

## 7. Tests
`src/lib/trustKernel.test.js` importe la source canonique `base44/functions/_shared/trustKernel.js` et contient 35 tests contractuels. B4 couvre la répétition idempotente exacte, l’absence de version et d’audit supplémentaires, le conflit de clé/action, la nouvelle clé avec version obsolète, l’activation partielle des drapeaux suivie d’un nettoyage obligatoire, l’absence d’identité retournée et le signalement d’un nettoyage échoué. Les tests ne touchent à aucune donnée Base44. Les commandes Node restent à exécuter extérieurement sur le prochain ZIP.

## 8. Dépendances
Base44 SDK 0.8.x, Web Crypto SHA-256, React 18, Vite 6 et Node `node:test`. `react-quill` et `quill` sont absents de `package.json`. Le lockfile et l’audit seront contrôlés extérieurement sur le prochain ZIP; aucun résultat n’est présumé ici.

## 9. Exclusivement BANKOSYSTEM
Six capitaux, besoins/offres, règles de complémentarité, disponibilités, territoires, conditions, valeurs, preuves autorisées, conflits, structures duo/trio/cercle/équipe/chaîne et explication SI → ALORS → PARCE QUE.

## 10. Risques résiduels
Base44 ne fournit ici ni transaction multi-entités ni compare-and-swap prouvé. `expectedVersion` détecte un conflit mais n’est pas une transaction. Les fonctions revérifient participants, reçus v2 et versions, et `commitReveal` remet tous les drapeaux à false après révocation concurrente ou échec d’audit. Project + Decision + AuditEntry utilisent journal préalable et compensation, sans atomicité garantie. Le dédoublonnage par empreinte n’est pas protégé par une contrainte unique transactionnelle.

Source canonique unique avec miroirs générés imposés par le bundler Base44. L’égalité SHA-256 est bloquante avant tests et build. Les copies ne sont jamais éditées manuellement.

## 11. Ordre d’intégration dans AIME mère
1. RLS et séparation des espaces. 2. Identity/PublicProfile/Project. 3. ConsentReceipt/MatchParticipant et fonctions de consentement. 4. AuditEntry/Decision. 5. Simulation/Ripple. 6. ORA/Seed/LastPoint. 7. Adaptateur radial. 8. Tests multi-comptes. 9. Extensions spécialisées choisies de BANKOSYSTEM.

## 12. Chemins exacts
### Entités
- `base44/entities/Identity.jsonc`
- `base44/entities/PublicProfile.jsonc`
- `base44/entities/Intention.jsonc`
- `base44/entities/Project.jsonc`
- `base44/entities/Seed.jsonc`
- `base44/entities/OraState.jsonc`
- `base44/entities/ConsentReceipt.jsonc`
- `base44/entities/MatchParticipant.jsonc`
- `base44/entities/Decision.jsonc`
- `base44/entities/Simulation.jsonc`
- `base44/entities/CausalSignal.jsonc`
- `base44/entities/CausalEffect.jsonc`
- `base44/entities/Evidence.jsonc`
- `base44/entities/Document.jsonc`
- `base44/entities/AuditEntry.jsonc`
- `base44/entities/LastPoint.jsonc`
- `base44/entities/Need.jsonc`
- `base44/entities/Offer.jsonc`
- `base44/entities/Capital.jsonc`
- `base44/entities/Commitment.jsonc`
- `base44/entities/MatchProposal.jsonc`

### Fonctions et adaptateur
- `base44/functions/recordConsent/entry.ts`
- `base44/functions/revealIdentity/entry.ts`
- `base44/functions/transitionOra/entry.ts`
- `base44/functions/simulateRipple/entry.ts`
- `base44/functions/applySimulation/entry.ts`
- `base44/functions/discardSimulation/entry.ts`
- `base44/functions/computeMatchProposals/entry.ts`
- `base44/functions/getMyMatches/entry.ts`
- `base44/functions/extractIntention/entry.ts`
- Adaptateur : `base44/functions/bankosystemCausalAdapter/entry.ts`

### Tests et noyau
- Source canonique éditable : `base44/functions/_shared/trustKernel.js`
- Miroirs générés : `base44/functions/{recordConsent,revealIdentity,transitionOra,simulateRipple,applySimulation,discardSimulation,computeMatchProposals}/trustKernel.js`
- Génération : `scripts/sync-trust-kernel.mjs` via `npm run sync:trust-kernel`
- Contrôle SHA-256 et exports : `scripts/check-trust-kernel-sync.mjs` via `npm run check:trust-kernel-sync`
- Tests : `src/lib/trustKernel.test.js`
- Typecheck ciblé : `jsconfig.trust-kernel.json` via `npm run typecheck:trust-kernel`
- `npm test` et `npm run build` exécutent d’abord le contrôle de synchronisation.

## 13. Validation de clôture B4
- `recordConsent` recherche le reçu avant le contrôle de version et rejoue une action identique sans mutation, nouvelle version ni nouvel audit.
- Une clé réutilisée pour une autre action retourne explicitement 409; une nouvelle clé avec version obsolète retourne 409.
- Les réponses initiale et rejouée utilisent la même projection publique limitée du participant.
- `commitReveal` tente toujours le nettoyage `setFlags(false)`, même si l’activation a partiellement réussi avant de lever une erreur.
- Un échec de nettoyage est signalé par `resetFailed` et journalisé côté serveur par `revealIdentity`; aucune identité n’est renvoyée.
- La source canonique et les sept miroirs générés restent en place.
- À exécuter extérieurement : `npm run check:trust-kernel-sync`, `npm run typecheck:trust-kernel`, `npm test`, `npm run lint`, `npm run build`, `npm audit --omit=dev`.
- Les scénarios multi-comptes réels restent à valider.
- Aucun transfert vers AIME mère n’a été effectué.

## 14. Décision
**NOT READY FOR MOTHER** uniquement jusqu’à l’exécution réussie des validations externes et des scénarios multi-comptes réels.