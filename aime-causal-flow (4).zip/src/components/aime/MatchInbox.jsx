import React from 'react';
import OraPanel from '@/components/aime/OraPanel';

export default function MatchInbox({ proposals, selectedId, onSelect, participant, oraState, onOraTransition, onConsent, onReveal, busy, reveal }) {
  const proposal = proposals.find((item) => item.id === selectedId) || proposals[0];
  if (!proposal) return <p className="py-10 text-center text-slate-600 dark:text-slate-400">Aucune proposition reçue pour le moment.</p>;
  return <div>
    <div className="mb-5">
      <h3 className="text-xl font-semibold">Boîte de réception sécurisée</h3>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Seules les informations autorisées de la proposition sont affichées.</p>
      {proposals.length > 1 && <label className="mt-4 block text-sm font-medium">
        Proposition
        <select value={proposal.id} onChange={(event) => onSelect(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-violet-200 bg-white px-3 dark:bg-slate-900">
          {proposals.map((item, index) => <option key={item.id} value={item.id}>Proposition {index + 1} · {item.structure_type}</option>)}
        </select>
      </label>}
    </div>
    <OraPanel key={proposal.id} proposal={proposal} participant={participant} oraState={oraState} onOraTransition={onOraTransition} onConsent={onConsent} onReveal={onReveal} busy={busy} reveal={reveal}/>
  </div>;
}