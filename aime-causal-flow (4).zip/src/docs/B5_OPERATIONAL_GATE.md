# B5 — Gate opérationnel multi-comptes

## Statut

**B5 BLOCKED — MULTI-ACCOUNT NOT EXECUTED.** Cette session de développement ne fournit pas trois sessions utilisateur authentifiées distinctes. Aucun transfert vers AIME mère n’a été effectué.

## Matrice des opérations `asServiceRole`

| Entité | Fonctions | Opérations backend |
|---|---|---|
| MatchProposal | computeMatchProposals, getMyMatches, recordConsent, revealIdentity, transitionOra, bankosystemCausalAdapter | filter, get, create, update |
| MatchParticipant | computeMatchProposals, getMyMatches, recordConsent, revealIdentity, transitionOra, bankosystemCausalAdapter | filter, bulkCreate, update, bulkUpdate |
| ConsentReceipt | computeMatchProposals, getMyMatches, recordConsent, revealIdentity, bankosystemCausalAdapter | filter, create, bulkCreate, update |
| OraState | getMyMatches, recordConsent, transitionOra | filter, create, update |
| Simulation | simulateRipple, applySimulation, discardSimulation, bankosystemCausalAdapter | filter, create, update |
| Decision | applySimulation, discardSimulation | filter, create, update |
| AuditEntry | recordConsent, revealIdentity, transitionOra, simulateRipple, applySimulation, discardSimulation | filter, create |
| Project | applySimulation | update |
| Identity | revealIdentity | filter |
| CausalEffect | simulateRipple, bankosystemCausalAdapter | filter, bulkCreate |
| Offer | computeMatchProposals | filter |

Les schémas conservent les mutations directes ordinaires fermées pour les entités serveur. La traversée valide de ces règles par `asServiceRole`, ainsi que le refus direct pour A, B et C, doivent être prouvés avec de vraies sessions avant toute extraction. Si Base44 traite le service role comme un compte administrateur au niveau RLS, cette limite signifie que l’administrateur technique n’est pas aveugle aux données privées; aucune affirmation contraire ne doit être faite.

## Corrections B5 appliquées

- La boîte de réception dépend uniquement de la projection `getMyMatches`, jamais de `projects[0]` ou `intentions[0]`.
- La sélection de proposition est explicite et ORA fonctionne sans charger le projet, l’intention ou l’identité privée d’un autre participant.
- La révélation reste exclusivement en mémoire React, est effacée au changement de proposition, au chargement, au refus/révocation, à la perte de validité temps réel et au départ de la page.
- Un abonnement `MatchParticipant` limité par la RLS de la session surveille le participant sélectionné; focus et retour de visibilité revérifient via `getMyMatches`.
- Une tentative logique de consentement conserve sa clé lors d’un résultat réseau inconnu et ne la libère qu’après réponse définitive ou changement de proposition/action/version.

## Recette et contrôles externes requis

Utiliser le Testing Agent avec trois comptes synthétiques distincts A, B et C et le préfixe `B5-<timestamp>`, puis supprimer toutes les données temporaires. Exécuter aussi, en consignant les codes réels :

- `npm run check:trust-kernel-sync`
- `npm run typecheck:trust-kernel`
- `npm test`
- `npm run lint`
- `npm run build`
- `npm run typecheck`
- `npm audit --omit=dev`

Aucun code de sortie n’est présumé dans ce document.