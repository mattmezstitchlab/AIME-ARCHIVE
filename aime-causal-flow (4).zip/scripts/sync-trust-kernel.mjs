import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const canonicalPath = resolve(rootDir, 'base44/functions/_shared/trustKernel.js');
export const mirrorPaths = [
  'recordConsent',
  'revealIdentity',
  'transitionOra',
  'simulateRipple',
  'applySimulation',
  'discardSimulation',
  'computeMatchProposals',
].map((name) => resolve(rootDir, `base44/functions/${name}/trustKernel.js`));
export const generatedHeader = '// GENERATED — DO NOT EDIT.\n// Source: base44/functions/_shared/trustKernel.js\n';

export async function syncTrustKernel() {
  const canonical = await readFile(canonicalPath, 'utf8');
  await Promise.all(mirrorPaths.map((path) => writeFile(path, `${generatedHeader}${canonical}`, 'utf8')));
  return mirrorPaths;
}

const isDirect = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirect) {
  syncTrustKernel()
    .then((paths) => console.log(`trustKernel synchronisé vers ${paths.length} miroirs.`))
    .catch((error) => {
      console.error(error instanceof Error ? error.message : error);
      process.exitCode = 1;
    });
}