import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { canonicalPath, generatedHeader, mirrorPaths } from './sync-trust-kernel.mjs';

const sha256 = (value) => createHash('sha256').update(value, 'utf8').digest('hex');
const exportNames = (value) => [...value.matchAll(/export\s+(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z_$][\w$]*)/g)]
  .map((match) => match[1])
  .sort();

export async function checkTrustKernelSync({ log = true } = {}) {
  const canonical = await readFile(canonicalPath, 'utf8');
  const canonicalHash = sha256(canonical);
  const canonicalExports = exportNames(canonical);

  for (const path of mirrorPaths) {
    let generated;
    try {
      generated = await readFile(path, 'utf8');
    } catch {
      throw new Error(`Miroir manquant : ${path}`);
    }
    if (!generated.startsWith(generatedHeader)) throw new Error(`Avertissement GENERATED absent : ${path}`);
    const functionalContent = generated.slice(generatedHeader.length);
    const mirrorExports = exportNames(functionalContent);
    if (mirrorExports.join('\n') !== canonicalExports.join('\n')) {
      throw new Error(`Exports divergents : ${path} (attendus ${canonicalExports.join(', ')}, reçus ${mirrorExports.join(', ')})`);
    }
    const mirrorHash = sha256(functionalContent);
    if (mirrorHash !== canonicalHash) {
      throw new Error(`Miroir divergent : ${path} (attendu ${canonicalHash}, reçu ${mirrorHash})`);
    }
  }

  if (log) console.log(`trustKernel synchronisé : ${mirrorPaths.length} miroirs, SHA-256 ${canonicalHash}.`);
  return { canonicalHash, exports: canonicalExports, mirrors: mirrorPaths };
}

const isDirect = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirect) {
  checkTrustKernelSync().catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  });
}