import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { buildSimulationDraft, GENERIC_SERVER_ERROR, logServerError, respondJson } from './trustKernel.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return respondJson({ error: 'Non autorisé' }, { status: 401 });
    const { projectId, changeType, value, idempotencyKey } = await req.json();
    if (!projectId || !idempotencyKey) return respondJson({ error: 'Demande invalide' }, { status: 400 });
    const project = await base44.entities.Project.get(projectId);
    if (!project || project.data_space !== 'real') return respondJson({ error: 'Dossier introuvable' }, { status: 404 });
    const prior = await base44.asServiceRole.entities.Simulation.filter({ user_id: user.id, project_id: projectId, idempotency_key: idempotencyKey, data_space: 'real' }, '-created_date', 1);
    if (prior[0]) {
      const priorEffects = await base44.asServiceRole.entities.CausalEffect.filter({ simulation_id: prior[0].id, data_space: 'real' });
      return respondJson({ simulation: prior[0], effects: priorEffects, idempotent: true });
    }
    const before = { budget: project.budget || 0, target_date: project.target_date || null, version: project.version || 1 };
    const draft = buildSimulationDraft(before, changeType, value);
    if (!draft.ok) {
      const message = draft.error === 'invalid_budget' ? 'Budget invalide' : draft.error === 'invalid_date' ? 'Date invalide' : draft.error === 'unchanged' ? 'Aucune donnée métier ne changerait.' : 'Mutation non implémentée.';
      return respondJson({ error: message }, { status: draft.error === 'unchanged' ? 409 : 400 });
    }
    const effects = changeType === 'budget'
      ? [{ layer: 'immediate', dimension: 'action', description: `Le budget passerait de ${before.budget} € à ${draft.after.budget} €.`, severity: draft.after.budget < before.budget ? 'attention' : 'info' }, { layer: 'cascade', dimension: 'temporality', description: draft.after.budget < before.budget ? 'Certaines étapes pourraient être décalées.' : 'Des étapes optionnelles pourraient devenir activables.', severity: 'attention' }]
      : [{ layer: 'immediate', dimension: 'temporality', description: `La date cible passerait de ${before.target_date || 'non définie'} à ${draft.after.target_date}.`, severity: 'info' }, { layer: 'cascade', dimension: 'relation', description: 'Les disponibilités et dépendances devront être revérifiées.', severity: 'attention' }];
    effects.push({ layer: 'human_decision', dimension: 'resonance', description: 'Une validation humaine reste obligatoire avant toute mutation.', severity: 'blocking' });
    const simulation = await base44.asServiceRole.entities.Simulation.create({ project_id: projectId, user_id: user.id, change_type: changeType, input: { value }, before_snapshot: before, after_snapshot: draft.after, status: 'calculated', idempotency_key: idempotencyKey, expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(), version: 1, data_space: 'real' });
    await base44.asServiceRole.entities.CausalEffect.bulkCreate(effects.map((effect) => ({ ...effect, simulation_id: simulation.id, reversible: true, data_space: 'real' })));
    await base44.asServiceRole.entities.AuditEntry.create({ actor_id: user.id, action: 'simulation_calculated', target_type: 'Simulation', target_id: simulation.id, reason: 'Prévisualisation demandée explicitement', previous_state: JSON.stringify(before), new_state: JSON.stringify(draft.after), data_used: [changeType], idempotency_key: `simulate:${idempotencyKey}`, server_date: new Date().toISOString(), version: 1, reversible: true, data_space: 'real' });
    return respondJson({ simulation, effects, notice: 'Ceci est une simulation. Rien n’a encore été modifié.' });
  } catch (error) {
    logServerError('simulateRipple', error);
    return respondJson({ error: GENERIC_SERVER_ERROR }, { status: 500 });
  }
});