import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { GENERIC_SERVER_ERROR, logServerError, simulationTransition } from './trustKernel.js';
Deno.serve(async (req) => {
  try {
    const respond=(body,init={})=>Response.json(body,{...init,headers:{...init.headers,'Cache-Control':'no-store, private','Pragma':'no-cache'}});
    const base44=createClientFromRequest(req); const user=await base44.auth.me();
    if(!user)return respond({error:'Non autorisé'},{status:401});
    const {simulationId,expectedProjectVersion,reason}=await req.json();
    if(!simulationId||!Number.isInteger(expectedProjectVersion)||!reason?.trim())return respond({error:'Demande invalide'},{status:400});
    const rows=await base44.asServiceRole.entities.Simulation.filter({id:simulationId,user_id:user.id,data_space:'real'},'-created_date',1); const simulation=rows[0];
    if(!simulation)return respond({error:'Simulation introuvable'},{status:404});
    const project=await base44.entities.Project.get(simulation.project_id);
    const transition=simulationTransition(simulation.status,'apply');
    if(!transition.ok)return respond({error:'Simulation non applicable dans son état actuel.'},{status:409});
    if(simulation.expires_at&&Date.parse(simulation.expires_at)<=Date.now()){await base44.asServiceRole.entities.Simulation.update(simulation.id,{status:'expired',version:(simulation.version||1)+1});return respond({error:'Simulation expirée.'},{status:410});}
    if(project.version!==expectedProjectVersion||simulation.before_snapshot.version!==project.version){await base44.asServiceRole.entities.Simulation.update(simulation.id,{status:'conflict',conflict_reason:'Version du projet modifiée',version:(simulation.version||1)+1});return respond({error:'Conflit de version. Relancez la simulation.'},{status:409});}
    const patch={version:project.version+1};
    if(simulation.change_type==='budget')patch.budget=simulation.after_snapshot.budget;
    else if(simulation.change_type==='date')patch.target_date=simulation.after_snapshot.target_date;
    else return respond({error:'Mutation non implémentée.'},{status:400});
    const changed=(simulation.change_type==='budget'&&patch.budget!==project.budget)||(simulation.change_type==='date'&&patch.target_date!==project.target_date);
    if(!changed){await base44.asServiceRole.entities.Simulation.update(simulation.id,{status:'conflict',conflict_reason:'Aucune mutation métier',version:(simulation.version||1)+1});return respond({error:'Aucune donnée métier ne changerait.'},{status:409});}
    const now=new Date().toISOString(); const key=`apply:${simulation.id}`; const before=JSON.stringify(simulation.before_snapshot); const after=JSON.stringify(simulation.after_snapshot);
    const existing=await base44.asServiceRole.entities.Decision.filter({idempotency_key:key,author_id:user.id},'-created_date',1);
    if(existing[0]?.status==='committed')return respond({project,simulation,idempotent:true,message:'Cette décision est déjà journalisée.'});
    const decision=existing[0]||await base44.asServiceRole.entities.Decision.create({project_id:project.id,author_id:user.id,action:`apply_${simulation.change_type}_simulation`,reason:reason.trim(),before_state:before,after_state:after,affected_data:[simulation.change_type],reversible:true,status:'pending',idempotency_key:key,server_date:now,version:project.version+1,data_space:'real'});
    await base44.asServiceRole.entities.AuditEntry.create({actor_id:user.id,action:'mutation_requested',target_type:'Project',target_id:project.id,reason:reason.trim(),previous_state:before,new_state:after,data_used:[simulation.change_type],idempotency_key:`${key}:requested`,server_date:now,version:project.version+1,reversible:true,data_space:'real'});
    let updated;
    try {
      updated=await base44.asServiceRole.entities.Project.update(project.id,patch);
      await base44.asServiceRole.entities.Simulation.update(simulation.id,{status:'applied',applied_at:new Date().toISOString(),version:(simulation.version||1)+1});
      await base44.asServiceRole.entities.Decision.update(decision.id,{status:'committed'});
      await base44.asServiceRole.entities.AuditEntry.create({actor_id:user.id,action:'mutation_committed',target_type:'Project',target_id:project.id,reason:reason.trim(),previous_state:before,new_state:JSON.stringify(updated),data_used:[simulation.change_type],idempotency_key:`${key}:committed`,server_date:new Date().toISOString(),version:updated.version,reversible:true,data_space:'real'});
    } catch(error) {
      try { await base44.asServiceRole.entities.Project.update(project.id,{budget:simulation.before_snapshot.budget,target_date:simulation.before_snapshot.target_date,version:project.version}); await base44.asServiceRole.entities.Simulation.update(simulation.id,{status:'conflict',conflict_reason:'Échec de journalisation',version:(simulation.version||1)+1}); await base44.asServiceRole.entities.Decision.update(decision.id,{status:'failed'}); } catch(_rollbackError) { /* limite non atomique documentée */ }
      return respond({error:'Mutation non validée : journalisation incomplète.'},{status:500});
    }
    return respond({project:updated,decision,simulation:{...simulation,status:'applied'},message:'Simulation appliquée, décidée et auditée.'});
  }catch(error){logServerError('applySimulation',error);return respond({error:GENERIC_SERVER_ERROR},{status:500});}
});