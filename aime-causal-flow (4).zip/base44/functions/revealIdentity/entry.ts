import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { canRevealSnapshot, commitReveal, GENERIC_SERVER_ERROR, logServerError, respondJson } from './trustKernel.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return respondJson({ error: 'Non autorisé' }, { status: 401 });
    const { matchProposalId } = await req.json();
    if (!matchProposalId) return respondJson({ error: 'Proposition invalide' }, { status: 400 });
    const readSnapshot = async () => ({
      participants: await base44.asServiceRole.entities.MatchParticipant.filter({ proposal_id: matchProposalId, data_space: 'real' }),
      receipts: await base44.asServiceRole.entities.ConsentReceipt.filter({ proposal_id: matchProposalId, purpose: 'identity_reveal', data_space: 'real' }),
    });
    const first = await readSnapshot();
    const requester = first.participants.find((item) => item.user_id === user.id);
    if (!requester) return respondJson({ error: 'Vous ne participez pas à cette proposition.' }, { status: 403 });
    if (!canRevealSnapshot(first.participants, first.receipts)) return respondJson({ revealed: false, message: 'Les identités restent masquées : tous les consentements actifs et versionnés sont requis.' });
    const initialVersions = new Map(first.participants.map((item) => [item.user_id, item.version]));
    const signature = first.participants.map((item) => `${item.user_id}:${item.version}`).sort().join('|');
    const identities = [];
    for (const participant of first.participants.filter((item) => item.user_id !== user.id)) {
      const privateRows = await base44.asServiceRole.entities.Identity.filter({ created_by_id: participant.user_id, data_space: 'real' }, '-created_date', 1);
      const publicRows = await base44.asServiceRole.entities.PublicProfile.filter({ created_by_id: participant.user_id, data_space: 'real' }, '-created_date', 1);
      if (!privateRows[0]) return respondJson({ revealed: false, message: 'Une identité consentante est incomplète.' }, { status: 409 });
      identities.push({ participantId: participant.id, displayName: privateRows[0].real_name, publicProfile: { displayName: publicRows[0]?.display_name || '', territory: publicRows[0]?.territory || '', publicSkills: publicRows[0]?.public_skills || [] } });
    }
    const setFlags = async (items, value) => base44.asServiceRole.entities.MatchParticipant.bulkUpdate(items.map((item) => ({ id: item.id, identity_revealed: value })));
    const revalidate = async () => {
      const snapshot = await readSnapshot();
      return canRevealSnapshot(snapshot.participants, snapshot.receipts)
        && snapshot.participants.length === first.participants.length
        && snapshot.participants.every((item) => initialVersions.get(item.user_id) === item.version);
    };
    const key = `reveal:${matchProposalId}:${signature}`;
    const result = await commitReveal({
      participants: first.participants,
      setFlags,
      revalidate,
      audit: async () => {
        const audits = await base44.asServiceRole.entities.AuditEntry.filter({ actor_id: user.id, idempotency_key: key }, '-created_date', 1);
        if (!audits[0]) await base44.asServiceRole.entities.AuditEntry.create({ actor_id: user.id, action: 'identity_revealed', target_type: 'MatchProposal', target_id: matchProposalId, reason: 'Tous les consentements actifs revérifiés immédiatement avant réponse', previous_state: 'masked', new_state: 'revealed', data_used: ['participants', 'reçus versionnés'], idempotency_key: key, server_date: new Date().toISOString(), version: requester.version, reversible: false, data_space: 'real' });
      },
    });
    if (!result.ok) {
      if (result.resetFailed) {
        logServerError('revealIdentity.cleanup', new Error('Le nettoyage initial des drapeaux a échoué.'));
        try { await setFlags((await readSnapshot()).participants, false); } catch (error) { logServerError('revealIdentity.failClosed', error); }
      }
      return respondJson({ revealed: false, message: 'Révélation annulée par sécurité.' }, { status: 409 });
    }
    return respondJson({ revealed: true, identities, cacheControl: 'no-store' });
  } catch (error) {
    logServerError('revealIdentity', error);
    return respondJson({ error: GENERIC_SERVER_ERROR }, { status: 500 });
  }
});