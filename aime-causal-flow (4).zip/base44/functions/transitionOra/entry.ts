import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { GENERIC_SERVER_ERROR, logServerError, nextOra, respondJson } from './trustKernel.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return respondJson({ error: 'Non autorisé' }, { status: 401 });
    const { proposalId, action, feeling, expectedVersion } = await req.json();
    if (!proposalId || !['observe', 'feel', 'act'].includes(action)) return respondJson({ error: 'Transition invalide' }, { status: 400 });
    const participants = await base44.asServiceRole.entities.MatchParticipant.filter({ proposal_id: proposalId, user_id: user.id, data_space: 'real' }, '-created_date', 1);
    if (!participants[0]) return respondJson({ error: 'Accès refusé' }, { status: 403 });
    const proposal = await base44.asServiceRole.entities.MatchProposal.get(proposalId);
    const states = await base44.asServiceRole.entities.OraState.filter({ proposal_id: proposalId, user_id: user.id, data_space: 'real' }, '-created_date', 1);
    const current = states[0];
    const transition = nextOra(current, action, expectedVersion);
    if (!transition.ok) {
      const message = transition.error === 'observe_required' ? 'Commencez par Observer.' : transition.error === 'expected_version_required' ? 'La version ORA attendue est obligatoire.' : transition.error === 'stale' ? 'Version ORA obsolète.' : 'Transition ORA interdite.';
      return respondJson({ error: message }, { status: 409 });
    }
    const now = new Date().toISOString();
    const patch = { stage: transition.stage, feeling_status: transition.feelingStatus, private_feeling: action === 'feel' ? (feeling || '') : (current?.private_feeling || ''), version: transition.version, last_transition_at: now };
    const next = current
      ? await base44.asServiceRole.entities.OraState.update(current.id, patch)
      : await base44.asServiceRole.entities.OraState.create({ project_id: proposal.project_id, proposal_id: proposalId, user_id: user.id, ...patch, data_space: 'real' });
    await base44.asServiceRole.entities.AuditEntry.create({ actor_id: user.id, action: `ora_${action}`, target_type: 'MatchProposal', target_id: proposalId, reason: 'Transition humaine explicite', previous_state: current?.stage || 'none', new_state: next.stage, data_used: action === 'feel' ? ['ressenti privé'] : ['étape ORA'], idempotency_key: `ora:${proposalId}:${user.id}:${next.version}`, server_date: now, version: next.version, reversible: false, data_space: 'real' });
    return respondJson({ state: { id: next.id, project_id: next.project_id, proposal_id: next.proposal_id, stage: next.stage, feeling_status: next.feeling_status, private_feeling: next.private_feeling, version: next.version } });
  } catch (error) {
    logServerError('transitionOra', error);
    return respondJson({ error: GENERIC_SERVER_ERROR }, { status: 500 });
  }
});