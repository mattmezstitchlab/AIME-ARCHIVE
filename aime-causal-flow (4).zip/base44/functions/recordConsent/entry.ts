import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { consentTransition, GENERIC_SERVER_ERROR, logServerError, resolveConsentIdempotency, respondJson } from './trustKernel.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return respondJson({ error: 'Non autorisé' }, { status: 401 });
    const { matchProposalId, action, expectedVersion, idempotencyKey } = await req.json();
    if (!matchProposalId || !['accept', 'refuse', 'revoke'].includes(action) || !Number.isInteger(expectedVersion) || !idempotencyKey) {
      return respondJson({ error: 'Demande invalide' }, { status: 400 });
    }
    const own = await base44.asServiceRole.entities.MatchParticipant.filter({ proposal_id: matchProposalId, user_id: user.id, data_space: 'real' }, '-created_date', 1);
    const participant = own[0];
    if (!participant) return respondJson({ error: 'Vous ne participez pas à cette proposition.' }, { status: 403 });
    const receipts = await base44.asServiceRole.entities.ConsentReceipt.filter({ proposal_id: matchProposalId, user_id: user.id, purpose: 'identity_reveal', data_space: 'real' }, '-created_date', 1);
    const receipt = receipts[0];
    const idempotency = resolveConsentIdempotency(receipt, action, idempotencyKey);
    const publicParticipant = (item) => ({ id: item.id, proposal_id: item.proposal_id, consent_state: item.consent_state, identity_revealed: false, version: item.version });
    const responseMessage = action === 'accept' ? 'Votre consentement est enregistré. Il ne révèle personne à lui seul.' : 'Votre choix est enregistré et toute identité affichée doit être effacée.';
    if (idempotency.status === 'conflict') return respondJson({ error: 'Clé d’idempotence déjà utilisée pour une autre action.' }, { status: 409 });
    if (idempotency.status === 'replay') {
      const proposal = await base44.asServiceRole.entities.MatchProposal.get(matchProposalId);
      return respondJson({ participant: publicParticipant(participant), proposalStatus: proposal.status, revealed: false, message: responseMessage, idempotent: true });
    }
    const states = action === 'accept'
      ? await base44.asServiceRole.entities.OraState.filter({ proposal_id: matchProposalId, user_id: user.id, stage: 'acting', data_space: 'real' }, '-created_date', 1)
      : [];
    const transition = consentTransition(participant, action, expectedVersion, states[0]?.stage);
    if (!transition.ok) {
      const message = transition.error === 'stale' ? 'Version obsolète. Rechargez la proposition.' : transition.error === 'ora_required' ? 'Le cycle Observer → Ressentir → Agir doit atteindre Agir.' : 'Demande invalide';
      return respondJson({ error: message }, { status: transition.error === 'invalid' ? 400 : 409 });
    }
    const now = new Date().toISOString();
    try {
      const updated = await base44.asServiceRole.entities.MatchParticipant.update(participant.id, { consent_state: transition.state, identity_revealed: false, version: transition.version });
      const receiptPatch = { status: transition.receiptStatus, action_version: transition.version, idempotency_key: idempotencyKey, decided_at: now, granted_at: action === 'accept' ? now : null, revoked_at: action === 'revoke' ? now : null, policy_version: 'aime-consent-v2' };
      if (receipt) await base44.asServiceRole.entities.ConsentReceipt.update(receipt.id, { ...receiptPatch, version: (receipt.version || 1) + 1 });
      else await base44.asServiceRole.entities.ConsentReceipt.create({ proposal_id: matchProposalId, user_id: user.id, purpose: 'identity_reveal', ...receiptPatch, version: 1, data_space: 'real' });
      const all = await base44.asServiceRole.entities.MatchParticipant.filter({ proposal_id: matchProposalId, data_space: 'real' });
      if (action !== 'accept') await base44.asServiceRole.entities.MatchParticipant.bulkUpdate(all.map((item) => ({ id: item.id, identity_revealed: false })));
      const proposal = await base44.asServiceRole.entities.MatchProposal.get(matchProposalId);
      const projected = all.map((item) => item.id === participant.id ? { ...item, consent_state: transition.state } : item);
      const proposalStatus = projected.some((item) => item.consent_state === 'revoked') ? 'revoked' : projected.some((item) => item.consent_state === 'refused') ? 'refused' : projected.length >= 2 && projected.every((item) => item.consent_state === 'accepted') ? 'mutually_accepted' : 'consenting';
      await base44.asServiceRole.entities.MatchProposal.update(matchProposalId, { status: proposalStatus, version: (proposal.version || 1) + 1 });
      await base44.asServiceRole.entities.AuditEntry.create({ actor_id: user.id, action: `consent_${action}`, target_type: 'MatchProposal', target_id: matchProposalId, reason: action === 'accept' ? 'Choix explicite après cycle ORA' : 'Choix explicite immédiat', previous_state: participant.consent_state, new_state: transition.state, data_used: ['session serveur', 'version participant', 'reçu individuel'], idempotency_key: idempotencyKey, server_date: now, version: transition.version, reversible: action === 'accept', data_space: 'real' });
      return respondJson({ participant: publicParticipant(updated), proposalStatus, revealed: false, message: responseMessage });
    } catch (error) {
      logServerError('recordConsent.commit', error);
      try {
        const all = await base44.asServiceRole.entities.MatchParticipant.filter({ proposal_id: matchProposalId, data_space: 'real' });
        await base44.asServiceRole.entities.MatchParticipant.bulkUpdate(all.map((item) => ({ id: item.id, identity_revealed: false })));
        await base44.asServiceRole.entities.MatchParticipant.update(participant.id, { consent_state: 'revoked', identity_revealed: false, version: transition.version + 1 });
        if (receipt) await base44.asServiceRole.entities.ConsentReceipt.update(receipt.id, { status: 'revoked', action_version: transition.version + 1, revoked_at: new Date().toISOString(), version: (receipt.version || 1) + 1 });
      } catch (resetError) { logServerError('recordConsent.failClosed', resetError); }
      return respondJson({ error: 'Consentement non validé : accès fermé par sécurité.' }, { status: 500 });
    }
  } catch (error) {
    logServerError('recordConsent', error);
    return respondJson({ error: GENERIC_SERVER_ERROR }, { status: 500 });
  }
});