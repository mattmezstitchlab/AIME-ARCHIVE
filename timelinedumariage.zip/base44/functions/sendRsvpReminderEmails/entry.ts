import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const rsvps = await base44.asServiceRole.entities.RSVP.list('-created_date', 500);
    const toRemind = rsvps.filter((rsvp) => {
      const incomplete = !rsvp.guest_name || !rsvp.attendance;
      return incomplete || rsvp.reminder_status === 'a_relancer';
    });

    let sent = 0;
    let skipped = 0;
    const now = new Date().toISOString();

    for (const rsvp of toRemind) {
      await base44.asServiceRole.entities.RSVP.update(rsvp.id, {
        reminder_status: 'a_relancer'
      });

      if (!rsvp.email) {
        skipped += 1;
        continue;
      }

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: rsvp.email,
        subject: 'Rappel RSVP — mariage dans une semaine',
        body: [
          `Bonjour ${rsvp.guest_name || ''},`,
          '',
          'Le mariage approche et nous avons besoin de finaliser les réponses RSVP.',
          'Merci de confirmer ou compléter votre présence dès que possible depuis l’application AIME Wedding.',
          '',
          'À très vite,',
          'L’équipe mariage'
        ].join('\n')
      });

      await base44.asServiceRole.entities.RSVP.update(rsvp.id, {
        reminder_status: 'reminder_sent',
        reminder_sent_date: now
      });
      sent += 1;
    }

    return Response.json({ success: true, marked_to_remind: toRemind.length, sent, skipped });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});