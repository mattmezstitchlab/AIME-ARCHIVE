import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const contribution = payload?.data;

    if (!contribution?.id) {
      return Response.json({ error: 'Contribution manquante' }, { status: 400 });
    }

    const guestName = contribution.guest_name || 'Un invité';
    const momentId = contribution.moment_id || 'moment non précisé';

    const notification = await base44.asServiceRole.entities.AdminNotification.create({
      title: 'Nouvelle contribution de moment',
      message: `${guestName} a ajouté une contribution pour ${momentId}.`,
      type: 'moment_contribution',
      related_entity: 'MomentContribution',
      related_entity_id: contribution.id,
      is_read: false
    });

    return Response.json({ success: true, notification });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});