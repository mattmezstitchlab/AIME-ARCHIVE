import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const attendanceLabels = {
  yes: 'Présents',
  no: 'Absents',
  maybe: 'Peut-être',
  missing: 'À relancer'
};

async function getAdminEmail(base44) {
  const admins = await base44.asServiceRole.entities.User.filter({ role: 'admin' }, '-created_date', 1);
  return admins?.[0]?.email || null;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const adminEmail = await getAdminEmail(base44);

    if (!adminEmail) {
      return Response.json({ error: 'Aucun email administrateur trouvé' }, { status: 400 });
    }

    const rsvps = await base44.asServiceRole.entities.RSVP.list('-created_date', 500);
    const counts = rsvps.reduce((acc, rsvp) => {
      const key = rsvp.attendance || 'missing';
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, { yes: 0, no: 0, maybe: 0, missing: 0 });

    const incomplete = rsvps.filter((rsvp) => !rsvp.guest_name || !rsvp.attendance || rsvp.reminder_status === 'a_relancer');
    const mealCounts = rsvps.reduce((acc, rsvp) => {
      const key = rsvp.meal_preference || 'standard';
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});

    const body = [
      'Bonjour,',
      '',
      'Voici le résumé RSVP quotidien :',
      '',
      `Total réponses : ${rsvps.length}`,
      `${attendanceLabels.yes} : ${counts.yes}`,
      `${attendanceLabels.no} : ${counts.no}`,
      `${attendanceLabels.maybe} : ${counts.maybe}`,
      `${attendanceLabels.missing} : ${counts.missing + incomplete.length}`,
      '',
      'Préférences repas :',
      ...Object.entries(mealCounts).map(([meal, count]) => `- ${meal} : ${count}`),
      '',
      incomplete.length ? 'Invités à relancer :' : 'Aucun invité à relancer actuellement.',
      ...incomplete.slice(0, 50).map((rsvp) => `- ${rsvp.guest_name || 'Nom manquant'} (${rsvp.email || 'email manquant'})`),
      '',
      'AIME Wedding'
    ].join('\n');

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: adminEmail,
      subject: 'Rapport RSVP quotidien',
      body
    });

    return Response.json({ success: true, sent_to: adminEmail, total: rsvps.length, counts });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});