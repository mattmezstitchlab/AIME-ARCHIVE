import WeddingTimeline from "../components/wedding/WeddingTimeline";
import CountdownWidget from "../components/wedding/CountdownWidget";
import WeddingPeopleCards from "../components/wedding/WeddingPeopleCards";
import GuestListSection from "../components/wedding/GuestListSection";
import RSVPForm from "../components/wedding/RSVPForm";
import FAQSection from "../components/wedding/FAQSection";
import CockpitOverviewSection from "../components/wedding/CockpitOverviewSection";
import InternalControlSection from "../components/wedding/InternalControlSection";

export default function WeddingDay() {
  return (
    <div className="min-h-screen bg-background">
      <section className="relative overflow-hidden px-4 pb-6 pt-8 sm:px-6 sm:pt-10 lg:pt-12">
        <div className="relative z-10 mx-auto max-w-6xl rounded-[2.5rem] border border-border bg-white/86 px-5 py-7 shadow-[0_24px_80px_rgba(23,21,17,0.08)] backdrop-blur-2xl sm:px-8 sm:py-9 lg:px-10">
          <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.26em] text-accent">AIME · Cockpit mariage</p>
              <p className="mt-2 text-sm font-semibold text-foreground/72">Cerise propose. L’humain valide.</p>
            </div>
            <CountdownWidget />
          </div>

          <div className="grid gap-7 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
            <div>
              <h1 className="max-w-4xl text-balance font-heading text-4xl font-black leading-[0.98] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
                Le cockpit clair du Jour J.
              </h1>
              <p className="mt-5 max-w-2xl text-pretty text-base font-semibold leading-relaxed text-foreground/72 sm:text-lg">
                Les moments, invités, prestataires et validations importantes réunis dans une lecture simple, chaleureuse et opérationnelle.
              </p>
              <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                <a href="#timeline" className="inline-flex min-h-11 items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-[0_14px_34px_rgba(23,21,17,0.14)] transition-colors duration-200 hover:bg-primary/88">
                  Ouvrir la Timeline
                </a>
                <button type="button" onClick={() => window.dispatchEvent(new CustomEvent("openCerise"))} className="inline-flex min-h-11 items-center justify-center rounded-full border border-border bg-white px-6 py-3 text-sm font-bold text-foreground transition-colors duration-200 hover:bg-muted">
                  Demander à Cerise
                </button>
              </div>
            </div>
            <div className="rounded-[2rem] border border-foreground/10 bg-[#FBF7F0] p-5">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-accent">Lecture immédiate</p>
              <h2 className="mt-3 text-2xl font-black tracking-tight text-foreground">Priorité au prochain moment.</h2>
              <p className="mt-3 text-sm font-semibold leading-relaxed text-foreground/72">
                Le cockpit ci-dessous résume l’état global, les confirmations importantes et les signaux à traiter sans exposer le contrôle interne.
              </p>
            </div>
          </div>
        </div>
      </section>

      <CockpitOverviewSection />

      <section id="timeline" className="pb-10">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <WeddingTimeline />
        </div>
      </section>

      <InternalControlSection />

      <WeddingPeopleCards />
      <GuestListSection />
      <RSVPForm />
      <FAQSection />
    </div>
  );
}