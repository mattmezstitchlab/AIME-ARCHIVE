import { Camera, CircleCheck, Clock, FileText, HeartHandshake, LockKeyhole, MapPin, Music, Smartphone, Users, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/AuthContext";
import DesignSystemSection from "../components/design-system/DesignSystemSection";
import DesignTokenCard from "../components/design-system/DesignTokenCard";
import ColorSwatch from "../components/design-system/ColorSwatch";
import DecisionList from "../components/design-system/DecisionList";

const typeRows = [
  ["H1 Hero", "48–72px", "900", "Anthracite", "Accueil, cockpit, grands écrans de contexte"],
  ["H2 Section", "28–40px", "900", "Anthracite", "Séparer les modules importants"],
  ["H3 Carte", "20–24px", "800/900", "Anthracite", "Titres de cartes et moments"],
  ["Texte courant", "15–18px", "600", "Anthracite 72%", "Explications lisibles"],
  ["Petits labels", "11–12px", "900", "Accent cerise", "Repères courts, catégories"],
  ["Boutons", "14px", "700/800", "Selon variante", "Actions explicites"],
  ["Aides", "12–14px", "600", "Anthracite 68%", "Formulaires et confidentialité"],
  ["Erreurs", "13–14px", "800", "Rouge erreur", "Messages de correction"],
];

const badges = [
  ["Confirmé", "bg-white text-foreground border-border"],
  ["En attente", "bg-red-50 text-red-900 border-red-200"],
  ["À vérifier", "bg-red-50 text-red-900 border-red-200"],
  ["Validé", "bg-white text-foreground border-border"],
  ["Privé", "bg-foreground text-background border-foreground"],
  ["Public", "bg-white text-foreground border-border"],
  ["Brouillon", "bg-muted text-foreground border-border"],
  ["Prêt à envoyer", "bg-red-50 text-red-900 border-red-200"],
  ["Archivé", "bg-muted text-foreground border-border"],
];

const cards = [
  ["Carte cockpit", "Synthèse lisible en quelques secondes, métriques sobres, action principale claire."],
  ["Carte moment", "Horaire, lieu, durée, description courte, pas de surcharge."],
  ["Carte invité", "Simple, émotionnelle, contributions publiques uniquement."],
  ["Carte prestataire", "Opérationnelle : horaires, lieux, brief et contact utile."],
  ["Carte document", "Titre, statut, visibilité et action validée."],
  ["Carte photo", "Image, légende douce, auteur si partagé."],
  ["Carte Cerise", "Courte, utile, jamais dominante côté public."],
  ["Carte contrôle interne", "Marquée couple/admin, diagnostics et validations uniquement internes."],
];

const futureTargets = ["WeddingDay", "Guests", "Prestataires", "WeddingPhotos", "Timeline", "RSVP", "Widget AIME", "Cerise", "Documents futurs", "Messages futurs", "Registre futur"];

const designRules = [
  ["Typographie", "Archivo pour les titres, sans-serif système pour l’interface. Deux familles maximum."],
  ["Couleurs", "Ivoire, blanc chaud, anthracite et cerise en micro-accent. Aucun autre accent coloré."],
  ["Contraste", "Texte principal anthracite ; texte secondaire foncé et lisible ; jamais blanc sur clair."],
  ["Boutons", "Actions principales anthracite, libellés explicites, focus visible, aucun bouton mort."],
  ["Cartes", "Fonds clairs, bordures nettes, respiration généreuse, pas de panneau surchargé."],
  ["Badges", "Le texte porte toujours le statut ; la couleur ne suffit jamais."],
  ["Pictogrammes", "Lucide-react uniquement, icônes sobres, pas d’emoji dans les blocs sérieux."],
  ["Espacements", "Grille modulaire, sections respirantes, largeur maîtrisée."],
  ["Responsive", "Une colonne mobile, pas d’overflow horizontal, boutons accessibles."],
  ["Public / admin", "Public simple et émotionnel ; diagnostics, logs et validations réservés couple/admin."],
  ["Cerise", "Cerise propose, l’humain valide. Discrète côté public, complète côté admin."],
];

const decisions = [
  "Typographie titres validée.",
  "Palette ivoire / anthracite / cerise validée.",
  "Cerise doit rester discrète côté public.",
  "Les cartes diagnostic sont réservées couple/admin.",
  "Le Widget AIME reste la navigation principale.",
  "Le Design System s’applique progressivement page par page.",
];

function AdminOnlyNotice() {
  return (
    <div className="min-h-screen bg-background px-6 py-28">
      <div className="mx-auto max-w-xl rounded-[2rem] border border-border bg-white/88 p-8 text-center shadow-[0_18px_54px_rgba(23,21,17,0.06)]">
        <LockKeyhole className="mx-auto h-10 w-10 text-foreground" />
        <h1 className="mt-4 font-heading text-3xl font-black text-foreground">Page interne</h1>
        <p className="mt-3 text-sm font-semibold leading-relaxed text-foreground/72">Cette charte est réservée au couple/admin et n’est pas destinée à l’espace invité.</p>
      </div>
    </div>
  );
}

export default function DesignSystemAime() {
  const { user } = useAuth();

  if (!user || user.role !== "admin") {
    return <AdminOnlyNotice />;
  }

  return (
    <div className="min-h-screen bg-background px-4 py-24 sm:px-6 lg:py-12">
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="rounded-[2.5rem] border border-border bg-white/88 p-6 shadow-[0_24px_80px_rgba(23,21,17,0.08)] backdrop-blur-2xl sm:p-9">
          <p className="text-xs font-black uppercase tracking-[0.28em] text-red-900">Charte interne · couple/admin</p>
          <h1 className="mt-4 max-w-4xl font-heading text-4xl font-black leading-tight tracking-tight text-foreground sm:text-6xl">Design System AIME Mariage</h1>
          <p className="mt-5 max-w-3xl text-base font-semibold leading-relaxed text-foreground/72 sm:text-lg">Source de vérité visuelle pour stabiliser typographie, couleurs, contrastes, boutons, cartes, pictogrammes, espacements, responsive et séparation public/admin.</p>
          <div className="mt-6 rounded-[1.5rem] border border-red-200 bg-red-50 p-4 text-sm font-black text-foreground">Cerise propose. L’humain valide.</div>
        </header>

        <DesignSystemSection eyebrow="Référence simple" title="Règles visuelles AIME Mariage" description="Charte lisible pour stabiliser les pages sans créer de builder interne ni appliquer de refonte automatique.">
          <div className="grid gap-3 md:grid-cols-2">
            {designRules.map(([title, description]) => (
              <div key={title} className="rounded-[1.5rem] border border-border bg-card p-4">
                <p className="font-black text-foreground">{title}</p>
                <p className="mt-2 text-sm font-semibold leading-relaxed text-foreground/72">{description}</p>
              </div>
            ))}
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="Décisions" title="Notes de décision" description="Historique court des choix visuels déjà validés pour éviter les régressions.">
          <DecisionList items={decisions} />
        </DesignSystemSection>

        <DesignSystemSection eyebrow="01 · Typographies" title="Bibliothèque typographique" description="Deux familles maximum : Archivo pour les titres, sans-serif système pour l’interface. Sobriété premium, jamais kitsch.">
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
            <DesignTokenCard title="Police titres" value="Archivo" description="H1, H2, H3, grands repères de cockpit." />
            <DesignTokenCard title="Police UI" value="Sans-serif système" description="Formulaires, cartes, boutons, textes courants." />
            <DesignTokenCard title="Boutons" value="14px · gras" description="Action claire, jamais ambiguë." />
            <DesignTokenCard title="Badges" value="11–12px · uppercase" description="Lisibles par texte + couleur." />
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="02 · Texte" title="Hiérarchie et usages" description="Chaque niveau indique son usage, son poids et sa couleur cible.">
          <div className="overflow-hidden rounded-[1.5rem] border border-border bg-card">
            {typeRows.map(([name, size, weight, color, usage]) => (
              <div key={name} className="grid gap-2 border-b border-border p-4 last:border-b-0 sm:grid-cols-[1.1fr_0.7fr_0.7fr_0.9fr_1.8fr]">
                <p className="font-black text-foreground">{name}</p>
                <p className="text-sm font-semibold text-foreground/72">{size}</p>
                <p className="text-sm font-semibold text-foreground/72">{weight}</p>
                <p className="text-sm font-semibold text-foreground/72">{color}</p>
                <p className="text-sm font-semibold text-foreground/72">{usage}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 grid gap-4 md:grid-cols-3">
            <div className="rounded-[1.5rem] border border-border bg-muted p-4"><p className="text-xs font-black uppercase tracking-widest text-red-900">Cerise</p><p className="mt-2 text-sm font-semibold text-foreground">Proposition courte, utile, à valider.</p></div>
            <div className="rounded-[1.5rem] border border-red-200 bg-red-50 p-4"><p className="text-sm font-black text-red-900">Erreur lisible</p><p className="mt-1 text-xs font-semibold text-red-800">Explique quoi corriger, sans ton technique.</p></div>
            <Badge className="w-fit self-start rounded-full border-red-200 bg-red-50 px-3 py-1 text-red-900 hover:bg-red-50">Badge statut lisible</Badge>
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="03 · Couleurs" title="Palette officielle" description="Ivoire et blanc chaud dominent. Anthracite pour l’action. Cerise en micro-accent uniquement.">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <ColorSwatch name="Ivoire" value="bg-background" usage="Fond principal" swatchClass="bg-background" />
            <ColorSwatch name="Blanc chaud" value="bg-card" usage="Cartes et panneaux" swatchClass="bg-card" />
            <ColorSwatch name="Anthracite" value="bg-foreground" usage="Texte principal et boutons" swatchClass="bg-foreground" />
            <ColorSwatch name="Anthracite doux" value="text-foreground/72" usage="Texte secondaire lisible" swatchClass="bg-foreground" />
            <ColorSwatch name="Cerise" value="accent" usage="Micro-accent, labels, alertes douces" swatchClass="bg-accent" />
            <ColorSwatch name="Neutre clair" value="muted" usage="Surfaces douces, jamais texte important" swatchClass="bg-muted" />
            <ColorSwatch name="Validation neutre" value="neutral" usage="Confirmé, validé sans couleur secondaire" swatchClass="bg-foreground" />
            <ColorSwatch name="Rouge attention" value="red" usage="À vérifier, attente, interdit" swatchClass="bg-red-500" />
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="04 · Contraste" title="Contraste obligatoire" description="Le texte doit rester lisible en une seconde, sur mobile comme desktop.">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-[1.5rem] bg-foreground p-5 text-background"><CircleCheck className="h-5 w-5" /><p className="mt-3 font-black">Autorisé</p><p className="text-sm font-semibold">Texte clair sur anthracite.</p></div>
            <div className="rounded-[1.5rem] border border-border bg-card p-5 text-foreground"><CircleCheck className="h-5 w-5" /><p className="mt-3 font-black">Autorisé</p><p className="text-sm font-semibold text-foreground/72">Texte anthracite sur fond clair.</p></div>
            <div className="rounded-[1.5rem] border border-red-200 bg-red-50 p-5 text-red-900"><XCircle className="h-5 w-5" /><p className="mt-3 font-black">Interdit</p><p className="text-sm font-semibold">Blanc sur ivoire, jaune pâle sur ivoire, champagne pour texte important.</p></div>
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="05 · Boutons" title="Styles d’actions" description="Aucun bouton mort. Un bouton désactivé doit expliquer pourquoi.">
          <div className="flex flex-wrap gap-3">
            <Button>Principal</Button>
            <Button variant="secondary">Secondaire</Button>
            <Button variant="outline">Outline</Button>
            <Button variant="ghost">Discret</Button>
            <Button variant="destructive">Danger</Button>
            <Button disabled title="Action disponible après validation">Désactivé · validation requise</Button>
            <Button className="w-full sm:w-auto">Mobile pleine largeur</Button>
          </div>
          <p className="mt-4 text-sm font-semibold text-foreground/72">États attendus : normal, hover, focus visible, disabled explicite, loading avec libellé d’attente.</p>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="06 · Cartes" title="Cartes publiques et internes" description="Les cartes publiques restent simples. Les cartes internes sont marquées couple/admin.">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {cards.map(([title, description]) => (
              <div key={title} className="rounded-[1.5rem] border border-border bg-card p-4">
                <p className="font-black text-foreground">{title}</p>
                <p className="mt-2 text-xs font-semibold leading-relaxed text-foreground/68">{description}</p>
              </div>
            ))}
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="07 · Badges" title="Statuts lisibles" description="Un badge ne dépend jamais uniquement de la couleur : le texte porte le sens.">
          <div className="flex flex-wrap gap-2">
            {badges.map(([label, className]) => <Badge key={label} variant="outline" className={`rounded-full px-3 py-1 font-black ${className}`}>{label}</Badge>)}
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="08 · Pictogrammes" title="Icônes" description="Une famille unique : lucide-react, trait fin, moderne, cohérent. Pas d’emoji décoratif dans les blocs principaux.">
          <div className="grid gap-4 md:grid-cols-3">
            <DesignTokenCard title="Autorisées" value="Calendar, Users, Clock, MapPin, FileText" description="Widget, cockpit, timeline, documents." />
            <DesignTokenCard title="À éviter" value="Pictos kitsch, emojis décoratifs" description="Pas de symboles mariage trop figuratifs dans les modules sérieux." />
            <DesignTokenCard title="À remplacer plus tard" value="Icônes incohérentes" description="Harmoniser progressivement sans casser le widget." />
          </div>
          <div className="mt-5 flex flex-wrap gap-4 text-foreground"><Users /><Clock /><MapPin /><FileText /><Camera /><Music /></div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="09 · Espacements" title="Grille et respiration" description="La grille AIME permet de retirer sans casser, d’ajouter sans surcharger, et de déplacer sans perdre le sens.">
          <div className="grid gap-4 md:grid-cols-3">
            <DesignTokenCard title="Sections" value="py-16 à py-24" description="Respiration généreuse, surtout desktop." />
            <DesignTokenCard title="Cartes" value="p-5 à p-8" description="Coins larges, contenu aligné." />
            <DesignTokenCard title="Largeur max" value="max-w-5xl / 6xl" description="Aucun bloc ne sort de l’écran." />
            <DesignTokenCard title="Desktop" value="2 à 4 colonnes" description="Selon densité, jamais surchargé." />
            <DesignTokenCard title="Tablette" value="2 colonnes" description="Cartes lisibles et respirantes." />
            <DesignTokenCard title="Mobile" value="1 colonne" description="Empilement propre, boutons accessibles." />
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="10 · Responsive" title="Règles mobiles" description="Mobile d’abord lisible : dock accessible, formulaires clairs, pas de texte coupé, pas de bouton hors écran.">
          <div className="rounded-[1.5rem] border border-border bg-card p-5"><Smartphone className="h-6 w-6" /><ul className="mt-4 space-y-2 text-sm font-semibold text-foreground/72"><li>Cartes empilées proprement.</li><li>Actions principales en pleine largeur si nécessaire.</li><li>Widget mobile compact et non intrusif.</li><li>Textes jamais tronqués sur les informations essentielles.</li></ul></div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="11 · Cerise" title="Présence de Cerise" description="Discrète, claire, courte et utile. Jamais dominante côté public ; plus complète côté couple/admin.">
          <div className="rounded-[1.5rem] border border-red-200 bg-red-50 p-5"><HeartHandshake className="h-6 w-6 text-red-900" /><p className="mt-3 text-lg font-black text-foreground">Cerise propose. L’humain valide.</p><p className="mt-2 text-sm font-semibold text-foreground/72">Aucune action engageante ne doit être envoyée, publiée, synchronisée, supprimée ou validée automatiquement.</p></div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="12 · Public / admin" title="Règles d’affichage" description="Aucun diagnostic interne côté public.">
          <div className="grid gap-4 md:grid-cols-3">
            <DesignTokenCard title="Invité" value="Simple, utile, émotionnel" description="Programme, informations pratiques, souvenirs publics validés." />
            <DesignTokenCard title="Prestataire" value="Opérationnel" description="Horaires, lieux, brief, consignes utiles." />
            <DesignTokenCard title="Couple/admin" value="Contrôle" description="Validations, logs, documents, décisions, diagnostics internes." />
          </div>
        </DesignSystemSection>

        <DesignSystemSection eyebrow="13 · À appliquer ensuite" title="Application progressive" description="Cette charte sert de référence. Ne pas appliquer partout sans validation page par page.">
          <div className="flex flex-wrap gap-2">
            {futureTargets.map((item) => <Badge key={item} variant="outline" className="rounded-full border-border bg-white px-3 py-1 text-foreground">{item}</Badge>)}
          </div>
        </DesignSystemSection>
      </div>
    </div>
  );
}