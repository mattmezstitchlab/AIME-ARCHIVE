import { HeartHandshake, Network, Sparkles } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background pt-28 pb-20">
      <section className="mx-auto max-w-5xl px-6">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl aime-glass-strong text-primary">
            <HeartHandshake className="h-8 w-8" />
          </div>
          <p className="mb-3 text-xs font-black uppercase tracking-[0.28em] text-primary">À propos</p>
          <h1 className="text-5xl font-semibold tracking-[-0.08em] text-foreground sm:text-7xl" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>
            About AIME
          </h1>
        </div>

        <div className="rounded-[2.75rem] border border-border bg-white/86 p-6 shadow-[0_18px_54px_rgba(23,21,17,0.06)] sm:p-10">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="rounded-[2rem] bg-muted/70 p-6">
              <Sparkles className="mb-4 h-7 w-7 text-primary" />
              <h2 className="mb-2 text-xl font-black text-foreground">Ce que fait l’app</h2>
              <p className="text-sm font-semibold leading-relaxed text-muted-foreground">
                AIME organise le Jour J comme une timeline vivante : moments, invités, photos, prestataires, rappels et informations pratiques sont regroupés dans une expérience claire.
              </p>
            </div>
            <div className="rounded-[2rem] bg-muted/70 p-6">
              <Network className="mb-4 h-7 w-7 text-primary" />
              <h2 className="mb-2 text-xl font-black text-foreground">Pour qui</h2>
              <p className="text-sm font-semibold leading-relaxed text-muted-foreground">
                Elle est pensée pour les couples, témoins, familles, invités et prestataires qui veulent rester synchronisés sans perdre l’émotion de la journée.
              </p>
            </div>
            <div className="rounded-[2rem] bg-muted/70 p-6">
              <HeartHandshake className="mb-4 h-7 w-7 text-primary" />
              <h2 className="mb-2 text-xl font-black text-foreground">Qui la construit</h2>
              <p className="text-sm font-semibold leading-relaxed text-muted-foreground">
                AIME est construit par une équipe créative qui mélange design, coordination événementielle et outils intelligents pour rendre l’organisation plus fluide.
              </p>
            </div>
          </div>

          <div className="mt-8 space-y-5 text-base font-semibold leading-8 text-foreground/80">
            <p>
              AIME est une application de gestion de mariage conçue pour transformer une journée complexe en un système simple, lisible et vivant. L’app permet de visualiser la timeline complète du mariage, de comprendre qui intervient à chaque moment, de centraliser les contributions des invités, de partager les photos, de suivre les réponses RSVP et de rendre les informations utiles accessibles au bon endroit. Au lieu d’une organisation dispersée entre messages, fichiers et conversations, AIME rassemble les éléments importants dans une interface élégante, pensée pour être consultée rapidement par les personnes concernées.
            </p>
            <p>
              L’application s’adresse aux futurs mariés qui veulent garder une vue globale sans tout porter seuls, aux témoins et proches qui aident à coordonner la journée, aux invités qui cherchent les horaires et informations pratiques, ainsi qu’aux prestataires qui ont besoin de comprendre le rythme de l’événement. AIME est construit comme un compagnon de coordination : visuel, rassurant, adaptable et suffisamment clair pour être utilisé avant, pendant et après le mariage. Derrière l’app, l’ambition est de créer une expérience humaine augmentée par la technologie, où chaque personne sait quoi faire, quand agir et comment rester connectée aux autres.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}