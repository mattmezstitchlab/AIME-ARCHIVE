import { useEffect, useState } from "react";
import { Camera } from "lucide-react";
import { base44 } from "@/api/base44Client";
import PageHero from "../components/layout/PageHero";
import PhotoUploadForm from "../components/wedding/PhotoUploadForm";
import WeddingPhotoGrid from "../components/wedding/WeddingPhotoGrid";

export default function WeddingPhotos() {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadPhotos = async () => {
    setLoading(true);
    const items = await base44.entities.WeddingPhoto.list("-created_date", 100);
    setPhotos(items);
    setLoading(false);
  };

  useEffect(() => {
    loadPhotos();
    const unsubscribe = base44.entities.WeddingPhoto.subscribe((event) => {
      if (event.type === "create") {
        setPhotos((current) => [event.data, ...current]);
      } else if (event.type === "delete") {
        setPhotos((current) => current.filter((photo) => photo.id !== event.id));
      } else if (event.type === "update") {
        setPhotos((current) => current.map((photo) => photo.id === event.id ? event.data : photo));
      }
    });
    return unsubscribe;
  }, []);

  return (
    <div className="min-h-screen bg-background pt-24 sm:pt-28 pb-16 sm:pb-20 overflow-x-hidden">
      <section className="max-w-6xl mx-auto px-4 sm:px-6 min-w-0">
        <PageHero
          icon={Camera}
          title="Photos en direct"
          description="Les invités peuvent partager leurs photos pendant l’événement, visibles instantanément dans la galerie."
        />


        <div className="grid min-w-0 lg:grid-cols-[360px_minmax(0,1fr)] gap-6 sm:gap-8 items-start">
          <PhotoUploadForm onUploaded={loadPhotos} />
          <WeddingPhotoGrid photos={photos} loading={loading} />
        </div>
      </section>
    </div>
  );
}