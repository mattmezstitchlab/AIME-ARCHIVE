import { useEffect, useState } from "react";
import { ShieldCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import PageHero from "../components/layout/PageHero";
import RSVPStatsSummary from "../components/admin/RSVPStatsSummary";
import RSVPResponseTable from "../components/admin/RSVPResponseTable";
import AdminMomentContributions from "../components/admin/AdminMomentContributions";
import CeriseInsightCard from "../components/cerise/CeriseInsightCard";

export default function AdminRSVP() {
  const [rsvps, setRsvps] = useState([]);
  const [contributions, setContributions] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadRsvps = async () => {
    const items = await base44.entities.RSVP.list("-created_date", 200);
    setRsvps(items);
  };

  const loadContributions = async () => {
    const items = await base44.entities.MomentContribution.list("-created_date", 100);
    setContributions(items);
  };

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me();
      setUser(me);
      if (me?.role === "admin") {
        await loadRsvps();
        await loadContributions();
      }
      setLoading(false);
    };

    init();
    const unsubscribeRsvps = base44.entities.RSVP.subscribe(() => {
      if (user?.role === "admin") loadRsvps();
    });
    const unsubscribeContributions = base44.entities.MomentContribution.subscribe(() => {
      if (user?.role === "admin") loadContributions();
    });
    return () => {
      unsubscribeRsvps();
      unsubscribeContributions();
    };
  }, [user?.role]);

  if (loading) {
    return <div className="min-h-screen pt-32 text-center font-bold text-muted-foreground">Chargement du tableau de bord...</div>;
  }

  if (user?.role !== "admin") {
    return <div className="min-h-screen pt-32 text-center font-black">Accès réservé à l’admin.</div>;
  }

  return (
    <div className="min-h-screen bg-background pt-28 pb-20">
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <PageHero
          badge={<><ShieldCheck className="w-4 h-4" /> Admin RSVP live</>}
          title="Tableau de bord RSVP"
          description="Suivez les réponses en temps réel, les présences confirmées et les préférences de repas."
        />

        <div className="mb-8">
          <CeriseInsightCard
            context="Rapports admin — Cerise synthétise sans exposer inutilement les données invitées."
            insights={[
              {
                id: "admin-rsvp-report",
                priority: "Done",
                diagnosis: "Le reporting RSVP et les contributions sont centralisés pour l’admin.",
                clear: "Les réponses, repas et contributions remontent dans le tableau de bord.",
                missing: "Validation humaine avant toute relance externe.",
                attention: "Les allergies et notes invitées restent sensibles.",
                action: "Lire les points à relancer puis valider le message doux.",
                automation: "Rapport RSVP quotidien et relances internes.",
                validation: true,
              },
            ]}
          />
        </div>

        <div className="grid lg:grid-cols-[420px_1fr] gap-8 items-start">
          <RSVPStatsSummary rsvps={rsvps} />
          <div className="space-y-8">
            <RSVPResponseTable rsvps={rsvps} />
            <AdminMomentContributions contributions={contributions} />
          </div>
        </div>
      </section>
    </div>
  );
}