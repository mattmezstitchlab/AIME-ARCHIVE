import { CalendarDays, Camera, Info } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import PublicTimeline from "../components/wedding/PublicTimeline";
import FAQSection from "../components/wedding/FAQSection";

export default function Guests() {
  return (
    <div className="min-h-screen bg-background pt-28 pb-20">
      <section className="relative max-w-5xl mx-auto px-4 sm:px-6">
        <div className="pointer-events-none absolute -top-10 left-8 h-28 w-28 rounded-[2rem] bg-red-50 blur-2xl" />
        <div className="pointer-events-none absolute top-24 right-4 h-36 w-36 rounded-full bg-muted blur-3xl" />
        <div className="relative text-center mb-12">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl bg-primary text-primary-foreground">
            <CalendarDays className="h-8 w-8" />
          </div>
          <h1 className="text-5xl font-black tracking-tight text-foreground sm:text-7xl">Espace invités</h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg font-semibold leading-relaxed text-foreground/72">Retrouvez les moments publics de la journée et les informations pratiques, sans notes privées ni contacts prestataires.</p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <Button asChild className="rounded-full bg-primary px-6 text-primary-foreground hover:bg-primary/90">
              <Link to="/WeddingPhotos"><Camera className="h-4 w-4" /> Partager mes photos</Link>
            </Button>
            <Button asChild variant="outline" className="rounded-full border-border bg-white px-6 text-foreground hover:bg-muted hover:text-foreground">
              <a href="#infos"><Info className="h-4 w-4" /> Infos pratiques</a>
            </Button>
          </div>
        </div>


        <PublicTimeline />
      </section>

      <div id="infos" className="mt-10">
        <FAQSection />
      </div>
    </div>
  );
}