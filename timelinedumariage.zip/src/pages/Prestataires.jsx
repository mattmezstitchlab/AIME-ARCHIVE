import { BriefcaseBusiness } from "lucide-react";
import PageHero from "../components/layout/PageHero";
import ProviderTimeline from "../components/wedding/ProviderTimeline";

export default function Prestataires() {
  return (
    <div className="min-h-screen bg-background pt-28 pb-20">
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <PageHero
          icon={BriefcaseBusiness}
          title="Espace prestataires"
          description="Une vue claire des moments concernés, avec contacts utiles et plans d’accès centralisés."
        />


        <ProviderTimeline />
      </section>
    </div>
  );
}