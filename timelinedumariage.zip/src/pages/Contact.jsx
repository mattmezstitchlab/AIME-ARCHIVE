import { Mail, MessageCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Contact() {
  return (
    <div className="min-h-screen bg-background pt-28 pb-20">
      <section className="mx-auto max-w-4xl px-6">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl aime-glass-strong text-primary">
            <MessageCircle className="h-8 w-8" />
          </div>
          <p className="mb-3 text-xs font-black uppercase tracking-[0.28em] text-primary">Contact</p>
          <h1 className="text-5xl font-semibold tracking-[-0.08em] text-foreground sm:text-7xl" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>
            Contact AIME
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg font-semibold text-muted-foreground">
            Une question, une idée ou un besoin pour votre mariage ? Écrivez-nous, on vous répondra avec plaisir.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-[2.5rem] border border-border bg-white/86 p-7 shadow-[0_18px_54px_rgba(23,21,17,0.06)]">
            <Mail className="mb-5 h-8 w-8 text-primary" />
            <h2 className="mb-3 text-2xl font-black text-foreground">Email</h2>
            <p className="mb-5 text-sm font-semibold leading-relaxed text-muted-foreground">
              Pour toute demande, vous pouvez nous contacter directement à cette adresse.
            </p>
            <a href="mailto:hello@aime-wedding.app" className="break-all rounded-full bg-primary px-4 py-2 text-sm font-black text-primary-foreground">
              hello@aime-wedding.app
            </a>
          </div>

          <form className="rounded-[2.5rem] border border-border bg-card p-7 text-card-foreground shadow-[0_18px_54px_rgba(23,21,17,0.06)]">
            <h2 className="mb-5 text-2xl font-black">Envoyer un message</h2>
            <div className="space-y-4">
              <Input placeholder="Votre nom" className="rounded-2xl border-card-foreground/15 bg-background text-foreground" />
              <Input type="email" placeholder="Votre email" className="rounded-2xl border-card-foreground/15 bg-background text-foreground" />
              <Textarea placeholder="Votre message" className="min-h-32 rounded-2xl border-card-foreground/15 bg-background text-foreground" />
              <Button type="button" className="w-full rounded-full font-black">
                <Send className="h-4 w-4" /> Envoyer
              </Button>
            </div>
          </form>
        </div>
      </section>
    </div>
  );
}