import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const questions = [
  {
    question: "Où se garer le jour du mariage ?",
    answer: "Un parking invité sera indiqué à l’entrée du domaine. Prévoyez d’arriver 20 minutes avant la cérémonie pour vous installer tranquillement.",
  },
  {
    question: "Quel est le code vestimentaire ?",
    answer: "Tenue élégante et confortable recommandée. Les tons doux, naturels ou pastel sont parfaits pour l’ambiance du mariage.",
  },
  {
    question: "Les enfants sont-ils les bienvenus ?",
    answer: "Oui, les enfants sont les bienvenus. Une option repas enfant est disponible dans le formulaire RSVP.",
  },
  {
    question: "Que faire en cas d’allergie alimentaire ?",
    answer: "Indiquez simplement vos allergies ou contraintes dans le champ notes du RSVP, nous transmettrons l’information au traiteur.",
  },
];

export default function FAQSection() {
  return (
    <section className="bg-transparent py-20">
      <div className="mx-auto max-w-4xl px-6">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
            <HelpCircle className="h-6 w-6" />
          </div>
          <h2 className="text-4xl font-black tracking-tight text-foreground">
            Questions fréquentes
          </h2>
          <p className="mt-3 text-base font-semibold text-muted-foreground">Toutes les informations pratiques pour profiter sereinement de la journée.</p>
        </div>

        <Accordion type="single" collapsible className="rounded-[2rem] border border-border bg-white/86 px-6 text-foreground shadow-[0_18px_54px_rgba(23,21,17,0.06)]">
          {questions.map((item, index) => (
            <AccordionItem key={item.question} value={`item-${index}`} className="border-border">
              <AccordionTrigger className="text-left font-black text-foreground hover:no-underline">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="font-semibold leading-relaxed text-muted-foreground">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}