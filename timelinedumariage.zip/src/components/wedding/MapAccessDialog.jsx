import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MapPin } from "lucide-react";

const locationQueries = {
  "Hébergement des mariés": "hotel de charme mariage domaine France",
  "Suite des mariés": "suite nuptiale domaine mariage France",
  "Chambre du marié": "domaine mariage France",
  "Suite & jardins": "jardin domaine mariage France",
  "Jardin privé": "jardin privé domaine mariage France",
  "Salon privé": "salon privé domaine mariage France",
  "Entrée du domaine": "entrée domaine mariage France",
  "Jardin principal": "jardin principal domaine mariage France",
  "Allée de cérémonie": "allée cérémonie mariage France",
  "Sortie cérémonie": "lieu cérémonie mariage France",
  "Terrasse ouest": "terrasse domaine mariage France",
  "Espace cocktail": "espace cocktail mariage France",
  "Salle de réception": "salle de réception mariage France",
  "Piste de danse": "piste de danse salle réception mariage France",
  "Espace buffet": "buffet mariage salle réception France",
  "Sortie du domaine": "sortie domaine mariage France",
  "Espace lounge": "lounge domaine mariage France",
};

export default function MapAccessDialog({ moment, open, onOpenChange }) {
  if (!moment) return null;

  const query = encodeURIComponent(locationQueries[moment.location] || moment.location);
  const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=-2.2%2C43.4%2C7.8%2C49.4&layer=mapnik&marker=46.7%2C2.4`;
  const directionsUrl = `https://www.google.com/maps/search/?api=1&query=${query}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl rounded-[2.5rem] overflow-hidden p-0">
        <div className="p-6 sm:p-8 pb-4">
          <DialogHeader>
            <DialogTitle className="text-2xl sm:text-3xl font-black flex items-center gap-3" >
              <MapPin className="w-6 h-6" /> Plan d'accès
            </DialogTitle>
          </DialogHeader>
          <p className="mt-2 text-sm font-bold text-muted-foreground">{moment.title} — {moment.location}</p>
        </div>

        <div className="h-[420px] bg-muted">
          <iframe
            title={`Plan ${moment.location}`}
            src={mapUrl}
            className="w-full h-full border-0"
            loading="lazy"
          />
        </div>

        <div className="p-6 pt-4 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
          <p className="text-xs font-bold text-muted-foreground">Carte interactive indicative. Ouvre l’itinéraire pour localiser précisément le lieu.</p>
          <a href={directionsUrl} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-2xl bg-foreground px-5 py-3 text-sm font-black text-background hover:bg-foreground/90">
            Ouvrir l’itinéraire
          </a>
        </div>
      </DialogContent>
    </Dialog>
  );
}