import { useState } from "react";
import { CheckCircle2, Circle } from "lucide-react";

const checklistByMoment = {
  "wake-up": ["Petit-déjeuner servi", "Tenues sorties", "Planning relu"],
  beauty: ["Coiffeuse arrivée", "Maquillage validé", "Retouches prêtes"],
  "groom-prep": ["Costume complet", "Boutonnière posée", "Accessoires vérifiés"],
  "bride-dress": ["Robe ajustée", "Bijoux portés", "Bouquet remis"],
  "prep-photos": ["Alliances photographiées", "Détails capturés", "Portraits terminés"],
  "first-look": ["Lieu discret prêt", "Photographe placé", "Mariés synchronisés"],
  "light-lunch": ["Repas léger servi", "Boissons disponibles", "Départ anticipé"],
  departure: ["Voitures prêtes", "Cortège organisé", "Coordonnées partagées"],
  "guest-arrival": ["Signalétique installée", "Livrets distribués", "Accueil en place"],
  procession: ["Ordre du cortège confirmé", "Musique d’entrée prête", "Enfants placés"],
  ceremony: ["Vœux prêts", "Alliances confiées", "Officiant installé"],
  "ceremony-exit": ["Confettis distribués", "Sortie dégagée", "Photo sortie prévue"],
  congratulations: ["File fluide", "Eau disponible", "Timing surveillé"],
  "group-photos": ["Liste groupes prête", "Familles appelées", "Photographe guidé"],
  "couple-photos": ["Lieu réservé", "Bouquet présent", "Retour cocktail prévu"],
  cocktail: ["Boissons servies", "Bouchées lancées", "Ambiance musicale active"],
  guestbook: ["Livre d’or ouvert", "Photobooth prêt", "Animations lancées"],
  seating: ["Plan de table visible", "Invités orientés", "Salle prête"],
  "newlyweds-entry": ["Musique d’entrée calée", "Portes prêtes", "DJ synchronisé"],
  speeches: ["Micro testé", "Intervenants prévenus", "Timing respecté"],
  dinner: ["Service coordonné", "Allergies vérifiées", "Animations espacées"],
  "dinner-games": ["Matériel prêt", "Témoins briefés", "DJ informé"],
  cake: ["Pièce montée prête", "Champagne servi", "Couteau disponible"],
  "first-dance": ["Titre lancé", "Piste dégagée", "Photographe placé"],
  party: ["Playlist lancée", "Bar ouvert", "Lumières soirée actives"],
  "night-buffet": ["Buffet installé", "Boissons réassorties", "Invités informés"],
  "official-end": ["Navettes confirmées", "Taxis appelés", "Sortie accompagnée"],
  after: ["Espace lounge ouvert", "Volume adapté", "Derniers retours organisés"],
};

export default function MomentChecklist({ moment }) {
  const tasks = checklistByMoment[moment.id] || ["Responsable confirmé", "Lieu prêt", "Timing validé"];
  const [checked, setChecked] = useState([]);

  const toggleTask = (task) => {
    setChecked((items) => items.includes(task) ? items.filter((item) => item !== task) : [...items, task]);
  };

  return (
    <div className="space-y-1.5">
      {tasks.map((task) => {
        const done = checked.includes(task);
        return (
          <button
            key={task}
            type="button"
            onClick={(event) => {
              event.stopPropagation();
              toggleTask(task);
            }}
            className="flex w-full items-center justify-center gap-2 text-center text-xs font-bold text-muted-foreground hover:text-foreground"
          >
            {done ? <CheckCircle2 className="w-4 h-4 text-foreground" /> : <Circle className="w-4 h-4" />}
            <span className={done ? "line-through" : ""}>{task}</span>
          </button>
        );
      })}
    </div>
  );
}