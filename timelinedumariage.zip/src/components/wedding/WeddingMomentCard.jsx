import { useState } from "react";
import { Clock, Map, Pencil, RotateCcw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import PeopleOrbit from "./PeopleOrbit";
import WeddingMomentBack from "./WeddingMomentBack";
import MomentAlertBadge from "./MomentAlertBadge";

const typeStyles = {
  ceremony: "bg-foreground text-background",
  dinner: "bg-foreground text-background",
  party: "bg-foreground text-background",
  prep: "bg-foreground text-background",
};

export default function WeddingMomentCard({ moment, index, onEdit }) {
  const [flipped, setFlipped] = useState(false);

  const toggleFlip = () => setFlipped((current) => !current);

  return (
    <div className="relative flex w-full min-w-0 flex-col items-center group pb-14 sm:pb-20 overflow-visible">
      <div className="relative z-10 mb-5 px-4">
        <span className="inline-flex min-w-20 justify-center rounded-full time-pill-flat px-4 py-2 text-sm sm:text-base font-black">
          {moment.time}
        </span>
      </div>

      <div className="relative z-10 w-full max-w-[min(92vw,36rem)] min-w-0 aspect-square flex items-center justify-center my-4 overflow-visible">
        <PeopleOrbit people={moment.people} />
        <MomentAlertBadge moment={moment} />

        <div
          role="button"
          tabIndex={0}
          onClick={toggleFlip}
          onKeyDown={(event) => {
            if (event.key === "Enter" || event.key === " ") toggleFlip();
          }}
          className="relative z-20 w-[68%] min-w-[210px] max-w-[360px] aspect-square cursor-pointer outline-none [perspective:1200px]"
          aria-label="Voir les détails du moment"
        >
          <div className={`relative h-full w-full transition-transform duration-700 [transform-style:preserve-3d] ${flipped ? "[transform:rotateY(180deg)]" : ""}`}>
            <div className="absolute inset-0 neu-surface rounded-[2rem] sm:rounded-[2.5rem] p-4 sm:p-8 transition-all duration-300 text-center flex items-center justify-center [backface-visibility:hidden]">
              <div className="flex flex-col items-center justify-center gap-4">
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <Badge className={`${typeStyles[moment.type] || typeStyles.prep} rounded-full px-3 py-1 uppercase tracking-widest text-[11px]`}>
                    {moment.label}
                  </Badge>
                  <span className="inline-flex items-center gap-1 text-xs font-bold time-pill-soft px-3 py-1 rounded-full">
                    <Clock className="w-3.5 h-3.5" />
                    {moment.duration}
                  </span>
                </div>

                <div>
                  <h3 className="mb-2 text-base font-black uppercase leading-tight tracking-wide text-foreground sm:mb-3 sm:text-2xl">
                    {moment.title}
                  </h3>
                  <p className="mx-auto max-w-xl text-xs leading-relaxed text-foreground/72 sm:text-base line-clamp-3">{moment.description}</p>
                </div>

                <div className="flex flex-col items-center justify-center gap-2 text-sm font-bold text-foreground">
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      window.dispatchEvent(new CustomEvent("openMomentMap", { detail: moment }));
                    }}
                    className="inline-flex items-center justify-center gap-3 text-foreground hover:text-primary transition-colors"
                    title="Plan d'accès"
                  >
                    <Map className="w-6 h-6" />
                    <span className="min-w-0 break-words">{moment.location}</span>
                  </button>

                </div>

                <div className="flex flex-col items-center gap-2">
                  <span className="inline-flex items-center gap-1 text-[10px] sm:text-[11px] font-black uppercase tracking-widest text-muted-foreground">
                    <RotateCcw className="w-3.5 h-3.5" /> Tap pour détails
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={(event) => {
                      event.stopPropagation();
                      onEdit(moment);
                    }}
                    className="h-8 rounded-full px-3 text-foreground hover:text-foreground hover:bg-muted"
                    title="Modifier"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Modifier
                  </Button>
                </div>
              </div>
            </div>
            <div className="absolute inset-0 neu-surface rounded-[2.5rem] p-5 sm:p-6 [backface-visibility:hidden] [transform:rotateY(180deg)]">
              {flipped && <WeddingMomentBack moment={moment} />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}