export default function LivingConnection({ className = "", delay = "0s", vertical = false }) {
  return (
    <div className={`pointer-events-none relative overflow-hidden bg-white/12 ${vertical ? "h-16 w-px" : "h-px w-full"} ${className}`}>
      <span
        className={`absolute rounded-full bg-primary shadow-[0_0_18px_rgba(205,255,10,0.9)] ${vertical ? "left-1/2 top-0 h-2 w-2 -translate-x-1/2 animate-network-flow-y" : "left-0 top-1/2 h-2 w-2 -translate-y-1/2 animate-network-flow-x"}`}
        style={{ animationDelay: delay }}
      />
      <span
        className={`absolute rounded-full bg-blue-400 shadow-[0_0_18px_rgba(96,165,250,0.9)] ${vertical ? "left-1/2 top-0 h-1.5 w-1.5 -translate-x-1/2 animate-network-flow-y" : "left-0 top-1/2 h-1.5 w-1.5 -translate-y-1/2 animate-network-flow-x"}`}
        style={{ animationDelay: `calc(${delay} + 1.1s)` }}
      />
    </div>
  );
}