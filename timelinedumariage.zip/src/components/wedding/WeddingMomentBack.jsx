import { useEffect, useState } from "react";
import { ClipboardCheck, Inbox } from "lucide-react";
import { base44 } from "@/api/base44Client";
import MomentChecklist from "./MomentChecklist";
import MomentContributions from "./MomentContributions";

export default function WeddingMomentBack({ moment }) {
  const [contributions, setContributions] = useState([]);

  useEffect(() => {
    const loadContributions = () => {
      base44.entities.MomentContribution.filter({ moment_id: moment.id }, "-created_date", 5).then(setContributions);
    };
    loadContributions();
    const unsubscribe = base44.entities.MomentContribution.subscribe(loadContributions);
    return unsubscribe;
  }, [moment.id]);

  return (
    <div className="h-full w-full overflow-y-auto text-left">
      <div className="min-h-full py-2">
        <div className="flex items-center justify-center gap-2 text-sm font-black mb-3">
          <ClipboardCheck className="w-5 h-5" /> Checklist
        </div>
        <MomentChecklist moment={moment} />
        <div className="mt-4 border-t border-border pt-3">
          <div className="mb-2 flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest text-muted-foreground">
            <Inbox className="h-4 w-4" /> Contributions invités
          </div>
          <MomentContributions contributions={contributions} compact />
        </div>
      </div>
    </div>
  );
}