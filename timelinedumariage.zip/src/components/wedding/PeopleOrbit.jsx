import { useState } from "react";
import { MessageCircle } from "lucide-react";

export default function PeopleOrbit({ people = [] }) {
  const visiblePeople = people.slice(0, 8);
  const [activePerson, setActivePerson] = useState(null);

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none sm:pointer-events-auto">
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes momentOrbit {
          from { transform: rotate(0deg) translateX(var(--orbit-radius)) rotate(0deg); }
          to { transform: rotate(360deg) translateX(var(--orbit-radius)) rotate(-360deg); }
        }
      ` }} />

      {visiblePeople.map((person, index) => {
        const size = index % 2 === 0 ? "w-12 h-12 sm:w-24 sm:h-24" : "w-10 h-10 sm:w-20 sm:h-20";

        return (
          <button
            key={person.id}
            type="button"
            onClick={(event) => {
              event.stopPropagation();
              setActivePerson((current) => current === person.id ? null : person.id);
            }}
            className={`group/contact absolute ${size} rounded-full neu-photo-ring bg-muted overflow-hidden pointer-events-auto transition-transform duration-300 hover:scale-105`}
            style={{
              "--orbit-radius": "clamp(145px, 42vw, 260px)",
              animation: "momentOrbit 42s linear infinite",
              animationDelay: `${index * -5}s`,
            }}
            title={`${person.name} — ${person.role}`}
          >
            <div className={`absolute inset-0 transition-transform duration-500 [transform-style:preserve-3d] ${activePerson === person.id ? "[transform:rotateY(180deg)]" : ""}`}>
              <img src={person.avatar} alt={person.name} className="absolute inset-0 w-full h-full object-cover [backface-visibility:hidden]" />
              <div className="absolute inset-0 flex items-center justify-center gap-2 bg-foreground/85 [backface-visibility:hidden] [transform:rotateY(180deg)]">
              <a
                href={`sms:${person.phone || "+33600000000"}`}
                onClick={(event) => event.stopPropagation()}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-background text-foreground shadow-lg hover:scale-110 transition-transform"
                title={`Message à ${person.name}`}
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
}