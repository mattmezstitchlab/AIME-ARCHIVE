import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import GuestMomentCard from "./GuestMomentCard";
import MapAccessDialog from "./MapAccessDialog";
import { initialWeddingMoments } from "./weddingData";

const publicMoments = initialWeddingMoments.filter((moment) => moment.type !== "prep");

export default function PublicTimeline() {
  const [contributions, setContributions] = useState([]);
  const [mapMoment, setMapMoment] = useState(null);

  const loadContributions = () => base44.entities.MomentContribution.list("-created_date").then(setContributions);

  useEffect(() => {
    loadContributions();
    const unsubscribe = base44.entities.MomentContribution.subscribe(loadContributions);
    return unsubscribe;
  }, []);

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2">
        {publicMoments.map((moment) => (
          <GuestMomentCard
            key={moment.id}
            moment={moment}
            contributions={contributions.filter((item) => item.moment_id === moment.id)}
            onContributionSubmitted={loadContributions}
            onOpenMap={setMapMoment}
          />
        ))}
      </div>
      <MapAccessDialog
        moment={mapMoment}
        open={Boolean(mapMoment)}
        onOpenChange={(open) => !open && setMapMoment(null)}
      />
    </>
  );
}