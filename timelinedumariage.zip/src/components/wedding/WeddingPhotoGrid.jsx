import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, Image, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";

export default function WeddingPhotoGrid({ photos = [], loading }) {
  const [selectedPhoto, setSelectedPhoto] = useState(null);

  if (loading) {
    return <div className="py-12 text-center font-bold text-foreground/72">Chargement des photos...</div>;
  }

  if (!photos.length) {
    return (
      <div className="text-center bg-muted rounded-[2rem] p-6 sm:p-10 min-w-0">
        <Image className="mx-auto mb-3 h-10 w-10 text-foreground" />
        <p className="font-black">Aucune photo pour le moment</p>
        <p className="text-sm font-semibold text-foreground/72">Soyez le premier à partager un souvenir.</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid w-full min-w-0 grid-cols-2 md:grid-cols-3 gap-3 sm:gap-5 overflow-hidden">
        <AnimatePresence>
          {photos.map((photo) => (
            <motion.article
              key={photo.id}
              layout
              initial={{ opacity: 0, y: 24, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.35 }}
              className="group min-w-0 bg-card text-card-foreground border border-border rounded-[1.25rem] sm:rounded-[1.75rem] overflow-hidden shadow-sm"
            >
              <button type="button" onClick={() => setSelectedPhoto(photo)} className="block w-full overflow-hidden">
                <img src={photo.image_url} alt={photo.caption || "Photo du mariage"} className="w-full aspect-square object-cover group-hover:scale-105 transition-transform duration-500" />
              </button>
              {(photo.guest_name || photo.caption) && (
                <div className="p-3 sm:p-4 min-w-0 break-words">
                  {photo.guest_name && <p className="text-sm font-black">{photo.guest_name}</p>}
                  {photo.caption && <p className="text-xs text-muted-foreground font-bold mt-1">{photo.caption}</p>}
                </div>
              )}
            </motion.article>
          ))}
        </AnimatePresence>
      </div>

      <Dialog open={Boolean(selectedPhoto)} onOpenChange={(open) => !open && setSelectedPhoto(null)}>
        <DialogContent className="max-w-4xl rounded-[2rem] p-3 sm:p-4">
          {selectedPhoto && (
            <div className="space-y-3">
              <img src={selectedPhoto.image_url} alt={selectedPhoto.caption || "Photo du mariage"} className="max-h-[72vh] w-full rounded-[1.5rem] object-contain bg-muted" />
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  {selectedPhoto.guest_name && <p className="font-black">{selectedPhoto.guest_name}</p>}
                  {selectedPhoto.caption && <p className="text-sm font-bold text-muted-foreground">{selectedPhoto.caption}</p>}
                </div>
                <div className="flex gap-2">
                  <Button asChild className="rounded-full bg-foreground text-background">
                    <a href={selectedPhoto.image_url} download target="_blank" rel="noreferrer"><Download className="h-4 w-4" /> Télécharger</a>
                  </Button>
                  <Button type="button" variant="outline" className="rounded-full" onClick={() => setSelectedPhoto(null)}>
                    <X className="h-4 w-4" /> Fermer
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}