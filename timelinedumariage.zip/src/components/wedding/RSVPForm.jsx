import { useState } from "react";
import { Check, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import CeriseInsightCard from "../cerise/CeriseInsightCard";

export default function RSVPForm() {
  const [form, setForm] = useState({
    guest_name: "",
    email: "",
    attendance: "yes",
    meal_preference: "standard",
    notes: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    await base44.entities.RSVP.create(form);
    setLoading(false);
    setSubmitted(true);
  };

  return (
    <section id="rsvp" className="bg-background py-20">
      <div className="max-w-4xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-[0.9fr_1.1fr] gap-8 items-start">
          <div>
            <p className="text-xs uppercase tracking-widest text-foreground/72 font-bold mb-3">RSVP</p>
            <h2 className="text-4xl font-black text-foreground tracking-tight mb-4" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>
              Confirmer votre présence
            </h2>
            <p className="text-foreground/72 leading-relaxed">
              Merci de répondre avant la date limite afin que nous puissions organiser les repas, les places et les moments importants de la journée.
            </p>
            <div className="mt-5">
              <CeriseInsightCard
                context="RSVP — Cerise protège les informations sensibles."
                insights={[
                  {
                    id: "rsvp-soft-reminder",
                    priority: "Calm",
                    diagnosis: "Le formulaire collecte les informations essentielles sans exposer les données privées.",
                    clear: "Présence, repas et allergies sont prévus.",
                    missing: "Date limite visible pour les invités.",
                    attention: "Les relances doivent rester douces et validées.",
                    action: "Préparer une relance RSVP prête à valider.",
                    automation: "Détection des RSVP manquants.",
                    validation: true,
                  },
                ]}
              />
            </div>
          </div>

          <div className="bg-card border border-border rounded-[2rem] p-6 sm:p-8 shadow-sm">
            {submitted ? (
              <div className="text-center py-10">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-5">
                  <Check className="w-8 h-8 text-foreground" />
                </div>
                <h3 className="text-2xl font-black text-foreground mb-2">Réponse envoyée</h3>
                <p className="text-foreground/72">Merci, votre RSVP a bien été enregistré.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label className="font-black text-foreground">Nom complet</Label>
                    <Input value={form.guest_name} onChange={(e) => update("guest_name", e.target.value)} required placeholder="Votre nom" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-black text-foreground">Email</Label>
                    <Input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="vous@email.com" />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label className="font-black text-foreground">Présence</Label>
                    <Select value={form.attendance} onValueChange={(value) => update("attendance", value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yes">Je serai présent(e)</SelectItem>
                        <SelectItem value="no">Je ne pourrai pas venir</SelectItem>
                        <SelectItem value="maybe">À confirmer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="font-black text-foreground">Repas</Label>
                    <Select value={form.meal_preference} onValueChange={(value) => update("meal_preference", value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">Menu classique</SelectItem>
                        <SelectItem value="vegetarian">Végétarien</SelectItem>
                        <SelectItem value="vegan">Vegan</SelectItem>
                        <SelectItem value="gluten_free">Sans gluten</SelectItem>
                        <SelectItem value="child">Menu enfant</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="font-black text-foreground">Allergies ou note privée</Label>
                  <Textarea value={form.notes} onChange={(e) => update("notes", e.target.value)} placeholder="Allergies, contraintes, accompagnant — transmis uniquement aux mariés" />
                </div>

                <Button type="submit" disabled={loading} className="w-full h-12 rounded-2xl bg-foreground text-background font-bold">
                  <Send className="w-4 h-4 mr-2" />
                  {loading ? "Envoi..." : "Envoyer mon RSVP"}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}