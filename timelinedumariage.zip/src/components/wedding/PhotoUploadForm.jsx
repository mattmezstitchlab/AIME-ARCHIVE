import { useState } from "react";
import { Camera, Upload } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function PhotoUploadForm({ onUploaded }) {
  const [guestName, setGuestName] = useState("");
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!file) return;

    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.WeddingPhoto.create({
      guest_name: guestName,
      caption,
      image_url: file_url,
    });
    setGuestName("");
    setCaption("");
    setFile(null);
    setUploading(false);
    onUploaded?.();
  };

  return (
    <form onSubmit={handleSubmit} className="w-full min-w-0 bg-card text-card-foreground border border-border rounded-[2rem] p-5 sm:p-6 shadow-sm space-y-4 overflow-hidden">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-foreground text-background flex items-center justify-center">
          <Camera className="w-6 h-6" />
        </div>
        <div className="min-w-0">
          <h2 className="text-xl font-black break-words" >Partager une photo</h2>
          <p className="break-words text-sm font-semibold text-foreground/72">Ajoutez vos meilleurs moments en direct.</p>
        </div>
      </div>

      <Input value={guestName} onChange={(event) => setGuestName(event.target.value)} placeholder="Votre nom" />
      <Textarea value={caption} onChange={(event) => setCaption(event.target.value)} placeholder="Un petit mot..." />
      <Input type="file" accept="image/*" onChange={(event) => setFile(event.target.files?.[0] || null)} />

      <Button type="submit" disabled={!file || uploading} className="w-full rounded-full">
        <Upload className="w-4 h-4" /> {uploading ? "Envoi..." : "Uploader la photo"}
      </Button>
    </form>
  );
}