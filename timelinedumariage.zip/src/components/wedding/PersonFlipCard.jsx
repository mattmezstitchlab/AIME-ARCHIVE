import { useState } from "react";
import { ArrowUpRight, ClipboardCheck, ListChecks, Phone, UserRoundCheck } from "lucide-react";
import { initialWeddingMoments } from "./weddingData";

export default function PersonFlipCard({ person, compact = false }) {
  const [flipped, setFlipped] = useState(false);
  const linkedMoments = initialWeddingMoments.filter((moment) => moment.people?.some((p) => p.id === person.id));
  const tasks = person.tasks || ["Recevoir les infos clés", "Confirmer son créneau", "Rester joignable"];

  return (
    <button
      type="button"
      onClick={() => setFlipped((current) => !current)}
      className={`relative text-left outline-none [perspective:1200px] ${compact ? "h-[260px] w-full max-w-[230px]" : "h-[315px] w-full max-w-[285px]"}`}
      aria-label={`Voir les actions liées à ${person.name}`}
    >
      <div className={`relative h-full w-full transition-transform duration-700 [transform-style:preserve-3d] ${flipped ? "[transform:rotateY(180deg)]" : ""}`}>
        <div className="absolute inset-0 flex flex-col items-center justify-center rounded-[2rem] border border-white/8 bg-muted p-6 text-center text-foreground shadow-[0_24px_70px_rgba(0,0,0,0.22)] [backface-visibility:hidden]">
          <div className={`${compact ? "h-24 w-24" : "h-32 w-32"} mb-5 overflow-hidden rounded-full border-4 border-background shadow-xl`}>
            <img src={person.avatar} alt={person.name} className="h-full w-full object-cover" />
          </div>
          <h3 className="text-2xl font-black tracking-[-0.05em] text-foreground" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>{person.name}</h3>
          <p className="mt-1 text-sm font-bold text-muted-foreground">{person.role}</p>
          <span className="mt-3 rounded-full bg-background px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-foreground/70">{person.branch}</span>
          <span className="absolute bottom-4 right-4 flex h-11 w-11 items-center justify-center rounded-full border border-border bg-background text-foreground">
            <ArrowUpRight className="h-5 w-5" />
          </span>
        </div>

        <div className="absolute inset-0 overflow-hidden rounded-[2rem] border border-white/10 bg-card p-5 text-card-foreground [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <div className="mb-4 flex items-center gap-3">
            <img src={person.avatar} alt={person.name} className="h-14 w-14 rounded-full border-4 border-background object-cover" />
            <div>
              <h3 className="text-xl font-black tracking-[-0.04em]" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>{person.name}</h3>
              <p className="text-xs font-bold text-card-foreground/55">{person.role}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <span className="rounded-2xl bg-background p-3 text-foreground"><Phone className="mx-auto h-4 w-4" /><small className="mt-1 block text-[10px] font-black">Appel</small></span>
            <span className="rounded-2xl bg-background p-3 text-foreground"><ListChecks className="mx-auto h-4 w-4" /><small className="mt-1 block text-[10px] font-black">Tâches</small></span>
            <span className="rounded-2xl bg-background p-3 text-foreground"><ClipboardCheck className="mx-auto h-4 w-4" /><small className="mt-1 block text-[10px] font-black">À faire</small></span>
          </div>

          <div className="mt-4 space-y-2">
            {tasks.slice(0, 3).map((task) => (
              <div key={task} className="flex items-center gap-2 rounded-2xl bg-background/70 px-3 py-2 text-xs font-bold text-foreground">
                <UserRoundCheck className="h-3.5 w-3.5" /> {task}
              </div>
            ))}
          </div>

          {linkedMoments.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {linkedMoments.slice(0, 3).map((moment) => (
                <span key={moment.id} className="rounded-full bg-primary px-2.5 py-1 text-[10px] font-black text-primary-foreground">
                  {moment.time} · {moment.label}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </button>
  );
}