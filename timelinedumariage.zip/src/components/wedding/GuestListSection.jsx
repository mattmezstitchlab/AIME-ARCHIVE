import LivingPeopleTree from "./LivingPeopleTree";

export default function GuestListSection() {
  return <LivingPeopleTree />;
}