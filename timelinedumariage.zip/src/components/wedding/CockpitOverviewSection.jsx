import { useEffect, useMemo, useState } from "react";
import { CalendarDays, Camera, Clock, HeartHandshake, Images, ListChecks, Sparkles, Users } from "lucide-react";
import { loadLivingTimelineItems } from "@/lib/timelineAdapter";
import { initialWeddingMoments } from "./weddingData";

const cards = [
  { title: "Timeline", text: "Voir les moments clés et le rythme du Jour J.", href: "#timeline", icon: ListChecks },
  { title: "RSVP", text: "Confirmer une présence, un repas ou une contrainte.", href: "#rsvp", icon: CalendarDays },
  { title: "Invités", text: "Accéder aux informations utiles côté invités.", href: "/Guests", icon: Users },
  { title: "Photos", text: "Retrouver les souvenirs partagés par les invités.", href: "/WeddingPhotos", icon: Images },
];

export default function CockpitOverviewSection() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    loadLivingTimelineItems().then(setItems);
  }, []);

  const nextMoment = useMemo(() => initialWeddingMoments.find((moment) => moment.time >= "14:30") || initialWeddingMoments[0], []);
  const toConfirm = items.filter((item) => item.status === "to_confirm" || item.priority === "To confirm").length;
  const cerisePriority = items.find((item) => item.source === "cerise" && ["Urgent", "Needs attention", "To confirm"].includes(item.priority));

  const watchItems = [
    { label: "État global", value: toConfirm > 0 ? "À vérifier" : "Calme", detail: toConfirm > 0 ? `${toConfirm} confirmation(s) à relire` : "Aucun signal critique", icon: HeartHandshake },
    { label: "Prochain moment", value: nextMoment?.time || "—", detail: nextMoment?.title || "Timeline prête", icon: Clock },
    { label: "Action prioritaire", value: cerisePriority?.priority || "Prêt", detail: cerisePriority?.title || "La journée reste lisible", icon: Sparkles },
  ];

  return (
    <section className="mx-auto max-w-6xl px-4 pb-8 sm:px-6">
      <div className="grid gap-5 lg:grid-cols-[1fr_0.9fr]">
        <div className="rounded-[2.25rem] border border-border bg-white/86 p-5 shadow-[0_18px_54px_rgba(23,21,17,0.06)] sm:p-6">
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><HeartHandshake className="h-4 w-4" /></div>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-accent">Vue couple immédiate</p>
              <h2 className="text-2xl font-black tracking-tight text-foreground">Comprendre le mariage en 5 secondes</h2>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {watchItems.map((item) => {
              const Icon = item.icon;
              return (
                <article key={item.label} className="rounded-[1.65rem] border border-foreground/10 bg-[#FBF7F0] p-4">
                  <Icon className="mb-4 h-4 w-4 text-accent" />
                  <p className="text-[11px] font-black uppercase tracking-[0.16em] text-foreground/72">{item.label}</p>
                  <p className="mt-2 text-2xl font-black text-foreground">{item.value}</p>
                  <p className="mt-1 text-sm font-semibold leading-snug text-foreground/72">{item.detail}</p>
                </article>
              );
            })}
          </div>
        </div>

        <div className="rounded-[2.25rem] border border-border bg-white/86 p-5 shadow-[0_18px_54px_rgba(23,21,17,0.06)] sm:p-6">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-accent">Accès utiles</p>
          <p className="mt-2 text-sm font-semibold text-foreground/72">Le Widget AIME reste la navigation principale ; ces raccourcis servent uniquement la lecture immédiate.</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {cards.map((card) => {
              const Icon = card.icon;
              return (
                <a key={card.title} href={card.href} className="group rounded-[1.65rem] border border-border bg-[#FBF7F0] p-4 transition-colors duration-200 hover:bg-muted">
                  <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Icon className="h-4 w-4" /></div>
                  <p className="text-sm font-black text-foreground">{card.title}</p>
                  <p className="mt-1 text-xs font-semibold leading-relaxed text-foreground/72">{card.text}</p>
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}