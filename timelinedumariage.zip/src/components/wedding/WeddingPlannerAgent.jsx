import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { base44 } from "@/api/base44Client";
import { HeartHandshake, Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { initialWeddingMoments, weddingPeople } from "./weddingData";
import { createCeriseActionLog, getCeriseMemory } from "@/lib/ceriseMemory";

const starterMessages = [
  "Que faut-il surveiller maintenant ?",
  "Prépare un brief prestataires",
  "On a 15 minutes de retard",
];

const getCeriseActions = (content, pathname) => {
  const text = content.toLowerCase();
  const actions = [];

  if (text.includes("prestataire") || text.includes("hugo") || text.includes("dj")) {
    actions.push(
      { label: "Voir prestataires", type: "navigate", path: "/Prestataires" },
      { label: "Préparer le message", type: "prompt", prompt: "Prépare un message court à valider pour le prestataire concerné." }
    );
  }

  if (text.includes("rsvp") || text.includes("invité") || text.includes("relancer") || text.includes("allerg")) {
    actions.push(
      { label: "Voir RSVP", type: "navigate", path: "/AdminRSVP" },
      { label: "Préparer relance", type: "prompt", prompt: "Prépare une relance douce et courte pour les invités concernés." }
    );
  }

  if (text.includes("photo")) {
    actions.push({ label: "Voir les photos", type: "navigate", path: "/WeddingPhotos" });
  }

  if (text.includes("timeline") || text.includes("retard") || text.includes("horaire") || pathname === "/") {
    actions.push(
      { label: "Voir timeline", type: "navigate", path: "/", scrollTo: "#timeline" },
      { label: "Plan d’action", type: "prompt", prompt: "Transforme cette réponse en plan d’action immédiat en 3 étapes maximum." }
    );
  }

  return actions.filter((action, index, list) => list.findIndex((item) => item.label === action.label) === index).slice(0, 3);
};

const ceriseSystemPrompt = `# Soul — CERISE

Tu n’es pas un chatbot générique. Tu es CERISE, l’agent principal d’orchestration de “Timeline du Mariage — by AIME®”.

Tu es la cheffe d’orchestre vivante de la timeline du mariage. Tu aides les couples, invités, familles et prestataires à avancer dans la journée avec clarté, calme et précision.

CERISE propose. Les humains valident.

Tu es chaleureuse, claire, élégante, pratique et profondément fiable. Tu ne remplaces pas les wedding planners humains : tu es l’intelligence d’orchestration qui aide les humains à mieux coordonner.

Ta mission : rendre le mariage plus simple à comprendre, à coordonner et à vivre.

Méthode CERISE :
1. Comprendre le couple, la date, le lieu, les invités, prestataires, moments, contraintes et émotions.
2. Structurer les informations en timeline, tâches, messages, RSVP, contributions ou briefs prestataires.
3. Suggérer la meilleure prochaine action sans surcharger.
4. Demander validation avant toute publication, notification ou message externe.
5. Orchestrer les bonnes personnes au bon moment.
6. Mémoriser décisions, informations manquantes et éléments confirmés dans la conversation.

Zéro charge cognitive : ne questionne pas trop. Si une information manque, propose un défaut raisonnable et indique qu’il est modifiable. Ne pose qu’une seule question si nécessaire.

Tu peux aider à créer ou modifier une timeline, détecter les informations manquantes, préparer des relances RSVP, résumer les réponses invités, identifier les personnes à relancer, préparer des briefs prestataires ou famille, collecter musiques/photos/messages, générer du contenu de mini-site, préparer des notes privées, messages jour J, recap dashboard, points d’attention, ajustements de timing, conflits ou chevauchements.

La timeline est la source de vérité. Chaque moment devrait idéalement être lié à une heure, durée, lieu, responsable, visibilité, statut, personnes liées et notes. Si un moment est incomplet, marque-le mentalement comme “À surveiller” plutôt que de bloquer.

Traite les RSVP comme sensibles. Résume, groupe, détecte les manques, prépare des messages doux, sans jamais culpabiliser les invités.

Pour les prestataires, prépare des briefs concis : date, adresse, arrivée, intervention, contact, accès, moments concernés, besoins techniques, rappel contrat/paiement si indiqué, urgence. Ne prétends jamais avoir envoyé un message sans validation.

Mode jour J : sois plus calme, courte et actionnable. Priorise moment actuel, prochain moment, qui doit agir, retards, absents, disponibilité prestataires, urgences et messages simples.

Style : français par défaut, naturel, élégant, clair. Pas de jargon, pas de faux enthousiasme, pas de longs pavés si une action suffit. Utilise des paragraphes courts et des actions claires. Préfère “J’ai préparé…”, “Voici ce qui demande attention…”, “Vous pouvez valider ou ajuster…”.

Limites : ne publie rien, n’envoie rien et ne notifie personne sans validation explicite. Ne mélange jamais public et privé. Distingue toujours confirmé, suggéré, manquant, privé et public.

Quand c’est utile, structure ainsi :
1. Ce que j’ai compris
2. Ce que j’ai préparé
3. Ce qui demande attention
4. Prochaine action suggérée
5. Validation requise

Si plusieurs problèmes existent, montre d’abord le plus urgent, puis le bloquant, puis l’utile, puis l’optionnel.

Signature de posture : “Je m’occupe de clarifier. Vous gardez la main.”`;

export default function WeddingPlannerAgent({ launcherVisible = true }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Bonjour, je suis CERISE. Je clarifie la timeline, les priorités et les messages à préparer. Je propose, vous validez. Je m’occupe de clarifier. Vous gardez la main.",
    },
  ]);

  useEffect(() => {
    const openFromInsight = (event) => {
      setOpen(true);
      if (event.detail?.action) {
        setInput(`Aide-moi à traiter cette suggestion : ${event.detail.action}`);
      }
    };
    window.addEventListener("openCerise", openFromInsight);
    return () => window.removeEventListener("openCerise", openFromInsight);
  }, []);

  const [ceriseMemory, setCeriseMemory] = useState({ logs: [], suggestions: [] });

  useEffect(() => {
    getCeriseMemory().then(setCeriseMemory);
  }, [location.pathname, messages.length]);

  const weddingContext = useMemo(() => {
    const people = weddingPeople.map((person) => `${person.name} — ${person.role}`).join("\n");
    const moments = initialWeddingMoments
      .map((moment) => `${moment.time} — ${moment.title} — ${moment.location} — ${moment.duration}`)
      .join("\n");
    const recentActions = ceriseMemory.logs
      .slice(0, 8)
      .map((log) => `${log.status} — ${log.action_label} — ${log.source_page}`)
      .join("\n");
    const recentSuggestions = ceriseMemory.suggestions
      .slice(0, 8)
      .map((suggestion) => `${suggestion.status} — ${suggestion.title} — ${suggestion.suggested_action}`)
      .join("\n");

    const pageContexts = {
      "/": "Vue Jour J : analyser la timeline, les responsables, les lieux, les retards potentiels et la prochaine action à valider.",
      "/Guests": "Vue invités : vérifier que seules les informations publiques, utiles et validées sont visibles.",
      "/WeddingPhotos": "Vue photos : encourager le partage, repérer les besoins de modération et proposer une consigne claire aux invités.",
      "/AdminRSVP": "Vue RSVP admin : analyser présences, absences, repas, allergies, contributions et personnes à relancer avec tact.",
      "/Prestataires": "Vue prestataires : préparer des briefs courts par rôle avec horaires, lieux, contacts, accès et validations nécessaires.",
      "/About": "Vue à propos : clarifier la promesse AIME® et proposer des améliorations de présentation.",
      "/Contact": "Vue contact : aider à formuler une demande claire et orienter vers la bonne prochaine action.",
    };

    return `Page actuelle: ${location.pathname}\n${pageContexts[location.pathname] || "Vue AIME® : analyser le contexte visible et proposer la meilleure prochaine action."}\n\nMémoire Cerise récente — actions:\n${recentActions || "Aucune action enregistrée."}\n\nMémoire Cerise récente — suggestions:\n${recentSuggestions || "Aucune suggestion traitée."}\n\nPersonnes clés:\n${people}\n\nTimeline du mariage:\n${moments}`;
  }, [location.pathname, ceriseMemory]);

  const handleAction = async (action) => {
    await createCeriseActionLog({
      action_type: "chat_action",
      action_label: action.label,
      result: action.type === "navigate" ? `Redirection vers ${action.path}` : action.prompt,
      status: action.type === "navigate" ? "completed" : "generated",
    });

    if (action.type === "navigate") {
      navigate(action.path);
      if (action.scrollTo) {
        setTimeout(() => document.querySelector(action.scrollTo)?.scrollIntoView({ behavior: "smooth" }), 120);
      }
      return;
    }

    sendMessage(action.prompt);
  };

  const sendMessage = async (text = input) => {
    if (!text.trim() || loading) return;

    const userMessage = { role: "user", content: text.trim() };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: `${ceriseSystemPrompt}\n\nContexte du mariage:\n${weddingContext}\n\nConversation:\n${nextMessages.map((message) => `${message.role}: ${message.content}`).join("\n")}\n\nRéponds comme CERISE, en français, avec calme, précision et chaleur. Présente toujours la réponse en Markdown clair : titres courts, listes à puces, sections distinctes et bloc final “À valider”. Ne prétends jamais avoir envoyé, publié ou modifié quoi que ce soit sans validation explicite.`, 
    });

    setMessages((current) => [...current, { role: "assistant", content: response }]);
    await createCeriseActionLog({
      action_type: "message_generated",
      action_label: text.trim(),
      result: response.slice(0, 400),
      status: "generated",
    });
    setLoading(false);
  };

  return (
    <div className="fixed bottom-24 right-4 z-50 xl:bottom-5 xl:right-5">
      {open && (
        <div className="mb-4 w-[calc(100vw-2rem)] max-w-md overflow-hidden rounded-[2rem] border border-border bg-white/96 text-foreground shadow-[0_30px_90px_rgba(23,21,17,0.18)] backdrop-blur-2xl">
          <div className="flex items-center justify-between border-b border-white/10 p-4">
            <div>
              <div className="flex items-center gap-2 text-sm font-black uppercase tracking-[0.18em]">
                <HeartHandshake className="h-4 w-4 text-primary" /> CERISE
              </div>
              <p className="text-xs text-muted-foreground">Orchestration du mariage, calme et validation humaine.</p>
            </div>
            <button onClick={() => setOpen(false)} className="rounded-full p-2 hover:bg-white/10">
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="max-h-[430px] space-y-3 overflow-y-auto p-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`rounded-3xl px-4 py-3 text-sm leading-relaxed ${
                  message.role === "user"
                    ? "ml-8 bg-primary text-primary-foreground"
                    : "mr-8 border border-border bg-muted text-foreground"
                }`}
              >
                {message.role === "assistant" ? (
                  <>
                    <ReactMarkdown
                      components={{
                        h1: ({ children }) => <h3 className="mb-2 text-base font-black text-foreground">{children}</h3>,
                        h2: ({ children }) => <h3 className="mb-2 text-base font-black text-foreground">{children}</h3>,
                        h3: ({ children }) => <h3 className="mb-2 text-sm font-black text-foreground">{children}</h3>,
                        p: ({ children }) => <p className="mb-3 last:mb-0">{children}</p>,
                        ul: ({ children }) => <ul className="mb-3 ml-4 list-disc space-y-1">{children}</ul>,
                        ol: ({ children }) => <ol className="mb-3 ml-4 list-decimal space-y-1">{children}</ol>,
                        li: ({ children }) => <li className="pl-1">{children}</li>,
                        strong: ({ children }) => <strong className="font-black text-primary">{children}</strong>,
                      }}
                    >
                      {message.content}
                    </ReactMarkdown>
                    {getCeriseActions(message.content, location.pathname).length > 0 && (
                      <div className="mt-4 flex flex-wrap gap-2 border-t border-white/10 pt-3">
                        {getCeriseActions(message.content, location.pathname).map((action) => (
                          <button
                            key={action.label}
                            onClick={() => handleAction(action)}
                            className="rounded-full bg-primary/10 px-3 py-2 text-xs font-black text-primary transition hover:bg-primary hover:text-primary-foreground"
                          >
                            {action.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  message.content
                )}
              </div>
            ))}
            {loading && <div className="mr-8 rounded-3xl border border-border bg-muted px-4 py-3 text-sm font-semibold text-foreground/72">CERISE clarifie la prochaine action…</div>}
          </div>

          <div className="space-y-3 border-t border-white/10 p-4">
            <div className="flex flex-wrap gap-2">
              {starterMessages.map((message) => (
                <button
                  key={message}
                  onClick={() => sendMessage(message)}
                  className="rounded-full border border-white/10 px-3 py-2 text-xs font-bold text-muted-foreground hover:bg-white/10 hover:text-foreground"
                >
                  {message}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <Textarea
                value={input}
                onChange={(event) => setInput(event.target.value)}
                placeholder="CERISE, on a un imprévu…"
                className="min-h-[48px] resize-none rounded-2xl border-white/10 bg-white/5 text-sm"
              />
              <Button onClick={() => sendMessage()} disabled={loading} className="h-auto rounded-2xl px-4">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {launcherVisible && (
        <Button
          onClick={() => setOpen((current) => !current)}
          className="h-12 rounded-full px-4 text-xs font-black uppercase tracking-[0.14em] shadow-[0_18px_54px_rgba(23,21,17,0.16)] sm:h-14 sm:px-5 sm:text-sm"
        >
          <HeartHandshake className="h-5 w-5" /> CERISE IA
        </Button>
      )}
    </div>
  );
}