import { useEffect, useRef, useState } from "react";
import WeddingMomentCard from "./WeddingMomentCard";
import EditMomentDialog from "./EditMomentDialog";
import MapAccessDialog from "./MapAccessDialog";
import TimelineShareActions from "./TimelineShareActions";
import TimelineRuler from "./TimelineRuler";
import SmartRipplePanel from "./SmartRipplePanel";
import CeriseInsightCard from "../cerise/CeriseInsightCard";
import { initialWeddingMoments, weddingPeople } from "./weddingData";


export default function WeddingTimeline() {
  const [moments, setMoments] = useState(initialWeddingMoments);
  const [editingMoment, setEditingMoment] = useState(null);
  const [mapMoment, setMapMoment] = useState(null);
  const [rippleInfo, setRippleInfo] = useState(null);
  const [zoom, setZoom] = useState(1);
  const pinchStart = useRef(null);


  useEffect(() => {
    const handleOpenMap = (event) => setMapMoment(event.detail);
    window.addEventListener("openMomentMap", handleOpenMap);
    return () => window.removeEventListener("openMomentMap", handleOpenMap);
  }, []);

  const handleSave = (updatedMoment) => {
    setMoments((items) => items.map((item) => (item.id === updatedMoment.id ? updatedMoment : item)));
    setEditingMoment(null);
  };

  const shiftTime = (time, minutes) => {
    const [hours, mins] = time.split(":").map(Number);
    const total = (hours * 60 + mins + minutes + 1440) % 1440;
    return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
  };

  const handleSmartRipple = (momentId, delayMinutes) => {
    const selectedIndex = moments.findIndex((moment) => moment.id === momentId);
    if (selectedIndex < 0) return;

    setMoments((items) =>
      items.map((moment, index) =>
        index >= selectedIndex ? { ...moment, time: shiftTime(moment.time, delayMinutes), rippleDelay: delayMinutes } : moment
      )
    );
    setRippleInfo(`${moments[selectedIndex].title} retardé de ${delayMinutes} min — les moments suivants ont été recalés.`);
  };

  const handleResetTimeline = () => {
    setMoments(initialWeddingMoments);
    setRippleInfo(null);
  };

  const getTouchDistance = (touches) => {
    const [first, second] = touches;
    return Math.hypot(first.clientX - second.clientX, first.clientY - second.clientY);
  };

  const handleTouchStart = (event) => {
    if (event.touches.length !== 2) return;
    pinchStart.current = { distance: getTouchDistance(event.touches), zoom };
  };

  const handleTouchMove = (event) => {
    if (event.touches.length !== 2 || !pinchStart.current) return;
    event.preventDefault();
    const ratio = getTouchDistance(event.touches) / pinchStart.current.distance;
    const nextZoom = Math.min(1, Math.max(0.48, pinchStart.current.zoom * ratio));
    setZoom(nextZoom);
  };

  const handleTouchEnd = () => {
    pinchStart.current = null;
  };

  return (
    <>
      <div
        id="timeline"
        className="relative overflow-visible"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{ touchAction: "pan-y" }}
      >
        <TimelineShareActions />
        <div className="mb-6">
          <CeriseInsightCard
            context="Timeline — Cerise limite les alertes aux points vraiment utiles."
            insights={[
              {
                id: "timeline-responsables",
                priority: "Needs attention",
                diagnosis: "La timeline est lisible, mais certains moments gagnent à avoir un responsable clairement identifié.",
                clear: "Les horaires, lieux et durées sont structurés.",
                missing: "Responsable opérationnel par moment.",
                attention: "Sans responsable, les transitions peuvent devenir floues le Jour J.",
                action: "Associer un témoin ou prestataire aux moments sensibles.",
                automation: "Notification interne 15 minutes avant les moments clés.",
                validation: true,
              },
            ]}
          />
        </div>
        <SmartRipplePanel
          moments={moments}
          rippleInfo={rippleInfo}
          onApplyDelay={handleSmartRipple}
          onReset={handleResetTimeline}
        />
        <div
          className="relative transition-transform duration-200 ease-out"
          style={{ transform: `scale(${zoom})`, transformOrigin: "top center" }}
        >
          <TimelineRuler moments={moments} />
          {moments.map((moment, index) => (
            <WeddingMomentCard
              key={moment.id}
              moment={moment}
              index={index}
              onEdit={setEditingMoment}
            />
          ))}
        </div>
        {zoom < 0.9 && (
          <div className="pointer-events-none sticky bottom-4 z-30 mx-auto w-fit rounded-full bg-foreground px-4 py-2 text-xs font-black text-background shadow-lg">
            Vue d’ensemble
          </div>
        )}
      </div>

      <EditMomentDialog
        moment={editingMoment}
        people={weddingPeople}
        open={Boolean(editingMoment)}
        onOpenChange={(open) => !open && setEditingMoment(null)}
        onSave={handleSave}
      />

      <MapAccessDialog
        moment={mapMoment}
        open={Boolean(mapMoment)}
        onOpenChange={(open) => !open && setMapMoment(null)}
      />
    </>
  );
}