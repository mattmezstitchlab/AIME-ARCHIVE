import { Network, Sparkles } from "lucide-react";
import { weddingPeople } from "./weddingData";
import PersonFlipCard from "./PersonFlipCard";
import LivingConnection from "./LivingConnection";

const extraPeople = [
  { id: "nora", name: "Nora", role: "Photographe", branch: "Prestataire", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=160&h=160&fit=crop&crop=faces", tasks: ["Shooter les moments clés", "Prévenir si retard photos", "Coordonner groupes"] },
  { id: "sofia", name: "Sofia", role: "Coordinatrice", branch: "Prestataire", avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=160&h=160&fit=crop&crop=faces", tasks: ["Piloter la timeline", "Alerter les prestataires", "Garder les mariés zen"] },
  { id: "enzo", name: "Enzo", role: "Traiteur", branch: "Prestataire", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&h=160&fit=crop&crop=faces", tasks: ["Préparer cocktail", "Synchroniser dîner", "Gérer service"] },
];

const people = weddingPeople.map((person) => ({ ...person, branch: person.role.includes("Marié") ? "Couple" : person.role === "DJ" ? "Prestataire" : person.id === "marc" ? "Côté marié" : "Côté mariée" }));
const couple = people.filter((person) => person.role === "Mariée" || person.role === "Marié");
const brideSide = people.filter((person) => person.branch === "Côté mariée");
const groomSide = people.filter((person) => person.branch === "Côté marié");
const providers = [...people.filter((person) => person.branch === "Prestataire"), ...extraPeople];

export default function LivingPeopleTree() {
  return (
    <section className="relative overflow-hidden bg-background py-20">
      <div className="pointer-events-none absolute left-1/2 top-28 h-[34rem] w-[34rem] -translate-x-1/2 rounded-full bg-primary/8 blur-3xl" />
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mb-12 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-3xl bg-foreground text-background">
            <Network className="h-7 w-7" />
          </div>
          <p className="mb-3 text-xs font-black uppercase tracking-[0.28em] text-primary">Génialogique vivant</p>
          <h2 className="text-4xl font-black tracking-tight text-foreground sm:text-6xl" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>
            L’arborescence du Jour J
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Les mariés au centre, les proches et prestataires connectés autour : les petits signaux montrent les infos qui circulent entre tout le monde.
          </p>
        </div>

        <div className="relative rounded-[2.75rem] border border-white/10 bg-white/[0.03] p-4 sm:p-8 shadow-[0_30px_120px_rgba(0,0,0,0.35)]">
          <div className="flex justify-center gap-5 sm:gap-8">
            {couple.map((person) => <PersonFlipCard key={person.id} person={person} compact />)}
          </div>

          <div className="mx-auto flex w-full max-w-4xl items-center justify-center gap-4 py-4">
            <LivingConnection vertical delay="0s" />
            <div className="flex items-center gap-2 rounded-full border border-white/10 bg-background px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-foreground">
              <Sparkles className="h-4 w-4 text-primary" /> Infos en circulation
            </div>
            <LivingConnection vertical delay=".7s" />
          </div>

          <div className="grid gap-6 lg:grid-cols-[1fr_auto_1fr]">
            <div className="rounded-[2rem] border border-white/8 bg-muted/40 p-4">
              <h3 className="mb-4 text-center text-sm font-black uppercase tracking-[0.2em] text-muted-foreground">Côté mariée</h3>
              <div className="grid justify-items-center gap-4 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                {brideSide.map((person) => <PersonFlipCard key={person.id} person={person} compact />)}
              </div>
            </div>

            <div className="hidden w-28 flex-col items-center justify-center lg:flex">
              <LivingConnection className="w-28" delay=".2s" />
              <div className="my-4 h-4 w-4 animate-network-pulse rounded-full bg-primary shadow-[0_0_28px_rgba(205,255,10,0.9)]" />
              <LivingConnection className="w-28" delay="1s" />
            </div>

            <div className="rounded-[2rem] border border-white/8 bg-muted/40 p-4">
              <h3 className="mb-4 text-center text-sm font-black uppercase tracking-[0.2em] text-muted-foreground">Côté marié</h3>
              <div className="grid justify-items-center gap-4 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                {groomSide.map((person) => <PersonFlipCard key={person.id} person={person} compact />)}
              </div>
            </div>
          </div>

          <div className="mx-auto my-5 max-w-5xl">
            <LivingConnection delay=".5s" />
          </div>

          <div className="rounded-[2rem] border border-primary/20 bg-primary/5 p-4">
            <h3 className="mb-4 text-center text-sm font-black uppercase tracking-[0.2em] text-primary">Prestataires connectés</h3>
            <div className="grid justify-items-center gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {providers.map((person) => <PersonFlipCard key={person.id} person={person} compact />)}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}