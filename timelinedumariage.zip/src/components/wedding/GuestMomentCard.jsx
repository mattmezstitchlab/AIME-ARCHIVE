import { useState } from "react";
import { Clock, MapPin, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import GuestMomentContributionForm from "./GuestMomentContributionForm";
import MomentContributions from "./MomentContributions";

export default function GuestMomentCard({ moment, contributions = [], onContributionSubmitted, onOpenMap }) {
  const [flipped, setFlipped] = useState(false);

  return (
    <article className="min-h-[21rem] [perspective:1200px]">
      <div className={`relative h-full min-h-[21rem] transition-transform duration-700 [transform-style:preserve-3d] ${flipped ? "[transform:rotateY(180deg)]" : ""}`}>
        <button type="button" onClick={() => setFlipped(true)} className="absolute inset-0 w-full rounded-[2rem] border border-border bg-card p-5 text-left text-foreground shadow-sm transition-colors hover:bg-muted sm:p-6 [backface-visibility:hidden]">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Badge className="rounded-full time-pill-flat">{moment.time}</Badge>
            <span className="inline-flex items-center gap-1 text-xs font-bold time-pill-soft px-3 py-1 rounded-full">
              <Clock className="w-3.5 h-3.5" /> {moment.duration}
            </span>
          </div>
          <h3 className="text-2xl font-black tracking-tight text-foreground">{moment.title}</h3>
          <p className="mt-3 text-sm font-semibold leading-relaxed text-foreground/72">{moment.description}</p>
          <span
            role="button"
            tabIndex={0}
            onClick={(event) => {
              event.stopPropagation();
              onOpenMap(moment);
            }}
            className="mt-5 inline-flex w-full items-center gap-2 rounded-full border border-border bg-white px-4 py-3 text-sm font-black text-foreground transition-colors hover:bg-muted"
          >
            <MapPin className="w-4 h-4" /> {moment.location}
          </span>
          <span className="mt-4 flex items-center justify-center gap-1 text-[11px] font-black uppercase tracking-widest text-foreground/65">
            <RefreshCw className="h-3.5 w-3.5" /> Tap pour contribuer
          </span>
        </button>

        <div className="absolute inset-0 overflow-y-auto rounded-[2rem] border border-border bg-white p-5 text-foreground shadow-sm [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <button type="button" onClick={() => setFlipped(false)} className="mb-3 flex items-center gap-1 text-xs font-black text-foreground/70 hover:text-foreground">
            <RefreshCw className="h-3.5 w-3.5" /> Retour
          </button>
          <h4 className="mb-3 text-lg font-black tracking-tight text-foreground">{moment.title}</h4>
          <GuestMomentContributionForm moment={moment} onSubmitted={onContributionSubmitted} />
          <div className="mt-4 border-t border-border pt-3">
            <p className="mb-2 text-xs font-black uppercase tracking-widest text-foreground/65">Contributions publiques</p>
            <MomentContributions contributions={contributions} />
          </div>
        </div>
      </div>
    </article>
  );
}