import { useState } from "react";
import { Download, Link as LinkIcon, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TimelineShareActions() {
  const [copied, setCopied] = useState(false);

  const timelineUrl = `${window.location.origin}${window.location.pathname}#timeline`;

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: "Timeline du mariage",
        text: "Voici la timeline complète du mariage.",
        url: timelineUrl,
      });
      return;
    }

    await navigator.clipboard.writeText(timelineUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="flex flex-row items-center justify-center gap-2 mt-3 mb-10 print:hidden">
      <Button onClick={handlePrint} variant="outline" size="sm" className="rounded-full px-3 text-foreground border-foreground/20 hover:bg-muted">
        <Download className="w-3.5 h-3.5" /> Générer PDF
      </Button>
      <Button onClick={handleShare} variant="outline" size="sm" className="rounded-full px-3 text-foreground border-foreground/20 hover:bg-muted">
        {navigator.share ? <Share2 className="w-3.5 h-3.5" /> : <LinkIcon className="w-3.5 h-3.5" />}
        {copied ? "Lien copié" : "Lien partageable"}
      </Button>
    </div>
  );
}