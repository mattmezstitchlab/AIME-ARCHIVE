import { Music } from "lucide-react";

export default function MomentContributions({ contributions = [], compact = false }) {
  const publicContributions = contributions.filter((item) => item.guest_name || item.music_titles);

  if (!publicContributions.length) {
    return <p className="text-center text-[11px] font-bold text-foreground/72">Aucune contribution publique pour ce moment.</p>;
  }

  return (
    <div className={compact ? "space-y-1.5" : "space-y-2"}>
      {publicContributions.map((item) => (
        <div key={item.id} className="rounded-xl bg-muted/70 px-3 py-2 text-left">
          {item.guest_name && <p className="text-xs font-black text-foreground">{item.guest_name}</p>}
          {item.music_titles && (
            <p className="mt-1 flex gap-1.5 text-[11px] font-bold text-foreground/72"><Music className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {item.music_titles}</p>
          )}
        </div>
      ))}
    </div>
  );
}