import { useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import { initialWeddingMoments } from "./weddingData";

const notifiedMoments = new Set();

function minutesUntil(time) {
  const [hours, minutes] = time.split(":").map(Number);
  const now = new Date();
  const target = new Date(now);
  target.setHours(hours, minutes, 0, 0);
  if (hours < 6 && now.getHours() > 18) target.setDate(target.getDate() + 1);
  return Math.round((target.getTime() - now.getTime()) / 60000);
}

export default function TimelineReminderProvider() {
  const { toast } = useToast();

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }

    const checkMoments = () => {
      initialWeddingMoments.forEach((moment) => {
        const remaining = minutesUntil(moment.time);
        if (remaining <= 15 && remaining >= 0 && !notifiedMoments.has(moment.id)) {
          notifiedMoments.add(moment.id);
          const message = `${moment.title} commence à ${moment.time} — ${moment.location}`;
          toast({ title: "Rappel timeline", description: message });
          if ("Notification" in window && Notification.permission === "granted") {
            new Notification("Rappel mariage", { body: message });
          }
        }
      });
    };

    checkMoments();
    const interval = window.setInterval(checkMoments, 60000);
    return () => window.clearInterval(interval);
  }, [toast]);

  return null;
}