import { ArrowRight } from "lucide-react";
import { weddingPeople } from "./weddingData";

export default function WeddingPeopleCards() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-black text-foreground tracking-tight" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>
            Les personnes clés
          </h2>
          <p className="text-muted-foreground mt-3 max-w-xl mx-auto">
            Les mariés, témoins et proches associés aux moments importants du Jour J.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {weddingPeople.slice(0, 4).map((person) => (
            <div key={person.id} className="group relative bg-muted rounded-[2rem] p-6 hover:-translate-y-2 transition-all duration-300 text-center flex flex-col items-center">
              <div className="w-32 h-32 rounded-full mb-6 overflow-hidden border-4 border-background shadow-xl">
                <img
                  src={person.avatar}
                  alt={person.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <h3 className="font-bold text-foreground text-xl mb-1" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>
                {person.name}
              </h3>
              <p className="text-sm font-bold text-muted-foreground">{person.role}</p>

              <div className="absolute -bottom-4 -right-4 w-10 h-10 bg-background rounded-full border border-border shadow-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowRight className="w-4 h-4 text-foreground transform -rotate-45" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}