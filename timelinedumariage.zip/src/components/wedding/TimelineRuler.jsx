export default function TimelineRuler({ moments = [] }) {
  return (
    <div className="pointer-events-none absolute left-1/2 top-8 bottom-10 z-0 hidden w-14 -translate-x-1/2 sm:block" aria-hidden="true">
      <div className="absolute left-1/2 top-0 h-full w-[3px] -translate-x-1/2 rounded-full bg-foreground/25" />
      <div className="absolute inset-y-0 left-1/2 flex -translate-x-1/2 flex-col justify-between py-8">
        {moments.map((moment, index) => (
          <div key={moment.id} className="flex items-center justify-center">
            <span className="h-3 w-3 rounded-full bg-foreground shadow-[0_0_0_6px_hsl(var(--background))]" />
            <span className={`absolute h-px w-7 bg-foreground/35 ${index % 2 === 0 ? "translate-x-6" : "-translate-x-6"}`} />
            <span className={`absolute rounded-full bg-background px-2 py-0.5 text-[10px] font-black text-foreground ${index % 2 === 0 ? "translate-x-16" : "-translate-x-16"}`}>
              {moment.time}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}