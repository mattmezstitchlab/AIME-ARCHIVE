import { useState } from "react";
import { AlertTriangle, Clock, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

const delayOptions = [5, 10, 15, 20, 30, 45, 60];

export default function SmartRipplePanel({ moments, rippleInfo, onApplyDelay, onReset }) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="mb-8 flex justify-center">
        <Button
          type="button"
          onClick={() => setOpen((current) => !current)}
          className="h-12 rounded-full border border-white/10 bg-white/10 px-6 text-white hover:bg-white/15 backdrop-blur-2xl shadow-[0_18px_60px_rgba(0,0,0,0.35)]"
        >
          <AlertTriangle className="h-4 w-4" /> SmartRipple retards
        </Button>
      </div>

      {open && (
        <div className="mx-auto mb-10 max-w-3xl rounded-[2.25rem] border border-border bg-card p-5 sm:p-7 text-card-foreground shadow-[0_24px_80px_rgba(0,0,0,0.35)]">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-sm font-black uppercase tracking-widest">
            <AlertTriangle className="h-4 w-4" /> SmartRipple retards
          </div>
          <p className="mt-1 text-sm font-bold text-card-foreground/65">
            Signale un retard et tous les horaires suivants se recalculent automatiquement.
          </p>
        </div>
        <Button type="button" variant="outline" size="sm" onClick={onReset} className="rounded-full">
          <RotateCcw className="h-4 w-4" /> Reset
        </Button>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto]">
        <select
          id="smart-ripple-moment"
          className="h-11 rounded-2xl border border-input bg-background px-4 text-sm font-bold text-foreground outline-none focus:ring-2 focus:ring-ring"
          defaultValue={moments[0]?.id || ""}
        >
          {moments.map((moment) => (
            <option key={moment.id} value={moment.id}>
              {moment.time} — {moment.title}
            </option>
          ))}
        </select>

        <div className="flex flex-wrap gap-2">
          {delayOptions.map((minutes) => (
            <Button
              key={minutes}
              type="button"
              size="sm"
              className="rounded-full bg-background text-foreground hover:bg-accent hover:text-accent-foreground shadow-sm"
              onClick={() => onApplyDelay(document.getElementById("smart-ripple-moment")?.value, minutes)}
            >
              +{minutes} min
            </Button>
          ))}
        </div>
      </div>

      {rippleInfo && (
        <div className="mt-5 flex items-center gap-2 rounded-3xl bg-background px-5 py-4 text-sm sm:text-base font-black text-foreground">
          <Clock className="h-4 w-4" /> {rippleInfo}
        </div>
      )}
        </div>
      )}
    </>
  );
}