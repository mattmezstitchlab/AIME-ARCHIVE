import { useState } from "react";
import { Music, Utensils, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function GuestMomentContributionForm({ moment, onSubmitted }) {
  const [form, setForm] = useState({ guest_name: "", music_titles: "", allergies: "", notes: "" });
  const [saving, setSaving] = useState(false);

  const update = (field, value) => setForm((current) => ({ ...current, [field]: value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSaving(true);
    await base44.entities.MomentContribution.create({ moment_id: moment.id, ...form });
    setForm({ guest_name: "", music_titles: "", allergies: "", notes: "" });
    setSaving(false);
    onSubmitted?.();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2" onClick={(event) => event.stopPropagation()}>
      <Input value={form.guest_name} onChange={(event) => update("guest_name", event.target.value)} placeholder="Votre nom — visible dans les contributions publiques" className="h-9 rounded-xl border-white/10 bg-black/30 text-white placeholder:text-white/35" />
      {(moment.type === "party" || moment.id.includes("dance") || moment.id.includes("entry")) && (
        <div className="relative">
          <Music className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={form.music_titles} onChange={(event) => update("music_titles", event.target.value)} placeholder="Proposition musicale — visible dans les contributions publiques" className="h-9 rounded-xl border-white/10 bg-black/30 pl-9 text-white placeholder:text-white/35" />
        </div>
      )}
      {moment.type === "dinner" && (
        <div className="relative">
          <Utensils className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={form.allergies} onChange={(event) => update("allergies", event.target.value)} placeholder="Allergies ou régime alimentaire — transmis uniquement au couple" className="h-9 rounded-xl border-white/10 bg-black/30 pl-9 text-white placeholder:text-white/35" />
        </div>
      )}
      <Textarea value={form.notes} onChange={(event) => update("notes", event.target.value)} placeholder="Note privée pour les mariés — non affichée publiquement" className="min-h-16 rounded-xl border-white/10 bg-black/30 text-white placeholder:text-white/35" />
      <Button type="submit" disabled={saving} className="h-9 w-full rounded-xl bg-accent text-accent-foreground hover:bg-accent/90 font-black">
        <Send className="h-4 w-4" /> {saving ? "Envoi..." : "Envoyer"}
      </Button>
    </form>
  );
}