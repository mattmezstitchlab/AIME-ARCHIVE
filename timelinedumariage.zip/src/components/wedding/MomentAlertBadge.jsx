import { useEffect, useState } from "react";
import { Bell, BellRing } from "lucide-react";

function getMinutesUntil(time) {
  const [hours, minutes] = time.split(":").map(Number);
  const target = new Date();
  target.setHours(hours, minutes, 0, 0);
  return Math.round((target.getTime() - Date.now()) / 60000);
}

export default function MomentAlertBadge({ moment }) {
  const [minutesUntil, setMinutesUntil] = useState(() => getMinutesUntil(moment.time));

  useEffect(() => {
    const timer = setInterval(() => setMinutesUntil(getMinutesUntil(moment.time)), 60000);
    return () => clearInterval(timer);
  }, [moment.time]);

  if (minutesUntil > 30 || minutesUntil < -15) return null;

  const isSoon = minutesUntil > 0;
  const isNow = minutesUntil <= 0;

  return (
    <div className={`absolute -top-3 left-1/2 z-40 -translate-x-1/2 rounded-full px-4 py-2 text-xs font-black shadow-xl ${isSoon ? "bg-accent text-accent-foreground animate-pulse" : "bg-foreground text-background"}`}>
      <span className="inline-flex items-center gap-2 whitespace-nowrap">
        {isSoon ? <BellRing className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
        {isSoon ? `Dans ${minutesUntil} min` : "Moment en cours"}
      </span>
    </div>
  );
}