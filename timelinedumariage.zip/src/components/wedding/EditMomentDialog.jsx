import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function EditMomentDialog({ moment, people, open, onOpenChange, onSave }) {
  const [form, setForm] = useState(moment);

  useEffect(() => {
    setForm(moment);
  }, [moment]);

  if (!form) return null;

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const togglePerson = (person) => {
    const exists = form.people.some((p) => p.id === person.id);
    update("people", exists ? form.people.filter((p) => p.id !== person.id) : [...form.people, person]);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    onSave(form);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm rounded-[2rem] p-4 sm:p-5">
        <DialogHeader>
          <DialogTitle className="text-lg font-black text-center" >
            Modifier le moment
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Heure</Label>
              <Input value={form.time} onChange={(e) => update("time", e.target.value)} className="h-9 rounded-xl" />
            </div>
            <div className="space-y-1.5">
              <Label>Durée</Label>
              <Input value={form.duration} onChange={(e) => update("duration", e.target.value)} className="h-9 rounded-xl" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Titre</Label>
            <Input value={form.title} onChange={(e) => update("title", e.target.value)} className="h-9 rounded-xl" />
          </div>

          <div className="space-y-2">
            <Label>Lieu</Label>
            <Input value={form.location} onChange={(e) => update("location", e.target.value)} className="h-9 rounded-xl" />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={form.description} onChange={(e) => update("description", e.target.value)} className="min-h-16 rounded-xl" />
          </div>

          <div className="space-y-2">
            <Label>Personnes associées</Label>
            <div className="grid grid-cols-2 gap-2">
              {people.map((person) => {
                const active = form.people.some((p) => p.id === person.id);
                return (
                  <button
                    key={person.id}
                    type="button"
                    onClick={() => togglePerson(person)}
                    className={`flex items-center gap-2 p-1.5 rounded-xl border text-left transition-all ${active ? "border-foreground bg-muted" : "border-border hover:bg-muted/50"}`}
                  >
                    <img src={person.avatar} alt={person.name} className="w-7 h-7 rounded-full object-cover" />
                    <span className="text-xs font-bold text-foreground">{person.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <Button type="submit" className="w-full rounded-xl bg-foreground text-background h-10 font-bold">
            Enregistrer
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}