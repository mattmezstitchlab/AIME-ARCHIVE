import { useEffect, useState } from "react";
import { ChevronDown, ShieldCheck } from "lucide-react";
import TimelineLivingView from "../timeline/TimelineLivingView";
import DayOfOperationPanel from "../timeline/DayOfOperationPanel";
import ValidationJournalPanel from "../timeline/ValidationJournalPanel";
import CeriseWeddingDayPriorityPanel from "../cerise/CeriseWeddingDayPriorityPanel";
import CeriseRecap from "../cerise/CeriseRecap";
import { loadLivingTimelineItems } from "@/lib/timelineAdapter";
import { getHumanValidationLogs } from "@/lib/humanValidationLog";

export default function InternalControlSection() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [validations, setValidations] = useState([]);

  useEffect(() => {
    Promise.all([loadLivingTimelineItems(), getHumanValidationLogs(80)]).then(([timelineItems, logs]) => {
      setItems(timelineItems);
      setValidations(logs);
    });
  }, []);

  const visibleCount = items.length;
  const confirmCount = items.filter((item) => item.status === "to_confirm" || item.priority === "To confirm").length;
  const relationCount = items.reduce((total, item) => total + (item.registered_relations || []).filter((relation) => relation.relation_status === "to_verify" || relation.sync_status === "to_verify").length, 0);

  const stats = [
    [visibleCount, "éléments visibles"],
    [confirmCount, "à confirmer"],
    [relationCount, "relations à vérifier"],
    [validations.length, "validations humaines"],
  ];

  return (
    <section className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
      <div className="rounded-[2.25rem] border border-foreground/10 bg-white/88 p-4 shadow-[0_18px_54px_rgba(23,21,17,0.06)] sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><ShieldCheck className="h-4 w-4" /></div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-black tracking-tight text-foreground">Contrôle interne — non visible pour les invités</h2>
                <span className="rounded-full bg-accent px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-accent-foreground">Admin</span>
              </div>
              <p className="mt-1 text-sm font-semibold text-foreground/72">Les panneaux complets restent disponibles, mais repliés par défaut.</p>
            </div>
          </div>
          <button type="button" onClick={() => setOpen((current) => !current)} className="inline-flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-black text-primary-foreground transition-colors duration-200 hover:bg-primary/90">
            {open ? "Fermer le contrôle interne" : "Ouvrir le contrôle interne"}
            <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${open ? "rotate-180" : ""}`} />
          </button>
        </div>

        {open && (
          <div className="mt-6 space-y-6 border-t border-border pt-6">
            <div className="grid gap-2 sm:grid-cols-4">
              {stats.map(([value, label]) => (
                <div key={label} className="rounded-2xl bg-[#FBF7F0] px-4 py-3">
                  <p className="text-xl font-black text-foreground">{value}</p>
                  <p className="text-[11px] font-black uppercase tracking-[0.12em] text-foreground/72">{label}</p>
                </div>
              ))}
            </div>
            <TimelineLivingView audience="couple_admin" />
            <div id="mode-jour-j">
              <DayOfOperationPanel audience="couple_admin" />
            </div>
            <ValidationJournalPanel audience="couple_admin" />
            <CeriseWeddingDayPriorityPanel />
            <CeriseRecap />
          </div>
        )}
      </div>
    </section>
  );
}