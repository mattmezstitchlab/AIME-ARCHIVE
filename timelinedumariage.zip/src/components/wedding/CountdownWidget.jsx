import { useEffect, useMemo, useState } from "react";
import { CalendarHeart } from "lucide-react";

const weddingDate = new Date("2026-09-12T14:30:00");

function getRemainingTime() {
  const diff = Math.max(weddingDate.getTime() - Date.now(), 0);
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

export default function CountdownWidget() {
  const [remaining, setRemaining] = useState(getRemainingTime());
  const units = useMemo(() => [
    ["Jours", remaining.days],
    ["Heures", remaining.hours],
    ["Minutes", remaining.minutes],
    ["Secondes", remaining.seconds],
  ], [remaining]);

  useEffect(() => {
    const timer = setInterval(() => setRemaining(getRemainingTime()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center justify-center gap-3 sm:gap-4">
      <CalendarHeart className="w-7 h-7 sm:w-8 sm:h-8 text-foreground flex-shrink-0" />
      <div className="flex items-center gap-2 sm:gap-3">
        {units.map(([label, value]) => (
          <div key={label} className="text-center">
            <div className="text-xl sm:text-2xl font-black text-foreground tabular-nums leading-none">{String(value).padStart(2, "0")}</div>
            <div className="text-[8px] sm:text-[9px] uppercase tracking-wider text-foreground/72 font-bold mt-1">{label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}