import { useMemo, useState } from "react";
import { Clock, MapPin, Phone, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { initialWeddingMoments, weddingPeople } from "./weddingData";

const providerRoles = ["DJ", "Photographe", "Traiteur", "Wedding planner", "Fleuriste", "Officiant"];

export default function ProviderTimeline() {
  const providers = useMemo(
    () => weddingPeople.filter((person) => providerRoles.includes(person.role)),
    []
  );
  const [selectedProviderId, setSelectedProviderId] = useState(providers[0]?.id || "all");

  const moments = initialWeddingMoments.filter((moment) =>
    selectedProviderId === "all"
      ? moment.people.some((person) => providers.some((provider) => provider.id === person.id))
      : moment.people.some((person) => person.id === selectedProviderId)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2">
        <Button onClick={() => setSelectedProviderId("all")} variant={selectedProviderId === "all" ? "default" : "outline"} className="rounded-full">
          Tous
        </Button>
        {providers.map((provider) => (
          <Button key={provider.id} onClick={() => setSelectedProviderId(provider.id)} variant={selectedProviderId === provider.id ? "default" : "outline"} className="rounded-full">
            {provider.role}
          </Button>
        ))}
      </div>

      <div className="grid gap-4">
        {moments.map((moment) => (
          <article key={moment.id} className="bg-card text-card-foreground border border-border rounded-[2rem] p-5 sm:p-6 shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-5">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <Badge className="rounded-full time-pill-flat">{moment.time}</Badge>
                  <span className="inline-flex items-center gap-1 text-xs font-bold time-pill-soft px-3 py-1 rounded-full">
                    <Clock className="w-3.5 h-3.5" /> {moment.duration}
                  </span>
                </div>
                <h2 className="text-2xl font-black tracking-tight" >{moment.title}</h2>
                <p className="mt-2 text-sm font-semibold leading-relaxed text-foreground/72">{moment.description}</p>
              </div>

              <div className="lg:w-72 space-y-3 shrink-0">
                <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(moment.location)}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-2xl bg-muted px-4 py-3 text-sm font-black text-foreground hover:bg-border transition-colors">
                  <MapPin className="w-4 h-4" /> Plan : {moment.location}
                </a>
                <div className="rounded-2xl bg-muted px-4 py-3 text-foreground">
                  <div className="flex items-center gap-2 text-sm font-black mb-2"><Users className="w-4 h-4" /> Contacts liés</div>
                  <div className="space-y-2">
                    {moment.people.map((person) => (
                      <div key={person.id} className="flex items-center justify-between gap-3 text-xs font-bold text-foreground/80">
                        <span>{person.name} — {person.role}</span>
                        {person.phone && <a href={`tel:${person.phone}`}><Phone className="w-3.5 h-3.5" /></a>}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}