import AimeUniversalWidget from "./navigation/AimeUniversalWidget";

export default function Header() {
  return <AimeUniversalWidget />;
}