export default function DesignTokenCard({ title, value, description, className = "" }) {
  return (
    <div className={`rounded-[1.5rem] border border-border bg-card p-4 ${className}`}>
      <p className="text-xs font-black uppercase tracking-[0.18em] text-foreground/55">{title}</p>
      <p className="mt-2 text-sm font-black text-foreground">{value}</p>
      {description && <p className="mt-2 text-xs font-semibold leading-relaxed text-foreground/68">{description}</p>}
    </div>
  );
}