export default function ColorSwatch({ name, value, usage, swatchClass, textClass = "text-foreground" }) {
  return (
    <div className="overflow-hidden rounded-[1.5rem] border border-border bg-card">
      <div className={`h-24 ${swatchClass}`} />
      <div className="p-4">
        <p className="text-sm font-black text-foreground">{name}</p>
        <p className={`mt-1 text-xs font-bold ${textClass}`}>{value}</p>
        <p className="mt-2 text-xs font-semibold leading-relaxed text-foreground/68">{usage}</p>
      </div>
    </div>
  );
}