export default function DecisionList({ items }) {
  return (
    <div className="space-y-2">
      {items.map((item) => (
        <div key={item} className="rounded-[1.25rem] border border-border bg-card px-4 py-3 text-sm font-semibold text-foreground/72">
          {item}
        </div>
      ))}
    </div>
  );
}