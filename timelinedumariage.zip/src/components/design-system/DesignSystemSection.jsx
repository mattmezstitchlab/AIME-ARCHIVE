export default function DesignSystemSection({ eyebrow, title, description, children }) {
  return (
    <section className="rounded-[2rem] border border-border bg-white/88 p-5 shadow-[0_18px_54px_rgba(23,21,17,0.06)] backdrop-blur-xl sm:p-7">
      {eyebrow && <p className="text-xs font-black uppercase tracking-[0.24em] text-accent">{eyebrow}</p>}
      <div className="mt-2 max-w-3xl">
        <h2 className="font-heading text-2xl font-black tracking-tight text-foreground sm:text-3xl">{title}</h2>
        {description && <p className="mt-3 text-sm font-semibold leading-relaxed text-foreground/72 sm:text-base">{description}</p>}
      </div>
      <div className="mt-6">{children}</div>
    </section>
  );
}