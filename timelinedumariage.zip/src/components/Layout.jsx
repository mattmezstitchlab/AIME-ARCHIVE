import { Outlet } from "react-router-dom";
import Header from "./Header";
import TimelineReminderProvider from "./wedding/TimelineReminderProvider";
import AimeCerisePanel from "./navigation/AimeCerisePanel";

export default function Layout() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-background text-foreground">
      <Header />
      <TimelineReminderProvider />
      <AimeCerisePanel />
      <main className="pb-32 lg:pl-24 lg:pb-0">
        <Outlet />
      </main>
    </div>
  );
}