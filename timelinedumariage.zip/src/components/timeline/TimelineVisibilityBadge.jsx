import { Shield, Users, UserCheck, Eye, Lock, HeartHandshake, Building2, Globe2 } from "lucide-react";

const visibilityConfig = {
  private_couple: { label: "couple uniquement", className: "bg-rose-500/15 text-rose-100 border-rose-300/20", icon: Lock },
  admin: { label: "admin", className: "bg-violet-500/15 text-violet-100 border-violet-300/20", icon: Shield },
  family: { label: "famille", className: "bg-pink-500/15 text-pink-100 border-pink-300/20", icon: HeartHandshake },
  witnesses: { label: "témoins", className: "bg-amber-500/15 text-amber-100 border-amber-300/20", icon: UserCheck },
  guests: { label: "invités", className: "bg-sky-500/15 text-sky-100 border-sky-300/20", icon: Users },
  providers: { label: "prestataires", className: "bg-lime-500/15 text-lime-100 border-lime-300/20", icon: Building2 },
  public: { label: "public", className: "bg-emerald-500/15 text-emerald-100 border-emerald-300/20", icon: Globe2 },
  internal: { label: "interne", className: "bg-white/10 text-white/75 border-white/15", icon: Eye },
};

export default function TimelineVisibilityBadge({ visibility = "private_couple" }) {
  const config = visibilityConfig[visibility] || visibilityConfig.private_couple;
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-black uppercase tracking-[0.12em] ${config.className}`}>
      <Icon className="h-3 w-3" />
      {config.label}
    </span>
  );
}

export { visibilityConfig };