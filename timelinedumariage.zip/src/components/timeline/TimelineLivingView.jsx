import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Bell, Briefcase, CalendarDays, Clock, FileText, Image, MessageSquare, Sparkles, UserRoundCheck } from "lucide-react";
import TimelineVisibilityBadge from "./TimelineVisibilityBadge";
import TimelineControlPanel from "./TimelineControlPanel";
import TimelineItemInspector from "./TimelineItemInspector";
import { loadLivingTimelineItems, adaptWeddingPeopleToPersons } from "@/lib/timelineAdapter";
import { filterTimelineItemsByAudience } from "@/lib/timelineVisibility";

const typeIcons = {
  wedding_moment: CalendarDays,
  rsvp_signal: UserRoundCheck,
  guest_reminder: AlertTriangle,
  provider_brief: Briefcase,
  document: FileText,
  message: MessageSquare,
  cerise_action: Sparkles,
  photo_memory: Image,
  day_of_instruction: Clock,
  reminder: Bell,
  instruction: Clock,
};

const typeLabels = {
  wedding_moment: "Moment",
  cerise_action: "Action Cerise",
  rsvp_signal: "RSVP",
  guest_reminder: "Alerte",
  message: "Message",
  document: "Document",
  photo_memory: "Souvenir",
  provider_brief: "Prestataire",
  day_of_instruction: "Consigne",
  reminder: "Rappel",
  instruction: "Consigne",
  private_note: "Alerte",
  public_info: "Moment",
};

const statusLabels = {
  planned: "prévu",
  to_confirm: "à confirmer",
  confirmed: "confirmé",
  in_progress: "en cours",
  done: "fait",
  urgent: "urgent",
  ignored: "ignoré",
  archived: "archivé",
};

const sourceLabels = {
  weddingData: "planning actuel",
  cerise: "Cerise",
  rsvp: "RSVP",
  photo: "photo",
  moment_contribution: "contribution",
  message: "message",
  document: "document",
  manual: "manuel",
};

export default function TimelineLivingView({ audience = "couple_admin", internalControls = audience === "couple_admin" }) {
  const [items, setItems] = useState([]);
  const [selectedAudience, setSelectedAudience] = useState(audience);
  const [inspectedItem, setInspectedItem] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLivingTimelineItems().then((timelineItems) => {
      setItems(timelineItems);
      setLoading(false);
    });
  }, []);

  const people = useMemo(() => adaptWeddingPeopleToPersons(), []);
  const visibleItems = useMemo(() => filterTimelineItemsByAudience(items, selectedAudience), [items, selectedAudience]);

  const dayOfItems = visibleItems.filter((item) => item.type === "wedding_moment").slice(0, 5);
  const attentionItems = visibleItems
    .filter((item) => item.status === "to_confirm" || item.priority === "Needs attention" || item.priority === "Urgent")
    .slice(0, 6);
  const previewItems = visibleItems.slice(0, 12);

  const findPeople = (ids = []) => ids.map((id) => people.find((person) => person.id === id)).filter(Boolean).slice(0, 5);

  const TypeBadge = ({ item }) => (
    <span className="inline-flex items-center rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-foreground">
      {typeLabels[item.type] || "Alerte"}
    </span>
  );

  return (
    <section className="mb-10 rounded-[2.75rem] border border-white/12 bg-white/7 p-5 text-foreground backdrop-blur-2xl sm:p-6">
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.24em] text-primary">Timeline vivante</p>
          <h2 className="mt-2 text-3xl font-black tracking-tight text-foreground">Le calendrier vivant du mariage</h2>
          <p className="mt-2 max-w-2xl text-sm font-semibold leading-relaxed text-muted-foreground">
            Lecture non destructive : la Timeline visuelle reste principale, cette couche relie moments, personnes, RSVP, photos, documents et actions Cerise.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-2xl bg-background/70 px-3 py-2"><p className="text-lg font-black">{visibleItems.length}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">signaux</p></div>
          <div className="rounded-2xl bg-background/70 px-3 py-2"><p className="text-lg font-black">{attentionItems.length}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">à confirmer</p></div>
          <div className="rounded-2xl bg-background/70 px-3 py-2"><p className="text-lg font-black">{dayOfItems.length}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">Jour J</p></div>
        </div>
      </div>

      <div className="mb-6 grid gap-3 lg:grid-cols-3">
        <div className="rounded-[2rem] border border-white/10 bg-background/60 p-4">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-primary">Passé</p>
          <p className="text-sm font-semibold text-muted-foreground">Décisions, messages, photos et actions Cerise validées resteront visibles comme mémoire utile.</p>
        </div>
        <div className="rounded-[2rem] border border-primary/25 bg-primary/10 p-4">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-primary">Présent</p>
          <p className="text-sm font-semibold text-foreground">Les éléments à confirmer, les RSVP sensibles et les consignes Jour J remontent ici en priorité.</p>
        </div>
        <div className="rounded-[2rem] border border-white/10 bg-background/60 p-4">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-primary">Futur</p>
          <p className="text-sm font-semibold text-muted-foreground">Moments, rappels, briefs prestataires, documents et messages prêts à valider structurent la suite.</p>
        </div>
      </div>

      {loading ? (
        <div className="rounded-2xl bg-background/70 p-4 text-sm font-semibold text-muted-foreground">Chargement de la Timeline vivante…</div>
      ) : (
        <>
          {internalControls && (
            <TimelineControlPanel audience={selectedAudience} onAudienceChange={setSelectedAudience} items={items} visibleItems={visibleItems} />
          )}
        <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
          <div className="space-y-3">
            <h3 className="text-lg font-black text-foreground">À confirmer maintenant</h3>
            {attentionItems.length ? attentionItems.map((item) => {
              const Icon = typeIcons[item.type] || Sparkles;
              return (
                <article key={item.id} className="rounded-[1.75rem] border border-white/10 bg-background/70 p-4">
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Icon className="h-4 w-4" /></div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-black text-foreground">{item.title}</p>
                          <TypeBadge item={item} />
                        </div>
                        <p className="mt-1 text-xs font-semibold text-muted-foreground">{statusLabels[item.status] || item.status} · source : {sourceLabels[item.source] || item.source}</p>
                      </div>
                    </div>
                    <TimelineVisibilityBadge visibility={item.visibility} />
                  </div>
                  {item.recommended_action && <p className="text-xs font-bold text-muted-foreground">Action : {item.recommended_action}</p>}
                </article>
              );
            }) : (
              <div className="rounded-2xl bg-background/70 p-4 text-sm font-semibold text-muted-foreground">Aucun élément critique pour le moment.</div>
            )}
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-black text-foreground">Lecture vivante des éléments</h3>
            {!previewItems.length && selectedAudience === "public" && (
              <div className="rounded-2xl bg-background/70 p-4 text-sm font-semibold text-muted-foreground">Aucun élément public pour le moment. Les informations seront visibles ici uniquement après validation.</div>
            )}
            {!previewItems.length && selectedAudience === "guests" && (
              <div className="rounded-2xl bg-background/70 p-4 text-sm font-semibold text-muted-foreground">Aucune information invitée validée pour le moment.</div>
            )}
            {!previewItems.length && selectedAudience === "providers" && (
              <div className="rounded-2xl bg-background/70 p-4 text-sm font-semibold text-muted-foreground">Aucun brief ou moment prestataire validé pour le moment.</div>
            )}
            {!previewItems.length && !["public", "guests", "providers"].includes(selectedAudience) && (
              <div className="rounded-2xl bg-background/70 p-4 text-sm font-semibold text-muted-foreground">Aucun élément visible pour cette audience.</div>
            )}
            {previewItems.map((item) => {
              const Icon = typeIcons[item.type] || Sparkles;
              const linkedPeople = findPeople([...(item.related_person_ids || []), ...(item.related_provider_ids || [])]);
              return (
                <article key={item.id} className="rounded-[1.75rem] border border-white/10 bg-background/70 p-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="flex gap-3">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-primary"><Icon className="h-4 w-4" /></div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-black text-foreground">{item.time ? `${item.time} · ` : ""}{item.title}</p>
                          <TypeBadge item={item} />
                          {item.requires_validation && <span className="rounded-full bg-primary/10 px-2 py-1 text-[10px] font-black uppercase text-primary">validation humaine</span>}
                        </div>
                        <p className="mt-1 text-xs font-semibold text-muted-foreground">{item.type} · {statusLabels[item.status] || item.status} · source : {sourceLabels[item.source] || item.source}</p>
                        {item.location && <p className="mt-1 text-xs font-semibold text-muted-foreground">Lieu : {item.location}</p>}
                        {internalControls && (item.registered_relations?.length ? <p className="mt-1 text-[11px] font-black uppercase tracking-widest text-primary">relation enregistrée</p> : <p className="mt-1 text-[11px] font-black uppercase tracking-widest text-muted-foreground">relation déduite</p>)}
                      </div>
                    </div>
                    <div className="flex flex-col items-start gap-2 sm:items-end">
                      <TimelineVisibilityBadge visibility={item.visibility} />
                      {internalControls && <button onClick={() => setInspectedItem(item)} className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-muted-foreground hover:bg-white/10 hover:text-foreground">Inspecter</button>}
                    </div>
                  </div>

                  {linkedPeople.length > 0 && (
                    <div className="mt-4 flex flex-wrap items-center gap-2">
                      {linkedPeople.map((person) => (
                        <div key={person.id} className="flex items-center gap-2 rounded-full bg-white/8 py-1 pl-1 pr-3 text-xs font-bold text-foreground">
                          <img src={person.photo_url} alt={person.full_name} className="h-7 w-7 rounded-full object-cover" />
                          <span>{person.full_name}</span>
                          <span className="text-muted-foreground">· {person.display_role || person.role}</span>
                          <span className="text-muted-foreground">· {person.group || person.side}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </div>
        </>
      )}
      {internalControls && <TimelineItemInspector item={inspectedItem} people={people} audience={selectedAudience} onClose={() => setInspectedItem(null)} />}
    </section>
  );
}