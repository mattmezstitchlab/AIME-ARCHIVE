import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Archive, CheckCircle2, EyeOff, Filter, UserCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { initialWeddingMoments } from "@/components/wedding/weddingData";

const statusLabels = {
  deduced: "déduite",
  to_verify: "à vérifier",
  validated: "validée",
  ignored: "ignorée",
  archived: "archivée",
};

const Stat = ({ label, value }) => (
  <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2">
    <p className="text-lg font-black text-foreground">{value}</p>
    <p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">{label}</p>
  </div>
);

const getStatus = (relation) => relation.relation_status || (relation.sync_status === "to_verify" ? "to_verify" : relation.sync_status === "synced" ? "validated" : "deduced");
const getMomentId = (timelineItemId = "") => timelineItemId.replace("weddingData-", "");
const getMomentTitle = (timelineItemId) => initialWeddingMoments.find((moment) => moment.id === getMomentId(timelineItemId))?.title || timelineItemId;

const isGenericRelation = (relation, person, personRelationCount, totalMoments) => {
  if (!person || ["validated", "ignored", "archived"].includes(getStatus(relation))) return false;
  const ratio = totalMoments ? personRelationCount / totalMoments : 0;
  if (["wedding_planner", "photographer"].includes(person.role)) return false;
  if (person.role === "dj") return ratio > 0.45;
  if (person.role === "caterer") return ratio > 0.35;
  if (person.role === "officiant") return ratio > 0.2;
  if (person.role === "witness") return ratio > 0.55;
  return ratio > 0.7;
};

export default function TimelineRelationQualityPanel() {
  const [people, setPeople] = useState([]);
  const [relations, setRelations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ moment: "all", person: "all", role: "all", visibility: "all", status: "all", source: "all", verifyOnly: false });

  const loadData = async () => {
    setLoading(true);
    const [personData, relationData] = await Promise.all([
      base44.entities.Person.list("full_name", 200),
      base44.entities.TimelineRelation.list("-created_date", 500),
    ]);
    setPeople(personData);
    setRelations(relationData);
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);

  const personById = useMemo(() => Object.fromEntries(people.map((person) => [person.id, person])), [people]);
  const relationCountsByPerson = useMemo(() => relations.reduce((acc, relation) => ({ ...acc, [relation.related_id]: (acc[relation.related_id] || 0) + 1 }), {}), [relations]);
  const genericRelationIds = useMemo(() => new Set(relations.filter((relation) => isGenericRelation(relation, personById[relation.related_id], relationCountsByPerson[relation.related_id], initialWeddingMoments.length)).map((relation) => relation.id)), [relations, personById, relationCountsByPerson]);

  const updateRelation = async (relation, status) => {
    await base44.entities.TimelineRelation.update(relation.id, {
      relation_status: status,
      sync_status: status === "validated" ? "synced" : status === "to_verify" ? "to_verify" : relation.sync_status || "deduced",
      requires_validation: status !== "validated",
      quality_note: status === "to_verify" ? "Relation marquée à vérifier par contrôle qualité humain." : status === "ignored" ? "Relation ignorée sans suppression." : status === "archived" ? "Relation archivée sans suppression." : "Relation validée humainement.",
    });
    await loadData();
  };

  const filteredRelations = relations.filter((relation) => {
    const status = getStatus(relation);
    if (filter.moment !== "all" && relation.timeline_item_id !== filter.moment) return false;
    if (filter.person !== "all" && relation.related_id !== filter.person) return false;
    if (filter.role !== "all" && relation.relation_role !== filter.role) return false;
    if (filter.visibility !== "all" && relation.visibility !== filter.visibility) return false;
    if (filter.status !== "all" && status !== filter.status) return false;
    if (filter.source !== "all" && relation.source !== filter.source) return false;
    if (filter.verifyOnly && status !== "to_verify" && !genericRelationIds.has(relation.id)) return false;
    return true;
  });

  const stats = {
    syncedPeople: people.filter((person) => person.source === "weddingData").length,
    total: relations.length,
    validated: relations.filter((relation) => getStatus(relation) === "validated").length,
    toVerify: relations.filter((relation) => getStatus(relation) === "to_verify").length,
    ignored: relations.filter((relation) => getStatus(relation) === "ignored").length,
    archived: relations.filter((relation) => getStatus(relation) === "archived").length,
    deduced: relations.filter((relation) => getStatus(relation) === "deduced").length,
    registered: relations.filter((relation) => relation.id).length,
    duplicateAvoided: Math.max(0, relations.length - new Set(relations.map((relation) => relation.sync_key || `${relation.timeline_item_id}-${relation.related_id}-${relation.relation_role}`)).size),
    generic: genericRelationIds.size,
    ceriseUsable: relations.filter((relation) => getStatus(relation) === "validated" && !["ignored", "archived"].includes(getStatus(relation))).length,
  };

  const unique = (key) => [...new Set(relations.map((relation) => relation[key]).filter(Boolean))];

  if (loading) return <div className="mt-4 rounded-2xl bg-white/5 p-3 text-sm font-semibold text-muted-foreground">Chargement du contrôle qualité…</div>;

  return (
    <div className="mt-4 rounded-[1.5rem] border border-white/10 bg-background/50 p-3">
      <div className="mb-4 flex items-center gap-2">
        <UserCheck className="h-4 w-4 text-primary" />
        <p className="text-xs font-black uppercase tracking-[0.16em] text-primary">Contrôle qualité des relations</p>
      </div>

      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        <Stat label="personnes synchronisées" value={stats.syncedPeople} />
        <Stat label="relations totales" value={stats.total} />
        <Stat label="validées" value={stats.validated} />
        <Stat label="à vérifier" value={stats.toVerify} />
        <Stat label="ignorées" value={stats.ignored} />
        <Stat label="archivées" value={stats.archived} />
        <Stat label="déduites" value={stats.deduced} />
        <Stat label="enregistrées" value={stats.registered} />
        <Stat label="doublons évités" value={stats.duplicateAvoided} />
        <Stat label="trop génériques" value={stats.generic} />
        <Stat label="utilisables par Cerise" value={stats.ceriseUsable} />
      </div>

      <div className="mb-4 rounded-2xl border border-primary/20 bg-primary/10 p-3 text-xs font-bold text-foreground">
        Cerise lit uniquement les relations validées comme fiables, évite de reproposer ce qui est déjà validé, et signale les relations encore à vérifier.
      </div>

      <p className="mb-2 text-[11px] font-black uppercase tracking-widest text-foreground">Personnes synchronisées</p>
      <div className="mb-5 grid gap-2 lg:grid-cols-2">
        {people.map((person) => (
          <article key={person.id} className="rounded-2xl border border-white/8 bg-white/5 p-3">
            <div className="flex items-center gap-3">
              {person.photo_url && <img src={person.photo_url} alt={person.full_name} className="h-11 w-11 rounded-full object-cover" />}
              <div className="min-w-0">
                <p className="font-black text-foreground">{person.full_name}</p>
                <p className="text-xs font-semibold text-muted-foreground">{person.display_role || person.role} · {person.group || "—"} / {person.side || "—"}</p>
                <p className="text-xs font-semibold text-muted-foreground">source : {person.source || "—"} · {statusLabels[person.sync_status] || person.sync_status || "déduite"} · {person.visibility}</p>
              </div>
            </div>
            <p className="mt-2 text-xs font-bold text-primary">{relationCountsByPerson[person.id] || 0} relation(s) liée(s)</p>
          </article>
        ))}
      </div>

      <div className="mb-3 flex items-center gap-2">
        <Filter className="h-4 w-4 text-primary" />
        <p className="text-[11px] font-black uppercase tracking-widest text-foreground">Relations créées</p>
      </div>

      <div className="mb-3 grid gap-2 md:grid-cols-4">
        <select className="rounded-xl bg-background/70 p-2 text-xs font-bold" value={filter.moment} onChange={(e) => setFilter({ ...filter, moment: e.target.value })}>
          <option value="all">Tous les moments</option>
          {unique("timeline_item_id").map((id) => <option key={id} value={id}>{getMomentTitle(id)}</option>)}
        </select>
        <select className="rounded-xl bg-background/70 p-2 text-xs font-bold" value={filter.person} onChange={(e) => setFilter({ ...filter, person: e.target.value })}>
          <option value="all">Toutes les personnes</option>
          {people.map((person) => <option key={person.id} value={person.id}>{person.full_name}</option>)}
        </select>
        <select className="rounded-xl bg-background/70 p-2 text-xs font-bold" value={filter.role} onChange={(e) => setFilter({ ...filter, role: e.target.value })}>
          <option value="all">Tous les rôles relationnels</option>
          {unique("relation_role").map((role) => <option key={role} value={role}>{role}</option>)}
        </select>
        <select className="rounded-xl bg-background/70 p-2 text-xs font-bold" value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })}>
          <option value="all">Tous les statuts</option>
          {Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select>
        <select className="rounded-xl bg-background/70 p-2 text-xs font-bold" value={filter.visibility} onChange={(e) => setFilter({ ...filter, visibility: e.target.value })}>
          <option value="all">Toutes les visibilités</option>
          {unique("visibility").map((visibility) => <option key={visibility} value={visibility}>{visibility}</option>)}
        </select>
        <select className="rounded-xl bg-background/70 p-2 text-xs font-bold" value={filter.source} onChange={(e) => setFilter({ ...filter, source: e.target.value })}>
          <option value="all">Toutes les sources</option>
          {unique("source").map((source) => <option key={source} value={source}>{source}</option>)}
        </select>
        <button onClick={() => setFilter({ ...filter, verifyOnly: !filter.verifyOnly })} className={`rounded-xl p-2 text-xs font-black ${filter.verifyOnly ? "bg-primary text-primary-foreground" : "bg-white/5 text-muted-foreground"}`}>À vérifier seulement</button>
      </div>

      <div className="max-h-[28rem] space-y-2 overflow-auto pr-1">
        {filteredRelations.map((relation) => {
          const person = personById[relation.related_id];
          const status = getStatus(relation);
          const generic = genericRelationIds.has(relation.id);
          return (
            <article key={relation.id} className="rounded-2xl border border-white/8 bg-white/5 p-3">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <p className="text-sm font-black text-foreground">{getMomentTitle(relation.timeline_item_id)} → {person?.full_name || relation.related_id}</p>
                  <p className="mt-1 text-xs font-semibold text-muted-foreground">rôle : {relation.relation_role} · visibilité : {relation.visibility} · source : {relation.source || "—"}</p>
                  <p className="mt-1 text-xs font-semibold text-muted-foreground">statut : {statusLabels[status] || status} · sync : {relation.sync_status || "deduced"} · validation humaine : {relation.requires_validation ? "requise" : "validée"}</p>
                  {generic && <p className="mt-2 inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-1 text-[10px] font-black uppercase text-primary"><AlertTriangle className="h-3 w-3" /> relation potentiellement trop générique</p>}
                </div>
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => updateRelation(relation, "validated")} className="rounded-full bg-primary px-3 py-1.5 text-[10px] font-black uppercase text-primary-foreground"><CheckCircle2 className="mr-1 inline h-3 w-3" /> Valider</button>
                  <button onClick={() => updateRelation(relation, "to_verify")} className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-black uppercase text-foreground">À vérifier</button>
                  <button onClick={() => updateRelation(relation, "ignored")} className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-black uppercase text-muted-foreground"><EyeOff className="mr-1 inline h-3 w-3" /> Ignorer</button>
                  <button onClick={() => updateRelation(relation, "archived")} className="rounded-full border border-white/10 px-3 py-1.5 text-[10px] font-black uppercase text-muted-foreground"><Archive className="mr-1 inline h-3 w-3" /> Archiver</button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}