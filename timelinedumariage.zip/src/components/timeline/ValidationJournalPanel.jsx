import { useEffect, useMemo, useState } from "react";
import { Archive, CheckCircle2, Clock, FileText, MessageSquare, ShieldCheck, Sparkles, XCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { getHumanValidationLogs } from "@/lib/humanValidationLog";

const filters = ["Tout", "Validé", "À vérifier", "Ignoré", "Archivé", "Brouillons", "Cerise", "Relations", "Messages", "Jour J"];

const actionLabels = {
  relation_validated: "Relation validée",
  relation_ignored: "Relation ignorée",
  relation_archived: "Relation archivée",
  relation_marked_to_verify: "Relation à vérifier",
  timeline_item_validated: "TimelineItem validé",
  draft_created: "Brouillon créé",
  private_note_added: "Note privée ajoutée",
  cerise_suggestion_applied: "Suggestion Cerise appliquée",
  cerise_suggestion_ignored: "Suggestion Cerise ignorée",
  message_prepared_not_sent: "Message préparé, non envoyé",
  visibility_changed: "Visibilité changée",
  other: "Action humaine",
};

const statusIcon = {
  validated: CheckCircle2,
  applied: CheckCircle2,
  to_verify: Clock,
  draft: MessageSquare,
  ignored: XCircle,
  archived: Archive,
};

const formatDate = (value) => value ? new Date(value).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "Date inconnue";

const normalizeEntries = ({ humanLogs, ceriseLogs, drafts, relations }) => [
  ...humanLogs.map((log) => ({
    id: `human-${log.id}`,
    date: log.created_date,
    action: actionLabels[log.action_type] || actionLabels.other,
    actionType: log.action_type,
    source: log.source,
    target: log.target_label || log.target_id || "Élément concerné",
    before: log.status_before || "—",
    after: log.status_after,
    personOrAudience: log.person_or_audience || "—",
    visibility: log.visibility,
    author: log.author_type,
    external: log.external_action_triggered,
    category: log.target_type,
  })),
  ...ceriseLogs.map((log) => ({
    id: `cerise-${log.id}`,
    date: log.created_date,
    action: log.action_label || "Action Cerise",
    actionType: log.action_type,
    source: "cerise",
    target: log.result || log.target_id || "Suggestion Cerise",
    before: "—",
    after: log.status,
    personOrAudience: "Cerise",
    visibility: log.visibility || "internal",
    author: "human",
    external: false,
    category: "cerise",
  })),
  ...drafts.map((draft) => ({
    id: `draft-${draft.id}`,
    date: draft.created_date,
    action: "Brouillon créé",
    actionType: "draft_created",
    source: draft.source || "manual",
    target: draft.message_body?.slice(0, 80) || "Brouillon",
    before: "—",
    after: draft.status,
    personOrAudience: draft.recipient_type || "custom",
    visibility: draft.visibility,
    author: "human",
    external: false,
    category: "message",
  })),
  ...relations.map((relation) => ({
    id: `relation-${relation.id}`,
    date: relation.updated_date || relation.created_date,
    action: relation.relation_status === "validated" ? "Relation validée" : relation.relation_status === "archived" ? "Relation archivée" : relation.relation_status === "ignored" ? "Relation ignorée" : "Relation à vérifier",
    actionType: relation.relation_status === "validated" ? "relation_validated" : relation.relation_status === "archived" ? "relation_archived" : relation.relation_status === "ignored" ? "relation_ignored" : "relation_marked_to_verify",
    source: relation.source || "relation",
    target: relation.related_id,
    before: "—",
    after: relation.relation_status || relation.sync_status || "deduced",
    personOrAudience: relation.related_type,
    visibility: relation.visibility,
    author: "human",
    external: false,
    category: "relation",
  })),
].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

const matchesFilter = (entry, filter) => {
  if (filter === "Tout") return true;
  if (filter === "Validé") return ["validated", "applied"].includes(entry.after) || entry.actionType.includes("validated");
  if (filter === "À vérifier") return entry.after === "to_verify" || entry.actionType.includes("to_verify");
  if (filter === "Ignoré") return entry.after === "ignored" || entry.actionType.includes("ignored");
  if (filter === "Archivé") return entry.after === "archived" || entry.actionType.includes("archived");
  if (filter === "Brouillons") return entry.actionType.includes("draft") || entry.after === "draft";
  if (filter === "Cerise") return entry.source === "cerise" || entry.category === "cerise";
  if (filter === "Relations") return entry.category === "relation";
  if (filter === "Messages") return entry.category === "message";
  if (filter === "Jour J") return entry.source === "day_of_panel" || entry.category === "day_of";
  return true;
};

export default function ValidationJournalPanel({ audience = "couple_admin" }) {
  const [filter, setFilter] = useState("Tout");
  const [data, setData] = useState({ humanLogs: [], ceriseLogs: [], drafts: [], relations: [] });

  useEffect(() => {
    if (audience !== "couple_admin") return;
    Promise.all([
      getHumanValidationLogs(80),
      base44.entities.CeriseActionLog.list("-created_date", 40),
      base44.entities.TimelineMessage.filter({ status: "draft" }, "-created_date", 30),
      base44.entities.TimelineRelation.list("-updated_date", 40),
    ]).then(([humanLogs, ceriseLogs, drafts, relations]) => {
      setData({ humanLogs, ceriseLogs, drafts, relations });
    });
  }, [audience]);

  const entries = useMemo(() => normalizeEntries(data).filter((entry) => matchesFilter(entry, filter)).slice(0, 30), [data, filter]);

  if (audience !== "couple_admin") return null;

  return (
    <section className="mb-10 rounded-[2.5rem] border border-white/12 bg-white/7 p-5 text-foreground backdrop-blur-2xl sm:p-6">
      <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.22em] text-primary"><ShieldCheck className="h-4 w-4" /> Journal interne</p>
          <h2 className="mt-2 text-3xl font-black tracking-tight">Journal de validation humaine</h2>
          <p className="mt-2 max-w-2xl text-sm font-semibold text-muted-foreground">Trace les validations, refus, brouillons et décisions humaines. Aucune action externe n’est déclenchée.</p>
        </div>
        <div className="rounded-2xl bg-background/70 px-4 py-3 text-sm font-black text-primary">{entries.length} entrées affichées</div>
      </div>

      <div className="mb-5 flex gap-2 overflow-x-auto pb-2">
        {filters.map((item) => (
          <Button key={item} size="sm" variant={filter === item ? "default" : "outline"} onClick={() => setFilter(item)} className="shrink-0 rounded-full">
            {item}
          </Button>
        ))}
      </div>

      <div className="grid gap-3">
        {entries.length ? entries.map((entry) => {
          const Icon = statusIcon[entry.after] || (entry.source === "cerise" ? Sparkles : FileText);
          return (
            <article key={entry.id} className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-primary"><Icon className="h-4 w-4" /></div>
                  <div>
                    <p className="text-sm font-black text-foreground">{entry.action}</p>
                    <p className="mt-1 text-xs font-semibold text-muted-foreground">{entry.target}</p>
                    <p className="mt-1 text-xs font-semibold text-muted-foreground">Avant : {entry.before} · Après : {entry.after} · Audience/personne : {entry.personOrAudience}</p>
                  </div>
                </div>
                <div className="text-left text-xs font-bold text-muted-foreground sm:text-right">
                  <p>{formatDate(entry.date)}</p>
                  <p>{entry.source} · {entry.visibility}</p>
                  <p>{entry.external ? "Action externe déclenchée" : "Aucune action externe"}</p>
                </div>
              </div>
            </article>
          );
        }) : (
          <div className="rounded-2xl bg-background/60 p-4 text-sm font-bold text-muted-foreground">Aucune entrée pour ce filtre.</div>
        )}
      </div>
    </section>
  );
}