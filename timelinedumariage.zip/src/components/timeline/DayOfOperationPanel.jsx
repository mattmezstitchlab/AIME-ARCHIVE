import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Clipboard, Clock, Copy, MessageSquare, ShieldCheck, Sparkles, UserCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import TimelineVisibilityBadge from "./TimelineVisibilityBadge";
import { loadLivingTimelineItems } from "@/lib/timelineAdapter";
import { accessMatrix, canViewTimelineItem } from "@/lib/timelineVisibility";
import { createHumanValidationLog, getHumanValidationLogs, hasExistingDraftForTarget, isIgnoredOrArchived } from "@/lib/humanValidationLog";

const roleGroups = {
  Couple: ["bride", "groom"],
  Témoins: ["witness"],
  Famille: ["family"],
  Invités: ["guest"],
  Prestataires: ["provider", "dj", "photographer", "caterer", "officiant", "musician", "florist", "wedding_planner"],
};

const statusLabels = {
  planned: "prévu",
  to_confirm: "à confirmer",
  confirmed: "confirmé",
  in_progress: "en cours",
  done: "fait",
};

const toMinutes = (time = "") => {
  const [hours, minutes] = time.split(":").map(Number);
  if (Number.isNaN(hours) || Number.isNaN(minutes)) return null;
  return hours * 60 + minutes;
};

const getRelationStatus = (relation) => relation.relation_status || (relation.sync_status === "synced" ? "validated" : relation.sync_status === "to_verify" ? "to_verify" : "deduced");

const canViewRelation = (relation, audience) => {
  if (audience === "couple_admin") return true;
  if (["private_couple", "admin", "internal"].includes(relation.visibility)) return false;
  return (accessMatrix[audience] || accessMatrix.public).includes(relation.visibility);
};

const PersonPill = ({ relation }) => {
  const person = relation.related_person;
  if (!person) return null;
  const status = getRelationStatus(relation);
  return (
    <div className="flex items-center gap-2 rounded-full bg-background/80 py-1 pl-1 pr-3 text-xs font-bold text-foreground">
      {person.photo_url && <img src={person.photo_url} alt={person.full_name} className="h-8 w-8 rounded-full object-cover" />}
      <span>{person.full_name}</span>
      <span className="text-muted-foreground">· {person.display_role || person.role}</span>
      <span className={status === "validated" ? "text-primary" : "text-muted-foreground"}>· {status === "validated" ? "validée" : "à vérifier"}</span>
      <span className="text-muted-foreground">· {relation.visibility}</span>
    </div>
  );
};

const MomentCard = ({ title, item, emptyLabel }) => (
  <article className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
    <p className="mb-2 text-xs font-black uppercase tracking-[0.16em] text-primary">{title}</p>
    {item ? (
      <>
        <h3 className="text-xl font-black text-foreground">{item.time ? `${item.time} · ` : ""}{item.title}</h3>
        <p className="mt-2 text-sm font-semibold text-muted-foreground">{item.location || "Lieu à confirmer"} · {statusLabels[item.status] || item.status}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <TimelineVisibilityBadge visibility={item.visibility} />
          {item.requires_validation && <span className="rounded-full bg-primary/10 px-3 py-1 text-[11px] font-black uppercase text-primary">validation humaine</span>}
        </div>
      </>
    ) : (
      <p className="text-sm font-bold text-muted-foreground">{emptyLabel}</p>
    )}
  </article>
);

export default function DayOfOperationPanel({ audience = "couple_admin" }) {
  const [items, setItems] = useState([]);
  const [people, setPeople] = useState([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState("");
  const [note, setNote] = useState("");
  const [validationLogs, setValidationLogs] = useState([]);

  useEffect(() => {
    Promise.all([
      loadLivingTimelineItems(),
      base44.entities.Person.list("full_name", 200),
      getHumanValidationLogs(80),
    ]).then(([timelineItems, personItems, logs]) => {
      setItems(timelineItems);
      setPeople(personItems);
      setValidationLogs(logs);
      setLoading(false);
    });
  }, []);

  const dayMoments = useMemo(() => items
    .filter((item) => item.type === "wedding_moment" && canViewTimelineItem(item, audience))
    .sort((a, b) => (toMinutes(a.time) ?? 9999) - (toMinutes(b.time) ?? 9999)), [items, audience]);

  const { currentMoment, nextMoment } = useMemo(() => {
    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const withTime = dayMoments.filter((item) => toMinutes(item.time) !== null);
    const isWeddingDay = withTime.some((item) => item.date === today);
    const next = withTime.find((item) => item.date > today || (item.date === today && toMinutes(item.time) >= currentMinutes)) || withTime[0] || null;
    const current = isWeddingDay ? withTime.filter((item) => item.date === today && toMinutes(item.time) <= currentMinutes).slice(-1)[0] || null : null;
    return { currentMoment: current, nextMoment: next };
  }, [dayMoments]);

  const focusMoment = nextMoment || currentMoment;
  const relevantLogs = validationLogs.filter((log) => log.target_id === focusMoment?.id || log.target_label === focusMoment?.title);
  const allVisibleRelations = (focusMoment?.all_registered_relations || []).filter((relation) => canViewRelation(relation, audience));
  const inactiveRelations = allVisibleRelations.filter((relation) => ["ignored", "archived"].includes(getRelationStatus(relation)));
  const activeRelations = allVisibleRelations.filter((relation) => !["ignored", "archived"].includes(getRelationStatus(relation)));
  const validatedRelations = activeRelations.filter((relation) => getRelationStatus(relation) === "validated");
  const toVerifyRelations = activeRelations.filter((relation) => getRelationStatus(relation) === "to_verify" || getRelationStatus(relation) === "deduced");
  const providerRelations = activeRelations.filter((relation) => ["provider", "dj", "photographer", "caterer", "officiant", "musician", "florist", "wedding_planner"].includes(relation.related_person?.role));

  const groupedRelations = useMemo(() => {
    const groups = Object.fromEntries([...Object.keys(roleGroups), "À vérifier"].map((group) => [group, []]));
    activeRelations.forEach((relation) => {
      const status = getRelationStatus(relation);
      const role = relation.related_person?.role;
      if (status !== "validated") {
        groups["À vérifier"].push(relation);
        return;
      }
      const groupName = Object.entries(roleGroups).find(([, roles]) => roles.includes(role))?.[0] || "Invités";
      groups[groupName].push(relation);
    });
    return groups;
  }, [activeRelations]);

  const priorities = useMemo(() => {
    if (!focusMoment) return ["Moment actuel à confirmer."];
    const result = [];
    if (relevantLogs.some(isIgnoredOrArchived)) result.push("Une action liée a déjà été ignorée ou archivée.");
    if (hasExistingDraftForTarget(validationLogs, focusMoment.id)) result.push("Un brouillon existe déjà.");
    if (validatedRelations[0]?.related_person) result.push(`${validatedRelations[0].related_person.full_name} est déjà lié à ce moment.`);
    if (toVerifyRelations[0]?.related_person) result.push(`${toVerifyRelations[0].related_person.full_name} est à vérifier pour ce moment.`);
    if (!validatedRelations.some((relation) => relation.relation_role === "responsible")) result.push("Aucun responsable confirmé pour ce moment.");
    if (providerRelations.length) result.push("Brief prestataire à préparer.");
    if (focusMoment.requires_validation) result.push("Message prêt à valider.");
    return result.slice(0, 3);
  }, [focusMoment, validatedRelations, toVerifyRelations, providerRelations, relevantLogs, validationLogs]);

  const prepareDraft = () => {
    if (!focusMoment) return;
    setDraft(`Bonjour, rappel : le moment “${focusMoment.title}” est prévu à ${focusMoment.time || "horaire à confirmer"}. Merci de vous tenir prêt${focusMoment.location ? ` près de ${focusMoment.location}` : ""}.`);
  };

  const addDraftToTimeline = async () => {
    if (!draft || !focusMoment) return;
    await base44.entities.TimelineMessage.create({
      timeline_item_id: focusMoment.id,
      recipient_type: "custom",
      message_body: draft,
      status: "draft",
      visibility: "private_couple",
      source: "cerise",
      validation_required: true,
    });
    await createHumanValidationLog({
      action_type: "draft_created",
      source: "day_of_panel",
      target_type: "message",
      target_id: focusMoment.id,
      target_label: focusMoment.title,
      status_before: "none",
      status_after: "draft",
      person_or_audience: "custom",
      visibility: "internal",
      author_type: "human",
      notes: "Brouillon ajouté à la Timeline. Aucun envoi réel.",
    });
  };

  const markMomentToVerify = async () => {
    if (!focusMoment?.id || focusMoment.source === "weddingData") return;
    await base44.entities.TimelineItem.update(focusMoment.id, { status: "to_confirm", requires_validation: true });
  };

  const addPrivateNote = async () => {
    if (!note || !focusMoment) return;
    const privateNote = await base44.entities.TimelineItem.create({
      title: `Note privée — ${focusMoment.title}`,
      type: "private_note",
      date: focusMoment.date,
      time: focusMoment.time,
      description: note,
      status: "to_confirm",
      priority: "To confirm",
      visibility: "private_couple",
      source: "manual",
      requires_validation: true,
    });
    await createHumanValidationLog({
      action_type: "private_note_added",
      source: "day_of_panel",
      target_type: "note",
      target_id: privateNote.id,
      target_label: privateNote.title,
      status_before: "none",
      status_after: "to_verify",
      person_or_audience: "couple/admin",
      visibility: "internal",
      author_type: "human",
      notes: "Note privée créée en visibilité couple/admin.",
    });
    setNote("");
  };

  const updateRelation = async (relation, status) => {
    const previousStatus = getRelationStatus(relation);
    await base44.entities.TimelineRelation.update(relation.id, {
      relation_status: status,
      sync_status: status === "validated" ? "synced" : "to_verify",
      requires_validation: status !== "validated",
      quality_note: status === "validated" ? "Relation validée humainement depuis le Mode Jour J." : "Relation marquée à vérifier depuis le Mode Jour J.",
    });
    await createHumanValidationLog({
      action_type: status === "validated" ? "relation_validated" : "relation_marked_to_verify",
      source: "day_of_panel",
      target_type: "relation",
      target_id: relation.id,
      target_label: relation.related_person?.full_name || relation.related_id,
      status_before: previousStatus,
      status_after: status,
      person_or_audience: relation.related_person?.display_role || relation.related_person?.role || relation.related_type,
      visibility: "internal",
      author_type: "human",
      notes: "Décision humaine enregistrée. Aucune action externe.",
    });
  };

  if (loading) return <section className="mb-10 rounded-[2rem] border border-white/10 bg-white/7 p-5 text-sm font-bold text-muted-foreground">Chargement du Mode Jour J…</section>;

  return (
    <section className="mb-10 rounded-[2.5rem] border border-primary/20 bg-white/7 p-5 text-foreground backdrop-blur-2xl sm:p-6">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.22em] text-primary"><ShieldCheck className="h-4 w-4" /> Mode Jour J</p>
          <h2 className="mt-2 text-3xl font-black tracking-tight">Lecture opérationnelle minimale</h2>
          <p className="mt-2 text-sm font-semibold text-muted-foreground">Cerise propose. L’humain valide. Aucun message n’est envoyé automatiquement.</p>
        </div>
        <div className="rounded-2xl bg-background/70 px-4 py-3 text-sm font-black text-primary">{dayMoments.length} moments lisibles</div>
      </div>

      <div className="mb-5 grid gap-4 lg:grid-cols-2">
        <MomentCard title="Moment actuel" item={currentMoment} emptyLabel="Moment actuel à confirmer." />
        <MomentCard title="Prochain moment" item={nextMoment} emptyLabel="Prochain moment à confirmer." />
      </div>

      {focusMoment && (
        <div className="grid gap-5 xl:grid-cols-[0.9fr_1.1fr]">
          <div className="space-y-4">
            <article className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
              <p className="mb-3 flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-primary"><Sparkles className="h-4 w-4" /> Priorités Cerise</p>
              <div className="space-y-2">
                {priorities.map((priority) => <p key={priority} className="rounded-2xl bg-white/8 p-3 text-sm font-bold text-foreground">{priority}</p>)}
              </div>
            </article>

            <article className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
              <p className="mb-3 flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-primary"><MessageSquare className="h-4 w-4" /> Message brouillon</p>
              <Button onClick={prepareDraft} variant="outline" className="mb-3 rounded-full">Préparer un message</Button>
              {draft && <Textarea value={draft} onChange={(event) => setDraft(event.target.value)} className="min-h-24 bg-background/70" />}
              {draft && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button variant="outline" onClick={() => navigator.clipboard.writeText(draft)}><Copy className="h-4 w-4" /> Copier</Button>
                  <Button variant="outline" onClick={addDraftToTimeline}><Clipboard className="h-4 w-4" /> Ajouter à la Timeline</Button>
                  <Button variant="outline" onClick={() => setDraft(`${draft}\n\nÀ vérifier avant envoi.`)}><UserCheck className="h-4 w-4" /> Marquer à vérifier</Button>
                </div>
              )}
            </article>

            <article className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
              <p className="mb-3 text-xs font-black uppercase tracking-[0.16em] text-primary">Actions humaines prudentes</p>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={markMomentToVerify} disabled={focusMoment.source === "weddingData"}>Marquer ce moment comme à vérifier</Button>
                <Button variant="outline" onClick={() => window.dispatchEvent(new CustomEvent("openCerise", { detail: { diagnosis: `Préparer le moment ${focusMoment.title}`, action: "Proposer une consigne courte, sans envoi automatique." } }))}>Demander à Cerise</Button>
              </div>
              <Textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Ajouter une note privée…" className="mt-3 min-h-20 bg-background/70" />
              <Button className="mt-3 rounded-full" onClick={addPrivateNote} disabled={!note}>Ajouter une note privée</Button>
            </article>
          </div>

          <div className="space-y-4">
            <article className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
              <p className="mb-3 text-xs font-black uppercase tracking-[0.16em] text-primary">Relations Jour J</p>
              <div className="mb-3 grid grid-cols-2 gap-2 text-xs font-bold text-muted-foreground sm:grid-cols-4">
                <span>Validées : {validatedRelations.length}</span>
                <span>À vérifier : {toVerifyRelations.length}</span>
                <span>Ignorées : {inactiveRelations.filter((relation) => getRelationStatus(relation) === "ignored").length}</span>
                <span>Archivées : {inactiveRelations.filter((relation) => getRelationStatus(relation) === "archived").length}</span>
              </div>
              <div className="space-y-3">
                {Object.entries(groupedRelations).map(([group, relations]) => (
                  <div key={group}>
                    <p className="mb-2 text-[11px] font-black uppercase tracking-widest text-muted-foreground">{group}</p>
                    {relations.length ? <div className="flex flex-wrap gap-2">{relations.map((relation) => <PersonPill key={relation.id} relation={relation} />)}</div> : <p className="text-xs font-semibold text-muted-foreground">Aucune relation affichable.</p>}
                  </div>
                ))}
              </div>
            </article>

            <article className="rounded-[1.5rem] border border-white/10 bg-background/60 p-4">
              <p className="mb-3 text-xs font-black uppercase tracking-[0.16em] text-primary">Validations récentes liées</p>
              <div className="mb-4 space-y-2">
                {relevantLogs.slice(0, 3).map((log) => <p key={log.id} className="rounded-2xl bg-white/8 p-3 text-xs font-bold text-muted-foreground">{log.action_type} · {log.status_after} · aucune action externe</p>)}
                {!relevantLogs.length && <p className="text-xs font-semibold text-muted-foreground">Aucune validation récente liée à ce moment.</p>}
              </div>
              <p className="mb-3 text-xs font-black uppercase tracking-[0.16em] text-primary">Validation relationnelle</p>
              <div className="space-y-2">
                {activeRelations.map((relation) => (
                  <div key={relation.id} className="rounded-2xl bg-white/8 p-3">
                    <p className="text-sm font-black text-foreground">{relation.related_person?.full_name || relation.related_id}</p>
                    <p className="text-xs font-semibold text-muted-foreground">{relation.relation_role} · {getRelationStatus(relation) === "validated" ? "validée" : "à vérifier"} · {relation.visibility}</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Button size="sm" variant="outline" onClick={() => updateRelation(relation, "validated")}><CheckCircle2 className="h-3 w-3" /> Valider une relation</Button>
                      <Button size="sm" variant="outline" onClick={() => updateRelation(relation, "to_verify")}><Clock className="h-3 w-3" /> Marquer à vérifier</Button>
                    </div>
                  </div>
                ))}
              </div>
            </article>
          </div>
        </div>
      )}
    </section>
  );
}