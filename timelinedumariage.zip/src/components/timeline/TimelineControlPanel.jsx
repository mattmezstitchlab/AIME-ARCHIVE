import { useState } from "react";
import { ChevronDown, ChevronUp, EyeOff, SlidersHorizontal, Sparkles } from "lucide-react";
import { isSensitiveTimelineItem } from "@/lib/timelineVisibility";
import TimelineSoftSyncPanel from "./TimelineSoftSyncPanel";

const audiences = [
  { value: "couple_admin", label: "Vue couple/admin" },
  { value: "guests", label: "Vue invités" },
  { value: "providers", label: "Vue prestataires" },
  { value: "family", label: "Vue famille" },
  { value: "witnesses", label: "Vue témoins" },
  { value: "public", label: "Vue publique" },
];

const countBy = (items, predicate) => items.filter(predicate).length;

export default function TimelineControlPanel({ audience, onAudienceChange, items, visibleItems }) {
  const [isOpen, setIsOpen] = useState(true);
  const visibleIds = new Set(visibleItems.map((item) => item.id));
  const hiddenCount = items.length - visibleItems.length;
  const sensitiveHiddenCount = countBy(items, (item) => isSensitiveTimelineItem(item) && !visibleIds.has(item.id));
  const privateAdminCount = countBy(items, (item) => ["private_couple", "admin", "internal"].includes(item.visibility));
  const publicCount = countBy(items, (item) => item.visibility === "public");
  const toConfirmCount = countBy(items, (item) => item.status === "to_confirm" || item.requires_validation);
  const ceriseItems = items.filter((item) => item.source === "cerise");
  const appliedSuggestions = ceriseItems.filter((item) => item.status === "to_confirm" || item.status === "done").length;
  const ignoredSuggestions = ceriseItems.filter((item) => item.status === "ignored").length;
  const ceriseTimelineItems = ceriseItems.filter((item) => item.cerise_suggestion_id && !String(item.id).startsWith("cerise-suggestion-")).length;
  const duplicateAvoided = Math.max(0, ceriseItems.filter((item) => item.cerise_suggestion_id).length - new Set(ceriseItems.map((item) => item.cerise_suggestion_id).filter(Boolean)).size);

  const counters = [
    ["Moments", countBy(visibleItems, (item) => item.type === "wedding_moment")],
    ["Actions Cerise", countBy(visibleItems, (item) => item.source === "cerise")],
    ["RSVP", countBy(visibleItems, (item) => ["rsvp_signal", "guest_reminder"].includes(item.type))],
    ["Messages", countBy(visibleItems, (item) => item.type === "message")],
    ["Documents", countBy(visibleItems, (item) => item.type === "document")],
    ["Photos / souvenirs", countBy(visibleItems, (item) => item.type === "photo_memory")],
    ["Prestataires", countBy(visibleItems, (item) => item.type === "provider_brief" || item.related_provider_ids?.length)],
    ["Alertes", countBy(visibleItems, (item) => ["guest_reminder", "private_note"].includes(item.type) || ["Needs attention", "Urgent"].includes(item.priority))],
    ["Consignes", countBy(visibleItems, (item) => ["day_of_instruction", "instruction"].includes(item.type))],
    ["Éléments privés", countBy(visibleItems, (item) => ["private_couple", "admin", "internal"].includes(item.visibility))],
    ["Éléments publics", countBy(visibleItems, (item) => item.visibility === "public")],
    ["À confirmer", countBy(visibleItems, (item) => item.status === "to_confirm" || item.requires_validation)],
  ];

  return (
    <div className="mb-6 rounded-[2rem] border border-white/10 bg-background/70 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-primary">
            <SlidersHorizontal className="h-4 w-4" /> Contrôle interne — non visible pour les invités
          </p>
          <p className="mt-1 text-xs font-semibold text-muted-foreground">Ces vues simulent ce que chaque audience peut voir. Les données sensibles restent privées par défaut.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {hiddenCount > 0 && (
            <span className="inline-flex items-center gap-2 rounded-full bg-white/8 px-3 py-2 text-xs font-bold text-muted-foreground">
              <EyeOff className="h-3.5 w-3.5" /> {hiddenCount} masqué(s) pour cette audience
            </span>
          )}
          <button onClick={() => setIsOpen(!isOpen)} className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs font-black text-foreground hover:bg-white/10">
            {isOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            {isOpen ? "Masquer le contrôle" : "Afficher le contrôle"}
          </button>
        </div>
      </div>

      {!isOpen && null}
      {isOpen && (
        <>

      <div className="mb-4 mt-4 flex flex-wrap gap-2">
        {audiences.map((option) => (
          <button
            key={option.value}
            onClick={() => onAudienceChange(option.value)}
            className={`rounded-full border px-3 py-2 text-xs font-black transition ${audience === option.value ? "border-primary bg-primary text-primary-foreground" : "border-white/10 bg-white/5 text-muted-foreground hover:text-foreground"}`}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className="mb-3 grid gap-2 sm:grid-cols-5">
        <div className="rounded-2xl border border-primary/20 bg-primary/10 px-3 py-2"><p className="text-lg font-black text-foreground">{visibleItems.length}</p><p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">visibles pour cette audience</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2"><p className="text-lg font-black text-foreground">{hiddenCount}</p><p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">masqués pour cette audience</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2"><p className="text-lg font-black text-foreground">{sensitiveHiddenCount}</p><p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">masqués car sensibles</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2"><p className="text-lg font-black text-foreground">{privateAdminCount}</p><p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">privés / admin au total</p></div>
        <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2"><p className="text-lg font-black text-foreground">{publicCount}</p><p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">publics au total</p></div>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
        {counters.map(([label, value]) => (
          <div key={label} className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2">
            <p className="text-lg font-black text-foreground">{value}</p>
            <p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">{label} visibles</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-[1.5rem] border border-white/8 bg-white/5 p-3">
        <p className="mb-2 flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-primary"><Sparkles className="h-3.5 w-3.5" /> Actions Cerise</p>
        <div className="grid gap-2 text-xs font-semibold text-muted-foreground sm:grid-cols-3 lg:grid-cols-6">
          <span>Appliquées : <strong className="text-foreground">{appliedSuggestions}</strong></span>
          <span>Ignorées : <strong className="text-foreground">{ignoredSuggestions}</strong></span>
          <span>TimelineItem Cerise : <strong className="text-foreground">{ceriseTimelineItems}</strong></span>
          <span>À confirmer : <strong className="text-foreground">{countBy(ceriseItems, (item) => item.status === "to_confirm")}</strong></span>
          <span>Validées : <strong className="text-foreground">{countBy(ceriseItems, (item) => item.status === "done" || item.status === "confirmed")}</strong></span>
          <span>Doublons évités : <strong className="text-foreground">{duplicateAvoided}</strong></span>
        </div>
      </div>
      <div className="mt-3 text-xs font-semibold text-muted-foreground">À confirmer au total : <strong className="text-foreground">{toConfirmCount}</strong></div>
      <TimelineSoftSyncPanel audience={audience} />
        </>
      )}
    </div>
  );
}