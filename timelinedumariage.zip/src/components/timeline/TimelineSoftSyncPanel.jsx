import { useState } from "react";
import { RefreshCw, Search, ShieldCheck } from "lucide-react";
import { previewWeddingSoftSync, syncWeddingSoftLayer } from "@/lib/timelineSoftSync";
import TimelineRelationQualityPanel from "./TimelineRelationQualityPanel";

const Stat = ({ label, value }) => (
  <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-2">
    <p className="text-lg font-black text-foreground">{value ?? "—"}</p>
    <p className="text-[10px] font-bold uppercase tracking-[0.08em] text-muted-foreground">{label}</p>
  </div>
);

export default function TimelineSoftSyncPanel({ audience }) {
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  if (audience !== "couple_admin") return null;

  const handlePreview = async () => {
    setLoading(true);
    setResult(null);
    const data = await previewWeddingSoftSync();
    setPreview(data);
    setLoading(false);
  };

  const handleSync = async () => {
    setLoading(true);
    const data = await syncWeddingSoftLayer();
    setResult(data);
    const refreshed = await previewWeddingSoftSync();
    setPreview(refreshed);
    setLoading(false);
  };

  const people = result?.people || preview?.people;
  const relations = result?.relations || preview?.relations;

  return (
    <div className="mt-4 rounded-[1.5rem] border border-primary/20 bg-primary/10 p-3">
      <div className="mb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-primary">
            <ShieldCheck className="h-3.5 w-3.5" /> Synchronisation douce
          </p>
          <p className="mt-1 text-xs font-semibold text-muted-foreground">Additive, réversible, sans publication : Cerise propose, les humains valident.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={handlePreview} disabled={loading} className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/8 px-3 py-2 text-xs font-black text-foreground disabled:opacity-50">
            <Search className="h-3.5 w-3.5" /> Prévisualiser
          </button>
          <button onClick={handleSync} disabled={loading || !preview} className="inline-flex items-center gap-2 rounded-full bg-primary px-3 py-2 text-xs font-black text-primary-foreground disabled:opacity-50">
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Synchroniser maintenant
          </button>
        </div>
      </div>

      {!preview && !result && (
        <p className="text-sm font-semibold text-muted-foreground">Cliquez sur “Prévisualiser” avant toute synchronisation. Rien ne se lance automatiquement.</p>
      )}

      {(people || relations) && (
        <div className="grid gap-3 lg:grid-cols-2">
          <div>
            <p className="mb-2 text-[11px] font-black uppercase tracking-widest text-foreground">Personnes</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              <Stat label="détectées" value={people?.detected} />
              <Stat label="existantes" value={people?.existing} />
              <Stat label="à créer" value={people?.toCreate} />
              <Stat label="créées" value={people?.created} />
              <Stat label="à vérifier" value={people?.toVerify} />
              <Stat label="doublons évités" value={people?.duplicatesAvoided} />
            </div>
          </div>

          <div>
            <p className="mb-2 text-[11px] font-black uppercase tracking-widest text-foreground">Relations</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              <Stat label="détectées" value={relations?.detected} />
              <Stat label="existantes" value={relations?.existing} />
              <Stat label="à créer" value={relations?.toCreate} />
              <Stat label="créées" value={relations?.created} />
              <Stat label="à vérifier" value={relations?.toVerify} />
              <Stat label="doublons évités" value={relations?.duplicatesAvoided} />
            </div>
          </div>
        </div>
      )}

      {result && (
        <p className="mt-3 text-xs font-bold text-foreground">Synchronisation terminée : aucune publication, aucun message, aucune suppression.</p>
      )}

      <TimelineRelationQualityPanel />
    </div>
  );
}