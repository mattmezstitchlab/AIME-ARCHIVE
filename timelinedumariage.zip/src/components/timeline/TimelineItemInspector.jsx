import { X } from "lucide-react";
import TimelineVisibilityBadge from "./TimelineVisibilityBadge";
import { canViewTimelineItem, isSensitiveTimelineItem } from "@/lib/timelineVisibility";

const Detail = ({ label, value }) => (
  <div className="rounded-2xl border border-white/8 bg-white/5 p-3">
    <p className="text-[10px] font-black uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
    <p className="mt-1 break-words text-sm font-bold text-foreground">{value || "—"}</p>
  </div>
);

export default function TimelineItemInspector({ item, people, audience, onClose }) {
  if (!item) return null;

  const visibleForAudience = canViewTimelineItem(item, audience);
  const sensitive = isSensitiveTimelineItem(item);
  const linkedPeople = [...(item.related_person_ids || []), ...(item.related_provider_ids || [])]
    .map((id) => people.find((person) => person.id === id))
    .filter(Boolean);
  const relationSource = item.registered_relations?.length ? "relation enregistrée" : "relation déduite";
  const allRelations = item.all_registered_relations || item.registered_relations || [];
  const validatedRelations = allRelations.filter((relation) => relation.relation_status === "validated");
  const toVerifyRelations = allRelations.filter((relation) => relation.relation_status === "to_verify");
  const inactiveRelations = allRelations.filter((relation) => ["ignored", "archived"].includes(relation.relation_status));
  const ceriseReadableRelations = validatedRelations.filter((relation) => relation.related_person);
  const shouldMaskDetails = !visibleForAudience || (audience === "public" && sensitive);

  return (
    <div className="fixed inset-0 z-[60] flex items-end bg-background/70 p-4 backdrop-blur-sm sm:items-center sm:justify-center">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-[2rem] border border-white/12 bg-background p-5 shadow-[0_30px_120px_rgba(0,0,0,0.55)]">
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-primary">Inspecteur interne</p>
            <h3 className="mt-1 text-2xl font-black text-foreground">{item.title}</h3>
          </div>
          <button onClick={onClose} className="rounded-full bg-white/8 p-2 text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>

        {shouldMaskDetails && (
          <div className="mb-4 rounded-2xl border border-primary/20 bg-primary/10 p-3 text-sm font-bold text-foreground">
            Données privées masquées pour l’audience sélectionnée. L’élément reste visible ici uniquement car vous êtes dans le panneau interne.
          </div>
        )}

        <div className="mb-4 flex flex-wrap gap-2">
          <TimelineVisibilityBadge visibility={item.visibility} />
          <span className="rounded-full bg-white/8 px-3 py-1 text-xs font-black uppercase text-foreground">{item.type}</span>
          <span className="rounded-full bg-white/8 px-3 py-1 text-xs font-black uppercase text-foreground">{item.source}</span>
          {item.requires_validation && <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-black uppercase text-primary">validation humaine</span>}
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <Detail label="Status" value={item.status} />
          <Detail label="Date" value={item.date || item.created_date?.slice(0, 10)} />
          <Detail label="Heure" value={item.time} />
          <Detail label="Lieu" value={item.location} />
          <Detail label="Documents liés" value={(item.related_document_ids || []).join(", ")} />
          <Detail label="Messages liés" value={(item.related_message_ids || []).join(", ")} />
          <Detail label="Action Cerise liée" value={item.cerise_suggestion_id || item.cerise_action_log_id} />
          <Detail label="Relation" value={relationSource} />
        </div>

        <div className="mt-4 rounded-2xl border border-white/8 bg-white/5 p-3">
          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-muted-foreground">Description / notes</p>
          <p className="mt-2 text-sm font-semibold leading-relaxed text-foreground">
            {shouldMaskDetails ? "Contenu masqué pour cette audience." : item.description || item.notes || "—"}
          </p>
        </div>

        <div className="mt-4 rounded-2xl border border-white/8 bg-white/5 p-3">
          <p className="mb-3 text-[10px] font-black uppercase tracking-[0.14em] text-muted-foreground">Personnes liées</p>
          {linkedPeople.length ? (
            <div className="flex flex-wrap gap-2">
              {linkedPeople.map((person) => (
                <div key={person.id} className="flex items-center gap-2 rounded-full bg-background/80 py-1 pl-1 pr-3 text-xs font-bold text-foreground">
                  <img src={person.photo_url} alt={person.full_name} className="h-8 w-8 rounded-full object-cover" />
                  <span>{person.full_name}</span>
                  <span className="text-muted-foreground">· {person.display_role || person.role}</span>
                  <span className="text-muted-foreground">· {person.group || person.side}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm font-semibold text-muted-foreground">Aucune personne liée pour l’instant.</p>
          )}
        </div>

        <div className="mt-4 rounded-2xl border border-white/8 bg-white/5 p-3">
          <p className="mb-3 text-[10px] font-black uppercase tracking-[0.14em] text-muted-foreground">Contrôle relationnel Cerise</p>
          <div className="grid gap-2 sm:grid-cols-3">
            <Detail label="Validées" value={validatedRelations.length} />
            <Detail label="À vérifier" value={toVerifyRelations.length} />
            <Detail label="Ignorées / archivées" value={inactiveRelations.length} />
          </div>
          <div className="mt-3 space-y-2">
            {validatedRelations.map((relation) => (
              <p key={relation.id} className="rounded-xl bg-primary/10 px-3 py-2 text-xs font-bold text-foreground">
                Validée : {relation.related_person?.full_name || relation.related_id} · {relation.relation_role} · {relation.visibility}
              </p>
            ))}
            {toVerifyRelations.map((relation) => (
              <p key={relation.id} className="rounded-xl bg-white/8 px-3 py-2 text-xs font-bold text-muted-foreground">
                À vérifier : {relation.related_person?.full_name || relation.related_id} · {relation.relation_role} · {relation.visibility}
              </p>
            ))}
            {inactiveRelations.length > 0 && (
              <p className="rounded-xl bg-background/80 px-3 py-2 text-xs font-bold text-muted-foreground">
                {inactiveRelations.length} relation(s) ignorée(s) ou archivée(s), conservée(s) sans suppression.
              </p>
            )}
          </div>
          <p className="mt-3 text-xs font-bold text-primary">
            Cerise peut considérer {ceriseReadableRelations.length} relation(s) comme fiables et signaler {toVerifyRelations.length} relation(s) à vérifier, sans reproposer les relations déjà validées.
          </p>
        </div>
      </div>
    </div>
  );
}