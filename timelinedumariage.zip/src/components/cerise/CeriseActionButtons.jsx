import { Button } from "@/components/ui/button";

export default function CeriseActionButtons({ insight, status, processing, onApply, onIgnore, onAsk }) {
  const isApplied = status === "applied";
  const isIgnored = status === "ignored";
  const disabled = processing || isApplied || isIgnored;

  return (
    <div className="mt-4 flex flex-wrap gap-2">
      <Button size="sm" className="rounded-full bg-accent text-accent-foreground hover:bg-accent/90" disabled={disabled} onClick={() => onApply(insight)}>
        {processing ? "Application…" : isApplied ? "Suggestion appliquée" : isIgnored ? "Suggestion ignorée" : "Appliquer la suggestion"}
      </Button>
      <Button size="sm" variant="outline" className="rounded-full" disabled={disabled} onClick={() => onIgnore(insight)}>
        Ignorer
      </Button>
      <Button size="sm" variant="ghost" className="rounded-full" onClick={() => onAsk(insight)}>
        Demander à Cerise
      </Button>
    </div>
  );
}