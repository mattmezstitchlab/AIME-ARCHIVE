import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, CircleDashed, ListChecks, ShieldCheck } from "lucide-react";
import { getCeriseMemory } from "@/lib/ceriseMemory";

const statusLabels = {
  applied: "Appliquée",
  ignored: "Ignorée",
  generated: "Générée",
  completed: "Terminée",
  pending: "À valider",
  failed: "À vérifier",
};

export default function CeriseRecap() {
  const [memory, setMemory] = useState({ logs: [], suggestions: [] });

  useEffect(() => {
    getCeriseMemory().then(setMemory);
  }, []);

  const stats = useMemo(() => {
    const applied = memory.logs.filter((log) => log.status === "applied" || log.status === "completed").length;
    const ignored = memory.logs.filter((log) => log.status === "ignored").length;
    const pending = memory.suggestions.filter((suggestion) => suggestion.status === "pending").length;
    return { applied, ignored, pending };
  }, [memory]);

  const latestItems = [...memory.suggestions, ...memory.logs]
    .sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0))
    .slice(0, 5);

  return (
    <section className="mb-10 rounded-[2.5rem] border border-white/12 bg-white/7 p-5 text-foreground backdrop-blur-2xl sm:p-6">
      <div className="mb-5 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.22em] text-primary">Récap Cerise</p>
          <h2 className="mt-2 text-2xl font-black text-foreground">Ce que Cerise garde en mémoire</h2>
          <p className="mt-2 text-sm font-semibold text-muted-foreground">
            Cerise sait ce qui a déjà été fait et ce qu’il reste à clarifier.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-2xl bg-background/70 px-3 py-2">
            <CheckCircle2 className="mx-auto mb-1 h-4 w-4 text-primary" />
            <p className="text-lg font-black">{stats.applied}</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">fait</p>
          </div>
          <div className="rounded-2xl bg-background/70 px-3 py-2">
            <CircleDashed className="mx-auto mb-1 h-4 w-4 text-primary" />
            <p className="text-lg font-black">{stats.pending}</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">à valider</p>
          </div>
          <div className="rounded-2xl bg-background/70 px-3 py-2">
            <ShieldCheck className="mx-auto mb-1 h-4 w-4 text-primary" />
            <p className="text-lg font-black">{stats.ignored}</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">ignoré</p>
          </div>
        </div>
      </div>

      {latestItems.length ? (
        <div className="grid gap-2">
          {latestItems.map((item) => (
            <article key={`${item.id}-${item.created_date}`} className="rounded-2xl border border-white/10 bg-background/60 p-3">
              <div className="flex items-start gap-3">
                <ListChecks className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div>
                  <p className="text-sm font-black text-foreground">{item.title || item.action_label}</p>
                  <p className="mt-1 text-xs font-semibold text-muted-foreground">
                    {statusLabels[item.status] || item.status || "Suivi"} · {item.source_page || "AIME"}
                  </p>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-white/10 bg-background/60 p-4 text-sm font-semibold text-muted-foreground">
          Aucune action enregistrée pour le moment. Les prochaines suggestions validées ou ignorées apparaîtront ici.
        </div>
      )}
    </section>
  );
}