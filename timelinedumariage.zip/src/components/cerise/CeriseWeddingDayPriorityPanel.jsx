import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, CalendarClock, PhoneCall, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { getCeriseMemory } from "@/lib/ceriseMemory";
import { initialWeddingMoments, weddingPeople } from "@/components/wedding/weddingData";

const providerRoles = ["DJ", "Photographe", "Traiteur", "Wedding planner", "Fleuriste", "Officiant"];
const urgentPriorities = ["Urgent", "Needs attention", "To confirm"];

export default function CeriseWeddingDayPriorityPanel() {
  const [memory, setMemory] = useState({ logs: [], suggestions: [] });

  useEffect(() => {
    getCeriseMemory().then(setMemory);
  }, []);

  const urgentSuggestions = useMemo(
    () =>
      memory.suggestions
        .filter((suggestion) => suggestion.status === "pending" && urgentPriorities.includes(suggestion.priority))
        .slice(0, 4),
    [memory.suggestions]
  );

  const providersToContact = useMemo(() => {
    const providers = weddingPeople.filter((person) => providerRoles.includes(person.role));
    return providers
      .map((provider) => {
        const nextMoment = initialWeddingMoments.find((moment) => moment.people.some((person) => person.id === provider.id));
        return { provider, nextMoment };
      })
      .filter((item) => item.nextMoment)
      .slice(0, 4);
  }, []);

  const dayPlanning = useMemo(() => initialWeddingMoments.slice(0, 8), []);

  return (
    <section className="mb-10 grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
      <div className="rounded-[2.5rem] border border-white/12 bg-white/7 p-5 backdrop-blur-2xl sm:p-6">
        <div className="mb-5 flex items-start gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-primary">Priorités Cerise</p>
            <h2 className="mt-1 text-2xl font-black text-foreground">Urgences et validations du Jour J</h2>
          </div>
        </div>

        <div className="grid gap-3">
          {urgentSuggestions.length ? (
            urgentSuggestions.map((suggestion) => (
              <article key={suggestion.id} className="rounded-2xl border border-primary/20 bg-background/70 p-4">
                <Badge className="mb-3 rounded-full bg-primary text-primary-foreground">{suggestion.priority}</Badge>
                <p className="text-sm font-black text-foreground">{suggestion.title}</p>
                <p className="mt-2 text-xs font-semibold text-muted-foreground">{suggestion.suggested_action}</p>
              </article>
            ))
          ) : (
            <article className="rounded-2xl border border-white/10 bg-background/70 p-4">
              <div className="flex gap-3">
                <AlertTriangle className="mt-0.5 h-4 w-4 text-primary" />
                <div>
                  <p className="text-sm font-black text-foreground">Aucune urgence enregistrée</p>
                  <p className="mt-1 text-xs font-semibold text-muted-foreground">Cerise affichera ici les suggestions prioritaires à valider.</p>
                </div>
              </div>
            </article>
          )}
        </div>
      </div>

      <div className="rounded-[2.5rem] border border-white/12 bg-white/7 p-5 backdrop-blur-2xl sm:p-6">
        <div className="mb-5 flex items-center gap-3">
          <PhoneCall className="h-5 w-5 text-primary" />
          <h3 className="text-xl font-black text-foreground">Prestataires à contacter</h3>
        </div>
        <div className="space-y-3">
          {providersToContact.map(({ provider, nextMoment }) => (
            <article key={provider.id} className="rounded-2xl bg-background/70 p-4">
              <p className="text-sm font-black text-foreground">{provider.name} — {provider.role}</p>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">
                Prochain point : {nextMoment.time} · {nextMoment.title}
              </p>
            </article>
          ))}
        </div>
      </div>

      <div className="rounded-[2.5rem] border border-white/12 bg-white/7 p-5 backdrop-blur-2xl sm:p-6 lg:col-span-2">
        <div className="mb-5 flex items-center gap-3">
          <CalendarClock className="h-5 w-5 text-primary" />
          <h3 className="text-xl font-black text-foreground">Planning de la journée</h3>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {dayPlanning.map((moment) => (
            <article key={moment.id} className="rounded-2xl border border-white/10 bg-background/70 p-4">
              <p className="text-xs font-black text-primary">{moment.time}</p>
              <p className="mt-1 text-sm font-black text-foreground">{moment.title}</p>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">{moment.location}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}