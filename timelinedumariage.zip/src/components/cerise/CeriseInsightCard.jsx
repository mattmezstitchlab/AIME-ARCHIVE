import { useEffect, useState } from "react";
import { AlertTriangle, CheckCircle2, CircleDot, HeartHandshake } from "lucide-react";
import CeriseActionButtons from "./CeriseActionButtons";
import { createCeriseActionLog, createCeriseSuggestion, getCeriseMemory } from "@/lib/ceriseMemory";
import { createTimelineItemFromCeriseSuggestion } from "@/lib/timelineCeriseBridge";
import { createHumanValidationLog } from "@/lib/humanValidationLog";

const priorityStyles = {
  Calm: "bg-muted text-foreground border-border",
  "To confirm": "bg-card text-card-foreground border-border",
  "Needs attention": "bg-red-50 text-red-900 border-red-200",
  Urgent: "bg-destructive text-destructive-foreground border-destructive",
  Done: "bg-foreground text-background border-foreground",
};

const priorityIcons = {
  Calm: CircleDot,
  "To confirm": CircleDot,
  "Needs attention": AlertTriangle,
  Urgent: AlertTriangle,
  Done: CheckCircle2,
};

export default function CeriseInsightCard({ title = "CERISE observe", context, insights = [] }) {
  const [handled, setHandled] = useState({});
  const [processingId, setProcessingId] = useState(null);
  const visibleInsights = insights.slice(0, 3);

  useEffect(() => {
    getCeriseMemory().then(({ suggestions }) => {
      setHandled(Object.fromEntries(
        suggestions
          .filter((suggestion) => ["applied", "ignored"].includes(suggestion.status))
          .map((suggestion) => [suggestion.target_id, suggestion.status])
      ));
    });
  }, []);

  if (!visibleInsights.length) return null;

  const askCerise = (insight) => {
    window.dispatchEvent(new CustomEvent("openCerise", { detail: insight }));
  };

  const applyInsight = async (insight) => {
    if (handled[insight.id] === "applied" || processingId) return;
    setProcessingId(insight.id);
    await createCeriseSuggestion(insight, "applied");
    const { timelineItem } = await createTimelineItemFromCeriseSuggestion(insight);
    await createCeriseActionLog({
      target_type: "timeline",
      target_id: timelineItem.id,
      action_type: "suggestion_applied",
      action_label: insight.action,
      result: `Suggestion validée humainement et TimelineItem créé : ${timelineItem.title}`,
      status: "applied",
      visibility: "internal",
    });
    await createHumanValidationLog({
      action_type: "cerise_suggestion_applied",
      source: "cerise",
      target_type: "suggestion",
      target_id: insight.id,
      target_label: insight.title || insight.diagnosis,
      status_before: "pending",
      status_after: "applied",
      person_or_audience: insight.target_type || "timeline",
      visibility: "internal",
      author_type: "human",
      notes: "Suggestion Cerise appliquée après validation humaine.",
    });
    askCerise(insight);
    setHandled((current) => ({ ...current, [insight.id]: "applied" }));
    setProcessingId(null);
  };

  const ignoreInsight = async (insight) => {
    if (handled[insight.id] || processingId) return;
    setProcessingId(insight.id);
    await createCeriseSuggestion(insight, "ignored");
    await createCeriseActionLog({
      target_type: "suggestion",
      target_id: insight.id,
      action_type: "suggestion_ignored",
      action_label: insight.action,
      result: "Suggestion ignorée par l’utilisateur.",
      status: "ignored",
    });
    await createHumanValidationLog({
      action_type: "cerise_suggestion_ignored",
      source: "cerise",
      target_type: "suggestion",
      target_id: insight.id,
      target_label: insight.title || insight.diagnosis,
      status_before: "pending",
      status_after: "ignored",
      person_or_audience: insight.target_type || "timeline",
      visibility: "internal",
      author_type: "human",
      notes: "Suggestion Cerise ignorée par décision humaine.",
    });
    setHandled((current) => ({ ...current, [insight.id]: "ignored" }));
    setProcessingId(null);
  };

  return (
    <section className="rounded-[2rem] border border-border bg-white/88 p-4 text-foreground shadow-[0_18px_54px_rgba(23,21,17,0.06)] backdrop-blur-2xl sm:p-5">
      <div className="mb-3 inline-flex rounded-full bg-muted px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-foreground/75">
        Contrôle interne — non visible par les invités
      </div>
      <div className="mb-4 flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-accent text-accent-foreground">
          <HeartHandshake className="h-5 w-5" />
        </div>
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-accent">{title}</p>
          {context && <p className="mt-1 text-sm font-semibold text-foreground/72">{context}</p>}
        </div>
      </div>

      <div className="grid gap-3">
        {visibleInsights.map((insight) => {
          const PriorityIcon = priorityIcons[insight.priority] || CircleDot;
          return (
            <article key={insight.id} className="rounded-[1.5rem] border border-border bg-[#FBF7F0] p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-black ${priorityStyles[insight.priority] || priorityStyles.Calm}`}>
                  <PriorityIcon className="h-3.5 w-3.5" /> {insight.priority}
                </span>
                {insight.validation && <span className="text-[11px] font-bold uppercase tracking-widest text-foreground/75">Validation requise</span>}
              </div>

              <p className="text-sm font-black text-foreground">{insight.diagnosis}</p>
              {insight.clear && <p className="mt-2 text-xs font-semibold text-foreground/72">Clair : {insight.clear}</p>}
              {insight.missing && <p className="mt-1 text-xs font-semibold text-foreground/72">Manquant : {insight.missing}</p>}
              {insight.attention && <p className="mt-1 text-xs font-semibold text-foreground/72">Attention : {insight.attention}</p>}
              {insight.automation && <p className="mt-1 text-xs font-semibold text-foreground/72">Automation suggérée : {insight.automation}</p>}

              <p className="mt-3 text-sm font-bold text-foreground">Prochaine action : {insight.action}</p>

              <CeriseActionButtons insight={insight} status={handled[insight.id]} processing={processingId === insight.id} onApply={applyInsight} onIgnore={ignoreInsight} onAsk={askCerise} />
            </article>
          );
        })}
      </div>
    </section>
  );
}