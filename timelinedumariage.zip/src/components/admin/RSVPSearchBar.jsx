import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function RSVPSearchBar({ value, onChange }) {
  return (
    <div className="relative">
      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
      <Input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Rechercher par nom ou statut..."
        className="pl-11 h-12 rounded-2xl font-bold"
      />
    </div>
  );
}