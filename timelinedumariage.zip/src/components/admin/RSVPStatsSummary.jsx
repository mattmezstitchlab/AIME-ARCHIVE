import { CheckCircle2, HelpCircle, Utensils, XCircle } from "lucide-react";

const mealLabels = {
  standard: "Standard",
  vegetarian: "Végétarien",
  vegan: "Vegan",
  gluten_free: "Sans gluten",
  child: "Enfant",
  other: "Autre",
};

export default function RSVPStatsSummary({ rsvps }) {
  const total = rsvps.length;
  const attending = rsvps.filter((rsvp) => rsvp.attendance === "yes").length;
  const declined = rsvps.filter((rsvp) => rsvp.attendance === "no").length;
  const maybe = rsvps.filter((rsvp) => rsvp.attendance === "maybe").length;
  const progress = total ? Math.round((attending / total) * 100) : 0;

  const mealCounts = rsvps.reduce((counts, rsvp) => {
    const key = rsvp.meal_preference || "standard";
    counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {});

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-3 gap-4">
        <StatCard icon={CheckCircle2} label="Présents" value={attending} />
        <StatCard icon={HelpCircle} label="Peut-être" value={maybe} />
        <StatCard icon={XCircle} label="Absents" value={declined} />
      </div>

      <div className="bg-card border border-border rounded-[2rem] p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <p className="font-black">Progression de présence</p>
          <span className="font-black text-2xl">{progress}%</span>
        </div>
        <div className="h-4 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-foreground transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
        <p className="text-sm text-muted-foreground font-bold mt-3">{attending} présents confirmés sur {total} réponses.</p>
      </div>

      <div className="bg-card border border-border rounded-[2rem] p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Utensils className="w-5 h-5" />
          <h2 className="font-black text-xl" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>Préférences repas</h2>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          {Object.entries(mealLabels).map(([key, label]) => (
            <div key={key} className="flex items-center justify-between bg-muted rounded-2xl px-4 py-3">
              <span className="font-bold text-sm">{label}</span>
              <span className="font-black">{mealCounts[key] || 0}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }) {
  return (
    <div className="bg-card border border-border rounded-[2rem] p-5 shadow-sm">
      <Icon className="w-6 h-6 mb-4" />
      <p className="text-sm text-muted-foreground font-bold">{label}</p>
      <p className="text-4xl font-black">{value}</p>
    </div>
  );
}