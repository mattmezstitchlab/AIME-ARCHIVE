import { useMemo, useState } from "react";
import RSVPSearchBar from "./RSVPSearchBar";

const attendanceLabels = {
  yes: "Présent",
  no: "Absent",
  maybe: "Peut-être",
};

const mealLabels = {
  standard: "Standard",
  vegetarian: "Végétarien",
  vegan: "Vegan",
  gluten_free: "Sans gluten",
  child: "Enfant",
  other: "Autre",
};

export default function RSVPResponseTable({ rsvps }) {
  const [search, setSearch] = useState("");

  const filteredRsvps = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return rsvps;

    return rsvps.filter((rsvp) => {
      const guestName = (rsvp.guest_name || "").toLowerCase();
      const attendance = (attendanceLabels[rsvp.attendance] || rsvp.attendance || "").toLowerCase();
      return guestName.includes(query) || attendance.includes(query);
    });
  }, [rsvps, search]);

  return (
    <div className="bg-card border border-border rounded-[2rem] shadow-sm overflow-hidden">
      <div className="p-5 border-b border-border space-y-4">
        <h2 className="text-xl font-black" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>Réponses RSVP</h2>
        <RSVPSearchBar value={search} onChange={setSearch} />
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted text-left">
            <tr>
              <th className="p-4 font-black">Invité</th>
              <th className="p-4 font-black">Présence</th>
              <th className="p-4 font-black">Repas</th>
              <th className="p-4 font-black">Notes</th>
            </tr>
          </thead>
          <tbody>
            {filteredRsvps.map((rsvp) => (
              <tr key={rsvp.id} className="border-t border-border">
                <td className="p-4 font-bold">{rsvp.guest_name}</td>
                <td className="p-4">{attendanceLabels[rsvp.attendance] || rsvp.attendance}</td>
                <td className="p-4">{mealLabels[rsvp.meal_preference] || "Standard"}</td>
                <td className="p-4 text-muted-foreground">{rsvp.notes || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!filteredRsvps.length && (
          <p className="p-8 text-center text-muted-foreground font-bold">Aucune réponse RSVP trouvée.</p>
        )}
      </div>
    </div>
  );
}