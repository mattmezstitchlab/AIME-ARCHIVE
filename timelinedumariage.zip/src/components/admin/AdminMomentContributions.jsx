import { useMemo } from "react";
import { Bell, MessageSquare, Music, Utensils } from "lucide-react";
import { initialWeddingMoments } from "../wedding/weddingData";

export default function AdminMomentContributions({ contributions = [] }) {
  const momentTitles = useMemo(() => {
    return initialWeddingMoments.reduce((acc, moment) => {
      acc[moment.id] = moment.title;
      return acc;
    }, {});
  }, []);

  return (
    <div className="bg-card border border-border rounded-[2rem] shadow-sm overflow-hidden">
      <div className="p-5 border-b border-border">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-xl font-black" style={{ fontFamily: "'Gilroy Bold', system-ui, sans-serif" }}>Contributions reçues</h2>
          <span className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs font-black text-muted-foreground">
            <Bell className="h-3.5 w-3.5" /> {contributions.length}
          </span>
        </div>
        <p className="mt-1 text-sm font-semibold text-muted-foreground">Nouvelles idées, allergies et messages liés aux moments du mariage.</p>
      </div>

      <div className="max-h-[520px] overflow-y-auto p-4 space-y-3">
        {contributions.map((item) => (
          <article key={item.id} className="rounded-2xl bg-muted/70 p-4 text-sm">
            <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
              <p className="font-black text-foreground">{item.guest_name || "Invité"}</p>
              <p className="text-xs font-bold text-muted-foreground">{momentTitles[item.moment_id] || item.moment_id || "Moment non précisé"}</p>
            </div>
            {item.music_titles && <p className="mt-3 flex gap-2 font-semibold text-muted-foreground"><Music className="mt-0.5 h-4 w-4 shrink-0" /> {item.music_titles}</p>}
            {item.allergies && <p className="mt-2 flex gap-2 font-semibold text-muted-foreground"><Utensils className="mt-0.5 h-4 w-4 shrink-0" /> {item.allergies}</p>}
            {item.notes && <p className="mt-2 flex gap-2 font-semibold text-muted-foreground"><MessageSquare className="mt-0.5 h-4 w-4 shrink-0" /> {item.notes}</p>}
          </article>
        ))}

        {!contributions.length && (
          <p className="py-10 text-center text-sm font-bold text-muted-foreground">Aucune contribution reçue pour le moment.</p>
        )}
      </div>
    </div>
  );
}