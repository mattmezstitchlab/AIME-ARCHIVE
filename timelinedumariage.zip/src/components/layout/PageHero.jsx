export default function PageHero({ icon: Icon, badge, title, description, children }) {
  return (
    <div className="text-center mb-10 sm:mb-12">
      {Icon && (
        <div className="w-16 h-16 rounded-3xl bg-foreground text-background flex items-center justify-center mx-auto mb-5">
          <Icon className="w-8 h-8" />
        </div>
      )}

      {badge && (
        <div className="inline-flex items-center gap-2 bg-muted rounded-full px-4 py-2 text-sm font-black mb-5">
          {badge}
        </div>
      )}

      {children}

      <h1 className="text-4xl sm:text-7xl font-black tracking-tight break-words font-heading">
        {title}
      </h1>
      {description && (
        <p className="mx-auto mt-4 max-w-2xl break-words text-base font-semibold leading-relaxed text-foreground/72 sm:text-lg">
          {description}
        </p>
      )}
    </div>
  );
}