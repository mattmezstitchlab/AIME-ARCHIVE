import { HeartHandshake, MoreHorizontal } from "lucide-react";
import AimeWidgetModuleButton from "./AimeWidgetModuleButton";

export default function AimeWidgetRail({ brandLabel = "AIME", modules, activeKey, onActivate, onTogglePanel, className = "" }) {
  return (
    <aside className={`fixed left-4 top-4 z-50 hidden h-[calc(100vh-2rem)] w-[4.35rem] flex-col items-center rounded-[2rem] bg-[#171511] px-2.5 py-4 text-white shadow-[0_18px_48px_rgba(23,21,17,0.14)] ${className}`}>
      <button type="button" onClick={onTogglePanel} aria-label={`Widget ${brandLabel}`} className="mb-5 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#F7F1E8] text-[#171511] transition-colors duration-200 hover:bg-[#EFE4D2]">
        <HeartHandshake className="h-5 w-5" />
      </button>
      <nav className="flex flex-1 flex-col items-center gap-2.5" aria-label={`Widget ${brandLabel} vertical`}>
        {modules.map((item) => (
          <AimeWidgetModuleButton key={item.key} item={item} active={activeKey === item.key} compact onActivate={onActivate} />
        ))}
      </nav>
      <button type="button" onClick={onTogglePanel} aria-label="Ouvrir Plus AIME" className="mt-4 flex h-11 w-11 items-center justify-center rounded-2xl text-[#F7F1E8] transition-colors duration-200 hover:bg-[#F7F1E8] hover:text-[#171511]">
        <MoreHorizontal className="h-[18px] w-[18px]" strokeWidth={1.8} />
      </button>
    </aside>
  );
}