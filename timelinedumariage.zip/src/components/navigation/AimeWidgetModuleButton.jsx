import { Link } from "react-router-dom";

export default function AimeWidgetModuleButton({ item, active, compact = false, onActivate }) {
  const Icon = item.icon;
  const content = (
    <>
      <span className={`flex shrink-0 items-center justify-center rounded-2xl transition-colors duration-200 ${compact ? "h-10 w-10" : "h-11 w-11"} ${
        active ? "bg-[#171511] text-white" : "bg-[#F7F1E8] text-[#171511] group-hover:bg-[#EFE4D2] group-hover:text-[#171511]"
      }`}>
        <Icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
      </span>
      {!compact && (
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-black text-[#171511]">{item.label}</span>
          {item.description && <span className="block truncate text-xs font-semibold text-[#6B6257]">{item.description}</span>}
        </span>
      )}
      {item.notification && <span className="h-2 w-2 rounded-full bg-red-500" />}
      {item.validation && !compact && <span className="rounded-full border border-red-200 bg-red-50 px-2 py-1 text-[11px] font-black uppercase text-red-900">à valider</span>}
      {item.soon && !compact && <span className="rounded-full border border-border bg-muted px-2 py-1 text-[11px] font-black uppercase text-foreground/72">bientôt</span>}
    </>
  );

  const className = `${compact ? "group relative flex h-11 w-11 items-center justify-center rounded-2xl" : "group flex w-full items-center gap-3 rounded-[1.35rem] p-2.5 text-left"} transition-colors duration-200 ${
    active ? "bg-transparent" : "hover:bg-[#F7F1E8]/80"
  }`;

  if (item.action || item.preview || item.soon) {
    return (
      <button type="button" aria-label={item.label} title={item.label} aria-disabled={item.soon ? "true" : undefined} onClick={() => !item.soon && onActivate?.(item)} className={className}>
        {content}
        {compact && <span className="pointer-events-none absolute left-[3.35rem] z-50 whitespace-nowrap rounded-full bg-[#171511] px-2.5 py-1 text-[11px] font-bold text-white opacity-0 transition-opacity duration-150 group-hover:opacity-100">{item.label}</span>}
      </button>
    );
  }

  return (
    <Link to={item.to || "/"} aria-label={item.label} title={item.label} onClick={() => onActivate?.(item)} className={className}>
      {content}
      {compact && <span className="pointer-events-none absolute left-[3.35rem] z-50 whitespace-nowrap rounded-full bg-[#171511] px-2.5 py-1 text-[11px] font-bold text-white opacity-0 transition-opacity duration-150 group-hover:opacity-100">{item.label}</span>}
    </Link>
  );
}