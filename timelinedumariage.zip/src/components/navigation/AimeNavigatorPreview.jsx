import { Compass, ExternalLink, Search } from "lucide-react";

const resources = [
  "Timeline du projet",
  "Ressources invités",
  "Brief prestataires",
];

export default function AimeNavigatorPreview() {
  return (
    <div className="rounded-[1.6rem] border border-[#E8DED0] bg-white/86 p-4">
      <div className="mb-3 flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-[#171511] text-white">
          <Compass className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-black text-[#171511]">Navigateur AIME</p>
          <p className="text-xs font-semibold text-[#6B6257]">Preview visuelle — ressources internes uniquement.</p>
        </div>
      </div>
      <div className="mb-3 flex items-center gap-2 rounded-2xl border border-[#E8DED0] bg-[#FBF7F0] px-3 py-2 text-xs font-semibold text-[#6B6257]">
        <Search className="h-4 w-4" />
        Rechercher une ressource bientôt…
      </div>
      <div className="grid gap-2">
        {resources.map((resource) => (
          <div key={resource} className="flex items-center justify-between rounded-2xl bg-[#FBF7F0] px-3 py-2 text-xs font-bold text-[#171511]">
            {resource}
            <ExternalLink className="h-3.5 w-3.5 text-[#6B6257]" />
          </div>
        ))}
      </div>
    </div>
  );
}