import { Link, useLocation } from "react-router-dom";
import {
  CalendarDays,
  Camera,
  ClipboardList,
  HeartHandshake,
  Home,
  Info,
  Mail,
  Sparkles,
  Users,
  BriefcaseBusiness,
} from "lucide-react";

const desktopNavItems = [
  { label: "Vue", path: "/", icon: Home },
  { label: "Jour J", path: "/", icon: CalendarDays },
  { label: "Invités", path: "/Guests", icon: Users },
  { label: "Photos", path: "/WeddingPhotos", icon: Camera },
  { label: "Prestataires", path: "/Prestataires", icon: BriefcaseBusiness },
  { label: "RSVP", path: "/AdminRSVP", icon: ClipboardList },
  { label: "À propos", path: "/About", icon: Info },
  { label: "Contact", path: "/Contact", icon: Mail },
];

const mobileNavItems = [
  { label: "Vue", path: "/", icon: Home },
  { label: "Jour J", path: "/", icon: CalendarDays },
  { label: "Invités", path: "/Guests", icon: Users },
  { label: "Photos", path: "/WeddingPhotos", icon: Camera },
  { label: "Cerise", path: "/", icon: Sparkles, action: "cerise" },
];

export default function AimeSidebar() {
  const location = useLocation();
  const isActive = (path, index) => (path === "/" ? location.pathname === "/" && index === 0 : location.pathname === path);

  return (
    <>
      <aside className="fixed left-4 top-4 z-50 hidden h-[calc(100vh-2rem)] w-[4.25rem] flex-col items-center rounded-[2rem] bg-[#171511] px-2.5 py-4 text-white shadow-[0_24px_70px_rgba(23,21,17,0.18)] xl:flex">
        <Link to="/" aria-label="AIME accueil" className="mb-5 flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-[#171511]">
          <HeartHandshake className="h-5 w-5" />
        </Link>

        <nav className="flex flex-1 flex-col items-center gap-2" aria-label="Navigation principale">
          {desktopNavItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.path, index);
            return (
              <Link
                key={`${item.label}-${index}`}
                to={item.path}
                aria-label={item.label}
                title={item.label}
                className={`group relative flex h-11 w-11 items-center justify-center rounded-2xl transition-colors duration-200 ${
                  active ? "bg-[#F5E7CF] text-[#171511] shadow-[0_10px_24px_rgba(245,231,207,0.18)]" : "text-white/62 hover:bg-white/10 hover:text-white"
                }`}
              >
                <Icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
                <span className="pointer-events-none absolute left-[3.35rem] whitespace-nowrap rounded-full bg-[#171511] px-3 py-1.5 text-xs font-bold text-white opacity-0 shadow-lg transition-opacity duration-200 group-hover:opacity-100">
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>

        <div className="mt-4 flex flex-col gap-2">
          <button aria-label="Cerise" title="Cerise" className="flex h-11 w-11 items-center justify-center rounded-2xl text-white/58 transition-colors duration-200 hover:bg-white/10 hover:text-white">
            <Sparkles className="h-[18px] w-[18px]" strokeWidth={1.8} />
          </button>
        </div>
      </aside>

      <div className="fixed bottom-4 left-3 right-3 z-40 rounded-[1.6rem] border border-[#E8DED0] bg-white/94 p-1.5 shadow-[0_16px_48px_rgba(23,21,17,0.12)] backdrop-blur-xl xl:hidden md:left-6 md:right-6">
        <nav className="grid grid-cols-5 gap-1" aria-label="Navigation mobile">
          {mobileNavItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.path, index);
            return (
              <Link
                key={item.label}
                to={item.path}
                aria-label={item.label}
                onClick={(event) => {
                  if (item.action === "cerise") {
                    event.preventDefault();
                    window.dispatchEvent(new CustomEvent("openCerise", { detail: { action: "Ouvre Cerise comme copilote discret." } }));
                  }
                }}
                className={`flex min-h-[3.35rem] flex-col items-center justify-center rounded-[1.2rem] text-[11px] font-black transition-colors duration-200 ${
                  active && item.action !== "cerise" ? "bg-[#171511] text-white" : "text-[#5F574D] hover:bg-[#F7F1E8]"
                }`}
              >
                <Icon className="mb-1 h-[18px] w-[18px]" strokeWidth={1.8} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </>
  );
}