import {
  BookOpen,
  BriefcaseBusiness,
  CalendarDays,
  Camera,
  Compass,
  FileText,
  Home,
  MessageSquare,
  MoreHorizontal,
  Sparkles,
  Users,
  Zap,
} from "lucide-react";

export const aimeWidgetConfigs = {
  wedding: {
    universe: "wedding",
    brandLabel: "AIME",
    accentColor: "cerise",
    primaryModules: ["timeline", "day", "guests", "photos"],
    groups: [
      {
        title: "Cœur",
        items: [
          { key: "timeline", label: "Timeline", shortLabel: "Vue", description: "Cœur vivant du mariage", icon: Home, to: "/", notification: true },
          { key: "day", label: "Jour J", shortLabel: "Jour J", description: "Mode opérationnel", icon: CalendarDays, to: "/#mode-jour-j", validation: true },
        ],
      },
      {
        title: "Organisation",
        items: [
          { key: "guests", label: "Invités", shortLabel: "Invités", description: "Personnes et cercles", icon: Users, to: "/Guests" },
          { key: "providers", label: "Prestataires", shortLabel: "Prest.", description: "Briefs et rôles", icon: BriefcaseBusiness, to: "/Prestataires" },
          { key: "photos", label: "Photos", shortLabel: "Photos", description: "Souvenirs partagés", icon: Camera, to: "/WeddingPhotos" },
        ],
      },
      {
        title: "Outils",
        items: [
          { key: "documents", label: "Documents", shortLabel: "Docs", description: "Espace préparé", icon: FileText, soon: true },
          { key: "messages", label: "Messages", shortLabel: "Msg", description: "Brouillons à valider", icon: MessageSquare, soon: true },
          { key: "registry", label: "Registre", shortLabel: "Registre", description: "Dossier mariage", icon: BookOpen, soon: true },
          { key: "navigator", label: "Navigateur", shortLabel: "Nav", description: "Ressources internes", icon: Compass, preview: true },
        ],
      },
      {
        title: "Intelligence",
        items: [
          { key: "cerise", label: "Cerise IA", shortLabel: "Cerise", description: "Copilote discret", icon: Sparkles, action: "cerise" },
          { key: "quick", label: "Actions rapides", shortLabel: "Actions", description: "Préparer sans envoyer", icon: Zap, soon: true },
        ],
      },
    ],
  },
  opus: {
    universe: "opus",
    brandLabel: "OPUS",
    accentColor: "blue",
    primaryModules: ["overview", "timeline", "missions", "documents"],
    groups: [],
  },
  generic: {
    universe: "generic",
    brandLabel: "AIME",
    accentColor: "cerise",
    primaryModules: ["timeline", "documents", "messages", "assistant"],
    groups: [],
  },
};

export const plusModule = { key: "more", label: "Plus", shortLabel: "Plus", icon: MoreHorizontal, action: "more" };

export const flattenWidgetModules = (groups = []) => groups.flatMap((group) => group.items);