import { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import AimeWidgetPanel from "./AimeWidgetPanel";
import AimeWidgetMoreSheet from "./AimeWidgetMoreSheet";
import AimeWidgetRail from "./AimeWidgetRail";
import AimeWidgetDock from "./AimeWidgetDock";
import { aimeWidgetConfigs, flattenWidgetModules, plusModule } from "./AimeWidgetConfig";

export default function AimeUniversalWidget({
  universe = "wedding",
  orientation = "auto",
  forceOrientation,
  activeModule,
  modules,
  brandLabel,
  mode = "compact",
  showNotifications = true,
  showValidationState = true,
}) {
  const config = aimeWidgetConfigs[universe] || aimeWidgetConfigs.wedding;
  const groups = modules || config.groups;
  const flatItems = useMemo(() => flattenWidgetModules(groups), [groups]);
  const [panelOpen, setPanelOpen] = useState(false);
  const [previewKey, setPreviewKey] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  const resolvedBrand = brandLabel || config.brandLabel || "AIME";
  const resolvedOrientation = forceOrientation || orientation;
  const isVerticalForced = resolvedOrientation === "vertical";
  const isHorizontalForced = resolvedOrientation === "horizontal";

  const routeActiveKey = useMemo(() => {
    const pathname = location.pathname;
    if (location.hash === "#mode-jour-j") return "day";
    if (pathname === "/Guests") return "guests";
    if (pathname === "/Prestataires") return "providers";
    if (pathname === "/WeddingPhotos") return "photos";
    if (pathname === "/AdminRSVP") return "registry";
    if (pathname === "/WeddingDay") return "day";
    if (pathname === "/") return "timeline";
    return null;
  }, [location.pathname]);

  const activeKey = activeModule || routeActiveKey;
  const primaryKeys = config.primaryModules || ["timeline", "day", "guests", "photos"];
  const primaryItems = primaryKeys.map((key) => flatItems.find((item) => item.key === key)).filter(Boolean);
  const dockItems = [...primaryItems.slice(0, 4), plusModule];
  const railItems = flatItems.filter((item) => ["timeline", "day", "guests", "providers", "photos", "documents", "messages", "cerise"].includes(item.key));
  const secondaryItems = flatItems.filter((item) => !primaryKeys.includes(item.key));

  const openCerise = () => {
    window.dispatchEvent(new CustomEvent("openCerise", { detail: { action: "Ouvre Cerise depuis le Widget AIME." } }));
  };

  const handleActivate = (item) => {
    if (item.soon) return;
    if (item.action === "more") {
      setPanelOpen((current) => !current);
      return;
    }
    if (item.action === "cerise") {
      openCerise();
      setPanelOpen(false);
      return;
    }
    if (item.preview) {
      setPreviewKey((current) => (current === item.key ? null : item.key));
      setPanelOpen(true);
      return;
    }
    if (item.to) {
      navigate(item.to);
      setPanelOpen(false);
    }
  };

  const verticalClass = isVerticalForced ? "flex" : isHorizontalForced ? "hidden" : "lg:flex";
  const horizontalClass = isHorizontalForced ? "block" : isVerticalForced ? "hidden" : "lg:hidden";
  const panelClass = isVerticalForced ? "block" : isHorizontalForced ? "hidden" : "hidden lg:block";
  const sheetClass = isHorizontalForced ? "block" : isVerticalForced ? "hidden" : "lg:hidden";

  return (
    <>
      <AimeWidgetRail
        brandLabel={resolvedBrand}
        modules={railItems}
        activeKey={activeKey}
        onActivate={handleActivate}
        onTogglePanel={() => setPanelOpen((current) => !current)}
        className={verticalClass}
      />

      <div className={`fixed left-24 top-4 z-50 ${panelClass}`}>
        {panelOpen && (
          <AimeWidgetPanel
            groups={groups}
            activeKey={activeKey}
            previewKey={previewKey}
            onActivate={handleActivate}
            onClose={() => setPanelOpen(false)}
          />
        )}
      </div>

      <AimeWidgetDock items={dockItems} activeKey={activeKey} onActivate={handleActivate} className={horizontalClass} />

      <div className={sheetClass}>
        {panelOpen && (
          <AimeWidgetMoreSheet
            items={secondaryItems}
            activeKey={activeKey}
            previewKey={previewKey}
            onActivate={handleActivate}
            onClose={() => setPanelOpen(false)}
          />
        )}
      </div>
    </>
  );
}