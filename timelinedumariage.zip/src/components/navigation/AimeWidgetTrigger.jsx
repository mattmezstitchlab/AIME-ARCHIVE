import { HeartHandshake, Sparkles } from "lucide-react";

export default function AimeWidgetTrigger({ open, hasNotification, onClick }) {
  return (
    <button
      type="button"
      aria-label="Ouvrir le Widget Universel AIME"
      onClick={onClick}
      className={`group flex items-center gap-2 rounded-full border px-3 py-2.5 text-sm font-black shadow-[0_18px_54px_rgba(23,21,17,0.14)] backdrop-blur-xl transition-all duration-200 ${
        open ? "border-[#171511] bg-[#171511] text-white" : "border-[#E8DED0] bg-white/94 text-[#171511] hover:-translate-y-0.5"
      }`}
    >
      <span className={`relative flex h-9 w-9 items-center justify-center rounded-2xl ${open ? "bg-white text-[#171511]" : "bg-[#171511] text-white"}`}>
        <HeartHandshake className="h-4 w-4" />
        {hasNotification && <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-accent ring-2 ring-white" />}
      </span>
      <span className="hidden sm:block">AIME</span>
      <Sparkles className="h-4 w-4 opacity-70" />
    </button>
  );
}