export default function AimeWidgetDock({ items, activeKey, onActivate, className = "" }) {
  return (
    <div className={`fixed bottom-4 left-3 right-3 z-40 rounded-[1.75rem] bg-[#171511] p-2 text-white shadow-[0_18px_48px_rgba(23,21,17,0.14)] md:left-6 md:right-6 ${className}`}>
      <nav className="grid grid-cols-5 gap-1" aria-label="Widget AIME horizontal">
        {items.map((item) => {
          const Icon = item.icon;
          const active = activeKey === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onActivate(item)}
              className={`relative flex min-h-[3.45rem] flex-col items-center justify-center rounded-[1.25rem] text-[11px] font-black transition-colors duration-200 ${
                active ? "bg-white/10 text-white" : "text-[#F7F1E8] hover:bg-white/10"
              }`}
            >
              <span className={`mb-1 flex h-9 w-9 items-center justify-center rounded-2xl transition-colors duration-200 ${
                active ? "bg-white text-[#171511]" : "bg-[#F7F1E8] text-[#171511]"
              }`}>
                <Icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
              </span>
              {item.shortLabel || item.label}
              {item.validation && <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-accent" />}
            </button>
          );
        })}
      </nav>
    </div>
  );
}