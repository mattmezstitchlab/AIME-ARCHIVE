import WeddingPlannerAgent from "../wedding/WeddingPlannerAgent";

export default function AimeCerisePanel() {
  return <WeddingPlannerAgent launcherVisible={false} />;
}