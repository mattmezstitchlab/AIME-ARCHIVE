import AimeWidgetModuleButton from "./AimeWidgetModuleButton";

export default function AimeWidgetMobileBar({ items, activeKey, onActivate }) {
  return (
    <div className="fixed bottom-4 left-3 right-3 z-40 rounded-[1.75rem] border border-[#E8DED0] bg-white/94 p-1.5 shadow-[0_16px_48px_rgba(23,21,17,0.12)] backdrop-blur-xl md:left-6 md:right-6 xl:hidden">
      <nav className="grid grid-cols-5 gap-1" aria-label="Widget AIME mobile">
        {items.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => onActivate(item)}
            className={`flex min-h-[3.45rem] flex-col items-center justify-center rounded-[1.25rem] text-[11px] font-black transition-colors duration-200 ${
              activeKey === item.key ? "bg-[#171511] text-white" : "text-[#5F574D] hover:bg-[#F7F1E8]"
            }`}
          >
            <item.icon className="mb-1 h-[18px] w-[18px]" strokeWidth={1.8} />
            {item.label}
          </button>
        ))}
      </nav>
    </div>
  );
}