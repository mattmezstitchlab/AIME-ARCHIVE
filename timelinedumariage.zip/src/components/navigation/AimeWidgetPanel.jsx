import { X } from "lucide-react";
import AimeWidgetModuleButton from "./AimeWidgetModuleButton";
import AimeNavigatorPreview from "./AimeNavigatorPreview";

export default function AimeWidgetPanel({ groups, activeKey, previewKey, onActivate, onClose }) {
  return (
    <div className="w-[min(26rem,calc(100vw-2rem))] overflow-hidden rounded-[2rem] border border-[#E8DED0] bg-[#FBF7F0]/96 text-[#171511] shadow-[0_28px_90px_rgba(23,21,17,0.18)] backdrop-blur-2xl">
      <div className="flex items-start justify-between border-b border-[#E8DED0] p-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.22em] text-red-900">Widget Universel AIME</p>
          <h2 className="mt-1 text-xl font-black tracking-tight">Orchestration centrale</h2>
          <p className="mt-1 text-xs font-semibold text-[#6B6257]">Cerise propose, l’humain valide.</p>
        </div>
        <button type="button" onClick={onClose} aria-label="Fermer" className="rounded-full p-2 text-[#6B6257] hover:bg-white hover:text-[#171511]">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="max-h-[min(38rem,calc(100vh-9rem))] space-y-4 overflow-y-auto p-4">
        {groups.map((group) => (
          <section key={group.title}>
            <p className="mb-2 text-[11px] font-black uppercase tracking-[0.18em] text-[#6B6257]">{group.title}</p>
            <div className="grid gap-1.5">
              {group.items.map((item) => (
                <AimeWidgetModuleButton key={item.key} item={item} active={activeKey === item.key} onActivate={onActivate} />
              ))}
            </div>
          </section>
        ))}
        {previewKey === "navigator" && <AimeNavigatorPreview />}
      </div>
    </div>
  );
}