import { X } from "lucide-react";
import AimeWidgetModuleButton from "./AimeWidgetModuleButton";
import AimeNavigatorPreview from "./AimeNavigatorPreview";

export default function AimeWidgetMoreSheet({ items, activeKey, previewKey, onActivate, onClose }) {
  return (
    <div className="fixed inset-x-3 bottom-24 z-50 rounded-[2rem] border border-[#E8DED0] bg-[#FBF7F0]/97 p-4 shadow-[0_24px_80px_rgba(23,21,17,0.18)] backdrop-blur-2xl md:inset-x-6 xl:hidden">
      <div className="mb-3 flex items-start justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-accent">Plus AIME</p>
          <p className="mt-1 text-sm font-semibold text-[#6B6257]">Outils autour de la Timeline.</p>
        </div>
        <button type="button" onClick={onClose} aria-label="Fermer" className="rounded-full p-2 text-[#6B6257] hover:bg-white hover:text-[#171511]">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="grid max-h-[55vh] gap-1.5 overflow-y-auto">
        {items.map((item) => (
          <AimeWidgetModuleButton key={item.key} item={item} active={activeKey === item.key} onActivate={onActivate} />
        ))}
        {previewKey === "navigator" && <AimeNavigatorPreview />}
      </div>
    </div>
  );
}