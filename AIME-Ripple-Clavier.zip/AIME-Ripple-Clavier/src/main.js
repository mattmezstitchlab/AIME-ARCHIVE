import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx' // Fichier qui contiendra tes composants Ripple
import './index.css' // Contient Tailwind + tokens.css

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)