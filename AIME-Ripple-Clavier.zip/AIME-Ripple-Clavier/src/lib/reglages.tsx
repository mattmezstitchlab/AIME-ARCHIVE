import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import type { ReactNode } from 'react'
import { PROFIL_DEFAUT, profil } from '@/data/roles'
import type { CarteId, Profil } from '@/data/types'

/**
 * Un clavier est un objet personnel : ses réglages restent sur l'appareil.
 * Rien ne part vers un serveur, jamais — c'est une propriété du produit,
 * pas une limite technique.
 */
export const CLE = 'aime.clavier.v2'

export interface Reglages {
  profil: string
  /** rôle d'ouverture — vide = le premier de la couche 1 */
  role: string
  theme: 'nuit' | 'jour'
  /** contraste, en facteur CSS */
  ctr: number
  /** zoom typographique, en % */
  fs: number
  /** interligne */
  lh: number
  anim: boolean
  souligne: boolean
  focus: boolean
  /** le dossier s'ouvre-t-il tout seul à chaque touche ? */
  panneau: boolean
  cartes: CarteId[]
}

export const DEFAUTS: Reglages = {
  profil: PROFIL_DEFAUT,
  role: '',
  theme: 'nuit',
  ctr: 1,
  fs: 100,
  lh: 1.55,
  anim: true,
  souligne: false,
  focus: false,
  panneau: true,
  cartes: ['infos', 'stats', 'graphe', 'pieces'],
}

export function lire(): Reglages {
  if (typeof window === 'undefined') return { ...DEFAUTS }
  let brut: Partial<Reglages> | null = null
  try {
    brut = JSON.parse(localStorage.getItem(CLE) || 'null')
  } catch {
    brut = null
  }
  const r = { ...DEFAUTS, ...(brut || {}) }
  if (!Array.isArray(r.cartes) || !r.cartes.length) r.cartes = [...DEFAUTS.cartes]
  r.profil = profil(r.profil).id
  r.theme = r.theme === 'jour' ? 'jour' : 'nuit'
  return r
}

function ecrire(r: Reglages) {
  try {
    localStorage.setItem(CLE, JSON.stringify(r))
  } catch {
    /* navigation privée : on continue sans mémoire */
  }
}

export function reduitLeMouvement(): boolean {
  return (
    typeof window !== 'undefined' &&
    !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  )
}

function appliquer(r: Reglages) {
  if (typeof document === 'undefined') return
  const html = document.documentElement
  html.dataset.theme = r.theme
  html.style.setProperty('--ctr', String(r.ctr))
  html.style.setProperty('--fs', r.fs + '%')
  html.style.setProperty('--lh', String(r.lh))
  const b = document.body
  if (!b) return
  b.classList.toggle('no-anim', !r.anim || reduitLeMouvement())
  b.classList.toggle('souligne', r.souligne)
  b.classList.toggle('focus-fort', r.focus)
}

interface Contexte {
  reglages: Reglages
  profilActif: Profil
  /** true une fois les réglages relus depuis l'appareil */
  pret: boolean
  regler: (patch: Partial<Reglages>) => void
  oublier: () => void
}

const Ctx = createContext<Contexte | null>(null)

export function FournisseurReglages({ children }: { children: ReactNode }) {
  const [reglages, setReglages] = useState<Reglages>(DEFAUTS)
  const [pret, setPret] = useState(false)

  useEffect(() => {
    const r = lire()
    setReglages(r)
    appliquer(r)
    setPret(true)
  }, [])

  const regler = useCallback((patch: Partial<Reglages>) => {
    setReglages((prev) => {
      const suivant = { ...prev, ...patch }
      ecrire(suivant)
      appliquer(suivant)
      return suivant
    })
  }, [])

  const oublier = useCallback(() => {
    try {
      localStorage.removeItem(CLE)
    } catch {
      /* rien à oublier */
    }
    setReglages({ ...DEFAUTS })
    appliquer(DEFAUTS)
  }, [])

  const valeur = useMemo<Contexte>(
    () => ({ reglages, profilActif: profil(reglages.profil), pret, regler, oublier }),
    [reglages, pret, regler, oublier],
  )

  return <Ctx.Provider value={valeur}>{children}</Ctx.Provider>
}

export function useReglages(): Contexte {
  const c = useContext(Ctx)
  if (!c) throw new Error('useReglages hors du fournisseur')
  return c
}

/**
 * Script inséré avant peinture : le thème et le zoom sont posés sur <html>
 * avant le premier rendu, pour qu'aucune page ne clignote au chargement.
 */
export const SCRIPT_SANS_CLIGNOTEMENT = `(function(){try{
var r=JSON.parse(localStorage.getItem('${CLE}')||'null')||{};
var h=document.documentElement;
h.dataset.theme=r.theme==='jour'?'jour':'nuit';
if(r.ctr)h.style.setProperty('--ctr',r.ctr);
if(r.fs)h.style.setProperty('--fs',r.fs+'%');
if(r.lh)h.style.setProperty('--lh',r.lh);
}catch(e){document.documentElement.dataset.theme='nuit'}})()`
