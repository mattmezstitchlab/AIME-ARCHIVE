import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { GESTES, R, SYSTEME, UNIVERSELLES } from '@/data/roles'
import type { Onde, Profil, Trace } from '@/data/types'
import {
  arcsDuGeste,
  dossierDuGeste,
  dossierDuRole,
  rolesDeLaCouche,
} from '@/lib/causal'
import type { DossierVivant } from '@/lib/causal'
import type { Reglages } from '@/lib/reglages'

const MAX_TRACES = 8

const heure = () =>
  new Date().toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })

function texteDuDossier(d: DossierVivant): string {
  const lignes = [
    `${d.who} · ${d.cle} — ${d.titre}`,
    d.sous,
    '',
    ...d.faits.map(([l, v]) => `• ${l} : ${v}`),
  ]
  if (d.arcs.length) {
    lignes.push('', 'Ondes :')
    for (const a of d.arcs)
      lignes.push(
        `→ ${R[a.r]?.nom ?? a.r}${a.lock ? ' (sous scellé)' : ''}${
          a.sous.length ? ` ↳ ${a.sous.map((s) => R[s.r ?? '']?.court ?? '—').join(', ')}` : ''
        }`,
      )
  }
  if (d.pieces?.length) {
    lignes.push('', 'Pièces :')
    for (const p of d.pieces) lignes.push(`— ${p.n} [${p.e}]${p.sous ? ` · ${p.sous}` : ''}`)
  }
  lignes.push('', 'AIME® · Ripple — mémoire causale')
  return lignes.join('\n')
}

async function auPressePapiers(texte: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(texte)
    return true
  } catch {
    return false
  }
}

export interface Moteur {
  roleActif: string
  couche: number
  dossier: DossierVivant | null
  traces: Trace[]
  compteurs: { ondes: number; masquees: number; actes: number }
  pareFeu: boolean
  repetition: boolean
  pouvoirs: boolean
  echos: Record<string, number>
  enfoncee: string | null
  rolesVisibles: string[]
  grapheOuvert: boolean
  setGrapheOuvert: (v: boolean) => void
  setRole: (id: string) => void
  setCouche: (i: number) => void
  tournerCouche: (d: number) => void
  presserLettre: (k: string, simu?: boolean) => void
  presserRole: (id: string) => void
  actionner: (fente: number) => void
  fermerDossier: () => void
  basculerPareFeu: () => void
  basculerRepetition: () => void
  basculerPouvoirs: () => void
  reinitialiser: () => void
  rejouer: () => void
  exporter: () => void
  lireDernier: () => void
}

export function useMoteur({
  profilActif,
  reglages,
  toast,
}: {
  profilActif: Profil
  reglages: Reglages
  toast: (t: string) => void
}): Moteur {
  const [couche, setCoucheBrut] = useState(0)
  const [roleActif, setRoleActif] = useState(
    () => rolesDeLaCouche(profilActif, 0)[0] ?? 'couple',
  )
  const [dossier, setDossier] = useState<DossierVivant | null>(null)
  const [traces, setTraces] = useState<Trace[]>([])
  const [compteurs, setCompteurs] = useState({ ondes: 0, masquees: 0, actes: 0 })
  const [pareFeu, setPareFeu] = useState(false)
  const [repetition, setRepetition] = useState(false)
  const [pouvoirs, setPouvoirs] = useState(false)
  const [echos, setEchos] = useState<Record<string, number>>({})
  const [enfoncee, setEnfoncee] = useState<string | null>(null)
  const [grapheOuvert, setGrapheOuvert] = useState(false)

  const idTrace = useRef(0)
  const minuteurs = useRef<Array<ReturnType<typeof setTimeout>>>([])

  useEffect(
    () => () => {
      minuteurs.current.forEach(clearTimeout)
    },
    [],
  )

  const differer = useCallback((fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms)
    minuteurs.current.push(t)
  }, [])

  const rolesVisibles = useMemo(() => {
    const l = rolesDeLaCouche(profilActif, couche)
    return profilActif.moteur ? [...l, SYSTEME.id] : l
  }, [profilActif, couche])

  /* le profil change : on repart sur un rôle qui existe vraiment */
  useEffect(() => {
    const premier =
      (reglages.role && rolesVisibles.includes(reglages.role) && reglages.role) ||
      rolesDeLaCouche(profilActif, couche)[0] ||
      SYSTEME.id
    setRoleActif((actuel) => (rolesVisibles.includes(actuel) ? actuel : premier))
    if (profilActif.feu !== 'ouvrable') setPareFeu(false)
  }, [profilActif, couche, rolesVisibles, reglages.role])

  const poser = useCallback((t: Omit<Trace, 'id' | 'horo'>) => {
    setTraces((prev) => [
      { ...t, id: ++idTrace.current, horo: heure() },
      ...prev,
    ].slice(0, MAX_TRACES))
  }, [])

  const faireEcho = useCallback(
    (ondes: Onde[]) => {
      ondes.forEach((o, i) => {
        if (!o.r) return
        differer(() => setEchos((e) => ({ ...e, [o.r!]: Date.now() })), 70 * i)
        differer(
          () =>
            setEchos((e) => {
              const { [o.r!]: _, ...reste } = e
              return reste
            }),
          70 * i + 700,
        )
      })
    },
    [differer],
  )

  const setRole = useCallback(
    (id: string) => {
      if (!R[id]) return
      setRoleActif(id)
      setDossier(null)
    },
    [],
  )

  const setCouche = useCallback(
    (i: number) => {
      const n = Math.max(0, Math.min(profilActif.couches.length - 1, i))
      setCoucheBrut(n)
      const premier = rolesDeLaCouche(profilActif, n)[0]
      if (premier) setRoleActif(premier)
      setDossier(null)
      toast(`Couche ${n + 1} — ${profilActif.couches[n]?.nom ?? ''}`)
    },
    [profilActif, toast],
  )

  const tournerCouche = useCallback(
    (d: number) => {
      if (profilActif.couches.length < 2) {
        toast(`Un seul jeu de touches sur le profil ${profilActif.nom}`)
        return
      }
      setCouche((couche + d + profilActif.couches.length) % profilActif.couches.length)
    },
    [couche, profilActif, setCouche, toast],
  )

  const basculerPareFeu = useCallback(() => {
    if (profilActif.feu !== 'ouvrable') {
      toast(
        `Pare-feu scellé sur le profil ${profilActif.nom} — ce qu’on vous prépare ne s’ouvre pas d’ici`,
      )
      return
    }
    setPareFeu((v) => {
      toast(
        v
          ? 'Pare-feu refermé — les surprises redeviennent invisibles'
          : 'Pare-feu ouvert — les ondes masquées se lisent, vue organisation',
      )
      return !v
    })
  }, [profilActif, toast])

  const basculerRepetition = useCallback(() => {
    setRepetition((v) => {
      toast(
        v
          ? 'Répétition levée — les gestes propagent à nouveau'
          : 'Répétition tenue — les gestes se calculent, rien ne se propage',
      )
      return !v
    })
  }, [toast])

  const basculerPouvoirs = useCallback(() => {
    setPouvoirs((v) => {
      toast(v ? 'Pouvoirs repliés' : 'Pouvoirs — chaque touche dit à quel rôle elle appartient')
      return !v
    })
  }, [toast])

  const reinitialiser = useCallback(() => {
    setTraces([])
    setCompteurs({ ondes: 0, masquees: 0, actes: 0 })
    setDossier(null)
    toast('Mémoire causale remise à plat')
  }, [toast])

  const exporter = useCallback(() => {
    if (!traces.length) {
      toast('Rien à exporter — la mémoire est vide')
      return
    }
    const lignes = [
      'AIME® · Ripple — mémoire causale',
      `profil : ${profilActif.nom}`,
      '',
      ...[...traces].reverse().flatMap((t) => [
        `${t.horo} · ${R[t.roleId]?.court ?? t.roleId} · ${t.touche} — ${t.titre}`,
        `   ${t.scn}`,
        ...t.ondes
          .filter((o) => o.r)
          .map(
            (o) =>
              `   → ${R[o.r!]?.court ?? o.r} : ${o.lock && !pareFeu ? 'onde masquée' : (o.lock && o.vrai) || o.t}`,
          ),
        '',
      ]),
    ]
    void auPressePapiers(lignes.join('\n')).then((ok) =>
      toast(ok ? 'Mémoire copiée — horodatée, lisible par un humain' : 'Copie refusée par le navigateur'),
    )
  }, [traces, profilActif, pareFeu, toast])

  const rejouer = useCallback(() => {
    if (!traces.length) {
      toast('Rien à rejouer — la mémoire est vide')
      return
    }
    const ordre = [...traces].reverse()
    toast(`Relecture de ${ordre.length} geste(s)`)
    ordre.forEach((t, i) => {
      differer(() => {
        setRoleActif(t.roleId)
        faireEcho(t.ondes)
      }, i * 620)
    })
  }, [traces, differer, faireEcho, toast])

  const lireDernier = useCallback(() => {
    const t = traces[0]
    const texte = t
      ? `${R[t.roleId]?.nom}. ${t.titre}. ${t.scn}. ${t.ondes
          .filter((o) => o.r)
          .map((o) => `${R[o.r!]?.nom} : ${o.lock && !pareFeu ? 'onde masquée' : o.t}`)
          .join('. ')}`
      : 'La mémoire causale est vide. Pressez une lettre pour créer la première onde.'
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      toast('Synthèse vocale indisponible sur ce navigateur')
      return
    }
    const s = window.speechSynthesis
    if (s.speaking) {
      s.cancel()
      toast('Lecture arrêtée')
      return
    }
    const u = new SpeechSynthesisUtterance(texte)
    u.lang = 'fr-FR'
    s.speak(u)
    toast('Lecture de la dernière onde')
  }, [traces, pareFeu, toast])

  const effet = useCallback(
    (quoi: string) => {
      if (quoi === 'graphe') setGrapheOuvert(true)
      else if (quoi === 'pare-feu') basculerPareFeu()
      else if (quoi === 'rejouer') rejouer()
      else if (quoi === 'exporter') exporter()
    },
    [basculerPareFeu, rejouer, exporter],
  )

  const universelle = useCallback(
    (k: string) => {
      const ro = R[roleActif]
      if (k === 'E') {
        poser({
          touche: 'touche E — Essentiel',
          roleId: ro.id,
          titre: 'L’essentiel',
          scn: ro.ess,
          ondes: [],
          genre: 'essentiel',
        })
        if (reglages.panneau) setDossier(dossierDuRole(ro))
      } else if (k === 'L') {
        lireDernier()
      } else if (k === 'T') {
        toast('Traduction — l’onde parle douze langues pour les invités venus de loin')
      } else if (k === 'A') {
        toast(`Aller à — l’espace ${ro.court} s’ouvre, le reste s’efface`)
      }
    },
    [roleActif, poser, reglages.panneau, lireDernier, toast],
  )

  const presserLettre = useCallback(
    (k: string, simuTouche = false) => {
      setEnfoncee(k)
      differer(() => setEnfoncee((e) => (e === k ? null : e)), 190)

      const g = GESTES[roleActif]?.[k]
      if (!g) {
        if (UNIVERSELLES[k]) universelle(k)
        else
          toast(
            `${k} — touche libre sur le clavier ${R[roleActif]?.court}. Rien ne se propage.`,
          )
        return
      }

      const simu = repetition || simuTouche
      const arcs = arcsDuGeste(g)
      const masquees = arcs.filter((a) => a.lock).length

      poser({
        touche: `touche ${k}`,
        roleId: roleActif,
        titre: g.label,
        scn: g.scn,
        ondes: g.ondes,
        simu,
        genre: 'geste',
      })

      if (!simu) {
        setCompteurs((c) => ({
          ...c,
          ondes: c.ondes + arcs.length,
          masquees: c.masquees + masquees,
        }))
        faireEcho(g.ondes)
      }

      if (g.effet) effet(g.effet)
      if (reglages.panneau) setDossier(dossierDuGeste(roleActif, k, g))
    },
    [roleActif, repetition, reglages.panneau, poser, faireEcho, effet, universelle, differer, toast],
  )

  const presserRole = useCallback(
    (id: string) => {
      setRole(id)
      const ro = R[id]
      if (ro) toast(`${ro.nom} — ${ro.ess}`)
    },
    [setRole, toast],
  )

  const actionner = useCallback(
    (fente: number) => {
      if (!dossier) {
        toast('Aucun dossier ouvert — pressez une lettre d’abord')
        return
      }
      const a = dossier.actions[fente]
      if (!a) return

      if (a.t === 'copie') {
        void auPressePapiers(texteDuDossier(dossier)).then((ok) =>
          toast(ok ? 'Dossier copié — prêt à coller' : 'Copie refusée par le navigateur'),
        )
        return
      }

      poser({
        touche: a.t === 'acte' ? '⏎ agir' : '⌫ reporter',
        roleId: dossier.roleId,
        titre: a.l,
        scn: a.note ?? dossier.sous,
        ondes: [],
        genre: a.t === 'acte' ? 'acte' : 'report',
      })
      if (a.t === 'acte') setCompteurs((c) => ({ ...c, actes: c.actes + 1 }))
      toast(a.t === 'acte' ? `Acte consigné — ${a.l}` : `Reporté — ${a.l}`)
    },
    [dossier, poser, toast],
  )

  const fermerDossier = useCallback(() => setDossier(null), [])

  return {
    roleActif,
    couche,
    dossier,
    traces,
    compteurs,
    pareFeu,
    repetition,
    pouvoirs,
    echos,
    enfoncee,
    rolesVisibles,
    grapheOuvert,
    setGrapheOuvert,
    setRole,
    setCouche,
    tournerCouche,
    presserLettre,
    presserRole,
    actionner,
    fermerDossier,
    basculerPareFeu,
    basculerRepetition,
    basculerPouvoirs,
    reinitialiser,
    rejouer,
    exporter,
    lireDernier,
  }
}
