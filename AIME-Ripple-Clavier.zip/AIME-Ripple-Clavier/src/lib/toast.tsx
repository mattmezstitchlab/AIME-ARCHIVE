import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'

interface Bulle {
  id: number
  texte: string
}

const Ctx = createContext<(texte: string) => void>(() => {})

export function FournisseurToast({ children }: { children: ReactNode }) {
  const [bulles, setBulles] = useState<Bulle[]>([])
  const compteur = useRef(0)

  const dire = useCallback((texte: string) => {
    const id = ++compteur.current
    setBulles((b) => [...b.slice(-2), { id, texte }])
    setTimeout(() => setBulles((b) => b.filter((x) => x.id !== id)), 2600)
  }, [])

  const valeur = useMemo(() => dire, [dire])

  return (
    <Ctx.Provider value={valeur}>
      {children}
      <div
        className="pointer-events-none fixed inset-x-0 bottom-6 z-[80] flex flex-col items-center gap-2 px-4"
        role="status"
        aria-live="polite"
      >
        {bulles.map((b) => (
          <div
            key={b.id}
            className="chrome trace-entre max-w-[min(30rem,92vw)] rounded-full border px-5 py-2.5 text-center text-[0.875rem] shadow-xl"
            style={{ borderColor: 'var(--line)', color: 'var(--ink)' }}
          >
            {b.texte}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  )
}

export const useToast = () => useContext(Ctx)
