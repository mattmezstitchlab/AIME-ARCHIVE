import { useEffect } from 'react'
import type { Reglages } from './reglages'

/**
 * La rangée F1–F12 n'est pas une démonstration : elle règle vraiment la page,
 * et le réglage suit d'une page à l'autre. Il n'y a donc pas de page
 * « accessibilité » séparée — l'accessibilité est dans le clavier.
 */
export const RANGEE_F: Array<{ k: string; l: string }> = [
  { k: 'F1 F2', l: 'contraste' },
  { k: 'F3', l: 'toute la carte' },
  { k: 'F4 F5', l: 'zoom du texte' },
  { k: 'F6', l: 'jour / nuit' },
  { k: 'F7 F8', l: 'lecture vocale' },
  { k: 'F9', l: 'interligne' },
  { k: 'F10', l: 'animations' },
  { k: 'F11', l: 'liens soulignés' },
  { k: 'F12', l: 'focus renforcé' },
]

const borne = (v: number, min: number, max: number) =>
  Math.min(max, Math.max(min, v))

function parler(texte: string) {
  if (typeof window === 'undefined' || !window.speechSynthesis) return false
  const s = window.speechSynthesis
  s.cancel()
  const u = new SpeechSynthesisUtterance(texte.slice(0, 4000))
  u.lang = 'fr-FR'
  u.rate = 1
  s.speak(u)
  return true
}

function texteDeLaPage(): string {
  const cible =
    document.querySelector('[data-lecture]') ?? document.querySelector('main')
  return (cible?.textContent ?? '').replace(/\s+/g, ' ').trim()
}

interface Options {
  reglages: Reglages
  regler: (patch: Partial<Reglages>) => void
  toast: (texte: string) => void
  /** F3 — la carte des gestes, disponible partout */
  ouvrirCarte: () => void
  /** esc — remettre à plat ce que la page a ouvert */
  echapper: () => boolean
}

export function useTouchesSysteme({
  reglages,
  regler,
  toast,
  ouvrirCarte,
  echapper,
}: Options) {
  useEffect(() => {
    const surTouche = (e: KeyboardEvent) => {
      const k = e.key

      if (k === 'Escape') {
        if (echapper()) e.preventDefault()
        return
      }

      if (!/^F([1-9]|1[0-2])$/.test(k)) return
      e.preventDefault()

      switch (k) {
        case 'F1':
          regler({ ctr: borne(+(reglages.ctr - 0.05).toFixed(2), 0.85, 1.6) })
          toast(`Contraste ${Math.round((reglages.ctr - 0.05) * 100)} %`)
          break
        case 'F2':
          regler({ ctr: borne(+(reglages.ctr + 0.05).toFixed(2), 0.85, 1.6) })
          toast(`Contraste ${Math.round((reglages.ctr + 0.05) * 100)} %`)
          break
        case 'F3':
          ouvrirCarte()
          break
        case 'F4':
          regler({ fs: borne(reglages.fs - 10, 80, 180) })
          toast(`Texte ${borne(reglages.fs - 10, 80, 180)} %`)
          break
        case 'F5':
          regler({ fs: borne(reglages.fs + 10, 80, 180) })
          toast(`Texte ${borne(reglages.fs + 10, 80, 180)} %`)
          break
        case 'F6': {
          const suivant = reglages.theme === 'jour' ? 'nuit' : 'jour'
          regler({ theme: suivant })
          toast(suivant === 'jour' ? 'Jour' : 'Nuit')
          break
        }
        case 'F7':
          toast(
            parler(texteDeLaPage())
              ? 'Lecture de la page'
              : 'Synthèse vocale indisponible sur ce navigateur',
          )
          break
        case 'F8': {
          const s = window.speechSynthesis
          if (!s) {
            toast('Synthèse vocale indisponible sur ce navigateur')
            break
          }
          if (s.speaking && !s.paused) {
            s.pause()
            toast('Lecture en pause')
          } else if (s.paused) {
            s.resume()
            toast('Lecture reprise')
          } else {
            toast('Rien à lire — F7 démarre la lecture')
          }
          break
        }
        case 'F9': {
          const suivant = reglages.lh >= 2 ? 1.35 : +(reglages.lh + 0.15).toFixed(2)
          regler({ lh: suivant })
          toast(`Interligne ${suivant}`)
          break
        }
        case 'F10':
          regler({ anim: !reglages.anim })
          toast(reglages.anim ? 'Animations coupées' : 'Animations rétablies')
          break
        case 'F11':
          regler({ souligne: !reglages.souligne })
          toast(reglages.souligne ? 'Liens non soulignés' : 'Liens soulignés')
          break
        case 'F12':
          regler({ focus: !reglages.focus })
          toast(reglages.focus ? 'Focus normal' : 'Focus renforcé')
          break
      }
    }

    window.addEventListener('keydown', surTouche)
    return () => window.removeEventListener('keydown', surTouche)
  }, [reglages, regler, toast, ouvrirCarte, echapper])
}
