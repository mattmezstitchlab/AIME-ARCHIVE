import { GESTES, PROFILS, R, ROLES, SYSTEME } from '@/data/roles'
import { DOSSIERS } from '@/data/dossiers'
import type { Acte, Dossier, Geste, Profil, Role, Stat } from '@/data/types'

/* ------------------------------------------------------------------
   Le graphe causal, déduit des données — jamais saisi à la main.
------------------------------------------------------------------ */
export interface Arete {
  src: string
  dst: string
  n: number
  lock: number
}

export const ARETES: Arete[] = (() => {
  const m = new Map<string, Arete>()
  const ajouter = (a: string, b: string | undefined, lock: boolean) => {
    if (!b || !R[a] || !R[b] || a === b) return
    const cle = `${a}>${b}`
    const e = m.get(cle) ?? { src: a, dst: b, n: 0, lock: 0 }
    e.n++
    if (lock) e.lock++
    m.set(cle, e)
  }
  for (const [src, gestes] of Object.entries(GESTES))
    for (const g of Object.values(gestes))
      for (const o of g.ondes) {
        if (!o.r) continue
        ajouter(src, o.r, !!o.lock)
        for (const p of o.puis ?? []) ajouter(o.r, p.r, false)
      }
  return [...m.values()]
})()

export interface Statistiques {
  roles: number
  gestes: number
  ordre2: number
  masquees: number
  aretes: number
  liens: number
}

export const STATS: Statistiques = (() => {
  let gestes = 0
  let ordre2 = 0
  let masquees = 0
  for (const g of Object.values(GESTES))
    for (const v of Object.values(g)) {
      gestes++
      for (const o of v.ondes) {
        if (o.lock) masquees++
        ordre2 += (o.puis ?? []).length
      }
    }
  return {
    roles: Object.keys(GESTES).length,
    gestes,
    ordre2,
    masquees,
    aretes: ARETES.length,
    liens: ARETES.reduce((n, e) => n + e.n, 0),
  }
})()

/* ------------------------------------------------------------------
   Arcs — la forme dessinable d'une onde.
------------------------------------------------------------------ */
export interface Arc {
  r: string
  lock: boolean
  n?: number
  sous: Array<{ r?: string }>
}

export const arcsDuGeste = (g: Geste): Arc[] =>
  g.ondes
    .filter((o) => o.r)
    .map((o) => ({
      r: o.r!,
      lock: !!o.lock,
      sous: (o.puis ?? []).map((p) => ({ r: p.r })),
    }))

/** Tous les gestes d'un rôle, agrégés : qui il déplace, combien de fois. */
export function arcsDuRole(rid: string): Arc[] {
  const m = new Map<string, Arc>()
  for (const g of Object.values(GESTES[rid] ?? {}))
    for (const o of g.ondes) {
      if (!o.r) continue
      const e = m.get(o.r) ?? { r: o.r, lock: false, n: 0, sous: [] }
      e.n = (e.n ?? 0) + 1
      if (o.lock) e.lock = true
      for (const p of o.puis ?? [])
        if (!e.sous.some((s) => s.r === p.r)) e.sous.push({ r: p.r })
      m.set(o.r, e)
    }
  return [...m.values()].sort((a, b) => (b.n ?? 0) - (a.n ?? 0))
}

/* ------------------------------------------------------------------
   Le dossier — ce qui s'ouvre au-dessus du clavier.
------------------------------------------------------------------ */
export interface DossierVivant {
  cle: string
  who: string
  roleId: string
  titre: string
  sous: string
  faits: Array<[string, string]>
  tuiles?: Array<{ l: string; v: string }>
  stats: Stat[]
  arcs: Arc[]
  pieces: Dossier['pieces']
  actions: Acte[]
  ecrit: boolean
}

export function dossierDuGeste(
  rid: string,
  touche: string,
  g: Geste,
): DossierVivant {
  const d = DOSSIERS[`${rid}.${touche}`]
  const ro = R[rid]
  const arcs = arcsDuGeste(g)
  const ordre2 = arcs.reduce((n, a) => n + a.sous.length, 0)
  const masquees = arcs.filter((a) => a.lock).length

  return {
    cle: `touche ${touche}`,
    who: ro.court,
    roleId: rid,
    titre: g.label,
    sous: d?.sous ?? g.scn,
    faits:
      d?.faits ??
      ([
        ['Rôle', ro.nom],
        ['Position', etiquette(ro)],
        ['Rôles déplacés', String(arcs.length)],
        ['Ondes d’ordre 2', String(ordre2)],
        ['Sous scellé', masquees ? `${masquees} onde(s)` : 'aucune'],
      ] as Array<[string, string]>),
    tuiles: d?.tuiles,
    stats:
      d?.stats ??
      ([
        {
          forme: 'tuiles',
          items: [
            { l: 'Rôles déplacés', v: String(arcs.length) },
            { l: 'Ondes d’ordre 2', v: String(ordre2) },
            { l: 'Sous scellé', v: String(masquees) },
          ],
        },
        {
          forme: 'jauge',
          l: 'Portée sur le graphe',
          v: arcs.length + ordre2,
          max: ROLES.length,
          unite: ' rôles',
          note: `Une touche, ${arcs.length + ordre2} rôle(s) déplacé(s) sur ${ROLES.length}. Aucun message à écrire.`,
        },
      ] as Stat[]),
    arcs,
    pieces: d?.pieces,
    actions: (
      d?.actes ??
      ([
        {
          l: 'Consigner la décision',
          t: 'acte',
          note: `${g.label} — décision consignée par ${ro.court}.`,
        },
        {
          l: 'Reporter d’une semaine',
          t: 'report',
          note: `${g.label} — reporté d’une semaine, aucune onde propagée.`,
        },
        { l: 'Copier le dossier', t: 'copie' },
      ] as Acte[])
    ).slice(0, 3),
    ecrit: !!d,
  }
}

export function dossierDuRole(ro: Role): DossierVivant {
  const gestes = Object.entries(GESTES[ro.id] ?? {})
  const arcs = arcsDuRole(ro.id)
  const emis = ARETES.filter((e) => e.src === ro.id).reduce((n, e) => n + e.n, 0)
  const recus = ARETES.filter((e) => e.dst === ro.id).reduce((n, e) => n + e.n, 0)

  return {
    cle: 'le rôle',
    who: ro.court,
    roleId: ro.id,
    titre: ro.nom,
    sous: ro.ess,
    faits: [
      ['Position', etiquette(ro)],
      ['Gestes sur ce clavier', gestes.map(([k]) => k).join(' · ') || '—'],
      ['Ondes émises', String(emis)],
      ['Ondes reçues', String(recus)],
    ],
    stats: [
      {
        forme: 'tuiles',
        items: [
          { l: 'Gestes', v: String(gestes.length) },
          { l: 'Ondes émises', v: String(emis) },
          { l: 'Ondes reçues', v: String(recus) },
        ],
      },
      {
        forme: 'barres',
        tt: 'Qui ce rôle déplace le plus',
        unite: ' onde(s)',
        items: arcs.slice(0, 5).map((a) => ({ l: R[a.r].court, v: a.n ?? 0 })),
      },
    ],
    arcs,
    pieces: gestes.map(([k, g]) => ({
      n: `${k} — ${g.label}`,
      sous: DOSSIERS[`${ro.id}.${k}`]
        ? 'dossier écrit à la main'
        : 'dossier déduit du graphe',
      ext: k,
      e: DOSSIERS[`${ro.id}.${k}`] ? 'écrit' : 'déduit',
    })),
    actions: [
      { l: 'Lire l’essentiel à voix haute', t: 'acte', note: ro.ess },
      { l: 'Fermer le dossier', t: 'report' },
      { l: 'Copier le dossier', t: 'copie' },
    ],
    ecrit: false,
  }
}

/* ------------------------------------------------------------------
   Position d'un rôle dans un profil
------------------------------------------------------------------ */
export function etiquette(ro: Role): string {
  if (ro.meta) return 'le moteur — touche 0'
  const f = ro.famille
  return f === 'personnes'
    ? 'une personne du mariage'
    : f === 'seuil'
      ? 'un métier du seuil'
      : 'une prestation'
}

export const rolesDeLaCouche = (p: Profil, couche: number): string[] =>
  (p.couches[couche]?.roles ?? []).slice(0, 9)

export function numeroDuRole(
  p: Profil,
  couche: number,
  rid: string,
): string | null {
  const i = rolesDeLaCouche(p, couche).indexOf(rid)
  if (i >= 0) return String(i + 1)
  return rid === 'systeme' && p.moteur ? '0' : null
}

export function coucheDuRole(p: Profil, rid: string): number {
  const i = p.couches.findIndex((c) => c.roles.includes(rid))
  return i < 0 ? 0 : i
}

/** Tous les rôles atteignables depuis un profil, moteur compris. */
export function rolesDuProfil(p: Profil): Role[] {
  const vus = new Set<string>()
  const liste: Role[] = []
  for (const c of p.couches)
    for (const rid of c.roles.slice(0, 9))
      if (!vus.has(rid) && R[rid]) {
        vus.add(rid)
        liste.push(R[rid])
      }
  if (p.moteur) liste.push(SYSTEME)
  return liste
}

/** Combien de profils voient ce rôle ? Sert à la carte F3. */
export const proprietaires = (rid: string): Profil[] =>
  PROFILS.filter((p) => p.couches.some((c) => c.roles.includes(rid)))

/* ------------------------------------------------------------------
   Format
------------------------------------------------------------------ */
export const nb = (n: number) => n.toLocaleString('fr-FR')

export const compact = (n: number) =>
  n.toLocaleString('fr-FR', { maximumFractionDigits: 1 })

/** Rampe ordinale — une seule teinte, jamais un arc-en-ciel. */
export const rampe = (jour: boolean) =>
  jour ? ['#C6B180', '#9C8449', '#6E5B2E'] : ['#EBD8AE', '#C9B27E', '#8F7E55']

export const teinte = (ro: Role | undefined, jour: boolean) =>
  !ro ? '#8A7238' : jour ? ro.cJour : ro.c
