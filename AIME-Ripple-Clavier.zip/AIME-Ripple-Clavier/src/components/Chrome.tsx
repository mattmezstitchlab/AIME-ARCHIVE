import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import type { ReactNode } from 'react'
import { Link, useRouterState } from '@tanstack/react-router'
import { useReglages } from '@/lib/reglages'
import { useToast } from '@/lib/toast'
import { useTouchesSysteme } from '@/lib/touches-systeme'
import { Feuille } from './Feuille'
import { CarteDesGestes } from './CarteDesGestes'

/* ------------------------------------------------------------------
   Contexte de chrome — la carte F3 et la touche esc sont partagées
   par toutes les pages, comme la rangée F.
------------------------------------------------------------------ */
interface ChromeCtx {
  ouvrirCarte: () => void
  /** une page pose ici ce que `esc` doit refermer chez elle */
  poserEchappe: (fn: (() => boolean) | null) => void
  /** une page reçoit ici la touche choisie dans la carte F3 */
  poserChoixCarte: (fn: ((roleId: string, touche: string) => void) | null) => void
}

const Ctx = createContext<ChromeCtx>({
  ouvrirCarte: () => {},
  poserEchappe: () => {},
  poserChoixCarte: () => {},
})

export const useChrome = () => useContext(Ctx)

const LIENS = [
  { to: '/manifeste', l: 'Le manifeste' },
  { to: '/', l: 'Le clavier' },
  { to: '/reglages', l: 'Réglages' },
] as const

function Marque() {
  return (
    <span className="flex items-center gap-2.5">
      <svg width="19" height="19" viewBox="0 0 24 24" aria-hidden="true">
        <circle cx="12" cy="12" r="2.6" fill="currentColor" />
        <circle cx="12" cy="12" r="6.4" fill="none" stroke="currentColor" strokeOpacity=".55" />
        <circle cx="12" cy="12" r="10.4" fill="none" stroke="currentColor" strokeOpacity=".24" />
      </svg>
      <span className="text-[0.9rem] font-semibold tracking-[-0.02em]">
        AIME<span style={{ color: 'var(--ink-3)' }}>®</span>
      </span>
    </span>
  )
}

export function Chrome({ children }: { children: ReactNode }) {
  const { reglages, profilActif, pret, regler } = useReglages()
  const toast = useToast()
  const [carte, setCarte] = useState(false)
  const [menu, setMenu] = useState(false)
  const chemin = useRouterState({ select: (s) => s.location.pathname })

  const echappe = useRef<(() => boolean) | null>(null)
  const choixCarte = useRef<((roleId: string, touche: string) => void) | null>(null)

  const poserEchappe = useCallback((fn: (() => boolean) | null) => {
    echappe.current = fn
  }, [])
  const poserChoixCarte = useCallback(
    (fn: ((roleId: string, touche: string) => void) | null) => {
      choixCarte.current = fn
    },
    [],
  )

  const ouvrirCarte = useCallback(() => setCarte((v) => !v), [])

  const echapper = useCallback(() => {
    if (menu) {
      setMenu(false)
      return true
    }
    if (carte) {
      setCarte(false)
      return true
    }
    return echappe.current?.() ?? false
  }, [carte, menu])

  useTouchesSysteme({ reglages, regler, toast, ouvrirCarte, echapper })

  useEffect(() => setMenu(false), [chemin])

  const valeur = useMemo<ChromeCtx>(
    () => ({ ouvrirCarte, poserEchappe, poserChoixCarte }),
    [ouvrirCarte, poserEchappe, poserChoixCarte],
  )

  return (
    <Ctx.Provider value={valeur}>
      <div className="grain" aria-hidden />

      <a
        href="#contenu"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[90] focus:rounded-full focus:bg-[var(--accent)] focus:px-4 focus:py-2 focus:text-[var(--accent-ink)]"
      >
        Aller au contenu
      </a>

      <header
        className="chrome sticky top-0 z-50 border-b"
        style={{ borderColor: 'var(--line)' }}
      >
        <nav
          className="mx-auto flex h-12 items-center justify-between gap-4 px-[var(--gutter)]"
          style={{ maxWidth: 'var(--page)' }}
          aria-label="Navigation principale"
        >
          <Link to="/" className="shrink-0 no-underline" style={{ color: 'var(--ink)' }}>
            <Marque />
          </Link>

          <ul className="hidden items-center gap-8 md:flex">
            {LIENS.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className="text-[0.8rem] no-underline transition-opacity hover:opacity-100"
                  style={{
                    color: chemin === l.to ? 'var(--ink)' : 'var(--ink-2)',
                    fontWeight: chemin === l.to ? 500 : 400,
                  }}
                >
                  {l.l}
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <Link
              to="/reglages"
              className="hidden rounded-full border px-3 py-1 text-[0.72rem] no-underline transition-colors sm:block"
              style={{ borderColor: 'var(--line)', color: 'var(--ink-2)' }}
            >
              profil ·{' '}
              <span style={{ color: 'var(--ink)' }}>{pret ? profilActif.court : '—'}</span>
            </Link>
            <button
              type="button"
              className="grid h-8 w-8 place-items-center rounded-full md:hidden"
              style={{ color: 'var(--ink)' }}
              aria-expanded={menu}
              aria-label={menu ? 'Fermer le menu' : 'Ouvrir le menu'}
              onClick={() => setMenu((v) => !v)}
            >
              <svg width="17" height="17" viewBox="0 0 24 24" aria-hidden="true">
                {menu ? (
                  <path d="M5 5l14 14M19 5L5 19" stroke="currentColor" strokeWidth="1.6" />
                ) : (
                  <path d="M3 8h18M3 16h18" stroke="currentColor" strokeWidth="1.6" />
                )}
              </svg>
            </button>
          </div>
        </nav>

        {menu ? (
          <div className="border-t px-[var(--gutter)] py-4 md:hidden" style={{ borderColor: 'var(--line)' }}>
            <ul className="space-y-1">
              {LIENS.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="block rounded-xl px-3 py-2.5 text-[1.05rem] no-underline"
                    style={{ color: 'var(--ink)' }}
                  >
                    {l.l}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </header>

      <main id="contenu" className="relative z-10" data-lecture>
        {children}
      </main>

      <footer
        className="relative z-10 mt-24 border-t px-[var(--gutter)] py-12"
        style={{ borderColor: 'var(--line)' }}
      >
        <div className="mx-auto space-y-6" style={{ maxWidth: 'var(--page)' }}>
          <div className="flex flex-wrap items-center justify-between gap-6">
            <Marque />
            <ul className="flex flex-wrap gap-6 text-[0.78rem]">
              {LIENS.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="lien no-underline" style={{ color: 'var(--ink-2)' }}>
                    {l.l}
                  </Link>
                </li>
              ))}
              <li>
                <button type="button" onClick={ouvrirCarte} className="lien" style={{ color: 'var(--ink-2)' }}>
                  <span className="mono">F3</span> · toute la carte
                </button>
              </li>
            </ul>
          </div>
          <p className="max-w-[46rem] text-[0.78rem] leading-relaxed" style={{ color: 'var(--ink-3)' }}>
            AIME® · Ripple — le clavier causal. Un geste, une onde, une mémoire.
            Démonstration : un mariage de 148 personnes, le 12 septembre 2026.
            Aucun compte, aucun envoi — le clavier et ses réglages restent dans votre navigateur.
          </p>
        </div>
      </footer>

      <Feuille
        ouverte={carte}
        titre="La carte des gestes"
        sousTitre="Deux couches, quinze rôles, un clavier — et ce que votre profil en voit."
        onFermer={() => setCarte(false)}
        large
      >
        <CarteDesGestes
          jour={reglages.theme === 'jour'}
          profilActif={profilActif}
          onChoisir={(rid, k) => {
            setCarte(false)
            choixCarte.current?.(rid, k)
          }}
        />
      </Feuille>
    </Ctx.Provider>
  )
}
