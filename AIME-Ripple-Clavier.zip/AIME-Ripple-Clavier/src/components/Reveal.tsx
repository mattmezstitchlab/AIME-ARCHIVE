import { useEffect, useRef, useState } from 'react'
import type { ElementType, ReactNode } from 'react'

/** Révélation au défilement — une seule fois, puis l'observateur se retire. */
export function Reveal({
  children,
  delai = 0,
  as: Balise = 'div',
  className = '',
}: {
  children: ReactNode
  delai?: number
  as?: ElementType
  className?: string
}) {
  const ref = useRef<HTMLElement>(null)
  const [vu, setVu] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (!('IntersectionObserver' in window)) {
      setVu(true)
      return
    }
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVu(true)
          io.disconnect()
        }
      },
      { rootMargin: '0px 0px -12% 0px', threshold: 0.08 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  return (
    <Balise
      ref={ref}
      className={`reveal ${vu ? 'vu' : ''} ${className}`}
      style={{ transitionDelay: `${delai}ms` }}
    >
      {children}
    </Balise>
  )
}
