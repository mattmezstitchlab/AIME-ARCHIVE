import { R } from '@/data/roles'
import type { Onde, Trace } from '@/data/types'
import { teinte } from '@/lib/causal'

function LigneOnde({
  o,
  jour,
  pareFeu,
  profond = false,
}: {
  o: Onde
  jour: boolean
  pareFeu: boolean
  profond?: boolean
}) {
  if (o.none)
    return (
      <li className="text-[0.82rem] italic" style={{ color: 'var(--ink-3)' }}>
        {o.t}
      </li>
    )
  const ro = o.r ? R[o.r] : undefined
  const c = teinte(ro, jour)
  const masquee = !!o.lock && !pareFeu
  const texte = o.lock && pareFeu && o.vrai ? o.vrai : o.t

  return (
    <li className={profond ? 'ml-5' : ''}>
      <p className="flex items-start gap-2 text-[0.84rem] leading-snug">
        <span
          className="mt-[0.42rem] h-1.5 w-1.5 shrink-0 rounded-full"
          style={{ background: c, opacity: masquee ? 0.4 : 1 }}
          aria-hidden
        />
        <span className="min-w-0">
          <span className="font-medium" style={{ color: masquee ? 'var(--ink-3)' : c }}>
            {ro?.court ?? '—'}
          </span>
          <span style={{ color: 'var(--ink-3)' }}> · </span>
          <span style={{ color: masquee ? 'var(--ink-3)' : 'var(--ink-2)' }}>
            {masquee ? 'onde masquée — le pare-feu causal protège la surprise' : texte}
          </span>
          {o.lock ? (
            <span
              className="ml-2 rounded-full px-1.5 py-px align-middle text-[0.6rem] tracking-wide uppercase"
              style={{ background: 'var(--surface-hi)', color: 'var(--ink-3)' }}
            >
              {pareFeu ? 'levé' : 'scellé'}
            </span>
          ) : null}
        </span>
      </p>
      {o.puis?.length ? (
        <ul className="mt-1.5 space-y-1.5 border-l pl-3" style={{ borderColor: 'var(--line)' }}>
          {o.puis.map((p, i) => (
            <LigneOnde key={i} o={p} jour={jour} pareFeu={pareFeu} profond />
          ))}
        </ul>
      ) : null}
    </li>
  )
}

export function Memoire({
  traces,
  jour,
  pareFeu,
  compteurs,
  onReinitialiser,
  onExporter,
  onRejouer,
}: {
  traces: Trace[]
  jour: boolean
  pareFeu: boolean
  compteurs: { ondes: number; masquees: number; actes: number }
  onReinitialiser: () => void
  onExporter: () => void
  onRejouer: () => void
}) {
  return (
    <section aria-label="Mémoire causale" className="space-y-5">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="display t-2">Mémoire causale</h2>
          <p className="mt-1 text-[0.84rem]" style={{ color: 'var(--ink-2)' }}>
            <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
              {compteurs.ondes}
            </span>{' '}
            onde(s) ·{' '}
            <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
              {compteurs.masquees}
            </span>{' '}
            masquée(s) ·{' '}
            <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
              {compteurs.actes}
            </span>{' '}
            acte(s)
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={onRejouer} className="btn btn-fantome !px-4 !py-1.5 !text-[0.8rem]">
            rejouer
          </button>
          <button type="button" onClick={onExporter} className="btn btn-fantome !px-4 !py-1.5 !text-[0.8rem]">
            exporter
          </button>
          <button
            type="button"
            onClick={onReinitialiser}
            className="btn btn-fantome !px-4 !py-1.5 !text-[0.8rem]"
          >
            <span className="mono">esc</span> · réinitialiser
          </button>
        </div>
      </header>

      {!traces.length ? (
        <div
          className="card flex flex-col items-center justify-center gap-2 px-6 py-14 text-center"
          style={{ borderStyle: 'dashed' }}
        >
          <p className="t-3 display">Rien ne s’est encore produit.</p>
          <p className="max-w-[34rem] text-[0.9rem]" style={{ color: 'var(--ink-2)' }}>
            Pressez une lettre — et regardez le geste onduler chez tous les autres.
          </p>
        </div>
      ) : (
        <ol className="space-y-3">
          {traces.map((t) => {
            const ro = R[t.roleId]
            const c = teinte(ro, jour)
            return (
              <li
                key={t.id}
                className="card trace-entre overflow-hidden px-5 py-4"
                style={{ borderLeft: `3px solid ${c}`, opacity: t.simu ? 0.72 : 1 }}
              >
                <header className="flex flex-wrap items-baseline gap-x-2.5 gap-y-1 text-[0.76rem]">
                  <span className="font-medium" style={{ color: c }}>
                    {ro?.court ?? t.roleId}
                  </span>
                  <span className="mono" style={{ color: 'var(--ink-3)' }}>
                    · {t.touche}
                  </span>
                  <span className="font-medium" style={{ color: 'var(--ink)' }}>
                    {t.titre}
                  </span>
                  {t.simu ? (
                    <span
                      className="rounded-full px-1.5 py-px text-[0.62rem] tracking-wide uppercase"
                      style={{ background: 'var(--surface-hi)', color: 'var(--ink-3)' }}
                    >
                      répétition — rien n’est parti
                    </span>
                  ) : null}
                  <span className="mono tnum ml-auto" style={{ color: 'var(--ink-3)' }}>
                    {t.horo}
                  </span>
                </header>

                <p className="mt-1.5 text-[0.92rem] leading-snug">{t.scn}</p>

                {t.ondes.length ? (
                  <ul className="mt-3 space-y-2">
                    {t.ondes.map((o, i) => (
                      <LigneOnde key={i} o={o} jour={jour} pareFeu={pareFeu} />
                    ))}
                  </ul>
                ) : null}
              </li>
            )
          })}
        </ol>
      )}
    </section>
  )
}
