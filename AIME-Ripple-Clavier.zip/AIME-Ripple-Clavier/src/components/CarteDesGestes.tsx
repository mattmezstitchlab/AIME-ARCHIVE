import { GESTES, PROFILS, R, TOUS_LES_ROLES } from '@/data/roles'
import { DOSSIERS } from '@/data/dossiers'
import { STATS, proprietaires, teinte } from '@/lib/causal'
import type { Profil } from '@/data/types'

/**
 * F3 · toute la carte — chaque rôle, chaque geste, et les profils
 * sur le clavier desquels la touche existe vraiment.
 */
export function CarteDesGestes({
  jour,
  profilActif,
  onChoisir,
}: {
  jour: boolean
  profilActif: Profil
  onChoisir: (roleId: string, touche: string) => void
}) {
  const visibles = new Set(
    profilActif.couches.flatMap((c) => c.roles.slice(0, 9)).concat(profilActif.moteur ? ['systeme'] : []),
  )

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-x-8 gap-y-2 text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
        <span>
          <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
            {STATS.roles}
          </span>{' '}
          rôles
        </span>
        <span>
          <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
            {STATS.gestes}
          </span>{' '}
          gestes
        </span>
        <span>
          <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
            {Object.keys(DOSSIERS).length}
          </span>{' '}
          dossiers écrits à la main
        </span>
        <span>
          <span className="tnum font-medium" style={{ color: 'var(--ink)' }}>
            {PROFILS.length}
          </span>{' '}
          claviers
        </span>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {TOUS_LES_ROLES.map((ro) => {
          const gestes = Object.entries(GESTES[ro.id] ?? {})
          if (!gestes.length) return null
          const c = teinte(ro, jour)
          const surMonClavier = visibles.has(ro.id)
          const qui = proprietaires(ro.id)

          return (
            <section
              key={ro.id}
              className="card-2 flex flex-col gap-3 p-4"
              style={{ opacity: surMonClavier ? 1 : 0.55 }}
            >
              <header className="flex items-start gap-2.5">
                <span
                  className="mt-[0.42rem] h-2.5 w-2.5 shrink-0 rounded-full"
                  style={{ background: c }}
                  aria-hidden
                />
                <div className="min-w-0">
                  <h3 className="truncate text-[0.95rem] font-semibold tracking-[-0.02em]">
                    {ro.nom}
                  </h3>
                  <p className="text-[0.76rem]" style={{ color: 'var(--ink-3)' }}>
                    {surMonClavier
                      ? 'sur votre clavier'
                      : `hors de votre clavier · ${qui.length} profil(s)`}
                  </p>
                </div>
              </header>

              <ul className="space-y-1.5">
                {gestes.map(([k, g]) => (
                  <li key={k}>
                    <button
                      type="button"
                      disabled={!surMonClavier}
                      onClick={() => onChoisir(ro.id, k)}
                      className="group flex w-full items-center gap-2.5 rounded-lg px-1.5 py-1 text-left transition-colors enabled:hover:bg-[var(--surface-hi)] disabled:cursor-not-allowed"
                    >
                      <span
                        className="mono grid h-6 w-6 shrink-0 place-items-center rounded-[6px] border text-[0.7rem] font-medium"
                        style={{ borderColor: 'var(--line)', color: c }}
                      >
                        {k}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-[0.82rem]">{g.label}</span>
                      {DOSSIERS[`${ro.id}.${k}`] ? (
                        <span
                          className="shrink-0 rounded-full px-1.5 py-px text-[0.62rem] tracking-wide uppercase"
                          style={{ background: 'var(--surface-hi)', color: 'var(--ink-3)' }}
                        >
                          dossier
                        </span>
                      ) : null}
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )
        })}
      </div>

      <div className="card-2 p-5">
        <p className="eyebrow mb-3">Le même moteur, découpé six fois</p>
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PROFILS.map((p) => (
            <li key={p.id} className="flex gap-3">
              <span
                className="mono grid h-6 w-6 shrink-0 place-items-center rounded-[6px] border text-[0.7rem]"
                style={{
                  borderColor: p.id === profilActif.id ? 'var(--accent)' : 'var(--line)',
                  color: p.id === profilActif.id ? 'var(--accent)' : 'var(--ink-3)',
                }}
              >
                {p.n}
              </span>
              <div>
                <p className="text-[0.85rem] font-medium">{p.nom}</p>
                <p className="text-[0.76rem]" style={{ color: 'var(--ink-3)' }}>
                  {p.couches.reduce((n, c) => n + Math.min(9, c.roles.length), 0)} touches ·{' '}
                  {p.couches.length} couche(s) ·{' '}
                  {p.feu === 'ouvrable' ? 'pare-feu ouvrable' : 'pare-feu scellé'}
                </p>
              </div>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-[0.82rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
          Ce qu’un rôle ne doit pas voir n’est ni grisé ni protégé par un mot de passe :
          la touche n’existe pas sur son clavier. Le clavier des mariés ne montre pas le
          flashmob ; celui des témoins, oui. C’est le même moteur —{' '}
          {R.systeme.court.toLowerCase()} compris.
        </p>
      </div>
    </div>
  )
}
