import type { Stat } from '@/data/types'
import { nb } from '@/lib/causal'

/* ------------------------------------------------------------------
   Les chiffres du dossier. Une seule teinte par bloc, jamais un
   arc-en-ciel : la couleur porte le rôle, pas la donnée.
------------------------------------------------------------------ */

const fmt = (v: number) =>
  Number.isInteger(v) ? nb(v) : v.toLocaleString('fr-FR', { maximumFractionDigits: 1 })

function Titre({ children }: { children: string }) {
  return <p className="eyebrow mb-3">{children}</p>
}

function Jauge({ s, tint }: { s: Extract<Stat, { forme: 'jauge' }>; tint: string }) {
  const pc = Math.max(2, Math.min(100, (s.v / s.max) * 100))
  return (
    <div className="card-2 p-5">
      <div className="flex items-baseline justify-between gap-4">
        <p className="text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
          {s.l}
        </p>
        <p className="tnum display text-[1.35rem]">
          {fmt(s.v)}
          <span className="text-[0.8rem] font-normal" style={{ color: 'var(--ink-3)' }}>
            {' '}
            / {fmt(s.max)}
            {s.unite ?? ''}
          </span>
        </p>
      </div>
      <div
        className="mt-3 h-2 w-full overflow-hidden rounded-full"
        style={{ background: 'var(--surface-hi)' }}
        role="img"
        aria-label={`${s.l} : ${fmt(s.v)} sur ${fmt(s.max)}${s.unite ?? ''}`}
      >
        <div
          className="h-full rounded-full transition-[width] duration-700"
          style={{
            width: `${pc}%`,
            background: `linear-gradient(90deg, color-mix(in srgb, ${tint} 55%, transparent), ${tint})`,
          }}
        />
      </div>
      {s.note ? (
        <p className="mt-3 text-[0.82rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
          {s.note}
        </p>
      ) : null}
    </div>
  )
}

function Barres({ s, tint }: { s: Extract<Stat, { forme: 'barres' }>; tint: string }) {
  const max = Math.max(...s.items.map((i) => i.v), 1)
  return (
    <div className="card-2 p-5">
      <Titre>{s.tt}</Titre>
      <ul className="space-y-2.5">
        {s.items.map((it) => (
          <li key={it.l} className="grid grid-cols-[minmax(5.5rem,9rem)_1fr_auto] items-center gap-3">
            <span className="truncate text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
              {it.l}
            </span>
            <span
              className="h-2 overflow-hidden rounded-full"
              style={{ background: 'var(--surface-hi)' }}
            >
              <span
                className="block h-full rounded-full"
                style={{
                  width: `${Math.max(3, (it.v / max) * 100)}%`,
                  background: tint,
                  opacity: 0.55 + 0.45 * (it.v / max),
                }}
              />
            </span>
            <span className="tnum text-[0.82rem] font-medium">
              {fmt(it.v)}
              <span style={{ color: 'var(--ink-3)' }}>{s.unite ?? ''}</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function Empile({ s, tint }: { s: Extract<Stat, { forme: 'empile' }>; tint: string }) {
  const total = s.total || s.segs.reduce((n, x) => n + x.v, 0)
  return (
    <div className="card-2 p-5">
      <Titre>{s.tt}</Titre>
      <div
        className="flex h-3 w-full overflow-hidden rounded-full"
        style={{ background: 'var(--surface-hi)' }}
      >
        {s.segs.map((seg, i) => (
          <span
            key={seg.l}
            style={{
              width: `${(seg.v / total) * 100}%`,
              background: tint,
              opacity: 1 - i * 0.32,
            }}
            title={`${seg.l} : ${fmt(seg.v)}`}
          />
        ))}
      </div>
      <ul className="mt-4 flex flex-wrap gap-x-6 gap-y-2">
        {s.segs.map((seg, i) => (
          <li key={seg.l} className="flex items-center gap-2 text-[0.82rem]">
            <span
              className="h-2 w-2 rounded-full"
              style={{ background: tint, opacity: 1 - i * 0.32 }}
            />
            <span style={{ color: 'var(--ink-2)' }}>{seg.l}</span>
            <span className="tnum font-medium">{fmt(seg.v)}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function Tuiles({ s }: { s: Extract<Stat, { forme: 'tuiles' }> }) {
  return (
    <div className="grid grid-cols-3 gap-2.5">
      {s.items.map((it) => (
        <div key={it.l} className="card-2 px-3 py-4 text-center">
          <p className="tnum display text-[clamp(1.3rem,3.2vw,1.9rem)]">{it.v}</p>
          <p className="mt-1 text-[0.7rem] leading-tight" style={{ color: 'var(--ink-3)' }}>
            {it.l}
          </p>
        </div>
      ))}
    </div>
  )
}

function Chrono({ s, tint }: { s: Extract<Stat, { forme: 'chrono' }>; tint: string }) {
  return (
    <div className="card-2 p-5">
      <Titre>{s.tt}</Titre>
      <ol className="relative space-y-4 pl-5">
        <span
          className="absolute top-1.5 bottom-1.5 left-[3px] w-px"
          style={{ background: 'var(--line)' }}
          aria-hidden
        />
        {s.pas.map((p) => (
          <li key={p.h + p.t} className="relative">
            <span
              className="absolute top-[0.42rem] -left-5 h-[7px] w-[7px] rounded-full"
              style={{
                background: p.glisse ? tint : 'var(--ink-3)',
                boxShadow: p.glisse
                  ? `0 0 0 3px color-mix(in srgb, ${tint} 22%, transparent)`
                  : 'none',
              }}
              aria-hidden
            />
            <p className="flex flex-wrap items-baseline gap-2">
              <span className="mono tnum text-[0.82rem] font-medium">{p.h}</span>
              {p.avant && p.avant !== p.h ? (
                <span
                  className="mono tnum text-[0.72rem] line-through"
                  style={{ color: 'var(--ink-3)' }}
                >
                  {p.avant}
                </span>
              ) : null}
            </p>
            <p className="text-[0.86rem] leading-snug" style={{ color: 'var(--ink-2)' }}>
              {p.t}
            </p>
          </li>
        ))}
      </ol>
    </div>
  )
}

export function BlocStat({ s, tint }: { s: Stat; tint: string }) {
  switch (s.forme) {
    case 'jauge':
      return <Jauge s={s} tint={tint} />
    case 'barres':
      return <Barres s={s} tint={tint} />
    case 'empile':
      return <Empile s={s} tint={tint} />
    case 'tuiles':
      return <Tuiles s={s} />
    case 'chrono':
      return <Chrono s={s} tint={tint} />
  }
}
