import { GESTES, R, UNIVERSELLES } from '@/data/roles'
import type { Moteur } from '@/lib/moteur'
import { numeroDuRole, teinte } from '@/lib/causal'
import type { Profil } from '@/data/types'

/* ------------------------------------------------------------------
   Le clavier — AZERTY, taille réelle, tout au clavier ou à la souris.
   La contrainte est une pédagogie, pas un piège : chaque touche est
   aussi un bouton, pour qui ne peut pas taper.
------------------------------------------------------------------ */

type Spec =
  | { t: 'fn'; k: string; sub: string }
  | { t: 'role'; n: string }
  | { t: 'sym'; k: string }
  | { t: 'acte'; k: string; fente: number }
  | { t: 'lettre'; k: string }
  | { t: 'pad'; w: number }
  | { t: 'mod'; k: string; sub: string; w: number; quoi: string }

const FN: Array<{ k: string; sub: string }> = [
  { k: 'F1', sub: 'contraste −' },
  { k: 'F2', sub: 'contraste +' },
  { k: 'F3', sub: 'la carte' },
  { k: 'F4', sub: 'texte −' },
  { k: 'F5', sub: 'texte +' },
  { k: 'F6', sub: 'jour / nuit' },
  { k: 'F7', sub: 'lire' },
  { k: 'F8', sub: 'pause' },
  { k: 'F9', sub: 'interligne' },
  { k: 'F10', sub: 'animations' },
  { k: 'F11', sub: 'soulignés' },
  { k: 'F12', sub: 'focus' },
]

const RANGEES: Spec[][] = [
  FN.map((f) => ({ t: 'fn', ...f }) as Spec),
  [
    { t: 'sym', k: '@' },
    ...'1234567890'.split('').map((n) => ({ t: 'role', n }) as Spec),
    { t: 'sym', k: ')' },
    { t: 'acte', k: '⌫', fente: 1 },
  ],
  [
    { t: 'pad', w: 0.5 },
    ...'AZERTYUIOP'.split('').map((k) => ({ t: 'lettre', k }) as Spec),
    { t: 'pad', w: 0.9 },
  ],
  [
    { t: 'pad', w: 0.9 },
    ...'QSDFGHJKLM'.split('').map((k) => ({ t: 'lettre', k }) as Spec),
    { t: 'acte', k: '⏎', fente: 0 },
  ],
  [
    { t: 'pad', w: 1.5 },
    ...'WXCVBN'.split('').map((k) => ({ t: 'lettre', k }) as Spec),
    { t: 'acte', k: ',', fente: 2 },
    { t: 'sym', k: ';' },
    { t: 'sym', k: ':' },
    { t: 'pad', w: 0.9 },
  ],
  [
    { t: 'mod', k: 'ctrl', sub: 'Pouvoirs', w: 1.4, quoi: 'pouvoirs' },
    { t: 'mod', k: 'alt', sub: 'Couche', w: 1.4, quoi: 'couche' },
    { t: 'mod', k: 'espace', sub: 'Lire / Pause', w: 5.2, quoi: 'lire' },
    { t: 'mod', k: 'altgr', sub: 'Répétition', w: 1.7, quoi: 'repetition' },
    { t: 'mod', k: '◀', sub: 'couche −', w: 1, quoi: 'prec' },
    { t: 'mod', k: '▶', sub: 'couche +', w: 1, quoi: 'suiv' },
  ],
]

const largeur = (s: Spec) =>
  s.t === 'pad' ? s.w : s.t === 'mod' ? s.w : s.t === 'acte' ? 1.6 : 1

export function Clavier({
  m,
  profilActif,
  jour,
  onFn,
}: {
  m: Moteur
  profilActif: Profil
  jour: boolean
  onFn: (k: string) => void
}) {
  const gestesDuRole = GESTES[m.roleActif] ?? {}

  const rendre = (s: Spec, i: number) => {
    const w = largeur(s)
    const base: React.CSSProperties = {
      width: `calc(var(--u) * ${w} + ${(w - 1) * 0.3}rem)`,
      height: s.t === 'fn' ? 'calc(var(--u) * .66)' : 'var(--u)',
    }

    if (s.t === 'pad') return <span key={`p${i}`} style={base} aria-hidden />

    if (s.t === 'fn')
      return (
        <button
          key={s.k}
          type="button"
          onClick={() => onFn(s.k)}
          style={base}
          className="cap flex flex-col items-center justify-center gap-px px-0.5 leading-none"
          title={s.sub}
        >
          <span className="mono text-[calc(var(--u)*.2)] font-medium">{s.k}</span>
          <span
            className="hidden max-w-full truncate text-[calc(var(--u)*.145)] sm:block"
            style={{ color: 'var(--ink-3)' }}
          >
            {s.sub}
          </span>
        </button>
      )

    if (s.t === 'sym')
      return (
        <span
          key={`s${i}${s.k}`}
          style={base}
          aria-hidden
          className="cap cap-morte flex items-center justify-center"
        >
          <span className="mono text-[calc(var(--u)*.26)]" style={{ color: 'var(--ink-3)' }}>
            {s.k}
          </span>
        </span>
      )

    if (s.t === 'role') {
      const rid = m.rolesVisibles.find(
        (id) => numeroDuRole(profilActif, m.couche, id) === s.n,
      )
      const ro = rid ? R[rid] : undefined
      if (!ro)
        return (
          <span
            key={`r${s.n}`}
            style={base}
            aria-hidden
            className="cap cap-morte flex items-center justify-center"
          >
            <span className="mono text-[calc(var(--u)*.24)]" style={{ color: 'var(--ink-3)' }}>
              {s.n}
            </span>
          </span>
        )
      const c = teinte(ro, jour)
      const actif = m.roleActif === ro.id
      const echo = !!m.echos[ro.id]
      return (
        <button
          key={`r${s.n}`}
          type="button"
          onClick={() => m.presserRole(ro.id)}
          aria-pressed={actif}
          aria-label={`${s.n} — ${ro.nom}`}
          style={{ ...base, ['--tint' as string]: c }}
          className={`cap relative flex flex-col items-center justify-center gap-px overflow-hidden px-0.5 leading-none ${
            actif ? 'active' : ''
          } ${echo ? 'echo' : ''}`}
        >
          <span
            className="absolute inset-x-0 top-0 h-[2px]"
            style={{ background: c, opacity: actif || m.pouvoirs ? 1 : 0.28 }}
            aria-hidden
          />
          <span className="mono text-[calc(var(--u)*.22)] font-medium" style={{ color: c }}>
            {s.n}
          </span>
          <span className="max-w-full truncate text-[calc(var(--u)*.155)]" style={{ color: 'var(--ink-2)' }}>
            {ro.court}
          </span>
        </button>
      )
    }

    if (s.t === 'acte') {
      const a = m.dossier?.actions[s.fente]
      const vivante = !!a
      return (
        <button
          key={`a${s.fente}`}
          type="button"
          disabled={!vivante}
          onClick={() => m.actionner(s.fente)}
          style={base}
          aria-label={a ? `${s.k} — ${a.l}` : `${s.k} — aucun dossier ouvert`}
          className={`cap flex flex-col items-center justify-center gap-px px-1 leading-none ${
            vivante ? '' : 'cap-morte'
          }`}
        >
          <span className="mono text-[calc(var(--u)*.26)]">{s.k}</span>
          <span className="max-w-full truncate text-[calc(var(--u)*.145)]" style={{ color: 'var(--ink-3)' }}>
            {a ? a.l : '—'}
          </span>
        </button>
      )
    }

    if (s.t === 'mod') {
      const on =
        (s.quoi === 'pouvoirs' && m.pouvoirs) || (s.quoi === 'repetition' && m.repetition)
      return (
        <button
          key={s.k}
          type="button"
          onClick={() => {
            if (s.quoi === 'pouvoirs') m.basculerPouvoirs()
            else if (s.quoi === 'couche') m.tournerCouche(1)
            else if (s.quoi === 'lire') m.lireDernier()
            else if (s.quoi === 'repetition') m.basculerRepetition()
            else if (s.quoi === 'prec') m.tournerCouche(-1)
            else if (s.quoi === 'suiv') m.tournerCouche(1)
          }}
          aria-pressed={on || undefined}
          style={base}
          className={`cap flex flex-col items-center justify-center gap-px px-1 leading-none ${
            on ? 'active' : ''
          }`}
        >
          <span className="mono text-[calc(var(--u)*.19)]" style={{ color: 'var(--ink-2)' }}>
            {s.k}
          </span>
          <span className="max-w-full truncate text-[calc(var(--u)*.155)]">{s.sub}</span>
        </button>
      )
    }

    /* lettre */
    const g = gestesDuRole[s.k]
    const univ = UNIVERSELLES[s.k]
    const c = teinte(R[m.roleActif], jour)
    const vivante = !!g || !!univ
    return (
      <button
        key={s.k}
        type="button"
        onClick={(e) => m.presserLettre(s.k, e.shiftKey)}
        style={{ ...base, ['--tint' as string]: c }}
        aria-label={g ? `${s.k} — ${g.label}` : univ ? `${s.k} — ${univ}` : `${s.k} — touche libre`}
        className={`cap relative flex flex-col items-center justify-center gap-px overflow-hidden px-0.5 leading-none ${
          vivante ? '' : 'cap-morte'
        } ${m.enfoncee === s.k ? 'enfoncee' : ''} ${g ? 'active' : ''}`}
      >
        {g ? (
          <span
            className="absolute inset-x-0 bottom-0 h-[2px]"
            style={{ background: c, opacity: m.pouvoirs ? 1 : 0.5 }}
            aria-hidden
          />
        ) : null}
        <span
          className="text-[calc(var(--u)*.3)] font-medium"
          style={{ color: g ? 'var(--ink)' : 'var(--ink-2)' }}
        >
          {s.k}
        </span>
        <span
          className="max-w-full truncate text-[calc(var(--u)*.145)]"
          style={{ color: g ? c : 'var(--ink-3)' }}
        >
          {g?.label ?? univ ?? ''}
        </span>
      </button>
    )
  }

  return (
    <div
      className="card relative mx-auto w-full overflow-hidden p-[clamp(.6rem,1.6vw,1.1rem)]"
      style={{
        ['--u' as string]: 'clamp(1.9rem, 5.4vw, 3.5rem)',
        background: 'linear-gradient(180deg, var(--surface-2), var(--surface))',
        boxShadow: 'var(--shadow)',
      }}
      role="group"
      aria-label={`Clavier ${profilActif.nom}, couche ${m.couche + 1}`}
    >
      <div className="flex flex-col gap-[0.3rem]">
        {RANGEES.map((rangee, i) => (
          <div key={i} className="flex justify-center gap-[0.3rem]">
            {rangee.map(rendre)}
          </div>
        ))}
      </div>
    </div>
  )
}
