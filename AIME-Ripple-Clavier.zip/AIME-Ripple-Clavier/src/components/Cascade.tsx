import { R } from '@/data/roles'
import type { Arc } from '@/lib/causal'
import { teinte } from '@/lib/causal'

/**
 * L'onde dessinée : le rôle qui agit, à gauche ; ceux qu'il déplace, au
 * milieu ; les ondes d'ordre 2, à droite. Les ondes masquées sont en
 * pointillés — elles existent, on ne les lit pas.
 */
export function Cascade({
  source,
  arcs,
  jour,
  pareFeu,
}: {
  source: string
  arcs: Arc[]
  jour: boolean
  pareFeu: boolean
}) {
  if (!arcs.length) {
    return (
      <p className="text-[0.86rem]" style={{ color: 'var(--ink-3)' }}>
        Aucune onde. Certains silences sont sacrés.
      </p>
    )
  }

  const PAS = 46
  const H = arcs.length * PAS + 16
  const W = 640
  const xs = 30
  const xm = 232
  const xd = 452
  const ys = H / 2
  const ro = R[source]
  const cSrc = teinte(ro, jour)

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      height={H}
      role="img"
      aria-label={`${ro?.court ?? source} déplace ${arcs.length} rôle(s)`}
      style={{ overflow: 'visible' }}
    >
      <defs>
        <linearGradient id={`fil-${source}`} x1="0" x2="1">
          <stop offset="0%" stopColor={cSrc} stopOpacity="0.85" />
          <stop offset="100%" stopColor={cSrc} stopOpacity="0.16" />
        </linearGradient>
      </defs>

      <circle cx={xs} cy={ys} r="7" fill={cSrc} />
      <circle cx={xs} cy={ys} r="13" fill="none" stroke={cSrc} strokeOpacity="0.28" />
      <text
        x={xs}
        y={ys + 30}
        textAnchor="middle"
        fontSize="10.5"
        fill="var(--ink-3)"
        letterSpacing="0.06em"
      >
        {ro?.court ?? source}
      </text>

      {arcs.map((a, i) => {
        const y = 20 + i * PAS
        const cible = R[a.r]
        const c = teinte(cible, jour)
        const masquee = a.lock && !pareFeu
        return (
          <g key={a.r + i}>
            <path
              d={`M${xs + 12} ${ys} C ${xs + 100} ${ys}, ${xm - 110} ${y}, ${xm - 12} ${y}`}
              fill="none"
              stroke={`url(#fil-${source})`}
              strokeWidth="1.4"
              strokeDasharray={masquee ? '3 4' : undefined}
              opacity={masquee ? 0.5 : 1}
            />
            <circle cx={xm} cy={y} r="5" fill={c} opacity={masquee ? 0.42 : 1} />
            <text
              x={xm + 13}
              y={y + 3.5}
              fontSize="11.5"
              fill="var(--ink-2)"
              opacity={masquee ? 0.55 : 1}
            >
              {cible?.court ?? a.r}
              {a.lock ? (pareFeu ? ' · levé' : ' · scellé') : ''}
            </text>

            {a.sous.map((s, j) => {
              const yy = y + (j - (a.sous.length - 1) / 2) * 20
              const sc = teinte(s.r ? R[s.r] : undefined, jour)
              return (
                <g key={(s.r ?? '') + j}>
                  <path
                    d={`M${xm + 8} ${y} C ${xm + 90} ${y}, ${xd - 90} ${yy}, ${xd - 8} ${yy}`}
                    fill="none"
                    stroke={sc}
                    strokeOpacity="0.34"
                    strokeWidth="1.1"
                  />
                  <circle cx={xd} cy={yy} r="3.6" fill={sc} opacity="0.85" />
                  <text x={xd + 10} y={yy + 3.4} fontSize="10.5" fill="var(--ink-3)">
                    {s.r ? (R[s.r]?.court ?? s.r) : '—'}
                  </text>
                </g>
              )
            })}
          </g>
        )
      })}
    </svg>
  )
}
