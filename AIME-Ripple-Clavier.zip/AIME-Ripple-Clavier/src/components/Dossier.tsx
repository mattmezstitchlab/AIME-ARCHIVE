import { R } from '@/data/roles'
import type { CarteId } from '@/data/types'
import type { DossierVivant } from '@/lib/causal'
import { teinte } from '@/lib/causal'
import { BlocStat } from './Stats'
import { Cascade } from './Cascade'

const GLYPHES = ['⏎', '⌫', ','] as const

export function PanneauDossier({
  dossier,
  cartes,
  jour,
  pareFeu,
  onActionner,
  onFermer,
}: {
  dossier: DossierVivant | null
  cartes: CarteId[]
  jour: boolean
  pareFeu: boolean
  onActionner: (fente: number) => void
  onFermer: () => void
}) {
  if (!dossier) {
    return (
      <div
        className="card flex min-h-[13rem] flex-col items-center justify-center gap-3 px-6 py-12 text-center"
        style={{ borderStyle: 'dashed' }}
      >
        <p className="t-3 display max-w-[30rem]">
          Pressez une touche — son dossier s’ouvre ici, au-dessus du clavier.
        </p>
        <p className="flex flex-wrap justify-center gap-x-5 gap-y-1 text-[0.82rem]" style={{ color: 'var(--ink-3)' }}>
          <span>
            <span className="mono">A–Z</span> un geste
          </span>
          <span>
            <span className="mono">1–9</span> un rôle
          </span>
          <span>
            <span className="mono">E</span> l’essentiel
          </span>
          <span>
            <span className="mono">F3</span> toute la carte
          </span>
        </p>
      </div>
    )
  }

  const ro = R[dossier.roleId]
  const c = teinte(ro, jour)
  const voir = (id: CarteId) => cartes.includes(id)
  const tuiles = dossier.tuiles ?? []
  const pieces = dossier.pieces ?? []

  return (
    <article
      className="card dossier-entre overflow-hidden"
      key={`${dossier.roleId}.${dossier.cle}`}
      style={{ boxShadow: 'var(--shadow)' }}
      aria-live="polite"
    >
      <span className="block h-[3px] w-full" style={{ background: c }} aria-hidden />

      <header
        className="flex flex-wrap items-start justify-between gap-4 border-b px-5 py-5 sm:px-7"
        style={{ borderColor: 'var(--line)' }}
      >
        <div className="min-w-0">
          <p className="flex flex-wrap items-center gap-2 text-[0.74rem]">
            <span className="h-2 w-2 rounded-full" style={{ background: c }} aria-hidden />
            <span className="font-medium" style={{ color: c }}>
              {dossier.who}
            </span>
            <span className="mono" style={{ color: 'var(--ink-3)' }}>
              · {dossier.cle}
            </span>
            {dossier.ecrit ? null : (
              <span
                className="rounded-full px-1.5 py-px text-[0.62rem] tracking-wide uppercase"
                style={{ background: 'var(--surface-hi)', color: 'var(--ink-3)' }}
              >
                déduit du graphe
              </span>
            )}
          </p>
          <h2 className="display t-2 mt-1.5">{dossier.titre}</h2>
          <p className="lede mt-2 max-w-[44rem] !text-[1rem]">{dossier.sous}</p>
        </div>
        <button type="button" onClick={onFermer} className="btn btn-fantome shrink-0 !px-4 !py-1.5 !text-[0.8rem]">
          <span className="mono">esc</span> · fermer
        </button>
      </header>

      <div className="grid gap-5 px-5 py-6 sm:px-7 lg:grid-cols-2">
        {voir('infos') ? (
          <section className="space-y-4">
            <p className="eyebrow">Ce qu’il faut savoir</p>
            <dl className="card-2 divide-y" style={{ borderColor: 'var(--line)' }}>
              {dossier.faits.map(([l, v]) => (
                <div
                  key={l + v}
                  className="flex flex-wrap items-baseline justify-between gap-3 px-4 py-2.5"
                  style={{ borderColor: 'var(--line)' }}
                >
                  <dt className="text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
                    {l}
                  </dt>
                  <dd className="text-[0.88rem] font-medium">{v}</dd>
                </div>
              ))}
            </dl>
            {tuiles.length ? (
              <BlocStat s={{ forme: 'tuiles', items: tuiles }} tint={c} />
            ) : null}
          </section>
        ) : null}

        {voir('stats') && dossier.stats.length ? (
          <section className="space-y-4">
            <p className="eyebrow">Les chiffres</p>
            {dossier.stats.map((s, i) => (
              <BlocStat key={i} s={s} tint={c} />
            ))}
          </section>
        ) : null}

        {voir('graphe') ? (
          <section className="space-y-4">
            <p className="eyebrow">L’onde</p>
            <div className="card-2 overflow-x-auto p-4">
              <Cascade source={dossier.roleId} arcs={dossier.arcs} jour={jour} pareFeu={pareFeu} />
            </div>
          </section>
        ) : null}

        {voir('pieces') && pieces.length ? (
          <section className="space-y-4">
            <p className="eyebrow">Les pièces</p>
            <ul className="space-y-2">
              {pieces.map((p) => (
                <li
                  key={p.n}
                  className="card-2 flex items-center gap-3 px-4 py-3"
                  style={{ opacity: p.scelle && !pareFeu ? 0.55 : 1 }}
                >
                  <span
                    className="mono grid h-9 w-11 shrink-0 place-items-center rounded-lg border text-[0.62rem] tracking-wide"
                    style={{ borderColor: 'var(--line)', color: 'var(--ink-3)' }}
                  >
                    {p.ext}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[0.85rem] font-medium">{p.n}</span>
                    {p.sous ? (
                      <span className="block truncate text-[0.75rem]" style={{ color: 'var(--ink-3)' }}>
                        {p.sous}
                      </span>
                    ) : null}
                  </span>
                  <span
                    className="shrink-0 rounded-full px-2 py-0.5 text-[0.68rem]"
                    style={{
                      background: 'var(--surface-hi)',
                      color: p.scelle && !pareFeu ? 'var(--ink-3)' : 'var(--ink-2)',
                    }}
                  >
                    {p.scelle && !pareFeu ? 'scellé' : p.e}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </div>

      <footer
        className="border-t px-5 py-4 sm:px-7"
        style={{ borderColor: 'var(--line)', background: 'var(--surface-2)' }}
      >
        <p className="eyebrow mb-3">Actions — aux touches seulement</p>
        <ul className="grid gap-2 sm:grid-cols-3">
          {dossier.actions.map((a, i) => (
            <li key={a.l}>
              <button
                type="button"
                onClick={() => onActionner(i)}
                className="flex w-full items-center gap-3 rounded-xl border px-3.5 py-2.5 text-left transition-colors hover:bg-[var(--surface-hi)]"
                style={{ borderColor: 'var(--line)', background: 'var(--surface)' }}
              >
                <span
                  className="mono grid h-7 w-8 shrink-0 place-items-center rounded-lg border text-[0.8rem]"
                  style={{
                    borderColor: 'var(--line)',
                    color: a.t === 'acte' ? c : 'var(--ink-2)',
                  }}
                >
                  {GLYPHES[i]}
                </span>
                <span className="min-w-0 flex-1 truncate text-[0.84rem]">{a.l}</span>
              </button>
            </li>
          ))}
        </ul>
      </footer>
    </article>
  )
}
