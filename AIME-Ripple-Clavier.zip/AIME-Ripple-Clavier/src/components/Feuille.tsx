import { useEffect, useRef } from 'react'
import type { ReactNode } from 'react'

/**
 * Une feuille modale — présentation à l'Apple : voile flou, panneau qui monte,
 * `esc` pour fermer, focus piégé tant qu'elle est ouverte.
 */
export function Feuille({
  ouverte,
  titre,
  sousTitre,
  onFermer,
  children,
  large = false,
}: {
  ouverte: boolean
  titre: string
  sousTitre?: string
  onFermer: () => void
  children: ReactNode
  large?: boolean
}) {
  const panneau = useRef<HTMLDivElement>(null)
  const rendu = useRef<Element | null>(null)

  useEffect(() => {
    if (!ouverte) return
    rendu.current = document.activeElement
    const precedent = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    panneau.current?.focus()

    const piege = (e: KeyboardEvent) => {
      if (e.key !== 'Tab' || !panneau.current) return
      const cibles = panneau.current.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])',
      )
      if (!cibles.length) return
      const premier = cibles[0]
      const dernier = cibles[cibles.length - 1]
      if (e.shiftKey && document.activeElement === premier) {
        e.preventDefault()
        dernier.focus()
      } else if (!e.shiftKey && document.activeElement === dernier) {
        e.preventDefault()
        premier.focus()
      }
    }

    window.addEventListener('keydown', piege)
    return () => {
      window.removeEventListener('keydown', piege)
      document.body.style.overflow = precedent
      ;(rendu.current as HTMLElement | null)?.focus?.()
    }
  }, [ouverte])

  if (!ouverte) return null

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center">
      <button
        type="button"
        aria-label="Fermer"
        onClick={onFermer}
        className="voile absolute inset-0 cursor-default"
        style={{
          background: 'color-mix(in srgb, var(--bg-deep) 72%, transparent)',
          backdropFilter: 'blur(26px) saturate(160%)',
          WebkitBackdropFilter: 'blur(26px) saturate(160%)',
        }}
      />
      <div
        ref={panneau}
        role="dialog"
        aria-modal="true"
        aria-label={titre}
        tabIndex={-1}
        className={`feuille scroll-fin relative m-0 flex max-h-[92vh] w-full flex-col overflow-hidden border shadow-2xl outline-none sm:m-6 ${
          large ? 'sm:max-w-[80rem]' : 'sm:max-w-[62rem]'
        }`}
        style={{
          background: 'var(--surface)',
          borderColor: 'var(--line)',
          borderRadius: 'var(--r-xl)',
        }}
      >
        <header
          className="chrome sticky top-0 z-10 flex items-start justify-between gap-6 border-b px-6 py-5 sm:px-9"
          style={{ borderColor: 'var(--line)' }}
        >
          <div>
            <h2 className="display t-3">{titre}</h2>
            {sousTitre ? (
              <p className="mt-1 text-[0.9rem]" style={{ color: 'var(--ink-2)' }}>
                {sousTitre}
              </p>
            ) : null}
          </div>
          <button
            type="button"
            onClick={onFermer}
            className="btn btn-fantome shrink-0 !px-4 !py-1.5 !text-[0.8rem]"
          >
            <span className="mono">esc</span> · fermer
          </button>
        </header>
        <div className="scroll-fin overflow-y-auto px-6 py-7 sm:px-9 sm:py-9">
          {children}
        </div>
      </div>
    </div>
  )
}
