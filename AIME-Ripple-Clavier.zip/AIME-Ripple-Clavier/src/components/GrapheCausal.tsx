import { useMemo, useState } from 'react'
import { R, ROLES } from '@/data/roles'
import { ARETES, STATS, teinte } from '@/lib/causal'

/**
 * Le graphe causal — qui déplace qui. Les rôles sont posés en couronne,
 * les arêtes plongent vers le centre : plus une arête est épaisse,
 * plus le lien est fréquent.
 */
export function GrapheCausal({ jour }: { jour: boolean }) {
  const [survole, setSurvole] = useState<string | null>(null)

  const { pos, degres, maxN, maxDeg } = useMemo(() => {
    const W = 520
    const cx = W / 2
    const cy = W / 2
    const rayon = W / 2 - 74
    const p: Record<string, { x: number; y: number; a: number }> = {}
    ROLES.forEach((ro, i) => {
      const a = (i / ROLES.length) * Math.PI * 2 - Math.PI / 2
      p[ro.id] = { x: cx + Math.cos(a) * rayon, y: cy + Math.sin(a) * rayon, a }
    })
    const d: Record<string, number> = {}
    for (const e of ARETES) {
      d[e.src] = (d[e.src] ?? 0) + e.n
      d[e.dst] = (d[e.dst] ?? 0) + e.n
    }
    return {
      pos: p,
      degres: d,
      maxN: Math.max(...ARETES.map((e) => e.n), 1),
      maxDeg: Math.max(...Object.values(d), 1),
    }
  }, [])

  const W = 520

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_17rem]">
      <div className="card-2 p-3 sm:p-5">
        <svg
          viewBox={`0 0 ${W} ${W}`}
          width="100%"
          role="img"
          aria-label={`Graphe causal : ${STATS.roles} rôles, ${STATS.aretes} arêtes, ${STATS.liens} liens.`}
          onMouseLeave={() => setSurvole(null)}
        >
          <circle
            cx={W / 2}
            cy={W / 2}
            r={W / 2 - 74}
            fill="none"
            stroke="var(--line)"
            strokeDasharray="2 6"
          />

          {ARETES.map((e) => {
            const a = pos[e.src]
            const b = pos[e.dst]
            if (!a || !b) return null
            const actif = !survole || survole === e.src || survole === e.dst
            const c = teinte(R[e.src], jour)
            const qx = (a.x + b.x) / 2 + (W / 2 - (a.x + b.x) / 2) * 0.62
            const qy = (a.y + b.y) / 2 + (W / 2 - (a.y + b.y) / 2) * 0.62
            return (
              <path
                key={`${e.src}>${e.dst}`}
                d={`M${a.x} ${a.y} Q ${qx} ${qy} ${b.x} ${b.y}`}
                fill="none"
                stroke={c}
                strokeWidth={0.7 + (e.n / maxN) * 2.2}
                strokeOpacity={actif ? (survole ? 0.72 : 0.3) : 0.05}
                strokeDasharray={e.lock ? '3 4' : undefined}
                style={{ transition: 'stroke-opacity .3s var(--ease)' }}
              />
            )
          })}

          {ROLES.map((ro) => {
            const p = pos[ro.id]
            const c = teinte(ro, jour)
            const r = 4.5 + ((degres[ro.id] ?? 0) / maxDeg) * 7
            const droite = Math.cos(p.a) > -0.15
            const lx = p.x + Math.cos(p.a) * (r + 9)
            const ly = p.y + Math.sin(p.a) * (r + 9)
            const actif = !survole || survole === ro.id
            return (
              <g
                key={ro.id}
                onMouseEnter={() => setSurvole(ro.id)}
                style={{ cursor: 'pointer', opacity: actif ? 1 : 0.28, transition: 'opacity .3s' }}
              >
                <circle cx={p.x} cy={p.y} r={r + 8} fill="transparent" />
                <circle cx={p.x} cy={p.y} r={r} fill={c} />
                {survole === ro.id ? (
                  <circle cx={p.x} cy={p.y} r={r + 6} fill="none" stroke={c} strokeOpacity="0.45" />
                ) : null}
                <text
                  x={lx}
                  y={ly + 3.4}
                  fontSize="10.5"
                  textAnchor={droite ? 'start' : 'end'}
                  fill={survole === ro.id ? 'var(--ink)' : 'var(--ink-3)'}
                >
                  {ro.court}
                </text>
              </g>
            )
          })}
        </svg>
      </div>

      <aside className="space-y-4">
        <div className="card-2 p-5">
          <p className="eyebrow mb-3">Le moteur en chiffres</p>
          <dl className="space-y-2 text-[0.86rem]">
            {(
              [
                ['Rôles', STATS.roles],
                ['Gestes écrits', STATS.gestes],
                ['Arêtes causales', STATS.aretes],
                ['Liens pondérés', STATS.liens],
                ['Ondes d’ordre 2', STATS.ordre2],
                ['Ondes sous scellé', STATS.masquees],
              ] as Array<[string, number]>
            ).map(([l, v]) => (
              <div key={l} className="flex items-baseline justify-between gap-4">
                <dt style={{ color: 'var(--ink-2)' }}>{l}</dt>
                <dd className="tnum font-medium">{v}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="card-2 p-5">
          <p className="eyebrow mb-2">Lecture</p>
          <p className="text-[0.84rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
            Un disque large reçoit et émet beaucoup. Une arête épaisse est un lien
            fréquent. Les pointillés sont des ondes que le pare-feu retient.
            {survole ? (
              <>
                {' '}
                <span style={{ color: 'var(--ink)' }}>
                  {R[survole]?.nom} — {degres[survole] ?? 0} lien(s).
                </span>
              </>
            ) : (
              ' Survolez un rôle pour isoler ses arêtes.'
            )}
          </p>
        </div>
      </aside>
    </div>
  )
}
