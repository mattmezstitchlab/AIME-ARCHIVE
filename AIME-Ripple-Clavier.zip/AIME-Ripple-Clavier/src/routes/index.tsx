import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { PROFILS, R } from '@/data/roles'
import { STATS, coucheDuRole, nb, rolesDeLaCouche, teinte } from '@/lib/causal'
import { useReglages } from '@/lib/reglages'
import { useToast } from '@/lib/toast'
import { useMoteur } from '@/lib/moteur'
import { useChrome } from '@/components/Chrome'
import { Clavier } from '@/components/Clavier'
import { PanneauDossier } from '@/components/Dossier'
import { Memoire } from '@/components/Memoire'
import { GrapheCausal } from '@/components/GrapheCausal'
import { Feuille } from '@/components/Feuille'
import { Reveal } from '@/components/Reveal'
import { RANGEE_F } from '@/lib/touches-systeme'

export const Route = createFileRoute('/')({
  component: PageClavier,
})

/** Le mariage de démonstration — une date fixe, un compte à rebours vivant. */
const JOUR_J = '2026-09-12T15:00:00+02:00'

const LEGENDE: Array<{ k: string; l: string }> = [
  { k: 'A – Z', l: 'un geste du rôle actif' },
  { k: '1 – 9', l: 'changer de rôle' },
  { k: '0', l: 'le moteur causal' },
  { k: '⏎', l: 'agir' },
  { k: '⌫', l: 'reporter' },
  { k: ',', l: 'copier le dossier' },
  { k: '◀ ▶', l: 'changer de couche' },
  { k: '⇧ + lettre', l: 'répéter sans propager' },
  { k: 'esc', l: 'refermer' },
  { k: 'F1 – F12', l: 'confort de lecture' },
]

function Compteur({ v, l }: { v: string; l: string }) {
  return (
    <div>
      <p className="display tnum text-[clamp(1.5rem,3.4vw,2.4rem)]">{v}</p>
      <p className="mt-0.5 text-[0.76rem]" style={{ color: 'var(--ink-2)' }}>
        {l}
      </p>
    </div>
  )
}

function PageClavier() {
  const { reglages, profilActif, pret, regler } = useReglages()
  const toast = useToast()
  const { ouvrirCarte, poserEchappe, poserChoixCarte } = useChrome()
  const m = useMoteur({ profilActif, reglages, toast })
  const jour = reglages.theme === 'jour'
  const clavier = useRef<HTMLDivElement>(null)

  /* le compte à rebours ne se calcule qu'au navigateur : le serveur ne rend
     jamais une date qui bougerait à l'hydratation */
  const [jours, setJours] = useState<number | null>(null)
  useEffect(() => {
    const ms = new Date(JOUR_J).getTime() - Date.now()
    setJours(Math.max(0, Math.ceil(ms / 86_400_000)))
  }, [])

  /* esc — d'abord le graphe, puis le dossier */
  useEffect(() => {
    poserEchappe(() => {
      if (m.grapheOuvert) {
        m.setGrapheOuvert(false)
        return true
      }
      if (m.dossier) {
        m.fermerDossier()
        return true
      }
      return false
    })
    return () => poserEchappe(null)
  }, [poserEchappe, m])

  /* la carte F3 renvoie une touche : on va d'abord chercher son rôle */
  const [enAttente, setEnAttente] = useState<{ r: string; k: string } | null>(null)

  useEffect(() => {
    poserChoixCarte((rid, k) => {
      const c = coucheDuRole(profilActif, rid)
      if (rid !== 'systeme' && c !== m.couche && rolesDeLaCouche(profilActif, c).includes(rid))
        m.setCouche(c)
      m.setRole(rid)
      setEnAttente({ r: rid, k })
      clavier.current?.scrollIntoView({ block: 'center', behavior: 'smooth' })
    })
    return () => poserChoixCarte(null)
  }, [poserChoixCarte, profilActif, m])

  useEffect(() => {
    if (!enAttente || m.roleActif !== enAttente.r) return
    const k = enAttente.k
    setEnAttente(null)
    m.presserLettre(k)
  }, [enAttente, m])

  /* le vrai clavier physique */
  useEffect(() => {
    const ecoute = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return
      const c = e.target as HTMLElement | null
      if (
        c &&
        (c.isContentEditable ||
          ['INPUT', 'TEXTAREA', 'SELECT'].includes(c.tagName) ||
          c.closest('[role="dialog"]'))
      )
        return

      const k = e.key
      if (/^[a-zA-Z]$/.test(k)) {
        e.preventDefault()
        m.presserLettre(k.toUpperCase(), e.shiftKey)
        return
      }
      if (/^[0-9]$/.test(k)) {
        const rid =
          k === '0'
            ? profilActif.moteur
              ? 'systeme'
              : null
            : (rolesDeLaCouche(profilActif, m.couche)[Number(k) - 1] ?? null)
        e.preventDefault()
        if (rid) m.presserRole(rid)
        else toast(`Touche ${k} — aucun rôle à ce numéro sur ce clavier`)
        return
      }
      if (k === 'Enter') {
        e.preventDefault()
        m.actionner(0)
      } else if (k === 'Backspace') {
        e.preventDefault()
        m.actionner(1)
      } else if (k === ',') {
        e.preventDefault()
        m.actionner(2)
      } else if (k === 'ArrowLeft') {
        m.tournerCouche(-1)
      } else if (k === 'ArrowRight') {
        m.tournerCouche(1)
      } else if (k === ' ') {
        e.preventDefault()
        m.lireDernier()
      }
    }
    window.addEventListener('keydown', ecoute)
    return () => window.removeEventListener('keydown', ecoute)
  }, [m, profilActif, toast])

  /* la rangée F du clavier dessiné rejoue les vraies touches système */
  const surFn = useCallback(
    (k: string) => {
      if (k === 'F3') {
        ouvrirCarte()
        return
      }
      window.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }))
    },
    [ouvrirCarte],
  )

  const roleActif = R[m.roleActif]
  const cActif = teinte(roleActif, jour)
  const couches = profilActif.couches
  const visibles = useMemo(() => m.rolesVisibles.map((id) => R[id]).filter(Boolean), [m.rolesVisibles])

  return (
    <>
      {/* ------------------------------------------------------------------
          Le titre — une phrase, deux lignes, rien d'autre à l'écran
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto px-[var(--gutter)] pt-[clamp(3.5rem,10vw,7rem)] pb-[clamp(2.5rem,5vw,4rem)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <p className="eyebrow">AIME® · Ripple</p>
          <h1 className="display t-hero mt-4">
            Le clavier
            <br />
            <span style={{ color: 'var(--ink-2)' }}>causal.</span>
          </h1>
          <p className="lede mt-6 max-w-[38rem]">
            Une touche. Un dossier qui s’ouvre. Une onde qui traverse quinze rôles —
            et la mémoire de qui a déplacé qui.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              type="button"
              className="btn btn-primaire"
              onClick={() => {
                clavier.current?.scrollIntoView({ block: 'center', behavior: 'smooth' })
                m.presserLettre('E')
              }}
            >
              Presser une touche
            </button>
            <Link to="/manifeste" className="btn btn-secondaire no-underline">
              Lire le manifeste
            </Link>
          </div>
          <p className="mt-6 text-[0.8rem]" style={{ color: 'var(--ink-3)' }}>
            Démonstration : un mariage de 148 personnes, le 12 septembre 2026
            {jours === null ? '' : ` · J−${nb(jours)}`}. Aucun compte, aucun envoi —
            tout tourne dans votre navigateur.
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Ce que la session a produit
      ------------------------------------------------------------------ */}
      <section className="mx-auto px-[var(--gutter)]" style={{ maxWidth: 'var(--page)' }}>
        <Reveal>
          <div
            className="card grid grid-cols-2 gap-6 px-6 py-6 sm:grid-cols-4 sm:px-8"
            aria-label="Compteurs de la session"
          >
            <Compteur v={nb(m.compteurs.ondes)} l="ondes propagées" />
            <Compteur v={nb(m.compteurs.masquees)} l="masquées par le pare-feu" />
            <Compteur v={nb(m.compteurs.actes)} l="actes consignés" />
            <Compteur v={`${nb(STATS.gestes)}`} l="gestes au catalogue" />
          </div>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          La barre de couche — qui est aux touches, et ce qu'il voit
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-8 px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
        aria-label="Réglages du clavier"
      >
        <div className="card-2 flex flex-wrap items-center gap-x-6 gap-y-3 px-5 py-4">
          <span className="flex items-center gap-2 text-[0.82rem]">
            <span className="eyebrow !tracking-[0.1em]">Profil</span>
            <Link to="/reglages" className="lien no-underline font-medium">
              {pret ? profilActif.nom : '…'}
            </Link>
          </span>

          {couches.length > 1 ? (
            <span className="flex items-center gap-2">
              <span className="eyebrow !tracking-[0.1em]">Couche</span>
              <span className="flex gap-1">
                {couches.map((c, i) => (
                  <button
                    key={c.nom}
                    type="button"
                    onClick={() => m.setCouche(i)}
                    aria-pressed={m.couche === i}
                    className="rounded-full px-3 py-1 text-[0.76rem] transition-colors"
                    style={{
                      background: m.couche === i ? 'var(--ink)' : 'transparent',
                      color: m.couche === i ? 'var(--bg)' : 'var(--ink-2)',
                      border: `1px solid ${m.couche === i ? 'transparent' : 'var(--line)'}`,
                    }}
                  >
                    {c.nom}
                  </button>
                ))}
              </span>
            </span>
          ) : (
            <span className="text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
              Une seule couche — {couches[0]?.nom}
            </span>
          )}

          <span className="ml-auto flex flex-wrap gap-2">
            <button
              type="button"
              onClick={m.basculerPareFeu}
              aria-pressed={m.pareFeu}
              className="rounded-full px-3 py-1 text-[0.76rem] transition-colors"
              style={{
                background: m.pareFeu ? 'color-mix(in srgb, var(--accent) 16%, transparent)' : 'transparent',
                color: m.pareFeu ? 'var(--accent)' : 'var(--ink-2)',
                border: `1px solid ${m.pareFeu ? 'color-mix(in srgb, var(--accent) 42%, transparent)' : 'var(--line)'}`,
              }}
            >
              pare-feu {m.pareFeu ? 'ouvert' : profilActif.feu === 'ouvrable' ? 'fermé' : 'scellé'}
            </button>
            <button
              type="button"
              onClick={m.basculerRepetition}
              aria-pressed={m.repetition}
              className="rounded-full px-3 py-1 text-[0.76rem] transition-colors"
              style={{
                background: m.repetition ? 'var(--surface-hi)' : 'transparent',
                color: m.repetition ? 'var(--ink)' : 'var(--ink-2)',
                border: '1px solid var(--line)',
              }}
            >
              ⇧ répétition
            </button>
            <button
              type="button"
              onClick={m.basculerPouvoirs}
              aria-pressed={m.pouvoirs}
              className="rounded-full px-3 py-1 text-[0.76rem] transition-colors"
              style={{
                background: m.pouvoirs ? 'var(--surface-hi)' : 'transparent',
                color: m.pouvoirs ? 'var(--ink)' : 'var(--ink-2)',
                border: '1px solid var(--line)',
              }}
            >
              pouvoirs
            </button>
            <button
              type="button"
              onClick={ouvrirCarte}
              className="rounded-full px-3 py-1 text-[0.76rem] transition-colors"
              style={{ color: 'var(--ink-2)', border: '1px solid var(--line)' }}
            >
              <span className="mono">F3</span> · la carte
            </button>
          </span>
        </div>

        {/* qui est aux touches */}
        <p className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-[0.8rem]">
          <span className="h-2 w-2 rounded-full" style={{ background: cActif }} aria-hidden />
          <span className="font-medium" style={{ color: cActif }}>
            {roleActif?.nom}
          </span>
          <span style={{ color: 'var(--ink-3)' }}>—</span>
          <span style={{ color: 'var(--ink-2)' }}>{roleActif?.ess}</span>
          <span className="ml-auto" style={{ color: 'var(--ink-3)' }}>
            {visibles.length} rôle(s) sous les doigts
          </span>
        </p>
      </section>

      {/* ------------------------------------------------------------------
          Le dossier, puis le clavier
      ------------------------------------------------------------------ */}
      <section
        ref={clavier}
        className="mx-auto mt-6 space-y-6 px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
        aria-label="Le clavier et son dossier"
      >
        <PanneauDossier
          dossier={m.dossier}
          cartes={profilActif.cartes.filter((c) => reglages.cartes.includes(c))}
          jour={jour}
          pareFeu={m.pareFeu}
          onActionner={m.actionner}
          onFermer={m.fermerDossier}
        />

        <Clavier m={m} profilActif={profilActif} jour={jour} onFn={surFn} />

        <ul
          className="flex flex-wrap justify-center gap-x-5 gap-y-2 text-[0.76rem]"
          style={{ color: 'var(--ink-3)' }}
        >
          {LEGENDE.map((l) => (
            <li key={l.k} className="flex items-center gap-1.5">
              <span className="mono" style={{ color: 'var(--ink-2)' }}>
                {l.k}
              </span>
              <span>{l.l}</span>
            </li>
          ))}
        </ul>
      </section>

      {/* ------------------------------------------------------------------
          Mémoire causale
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,7vw,5.5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Memoire
          traces={m.traces}
          jour={jour}
          pareFeu={m.pareFeu}
          compteurs={m.compteurs}
          onReinitialiser={m.reinitialiser}
          onExporter={m.exporter}
          onRejouer={m.rejouer}
        />
      </section>

      {/* ------------------------------------------------------------------
          Pourquoi un clavier
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <p className="eyebrow">Le principe</p>
          <h2 className="display t-1 mt-4 max-w-[22ch]">
            Une touche fait trois choses à la fois.
          </h2>
        </Reveal>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {[
            {
              n: '01',
              t: 'Elle ouvre un dossier',
              d: 'Pas un menu, pas un formulaire : l’état complet de la chose, chiffres et pièces compris, au-dessus du clavier.',
            },
            {
              n: '02',
              t: 'Elle propage une onde',
              d: 'Le geste ne s’arrête pas à vous. Il déplace le traiteur, la coordination, la mairie — et parfois eux à leur tour.',
            },
            {
              n: '03',
              t: 'Elle laisse une trace',
              d: 'La mémoire causale garde l’heure, la touche, le rôle et les ondes. Rien à reconstituer après coup.',
            },
          ].map((c, i) => (
            <Reveal key={c.n} delai={i * 90}>
              <article className="card lift h-full px-6 py-7">
                <p className="mono text-[0.74rem]" style={{ color: 'var(--ink-3)' }}>
                  {c.n}
                </p>
                <h3 className="display t-3 mt-2">{c.t}</h3>
                <p className="mt-2.5 text-[0.92rem]" style={{ color: 'var(--ink-2)' }}>
                  {c.d}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------------
          Le graphe — touche G du moteur
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,7vw,5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <div className="card flex flex-wrap items-center justify-between gap-6 px-7 py-8">
            <div className="max-w-[40rem]">
              <p className="eyebrow">Système · touche G</p>
              <h2 className="display t-2 mt-2">Le graphe causal — qui déplace qui</h2>
              <p className="mt-2.5 text-[0.95rem]" style={{ color: 'var(--ink-2)' }}>
                {nb(STATS.roles)} rôles, {nb(STATS.gestes)} gestes, {nb(STATS.aretes)} arêtes,{' '}
                {nb(STATS.ordre2)} ondes de second ordre et {nb(STATS.masquees)} sous scellé.
                Le moteur ne cache pas sa forme.
              </p>
            </div>
            <button type="button" className="btn btn-secondaire" onClick={() => m.setGrapheOuvert(true)}>
              Ouvrir le graphe
            </button>
          </div>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Six claviers, un moteur
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,7vw,5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <p className="eyebrow">Le même moteur, découpé six fois</p>
          <h2 className="display t-2 mt-3 max-w-[24ch]">
            Qui vous êtes décide des touches que vous avez.
          </h2>
        </Reveal>
        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PROFILS.map((p, i) => {
            const actif = p.id === profilActif.id
            return (
              <Reveal key={p.id} delai={i * 60}>
                <button
                  type="button"
                  onClick={() => regler({ profil: p.id, role: '' })}
                  aria-pressed={actif}
                  className="card lift h-full w-full px-5 py-5 text-left"
                  style={{
                    borderColor: actif ? 'color-mix(in srgb, var(--accent) 55%, transparent)' : undefined,
                  }}
                >
                  <p className="flex items-baseline gap-2">
                    <span className="mono text-[0.74rem]" style={{ color: 'var(--ink-3)' }}>
                      {p.n}
                    </span>
                    <span className="display t-3">{p.nom}</span>
                    {actif ? (
                      <span className="ml-auto text-[0.7rem]" style={{ color: 'var(--accent)' }}>
                        actif
                      </span>
                    ) : null}
                  </p>
                  <p className="mt-2 text-[0.88rem]" style={{ color: 'var(--ink-2)' }}>
                    {p.tagline}
                  </p>
                  <p className="mt-3 text-[0.74rem]" style={{ color: 'var(--ink-3)' }}>
                    {p.couches.length} couche(s) · {p.moteur ? 'moteur donné' : 'sans moteur'} ·
                    pare-feu {p.feu === 'ouvrable' ? 'ouvrable' : 'scellé'}
                  </p>
                </button>
              </Reveal>
            )
          })}
        </div>
      </section>

      {/* ------------------------------------------------------------------
          La rangée F — l'accessibilité est une rangée, pas une page
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,7vw,5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <div className="card-2 px-6 py-7">
            <p className="eyebrow">Accessible par construction</p>
            <h2 className="display t-3 mt-2 max-w-[34ch]">
              Le confort de lecture tient dans une rangée — la même sur toutes les pages.
            </h2>
            <ul className="mt-5 grid gap-x-6 gap-y-2 text-[0.8rem] sm:grid-cols-2 lg:grid-cols-3">
              {RANGEE_F.map((f) => (
                <li key={f.k} className="flex items-center gap-2">
                  <span
                    className="mono grid h-6 w-9 shrink-0 place-items-center rounded-md border text-[0.66rem]"
                    style={{ borderColor: 'var(--line)', color: 'var(--ink-2)' }}
                  >
                    {f.k}
                  </span>
                  <span style={{ color: 'var(--ink-2)' }}>{f.l}</span>
                </li>
              ))}
            </ul>
            <p className="mt-5 text-[0.8rem]" style={{ color: 'var(--ink-3)' }}>
              Chaque touche dessinée est aussi un bouton : la contrainte est une pédagogie,
              jamais un piège. Vos réglages restent sur cet appareil —{' '}
              <Link to="/reglages" className="lien">
                page réglages
              </Link>
              .
            </p>
          </div>
        </Reveal>
      </section>

      <Feuille
        ouverte={m.grapheOuvert}
        titre="Le graphe causal"
        sousTitre="Quinze rôles, et toutes les arêtes qui les relient. Survolez un rôle pour l’isoler."
        onFermer={() => m.setGrapheOuvert(false)}
        large
      >
        <GrapheCausal jour={jour} />
      </Feuille>
    </>
  )
}
