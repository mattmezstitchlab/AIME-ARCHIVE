import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'

import { Chrome } from '@/components/Chrome'
import { FournisseurReglages, SCRIPT_SANS_CLIGNOTEMENT } from '@/lib/reglages'
import { FournisseurToast } from '@/lib/toast'

import '../styles.css'

const TITRE = 'AIME® · Ripple — Le Clavier Causal'
const DESCRIPTION =
  'Un clavier par métier. Une touche est un geste, un geste ouvre un dossier et propage une onde chez tous ceux qu’elle concerne — sans réveiller les autres.'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover' },
      { title: TITRE },
      { name: 'description', content: DESCRIPTION },
      { name: 'theme-color', content: '#08080a' },
      { property: 'og:title', content: TITRE },
      { property: 'og:description', content: DESCRIPTION },
      { property: 'og:type', content: 'website' },
    ],
    links: [
      { rel: 'icon', href: '/favicon.ico' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Figtree:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap',
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" data-theme="nuit">
      <head>
        <HeadContent />
        <script dangerouslySetInnerHTML={{ __html: SCRIPT_SANS_CLIGNOTEMENT }} />
      </head>
      <body>
        <FournisseurReglages>
          <FournisseurToast>
            <Chrome>{children}</Chrome>
          </FournisseurToast>
        </FournisseurReglages>
        <Scripts />
      </body>
    </html>
  )
}
