import { useEffect } from 'react'
import type { ReactNode } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { PROFILS, profil } from '@/data/roles'
import { rolesDuProfil, teinte } from '@/lib/causal'
import { DEFAUTS, useReglages } from '@/lib/reglages'
import type { CarteId } from '@/data/types'
import { useToast } from '@/lib/toast'
import { Reveal } from '@/components/Reveal'

export const Route = createFileRoute('/reglages')({
  component: PageReglages,
})

const CARTES: Array<{ id: CarteId; l: string; d: string }> = [
  { id: 'infos', l: 'Ce qu’il faut savoir', d: 'Les faits du dossier, en clair.' },
  { id: 'stats', l: 'Les chiffres', d: 'Jauges, barres, chronologies.' },
  { id: 'graphe', l: 'L’onde', d: 'Qui le geste déplace, et qui ensuite.' },
  { id: 'pieces', l: 'Les pièces', d: 'Documents attachés au dossier.' },
]

function Ligne({
  titre,
  aide,
  children,
}: {
  titre: string
  aide?: string
  children: ReactNode
}) {
  return (
    <div
      className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3 border-b px-5 py-4 last:border-b-0"
      style={{ borderColor: 'var(--line)' }}
    >
      <div className="min-w-0 max-w-[30rem]">
        <p className="text-[0.94rem] font-medium">{titre}</p>
        {aide ? (
          <p className="mt-0.5 text-[0.8rem]" style={{ color: 'var(--ink-3)' }}>
            {aide}
          </p>
        ) : null}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  )
}

function Bascule({
  on,
  onChange,
  labelOn,
  labelOff,
}: {
  on: boolean
  onChange: (v: boolean) => void
  labelOn: string
  labelOff: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className="flex items-center gap-2.5 rounded-full border px-3 py-1.5 text-[0.8rem] transition-colors"
      style={{ borderColor: 'var(--line)', color: 'var(--ink-2)' }}
    >
      <span
        className="relative block h-[18px] w-[32px] rounded-full transition-colors"
        style={{ background: on ? 'var(--accent)' : 'var(--surface-hi)' }}
        aria-hidden
      >
        <span
          className="absolute top-[2px] block h-[14px] w-[14px] rounded-full bg-white transition-[left] duration-300"
          style={{ left: on ? '16px' : '2px', transitionTimingFunction: 'var(--ease)' }}
        />
      </span>
      <span style={{ color: 'var(--ink)' }}>{on ? labelOn : labelOff}</span>
    </button>
  )
}

function Pas({
  onMoins,
  onPlus,
  valeur,
  label,
}: {
  onMoins: () => void
  onPlus: () => void
  valeur: string
  label: string
}) {
  return (
    <span className="flex items-center gap-1.5">
      <button
        type="button"
        onClick={onMoins}
        aria-label={`${label} — diminuer`}
        className="cap mono grid h-8 w-9 place-items-center text-[0.9rem]"
      >
        −
      </button>
      <span
        className="tnum mono min-w-[4.5rem] text-center text-[0.84rem]"
        style={{ color: 'var(--ink-2)' }}
      >
        {valeur}
      </span>
      <button
        type="button"
        onClick={onPlus}
        aria-label={`${label} — augmenter`}
        className="cap mono grid h-8 w-9 place-items-center text-[0.9rem]"
      >
        +
      </button>
    </span>
  )
}

const borne = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v))

function PageReglages() {
  const { reglages, profilActif, pret, regler, oublier } = useReglages()
  const toast = useToast()
  const jour = reglages.theme === 'jour'
  const roles = rolesDuProfil(profilActif)

  /* 1 – 6 choisissent un profil : la page se règle au clavier, comme le reste */
  useEffect(() => {
    const ecoute = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return
      const c = e.target as HTMLElement | null
      if (c && (c.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(c.tagName))) return
      const p = PROFILS.find((x) => x.n === e.key)
      if (!p) return
      e.preventDefault()
      regler({ profil: p.id, role: '' })
      toast(`${p.nom} — ${p.tagline}`)
    }
    window.addEventListener('keydown', ecoute)
    return () => window.removeEventListener('keydown', ecoute)
  }, [regler, toast])

  return (
    <>
      <section
        className="mx-auto px-[var(--gutter)] pt-[clamp(3.5rem,10vw,7rem)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <p className="eyebrow">Réglages · qui suis-je</p>
          <h1 className="display t-1 mt-4 max-w-[18ch]">
            Un chiffre, un clavier.
          </h1>
          <p className="lede mt-5 max-w-[42rem]">
            Votre rôle décide de vos touches. Tout ce qui suit reste sur cet appareil — aucun
            compte, aucun envoi, rien à révoquer.
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Le profil
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-10 px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
        aria-label="Choix du profil"
      >
        <Reveal>
          <h2 className="display t-3">Mon clavier</h2>
          <p className="mt-1.5 text-[0.85rem]" style={{ color: 'var(--ink-3)' }}>
            Pressez le chiffre, ou choisissez à la souris.
          </p>
        </Reveal>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PROFILS.map((p, i) => {
            const actif = pret && p.id === profilActif.id
            return (
              <Reveal key={p.id} delai={i * 50}>
                <button
                  type="button"
                  onClick={() => regler({ profil: p.id, role: '' })}
                  aria-pressed={actif}
                  className="card lift h-full w-full px-5 py-5 text-left"
                  style={{
                    borderColor: actif
                      ? 'color-mix(in srgb, var(--accent) 55%, transparent)'
                      : undefined,
                    boxShadow: actif ? 'var(--shadow)' : undefined,
                  }}
                >
                  <p className="flex items-baseline gap-2">
                    <span
                      className="mono grid h-6 w-6 shrink-0 place-items-center rounded-md border text-[0.7rem]"
                      style={{
                        borderColor: actif ? 'transparent' : 'var(--line)',
                        background: actif ? 'var(--accent)' : 'transparent',
                        color: actif ? 'var(--accent-ink)' : 'var(--ink-3)',
                      }}
                    >
                      {p.n}
                    </span>
                    <span className="display t-3">{p.nom}</span>
                  </p>
                  <p className="mt-2.5 text-[0.88rem]" style={{ color: 'var(--ink-2)' }}>
                    {p.tagline}
                  </p>
                  <p className="mt-3 text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
                    {p.pour}
                  </p>
                  <p
                    className="mt-4 flex flex-wrap gap-x-3 gap-y-1 border-t pt-3 text-[0.72rem]"
                    style={{ borderColor: 'var(--line)', color: 'var(--ink-3)' }}
                  >
                    <span>{p.couches.length} couche(s)</span>
                    <span>{p.moteur ? 'moteur donné' : 'sans moteur'}</span>
                    <span>pare-feu {p.feu === 'ouvrable' ? 'ouvrable' : 'scellé'}</span>
                    <span>{p.cartes.length} carte(s)</span>
                  </p>
                </button>
              </Reveal>
            )
          })}
        </div>

        <Reveal delai={60}>
          <p className="mt-5 max-w-[52rem] text-[0.84rem]" style={{ color: 'var(--ink-3)' }}>
            {pret ? profilActif.note : ''}
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Le rôle d'ouverture
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,6vw,4.5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
        aria-label="Rôle d’ouverture"
      >
        <Reveal>
          <h2 className="display t-3">À l’ouverture, je suis…</h2>
          <p className="mt-1.5 text-[0.85rem]" style={{ color: 'var(--ink-3)' }}>
            Le rôle sous les doigts quand le clavier s’affiche. Par défaut, le premier de la couche 1.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => regler({ role: '' })}
              aria-pressed={!reglages.role}
              className="rounded-full border px-3.5 py-1.5 text-[0.8rem] transition-colors"
              style={{
                borderColor: !reglages.role ? 'transparent' : 'var(--line)',
                background: !reglages.role ? 'var(--ink)' : 'transparent',
                color: !reglages.role ? 'var(--bg)' : 'var(--ink-2)',
              }}
            >
              le premier de la couche
            </button>
            {roles.map((ro) => {
              const actif = reglages.role === ro.id
              const c = teinte(ro, jour)
              return (
                <button
                  key={ro.id}
                  type="button"
                  onClick={() => regler({ role: ro.id })}
                  aria-pressed={actif}
                  className="flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[0.8rem] transition-colors"
                  style={{
                    borderColor: actif ? c : 'var(--line)',
                    background: actif ? `color-mix(in srgb, ${c} 16%, transparent)` : 'transparent',
                    color: actif ? c : 'var(--ink-2)',
                  }}
                >
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} aria-hidden />
                  {ro.court}
                </button>
              )
            })}
          </div>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Confort de lecture — les mêmes réglages que la rangée F
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,6vw,4.5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
        aria-label="Confort de lecture"
      >
        <Reveal>
          <h2 className="display t-3">Confort de lecture</h2>
          <p className="mt-1.5 max-w-[46rem] text-[0.85rem]" style={{ color: 'var(--ink-3)' }}>
            Exactement ce que fait la rangée F1–F12, écrit en toutes lettres. Les deux commandent
            le même réglage : il n’y a pas de page « accessibilité » à part.
          </p>
          <div className="card mt-5 overflow-hidden">
            <Ligne titre="Thème" aide="F6 — jour / nuit">
              <Bascule
                on={jour}
                onChange={(v) => regler({ theme: v ? 'jour' : 'nuit' })}
                labelOn="jour"
                labelOff="nuit"
              />
            </Ligne>

            <Ligne titre="Contraste" aide="F1 / F2 — de 85 % à 160 %">
              <Pas
                label="Contraste"
                valeur={`${Math.round(reglages.ctr * 100)} %`}
                onMoins={() => regler({ ctr: borne(+(reglages.ctr - 0.05).toFixed(2), 0.85, 1.6) })}
                onPlus={() => regler({ ctr: borne(+(reglages.ctr + 0.05).toFixed(2), 0.85, 1.6) })}
              />
            </Ligne>

            <Ligne titre="Taille du texte" aide="F4 / F5 — de 80 % à 180 %">
              <Pas
                label="Taille du texte"
                valeur={`${reglages.fs} %`}
                onMoins={() => regler({ fs: borne(reglages.fs - 10, 80, 180) })}
                onPlus={() => regler({ fs: borne(reglages.fs + 10, 80, 180) })}
              />
            </Ligne>

            <Ligne titre="Interligne" aide="F9 — de 1,35 à 2">
              <Pas
                label="Interligne"
                valeur={reglages.lh.toLocaleString('fr-FR')}
                onMoins={() => regler({ lh: borne(+(reglages.lh - 0.15).toFixed(2), 1.35, 2) })}
                onPlus={() => regler({ lh: borne(+(reglages.lh + 0.15).toFixed(2), 1.35, 2) })}
              />
            </Ligne>

            <Ligne titre="Animations" aide="F10 — coupées d’office si le système le demande">
              <Bascule
                on={reglages.anim}
                onChange={(v) => regler({ anim: v })}
                labelOn="actives"
                labelOff="coupées"
              />
            </Ligne>

            <Ligne titre="Liens soulignés" aide="F11 — pour ne jamais confondre lien et texte">
              <Bascule
                on={reglages.souligne}
                onChange={(v) => regler({ souligne: v })}
                labelOn="soulignés"
                labelOff="normaux"
              />
            </Ligne>

            <Ligne titre="Focus renforcé" aide="F12 — un anneau large, visible de loin">
              <Bascule
                on={reglages.focus}
                onChange={(v) => regler({ focus: v })}
                labelOn="renforcé"
                labelOff="normal"
              />
            </Ligne>
          </div>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Le dossier
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,6vw,4.5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
        aria-label="Le dossier"
      >
        <Reveal>
          <h2 className="display t-3">Le dossier</h2>
          <p className="mt-1.5 max-w-[46rem] text-[0.85rem]" style={{ color: 'var(--ink-3)' }}>
            Ce qui s’ouvre au-dessus du clavier. Votre profil décide de ce qui est disponible ;
            vous décidez de ce que vous voulez voir.
          </p>
          <div className="card mt-5 overflow-hidden">
            <Ligne
              titre="Ouvrir le dossier à chaque touche"
              aide="Sinon, la touche propage l’onde et laisse sa trace, sans rien ouvrir."
            >
              <Bascule
                on={reglages.panneau}
                onChange={(v) => regler({ panneau: v })}
                labelOn="ouvert"
                labelOff="replié"
              />
            </Ligne>

            {CARTES.map((c) => {
              const dispo = profilActif.cartes.includes(c.id)
              const on = reglages.cartes.includes(c.id)
              return (
                <Ligne
                  key={c.id}
                  titre={c.l}
                  aide={
                    dispo ? c.d : `Indisponible sur le profil ${profilActif.nom} — ${c.d}`
                  }
                >
                  <Bascule
                    on={dispo && on}
                    onChange={(v) => {
                      if (!dispo) {
                        toast(`Le profil ${profilActif.nom} n’a pas cette carte`)
                        return
                      }
                      const suivant = v
                        ? [...reglages.cartes, c.id]
                        : reglages.cartes.filter((x) => x !== c.id)
                      if (!suivant.length) {
                        toast('Au moins une carte doit rester visible')
                        return
                      }
                      regler({ cartes: suivant })
                    }}
                    labelOn="visible"
                    labelOff="masquée"
                  />
                </Ligne>
              )
            })}
          </div>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Oublier
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,6vw,4.5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <div className="card-2 flex flex-wrap items-center justify-between gap-6 px-6 py-6">
            <div className="max-w-[38rem]">
              <h2 className="display t-3">Tout oublier</h2>
              <p className="mt-1.5 text-[0.85rem]" style={{ color: 'var(--ink-2)' }}>
                Les réglages vivent dans le stockage local de ce navigateur, sous une seule clé.
                Les effacer remet le clavier à neuf : profil {profil(DEFAUTS.profil).nom}, thème
                nuit, texte à 100 %.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="btn btn-fantome !px-5 !py-2 !text-[0.88rem]"
                onClick={() => {
                  oublier()
                  toast('Réglages oubliés — le clavier repart à neuf')
                }}
              >
                Oublier mes réglages
              </button>
              <Link to="/" className="btn btn-primaire no-underline !px-5 !py-2 !text-[0.88rem]">
                Ouvrir le clavier
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  )
}
