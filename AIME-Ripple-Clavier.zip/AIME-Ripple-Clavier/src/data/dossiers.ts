// Généré depuis le socle AIME® · Ripple — contenu de référence, typé.
import type { Dossier } from "./types"

export const DOSSIERS: Record<string, Dossier> = {
  "couple.O": {
    "sous": "Le oui est la première onde : elle réveille neuf métiers en douze secondes, et n'en dérange aucun deux fois.",
    "faits": [
      [
        "Date retenue",
        "samedi 12 septembre 2026"
      ],
      [
        "Lieu",
        "Domaine des Grands-Verger"
      ],
      [
        "Cérémonie civile",
        "11 h 15, mairie du bourg"
      ],
      [
        "Invités pressentis",
        "148"
      ]
    ],
    "tuiles": [
      {
        "l": "Métiers prévenus",
        "v": "9"
      },
      {
        "l": "Signatures à venir",
        "v": "4"
      },
      {
        "l": "Choses à refaire",
        "v": "0"
      }
    ],
    "stats": [
      {
        "forme": "jauge",
        "l": "Rétroplanning déplié",
        "v": 24,
        "max": 427,
        "unite": " j",
        "note": "427 jours de rétroplanning, dépliés d'un coup. Vous n'en verrez que trois décisions par semaine."
      }
    ],
    "pieces": [
      {
        "n": "Contrat_domaine_12-09.pdf",
        "sous": "Acompte 30 % — 4 320 €",
        "ext": "PDF",
        "e": "à signer"
      },
      {
        "n": "Creneau_mairie_11h15.pdf",
        "sous": "Sous réserve de publication des bans",
        "ext": "PDF",
        "e": "réservé"
      },
      {
        "n": "Save-the-date_148.csv",
        "sous": "148 adresses, 34 hors département",
        "ext": "CSV",
        "e": "prêt"
      }
    ],
    "actes": [
      {
        "l": "Confirmer la date au Domaine",
        "t": "acte",
        "note": "Date confirmée au Domaine des Grands-Verger : samedi 12 septembre 2026. Contrat déclenché."
      },
      {
        "l": "Garder l'option 48 h",
        "t": "report",
        "note": "Option tenue 48 h : aucune onde envoyée, aucun métier prévenu."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "couple.B": {
    "sous": "Un arbitrage de 600 € sur les fleurs. Trois métiers s'ajustent, les invités n'en sauront rien.",
    "faits": [
      [
        "Enveloppe totale",
        "26 000 €"
      ],
      [
        "Engagé à ce jour",
        "24 490 €"
      ],
      [
        "Arbitrage en cours",
        "fleurs : −600 €"
      ]
    ],
    "stats": [
      {
        "forme": "barres",
        "tt": "Postes engagés",
        "unite": " €",
        "items": [
          {
            "l": "Lieu",
            "v": 9400
          },
          {
            "l": "Traiteur",
            "v": 8950
          },
          {
            "l": "Photo",
            "v": 2850
          },
          {
            "l": "Musique",
            "v": 1450
          },
          {
            "l": "Fleurs",
            "v": 1200
          },
          {
            "l": "Papeterie",
            "v": 640
          }
        ]
      },
      {
        "forme": "jauge",
        "l": "Enveloppe engagée",
        "v": 24490,
        "max": 26000,
        "unite": " €",
        "note": "Il reste 1 510 € — soit exactement une navette de retour et deux menus enfants."
      }
    ],
    "pieces": [
      {
        "n": "Arbitrage_fleurs_v2.pdf",
        "sous": "Plus de feuillage, moins de pivoines",
        "ext": "PDF",
        "e": "à valider"
      },
      {
        "n": "Devis_fleuriste_1200.pdf",
        "ext": "PDF",
        "e": "reçu"
      },
      {
        "n": "Ce_que_les_invites_voient.txt",
        "sous": "Vide. C'est voulu.",
        "ext": "TXT",
        "e": "scellé",
        "scelle": true
      }
    ],
    "actes": [
      {
        "l": "Valider l'arbitrage à 1 200 €",
        "t": "acte",
        "note": "Arbitrage fleurs validé : 1 200 €. Fleuriste, lieu et coordination ajustés."
      },
      {
        "l": "Refuser et garder 1 800 €",
        "t": "report",
        "note": "Arbitrage refusé : l'enveloppe fleurs reste à 1 800 €, l'écart se prendra ailleurs."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "invite.R": {
    "sous": "Une réponse d'invité, et le traiteur, le plan de table et les navettes se recalculent avant que vous ayez fermé l'onglet.",
    "faits": [
      [
        "Faire-part envoyés",
        "148"
      ],
      [
        "Réponses reçues",
        "121"
      ],
      [
        "Dernière réponse",
        "hier, 23 h 12"
      ]
    ],
    "stats": [
      {
        "forme": "empile",
        "tt": "Où en sont les 148",
        "total": 148,
        "segs": [
          {
            "l": "Confirmés",
            "v": 112
          },
          {
            "l": "En attente",
            "v": 27
          },
          {
            "l": "Déclinés",
            "v": 9
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Couverts commandés",
            "v": "134"
          },
          {
            "l": "Régimes déclarés",
            "v": "6"
          },
          {
            "l": "Sièges de retour",
            "v": "38"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Reponse_Marchetti_Solene.pdf",
        "sous": "Deux adultes — le petit dort chez papi",
        "ext": "PDF",
        "e": "reçu"
      },
      {
        "n": "Covoiturage_Lille_13h.ics",
        "sous": "3 places, départ 13 h",
        "ext": "ICS",
        "e": "ouvert"
      }
    ],
    "actes": [
      {
        "l": "Enregistrer deux présences",
        "t": "acte",
        "note": "Deux présences enregistrées : 134 couverts, plan de table et navettes réalignés."
      },
      {
        "l": "Répondre plus tard",
        "t": "report",
        "note": "Réponse reportée : le traiteur garde sa fenêtre de commande ouverte jusqu'à J-21."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "traiteur.Q": {
    "sous": "132 devient 134 à 23 h 12. Personne n'a été réveillé, et pourtant tout est à jour.",
    "faits": [
      [
        "Couverts confirmés",
        "134"
      ],
      [
        "Écart depuis la commande",
        "+2"
      ],
      [
        "Coût de l'écart",
        "78,40 €"
      ]
    ],
    "stats": [
      {
        "forme": "barres",
        "tt": "Régimes à croiser",
        "unite": " pers.",
        "items": [
          {
            "l": "Végétarien",
            "v": 3
          },
          {
            "l": "Sans gluten",
            "v": 1
          },
          {
            "l": "Arachide",
            "v": 1
          },
          {
            "l": "Sans porc",
            "v": 2
          },
          {
            "l": "Menus enfants",
            "v": 9
          }
        ]
      },
      {
        "forme": "jauge",
        "l": "Cuisine — capacité de passe",
        "v": 134,
        "max": 160,
        "unite": " couverts",
        "note": "26 couverts de marge : deux tables de retardataires tiennent encore."
      }
    ],
    "pieces": [
      {
        "n": "BAT_menu_v4.pdf",
        "sous": "Bar de ligne — arrivage du 10",
        "ext": "PDF",
        "e": "à valider"
      },
      {
        "n": "Fiche_allergenes_table4.pdf",
        "sous": "Cuisine verrouillée, zéro trace en salle",
        "ext": "PDF",
        "e": "scellé",
        "scelle": true
      }
    ],
    "actes": [
      {
        "l": "Commander 134 couverts",
        "t": "acte",
        "note": "134 couverts commandés, 6 régimes croisés, cuisine verrouillée."
      },
      {
        "l": "Attendre J-21",
        "t": "report",
        "note": "Commande retenue jusqu'à J-21 — la fenêtre reste tenue."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "lieu.P": {
    "sous": "Orage annoncé à 17 h. Le plan B n'est pas un document : c'est une onde de quarante minutes.",
    "faits": [
      [
        "Bascule",
        "verger → grange"
      ],
      [
        "Durée de bascule",
        "40 min"
      ],
      [
        "Décision à prendre avant",
        "15 h 30"
      ]
    ],
    "stats": [
      {
        "forme": "chrono",
        "tt": "La bascule, minute par minute",
        "pas": [
          {
            "h": "14 h 50",
            "t": "Alerte météo : 80 % de pluie entre 17 h et 18 h 20"
          },
          {
            "h": "15 h 30",
            "t": "Dernier moment pour décider — au-delà, l'arche ne se remonte plus"
          },
          {
            "h": "16 h 10",
            "t": "Fleuriste : arche démontée, remontée sous charpente",
            "glisse": true
          },
          {
            "h": "16 h 50",
            "t": "Sono déplacée, câbles compris — le DJ garde son set",
            "glisse": true
          },
          {
            "h": "17 h 20",
            "t": "Cérémonie sous la charpente. Le Verbe porte mieux qu'au verger"
          }
        ]
      },
      {
        "forme": "jauge",
        "l": "Grange — capacité assise",
        "v": 148,
        "max": 160,
        "unite": " places",
        "note": "Douze places de marge : la bascule ne coûte aucun invité."
      }
    ],
    "pieces": [
      {
        "n": "Plan_grange_repli.pdf",
        "sous": "148 assis, deux allées, une arche",
        "ext": "PDF",
        "e": "validé"
      },
      {
        "n": "Consigne_office_pluie.pdf",
        "ext": "PDF",
        "e": "transmis"
      }
    ],
    "actes": [
      {
        "l": "Déclencher le plan B",
        "t": "acte",
        "note": "Plan B déclenché : bascule grange, six métiers pivotent en une passe."
      },
      {
        "l": "Attendre le radar de 15 h",
        "t": "report",
        "note": "Bascule retenue : nouveau point radar à 15 h, décision reportée d'une heure."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "coordo.J": {
    "sous": "Vingt minutes de retard, absorbées sans qu'un seul invité s'en aperçoive. C'est tout le métier.",
    "faits": [
      [
        "Glissement",
        "+20 min"
      ],
      [
        "Métiers recalculés",
        "6"
      ],
      [
        "Invités prévenus",
        "0 — inutile"
      ]
    ],
    "stats": [
      {
        "forme": "chrono",
        "tt": "Le Jour J, après glissement",
        "pas": [
          {
            "h": "16 h 20",
            "avant": "16 h 00",
            "t": "Cérémonie laïque — le Verbe respire, personne ne court",
            "glisse": true
          },
          {
            "h": "17 h 35",
            "avant": "17 h 15",
            "t": "Photo des quatre générations",
            "glisse": true
          },
          {
            "h": "20 h 02",
            "avant": "19 h 42",
            "t": "Golden hour recalculée — sept minutes de miel",
            "glisse": true
          },
          {
            "h": "22 h 40",
            "avant": "22 h 40",
            "t": "Dédicace des grands-parents — inchangée"
          },
          {
            "h": "01 h 00",
            "avant": "01 h 00",
            "t": "Fin de sono. L'élastique s'arrête là."
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Minutes absorbées",
            "v": "20"
          },
          {
            "l": "Créneaux déplacés",
            "v": "7"
          },
          {
            "l": "Appels passés",
            "v": "0"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Retroplanning_JourJ_v11.pdf",
        "sous": "Version 11 — la seule qui compte",
        "ext": "PDF",
        "e": "à jour"
      },
      {
        "n": "Consignes_chauffeurs_1h35.pdf",
        "ext": "PDF",
        "e": "envoyé"
      }
    ],
    "actes": [
      {
        "l": "Propager le glissement",
        "t": "acte",
        "note": "Glissement de 20 minutes propagé : DJ, traiteur, photo, Verbe et navettes recalés."
      },
      {
        "l": "Tenir l'horaire coûte que coûte",
        "t": "report",
        "note": "Horaire tenu : le glissement sera repris sur le plateau de fromages."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "photo.G": {
    "sous": "Sept minutes de lumière, volées entre le fromage et le dessert. Les invités n'y verront que du feu.",
    "faits": [
      [
        "Golden hour",
        "19 h 42 → 19 h 49"
      ],
      [
        "Absence des mariés",
        "9 min"
      ],
      [
        "Plan de repli",
        "porche ouest"
      ]
    ],
    "stats": [
      {
        "forme": "chrono",
        "tt": "La fenêtre de miel",
        "pas": [
          {
            "h": "19 h 33",
            "t": "Exfiltration en douceur — deux minutes avant, sans annonce"
          },
          {
            "h": "19 h 42",
            "t": "Première lumière rasante sur le verger"
          },
          {
            "h": "19 h 49",
            "t": "Dernière lumière. On rentre par la cuisine."
          },
          {
            "h": "19 h 51",
            "t": "Le plateau de fromages arrive. Personne n'a rien remarqué."
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Minutes de lumière",
            "v": "7"
          },
          {
            "l": "Images visées",
            "v": "40"
          },
          {
            "l": "Invités dérangés",
            "v": "0"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Reperages_verger_pluie.pdf",
        "sous": "Douze angles, dont trois sous abri",
        "ext": "PDF",
        "e": "reçu"
      },
      {
        "n": "Absence_des_maries_9min.txt",
        "sous": "Ce que les invités ne lisent pas",
        "ext": "TXT",
        "e": "scellé",
        "scelle": true
      }
    ],
    "actes": [
      {
        "l": "Réserver la fenêtre 19 h 33",
        "t": "acte",
        "note": "Fenêtre golden hour réservée : 19 h 33 → 19 h 49, fromages décalés de dix minutes."
      },
      {
        "l": "Laisser la lumière filer",
        "t": "report",
        "note": "Fenêtre non réservée : la golden hour passera sans les mariés."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "dj.B": {
    "sous": "Le BPM n'est pas un réglage : c'est une négociation avec le traiteur, le lieu et les voisins.",
    "faits": [
      [
        "Limiteur du lieu",
        "102 dB"
      ],
      [
        "Mesure la plus haute",
        "96,4 dB"
      ],
      [
        "Fin de sono",
        "1 h 00, extinction 2 h"
      ]
    ],
    "stats": [
      {
        "forme": "barres",
        "tt": "BPM par créneau",
        "items": [
          {
            "l": "21 h 40",
            "v": 96
          },
          {
            "l": "22 h 30",
            "v": 118
          },
          {
            "l": "23 h 15",
            "v": 124
          },
          {
            "l": "00 h 10",
            "v": 128
          },
          {
            "l": "00 h 47",
            "v": 112
          }
        ]
      },
      {
        "forme": "jauge",
        "l": "Niveau sonore mesuré",
        "v": 96.4,
        "max": 102,
        "unite": " dB",
        "note": "5,6 dB de marge : les voisins dorment, le limiteur ne coupera pas."
      }
    ],
    "pieces": [
      {
        "n": "Set_JourJ_4h20.m3u",
        "sous": "Dont 12 min d'élastique",
        "ext": "M3U",
        "e": "prêt"
      },
      {
        "n": "Ne_jamais_jouer.txt",
        "sous": "Onze titres. Certains silences sont sacrés.",
        "ext": "TXT",
        "e": "lu"
      }
    ],
    "actes": [
      {
        "l": "Monter le set de 6 BPM",
        "t": "acte",
        "note": "Set relevé de 6 BPM : le trou normand patientera dix minutes."
      },
      {
        "l": "Tenir le tempo actuel",
        "t": "report",
        "note": "Tempo tenu — le service reprend la main."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "temoin.S": {
    "sous": "Douze complices, une piste secrète, et un pare-feu qui tient. Ce dossier n'existe pas côté mariés.",
    "faits": [
      [
        "Titre",
        "« September »"
      ],
      [
        "Complices",
        "12"
      ],
      [
        "Répétitions faites",
        "2 sur 3"
      ],
      [
        "Visible par les mariés",
        "non"
      ]
    ],
    "stats": [
      {
        "forme": "jauge",
        "l": "Complices au point",
        "v": 9,
        "max": 12,
        "unite": " pers.",
        "note": "Trois complices n'ont pas encore répété. La troisième répétition est jeudi, 19 h."
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Ondes masquées",
            "v": "1"
          },
          {
            "l": "Créneaux fantômes",
            "v": "1"
          },
          {
            "l": "Fuites",
            "v": "0"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Choregraphie_September.mp4",
        "sous": "3 min 12 — top au premier refrain",
        "ext": "MP4",
        "e": "scellé",
        "scelle": true
      },
      {
        "n": "Liste_complices_12.csv",
        "ext": "CSV",
        "e": "scellé",
        "scelle": true
      },
      {
        "n": "Creneau_fantome_coordo.ics",
        "sous": "Invisible au planning des mariés",
        "ext": "ICS",
        "e": "scellé",
        "scelle": true
      }
    ],
    "actes": [
      {
        "l": "Verrouiller la surprise",
        "t": "acte",
        "note": "Surprise verrouillée : piste chargée, top au refrain, créneau fantôme posé."
      },
      {
        "l": "Annuler le flashmob",
        "t": "report",
        "note": "Flashmob annulé : les douze complices sont prévenus, les mariés ne sauront rien."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "navette.N": {
    "sous": "Deux navettes de dix-neuf places. Le but n'est pas le confort : c'est que personne ne conduise fatigué.",
    "faits": [
      [
        "Départ gare",
        "15 h 40"
      ],
      [
        "Dernier retour",
        "1 h 15, puis 1 h 35"
      ],
      [
        "Voitures évitées",
        "22"
      ]
    ],
    "stats": [
      {
        "forme": "barres",
        "tt": "Occupation par départ",
        "unite": " / 19",
        "items": [
          {
            "l": "15 h 40 gare",
            "v": 19
          },
          {
            "l": "16 h 20 hôtel",
            "v": 14
          },
          {
            "l": "1 h 15 hôtel",
            "v": 17
          },
          {
            "l": "1 h 35 bourg",
            "v": 11
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Sièges offerts",
            "v": "76"
          },
          {
            "l": "Places parking libérées",
            "v": "22"
          },
          {
            "l": "Retours anonymes",
            "v": "1"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Feuille_de_route_chauffeurs.pdf",
        "sous": "Deux véhicules, quatre boucles",
        "ext": "PDF",
        "e": "envoyé"
      },
      {
        "n": "Retour_0h30_anonyme.txt",
        "sous": "La dignité n'a pas besoin de public",
        "ext": "TXT",
        "e": "scellé",
        "scelle": true
      }
    ],
    "actes": [
      {
        "l": "Valider les quatre boucles",
        "t": "acte",
        "note": "Quatre boucles validées : 76 sièges, 22 voitures de moins au verger."
      },
      {
        "l": "Ajouter un retour à 0 h 30",
        "t": "acte",
        "note": "Un retour ajouté à 0 h 30 — la place reste anonyme, même au registre."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "mairie.H": {
    "sous": "Quinze minutes de décalage au civil, et toute la matinée se recalcule — y compris le goûter des enfants.",
    "faits": [
      [
        "Cérémonie civile",
        "11 h 15"
      ],
      [
        "Salle rendue",
        "12 h 00"
      ],
      [
        "Publication des bans",
        "12 août"
      ]
    ],
    "stats": [
      {
        "forme": "chrono",
        "tt": "La matinée recalculée",
        "pas": [
          {
            "h": "09 h 40",
            "avant": "10 h 00",
            "t": "Habillage avancé — goûter des enfants prévu avant",
            "glisse": true
          },
          {
            "h": "10 h 50",
            "t": "Convocation des quatre témoins, pièce d'identité en poche"
          },
          {
            "h": "11 h 15",
            "avant": "11 h 00",
            "t": "Cérémonie civile",
            "glisse": true
          },
          {
            "h": "12 h 00",
            "t": "Salle rendue. Cocktail décalé, glace commandée en plus."
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Témoins déclarés",
            "v": "4"
          },
          {
            "l": "Pièces au dossier",
            "v": "11"
          },
          {
            "l": "Manquantes",
            "v": "0"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Dossier_mariage_complet.pdf",
        "sous": "Onze pièces, zéro manquante",
        "ext": "PDF",
        "e": "déposé"
      },
      {
        "n": "Bans_publication_12-08.pdf",
        "ext": "PDF",
        "e": "affiché"
      }
    ],
    "actes": [
      {
        "l": "Accepter 11 h 15",
        "t": "acte",
        "note": "Horaire civil accepté à 11 h 15 : matinée recalculée en une passe."
      },
      {
        "l": "Demander un autre créneau",
        "t": "report",
        "note": "Autre créneau demandé — la matinée reste en attente."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "fleuriste.D": {
    "sous": "À 2 h, les compositions repartent. Aucune fleur à la benne : c'est une contrainte, pas une option.",
    "faits": [
      [
        "Créneau de démontage",
        "2 h – 3 h 30"
      ],
      [
        "Compositions",
        "39"
      ],
      [
        "À la benne",
        "3 tiges"
      ]
    ],
    "stats": [
      {
        "forme": "barres",
        "tt": "Où repartent les fleurs",
        "unite": " compositions",
        "items": [
          {
            "l": "Invités",
            "v": 22
          },
          {
            "l": "Maison de retraite",
            "v": 14
          },
          {
            "l": "Compost",
            "v": 3
          }
        ]
      },
      {
        "forme": "jauge",
        "l": "Fleurs qui vivent après",
        "v": 36,
        "max": 39,
        "unite": " comp.",
        "note": "Trois compositions ne survivent pas à la nuit. Les 36 autres ont une adresse."
      }
    ],
    "pieces": [
      {
        "n": "Bon_remise_maison_retraite.pdf",
        "sous": "Bénévole désigné, clés remises la veille",
        "ext": "PDF",
        "e": "signé"
      },
      {
        "n": "Plan_demontage_1h30.pdf",
        "ext": "PDF",
        "e": "validé"
      }
    ],
    "actes": [
      {
        "l": "Confirmer le créneau 2 h",
        "t": "acte",
        "note": "Démontage confirmé 2 h – 3 h 30 : un aller ajouté vers la maison de retraite du bourg."
      },
      {
        "l": "Reporter au lendemain",
        "t": "report",
        "note": "Démontage reporté au lendemain 9 h — le lieu accepte, le bénévole est prévenu."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "officiant.V": {
    "sous": "Vingt-quatre minutes verrouillées. Le Verbe ne s'allonge pas : il se répète jusqu'à tenir.",
    "faits": [
      [
        "Durée cérémonie",
        "24 min"
      ],
      [
        "Vœux",
        "2 min 10 chacun"
      ],
      [
        "Silence tenu",
        "60 s"
      ]
    ],
    "stats": [
      {
        "forme": "chrono",
        "tt": "Les vingt-quatre minutes",
        "pas": [
          {
            "h": "00:00",
            "t": "Entrée — quarante secondes de plus pour les enfants de pétales"
          },
          {
            "h": "04:20",
            "t": "Vœux, deux fois 2 min 10 — au mot près"
          },
          {
            "h": "11:00",
            "t": "Rituel du sable : six minutes, aînés en dernier"
          },
          {
            "h": "18:30",
            "t": "Minute de silence. Zéro obturateur — consigne écrite."
          },
          {
            "h": "24:00",
            "t": "Sortie. Le fondu d'entrée du DJ est réglé au premier pas."
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Minutes",
            "v": "24"
          },
          {
            "l": "Mouchoirs, rang un",
            "v": "12"
          },
          {
            "l": "Improvisation",
            "v": "0"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Ceremonie_v6_24min.pdf",
        "sous": "Version 6 — chronométrée",
        "ext": "PDF",
        "e": "verrouillé"
      },
      {
        "n": "Notes_intention_couple.pdf",
        "sous": "Deux pages, déposées au coffre du Verbe",
        "ext": "PDF",
        "e": "scellé",
        "scelle": true
      }
    ],
    "actes": [
      {
        "l": "Verrouiller les 24 minutes",
        "t": "acte",
        "note": "Cérémonie verrouillée à 24 minutes : photo, DJ et coordination alignés."
      },
      {
        "l": "Rouvrir le texte",
        "t": "report",
        "note": "Texte rouvert : la durée redevient indicative jusqu'à la répétition."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "enfants.G": {
    "sous": "Une nounou de 18 h à 1 h, et quatre familles peuvent enfin danser. C'est le meilleur rapport qualité-prix du mariage.",
    "faits": [
      [
        "Nounou",
        "18 h – 1 h, salle du bas"
      ],
      [
        "Enfants inscrits",
        "7 sur 9"
      ],
      [
        "Coût",
        "210 €"
      ]
    ],
    "stats": [
      {
        "forme": "jauge",
        "l": "Inscriptions garderie",
        "v": 7,
        "max": 9,
        "unite": " enfants",
        "note": "Deux familles n'ont pas encore inscrit — relance douce prévue à J-10."
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Menus enfants",
            "v": "9"
          },
          {
            "l": "Matelas",
            "v": "6"
          },
          {
            "l": "Parents libérés",
            "v": "8"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Contrat_garderie_18h-1h.pdf",
        "ext": "PDF",
        "e": "signé"
      },
      {
        "n": "Inscriptions_garderie.csv",
        "sous": "Deux clics, gratuit",
        "ext": "CSV",
        "e": "ouvert"
      }
    ],
    "actes": [
      {
        "l": "Ouvrir la garderie",
        "t": "acte",
        "note": "Garderie ouverte 18 h – 1 h : neuf menus enfants servis à 19 h, salle du bas équipée."
      },
      {
        "l": "Relancer les deux familles",
        "t": "acte",
        "note": "Relance envoyée aux deux familles restantes — inscription en deux clics."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  },
  "famille.H": {
    "sous": "Mamie a 92 ans. Une chambre au calme, sans escalier, et une navette douce à 22 h : trois métiers, aucune discussion.",
    "faits": [
      [
        "Chambre",
        "côté verger, rez-de-chaussée"
      ],
      [
        "Navette douce",
        "22 h, véhicule bas"
      ],
      [
        "Charge pour les mariés",
        "aucune"
      ]
    ],
    "stats": [
      {
        "forme": "barres",
        "tt": "Hébergements bloqués",
        "unite": " pers.",
        "items": [
          {
            "l": "Domaine",
            "v": 14
          },
          {
            "l": "Hôtel du bourg",
            "v": 22
          },
          {
            "l": "Chez des proches",
            "v": 9
          }
        ]
      },
      {
        "forme": "tuiles",
        "items": [
          {
            "l": "Chambres accessibles",
            "v": "3"
          },
          {
            "l": "Places assises garanties",
            "v": "2"
          },
          {
            "l": "Escaliers",
            "v": "0"
          }
        ]
      }
    ],
    "pieces": [
      {
        "n": "Chambre_verger_RDC.pdf",
        "sous": "Bloquée jusqu'au 13 septembre",
        "ext": "PDF",
        "e": "réservé"
      },
      {
        "n": "Navette_douce_22h.ics",
        "ext": "ICS",
        "e": "programmé"
      }
    ],
    "actes": [
      {
        "l": "Bloquer la chambre du verger",
        "t": "acte",
        "note": "Chambre côté verger bloquée au rez-de-chaussée, navette douce programmée à 22 h."
      },
      {
        "l": "Chercher une autre solution",
        "t": "report",
        "note": "Recherche relancée : le lieu propose deux autres chambres accessibles."
      },
      {
        "l": "Copier le dossier",
        "t": "copie"
      }
    ]
  }
}
