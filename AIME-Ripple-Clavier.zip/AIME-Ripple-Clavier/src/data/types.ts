/**
 * Le vocabulaire du clavier causal.
 *
 * Un rôle possède des gestes. Un geste ouvre un dossier et propage des ondes.
 * Une onde peut en déclencher une seconde (`puis`) ou rester masquée (`lock`)
 * derrière le pare-feu causal.
 */

export type Famille = 'personnes' | 'prestation' | 'seuil' | 'moteur'

export interface Role {
  id: string
  nom: string
  court: string
  /** teinte en mode nuit */
  c: string
  /** teinte en mode jour (plus dense, contraste AA sur fond clair) */
  cJour: string
  famille: Famille
  /** l'essentiel : une phrase, jamais deux */
  ess: string
  meta?: boolean
}

export interface Onde {
  /** le rôle touché ; absent si l'onde s'arrête là */
  r?: string
  t: string
  /** onde masquée par le pare-feu causal */
  lock?: boolean
  /** ce que l'onde dit vraiment, une fois le pare-feu levé */
  vrai?: string
  /** ondes d'ordre 2 */
  puis?: Onde[]
  /** « aucune onde » — le silence est une réponse */
  none?: boolean
}

/** Les gestes du moteur agissent sur l'application elle-même. */
export type EffetMoteur = 'graphe' | 'pare-feu' | 'rejouer' | 'exporter'

export interface Geste {
  label: string
  scn: string
  ondes: Onde[]
  effet?: EffetMoteur
}

/** roleId → lettre → geste */
export type Gestes = Record<string, Record<string, Geste>>

export type Stat =
  | {
      forme: 'jauge'
      l: string
      v: number
      max: number
      unite?: string
      note?: string
    }
  | {
      forme: 'barres'
      tt: string
      unite?: string
      items: Array<{ l: string; v: number }>
    }
  | {
      forme: 'empile'
      tt: string
      total: number
      segs: Array<{ l: string; v: number }>
    }
  | { forme: 'tuiles'; items: Array<{ l: string; v: string }> }
  | {
      forme: 'chrono'
      tt: string
      pas: Array<{ h: string; avant?: string; t: string; glisse?: boolean }>
    }

export interface Piece {
  n: string
  sous?: string
  ext: string
  e: string
  /** scellé : listé, jamais ouvert */
  scelle?: boolean
}

export type TypeActe = 'acte' | 'report' | 'copie'

export interface Acte {
  l: string
  t: TypeActe
  note?: string
}

export interface Dossier {
  sous: string
  faits?: Array<[string, string]>
  tuiles?: Array<{ l: string; v: string }>
  stats?: Stat[]
  pieces?: Piece[]
  actes?: Acte[]
}

export interface Couche {
  nom: string
  roles: string[]
}

export interface Profil {
  id: string
  /** le chiffre qui choisit ce profil sur la page réglages */
  n: string
  nom: string
  court: string
  tagline: string
  pour: string
  couches: Couche[]
  /** la touche 0 — le moteur causal — est-elle donnée ? */
  moteur: boolean
  feu: 'ouvrable' | 'scelle'
  cartes: CarteId[]
  note: string
}

export type CarteId = 'infos' | 'stats' | 'graphe' | 'pieces'

/** Une entrée de la mémoire causale. */
export interface Trace {
  id: number
  /** horodatage local, déjà formaté — la mémoire ne stocke pas d'objet Date */
  horo: string
  /** libellé de la touche pressée, ou l'acte posé */
  touche: string
  roleId: string
  titre: string
  scn: string
  ondes: Onde[]
  /** répétition : le geste s'est calculé, rien ne s'est propagé */
  simu?: boolean
  /** trace d'acte (⏎ / ⌫) plutôt que trace de geste */
  genre: 'geste' | 'acte' | 'report' | 'essentiel'
}
