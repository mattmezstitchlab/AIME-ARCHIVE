import type { Gestes, Profil, Role } from './types'
import { GESTES_METIERS } from './gestes'

/* ------------------------------------------------------------------
   Le moteur causal — présent sur toutes les couches, toujours en 0.
------------------------------------------------------------------ */
export const SYSTEME: Role = {
  id: 'systeme',
  nom: 'AIME · Le Moteur causal',
  court: 'Système',
  c: '#D8C79B',
  cJour: '#8A7238',
  famille: 'moteur',
  ess: 'Quinze rôles, deux couches, une seule mémoire — et rien à refaire.',
  meta: true,
}

/* ------------------------------------------------------------------
   Les quinze rôles du mariage — un catalogue, pas un clavier.
   Le clavier, lui, est découpé par profil.
------------------------------------------------------------------ */
export const ROLES: Role[] = [
  { id: 'couple', nom: 'Couple', court: 'Couple', c: '#FF6F91', cJour: '#B8355A', famille: 'personnes', ess: 'Trois décisions vous attendent — tout le reste peut attendre.' },
  { id: 'temoin', nom: 'Témoin', court: 'Témoin', c: '#E5C168', cJour: '#8C6A1F', famille: 'personnes', ess: 'Le discours : 3 min 40. La surprise : intacte.' },
  { id: 'famille', nom: 'Famille', court: 'Famille', c: '#C99A72', cJour: '#8C5F3E', famille: 'personnes', ess: 'Mamie a sa chambre, l’oncle a son menu — respirez.' },
  { id: 'invite', nom: 'Invité', court: 'Invité', c: '#8FD48C', cJour: '#3F7A3A', famille: 'personnes', ess: 'Répondu · Covoiturage trouvé · Il ne reste qu’à danser.' },
  { id: 'coordo', nom: 'Coordination', court: 'Coordo', c: '#FFD44D', cJour: '#8A6C00', famille: 'seuil', ess: 'Toutes les ondes passent par vous — et rien ne déborde.' },
  { id: 'dj', nom: 'DJ', court: 'DJ', c: '#B39CFF', cJour: '#5F3FD1', famille: 'prestation', ess: 'BPM branché sur l’orchestration du Jour J.' },
  { id: 'photo', nom: 'Photographe', court: 'Photo', c: '#7FB6EA', cJour: '#2F63A0', famille: 'prestation', ess: 'Golden hour : 19 h 42. Sept minutes de miel.' },
  { id: 'traiteur', nom: 'Traiteur', court: 'Traiteur', c: '#FF8A63', cJour: '#B0442A', famille: 'prestation', ess: '134 couverts, 6 régimes, 0 improvisation.' },
  { id: 'lieu', nom: 'Lieu', court: 'Lieu', c: '#5FC7B8', cJour: '#2F6E66', famille: 'prestation', ess: 'Le plan B est répété — même la pluie est prévue.' },
  { id: 'officiant', nom: 'Officiant · Le Verbe', court: 'Le Verbe', c: '#EFE9DC', cJour: '#6E6347', famille: 'seuil', ess: 'Les mots sont prêts. Le silence aussi.' },
  { id: 'fleuriste', nom: 'Fleuriste · Le Vivant', court: 'Fleuriste', c: '#EE97C6', cJour: '#8E4A78', famille: 'prestation', ess: 'Rien de coupé pour rien : chaque tige a sa table.' },
  { id: 'mairie', nom: 'Mairie · L’État civil', court: 'Mairie', c: '#9BAAC9', cJour: '#454F68', famille: 'seuil', ess: 'Le dossier est complet. Le reste n’est qu’une fête.' },
  { id: 'navette', nom: 'Navettes · Le Trajet', court: 'Navettes', c: '#AEBD87', cJour: '#535E2C', famille: 'prestation', ess: 'Personne ne rentrera au volant fatigué.' },
  { id: 'enfants', nom: 'Enfants d’honneur', court: 'Enfants', c: '#FFCE9E', cJour: '#8E602A', famille: 'seuil', ess: 'Six enfants, deux paniers, un seul couloir.' },
]

export const TOUS_LES_ROLES: Role[] = [...ROLES, SYSTEME]

export const R: Record<string, Role> = Object.fromEntries(
  TOUS_LES_ROLES.map((r) => [r.id, r]),
)

/* ------------------------------------------------------------------
   Les gestes du moteur — ils agissent sur l'application elle-même.
------------------------------------------------------------------ */
const GESTES_MOTEUR: Gestes['systeme'] = {
  G: {
    label: 'Graphe causal',
    scn: 'Le moteur ouvre sa carte : quinze rôles, cinquante gestes, et toutes les arêtes qui les relient.',
    effet: 'graphe',
    ondes: [
      { r: 'coordo', t: 'Voit d’un seul regard ce qui dépend de quoi' },
      { r: 'couple', t: 'Comprend enfin pourquoi ils n’ont rien à faire' },
    ],
  },
  P: {
    label: 'Pare-feu',
    scn: 'Le pare-feu bascule : les ondes masquées se laissent lire — vue organisation, jamais vue invités.',
    effet: 'pare-feu',
    ondes: [
      { r: 'temoin', t: 'Les surprises restent sous scellé côté mariés' },
      { r: 'coordo', t: 'Vue complète — c’est le seul rôle qui la mérite' },
    ],
  },
  R: {
    label: 'Rejouer',
    scn: 'Le moteur rejoue la mémoire, geste par geste, du plus ancien au plus récent.',
    effet: 'rejouer',
    ondes: [
      { r: 'couple', t: 'Quatorze mois de décisions relus en trente secondes' },
    ],
  },
  X: {
    label: 'Exporter',
    scn: 'La mémoire causale part en clair : horodatée, lisible par un humain.',
    effet: 'exporter',
    ondes: [
      { r: 'coordo', t: 'Compte rendu prêt à coller dans un mail' },
      { r: 'lieu', t: 'Trace écrite des consignes reçues' },
    ],
  },
}

export const GESTES: Gestes = { ...GESTES_METIERS, systeme: GESTES_MOTEUR }

/** Touches universelles — les mêmes sur tous les rôles. */
export const UNIVERSELLES: Record<string, string> = {
  A: 'Aller à…',
  E: 'Essentiel',
  L: 'Lire',
  T: 'Traduire',
}

/* ------------------------------------------------------------------
   Les profils de clavier — « qui on est » décide des touches.
------------------------------------------------------------------ */
export const PROFILS: Profil[] = [
  {
    id: 'maries',
    n: '1',
    nom: 'Futurs mariés',
    court: 'Mariés',
    tagline: 'Trois décisions par semaine. Jamais quatre.',
    pour: 'Celles et ceux qui se marient — et qui n’ont pas à savoir ce qu’on leur prépare.',
    couches: [
      { nom: 'Nos proches', roles: ['couple', 'temoin', 'famille', 'invite', 'coordo'] },
      { nom: 'Nos prestataires', roles: ['lieu', 'traiteur', 'photo', 'dj', 'fleuriste', 'officiant', 'mairie', 'navette', 'enfants'] },
    ],
    moteur: true,
    feu: 'scelle',
    cartes: ['infos', 'stats', 'graphe', 'pieces'],
    note: 'Le pare-feu reste scellé : les surprises préparées pour vous ne s’ouvrent pas depuis ce clavier.',
  },
  {
    id: 'invite',
    n: '2',
    nom: 'Invité',
    court: 'Invité',
    tagline: 'Cinq touches, une soirée, zéro question.',
    pour: 'Les 148 personnes qui reçoivent un faire-part et veulent juste savoir quoi faire.',
    couches: [{ nom: 'Votre soirée', roles: ['invite', 'navette', 'lieu', 'enfants', 'famille'] }],
    moteur: false,
    feu: 'scelle',
    cartes: ['infos', 'pieces'],
    note: 'Ni moteur, ni statistiques, ni graphe : un invité n’a pas à lire l’organisation.',
  },
  {
    id: 'prestataire',
    n: '3',
    nom: 'Prestataire',
    court: 'Prestataire',
    tagline: 'Votre métier en couche 1, vos interlocuteurs en couche 2.',
    pour: 'Traiteur, photographe, DJ, fleuriste, officiant, mairie, navettes.',
    couches: [
      { nom: 'Vos métiers', roles: ['traiteur', 'photo', 'dj', 'fleuriste', 'officiant', 'mairie', 'navette'] },
      { nom: 'Vos interlocuteurs', roles: ['coordo', 'lieu', 'couple', 'famille', 'invite'] },
    ],
    moteur: true,
    feu: 'ouvrable',
    cartes: ['infos', 'stats', 'graphe', 'pieces'],
    note: 'Pare-feu ouvrable : un prestataire doit pouvoir lire ce qu’on lui demande de taire.',
  },
  {
    id: 'lieu',
    n: '4',
    nom: 'Lieu',
    court: 'Lieu',
    tagline: 'Un domaine, quarante mariages par an, un seul clavier.',
    pour: 'Le domaine, la salle, la ferme — celui qui reçoit et qui rend les clés.',
    couches: [{ nom: 'Le domaine', roles: ['lieu', 'traiteur', 'navette', 'coordo', 'dj', 'fleuriste', 'enfants'] }],
    moteur: true,
    feu: 'ouvrable',
    cartes: ['infos', 'stats', 'graphe', 'pieces'],
    note: 'Le clavier du lieu ne parle que de ce qui touche les murs, les horaires et le parking.',
  },
  {
    id: 'temoin',
    n: '5',
    nom: 'Témoin & complices',
    court: 'Témoin',
    tagline: 'Le seul clavier qui garde des secrets pour de bon.',
    pour: 'Témoins, demoiselles et garçons d’honneur, comploteurs de flashmob.',
    couches: [{ nom: 'La complicité', roles: ['temoin', 'invite', 'dj', 'photo', 'coordo', 'enfants'] }],
    moteur: true,
    feu: 'ouvrable',
    cartes: ['infos', 'stats', 'graphe', 'pieces'],
    note: 'Ici le pare-feu s’ouvre : c’est vous qui tenez les surprises, donc vous qui les voyez.',
  },
  {
    id: 'orga',
    n: '6',
    nom: 'Organisation',
    court: 'Orga',
    tagline: 'Les quinze rôles, les deux couches, tout le graphe.',
    pour: 'Wedding planner, coordination, et quiconque doit voir l’ensemble.',
    couches: [
      { nom: 'Les personnes', roles: ['couple', 'temoin', 'famille', 'invite', 'coordo', 'dj', 'photo', 'traiteur', 'lieu'] },
      { nom: 'Les métiers du seuil', roles: ['officiant', 'fleuriste', 'mairie', 'navette', 'enfants'] },
    ],
    moteur: true,
    feu: 'ouvrable',
    cartes: ['infos', 'stats', 'graphe', 'pieces'],
    note: 'Le clavier complet — celui sur lequel le moteur a été dessiné.',
  },
]

export const PROFIL_DEFAUT = 'orga'

export const profil = (id: string | undefined): Profil =>
  PROFILS.find((p) => p.id === id) ?? PROFILS.find((p) => p.id === PROFIL_DEFAUT)!
