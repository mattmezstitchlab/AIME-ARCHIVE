// Généré depuis le socle AIME® · Ripple — contenu de référence, typé.
import type { Gestes } from "./types"

export const GESTES_METIERS: Gestes = {
  "couple": {
    "O": {
      "label": "Le « Oui »",
      "scn": "Le couple dit oui : ce sera le 12 septembre, au Domaine.",
      "ondes": [
        {
          "r": "lieu",
          "t": "Option posée → date confirmée, contrat déclenché",
          "puis": [
            {
              "r": "mairie",
              "t": "Créneau civil demandé pour le matin du 12"
            }
          ]
        },
        {
          "r": "invite",
          "t": "Le save-the-date part vers 148 boîtes aux lettres",
          "puis": [
            {
              "r": "navette",
              "t": "Distances calculées : 34 invités à plus de 200 km"
            }
          ]
        },
        {
          "r": "traiteur",
          "t": "Dégustation proposée — trois jeudis au choix"
        },
        {
          "r": "photo",
          "t": "Golden hour du 12/09 calculée : 19 h 42"
        },
        {
          "r": "coordo",
          "t": "Le rétroplanning se déplie sur quatorze mois"
        }
      ]
    },
    "B": {
      "label": "Budget",
      "scn": "L'enveloppe fleurs passe de 1 800 € à 1 200 €.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Trois arbitrages proposés, zéro drame"
        },
        {
          "r": "fleuriste",
          "t": "Volume repensé — plus de feuillage, moins de pivoines"
        },
        {
          "r": "lieu",
          "t": "Scénographie ajustée — la pierre porte le décor"
        },
        {
          "r": "invite",
          "t": "Les invités n'en sauront jamais rien",
          "lock": true,
          "vrai": "Enveloppe fleurs : 1 200 € — arbitrage interne, jamais affiché."
        }
      ]
    },
    "V": {
      "label": "Vision",
      "scn": "Le moodboard glisse du bohème au minéral.",
      "ondes": [
        {
          "r": "photo",
          "t": "Repérages relancés — pierre, lin, lumière franche"
        },
        {
          "r": "lieu",
          "t": "La grange devient chapelle de calcaire"
        },
        {
          "r": "fleuriste",
          "t": "Palette resserrée : blanc cassé, gris vert, une note bordeaux"
        },
        {
          "r": "traiteur",
          "t": "Dressage épuré, assiettes crème"
        },
        {
          "r": "dj",
          "t": "Palette sonore recalibrée — cordes, souffle, réverbération"
        }
      ]
    },
    "N": {
      "label": "Notes d'intention",
      "scn": "Deux pages de vœux déposées dans le coffre du Verbe.",
      "ondes": [
        {
          "r": "officiant",
          "t": "Le Verbe reçoit la matière brute — il n'en perdra rien",
          "puis": [
            {
              "r": "coordo",
              "t": "La cérémonie gagne 90 secondes de silence tenu"
            }
          ]
        },
        {
          "r": "coordo",
          "t": "Deux fois 2 min 10, calées dans la cérémonie"
        },
        {
          "r": "photo",
          "t": "Plans serrés réservés aux mots-clés"
        }
      ]
    }
  },
  "temoin": {
    "D": {
      "label": "Discours",
      "scn": "Répétition du discours : 3 min 40, deux rires, une larme.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Créneau calé entre le fromage et le dessert"
        },
        {
          "r": "dj",
          "t": "Micro ouvert, fond sonore en retrait"
        },
        {
          "r": "photo",
          "t": "Angle réservé sur la table d'honneur"
        },
        {
          "r": "couple",
          "t": "Onde masquée — la surprise reste entière",
          "lock": true,
          "vrai": "Discours de 3 min 40 : deux rires écrits, une larme assumée."
        }
      ]
    },
    "S": {
      "label": "Surprise",
      "scn": "Un flashmob se prépare sur « September ».",
      "ondes": [
        {
          "r": "dj",
          "t": "Piste secrète chargée, top départ au refrain",
          "puis": [
            {
              "r": "lieu",
              "t": "Limiteur relevé de 3 dB pendant 4 minutes"
            }
          ]
        },
        {
          "r": "invite",
          "t": "Douze complices répètent en silence"
        },
        {
          "r": "coordo",
          "t": "Créneau fantôme — invisible au planning des mariés"
        },
        {
          "r": "couple",
          "t": "Onde masquée — pare-feu causal actif",
          "lock": true,
          "vrai": "Flashmob sur « September » : douze complices, top au premier refrain."
        }
      ]
    },
    "F": {
      "label": "Fête · EVJF / EVG",
      "scn": "Le week-end surprise se vote : mer ou montagne ?",
      "ondes": [
        {
          "r": "invite",
          "t": "Sondage envoyé aux proches — réponses sous 48 h"
        },
        {
          "r": "coordo",
          "t": "Hors Jour J — consigné quand même"
        },
        {
          "r": "couple",
          "t": "Onde masquée — ils ne verront rien venir",
          "lock": true,
          "vrai": "Montagne : chalet pour 14, du 4 au 6 juillet, acompte versé."
        }
      ]
    },
    "C": {
      "label": "Cagnotte",
      "scn": "Le cadeau commun s'ouvre : un voyage, pas un grille-pain.",
      "ondes": [
        {
          "r": "invite",
          "t": "Participation libre, montants invisibles entre invités"
        },
        {
          "r": "coordo",
          "t": "Objectif suivi sans bruit"
        },
        {
          "r": "couple",
          "t": "Onde masquée jusqu'au retour de lune de miel",
          "lock": true,
          "vrai": "Cagnotte voyage : objectif 2 400 €, 61 % atteints, 37 participants."
        }
      ]
    }
  },
  "famille": {
    "H": {
      "label": "Hébergement",
      "scn": "Mamie, 92 ans, a besoin d'une chambre au calme, sans escalier.",
      "ondes": [
        {
          "r": "lieu",
          "t": "Chambre côté verger bloquée — rez-de-chaussée"
        },
        {
          "r": "coordo",
          "t": "Navette douce programmée à 22 h",
          "puis": [
            {
              "r": "navette",
              "t": "Un véhicule bas ajouté, deux places assises garanties"
            }
          ]
        },
        {
          "r": "invite",
          "t": "Covoiturage adapté proposé au cousin"
        },
        {
          "r": "couple",
          "t": "Une notification tendre — rien à gérer"
        }
      ]
    },
    "P": {
      "label": "Photo des générations",
      "scn": "La photo des quatre générations, avant que la lumière tombe.",
      "ondes": [
        {
          "r": "photo",
          "t": "Créneau 17 h 15 — lumière de face, dos au verger"
        },
        {
          "r": "coordo",
          "t": "Annonce micro écrite, douce mais ferme"
        },
        {
          "r": "dj",
          "t": "Pause musicale de quatre minutes"
        },
        {
          "r": "invite",
          "t": "L'onde rameute les cousins éloignés"
        }
      ]
    },
    "R": {
      "label": "Régimes",
      "scn": "L'oncle Bernard déclare son allergie aux arachides.",
      "ondes": [
        {
          "r": "traiteur",
          "t": "Menu croisé, cuisine verrouillée — zéro trace"
        },
        {
          "r": "coordo",
          "t": "Plan de table annoté discrètement"
        },
        {
          "r": "lieu",
          "t": "Consigne transmise à l'office"
        },
        {
          "r": "couple",
          "t": "Onde absorbée — aucune charge mentale transférée",
          "lock": true,
          "vrai": "Allergie arachide (oncle Bernard, table 4) : menu croisé, cuisine verrouillée."
        }
      ]
    },
    "O": {
      "label": "Objets",
      "scn": "Le voile de la grand-mère sort de sa boîte. 1954.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Remise prévue à l'habillage, 14 h 20"
        },
        {
          "r": "photo",
          "t": "Une macro réservée — dentelle et lumière"
        },
        {
          "r": "officiant",
          "t": "Une ligne offerte au Verbe, s'il veut la dire"
        },
        {
          "r": "couple",
          "t": "L'émotion est programmée sans être annoncée"
        }
      ]
    }
  },
  "invite": {
    "R": {
      "label": "Répondre",
      "scn": "« Nous venons à deux — le petit dort chez papi. »",
      "ondes": [
        {
          "r": "traiteur",
          "t": "134 couverts — quantités réalignées à la seconde",
          "puis": [
            {
              "r": "lieu",
              "t": "Deux chaises, deux couverts, un rab de nappe"
            }
          ]
        },
        {
          "r": "coordo",
          "t": "Le plan de table respire"
        },
        {
          "r": "couple",
          "t": "Plus deux au compteur du bonheur"
        },
        {
          "r": "navette",
          "t": "Deux sièges de retour retenus sur la 2ᵉ navette"
        }
      ]
    },
    "M": {
      "label": "Menu",
      "scn": "Un invité passe végétarien, à J-21.",
      "ondes": [
        {
          "r": "traiteur",
          "t": "Réaligné à la seconde — c'est le principe même"
        },
        {
          "r": "coordo",
          "t": "Voisins d'assiette vérifiés"
        },
        {
          "r": "couple",
          "t": "Onde absorbée — rien à faire, c'est voulu",
          "lock": true,
          "vrai": "Un végétarien de plus (table 7) : le traiteur a déjà réaligné, 0 € d'écart."
        }
      ]
    },
    "V": {
      "label": "Covoiturer",
      "scn": "Trois places libres depuis Lille, départ 13 h.",
      "ondes": [
        {
          "r": "invite",
          "t": "Deux passagers matchés sur le trajet"
        },
        {
          "r": "navette",
          "t": "Une navette gare allégée — un véhicule libéré"
        },
        {
          "r": "coordo",
          "t": "Arrivées groupées à 15 h 40"
        },
        {
          "r": "lieu",
          "t": "Une voiture de moins au verger"
        }
      ]
    },
    "O": {
      "label": "Offrir",
      "scn": "Un geste part vers la cagnotte lune de miel.",
      "ondes": [
        {
          "r": "temoin",
          "t": "Le cadeau commun se coordonne — zéro doublon"
        },
        {
          "r": "couple",
          "t": "Onde masquée jusqu'au grand jour",
          "lock": true,
          "vrai": "37 invités ont participé — le voyage est financé à 61 %."
        }
      ]
    }
  },
  "coordo": {
    "P": {
      "label": "Plan de table",
      "scn": "La table 7 accueille deux retardataires : elle passe à neuf.",
      "ondes": [
        {
          "r": "traiteur",
          "t": "Service resynchronisé, chaises comprises"
        },
        {
          "r": "lieu",
          "t": "Nappe rallongée, couverts ajoutés"
        },
        {
          "r": "fleuriste",
          "t": "Un centre de table de plus, hauteur basse"
        },
        {
          "r": "invite",
          "t": "Placements mis à jour, en silence"
        },
        {
          "r": "photo",
          "t": "Axe de la table d'honneur recalé"
        }
      ]
    },
    "J": {
      "label": "Jour J",
      "scn": "Orage passager : tout le Jour J glisse de vingt minutes.",
      "ondes": [
        {
          "r": "dj",
          "t": "Le set s'étire sans couture",
          "puis": [
            {
              "r": "lieu",
              "t": "Fin de sono maintenue à 1 h — l'élastique s'arrête là"
            }
          ]
        },
        {
          "r": "traiteur",
          "t": "Le chaud attend le sec"
        },
        {
          "r": "photo",
          "t": "Golden hour recalculée : 20 h 02"
        },
        {
          "r": "officiant",
          "t": "Le Verbe respire — personne ne courra"
        },
        {
          "r": "navette",
          "t": "Dernier départ repoussé à 1 h 35, chauffeurs prévenus"
        },
        {
          "r": "invite",
          "t": "Et personne ne le saura jamais"
        }
      ]
    },
    "N": {
      "label": "Notifier",
      "scn": "Trois réponses dorment encore — rappel doux envoyé.",
      "ondes": [
        {
          "r": "invite",
          "t": "Trois téléphones vibrent gentiment"
        },
        {
          "r": "traiteur",
          "t": "La fenêtre de commande reste tenue"
        },
        {
          "r": "couple",
          "t": "Le compteur bougera avant dimanche"
        }
      ]
    }
  },
  "dj": {
    "D": {
      "label": "Dédicace",
      "scn": "Une invitée glisse « la chanson des grands-parents, 1962 ».",
      "ondes": [
        {
          "r": "coordo",
          "t": "Créneau trouvé juste avant le dessert"
        },
        {
          "r": "famille",
          "t": "Les grands-parents placés bord de piste"
        },
        {
          "r": "photo",
          "t": "Prévenu — larmes probables vers 22 h 40"
        },
        {
          "r": "couple",
          "t": "Notifié en une ligne, pas plus"
        }
      ]
    },
    "B": {
      "label": "BPM",
      "scn": "La piste chauffe — le BPM grimpe, le monde suit.",
      "ondes": [
        {
          "r": "traiteur",
          "t": "Le trou normand patientera dix minutes"
        },
        {
          "r": "coordo",
          "t": "Planning élastique : douze minutes absorbées"
        },
        {
          "r": "lieu",
          "t": "Limiteur respecté — les voisins dorment"
        }
      ]
    },
    "O": {
      "label": "Ouverture de bal",
      "scn": "La valse secrète se répète mardi, 19 h.",
      "ondes": [
        {
          "r": "couple",
          "t": "Créneau discret posé dans deux agendas"
        },
        {
          "r": "photo",
          "t": "Position clé réservée, dos à la baie"
        },
        {
          "r": "coordo",
          "t": "Annonce écrite, lumière commandée"
        },
        {
          "r": "temoin",
          "t": "Autorisé à pleurer en premier"
        }
      ]
    },
    "P": {
      "label": "Playlist",
      "scn": "La liste « Ne jamais jouer » s'allonge d'un titre.",
      "ondes": [
        {
          "none": true,
          "t": "Aucune onde. Certains silences sont sacrés."
        }
      ]
    }
  },
  "photo": {
    "G": {
      "label": "Golden hour",
      "scn": "19 h 42 — sept minutes de miel sur le verger.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Le fromage patiente — dix minutes volées"
        },
        {
          "r": "couple",
          "t": "Exfiltrés en douceur, deux minutes avant"
        },
        {
          "r": "dj",
          "t": "L'ambiance tient la salle sans les mariés"
        },
        {
          "r": "invite",
          "t": "Ils n'y verront que du feu",
          "lock": true,
          "vrai": "Les mariés s'absentent 9 minutes pendant le plateau de fromages."
        }
      ]
    },
    "R": {
      "label": "Repérages",
      "scn": "Repérage sous la pluie — on ne sait jamais.",
      "ondes": [
        {
          "r": "lieu",
          "t": "Accès grange ouvert, clés confiées"
        },
        {
          "r": "coordo",
          "t": "Le plan B s'enrichit de trois angles"
        },
        {
          "r": "couple",
          "t": "Le moodboard se nourrit de douze images"
        }
      ]
    },
    "P": {
      "label": "Planche contact",
      "scn": "Quarante images du jour, choisies à quatre yeux.",
      "ondes": [
        {
          "r": "couple",
          "t": "L'album vivant s'ouvre en premier"
        },
        {
          "r": "famille",
          "t": "Tirages grand format proposés"
        },
        {
          "r": "invite",
          "t": "Galerie partagée — visages floutés sur demande"
        }
      ]
    }
  },
  "traiteur": {
    "Q": {
      "label": "Quantités",
      "scn": "Une réponse tombe à 23 h 12 : 132 devient 134.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Plan de table synchronisé"
        },
        {
          "r": "lieu",
          "t": "Deux chaises, deux couverts, un rab de nappe"
        },
        {
          "r": "couple",
          "t": "Budget : plus deux couverts — validé d'un geste"
        }
      ]
    },
    "D": {
      "label": "Dégustation",
      "scn": "Trois accords à trancher : jeudi, 18 h 30.",
      "ondes": [
        {
          "r": "couple",
          "t": "Deux chaises réservées, appétit requis"
        },
        {
          "r": "coordo",
          "t": "Les verdicts seront consignés au menu maître"
        }
      ]
    },
    "M": {
      "label": "Menu",
      "scn": "Arrivage : le bar devient lieu jaune.",
      "ondes": [
        {
          "r": "invite",
          "t": "Allergies recroisées automatiquement"
        },
        {
          "r": "couple",
          "t": "La carte se met à jour toute seule"
        },
        {
          "r": "lieu",
          "t": "Menus réimprimés — le Lieu, lui, ne change pas"
        }
      ]
    }
  },
  "lieu": {
    "P": {
      "label": "Plan B",
      "scn": "Orage annoncé à 17 h : bascule grange enclenchée.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Timeline pivotée en douceur",
          "puis": [
            {
              "r": "navette",
              "t": "Dépose avancée sous l'auvent, deux boucles de plus"
            }
          ]
        },
        {
          "r": "photo",
          "t": "Lumière recalculée sous les poutres"
        },
        {
          "r": "fleuriste",
          "t": "L'arche se remonte sous la charpente — 40 minutes"
        },
        {
          "r": "dj",
          "t": "Sono déplacée, câbles compris"
        },
        {
          "r": "invite",
          "t": "Parapluies prêts au vestiaire — au cas où"
        },
        {
          "r": "officiant",
          "t": "Le Verbe portera sous la charpente"
        }
      ]
    },
    "H": {
      "label": "Horaires",
      "scn": "Sono jusqu'à 1 h, extinction douce à 2 h.",
      "ondes": [
        {
          "r": "dj",
          "t": "Set calibré à la minute près"
        },
        {
          "r": "coordo",
          "t": "Last dance posée à 0 h 47"
        },
        {
          "r": "navette",
          "t": "Dernier départ calé sur la dernière chanson"
        },
        {
          "r": "invite",
          "t": "Retours annoncés dès l'apéritif"
        }
      ]
    },
    "V": {
      "label": "Visite technique",
      "scn": "Visite jeudi — mètre laser et carnet.",
      "ondes": [
        {
          "r": "couple",
          "t": "Invités d'honneur de leur propre lieu"
        },
        {
          "r": "traiteur",
          "t": "Cuisine mesurée, passes chronométrées"
        },
        {
          "r": "photo",
          "t": "Prises testées — les deux sortes"
        }
      ]
    }
  },
  "officiant": {
    "V": {
      "label": "Vœux",
      "scn": "Les vœux sont prêts : 2 min 10 chacun, au mot près.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Cérémonie verrouillée à 24 minutes"
        },
        {
          "r": "photo",
          "t": "Plans serrés déclenchés aux mots-clés"
        },
        {
          "r": "dj",
          "t": "Fondu d'entrée réglé au premier pas"
        },
        {
          "r": "temoin",
          "t": "Mouchoirs distribués, rang un"
        }
      ]
    },
    "R": {
      "label": "Rituel",
      "scn": "Le rituel du sable entre dans la cérémonie.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Six minutes absorbées sans plier"
        },
        {
          "r": "lieu",
          "t": "Une table dédiée, face à la lumière"
        },
        {
          "r": "enfants",
          "t": "Les enfants verseront le premier sable — deux répétitions"
        },
        {
          "r": "famille",
          "t": "Les aînés versent en dernier, assis"
        }
      ]
    },
    "S": {
      "label": "Silence",
      "scn": "Une minute de silence pour celles et ceux qui manquent.",
      "ondes": [
        {
          "r": "dj",
          "t": "Fondu au noir sonore, main levée"
        },
        {
          "r": "coordo",
          "t": "Sanctuarisée — rien ne bougera"
        },
        {
          "r": "invite",
          "t": "Prévenus, avec des mots choisis"
        },
        {
          "r": "photo",
          "t": "Aucun déclenchement — l'onde s'arrête ici",
          "lock": true,
          "vrai": "Consigne écrite : zéro obturateur pendant les 60 secondes."
        }
      ]
    }
  },
  "fleuriste": {
    "F": {
      "label": "Fleurs de saison",
      "scn": "Les pivoines sont hors saison : le dahlia prend la table.",
      "ondes": [
        {
          "r": "couple",
          "t": "Moodboard mis à jour — minéral, dahlia, bordeaux profond"
        },
        {
          "r": "lieu",
          "t": "Vasques basses : on voit son voisin d'en face"
        },
        {
          "r": "photo",
          "t": "Palette prévenue — le bordeaux tient en fond de champ"
        },
        {
          "r": "traiteur",
          "t": "Centres de table abaissés — le service passe"
        }
      ]
    },
    "B": {
      "label": "Bouquet",
      "scn": "Le bouquet de la mariée se double d'un bouquet de lancer.",
      "ondes": [
        {
          "r": "photo",
          "t": "Deux plans réservés : la remise, puis le lancer"
        },
        {
          "r": "temoin",
          "t": "Le lancer est chorégraphié — dos à la lumière"
        },
        {
          "r": "dj",
          "t": "Titre de trente secondes tenu prêt"
        },
        {
          "r": "invite",
          "t": "Annonce faite sans micro, de bouche à oreille"
        }
      ]
    },
    "D": {
      "label": "Démontage",
      "scn": "À 2 h, les compositions repartent — aucune fleur à la benne.",
      "ondes": [
        {
          "r": "lieu",
          "t": "Créneau de remise en état confirmé : 2 h – 3 h 30"
        },
        {
          "r": "navette",
          "t": "Un aller ajouté vers la maison de retraite du bourg",
          "puis": [
            {
              "r": "coordo",
              "t": "Bénévole désigné, clés remises la veille"
            }
          ]
        },
        {
          "r": "invite",
          "t": "Chacun peut repartir avec une tige"
        },
        {
          "r": "couple",
          "t": "Rien à porter, rien à jeter, rien à décider"
        }
      ]
    }
  },
  "mairie": {
    "D": {
      "label": "Dossier",
      "scn": "Le dossier est déposé : publication des bans le 12 août.",
      "ondes": [
        {
          "r": "couple",
          "t": "Plus rien à signer avant le jour même"
        },
        {
          "r": "coordo",
          "t": "Date verrouillée — le civil ne bouge plus"
        },
        {
          "r": "officiant",
          "t": "Le civil précède le Verbe : l'ordre est écrit"
        },
        {
          "r": "famille",
          "t": "Les témoins fournissent leur pièce d'identité"
        }
      ]
    },
    "H": {
      "label": "Horaire civil",
      "scn": "La cérémonie civile passe à 11 h 15 — la salle est prise à 12 h.",
      "ondes": [
        {
          "r": "coordo",
          "t": "Toute la matinée recalculée en une passe",
          "puis": [
            {
              "r": "enfants",
              "t": "Habillage avancé à 9 h 40, goûter prévu avant"
            }
          ]
        },
        {
          "r": "navette",
          "t": "Deux départs avancés de vingt minutes"
        },
        {
          "r": "photo",
          "t": "Lumière dure à midi — repli sous le porche"
        },
        {
          "r": "traiteur",
          "t": "Cocktail décalé, glace commandée en plus"
        },
        {
          "r": "invite",
          "t": "Un seul message, une seule heure à retenir"
        }
      ]
    },
    "C": {
      "label": "Témoins civils",
      "scn": "Les quatre témoins sont déclarés — noms, pièces, signatures.",
      "ondes": [
        {
          "r": "temoin",
          "t": "Convocation à 10 h 50, pièce en poche"
        },
        {
          "r": "famille",
          "t": "Deux places assises réservées au premier rang"
        },
        {
          "r": "officiant",
          "t": "Les mêmes quatre noms reviendront à la cérémonie laïque"
        },
        {
          "r": "coordo",
          "t": "Liste figée — plus d'ajout de dernière minute"
        }
      ]
    }
  },
  "navette": {
    "N": {
      "label": "Navettes",
      "scn": "Deux navettes de 19 places : 15 h 40 gare, 1 h 15 retour hôtel.",
      "ondes": [
        {
          "r": "invite",
          "t": "Horaires poussés à chacun, selon son point de départ"
        },
        {
          "r": "lieu",
          "t": "Parking allégé de 22 voitures"
        },
        {
          "r": "dj",
          "t": "Last dance calée avant le dernier départ"
        },
        {
          "r": "coordo",
          "t": "Arrivées groupées — accueil tenu par deux personnes"
        }
      ]
    },
    "P": {
      "label": "Parking",
      "scn": "Le verger passe à 40 places : le covoiturage devient la règle.",
      "ondes": [
        {
          "r": "invite",
          "t": "Trajets appariés automatiquement, par village"
        },
        {
          "r": "lieu",
          "t": "Herbe préservée, deux allées balisées"
        },
        {
          "r": "coordo",
          "t": "Un régisseur parking de 15 h à 17 h"
        }
      ]
    },
    "R": {
      "label": "Retour",
      "scn": "Un invité ne conduira pas : un retour s'ajoute à 0 h 30.",
      "ondes": [
        {
          "r": "invite",
          "t": "Siège réservé, sans nom sur la liste"
        },
        {
          "r": "coordo",
          "t": "Chauffeur prévenu, boucle de douze minutes"
        },
        {
          "r": "couple",
          "t": "Onde masquée — la dignité n'a pas besoin de public",
          "lock": true,
          "vrai": "Un retour supplémentaire à 0 h 30 : la place reste anonyme, même au registre."
        }
      ]
    }
  },
  "enfants": {
    "P": {
      "label": "Pétales",
      "scn": "Six enfants, deux paniers de pétales, un couloir de dix mètres.",
      "ondes": [
        {
          "r": "fleuriste",
          "t": "Deux kilos de pétales séchés, non glissants"
        },
        {
          "r": "photo",
          "t": "Position basse réservée à l'entrée"
        },
        {
          "r": "officiant",
          "t": "Entrée rallongée de quarante secondes"
        },
        {
          "r": "coordo",
          "t": "Un adulte par panier — noms attribués"
        }
      ]
    },
    "G": {
      "label": "Garderie",
      "scn": "Une nounou de 18 h à 1 h, dans la salle du bas.",
      "ondes": [
        {
          "r": "famille",
          "t": "Quatre familles peuvent enfin danser"
        },
        {
          "r": "lieu",
          "t": "Salle du bas équipée, veilleuse et matelas"
        },
        {
          "r": "traiteur",
          "t": "Neuf menus enfants servis à 19 h, avant les adultes"
        },
        {
          "r": "invite",
          "t": "Inscription en deux clics, gratuite"
        }
      ]
    },
    "R": {
      "label": "Répétition",
      "scn": "Répétition de l'entrée samedi 17 h — quatre minutes, pas plus.",
      "ondes": [
        {
          "r": "officiant",
          "t": "Le tempo d'entrée se cale sur les plus petits"
        },
        {
          "r": "coordo",
          "t": "Créneau posé, parents prévenus la veille"
        },
        {
          "r": "famille",
          "t": "Un goûter prévu juste après — négociation gagnée"
        }
      ]
    }
  }
}
