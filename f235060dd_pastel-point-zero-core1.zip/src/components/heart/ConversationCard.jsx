import React, { useEffect, useRef, useState } from "react";
import { Loader2, Volume2, Send } from "lucide-react";

// La conversation avec PLUME, posée au centre comme une feuille sur le bureau.
// Le fil se lit comme des notes manuscrites ; en bas, un champ de saisie texte.
export default function ConversationCard({ history, thinking, onSend, onReplay }) {
  const endRef = useRef(null);
  const [input, setInput] = useState("");
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history, thinking]);

  const submit = (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || thinking) return;
    onSend(text);
    setInput("");
  };

  return (
    <div className="flex w-full max-w-md flex-col overflow-hidden rounded-[28px] bg-white/85 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.25)] ring-1 ring-black/5 backdrop-blur-xl">
      {/* Entête intime */}
      <div className="flex items-center gap-2 border-b border-neutral-100 px-6 py-4">
        <span className="text-lg">✦</span>
        <div>
          <p className="text-[15px] font-semibold text-neutral-800">PLUME</p>
          <p className="text-[11px] text-neutral-400">ta wedding planner, rien qu'à toi</p>
        </div>
      </div>

      {/* Le fil de conversation */}
      <div className="max-h-[42vh] min-h-[140px] space-y-3 overflow-y-auto px-5 py-5">
        {history.map((m, i) => (
          <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-[14px] leading-relaxed ${
                m.role === "user"
                  ? "bg-neutral-900 text-white"
                  : "bg-rose-50/80 text-neutral-700 ring-1 ring-rose-100"
              }`}
            >
              {m.role === "plume" && onReplay && (
                <button
                  onClick={() => onReplay(m.content)}
                  aria-label="Réécouter"
                  className="float-right ml-2 mt-0.5 text-neutral-300 transition-colors hover:text-neutral-600"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                </button>
              )}
              {m.content}
            </div>
          </div>
        ))}
        {thinking && (
          <div className="flex justify-start">
            <span className="flex items-center gap-2 rounded-2xl bg-rose-50/80 px-4 py-2.5 text-[13px] text-neutral-400 ring-1 ring-rose-100">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> PLUME réfléchit…
            </span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Champ de saisie texte */}
      <form onSubmit={submit} className="flex items-center gap-2 border-t border-neutral-100 bg-white/60 p-3 pl-5">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Écris à PLUME…"
          className="min-w-0 flex-1 bg-transparent text-[14px] text-neutral-800 placeholder:text-neutral-400 outline-none"
        />
        <button
          type="submit"
          disabled={thinking || !input.trim()}
          aria-label="Envoyer"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-neutral-900 text-white transition-all hover:bg-neutral-700 disabled:bg-neutral-200 disabled:text-neutral-400"
        >
          {thinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}