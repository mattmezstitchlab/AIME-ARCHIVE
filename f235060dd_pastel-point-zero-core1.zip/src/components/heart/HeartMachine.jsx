import React from "react";

// La petite machine-cœur conversationnelle, sur fond blanc.
// États :
//  - repos     : bat doucement, invite à être pressée
//  - listening : on presse pour parler → le cœur s'illumine et vibre avec TA voix
//  - thinking  : PLUME réfléchit → rotation lente
//  - speaking  : PLUME parle → le cœur vibre avec SA voix
//  - notif     : une lumière clignote quand PLUME a quelque chose à dire
export default function HeartMachine({ state = "idle", level = 0, notif = false, onPress, onRelease }) {
  const listening = state === "listening";
  const speaking = state === "speaking";
  const thinking = state === "thinking";
  const active = listening || speaking;

  // L'amplitude de la voix (0→1) fait respirer le cœur.
  const scale = 1 + (active ? level * 0.35 : 0);
  const glow = active ? 0.35 + level * 0.55 : listening ? 0.4 : 0.2;

  return (
    <div className="relative flex items-center justify-center" style={{ width: 260, height: 260 }}>
      {/* Halo de notification qui clignote */}
      {notif && !active && (
        <span className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
      )}

      {/* Anneaux lumineux pilotés par la voix */}
      <div
        className="absolute rounded-full bg-primary/30 blur-2xl transition-transform duration-100"
        style={{ width: 220, height: 220, opacity: glow, transform: `scale(${scale})` }}
      />
      <div
        className="absolute rounded-full ring-1 ring-primary/20"
        style={{ width: 200, height: 200, transform: `scale(${scale})` }}
      />

      {/* Le bouton-cœur : on presse pour parler, on relâche pour envoyer */}
      <button
        onMouseDown={onPress}
        onMouseUp={onRelease}
        onMouseLeave={(e) => listening && onRelease?.(e)}
        onTouchStart={(e) => { e.preventDefault(); onPress?.(e); }}
        onTouchEnd={(e) => { e.preventDefault(); onRelease?.(e); }}
        aria-label="Presser pour parler à PLUME"
        className={`relative z-10 flex items-center justify-center rounded-full text-white shadow-2xl transition-all duration-150 ${
          thinking ? "animate-spin-slow" : ""
        }`}
        style={{
          width: 132,
          height: 132,
          transform: `scale(${listening ? 0.94 : scale})`,
          background: "radial-gradient(circle at 35% 30%, hsl(var(--primary)), hsl(211 90% 38%))",
          boxShadow: `0 20px 60px -12px hsl(var(--primary) / ${0.5 + level * 0.4})`,
        }}
      >
        <HeartGlyph pulsing={!active && !thinking} beat={active ? level : 0} />
        {/* Point de notif sur le cœur */}
        {notif && (
          <span className="absolute right-6 top-6 h-3 w-3 rounded-full bg-white shadow animate-pulse" />
        )}
      </button>
    </div>
  );
}

function HeartGlyph({ pulsing, beat }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={pulsing ? "animate-pulse" : ""}
      style={{ width: 56, height: 56, transform: `scale(${1 + beat * 0.25})`, transition: "transform 80ms" }}
      fill="currentColor"
    >
      <path d="M12 21s-6.7-4.3-9.3-8.2C1 10 1.8 6.5 4.8 5.4c2-.7 3.9.2 4.9 1.7l.3.4.3-.4c1-1.5 2.9-2.4 4.9-1.7 3 1.1 3.8 4.6 2.1 7.4C18.7 16.7 12 21 12 21z" />
    </svg>
  );
}