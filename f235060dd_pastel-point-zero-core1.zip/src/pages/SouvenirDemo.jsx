import React, { useEffect, useRef, useState } from "react";
import { Loader2, LayoutGrid } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useProfil from "@/hooks/useProfil";
import ConversationCard from "@/components/heart/ConversationCard";
import CockpitBackstage from "@/components/grille/cockpit/CockpitBackstage";

// L'expérience unique : la mariée se confie à PLUME. Un bureau serein en fond,
// la conversation posée au centre comme une feuille. On presse le cœur pour parler,
// PLUME répond à voix haute et prend note dans l'ombre.
const FOND_BUREAU = "https://media.base44.com/images/public/6a3d9d5c0a5919901b4c0290/6bff7cf66_generated_image.png";

export default function SouvenirDemo() {
  const { profil, loading: loadingProfil } = useProfil();

  const [history, setHistory] = useState([]);
  const [thinking, setThinking] = useState(false);
  const [cockpit, setCockpit] = useState(false);
  const accueilFait = useRef(false);

  const estMariee = profil?.role === "future_mariee" || profil?.role === "futur_marie";

  // PLUME ouvre le rendez-vous d'elle-même.
  useEffect(() => {
    if (!estMariee || accueilFait.current) return;
    accueilFait.current = true;
    base44.functions
      .invoke("plumeMessage", {})
      .then((res) => {
        const mot = res.data?.message || "Alors, on se marie ? Raconte-moi tout — je t'écoute.";
        setHistory([{ role: "plume", content: mot }]);
      })
      .catch(() => {});
  }, [estMariee]);

  // On envoie un message écrit : PLUME répond et prend note.
  const handleSend = async (texte) => {
    const next = [...history, { role: "user", content: texte }];
    setHistory(next);
    setThinking(true);
    try {
      const res = await base44.functions.invoke("plumeRdv", { message: texte, history: next });
      const reponse = res.data?.reponse || "…";
      setHistory([...next, { role: "plume", content: reponse }]);
    } catch (_e) {
      setHistory([...next, { role: "plume", content: "Je me suis perdue un instant. Redis-moi ?" }]);
    } finally {
      setThinking(false);
    }
  };

  if (loadingProfil) {
    return (
      <main className="flex h-screen w-full items-center justify-center bg-[#efece7]">
        <Loader2 className="h-6 w-6 animate-spin text-neutral-400" />
      </main>
    );
  }

  return (
    <main
      className="relative flex h-screen w-full items-center justify-center bg-[#efece7] bg-cover bg-center px-4 text-neutral-900"
      style={{ backgroundImage: `url(${FOND_BUREAU})` }}
    >
      {/* Voile léger pour poser la conversation sur le bureau */}
      <div className="absolute inset-0 bg-white/25" />

      {/* Accès discret à la mémoire de PLUME */}
      <button
        onClick={() => setCockpit(true)}
        aria-label="Ouvrir la mémoire de PLUME"
        className="absolute right-5 top-5 z-20 flex h-10 w-10 items-center justify-center rounded-full bg-white/70 text-neutral-500 ring-1 ring-black/5 backdrop-blur transition-colors hover:bg-white hover:text-neutral-800"
      >
        <LayoutGrid className="h-4.5 w-4.5" />
      </button>

      {/* Réservé à la mariée */}
      {!estMariee ? (
        <div className="relative z-10 max-w-xs rounded-3xl bg-white/85 px-8 py-10 text-center shadow-xl ring-1 ring-black/5 backdrop-blur-xl">
          <span className="text-2xl">✦</span>
          <p className="mt-3 text-sm text-neutral-500">
            Ce premier rendez-vous est réservé à la mariée. Reviens avec son profil pour ouvrir le cœur à cœur.
          </p>
        </div>
      ) : (
        <div className="relative z-10">
          <ConversationCard
            history={history}
            thinking={thinking}
            onSend={handleSend}
            onReplay={null}
          />
        </div>
      )}

      <CockpitBackstage open={cockpit} onClose={() => setCockpit(false)} />
    </main>
  );
}