import { useCallback, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";

// Push-to-talk : on presse pour parler (enregistrement micro), on relâche → transcription.
// Expose `level` (0→1) : l'amplitude de TA voix pendant que tu presses, pour animer le cœur.
export default function usePlumeListen() {
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [level, setLevel] = useState(0);
  const mediaRef = useRef(null);
  const chunksRef = useRef([]);
  const streamRef = useRef(null);
  const ctxRef = useRef(null);
  const rafRef = useRef(null);

  const cleanup = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    setLevel(0);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  const start = useCallback(async () => {
    if (recording) return;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    streamRef.current = stream;
    chunksRef.current = [];
    const rec = new MediaRecorder(stream);
    mediaRef.current = rec;
    rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
    rec.start();
    setRecording(true);

    // Visualisation de l'amplitude de la voix pendant qu'on parle.
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = ctxRef.current || new Ctx();
      ctxRef.current = ctx;
      if (ctx.state === "suspended") await ctx.resume();
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) sum += data[i];
        setLevel(Math.min(1, (sum / data.length / 255) * 2.4));
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch (_e) { /* enregistre quand même sans visualiseur */ }
  }, [recording]);

  // Relâche : arrête l'enregistrement, transcrit, renvoie le texte.
  const stop = useCallback(async () => {
    const rec = mediaRef.current;
    if (!rec) return "";
    setRecording(false);
    cleanup();
    const blob = await new Promise((resolve) => {
      rec.onstop = () => resolve(new Blob(chunksRef.current, { type: "audio/webm" }));
      rec.stop();
    });
    if (!blob.size) return "";
    setTranscribing(true);
    try {
      const file = new File([blob], "voix.webm", { type: "audio/webm" });
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const text = await base44.integrations.Core.TranscribeAudio({ audio_url: file_url });
      return typeof text === "string" ? text.trim() : (text?.transcript || "").trim();
    } finally {
      setTranscribing(false);
    }
  }, [cleanup]);

  return { start, stop, recording, transcribing, level };
}