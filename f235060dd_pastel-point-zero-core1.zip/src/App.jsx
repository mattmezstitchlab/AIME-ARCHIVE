import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import Home from './pages/Home';
import GrilleGlobale from './pages/GrilleGlobale';
import DimensionView from './pages/DimensionView';
import NodeDetail from './pages/NodeDetail';
import ProjectionMariage from './pages/ProjectionMariage';
import SouvenirDemo from './pages/SouvenirDemo';
import Constellation from './pages/Constellation';
import Rencontres from './pages/Rencontres';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<SouvenirDemo />} />
      <Route path="/accueil" element={<Home />} />
      <Route path="/grille" element={<GrilleGlobale />} />
      <Route path="/dimension/:key" element={<DimensionView />} />
      <Route path="/noeud/:id" element={<NodeDetail />} />
      <Route path="/projection/mariage" element={<ProjectionMariage />} />
      <Route path="/souvenir" element={<SouvenirDemo />} />
      <Route path="/constellation" element={<Constellation />} />
      <Route path="/rencontres" element={<Rencontres />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App