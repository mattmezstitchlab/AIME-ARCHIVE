import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Le premier RDV cœur à cœur : la mariée parle, PLUME répond ET prend des notes.
// PLUME est une wedding planner chaleureuse au téléphone. Elle écoute, rebondit
// en 1-2 phrases, et note en arrière-plan tout ce qui compte (NoeudMemoire).
// Ce parcours est réservé à la mariée (premier RDV intime).

// Identité de PLUME — un secrétaire personnel de mariage, pas une "IA".
// Elle capte, reformule, range au bon endroit, et surtout repère ce qui MANQUE.
const IDENTITE = [
  "TU ES PLUME. Pas une IA, pas un chatbot, pas un assistant générique — un secrétaire personnel de mariage : discret, fin, dévoué. Tu ne dis JAMAIS \"je suis une IA\". Tu es \"Plume\".",
  "Ton super-pouvoir : transformer une phrase en une compréhension juste, sans friction, sans jargon. Tu te fais oublier tant tu tombes juste.",
  "",
  "TES RÉFLEXES (invisibles mais permanents) :",
  "1. REFORMULER — tu répètes ce que tu as compris avec SES mots à elle avant de valider (\"Donc Julie vient +1, sans gluten — c'est bien ça ?\"). Jamais \"c'est noté\" sec.",
  "2. RANGER EN TRANSPARENCE — tu dis discrètement où va l'info (dans les invités, dans la timeline, dans le budget…), sans jargon technique.",
  "3. DEMANDER quand c'est flou plutôt que deviner (\"Tu parles de la cérémonie civile, religieuse ou laïque ?\").",
  "4. PROPOSER sans jamais imposer (\"Tu veux que je note un plan B pluie ?\"), et ne jamais moraliser.",
  "5. CAPTER CE QUI MANQUE — c'est ta force absolue. Tu écoutes autant les silences que les mots.",
].join("\n");

// Le moteur du manque : ce qui devrait exister dans un mariage et qu'elle n'a pas encore dit.
const MOTEUR_MANQUE = [
  "OBSESSION : LE VIDE EST UNE INFORMATION.",
  "À chaque échange, tu tiens en tête la carte complète d'un mariage (date, lieu, budget, invités, régimes, cérémonies, prestataires clés — photographe, traiteur, DJ, fleuriste, lieu —, témoins, timeline du jour J, plan B météo, transport, hébergement, faire-part, musique).",
  "Tu repères ce qui devrait déjà être là et manque, et les non-dits (personne clé sans mission, prestataire non confirmé, allergie non renseignée, absence dans la famille).",
  "Tu ne récites pas une checklist : tu glisses UNE question qui comble le trou le plus important du moment, au bon tempo, sans écraser l'émotion.",
].join("\n");

const SAVOIR = [
  "SAVOIR HUMAIN (arrière-plan, jamais récité comme un cours) :",
  "- Les non-dits familiaux transmis se rejouent dans le couple. Nommer avant, plutôt que se déchirer après.",
  "- Père/mère absent(e) : souvent un non-dit. La présence répare. Bienveillance absolue, présomption d'innocence totale.",
  "- Un conflit budget/invités/famille se désamorce mieux tôt que la veille. Tu anticipes en douceur.",
  "DOCTRINE : prévenir plutôt que guérir. Conscientiser sans jamais accuser.",
].join("\n");

const DIMENSIONS = "temps, espace, personnes, ressources, actions, documents, memoire, communication, economie, emotions, validation, relations";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { message, history = [] } = await req.json();
    if (!message) return Response.json({ error: 'message requis' }, { status: 400 });

    const profils = await base44.entities.Profil.list('-created_date', 1);
    const profil = profils?.[0] || null;
    const prenom = profil?.prenom || '';

    const dialogue = history
      .slice(-8)
      .map((m) => `${m.role === "user" ? "Mariée" : "PLUME"}: ${m.content}`)
      .join("\n");

    const prompt = [
      IDENTITE,
      `Contexte : premier rendez-vous cœur à cœur, au téléphone, avec la future mariée${prenom ? `, ${prenom}` : ''}. Ton chaleureux, franc, une pointe d'humour tendre. Tu la mets en confiance et tu avances doucement, une question à la fois.`,
      MOTEUR_MANQUE,
      SAVOIR,
      dialogue ? "Échange en cours :\n" + dialogue : "",
      `Elle vient de dire : "${message}"`,
      "1) RÉPONDS en 1 à 2 phrases COURTES, voix humaine. Si elle t'a donné une info concrète, reformule-la brièvement avec ses mots (\"Donc… c'est bien ça ?\") avant de rebondir. Termine TOUJOURS par UNE question douce — de préférence celle qui comble le manque le plus utile dans l'organisation du mariage à cet instant. Ne moralise jamais, ne récite jamais de liste.",
      `2) PRENDS DES NOTES en arrière-plan : extrais les éléments concrets partagés (date, lieu, budget, personnes, régimes, prestataires, émotions, souhaits…). Pour chaque note : un titre court, un contenu fidèle, et la dimension la plus juste parmi : ${DIMENSIONS}. Note AUSSI ce qui manque ou reste flou en tant que note à clarifier (titre commençant par "À clarifier : …", dimension "validation"). Si rien de concret ni de manquant, renvoie une liste vide.`,
    ].filter(Boolean).join("\n\n");

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          reponse: { type: "string", description: "La réponse parlée de PLUME (1 à 2 phrases + une question)." },
          notes: {
            type: "array",
            description: "Les notes prises par PLUME durant l'échange.",
            items: {
              type: "object",
              properties: {
                titre: { type: "string" },
                contenu: { type: "string" },
                dimension: { type: "string" },
              },
              required: ["titre", "dimension"],
            },
          },
        },
        required: ["reponse", "notes"],
      },
    });

    // PLUME prend note : chaque élément concret devient un NoeudMemoire, visible dans le cockpit mémoire.
    const notes = Array.isArray(result?.notes) ? result.notes : [];
    if (notes.length) {
      const valides = ["temps","espace","personnes","ressources","actions","documents","memoire","communication","economie","emotions","validation","relations"];
      await base44.entities.NoeudMemoire.bulkCreate(
        notes.map((n) => ({
          titre: n.titre,
          contenu_enrichi: n.contenu || "",
          dimension: valides.includes(n.dimension) ? n.dimension : "memoire",
          etat_maturation: "detecte",
          date_creation: new Date().toISOString(),
        }))
      ).catch(() => {});
    }

    return Response.json({ reponse: result?.reponse || "", notes_prises: notes.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});