import React from 'react';
import { Moon, Sun, UserRound } from 'lucide-react';

export default function AimeHeader({ dark, onTheme, profile, onProfile }) {
  return <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-violet-200/50 bg-[#f8f6f0]/90 px-4 backdrop-blur-xl dark:border-white/10 dark:bg-[#0d1117]/90 sm:px-8">
    <div><p className="font-heading text-lg font-semibold tracking-tight">AIME <span className="text-violet-600 dark:text-violet-300">BANKOSYSTÈME</span></p><p className="text-[11px] text-slate-600 dark:text-slate-400">La banque causale des possibles</p></div>
    <div className="flex gap-2">
      <button aria-label={dark ? 'Activer le mode jour' : 'Activer le mode nuit'} onClick={onTheme} className="grid h-11 w-11 cursor-pointer place-items-center rounded-full bg-white/80 text-slate-700 shadow-sm transition-colors duration-200 hover:bg-violet-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-600 dark:bg-white/10 dark:text-white dark:hover:bg-white/15">{dark ? <Sun size={19}/> : <Moon size={19}/>}</button>
      <button onClick={onProfile} className="flex h-11 cursor-pointer items-center gap-2 rounded-full bg-violet-600 px-3 text-sm font-medium text-white transition-colors duration-200 hover:bg-violet-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-600"><UserRound size={18}/><span className="hidden sm:inline">{profile?.display_name || 'Carte +ME'}</span></button>
    </div>
  </header>;
}