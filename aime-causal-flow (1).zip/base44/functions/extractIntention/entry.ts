import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

Deno.serve(async (req) => {
  try {
    const respond=(body,init={})=>Response.json(body,{...init,headers:{...init.headers,'Cache-Control':'no-store, private','Pragma':'no-cache'}});
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return respond({ error: 'Non autorisé' }, { status: 401 });
    const { text, entryType = 'project' } = await req.json();
    if (!text || typeof text !== 'string' || text.trim().length < 8) return respond({ error: 'Décrivez votre intention en quelques mots.' }, { status: 400 });
    const schema = { type: 'object', properties: {
      intention: { type: 'string' }, context: { type: 'string' }, timeframe: { type: 'string' }, location: { type: 'string' },
      presentResources: { type: 'array', items: { type: 'string' } }, missingResources: { type: 'array', items: { type: 'string' } },
      constraints: { type: 'array', items: { type: 'string' } }, peopleConcerned: { type: 'array', items: { type: 'string' } },
      risks: { type: 'array', items: { type: 'string' } }, openQuestions: { type: 'array', items: { type: 'string' } },
      uncertainties: { type: 'array', items: { type: 'string' } }
    }, required: ['intention','context','timeframe','location','presentResources','missingResources','constraints','peopleConcerned','risks','openQuestions','uncertainties'] };
    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Tu aides une personne à clarifier une intention pour AIME. Type d'entrée: ${entryType}. Texte exact: "${text.trim()}". Extrais uniquement les informations explicitement présentes. N'invente rien. Pour toute information absente, utilise une chaîne vide ou un tableau vide et ajoute une question précise dans openQuestions. Place toute interprétation incertaine dans uncertainties. Langage simple, français.`,
      response_json_schema: schema
    });
    return respond({ extraction: result, sourceText: text.trim(), notice: 'Proposition assistée à vérifier et corriger humainement.' });
  } catch (error) {
    return respond({ error: error.message }, { status: 500 });
  }
});