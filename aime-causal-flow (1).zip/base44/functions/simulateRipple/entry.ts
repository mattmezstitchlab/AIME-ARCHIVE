import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
Deno.serve(async (req) => {
  try {
    const respond=(body,init={})=>Response.json(body,{...init,headers:{...init.headers,'Cache-Control':'no-store, private','Pragma':'no-cache'}});
    const base44 = createClientFromRequest(req); const user = await base44.auth.me();
    if (!user) return respond({ error: 'Non autorisé' }, { status: 401 });
    const { projectId, changeType, value, idempotencyKey } = await req.json();
    if (!projectId || !['budget','date'].includes(changeType) || !idempotencyKey) return respond({ error: 'Demande invalide' }, { status: 400 });
    const project = await base44.entities.Project.get(projectId);
    if (!project || project.data_space !== 'real') return respond({ error: 'Dossier introuvable' }, { status: 404 });
    const prior = await base44.asServiceRole.entities.Simulation.filter({ user_id:user.id, project_id:projectId, idempotency_key:idempotencyKey, data_space:'real' }, '-created_date', 1);
    if (prior[0]) {
      const priorEffects = await base44.asServiceRole.entities.CausalEffect.filter({ simulation_id:prior[0].id, data_space:'real' });
      return respond({ simulation:prior[0], effects:priorEffects, idempotent:true });
    }
    const before = { budget:project.budget || 0, target_date:project.target_date || null, version:project.version || 1 };
    const after = { ...before }; const effects = [];
    if (changeType === 'budget') {
      const next = Number(value);
      if (!Number.isFinite(next) || next < 0) return respond({ error:'Budget invalide' }, { status:400 });
      if (next === before.budget) return respond({ error:'Aucune donnée métier ne changerait.' }, { status:409 });
      after.budget = next;
      effects.push({layer:'immediate',dimension:'action',description:`Le budget passerait de ${before.budget} € à ${next} €.`,severity:next < before.budget?'attention':'info'});
      effects.push({layer:'cascade',dimension:'temporality',description:next < before.budget?'Certaines étapes pourraient être décalées.':'Des étapes optionnelles pourraient devenir activables.',severity:'attention'});
    } else {
      if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00Z`))) return respond({ error:'Date invalide' }, { status:400 });
      if (value === before.target_date) return respond({ error:'Aucune donnée métier ne changerait.' }, { status:409 });
      after.target_date = value;
      effects.push({layer:'immediate',dimension:'temporality',description:`La date cible passerait de ${before.target_date || 'non définie'} à ${value}.`,severity:'info'});
      effects.push({layer:'cascade',dimension:'relation',description:'Les disponibilités et dépendances devront être revérifiées.',severity:'attention'});
    }
    effects.push({layer:'human_decision',dimension:'resonance',description:'Une validation humaine reste obligatoire avant toute mutation.',severity:'blocking'});
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    const simulation = await base44.asServiceRole.entities.Simulation.create({ project_id:projectId, user_id:user.id, change_type:changeType, input:{value}, before_snapshot:before, after_snapshot:after, status:'calculated', idempotency_key:idempotencyKey, expires_at:expiresAt, version:1, data_space:'real' });
    await base44.asServiceRole.entities.CausalEffect.bulkCreate(effects.map((effect)=>({ ...effect, simulation_id:simulation.id, reversible:true, data_space:'real' })));
    await base44.asServiceRole.entities.AuditEntry.create({actor_id:user.id,action:'simulation_calculated',target_type:'Simulation',target_id:simulation.id,reason:'Prévisualisation demandée explicitement',previous_state:JSON.stringify(before),new_state:JSON.stringify(after),data_used:[changeType],idempotency_key:`simulate:${idempotencyKey}`,server_date:new Date().toISOString(),version:1,reversible:true,data_space:'real'});
    return respond({ simulation, effects, notice:'Ceci est une simulation. Rien n’a encore été modifié.' });
  } catch (error) { return respond({ error:error.message }, { status:500 }); }
});