# BANKOSYSTEM → AIME mère

## 1. Entités universelles transférables
Identity, PublicProfile (+ME), Intention (Point Zéro), Project, Seed, OraState, ConsentReceipt, MatchParticipant, Decision, Simulation, CausalSignal, CausalEffect, Evidence, Document, AuditEntry et LastPoint. Need, Offer, Capital, Commitment et MatchProposal gardent des extensions BANKOSYSTEM.

## 2. Fonctions backend transférables
`recordConsent`, `revealIdentity`, `transitionOra`, `simulateRipple`, `applySimulation`, `discardSimulation` et `bankosystemCausalAdapter`. `computeMatchProposals` reste spécialisé mais son empreinte et son explication sont transférables.

## 3. Machines d’état
- Consentement participant : pending → accepted | refused | revoked. Toute nouvelle action incrémente la version.
- Reçu : pending → granted | refused | revoked | expired.
- ORA : observing → feeling → acting. Si Ressentir est ignoré, la transition observing → acting persiste `feeling_status: skipped`; un ressenti fourni persiste `provided`.
- Simulation : calculated → applied | discarded | expired | conflict.
- Décision : pending → committed | failed.
- Seed : sown/detected/recognized/proposed/awaiting_consent/mutually_accepted/activated/completed/suspended/revoked/archived.

## 4. Règles de consentement
L’utilisateur vient exclusivement de la session serveur. Chaque participant reçoit un reçu dès la proposition. Une identité exige au moins deux participants uniques, tous accepted, un reçu granted v2 par participant et une égalité entre version du reçu et version du participant. La vérification est répétée avant la réponse, les réponses privées portent `Cache-Control: no-store`, et refus/révocation effacent les drapeaux et l’affichage. Aucun score global et aucune identité privée ne participent au matching.

## 5. Règles RLS
Project est lisible par son créateur mais non modifiable directement. MatchProposal, ConsentReceipt, OraState, Decision et AuditEntry sont mutés uniquement côté serveur ; les lectures de reçus, ORA, décisions et audits sont limitées à leur utilisateur/auteur. Simulation est limitée à `user_id`. Les espaces real/demo/test sont filtrés explicitement dans les fonctions sensibles.

## 6. Contrat BankosystemCausalAdapter
Version `bankosystem-causal-radial/v1` : `{project,nodes,relations,capitalTypes,generatedAt}`. Chaque nœud expose type, état, causes, effets, incertitudes, barrières, décisions humaines, preuves et droits d’action. Aucune dépendance à AIME Event. Les six capitaux restent : financial, time, skills, experience, relational, material_territorial.

## 7. Tests
`src/lib/trustKernel.test.js` contient 18 tests contractuels : double/unique consentement, révocation concurrente modélisée, reçu v2, versions obsolètes, ORA skipped/provided, non-mutation, décision/audit, discarded, budget/date, dédoublonnage, isolation projet/espace et refus d’identité privée. Ils n’ont pas été exécutés dans cet environnement faute de terminal. Dix contrôles finaux de déploiement backend ont réussi avec les codes attendus (9 refus 400, 1 lecture 200), puis `revealIdentity` a été revalidée en 400 après son dernier durcissement.

## 8. Dépendances
Base44 SDK 0.8.x, Web Crypto SHA-256, React 18, Vite 6 et Node `node:test`. Aucun paquet supplémentaire.

## 9. Exclusivement BANKOSYSTEM
Six capitaux, besoins/offres, règles de complémentarité, disponibilités, territoires, conditions, valeurs, preuves autorisées, conflits, structures duo/trio/cercle/équipe/chaîne et explication SI → ALORS → PARCE QUE.

## 10. Risques résiduels
Base44 ne fournit ici ni transaction multi-entités ni compare-and-swap prouvé. `expectedVersion` détecte un conflit mais n’est pas une transaction. Les fonctions revérifient participants, unicité des reçus, politique v2 et versions avant réponse, puis ferment l’accès en cas d’écart ; une fenêtre de course résiduelle demeure entre la dernière lecture et la réponse. Project + Decision + AuditEntry utilisent journal préalable et compensation, sans atomicité garantie. Le dédoublonnage par empreinte n’est pas protégé par une contrainte unique transactionnelle. Les distances restent déclaratives. Les tests réels avec deux comptes, les commandes npm et l’observation runtime des en-têtes doivent encore être exécutés par l’agent de test.

## 11. Ordre d’intégration dans AIME mère
1. RLS et séparation des espaces. 2. Identity/PublicProfile/Project. 3. ConsentReceipt/MatchParticipant et fonctions de consentement. 4. AuditEntry/Decision. 5. Simulation/Ripple. 6. ORA/Seed/LastPoint. 7. Adaptateur radial. 8. Tests multi-comptes. 9. Extensions spécialisées choisies de BANKOSYSTEM.

## 12. Chemins exacts
### Entités
- `base44/entities/Identity.jsonc`
- `base44/entities/PublicProfile.jsonc`
- `base44/entities/Intention.jsonc`
- `base44/entities/Project.jsonc`
- `base44/entities/Seed.jsonc`
- `base44/entities/OraState.jsonc`
- `base44/entities/ConsentReceipt.jsonc`
- `base44/entities/MatchParticipant.jsonc`
- `base44/entities/Decision.jsonc`
- `base44/entities/Simulation.jsonc`
- `base44/entities/CausalSignal.jsonc`
- `base44/entities/CausalEffect.jsonc`
- `base44/entities/Evidence.jsonc`
- `base44/entities/Document.jsonc`
- `base44/entities/AuditEntry.jsonc`
- `base44/entities/LastPoint.jsonc`
- `base44/entities/Need.jsonc`
- `base44/entities/Offer.jsonc`
- `base44/entities/Capital.jsonc`
- `base44/entities/Commitment.jsonc`
- `base44/entities/MatchProposal.jsonc`

### Fonctions et adaptateur
- `base44/functions/recordConsent/entry.ts`
- `base44/functions/revealIdentity/entry.ts`
- `base44/functions/transitionOra/entry.ts`
- `base44/functions/simulateRipple/entry.ts`
- `base44/functions/applySimulation/entry.ts`
- `base44/functions/discardSimulation/entry.ts`
- `base44/functions/computeMatchProposals/entry.ts`
- `base44/functions/getMyMatches/entry.ts`
- `base44/functions/extractIntention/entry.ts`
- Adaptateur : `base44/functions/bankosystemCausalAdapter/entry.ts`

### Tests
- `src/lib/trustKernel.test.js`
- Contrats testés : `src/lib/trustKernel.js`

## 13. Validation de clôture B1
- Project : `rls.update` et `rls.delete` sont `false`; modification métier uniquement via fonction de service. Vérification statique réussie, test utilisateur runtime non disponible.
- Réponses privées : les dix fonctions authentifiées utilisent `Cache-Control: no-store, private` et `Pragma: no-cache` sur tous leurs retours. Vérification source réussie; l’outil backend ne restitue pas les en-têtes pour preuve runtime.
- Simulation : `applied` retourne 409, `expired` 410, version obsolète 409, type hors budget/date 400, absence de mutation 409. Vérification source réussie; scénarios persistés non exécutés.
- Matching : empreinte SHA-256 inclut projet/besoin/offre et les lectures UI sont filtrées par projet. Vérification source réussie; course de création simultanée non couverte transactionnellement.
- ORA : `pending → provided|skipped`, puis `acting`; persistance et retour API ajoutés.
- Multi-comptes : 0/5 scénarios exécutés, faute de deux sessions de comptes autorisées dans cet environnement.
- Commandes demandées : `npm run build`, `npm run lint`, `npm run typecheck`, `npm test` non exécutées; code de sortie indisponible, car aucun terminal n’est exposé.
- Contrôles backend finaux : 11 réussis, 0 échoué après correction; les dix fonctions passent leur contrôle final et `revealIdentity` a été contrôlée une seconde fois après durcissement.
- ZIP exportable : non généré; aucun outil d’archive/export n’est disponible dans cet environnement.

## 14. Décision
**NOT READY FOR MOTHER** tant que les quatre commandes npm et les cinq scénarios réels multi-comptes ne sont pas exécutés avec preuves.