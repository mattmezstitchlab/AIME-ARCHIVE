CREATE TABLE `agenda_items` (
	`id` varchar(64) NOT NULL,
	`eventId` varchar(64) NOT NULL,
	`time` varchar(8) NOT NULL,
	`endTime` varchar(8),
	`title` varchar(255) NOT NULL,
	`description` text,
	`speaker` varchar(255),
	`category` enum('ceremony','cocktail','dinner','music','photo','logistics','other') NOT NULL DEFAULT 'other',
	`location` varchar(255),
	`isLive` boolean NOT NULL DEFAULT false,
	`delayMinutes` int NOT NULL DEFAULT 0,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agenda_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `event_alerts` (
	`id` varchar(64) NOT NULL,
	`eventId` varchar(64) NOT NULL,
	`agendaItemId` varchar(64),
	`type` enum('delay','broadcast','reminder') NOT NULL,
	`message` text NOT NULL,
	`delayMinutes` int DEFAULT 0,
	`targetRoles` json DEFAULT ('["couple","vendor","guest","coordinator"]'),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `event_alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gallery_photos` (
	`id` varchar(64) NOT NULL,
	`eventId` varchar(64) NOT NULL,
	`uploaderName` varchar(255) NOT NULL,
	`photoUrl` text NOT NULL,
	`caption` text,
	`likesCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gallery_photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guest_registrations` (
	`id` varchar(64) NOT NULL,
	`eventId` varchar(64) NOT NULL,
	`firstName` varchar(128) NOT NULL,
	`lastName` varchar(128) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(32),
	`dietaryRestrictions` text,
	`attendsCeremony` boolean NOT NULL DEFAULT false,
	`attendsCocktail` boolean NOT NULL DEFAULT false,
	`attendsDinner` boolean NOT NULL DEFAULT false,
	`plusOne` boolean NOT NULL DEFAULT false,
	`plusOneName` varchar(255),
	`message` text,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guest_registrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vendors` (
	`id` varchar(64) NOT NULL,
	`eventId` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`role` varchar(255) NOT NULL,
	`phone` varchar(32),
	`email` varchar(320),
	`description` text,
	`arrivalTime` varchar(8),
	`status` enum('pending','confirmed','arrived') NOT NULL DEFAULT 'pending',
	`category` enum('ceremony','cocktail','dinner','music','photo','logistics','other') NOT NULL DEFAULT 'other',
	`notes` text,
	`checklist` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vendors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `voice_messages` (
	`id` varchar(64) NOT NULL,
	`eventId` varchar(64) NOT NULL,
	`guestName` varchar(255) NOT NULL,
	`audioUrl` text NOT NULL,
	`duration` int NOT NULL DEFAULT 0,
	`transcription` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `voice_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_events` (
	`id` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`date` varchar(64) NOT NULL,
	`venue` varchar(255) NOT NULL,
	`address` text,
	`dressCode` text,
	`parkingInfo` text,
	`accommodationInfo` text,
	`organizerPhone` varchar(32),
	`organizerEmail` varchar(320),
	`heroImageUrl` text,
	`adminPinHash` varchar(64),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wedding_events_id` PRIMARY KEY(`id`)
);
