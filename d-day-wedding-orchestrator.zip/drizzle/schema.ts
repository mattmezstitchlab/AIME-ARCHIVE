import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
} from "drizzle-orm/mysql-core";

// ─── Users (existing) ─────────────────────────────────────────────────────────

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Wedding Events ───────────────────────────────────────────────────────────

export const weddingEvents = mysqlTable("wedding_events", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  date: varchar("date", { length: 64 }).notNull(),
  venue: varchar("venue", { length: 255 }).notNull(),
  address: text("address"),
  dressCode: text("dressCode"),
  parkingInfo: text("parkingInfo"),
  accommodationInfo: text("accommodationInfo"),
  organizerPhone: varchar("organizerPhone", { length: 32 }),
  organizerEmail: varchar("organizerEmail", { length: 320 }),
  heroImageUrl: text("heroImageUrl"),
  adminPinHash: varchar("adminPinHash", { length: 64 }), // SHA-256 of PIN
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WeddingEventRow = typeof weddingEvents.$inferSelect;
export type InsertWeddingEvent = typeof weddingEvents.$inferInsert;

// ─── Agenda Items ─────────────────────────────────────────────────────────────

export const agendaItems = mysqlTable("agenda_items", {
  id: varchar("id", { length: 64 }).primaryKey(),
  eventId: varchar("eventId", { length: 64 }).notNull(),
  time: varchar("time", { length: 8 }).notNull(), // "HH:MM"
  endTime: varchar("endTime", { length: 8 }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  speaker: varchar("speaker", { length: 255 }),
  category: mysqlEnum("category", [
    "ceremony",
    "cocktail",
    "dinner",
    "music",
    "photo",
    "logistics",
    "other",
  ])
    .default("other")
    .notNull(),
  location: varchar("location", { length: 255 }),
  isLive: boolean("isLive").default(false).notNull(),
  delayMinutes: int("delayMinutes").default(0).notNull(), // SmartRipple delay
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AgendaItemRow = typeof agendaItems.$inferSelect;
export type InsertAgendaItem = typeof agendaItems.$inferInsert;

// ─── Vendors ──────────────────────────────────────────────────────────────────

export const vendors = mysqlTable("vendors", {
  id: varchar("id", { length: 64 }).primaryKey(),
  eventId: varchar("eventId", { length: 64 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  role: varchar("role", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  email: varchar("email", { length: 320 }),
  description: text("description"),
  arrivalTime: varchar("arrivalTime", { length: 8 }),
  status: mysqlEnum("status", ["pending", "confirmed", "arrived"])
    .default("pending")
    .notNull(),
  category: mysqlEnum("category", [
    "ceremony",
    "cocktail",
    "dinner",
    "music",
    "photo",
    "logistics",
    "other",
  ])
    .default("other")
    .notNull(),
  notes: text("notes"),
  checklist: json("checklist").$type<string[]>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type VendorRow = typeof vendors.$inferSelect;
export type InsertVendor = typeof vendors.$inferInsert;

// ─── Guest Registrations ──────────────────────────────────────────────────────

export const guestRegistrations = mysqlTable("guest_registrations", {
  id: varchar("id", { length: 64 }).primaryKey(),
  eventId: varchar("eventId", { length: 64 }).notNull(),
  firstName: varchar("firstName", { length: 128 }).notNull(),
  lastName: varchar("lastName", { length: 128 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  dietaryRestrictions: text("dietaryRestrictions"),
  attendsCeremony: boolean("attendsCeremony").default(false).notNull(),
  attendsCocktail: boolean("attendsCocktail").default(false).notNull(),
  attendsDinner: boolean("attendsDinner").default(false).notNull(),
  plusOne: boolean("plusOne").default(false).notNull(),
  plusOneName: varchar("plusOneName", { length: 255 }),
  message: text("message"),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
});

export type GuestRegistrationRow = typeof guestRegistrations.$inferSelect;
export type InsertGuestRegistration = typeof guestRegistrations.$inferInsert;

// ─── Voice Messages (Capsule Sonore) ─────────────────────────────────────────

export const voiceMessages = mysqlTable("voice_messages", {
  id: varchar("id", { length: 64 }).primaryKey(),
  eventId: varchar("eventId", { length: 64 }).notNull(),
  guestName: varchar("guestName", { length: 255 }).notNull(),
  audioUrl: text("audioUrl").notNull(), // S3 storage URL
  duration: int("duration").default(0).notNull(), // seconds
  transcription: text("transcription"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VoiceMessageRow = typeof voiceMessages.$inferSelect;
export type InsertVoiceMessage = typeof voiceMessages.$inferInsert;

// ─── Photo Gallery ────────────────────────────────────────────────────────────

export const galleryPhotos = mysqlTable("gallery_photos", {
  id: varchar("id", { length: 64 }).primaryKey(),
  eventId: varchar("eventId", { length: 64 }).notNull(),
  uploaderName: varchar("uploaderName", { length: 255 }).notNull(),
  photoUrl: text("photoUrl").notNull(), // S3 storage URL
  caption: text("caption"),
  likesCount: int("likesCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GalleryPhotoRow = typeof galleryPhotos.$inferSelect;
export type InsertGalleryPhoto = typeof galleryPhotos.$inferInsert;

// ─── Event Alerts (SmartRipple + Broadcast) ───────────────────────────────────

export const eventAlerts = mysqlTable("event_alerts", {
  id: varchar("id", { length: 64 }).primaryKey(),
  eventId: varchar("eventId", { length: 64 }).notNull(),
  agendaItemId: varchar("agendaItemId", { length: 64 }),
  type: mysqlEnum("type", ["delay", "broadcast", "reminder"]).notNull(),
  message: text("message").notNull(),
  delayMinutes: int("delayMinutes").default(0),
  targetRoles: json("targetRoles").$type<string[]>().default(["couple", "vendor", "guest", "coordinator"]),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EventAlertRow = typeof eventAlerts.$inferSelect;
export type InsertEventAlert = typeof eventAlerts.$inferInsert;
