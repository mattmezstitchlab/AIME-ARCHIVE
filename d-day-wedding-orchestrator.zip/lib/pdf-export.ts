/**
 * Service d'export PDF du programme
 * Utilise expo-print pour générer un PDF HTML du programme complet
 * et expo-sharing pour le partager.
 */

import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import type { WeddingEvent, AgendaItem } from "./wedding-store";

// Couleurs Light Neumorphism pour le PDF
const PDF_COLORS = {
  bg: "#f0f0f0",
  surface: "#e8e8e8",
  red: "#e8453c",
  text: "#2d2d2d",
  muted: "#888888",
  border: "#c8c8c8",
};

const CATEGORY_LABELS: Record<string, string> = {
  ceremony:   "Cérémonie",
  cocktail:   "Cocktail",
  dinner:     "Dîner",
  party:      "Soirée",
  logistics:  "Logistique",
  other:      "Autre",
};

const CATEGORY_COLORS: Record<string, string> = {
  ceremony:   "#e8453c",
  cocktail:   "#f39c12",
  dinner:     "#27ae60",
  party:      "#8e44ad",
  logistics:  "#2980b9",
  other:      "#7f8c8d",
};

function formatDateFR(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString("fr-FR", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return dateStr;
  }
}

function buildHTML(event: WeddingEvent, items: AgendaItem[]): string {
  const sortedItems = [...items].sort((a, b) => a.time.localeCompare(b.time));

  const itemsHTML = sortedItems.map((item, i) => {
    const catColor = CATEGORY_COLORS[item.category] ?? PDF_COLORS.red;
    const catLabel = CATEGORY_LABELS[item.category] ?? item.category;
    return `
      <tr style="background: ${i % 2 === 0 ? "#f8f8f8" : "#ffffff"};">
        <td style="padding: 12px 16px; font-weight: 700; color: ${PDF_COLORS.red}; font-size: 15px; white-space: nowrap; border-right: 1px solid ${PDF_COLORS.border};">
          ${item.time}
        </td>
        <td style="padding: 12px 16px; border-right: 1px solid ${PDF_COLORS.border};">
          <div style="font-weight: 700; color: ${PDF_COLORS.text}; font-size: 14px; margin-bottom: 2px;">
            ${item.title}
          </div>
          ${item.description ? `<div style="color: ${PDF_COLORS.muted}; font-size: 12px; margin-top: 3px;">${item.description}</div>` : ""}
          ${item.speaker ? `<div style="color: ${PDF_COLORS.muted}; font-size: 11px; margin-top: 3px; font-style: italic;">▸ ${item.speaker}</div>` : ""}
          ${item.location ? `<div style="color: ${PDF_COLORS.muted}; font-size: 11px; margin-top: 2px;">📍 ${item.location}</div>` : ""}
        </td>
        <td style="padding: 12px 16px; text-align: center;">
          <span style="
            display: inline-block;
            background: ${catColor}20;
            color: ${catColor};
            border: 1px solid ${catColor}50;
            border-radius: 6px;
            padding: 3px 10px;
            font-size: 11px;
            font-weight: 600;
          ">${catLabel}</span>
        </td>
      </tr>
    `;
  }).join("");

  return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Programme — ${event.name}</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
          background: #ffffff;
          color: ${PDF_COLORS.text};
          padding: 40px;
        }
        .header {
          text-align: center;
          padding-bottom: 32px;
          border-bottom: 3px solid ${PDF_COLORS.red};
          margin-bottom: 32px;
        }
        .header .monogram {
          display: inline-block;
          width: 60px; height: 60px;
          border-radius: 50%;
          background: ${PDF_COLORS.surface};
          border: 2px solid ${PDF_COLORS.red};
          line-height: 60px;
          font-size: 18px;
          font-weight: 900;
          color: ${PDF_COLORS.red};
          letter-spacing: 2px;
          margin-bottom: 16px;
        }
        .header h1 {
          font-size: 28px;
          font-weight: 900;
          color: ${PDF_COLORS.text};
          letter-spacing: 0.5px;
        }
        .header .subtitle {
          font-size: 11px;
          color: ${PDF_COLORS.red};
          letter-spacing: 4px;
          font-weight: 700;
          text-transform: uppercase;
          margin-top: 6px;
        }
        .header .date {
          font-size: 14px;
          color: ${PDF_COLORS.muted};
          margin-top: 8px;
        }
        .header .venue {
          font-size: 13px;
          color: ${PDF_COLORS.muted};
          margin-top: 4px;
        }
        .section-title {
          font-size: 11px;
          font-weight: 700;
          color: ${PDF_COLORS.muted};
          letter-spacing: 3px;
          text-transform: uppercase;
          margin-bottom: 16px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        }
        thead tr {
          background: ${PDF_COLORS.red};
          color: white;
        }
        thead th {
          padding: 14px 16px;
          text-align: left;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 1px;
          text-transform: uppercase;
        }
        .footer {
          margin-top: 40px;
          text-align: center;
          font-size: 11px;
          color: ${PDF_COLORS.muted};
          border-top: 1px solid ${PDF_COLORS.border};
          padding-top: 20px;
        }
        .footer .contact {
          margin-top: 8px;
          font-weight: 600;
          color: ${PDF_COLORS.red};
        }
        .info-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
          margin-bottom: 32px;
        }
        .info-card {
          background: ${PDF_COLORS.surface};
          border-radius: 10px;
          padding: 14px 16px;
          border: 1px solid ${PDF_COLORS.border};
        }
        .info-card .label {
          font-size: 10px;
          font-weight: 700;
          color: ${PDF_COLORS.muted};
          letter-spacing: 2px;
          text-transform: uppercase;
          margin-bottom: 4px;
        }
        .info-card .value {
          font-size: 13px;
          font-weight: 600;
          color: ${PDF_COLORS.text};
        }
      </style>
    </head>
    <body>
      <!-- En-tête -->
      <div class="header">
        <div class="monogram">D·D</div>
        <h1>${event.name}</h1>
        <div class="subtitle">Programme officiel</div>
        <div class="date">📅 ${formatDateFR(event.date)}</div>
        ${event.venue ? `<div class="venue">📍 ${event.venue}${event.address ? ` — ${event.address}` : ""}</div>` : ""}
      </div>

      <!-- Infos pratiques -->
      ${(event.venue || event.dressCode || event.organizerPhone) ? `
      <p class="section-title">Informations pratiques</p>
      <div class="info-grid">
        ${event.venue ? `<div class="info-card"><div class="label">Lieu</div><div class="value">${event.venue}</div></div>` : ""}
        ${event.dressCode ? `<div class="info-card"><div class="label">Dress Code</div><div class="value">${event.dressCode}</div></div>` : ""}
        ${event.organizerPhone ? `<div class="info-card"><div class="label">Contact organisateur</div><div class="value">${event.organizerPhone}</div></div>` : ""}
        ${event.organizerEmail ? `<div class="info-card"><div class="label">Email</div><div class="value">${event.organizerEmail}</div></div>` : ""}
      </div>
      ` : ""}

      <!-- Programme -->
      <p class="section-title">Déroulé de la journée</p>
      <table>
        <thead>
          <tr>
            <th style="width: 80px;">Heure</th>
            <th>Étape</th>
            <th style="width: 110px; text-align: center;">Catégorie</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHTML}
        </tbody>
      </table>

      <!-- Pied de page -->
      <div class="footer">
        <div>Document généré par D Day Wedding Orchestrator</div>
        <div>Généré le ${new Date().toLocaleDateString("fr-FR")}</div>
        ${event.organizerPhone ? `<div class="contact">Contact : ${event.organizerPhone}</div>` : ""}
      </div>
    </body>
    </html>
  `;
}

export async function exportProgramPDF(
  event: WeddingEvent,
  items: AgendaItem[]
): Promise<void> {
  const html = buildHTML(event, items);

  const { uri } = await Print.printToFileAsync({
    html,
    base64: false,
  });

  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(uri, {
      mimeType: "application/pdf",
      dialogTitle: `Programme — ${event.name}`,
      UTI: "com.adobe.pdf",
    });
  } else if (Platform.OS === "web") {
    // Sur web, ouvrir dans un nouvel onglet
    const w = window.open("", "_blank");
    if (w) {
      w.document.write(html);
      w.document.close();
    }
  }
}
