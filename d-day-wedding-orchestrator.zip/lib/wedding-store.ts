import AsyncStorage from "@react-native-async-storage/async-storage";

// ─── Types ────────────────────────────────────────────────────────────────────

export type UserRole = "couple" | "vendor" | "guest";

export type EventCategory =
  | "ceremony"
  | "cocktail"
  | "dinner"
  | "music"
  | "photo"
  | "logistics"
  | "other";

export interface AgendaItem {
  id: string;
  time: string; // "HH:MM"
  endTime?: string;
  title: string;
  description?: string;
  speaker?: string; // intervenant / prestataire
  category: EventCategory;
  location?: string;
  isLive?: boolean;
}

export interface Vendor {
  id: string;
  name: string;
  role: string;
  phone?: string;
  email?: string;
  description?: string;
  arrivalTime?: string;
  status: "confirmed" | "pending" | "arrived";
  category: EventCategory;
  avatar?: string; // initials
}

export interface GuestRegistration {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dietaryRestrictions?: string;
  attendsCeremony: boolean;
  attendsCocktail: boolean;
  attendsDinner: boolean;
  plusOne?: boolean;
  plusOneName?: string;
  message?: string;
  submittedAt: string;
}

export interface WeddingEvent {
  id: string;
  name: string;
  date: string; // ISO date string
  venue: string;
  address?: string;
  dressCode?: string;
  parkingInfo?: string;
  accommodationInfo?: string;
  organizerPhone?: string;
  organizerEmail?: string;
  heroImageUrl?: string;
  agenda: AgendaItem[];
  vendors: Vendor[];
  registrations: GuestRegistration[];
}

// ─── Demo Data ────────────────────────────────────────────────────────────────

const DEMO_AGENDA: AgendaItem[] = [
  {
    id: "a1",
    time: "10:00",
    endTime: "11:30",
    title: "Cérémonie civile",
    description: "Mairie du 8ème arrondissement. Rassemblement des proches pour la cérémonie officielle.",
    speaker: "Officier d'état civil",
    category: "ceremony",
    location: "Mairie du 8ème",
    isLive: false,
  },
  {
    id: "a2",
    time: "12:00",
    endTime: "13:30",
    title: "Cérémonie laïque",
    description: "Échange des vœux personnalisés dans les jardins du château. Musique live par le Quatuor Lumière.",
    speaker: "Officiant & Quatuor Lumière",
    category: "ceremony",
    location: "Jardins du Château",
    isLive: false,
  },
  {
    id: "a3",
    time: "13:30",
    endTime: "16:00",
    title: "Cocktail & Vin d'honneur",
    description: "Champagne, canapés et animations musicales. Séance photo de groupe à 14h30.",
    speaker: "Saxophone — Marc Delacroix",
    category: "cocktail",
    location: "Terrasse du Château",
    isLive: true,
  },
  {
    id: "a4",
    time: "14:30",
    endTime: "15:00",
    title: "Séance photo de groupe",
    description: "Regroupement de tous les invités pour les photos officielles.",
    speaker: "Photographe — Élise Martin",
    category: "photo",
    location: "Escalier principal",
    isLive: false,
  },
  {
    id: "a5",
    time: "16:00",
    endTime: "16:30",
    title: "Installation en salle",
    description: "Accueil des invités dans la grande salle de réception. Plan de table disponible à l'entrée.",
    category: "logistics",
    location: "Grande Salle",
    isLive: false,
  },
  {
    id: "a6",
    time: "16:30",
    endTime: "17:00",
    title: "Discours & Toasts",
    description: "Discours des témoins et des parents. Toast au champagne.",
    speaker: "Témoins & Famille",
    category: "dinner",
    location: "Grande Salle",
    isLive: false,
  },
  {
    id: "a7",
    time: "17:00",
    endTime: "21:00",
    title: "Dîner de gala",
    description: "Menu gastronomique en 5 services. Accord mets et vins par le sommelier.",
    speaker: "Chef Thomas Renard",
    category: "dinner",
    location: "Grande Salle",
    isLive: false,
  },
  {
    id: "a8",
    time: "21:00",
    endTime: "21:30",
    title: "Pièce montée & Desserts",
    description: "Découpe de la pièce montée par les mariés. Buffet de desserts.",
    speaker: "Pâtissier — Sophie Laurent",
    category: "dinner",
    location: "Grande Salle",
    isLive: false,
  },
  {
    id: "a9",
    time: "21:30",
    endTime: "22:00",
    title: "Ouverture du bal",
    description: "Première danse des mariés sur 'La Vie en Rose'. Orchestre live pour la soirée.",
    speaker: "Orchestre Étoile — 8 musiciens",
    category: "music",
    location: "Salle de bal",
    isLive: false,
  },
  {
    id: "a10",
    time: "22:00",
    endTime: "03:00",
    title: "Soirée dansante",
    description: "Musique live et DJ set. Bar ouvert. Photobooth disponible.",
    speaker: "DJ Maxime & Orchestre Étoile",
    category: "music",
    location: "Salle de bal",
    isLive: false,
  },
];

const DEMO_VENDORS: Vendor[] = [
  {
    id: "v1",
    name: "Élise Martin",
    role: "Photographe",
    phone: "+33 6 12 34 56 78",
    email: "elise@elise-martin-photo.fr",
    description: "Photographie de mariage naturelle et lumineuse. Reportage complet de la journée.",
    arrivalTime: "09:30",
    status: "confirmed",
    category: "photo",
    avatar: "EM",
  },
  {
    id: "v2",
    name: "Quatuor Lumière",
    role: "Musique cérémonie",
    phone: "+33 6 98 76 54 32",
    email: "contact@quatuor-lumiere.fr",
    description: "Quatuor à cordes classique. Répertoire romantique et contemporain.",
    arrivalTime: "11:00",
    status: "confirmed",
    category: "music",
    avatar: "QL",
  },
  {
    id: "v3",
    name: "Marc Delacroix",
    role: "Saxophoniste cocktail",
    phone: "+33 6 55 44 33 22",
    email: "marc.delacroix@music.fr",
    description: "Saxophone jazz et bossa nova pour l'ambiance cocktail.",
    arrivalTime: "13:00",
    status: "confirmed",
    category: "music",
    avatar: "MD",
  },
  {
    id: "v4",
    name: "Chef Thomas Renard",
    role: "Traiteur",
    phone: "+33 6 11 22 33 44",
    email: "thomas@renard-traiteur.fr",
    description: "Cuisine gastronomique française. Menu personnalisé avec produits locaux.",
    arrivalTime: "08:00",
    status: "arrived",
    category: "dinner",
    avatar: "TR",
  },
  {
    id: "v5",
    name: "Sophie Laurent",
    role: "Pâtissière",
    phone: "+33 6 77 88 99 00",
    email: "sophie@patisserie-laurent.fr",
    description: "Pièce montée sur mesure et buffet de desserts. Spécialiste mariage.",
    arrivalTime: "14:00",
    status: "confirmed",
    category: "dinner",
    avatar: "SL",
  },
  {
    id: "v6",
    name: "Orchestre Étoile",
    role: "Orchestre soirée",
    phone: "+33 6 33 44 55 66",
    email: "contact@orchestre-etoile.fr",
    description: "8 musiciens pour la soirée dansante. Jazz, variété française et internationale.",
    arrivalTime: "19:00",
    status: "pending",
    category: "music",
    avatar: "OE",
  },
  {
    id: "v7",
    name: "Fleurs & Jardins",
    role: "Fleuriste",
    phone: "+33 6 44 55 66 77",
    email: "contact@fleurs-jardins.fr",
    description: "Décoration florale complète : bouquet, tables, arche cérémonie.",
    arrivalTime: "07:00",
    status: "arrived",
    category: "other",
    avatar: "FJ",
  },
];

const DEMO_REGISTRATIONS: GuestRegistration[] = [
  {
    id: "reg_demo_1",
    firstName: "Marie",
    lastName: "Dupont",
    email: "marie.dupont@email.fr",
    phone: "+33 6 11 22 33 44",
    dietaryRestrictions: "Végétarienne",
    attendsCeremony: true,
    attendsCocktail: true,
    attendsDinner: true,
    plusOne: true,
    plusOneName: "Paul Dupont",
    message: "Nous sommes tellement heureux pour vous !",
    submittedAt: "2026-05-01T10:00:00.000Z",
  },
  {
    id: "reg_demo_2",
    firstName: "Jean",
    lastName: "Martin",
    email: "jean.martin@email.fr",
    phone: "+33 6 55 66 77 88",
    dietaryRestrictions: "Allergie aux noix",
    attendsCeremony: true,
    attendsCocktail: true,
    attendsDinner: false,
    plusOne: false,
    message: "",
    submittedAt: "2026-05-03T14:30:00.000Z",
  },
  {
    id: "reg_demo_3",
    firstName: "Claire",
    lastName: "Bernard",
    email: "claire.bernard@email.fr",
    dietaryRestrictions: "Sans gluten",
    attendsCeremony: true,
    attendsCocktail: false,
    attendsDinner: true,
    plusOne: true,
    plusOneName: "Luc Bernard",
    submittedAt: "2026-05-05T09:15:00.000Z",
  },
  {
    id: "reg_demo_4",
    firstName: "Thomas",
    lastName: "Petit",
    email: "thomas.petit@email.fr",
    phone: "+33 6 99 88 77 66",
    attendsCeremony: false,
    attendsCocktail: true,
    attendsDinner: true,
    plusOne: false,
    message: "Félicitations à vous deux !",
    submittedAt: "2026-05-07T16:45:00.000Z",
  },
  {
    id: "reg_demo_5",
    firstName: "Isabelle",
    lastName: "Leroy",
    email: "isabelle.leroy@email.fr",
    dietaryRestrictions: "Vegan",
    attendsCeremony: true,
    attendsCocktail: true,
    attendsDinner: true,
    plusOne: false,
    message: "Avec tout notre amour !",
    submittedAt: "2026-05-10T11:00:00.000Z",
  },
];

const DEMO_EVENT: WeddingEvent = {
  id: "wedding-2026",
  name: "Mariage Sophie & Alexandre",
  date: "2026-06-14T10:00:00.000Z",
  venue: "Château de Vaux-le-Vicomte",
  address: "77950 Maincy, Seine-et-Marne",
  dressCode: "Tenue de soirée — Palette champagne & bleu nuit",
  parkingInfo: "Parking gratuit sur place. Navettes depuis la gare de Melun toutes les 30 minutes.",
  accommodationInfo: "Hôtel du Château (sur place) — Réservation au 01 64 14 41 90. Hôtel Ibis Melun à 15 min.",
  organizerPhone: "+33 6 00 11 22 33",
  organizerEmail: "organisation@mariage-sophie-alexandre.fr",
  agenda: DEMO_AGENDA,
  vendors: DEMO_VENDORS,
  registrations: DEMO_REGISTRATIONS,
};

// ─── Storage Keys ─────────────────────────────────────────────────────────────

const STORAGE_KEY = "ddw_event_v1";
const ROLE_KEY = "ddw_user_role";
const REGISTRATIONS_KEY = "ddw_registrations_v1";

// ─── Store Functions ──────────────────────────────────────────────────────────

export async function loadEvent(): Promise<WeddingEvent> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as WeddingEvent;
      // Merge with demo registrations if none exist
      if (!parsed.registrations || parsed.registrations.length === 0) {
        parsed.registrations = DEMO_REGISTRATIONS;
      }
      return parsed;
    }
  } catch {}
  return DEMO_EVENT;
}

export async function saveEvent(event: WeddingEvent): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(event));
}

export async function loadUserRole(): Promise<UserRole | null> {
  try {
    const raw = await AsyncStorage.getItem(ROLE_KEY);
    return raw as UserRole | null;
  } catch {
    return null;
  }
}

export async function saveUserRole(role: UserRole): Promise<void> {
  await AsyncStorage.setItem(ROLE_KEY, role);
}

export async function addRegistration(
  reg: Omit<GuestRegistration, "id" | "submittedAt">
): Promise<GuestRegistration> {
  const newReg: GuestRegistration = {
    ...reg,
    id: `reg_${Date.now()}`,
    submittedAt: new Date().toISOString(),
  };
  try {
    const raw = await AsyncStorage.getItem(REGISTRATIONS_KEY);
    const existing: GuestRegistration[] = raw ? JSON.parse(raw) : [];
    existing.push(newReg);
    await AsyncStorage.setItem(REGISTRATIONS_KEY, JSON.stringify(existing));
    // Also update the event
    const event = await loadEvent();
    event.registrations = [...event.registrations, newReg];
    await saveEvent(event);
  } catch {}
  return newReg;
}

export async function deleteRegistration(regId: string): Promise<void> {
  const event = await loadEvent();
  event.registrations = event.registrations.filter((r) => r.id !== regId);
  await saveEvent(event);
}

// ─── Admin: Vendor CRUD ─────────────────────────────────────────────────────

export async function updateVendorStatus(
  id: string,
  status: Vendor["status"]
): Promise<void> {
  const event = await loadEvent();
  event.vendors = event.vendors.map((v) =>
    v.id === id ? { ...v, status } : v
  );
  await saveEvent(event);
}

export async function addVendor(
  vendor: Omit<Vendor, "id">
): Promise<Vendor> {
  const newVendor: Vendor = {
    ...vendor,
    id: `v_${Date.now()}`,
  };
  const event = await loadEvent();
  event.vendors = [...event.vendors, newVendor];
  await saveEvent(event);
  return newVendor;
}

export async function updateVendor(
  id: string,
  updates: Partial<Omit<Vendor, "id">>
): Promise<void> {
  const event = await loadEvent();
  event.vendors = event.vendors.map((v) =>
    v.id === id ? { ...v, ...updates } : v
  );
  await saveEvent(event);
}

export async function deleteVendor(id: string): Promise<void> {
  const event = await loadEvent();
  event.vendors = event.vendors.filter((v) => v.id !== id);
  await saveEvent(event);
}

export function cycleVendorStatus(current: Vendor["status"]): Vendor["status"] {
  const cycle: Vendor["status"][] = ["pending", "confirmed", "arrived"];
  const idx = cycle.indexOf(current);
  return cycle[(idx + 1) % cycle.length];
}

export function getVendorStatusLabel(status: Vendor["status"]): string {
  const labels: Record<Vendor["status"], string> = {
    pending: "En attente",
    confirmed: "Confirmé",
    arrived: "Arrivé",
  };
  return labels[status];
}

export function getVendorStatusColor(status: Vendor["status"]): string {
  const colors: Record<Vendor["status"], string> = {
    pending: "#FBBF24",
    confirmed: "#c9a96e",
    arrived: "#4ade80",
  };
  return colors[status];
}

// ─── Admin: Agenda CRUD ───────────────────────────────────────────────────────

export async function addAgendaItem(
  item: Omit<AgendaItem, "id">
): Promise<AgendaItem> {
  const newItem: AgendaItem = {
    ...item,
    id: `a_${Date.now()}`,
  };
  const event = await loadEvent();
  event.agenda = [...event.agenda, newItem].sort((a, b) =>
    a.time.localeCompare(b.time)
  );
  await saveEvent(event);
  return newItem;
}

export async function updateAgendaItem(
  id: string,
  updates: Partial<Omit<AgendaItem, "id">>
): Promise<void> {
  const event = await loadEvent();
  event.agenda = event.agenda
    .map((item) => (item.id === id ? { ...item, ...updates } : item))
    .sort((a, b) => a.time.localeCompare(b.time));
  await saveEvent(event);
}

export async function deleteAgendaItem(id: string): Promise<void> {
  const event = await loadEvent();
  event.agenda = event.agenda.filter((item) => item.id !== id);
  await saveEvent(event);
}

// ─── Dietary Analysis ────────────────────────────────────────────────────────

export interface DietarySummary {
  label: string;
  count: number;
  guests: string[];
  color: string;
}

export function analyzeDietaryRestrictions(
  registrations: GuestRegistration[]
): DietarySummary[] {
  const groups: Record<string, { guests: string[]; color: string }> = {
    "Végétarien / Vegan": { guests: [], color: "#4ade80" },
    "Sans gluten": { guests: [], color: "#FBBF24" },
    "Allergie aux noix": { guests: [], color: "#f87171" },
    "Allergie aux fruits de mer": { guests: [], color: "#f87171" },
    "Sans lactose": { guests: [], color: "#a78bfa" },
    "Halal": { guests: [], color: "#34d399" },
    "Casher": { guests: [], color: "#60a5fa" },
    "Autre restriction": { guests: [], color: "#9b9b8a" },
    "Aucune restriction": { guests: [], color: "rgba(201,169,110,0.5)" },
  };

  for (const reg of registrations) {
    const fullName = `${reg.firstName} ${reg.lastName}`;
    const restriction = reg.dietaryRestrictions?.trim().toLowerCase() ?? "";

    if (!restriction) {
      groups["Aucune restriction"].guests.push(fullName);
    } else if (restriction.includes("vegan") || restriction.includes("végétar")) {
      groups["Végétarien / Vegan"].guests.push(fullName);
    } else if (restriction.includes("gluten")) {
      groups["Sans gluten"].guests.push(fullName);
    } else if (restriction.includes("noix") || restriction.includes("cacahuète") || restriction.includes("arachide")) {
      groups["Allergie aux noix"].guests.push(fullName);
    } else if (restriction.includes("fruit") && restriction.includes("mer")) {
      groups["Allergie aux fruits de mer"].guests.push(fullName);
    } else if (restriction.includes("lactose") || restriction.includes("lait")) {
      groups["Sans lactose"].guests.push(fullName);
    } else if (restriction.includes("halal")) {
      groups["Halal"].guests.push(fullName);
    } else if (restriction.includes("casher") || restriction.includes("kosher")) {
      groups["Casher"].guests.push(fullName);
    } else {
      groups["Autre restriction"].guests.push(fullName);
    }
  }

  return Object.entries(groups)
    .filter(([, v]) => v.guests.length > 0)
    .map(([label, v]) => ({
      label,
      count: v.guests.length,
      guests: v.guests,
      color: v.color,
    }))
    .sort((a, b) => b.count - a.count);
}

// ─── Utility Functions ────────────────────────────────────────────────────────

export function getCategoryLabel(cat: EventCategory): string {
  const labels: Record<EventCategory, string> = {
    ceremony: "Cérémonie",
    cocktail: "Cocktail",
    dinner: "Dîner",
    music: "Musique",
    photo: "Photo",
    logistics: "Logistique",
    other: "Autre",
  };
  return labels[cat] ?? "Autre";
}

export function getCategoryIcon(cat: EventCategory): string {
  const icons: Record<EventCategory, string> = {
    ceremony: "favorite",
    cocktail: "local-bar",
    dinner: "restaurant",
    music: "music-note",
    photo: "photo-camera",
    logistics: "directions-car",
    other: "star",
  };
  return icons[cat] ?? "star";
}

export function formatTime(isoDate: string): string {
  const d = new Date(isoDate);
  return d.toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function getCountdown(targetDate: string): {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
} {
  const now = Date.now();
  const target = new Date(targetDate).getTime();
  const diff = target - now;
  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
  }
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);
  return { days, hours, minutes, seconds, isPast: false };
}

export function getCurrentAgendaItem(agenda: AgendaItem[]): AgendaItem | null {
  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  for (const item of agenda) {
    if (item.time <= hhmm && (!item.endTime || item.endTime > hhmm)) {
      return item;
    }
  }
  return null;
}
