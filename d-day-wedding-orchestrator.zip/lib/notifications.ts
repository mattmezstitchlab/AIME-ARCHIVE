/**
 * Service de notifications push locales
 * Utilise expo-notifications pour programmer des rappels automatiques
 * 30 minutes avant chaque étape du programme.
 */

import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import type { AgendaItem, WeddingEvent } from "./wedding-store";

// Configuration du handler de notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

// ─── Permissions ──────────────────────────────────────────────────────────────

export async function requestNotificationPermissions(): Promise<boolean> {
  if (Platform.OS === "web") return false;

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === "granted") return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

// ─── Programmer les rappels ───────────────────────────────────────────────────

/**
 * Programme un rappel 30 minutes avant chaque étape de l'agenda.
 * Retourne le nombre de notifications programmées.
 */
export async function scheduleAgendaReminders(
  event: WeddingEvent,
  items: AgendaItem[],
  minutesBefore = 30
): Promise<number> {
  if (Platform.OS === "web") return 0;

  const hasPermission = await requestNotificationPermissions();
  if (!hasPermission) return 0;

  // Annuler les rappels existants
  await cancelAllAgendaReminders();

  const eventDate = new Date(event.date);
  let scheduled = 0;

  for (const item of items) {
    try {
      // Parser l'heure de l'étape (format "HH:MM")
      const [hours, minutes] = item.time.split(":").map(Number);
      if (isNaN(hours) || isNaN(minutes)) continue;

      // Construire la date/heure de l'étape
      const stepDate = new Date(eventDate);
      stepDate.setHours(hours, minutes, 0, 0);

      // Calculer l'heure du rappel (X minutes avant)
      const reminderDate = new Date(stepDate.getTime() - minutesBefore * 60 * 1000);

      // Ne pas programmer si le rappel est dans le passé
      if (reminderDate <= new Date()) continue;

      const categoryEmojis: Record<string, string> = {
        ceremony: "💒",
        cocktail: "🥂",
        dinner: "🍽️",
        party: "🎉",
        logistics: "📋",
        other: "📌",
      };
      const emoji = categoryEmojis[item.category] ?? "⏰";

      await Notifications.scheduleNotificationAsync({
        identifier: `agenda-${item.id}`,
        content: {
          title: `${emoji} Dans ${minutesBefore} minutes`,
          body: `${item.time} — ${item.title}${item.location ? ` · ${item.location}` : ""}`,
          data: { agendaItemId: item.id, type: "agenda_reminder" },
          sound: true,
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DATE,
          date: reminderDate,
        },
      });
      scheduled++;
    } catch (e) {
      console.warn(`Impossible de programmer le rappel pour ${item.title}:`, e);
    }
  }

  return scheduled;
}

// ─── Annuler les rappels ──────────────────────────────────────────────────────

export async function cancelAllAgendaReminders(): Promise<void> {
  if (Platform.OS === "web") return;
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  const agendaIds = scheduled
    .filter(n => n.identifier.startsWith("agenda-"))
    .map(n => n.identifier);
  await Promise.all(agendaIds.map(id => Notifications.cancelScheduledNotificationAsync(id)));
}

// ─── Notification immédiate (test / alerte) ───────────────────────────────────

export async function sendImmediateNotification(
  title: string,
  body: string,
  data?: Record<string, unknown>
): Promise<void> {
  if (Platform.OS === "web") return;

  const hasPermission = await requestNotificationPermissions();
  if (!hasPermission) return;

  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      data: data ?? {},
      sound: true,
    },
    trigger: null, // immédiat
  });
}

// ─── Lister les rappels programmés ───────────────────────────────────────────

export async function getScheduledReminders(): Promise<{
  id: string;
  title: string;
  body: string;
  triggerDate?: Date;
}[]> {
  if (Platform.OS === "web") return [];

  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  return scheduled
    .filter(n => n.identifier.startsWith("agenda-"))
    .map(n => ({
      id: n.identifier,
      title: n.content.title ?? "",
      body: n.content.body ?? "",
      triggerDate: (n.trigger as any)?.date
        ? new Date((n.trigger as any).date)
        : undefined,
    }))
    .sort((a, b) => {
      if (!a.triggerDate || !b.triggerDate) return 0;
      return a.triggerDate.getTime() - b.triggerDate.getTime();
    });
}
