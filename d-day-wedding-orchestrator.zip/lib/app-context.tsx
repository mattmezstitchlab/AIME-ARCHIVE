import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import {
  loadEvent,
  loadUserRole,
  saveUserRole,
  saveEvent,
  addAgendaItem,
  updateAgendaItem,
  deleteAgendaItem,
  deleteRegistration,
  addVendor,
  updateVendor,
  updateVendorStatus,
  deleteVendor,
  type WeddingEvent,
  type UserRole,
  type AgendaItem,
  type Vendor,
  getCurrentAgendaItem,
} from "./wedding-store";

interface AppContextValue {
  event: WeddingEvent | null;
  userRole: UserRole | null;
  currentAgendaItem: AgendaItem | null;
  isLoading: boolean;
  setUserRole: (role: UserRole) => Promise<void>;
  refreshEvent: () => Promise<void>;
  // Admin: Agenda
  adminAddAgendaItem: (item: Omit<AgendaItem, "id">) => Promise<void>;
  adminUpdateAgendaItem: (id: string, updates: Partial<Omit<AgendaItem, "id">>) => Promise<void>;
  adminDeleteAgendaItem: (id: string) => Promise<void>;
  adminDeleteRegistration: (regId: string) => Promise<void>;
  // Admin: Vendors
  adminAddVendor: (vendor: Omit<Vendor, "id">) => Promise<void>;
  adminUpdateVendor: (id: string, updates: Partial<Omit<Vendor, "id">>) => Promise<void>;
  adminUpdateVendorStatus: (id: string, status: Vendor["status"]) => Promise<void>;
  adminDeleteVendor: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextValue>({
  event: null,
  userRole: null,
  currentAgendaItem: null,
  isLoading: true,
  setUserRole: async () => {},
  refreshEvent: async () => {},
  adminAddAgendaItem: async () => {},
  adminUpdateAgendaItem: async () => {},
  adminDeleteAgendaItem: async () => {},
  adminDeleteRegistration: async () => {},
  adminAddVendor: async () => {},
  adminUpdateVendor: async () => {},
  adminUpdateVendorStatus: async () => {},
  adminDeleteVendor: async () => {},
});

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [event, setEvent] = useState<WeddingEvent | null>(null);
  const [userRole, setUserRoleState] = useState<UserRole | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshEvent = useCallback(async () => {
    const ev = await loadEvent();
    setEvent(ev);
  }, []);

  useEffect(() => {
    (async () => {
      const [ev, role] = await Promise.all([loadEvent(), loadUserRole()]);
      setEvent(ev);
      setUserRoleState(role);
      setIsLoading(false);
    })();
  }, []);

  const setUserRole = useCallback(async (role: UserRole) => {
    await saveUserRole(role);
    setUserRoleState(role);
  }, []);

  const adminAddAgendaItem = useCallback(async (item: Omit<AgendaItem, "id">) => {
    await addAgendaItem(item);
    await refreshEvent();
  }, [refreshEvent]);

  const adminUpdateAgendaItem = useCallback(async (id: string, updates: Partial<Omit<AgendaItem, "id">>) => {
    await updateAgendaItem(id, updates);
    await refreshEvent();
  }, [refreshEvent]);

  const adminDeleteAgendaItem = useCallback(async (id: string) => {
    await deleteAgendaItem(id);
    await refreshEvent();
  }, [refreshEvent]);

  const adminDeleteRegistration = useCallback(async (regId: string) => {
    await deleteRegistration(regId);
    await refreshEvent();
  }, [refreshEvent]);

  const adminAddVendor = useCallback(async (vendor: Omit<Vendor, "id">) => {
    await addVendor(vendor);
    await refreshEvent();
  }, [refreshEvent]);

  const adminUpdateVendor = useCallback(async (id: string, updates: Partial<Omit<Vendor, "id">>) => {
    await updateVendor(id, updates);
    await refreshEvent();
  }, [refreshEvent]);

  const adminUpdateVendorStatus = useCallback(async (id: string, status: Vendor["status"]) => {
    await updateVendorStatus(id, status);
    await refreshEvent();
  }, [refreshEvent]);

  const adminDeleteVendor = useCallback(async (id: string) => {
    await deleteVendor(id);
    await refreshEvent();
  }, [refreshEvent]);

  const currentAgendaItem = event ? getCurrentAgendaItem(event.agenda) : null;

  return (
    <AppContext.Provider
      value={{
        event,
        userRole,
        currentAgendaItem,
        isLoading,
        setUserRole,
        refreshEvent,
        adminAddAgendaItem,
        adminUpdateAgendaItem,
        adminDeleteAgendaItem,
        adminDeleteRegistration,
        adminAddVendor,
        adminUpdateVendor,
        adminUpdateVendorStatus,
        adminDeleteVendor,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  return useContext(AppContext);
}
