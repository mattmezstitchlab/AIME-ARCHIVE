/**
 * Light Neumorphism Design System
 *
 * Palette exacte du visuel de référence :
 *   Fond       : #e8e8e8 (gris très clair — fond principal)
 *   Surface    : #f0f0f0 (blanc cassé — cartes, boutons surélevés)
 *   Creux      : #dcdcdc (gris moyen — inputs, zones concaves)
 *   Accent     : #e8453c (rouge corail — accent principal)
 *   Ombre clair: #ffffff (blanc pur — haut-gauche)
 *   Ombre sombre: #c8c8c8 (gris moyen — bas-droite)
 *   Texte      : #2d2d2d (gris très foncé — texte principal)
 */

import { StyleSheet } from "react-native";

// ─── Palette ──────────────────────────────────────────────────────────────────

export const NEU = {
  // Fonds
  bg:        "#e8e8e8",   // Fond principal
  bgMid:     "#e4e4e4",   // Fond intermédiaire (header, tab bar)
  bgRaised:  "#f0f0f0",   // Surface en relief (cartes, boutons)
  bgSunken:  "#dcdcdc",   // Surface en creux (inputs, insets)
  bgWhite:   "#f5f5f5",   // Blanc cassé premium

  // Accent rouge corail
  red:       "#e8453c",   // Rouge corail — accent principal
  redLight:  "#ff6b6b",   // Rouge clair — hover/dégradé
  redDark:   "#c0392b",   // Rouge foncé — pressed/ombre
  redBg:     "rgba(232,69,60,0.10)",
  redBorder: "rgba(232,69,60,0.30)",

  // Compatibilité avec les anciens tokens (évite les erreurs de compilation)
  magenta:      "#e8453c",
  cyan:         "#2980b9",
  orange:       "#f39c12",
  rose:         "#ff6b6b",
  gold:         "#e8453c",
  borderMagenta: "rgba(232,69,60,0.30)",
  borderCyan:    "rgba(41,128,185,0.30)",
  borderOrange:  "rgba(243,156,18,0.30)",
  borderGold:    "rgba(232,69,60,0.30)",
  bgDeep:        "#dcdcdc",

  // Texte
  textPrimary:   "#2d2d2d",
  textSecondary: "#555555",
  textMuted:     "#999999",
  textAccent:    "#e8453c",
  textOnRed:     "#ffffff",

  // Ombres Neumorphism Light
  shadowLight: "#ffffff",   // Ombre claire (haut-gauche)
  shadowDark:  "#c8c8c8",   // Ombre sombre (bas-droite)

  // Bordures
  borderSubtle:  "rgba(0,0,0,0.06)",
  borderMedium:  "rgba(0,0,0,0.12)",
  borderRed:     "rgba(232,69,60,0.30)",

  // Statuts
  success:  "#27ae60",
  warning:  "#f39c12",
  info:     "#2980b9",

  // Dégradés (pour compatibilité)
  gradMagentaCyan: ["#e8453c", "#ff6b6b"] as [string, string],
  gradOrangeGold:  ["#f39c12", "#e8453c"] as [string, string],
  gradCyanMagenta: ["#2980b9", "#e8453c"] as [string, string],
} as const;

// ─── Ombres Neumorphism Light ─────────────────────────────────────────────────

/** Ombre en relief standard (carte/bouton) */
export const neuShadow = {
  shadowColor: NEU.shadowDark,
  shadowOffset: { width: 6, height: 6 },
  shadowOpacity: 1,
  shadowRadius: 12,
  elevation: 8,
} as const;

/** Ombre en relief légère */
export const neuShadowSm = {
  shadowColor: NEU.shadowDark,
  shadowOffset: { width: 4, height: 4 },
  shadowOpacity: 0.9,
  shadowRadius: 8,
  elevation: 5,
} as const;

/** Ombre en relief forte */
export const neuShadowLg = {
  shadowColor: NEU.shadowDark,
  shadowOffset: { width: 8, height: 8 },
  shadowOpacity: 1,
  shadowRadius: 18,
  elevation: 12,
} as const;

/** Ombre en creux (input, inset) */
export const neuShadowInset = {
  shadowColor: NEU.shadowDark,
  shadowOffset: { width: 2, height: 2 },
  shadowOpacity: 0.8,
  shadowRadius: 5,
  elevation: 2,
} as const;

// ─── Styles partagés ─────────────────────────────────────────────────────────

export const neuStyles = StyleSheet.create({
  /** Carte en relief standard */
  card: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: NEU.shadowLight,
    ...neuShadow,
  },

  /** Carte avec accent rouge */
  cardRed: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: NEU.redBorder,
    ...neuShadow,
  },

  /** Carte en creux */
  cardMagenta: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: NEU.redBorder,
    ...neuShadow,
  },

  /** Carte cyan */
  cardCyan: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(41,128,185,0.25)",
    ...neuShadow,
  },

  /** Input en creux */
  input: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: NEU.shadowLight,
    ...neuShadowInset,
  },

  /** Badge rouge */
  badgeMagenta: {
    backgroundColor: NEU.redBg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: NEU.redBorder,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },

  /** Badge bleu */
  badgeCyan: {
    backgroundColor: "rgba(41,128,185,0.10)",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "rgba(41,128,185,0.30)",
    paddingHorizontal: 10,
    paddingVertical: 4,
  },

  /** Badge orange */
  badgeOrange: {
    backgroundColor: "rgba(243,156,18,0.10)",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "rgba(243,156,18,0.30)",
    paddingHorizontal: 10,
    paddingVertical: 4,
  },

  /** Divider */
  dividerMagenta: {
    height: 1,
    backgroundColor: "rgba(232,69,60,0.20)",
  },

  dividerCyan: {
    height: 1,
    backgroundColor: "rgba(0,0,0,0.08)",
  },
});
