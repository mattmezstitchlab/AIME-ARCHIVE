import { describe, it, expect, vi } from "vitest";
import {
  getCountdown,
  getCategoryLabel,
  getCategoryIcon,
  formatTime,
  getCurrentAgendaItem,
  analyzeDietaryRestrictions,
  cycleVendorStatus,
  getVendorStatusLabel,
  getVendorStatusColor,
  type AgendaItem,
  type EventCategory,
  type GuestRegistration,
  type Vendor,
} from "../lib/wedding-store";

// ─── Countdown ────────────────────────────────────────────────────────────────

describe("getCountdown", () => {
  it("returns isPast=true for past dates", () => {
    const past = new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString();
    const result = getCountdown(past);
    expect(result.isPast).toBe(true);
    expect(result.days).toBe(0);
    expect(result.hours).toBe(0);
  });

  it("returns positive values for future dates", () => {
    const future = new Date(Date.now() + 1000 * 60 * 60 * 24 * 10).toISOString();
    const result = getCountdown(future);
    expect(result.isPast).toBe(false);
    expect(result.days).toBeGreaterThan(0);
  });

  it("returns correct structure", () => {
    const future = new Date(Date.now() + 1000 * 60 * 60 * 2).toISOString();
    const result = getCountdown(future);
    expect(result).toHaveProperty("days");
    expect(result).toHaveProperty("hours");
    expect(result).toHaveProperty("minutes");
    expect(result).toHaveProperty("seconds");
    expect(result).toHaveProperty("isPast");
  });

  it("returns all zeros for isPast", () => {
    const past = new Date(Date.now() - 1).toISOString();
    const result = getCountdown(past);
    expect(result.days).toBe(0);
    expect(result.hours).toBe(0);
    expect(result.minutes).toBe(0);
    expect(result.seconds).toBe(0);
  });
});

// ─── Category Helpers ─────────────────────────────────────────────────────────

describe("getCategoryLabel", () => {
  it("returns correct French labels", () => {
    expect(getCategoryLabel("ceremony")).toBe("Cérémonie");
    expect(getCategoryLabel("cocktail")).toBe("Cocktail");
    expect(getCategoryLabel("dinner")).toBe("Dîner");
    expect(getCategoryLabel("music")).toBe("Musique");
    expect(getCategoryLabel("photo")).toBe("Photo");
    expect(getCategoryLabel("logistics")).toBe("Logistique");
    expect(getCategoryLabel("other")).toBe("Autre");
  });
});

describe("getCategoryIcon", () => {
  it("returns a non-empty string for all categories", () => {
    const categories: EventCategory[] = [
      "ceremony", "cocktail", "dinner", "music", "photo", "logistics", "other",
    ];
    for (const cat of categories) {
      const icon = getCategoryIcon(cat);
      expect(typeof icon).toBe("string");
      expect(icon.length).toBeGreaterThan(0);
    }
  });
});

// ─── Format Time ─────────────────────────────────────────────────────────────

describe("formatTime", () => {
  it("formats ISO date to French locale string", () => {
    const date = "2026-06-14T10:00:00.000Z";
    const result = formatTime(date);
    expect(result).toContain("2026");
    expect(result.length).toBeGreaterThan(5);
  });
});

// ─── Current Agenda Item ──────────────────────────────────────────────────────

describe("getCurrentAgendaItem", () => {
  const mockAgenda: AgendaItem[] = [
    { id: "a1", time: "09:00", endTime: "10:00", title: "Cérémonie", category: "ceremony" },
    { id: "a2", time: "13:00", endTime: "16:00", title: "Cocktail", category: "cocktail" },
    { id: "a3", time: "17:00", endTime: "21:00", title: "Dîner", category: "dinner" },
  ];

  it("returns null for empty agenda", () => {
    const result = getCurrentAgendaItem([]);
    expect(result).toBeNull();
  });

  it("returns agenda item structure when found", () => {
    const result = getCurrentAgendaItem(mockAgenda);
    if (result !== null) {
      expect(result).toHaveProperty("id");
      expect(result).toHaveProperty("time");
      expect(result).toHaveProperty("title");
      expect(result).toHaveProperty("category");
    } else {
      expect(result).toBeNull();
    }
  });
});

// ─── AgendaItem Structure ─────────────────────────────────────────────────────

describe("AgendaItem structure", () => {
  it("has required fields", () => {
    const item: AgendaItem = {
      id: "test-1",
      time: "10:00",
      title: "Test Event",
      category: "ceremony",
    };
    expect(item.id).toBe("test-1");
    expect(item.time).toBe("10:00");
    expect(item.title).toBe("Test Event");
    expect(item.category).toBe("ceremony");
  });

  it("supports optional fields", () => {
    const item: AgendaItem = {
      id: "test-2",
      time: "14:00",
      endTime: "16:00",
      title: "Full Event",
      description: "A description",
      speaker: "John Doe",
      category: "music",
      location: "Main Hall",
      isLive: true,
    };
    expect(item.endTime).toBe("16:00");
    expect(item.description).toBe("A description");
    expect(item.speaker).toBe("John Doe");
    expect(item.location).toBe("Main Hall");
    expect(item.isLive).toBe(true);
  });
});

// ─── Dietary Analysis (Admin Feature) ────────────────────────────────────────

const makeReg = (
  id: string,
  firstName: string,
  lastName: string,
  diet?: string
): GuestRegistration => ({
  id,
  firstName,
  lastName,
  email: `${id}@test.fr`,
  dietaryRestrictions: diet,
  attendsCeremony: true,
  attendsCocktail: true,
  attendsDinner: true,
  submittedAt: new Date().toISOString(),
});

describe("analyzeDietaryRestrictions", () => {
  it("returns empty array for empty registrations", () => {
    const summary = analyzeDietaryRestrictions([]);
    expect(summary).toHaveLength(0);
  });

  it("groups vegetarian and vegan guests together", () => {
    const regs = [
      makeReg("1", "Alice", "Martin", "Végétarienne"),
      makeReg("2", "Bob", "Dupont", "Vegan"),
    ];
    const summary = analyzeDietaryRestrictions(regs);
    const vegGroup = summary.find((g) => g.label === "Végétarien / Vegan");
    expect(vegGroup).toBeDefined();
    expect(vegGroup!.count).toBe(2);
    expect(vegGroup!.guests).toContain("Alice Martin");
    expect(vegGroup!.guests).toContain("Bob Dupont");
  });

  it("groups gluten-free guests correctly", () => {
    const regs = [makeReg("1", "Claire", "Bernard", "Sans gluten")];
    const summary = analyzeDietaryRestrictions(regs);
    const group = summary.find((g) => g.label === "Sans gluten");
    expect(group).toBeDefined();
    expect(group!.count).toBe(1);
    expect(group!.guests).toContain("Claire Bernard");
  });

  it("groups nut allergy guests correctly", () => {
    const regs = [makeReg("1", "Jean", "Petit", "Allergie aux noix")];
    const summary = analyzeDietaryRestrictions(regs);
    const group = summary.find((g) => g.label === "Allergie aux noix");
    expect(group).toBeDefined();
    expect(group!.count).toBe(1);
  });

  it("groups guests with no restriction correctly", () => {
    const regs = [
      makeReg("1", "Marc", "Leroy", undefined),
      makeReg("2", "Julie", "Simon", ""),
    ];
    const summary = analyzeDietaryRestrictions(regs);
    const noRestriction = summary.find((g) => g.label === "Aucune restriction");
    expect(noRestriction).toBeDefined();
    expect(noRestriction!.count).toBe(2);
  });

  it("returns groups sorted by count descending", () => {
    const regs = [
      makeReg("1", "A", "A", "Végétarienne"),
      makeReg("2", "B", "B", "Vegan"),
      makeReg("3", "C", "C", "Sans gluten"),
    ];
    const summary = analyzeDietaryRestrictions(regs);
    for (let i = 1; i < summary.length; i++) {
      expect(summary[i - 1].count).toBeGreaterThanOrEqual(summary[i].count);
    }
  });

  it("handles halal and casher restrictions", () => {
    const regs = [
      makeReg("1", "A", "A", "Halal"),
      makeReg("2", "B", "B", "Casher"),
    ];
    const summary = analyzeDietaryRestrictions(regs);
    expect(summary.find((g) => g.label === "Halal")).toBeDefined();
    expect(summary.find((g) => g.label === "Casher")).toBeDefined();
  });

  it("handles lactose intolerance", () => {
    const regs = [makeReg("1", "A", "A", "Sans lactose")];
    const summary = analyzeDietaryRestrictions(regs);
    expect(summary.find((g) => g.label === "Sans lactose")).toBeDefined();
  });

  it("each group has a color property", () => {
    const regs = [makeReg("1", "A", "A", "Végétarienne")];
    const summary = analyzeDietaryRestrictions(regs);
    for (const group of summary) {
      expect(typeof group.color).toBe("string");
      expect(group.color.length).toBeGreaterThan(0);
    }
  });
});

// ─── Vendor Status Helpers ────────────────────────────────────────────────────

describe("cycleVendorStatus", () => {
  it("cycles from pending to confirmed", () => {
    expect(cycleVendorStatus("pending")).toBe("confirmed");
  });

  it("cycles from confirmed to arrived", () => {
    expect(cycleVendorStatus("confirmed")).toBe("arrived");
  });

  it("cycles from arrived back to pending", () => {
    expect(cycleVendorStatus("arrived")).toBe("pending");
  });

  it("covers all three states in a full cycle", () => {
    let status: Vendor["status"] = "pending";
    status = cycleVendorStatus(status); // → confirmed
    expect(status).toBe("confirmed");
    status = cycleVendorStatus(status); // → arrived
    expect(status).toBe("arrived");
    status = cycleVendorStatus(status); // → pending
    expect(status).toBe("pending");
  });
});

describe("getVendorStatusLabel", () => {
  it("returns correct French label for pending", () => {
    expect(getVendorStatusLabel("pending")).toBe("En attente");
  });

  it("returns correct French label for confirmed", () => {
    expect(getVendorStatusLabel("confirmed")).toBe("Confirmé");
  });

  it("returns correct French label for arrived", () => {
    expect(getVendorStatusLabel("arrived")).toBe("Arrivé");
  });
});

describe("getVendorStatusColor", () => {
  it("returns a hex color string for each status", () => {
    const statuses: Vendor["status"][] = ["pending", "confirmed", "arrived"];
    for (const status of statuses) {
      const color = getVendorStatusColor(status);
      expect(typeof color).toBe("string");
      expect(color).toMatch(/^#[0-9a-fA-F]{3,8}$/);
    }
  });

  it("returns green for arrived status", () => {
    expect(getVendorStatusColor("arrived")).toBe("#4ade80");
  });

  it("returns gold for confirmed status", () => {
    expect(getVendorStatusColor("confirmed")).toBe("#c9a96e");
  });

  it("returns yellow for pending status", () => {
    expect(getVendorStatusColor("pending")).toBe("#FBBF24");
  });
});

describe("Vendor type structure", () => {
  it("has required fields", () => {
    const vendor: Vendor = {
      id: "v1",
      name: "Studio Lumière",
      role: "Photographe",
      status: "confirmed",
      category: "photo",
    };
    expect(vendor.id).toBe("v1");
    expect(vendor.name).toBe("Studio Lumière");
    expect(vendor.role).toBe("Photographe");
    expect(vendor.status).toBe("confirmed");
    expect(vendor.category).toBe("photo");
  });

  it("supports optional contact and description fields", () => {
    const vendor: Vendor = {
      id: "v2",
      name: "Quatuor Harmonie",
      role: "Musiciens",
      status: "arrived",
      category: "music",
      phone: "06 12 34 56 78",
      email: "contact@quatuor.fr",
      description: "Quatuor à cordes classique",
      arrivalTime: "10:00",
    };
    expect(vendor.phone).toBe("06 12 34 56 78");
    expect(vendor.email).toBe("contact@quatuor.fr");
    expect(vendor.description).toBe("Quatuor à cordes classique");
    expect(vendor.arrivalTime).toBe("10:00");
  });
});

// ─── Tests PIN Guard ───────────────────────────────────────────────────────────

describe("PIN Guard logic", () => {
  it("should validate a 4-digit PIN format", () => {
    const pin = "1234";
    expect(pin).toHaveLength(4);
    expect(/^\d{4}$/.test(pin)).toBe(true);
  });

  it("should reject PIN mismatch during setup", () => {
    const pin1 = "1234" as string;
    const pin2 = "5678" as string;
    expect(pin1 === pin2).toBe(false);
  });

  it("should accept matching PIN during setup", () => {
    const pin1 = "9876" as string;
    const pin2 = "9876" as string;
    expect(pin1 === pin2).toBe(true);
  });

  it("should reject wrong PIN on unlock", () => {
    const stored = "1111" as string;
    const entered = "4321" as string;
    expect(stored === entered).toBe(false);
  });

  it("should accept correct PIN on unlock", () => {
    expect("4321" === "4321").toBe(true);
  });
});

// ─── Tests SmartRipple ─────────────────────────────────────────────────────────

function addMinutesToTime(time: string, minutes: number): string {
  const [h, m] = time.split(":").map(Number);
  const total = h * 60 + m + minutes;
  const newH = Math.floor(total / 60) % 24;
  const newM = total % 60;
  return `${String(newH).padStart(2, "0")}:${String(newM).padStart(2, "0")}`;
}

describe("SmartRipple time propagation", () => {
  it("should add 15 minutes to 10:00 → 10:15", () => {
    expect(addMinutesToTime("10:00", 15)).toBe("10:15");
  });

  it("should handle hour rollover: 11:50 + 20min → 12:10", () => {
    expect(addMinutesToTime("11:50", 20)).toBe("12:10");
  });

  it("should handle midnight rollover: 23:50 + 15min → 00:05", () => {
    expect(addMinutesToTime("23:50", 15)).toBe("00:05");
  });

  it("should propagate delay only to items at or after trigger time", () => {
    const items = [
      { id: "1", time: "09:00" },
      { id: "2", time: "10:00" },
      { id: "3", time: "11:00" },
      { id: "4", time: "14:00" },
    ];
    const triggerTime = "10:00";
    const delay = 30;
    const updated = items.map(item =>
      item.time >= triggerTime
        ? { ...item, time: addMinutesToTime(item.time, delay) }
        : item
    );
    expect(updated[0].time).toBe("09:00");
    expect(updated[1].time).toBe("10:30");
    expect(updated[2].time).toBe("11:30");
    expect(updated[3].time).toBe("14:30");
  });

  it("should not affect items before trigger time", () => {
    const items = [
      { id: "1", time: "08:00" },
      { id: "2", time: "09:00" },
    ];
    const triggerTime = "10:00";
    const delay = 30;
    const updated = items.map(item =>
      item.time >= triggerTime
        ? { ...item, time: addMinutesToTime(item.time, delay) }
        : item
    );
    expect(updated[0].time).toBe("08:00");
    expect(updated[1].time).toBe("09:00");
  });
});

// ─── Tests Event Settings ──────────────────────────────────────────────────────

describe("Event settings update", () => {
  it("should merge event fields correctly", () => {
    const base = {
      name: "Mariage Sophie & Alexandre",
      date: "2026-06-14T10:00:00.000Z",
      venue: "Château de la Forêt",
      address: "1 route des Bois",
      dressCode: "Tenue de soirée",
    };
    const updates = { name: "Mariage Léa & Marc", venue: "Villa Méditerranée" };
    const merged = { ...base, ...updates };
    expect(merged.name).toBe("Mariage Léa & Marc");
    expect(merged.venue).toBe("Villa Méditerranée");
    expect(merged.date).toBe("2026-06-14T10:00:00.000Z");
    expect(merged.dressCode).toBe("Tenue de soirée");
  });

  it("should keep original date when not updated", () => {
    const base = { date: "2026-06-14T10:00:00.000Z", name: "Mariage" };
    const merged = { ...base, name: "Nouveau Mariage" };
    expect(merged.date).toBe("2026-06-14T10:00:00.000Z");
  });
});
