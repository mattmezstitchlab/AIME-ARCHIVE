# D Day Wedding Orchestrator — TODO

- [x] Générer logo app (icône dorée sur fond sombre)
- [x] Configurer thème couleurs (doré, noir profond)
- [x] Configurer app.config.ts (nom, slug, logo)
- [x] Configurer icon-symbol.tsx avec icônes nécessaires
- [x] Créer écran Onboarding / sélection de rôle
- [x] Créer écran Accueil avec header et compte à rebours
- [x] Créer écran Timeline/Programme avec ligne dorée verticale
- [x] Créer composant EventCard (carte événement alternée)
- [x] Créer badge "EN COURS" pulsant
- [x] Créer écran Prestataires avec liste et fiches
- [x] Créer écran Inscription avec formulaire complet
- [x] Créer écran Informations pratiques
- [x] Configurer navigation par onglets (5 tabs)
- [x] Persister données avec AsyncStorage
- [x] Ajouter données de démonstration (mariage exemple)
- [x] Créer composant AppHeader réutilisable
- [x] Créer lib/app-context.tsx (contexte global)
- [x] Créer lib/wedding-store.ts (store de données)
- [x] Écrire tests unitaires (9 tests passés)
- [x] Tester tous les flux utilisateur

## Espace Administration (Futurs Mariés)

- [x] Créer écran admin protégé (accès réservé au rôle "couple")
- [x] Tableau de bord admin : stats inscriptions, présences, régimes
- [x] Liste des inscrits avec détails complets
- [x] Vue régimes alimentaires groupés (végétarien, allergies, etc.)
- [x] Éditeur d'agenda : modifier titre, heure, description, intervenant
- [x] Ajouter un nouvel événement à l'agenda
- [x] Supprimer un événement de l'agenda
- [x] Réordonner les événements (tri automatique par heure)
- [x] Mettre à jour le store AsyncStorage après chaque modification
- [x] Accès admin depuis l'onglet Accueil (bouton visible uniquement pour le rôle "couple")
- [x] Écrire tests unitaires pour les nouvelles fonctionnalités admin (20 tests passent)

## Onglet Prestataires Admin (5ème onglet)

- [x] Ajouter l'onglet "Prestataires" dans la barre de navigation admin
- [x] Liste des prestataires avec statut visuel (Arrivé / Confirmé / En attente)
- [x] Changement de statut en un tap (cycle : En attente → Confirmé → Arrivé)
- [x] Fiche détail prestataire (nom, rôle, téléphone, email, heure d'arrivée prévue)
- [x] Appel téléphonique direct depuis la fiche (lien tel:)
- [x] Envoi d'email direct depuis la fiche (lien mailto:)
- [x] Ajouter un nouveau prestataire depuis l'admin
- [x] Modifier les informations d'un prestataire existant
- [x] Supprimer un prestataire
- [x] Résumé des statuts en haut de l'onglet (X arrivés / X confirmés / X en attente)
- [x] Persistance des statuts dans AsyncStorage
- [x] Mettre à jour les fonctions store pour les opérations CRUD prestataires
- [x] Écrire tests unitaires pour les nouvelles fonctions store prestataires (33 tests passent)

## Sprint Différenciation — Fonctionnalités Clés

### Fondations Critiques
- [x] Synchronisation backend multi-appareils (PostgreSQL + tRPC) — événement, agenda, prestataires, inscriptions
- [x] Protection espace admin par code PIN à 4 chiffres (AsyncStorage)
- [x] Onglet "Événement" dans admin : modifier nom, date, lieu, dress code, contacts depuis l'app

### Coordination Temps Réel
- [x] SmartRipple : signaler un retard sur une étape et recalculer tous les horaires suivants en cascade
- [x] Onglet Alertes admin : diffuser un message broadcast à tous les participants
- [ ] Mode Coordinateur Fantôme : 4ème rôle avec supervision toutes vues + envoi d'alertes broadcast
- [ ] Vue Prestataire dédiée : heure d'arrivée en grand, plan d'accès, checklist tâches du jour
- [ ] Bouton "Je suis arrivé·e" pour les prestataires (mise à jour statut en temps réel)

### Engagement Invités
- [ ] Galerie photo collaborative : invités uploadent photos, album commun visible par tous
- [ ] Capsule sonore : enregistrement message vocal 30s par invité, compilation pour les mariés
- [ ] QR Code d'invitation personnalisé par rôle (pré-configure le rôle à l'ouverture)
- [ ] QR Code invité : pré-remplit le formulaire d'inscription avec le nom

### Export & Partage
- [ ] Export PDF du programme complet (expo-print) depuis l'espace admin
- [ ] Export CSV des inscriptions et régimes alimentaires
- [ ] Partage natif iOS/Android (expo-sharing) depuis l'espace admin

### Notifications Push
- [ ] Rappel automatique 30 min avant chaque étape du programme
- [ ] Notification broadcast "La cérémonie commence dans 10 minutes"
- [ ] Alerte retard push vers tous les prestataires concernés

### Qualité & Robustesse
- [ ] Validation email complète (regex) dans le formulaire d'inscription
- [ ] Détection de doublon d'inscription (même email)
- [ ] Segmentation vues par rôle (onglets différents selon couple/prestataire/invité)
- [ ] Gestion explicite des erreurs AsyncStorage avec récupération

## Refactoring Dark Neumorphism

- [ ] Définir tokens de design Neumorphism (couleurs, ombres, rayons)
- [ ] Mettre à jour theme.config.js avec palette Neumorphism sombre
- [ ] Créer lib/neu-styles.ts — styles partagés (ombres, reliefs, cartes)
- [ ] Refactoriser écran Onboarding
- [ ] Refactoriser écran Accueil (compte à rebours, cartes, header)
- [ ] Refactoriser écran Agenda/Timeline
- [ ] Refactoriser écran Prestataires
- [ ] Refactoriser écran Inscription
- [ ] Refactoriser écran Informations
- [ ] Refactoriser tab bar (icônes en relief, onglet actif dégradé)
- [ ] Refactoriser composant AppHeader
- [ ] Refactoriser espace Admin (PIN, dashboard, onglets)

## Sprint Neumorphism V2 + Écran Prestataire

- [x] Corriger la palette Neumorphism : fond #1e1e2e, surface #272740, ombres plus marquées
- [x] Corriger les tokens NEU pour correspondre exactement à l'image de référence
- [x] Dégradé rose-or (#c9a96e → #e8a0a0) sur icônes actives tab bar via LinearGradient SVG
- [x] Icônes tab bar inactives en gris neutre, actives avec conteneur en relief doré + glow
- [x] Animation d'enfoncement Neumorphism sur boutons primaires (shadowRadius diminue + scale 0.97)
- [x] Composant NeuButton réutilisable avec animation reanimated
- [x] Appliquer NeuButton sur boutons principaux de l'app (onboarding, vendor-dashboard)
- [x] Créer écran dédié Prestataire (heure d'arrivée en grand, plan d'accès, checklist tâches)
- [x] Checklist interactive avec cases à cocher persistées en AsyncStorage
- [x] Accès à l'écran Prestataire depuis l'accueil (rôle "Prestataire")

## Sprint Dark Neon Neumorphism + QR + PDF + Push

- [ ] Appliquer palette Dark Neon : fond #1a1a2e, magenta #e91e8c, cyan #00d4ff, orange #ff6b35
- [ ] Mettre à jour neu-styles.ts avec les nouvelles couleurs néon
- [ ] Mettre à jour theme.config.js avec la palette néon
- [ ] Refactoriser tous les écrans avec la nouvelle palette
- [ ] QR Code par rôle : générer depuis l'admin un QR code unique par rôle
- [ ] Partage du QR Code via expo-sharing
- [ ] Écran de scan QR Code qui pré-configure le rôle automatiquement
- [ ] Export PDF du programme via expo-print depuis l'onglet Programme admin
- [ ] Notifications push : rappel 30 min avant chaque étape du programme
- [ ] Notification broadcast "La cérémonie commence dans 10 minutes"
