# Rapport d'Audit — D Day Wedding Orchestrator

**Version auditée :** 3aa251aa → post-suppression logo  
**Date :** 18 mai 2026  
**Périmètre :** Application mobile React Native / Expo SDK 54 — 6 006 lignes de code source, 9 écrans, 33 tests unitaires

---

## 1. Ce qui fonctionne réellement

### 1.1 Onboarding & Gestion des rôles

L'écran d'onboarding est pleinement opérationnel. La sélection du rôle (Futurs Mariés, Prestataire, Invité·e) est persistée dans AsyncStorage via `saveUserRole()` et rechargée à chaque démarrage. La redirection automatique vers `/(tabs)` si un rôle est déjà enregistré fonctionne correctement, évitant de redemander le rôle à chaque ouverture. Le monogramme typographique "D·D" remplace désormais le logo image sur l'onboarding et dans le header global.

### 1.2 Écran d'Accueil

Le compte à rebours en temps réel (jours, heures, minutes, secondes) est calculé dynamiquement via `getCountdown()` et se met à jour toutes les secondes grâce à un `setInterval`. Le résumé du programme (3 prochaines étapes) et les accès rapides vers les autres onglets fonctionnent. Le bouton "Espace Admin" n'est visible que pour le rôle `couple`, ce qui constitue un premier niveau de contrôle d'accès.

### 1.3 Programme / Timeline

La timeline verticale avec cartes alternées gauche/droite est rendue correctement. Le badge pulsant "EN COURS" s'affiche sur l'étape dont l'heure de début ≤ heure actuelle < heure de fin, calculé via `getCurrentAgendaItem()`. Les filtres par catégorie (Cérémonie, Cocktail, Dîner, Musique, Photo, Logistique) sont fonctionnels. Le dépliage des cartes pour afficher description, intervenant et lieu fonctionne via un état local `expandedId`. Les 10 étapes de démonstration sont affichées et triées par heure.

### 1.4 Prestataires (vue publique)

La liste des prestataires avec filtres par catégorie, badges de statut colorés et vue détail interne est opérationnelle. Les coordonnées (téléphone, email) sont affichées en texte. La vue est strictement consultative pour les rôles non-admin.

### 1.5 Formulaire d'Inscription

Le formulaire complet (identité, présences, accompagnant, régime alimentaire, message) fonctionne avec une validation minimale (prénom, nom, email requis + présence de "@"). La soumission appelle `addRegistration()` qui persiste dans AsyncStorage. L'écran de confirmation avec récapitulatif des moments sélectionnés s'affiche correctement. Le bouton "Nouvelle inscription" réinitialise le formulaire.

### 1.6 Informations Pratiques

L'écran affiche le lieu, l'adresse, le dress code, les informations parking/hébergement et les contacts de l'organisateur. Les liens `tel:`, `mailto:` et `https://maps.google.com` fonctionnent via `Linking.openURL`. Le mini-programme des 5 premières étapes est affiché en bas de l'écran.

### 1.7 Espace Administration (Futurs Mariés uniquement)

L'espace admin est accessible depuis l'accueil uniquement pour le rôle `couple`. Il contient 5 onglets entièrement fonctionnels :

| Onglet | Fonctionnalités réellement opérationnelles |
|---|---|
| **Tableau de bord** | Stats globales, barres de présence par moment, liste des messages invités |
| **Inscrits** | Liste avec recherche textuelle, fiche détail par invité, suppression avec confirmation |
| **Régimes** | Analyse groupée avec barres visuelles, liste dépliable par groupe, liste brute |
| **Programme** | Ajout, modification, suppression d'étapes ; formulaire complet ; tri automatique par heure |
| **Prestataires** | Résumé statuts, liste avec cycle de statut en 1 tap, fiche détail, ajout/modification/suppression, appel/email directs |

Toutes les mutations passent par le contexte global `AppProvider` et rappellent `refreshEvent()` pour mettre à jour l'UI en temps réel. La persistance AsyncStorage est assurée sur toutes les opérations CRUD.

### 1.8 Infrastructure technique

Le projet compile sans erreur TypeScript (LSP : 0 erreur). 33 tests unitaires passent (helpers du store, types, fonctions utilitaires). Le thème sombre/doré est cohérent sur tous les écrans. La navigation par onglets fonctionne avec redirection automatique vers l'onboarding si aucun rôle n'est défini.

---

## 2. Ce qui n'est PAS implémenté

### 2.1 Synchronisation multi-appareils et backend

L'intégralité des données (événement, inscriptions, prestataires, agenda) est stockée **localement** dans AsyncStorage sur l'appareil. Il n'y a aucune synchronisation avec le backend disponible dans le projet (PostgreSQL + tRPC). Conséquence directe : deux utilisateurs sur deux téléphones différents ne voient pas les mêmes données. Les modifications faites par les futurs mariés sur leur téléphone ne sont pas visibles par les prestataires ou les invités sur les leurs.

### 2.2 Authentification et contrôle d'accès réel

Le "rôle" est une simple chaîne de caractères stockée localement, sans aucune vérification d'identité. N'importe qui peut choisir le rôle "Futurs Mariés" et accéder à l'espace admin. Il n'y a pas de code PIN, de mot de passe, ni d'authentification OAuth pour protéger l'espace admin. Le fichier `app/oauth/callback.tsx` existe dans le projet mais n'est pas intégré au parcours principal.

### 2.3 Notifications push

Aucune notification push n'est implémentée. Le package `expo-notifications` est installé dans `package.json` mais n'est utilisé nulle part dans le code de l'application. Il n'y a pas de rappel automatique avant les étapes du programme, pas d'alerte en cas de retard, pas de message broadcast aux invités.

### 2.4 Validation robuste du formulaire d'inscription

La validation du formulaire se limite à vérifier que prénom, nom et email sont non vides et que l'email contient "@". Il n'y a pas de vérification de format d'email complet (regex), pas de détection de doublon (un même invité peut s'inscrire plusieurs fois), pas de validation du numéro de téléphone, et pas de limite sur la longueur des champs.

### 2.5 Personnalisation de l'événement depuis l'app

Il n'existe pas d'écran permettant aux futurs mariés de modifier les informations de base de l'événement (nom, date, lieu, dress code, contacts) depuis l'interface. Ces données ne sont modifiables qu'en éditant directement le fichier `lib/wedding-store.ts` dans le code source.

### 2.6 Partage et export

Aucune fonctionnalité de partage n'est implémentée : pas d'export PDF du programme, pas d'export CSV des inscriptions ou des régimes alimentaires, pas de partage via le système natif iOS/Android (`expo-sharing`), pas de génération de QR code d'invitation.

### 2.7 Galerie photo et médias

Il n'y a pas de fonctionnalité de partage de photos entre invités, pas de galerie de l'événement, pas de possibilité pour les invités d'uploader des photos depuis l'app. Le champ `heroImageUrl` existe dans le type `WeddingEvent` mais n'est jamais utilisé dans l'UI.

### 2.8 Mode hors-ligne explicite et gestion des erreurs réseau

Bien que les données soient locales (ce qui garantit un fonctionnement hors-ligne de fait), il n'y a pas de gestion explicite des erreurs AsyncStorage, pas d'indicateur de connectivité, et pas de mécanisme de récupération si les données sont corrompues (sauf le fallback vers `DEMO_EVENT`).

### 2.9 Segmentation des vues par rôle

Tous les onglets (Programme, Prestataires, Inscription, Infos) sont visibles pour tous les rôles une fois le rôle choisi. Il n'y a pas de vue spécifique "Prestataire" qui afficherait uniquement les informations pertinentes pour ce rôle (heure d'arrivée, lieu de déchargement, contact coordinateur), ni de vue "Invité" simplifiée sans les détails opérationnels.

### 2.10 Gestion des retards et recalcul de timeline

Il n'y a pas de mécanisme pour signaler un retard sur une étape et recalculer automatiquement les horaires suivants. C'est précisément la fonctionnalité centrale d'EventSync (voir section 4), et son absence est la lacune fonctionnelle la plus critique pour un usage réel le jour J.

### 2.11 Communication intégrée

Il n'y a pas de messagerie interne entre les rôles, pas de canal de communication coordinateur ↔ prestataires, et pas de système d'annonces broadcast (ex. "La cérémonie commence dans 10 minutes").

### 2.12 Tests de composants et tests end-to-end

Les 33 tests existants couvrent uniquement les fonctions utilitaires du store (helpers, types, calculs). Il n'y a aucun test de composant React Native, aucun test de navigation, aucun test des formulaires, et aucun test end-to-end simulant un parcours utilisateur complet.

---

## 3. Analyse concurrentielle

### 3.1 Panorama du marché

Le marché des applications de mariage se divise en deux segments distincts qui ne se chevauchent presque jamais : les **plateformes de planification pré-mariage** (The Knot, Zola, WeddingWire, Joy, Bridebook) et les **outils de coordination jour J** (EventSync, Timeline Genius, Aisle Planner). D Day Wedding Orchestrator se positionne à l'intersection de ces deux segments, ce qui constitue à la fois sa singularité et son défi.

| Application | Segment | Forces | Faiblesses |
|---|---|---|---|
| **The Knot** | Planification | Annuaire prestataires massif, budget, liste invités, RSVP | Pas de coordination temps réel jour J, interface surchargée |
| **Zola** | Planification | Design soigné, registre cadeaux, site web couple | Orienté pré-mariage uniquement, pas de gestion prestataires jour J |
| **Joy** | Planification + Invités | Site web couple, RSVP intelligent, app invités, partage photos | Pas de suivi prestataires, pas de timeline opérationnelle |
| **Appy Couple** | Invités | App dédiée invités, notifications push, partage photos | Pas de gestion prestataires, pas d'espace admin coordinateur |
| **Bridebook** | Planification | Budget, checklist, annuaire UK | Pas d'outil jour J, pas de coordination prestataires |
| **EventSync** | Coordination jour J | Timeline en temps réel, "SmartRipple" (recalcul automatique en cascade), vues différenciées coordinateur/prestataires/couple | Uniquement pour coordinateurs professionnels, pas d'espace invités |
| **WeddingHappy** | Planification | Tâches, paiements, prestataires | Pas de coordination temps réel, pas d'app invités |
| **D Day Wedding Orchestrator** | **Hybride** | Tous les rôles dans une seule app, admin complet, thème luxe, offline-first | Pas de sync multi-appareils, pas de notifications, pas de recalcul timeline |

### 3.2 La lacune que personne ne comble vraiment

La recherche révèle une frustration récurrente exprimée par les coordinateurs de mariage : **"Si je pouvais avoir l'app parfaite pour le jour J, elle garderait les timelines et les arrivées prestataires à jour en temps réel, enverrait des rappels, et aurait un chat en direct."** EventSync s'approche de cet idéal pour les coordinateurs professionnels, mais ne propose pas d'expérience unifiée pour les invités et les futurs mariés dans la même application.

Joy offre la meilleure expérience invités mais ignore complètement la coordination opérationnelle. EventSync résout brillamment la coordination mais exclut les invités. **Aucune application ne réunit les trois rôles (couple, prestataires, invités) dans une interface cohérente avec synchronisation temps réel.**

---

## 4. Idées différenciantes — Ce qui ferait vraiment la différence

### 4.1 Le "SmartRipple" pour mariage orchestral

**Concept :** Inspiré d'EventSync, implémenter un mécanisme de recalcul en cascade. Lorsque les futurs mariés (ou le coordinateur) signalent un retard sur une étape ("La cérémonie a 20 minutes de retard"), l'application recalcule automatiquement tous les horaires suivants, envoie une notification push à tous les prestataires concernés, et affiche un bandeau d'alerte sur l'écran Programme de tous les invités. C'est la fonctionnalité qui transforme une app de consultation en un véritable outil de pilotage.

### 4.2 QR Code d'invitation personnalisé par rôle

**Concept :** Générer un QR code unique par rôle (ou même par prestataire) que les futurs mariés partagent avant l'événement. Lorsqu'un prestataire scanne son QR code, l'app s'ouvre directement avec son rôle pré-configuré et ses informations spécifiques (heure d'arrivée, lieu de déchargement, contact coordinateur). Pour les invités, le QR code pré-remplit le formulaire d'inscription avec leur nom. Cela élimine la friction de l'onboarding et garantit que chaque utilisateur voit exactement ce qui le concerne.

### 4.3 Vue "Prestataire" dédiée avec checklist d'arrivée

**Concept :** Lorsqu'un prestataire se connecte, il voit une interface radicalement différente : son heure d'arrivée en grand, un plan d'accès, une checklist de ses tâches du jour (ex. "Installer le matériel son avant 10h", "Rejoindre la terrasse à 13h30"), et un bouton "Je suis arrivé·e" qui met à jour son statut en temps réel pour les futurs mariés. Cette vue est plus opérationnelle et moins esthétique que la vue invités.

### 4.4 Galerie photo collaborative temps réel

**Concept :** Permettre aux invités de partager leurs photos directement depuis l'app dans un album commun visible par tous. Joy propose cette fonctionnalité mais uniquement sur son site web. L'intégrer nativement dans une app de coordination jour J crée une valeur émotionnelle immédiate et encourage l'engagement des invités pendant l'événement.

### 4.5 Mémoire sonore de l'événement

**Concept :** Spécifique au contexte "orchestral" de D Day Wedding : permettre aux invités d'enregistrer un message vocal de 30 secondes depuis l'app, qui est automatiquement ajouté à une "capsule sonore" de l'événement. Les futurs mariés reçoivent à la fin de la journée une compilation audio de tous les messages. C'est une fonctionnalité émotionnellement forte, techniquement faisable avec `expo-audio`, et totalement absente du marché.

### 4.6 Mode "Coordinateur fantôme"

**Concept :** Un 4ème rôle optionnel pour le wedding planner ou le coordinateur professionnel, qui a accès à toutes les vues (couple + prestataires + invités) en lecture seule, peut envoyer des alertes à tous les rôles, et dispose d'un tableau de bord de supervision en temps réel. Ce rôle est invisible pour les invités mais essentiel pour les événements avec un coordinateur professionnel.

### 4.7 Personnalisation de l'événement sans code

**Concept :** Un écran "Configurer mon événement" accessible aux futurs mariés depuis l'espace admin, permettant de modifier le nom de l'événement, la date, le lieu, le dress code, les contacts et l'image de couverture directement depuis l'app, sans toucher au code source. C'est la fonctionnalité la plus urgente pour rendre l'app utilisable par de vrais couples.

### 4.8 Export PDF du programme pour les prestataires

**Concept :** Générer un PDF imprimable du programme complet (avec logo, noms des mariés, tous les horaires et intervenants) depuis l'espace admin. Ce PDF peut être partagé par email ou WhatsApp avec les prestataires qui n'ont pas de smartphone. C'est une demande universelle dans le secteur et techniquement simple avec `expo-print` ou `react-native-html-to-pdf`.

---

## 5. Tableau de synthèse — Priorités de développement

| Priorité | Fonctionnalité | Impact | Complexité | Valeur différenciante |
|---|---|---|---|---|
| 🔴 Critique | Personnalisation événement sans code | Très élevé | Faible | Nécessaire pour tout usage réel |
| 🔴 Critique | Synchronisation multi-appareils (backend) | Très élevé | Élevée | Fondamental pour la collaboration |
| 🔴 Critique | Protection de l'espace admin (PIN/code) | Élevé | Faible | Sécurité minimale |
| 🟠 Important | Notifications push (rappels + retards) | Élevé | Moyenne | Différenciant fort |
| 🟠 Important | QR Code d'invitation par rôle | Élevé | Faible | Différenciant fort |
| 🟠 Important | Export PDF du programme | Moyen | Faible | Demande universelle |
| 🟡 Souhaitable | Recalcul timeline en cascade (SmartRipple) | Très élevé | Élevée | Différenciant majeur |
| 🟡 Souhaitable | Vue Prestataire dédiée avec checklist | Moyen | Moyenne | Différenciant fort |
| 🟡 Souhaitable | Galerie photo collaborative | Moyen | Moyenne | Engagement invités |
| 🟢 Bonus | Mémoire sonore (capsule audio) | Élevé (émotionnel) | Moyenne | Totalement unique sur le marché |
| 🟢 Bonus | Rôle Coordinateur fantôme | Moyen | Faible | Niche professionnelle |

---

## 6. État technique du projet

| Indicateur | État |
|---|---|
| Erreurs TypeScript | ✅ 0 erreur |
| Erreurs LSP | ✅ 0 erreur |
| Tests unitaires | ✅ 33/33 passent |
| Persistance locale | ✅ AsyncStorage opérationnel |
| Synchronisation cloud | ❌ Non implémentée |
| Notifications push | ❌ Non implémentées |
| Authentification admin | ❌ Aucune protection |
| Export/partage | ❌ Non implémenté |
| Tests composants/e2e | ❌ Absents |
| Logo supprimé | ✅ Remplacé par monogramme D·D |

---

*Rapport généré le 18 mai 2026 — D Day Wedding Orchestrator v3aa251aa*
