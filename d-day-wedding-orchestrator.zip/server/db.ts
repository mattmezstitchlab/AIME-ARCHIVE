import { and, eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import {
  weddingEvents,
  agendaItems,
  vendors,
  guestRegistrations,
  voiceMessages,
  galleryPhotos,
  eventAlerts,
  type InsertWeddingEvent,
  type InsertAgendaItem,
  type InsertVendor,
  type InsertGuestRegistration,
  type InsertVoiceMessage,
  type InsertGalleryPhoto,
  type InsertEventAlert,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }

  const existing = await db.select().from(users).where(eq(users.openId, user.openId)).limit(1);
  if (existing.length > 0) {
    const updates: Partial<InsertUser> = { lastSignedIn: new Date() };
    if (user.name != null) updates.name = user.name;
    if (user.email != null) updates.email = user.email;
    if (user.loginMethod != null) updates.loginMethod = user.loginMethod;
    if (ENV.ownerOpenId && user.openId === ENV.ownerOpenId) updates.role = "admin";
    await db.update(users).set(updates).where(eq(users.openId, user.openId));
  } else {
    const insertData: InsertUser = { ...user };
    if (ENV.ownerOpenId && user.openId === ENV.ownerOpenId) insertData.role = "admin";
    await db.insert(users).values(insertData);
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0] ?? null;
}

// ─── Wedding Events ───────────────────────────────────────────────────────────

export const EVENT_ID = "wedding-2026"; // Single event for now

export async function getEvent() {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(weddingEvents).where(eq(weddingEvents.id, EVENT_ID)).limit(1);
  return result[0] ?? null;
}

export async function upsertEvent(data: Omit<InsertWeddingEvent, "id">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await getEvent();
  if (existing) {
    await db.update(weddingEvents).set(data).where(eq(weddingEvents.id, EVENT_ID));
  } else {
    await db.insert(weddingEvents).values({ ...data, id: EVENT_ID });
  }
}

export async function setAdminPin(pinHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(weddingEvents).set({ adminPinHash: pinHash }).where(eq(weddingEvents.id, EVENT_ID));
}

export async function getAdminPin(): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select({ adminPinHash: weddingEvents.adminPinHash })
    .from(weddingEvents).where(eq(weddingEvents.id, EVENT_ID)).limit(1);
  return result[0]?.adminPinHash ?? null;
}

// ─── Agenda Items ─────────────────────────────────────────────────────────────

export async function getAgendaItems() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agendaItems)
    .where(eq(agendaItems.eventId, EVENT_ID))
    .orderBy(agendaItems.time);
}

export async function upsertAgendaItem(item: InsertAgendaItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(agendaItems).where(eq(agendaItems.id, item.id)).limit(1);
  if (existing.length > 0) {
    await db.update(agendaItems).set(item).where(eq(agendaItems.id, item.id));
  } else {
    await db.insert(agendaItems).values(item);
  }
}

export async function deleteAgendaItemDb(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(agendaItems).where(eq(agendaItems.id, id));
}

export async function applySmartRipple(startItemId: string, delayMinutes: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get the start item
  const startItems = await db.select().from(agendaItems)
    .where(and(eq(agendaItems.id, startItemId), eq(agendaItems.eventId, EVENT_ID))).limit(1);
  if (!startItems.length) throw new Error("Agenda item not found");

  const startItem = startItems[0];
  const startTime = startItem.time;

  // Get all items after the start item (by time)
  const allItems = await db.select().from(agendaItems)
    .where(eq(agendaItems.eventId, EVENT_ID)).orderBy(agendaItems.time);

  const itemsToUpdate = allItems.filter(item => item.time >= startTime);

  // Recalculate times
  for (const item of itemsToUpdate) {
    const [h, m] = item.time.split(":").map(Number);
    const totalMinutes = h * 60 + m + delayMinutes;
    const newH = Math.floor(totalMinutes / 60) % 24;
    const newM = totalMinutes % 60;
    const newTime = `${String(newH).padStart(2, "0")}:${String(newM).padStart(2, "0")}`;

    let newEndTime = item.endTime;
    if (item.endTime) {
      const [eh, em] = item.endTime.split(":").map(Number);
      const totalEndMinutes = eh * 60 + em + delayMinutes;
      const newEh = Math.floor(totalEndMinutes / 60) % 24;
      const newEm = totalEndMinutes % 60;
      newEndTime = `${String(newEh).padStart(2, "0")}:${String(newEm).padStart(2, "0")}`;
    }

    await db.update(agendaItems)
      .set({ time: newTime, endTime: newEndTime, delayMinutes: (item.delayMinutes ?? 0) + delayMinutes })
      .where(eq(agendaItems.id, item.id));
  }

  return itemsToUpdate.length;
}

// ─── Vendors ──────────────────────────────────────────────────────────────────

export async function getVendors() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(vendors).where(eq(vendors.eventId, EVENT_ID));
}

export async function upsertVendor(vendor: InsertVendor) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(vendors).where(eq(vendors.id, vendor.id)).limit(1);
  if (existing.length > 0) {
    await db.update(vendors).set(vendor).where(eq(vendors.id, vendor.id));
  } else {
    await db.insert(vendors).values(vendor);
  }
}

export async function deleteVendorDb(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(vendors).where(eq(vendors.id, id));
}

// ─── Guest Registrations ──────────────────────────────────────────────────────

export async function getRegistrations() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(guestRegistrations)
    .where(eq(guestRegistrations.eventId, EVENT_ID))
    .orderBy(desc(guestRegistrations.submittedAt));
}

export async function addRegistrationDb(reg: InsertGuestRegistration) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Check for duplicate email
  const existing = await db.select().from(guestRegistrations)
    .where(and(eq(guestRegistrations.eventId, EVENT_ID), eq(guestRegistrations.email, reg.email))).limit(1);
  if (existing.length > 0) throw new Error("DUPLICATE_EMAIL");
  await db.insert(guestRegistrations).values(reg);
}

export async function deleteRegistrationDb(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(guestRegistrations).where(eq(guestRegistrations.id, id));
}

// ─── Voice Messages ───────────────────────────────────────────────────────────

export async function getVoiceMessages() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(voiceMessages)
    .where(eq(voiceMessages.eventId, EVENT_ID))
    .orderBy(desc(voiceMessages.createdAt));
}

export async function addVoiceMessage(msg: InsertVoiceMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(voiceMessages).values(msg);
}

// ─── Gallery Photos ───────────────────────────────────────────────────────────

export async function getGalleryPhotos() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(galleryPhotos)
    .where(eq(galleryPhotos.eventId, EVENT_ID))
    .orderBy(desc(galleryPhotos.createdAt));
}

export async function addGalleryPhoto(photo: InsertGalleryPhoto) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(galleryPhotos).values(photo);
}

export async function likePhoto(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(galleryPhotos).where(eq(galleryPhotos.id, id)).limit(1);
  if (existing.length > 0) {
    await db.update(galleryPhotos)
      .set({ likesCount: (existing[0].likesCount ?? 0) + 1 })
      .where(eq(galleryPhotos.id, id));
  }
}

// ─── Event Alerts ─────────────────────────────────────────────────────────────

export async function getActiveAlerts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eventAlerts)
    .where(and(eq(eventAlerts.eventId, EVENT_ID), eq(eventAlerts.isActive, true)))
    .orderBy(desc(eventAlerts.createdAt));
}

export async function createAlert(alert: InsertEventAlert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(eventAlerts).values(alert);
}

export async function dismissAlert(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(eventAlerts).set({ isActive: false }).where(eq(eventAlerts.id, id));
}
