import { z } from "zod";
import { router, publicProcedure } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import * as db from "./db";
import { storagePut } from "./storage";
import crypto from "crypto";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function hashPin(pin: string): string {
  return crypto.createHash("sha256").update(pin + "ddw_salt_2026").digest("hex");
}

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// ─── Event Router ─────────────────────────────────────────────────────────────

const eventRouter = router({
  // Get full event data (public — all roles can read)
  get: publicProcedure.query(async () => {
    const [event, agenda, vendorList, registrations, alerts] = await Promise.all([
      db.getEvent(),
      db.getAgendaItems(),
      db.getVendors(),
      db.getRegistrations(),
      db.getActiveAlerts(),
    ]);
    return { event, agenda, vendors: vendorList, registrations, alerts };
  }),

  // Update event settings (requires PIN)
  updateSettings: publicProcedure
    .input(z.object({
      pin: z.string().length(4),
      name: z.string().min(1).max(255).optional(),
      date: z.string().optional(),
      venue: z.string().max(255).optional(),
      address: z.string().optional(),
      dressCode: z.string().optional(),
      parkingInfo: z.string().optional(),
      accommodationInfo: z.string().optional(),
      organizerPhone: z.string().optional(),
      organizerEmail: z.string().email().optional(),
      heroImageUrl: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { pin, ...updates } = input;
      const storedHash = await db.getAdminPin();
      if (storedHash && hashPin(pin) !== storedHash) {
        throw new Error("INVALID_PIN");
      }
      await db.upsertEvent(updates as Parameters<typeof db.upsertEvent>[0]);
      return { success: true };
    }),

  // Set admin PIN (first time or reset)
  setPin: publicProcedure
    .input(z.object({ pin: z.string().length(4) }))
    .mutation(async ({ input }) => {
      await db.setAdminPin(hashPin(input.pin));
      return { success: true };
    }),

  // Verify PIN
  verifyPin: publicProcedure
    .input(z.object({ pin: z.string().length(4) }))
    .mutation(async ({ input }) => {
      const storedHash = await db.getAdminPin();
      if (!storedHash) return { valid: true, noPinSet: true };
      return { valid: hashPin(input.pin) === storedHash, noPinSet: false };
    }),
});

// ─── Agenda Router ────────────────────────────────────────────────────────────

const agendaRouter = router({
  list: publicProcedure.query(() => db.getAgendaItems()),

  upsert: publicProcedure
    .input(z.object({
      id: z.string().optional(),
      time: z.string(),
      endTime: z.string().optional(),
      title: z.string().min(1).max(255),
      description: z.string().optional(),
      speaker: z.string().optional(),
      category: z.enum(["ceremony", "cocktail", "dinner", "music", "photo", "logistics", "other"]),
      location: z.string().optional(),
      isLive: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = input.id ?? generateId("a");
      await db.upsertAgendaItem({
        id,
        eventId: db.EVENT_ID,
        time: input.time,
        endTime: input.endTime,
        title: input.title,
        description: input.description,
        speaker: input.speaker,
        category: input.category,
        location: input.location,
        isLive: input.isLive ?? false,
        delayMinutes: 0,
        sortOrder: 0,
      });
      return { id };
    }),

  delete: publicProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await db.deleteAgendaItemDb(input.id);
      return { success: true };
    }),

  // SmartRipple: signal a delay and recalculate all subsequent times
  smartRipple: publicProcedure
    .input(z.object({
      agendaItemId: z.string(),
      delayMinutes: z.number().int().min(1).max(240),
      message: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const updatedCount = await db.applySmartRipple(input.agendaItemId, input.delayMinutes);

      // Create a broadcast alert
      await db.createAlert({
        id: generateId("alert"),
        eventId: db.EVENT_ID,
        agendaItemId: input.agendaItemId,
        type: "delay",
        message: input.message ?? `Retard de ${input.delayMinutes} min — horaires recalculés automatiquement`,
        delayMinutes: input.delayMinutes,
        targetRoles: ["couple", "vendor", "guest", "coordinator"],
        isActive: true,
      });

      return { success: true, updatedCount };
    }),
});

// ─── Vendors Router ───────────────────────────────────────────────────────────

const vendorsRouter = router({
  list: publicProcedure.query(() => db.getVendors()),

  upsert: publicProcedure
    .input(z.object({
      id: z.string().optional(),
      name: z.string().min(1).max(255),
      role: z.string().min(1).max(255),
      phone: z.string().optional(),
      email: z.string().email().optional(),
      description: z.string().optional(),
      arrivalTime: z.string().optional(),
      status: z.enum(["pending", "confirmed", "arrived"]).optional(),
      category: z.enum(["ceremony", "cocktail", "dinner", "music", "photo", "logistics", "other"]).optional(),
      notes: z.string().optional(),
      checklist: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input }) => {
      const id = input.id ?? generateId("v");
      await db.upsertVendor({
        id,
        eventId: db.EVENT_ID,
        name: input.name,
        role: input.role,
        phone: input.phone,
        email: input.email,
        description: input.description,
        arrivalTime: input.arrivalTime,
        status: input.status ?? "pending",
        category: input.category ?? "other",
        notes: input.notes,
        checklist: input.checklist ?? [],
      });
      return { id };
    }),

  updateStatus: publicProcedure
    .input(z.object({
      id: z.string(),
      status: z.enum(["pending", "confirmed", "arrived"]),
    }))
    .mutation(async ({ input }) => {
      await db.upsertVendor({
        id: input.id,
        eventId: db.EVENT_ID,
        name: "", // will be ignored in update
        role: "",
        status: input.status,
        category: "other",
        isLive: false,
      } as Parameters<typeof db.upsertVendor>[0]);
      // Use partial update instead
      const vendorList = await db.getVendors();
      const existing = vendorList.find(v => v.id === input.id);
      if (existing) {
        await db.upsertVendor({ ...existing, status: input.status });
      }
      return { success: true };
    }),

  delete: publicProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await db.deleteVendorDb(input.id);
      return { success: true };
    }),
});

// ─── Registrations Router ─────────────────────────────────────────────────────

const registrationsRouter = router({
  list: publicProcedure.query(() => db.getRegistrations()),

  add: publicProcedure
    .input(z.object({
      firstName: z.string().min(1).max(128),
      lastName: z.string().min(1).max(128),
      email: z.string().email(),
      phone: z.string().optional(),
      dietaryRestrictions: z.string().optional(),
      attendsCeremony: z.boolean(),
      attendsCocktail: z.boolean(),
      attendsDinner: z.boolean(),
      plusOne: z.boolean().optional(),
      plusOneName: z.string().optional(),
      message: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = generateId("reg");
      await db.addRegistrationDb({
        id,
        eventId: db.EVENT_ID,
        firstName: input.firstName,
        lastName: input.lastName,
        email: input.email,
        phone: input.phone,
        dietaryRestrictions: input.dietaryRestrictions,
        attendsCeremony: input.attendsCeremony,
        attendsCocktail: input.attendsCocktail,
        attendsDinner: input.attendsDinner,
        plusOne: input.plusOne ?? false,
        plusOneName: input.plusOneName,
        message: input.message,
      });
      return { id };
    }),

  delete: publicProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await db.deleteRegistrationDb(input.id);
      return { success: true };
    }),
});

// ─── Voice Messages Router ────────────────────────────────────────────────────

const voiceRouter = router({
  list: publicProcedure.query(() => db.getVoiceMessages()),

  // Upload audio and save voice message
  upload: publicProcedure
    .input(z.object({
      guestName: z.string().min(1).max(255),
      audioBase64: z.string(), // base64 encoded audio
      duration: z.number().int().min(1).max(30),
      mimeType: z.string().default("audio/m4a"),
    }))
    .mutation(async ({ input }) => {
      const id = generateId("voice");
      const buffer = Buffer.from(input.audioBase64, "base64");
      const ext = input.mimeType.includes("mp4") ? "m4a" : "webm";
      const { url } = await storagePut(
        `voice/${db.EVENT_ID}/${id}.${ext}`,
        buffer,
        input.mimeType
      );
      await db.addVoiceMessage({
        id,
        eventId: db.EVENT_ID,
        guestName: input.guestName,
        audioUrl: url,
        duration: input.duration,
      });
      return { id, url };
    }),
});

// ─── Gallery Router ───────────────────────────────────────────────────────────

const galleryRouter = router({
  list: publicProcedure.query(() => db.getGalleryPhotos()),

  upload: publicProcedure
    .input(z.object({
      uploaderName: z.string().min(1).max(255),
      photoBase64: z.string(),
      caption: z.string().optional(),
      mimeType: z.string().default("image/jpeg"),
    }))
    .mutation(async ({ input }) => {
      const id = generateId("photo");
      const buffer = Buffer.from(input.photoBase64, "base64");
      const ext = input.mimeType.includes("png") ? "png" : "jpg";
      const { url } = await storagePut(
        `gallery/${db.EVENT_ID}/${id}.${ext}`,
        buffer,
        input.mimeType
      );
      await db.addGalleryPhoto({
        id,
        eventId: db.EVENT_ID,
        uploaderName: input.uploaderName,
        photoUrl: url,
        caption: input.caption,
        likesCount: 0,
      });
      return { id, url };
    }),

  like: publicProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await db.likePhoto(input.id);
      return { success: true };
    }),
});

// ─── Alerts Router ────────────────────────────────────────────────────────────

const alertsRouter = router({
  list: publicProcedure.query(() => db.getActiveAlerts()),

  broadcast: publicProcedure
    .input(z.object({
      message: z.string().min(1).max(500),
      targetRoles: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input }) => {
      const id = generateId("alert");
      await db.createAlert({
        id,
        eventId: db.EVENT_ID,
        type: "broadcast",
        message: input.message,
        targetRoles: input.targetRoles ?? ["couple", "vendor", "guest", "coordinator"],
        isActive: true,
      });
      return { id };
    }),

  dismiss: publicProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await db.dismissAlert(input.id);
      return { success: true };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user ?? null),
    logout: publicProcedure.mutation(({ ctx }) => {
      const { getSessionCookieOptions, COOKIE_NAME } = require("./_core/cookies");
      ctx.res.clearCookie(COOKIE_NAME, getSessionCookieOptions());
      return { success: true };
    }),
  }),
  event: eventRouter,
  agenda: agendaRouter,
  vendors: vendorsRouter,
  registrations: registrationsRouter,
  voice: voiceRouter,
  gallery: galleryRouter,
  alerts: alertsRouter,
});

export type AppRouter = typeof appRouter;
