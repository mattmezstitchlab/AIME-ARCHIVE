# D Day Wedding Orchestrator — Design Document

## Concept
Application mobile élégante pour orchestrer les événements de mariage et conférences. Interface sombre et dorée, inspirée d'un programme de gala orchestral. Trois rôles distincts : futurs mariés, prestataires, et invités.

## Palette de couleurs
- **Fond principal** : `#03030e` (noir profond)
- **Doré accent** : `#c9a96e` (or champagne)
- **Doré clair** : `#e8d5a3`
- **Surface carte** : `#0d0d1a`
- **Bordure** : `rgba(201,169,110,0.2)`
- **Texte principal** : `#f5f0e8`
- **Texte secondaire** : `#9b9b8a`
- **Vert live** : `#4ade80`
- **Fond surface** : `#111120`

## Typographie
- Titres : **Playfair Display** (serif élégant)
- Corps : **Inter** (sans-serif moderne)

## Écrans

### 1. Splash / Onboarding
- Animation d'entrée avec logo doré
- Sélection du rôle : Futur(e) marié(e) | Prestataire | Invité(e)

### 2. Accueil (Home)
- Header avec nom de l'événement et date
- Compte à rebours jusqu'au Jour J
- Résumé du programme du jour
- Accès rapide aux sections principales

### 3. Timeline / Programme (Agenda)
- Ligne verticale centrale dorée
- Cartes alternées gauche/droite
- Horaire, titre, description, intervenant/prestataire
- Badge "EN COURS" pulsant pour l'événement actif
- Filtrage par catégorie (cérémonie, cocktail, dîner, etc.)

### 4. Prestataires
- Liste des prestataires avec rôle et contact
- Fiche détaillée : photo, description, horaire d'intervention
- Statut : confirmé / en attente / en cours

### 5. Inscription (Registration)
- Formulaire d'inscription pour invités
- Champs : Nom, Prénom, Email, Téléphone, Régime alimentaire, Présence à la cérémonie/cocktail/dîner
- Confirmation par email (optionnel)

### 6. Informations pratiques
- Lieu et adresse avec carte
- Code dress code
- Informations logistiques (parking, hébergement)
- Contact organisateur

## Flux utilisateur principal
1. Ouverture → Sélection rôle → Accueil
2. Accueil → Timeline → Détail événement
3. Accueil → Prestataires → Fiche prestataire
4. Accueil → Inscription → Formulaire → Confirmation

## Navigation
- Tab bar : Accueil | Programme | Prestataires | Infos | Inscription
- Header fixe avec nom événement et date
- Retour arrière natif iOS/Android
