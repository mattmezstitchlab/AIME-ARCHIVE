import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AppHeader } from "@/components/app-header";
import { addRegistration } from "@/lib/wedding-store";
import { useState } from "react";
import { NEU } from "@/lib/neu-styles";

interface FormState {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dietaryRestrictions: string;
  attendsCeremony: boolean;
  attendsCocktail: boolean;
  attendsDinner: boolean;
  plusOne: boolean;
  plusOneName: string;
  message: string;
}

const INITIAL_FORM: FormState = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  dietaryRestrictions: "",
  attendsCeremony: true,
  attendsCocktail: true,
  attendsDinner: true,
  plusOne: false,
  plusOneName: "",
  message: "",
};

function Toggle({ value, onToggle, label, subtitle }: {
  value: boolean; onToggle: () => void; label: string; subtitle?: string;
}) {
  return (
    <Pressable
      onPress={onToggle}
      style={({ pressed }) => [styles.toggleRow, pressed && { opacity: 0.75 }]}
    >
      <View style={styles.toggleTextContainer}>
        <Text style={styles.toggleLabel}>{label}</Text>
        {subtitle && <Text style={styles.toggleSubtitle}>{subtitle}</Text>}
      </View>
      {/* Toggle Neumorphism */}
      <View style={[styles.toggleTrack, value && styles.toggleTrackActive]}>
        <View style={[styles.toggleThumb, value && styles.toggleThumbActive]} />
      </View>
    </Pressable>
  );
}

function InputField({ label, value, onChangeText, placeholder, keyboardType, multiline, required }: {
  label: string; value: string; onChangeText: (text: string) => void;
  placeholder?: string; keyboardType?: "default" | "email-address" | "phone-pad";
  multiline?: boolean; required?: boolean;
}) {
  return (
    <View style={styles.inputGroup}>
      <Text style={styles.inputLabel}>
        {label}
        {required && <Text style={styles.required}> *</Text>}
      </Text>
      {/* Input en creux Neumorphism */}
      <View style={styles.inputWrap}>
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={NEU.textMuted}
          keyboardType={keyboardType ?? "default"}
          multiline={multiline}
          numberOfLines={multiline ? 3 : 1}
          style={[styles.input, multiline && styles.inputMultiline]}
          returnKeyType={multiline ? "default" : "done"}
        />
      </View>
    </View>
  );
}

export default function RegisterScreen() {
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async () => {
    if (!form.firstName.trim() || !form.lastName.trim() || !form.email.trim()) {
      Alert.alert("Champs requis", "Veuillez remplir votre prénom, nom et email.");
      return;
    }
    if (!form.email.includes("@")) {
      Alert.alert("Email invalide", "Veuillez saisir une adresse email valide.");
      return;
    }
    setIsSubmitting(true);
    try {
      await addRegistration({
        firstName: form.firstName.trim(),
        lastName: form.lastName.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || undefined,
        dietaryRestrictions: form.dietaryRestrictions.trim() || undefined,
        attendsCeremony: form.attendsCeremony,
        attendsCocktail: form.attendsCocktail,
        attendsDinner: form.attendsDinner,
        plusOne: form.plusOne,
        plusOneName: form.plusOneName.trim() || undefined,
        message: form.message.trim() || undefined,
      });
      setSubmitted(true);
    } catch {
      Alert.alert("Erreur", "Une erreur est survenue. Veuillez réessayer.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
        <AppHeader title="Inscription" />
        <View style={styles.successContainer}>
          {/* Icône succès Neumorphism */}
          <View style={styles.successIconOuter}>
            <View style={styles.successIconInner}>
              <Text style={styles.successIconText}>✓</Text>
            </View>
          </View>
          <Text style={styles.successTitle}>Inscription confirmée</Text>
          <Text style={styles.successSubtitle}>
            Merci {form.firstName} ! Votre présence a bien été enregistrée.
          </Text>
          <View style={styles.successDetails}>
            {form.attendsCeremony && <Text style={styles.successDetailItem}>✦ Cérémonie</Text>}
            {form.attendsCocktail && <Text style={styles.successDetailItem}>✦ Cocktail</Text>}
            {form.attendsDinner && <Text style={styles.successDetailItem}>✦ Dîner</Text>}
          </View>
          <Pressable
            onPress={() => { setForm(INITIAL_FORM); setSubmitted(false); }}
            style={({ pressed }) => [styles.newBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
          >
            <Text style={styles.newBtnText}>Nouvelle inscription</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <AppHeader title="Inscription" />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* En-tête */}
          <View style={styles.formHeader}>
            <Text style={styles.formTitle}>Confirmez votre présence</Text>
            <Text style={styles.formSubtitle}>Mariage Sophie & Alexandre · 14 juin 2026</Text>
          </View>

          {/* Identité */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>VOS INFORMATIONS</Text>
            <View style={styles.sectionCard}>
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <InputField label="Prénom" value={form.firstName} onChangeText={(v) => updateField("firstName", v)} placeholder="Sophie" required />
                </View>
                <View style={{ flex: 1 }}>
                  <InputField label="Nom" value={form.lastName} onChangeText={(v) => updateField("lastName", v)} placeholder="Dupont" required />
                </View>
              </View>
              <InputField label="Email" value={form.email} onChangeText={(v) => updateField("email", v)} placeholder="sophie@exemple.fr" keyboardType="email-address" required />
              <InputField label="Téléphone" value={form.phone} onChangeText={(v) => updateField("phone", v)} placeholder="+33 6 00 00 00 00" keyboardType="phone-pad" />
            </View>
          </View>

          {/* Présence */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>VOTRE PRÉSENCE</Text>
            <View style={styles.sectionCard}>
              <Toggle label="Cérémonie" subtitle="10h00 — Mairie & Jardins du Château" value={form.attendsCeremony} onToggle={() => updateField("attendsCeremony", !form.attendsCeremony)} />
              <View style={styles.toggleDivider} />
              <Toggle label="Cocktail" subtitle="13h30 — Terrasse du Château" value={form.attendsCocktail} onToggle={() => updateField("attendsCocktail", !form.attendsCocktail)} />
              <View style={styles.toggleDivider} />
              <Toggle label="Dîner de gala" subtitle="17h00 — Grande Salle" value={form.attendsDinner} onToggle={() => updateField("attendsDinner", !form.attendsDinner)} />
            </View>
          </View>

          {/* Accompagnant */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>ACCOMPAGNANT(E)</Text>
            <View style={styles.sectionCard}>
              <Toggle label="Je viens avec un(e) accompagnant(e)" value={form.plusOne} onToggle={() => updateField("plusOne", !form.plusOne)} />
              {form.plusOne && (
                <>
                  <View style={styles.toggleDivider} />
                  <InputField label="Nom de l'accompagnant(e)" value={form.plusOneName} onChangeText={(v) => updateField("plusOneName", v)} placeholder="Prénom Nom" />
                </>
              )}
            </View>
          </View>

          {/* Régime */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>RÉGIME ALIMENTAIRE</Text>
            <View style={styles.sectionCard}>
              <InputField label="Restrictions ou allergies" value={form.dietaryRestrictions} onChangeText={(v) => updateField("dietaryRestrictions", v)} placeholder="Végétarien, sans gluten, allergie aux noix..." multiline />
            </View>
          </View>

          {/* Message */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>MESSAGE AUX MARIÉS</Text>
            <View style={styles.sectionCard}>
              <InputField label="Votre message (optionnel)" value={form.message} onChangeText={(v) => updateField("message", v)} placeholder="Un mot pour Sophie & Alexandre..." multiline />
            </View>
          </View>

          {/* Bouton Neumorphism */}
          <Pressable
            onPress={handleSubmit}
            disabled={isSubmitting}
            style={({ pressed }) => [
              styles.submitButton,
              isSubmitting && styles.submitButtonDisabled,
              pressed && !isSubmitting && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
          >
            <Text style={styles.submitText}>
              {isSubmitting ? "Envoi en cours..." : "Confirmer ma présence"}
            </Text>
          </Pressable>

          <Text style={styles.requiredNote}>* Champs obligatoires</Text>
          <View style={{ height: 32 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  scrollContent: { paddingBottom: 16 },

  formHeader: {
    alignItems: "center",
    paddingVertical: 22,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.3)",
    backgroundColor: NEU.bgRaised,
  },
  formTitle: {
    fontSize: 17,
    fontWeight: "800",
    color: NEU.red,
    textAlign: "center",
    marginBottom: 4,
  },
  formSubtitle: {
    fontSize: 11,
    color: NEU.textSecondary,
    textAlign: "center",
    letterSpacing: 0.3,
  },

  section: { marginHorizontal: 16, marginTop: 20 },
  sectionTitle: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 2.5,
    textTransform: "uppercase",
    marginBottom: 10,
    fontWeight: "700",
  },

  // Carte section Neumorphism
  sectionCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },

  row: { flexDirection: "row", gap: 12 },

  // Input en creux Neumorphism
  inputGroup: { marginBottom: 14 },
  inputLabel: {
    fontSize: 10,
    color: NEU.textSecondary,
    marginBottom: 7,
    letterSpacing: 0.5,
    fontWeight: "600",
    textTransform: "uppercase",
  },
  required: { color: NEU.red },
  inputWrap: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.35)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    elevation: 0,
  },
  input: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: NEU.textPrimary,
  },
  inputMultiline: {
    minHeight: 80,
    textAlignVertical: "top",
    paddingTop: 12,
  },

  // Toggle Neumorphism
  toggleRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 4,
    gap: 12,
  },
  toggleTextContainer: { flex: 1 },
  toggleLabel: { fontSize: 14, color: NEU.textPrimary, fontWeight: "500" },
  toggleSubtitle: { fontSize: 11, color: NEU.textSecondary, marginTop: 2 },
  toggleTrack: {
    width: 46,
    height: 26,
    borderRadius: 13,
    backgroundColor: NEU.bgSunken,
    padding: 3,
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.3)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 0,
  },
  toggleTrackActive: {
    backgroundColor: "rgba(232,69,60,0.15)",
    borderColor: "rgba(232,69,60,0.4)",
  },
  toggleThumb: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: NEU.bgRaised,
    alignSelf: "flex-start",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
  },
  toggleThumbActive: {
    backgroundColor: NEU.red,
    alignSelf: "flex-end",
  },
  toggleDivider: {
    height: 1,
    backgroundColor: "rgba(0,0,0,0.25)",
    marginVertical: 10,
  },

  // Bouton submit Neumorphism
  submitButton: {
    marginHorizontal: 16,
    marginTop: 24,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.4)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8,
  },
  submitButtonDisabled: {
    borderColor: "rgba(0,0,0,0.06)",
    opacity: 0.4,
  },
  submitText: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.red,
    letterSpacing: 0.5,
  },

  requiredNote: {
    textAlign: "center",
    fontSize: 11,
    color: NEU.textMuted,
    marginTop: 12,
  },

  // Succès Neumorphism
  successContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
  },
  successIconOuter: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: NEU.bgRaised,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 24,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 14,
    elevation: 10,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
  },
  successIconInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.5,
    borderColor: "rgba(232,69,60,0.4)",
  },
  successIconText: { fontSize: 26, color: NEU.red, fontWeight: "800" },
  successTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: NEU.red,
    marginBottom: 8,
    textAlign: "center",
  },
  successSubtitle: {
    fontSize: 14,
    color: NEU.textSecondary,
    textAlign: "center",
    lineHeight: 22,
    marginBottom: 24,
  },
  successDetails: { gap: 8, marginBottom: 32, alignItems: "center" },
  successDetailItem: { fontSize: 13, color: NEU.textPrimary, letterSpacing: 0.5 },
  newBtn: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 12,
    paddingHorizontal: 28,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.35)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  newBtnText: { fontSize: 14, color: NEU.red, fontWeight: "600" },
});
