import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform, View, StyleSheet } from "react-native";
import { HapticTab } from "@/components/haptic-tab";
import { GradientIcon } from "@/components/ui/gradient-icon";
import { NEU } from "@/lib/neu-styles";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 62 + bottomPadding;

  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: NEU.bgRaised,
          borderTopColor: NEU.shadowLight,
          borderTopWidth: 1.5,
          // Ombre Neumorphism vers le haut
          shadowColor: NEU.shadowDark,
          shadowOffset: { width: 0, height: -4 },
          shadowOpacity: 0.8,
          shadowRadius: 10,
          elevation: 12,
        },
        tabBarActiveTintColor: NEU.red,
        tabBarInactiveTintColor: NEU.textMuted,
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: "700",
          letterSpacing: 0.3,
          marginTop: 2,
        },
        tabBarIcon: ({ focused }) => {
          const iconMap: Record<string, string> = {
            index: "house.fill",
            agenda: "calendar",
            vendors: "person.2.fill",
            register: "pencil",
            info: "info.circle.fill",
          };
          const iconName = iconMap[route.name] ?? "circle.fill";

          if (focused) {
            return (
              <View style={styles.activeIconContainer}>
                <GradientIcon
                  name={iconName as any}
                  size={22}
                  colors={[NEU.red, NEU.redLight]}
                />
              </View>
            );
          }
          return (
            <GradientIcon
              name={iconName as any}
              size={22}
              colors={[NEU.textMuted, NEU.textMuted]}
            />
          );
        },
      })}
    >
      <Tabs.Screen name="index"    options={{ title: "Accueil" }} />
      <Tabs.Screen name="agenda"   options={{ title: "Programme" }} />
      <Tabs.Screen name="vendors"  options={{ title: "Équipe" }} />
      <Tabs.Screen name="register" options={{ title: "Inscription" }} />
      <Tabs.Screen name="info"     options={{ title: "Infos" }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  activeIconContainer: {
    width: 44,
    height: 34,
    borderRadius: 12,
    backgroundColor: NEU.redBg,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.5,
    borderColor: NEU.redBorder,
    // Ombre Neumorphism en creux
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.8,
    shadowRadius: 6,
    elevation: 4,
  },
});
