import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  FlatList,
  Linking,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AppHeader } from "@/components/app-header";
import { useAppContext } from "@/lib/app-context";
import { getCategoryLabel, type Vendor, type EventCategory } from "@/lib/wedding-store";
import { useState } from "react";
import { NEU } from "@/lib/neu-styles";

const STATUS_COLORS: Record<Vendor["status"], string> = {
  confirmed: "#4ade80",
  pending: "#FBBF24",
  arrived: NEU.red,
};
const STATUS_LABELS: Record<Vendor["status"], string> = {
  confirmed: "Confirmé",
  pending: "En attente",
  arrived: "Arrivé",
};
const CATEGORY_FILTERS: { key: "all" | EventCategory; label: string }[] = [
  { key: "all", label: "Tous" },
  { key: "ceremony", label: "Cérémonie" },
  { key: "music", label: "Musique" },
  { key: "photo", label: "Photo" },
  { key: "dinner", label: "Traiteur" },
  { key: "other", label: "Décoration" },
];

function VendorCard({ vendor, onPress }: { vendor: Vendor; onPress: () => void }) {
  const statusColor = STATUS_COLORS[vendor.status];
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.vendorCard,
        pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
      ]}
    >
      {/* Avatar Neumorphism */}
      <View style={styles.avatarOuter}>
        <View style={styles.avatarInner}>
          <Text style={styles.avatarText}>
            {vendor.avatar ?? vendor.name.slice(0, 2).toUpperCase()}
          </Text>
        </View>
      </View>

      <View style={styles.vendorInfo}>
        <View style={styles.vendorNameRow}>
          <Text style={styles.vendorName} numberOfLines={1}>{vendor.name}</Text>
          <View style={[styles.statusBadge, { borderColor: statusColor + "60" }]}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.statusText, { color: statusColor }]}>
              {STATUS_LABELS[vendor.status]}
            </Text>
          </View>
        </View>
        <Text style={styles.vendorRole}>{vendor.role}</Text>
        {vendor.arrivalTime && (
          <Text style={styles.vendorTime}>◈ Arrivée : {vendor.arrivalTime}</Text>
        )}
      </View>

      <Text style={styles.chevron}>›</Text>
    </Pressable>
  );
}

function VendorDetail({ vendor, onClose }: { vendor: Vendor; onClose: () => void }) {
  const statusColor = STATUS_COLORS[vendor.status];
  return (
    <View style={styles.detailContainer}>
      <View style={styles.detailHeader}>
        <Pressable
          onPress={onClose}
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
        >
          <Text style={styles.backBtnText}>← Retour</Text>
        </Pressable>
      </View>

      <ScrollView style={styles.detailScroll} showsVerticalScrollIndicator={false}>
        {/* Avatar large Neumorphism */}
        <View style={styles.detailAvatarContainer}>
          <View style={styles.detailAvatarOuter}>
            <View style={styles.detailAvatarInner}>
              <Text style={styles.detailAvatarText}>
                {vendor.avatar ?? vendor.name.slice(0, 2).toUpperCase()}
              </Text>
            </View>
          </View>
          <View style={[styles.statusBadgeLarge, { borderColor: statusColor + "60" }]}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.statusTextLarge, { color: statusColor }]}>
              {STATUS_LABELS[vendor.status]}
            </Text>
          </View>
        </View>

        <Text style={styles.detailName}>{vendor.name}</Text>
        <Text style={styles.detailRole}>{vendor.role}</Text>

        <View style={styles.detailDivider} />

        {vendor.description && (
          <View style={styles.detailSection}>
            <Text style={styles.detailSectionTitle}>À PROPOS</Text>
            <View style={styles.detailCard}>
              <Text style={styles.detailSectionText}>{vendor.description}</Text>
            </View>
          </View>
        )}

        <View style={styles.detailInfoGrid}>
          {vendor.arrivalTime && (
            <View style={styles.detailInfoItem}>
              <Text style={styles.detailInfoLabel}>ARRIVÉE</Text>
              <Text style={styles.detailInfoValue}>{vendor.arrivalTime}</Text>
            </View>
          )}
          <View style={styles.detailInfoItem}>
            <Text style={styles.detailInfoLabel}>CATÉGORIE</Text>
            <Text style={styles.detailInfoValue}>{getCategoryLabel(vendor.category)}</Text>
          </View>
        </View>

        {(vendor.phone || vendor.email) && (
          <View style={styles.detailSection}>
            <Text style={styles.detailSectionTitle}>CONTACT</Text>
            {vendor.phone && (
              <Pressable
                onPress={() => Linking.openURL(`tel:${vendor.phone}`)}
                style={({ pressed }) => [styles.contactCard, pressed && { opacity: 0.75 }]}
              >
                <View style={styles.contactIconWrap}>
                  <Text style={styles.contactIcon}>✆</Text>
                </View>
                <Text style={styles.contactText}>{vendor.phone}</Text>
                <Text style={styles.contactArrow}>→</Text>
              </Pressable>
            )}
            {vendor.email && (
              <Pressable
                onPress={() => Linking.openURL(`mailto:${vendor.email}`)}
                style={({ pressed }) => [styles.contactCard, pressed && { opacity: 0.75 }]}
              >
                <View style={styles.contactIconWrap}>
                  <Text style={styles.contactIcon}>✉</Text>
                </View>
                <Text style={styles.contactText}>{vendor.email}</Text>
                <Text style={styles.contactArrow}>→</Text>
              </Pressable>
            )}
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

export default function VendorsScreen() {
  const { event } = useAppContext();
  const [filter, setFilter] = useState<"all" | EventCategory>("all");
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);

  if (!event) return null;

  if (selectedVendor) {
    return (
      <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
        <AppHeader title="Prestataire" showBack={false} />
        <VendorDetail vendor={selectedVendor} onClose={() => setSelectedVendor(null)} />
      </ScreenContainer>
    );
  }

  const filteredVendors =
    filter === "all" ? event.vendors : event.vendors.filter((v) => v.category === filter);

  const arrivedCount = event.vendors.filter((v) => v.status === "arrived").length;
  const confirmedCount = event.vendors.filter((v) => v.status === "confirmed").length;
  const pendingCount = event.vendors.filter((v) => v.status === "pending").length;

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <AppHeader title="Prestataires" />

      {/* Stats Neumorphism */}
      <View style={styles.statsRow}>
        {[
          { value: arrivedCount, label: "Arrivés", color: NEU.red },
          { value: confirmedCount, label: "Confirmés", color: "#4ade80" },
          { value: pendingCount, label: "En attente", color: "#FBBF24" },
        ].map((stat, i) => (
          <View key={stat.label} style={styles.statItem}>
            <Text style={[styles.statValue, { color: stat.color }]}>{stat.value}</Text>
            <Text style={styles.statLabel}>{stat.label}</Text>
          </View>
        ))}
      </View>

      {/* Filtres Neumorphism */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterScroll}
        contentContainerStyle={styles.filterContent}
      >
        {CATEGORY_FILTERS.map((cat) => (
          <Pressable
            key={cat.key}
            onPress={() => setFilter(cat.key)}
            style={({ pressed }) => [
              styles.filterChip,
              filter === cat.key && styles.filterChipActive,
              pressed && { opacity: 0.75, transform: [{ scale: 0.96 }] },
            ]}
          >
            <Text style={[styles.filterChipText, filter === cat.key && styles.filterChipTextActive]}>
              {cat.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      <FlatList
        data={filteredVendors}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <VendorCard vendor={item} onPress={() => setSelectedVendor(item)} />
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Aucun prestataire dans cette catégorie</Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  // Stats
  statsRow: {
    flexDirection: "row",
    backgroundColor: NEU.bgRaised,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.3)",
    paddingVertical: 14,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  statItem: {
    flex: 1,
    alignItems: "center",
    gap: 3,
  },
  statValue: {
    fontSize: 22,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },

  // Filtres
  filterScroll: {
    flexGrow: 0,
    backgroundColor: NEU.bgRaised,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.3)",
  },
  filterContent: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.3)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 3,
  },
  filterChipActive: {
    backgroundColor: "rgba(232,69,60,0.1)",
    borderColor: "rgba(232,69,60,0.5)",
  },
  filterChipText: {
    fontSize: 12,
    color: NEU.textSecondary,
    fontWeight: "500",
  },
  filterChipTextActive: {
    color: NEU.red,
    fontWeight: "700",
  },

  listContent: { padding: 16, paddingBottom: 24 },

  // Carte prestataire Neumorphism
  vendorCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
    gap: 12,
  },
  avatarOuter: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: NEU.bgRaised,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 8,
    elevation: 6,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
  },
  avatarInner: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.25)",
  },
  avatarText: {
    fontSize: 13,
    fontWeight: "800",
    color: NEU.red,
  },
  vendorInfo: { flex: 1 },
  vendorNameRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    marginBottom: 3,
  },
  vendorName: {
    fontSize: 14,
    fontWeight: "700",
    color: NEU.textPrimary,
    flex: 1,
  },
  vendorRole: {
    fontSize: 12,
    color: NEU.textSecondary,
    marginBottom: 2,
  },
  vendorTime: {
    fontSize: 11,
    color: NEU.textMuted,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderWidth: 1,
    gap: 3,
    backgroundColor: "rgba(0,0,0,0.2)",
  },
  statusDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
  },
  statusText: {
    fontSize: 9,
    fontWeight: "700",
    letterSpacing: 0.3,
  },
  chevron: {
    fontSize: 22,
    color: "rgba(232,69,60,0.35)",
  },

  emptyContainer: { padding: 32, alignItems: "center" },
  emptyText: { fontSize: 13, color: NEU.textSecondary, textAlign: "center" },

  // Detail
  detailContainer: { flex: 1 },
  detailHeader: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: NEU.bgRaised,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.3)",
  },
  backBtn: { alignSelf: "flex-start" },
  backBtnText: { fontSize: 14, color: NEU.red, fontWeight: "600" },
  detailScroll: { flex: 1, padding: 24 },
  detailAvatarContainer: { alignItems: "center", marginBottom: 16, gap: 12 },
  detailAvatarOuter: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: NEU.bgRaised,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 14,
    elevation: 10,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
  },
  detailAvatarInner: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.5,
    borderColor: "rgba(232,69,60,0.3)",
  },
  detailAvatarText: { fontSize: 26, fontWeight: "800", color: NEU.red },
  statusBadgeLarge: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderWidth: 1,
    gap: 6,
    backgroundColor: "rgba(0,0,0,0.2)",
  },
  statusTextLarge: { fontSize: 12, fontWeight: "700" },
  detailName: {
    fontSize: 22,
    fontWeight: "800",
    color: NEU.textPrimary,
    textAlign: "center",
    marginBottom: 4,
  },
  detailRole: {
    fontSize: 14,
    color: NEU.red,
    textAlign: "center",
    letterSpacing: 0.5,
  },
  detailDivider: {
    height: 1,
    backgroundColor: "rgba(232,69,60,0.12)",
    marginVertical: 20,
  },
  detailSection: { marginBottom: 20 },
  detailSectionTitle: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 2.5,
    textTransform: "uppercase",
    marginBottom: 10,
  },
  detailCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  detailSectionText: { fontSize: 14, color: NEU.textPrimary, lineHeight: 22 },
  detailInfoGrid: { flexDirection: "row", gap: 12, marginBottom: 20 },
  detailInfoItem: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
    gap: 4,
  },
  detailInfoLabel: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 1.5,
    textTransform: "uppercase",
  },
  detailInfoValue: { fontSize: 15, fontWeight: "700", color: NEU.red },
  contactCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
    gap: 12,
    marginBottom: 10,
  },
  contactIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.2)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 4,
  },
  contactIcon: { fontSize: 16, color: NEU.red },
  contactText: { flex: 1, fontSize: 13, color: NEU.textPrimary },
  contactArrow: { fontSize: 16, color: "rgba(232,69,60,0.4)" },
});
