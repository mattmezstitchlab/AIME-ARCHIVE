import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  Linking,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AppHeader } from "@/components/app-header";
import { useAppContext } from "@/lib/app-context";
import { NEU } from "@/lib/neu-styles";

function InfoCard({ icon, title, children }: {
  icon: string; title: string; children: React.ReactNode;
}) {
  return (
    <View style={styles.infoCard}>
      <View style={styles.infoCardHeader}>
        <View style={styles.iconWrap}>
          <Text style={styles.infoCardIcon}>{icon}</Text>
        </View>
        <Text style={styles.infoCardTitle}>{title}</Text>
      </View>
      <View style={styles.infoCardContent}>{children}</View>
    </View>
  );
}

function InfoRow({ label, value, onPress }: { label: string; value: string; onPress?: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [styles.infoRow, onPress && pressed && { opacity: 0.6 }]}
    >
      <Text style={styles.infoRowLabel}>{label}</Text>
      <Text style={[styles.infoRowValue, onPress && styles.infoRowValueLink]}>{value}</Text>
    </Pressable>
  );
}

export default function InfoScreen() {
  const { event } = useAppContext();
  if (!event) return null;

  const handleCall = (phone: string) => Linking.openURL(`tel:${phone.replace(/\s/g, "")}`);
  const handleEmail = (email: string) => Linking.openURL(`mailto:${email}`);
  const handleMaps = (address: string) => Linking.openURL(`https://maps.google.com/?q=${encodeURIComponent(address)}`);

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <AppHeader title="Informations" />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Résumé événement Neumorphism */}
        <View style={styles.eventSummary}>
          <View style={styles.eventSummaryCard}>
            <Text style={styles.eventSummaryName}>{event.name}</Text>
            <Text style={styles.eventSummaryDate}>
              {new Date(event.date).toLocaleDateString("fr-FR", {
                weekday: "long", day: "numeric", month: "long", year: "numeric",
              })}
            </Text>
            <View style={styles.divider} />
            <Text style={styles.eventSummaryVenue}>{event.venue}</Text>
          </View>
        </View>

        {/* Lieu */}
        <InfoCard icon="◈" title="Lieu">
          <InfoRow label="Nom du lieu" value={event.venue} />
          {event.address && (
            <InfoRow label="Adresse" value={event.address} onPress={() => handleMaps(event.address!)} />
          )}
          <Pressable
            onPress={() => event.address && handleMaps(event.address)}
            style={({ pressed }) => [styles.mapButton, pressed && { opacity: 0.7, transform: [{ scale: 0.97 }] }]}
          >
            <Text style={styles.mapButtonText}>Ouvrir dans Maps →</Text>
          </Pressable>
        </InfoCard>

        {/* Dress code */}
        {event.dressCode && (
          <InfoCard icon="✦" title="Dress Code">
            <Text style={styles.infoText}>{event.dressCode}</Text>
          </InfoCard>
        )}

        {/* Parking */}
        {event.parkingInfo && (
          <InfoCard icon="◉" title="Parking & Transports">
            <Text style={styles.infoText}>{event.parkingInfo}</Text>
          </InfoCard>
        )}

        {/* Hébergement */}
        {event.accommodationInfo && (
          <InfoCard icon="⬡" title="Hébergement">
            <Text style={styles.infoText}>{event.accommodationInfo}</Text>
          </InfoCard>
        )}

        {/* Contact organisateur */}
        {(event.organizerPhone || event.organizerEmail) && (
          <InfoCard icon="✉" title="Contact organisateur">
            {event.organizerPhone && (
              <InfoRow label="Téléphone" value={event.organizerPhone} onPress={() => handleCall(event.organizerPhone!)} />
            )}
            {event.organizerEmail && (
              <InfoRow label="Email" value={event.organizerEmail} onPress={() => handleEmail(event.organizerEmail!)} />
            )}
          </InfoCard>
        )}

        {/* Résumé programme */}
        <InfoCard icon="◈" title="Résumé du programme">
          {event.agenda.slice(0, 5).map((item) => (
            <View key={item.id} style={styles.programRow}>
              <Text style={styles.programTime}>{item.time}</Text>
              <Text style={styles.programTitle} numberOfLines={1}>{item.title}</Text>
            </View>
          ))}
          {event.agenda.length > 5 && (
            <Text style={styles.programMore}>+ {event.agenda.length - 5} autres étapes dans le programme</Text>
          )}
        </InfoCard>

        {/* Footer */}
        <View style={styles.footer}>
          <View style={styles.footerOrnament}>
            <View style={styles.footerLine} />
            <Text style={styles.footerDiamond}>✦</Text>
            <View style={styles.footerLine} />
          </View>
          <Text style={styles.footerText}>Avec tout notre amour</Text>
          <Text style={styles.footerSubtext}>Sophie & Alexandre</Text>
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  scrollContent: { paddingBottom: 16 },

  // Résumé événement
  eventSummary: { padding: 16, paddingBottom: 4 },
  eventSummaryCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 18,
    padding: 22,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 14,
    elevation: 10,
  },
  eventSummaryName: {
    fontSize: 20,
    fontWeight: "800",
    color: NEU.red,
    textAlign: "center",
    marginBottom: 6,
    letterSpacing: 0.3,
  },
  eventSummaryDate: {
    fontSize: 13,
    color: NEU.textSecondary,
    textAlign: "center",
    textTransform: "capitalize",
  },
  divider: {
    width: 50,
    height: 1,
    backgroundColor: "rgba(232,69,60,0.3)",
    marginVertical: 14,
  },
  eventSummaryVenue: {
    fontSize: 12,
    color: NEU.textSecondary,
    textAlign: "center",
    letterSpacing: 0.5,
  },

  // Carte info Neumorphism
  infoCard: {
    marginHorizontal: 16,
    marginBottom: 14,
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    overflow: "hidden",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },
  infoCardHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.25)",
    gap: 10,
  },
  iconWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.2)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 3,
  },
  infoCardIcon: { fontSize: 13, color: NEU.red },
  infoCardTitle: {
    fontSize: 11,
    fontWeight: "700",
    color: NEU.red,
    letterSpacing: 1.5,
    textTransform: "uppercase",
  },
  infoCardContent: { padding: 16 },

  infoRow: {
    paddingVertical: 9,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.2)",
  },
  infoRowLabel: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 1,
    marginBottom: 3,
    textTransform: "uppercase",
  },
  infoRowValue: { fontSize: 14, color: NEU.textPrimary, lineHeight: 20 },
  infoRowValueLink: { color: NEU.red },

  infoText: { fontSize: 14, color: NEU.textPrimary, lineHeight: 22 },

  mapButton: {
    marginTop: 12,
    alignSelf: "flex-start",
    backgroundColor: NEU.bgSunken,
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.3)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 3,
  },
  mapButtonText: { fontSize: 12, color: NEU.red, fontWeight: "700" },

  programRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.2)",
    gap: 12,
  },
  programTime: { fontSize: 12, fontWeight: "700", color: NEU.red, width: 44 },
  programTitle: { fontSize: 13, color: NEU.textPrimary, flex: 1 },
  programMore: {
    fontSize: 11, color: NEU.textSecondary, marginTop: 10, textAlign: "center", fontStyle: "italic",
  },

  // Footer
  footer: { alignItems: "center", paddingVertical: 32, gap: 8 },
  footerOrnament: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 8,
  },
  footerLine: { width: 40, height: 1, backgroundColor: "rgba(232,69,60,0.25)" },
  footerDiamond: { fontSize: 12, color: "rgba(232,69,60,0.5)" },
  footerText: { fontSize: 13, color: NEU.red, letterSpacing: 1 },
  footerSubtext: { fontSize: 12, color: NEU.textSecondary, letterSpacing: 0.5 },
});
