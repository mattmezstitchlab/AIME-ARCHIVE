import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  Animated,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AppHeader } from "@/components/app-header";
import { useAppContext } from "@/lib/app-context";
import { type AgendaItem, type EventCategory } from "@/lib/wedding-store";
import { useEffect, useRef, useState } from "react";
import { NEU } from "@/lib/neu-styles";

const CATEGORIES: { key: "all" | EventCategory; label: string }[] = [
  { key: "all", label: "Tout" },
  { key: "ceremony", label: "Cérémonie" },
  { key: "cocktail", label: "Cocktail" },
  { key: "dinner", label: "Dîner" },
  { key: "music", label: "Musique" },
  { key: "photo", label: "Photo" },
  { key: "logistics", label: "Logistique" },
];

const CATEGORY_COLORS: Record<EventCategory, string> = {
  ceremony: NEU.red,
  cocktail: NEU.info,
  dinner: "#a0c4a0",
  music: "#9b9bda",
  photo: "#da9b9b",
  logistics: "#9bbcda",
  other: "#9b9b8a",
};

function PulseBadge() {
  const pulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 0.3, duration: 600, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 600, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return (
    <View style={styles.liveBadge}>
      <Animated.View style={[styles.liveDot, { opacity: pulse }]} />
      <Text style={styles.liveBadgeText}>EN COURS</Text>
    </View>
  );
}

function TimelineItem({
  item,
  index,
  isLive,
  isExpanded,
  onToggle,
}: {
  item: AgendaItem;
  index: number;
  isLive: boolean;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const isLeft = index % 2 === 0;
  const catColor = CATEGORY_COLORS[item.category] ?? "#9b9b8a";

  const card = (
    <Pressable
      onPress={onToggle}
      style={({ pressed }) => [
        styles.timelineCard,
        isLeft ? styles.timelineCardLeft : styles.timelineCardRight,
        isLive && styles.timelineCardLive,
        pressed && { opacity: 0.82, transform: [{ scale: 0.98 }] },
      ]}
    >
      <View style={styles.cardHeader}>
        <Text style={[styles.cardTime, isLive && styles.cardTimeLive]}>{item.time}</Text>
        {isLive && <PulseBadge />}
      </View>
      <Text style={[styles.cardTitle, isLive && styles.cardTitleLive]} numberOfLines={2}>
        {item.title}
      </Text>
      <View style={[styles.categoryBar, { backgroundColor: catColor }]} />
      {isExpanded && (
        <View style={styles.cardExpanded}>
          {item.description && <Text style={styles.cardDesc}>{item.description}</Text>}
          {item.speaker && <Text style={styles.cardSpeaker}>✦ {item.speaker}</Text>}
          {item.location && <Text style={styles.cardLocation}>◈ {item.location}</Text>}
          {item.endTime && <Text style={styles.cardEndTime}>Fin : {item.endTime}</Text>}
        </View>
      )}
    </Pressable>
  );

  return (
    <View style={styles.timelineRow}>
      {isLeft ? card : <View style={styles.placeholder} />}

      {/* Centre Neumorphism */}
      <View style={styles.timelineCenter}>
        <View style={[styles.timelineNode, isLive && styles.timelineNodeLive]}>
          {isLive ? (
            <Text style={styles.timelineNodeText}>●</Text>
          ) : (
            <View style={styles.timelineNodeInner} />
          )}
        </View>
        <View style={styles.timelineLine} />
      </View>

      {!isLeft ? card : <View style={styles.placeholder} />}
    </View>
  );
}

export default function AgendaScreen() {
  const { event, currentAgendaItem } = useAppContext();
  const [filter, setFilter] = useState<"all" | EventCategory>("all");
  const [expandedId, setExpandedId] = useState<string | null>(currentAgendaItem?.id ?? null);

  if (!event) return null;

  const filteredAgenda =
    filter === "all" ? event.agenda : event.agenda.filter((item) => item.category === filter);

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <AppHeader title="Programme" />

      {/* Filtres Neumorphism */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterScroll}
        contentContainerStyle={styles.filterContent}
      >
        {CATEGORIES.map((cat) => (
          <Pressable
            key={cat.key}
            onPress={() => setFilter(cat.key)}
            style={({ pressed }) => [
              styles.filterChip,
              filter === cat.key && styles.filterChipActive,
              pressed && { opacity: 0.75, transform: [{ scale: 0.96 }] },
            ]}
          >
            <Text style={[styles.filterChipText, filter === cat.key && styles.filterChipTextActive]}>
              {cat.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* En-tête timeline */}
        <View style={styles.timelineHeader}>
          <Text style={styles.timelineTitle}>
            {new Date(event.date).toLocaleDateString("fr-FR", {
              weekday: "long", day: "numeric", month: "long",
            })}
          </Text>
          <Text style={styles.timelineSubtitle}>{filteredAgenda.length} étapes</Text>
        </View>

        {/* Timeline */}
        <View style={styles.timeline}>
          {filteredAgenda.map((item, index) => (
            <TimelineItem
              key={item.id}
              item={item}
              index={index}
              isLive={item.id === currentAgendaItem?.id}
              isExpanded={expandedId === item.id}
              onToggle={() => setExpandedId(expandedId === item.id ? null : item.id)}
            />
          ))}
          {/* Fin */}
          <View style={styles.timelineEnd}>
            <View style={styles.timelineEndNode} />
            <Text style={styles.timelineEndText}>FIN DE LA JOURNÉE</Text>
          </View>
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  // Filtres
  filterScroll: {
    flexGrow: 0,
    backgroundColor: NEU.bgRaised,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.3)",
  },
  filterContent: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.3)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 3,
  },
  filterChipActive: {
    backgroundColor: "rgba(232,69,60,0.1)",
    borderColor: "rgba(232,69,60,0.5)",
  },
  filterChipText: {
    fontSize: 12,
    color: NEU.textSecondary,
    fontWeight: "500",
  },
  filterChipTextActive: {
    color: NEU.red,
    fontWeight: "700",
  },

  scroll: { flex: 1 },
  scrollContent: { paddingBottom: 16 },

  // En-tête
  timelineHeader: {
    alignItems: "center",
    paddingVertical: 20,
    paddingHorizontal: 16,
  },
  timelineTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: NEU.red,
    letterSpacing: 0.3,
    textTransform: "capitalize",
  },
  timelineSubtitle: {
    fontSize: 10,
    color: NEU.textSecondary,
    marginTop: 4,
    letterSpacing: 1,
    textTransform: "uppercase",
  },

  timeline: { paddingHorizontal: 8 },

  timelineRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    minHeight: 80,
  },
  placeholder: { flex: 1 },

  // Centre de la timeline
  timelineCenter: {
    width: 40,
    alignItems: "center",
    paddingTop: 14,
  },
  timelineLine: {
    flex: 1,
    width: 1.5,
    backgroundColor: "rgba(232,69,60,0.25)",
    marginTop: 4,
    minHeight: 40,
  },
  timelineNode: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1.5,
    borderColor: "rgba(232,69,60,0.35)",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  timelineNodeLive: {
    borderColor: NEU.red,
    backgroundColor: "rgba(232,69,60,0.12)",
    shadowColor: NEU.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 8,
    elevation: 6,
  },
  timelineNodeInner: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: "rgba(232,69,60,0.45)",
  },
  timelineNodeText: {
    fontSize: 9,
    color: NEU.red,
  },

  // Cartes Neumorphism
  timelineCard: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 12,
    marginVertical: 6,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 10,
    elevation: 7,
    position: "relative",
  },
  timelineCardLeft: { marginRight: 4 },
  timelineCardRight: { marginLeft: 4 },
  timelineCardLive: {
    borderColor: "rgba(232,69,60,0.4)",
    backgroundColor: "rgba(232,69,60,0.05)",
  },

  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 5,
  },
  cardTime: {
    fontSize: 11,
    fontWeight: "700",
    color: NEU.textSecondary,
    letterSpacing: 0.5,
  },
  cardTimeLive: { color: NEU.red },
  cardTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: NEU.textPrimary,
    lineHeight: 18,
    marginBottom: 6,
  },
  cardTitleLive: { color: NEU.red },
  categoryBar: {
    width: 20,
    height: 3,
    borderRadius: 2,
    marginTop: 2,
  },
  cardExpanded: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 0.5,
    borderTopColor: "rgba(232,69,60,0.15)",
    gap: 5,
  },
  cardDesc: {
    fontSize: 11,
    color: NEU.textSecondary,
    lineHeight: 16,
  },
  cardSpeaker: {
    fontSize: 11,
    color: NEU.red,
    fontWeight: "500",
  },
  cardLocation: {
    fontSize: 11,
    color: NEU.textMuted,
  },
  cardEndTime: {
    fontSize: 10,
    color: NEU.textMuted,
    marginTop: 2,
  },

  // Live badge
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(74,222,128,0.1)",
    borderRadius: 5,
    paddingHorizontal: 5,
    paddingVertical: 2,
    gap: 3,
    borderWidth: 0.5,
    borderColor: "rgba(74,222,128,0.35)",
  },
  liveDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#4ade80",
  },
  liveBadgeText: {
    fontSize: 7,
    color: "#4ade80",
    fontWeight: "700",
    letterSpacing: 0.5,
  },

  // Fin de timeline
  timelineEnd: {
    alignItems: "center",
    paddingVertical: 20,
    gap: 8,
  },
  timelineEndNode: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.35)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 3,
  },
  timelineEndText: {
    fontSize: 9,
    color: NEU.textMuted,
    letterSpacing: 2,
    textTransform: "uppercase",
  },
});
