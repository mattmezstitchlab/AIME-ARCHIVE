import { View, Text, Pressable, StyleSheet, ScrollView, StatusBar } from "react-native";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { AppHeader } from "@/components/app-header";
import { useAppContext } from "@/lib/app-context";
import { NEU } from "@/lib/neu-styles";
import type { AgendaItem } from "@/lib/wedding-store";

function getCountdown(dateStr: string) {
  const target = new Date(dateStr).getTime();
  const now = Date.now();
  const diff = target - now;
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return { days, hours, minutes, seconds, isPast: false };
}

function CountdownBlock({ value, label, accent }: { value: number; label: string; accent: string }) {
  return (
    <View style={[styles.countdownBlock, { borderColor: `${accent}30` }]}>
      <Text style={[styles.countdownValue, { color: accent }]}>{String(value).padStart(2, "0")}</Text>
      <Text style={styles.countdownLabel}>{label}</Text>
    </View>
  );
}

function LiveBadge() {
  return (
    <View style={styles.liveBadge}>
      <View style={styles.liveDot} />
      <Text style={styles.liveBadgeText}>LIVE</Text>
    </View>
  );
}

function AgendaPreviewCard({ item, isLive }: { item: AgendaItem; isLive: boolean }) {
  const router = useRouter();
  return (
    <Pressable
      onPress={() => router.push("/(tabs)/agenda")}
      style={({ pressed }) => [
        styles.agendaCard,
        isLive && styles.agendaCardLive,
        pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
      ]}
    >
      <View style={styles.agendaCardLeft}>
        <Text style={[styles.agendaTime, isLive && styles.agendaTimeLive]}>{item.time}</Text>
        {item.endTime && <Text style={styles.agendaEndTime}>{item.endTime}</Text>}
      </View>
      <View style={styles.agendaCardRight}>
        <View style={styles.agendaCardTitleRow}>
          <Text style={[styles.agendaTitle, isLive && styles.agendaTitleLive]} numberOfLines={1}>
            {item.title}
          </Text>
          {isLive && <LiveBadge />}
        </View>
        {item.speaker && <Text style={styles.agendaSpeaker} numberOfLines={1}>✦ {item.speaker}</Text>}
        {item.location && <Text style={styles.agendaLocation} numberOfLines={1}>◈ {item.location}</Text>}
      </View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const { event, currentAgendaItem, userRole } = useAppContext();
  const [countdown, setCountdown] = useState(
    event ? getCountdown(event.date) : { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: false }
  );
  const router = useRouter();

  useEffect(() => {
    if (!event) return;
    const timer = setInterval(() => setCountdown(getCountdown(event.date)), 1000);
    return () => clearInterval(timer);
  }, [event]);

  if (!event) return null;

  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const upcomingItems = event.agenda.filter((item) => item.time >= hhmm).slice(0, 3);
  const displayItems = upcomingItems.length > 0 ? upcomingItems : event.agenda.slice(0, 3);
  const confirmedVendors = event.vendors.filter((v) => v.status === "confirmed" || v.status === "arrived").length;

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <StatusBar barStyle="dark-content" backgroundColor={NEU.bg} />
      <AppHeader />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero */}
        <View style={styles.heroSection}>
          <Text style={styles.heroDate}>
            {new Date(event.date).toLocaleDateString("fr-FR", {
              weekday: "long", day: "numeric", month: "long", year: "numeric",
            })}
          </Text>
          <Text style={styles.heroName}>{event.name}</Text>
          <Text style={styles.heroVenue}>◈ {event.venue}</Text>
          {/* Ligne décorative néon */}
          <View style={styles.heroDivider} />
        </View>

        {/* Countdown Neon Neumorphism */}
        {!countdown.isPast && (
          <View style={styles.countdownContainer}>
            <Text style={styles.countdownTitle}>COMPTE À REBOURS</Text>
            <View style={styles.countdownRow}>
              <CountdownBlock value={countdown.days} label="jours" accent={NEU.red} />
              <Text style={styles.countdownSep}>:</Text>
              <CountdownBlock value={countdown.hours} label="h" accent={NEU.info} />
              <Text style={styles.countdownSep}>:</Text>
              <CountdownBlock value={countdown.minutes} label="min" accent={NEU.warning} />
              <Text style={styles.countdownSep}>:</Text>
              <CountdownBlock value={countdown.seconds} label="sec" accent={NEU.red} />
            </View>
          </View>
        )}

        {countdown.isPast && (
          <View style={styles.dayJBanner}>
            <Text style={styles.dayJText}>✦ Jour J ✦</Text>
            <Text style={styles.dayJSubtext}>Le grand jour est arrivé !</Text>
          </View>
        )}

        {/* Stats Neon */}
        <View style={styles.statsRow}>
          {[
            { value: event.agenda.length, label: "Étapes", route: "/(tabs)/agenda", accent: NEU.red },
            { value: confirmedVendors, label: "Prestataires", route: "/(tabs)/vendors", accent: NEU.info },
            { value: event.registrations.length, label: "Inscrits", route: "/(tabs)/register", accent: NEU.warning },
          ].map((stat) => (
            <Pressable
              key={stat.label}
              onPress={() => router.push(stat.route as any)}
              style={({ pressed }) => [styles.statCard, pressed && { opacity: 0.75, transform: [{ scale: 0.97 }] }]}
            >
              <Text style={[styles.statValue, { color: stat.accent }]}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Programme */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>
              {countdown.isPast ? "PROGRAMME DU JOUR" : "PROGRAMME À VENIR"}
            </Text>
            <Pressable onPress={() => router.push("/(tabs)/agenda")} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
              <Text style={styles.seeAll}>Tout voir →</Text>
            </Pressable>
          </View>

          {currentAgendaItem && <AgendaPreviewCard item={currentAgendaItem} isLive={true} />}
          {displayItems
            .filter((item) => item.id !== currentAgendaItem?.id)
            .map((item) => <AgendaPreviewCard key={item.id} item={item} isLive={false} />)}
        </View>

        {/* Accès rapide */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ACCÈS RAPIDE</Text>
          <View style={styles.quickActionsRow}>
            {[
              { icon: "✦", label: "Prestataires", route: "/(tabs)/vendors", accent: NEU.info },
              { icon: "◈", label: "Inscription", route: "/(tabs)/register", accent: NEU.warning },
              { icon: "◉", label: "Infos", route: "/(tabs)/info", accent: NEU.red },
            ].map((action) => (
              <Pressable
                key={action.label}
                onPress={() => router.push(action.route as any)}
                style={({ pressed }) => [styles.quickAction, pressed && { opacity: 0.75, transform: [{ scale: 0.95 }] }]}
              >
                <View style={[styles.quickActionIconWrap, { borderColor: `${action.accent}30` }]}>
                  <Text style={[styles.quickActionIcon, { color: action.accent }]}>{action.icon}</Text>
                </View>
                <Text style={styles.quickActionLabel}>{action.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Espace Prestataire — vendor only */}
        {userRole === "vendor" && (
          <View style={styles.section}>
            <Pressable
              onPress={() => router.push("/vendor-dashboard" as any)}
              style={({ pressed }) => [
                styles.adminButton,
                styles.vendorButton,
                pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
              ]}
            >
              <View style={styles.adminButtonInner}>
                <View style={[styles.adminIconWrap, styles.vendorIconWrap]}>
                  <Text style={[styles.adminButtonIcon, { color: NEU.info }]}>✦</Text>
                </View>
                <View style={styles.adminButtonTextGroup}>
                  <Text style={[styles.adminButtonTitle, { color: NEU.info }]}>Mon Espace Prestataire</Text>
                  <Text style={styles.adminButtonSub}>Arrivée · Plan d'accès · Checklist</Text>
                </View>
                <Text style={[styles.adminButtonArrow, { color: `${NEU.info}60` }]}>→</Text>
              </View>
            </Pressable>
          </View>
        )}

        {/* Admin — couple only */}
        {userRole === "couple" && (
          <View style={styles.section}>
            <Pressable
              onPress={() => router.push("/admin")}
              style={({ pressed }) => [
                styles.adminButton,
                pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
              ]}
            >
              <View style={styles.adminButtonInner}>
                <View style={styles.adminIconWrap}>
                  <Text style={styles.adminButtonIcon}>◉</Text>
                </View>
                <View style={styles.adminButtonTextGroup}>
                  <Text style={styles.adminButtonTitle}>Espace Administration</Text>
                  <Text style={styles.adminButtonSub}>Inscriptions · Régimes · Programme</Text>
                </View>
                <Text style={styles.adminButtonArrow}>→</Text>
              </View>
            </Pressable>
          </View>
        )}

        <View style={{ height: 24 }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  scrollContent: { paddingBottom: 16 },

  // Hero
  heroSection: {
    alignItems: "center",
    paddingVertical: 28,
    paddingHorizontal: 24,
  },
  heroDate: {
    fontSize: 10,
    color: NEU.textSecondary,
    letterSpacing: 2,
    textTransform: "uppercase",
    marginBottom: 8,
  },
  heroName: {
    fontSize: 26,
    fontWeight: "800",
    color: NEU.textPrimary,
    textAlign: "center",
    letterSpacing: 0.3,
    marginBottom: 8,
  },
  heroVenue: {
    fontSize: 13,
    color: NEU.textSecondary,
    textAlign: "center",
    marginBottom: 16,
  },
  heroDivider: {
    width: 48,
    height: 2,
    backgroundColor: NEU.red,
    borderRadius: 1,
    shadowColor: NEU.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 8,
  },

  // Countdown
  countdownContainer: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: NEU.bgRaised,
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    alignItems: "center",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 10,
  },
  countdownTitle: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 2.5,
    marginBottom: 16,
    textTransform: "uppercase",
  },
  countdownRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  countdownBlock: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    alignItems: "center",
    minWidth: 58,
    borderWidth: 1,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 6,
    elevation: 4,
  },
  countdownValue: {
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  countdownLabel: {
    fontSize: 9,
    color: NEU.textMuted,
    letterSpacing: 0.5,
    marginTop: 2,
  },
  countdownSep: {
    fontSize: 22,
    color: NEU.textMuted,
    fontWeight: "300",
  },

  // Jour J
  dayJBanner: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: "rgba(232,69,60,0.08)",
    borderRadius: 20,
    padding: 20,
    alignItems: "center",
    borderWidth: 1,
    borderColor: NEU.redBorder,
    shadowColor: NEU.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  dayJText: {
    fontSize: 22,
    fontWeight: "800",
    color: NEU.red,
    letterSpacing: 2,
  },
  dayJSubtext: {
    fontSize: 13,
    color: NEU.textSecondary,
    marginTop: 4,
  },

  // Stats
  statsRow: {
    flexDirection: "row",
    marginHorizontal: 16,
    marginBottom: 16,
    gap: 10,
  },
  statCard: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 8,
  },
  statValue: {
    fontSize: 26,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 9,
    color: NEU.textSecondary,
    letterSpacing: 0.5,
    marginTop: 4,
    textTransform: "uppercase",
  },

  // Section
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 10,
    fontWeight: "700",
    color: NEU.textSecondary,
    letterSpacing: 2,
    textTransform: "uppercase",
  },
  seeAll: {
    fontSize: 12,
    color: NEU.red,
    fontWeight: "600",
  },

  // Agenda card
  agendaCard: {
    flexDirection: "row",
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.55,
    shadowRadius: 10,
    elevation: 6,
    gap: 12,
  },
  agendaCardLive: {
    borderColor: NEU.redBorder,
    backgroundColor: "rgba(232,69,60,0.05)",
  },
  agendaCardLeft: {
    alignItems: "center",
    minWidth: 44,
  },
  agendaTime: {
    fontSize: 14,
    fontWeight: "700",
    color: NEU.textSecondary,
  },
  agendaTimeLive: {
    color: NEU.red,
  },
  agendaEndTime: {
    fontSize: 10,
    color: NEU.textMuted,
    marginTop: 2,
  },
  agendaCardRight: {
    flex: 1,
  },
  agendaCardTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 4,
  },
  agendaTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: NEU.textPrimary,
    flex: 1,
  },
  agendaTitleLive: {
    color: NEU.red,
  },
  agendaSpeaker: {
    fontSize: 11,
    color: NEU.info,
    marginBottom: 2,
  },
  agendaLocation: {
    fontSize: 11,
    color: NEU.textMuted,
  },

  // Live badge
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(232,69,60,0.12)",
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    gap: 4,
    borderWidth: 0.5,
    borderColor: NEU.redBorder,
  },
  liveDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: NEU.red,
    shadowColor: NEU.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 4,
  },
  liveBadgeText: {
    fontSize: 8,
    color: NEU.red,
    fontWeight: "700",
    letterSpacing: 0.5,
  },

  // Quick actions
  quickActionsRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 10,
  },
  quickAction: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.55,
    shadowRadius: 10,
    elevation: 6,
    gap: 10,
  },
  quickActionIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 6,
    elevation: 4,
  },
  quickActionIcon: {
    fontSize: 18,
  },
  quickActionLabel: {
    fontSize: 10,
    color: NEU.textSecondary,
    textAlign: "center",
    letterSpacing: 0.3,
  },

  // Admin button
  adminButton: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: NEU.redBorder,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 8,
    overflow: "hidden",
  },
  adminButtonInner: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    gap: 14,
  },
  adminIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: NEU.redBorder,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 6,
    elevation: 4,
  },
  adminButtonIcon: {
    fontSize: 20,
    color: NEU.red,
  },
  adminButtonTextGroup: {
    flex: 1,
  },
  adminButtonTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: NEU.red,
    marginBottom: 2,
  },
  adminButtonSub: {
    fontSize: 11,
    color: NEU.textSecondary,
    letterSpacing: 0.3,
  },
  adminButtonArrow: {
    fontSize: 18,
    color: `${NEU.red}60`,
  },
  // Vendor button
  vendorButton: {
    borderColor: NEU.borderSubtle,
    backgroundColor: "rgba(0,212,255,0.03)",
  },
  vendorIconWrap: {
    borderColor: NEU.borderSubtle,
    backgroundColor: "rgba(0,212,255,0.07)",
  },
});
