/**
 * Vendor Dashboard — Écran dédié Prestataire
 *
 * Vue spécifique pour le rôle "Prestataire" :
 *   - Heure d'arrivée en grand format (hero)
 *   - Statut actuel avec bouton "Je suis arrivé·e"
 *   - Plan d'accès (adresse + instructions)
 *   - Checklist des tâches du jour (persistée AsyncStorage)
 *   - Programme de la journée (étapes concernées)
 *   - Contact organisateur
 */

import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  StatusBar,
  Linking,
  Alert,
  Platform,
} from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useAppContext } from "@/lib/app-context";
import { NEU, neuStyles } from "@/lib/neu-styles";
import { NeuButton } from "@/components/ui/neu-button";

// ─── Types ────────────────────────────────────────────────────────────────────

interface ChecklistItem {
  id: string;
  label: string;
  done: boolean;
  time?: string;
}

const STORAGE_KEY = "vendor_checklist";

// ─── Default Checklist ────────────────────────────────────────────────────────

const DEFAULT_CHECKLIST: ChecklistItem[] = [
  { id: "c1", label: "Prendre contact avec le coordinateur à l'arrivée", done: false, time: "09:30" },
  { id: "c2", label: "Vérifier l'emplacement dédié à votre prestation", done: false, time: "09:45" },
  { id: "c3", label: "Installer et tester votre matériel", done: false, time: "10:00" },
  { id: "c4", label: "Confirmer le planning avec l'équipe", done: false, time: "10:30" },
  { id: "c5", label: "Préparer votre espace pour la cérémonie", done: false, time: "11:00" },
  { id: "c6", label: "Vérification finale avant le début", done: false, time: "11:30" },
  { id: "c7", label: "Rangement et débrief en fin de journée", done: false },
];

// ─── Component ────────────────────────────────────────────────────────────────

export default function VendorDashboardScreen() {
  const router = useRouter();
  const { event, adminUpdateVendorStatus } = useAppContext();
  const vendors = event?.vendors ?? [];
  const updateVendorStatus = adminUpdateVendorStatus;
  const [checklist, setChecklist] = useState<ChecklistItem[]>(DEFAULT_CHECKLIST);
  const [hasArrived, setHasArrived] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Trouver le prestataire actuel (premier vendor par défaut pour la démo)
  const currentVendor = vendors[0] ?? null;

  // Horloge en temps réel
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Charger la checklist depuis AsyncStorage
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          setChecklist(JSON.parse(raw));
        } catch {
          // ignore
        }
      }
    });
  }, []);

  // Sauvegarder la checklist
  const saveChecklist = useCallback(async (items: ChecklistItem[]) => {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, []);

  const toggleItem = useCallback(
    (id: string) => {
      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
      setChecklist((prev) => {
        const updated = prev.map((item) =>
          item.id === id ? { ...item, done: !item.done } : item
        );
        saveChecklist(updated);
        return updated;
      });
    },
    [saveChecklist]
  );

  const handleArrived = useCallback(() => {
    Alert.alert(
      "Confirmer votre arrivée",
      "Voulez-vous signaler votre arrivée aux organisateurs ?",
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Confirmer",
          onPress: async () => {
            setHasArrived(true);
            if (currentVendor) {
              await updateVendorStatus(currentVendor.id, "arrived");
            }
            if (Platform.OS !== "web") {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }
          },
        },
      ]
    );
  }, [currentVendor, updateVendorStatus]);

  const handleCall = useCallback((phone: string) => {
    Linking.openURL(`tel:${phone}`);
  }, []);

  const handleEmail = useCallback((email: string) => {
    Linking.openURL(`mailto:${email}`);
  }, []);

  // Formatage heure
  const formatHour = (date: Date) =>
    date.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

  const completedCount = checklist.filter((i) => i.done).length;
  const progressPct = Math.round((completedCount / checklist.length) * 100);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <StatusBar barStyle="dark-content" backgroundColor={NEU.bg} />

        <ScrollView
          contentContainerStyle={styles.scroll}
          showsVerticalScrollIndicator={false}
        >
          {/* ── Header ── */}
          <View style={styles.header}>
            <Pressable
              onPress={() => router.back()}
              style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.7 }]}
            >
              <Text style={styles.backIcon}>←</Text>
            </Pressable>
            <Text style={styles.headerTitle}>Mon Espace</Text>
            <View style={styles.headerRight}>
              <Text style={styles.liveTime}>{formatHour(currentTime)}</Text>
            </View>
          </View>

          {/* ── Hero : Heure d'arrivée ── */}
          <View style={styles.heroCard}>
            {/* Glow */}
            <View style={styles.heroGlow} />

            <Text style={styles.heroLabel}>HEURE D'ARRIVÉE PRÉVUE</Text>
            <Text style={styles.heroTime}>
              {currentVendor?.arrivalTime ?? "10:00"}
            </Text>

            {currentVendor && (
              <View style={styles.heroVendorRow}>
                <View style={styles.heroAvatar}>
                  <Text style={styles.heroAvatarText}>
                    {currentVendor.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <View>
                  <Text style={styles.heroVendorName}>{currentVendor.name}</Text>
                  <Text style={styles.heroVendorRole}>{currentVendor.role}</Text>
                </View>
              </View>
            )}

            {/* Statut */}
            <View style={[
              styles.statusBadge,
              hasArrived && styles.statusBadgeArrived,
            ]}>
              <View style={[
                styles.statusDot,
                hasArrived && styles.statusDotArrived,
              ]} />
              <Text style={[
                styles.statusText,
                hasArrived && styles.statusTextArrived,
              ]}>
                {hasArrived ? "Arrivé·e — Confirmé" : "En attente d'arrivée"}
              </Text>
            </View>
          </View>

          {/* ── Bouton Je suis arrivé ── */}
          {!hasArrived && (
            <NeuButton
              label="✓  Je suis arrivé·e"
              onPress={handleArrived}
              fullWidth
              size="lg"
              style={styles.arrivedBtn}
            />
          )}

          {hasArrived && (
            <View style={styles.arrivedConfirm}>
              <Text style={styles.arrivedConfirmText}>
                ✓  Arrivée confirmée — Les organisateurs ont été notifiés
              </Text>
            </View>
          )}

          {/* ── Plan d'accès ── */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>PLAN D'ACCÈS</Text>
            <View style={styles.accessCard}>
              <View style={styles.accessRow}>
                <View style={styles.accessIcon}>
                  <Text style={styles.accessIconText}>📍</Text>
                </View>
                <View style={styles.accessInfo}>
                  <Text style={styles.accessVenueName}>
                    {event?.venue ?? "Château de Vaux-le-Vicomte"}
                  </Text>
                  <Text style={styles.accessAddress}>
                    {event?.address ?? "77950 Maincy, Seine-et-Marne"}
                  </Text>
                </View>
              </View>

              <View style={styles.accessDivider} />

              <View style={styles.instructionsList}>
                <View style={styles.instructionItem}>
                  <Text style={styles.instructionBullet}>→</Text>
                  <Text style={styles.instructionText}>
                    Accès prestataires par l'entrée de service (côté nord)
                  </Text>
                </View>
                <View style={styles.instructionItem}>
                  <Text style={styles.instructionBullet}>→</Text>
                  <Text style={styles.instructionText}>
                    Parking réservé prestataires : zone P3 (fléché depuis l'entrée)
                  </Text>
                </View>
                <View style={styles.instructionItem}>
                  <Text style={styles.instructionBullet}>→</Text>
                  <Text style={styles.instructionText}>
                    Badge d'accès à récupérer auprès du coordinateur à l'accueil
                  </Text>
                </View>
                <View style={styles.instructionItem}>
                  <Text style={styles.instructionBullet}>→</Text>
                  <Text style={styles.instructionText}>
                    Déchargement autorisé jusqu'à 11h00 — zone de livraison balisée
                  </Text>
                </View>
              </View>

              <NeuButton
                label="Ouvrir dans Maps"
                onPress={() => {
                  const addr = encodeURIComponent(event?.address ?? "Château de Vaux-le-Vicomte, Maincy");
                  Linking.openURL(`https://maps.apple.com/?q=${addr}`);
                }}
                variant="secondary"
                size="sm"
                style={{ marginTop: 14 }}
              />
            </View>
          </View>

          {/* ── Checklist tâches ── */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>CHECKLIST DU JOUR</Text>
              <View style={styles.progressBadge}>
                <Text style={styles.progressText}>{completedCount}/{checklist.length}</Text>
              </View>
            </View>

            {/* Barre de progression */}
            <View style={styles.progressBarBg}>
              <View style={[styles.progressBarFill, { width: `${progressPct}%` as any }]} />
            </View>

            <View style={styles.checklistContainer}>
              {checklist.map((item) => (
                <Pressable
                  key={item.id}
                  onPress={() => toggleItem(item.id)}
                  style={({ pressed }) => [
                    styles.checklistItem,
                    item.done && styles.checklistItemDone,
                    pressed && { opacity: 0.8 },
                  ]}
                >
                  {/* Checkbox */}
                  <View style={[styles.checkbox, item.done && styles.checkboxDone]}>
                    {item.done && <Text style={styles.checkboxCheck}>✓</Text>}
                  </View>

                  {/* Label */}
                  <View style={styles.checklistTextWrap}>
                    <Text style={[styles.checklistLabel, item.done && styles.checklistLabelDone]}>
                      {item.label}
                    </Text>
                    {item.time && (
                      <Text style={styles.checklistTime}>{item.time}</Text>
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          </View>

          {/* ── Contact organisateur ── */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>CONTACT ORGANISATEUR</Text>
            <View style={styles.contactCard}>
              <View style={styles.contactRow}>
                <View style={styles.contactAvatar}>
                  <Text style={styles.contactAvatarText}>
                    {event?.organizerPhone?.charAt(0)?.toUpperCase() ?? "O"}
                  </Text>
                </View>
                <View style={styles.contactInfo}>
                  <Text style={styles.contactName}>
                    {event?.organizerEmail ? event.organizerEmail.split("@")[0] : "Sophie & Alexandre"}
                  </Text>
                  <Text style={styles.contactRole}>Organisateurs</Text>
                </View>
              </View>

              <View style={styles.contactBtns}>
                {event?.organizerPhone && (
                  <NeuButton
                    label="📞  Appeler"
                    onPress={() => handleCall(event.organizerPhone!)}
                    variant="success"
                    size="sm"
                    style={{ flex: 1 }}
                  />
                )}
                {event?.organizerEmail && (
                  <NeuButton
                    label="✉  Email"
                    onPress={() => handleEmail(event.organizerEmail!)}
                    variant="secondary"
                    size="sm"
                    style={{ flex: 1 }}
                  />
                )}
              </View>
            </View>
          </View>

          <View style={{ height: 32 }} />
        </ScrollView>
      </View>
    </GestureHandlerRootView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: NEU.bg,
  },
  scroll: {
    paddingBottom: 40,
  },

  // ── Header ──
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
    backgroundColor: NEU.bgMid,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 8,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: NEU.bgRaised,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 7,
    elevation: 6,
  },
  backIcon: {
    fontSize: 18,
    color: NEU.textSecondary,
    fontWeight: "600",
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: NEU.textPrimary,
    letterSpacing: 0.3,
  },
  headerRight: {
    width: 38,
    alignItems: "flex-end",
  },
  liveTime: {
    fontSize: 13,
    fontWeight: "600",
    color: NEU.red,
    letterSpacing: 0.5,
  },

  // ── Hero ──
  heroCard: {
    margin: 20,
    borderRadius: 22,
    padding: 28,
    backgroundColor: NEU.bgRaised,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.2)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 8, height: 8 },
    shadowOpacity: 1,
    shadowRadius: 18,
    elevation: 14,
    alignItems: "center",
    overflow: "hidden",
  },
  heroGlow: {
    position: "absolute",
    top: -30,
    left: "50%",
    marginLeft: -60,
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "rgba(232,69,60,0.06)",
  },
  heroLabel: {
    fontSize: 10,
    fontWeight: "700",
    color: NEU.textSecondary,
    letterSpacing: 2.5,
    marginBottom: 8,
  },
  heroTime: {
    fontSize: 64,
    fontWeight: "800",
    color: NEU.red,
    letterSpacing: -2,
    lineHeight: 72,
    marginBottom: 16,
  },
  heroVendorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 18,
  },
  heroAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.25)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.45,
    shadowRadius: 6,
    elevation: 5,
  },
  heroAvatarText: {
    fontSize: 16,
    fontWeight: "700",
    color: NEU.red,
  },
  heroVendorName: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.textPrimary,
  },
  heroVendorRole: {
    fontSize: 12,
    color: NEU.textSecondary,
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: "rgba(251,191,36,0.08)",
    borderWidth: 1,
    borderColor: "rgba(251,191,36,0.2)",
  },
  statusBadgeArrived: {
    backgroundColor: "rgba(74,222,128,0.08)",
    borderColor: "rgba(74,222,128,0.25)",
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: "#FBBF24",
  },
  statusDotArrived: {
    backgroundColor: "#4ade80",
  },
  statusText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#FBBF24",
    letterSpacing: 0.3,
  },
  statusTextArrived: {
    color: "#4ade80",
  },

  // ── Bouton arrivée ──
  arrivedBtn: {
    marginHorizontal: 20,
    marginBottom: 16,
  },
  arrivedConfirm: {
    marginHorizontal: 20,
    marginBottom: 16,
    padding: 14,
    borderRadius: 12,
    backgroundColor: "rgba(74,222,128,0.07)",
    borderWidth: 1,
    borderColor: "rgba(74,222,128,0.2)",
    alignItems: "center",
  },
  arrivedConfirmText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#4ade80",
    textAlign: "center",
    letterSpacing: 0.2,
  },

  // ── Sections ──
  section: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 10,
    fontWeight: "700",
    color: NEU.textSecondary,
    letterSpacing: 2.5,
    marginBottom: 12,
  },

  // ── Plan d'accès ──
  accessCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.55,
    shadowRadius: 12,
    elevation: 9,
  },
  accessRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 14,
    marginBottom: 14,
  },
  accessIcon: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.15)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.45,
    shadowRadius: 6,
    elevation: 4,
  },
  accessIconText: {
    fontSize: 20,
  },
  accessInfo: {
    flex: 1,
  },
  accessVenueName: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.textPrimary,
  },
  accessAddress: {
    fontSize: 12,
    color: NEU.textSecondary,
    marginTop: 3,
  },
  accessDivider: {
    height: 1,
    backgroundColor: "rgba(0,0,0,0.06)",
    marginBottom: 14,
  },
  instructionsList: {
    gap: 10,
  },
  instructionItem: {
    flexDirection: "row",
    gap: 10,
    alignItems: "flex-start",
  },
  instructionBullet: {
    fontSize: 13,
    color: NEU.red,
    fontWeight: "700",
    marginTop: 1,
  },
  instructionText: {
    flex: 1,
    fontSize: 13,
    color: NEU.textSecondary,
    lineHeight: 19,
  },

  // ── Checklist ──
  progressBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: "rgba(232,69,60,0.1)",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.25)",
  },
  progressText: {
    fontSize: 11,
    fontWeight: "700",
    color: NEU.red,
  },
  progressBarBg: {
    height: 4,
    borderRadius: 2,
    backgroundColor: NEU.bgSunken,
    marginBottom: 14,
    overflow: "hidden",
  },
  progressBarFill: {
    height: 4,
    borderRadius: 2,
    backgroundColor: NEU.red,
  },
  checklistContainer: {
    gap: 10,
  },
  checklistItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 9,
    elevation: 7,
  },
  checklistItemDone: {
    backgroundColor: NEU.bgSunken,
    borderColor: "rgba(74,222,128,0.12)",
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 2,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 8,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1.5,
    borderColor: "rgba(0,0,0,0.08)",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 3,
  },
  checkboxDone: {
    backgroundColor: "rgba(74,222,128,0.1)",
    borderColor: "#4ade80",
  },
  checkboxCheck: {
    fontSize: 12,
    color: "#4ade80",
    fontWeight: "800",
  },
  checklistTextWrap: {
    flex: 1,
  },
  checklistLabel: {
    fontSize: 13,
    fontWeight: "500",
    color: NEU.textPrimary,
    lineHeight: 18,
  },
  checklistLabelDone: {
    color: NEU.textMuted,
    textDecorationLine: "line-through",
  },
  checklistTime: {
    fontSize: 11,
    color: NEU.red,
    marginTop: 3,
    fontWeight: "600",
  },

  // ── Contact ──
  contactCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.55,
    shadowRadius: 12,
    elevation: 9,
    gap: 14,
  },
  contactRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  contactAvatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.2)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.45,
    shadowRadius: 6,
    elevation: 5,
  },
  contactAvatarText: {
    fontSize: 18,
    fontWeight: "700",
    color: NEU.red,
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.textPrimary,
  },
  contactRole: {
    fontSize: 12,
    color: NEU.textSecondary,
    marginTop: 2,
  },
  contactBtns: {
    flexDirection: "row",
    gap: 10,
  },
});
