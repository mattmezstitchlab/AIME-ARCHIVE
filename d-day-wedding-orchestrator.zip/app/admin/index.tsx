import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  FlatList,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Switch,
  ActivityIndicator,
  Linking,
} from "react-native";
import { NEU } from "@/lib/neu-styles";
import { ScreenContainer } from "@/components/screen-container";
import { useAppContext } from "@/lib/app-context";
import {
  analyzeDietaryRestrictions,
  getCategoryLabel,
  cycleVendorStatus,
  getVendorStatusLabel,
  getVendorStatusColor,
  loadEvent,
  saveEvent,
  type AgendaItem,
  type GuestRegistration,
  type EventCategory,
  type Vendor,
} from "@/lib/wedding-store";
import { useState, useCallback, useEffect } from "react";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { trpc } from "@/lib/trpc";

const PIN_KEY = "ddw_admin_pin";

// ─── Types ────────────────────────────────────────────────────────────────────

type AdminTab = "dashboard" | "registrations" | "dietary" | "agenda" | "vendors" | "settings" | "alerts" | "qrcodes" | "notifications";

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatCard({
  value,
  label,
  color,
  onPress,
}: {
  value: number | string;
  label: string;
  color?: string;
  onPress?: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [styles.statCard, pressed && onPress && { opacity: 0.7 }]}
    >
      <Text style={[styles.statValue, { color: color ?? NEU.red }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </Pressable>
  );
}

// ─── Dashboard Tab ────────────────────────────────────────────────────────────

function DashboardTab({ onNavigate }: { onNavigate: (tab: AdminTab) => void }) {
  const { event } = useAppContext();
  if (!event) return null;

  const regs = event.registrations;
  const totalGuests = regs.reduce((acc, r) => acc + 1 + (r.plusOne ? 1 : 0), 0);
  const attendsCeremony = regs.filter((r) => r.attendsCeremony).length;
  const attendsCocktail = regs.filter((r) => r.attendsCocktail).length;
  const attendsDinner = regs.filter((r) => r.attendsDinner).length;
  const withDietary = regs.filter((r) => r.dietaryRestrictions?.trim()).length;
  const withMessages = regs.filter((r) => r.message?.trim()).length;

  return (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      {/* Event info */}
      <View style={styles.eventBanner}>
        <Text style={styles.eventBannerName}>{event.name}</Text>
        <Text style={styles.eventBannerDate}>
          {new Date(event.date).toLocaleDateString("fr-FR", {
            weekday: "long",
            day: "numeric",
            month: "long",
            year: "numeric",
          })}
        </Text>
        <Text style={styles.eventBannerVenue}>◈ {event.venue}</Text>
      </View>

      {/* Main stats */}
      <Text style={styles.sectionTitle}>Inscriptions</Text>
      <View style={styles.statsGrid}>
        <StatCard
          value={regs.length}
          label="Formulaires"
          color={NEU.red}
          onPress={() => onNavigate("registrations")}
        />
        <StatCard
          value={totalGuests}
          label="Personnes"
          color="#4ade80"
        />
        <StatCard
          value={withDietary}
          label="Régimes"
          color="#FBBF24"
          onPress={() => onNavigate("dietary")}
        />
      </View>

      {/* Presence breakdown */}
      <Text style={styles.sectionTitle}>Présence par moment</Text>
      <View style={styles.presenceCard}>
        <PresenceRow
          label="Cérémonie"
          count={attendsCeremony}
          total={regs.length}
          color={NEU.red}
        />
        <PresenceRow
          label="Cocktail"
          count={attendsCocktail}
          total={regs.length}
          color="#e8d5a3"
        />
        <PresenceRow
          label="Dîner"
          count={attendsDinner}
          total={regs.length}
          color="#a0c4a0"
        />
      </View>

      {/* Agenda stats */}
      <Text style={styles.sectionTitle}>Programme</Text>
      <View style={styles.statsGrid}>
        <StatCard
          value={event.agenda.length}
          label="Étapes"
          color={NEU.red}
          onPress={() => onNavigate("agenda")}
        />
        <StatCard
          value={event.vendors.filter((v) => v.status === "arrived").length}
          label="Arrivés"
          color="#4ade80"
        />
        <StatCard
          value={event.vendors.filter((v) => v.status === "pending").length}
          label="En attente"
          color="#FBBF24"
        />
      </View>

      {/* Messages */}
      {withMessages > 0 && (
        <>
          <Text style={styles.sectionTitle}>Messages des invités</Text>
          {regs
            .filter((r) => r.message?.trim())
            .slice(0, 3)
            .map((r) => (
              <View key={r.id} style={styles.messageCard}>
                <Text style={styles.messageName}>
                  {r.firstName} {r.lastName}
                </Text>
                <Text style={styles.messageText}>{r.message}</Text>
              </View>
            ))}
          {withMessages > 3 && (
            <Pressable
              onPress={() => onNavigate("registrations")}
              style={({ pressed }) => [styles.seeMoreBtn, pressed && { opacity: 0.7 }]}
            >
              <Text style={styles.seeMoreText}>
                Voir tous les messages ({withMessages}) →
              </Text>
            </Pressable>
          )}
        </>
      )}

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

function PresenceRow({
  label,
  count,
  total,
  color,
}: {
  label: string;
  count: number;
  total: number;
  color: string;
}) {
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <View style={styles.presenceRow}>
      <Text style={styles.presenceLabel}>{label}</Text>
      <View style={styles.presenceBarContainer}>
        <View style={[styles.presenceBar, { width: `${pct}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.presenceCount, { color }]}>
        {count}/{total}
      </Text>
    </View>
  );
}

// ─── Registrations Tab ────────────────────────────────────────────────────────

function RegistrationsTab() {
  const { event, adminDeleteRegistration } = useAppContext();
  const [search, setSearch] = useState("");
  const [selectedReg, setSelectedReg] = useState<GuestRegistration | null>(null);

  if (!event) return null;

  const filtered = event.registrations.filter((r) => {
    const q = search.toLowerCase();
    return (
      r.firstName.toLowerCase().includes(q) ||
      r.lastName.toLowerCase().includes(q) ||
      r.email.toLowerCase().includes(q)
    );
  });

  const handleDelete = (reg: GuestRegistration) => {
    Alert.alert(
      "Supprimer l'inscription",
      `Supprimer l'inscription de ${reg.firstName} ${reg.lastName} ?`,
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Supprimer",
          style: "destructive",
          onPress: () => {
            adminDeleteRegistration(reg.id);
            if (selectedReg?.id === reg.id) setSelectedReg(null);
          },
        },
      ]
    );
  };

  if (selectedReg) {
    return (
      <RegistrationDetail
        reg={selectedReg}
        onClose={() => setSelectedReg(null)}
        onDelete={() => handleDelete(selectedReg)}
      />
    );
  }

  return (
    <View style={styles.tabContent}>
      {/* Search */}
      <View style={styles.searchContainer}>
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Rechercher un invité..."
          placeholderTextColor="rgba(155,155,138,0.4)"
          style={styles.searchInput}
          returnKeyType="search"
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch("")} style={styles.searchClear}>
            <Text style={styles.searchClearText}>✕</Text>
          </Pressable>
        )}
      </View>

      <Text style={styles.listCount}>
        {filtered.length} inscription{filtered.length !== 1 ? "s" : ""}
      </Text>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RegistrationRow
            reg={item}
            onPress={() => setSelectedReg(item)}
            onDelete={() => handleDelete(item)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 6 }} />}
        contentContainerStyle={{ paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Aucune inscription trouvée</Text>
          </View>
        }
      />
    </View>
  );
}

function RegistrationRow({
  reg,
  onPress,
  onDelete,
}: {
  reg: GuestRegistration;
  onPress: () => void;
  onDelete: () => void;
}) {
  const presences = [
    reg.attendsCeremony && "Cér.",
    reg.attendsCocktail && "Cock.",
    reg.attendsDinner && "Dîner",
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.regRow, pressed && { opacity: 0.8 }]}
    >
      <View style={styles.regAvatar}>
        <Text style={styles.regAvatarText}>
          {reg.firstName.charAt(0)}{reg.lastName.charAt(0)}
        </Text>
      </View>
      <View style={styles.regInfo}>
        <Text style={styles.regName}>
          {reg.firstName} {reg.lastName}
          {reg.plusOne && (
            <Text style={styles.regPlusOne}> +1</Text>
          )}
        </Text>
        <Text style={styles.regEmail} numberOfLines={1}>{reg.email}</Text>
        <Text style={styles.regPresence}>{presences}</Text>
        {reg.dietaryRestrictions && (
          <View style={styles.regDietBadge}>
            <Text style={styles.regDietText}>{reg.dietaryRestrictions}</Text>
          </View>
        )}
      </View>
      <Pressable
        onPress={onDelete}
        style={({ pressed }) => [styles.deleteBtn, pressed && { opacity: 0.5 }]}
        hitSlop={8}
      >
        <Text style={styles.deleteBtnText}>✕</Text>
      </Pressable>
    </Pressable>
  );
}

function RegistrationDetail({
  reg,
  onClose,
  onDelete,
}: {
  reg: GuestRegistration;
  onClose: () => void;
  onDelete: () => void;
}) {
  return (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      <Pressable
        onPress={onClose}
        style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
      >
        <Text style={styles.backBtnText}>← Retour à la liste</Text>
      </Pressable>

      <View style={styles.detailAvatarContainer}>
        <View style={styles.detailAvatar}>
          <Text style={styles.detailAvatarText}>
            {reg.firstName.charAt(0)}{reg.lastName.charAt(0)}
          </Text>
        </View>
        <Text style={styles.detailName}>
          {reg.firstName} {reg.lastName}
        </Text>
        <Text style={styles.detailDate}>
          Inscrit le{" "}
          {new Date(reg.submittedAt).toLocaleDateString("fr-FR", {
            day: "numeric",
            month: "long",
            year: "numeric",
          })}
        </Text>
      </View>

      <View style={styles.detailSection}>
        <Text style={styles.detailSectionTitle}>Contact</Text>
        <DetailRow label="Email" value={reg.email} />
        {reg.phone && <DetailRow label="Téléphone" value={reg.phone} />}
      </View>

      <View style={styles.detailSection}>
        <Text style={styles.detailSectionTitle}>Présence</Text>
        <DetailRow label="Cérémonie" value={reg.attendsCeremony ? "✓ Présent(e)" : "✗ Absent(e)"} highlight={reg.attendsCeremony} />
        <DetailRow label="Cocktail" value={reg.attendsCocktail ? "✓ Présent(e)" : "✗ Absent(e)"} highlight={reg.attendsCocktail} />
        <DetailRow label="Dîner" value={reg.attendsDinner ? "✓ Présent(e)" : "✗ Absent(e)"} highlight={reg.attendsDinner} />
        {reg.plusOne && (
          <DetailRow label="Accompagnant(e)" value={reg.plusOneName ?? "Oui"} highlight />
        )}
      </View>

      {reg.dietaryRestrictions && (
        <View style={styles.detailSection}>
          <Text style={styles.detailSectionTitle}>Régime alimentaire</Text>
          <View style={styles.dietaryHighlight}>
            <Text style={styles.dietaryHighlightText}>{reg.dietaryRestrictions}</Text>
          </View>
        </View>
      )}

      {reg.message && (
        <View style={styles.detailSection}>
          <Text style={styles.detailSectionTitle}>Message</Text>
          <View style={styles.messageCard}>
            <Text style={styles.messageText}>{reg.message}</Text>
          </View>
        </View>
      )}

      <Pressable
        onPress={onDelete}
        style={({ pressed }) => [styles.deleteFullBtn, pressed && { opacity: 0.7 }]}
      >
        <Text style={styles.deleteFullBtnText}>Supprimer cette inscription</Text>
      </Pressable>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

function DetailRow({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailRowLabel}>{label}</Text>
      <Text style={[styles.detailRowValue, highlight && styles.detailRowValueHighlight]}>
        {value}
      </Text>
    </View>
  );
}

// ─── Dietary Tab ──────────────────────────────────────────────────────────────

function DietaryTab() {
  const { event } = useAppContext();
  const [expandedGroup, setExpandedGroup] = useState<string | null>(null);

  if (!event) return null;

  const summary = analyzeDietaryRestrictions(event.registrations);
  const total = event.registrations.length;

  return (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      {/* Summary header */}
      <View style={styles.dietaryHeader}>
        <Text style={styles.dietaryHeaderTitle}>Analyse des régimes</Text>
        <Text style={styles.dietaryHeaderSub}>
          {total} inscription{total !== 1 ? "s" : ""} analysée{total !== 1 ? "s" : ""}
        </Text>
      </View>

      {/* Pie-like visual */}
      <View style={styles.dietaryBars}>
        {summary.map((group) => (
          <View key={group.label} style={styles.dietaryBarRow}>
            <View style={[styles.dietaryBarDot, { backgroundColor: group.color }]} />
            <View style={styles.dietaryBarTrack}>
              <View
                style={[
                  styles.dietaryBarFill,
                  {
                    width: `${(group.count / total) * 100}%`,
                    backgroundColor: group.color,
                  },
                ]}
              />
            </View>
            <Text style={[styles.dietaryBarCount, { color: group.color }]}>
              {group.count}
            </Text>
          </View>
        ))}
      </View>

      {/* Detailed groups */}
      {summary.map((group) => (
        <Pressable
          key={group.label}
          onPress={() =>
            setExpandedGroup(expandedGroup === group.label ? null : group.label)
          }
          style={({ pressed }) => [styles.dietaryGroup, pressed && { opacity: 0.8 }]}
        >
          <View style={styles.dietaryGroupHeader}>
            <View style={[styles.dietaryGroupDot, { backgroundColor: group.color }]} />
            <Text style={styles.dietaryGroupLabel}>{group.label}</Text>
            <View style={[styles.dietaryGroupBadge, { borderColor: group.color }]}>
              <Text style={[styles.dietaryGroupCount, { color: group.color }]}>
                {group.count}
              </Text>
            </View>
            <Text style={styles.dietaryGroupChevron}>
              {expandedGroup === group.label ? "▲" : "▼"}
            </Text>
          </View>

          {expandedGroup === group.label && (
            <View style={styles.dietaryGroupGuests}>
              {group.guests.map((name, i) => (
                <View key={i} style={styles.dietaryGuestRow}>
                  <View style={[styles.dietaryGuestDot, { backgroundColor: group.color }]} />
                  <Text style={styles.dietaryGuestName}>{name}</Text>
                </View>
              ))}
            </View>
          )}
        </Pressable>
      ))}

      {/* Raw list */}
      <Text style={[styles.sectionTitle, { marginTop: 20 }]}>
        Liste complète des restrictions
      </Text>
      {event.registrations
        .filter((r) => r.dietaryRestrictions?.trim())
        .map((r) => (
          <View key={r.id} style={styles.rawDietRow}>
            <Text style={styles.rawDietName}>
              {r.firstName} {r.lastName}
            </Text>
            <Text style={styles.rawDietValue}>{r.dietaryRestrictions}</Text>
          </View>
        ))}

      {event.registrations.filter((r) => r.dietaryRestrictions?.trim()).length === 0 && (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>Aucune restriction alimentaire déclarée</Text>
        </View>
      )}

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

// ─── Agenda Editor Tab ────────────────────────────────────────────────────────

const CATEGORIES: EventCategory[] = [
  "ceremony", "cocktail", "dinner", "music", "photo", "logistics", "other",
];

const CATEGORY_COLORS: Record<EventCategory, string> = {
  ceremony: NEU.red,
  cocktail: "#e8d5a3",
  dinner: "#a0c4a0",
  music: "#9b9bda",
  photo: "#da9b9b",
  logistics: "#9bbcda",
  other: "#9b9b8a",
};

interface AgendaFormState {
  time: string;
  endTime: string;
  title: string;
  description: string;
  speaker: string;
  location: string;
  category: EventCategory;
}

const EMPTY_FORM: AgendaFormState = {
  time: "",
  endTime: "",
  title: "",
  description: "",
  speaker: "",
  location: "",
  category: "ceremony",
};

function AgendaEditorTab() {
  const { event, adminAddAgendaItem, adminUpdateAgendaItem, adminDeleteAgendaItem } =
    useAppContext();
  const [editingItem, setEditingItem] = useState<AgendaItem | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<AgendaFormState>(EMPTY_FORM);
  const [isSaving, setIsSaving] = useState(false);

  if (!event) return null;

  const openAdd = () => {
    setEditingItem(null);
    setForm(EMPTY_FORM);
    setShowForm(true);
  };

  const openEdit = (item: AgendaItem) => {
    setEditingItem(item);
    setForm({
      time: item.time,
      endTime: item.endTime ?? "",
      title: item.title,
      description: item.description ?? "",
      speaker: item.speaker ?? "",
      location: item.location ?? "",
      category: item.category,
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.time.trim() || !form.title.trim()) {
      Alert.alert("Champs requis", "L'heure et le titre sont obligatoires.");
      return;
    }
    // Validate time format HH:MM
    if (!/^\d{2}:\d{2}$/.test(form.time)) {
      Alert.alert("Format invalide", "L'heure doit être au format HH:MM (ex: 14:30).");
      return;
    }

    setIsSaving(true);
    try {
      const payload = {
        time: form.time.trim(),
        endTime: form.endTime.trim() || undefined,
        title: form.title.trim(),
        description: form.description.trim() || undefined,
        speaker: form.speaker.trim() || undefined,
        location: form.location.trim() || undefined,
        category: form.category,
      };

      if (editingItem) {
        await adminUpdateAgendaItem(editingItem.id, payload);
      } else {
        await adminAddAgendaItem(payload);
      }
      setShowForm(false);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = (item: AgendaItem) => {
    Alert.alert(
      "Supprimer cet événement",
      `Supprimer "${item.title}" du programme ?`,
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Supprimer",
          style: "destructive",
          onPress: () => adminDeleteAgendaItem(item.id),
        },
      ]
    );
  };

  if (showForm) {
    return (
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          style={styles.tabContent}
          contentContainerStyle={{ paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Pressable
            onPress={() => setShowForm(false)}
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          >
            <Text style={styles.backBtnText}>← Retour au programme</Text>
          </Pressable>

          <Text style={styles.formTitle}>
            {editingItem ? "Modifier l'étape" : "Nouvelle étape"}
          </Text>

          {/* Time row */}
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <AgendaFormField
                label="Heure début *"
                value={form.time}
                onChangeText={(v) => setForm((p) => ({ ...p, time: v }))}
                placeholder="10:00"
                keyboardType="numbers-and-punctuation"
              />
            </View>
            <View style={{ flex: 1 }}>
              <AgendaFormField
                label="Heure fin"
                value={form.endTime}
                onChangeText={(v) => setForm((p) => ({ ...p, endTime: v }))}
                placeholder="11:30"
                keyboardType="numbers-and-punctuation"
              />
            </View>
          </View>

          <AgendaFormField
            label="Titre *"
            value={form.title}
            onChangeText={(v) => setForm((p) => ({ ...p, title: v }))}
            placeholder="Cérémonie laïque"
          />

          <AgendaFormField
            label="Description"
            value={form.description}
            onChangeText={(v) => setForm((p) => ({ ...p, description: v }))}
            placeholder="Détails de l'étape..."
            multiline
          />

          <AgendaFormField
            label="Intervenant / Prestataire"
            value={form.speaker}
            onChangeText={(v) => setForm((p) => ({ ...p, speaker: v }))}
            placeholder="Nom du prestataire"
          />

          <AgendaFormField
            label="Lieu"
            value={form.location}
            onChangeText={(v) => setForm((p) => ({ ...p, location: v }))}
            placeholder="Grande Salle"
          />

          {/* Category picker */}
          <Text style={styles.formFieldLabel}>Catégorie</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.categoryScroll}
            contentContainerStyle={styles.categoryScrollContent}
          >
            {CATEGORIES.map((cat) => (
              <Pressable
                key={cat}
                onPress={() => setForm((p) => ({ ...p, category: cat }))}
                style={({ pressed }) => [
                  styles.categoryChip,
                  form.category === cat && {
                    backgroundColor: `${CATEGORY_COLORS[cat]}22`,
                    borderColor: CATEGORY_COLORS[cat],
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Text
                  style={[
                    styles.categoryChipText,
                    form.category === cat && { color: CATEGORY_COLORS[cat] },
                  ]}
                >
                  {getCategoryLabel(cat)}
                </Text>
              </Pressable>
            ))}
          </ScrollView>

          <Pressable
            onPress={handleSave}
            disabled={isSaving}
            style={({ pressed }) => [
              styles.saveButton,
              isSaving && styles.saveButtonDisabled,
              pressed && !isSaving && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
          >
            <Text style={styles.saveButtonText}>
              {isSaving ? "Enregistrement..." : editingItem ? "Enregistrer les modifications" : "Ajouter au programme"}
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }

  return (
    <View style={styles.tabContent}>
      {/* Add button */}
      <Pressable
        onPress={openAdd}
        style={({ pressed }) => [styles.addButton, pressed && { opacity: 0.8 }]}
      >
        <Text style={styles.addButtonText}>+ Ajouter une étape</Text>
      </Pressable>

      {/* Bouton Export PDF */}
      <Pressable
        onPress={async () => {
          try {
            const { exportProgramPDF } = await import("@/lib/pdf-export");
            await exportProgramPDF(event, event.agenda);
          } catch (e) {
            Alert.alert("Export PDF", "Impossible de générer le PDF. Vérifiez que expo-print est installé.");
          }
        }}
        style={({ pressed }) => [{
          marginTop: 8, marginHorizontal: 16, borderRadius: 12, paddingVertical: 12,
          alignItems: "center" as const, borderWidth: 1.5, borderColor: NEU.info,
          backgroundColor: `${NEU.info}10`,
          shadowColor: NEU.shadowDark, shadowOffset: { width: pressed ? 1 : 3, height: pressed ? 1 : 3 },
          shadowOpacity: 1, shadowRadius: pressed ? 2 : 6, elevation: pressed ? 2 : 4,
        }]}
      >
        <Text style={{ fontSize: 14, fontWeight: "700" as const, color: NEU.info }}>📄 Exporter le programme en PDF</Text>
      </Pressable>

      <Text style={styles.listCount}>
        {event.agenda.length} étape{event.agenda.length !== 1 ? "s" : ""}
      </Text>

      <FlatList
        data={event.agenda}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <AgendaEditorRow
            item={item}
            onEdit={() => openEdit(item)}
            onDelete={() => handleDelete(item)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 6 }} />}
        contentContainerStyle={{ paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

function AgendaFormField({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType,
  multiline,
}: {
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  keyboardType?: "default" | "numbers-and-punctuation";
  multiline?: boolean;
}) {
  return (
    <View style={styles.formField}>
      <Text style={styles.formFieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="rgba(155,155,138,0.4)"
        keyboardType={keyboardType ?? "default"}
        multiline={multiline}
        numberOfLines={multiline ? 3 : 1}
        style={[styles.formInput, multiline && styles.formInputMultiline]}
        returnKeyType={multiline ? "default" : "done"}
      />
    </View>
  );
}

function AgendaEditorRow({
  item,
  onEdit,
  onDelete,
}: {
  item: AgendaItem;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const catColor = CATEGORY_COLORS[item.category] ?? "#9b9b8a";
  return (
    <View style={styles.agendaEditorRow}>
      <View style={[styles.agendaEditorCatBar, { backgroundColor: catColor }]} />
      <Pressable
        onPress={onEdit}
        style={({ pressed }) => [styles.agendaEditorContent, pressed && { opacity: 0.8 }]}
      >
        <View style={styles.agendaEditorTimeRow}>
          <Text style={styles.agendaEditorTime}>{item.time}</Text>
          {item.endTime && (
            <Text style={styles.agendaEditorEndTime}>→ {item.endTime}</Text>
          )}
          <View style={[styles.agendaEditorCatBadge, { borderColor: catColor }]}>
            <Text style={[styles.agendaEditorCatText, { color: catColor }]}>
              {getCategoryLabel(item.category)}
            </Text>
          </View>
        </View>
        <Text style={styles.agendaEditorTitle} numberOfLines={1}>
          {item.title}
        </Text>
        {item.speaker && (
          <Text style={styles.agendaEditorSpeaker} numberOfLines={1}>
            ✦ {item.speaker}
          </Text>
        )}
      </Pressable>
      <View style={styles.agendaEditorActions}>
        <Pressable
          onPress={onEdit}
          style={({ pressed }) => [styles.editBtn, pressed && { opacity: 0.5 }]}
          hitSlop={6}
        >
          <Text style={styles.editBtnText}>✎</Text>
        </Pressable>
        <Pressable
          onPress={onDelete}
          style={({ pressed }) => [styles.deleteBtn, pressed && { opacity: 0.5 }]}
          hitSlop={6}
        >
          <Text style={styles.deleteBtnText}>✕</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ─── Vendors Admin Tab ───────────────────────────────────────────────────────

interface VendorFormState {
  name: string;
  role: string;
  phone: string;
  email: string;
  description: string;
  arrivalTime: string;
  category: string;
}

const EMPTY_VENDOR_FORM: VendorFormState = {
  name: "",
  role: "",
  phone: "",
  email: "",
  description: "",
  arrivalTime: "",
  category: "other",
};

function VendorAdminRow({
  vendor,
  onPress,
  onStatusCycle,
}: {
  vendor: Vendor;
  onPress: () => void;
  onStatusCycle: () => void;
}) {
  const statusColor = getVendorStatusColor(vendor.status);
  const statusLabel = getVendorStatusLabel(vendor.status);
  const initials = vendor.name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  return (
    <View style={styles.vendorRow}>
      <Pressable
        onPress={onPress}
        style={({ pressed }) => [styles.vendorRowMain, pressed && { opacity: 0.8 }]}
      >
        <View style={styles.vendorAvatar}>
          <Text style={styles.vendorAvatarText}>{initials}</Text>
        </View>
        <View style={styles.vendorRowInfo}>
          <Text style={styles.vendorRowName} numberOfLines={1}>{vendor.name}</Text>
          <Text style={styles.vendorRowRole} numberOfLines={1}>{vendor.role}</Text>
          {vendor.arrivalTime && (
            <Text style={styles.vendorRowArrival}>Arrivée prévue : {vendor.arrivalTime}</Text>
          )}
        </View>
      </Pressable>
      <Pressable
        onPress={onStatusCycle}
        style={({ pressed }) => [
          styles.vendorStatusBadge,
          { borderColor: statusColor, backgroundColor: `${statusColor}18` },
          pressed && { opacity: 0.7 },
        ]}
      >
        <View style={[styles.vendorStatusDot, { backgroundColor: statusColor }]} />
        <Text style={[styles.vendorStatusText, { color: statusColor }]}>{statusLabel}</Text>
      </Pressable>
    </View>
  );
}

function VendorDetailView({
  vendor,
  onBack,
  onEdit,
  onDelete,
}: {
  vendor: Vendor;
  onBack: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const statusColor = getVendorStatusColor(vendor.status);
  const statusLabel = getVendorStatusLabel(vendor.status);
  const initials = vendor.name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  const handleCall = () => {
    if (vendor.phone) {
      Linking.openURL(`tel:${vendor.phone.replace(/\s/g, "")}`);
    }
  };

  const handleEmail = () => {
    if (vendor.email) {
      Linking.openURL(`mailto:${vendor.email}`);
    }
  };

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.vendorDetailScroll} showsVerticalScrollIndicator={false}>
      <Pressable
        onPress={onBack}
        style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
      >
        <Text style={styles.backBtnText}>← Retour</Text>
      </Pressable>

      {/* Avatar + name */}
      <View style={styles.detailAvatarContainer}>
        <View style={[styles.vendorDetailAvatar, { borderColor: statusColor }]}>
          <Text style={styles.vendorDetailAvatarText}>{initials}</Text>
        </View>
        <Text style={styles.detailName}>{vendor.name}</Text>
        <Text style={styles.vendorDetailRole}>{vendor.role}</Text>
        <View style={[styles.vendorStatusBadge, { borderColor: statusColor, backgroundColor: `${statusColor}18` }]}>
          <View style={[styles.vendorStatusDot, { backgroundColor: statusColor }]} />
          <Text style={[styles.vendorStatusText, { color: statusColor }]}>{statusLabel}</Text>
        </View>
      </View>

      {/* Info section */}
      <View style={styles.detailSection}>
        <Text style={styles.detailSectionTitle}>Informations</Text>
        {vendor.arrivalTime && (
          <View style={styles.detailRow}>
            <Text style={styles.detailRowLabel}>HEURE D'ARRIVÉE PRÉVUE</Text>
            <Text style={styles.detailRowValue}>{vendor.arrivalTime}</Text>
          </View>
        )}
        <View style={styles.detailRow}>
          <Text style={styles.detailRowLabel}>CATÉGORIE</Text>
          <Text style={styles.detailRowValue}>{getCategoryLabel(vendor.category as EventCategory)}</Text>
        </View>
        {vendor.description && (
          <View style={[styles.detailRow, { borderBottomWidth: 0 }]}>
            <Text style={styles.detailRowLabel}>DESCRIPTION</Text>
            <Text style={[styles.detailRowValue, { marginTop: 4, lineHeight: 20 }]}>{vendor.description}</Text>
          </View>
        )}
      </View>

      {/* Contact section */}
      {(vendor.phone || vendor.email) && (
        <View style={styles.detailSection}>
          <Text style={styles.detailSectionTitle}>Contact</Text>
          {vendor.phone && (
            <Pressable
              onPress={handleCall}
              style={({ pressed }) => [styles.detailRow, pressed && { opacity: 0.7 }]}
            >
              <Text style={styles.detailRowLabel}>TÉLÉPHONE</Text>
              <Text style={[styles.detailRowValue, styles.vendorContactLink]}>{vendor.phone}</Text>
            </Pressable>
          )}
          {vendor.email && (
            <Pressable
              onPress={handleEmail}
              style={({ pressed }) => [styles.detailRow, { borderBottomWidth: 0 }, pressed && { opacity: 0.7 }]}
            >
              <Text style={styles.detailRowLabel}>EMAIL</Text>
              <Text style={[styles.detailRowValue, styles.vendorContactLink]}>{vendor.email}</Text>
            </Pressable>
          )}
        </View>
      )}

      {/* Actions */}
      <View style={styles.vendorDetailActions}>
        <Pressable
          onPress={onEdit}
          style={({ pressed }) => [styles.vendorEditBtn, pressed && { opacity: 0.7 }]}
        >
          <Text style={styles.vendorEditBtnText}>Modifier</Text>
        </Pressable>
        <Pressable
          onPress={onDelete}
          style={({ pressed }) => [styles.deleteFullBtn, { flex: 1 }, pressed && { opacity: 0.7 }]}
        >
          <Text style={styles.deleteFullBtnText}>Supprimer</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function VendorsAdminTab() {
  const { event, adminAddVendor, adminUpdateVendor, adminUpdateVendorStatus, adminDeleteVendor } =
    useAppContext();
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [form, setForm] = useState<VendorFormState>(EMPTY_VENDOR_FORM);
  const [isSaving, setIsSaving] = useState(false);

  if (!event) return null;

  const vendors = event.vendors;
  const arrivedCount = vendors.filter((v) => v.status === "arrived").length;
  const confirmedCount = vendors.filter((v) => v.status === "confirmed").length;
  const pendingCount = vendors.filter((v) => v.status === "pending").length;

  const openAdd = () => {
    setEditingVendor(null);
    setForm(EMPTY_VENDOR_FORM);
    setShowForm(true);
  };

  const openEdit = (vendor: Vendor) => {
    setEditingVendor(vendor);
    setForm({
      name: vendor.name,
      role: vendor.role,
      phone: vendor.phone ?? "",
      email: vendor.email ?? "",
      description: vendor.description ?? "",
      arrivalTime: vendor.arrivalTime ?? "",
      category: vendor.category,
    });
    setSelectedVendor(null);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.role.trim()) {
      Alert.alert("Champs requis", "Le nom et le rôle sont obligatoires.");
      return;
    }
    setIsSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        role: form.role.trim(),
        phone: form.phone.trim() || undefined,
        email: form.email.trim() || undefined,
        description: form.description.trim() || undefined,
        arrivalTime: form.arrivalTime.trim() || undefined,
        category: form.category as EventCategory,
        status: (editingVendor?.status ?? "pending") as Vendor["status"],
      };
      if (editingVendor) {
        await adminUpdateVendor(editingVendor.id, payload);
      } else {
        await adminAddVendor(payload);
      }
      setShowForm(false);
      setEditingVendor(null);
      setForm(EMPTY_VENDOR_FORM);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = (vendor: Vendor) => {
    Alert.alert(
      "Supprimer le prestataire",
      `Supprimer "${vendor.name}" ?`,
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Supprimer",
          style: "destructive",
          onPress: async () => {
            await adminDeleteVendor(vendor.id);
            setSelectedVendor(null);
          },
        },
      ]
    );
  };

  const handleStatusCycle = async (vendor: Vendor) => {
    const nextStatus = cycleVendorStatus(vendor.status);
    await adminUpdateVendorStatus(vendor.id, nextStatus);
  };

  // ── Form view ──
  if (showForm) {
    return (
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.tabContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.formTitle}>
            {editingVendor ? "Modifier le prestataire" : "Nouveau prestataire"}
          </Text>

          <AgendaFormField
            label="Nom *"
            value={form.name}
            onChangeText={(v) => setForm((f) => ({ ...f, name: v }))}
            placeholder="Ex: Studio Lumière"
          />
          <AgendaFormField
            label="Rôle *"
            value={form.role}
            onChangeText={(v) => setForm((f) => ({ ...f, role: v }))}
            placeholder="Ex: Photographe"
          />
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <AgendaFormField
                label="Téléphone"
                value={form.phone}
                onChangeText={(v) => setForm((f) => ({ ...f, phone: v }))}
                placeholder="06 00 00 00 00"
              />
            </View>
            <View style={{ flex: 1 }}>
              <AgendaFormField
                label="Heure d'arrivée"
                value={form.arrivalTime}
                onChangeText={(v) => setForm((f) => ({ ...f, arrivalTime: v }))}
                placeholder="08:30"
              />
            </View>
          </View>
          <AgendaFormField
            label="Email"
            value={form.email}
            onChangeText={(v) => setForm((f) => ({ ...f, email: v }))}
            placeholder="contact@prestataire.fr"
          />
          <AgendaFormField
            label="Description"
            value={form.description}
            onChangeText={(v) => setForm((f) => ({ ...f, description: v }))}
            placeholder="Notes sur ce prestataire…"
            multiline
          />

          <View style={styles.vendorFormActions}>
            <Pressable
              onPress={() => { setShowForm(false); setEditingVendor(null); }}
              style={({ pressed }) => [styles.vendorCancelBtn, pressed && { opacity: 0.7 }]}
            >
              <Text style={styles.vendorCancelBtnText}>Annuler</Text>
            </Pressable>
            <Pressable
              onPress={handleSave}
              disabled={isSaving}
              style={({ pressed }) => [
                styles.saveButton,
                { flex: 1 },
                isSaving && styles.saveButtonDisabled,
                pressed && { opacity: 0.85 },
              ]}
            >
              <Text style={styles.saveButtonText}>
                {isSaving ? "Enregistrement…" : "Enregistrer"}
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }

  // ── Detail view ──
  if (selectedVendor) {
    return (
      <View style={styles.tabContent}>
        <VendorDetailView
          vendor={selectedVendor}
          onBack={() => setSelectedVendor(null)}
          onEdit={() => openEdit(selectedVendor)}
          onDelete={() => handleDelete(selectedVendor)}
        />
      </View>
    );
  }

  // ── List view ──
  return (
    <View style={styles.tabContent}>
      {/* Summary */}
      <View style={styles.vendorSummaryRow}>
        <View style={[styles.vendorSummaryCard, { borderColor: "rgba(74,222,128,0.3)" }]}>
          <Text style={[styles.vendorSummaryCount, { color: "#4ade80" }]}>{arrivedCount}</Text>
          <Text style={styles.vendorSummaryLabel}>Arrivés</Text>
        </View>
        <View style={[styles.vendorSummaryCard, { borderColor: "rgba(232,69,60,0.3)" }]}>
          <Text style={[styles.vendorSummaryCount, { color: NEU.red }]}>{confirmedCount}</Text>
          <Text style={styles.vendorSummaryLabel}>Confirmés</Text>
        </View>
        <View style={[styles.vendorSummaryCard, { borderColor: "rgba(251,191,36,0.3)" }]}>
          <Text style={[styles.vendorSummaryCount, { color: "#FBBF24" }]}>{pendingCount}</Text>
          <Text style={styles.vendorSummaryLabel}>En attente</Text>
        </View>
      </View>

      {/* Add button */}
      <Pressable
        onPress={openAdd}
        style={({ pressed }) => [styles.addButton, pressed && { opacity: 0.7 }]}
      >
        <Text style={styles.addButtonText}>+ Ajouter un prestataire</Text>
      </Pressable>

      <Text style={styles.listCount}>
        {vendors.length} prestataire{vendors.length !== 1 ? "s" : ""}
      </Text>

      <FlatList
        data={vendors}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <VendorAdminRow
            vendor={item}
            onPress={() => setSelectedVendor(item)}
            onStatusCycle={() => handleStatusCycle(item)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 6 }} />}
        contentContainerStyle={{ paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Aucun prestataire enregistré.</Text>
          </View>
        }
      />
    </View>
  );
}

// ─── QR Codes Admin Tab ─────────────────────────────────────────────────────────

function QRCodesAdminTab() {
  const ROLES_DATA = [
    { key: "couple" as const, label: "Futurs Mariés", icon: "💍", color: NEU.red },
    { key: "vendor" as const, label: "Prestataire", icon: "🎵", color: NEU.info },
    { key: "guest" as const, label: "Invité(e)", icon: "🌸", color: NEU.success },
  ];
  const [activeRole, setActiveRole] = useState<"couple" | "vendor" | "guest">("guest");
  const active = ROLES_DATA.find(r => r.key === activeRole)!;
  const qrValue = `ddwedding://role/${activeRole}`;

  const handleShare = async () => {
    try {
      const { Share } = await import("react-native");
      await Share.share({
        message: `Rejoignez notre mariage !\n\nScannez ce QR code pour accéder à votre espace ${active.label.toLowerCase()}.\n\nLien : ${qrValue}`,
      });
    } catch (e) {
      Alert.alert("Partage", "Impossible de partager le QR code.");
    }
  };

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionTitle}>SÉLECTIONNER UN RÔLE</Text>
      <View style={{ flexDirection: "row", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {ROLES_DATA.map(role => (
          <Pressable
            key={role.key}
            onPress={() => setActiveRole(role.key)}
            style={({ pressed }) => [{
              flexDirection: "row" as const, alignItems: "center" as const, gap: 6,
              paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12,
              backgroundColor: activeRole === role.key ? `${role.color}15` : NEU.bgRaised,
              borderWidth: 1.5, borderColor: activeRole === role.key ? role.color : NEU.borderSubtle,
              shadowColor: NEU.shadowDark, shadowOffset: { width: pressed ? 1 : 4, height: pressed ? 1 : 4 },
              shadowOpacity: 1, shadowRadius: pressed ? 3 : 8, elevation: pressed ? 2 : 5,
            }]}
          >
            <Text style={{ fontSize: 16 }}>{role.icon}</Text>
            <Text style={{ fontSize: 13, fontWeight: "600" as const, color: activeRole === role.key ? role.color : NEU.textSecondary }}>{role.label}</Text>
          </Pressable>
        ))}
      </View>

      {/* QR Card */}
      <View style={[styles.card, { alignItems: "center" as const }]}>
        <View style={{ flexDirection: "row" as const, alignItems: "center" as const, gap: 10, marginBottom: 16, alignSelf: "flex-start" as const }}>
          <Text style={{ fontSize: 28 }}>{active.icon}</Text>
          <View>
            <Text style={{ fontSize: 17, fontWeight: "800" as const, color: active.color }}>{active.label}</Text>
            <Text style={{ fontSize: 12, color: NEU.textMuted }}>Accès dédié à ce rôle</Text>
          </View>
        </View>

        {/* QR en creux */}
        <View style={{
          padding: 16, borderRadius: 16,
          backgroundColor: NEU.bgSunken,
          borderWidth: 1, borderColor: NEU.shadowLight,
          shadowColor: NEU.shadowDark, shadowOffset: { width: 3, height: 3 },
          shadowOpacity: 1, shadowRadius: 6, elevation: 3, marginBottom: 14,
        }}>
          {/* Placeholder QR visuel */}
          <View style={{ width: 180, height: 180, backgroundColor: NEU.bgSunken, alignItems: "center" as const, justifyContent: "center" as const }}>
            <Text style={{ fontSize: 11, color: NEU.textMuted, textAlign: "center" as const, lineHeight: 18 }}>
              QR Code{"\n"}{active.label}{"\n"}{qrValue}
            </Text>
            <View style={{ marginTop: 8, padding: 8, borderWidth: 2, borderColor: active.color, borderRadius: 8 }}>
              <Text style={{ fontSize: 10, color: active.color, fontWeight: "700" as const }}>{active.icon} {active.label.toUpperCase()}</Text>
            </View>
          </View>
        </View>

        <View style={{ backgroundColor: NEU.bgSunken, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, marginBottom: 14, borderWidth: 1, borderColor: NEU.borderSubtle, alignSelf: "stretch" as const }}>
          <Text style={{ fontSize: 11, color: NEU.textMuted, textAlign: "center" as const, fontFamily: Platform.OS === "ios" ? "Courier" : "monospace" }}>{qrValue}</Text>
        </View>

        <Pressable
          onPress={handleShare}
          style={({ pressed }) => [{
            borderRadius: 14, paddingVertical: 14, alignItems: "center" as const,
            borderWidth: 1.5, borderColor: active.color,
            backgroundColor: `${active.color}10`,
            shadowColor: NEU.shadowDark, shadowOffset: { width: pressed ? 1 : 4, height: pressed ? 1 : 4 },
            shadowOpacity: 1, shadowRadius: pressed ? 3 : 8, elevation: pressed ? 2 : 5,
            alignSelf: "stretch" as const,
          }]}
        >
          <Text style={{ fontSize: 15, fontWeight: "700" as const, color: active.color }}>↑ Partager ce QR code</Text>
        </Pressable>
      </View>

      {/* Note */}
      <View style={[styles.card, { backgroundColor: NEU.bgSunken }]}>
        <Text style={{ fontSize: 13, fontWeight: "700" as const, color: NEU.textPrimary, marginBottom: 8 }}>💡 Comment ça marche ?</Text>
        <Text style={{ fontSize: 12, color: NEU.textSecondary, lineHeight: 20 }}>
          1. Générez le QR code du rôle souhaité.{"\n"}
          2. Partagez-le par message, email ou imprimez-le.{"\n"}
          3. En scannant le code, l'app s'ouvre directement sur l'espace dédié.{"\n"}
          4. Aucune saisie manuelle nécessaire.
        </Text>
      </View>
    </ScrollView>
  );
}

// ─── Notifications Admin Tab ──────────────────────────────────────────────────

function NotificationsAdminTab() {
  const { agenda, event } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [scheduled, setScheduled] = useState(0);
  const [minutesBefore, setMinutesBefore] = useState("30");
  const [permGranted, setPermGranted] = useState<boolean | null>(null);

  useEffect(() => {
    if (Platform.OS !== "web") {
      import("@/lib/notifications").then(({ requestNotificationPermissions, getScheduledReminders }) => {
        requestNotificationPermissions().then(setPermGranted);
        getScheduledReminders().then(r => setScheduled(r.length));
      });
    }
  }, []);

  const handleSchedule = async () => {
    if (!event) { Alert.alert("Erreur", "Aucun événement configuré."); return; }
    setLoading(true);
    try {
      const { scheduleAgendaReminders } = await import("@/lib/notifications");
      const mins = parseInt(minutesBefore) || 30;
      const count = await scheduleAgendaReminders(event, agenda, mins);
      setScheduled(count);
      Alert.alert("✅ Rappels programmés", `${count} rappel${count !== 1 ? "s" : ""} programmé${count !== 1 ? "s" : ""} (${mins} min avant chaque étape).`);
    } catch (e) {
      Alert.alert("Erreur", "Impossible de programmer les rappels.");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    setLoading(true);
    try {
      const { cancelAllAgendaReminders } = await import("@/lib/notifications");
      await cancelAllAgendaReminders();
      setScheduled(0);
      Alert.alert("✅ Annulé", "Tous les rappels ont été annulés.");
    } catch (e) {
      Alert.alert("Erreur", "Impossible d'annuler les rappels.");
    } finally {
      setLoading(false);
    }
  };

  const handleTest = async () => {
    try {
      const { sendImmediateNotification } = await import("@/lib/notifications");
      await sendImmediateNotification("💍 Test D Day Wedding", "Les notifications fonctionnent correctement !");
      Alert.alert("✅ Test envoyé", "Vérifiez vos notifications.");
    } catch (e) {
      Alert.alert("Erreur", "Impossible d'envoyer la notification de test.");
    }
  };

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
      {/* Statut permissions */}
      <View style={[styles.card, { flexDirection: "row" as const, alignItems: "center" as const, gap: 12 }]}>
        <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: permGranted ? `${NEU.success}20` : `${NEU.warning}20`, alignItems: "center" as const, justifyContent: "center" as const, borderWidth: 1, borderColor: permGranted ? NEU.success : NEU.warning }}>
          <Text style={{ fontSize: 18 }}>{permGranted ? "✅" : "⚠️"}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 14, fontWeight: "700" as const, color: NEU.textPrimary }}>Permissions notifications</Text>
          <Text style={{ fontSize: 12, color: permGranted ? NEU.success : NEU.warning, marginTop: 2 }}>
            {permGranted === null ? "Vérification..." : permGranted ? "Autorisées" : "Non autorisées — activez dans les réglages"}
          </Text>
        </View>
      </View>

      {/* Rappels actifs */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>RAPPELS PROGRAMMÉS</Text>
        <View style={{ flexDirection: "row" as const, alignItems: "center" as const, gap: 12 }}>
          <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: `${NEU.red}15`, alignItems: "center" as const, justifyContent: "center" as const, borderWidth: 1.5, borderColor: NEU.redBorder, shadowColor: NEU.shadowDark, shadowOffset: { width: 3, height: 3 }, shadowOpacity: 1, shadowRadius: 6, elevation: 4 }}>
            <Text style={{ fontSize: 22, fontWeight: "900" as const, color: NEU.red }}>{scheduled}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: "700" as const, color: NEU.textPrimary }}>rappel{scheduled !== 1 ? "s" : ""} actif{scheduled !== 1 ? "s" : ""}</Text>
            <Text style={{ fontSize: 12, color: NEU.textMuted, marginTop: 2 }}>{agenda.length} étapes dans le programme</Text>
          </View>
        </View>
      </View>

      {/* Configuration */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>CONFIGURATION</Text>
        <Text style={{ fontSize: 13, color: NEU.textSecondary, marginBottom: 8 }}>Minutes avant chaque étape</Text>
        <View style={{ flexDirection: "row" as const, gap: 8, marginBottom: 16, flexWrap: "wrap" as const }}>
          {["10", "15", "30", "60"].map(m => (
            <Pressable
              key={m}
              onPress={() => setMinutesBefore(m)}
              style={({ pressed }) => [{
                paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10,
                backgroundColor: minutesBefore === m ? `${NEU.red}15` : NEU.bgRaised,
                borderWidth: 1.5, borderColor: minutesBefore === m ? NEU.red : NEU.borderSubtle,
                shadowColor: NEU.shadowDark, shadowOffset: { width: pressed ? 1 : 3, height: pressed ? 1 : 3 },
                shadowOpacity: 1, shadowRadius: pressed ? 2 : 6, elevation: pressed ? 2 : 4,
              }]}
            >
              <Text style={{ fontSize: 14, fontWeight: "700" as const, color: minutesBefore === m ? NEU.red : NEU.textSecondary }}>{m} min</Text>
            </Pressable>
          ))}
        </View>

        <Pressable
          onPress={handleSchedule}
          disabled={loading}
          style={({ pressed }) => [styles.addButton, { opacity: loading ? 0.6 : 1, shadowOffset: { width: pressed ? 1 : 4, height: pressed ? 1 : 4 }, shadowRadius: pressed ? 3 : 8 }]}
        >
          {loading ? <ActivityIndicator color={NEU.red} size="small" /> : <Text style={styles.addButtonText}>⏰ Programmer les rappels</Text>}
        </Pressable>

        {scheduled > 0 && (
          <Pressable
            onPress={handleCancel}
            disabled={loading}
            style={({ pressed }) => [{
              marginTop: 10, borderRadius: 12, paddingVertical: 12, alignItems: "center" as const,
              borderWidth: 1.5, borderColor: NEU.borderSubtle, backgroundColor: NEU.bgSunken,
              shadowColor: NEU.shadowDark, shadowOffset: { width: pressed ? 1 : 3, height: pressed ? 1 : 3 },
              shadowOpacity: 1, shadowRadius: pressed ? 2 : 6, elevation: pressed ? 2 : 4,
            }]}
          >
            <Text style={{ fontSize: 14, fontWeight: "600" as const, color: NEU.textMuted }}>Annuler tous les rappels</Text>
          </Pressable>
        )}
      </View>

      {/* Test */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>TEST</Text>
        <Text style={{ fontSize: 12, color: NEU.textMuted, marginBottom: 12 }}>Envoyez une notification immédiate pour vérifier que tout fonctionne.</Text>
        <Pressable
          onPress={handleTest}
          style={({ pressed }) => [{
            borderRadius: 12, paddingVertical: 12, alignItems: "center" as const,
            borderWidth: 1.5, borderColor: NEU.info, backgroundColor: `${NEU.info}10`,
            shadowColor: NEU.shadowDark, shadowOffset: { width: pressed ? 1 : 3, height: pressed ? 1 : 3 },
            shadowOpacity: 1, shadowRadius: pressed ? 2 : 6, elevation: pressed ? 2 : 4,
          }]}
        >
          <Text style={{ fontSize: 14, fontWeight: "700" as const, color: NEU.info }}>🔔 Envoyer une notification test</Text>
        </Pressable>
      </View>

      {/* Note */}
      <View style={[styles.card, { backgroundColor: NEU.bgSunken }]}>
        <Text style={{ fontSize: 13, fontWeight: "700" as const, color: NEU.textPrimary, marginBottom: 8 }}>💡 Comment ça marche ?</Text>
        <Text style={{ fontSize: 12, color: NEU.textSecondary, lineHeight: 20 }}>
          Les rappels sont des notifications locales programmées sur l'appareil.{"\n"}
          Chaque participant doit avoir l'app installée et les notifications activées.{"\n"}
          Les rappels sont envoyés automatiquement, même si l'app est fermée.{"\n"}
          Reprogrammez après chaque modification du programme.
        </Text>
      </View>
    </ScrollView>
  );
}

// ─── Main Admin Screen ─────────────────────────────────────────────────────────

const TABS: { key: AdminTab; label: string; icon: string }[] = [
  { key: "dashboard", label: "Tableau de bord", icon: "◉" },
  { key: "registrations", label: "Inscrits", icon: "◈" },
  { key: "dietary", label: "Régimes", icon: "✦" },
  { key: "agenda", label: "Programme", icon: "◎" },
  { key: "vendors", label: "Prestataires", icon: "▦" },
  { key: "settings", label: "Événement", icon: "◆" },
  { key: "alerts", label: "Alertes", icon: "◉" },
  { key: "qrcodes", label: "QR Codes", icon: "▣" },
  { key: "notifications", label: "Rappels", icon: "◎" },
];

// ─── PIN Guard ────────────────────────────────────────────────────────────────

function PinGuard({ onUnlock }: { onUnlock: () => void }) {
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [isSettingPin, setIsSettingPin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [storedPin, setStoredPin] = useState<string | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(PIN_KEY).then((p) => {
      setStoredPin(p);
      setIsSettingPin(!p);
      setLoading(false);
    });
  }, []);

  const handleDigit = (d: string) => {
    if (isSettingPin) {
      if (pin.length < 4) {
        const np = pin + d;
        setPin(np);
      } else if (confirmPin.length < 4) {
        const nc = confirmPin + d;
        setConfirmPin(nc);
        if (nc.length === 4) {
          if (pin === nc) {
            AsyncStorage.setItem(PIN_KEY, pin);
            onUnlock();
          } else {
            setError("Les codes ne correspondent pas");
            setPin(""); setConfirmPin("");
          }
        }
      }
    } else {
      if (pin.length < 4) {
        const np = pin + d;
        setPin(np);
        if (np.length === 4) {
          if (np === storedPin) {
            onUnlock();
          } else {
            setError("Code incorrect");
            setTimeout(() => { setPin(""); setError(""); }, 800);
          }
        }
      }
    }
  };

  const handleDelete = () => {
    setError("");
    if (isSettingPin && pin.length === 4) setConfirmPin(c => c.slice(0, -1));
    else setPin(p => p.slice(0, -1));
  };

  if (loading) return (
    <View style={pinStyles.container}><ActivityIndicator color={NEU.red} /></View>
  );

  const currentInput = isSettingPin && pin.length === 4 ? confirmPin : pin;
  const prompt = isSettingPin
    ? (pin.length < 4 ? "Créez votre code PIN admin" : "Confirmez votre code PIN")
    : "Code PIN administrateur";

  return (
    <View style={pinStyles.container}>
      <Text style={pinStyles.title}>D·D</Text>
      <Text style={pinStyles.subtitle}>Espace Administration</Text>
      <Text style={pinStyles.prompt}>{prompt}</Text>
      <View style={pinStyles.dots}>
        {[0,1,2,3].map(i => (
          <View key={i} style={[pinStyles.dot, currentInput.length > i && pinStyles.dotFilled, !!error && pinStyles.dotError]} />
        ))}
      </View>
      {!!error && <Text style={pinStyles.error}>{error}</Text>}
      <View style={pinStyles.grid}>
        {["1","2","3","4","5","6","7","8","9","","0","⌫"].map((d, i) => (
          <Pressable
            key={i}
            style={({ pressed }) => [pinStyles.key, !d && pinStyles.keyEmpty, pressed && d && { opacity: 0.6 }]}
            onPress={() => d === "⌫" ? handleDelete() : d && handleDigit(d)}
            disabled={!d}
          >
            <Text style={pinStyles.keyText}>{d}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const pinStyles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, backgroundColor: NEU.bg },
  title: { fontSize: 48, fontWeight: "800", color: NEU.red, letterSpacing: 8, marginBottom: 4 },
  subtitle: { fontSize: 12, color: NEU.textSecondary, letterSpacing: 3, textTransform: "uppercase", marginBottom: 32 },
  prompt: { fontSize: 15, color: NEU.textPrimary, marginBottom: 24, textAlign: "center" },
  dots: { flexDirection: "row", gap: 16, marginBottom: 12 },
  dot: { width: 16, height: 16, borderRadius: 8, borderWidth: 1.5, borderColor: NEU.red, backgroundColor: NEU.bgRaised, shadowColor: NEU.shadowDark, shadowOffset: { width: 2, height: 2 }, shadowOpacity: 0.35, shadowRadius: 4, elevation: 3 },
  dotFilled: { backgroundColor: NEU.red, shadowColor: NEU.red, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.4, shadowRadius: 6, elevation: 5 },
  dotError: { borderColor: "#f87171" },
  error: { color: "#f87171", fontSize: 13, marginBottom: 16 },
  grid: { flexDirection: "row", flexWrap: "wrap", width: 240, gap: 12, marginTop: 16 },
  key: { width: 64, height: 64, borderRadius: 32, borderWidth: 1, borderColor: "rgba(0,0,0,0.06)", alignItems: "center", justifyContent: "center", backgroundColor: NEU.bgRaised, shadowColor: NEU.shadowDark, shadowOffset: { width: 4, height: 4 }, shadowOpacity: 0.45, shadowRadius: 10, elevation: 7 },
  keyEmpty: { backgroundColor: "transparent", borderColor: "transparent" },
  keyText: { color: NEU.textPrimary, fontSize: 22, fontWeight: "600" },
});

// ─── Settings Tab ─────────────────────────────────────────────────────────────

function SettingsTab() {
  const { event, refreshEvent } = useAppContext();
  const [form, setForm] = useState({
    name: event?.name ?? "",
    date: event?.date ?? "",
    venue: event?.venue ?? "",
    address: event?.address ?? "",
    dressCode: event?.dressCode ?? "",
    parkingInfo: event?.parkingInfo ?? "",
    accommodationInfo: event?.accommodationInfo ?? "",
    organizerPhone: event?.organizerPhone ?? "",
    organizerEmail: event?.organizerEmail ?? "",
  });
  const [saving, setSaving] = useState(false);
  const [pinReset, setPinReset] = useState(false);
  const [newPin, setNewPin] = useState("");

  const handleSave = async () => {
    setSaving(true);
    try {
      const ev = await loadEvent();
      await saveEvent({ ...ev, ...form });
      await refreshEvent();
      Alert.alert("Enregistré", "Les informations de l'événement ont été mises à jour.");
    } catch {
      Alert.alert("Erreur", "Impossible d'enregistrer les modifications");
    } finally {
      setSaving(false);
    }
  };

  const handleResetPin = async () => {
    if (newPin.length !== 4) { Alert.alert("Erreur", "Le PIN doit contenir 4 chiffres"); return; }
    await AsyncStorage.setItem(PIN_KEY, newPin);
    Alert.alert("PIN mis à jour", "Votre nouveau code PIN a été enregistré.");
    setPinReset(false); setNewPin("");
  };

  const FIELDS: { key: keyof typeof form; label: string; multiline?: boolean }[] = [
    { key: "name", label: "Nom de l'événement" },
    { key: "date", label: "Date (ISO : 2026-06-14T10:00:00.000Z)" },
    { key: "venue", label: "Lieu" },
    { key: "address", label: "Adresse" },
    { key: "dressCode", label: "Dress code" },
    { key: "parkingInfo", label: "Parking", multiline: true },
    { key: "accommodationInfo", label: "Hébergement", multiline: true },
    { key: "organizerPhone", label: "Téléphone organisateur" },
    { key: "organizerEmail", label: "Email organisateur" },
  ];

  return (
    <ScrollView style={styles.tabContent} contentContainerStyle={{ paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionTitle}>Configurer l'événement</Text>
      {FIELDS.map(({ key, label, multiline }) => (
        <View key={key} style={settingsStyles.formGroup}>
          <Text style={settingsStyles.label}>{label}</Text>
          <TextInput
            style={[settingsStyles.input, multiline && { height: 70, textAlignVertical: "top" }]}
            value={form[key]}
            onChangeText={(v) => setForm(f => ({ ...f, [key]: v }))}
            placeholderTextColor="rgba(155,155,138,0.4)"
            multiline={multiline}
          />
        </View>
      ))}
      <Pressable
        onPress={handleSave}
        disabled={saving}
        style={({ pressed }) => [styles.saveButton, pressed && { opacity: 0.8 }]}
      >
        {saving ? <ActivityIndicator color="#03030e" /> : <Text style={styles.saveButtonText}>Enregistrer les modifications</Text>}
      </Pressable>

      <View style={settingsStyles.divider} />
      <Text style={styles.sectionTitle}>Sécurité — Code PIN</Text>
      {!pinReset ? (
        <Pressable
          onPress={() => setPinReset(true)}
          style={({ pressed }) => [settingsStyles.pinBtn, pressed && { opacity: 0.7 }]}
        >
          <Text style={settingsStyles.pinBtnText}>Modifier le code PIN admin</Text>
        </Pressable>
      ) : (
        <View>
          <View style={settingsStyles.formGroup}>
            <Text style={settingsStyles.label}>Nouveau PIN (4 chiffres)</Text>
            <TextInput
              style={settingsStyles.input}
              value={newPin}
              onChangeText={(v) => setNewPin(v.replace(/\D/g, "").slice(0, 4))}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={4}
              placeholderTextColor="rgba(155,155,138,0.4)"
            />
          </View>
          <Pressable onPress={handleResetPin} style={({ pressed }) => [styles.saveButton, pressed && { opacity: 0.8 }]}>
            <Text style={styles.saveButtonText}>Enregistrer le nouveau PIN</Text>
          </Pressable>
          <Pressable onPress={() => setPinReset(false)} style={{ marginTop: 8, alignItems: "center" }}>
            <Text style={{ color: "#9b9b8a", fontSize: 14 }}>Annuler</Text>
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}

const settingsStyles = StyleSheet.create({
  formGroup: { marginBottom: 14 },
  label: { color: NEU.textSecondary, fontSize: 11, fontWeight: "600", letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 },
  input: { backgroundColor: NEU.bgSunken, borderRadius: 10, padding: 12, color: NEU.textPrimary, fontSize: 14, borderWidth: 1, borderColor: "rgba(0,0,0,0.3)", shadowColor: NEU.shadowDark, shadowOffset: { width: 2, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4, elevation: 0 },
  divider: { height: 1, backgroundColor: "rgba(232,69,60,0.1)", marginVertical: 24 },
  pinBtn: { borderWidth: 1, borderColor: "rgba(251,191,36,0.4)", borderRadius: 12, padding: 14, alignItems: "center" },
  pinBtnText: { color: "#FBBF24", fontSize: 14, fontWeight: "600" },
  // Neumorphism helpers
  neuCard: { backgroundColor: NEU.bgRaised, borderRadius: 16, borderWidth: 1, borderColor: "rgba(0,0,0,0.06)", shadowColor: NEU.shadowDark, shadowOffset: { width: 5, height: 5 }, shadowOpacity: 0.45, shadowRadius: 12, elevation: 8 },
});

// ─── Alerts Tab ───────────────────────────────────────────────────────────────

function AlertsTab() {
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const broadcastMutation = trpc.alerts.broadcast.useMutation();
  const alertsQuery = trpc.alerts.list.useQuery();
  const dismissMutation = trpc.alerts.dismiss.useMutation();

  const alerts = (alertsQuery.data ?? []).map(a => ({
    id: a.id,
    type: a.type,
    message: a.message,
    createdAt: a.createdAt instanceof Date ? a.createdAt.toISOString() : String(a.createdAt),
  }));

  const handleBroadcast = async () => {
    if (!message.trim()) return;
    setSending(true);
    try {
      await broadcastMutation.mutateAsync({ message });
      setMessage("");
      alertsQuery.refetch();
      Alert.alert("Alerte envoyée", "Le message a été diffusé à tous les participants.");
    } catch {
      Alert.alert("Erreur", "Impossible d'envoyer l'alerte");
    } finally {
      setSending(false);
    }
  };

  return (
    <ScrollView style={styles.tabContent} contentContainerStyle={{ paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionTitle}>Diffuser une alerte</Text>
      <TextInput
        style={[settingsStyles.input, { height: 80, textAlignVertical: "top", marginBottom: 12 }]}
        value={message}
        onChangeText={setMessage}
        multiline
        placeholder="Message à diffuser à tous les participants..."
        placeholderTextColor="rgba(155,155,138,0.4)"
      />
      <Pressable
        onPress={handleBroadcast}
        disabled={sending || !message.trim()}
        style={({ pressed }) => [styles.saveButton, { backgroundColor: "#FBBF24" }, pressed && { opacity: 0.8 }]}
      >
        {sending ? <ActivityIndicator color="#03030e" /> : <Text style={[styles.saveButtonText, { color: "#03030e" }]}>Diffuser à tous</Text>}
      </Pressable>

      <Text style={[styles.sectionTitle, { marginTop: 24 }]}>Alertes actives</Text>
      {alerts.length === 0 ? (
        <View style={styles.emptyContainer}><Text style={styles.emptyText}>Aucune alerte active</Text></View>
      ) : (
        alerts.map(alert => (
          <View key={alert.id} style={alertStyles.card}>
            <View style={{ flex: 1 }}>
              <Text style={alertStyles.type}>{alert.type === "delay" ? "⚡ Retard" : "📢 Annonce"}</Text>
              <Text style={alertStyles.msg}>{alert.message}</Text>
              <Text style={alertStyles.time}>{new Date(alert.createdAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</Text>
            </View>
            <Pressable
              onPress={async () => { await dismissMutation.mutateAsync({ id: alert.id }); alertsQuery.refetch(); }}
              style={{ padding: 8 }}
            >
              <Text style={{ color: "#9b9b8a", fontSize: 18 }}>×</Text>
            </Pressable>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const alertStyles = StyleSheet.create({
  card: { backgroundColor: NEU.bgRaised, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderLeftWidth: 3, borderColor: "rgba(232,69,60,0.3)", flexDirection: "row", alignItems: "flex-start", gap: 8, shadowColor: NEU.shadowDark, shadowOffset: { width: 4, height: 4 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 6 },
  type: { color: "#FBBF24", fontSize: 12, fontWeight: "700", marginBottom: 4 },
  msg: { color: NEU.textPrimary, fontSize: 13, lineHeight: 19 },
  time: { color: NEU.textSecondary, fontSize: 11, marginTop: 4 },
});

// ─── SmartRipple Modal ────────────────────────────────────────────────────────

function SmartRippleModal({ item, onClose, onApply }: { item: AgendaItem; onClose: () => void; onApply: (delay: number, msg: string) => Promise<void> }) {
  const [delay, setDelay] = useState("15");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const handle = async () => {
    const d = parseInt(delay, 10);
    if (isNaN(d) || d < 1) { Alert.alert("Erreur", "Retard invalide"); return; }
    setLoading(true);
    try { await onApply(d, msg); onClose(); }
    catch { Alert.alert("Erreur", "Impossible d'appliquer le retard"); }
    finally { setLoading(false); }
  };

  return (
    <Modal visible animationType="slide" transparent>
      <View style={rippleStyles.overlay}>
        <View style={rippleStyles.card}>
          <Text style={rippleStyles.title}>⚡ SmartRipple</Text>
          <Text style={rippleStyles.subtitle}>Retard sur "{item.title}" — tous les horaires suivants seront recalculés automatiquement.</Text>
          <Text style={settingsStyles.label}>Retard (minutes)</Text>
          <TextInput style={[settingsStyles.input, { marginBottom: 14 }]} value={delay} onChangeText={setDelay} keyboardType="number-pad" placeholderTextColor="rgba(155,155,138,0.4)" />
          <Text style={settingsStyles.label}>Message aux invités (optionnel)</Text>
          <TextInput style={[settingsStyles.input, { height: 70, textAlignVertical: "top", marginBottom: 20 }]} value={msg} onChangeText={setMsg} multiline placeholder="Ex: La cérémonie a pris du retard..." placeholderTextColor="rgba(155,155,138,0.4)" />
          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable onPress={onClose} style={({ pressed }) => [settingsStyles.pinBtn, { flex: 1 }, pressed && { opacity: 0.7 }]}>
              <Text style={settingsStyles.pinBtnText}>Annuler</Text>
            </Pressable>
            <Pressable onPress={handle} disabled={loading} style={({ pressed }) => [styles.saveButton, { flex: 1, backgroundColor: "#FBBF24" }, pressed && { opacity: 0.8 }]}>
              {loading ? <ActivityIndicator color="#03030e" /> : <Text style={[styles.saveButtonText, { color: "#03030e" }]}>Propager</Text>}
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const rippleStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" },
  card: { backgroundColor: NEU.bgRaised, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, borderTopWidth: 1, borderColor: "rgba(251,191,36,0.3)", shadowColor: NEU.shadowDark, shadowOffset: { width: 0, height: -4 }, shadowOpacity: 0.4, shadowRadius: 10, elevation: 10 },
  title: { color: "#FBBF24", fontSize: 20, fontWeight: "800", marginBottom: 8 },
  subtitle: { color: NEU.textSecondary, fontSize: 13, lineHeight: 19, marginBottom: 20 },
});

export default function AdminScreen() {
  const { userRole } = useAppContext();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<AdminTab>("dashboard");

  const [unlocked, setUnlocked] = useState(false);
  const [smartRippleItem, setSmartRippleItem] = useState<AgendaItem | null>(null);
  const { event, adminUpdateAgendaItem } = useAppContext();

  const applySmartRipple = async (agendaItemId: string, delayMinutes: number, message: string) => {
    const items = event?.agenda ?? [];
    const trigger = items.find(i => i.id === agendaItemId);
    if (!trigger) return;
    for (const item of items) {
      if (item.time >= trigger.time) {
        const [h, m] = item.time.split(":").map(Number);
        const total = h * 60 + m + delayMinutes;
        const newH = Math.floor(total / 60) % 24;
        const newM = total % 60;
        await adminUpdateAgendaItem(item.id, { time: `${String(newH).padStart(2, "0")}:${String(newM).padStart(2, "0")}` });
      }
    }
    Alert.alert("SmartRipple activé", `${delayMinutes} min de retard propagés sur tous les horaires suivants.`);
  };

  // Guard: only couple can access
  if (userRole !== "couple") {
    return (
      <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
        <View style={styles.accessDenied}>
          <Text style={styles.accessDeniedIcon}>◉</Text>
          <Text style={styles.accessDeniedTitle}>Accès restreint</Text>
          <Text style={styles.accessDeniedText}>
            Cet espace est réservé aux futurs mariés.
          </Text>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [styles.accessDeniedBtn, pressed && { opacity: 0.7 }]}
          >
            <Text style={styles.accessDeniedBtnText}>Retour</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  if (!unlocked) {
    return (
      <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
        <PinGuard onUnlock={() => setUnlocked(true)} />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      {smartRippleItem && (
        <SmartRippleModal
          item={smartRippleItem}
          onClose={() => setSmartRippleItem(null)}
          onApply={(d, m) => applySmartRipple(smartRippleItem.id, d, m)}
        />
      )}
      {/* Header */}
      <View style={styles.header}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.headerBack, pressed && { opacity: 0.6 }]}
        >
          <Text style={styles.headerBackText}>←</Text>
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>Administration</Text>
          <Text style={styles.headerSubtitle}>Futurs Mariés</Text>
        </View>
        <View style={styles.headerBadge}>
          <Text style={styles.headerBadgeText}>ADMIN</Text>
        </View>
      </View>

      {/* Tab bar */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.tabBar}
        contentContainerStyle={styles.tabBarContent}
      >
        {TABS.map((tab) => (
          <Pressable
            key={tab.key}
            onPress={() => setActiveTab(tab.key)}
            style={({ pressed }) => [
              styles.tabItem,
              activeTab === tab.key && styles.tabItemActive,
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text
              style={[
                styles.tabItemIcon,
                activeTab === tab.key && styles.tabItemIconActive,
              ]}
            >
              {tab.icon}
            </Text>
            <Text
              style={[
                styles.tabItemLabel,
                activeTab === tab.key && styles.tabItemLabelActive,
              ]}
            >
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Content */}
      {activeTab === "dashboard" && (
        <DashboardTab onNavigate={setActiveTab} />
      )}
      {activeTab === "registrations" && <RegistrationsTab />}
      {activeTab === "dietary" && <DietaryTab />}
      {activeTab === "agenda" && <AgendaEditorTab />}
      {activeTab === "vendors" && <VendorsAdminTab />}
      {activeTab === "settings" && <SettingsTab />}
      {activeTab === "alerts" && <AlertsTab />}
      {activeTab === "qrcodes" && <QRCodesAdminTab />}
      {activeTab === "notifications" && <NotificationsAdminTab />}
    </ScreenContainer>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  // Header
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: "rgba(232,69,60,0.15)",
    gap: 12,
  },
  headerBack: {
    width: 32,
    height: 32,
    alignItems: "center",
    justifyContent: "center",
  },
  headerBackText: {
    fontSize: 22,
    color: NEU.red,
  },
  headerCenter: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#f5f0e8",
    letterSpacing: 0.3,
  },
  headerSubtitle: {
    fontSize: 10,
    color: "#9b9b8a",
    letterSpacing: 1,
    textTransform: "uppercase",
  },
  headerBadge: {
    backgroundColor: "rgba(232,69,60,0.12)",
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.3)",
  },
  headerBadgeText: {
    fontSize: 9,
    fontWeight: "700",
    color: NEU.red,
    letterSpacing: 1.5,
  },

  // Tab bar
  tabBar: {
    flexGrow: 0,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.3)",
    backgroundColor: NEU.bgRaised,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  tabBarContent: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 4,
  },
  tabItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 6,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.2)",
    backgroundColor: NEU.bgSunken,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  tabItemActive: {
    backgroundColor: "rgba(232,69,60,0.08)",
    borderColor: "rgba(232,69,60,0.45)",
    shadowColor: NEU.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  tabItemIcon: {
    fontSize: 12,
    color: "#9b9b8a",
  },
  tabItemIconActive: {
    color: NEU.red,
  },
  tabItemLabel: {
    fontSize: 12,
    color: "#9b9b8a",
    fontWeight: "500",
  },
  tabItemLabelActive: {
    color: NEU.red,
    fontWeight: "700",
  },

  // Tab content
  tabContent: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },

  // Access denied
  accessDenied: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    gap: 12,
  },
  accessDeniedIcon: {
    fontSize: 40,
    color: "rgba(232,69,60,0.3)",
    marginBottom: 8,
  },
  accessDeniedTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#f5f0e8",
  },
  accessDeniedText: {
    fontSize: 14,
    color: "#9b9b8a",
    textAlign: "center",
    lineHeight: 22,
  },
  accessDeniedBtn: {
    marginTop: 16,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.3)",
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 10,
  },
  accessDeniedBtnText: {
    fontSize: 14,
    color: NEU.red,
  },

  // Dashboard
  eventBanner: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    marginBottom: 20,
    alignItems: "center",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },
  eventBannerName: {
    fontSize: 16,
    fontWeight: "700",
    color: NEU.red,
    textAlign: "center",
    marginBottom: 4,
  },
  eventBannerDate: {
    fontSize: 12,
    color: "#9b9b8a",
    textTransform: "capitalize",
    marginBottom: 4,
  },
  eventBannerVenue: {
    fontSize: 12,
    color: "rgba(155,155,138,0.6)",
  },

  sectionTitle: {
    fontSize: 10,
    color: "#9b9b8a",
    letterSpacing: 2,
    textTransform: "uppercase",
    fontWeight: "600",
    marginBottom: 10,
  },

  statsGrid: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 7,
  },
  statValue: {
    fontSize: 24,
    fontWeight: "700",
  },
  statLabel: {
    fontSize: 10,
    color: "#9b9b8a",
    marginTop: 3,
    letterSpacing: 0.3,
  },

  presenceCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    marginBottom: 20,
    gap: 12,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },
  presenceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  presenceLabel: {
    fontSize: 12,
    color: "#9b9b8a",
    width: 70,
  },
  presenceBarContainer: {
    flex: 1,
    height: 6,
    backgroundColor: "rgba(155,155,138,0.1)",
    borderRadius: 3,
    overflow: "hidden",
  },
  presenceBar: {
    height: 6,
    borderRadius: 3,
  },
  presenceCount: {
    fontSize: 12,
    fontWeight: "700",
    width: 36,
    textAlign: "right",
  },

  messageCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    marginBottom: 8,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  messageName: {
    fontSize: 11,
    color: NEU.red,
    fontWeight: "600",
    marginBottom: 4,
    letterSpacing: 0.3,
  },
  messageText: {
    fontSize: 13,
    color: "#f5f0e8",
    lineHeight: 20,
    fontStyle: "italic",
  },

  seeMoreBtn: {
    alignSelf: "center",
    marginTop: 4,
    marginBottom: 8,
  },
  seeMoreText: {
    fontSize: 12,
    color: NEU.red,
  },

  // Registrations
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: NEU.bgSunken,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.3)",
    marginBottom: 12,
    paddingHorizontal: 14,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 0,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 14,
    color: "#f5f0e8",
  },
  searchClear: {
    padding: 4,
  },
  searchClearText: {
    fontSize: 14,
    color: "#9b9b8a",
  },
  listCount: {
    fontSize: 11,
    color: "#9b9b8a",
    marginBottom: 10,
    letterSpacing: 0.3,
  },

  regRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    gap: 10,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  regAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(232,69,60,0.1)",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.25)",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  regAvatarText: {
    fontSize: 13,
    fontWeight: "700",
    color: NEU.red,
  },
  regInfo: {
    flex: 1,
  },
  regName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#f5f0e8",
    marginBottom: 2,
  },
  regPlusOne: {
    fontSize: 12,
    color: NEU.red,
    fontWeight: "400",
  },
  regEmail: {
    fontSize: 11,
    color: "#9b9b8a",
    marginBottom: 3,
  },
  regPresence: {
    fontSize: 10,
    color: "rgba(155,155,138,0.6)",
    letterSpacing: 0.3,
  },
  regDietBadge: {
    marginTop: 5,
    alignSelf: "flex-start",
    backgroundColor: "rgba(251,191,36,0.1)",
    borderRadius: 5,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderWidth: 0.5,
    borderColor: "rgba(251,191,36,0.3)",
  },
  regDietText: {
    fontSize: 10,
    color: "#FBBF24",
    fontWeight: "500",
  },

  deleteBtn: {
    width: 28,
    height: 28,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: "rgba(248,113,113,0.08)",
  },
  deleteBtnText: {
    fontSize: 12,
    color: "#f87171",
    fontWeight: "600",
  },

  emptyContainer: {
    padding: 32,
    alignItems: "center",
  },
  emptyText: {
    fontSize: 13,
    color: "#9b9b8a",
    textAlign: "center",
  },

  // Registration detail
  backBtn: {
    marginBottom: 16,
    alignSelf: "flex-start",
  },
  backBtnText: {
    fontSize: 14,
    color: NEU.red,
    fontWeight: "500",
  },
  detailAvatarContainer: {
    alignItems: "center",
    marginBottom: 20,
    gap: 8,
  },
  detailAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "rgba(232,69,60,0.1)",
    borderWidth: 2,
    borderColor: "rgba(232,69,60,0.3)",
    alignItems: "center",
    justifyContent: "center",
  },
  detailAvatarText: {
    fontSize: 22,
    fontWeight: "700",
    color: NEU.red,
  },
  detailName: {
    fontSize: 18,
    fontWeight: "700",
    color: "#f5f0e8",
  },
  detailDate: {
    fontSize: 11,
    color: "#9b9b8a",
  },
  detailSection: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    marginBottom: 12,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },
  detailSectionTitle: {
    fontSize: 9,
    color: "#9b9b8a",
    letterSpacing: 2,
    textTransform: "uppercase",
    fontWeight: "600",
    marginBottom: 10,
  },
  detailRow: {
    paddingVertical: 7,
    borderBottomWidth: 0.5,
    borderBottomColor: "rgba(232,69,60,0.06)",
  },
  detailRowLabel: {
    fontSize: 10,
    color: "#9b9b8a",
    letterSpacing: 0.5,
    marginBottom: 2,
    textTransform: "uppercase",
  },
  detailRowValue: {
    fontSize: 14,
    color: "#f5f0e8",
  },
  detailRowValueHighlight: {
    color: "#4ade80",
    fontWeight: "600",
  },
  dietaryHighlight: {
    backgroundColor: "rgba(251,191,36,0.08)",
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: "rgba(251,191,36,0.2)",
  },
  dietaryHighlightText: {
    fontSize: 14,
    color: "#FBBF24",
    fontWeight: "500",
  },
  deleteFullBtn: {
    marginTop: 8,
    borderWidth: 1,
    borderColor: "rgba(248,113,113,0.3)",
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "rgba(248,113,113,0.05)",
  },
  deleteFullBtnText: {
    fontSize: 14,
    color: "#f87171",
    fontWeight: "500",
  },

  // Dietary
  dietaryHeader: {
    alignItems: "center",
    marginBottom: 20,
    paddingVertical: 16,
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },
  dietaryHeaderTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.red,
    marginBottom: 4,
  },
  dietaryHeaderSub: {
    fontSize: 11,
    color: "#9b9b8a",
  },
  dietaryBars: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    marginBottom: 16,
    gap: 10,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.45,
    shadowRadius: 12,
    elevation: 8,
  },
  dietaryBarRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  dietaryBarDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    flexShrink: 0,
  },
  dietaryBarTrack: {
    flex: 1,
    height: 6,
    backgroundColor: "rgba(155,155,138,0.1)",
    borderRadius: 3,
    overflow: "hidden",
  },
  dietaryBarFill: {
    height: 6,
    borderRadius: 3,
    minWidth: 4,
  },
  dietaryBarCount: {
    fontSize: 12,
    fontWeight: "700",
    width: 20,
    textAlign: "right",
  },
  dietaryGroup: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    marginBottom: 8,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  dietaryGroupHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  dietaryGroupDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    flexShrink: 0,
  },
  dietaryGroupLabel: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
    color: "#f5f0e8",
  },
  dietaryGroupBadge: {
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderWidth: 1,
  },
  dietaryGroupCount: {
    fontSize: 12,
    fontWeight: "700",
  },
  dietaryGroupChevron: {
    fontSize: 10,
    color: "#9b9b8a",
    width: 16,
    textAlign: "center",
  },
  dietaryGroupGuests: {
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 0.5,
    borderTopColor: "rgba(232,69,60,0.08)",
    gap: 6,
  },
  dietaryGuestRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  dietaryGuestDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    flexShrink: 0,
  },
  dietaryGuestName: {
    fontSize: 13,
    color: "#f5f0e8",
  },
  rawDietRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    paddingVertical: 8,
    borderBottomWidth: 0.5,
    borderBottomColor: "rgba(232,69,60,0.06)",
    gap: 12,
  },
  rawDietName: {
    fontSize: 13,
    color: "#f5f0e8",
    fontWeight: "500",
    flex: 1,
  },
  rawDietValue: {
    fontSize: 12,
    color: "#FBBF24",
    flex: 1,
    textAlign: "right",
  },

  // Agenda editor
  addButton: {
    backgroundColor: "rgba(232,69,60,0.12)",
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.3)",
    marginBottom: 12,
  },
  addButtonText: {
    fontSize: 14,
    color: NEU.red,
    fontWeight: "600",
  },
  agendaEditorRow: {
    flexDirection: "row",
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  agendaEditorCatBar: {
    width: 4,
    flexShrink: 0,
  },
  agendaEditorContent: {
    flex: 1,
    padding: 12,
  },
  agendaEditorTimeRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 4,
  },
  agendaEditorTime: {
    fontSize: 12,
    fontWeight: "700",
    color: NEU.red,
  },
  agendaEditorEndTime: {
    fontSize: 11,
    color: "#9b9b8a",
  },
  agendaEditorCatBadge: {
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderWidth: 0.5,
    marginLeft: "auto",
  },
  agendaEditorCatText: {
    fontSize: 9,
    fontWeight: "600",
    letterSpacing: 0.3,
  },
  agendaEditorTitle: {
    fontSize: 13,
    fontWeight: "600",
    color: "#f5f0e8",
    marginBottom: 2,
  },
  agendaEditorSpeaker: {
    fontSize: 11,
    color: "#9b9b8a",
  },
  agendaEditorActions: {
    flexDirection: "column",
    justifyContent: "center",
    paddingHorizontal: 10,
    gap: 8,
  },
  editBtn: {
    width: 28,
    height: 28,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: "rgba(232,69,60,0.08)",
  },
  editBtnText: {
    fontSize: 14,
    color: NEU.red,
  },

  // Agenda form
  formTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: NEU.red,
    marginBottom: 20,
    letterSpacing: 0.3,
  },
  formRow: {
    flexDirection: "row",
    gap: 12,
  },
  formField: {
    marginBottom: 14,
  },
  formFieldLabel: {
    fontSize: 11,
    color: "#9b9b8a",
    marginBottom: 6,
    letterSpacing: 0.3,
    fontWeight: "500",
  },
  formInput: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: NEU.textPrimary,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.3)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 0,
  },
  formInputMultiline: {
    minHeight: 80,
    textAlignVertical: "top",
    paddingTop: 12,
  },
  categoryScroll: {
    flexGrow: 0,
    marginBottom: 20,
  },
  categoryScrollContent: {
    gap: 8,
    paddingVertical: 4,
  },
  categoryChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.3)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 3,
  },
  categoryChipText: {
    fontSize: 12,
    color: "#9b9b8a",
    fontWeight: "500",
  },
  saveButton: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 8,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.4)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8,
  },
  saveButtonDisabled: {
    backgroundColor: "rgba(232,69,60,0.3)",
  },
  saveButtonText: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.red,
    letterSpacing: 0.3,
  },

  // Vendors admin
  vendorSummaryRow: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 12,
  },
  vendorSummaryCard: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    gap: 4,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  vendorSummaryCount: {
    fontSize: 22,
    fontWeight: "800",
  },
  vendorSummaryLabel: {
    fontSize: 10,
    color: "#9b9b8a",
    letterSpacing: 0.3,
  },
  vendorRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    overflow: "hidden",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  vendorRowMain: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    gap: 12,
  },
  vendorAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "rgba(232,69,60,0.1)",
    borderWidth: 1.5,
    borderColor: "rgba(232,69,60,0.25)",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  vendorAvatarText: {
    fontSize: 14,
    fontWeight: "700",
    color: NEU.red,
  },
  vendorRowInfo: {
    flex: 1,
    gap: 2,
  },
  vendorRowName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#f5f0e8",
  },
  vendorRowRole: {
    fontSize: 12,
    color: "#9b9b8a",
  },
  vendorRowArrival: {
    fontSize: 10,
    color: "rgba(232,69,60,0.6)",
    marginTop: 2,
  },
  vendorStatusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    marginRight: 10,
    flexShrink: 0,
  },
  vendorStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  vendorStatusText: {
    fontSize: 11,
    fontWeight: "600",
  },
  vendorDetailAvatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: "rgba(232,69,60,0.1)",
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  vendorDetailAvatarText: {
    fontSize: 26,
    fontWeight: "700",
    color: NEU.red,
  },
  vendorDetailRole: {
    fontSize: 13,
    color: "#9b9b8a",
    marginTop: 2,
  },
  vendorDetailScroll: {
    paddingBottom: 32,
  },
  vendorContactLink: {
    color: NEU.red,
    textDecorationLine: "underline",
  },
  vendorDetailActions: {
    flexDirection: "row",
    gap: 10,
    marginTop: 8,
  },
  vendorEditBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.4)",
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "rgba(232,69,60,0.06)",
  },
  vendorEditBtnText: {
    fontSize: 14,
    color: NEU.red,
    fontWeight: "500",
  },
  vendorFormActions: {
    flexDirection: "row",
    gap: 10,
    marginTop: 8,
  },
  vendorCancelBtn: {
    borderWidth: 1,
    borderColor: "rgba(155,155,138,0.3)",
    borderRadius: 14,
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: "center",
  },
  vendorCancelBtnText: {
    fontSize: 15,
    color: "#9b9b8a",
    fontWeight: "500",
  },
});
