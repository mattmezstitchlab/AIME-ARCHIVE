/**
 * QR Codes d'invitation par rôle
 * Accessible depuis l'onglet Admin → QR Codes
 * Génère 3 QR codes (couple, vendor, guest) encodant un deep link
 * qui pré-configure automatiquement le rôle à l'ouverture de l'app.
 */

import { View, Text, StyleSheet, ScrollView, Pressable, Share, Alert, Platform } from "react-native";
import { useState } from "react";
import QRCode from "react-native-qrcode-svg";
import * as Sharing from "expo-sharing";
import { ScreenContainer } from "@/components/screen-container";
import { AppHeader } from "@/components/app-header";
import { NEU, neuShadow } from "@/lib/neu-styles";
import type { UserRole } from "@/lib/wedding-store";

const ROLES: { key: UserRole; label: string; icon: string; desc: string; color: string }[] = [
  {
    key: "couple",
    label: "Futurs Mariés",
    icon: "💍",
    desc: "Accès complet à l'administration et à l'organisation",
    color: NEU.red,
  },
  {
    key: "vendor",
    label: "Prestataire",
    icon: "🎵",
    desc: "Planning, checklist et signalement d'arrivée",
    color: NEU.info,
  },
  {
    key: "guest",
    label: "Invité(e)",
    icon: "🌸",
    desc: "Programme, inscription et informations pratiques",
    color: NEU.success,
  },
];

// Deep link encodé dans le QR code
// Format : ddwedding://role/<role>
const buildQRValue = (role: UserRole) =>
  `ddwedding://role/${role}`;

export default function QRCodesScreen() {
  const [activeRole, setActiveRole] = useState<UserRole>("guest");
  const activeRoleData = ROLES.find(r => r.key === activeRole)!;

  const handleShare = async () => {
    try {
      const message = `Rejoignez le programme de notre mariage !\n\nScannez ce QR code pour accéder à votre espace ${activeRoleData.label.toLowerCase()}.\n\nLien direct : ${buildQRValue(activeRole)}`;
      await Share.share({ message });
    } catch (e) {
      Alert.alert("Partage", "Impossible de partager le QR code.");
    }
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <AppHeader title="QR Codes d'invitation" showBack />
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Sélecteur de rôle */}
        <Text style={styles.sectionLabel}>SÉLECTIONNER UN RÔLE</Text>
        <View style={styles.roleSelector}>
          {ROLES.map(role => (
            <Pressable
              key={role.key}
              onPress={() => setActiveRole(role.key)}
              style={({ pressed }) => [
                styles.roleChip,
                activeRole === role.key && { borderColor: role.color, backgroundColor: `${role.color}12` },
                pressed && styles.chipPressed,
              ]}
            >
              <Text style={styles.chipIcon}>{role.icon}</Text>
              <Text style={[styles.chipLabel, activeRole === role.key && { color: role.color }]}>
                {role.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* QR Code principal */}
        <View style={styles.qrCard}>
          {/* En-tête de la carte */}
          <View style={styles.qrCardHeader}>
            <Text style={styles.qrRoleIcon}>{activeRoleData.icon}</Text>
            <View style={styles.qrCardHeaderText}>
              <Text style={[styles.qrRoleLabel, { color: activeRoleData.color }]}>
                {activeRoleData.label}
              </Text>
              <Text style={styles.qrRoleDesc}>{activeRoleData.desc}</Text>
            </View>
          </View>

          {/* QR Code en creux Neumorphism */}
          <View style={styles.qrContainer}>
            <View style={styles.qrInset}>
              <QRCode
                value={buildQRValue(activeRole)}
                size={200}
                color={NEU.textPrimary}
                backgroundColor={NEU.bgSunken}
                logo={undefined}
              />
            </View>
          </View>

          {/* URL encodée */}
          <View style={styles.urlBadge}>
            <Text style={styles.urlText} numberOfLines={1}>
              {buildQRValue(activeRole)}
            </Text>
          </View>

          {/* Instructions */}
          <Text style={styles.instructions}>
            Partagez ce QR code avec vos {activeRoleData.label.toLowerCase()}s.{"\n"}
            En le scannant, l'application s'ouvrira directement sur leur espace dédié.
          </Text>

          {/* Bouton partager */}
          <Pressable
            onPress={handleShare}
            style={({ pressed }) => [
              styles.shareBtn,
              { borderColor: activeRoleData.color, backgroundColor: `${activeRoleData.color}10` },
              pressed && styles.shareBtnPressed,
            ]}
          >
            <Text style={[styles.shareBtnText, { color: activeRoleData.color }]}>
              ↑ Partager ce QR code
            </Text>
          </Pressable>
        </View>

        {/* Tous les QR codes en miniature */}
        <Text style={styles.sectionLabel}>APERÇU DE TOUS LES RÔLES</Text>
        <View style={styles.miniGrid}>
          {ROLES.map(role => (
            <Pressable
              key={role.key}
              onPress={() => setActiveRole(role.key)}
              style={({ pressed }) => [
                styles.miniCard,
                pressed && styles.chipPressed,
              ]}
            >
              <View style={styles.miniQrWrap}>
                <QRCode
                  value={buildQRValue(role.key)}
                  size={80}
                  color={NEU.textPrimary}
                  backgroundColor={NEU.bgSunken}
                />
              </View>
              <Text style={styles.miniIcon}>{role.icon}</Text>
              <Text style={[styles.miniLabel, { color: role.color }]}>{role.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Note d'usage */}
        <View style={styles.noteCard}>
          <Text style={styles.noteTitle}>💡 Comment ça marche ?</Text>
          <Text style={styles.noteText}>
            1. Générez le QR code correspondant au rôle de votre invité.{"\n"}
            2. Partagez-le par message, email ou imprimez-le sur les faire-parts.{"\n"}
            3. En scannant le code, l'app s'ouvre directement sur l'espace dédié au rôle.{"\n"}
            4. Aucune saisie manuelle nécessaire — le rôle est configuré automatiquement.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: {
    padding: 20,
    paddingBottom: 40,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: "700",
    color: NEU.textMuted,
    letterSpacing: 2.5,
    marginBottom: 12,
    marginTop: 8,
  },

  // Sélecteur de rôle
  roleSelector: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 24,
    flexWrap: "wrap",
  },
  roleChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: NEU.bgRaised,
    borderWidth: 1.5,
    borderColor: NEU.borderSubtle,
    ...neuShadow,
  },
  chipPressed: {
    backgroundColor: NEU.bgSunken,
    shadowOffset: { width: 2, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  chipIcon: { fontSize: 16 },
  chipLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: NEU.textSecondary,
  },

  // Carte QR principale
  qrCard: {
    backgroundColor: NEU.bgRaised,
    borderRadius: 20,
    padding: 20,
    marginBottom: 28,
    borderWidth: 1,
    borderColor: NEU.shadowLight,
    ...neuShadow,
  },
  qrCardHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 20,
  },
  qrRoleIcon: { fontSize: 28 },
  qrCardHeaderText: { flex: 1 },
  qrRoleLabel: {
    fontSize: 18,
    fontWeight: "800",
    letterSpacing: 0.2,
  },
  qrRoleDesc: {
    fontSize: 12,
    color: NEU.textMuted,
    marginTop: 2,
  },

  // QR Code en creux
  qrContainer: {
    alignItems: "center",
    marginBottom: 16,
  },
  qrInset: {
    padding: 16,
    borderRadius: 16,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1,
    borderColor: NEU.shadowLight,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 3,
  },

  // URL
  urlBadge: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
  },
  urlText: {
    fontSize: 11,
    color: NEU.textMuted,
    fontFamily: Platform.OS === "ios" ? "Courier" : "monospace",
    textAlign: "center",
  },

  instructions: {
    fontSize: 12,
    color: NEU.textSecondary,
    textAlign: "center",
    lineHeight: 18,
    marginBottom: 16,
  },

  // Bouton partager
  shareBtn: {
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: "center",
    borderWidth: 1.5,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 5,
  },
  shareBtnPressed: {
    backgroundColor: NEU.bgSunken,
    shadowOffset: { width: 2, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  shareBtnText: {
    fontSize: 15,
    fontWeight: "700",
    letterSpacing: 0.3,
  },

  // Mini grille
  miniGrid: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 24,
    justifyContent: "space-between",
  },
  miniCard: {
    flex: 1,
    backgroundColor: NEU.bgRaised,
    borderRadius: 14,
    padding: 12,
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
    borderColor: NEU.shadowLight,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 5,
  },
  miniQrWrap: {
    padding: 8,
    borderRadius: 10,
    backgroundColor: NEU.bgSunken,
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
  },
  miniIcon: { fontSize: 16 },
  miniLabel: {
    fontSize: 10,
    fontWeight: "700",
    textAlign: "center",
  },

  // Note
  noteCard: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
  },
  noteTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: NEU.textPrimary,
    marginBottom: 8,
  },
  noteText: {
    fontSize: 12,
    color: NEU.textSecondary,
    lineHeight: 20,
  },
});
