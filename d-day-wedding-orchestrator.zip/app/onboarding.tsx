import { View, Text, Pressable, StyleSheet, Animated, StatusBar, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { useAppContext } from "@/lib/app-context";
import type { UserRole } from "@/lib/wedding-store";
import { NEU } from "@/lib/neu-styles";
import { NeuButton } from "@/components/ui/neu-button";

const ROLES: { key: UserRole; label: string; subtitle: string; icon: string; desc: string; accent: string; border: string }[] = [
  {
    key: "couple",
    label: "Futurs Mariés",
    subtitle: "Accès complet à l'organisation",
    icon: "💍",
    desc: "Gérez l'agenda, les prestataires et les inscriptions",
    accent: NEU.red,
    border: NEU.redBorder,
  },
  {
    key: "vendor",
    label: "Prestataire",
    subtitle: "Planning & coordination",
    icon: "✦",
    desc: "Consultez votre planning et signalez votre arrivée",
    accent: NEU.info,
    border: NEU.borderSubtle,
  },
  {
    key: "guest",
    label: "Invité(e)",
    subtitle: "Programme & informations",
    icon: "◈",
    desc: "Accédez au programme et inscrivez-vous",
    accent: NEU.warning,
    border: NEU.borderSubtle,
  },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const { setUserRole } = useAppContext();
  const [selected, setSelected] = useState<UserRole | null>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 900, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 900, useNativeDriver: true }),
    ]).start();
  }, []);

  const handleContinue = async () => {
    if (!selected) return;
    await setUserRole(selected);
    router.replace("/(tabs)");
  };

  const selectedRole = ROLES.find(r => r.key === selected);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <StatusBar barStyle="dark-content" backgroundColor={NEU.bg} />

        <ScrollView
          contentContainerStyle={styles.scroll}
          showsVerticalScrollIndicator={false}
        >
          <Animated.View
            style={[styles.content, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}
          >
            {/* Monogramme Neumorphism Neon */}
            <View style={styles.monogramOuter}>
              <View style={styles.monogramInner}>
                <Text style={styles.monogramText}>D·D</Text>
              </View>
              {/* Halo magenta */}
              <View style={styles.monogramHalo} />
            </View>

            {/* Titre */}
            <Text style={styles.title}>D Day Wedding</Text>
            <Text style={styles.subtitle}>ORCHESTRATEUR D'ÉVÉNEMENTS</Text>

            {/* Divider néon magenta */}
            <View style={styles.divider} />

            <Text style={styles.sectionLabel}>QUI ÊTES-VOUS ?</Text>

            {/* Rôles */}
            <View style={styles.rolesContainer}>
              {ROLES.map((role) => {
                const isActive = selected === role.key;
                return (
                  <Pressable
                    key={role.key}
                    onPress={() => setSelected(role.key)}
                    style={({ pressed }) => [
                      styles.roleCard,
                      isActive && { borderColor: role.border, backgroundColor: `${role.accent}08` },
                      pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                    ]}
                  >
                    {/* Icône en relief */}
                    <View style={[
                      styles.roleIconWrap,
                      isActive && { borderColor: role.border, backgroundColor: `${role.accent}12` },
                    ]}>
                      <Text style={styles.roleIcon}>{role.icon}</Text>
                    </View>

                    <View style={styles.roleTextWrap}>
                      <Text style={[styles.roleLabel, isActive && { color: role.accent }]}>
                        {role.label}
                      </Text>
                      <Text style={styles.roleSubtitle}>{role.subtitle}</Text>
                      {isActive && <Text style={[styles.roleDesc, { color: `${role.accent}aa` }]}>{role.desc}</Text>}
                    </View>

                    {isActive && (
                      <View style={[styles.checkWrap, { borderColor: role.accent, backgroundColor: `${role.accent}15` }]}>
                        <Text style={[styles.checkText, { color: role.accent }]}>✓</Text>
                      </View>
                    )}
                  </Pressable>
                );
              })}
            </View>

            {/* Bouton Neumorphism animé */}
            <NeuButton
              label="Accéder au programme"
              onPress={handleContinue}
              disabled={!selected}
              fullWidth
              size="lg"
              style={{ marginBottom: 22 }}
            />

            <Text style={styles.footer}>Mariage Sophie & Alexandre · 14 juin 2026</Text>
          </Animated.View>
        </ScrollView>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: NEU.bg,
  },
  scroll: {
    flexGrow: 1,
    alignItems: "center",
    paddingHorizontal: 24,
    paddingTop: 64,
    paddingBottom: 40,
  },
  content: {
    width: "100%",
    alignItems: "center",
  },

  // ── Monogramme ──
  monogramOuter: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: NEU.bgRaised,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 24,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 7, height: 7 },
    shadowOpacity: 1,
    shadowRadius: 16,
    elevation: 14,
    borderWidth: 1,
    borderColor: NEU.redBorder,
  },
  monogramInner: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(232,69,60,0.2)",
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 6,
  },
  monogramHalo: {
    position: "absolute",
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "rgba(232,69,60,0.05)",
    zIndex: -1,
  },
  monogramText: {
    fontSize: 22,
    fontWeight: "800",
    color: NEU.red,
    letterSpacing: 2,
  },

  // ── Titre ──
  title: {
    fontSize: 30,
    fontWeight: "800",
    color: NEU.textPrimary,
    letterSpacing: -0.3,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 10,
    fontWeight: "600",
    color: NEU.textSecondary,
    letterSpacing: 3,
    textAlign: "center",
    marginTop: 5,
  },
  divider: {
    width: 48,
    height: 2,
    backgroundColor: NEU.red,
    borderRadius: 1,
    marginVertical: 22,
    opacity: 0.8,
    shadowColor: NEU.red,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 6,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: "700",
    color: NEU.textSecondary,
    letterSpacing: 2.5,
    textAlign: "center",
    marginBottom: 18,
  },

  // ── Rôles ──
  rolesContainer: {
    width: "100%",
    gap: 12,
    marginBottom: 28,
  },
  roleCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: NEU.bgRaised,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 10,
    gap: 14,
  },
  roleIconWrap: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 6,
    elevation: 4,
  },
  roleIcon: {
    fontSize: 20,
  },
  roleTextWrap: {
    flex: 1,
  },
  roleLabel: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.textPrimary,
  },
  roleSubtitle: {
    fontSize: 12,
    color: NEU.textSecondary,
    marginTop: 2,
  },
  roleDesc: {
    fontSize: 11,
    marginTop: 5,
    lineHeight: 16,
  },
  checkWrap: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  checkText: {
    fontSize: 12,
    fontWeight: "700",
  },

  footer: {
    fontSize: 11,
    color: NEU.textMuted,
    textAlign: "center",
    letterSpacing: 0.3,
  },
});
