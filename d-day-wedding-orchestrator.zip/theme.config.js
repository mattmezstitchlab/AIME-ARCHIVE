/** @type {const} */
const themeColors = {
  // Light Neumorphism — fond gris clair, accents rouge corail
  primary:    { light: '#e8453c', dark: '#e8453c' },
  background: { light: '#e8e8e8', dark: '#e8e8e8' },
  surface:    { light: '#f0f0f0', dark: '#f0f0f0' },
  foreground: { light: '#2d2d2d', dark: '#2d2d2d' },
  muted:      { light: '#999999', dark: '#999999' },
  border:     { light: '#c8c8c8', dark: '#c8c8c8' },
  success:    { light: '#27ae60', dark: '#27ae60' },
  warning:    { light: '#f39c12', dark: '#f39c12' },
  error:      { light: '#e8453c', dark: '#e8453c' },
  tint:       { light: '#e8453c', dark: '#e8453c' },
};

module.exports = { themeColors };
