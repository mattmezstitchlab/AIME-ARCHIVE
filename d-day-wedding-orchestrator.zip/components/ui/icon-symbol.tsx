// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconSymbolName = string;

const MAPPING: Record<string, ComponentProps<typeof MaterialIcons>["name"]> = {
  // Navigation
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.down": "expand-more",
  "chevron.up": "expand-less",
  // App tabs
  "calendar": "calendar-today",
  "list.bullet": "format-list-bulleted",
  "person.2.fill": "group",
  "info.circle.fill": "info",
  "pencil.and.list.clipboard": "assignment",
  // Content
  "heart.fill": "favorite",
  "music.note": "music-note",
  "camera.fill": "photo-camera",
  "fork.knife": "restaurant",
  "car.fill": "directions-car",
  "wineglass.fill": "local-bar",
  "star.fill": "star",
  "mappin.fill": "location-on",
  "phone.fill": "phone",
  "envelope.fill": "email",
  "clock.fill": "access-time",
  "checkmark.circle.fill": "check-circle",
  "xmark.circle.fill": "cancel",
  "person.fill": "person",
  "building.2.fill": "business",
  "music.mic": "mic",
  "sparkles": "auto-awesome",
  "wand.and.stars": "auto-fix-high",
  "arrow.right": "arrow-forward",
  "arrow.left": "arrow-back",
  "plus": "add",
  "minus": "remove",
  "xmark": "close",
  "checkmark": "check",
  "bell.fill": "notifications",
  "gear": "settings",
  "square.and.arrow.up": "share",
  "doc.text.fill": "description",
  "crown.fill": "workspace-premium",
};

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
