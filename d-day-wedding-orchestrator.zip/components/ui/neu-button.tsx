/**
 * NeuButton — Bouton Neumorphism avec animation d'enfoncement
 *
 * Effet de pression : le bouton s'enfonce visuellement
 *   - scale: 1.0 → 0.97
 *   - shadowRadius diminue (relief s'aplatit)
 *   - backgroundColor légèrement plus sombre
 *   - Haptic feedback léger
 *
 * Usage :
 *   <NeuButton onPress={handlePress} label="Confirmer" />
 *   <NeuButton onPress={handlePress} variant="secondary" label="Annuler" />
 *   <NeuButton onPress={handlePress} variant="danger" label="Supprimer" />
 */

import React, { useCallback } from "react";
import { Text, StyleSheet, Platform, ViewStyle, TextStyle } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
  runOnJS,
} from "react-native-reanimated";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import * as Haptics from "expo-haptics";
import { NEU } from "@/lib/neu-styles";

// ─── Types ────────────────────────────────────────────────────────────────────

type NeuButtonVariant = "primary" | "secondary" | "danger" | "success" | "ghost";

interface NeuButtonProps {
  label: string;
  onPress: () => void;
  variant?: NeuButtonVariant;
  disabled?: boolean;
  fullWidth?: boolean;
  icon?: React.ReactNode;
  style?: ViewStyle;
  labelStyle?: TextStyle;
  size?: "sm" | "md" | "lg";
}

// ─── Variant configs ──────────────────────────────────────────────────────────

const VARIANTS: Record<NeuButtonVariant, {
  bg: string;
  borderColor: string;
  textColor: string;
  glowColor: string;
}> = {
  primary: {
    bg: NEU.red,
    borderColor: NEU.redDark,
    textColor: "#ffffff",
    glowColor: "rgba(232,69,60,0.15)",
  },
  secondary: {
    bg: NEU.bgRaised,
    borderColor: NEU.borderSubtle,
    textColor: NEU.textPrimary,
    glowColor: "rgba(0,0,0,0.02)",
  },
  danger: {
    bg: NEU.bgRaised,
    borderColor: "rgba(192,57,43,0.4)",
    textColor: NEU.redDark,
    glowColor: "rgba(192,57,43,0.06)",
  },
  success: {
    bg: NEU.bgRaised,
    borderColor: "rgba(39,174,96,0.35)",
    textColor: "#27ae60",
    glowColor: "rgba(39,174,96,0.06)",
  },
  ghost: {
    bg: "transparent",
    borderColor: NEU.redBorder,
    textColor: NEU.red,
    glowColor: "transparent",
  },
};

const SIZE_STYLES: Record<"sm" | "md" | "lg", {
  paddingVertical: number;
  paddingHorizontal: number;
  fontSize: number;
  borderRadius: number;
}> = {
  sm: { paddingVertical: 10, paddingHorizontal: 16, fontSize: 13, borderRadius: 12 },
  md: { paddingVertical: 14, paddingHorizontal: 22, fontSize: 15, borderRadius: 14 },
  lg: { paddingVertical: 18, paddingHorizontal: 28, fontSize: 17, borderRadius: 16 },
};

// ─── Component ────────────────────────────────────────────────────────────────

export function NeuButton({
  label,
  onPress,
  variant = "primary",
  disabled = false,
  fullWidth = false,
  icon,
  style,
  labelStyle,
  size = "md",
}: NeuButtonProps) {
  const v = VARIANTS[variant];
  const s = SIZE_STYLES[size];

  // Animation values
  const scale = useSharedValue(1);
  const shadowOpacity = useSharedValue(0.55);
  const shadowRadius = useSharedValue(12);
  const bgOpacity = useSharedValue(1);

  const triggerHaptic = useCallback(() => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }, []);

  const triggerPress = useCallback(() => {
    onPress();
  }, [onPress]);

  const gesture = Gesture.Tap()
    .enabled(!disabled)
    .onBegin(() => {
      // Enfoncement : scale diminue, ombre s'aplatit
      scale.value = withTiming(0.97, { duration: 80, easing: Easing.out(Easing.quad) });
      shadowOpacity.value = withTiming(0.2, { duration: 80 });
      shadowRadius.value = withTiming(4, { duration: 80 });
      bgOpacity.value = withTiming(0.85, { duration: 80 });
      runOnJS(triggerHaptic)();
    })
    .onFinalize((_, success) => {
      // Rebond : retour à l'état normal
      scale.value = withTiming(1, { duration: 200, easing: Easing.out(Easing.back(1.5)) });
      shadowOpacity.value = withTiming(0.55, { duration: 200 });
      shadowRadius.value = withTiming(12, { duration: 200 });
      bgOpacity.value = withTiming(1, { duration: 200 });
      if (success) {
        runOnJS(triggerPress)();
      }
    });

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    shadowOpacity: shadowOpacity.value,
    shadowRadius: shadowRadius.value,
    opacity: disabled ? 0.45 : bgOpacity.value,
  }));

  return (
    <GestureDetector gesture={gesture}>
      <Animated.View
        style={[
          styles.base,
          {
            backgroundColor: v.bg,
            borderColor: v.borderColor,
            borderRadius: s.borderRadius,
            paddingVertical: s.paddingVertical,
            paddingHorizontal: s.paddingHorizontal,
            width: fullWidth ? "100%" : undefined,
          },
          animatedStyle,
          style,
        ]}
      >
        {/* Glow intérieur */}
        <Animated.View
          style={[
            styles.glow,
            { backgroundColor: v.glowColor, borderRadius: s.borderRadius - 1 },
          ]}
        />
        {/* Contenu */}
        {icon && <Animated.View style={styles.iconWrapper}>{icon}</Animated.View>}
        <Text
          style={[
            styles.label,
            { color: v.textColor, fontSize: s.fontSize },
            labelStyle,
          ]}
        >
          {label}
        </Text>
      </Animated.View>
    </GestureDetector>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  base: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 0.55,
    shadowRadius: 12,
    elevation: 8,
    overflow: "hidden",
  },
  glow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  iconWrapper: {
    marginRight: 8,
  },
  label: {
    fontWeight: "700",
    letterSpacing: 0.6,
    textAlign: "center",
  },
});
