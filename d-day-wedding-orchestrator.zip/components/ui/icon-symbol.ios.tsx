import { SymbolView, SymbolViewProps, SymbolWeight } from "expo-symbols";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ComponentProps } from "react";
import { StyleProp, ViewStyle, OpaqueColorValue, StyleSheet, TextStyle } from "react-native";

// SF Symbols that are available on iOS
const SF_SYMBOLS: Set<string> = new Set([
  "house.fill",
  "paperplane.fill",
  "chevron.left.forwardslash.chevron.right",
  "chevron.right",
  "chevron.left",
  "chevron.down",
  "chevron.up",
  "heart.fill",
  "star.fill",
  "person.fill",
  "person.2.fill",
  "info.circle.fill",
  "checkmark.circle.fill",
  "xmark.circle.fill",
  "bell.fill",
  "gear",
  "xmark",
  "checkmark",
  "plus",
  "minus",
  "arrow.right",
  "arrow.left",
  "clock.fill",
  "mappin.fill",
  "phone.fill",
  "envelope.fill",
  "camera.fill",
  "music.note",
  "music.mic",
  "doc.text.fill",
  "square.and.arrow.up",
  "building.2.fill",
  "crown.fill",
  "sparkles",
  "wand.and.stars",
  "calendar",
]);

const MATERIAL_FALLBACK: Record<string, ComponentProps<typeof MaterialIcons>["name"]> = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.down": "expand-more",
  "chevron.up": "expand-less",
  "calendar": "calendar-today",
  "list.bullet": "format-list-bulleted",
  "person.2.fill": "group",
  "info.circle.fill": "info",
  "pencil.and.list.clipboard": "assignment",
  "heart.fill": "favorite",
  "music.note": "music-note",
  "camera.fill": "photo-camera",
  "fork.knife": "restaurant",
  "car.fill": "directions-car",
  "wineglass.fill": "local-bar",
  "star.fill": "star",
  "mappin.fill": "location-on",
  "phone.fill": "phone",
  "envelope.fill": "email",
  "clock.fill": "access-time",
  "checkmark.circle.fill": "check-circle",
  "xmark.circle.fill": "cancel",
  "person.fill": "person",
  "building.2.fill": "business",
  "music.mic": "mic",
  "sparkles": "auto-awesome",
  "wand.and.stars": "auto-fix-high",
  "arrow.right": "arrow-forward",
  "arrow.left": "arrow-back",
  "plus": "add",
  "minus": "remove",
  "xmark": "close",
  "checkmark": "check",
  "bell.fill": "notifications",
  "gear": "settings",
  "square.and.arrow.up": "share",
  "doc.text.fill": "description",
  "crown.fill": "workspace-premium",
};

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
  weight = "regular",
}: {
  name: string;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<ViewStyle> | StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  if (SF_SYMBOLS.has(name)) {
    return (
      <SymbolView
        weight={weight}
        tintColor={color as string}
        resizeMode="scaleAspectFit"
        name={name as SymbolViewProps["name"]}
        style={[{ width: size, height: size }, style as StyleProp<ViewStyle>]}
      />
    );
  }
  const materialName = MATERIAL_FALLBACK[name] ?? "star";
  return (
    <MaterialIcons
      color={color}
      size={size}
      name={materialName}
      style={style as StyleProp<TextStyle>}
    />
  );
}
