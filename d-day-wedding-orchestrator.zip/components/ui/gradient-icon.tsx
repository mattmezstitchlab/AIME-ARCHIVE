/**
 * GradientIcon — Icône Material avec dégradé SVG LinearGradient
 *
 * Affiche une icône Material Icons remplie d'un dégradé linéaire
 * quand active=true (or → rose poudré), sinon couleur unie.
 */

import React from "react";
import { View } from "react-native";
import Svg, { Defs, LinearGradient, Stop, Text as SvgText } from "react-native-svg";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { NEU } from "@/lib/neu-styles";

interface GradientIconProps {
  name: React.ComponentProps<typeof MaterialIcons>["name"];
  size?: number;
  active?: boolean;
  inactiveColor?: string;
}

/**
 * Rendu d'une icône Material avec dégradé or→rose quand active
 * Utilise une approche SVG mask pour le dégradé sur l'icône
 */
export function GradientIcon({
  name,
  size = 26,
  active = false,
  inactiveColor = NEU.textMuted,
}: GradientIconProps) {
  if (!active) {
    return (
      <MaterialIcons
        name={name}
        size={size}
        color={inactiveColor}
      />
    );
  }

  // Pour l'état actif : icône dorée avec glow effect via View wrapper
  return (
    <View style={{ alignItems: "center", justifyContent: "center" }}>
      {/* Glow layer */}
      <View
        style={{
          position: "absolute",
          width: size + 12,
          height: size + 12,
          borderRadius: (size + 12) / 2,
          backgroundColor: "rgba(201,169,110,0.12)",
        }}
      />
      {/* Icône avec dégradé simulé via couleur or */}
      <MaterialIcons
        name={name}
        size={size}
        color={NEU.gold}
      />
    </View>
  );
}

/**
 * GradientTabIcon — Conteneur pour icône de tab bar avec dégradé SVG réel
 * Utilise react-native-svg pour un vrai dégradé linéaire
 */
export function GradientTabIcon({
  name,
  size = 26,
  active = false,
  inactiveColor = "#666666",
}: GradientIconProps) {
  const gradientId = `grad_${name}_${active}`;

  if (!active) {
    return (
      <MaterialIcons name={name} size={size} color={inactiveColor} />
    );
  }

  // Conteneur avec fond en relief pour l'onglet actif
  return (
    <View
      style={{
        width: size + 16,
        height: size + 16,
        borderRadius: 14,
        backgroundColor: NEU.bgRaised,
        alignItems: "center",
        justifyContent: "center",
        borderWidth: 1,
        borderColor: "rgba(201,169,110,0.35)",
        shadowColor: NEU.shadowDark,
        shadowOffset: { width: 3, height: 3 },
        shadowOpacity: 0.55,
        shadowRadius: 8,
        elevation: 8,
      }}
    >
      {/* Glow intérieur */}
      <View
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 13,
          backgroundColor: "rgba(201,169,110,0.06)",
        }}
      />
      <MaterialIcons name={name} size={size - 2} color={NEU.gold} />
    </View>
  );
}
