import { View, Text, StyleSheet, Pressable } from "react-native";
import { useAppContext } from "@/lib/app-context";
import { useRouter } from "expo-router";
import { formatTime } from "@/lib/wedding-store";
import { NEU } from "@/lib/neu-styles";

const ROLE_LABELS: Record<string, string> = {
  couple: "Mariés",
  vendor: "Prestataire",
  guest: "Invité(e)",
};

interface AppHeaderProps {
  title?: string;
  showBack?: boolean;
}

export function AppHeader({ title, showBack = false }: AppHeaderProps) {
  const { event, userRole } = useAppContext();
  const router = useRouter();

  return (
    <View style={styles.header}>
      {/* Left — monogramme ou retour */}
      <View style={styles.headerLeft}>
        {showBack ? (
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          >
            <Text style={styles.backArrow}>←</Text>
          </Pressable>
        ) : (
          <View style={styles.monogramOuter}>
            <View style={styles.monogramInner}>
              <Text style={styles.monogramText}>D·D</Text>
            </View>
          </View>
        )}
      </View>

      {/* Center */}
      <View style={styles.headerCenter}>
        {title ? (
          <Text style={styles.pageTitle}>{title}</Text>
        ) : (
          <>
            <Text style={styles.eventName} numberOfLines={1}>
              {event?.name ?? "D Day Wedding"}
            </Text>
            {event && (
              <Text style={styles.eventDate} numberOfLines={1}>
                {formatTime(event.date)}
              </Text>
            )}
          </>
        )}
      </View>

      {/* Right — badge rôle */}
      <View style={styles.headerRight}>
        {userRole && (
          <View style={styles.roleBadge}>
            <Text style={styles.roleBadgeText}>{ROLE_LABELS[userRole] ?? userRole}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: NEU.bgRaised,
    borderBottomWidth: 1.5,
    borderBottomColor: NEU.shadowLight,
    gap: 8,
    // Ombre Neumorphism vers le bas
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 6,
  },
  headerLeft: {
    width: 40,
    alignItems: "flex-start",
    justifyContent: "center",
  },
  // Monogramme Neumorphism
  monogramOuter: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: NEU.redBorder,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 4,
  },
  monogramInner: {
    alignItems: "center",
    justifyContent: "center",
  },
  monogramText: {
    fontSize: 9,
    fontWeight: "800",
    color: NEU.red,
    letterSpacing: 1,
  },
  backBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: NEU.bgSunken,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: NEU.borderSubtle,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  backArrow: {
    fontSize: 18,
    color: NEU.red,
  },
  headerCenter: {
    flex: 1,
    alignItems: "center",
  },
  eventName: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.textPrimary,
    letterSpacing: 0.2,
    textAlign: "center",
  },
  pageTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: NEU.red,
    letterSpacing: 0.5,
    textAlign: "center",
  },
  eventDate: {
    fontSize: 10,
    color: NEU.textSecondary,
    letterSpacing: 0.3,
    marginTop: 1,
    textAlign: "center",
  },
  headerRight: {
    width: 80,
    alignItems: "flex-end",
  },
  roleBadge: {
    backgroundColor: NEU.bgSunken,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: NEU.redBorder,
    shadowColor: NEU.shadowDark,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 3,
  },
  roleBadgeText: {
    fontSize: 9,
    color: NEU.red,
    fontWeight: "600",
    letterSpacing: 0.3,
  },
});
