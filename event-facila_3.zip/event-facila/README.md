# Facila × Pennylane — Site événementiel

Site événementiel complet avec deux faces :

- **`index.html`** — Page publique RSVP que reçoivent les 700 clients
- **`organisateur.html`** — Back-office Facila avec agent IA Cléo + recherche prestataires + carte Arras

## Déployer sur Netlify

1. Aller sur [app.netlify.com](https://app.netlify.com)
2. Glisser-déposer le dossier complet dans la zone "Deploy manually"
3. Le site est en ligne immédiatement
4. `index.html` est la page publique ; `/organisateur.html` est l'espace admin

## Liens internes

- Depuis l'admin : bouton "Voir la page publique" → ouvre `index.html`
- Depuis la page publique : pas de lien vers l'admin (normal)

## Fonctionnalités présentes

### Page publique (`index.html`)
- Hero avec dates et localisation
- 3 cards de session avec progression d'inscriptions en temps réel
- Programme minuté détaillé (timeline)
- Pourquoi venir (4 bénéfices)
- Intervenants (3 portraits)
- Formulaire RSVP fonctionnel (stockage localStorage en démo)
- FAQ (6 questions)
- Footer avec mentions légales claires

### Espace organisateur (`organisateur.html`)
- Sidebar de navigation
- 4 métriques clés (inscrits, prestataires, budget, date proche)
- Bloc agent IA "Cléo" avec recommandations contextuelles
- Checklist J-118 interactive (cliquer pour cocher)
- Budget par poste avec barre de progression colorée
- Carte interactive Leaflet avec 7 prestataires géolocalisés autour d'Arras
- Liste prestataires avec filtres par catégorie

## À faire pour passer en production

1. **Connecter un vrai backend** pour stocker les RSVP (Supabase, Firebase, ou API custom)
2. **Configurer un service d'envoi d'emails** (Resend, SendGrid) pour les confirmations
3. **Brancher l'agent IA Cléo** sur l'API Anthropic Claude
4. **Vérifier l'accord de Pennylane** pour l'utilisation de leur nom et logo
5. **Compléter les mentions légales** avec le vrai SIRET de Facila

## Notes juridiques importantes

- L'événement est présenté comme organisé par **Facila**, avec Pennylane comme **partenaire** — c'est le positionnement le plus sûr juridiquement
- Le footer précise explicitement que Pennylane n'est pas un service public
- L'usage du nom et logo Pennylane nécessite leur accord écrit avant mise en ligne

---

Créé avec EVENIO — plateforme d'organisation événementielle
