import React, { useMemo } from "react";

export default function CancellationMark({ city = "PARIS", date, size = 110 }) {
  const d = date ? new Date(date) : new Date();
  const day = String(d.getDate()).padStart(2, "0");
  const month = d.toLocaleString("fr-FR", { month: "short" }).toUpperCase().replace(".", "");
  const year = d.getFullYear();

  const wavyPath = useMemo(() => {
    let p = `M ${size * 0.55} ${size / 2} `;
    for (let i = 0; i < 4; i++) {
      p += `q ${size * 0.06} -${size * 0.05} ${size * 0.12} 0 `;
      p += `q ${size * 0.06} ${size * 0.05} ${size * 0.12} 0 `;
    }
    return p;
  }, [size]);

  return (
    <svg
      width={size}
      height={size * 0.65}
      viewBox={`0 0 ${size * 1.6} ${size}`}
      style={{ filter: "url(#cancel-wear)" }}
    >
      <defs>
        <filter id="cancel-wear">
          <feTurbulence baseFrequency="0.9" numOctaves="2" seed="3" />
          <feDisplacementMap in="SourceGraphic" scale="1.5" />
        </filter>
      </defs>
      <g
        stroke="#1a1a1a"
        strokeWidth="2"
        fill="none"
        opacity="0.78"
      >
        {/* Outer circle */}
        <circle cx={size / 2} cy={size / 2} r={size / 2 - 4} />
        {/* Inner circle */}
        <circle cx={size / 2} cy={size / 2} r={size / 2 - 12} />
      </g>
      <text
        x={size / 2}
        y={size * 0.3}
        textAnchor="middle"
        fontSize={size * 0.13}
        fontFamily="Georgia, serif"
        fontWeight="bold"
        fill="#1a1a1a"
        opacity="0.78"
      >
        {city.toUpperCase()}
      </text>
      <text
        x={size / 2}
        y={size * 0.55}
        textAnchor="middle"
        fontSize={size * 0.14}
        fontFamily="Georgia, serif"
        fontWeight="bold"
        fill="#1a1a1a"
        opacity="0.78"
      >
        {day} {month}
      </text>
      <text
        x={size / 2}
        y={size * 0.78}
        textAnchor="middle"
        fontSize={size * 0.12}
        fontFamily="Georgia, serif"
        fill="#1a1a1a"
        opacity="0.78"
      >
        {year}
      </text>
      {/* Wavy lines extending right */}
      <path
        d={wavyPath}
        stroke="#1a1a1a"
        strokeWidth="2.5"
        fill="none"
        opacity="0.78"
        transform={`translate(${size * 0.45}, -${size * 0.12})`}
      />
      <path
        d={wavyPath}
        stroke="#1a1a1a"
        strokeWidth="2.5"
        fill="none"
        opacity="0.78"
        transform={`translate(${size * 0.45}, 0)`}
      />
      <path
        d={wavyPath}
        stroke="#1a1a1a"
        strokeWidth="2.5"
        fill="none"
        opacity="0.78"
        transform={`translate(${size * 0.45}, ${size * 0.12})`}
      />
    </svg>
  );
}