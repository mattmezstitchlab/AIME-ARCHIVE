import React from "react";
import { FileText, Receipt, FileSignature, CreditCard, ScrollText, FileQuestion, Ban } from "lucide-react";

export const DOC_TYPES = [
  { id: "aucun", label: "Aucun", Icon: Ban, color: "text-white/40" },
  { id: "devis", label: "Devis", Icon: FileQuestion, color: "text-cyan-300" },
  { id: "facture", label: "Facture", Icon: Receipt, color: "text-amber-300" },
  { id: "attestation", label: "Attestation", Icon: FileSignature, color: "text-emerald-300" },
  { id: "paiement", label: "Paiement", Icon: CreditCard, color: "text-pink-300" },
  { id: "contrat", label: "Contrat", Icon: ScrollText, color: "text-indigo-300" },
  { id: "autre", label: "Autre", Icon: FileText, color: "text-white/60" },
];

export default function DocTypePicker({ value, onChange }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.15em] text-white/40 mb-2 px-1">
        Document certifié
      </p>
      <div className="w-full flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl border border-white/10 bg-white/[0.02]">
        {DOC_TYPES.map(({ id, label, Icon, color }) => (
          <button
            key={id}
            onClick={() => onChange(id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs transition-all ${
              value === id ? "bg-white text-black" : `${color} hover:bg-white/5`
            }`}
          >
            <Icon className="w-3 h-3" />
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}