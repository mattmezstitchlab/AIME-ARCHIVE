import React, { useState } from "react";
import { Mail, Loader2, X, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function EmailSendButton({ stamp }) {
  const [open, setOpen] = useState(false);
  const [to, setTo] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const verifyUrl = stamp?.code
    ? `${window.location.origin}/verify/${stamp.code}`
    : null;

  const handleSend = async () => {
    if (!to || sending) return;
    setSending(true);
    try {
      const body = `
        <div style="font-family: Georgia, serif; max-width: 560px; margin: auto; padding: 32px; background: #fafaf7; border: 1px solid #e6e2d8;">
          <h2 style="text-align:center; color:#3a3a3a; letter-spacing:2px; margin-bottom:8px;">AIME STAMP</h2>
          <p style="text-align:center; color:#888; font-size:12px; letter-spacing:3px; text-transform:uppercase;">Vous avez reçu un timbre</p>
          <div style="text-align:center; margin: 24px 0;">
            <img src="${stamp.image_url}" style="max-width:240px; height:auto;" alt="stamp" />
          </div>
          <p style="text-align:center; font-family:monospace; letter-spacing:2px; color:#444;">${stamp.code || ""}</p>
          <p style="color:#444; line-height:1.6; white-space:pre-wrap;">${message || ""}</p>
          ${verifyUrl ? `<p style="text-align:center; margin-top:24px;"><a href="${verifyUrl}" style="color:#7a5a1a;">Vérifier l'authenticité →</a></p>` : ""}
        </div>
      `;
      await base44.integrations.Core.SendEmail({
        to,
        subject: `Un timbre AIME pour vous — ${stamp.code || ""}`,
        body,
        from_name: "AIME Stamp",
      });
      setSent(true);
      setTimeout(() => {
        setOpen(false);
        setSent(false);
        setTo("");
        setMessage("");
      }, 1600);
    } catch (e) {
      console.error(e);
    }
    setSending(false);
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white/80 hover:bg-white/10 hover:text-white transition-all"
      >
        <Mail className="w-4 h-4" />
        Affranchir & envoyer
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={() => !sending && setOpen(false)}>
          <div
            className="relative w-full max-w-md rounded-2xl border border-white/10 bg-zinc-950 p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOpen(false)}
              className="absolute top-3 right-3 text-white/40 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-sm uppercase tracking-[0.2em] text-white/70 mb-1">
              Affranchir & envoyer
            </h3>
            <p className="text-xs text-white/40 mb-5">
              Envoyez ce timbre par email avec un message personnalisé.
            </p>

            {sent ? (
              <div className="py-8 text-center">
                <div className="text-emerald-300 text-sm">✓ Envoyé</div>
              </div>
            ) : (
              <div className="space-y-3">
                <input
                  type="email"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  placeholder="destinataire@email.com"
                  className="w-full bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/40"
                />
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  placeholder="Votre message…"
                  className="w-full bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/40 resize-none"
                />
                <button
                  onClick={handleSend}
                  disabled={!to || sending}
                  className="w-full py-2.5 rounded-lg bg-white text-black text-sm font-medium hover:bg-white/90 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {sending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Envoi…
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      Envoyer
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}