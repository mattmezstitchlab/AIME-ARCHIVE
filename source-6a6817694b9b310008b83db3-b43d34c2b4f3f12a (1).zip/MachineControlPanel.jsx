import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Loader2,
  Type,
  Tag,
  FileText,
  User,
  ListTodo,
  Lock,
  Palette,
} from "lucide-react";
import { CATEGORIES } from "./CategoryPicker";
import { DOC_TYPES } from "./DocTypePicker";
import MicButton from "./MicButton";
import DocScanButton from "./DocScanButton";
import MultiPersonUploader from "./MultiPersonUploader";
import CategoryTreePicker from "./CategoryTreePicker";
import SearchField from "./SearchField";
import { base44 } from "@/api/base44Client";

const COLORS = [
  { id: "red", label: "Rouge", hex: "#B22222" },
  { id: "crimson", label: "Cramoisi", hex: "#7B1E2E" },
  { id: "orange", label: "Orange", hex: "#E07A1F" },
  { id: "amber", label: "Ambre", hex: "#D97706" },
  { id: "yellow", label: "Jaune", hex: "#EAB308" },
  { id: "gold", label: "Or", hex: "#C9A227" },
  { id: "olive", label: "Olive", hex: "#6B7B2A" },
  { id: "green", label: "Vert", hex: "#1F7A3A" },
  { id: "emerald", label: "Émeraude", hex: "#047857" },
  { id: "teal", label: "Sarcelle", hex: "#0E7490" },
  { id: "cyan", label: "Cyan", hex: "#0891B2" },
  { id: "sky", label: "Ciel", hex: "#0369A1" },
  { id: "blue", label: "Bleu", hex: "#1E3A8A" },
  { id: "indigo", label: "Indigo", hex: "#3730A3" },
  { id: "violet", label: "Violet", hex: "#6D28D9" },
  { id: "purple", label: "Pourpre", hex: "#7E22CE" },
  { id: "magenta", label: "Magenta", hex: "#A21CAF" },
  { id: "pink", label: "Rose", hex: "#DB2777" },
  { id: "rose", label: "Rose vif", hex: "#E11D48" },
  { id: "brown", label: "Sépia", hex: "#78350F" },
  { id: "black", label: "Noir", hex: "#1a1a1a" },
  { id: "silver", label: "Argent", hex: "#9CA3AF" },
];

const WEAR_LABELS = ["Neuf", "Léger", "Usé", "Vieilli", "Très vieilli"];

const SCREENS = [
  { id: "text", label: "Texte", Icon: Type },
  { id: "category", label: "Catégorie", Icon: Tag },
  { id: "doc", label: "Document", Icon: FileText },
  { id: "person", label: "Personne", Icon: User },
  { id: "task", label: "Tâche", Icon: ListTodo },
  { id: "capsule", label: "Capsule", Icon: Lock },
  { id: "style", label: "Style", Icon: Palette },
];

export default function MachineControlPanel({
  loading,
  // text
  text, setText,
  // category
  category, setCategory,
  subcategory, setSubcategory,
  domain, setDomain,
  // genius
  onGeniusApply,
  // doc
  docType, setDocType,
  docAmount, setDocAmount,
  docReference, setDocReference,
  eventName, setEventName,
  // person
  personName, setPersonName,
  personPhotoUrl, setPersonPhotoUrl,
  onPickPhoto,
  extraPhotos, setExtraPhotos,
  // ai scan
  onScanExtracted,
  // task
  taskNotes, setTaskNotes,
  taskDueDate, setTaskDueDate,
  // capsule
  capsuleEnabled, setCapsuleEnabled,
  capsuleDate, setCapsuleDate,
  capsuleMessage, setCapsuleMessage,
  // style
  color, setColor,
  wear, setWear,
  // generate
  onGenerate,
}) {
  const [screenIdx, setScreenIdx] = useState(0);
  const [search, setSearch] = useState("");
  const [searching, setSearching] = useState(false);
  const screen = SCREENS[screenIdx];

  const next = () => setScreenIdx((i) => (i + 1) % SCREENS.length);
  const prev = () => setScreenIdx((i) => (i - 1 + SCREENS.length) % SCREENS.length);

  // Smart search: jump to the matching screen, and if the query looks like
  // a full description, ask the LLM to fill the form (Génius mode).
  const handleSearchSubmit = async () => {
    if (!search.trim()) return;
    const q = search.toLowerCase();
    const screenMatch = SCREENS.findIndex(
      (s) => s.label.toLowerCase().includes(q) || s.id.includes(q)
    );
    if (screenMatch >= 0) {
      setScreenIdx(screenMatch);
      setSearch("");
      return;
    }
    // Otherwise → Génius natural-language fill
    if (!onGeniusApply) return;
    setSearching(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Transforme cette phrase en champs structurés pour un timbre numérique de gestion d'événements/mariages. Phrase : "${search}"`,
        response_json_schema: {
          type: "object",
          properties: {
            category: { type: "string", enum: ["mariage", "prestataire", "evenement", "tache", "personnel", "autre"] },
            subcategory: { type: "string" },
            domain: { type: "string" },
            text: { type: "string" },
            doc_type: { type: "string", enum: ["aucun", "devis", "facture", "attestation", "paiement", "contrat", "autre"] },
            doc_amount: { type: "number" },
            event_name: { type: "string" },
            person_name: { type: "string" },
            task_notes: { type: "string" },
            task_due_date: { type: "string" },
            color: { type: "string" },
          },
        },
      });
      onGeniusApply(res);
      setSearch("");
    } catch (err) {
      console.error(err);
    }
    setSearching(false);
  };

  return (
    <div className="w-full min-w-0">
      {/* Champ de recherche intelligent (saut d'écran ou Génius IA) */}
      <div className="mb-2">
        <SearchField
          value={search}
          onChange={setSearch}
          onSubmit={handleSearchSubmit}
          placeholder={searching ? "Génius analyse…" : "Rechercher un menu ou décrire un timbre…"}
          variant="led"
        />
      </div>

      {/* Bandeau d'onglets en haut de l'écran */}
      <div className="flex items-center justify-between gap-1 mb-2 min-w-0">
        <button
          onClick={prev}
          className="w-8 h-8 rounded-md bg-emerald-950/60 border border-emerald-400/30 text-emerald-300 hover:bg-emerald-900/60 hover:text-emerald-200 transition-all flex items-center justify-center"
          aria-label="Précédent"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="flex-1 min-w-0 flex items-center justify-center gap-0.5 overflow-hidden">
          {SCREENS.map((s, i) => {
            const Icon = s.Icon;
            const active = i === screenIdx;
            return (
              <button
                key={s.id}
                onClick={() => setScreenIdx(i)}
                className={`flex-shrink-0 flex items-center justify-center p-1.5 rounded transition-all ${
                  active
                    ? "bg-emerald-400/20 text-emerald-200 border border-emerald-400/40"
                    : "text-emerald-400/40 hover:text-emerald-300/80 border border-transparent"
                }`}
                title={s.label}
              >
                <Icon className="w-3 h-3" />
              </button>
            );
          })}
        </div>

        <button
          onClick={next}
          className="w-8 h-8 rounded-md bg-emerald-950/60 border border-emerald-400/30 text-emerald-300 hover:bg-emerald-900/60 hover:text-emerald-200 transition-all flex items-center justify-center"
          aria-label="Suivant"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Écran courant */}
      <div className="relative min-h-[180px] rounded-lg bg-emerald-950/40 border border-emerald-400/20 p-3 shadow-inner overflow-hidden">
        {/* Scanline effect */}
        <div
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, rgba(110,231,183,0.15) 0px, transparent 1px, transparent 3px)",
          }}
        />

        <div className="relative">
          <div className="flex items-center gap-1.5 mb-2">
            <screen.Icon className="w-3 h-3 text-emerald-300" />
            <span className="font-mono text-[10px] tracking-[0.2em] text-emerald-300/80 uppercase">
              {screen.label}
            </span>
            <span className="ml-auto font-mono text-[9px] text-emerald-400/50">
              {String(screenIdx + 1).padStart(2, "0")}/{String(SCREENS.length).padStart(2, "0")}
            </span>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={screen.id}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              {screen.id === "text" && (
                <ScreenText text={text} setText={setText} />
              )}
              {screen.id === "category" && (
                <CategoryTreePicker
                  category={category} setCategory={setCategory}
                  subcategory={subcategory} setSubcategory={setSubcategory}
                  domain={domain} setDomain={setDomain}
                />
              )}
              {screen.id === "doc" && (
                <ScreenDoc
                  docType={docType} setDocType={setDocType}
                  docAmount={docAmount} setDocAmount={setDocAmount}
                  docReference={docReference} setDocReference={setDocReference}
                  eventName={eventName} setEventName={setEventName}
                  onScanExtracted={onScanExtracted}
                />
              )}
              {screen.id === "person" && (
                <ScreenPerson
                  personName={personName} setPersonName={setPersonName}
                  personPhotoUrl={personPhotoUrl} setPersonPhotoUrl={setPersonPhotoUrl}
                  onPickPhoto={onPickPhoto}
                  extraPhotos={extraPhotos} setExtraPhotos={setExtraPhotos}
                />
              )}
              {screen.id === "task" && (
                <ScreenTask
                  taskNotes={taskNotes} setTaskNotes={setTaskNotes}
                  taskDueDate={taskDueDate} setTaskDueDate={setTaskDueDate}
                />
              )}
              {screen.id === "capsule" && (
                <ScreenCapsule
                  enabled={capsuleEnabled} setEnabled={setCapsuleEnabled}
                  date={capsuleDate} setDate={setCapsuleDate}
                  message={capsuleMessage} setMessage={setCapsuleMessage}
                />
              )}
              {screen.id === "style" && (
                <ScreenStyle
                  color={color} setColor={setColor}
                  wear={wear} setWear={setWear}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Bouton ENTER / Imprimer */}
      <button
        onClick={onGenerate}
        disabled={loading}
        className="mt-3 w-full py-3 rounded-lg bg-gradient-to-b from-emerald-400 to-emerald-600 text-emerald-950 text-xs font-bold tracking-[0.25em] uppercase disabled:opacity-50 disabled:cursor-not-allowed hover:from-emerald-300 hover:to-emerald-500 transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.4)] border border-emerald-300/50"
      >
        {loading ? (
          <>
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            Impression…
          </>
        ) : (
          <>
            <Sparkles className="w-3.5 h-3.5" />
            Imprimer
          </>
        )}
      </button>
    </div>
  );
}

/* ============== Sub-screens ============== */

const ledInput =
  "w-full bg-black/60 border border-emerald-400/30 rounded px-2.5 py-1.5 text-[12px] text-emerald-100 placeholder:text-emerald-500/40 focus:outline-none focus:border-emerald-300/70 font-mono";

const ScreenText = ({ text, setText }) => (
  <div className="space-y-2">
    <div className="flex items-center gap-1.5">
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="PARIS 1925…"
        className={ledInput}
      />
      <MicButton onText={(t) => setText(t.toUpperCase())} title="Dicter le texte" />
    </div>
    <div className="flex flex-wrap gap-1">
      {["RÉPUBLIQUE FRANÇAISE", "POSTES 50c", "AIR MAIL"].map((ex) => (
        <button
          key={ex}
          onClick={() => setText(ex)}
          className="text-[9px] text-emerald-400/60 hover:text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-400/20 hover:border-emerald-400/50 transition-all"
        >
          {ex}
        </button>
      ))}
    </div>
  </div>
);

const ScreenCategory = ({ value, onChange }) => (
  <div className="grid grid-cols-3 gap-1.5">
    {CATEGORIES.map(({ id, label, Icon }) => (
      <button
        key={id}
        onClick={() => onChange(id)}
        className={`flex flex-col items-center gap-1 px-2 py-2 rounded text-[10px] transition-all ${
          value === id
            ? "bg-emerald-400/20 border border-emerald-400/60 text-emerald-200"
            : "bg-black/40 border border-emerald-400/15 text-emerald-400/60 hover:text-emerald-300 hover:border-emerald-400/40"
        }`}
      >
        <Icon className="w-3.5 h-3.5" />
        {label}
      </button>
    ))}
  </div>
);

const ScreenDoc = ({ docType, setDocType, docAmount, setDocAmount, docReference, setDocReference, eventName, setEventName, onScanExtracted }) => (
  <div className="space-y-2">
    <DocScanButton onExtracted={onScanExtracted} />
    <div className="grid grid-cols-4 gap-1">
      {DOC_TYPES.map(({ id, label, Icon }) => (
        <button
          key={id}
          onClick={() => setDocType(id)}
          className={`flex flex-col items-center gap-0.5 px-1 py-1.5 rounded text-[9px] transition-all ${
            docType === id
              ? "bg-emerald-400/20 border border-emerald-400/60 text-emerald-200"
              : "bg-black/40 border border-emerald-400/15 text-emerald-400/60 hover:text-emerald-300"
          }`}
        >
          <Icon className="w-3 h-3" />
          {label}
        </button>
      ))}
    </div>
    {docType !== "aucun" && (
      <div className="grid grid-cols-3 gap-1.5">
        <input
          value={docAmount}
          onChange={(e) => setDocAmount(e.target.value)}
          type="number"
          placeholder="€"
          className={ledInput}
        />
        <input
          value={docReference}
          onChange={(e) => setDocReference(e.target.value)}
          placeholder="N° ref"
          className={ledInput}
        />
        <input
          value={eventName}
          onChange={(e) => setEventName(e.target.value)}
          placeholder="Événement"
          className={ledInput}
        />
      </div>
    )}
  </div>
);

const ScreenPerson = ({ personName, setPersonName, personPhotoUrl, setPersonPhotoUrl, onPickPhoto, extraPhotos, setExtraPhotos }) => (
  <div className="space-y-2">
    <div className="flex items-center gap-1.5">
      <input
        value={personName}
        onChange={(e) => setPersonName(e.target.value)}
        placeholder="Nom de la personne"
        className={ledInput}
      />
      <MicButton onText={setPersonName} title="Dicter le nom" />
    </div>
    <div className="flex items-center gap-2">
      {personPhotoUrl ? (
        <div className="flex items-center gap-2 flex-1">
          <img src={personPhotoUrl} alt="" className="w-10 h-10 rounded object-cover border border-emerald-400/40" />
          <button
            onClick={() => setPersonPhotoUrl("")}
            className="text-[10px] text-emerald-400/70 hover:text-red-300"
          >
            Retirer
          </button>
        </div>
      ) : (
        <button
          onClick={onPickPhoto}
          className="flex-1 py-2 rounded border border-dashed border-emerald-400/30 text-[10px] text-emerald-400/70 hover:border-emerald-400/60 hover:text-emerald-300 transition-all"
        >
          + Photo principale
        </button>
      )}
    </div>
    <div className="pt-1 border-t border-emerald-400/10">
      <p className="text-[9px] text-emerald-400/60 uppercase tracking-wider mb-1.5">
        Mode groupe (optionnel)
      </p>
      <MultiPersonUploader photos={extraPhotos || []} onChange={setExtraPhotos} />
    </div>
  </div>
);

const ScreenTask = ({ taskNotes, setTaskNotes, taskDueDate, setTaskDueDate }) => (
  <div className="space-y-2">
    <div className="flex items-start gap-1.5">
      <textarea
        value={taskNotes}
        onChange={(e) => setTaskNotes(e.target.value)}
        placeholder="Notes (prestataire, tâche…)"
        rows={3}
        className={`${ledInput} resize-none`}
      />
      <MicButton onText={setTaskNotes} title="Dicter les notes" />
    </div>
    <input
      type="date"
      value={taskDueDate}
      onChange={(e) => setTaskDueDate(e.target.value)}
      className={ledInput}
      style={{ colorScheme: "dark" }}
    />
  </div>
);

const ScreenCapsule = ({ enabled, setEnabled, date, setDate, message, setMessage }) => (
  <div className="space-y-2">
    <button
      onClick={() => setEnabled(!enabled)}
      className={`w-full py-1.5 rounded text-[10px] uppercase tracking-wider border transition-all ${
        enabled
          ? "bg-emerald-400/20 border-emerald-400/60 text-emerald-200"
          : "bg-black/40 border-emerald-400/20 text-emerald-400/60"
      }`}
    >
      {enabled ? "● Capsule activée" : "○ Capsule désactivée"}
    </button>
    {enabled && (
      <>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className={ledInput}
          style={{ colorScheme: "dark" }}
        />
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Message secret…"
          rows={2}
          className={`${ledInput} resize-none`}
        />
      </>
    )}
  </div>
);

const ScreenStyle = ({ color, setColor, wear, setWear }) => (
  <div className="space-y-3">
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <p className="text-[9px] text-emerald-400/60 uppercase tracking-wider">Couleur d'encre</p>
        <p className="text-[10px] text-emerald-300 font-mono capitalize">
          {COLORS.find((c) => c.id === color)?.label || color}
        </p>
      </div>
      <div className="grid grid-cols-8 gap-1">
        {COLORS.map((c) => {
          const active = color === c.id;
          const lightLabel = ["yellow", "gold", "silver", "amber"].includes(c.id);
          return (
            <button
              key={c.id}
              onClick={() => setColor(c.id)}
              title={c.label}
              className={`relative aspect-square rounded-md border transition-all ${
                active
                  ? "border-emerald-300 ring-2 ring-emerald-300/60 scale-110 shadow-[0_0_12px_rgba(16,185,129,0.5)]"
                  : "border-white/10 hover:border-white/40 hover:scale-105"
              }`}
              style={{ backgroundColor: c.hex }}
            >
              {active && (
                <span
                  className="absolute inset-0 flex items-center justify-center text-[10px] font-bold"
                  style={{ color: lightLabel ? "#000" : "#fff" }}
                >
                  ✓
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <p className="text-[9px] text-emerald-400/60 uppercase tracking-wider">Usure</p>
        <p className="text-[10px] text-emerald-300 font-mono">{WEAR_LABELS[wear]}</p>
      </div>
      <input
        type="range"
        min={0}
        max={4}
        value={wear}
        onChange={(e) => setWear(Number(e.target.value))}
        className="w-full h-1 appearance-none bg-emerald-950 rounded-full cursor-pointer
          [&::-webkit-slider-thumb]:appearance-none
          [&::-webkit-slider-thumb]:w-3
          [&::-webkit-slider-thumb]:h-3
          [&::-webkit-slider-thumb]:rounded-full
          [&::-webkit-slider-thumb]:bg-emerald-400
          [&::-webkit-slider-thumb]:shadow-[0_0_8px_rgba(16,185,129,0.8)]"
      />
    </div>
  </div>
);