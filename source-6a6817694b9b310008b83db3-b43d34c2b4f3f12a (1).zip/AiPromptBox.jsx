import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Wand2, Loader2 } from "lucide-react";

export default function AiPromptBox({ onApply }) {
  const [desc, setDesc] = useState("");
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!desc.trim() || loading) return;
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es un expert en philatélie. À partir de cette description: "${desc}", invente un timbre-poste cohérent. Réponds UNIQUEMENT en JSON avec : text (texte court à imprimer sur le timbre, max 40 caractères, en MAJUSCULES, incluant pays + thème + valeur), color (red/black/blue/gold), wear (0=neuf, 1=léger, 2=usé, 3=vieilli, 4=très vieilli), description_ai (description visuelle riche en anglais pour guider l'illustration centrale du timbre, max 200 caractères).`,
        response_json_schema: {
          type: "object",
          properties: {
            text: { type: "string" },
            color: { type: "string", enum: ["red", "black", "blue", "gold"] },
            wear: { type: "number" },
            description_ai: { type: "string" },
          },
          required: ["text", "color", "wear", "description_ai"],
        },
      });
      onApply(res);
      setDesc("");
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  return (
    <div className="w-full mt-4 bg-gradient-to-b from-purple-500/[0.08] to-purple-500/[0.02] border border-purple-400/15 rounded-2xl p-2">
      <div className="flex items-center gap-2">
        <Wand2 className="w-4 h-4 text-purple-300/80 ml-2" />
        <input
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAsk()}
          placeholder="Décris ton timbre… ex: « commémoratif de la lune 1969 »"
          className="flex-1 bg-transparent px-2 py-2.5 text-[14px] placeholder:text-white/30 focus:outline-none"
        />
        <button
          onClick={handleAsk}
          disabled={loading || !desc.trim()}
          className="px-4 py-2 rounded-xl bg-purple-400/20 border border-purple-300/30 text-purple-100 text-xs font-medium disabled:opacity-30 hover:bg-purple-400/30 transition-all"
        >
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Imaginer"}
        </button>
      </div>
    </div>
  );
}