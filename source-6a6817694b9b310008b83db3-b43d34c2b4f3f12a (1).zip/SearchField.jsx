import React from "react";
import { Search, X } from "lucide-react";

/**
 * Reusable search input — used inside the machine LED panel and the wallet.
 * Variant 'led' = green CRT look, 'wallet' = white-on-black neutral.
 */
export default function SearchField({
  value,
  onChange,
  onSubmit,
  placeholder = "Rechercher…",
  variant = "led",
  className = "",
}) {
  const isLed = variant === "led";
  const wrap = isLed
    ? "flex items-center gap-1.5 bg-black/60 border border-emerald-400/30 rounded px-2 py-1.5 focus-within:border-emerald-300/70"
    : "flex items-center gap-2 bg-white/[0.03] border border-white/10 rounded-full px-3 py-1.5 focus-within:border-white/40";
  const icon = isLed ? "text-emerald-400/70" : "text-white/40";
  const input = isLed
    ? "flex-1 bg-transparent outline-none text-[12px] text-emerald-100 placeholder:text-emerald-500/40 font-mono"
    : "flex-1 bg-transparent outline-none text-xs text-white placeholder:text-white/30";

  return (
    <div className={`${wrap} ${className}`}>
      <Search className={`w-3.5 h-3.5 ${icon}`} />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" && typeof onSubmit === "function") onSubmit(); }}
        placeholder={placeholder}
        className={input}
      />
      {value && (
        <button
          onClick={() => onChange("")}
          className={`${icon} hover:opacity-100 opacity-60`}
          aria-label="Effacer"
        >
          <X className="w-3 h-3" />
        </button>
      )}
    </div>
  );
}