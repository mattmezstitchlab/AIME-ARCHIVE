// ─── AIME / Cerise Pipeline Engine ───────────────────────────────────────────
// Types, helpers, automation triggers for the quote → contract → payment flow.

import * as kv from "./kv_store.mjs";

// ── ID helper ─────────────────────────────────────────────────────────────────
export const puid = () =>
  globalThis.crypto?.randomUUID?.() ??
  `${Date.now()}-${Math.random().toString(36).slice(2)}`;

// ── Types ─────────────────────────────────────────────────────────────────────

export type PipelineStage =
  | "quoted"       // Devis envoyé (état initial)
  | "accepted"     // Devis accepté par le client
  | "contract"     // Contrat généré + envoyé
  | "signed"       // Signé des 2 côtés → paiement déclenché
  | "payment"      // Lien Stripe envoyé / en attente
  | "confirmed"    // Acompte reçu ✓
  | "cancelled";

export type PipelineDossier = {
  id: string;
  stage: PipelineStage;
  quoteId: string;
  contractId?: string;
  paymentId?: string;
  clientName: string;
  clientEmail: string;
  clientToken: string;   // token opaque pour le portail client
  createdBy: "admin" | "cerise";
  createdAt: string;
  updatedAt: string;
};

export type PipelineQuote = {
  id: string;
  dossierId: string;
  version: number;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  eventDate: string;
  eventVenue: string;
  service: string;
  duration: number;
  amount: number;
  deposit: number;
  depositPercent: number;
  notes?: string;
  status: "sent" | "accepted" | "refused" | "expired";
  acceptedAt?: string;
  refusedAt?: string;
  createdAt: string;
  updatedAt: string;
};

export type ContractSignature = {
  signedAt: string;
  ip?: string;
  name: string;  // typed name for OTP-less e-sign
};

export type PipelineContract = {
  id: string;
  dossierId: string;
  quoteId: string;
  version: string;
  client: { name: string; email: string; phone?: string };
  prestataire: { name: string; email: string };
  service: string;
  eventDate: string;
  eventVenue: string;
  duration: number;
  amount: number;
  deposit: number;
  depositPercent: number;
  conditions: string[];
  status: "sent" | "client_signed" | "fully_signed";
  signatures: {
    client?: ContractSignature;
    vendor?: ContractSignature;
  };
  sentAt: string;
  createdAt: string;
  updatedAt: string;
};

export type PipelinePayment = {
  id: string;
  dossierId: string;
  contractId: string;
  amountEur: number;
  currency: "eur";
  status: "pending" | "checkout_created" | "paid" | "failed";
  stripeCheckoutSessionId?: string;
  stripePaymentIntentId?: string;
  checkoutUrl?: string;
  paidAt?: string;
  createdAt: string;
  updatedAt: string;
};

export type LogActor = "cerise" | "admin" | "client" | "stripe" | "system";

export type PipelineLog = {
  id: string;
  dossierId: string;
  actor: LogActor;
  action: string;
  detail?: string;
  auto: boolean;   // true = déclenché automatiquement
  timestamp: string;
};

// ── KV helpers ────────────────────────────────────────────────────────────────

export const getDossier  = (id: string) => kv.get(`pl:dossier:${id}`)  as Promise<PipelineDossier | null>;
export const getQuote    = (id: string) => kv.get(`pl:quote:${id}`)    as Promise<PipelineQuote | null>;
export const getContract = (id: string) => kv.get(`pl:contract:${id}`) as Promise<PipelineContract | null>;
export const getPayment  = (id: string) => kv.get(`pl:payment:${id}`)  as Promise<PipelinePayment | null>;

export const getAllDossiers = async (): Promise<PipelineDossier[]> => {
  const list = (await kv.getByPrefix("pl:dossier:")) as PipelineDossier[];
  return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
};

export const getDossierByToken = async (token: string): Promise<PipelineDossier | null> => {
  const ref = await kv.get(`pl:token:${token}`) as { dossierId: string } | null;
  if (!ref) return null;
  return getDossier(ref.dossierId);
};

// ── Log helpers ───────────────────────────────────────────────────────────────

export async function logAction(
  dossierId: string,
  actor: LogActor,
  action: string,
  detail?: string,
  auto = false,
): Promise<void> {
  const ts  = new Date().toISOString();
  const id  = puid();
  const log: PipelineLog = { id, dossierId, actor, action, detail, auto, timestamp: ts };
  await kv.set(`pl:log:${dossierId}:${ts}:${id}`, log);
}

export async function getLogs(dossierId: string): Promise<PipelineLog[]> {
  const logs = (await kv.getByPrefix(`pl:log:${dossierId}:`)) as PipelineLog[];
  return logs.sort((a, b) => a.timestamp.localeCompare(b.timestamp));
}

// ── Contract template ─────────────────────────────────────────────────────────

export function buildContractTemplate(
  quote: PipelineQuote,
): Omit<PipelineContract, "id" | "dossierId" | "createdAt" | "updatedAt"> {
  const depositPct = Math.round((quote.deposit / quote.amount) * 100);
  const balance    = quote.amount - quote.deposit;
  const dateStr    = quote.eventDate
    ? new Date(quote.eventDate).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })
    : "date à définir";

  const conditions = [
    `L'artiste s'engage à se présenter au lieu mentionné (${quote.eventVenue || "lieu à préciser"}) à l'heure convenue pour une prestation de ${quote.duration} heure${quote.duration > 1 ? "s" : ""}.`,
    `Un acompte de ${depositPct} % du montant total, soit ${quote.deposit.toLocaleString("fr-FR")} €, est requis pour confirmer la réservation. Il doit être réglé dans les 7 jours suivant la signature du présent contrat.`,
    `Le solde de ${balance.toLocaleString("fr-FR")} € est dû le jour de la prestation, avant le début de celle-ci, par virement bancaire ou chèque.`,
    `En cas d'annulation par le client moins de 30 jours avant la date de l'événement (${dateStr}), l'acompte reste définitivement acquis au prestataire à titre d'indemnité forfaitaire.`,
    `En cas d'annulation par le client plus de 30 jours avant la prestation, l'acompte est remboursé intégralement sous 15 jours ouvrés.`,
    `En cas d'empêchement majeur du prestataire (maladie, force majeure dûment justifiée), le prestataire s'engage à rembourser intégralement les sommes versées et, dans la mesure du possible, à proposer une date alternative.`,
    `Le prestataire se réserve le droit d'enregistrer des extraits audio/vidéo à des fins exclusivement promotionnelles. Le client peut s'y opposer par écrit avant la date de l'événement.`,
    `Toute modification de durée, de lieu ou de programme devra faire l'objet d'un avenant écrit signé par les deux parties.`,
    `Le présent contrat est soumis au droit français. En cas de litige, les parties s'engagent à rechercher une solution amiable avant toute action judiciaire.`,
  ];

  const now = new Date().toISOString();
  return {
    quoteId:        quote.id,
    version:        "1.0",
    client:         { name: quote.clientName, email: quote.clientEmail, phone: quote.clientPhone },
    prestataire:    { name: "Matt Mez Sax", email: "matt@aime.fr" },
    service:        quote.service,
    eventDate:      quote.eventDate,
    eventVenue:     quote.eventVenue,
    duration:       quote.duration,
    amount:         quote.amount,
    deposit:        quote.deposit,
    depositPercent: depositPct,
    conditions,
    status:         "sent",
    signatures:     {},
    sentAt:         now,
  };
}

// ── Automation: Quote → Contract ──────────────────────────────────────────────

export async function autoGenerateContract(
  dossierId: string,
  quote: PipelineQuote,
): Promise<PipelineContract> {
  const now      = new Date().toISOString();
  const id       = puid();
  const template = buildContractTemplate(quote);
  const contract: PipelineContract = { id, dossierId, ...template, createdAt: now, updatedAt: now };

  const dossier = await getDossier(dossierId);

  await Promise.all([
    kv.set(`pl:contract:${id}`, contract),
    kv.set(`pl:quote:${quote.id}`,     { ...quote,   status: "accepted", acceptedAt: now, updatedAt: now }),
    kv.set(`pl:dossier:${dossierId}`,  { ...dossier, contractId: id, stage: "contract" as PipelineStage, updatedAt: now }),
  ]);

  await logAction(dossierId, "system", "Contrat généré automatiquement", `Contrat v1.0 — ${quote.service}`, true);
  return contract;
}

// ── Automation: Signatures complètes → Paiement Stripe ───────────────────────

export async function autoTriggerPayment(
  dossierId: string,
  contract: PipelineContract,
  stripeKey: string | undefined,
  baseUrl: string,
): Promise<PipelinePayment> {
  const now = new Date().toISOString();
  const id  = puid();

  let checkoutUrl:    string | undefined;
  let stripeSessionId: string | undefined;

  // ── Stripe Checkout Session (optionnel — si clé présente) ─────────────────
  if (stripeKey) {
    try {
      const dossier  = await getDossier(dossierId);
      const token    = dossier?.clientToken ?? "";
      const successUrl = `${baseUrl}/client/${token}?paid=true`;
      const cancelUrl  = `${baseUrl}/client/${token}?paid=false`;
      const amtCents   = Math.round(contract.deposit * 100);
      const dateLabel  = contract.eventDate
        ? new Date(contract.eventDate).toLocaleDateString("fr-FR")
        : "";

      const params = new URLSearchParams();
      params.append("payment_method_types[]", "card");
      params.append("line_items[0][price_data][currency]", "eur");
      params.append("line_items[0][price_data][product_data][name]", contract.service);
      params.append("line_items[0][price_data][product_data][description]",
        `Acompte ${contract.depositPercent} % — ${contract.eventVenue}${dateLabel ? ` le ${dateLabel}` : ""}`);
      params.append("line_items[0][price_data][unit_amount]", amtCents.toString());
      params.append("line_items[0][quantity]", "1");
      params.append("mode", "payment");
      params.append("customer_email", contract.client.email);
      params.append("success_url", successUrl);
      params.append("cancel_url", cancelUrl);
      params.append("metadata[dossierId]", dossierId);
      params.append("metadata[contractId]", contract.id);
      params.append("metadata[paymentId]",  id);

      const stripeRes = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method:  "POST",
        headers: { Authorization: `Bearer ${stripeKey}`, "Content-Type": "application/x-www-form-urlencoded" },
        body:    params.toString(),
      });

      if (stripeRes.ok) {
        const session    = await stripeRes.json();
        stripeSessionId  = session.id;
        checkoutUrl      = session.url;
      } else {
        console.log("Stripe checkout error:", await stripeRes.text());
      }
    } catch (e) {
      console.log("Stripe autoTrigger error:", e);
    }
  }

  const payment: PipelinePayment = {
    id, dossierId, contractId: contract.id,
    amountEur: contract.deposit, currency: "eur",
    status:  checkoutUrl ? "checkout_created" : "pending",
    stripeCheckoutSessionId: stripeSessionId,
    checkoutUrl,
    createdAt: now, updatedAt: now,
  };

  const dossier = await getDossier(dossierId);
  await Promise.all([
    kv.set(`pl:payment:${id}`, payment),
    kv.set(`pl:dossier:${dossierId}`, { ...dossier, paymentId: id, stage: "payment" as PipelineStage, updatedAt: now }),
  ]);

  await logAction(
    dossierId, "stripe",
    checkoutUrl ? "Lien de paiement Stripe créé automatiquement" : "Paiement en attente — clé Stripe non configurée",
    `Acompte : ${contract.deposit.toLocaleString("fr-FR")} €`,
    true,
  );

  return payment;
}

// ── Full dossier view ─────────────────────────────────────────────────────────

export async function getFullDossier(id: string) {
  const dossier = await getDossier(id);
  if (!dossier) return null;

  const [quote, contract, payment, logs] = await Promise.all([
    dossier.quoteId    ? getQuote(dossier.quoteId)       : Promise.resolve(null),
    dossier.contractId ? getContract(dossier.contractId) : Promise.resolve(null),
    dossier.paymentId  ? getPayment(dossier.paymentId)   : Promise.resolve(null),
    getLogs(id),
  ]);

  return { dossier, quote, contract, payment, logs };
}
