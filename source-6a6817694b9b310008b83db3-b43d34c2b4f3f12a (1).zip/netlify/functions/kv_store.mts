import { getDatabase } from "@netlify/database";

const db = getDatabase();

export async function set(key: string, value: unknown): Promise<void> {
  await db.sql`
    INSERT INTO app_kv_store (key, value)
    VALUES (${key}, ${JSON.stringify(value)}::jsonb)
    ON CONFLICT (key)
    DO UPDATE SET value = EXCLUDED.value, updated_at = now()
  `;
}

export async function get(key: string): Promise<unknown | null> {
  const rows = await db.sql`
    SELECT value
    FROM app_kv_store
    WHERE key = ${key}
    LIMIT 1
  `;
  return rows[0]?.value ?? null;
}

export async function del(key: string): Promise<void> {
  await db.sql`
    DELETE FROM app_kv_store
    WHERE key = ${key}
  `;
}

export async function getByPrefix(prefix: string): Promise<unknown[]> {
  const rows = await db.sql`
    SELECT value
    FROM app_kv_store
    WHERE key LIKE ${`${prefix}%`}
    ORDER BY key ASC
  `;
  return rows.map((row: { value: unknown }) => row.value);
}
