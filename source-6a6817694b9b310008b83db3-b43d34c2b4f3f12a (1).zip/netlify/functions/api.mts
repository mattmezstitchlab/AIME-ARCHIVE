import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import type { Config } from "@netlify/functions";
import * as kv from "./kv_store.mjs";
import {
  puid, logAction, getLogs, getFullDossier, getAllDossiers,
  getDossier, getQuote, getContract, getPayment, getDossierByToken,
  autoGenerateContract, autoTriggerPayment,
  type PipelineDossier, type PipelineQuote, type PipelineContract, type PipelinePayment,
} from "./pipeline.mjs";

const app = new Hono();
app.use("*", logger(console.log));
app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
}));

const BASE = "/api";

// ─── Bump to force full re-seed on next /seed call ──────────────────────────
const SEED_VERSION = "msa-v2";

// ─── Types ───────────────────────────────────────────────────────────────────

type RelationStatus = "célibataire" | "concubinage" | "pacs" | "marié" | "divorcé";
type Participation = "participant" | "non-participant";
type StatutRelationnel = "celibataire" | "marie" | "divorce" | "concubinage" | "pacs";
type StatutPro =
  | "exploitant"
  | "salarie_agricole"
  | "conjoint_participant"
  | "conjoint_non_participant"
  | null;
type ParticipationAgricole = "participant" | "non_participant" | "inconnu";

type Dossier = {
  id: string;
  name: string;
  // UI legacy fields
  relationStatus: RelationStatus;
  participation: Participation;
  // MSA extended fields
  statut_relationnel?: StatutRelationnel;
  statut_pro?: StatutPro;
  participation_agricole?: ParticipationAgricole;
  createdAt: string;
  updatedAt: string;
};

type EventType =
  | "mariage"
  | "divorce"
  | "naissance"
  | "emploi"
  | "pacs"
  | "changement"
  | "concubinage";

type EventMetadata = {
  declared?: boolean;
  sector?: string;
  source?: "msa" | "caf" | "user";
  confidence?: number;
  [key: string]: unknown;
};

type EventItem = {
  id: string;
  dossierId: string;
  type: EventType;
  date: string;
  description: string;
  metadata?: EventMetadata;
  createdAt: string;
};

type DocumentItem = {
  id: string;
  dossierId: string;
  name: string;
  type?: string;
  status: "manquant" | "reçu" | "validé";
  createdAt: string;
};

type AlertSeverity = "high" | "medium" | "low";
type Alert = { type: string; message: string; severity: AlertSeverity };

const uid = () =>
  globalThis.crypto?.randomUUID?.() ??
  `${Date.now()}-${Math.random().toString(36).slice(2)}`;

// ─── MOTEUR MSA — 7 RÈGLES ──────────────────────────────────────────────────

function analyzeMSA(
  dossier: Dossier,
  events: EventItem[],
  documents: DocumentItem[],
): {
  status: "coherent" | "warning" | "critical";
  suggestions: string[];
  actions: string[];
  alerts: Alert[];
} {
  const alerts: Alert[] = [];
  const hasType = (t: EventType) => events.some((e) => e.type === t);
  const getFirst = (t: EventType) => events.find((e) => e.type === t);

  const rel = dossier.statut_relationnel;

  // ── Règle 1 — Statut « marié » sans événement mariage ───────────────────
  if (rel === "marie" && !hasType("mariage")) {
    alerts.push({
      type: "status_error",
      message: "Statut marié sans événement mariage enregistré",
      severity: "high",
    });
  }

  // ── Règle 2 — Divorce non propagé dans le statut ──────────────────────
  if (hasType("divorce") && rel && rel !== "divorce") {
    alerts.push({
      type: "status_update",
      message: "Statut non mis à jour après divorce",
      severity: "high",
    });
  }

  // ── Règle 3 — Concubinage non déclaré ─────────────────────────────────
  const concubinageEvents = events.filter((e) => e.type === "concubinage");
  for (const ce of concubinageEvents) {
    if (ce.metadata?.declared === false) {
      alerts.push({
        type: "declaration",
        message: "Concubinage non déclaré — impact sur les prestations MSA",
        severity: "medium",
      });
      break;
    }
  }

  // ── Règle 4 — Conjoint agricole incohérent ────────────────────────────
  if (
    dossier.statut_pro === "conjoint_participant" &&
    dossier.participation_agricole &&
    dossier.participation_agricole !== "participant"
  ) {
    alerts.push({
      type: "agri_status",
      message:
        "Incohérence : statut conjoint_participant mais participation_agricole ≠ participant",
      severity: "high",
    });
  }

  // ── Règle 5 — Activité agricole sans statut professionnel ─────────────
  const agriEvent = events.find(
    (e) => e.type === "emploi" && e.metadata?.sector === "agricole",
  );
  if (agriEvent && !dossier.statut_pro) {
    alerts.push({
      type: "missing_status",
      message: "Statut professionnel MSA manquant (activité agricole détectée)",
      severity: "medium",
    });
  }

  // ── Règle 6 — Relations simultanées (mariage actif + concubinage) ──────
  if (hasType("mariage") && hasType("concubinage")) {
    const divorceDate = getFirst("divorce")?.date;
    const firstConcubinageDate = getFirst("concubinage")?.date;
    // Overlap si pas de divorce, ou si le concubinage commence avant le divorce
    if (!divorceDate || (firstConcubinageDate && divorceDate > firstConcubinageDate)) {
      alerts.push({
        type: "relation_overlap",
        message: "Relations simultanées incohérentes (mariage + concubinage actifs)",
        severity: "high",
      });
    }
  }

  // ── Règle 7 — Acte de divorce manquant ───────────────────────────────
  const hasDivorceDoc = documents.some(
    (d) =>
      d.type === "acte_divorce" ||
      /acte.+divorce|divorce|jugement.+divorce/i.test(d.name),
  );
  if (hasType("divorce") && !hasDivorceDoc) {
    alerts.push({
      type: "missing_doc",
      message: "Acte de divorce manquant dans les documents",
      severity: "high",
    });
  }

  // ── Génération des suggestions + actions ─────────────────────────────
  const suggestions = alerts.map((a) => a.message);
  const actions = alerts.map((a) => {
    switch (a.type) {
      case "status_error":     return "Ajouter l'acte de mariage";
      case "status_update":    return "Mettre à jour le statut relationnel";
      case "declaration":      return "Demander une déclaration de concubinage";
      case "agri_status":      return "Vérifier le statut de participation agricole";
      case "missing_status":   return "Définir le statut professionnel MSA";
      case "relation_overlap": return "Clarifier la situation relationnelle";
      case "missing_doc":      return "Demander l'acte de divorce";
      default:                 return "Analyser le dossier";
    }
  });

  let status: "coherent" | "warning" | "critical" = "coherent";
  if (alerts.length === 1) status = "warning";
  if (alerts.length >= 2)  status = "critical";

  return { status, suggestions, actions, alerts };
}

function computePriority(
  d: Dossier,
  events: EventItem[],
  documents: DocumentItem[],
): "Prioritaire" | "Alerte" | "Cohérent" {
  const { status } = analyzeMSA(d, events, documents);
  if (status === "critical") return "Prioritaire";
  if (status === "warning")  return "Alerte";
  return "Cohérent";
}

// ─── HEALTH ──────────────────────────────────────────────────────────────────

app.get(`${BASE}/health`, (c) =>
  c.json({ status: "ok", engine: "msa-v2", version: SEED_VERSION }),
);

// ─── SEED (version-contrôlé, idempotent) ─────────────────────────────────────

app.post(`${BASE}/seed`, async (c) => {
  try {
    const currentVersion = await kv.get("meta:seed_version");
    if (currentVersion === SEED_VERSION) {
      return c.json({ seeded: false, version: SEED_VERSION });
    }

    // Purger les anciennes données
    const [oldDossiers, oldEvents, oldDocs] = await Promise.all([
      kv.getByPrefix("dossier:") as Promise<Dossier[]>,
      kv.getByPrefix("event:")   as Promise<EventItem[]>,
      kv.getByPrefix("document:") as Promise<DocumentItem[]>,
    ]);
    await Promise.all([
      ...oldDossiers.map((d) => kv.del(`dossier:${d.id}`)),
      ...oldEvents.map((e)   => kv.del(`event:${e.dossierId}:${e.id}`)),
      ...oldDocs.map((d)     => kv.del(`document:${d.dossierId}:${d.id}`)),
    ]);

    const now = new Date().toISOString();

    type Seed = {
      d: Omit<Dossier, "id" | "createdAt" | "updatedAt">;
      events: Array<Omit<EventItem, "id" | "dossierId" | "createdAt">>;
      docs: Array<Omit<DocumentItem, "id" | "dossierId" | "createdAt">>;
    };

    const samples: Seed[] = [

      // ── 1. Marie Bernard — Règle 2 + Règle 7 (PRIORITAIRE) ───────────
      {
        d: {
          name: "Marie Bernard",
          relationStatus: "marié",
          participation: "participant",
          statut_relationnel: "marie",
          statut_pro: "conjoint_participant",
          participation_agricole: "participant",
        },
        events: [
          {
            type: "mariage",
            date: "2015-06-15",
            description: "Mariage avec Thomas Bernard — mairie de Clermont-Ferrand.",
          },
          {
            type: "emploi",
            date: "2016-04-01",
            description: "Intégration à l'exploitation agricale familiale Bernard & Fils.",
            metadata: { sector: "agricole" },
          },
          {
            type: "divorce",
            date: "2022-01-12",
            description: "Divorce prononcé par le TGI de Clermont-Ferrand — accord amiable.",
          },
        ],
        docs: [
          { name: "Attestation exploitation", status: "validé" },
          { name: "Justificatif domicile", status: "reçu" },
        ],
      },

      // ── 2. Jean Lefebvre — Règle 3 + Règle 7 (PRIORITAIRE) ──────────
      {
        d: {
          name: "Jean Lefebvre",
          relationStatus: "divorcé",
          participation: "participant",
          statut_relationnel: "divorce",
          statut_pro: "salarie_agricole",
          participation_agricole: "participant",
        },
        events: [
          {
            type: "mariage",
            date: "2014-09-20",
            description: "Mariage avec Isabelle Lefebvre — mairie de Bordeaux.",
          },
          {
            type: "divorce",
            date: "2021-05-10",
            description: "Divorce prononcé — jugement du tribunal judiciaire de Bordeaux.",
          },
          {
            type: "concubinage",
            date: "2022-03-01",
            description: "Mise en concubinage avec Aurélie Martin — situation non déclarée à la MSA.",
            metadata: { declared: false, source: "user" },
          },
        ],
        docs: [
          { name: "Contrat salarié agricole", status: "validé" },
        ],
      },

      // ── 3. Claire Moreau — Règle 4 (ALERTE) ─────────────────────────
      {
        d: {
          name: "Claire Moreau",
          relationStatus: "marié",
          participation: "non-participant",
          statut_relationnel: "marie",
          statut_pro: "conjoint_participant",
          participation_agricole: "non_participant",
        },
        events: [
          {
            type: "mariage",
            date: "2019-07-14",
            description: "Mariage avec Antoine Moreau — mairie de Lyon.",
          },
        ],
        docs: [
          { name: "Acte de mariage", status: "validé" },
        ],
      },

      // ── 4. Thomas Petit — Règle 5 (ALERTE) ──────────────────────────
      {
        d: {
          name: "Thomas Petit",
          relationStatus: "célibataire",
          participation: "participant",
          statut_relationnel: "celibataire",
          statut_pro: null,
          participation_agricole: "participant",
        },
        events: [
          {
            type: "emploi",
            date: "2023-03-15",
            description: "Début d'activité agricole — polyculture élevage, GAEC Petit.",
            metadata: { sector: "agricole" },
          },
        ],
        docs: [],
      },

      // ── 5. Sophie Garnier — Règle 6 (ALERTE) ────────────────────────
      {
        d: {
          name: "Sophie Garnier",
          relationStatus: "marié",
          participation: "non-participant",
          statut_relationnel: "marie",
          statut_pro: "conjoint_non_participant",
          participation_agricole: "non_participant",
        },
        events: [
          {
            type: "mariage",
            date: "2018-01-20",
            description: "Mariage avec Nicolas Garnier.",
          },
          {
            type: "concubinage",
            date: "2020-06-01",
            description: "Concubinage déclaré avec Paul Renard.",
            metadata: { declared: true, source: "user" },
          },
        ],
        docs: [
          { name: "Acte de mariage", status: "validé" },
        ],
      },

      // ── 6. Jean Dupont — COHÉRENT (dossier de référence) ─────────────
      {
        d: {
          name: "Jean Dupont",
          relationStatus: "marié",
          participation: "participant",
          statut_relationnel: "marie",
          statut_pro: "exploitant",
          participation_agricole: "participant",
        },
        events: [
          {
            type: "mariage",
            date: "2010-05-08",
            description: "Mariage avec Anne Dupont — mairie de Nantes.",
          },
          {
            type: "naissance",
            date: "2012-02-12",
            description: "Naissance de Lucas Dupont.",
          },
          {
            type: "emploi",
            date: "2014-09-01",
            description: "Reprise de l'exploitation familiale Dupont & Fils.",
            metadata: { sector: "agricole" },
          },
        ],
        docs: [
          { name: "Acte de mariage", status: "validé" },
          { name: "Acte de naissance Lucas", status: "validé" },
          { name: "Attestation exploitation", status: "validé" },
        ],
      },

      // ── 7. Pierre Laval — COHÉRENT (salarié agricole, situation stable)
      {
        d: {
          name: "Pierre Laval",
          relationStatus: "pacs",
          participation: "participant",
          statut_relationnel: "pacs",
          statut_pro: "salarie_agricole",
          participation_agricole: "participant",
        },
        events: [
          {
            type: "pacs",
            date: "2020-11-22",
            description: "PACS avec Julie Laval — tribunal de Bordeaux.",
          },
          {
            type: "emploi",
            date: "2021-04-01",
            description: "Embauche salarié agricole — Château Laval Viticole.",
            metadata: { sector: "agricole" },
          },
        ],
        docs: [
          { name: "Convention PACS", status: "validé" },
          { name: "Contrat de travail", status: "validé" },
        ],
      },
    ];

    const writes: Promise<void>[] = [];
    for (const s of samples) {
      const id = uid();
      const dossier: Dossier = { id, ...s.d, createdAt: now, updatedAt: now };
      writes.push(kv.set(`dossier:${id}`, dossier));
      for (const e of s.events) {
        const eid = uid();
        writes.push(kv.set(`event:${id}:${eid}`, { id: eid, dossierId: id, ...e, createdAt: now }));
      }
      for (const doc of s.docs) {
        const did = uid();
        writes.push(kv.set(`document:${id}:${did}`, { id: did, dossierId: id, ...doc, createdAt: now }));
      }
    }
    writes.push(kv.set("meta:seed_version", SEED_VERSION));
    await Promise.all(writes);
    return c.json({ seeded: true, count: samples.length, version: SEED_VERSION });
  } catch (err) {
    console.log("Seed error:", err);
    return c.json({ error: `Seed failed: ${err}` }, 500);
  }
});

// ─── GET /dossiers ────────────────────────────────────────────────────────────

app.get(`${BASE}/dossiers`, async (c) => {
  try {
    const dossiers = (await kv.getByPrefix("dossier:")) as Dossier[];
    const allEvents = (await kv.getByPrefix("event:")) as EventItem[];
    const allDocs   = (await kv.getByPrefix("document:")) as DocumentItem[];

    const eventsByDossier = new Map<string, EventItem[]>();
    for (const e of allEvents) {
      const arr = eventsByDossier.get(e.dossierId) ?? [];
      arr.push(e);
      eventsByDossier.set(e.dossierId, arr);
    }
    const docsByDossier = new Map<string, DocumentItem[]>();
    for (const d of allDocs) {
      const arr = docsByDossier.get(d.dossierId) ?? [];
      arr.push(d);
      docsByDossier.set(d.dossierId, arr);
    }

    const enriched = dossiers.map((d) => ({
      ...d,
      priority: computePriority(
        d,
        eventsByDossier.get(d.id) ?? [],
        docsByDossier.get(d.id) ?? [],
      ),
    }));

    const order: Record<string, number> = { Prioritaire: 3, Alerte: 2, Cohérent: 1 };
    enriched.sort((a, b) => {
      const diff = order[b.priority] - order[a.priority];
      return diff !== 0 ? diff : a.createdAt < b.createdAt ? 1 : -1;
    });

    return c.json({ dossiers: enriched });
  } catch (err) {
    console.log("List dossiers error:", err);
    return c.json({ error: `Failed to list dossiers: ${err}` }, 500);
  }
});

// ─── POST /dossiers ───────────────────────────────────────────────────────────

app.post(`${BASE}/dossiers`, async (c) => {
  try {
    const body = await c.req.json();
    const id   = uid();
    const now  = new Date().toISOString();
    const dossier: Dossier = {
      id,
      name:                   body.name                   ?? "Nouveau dossier",
      relationStatus:         body.relationStatus         ?? "célibataire",
      participation:          body.participation          ?? "non-participant",
      statut_relationnel:     body.statut_relationnel,
      statut_pro:             body.statut_pro             ?? null,
      participation_agricole: body.participation_agricole ?? "inconnu",
      createdAt: now,
      updatedAt: now,
    };
    await kv.set(`dossier:${id}`, dossier);
    return c.json({ dossier });
  } catch (err) {
    console.log("Create dossier error:", err);
    return c.json({ error: `Failed to create dossier: ${err}` }, 500);
  }
});

// ─── GET /dossiers/:id ────────────────────────────────────────────────────────

app.get(`${BASE}/dossiers/:id`, async (c) => {
  try {
    const id      = c.req.param("id");
    const dossier = (await kv.get(`dossier:${id}`)) as Dossier | undefined;
    if (!dossier) return c.json({ error: "Dossier not found" }, 404);

    const events    = ((await kv.getByPrefix(`event:${id}:`)) as EventItem[]).sort((a, b) =>
      a.date < b.date ? -1 : 1,
    );
    const documents = (await kv.getByPrefix(`document:${id}:`)) as DocumentItem[];
    const analysis  = analyzeMSA(dossier, events, documents);

    return c.json({ dossier, events, documents, analysis });
  } catch (err) {
    console.log("Get dossier error:", err);
    return c.json({ error: `Failed to get dossier: ${err}` }, 500);
  }
});

// ─── PUT /dossiers/:id ────────────────────────────────────────────────────────

app.put(`${BASE}/dossiers/:id`, async (c) => {
  try {
    const id      = c.req.param("id");
    const dossier = (await kv.get(`dossier:${id}`)) as Dossier | undefined;
    if (!dossier) return c.json({ error: "Dossier not found" }, 404);
    const body    = await c.req.json();
    const updated: Dossier = {
      ...dossier,
      name:                   body.name                   ?? dossier.name,
      relationStatus:         body.relationStatus         ?? dossier.relationStatus,
      participation:          body.participation          ?? dossier.participation,
      statut_relationnel:     body.statut_relationnel     ?? dossier.statut_relationnel,
      statut_pro:             "statut_pro" in body        ? body.statut_pro : dossier.statut_pro,
      participation_agricole: body.participation_agricole ?? dossier.participation_agricole,
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`dossier:${id}`, updated);
    return c.json({ dossier: updated });
  } catch (err) {
    console.log("Update dossier error:", err);
    return c.json({ error: `Failed to update dossier: ${err}` }, 500);
  }
});

// ─── DELETE /dossiers/:id ─────────────────────────────────────────────────────

app.delete(`${BASE}/dossiers/:id`, async (c) => {
  try {
    const id        = c.req.param("id");
    const events    = (await kv.getByPrefix(`event:${id}:`))    as EventItem[];
    const documents = (await kv.getByPrefix(`document:${id}:`)) as DocumentItem[];
    await Promise.all([
      kv.del(`dossier:${id}`),
      ...events.map((e) => kv.del(`event:${id}:${e.id}`)),
      ...documents.map((d) => kv.del(`document:${id}:${d.id}`)),
    ]);
    return c.json({ ok: true });
  } catch (err) {
    console.log("Delete dossier error:", err);
    return c.json({ error: `Failed to delete dossier: ${err}` }, 500);
  }
});

// ─── POST /dossiers/:id/events ────────────────────────────────────────────────

app.post(`${BASE}/dossiers/:id/events`, async (c) => {
  try {
    const id      = c.req.param("id");
    const dossier = (await kv.get(`dossier:${id}`)) as Dossier | undefined;
    if (!dossier) return c.json({ error: "Dossier not found" }, 404);
    const body    = await c.req.json();
    const eid     = uid();
    const now     = new Date().toISOString();
    const event: EventItem = {
      id:          eid,
      dossierId:   id,
      type:        body.type        ?? "changement",
      date:        body.date        ?? now.slice(0, 10),
      description: body.description ?? "Événement",
      metadata:    body.metadata,
      createdAt:   now,
    };
    await kv.set(`event:${id}:${eid}`, event);
    await kv.set(`dossier:${id}`, { ...dossier, updatedAt: now });
    return c.json({ event });
  } catch (err) {
    console.log("Add event error:", err);
    return c.json({ error: `Failed to add event: ${err}` }, 500);
  }
});

// ─── DELETE /dossiers/:id/events/:eid ────────────────────────────────────────

app.delete(`${BASE}/dossiers/:id/events/:eid`, async (c) => {
  try {
    const id  = c.req.param("id");
    const eid = c.req.param("eid");
    await kv.del(`event:${id}:${eid}`);
    const dossier = (await kv.get(`dossier:${id}`)) as Dossier | undefined;
    if (dossier) await kv.set(`dossier:${id}`, { ...dossier, updatedAt: new Date().toISOString() });
    return c.json({ ok: true });
  } catch (err) {
    console.log("Delete event error:", err);
    return c.json({ error: `Failed to delete event: ${err}` }, 500);
  }
});

// ─── POST /dossiers/:id/documents ─────────────────────────────────────────────

app.post(`${BASE}/dossiers/:id/documents`, async (c) => {
  try {
    const id      = c.req.param("id");
    const dossier = (await kv.get(`dossier:${id}`)) as Dossier | undefined;
    if (!dossier) return c.json({ error: "Dossier not found" }, 404);
    const body    = await c.req.json();
    const did     = uid();
    const doc: DocumentItem = {
      id:         did,
      dossierId:  id,
      name:       body.name   ?? "Document",
      type:       body.type,
      status:     body.status ?? "manquant",
      createdAt:  new Date().toISOString(),
    };
    await kv.set(`document:${id}:${did}`, doc);
    return c.json({ document: doc });
  } catch (err) {
    console.log("Add document error:", err);
    return c.json({ error: `Failed to add document: ${err}` }, 500);
  }
});

// ─── PATCH /dossiers/:id/documents/:did ──────────────────────────────────────

app.patch(`${BASE}/dossiers/:id/documents/:did`, async (c) => {
  try {
    const id  = c.req.param("id");
    const did = c.req.param("did");
    const doc = (await kv.get(`document:${id}:${did}`)) as DocumentItem | undefined;
    if (!doc) return c.json({ error: "Document not found" }, 404);
    const body    = await c.req.json();
    const updated = { ...doc, status: body.status ?? doc.status };
    await kv.set(`document:${id}:${did}`, updated);
    return c.json({ document: updated });
  } catch (err) {
    console.log("Update document error:", err);
    return c.json({ error: `Failed to update document: ${err}` }, 500);
  }
});

// ─── DELETE /dossiers/:id/documents/:did ─────────────────────────────────────

app.delete(`${BASE}/dossiers/:id/documents/:did`, async (c) => {
  try {
    const id  = c.req.param("id");
    const did = c.req.param("did");
    await kv.del(`document:${id}:${did}`);
    return c.json({ ok: true });
  } catch (err) {
    console.log("Delete document error:", err);
    return c.json({ error: `Failed to delete document: ${err}` }, 500);
  }
});

// ─── WEDDING — Auth routes ────────────────────────────────────────────────────

app.post(`${BASE}/auth/signup`, async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    if (!email || !password) return c.json({ error: 'Email et mot de passe requis' }, 400);
    const normalizedEmail = String(email).trim().toLowerCase();
    const existing = await kv.get(`auth:user_email:${normalizedEmail}`);
    if (existing) return c.json({ error: 'Un compte existe déjà avec cet email' }, 409);

    const user = {
      id: uid(),
      email: normalizedEmail,
      name: name || normalizedEmail.split('@')[0],
      passwordHash: await hashPwd(password),
      createdAt: new Date().toISOString(),
    };
    await Promise.all([
      kv.set(`auth:user:${user.id}`, user),
      kv.set(`auth:user_email:${normalizedEmail}`, { userId: user.id }),
    ]);
    return c.json({ user: { id: user.id, email: user.email, user_metadata: { name: user.name } } });
  } catch (err) {
    console.log('Signup error:', err);
    return c.json({ error: `Signup failed: ${err}` }, 500);
  }
});

app.post(`${BASE}/auth/login`, async (c) => {
  try {
    const { email, password } = await c.req.json();
    if (!email || !password) return c.json({ error: 'Email et mot de passe requis' }, 400);
    const normalizedEmail = String(email).trim().toLowerCase();
    const ref = await kv.get(`auth:user_email:${normalizedEmail}`) as { userId: string } | null;
    if (!ref) return c.json({ error: 'Email ou mot de passe incorrect' }, 401);
    const user = await kv.get(`auth:user:${ref.userId}`) as { id: string; email: string; name: string; passwordHash: string } | null;
    if (!user || await hashPwd(password) !== user.passwordHash) {
      return c.json({ error: 'Email ou mot de passe incorrect' }, 401);
    }
    const token = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    await kv.set(`auth:session:${token}`, { token, userId: user.id, expiresAt });
    return c.json({
      session: { access_token: token, expires_at: expiresAt },
      user: { id: user.id, email: user.email, user_metadata: { name: user.name } },
    });
  } catch (err) {
    console.log('Login error:', err);
    return c.json({ error: `Login failed: ${err}` }, 500);
  }
});

// ─── WEDDING — Persistence ────────────────────────────────────────────────────

async function getUserId(token: string): Promise<string | null> {
  try {
    const session = await kv.get(`auth:session:${token}`) as { userId: string; expiresAt: string } | null;
    if (!session) return null;
    if (new Date(session.expiresAt) < new Date()) {
      await kv.del(`auth:session:${token}`);
      return null;
    }
    return session.userId;
  } catch { return null; }
}

app.post(`${BASE}/wedding/save`, async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    if (!token) return c.json({ error: 'Non authentifié' }, 401);
    const userId = await getUserId(token);
    if (!userId) return c.json({ error: 'Token invalide' }, 401);

    const body = await c.req.json();
    await kv.set(`wedding:${userId}`, { ...body, savedAt: new Date().toISOString() });
    return c.json({ ok: true });
  } catch (err) {
    console.log('Wedding save error:', err);
    return c.json({ error: `Save failed: ${err}` }, 500);
  }
});

app.get(`${BASE}/wedding/load`, async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    if (!token) return c.json({ error: 'Non authentifié' }, 401);
    const userId = await getUserId(token);
    if (!userId) return c.json({ error: 'Token invalide' }, 401);

    const data = await kv.get(`wedding:${userId}`);
    return c.json({ wedding: data });
  } catch (err) {
    console.log('Wedding load error:', err);
    return c.json({ error: `Load failed: ${err}` }, 500);
  }
});

// ─── CERISE — Claude Sonnet AI ────────────────────────────────────────────────

app.post(`${BASE}/cerise/chat`, async (c) => {
  try {
    const { message, events, config, history } = await c.req.json();

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) return c.json({ error: 'Clé API Anthropic manquante' }, 500);
    const anthropicBaseUrl = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/$/, '');

    // ── Build timeline context ─────────────────────────────────────────────
    const timelineStr = events?.length
      ? events.map((e: { id: string; time: string; title: string; category: string; status: string; vendor?: string }) =>
          `[ID:${e.id}] ${e.time} — ${e.title} (${e.category}) statut:${e.status}${e.vendor ? ` prestataire:${e.vendor}` : ''}`
        ).join('\n')
      : 'Aucun moment planifié';

    // ── System prompt ─────────────────────────────────────────────────────
    const systemPrompt = `Tu es Cerise, l'assistante mariage de AIME.

PERSONNALITÉ :
- Claire, rapide, utile
- Ton détendu, naturel — jamais formel, jamais robotique
- Légère touche d'humour quand c'est pertinent (1 phrase max, jamais forcé)
- Jamais lourde, jamais enthousiaste à outrance

STYLE D'ÉCRITURE :
- Phrases courtes, directes
- Propose toujours une action concrète en fin de message
- Pas de "Bien sûr !", "Absolument !", "Avec plaisir", "Super choix !"
- Si humour : discret, pertinent, jamais au détriment de l'utilité

EXEMPLES DE TON :
✅ "Bonne base. Il manque encore 2 éléments clés — on les ajoute ?"
✅ "DJ à 14h… audacieux 😄 On le décale pour la soirée ?"
✅ "Photographe ajouté à 14h. Tu veux prévoir aussi les préparatifs en studio ?"
❌ "Ah super mariage incroyable !!! 🎉🔥"
❌ "Bien sûr ! Je serais ravie de vous aider avec votre magnifique mariage !"
❌ "C'est noté, voici une réponse détaillée et exhaustive sur ce sujet…"

SPÉCIALISATION UNIQUE :
Tu es experte UNIQUEMENT dans :
- Organisation de mariage et planification de journée
- Timeline d'événements (horaires, ordre, cohérence logistique)
- Prestataires (DJ, traiteur, photographe, vidéaste, fleuriste, etc.)
- Cohérence temporelle et logistique
- Budget estimatif et priorités

CONTEXTE DU MARIAGE EN COURS :
- Invités : ${config?.guestCount ?? 'non défini'}
- Lieu : ${config?.venue || 'non défini'}
- Style : ${config?.style || 'non défini'}
- Saison : ${config?.season || 'non défini'}
- Date : ${config?.weddingDate || 'non définie'}
- Description : "${config?.rawInput || ''}"

TIMELINE ACTUELLE (${events?.length ?? 0} moments — utilise les IDs exacts pour update/delete) :
${timelineStr}

─────────────────────────────────────────────────────────────
FORMAT DE RÉPONSE — JSON STRICT OBLIGATOIRE
─────────────────────────────────────────────────────────────
Réponds UNIQUEMENT avec du JSON valide. Zéro texte en dehors du JSON.

FORMAT MULTI-ACTIONS (à privilégier) :
{
  "actions": [
    { "type": "add_event",      "data": { "title": "...", "time": "HH:MM", "category": "ceremony|catering|music|photo|preparation|reception|transport|accommodation|other", "description": "..." } },
    { "type": "update_event",   "data": { "eventId": "ID_EXACT_DE_LA_TIMELINE", "title": "...", "time": "HH:MM", "status": "pending|in_progress|done", "vendor": "..." } },
    { "type": "delete_event",   "data": { "eventId": "ID_EXACT_DE_LA_TIMELINE" } },
    { "type": "add_alert",      "data": { "severity": "critical|warning", "message": "...", "action": "..." } },
    { "type": "suggest_action", "data": { "label": "...", "priority": "high|medium|low" } },
    { "type": "ask_question",   "data": { "question": "..." } },
    { "type": "none",           "data": {} }
  ],
  "message": "Texte court — ton Cerise, direct, utile (2 phrases max)",
  "suggestion": "Prochaine étape — phrase courte (optionnel)"
}

FORMAT ACTION UNIQUE (si une seule action) :
{
  "action": "add_event",
  "data": { ... },
  "message": "...",
  "suggestion": "..."
}

─────────────────────────────────────────────────────────────
RÈGLES MÉTIER — LOGIQUE TEMPORELLE OBLIGATOIRE
─────────────────────────────────────────────────────────────
Ordre canonique : préparatifs → cérémonie → vin d'honneur → dîner → soirée
- Préparatifs : 8h00–13h00 MAXIMUM
- Cérémonie principale : 14h00–18h00
- Vin d'honneur : minimum 30min après la cérémonie
- Dîner : 19h00–21h00
- Soirée/DJ : après 21h00
- Jamais deux événements à la même heure exacte

Si violation détectée → TOUJOURS ajouter un "add_alert" en plus de l'action.

─────────────────────────────────────────────────────────────
RÈGLES COMPORTEMENT
─────────────────────────────────────────────────────────────
1. Réponses COURTES et CONCRÈTES (2 phrases max dans "message")
2. Toujours spécifique au mariage en cours, jamais généraliste
3. Si info manquante → "ask_question" avec UNE seule question claire
4. Si incohérence → add_alert, même si l'utilisateur ne le signale pas
5. Si hors contexte mariage → { "action": "none", "message": "Je suis spécialisée en organisation de mariage uniquement." }
6. Utilise les IDs EXACTS de la timeline pour update/delete`;

    // ── Build messages with history ────────────────────────────────────────
    const chatHistory: { role: string; content: string }[] = (history || [])
      .slice(-12)  // Last 12 messages for context
      .map((m: { role: string; text: string }) => ({
        role: m.role === 'user' ? 'user' : 'assistant',
        content: m.text,
      }))
      .filter((m: { role: string; content: string }) => m.content?.trim());

    // Ensure we don't end with an assistant message (Claude needs user turn last)
    const messagesForClaude = [
      ...chatHistory,
      { role: 'user', content: message },
    ];

    // ── Call Claude ────────────────────────────────────────────────────────
    const response = await fetch(`${anthropicBaseUrl}/v1/messages`, {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5',
        max_tokens: 1500,
        system: systemPrompt,
        messages: messagesForClaude,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.log('Claude API error:', response.status, errText);
      return c.json({ error: `Claude API error ${response.status}: ${errText}` }, 502);
    }

    const claudeData = await response.json();
    const rawContent = claudeData.content?.[0]?.text || '{}';

    // ── Parse & normalize response ─────────────────────────────────────────
    let parsed: Record<string, unknown>;
    try {
      const jsonStr = rawContent
        .replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
      // Extract first JSON object/array
      const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
      parsed = JSON.parse(jsonMatch ? jsonMatch[0] : jsonStr);
    } catch {
      // Claude didn't return valid JSON — wrap it
      parsed = { action: 'none', data: {}, message: rawContent };
    }

    // ── Normalize to standard format: { actions, message, suggestion } ─────
    type NormalizedAction = { type: string; data: Record<string, unknown> };
    let normalizedActions: NormalizedAction[] = [];
    const message_out = (parsed.message as string) || '';
    const suggestion   = (parsed.suggestion as string) || undefined;

    if (Array.isArray(parsed.actions)) {
      // Multi-action format
      normalizedActions = (parsed.actions as Array<{ type: string; data: Record<string, unknown> }>)
        .filter((a) => a.type && a.type !== 'none')
        .map((a) => ({ type: a.type, data: a.data || {} }));
    } else if (parsed.action && parsed.action !== 'none') {
      // Single action format
      normalizedActions = [{ type: parsed.action as string, data: (parsed.data as Record<string, unknown>) || {} }];
    }

    return c.json({
      actions:    normalizedActions,
      message:    message_out || 'Réponse reçue.',
      suggestion: suggestion,
    });

  } catch (err) {
    console.log('Cerise chat error:', err);
    return c.json({ error: `Chat failed: ${err}` }, 500);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// ─── ADMIN — Types ────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

type AdminSession     = { token: string; email: string; expiresAt: string };
type AdminCredentials = { email: string; passwordHash: string };

type AdminQuote = {
  id: string; clientName: string; clientEmail: string; clientPhone?: string;
  eventDate: string; eventVenue: string; service: string;
  duration: number; amount: number; deposit: number;
  status: 'draft' | 'sent' | 'accepted' | 'refused';
  notes?: string; contractId?: string; createdAt: string; updatedAt: string;
};

type AdminContract = {
  id: string; quoteId: string; clientName: string; clientEmail: string;
  eventDate: string; eventVenue: string; service: string;
  amount: number; deposit: number;
  clientSignedAt?: string; vendorSignedAt?: string; depositPaidAt?: string;
  status: 'draft' | 'sent' | 'client_signed' | 'fully_signed' | 'deposit_paid' | 'confirmed';
  notes?: string; createdAt: string; updatedAt: string;
};

// ─── ADMIN — Helpers ──────────────────────────────────────────────────────────

async function hashPwd(password: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(password));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function verifyAdminToken(token: string | undefined): Promise<boolean> {
  if (!token) return false;
  const session = await kv.get(`admin:session:${token}`) as AdminSession | null;
  if (!session) return false;
  if (new Date(session.expiresAt) < new Date()) { await kv.del(`admin:session:${token}`); return false; }
  return true;
}
function adminTok(c: { req: { header: (k: string) => string | undefined } }) {
  return c.req.header('Authorization')?.split(' ')[1];
}

// ─── ADMIN — Auth ─────────────────────────────────────────────────────────────

app.post(`${BASE}/admin/login`, async (c) => {
  try {
    const { email, password } = await c.req.json();
    if (!email || !password) return c.json({ error: 'Champs requis' }, 400);
    let creds = await kv.get('admin:credentials') as AdminCredentials | null;
    if (!creds) {
      const initialEmail = process.env.ADMIN_EMAIL;
      const initialPassword = process.env.ADMIN_PASSWORD;
      if (!initialEmail || !initialPassword) {
        return c.json({ error: 'Compte administrateur non initialisé' }, 503);
      }
      creds = { email: initialEmail.trim().toLowerCase(), passwordHash: await hashPwd(initialPassword) };
      await kv.set('admin:credentials', creds);
    }
    if (String(email).trim().toLowerCase() !== creds.email || await hashPwd(password) !== creds.passwordHash)
      return c.json({ error: 'Identifiants incorrects' }, 401);
    const token = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    await kv.set(`admin:session:${token}`, { token, email, expiresAt });
    return c.json({ token, expiresAt, email });
  } catch (err) { return c.json({ error: `Login failed: ${err}` }, 500); }
});

app.get(`${BASE}/admin/verify`, async (c) => {
  return await verifyAdminToken(adminTok(c))
    ? c.json({ ok: true }) : c.json({ error: 'Unauthorized' }, 401);
});

app.post(`${BASE}/admin/logout`, async (c) => {
  const t = adminTok(c); if (t) await kv.del(`admin:session:${t}`);
  return c.json({ ok: true });
});

// ─── ADMIN — Stats Dashboard ──────────────────────────────────────────────────

app.get(`${BASE}/admin/stats`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const [quotes, contracts] = await Promise.all([
    kv.getByPrefix('admin:quote:')    as Promise<AdminQuote[]>,
    kv.getByPrefix('admin:contract:') as Promise<AdminContract[]>,
  ]);
  const totalRevenue = contracts
    .filter(ct => ['confirmed','fully_signed','deposit_paid'].includes(ct.status))
    .reduce((s, ct) => s + ct.amount, 0);
  const upcoming = contracts
    .filter(ct => ct.eventDate && new Date(ct.eventDate) > new Date())
    .sort((a, b) => a.eventDate.localeCompare(b.eventDate))[0] ?? null;
  return c.json({
    totalQuotes: quotes.length,
    pendingQuotes: quotes.filter(q => q.status === 'sent').length,
    confirmedContracts: contracts.filter(ct => ct.status === 'confirmed').length,
    totalRevenue,
    upcoming,
    recentQuotes: quotes.slice(0, 5),
    recentContracts: contracts.slice(0, 5),
  });
});

// ─── ADMIN — Profile ──────────────────────────────────────────────────────────

app.get(`${BASE}/admin/profile`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const profile = await kv.get('admin:profile') ?? {
    name: 'Matt Mez Sax', tagline: 'Saxophoniste & Musicien d\'événements',
    bio: 'Saxophoniste professionnel spécialisé dans les mariages et événements premium. Repertoire jazz, pop, classique et électro-acoustique.',
    phone: '', email: 'matt@aime.fr', website: '',
    services: [
      { id: '1', title: 'Cocktail Sax', description: 'Animation cocktail et vin d\'honneur (1h30)', price: 800 },
      { id: '2', title: 'Soirée complète', description: 'Animation cocktail + dîner + soirée (5h)', price: 1800 },
      { id: '3', title: 'Cérémonie', description: 'Musique de cérémonie laïque (1h)', price: 600 },
    ],
    tarifs: [
      { id: '1', label: 'Déplacement > 100km', price: 150, details: 'Frais kilométriques' },
      { id: '2', label: 'Nuitée', price: 120, details: 'Si déplacement > 200km' },
      { id: '3', label: 'Sono supplémentaire', price: 200, details: 'Pour grande salle > 300 personnes' },
    ],
    gallery: [
      { id: '1', type: 'image', url: 'https://res.cloudinary.com/divou1vcx/image/upload/v1772854228/invites_vnzgm4.jpg', caption: 'Cocktail mariage' },
    ],
    published: false,
  };
  return c.json({ profile });
});

app.put(`${BASE}/admin/profile`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  await kv.set('admin:profile', { ...await c.req.json(), updatedAt: new Date().toISOString() });
  return c.json({ ok: true });
});

// ─── ADMIN — Quotes ───────────────────────────────────────────────────────────

app.get(`${BASE}/admin/quotes`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const quotes = (await kv.getByPrefix('admin:quote:') as AdminQuote[])
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return c.json({ quotes });
});

app.post(`${BASE}/admin/quotes`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const body = await c.req.json();
  const now = new Date().toISOString();
  const amt = body.amount || 0;
  const quote: AdminQuote = {
    id: uid(), clientName: body.clientName || '', clientEmail: body.clientEmail || '',
    clientPhone: body.clientPhone || '', eventDate: body.eventDate || '',
    eventVenue: body.eventVenue || '', service: body.service || 'Matt Mez Sax',
    duration: body.duration || 3, amount: amt,
    deposit: body.deposit ?? Math.round(amt * 0.3),
    status: 'draft', notes: body.notes || '', createdAt: now, updatedAt: now,
  };
  await kv.set(`admin:quote:${quote.id}`, quote);
  return c.json({ quote });
});

app.put(`${BASE}/admin/quotes/:id`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const quote = await kv.get(`admin:quote:${c.req.param('id')}`) as AdminQuote | null;
  if (!quote) return c.json({ error: 'Not found' }, 404);
  const body = await c.req.json();
  const updated = { ...quote, ...body, id: quote.id, updatedAt: new Date().toISOString() };
  await kv.set(`admin:quote:${quote.id}`, updated);
  return c.json({ quote: updated });
});

app.delete(`${BASE}/admin/quotes/:id`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  await kv.del(`admin:quote:${c.req.param('id')}`);
  return c.json({ ok: true });
});

app.post(`${BASE}/admin/quotes/:id/contract`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const quote = await kv.get(`admin:quote:${c.req.param('id')}`) as AdminQuote | null;
  if (!quote) return c.json({ error: 'Not found' }, 404);
  const now = new Date().toISOString();
  const contract: AdminContract = {
    id: uid(), quoteId: quote.id, clientName: quote.clientName,
    clientEmail: quote.clientEmail, eventDate: quote.eventDate,
    eventVenue: quote.eventVenue, service: quote.service,
    amount: quote.amount, deposit: quote.deposit,
    status: 'draft', notes: quote.notes, createdAt: now, updatedAt: now,
  };
  await kv.set(`admin:contract:${contract.id}`, contract);
  await kv.set(`admin:quote:${quote.id}`, { ...quote, contractId: contract.id, status: 'accepted', updatedAt: now });
  return c.json({ contract });
});

// ─── ADMIN — Contracts ────────────────────────────────────────────────────────

app.get(`${BASE}/admin/contracts`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const contracts = (await kv.getByPrefix('admin:contract:') as AdminContract[])
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return c.json({ contracts });
});

app.put(`${BASE}/admin/contracts/:id`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const contract = await kv.get(`admin:contract:${c.req.param('id')}`) as AdminContract | null;
  if (!contract) return c.json({ error: 'Not found' }, 404);
  const updated = { ...contract, ...await c.req.json(), id: contract.id, updatedAt: new Date().toISOString() };
  await kv.set(`admin:contract:${contract.id}`, updated);
  return c.json({ contract: updated });
});

app.post(`${BASE}/admin/contracts/:id/sign`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const contract = await kv.get(`admin:contract:${c.req.param('id')}`) as AdminContract | null;
  if (!contract) return c.json({ error: 'Not found' }, 404);
  const { party } = await c.req.json();
  const now = new Date().toISOString();
  const u = { ...contract, updatedAt: now };
  if (party === 'client')  u.clientSignedAt = now;
  if (party === 'vendor')  u.vendorSignedAt = now;
  if (u.clientSignedAt && u.vendorSignedAt) u.status = 'fully_signed';
  else if (u.clientSignedAt) u.status = 'client_signed';
  await kv.set(`admin:contract:${contract.id}`, u);
  return c.json({ contract: u });
});

app.post(`${BASE}/admin/contracts/:id/deposit`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const contract = await kv.get(`admin:contract:${c.req.param('id')}`) as AdminContract | null;
  if (!contract) return c.json({ error: 'Not found' }, 404);
  const now = new Date().toISOString();
  const u = { ...contract, depositPaidAt: now, status: 'confirmed' as const, updatedAt: now };
  await kv.set(`admin:contract:${contract.id}`, u);
  return c.json({ contract: u });
});

// ─── ADMIN — Site Content ─────────────────────────────────────────────────────

app.get(`${BASE}/admin/content`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const content = await kv.get('admin:content') ?? {
    heroTitle: 'Décrivez votre mariage.\nOn s\'occupe du reste.',
    heroSubtitle: 'Cerise organise, structure et guide chaque étape de votre journée — en quelques mots.',
    heroCta: 'Créer mon organisation',
    videoUrl: 'https://res.cloudinary.com/divou1vcx/video/upload/v1776701678/AIME_tfm3wc.mp4',
    hymneUrl: 'https://res.cloudinary.com/divou1vcx/video/upload/v1777377166/Aime_-_Hymne_ljloly.mp3',
    taglines: [
      "Il y a des matins qui goûtent différemment.",
      "L'amour s'improvise. Les belles choses se préparent.",
      "Vous vous êtes dit oui — on veille sur le reste.",
      "Chaque pétale compte. Aucun ne tombe sans qu'on le sache.",
      "Du premier regard au dernier slow.",
      "Parce que votre histoire mérite d'être bien gardée.",
      "AIME — le nom dit tout.",
    ],
    philosophie: '"Comprendre. Structurer. Vérifier. Avancer."',
    footerTagline: 'Comprendre. Structurer. Vérifier. Avancer.',
  };
  return c.json({ content });
});

app.put(`${BASE}/admin/content`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  await kv.set('admin:content', { ...await c.req.json(), updatedAt: new Date().toISOString() });
  return c.json({ ok: true });
});

// ─── ADMIN — Cerise Config ────────────────────────────────────────────────────

const CERISE_DEFAULT_PROMPT = `Tu es Cerise, l'assistante mariage de AIME.
Personnalité claire, rapide, utile. Ton détendu, jamais formel.
Phrases courtes, directes. Propose toujours une action concrète.`;

app.get(`${BASE}/admin/cerise-config`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  const config = await kv.get('admin:cerise_config') ?? {
    systemPrompt: CERISE_DEFAULT_PROMPT,
    temperature: 0.7,
    rules: [
      'Réponses courtes (2 phrases max dans "message")',
      'Toujours spécifique au mariage en cours',
      'Si info manquante → ask_question (1 seule question)',
      'Si incohérence → add_alert automatiquement',
      'Si hors contexte → "Je suis spécialisée en mariage uniquement"',
    ],
    examples: [
      { user: 'Ajoute un DJ pour la soirée', assistant: 'DJ ajouté à 21h30. On lui attribue 4h ?' },
      { user: 'Quel est mon budget ?', assistant: 'Basé sur tes prestataires : ~8500€. Il manque encore le traiteur.' },
    ],
  };
  return c.json({ config });
});

app.put(`${BASE}/admin/cerise-config`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  await kv.set('admin:cerise_config', { ...await c.req.json(), updatedAt: new Date().toISOString() });
  return c.json({ ok: true });
});

app.post(`${BASE}/admin/cerise-test`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const { message, systemPrompt } = await c.req.json();
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) return c.json({ error: 'Clé API manquante' }, 500);
    const anthropicBaseUrl = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/$/, '');
    const res = await fetch(`${anthropicBaseUrl}/v1/messages`, {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5', max_tokens: 600,
        system: systemPrompt || CERISE_DEFAULT_PROMPT,
        messages: [{ role: 'user', content: message }],
      }),
    });
    if (!res.ok) return c.json({ error: `Claude error: ${await res.text()}` }, 502);
    const data = await res.json();
    return c.json({ response: data.content?.[0]?.text || '' });
  } catch (err) { return c.json({ error: `Test failed: ${err}` }, 500); }
});


// ═══════════════════════════════════════════════════════════════════════════════
// ─── PIPELINE — AIME Automated Quote → Contract → Payment ────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

// ── GET /admin/pipeline/dossiers ──────────────────────────────────────────────
app.get(`${BASE}/admin/pipeline/dossiers`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const dossiers = await getAllDossiers();
    const enriched = await Promise.all(dossiers.map(async (d) => {
      const quote = d.quoteId ? await getQuote(d.quoteId) : null;
      return { ...d, quote };
    }));
    return c.json({ dossiers: enriched });
  } catch (err) {
    console.log('Pipeline list error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── GET /admin/pipeline/dossier/:id ───────────────────────────────────────────
app.get(`${BASE}/admin/pipeline/dossier/:id`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const full = await getFullDossier(c.req.param('id'));
    if (!full) return c.json({ error: 'Not found' }, 404);
    return c.json(full);
  } catch (err) {
    console.log('Pipeline get dossier error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── POST /admin/pipeline/dossier — Create quote + auto-send ──────────────────
app.post(`${BASE}/admin/pipeline/dossier`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const body        = await c.req.json();
    const now         = new Date().toISOString();
    const dossierId   = puid();
    const quoteId     = puid();
    const clientToken = puid().replace(/-/g, '');
    const amt  = Number(body.amount)  || 0;
    const dep  = Number(body.deposit) || Math.round(amt * 0.3);
    const pct  = amt > 0 ? Math.round((dep / amt) * 100) : 30;
    const quote: PipelineQuote = {
      id: quoteId, dossierId, version: 1,
      clientName: body.clientName || '', clientEmail: body.clientEmail || '',
      clientPhone: body.clientPhone || '', eventDate: body.eventDate || '',
      eventVenue: body.eventVenue || '', service: body.service || 'Matt Mez Sax',
      duration: Number(body.duration) || 3, amount: amt, deposit: dep, depositPercent: pct,
      notes: body.notes || '', status: 'sent',
      createdAt: now, updatedAt: now,
    };
    const dossier: PipelineDossier = {
      id: dossierId, stage: 'quoted', quoteId,
      clientName: body.clientName || '', clientEmail: body.clientEmail || '',
      clientToken, createdBy: body.createdBy || 'admin',
      createdAt: now, updatedAt: now,
    };
    await Promise.all([
      kv.set(`pl:quote:${quoteId}`, quote),
      kv.set(`pl:dossier:${dossierId}`, dossier),
      kv.set(`pl:token:${clientToken}`, { dossierId }),
    ]);
    const actor = body.createdBy === 'cerise' ? 'cerise' : 'admin';
    await logAction(dossierId, actor as 'cerise' | 'admin',
      'Devis créé et envoyé automatiquement',
      `${quote.service} — ${amt.toLocaleString('fr-FR')} € (acompte ${dep.toLocaleString('fr-FR')} €)`,
      actor === 'cerise');
    return c.json({ dossier, quote, clientToken });
  } catch (err) {
    console.log('Pipeline create error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── POST /admin/pipeline/quote/:id/accept ─────────────────────────────────────
app.post(`${BASE}/admin/pipeline/quote/:id/accept`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const quote = await getQuote(c.req.param('id'));
    if (!quote) return c.json({ error: 'Quote not found' }, 404);
    if (quote.status === 'accepted') return c.json({ error: 'Already accepted' }, 409);
    await logAction(quote.dossierId, 'admin', 'Devis accepté', 'Par l\'administrateur', false);
    const contract = await autoGenerateContract(quote.dossierId, quote);
    const full     = await getFullDossier(quote.dossierId);
    return c.json({ ...full, contract });
  } catch (err) {
    console.log('Pipeline accept error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── POST /admin/pipeline/quote/:id/refuse ─────────────────────────────────────
app.post(`${BASE}/admin/pipeline/quote/:id/refuse`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const quote = await getQuote(c.req.param('id'));
    if (!quote) return c.json({ error: 'Not found' }, 404);
    const now = new Date().toISOString();
    const updated = { ...quote, status: 'refused' as const, refusedAt: now, updatedAt: now };
    const dossier = await getDossier(quote.dossierId);
    await Promise.all([
      kv.set(`pl:quote:${quote.id}`, updated),
      kv.set(`pl:dossier:${quote.dossierId}`, { ...dossier, stage: 'cancelled' as const, updatedAt: now }),
    ]);
    await logAction(quote.dossierId, 'admin', 'Devis refusé', undefined, false);
    return c.json({ quote: updated });
  } catch (err) {
    console.log('Pipeline refuse error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── POST /admin/pipeline/contract/:id/sign ────────────────────────────────────
app.post(`${BASE}/admin/pipeline/contract/:id/sign`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const contract = await getContract(c.req.param('id'));
    if (!contract) return c.json({ error: 'Contract not found' }, 404);
    const { party, name, ip } = await c.req.json() as { party: 'client' | 'vendor'; name?: string; ip?: string };
    const now = new Date().toISOString();
    const sig = { signedAt: now, ip: ip || 'admin', name: name || (party === 'vendor' ? 'Matt Mez Sax' : contract.client.name) };
    const updated: PipelineContract = {
      ...contract,
      signatures: { ...contract.signatures, [party === 'client' ? 'client' : 'vendor']: sig },
      updatedAt: now,
    };
    const bothSigned = !!(updated.signatures.client && updated.signatures.vendor);
    if (bothSigned) updated.status = 'fully_signed';
    else if (updated.signatures.client) updated.status = 'client_signed';
    await kv.set(`pl:contract:${contract.id}`, updated);
    await logAction(contract.dossierId, party === 'vendor' ? 'admin' : 'client',
      party === 'vendor' ? 'Signature prestataire (Matt)' : 'Signature client', sig.name, false);
    let payment: PipelinePayment | null = null;
    if (bothSigned) {
      const dossier = await getDossier(contract.dossierId);
      await kv.set(`pl:dossier:${contract.dossierId}`, { ...dossier, stage: 'signed' as const, updatedAt: now });
      await logAction(contract.dossierId, 'system', 'Contrat signé des deux parties', undefined, true);
      const stripeKey = process.env.STRIPE_SECRET_KEY;
      const baseUrl   = c.req.header('Origin') || 'https://aime.fr';
      payment         = await autoTriggerPayment(contract.dossierId, updated, stripeKey, baseUrl);
    }
    const full = await getFullDossier(contract.dossierId);
    return c.json({ ...full, payment });
  } catch (err) {
    console.log('Pipeline sign error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── POST /admin/pipeline/payment/:id/confirm ──────────────────────────────────
app.post(`${BASE}/admin/pipeline/payment/:id/confirm`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const payment = await getPayment(c.req.param('id'));
    if (!payment) return c.json({ error: 'Not found' }, 404);
    const now     = new Date().toISOString();
    const updated = { ...payment, status: 'paid' as const, paidAt: now, updatedAt: now };
    const dossier = await getDossier(payment.dossierId);
    await Promise.all([
      kv.set(`pl:payment:${payment.id}`, updated),
      kv.set(`pl:dossier:${payment.dossierId}`, { ...dossier, stage: 'confirmed' as const, updatedAt: now }),
    ]);
    await logAction(payment.dossierId, 'admin', 'Acompte confirmé manuellement',
      `${payment.amountEur.toLocaleString('fr-FR')} € reçus`, false);
    return c.json(await getFullDossier(payment.dossierId));
  } catch (err) {
    console.log('Pipeline confirm error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── DELETE /admin/pipeline/dossier/:id ────────────────────────────────────────
app.delete(`${BASE}/admin/pipeline/dossier/:id`, async (c) => {
  if (!await verifyAdminToken(adminTok(c))) return c.json({ error: 'Unauthorized' }, 401);
  try {
    const dossier = await getDossier(c.req.param('id'));
    if (!dossier) return c.json({ error: 'Not found' }, 404);
    const logs = await getLogs(c.req.param('id'));
    await Promise.all([
      kv.del(`pl:dossier:${dossier.id}`),
      kv.del(`pl:token:${dossier.clientToken}`),
      dossier.quoteId    ? kv.del(`pl:quote:${dossier.quoteId}`)       : Promise.resolve(),
      dossier.contractId ? kv.del(`pl:contract:${dossier.contractId}`) : Promise.resolve(),
      dossier.paymentId  ? kv.del(`pl:payment:${dossier.paymentId}`)   : Promise.resolve(),
      ...logs.map(l => kv.del(`pl:log:${dossier.id}:${l.timestamp}:${l.id}`)),
    ]);
    return c.json({ ok: true });
  } catch (err) {
    console.log('Pipeline delete error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ─── CLIENT PORTAL — public, token-based ─────────────────────────────────────

app.get(`${BASE}/client/portal/:token`, async (c) => {
  try {
    const dossier = await getDossierByToken(c.req.param('token'));
    if (!dossier) return c.json({ error: 'Lien invalide ou expiré' }, 404);
    const full = await getFullDossier(dossier.id);
    return c.json({
      stage:    full?.dossier.stage,
      quote:    full?.quote,
      contract: full?.contract ? { ...full.contract, prestataire: { name: full.contract.prestataire.name } } : null,
      payment:  full?.payment  ? { status: full.payment.status, amountEur: full.payment.amountEur, checkoutUrl: full.payment.checkoutUrl } : null,
    });
  } catch (err) {
    console.log('Client portal get error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

app.post(`${BASE}/client/portal/:token/accept`, async (c) => {
  try {
    const dossier = await getDossierByToken(c.req.param('token'));
    if (!dossier) return c.json({ error: 'Lien invalide' }, 404);
    if (!dossier.quoteId) return c.json({ error: 'Devis introuvable' }, 404);
    const quote = await getQuote(dossier.quoteId);
    if (!quote) return c.json({ error: 'Devis introuvable' }, 404);
    if (quote.status === 'accepted') return c.json({ error: 'Déjà accepté' }, 409);
    await logAction(dossier.id, 'client', 'Devis accepté par le client',
      `IP: ${c.req.header('CF-Connecting-IP') || 'inconnue'}`, false);
    const contract = await autoGenerateContract(dossier.id, quote);
    return c.json({ ok: true, contract: { id: contract.id, status: contract.status } });
  } catch (err) {
    console.log('Client accept error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

app.post(`${BASE}/client/portal/:token/sign`, async (c) => {
  try {
    const dossier = await getDossierByToken(c.req.param('token'));
    if (!dossier) return c.json({ error: 'Lien invalide' }, 404);
    if (!dossier.contractId) return c.json({ error: 'Contrat introuvable' }, 404);
    const contract = await getContract(dossier.contractId);
    if (!contract) return c.json({ error: 'Contrat introuvable' }, 404);
    if (contract.signatures.client) return c.json({ error: 'Déjà signé' }, 409);
    const { name } = await c.req.json();
    const now = new Date().toISOString();
    const ip  = c.req.header('CF-Connecting-IP') || 'inconnue';
    const updated: PipelineContract = {
      ...contract,
      signatures: { ...contract.signatures, client: { signedAt: now, ip, name: name || contract.client.name } },
      status: 'client_signed', updatedAt: now,
    };
    await kv.set(`pl:contract:${contract.id}`, updated);
    await logAction(dossier.id, 'client', 'Contrat signé par le client', name, false);
    let paymentInfo: { status: string; amountEur: number; checkoutUrl?: string } | null = null;
    if (updated.signatures.vendor) {
      const fullySignedContract = { ...updated, status: 'fully_signed' as const };
      await kv.set(`pl:contract:${contract.id}`, fullySignedContract);
      await logAction(dossier.id, 'system', 'Contrat signé des deux parties', undefined, true);
      const d = await getDossier(dossier.id);
      await kv.set(`pl:dossier:${dossier.id}`, { ...d, stage: 'signed' as const, updatedAt: now });
      const stripeKey = process.env.STRIPE_SECRET_KEY;
      const baseUrl   = c.req.header('Origin') || 'https://aime.fr';
      const p = await autoTriggerPayment(dossier.id, fullySignedContract, stripeKey, baseUrl);
      paymentInfo = { status: p.status, amountEur: p.amountEur, checkoutUrl: p.checkoutUrl };
    }
    return c.json({ ok: true, payment: paymentInfo });
  } catch (err) {
    console.log('Client sign error:', err);
    return c.json({ error: `Failed: ${err}` }, 500);
  }
});

// ── POST /webhook/stripe ──────────────────────────────────────────────────────
app.post(`${BASE}/webhook/stripe`, async (c) => {
  try {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!webhookSecret) return c.json({ error: 'Webhook Stripe non configuré' }, 503);

    const payload = await c.req.text();
    const signature = c.req.header('stripe-signature');
    const verified = await verifyStripeSignature(payload, signature, webhookSecret);
    if (!verified) return c.json({ error: 'Signature Stripe invalide' }, 400);

    const event = JSON.parse(payload);
    if (event.type === 'checkout.session.completed') {
      const session    = event.data?.object;
      const paymentId  = session?.metadata?.paymentId;
      const dossierId  = session?.metadata?.dossierId;
      if (paymentId && dossierId) {
        const payment = await getPayment(paymentId);
        const dossier = await getDossier(dossierId);
        const now     = new Date().toISOString();
        if (payment) await kv.set(`pl:payment:${paymentId}`, { ...payment, status: 'paid', stripePaymentIntentId: session.payment_intent, paidAt: now, updatedAt: now });
        if (dossier) await kv.set(`pl:dossier:${dossierId}`, { ...dossier, stage: 'confirmed' as const, updatedAt: now });
        await logAction(dossierId, 'stripe', 'Paiement Stripe confirmé ✓', `Session: ${session.id}`, true);
      }
    }
    return c.json({ received: true });
  } catch (err) {
    console.log('Stripe webhook error:', err);
    return c.json({ error: `Webhook failed: ${err}` }, 500);
  }
});

async function verifyStripeSignature(payload: string, signatureHeader: string | undefined, secret: string): Promise<boolean> {
  if (!signatureHeader) return false;
  const parts = Object.fromEntries(
    signatureHeader.split(',').map((part) => {
      const [key, ...value] = part.split('=');
      return [key, value.join('=')];
    }),
  );
  const timestamp = parts.t;
  const expected = parts.v1;
  if (!timestamp || !expected) return false;

  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const signedPayload = `${timestamp}.${payload}`;
  const digest = await crypto.subtle.sign('HMAC', key, encoder.encode(signedPayload));
  const actual = Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, '0')).join('');
  return timingSafeEqual(actual, expected);
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i += 1) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

export default app.fetch;

export const config: Config = {
  path: "/api/*",
};
