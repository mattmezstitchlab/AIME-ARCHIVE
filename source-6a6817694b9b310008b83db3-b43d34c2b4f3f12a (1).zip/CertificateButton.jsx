import React, { useState } from "react";
import { jsPDF } from "jspdf";
import QRCode from "qrcode";
import { Award, Loader2 } from "lucide-react";

// Simple deterministic hash for the certificate signature
const hashString = (str) => {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h).toString(16).padStart(8, "0").toUpperCase();
};

export default function CertificateButton({ stamp }) {
  const [busy, setBusy] = useState(false);

  const handleDownload = async () => {
    if (!stamp || busy) return;
    setBusy(true);

    const issued = new Date();
    const issuedStr = issued.toLocaleString("fr-FR");
    const signature = hashString(
      `${stamp.code}-${stamp.text}-${stamp.image_url}-${issued.getTime()}`
    );
    const verifyUrl = `${window.location.origin}/verify/${stamp.code}`;

    // Load stamp image as data URL for embedding
    let imgData = null;
    try {
      const res = await fetch(stamp.image_url);
      const blob = await res.blob();
      imgData = await new Promise((resolve) => {
        const r = new FileReader();
        r.onloadend = () => resolve(r.result);
        r.readAsDataURL(blob);
      });
    } catch (e) {
      console.error(e);
    }

    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const W = pdf.internal.pageSize.getWidth();

    // Border
    pdf.setDrawColor(180, 150, 80);
    pdf.setLineWidth(1.5);
    pdf.rect(10, 10, W - 20, 277);
    pdf.setLineWidth(0.3);
    pdf.rect(13, 13, W - 26, 271);

    // Header
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(10);
    pdf.setTextColor(120, 100, 60);
    pdf.text("AIME STAMP — CERTIFICAT D'AUTHENTICITÉ", W / 2, 28, { align: "center" });

    pdf.setFontSize(28);
    pdf.setTextColor(30, 30, 30);
    pdf.text("Certificat Numérique", W / 2, 50, { align: "center" });

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    pdf.setTextColor(100, 100, 100);
    pdf.text(
      "Ce document certifie l'authenticité et l'unicité du timbre suivant",
      W / 2,
      60,
      { align: "center" }
    );

    // Stamp image
    if (imgData) {
      pdf.addImage(imgData, "PNG", (W - 80) / 2, 75, 80, 80);
    }

    // Code
    pdf.setFont("courier", "bold");
    pdf.setFontSize(18);
    pdf.setTextColor(30, 30, 30);
    pdf.text(stamp.code || "—", W / 2, 170, { align: "center" });

    // Details box
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    pdf.setTextColor(60, 60, 60);
    const details = [
      ["Texte du timbre", stamp.text || "—"],
      ["Couleur d'encre", stamp.color || "—"],
      ["Niveau d'usure", String(stamp.wear ?? "—")],
      ["Date d'émission", issuedStr],
      ["Signature", signature],
    ];
    let y = 180;
    details.forEach(([k, v]) => {
      pdf.setFont("helvetica", "bold");
      pdf.text(`${k} :`, 40, y);
      pdf.setFont("helvetica", "normal");
      pdf.text(String(v), 90, y);
      y += 6;
    });

    // QR code for verification (blockchain-style proof)
    try {
      const qrData = await QRCode.toDataURL(verifyUrl, {
        margin: 0,
        width: 256,
        color: { dark: "#1a1a1a", light: "#ffffff" },
      });
      pdf.addImage(qrData, "PNG", W / 2 - 15, 222, 30, 30);
    } catch (e) {
      console.error(e);
    }

    // Verification line
    pdf.setFontSize(8);
    pdf.setTextColor(120, 120, 120);
    pdf.text(
      `Scannez le QR code · ${verifyUrl}`,
      W / 2,
      258,
      { align: "center" }
    );

    pdf.setFontSize(7);
    pdf.text(
      "Ce certificat atteste que le code AIME ci-dessus correspond à un timbre unique généré par AIME Stamp.",
      W / 2,
      264,
      { align: "center" }
    );

    pdf.save(`certificat-${stamp.code || Date.now()}.pdf`);
    setBusy(false);
  };

  return (
    <button
      onClick={handleDownload}
      disabled={busy}
      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-b from-amber-400/15 to-amber-600/10 border border-amber-300/30 text-sm text-amber-100 hover:from-amber-400/25 hover:to-amber-600/15 transition-all disabled:opacity-50"
    >
      {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Award className="w-4 h-4" />}
      Certificat
    </button>
  );
}