import React from "react";
import { Heart, Briefcase, PartyPopper, ListTodo, User, Tag } from "lucide-react";

export const CATEGORIES = [
  { id: "mariage", label: "Mariage", Icon: Heart, color: "text-pink-300" },
  { id: "prestataire", label: "Prestataire", Icon: Briefcase, color: "text-blue-300" },
  { id: "evenement", label: "Événement", Icon: PartyPopper, color: "text-purple-300" },
  { id: "tache", label: "Tâche", Icon: ListTodo, color: "text-amber-300" },
  { id: "personnel", label: "Personnel", Icon: User, color: "text-emerald-300" },
  { id: "autre", label: "Autre", Icon: Tag, color: "text-white/60" },
];

export default function CategoryPicker({ value, onChange }) {
  return (
    <div className="w-full flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl border border-white/10 bg-white/[0.02]">
      {CATEGORIES.map(({ id, label, Icon, color }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs transition-all ${
            value === id
              ? "bg-white text-black"
              : `${color} hover:bg-white/5`
          }`}
        >
          <Icon className="w-3 h-3" />
          {label}
        </button>
      ))}
    </div>
  );
}