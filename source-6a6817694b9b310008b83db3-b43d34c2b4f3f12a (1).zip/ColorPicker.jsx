import React from "react";

const COLORS = [
  { id: "red", label: "Rouge", hex: "#B22222" },
  { id: "black", label: "Noir", hex: "#111111" },
  { id: "blue", label: "Bleu", hex: "#1E3A8A" },
  { id: "gold", label: "Or", hex: "#C9A227", premium: true },
];

export default function ColorPicker({ color, onChange }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-full border border-white/10 bg-white/[0.02]">
      {COLORS.map((c) => (
        <button
          key={c.id}
          onClick={() => onChange(c.id)}
          title={c.label + (c.premium ? " (premium)" : "")}
          className={`relative w-6 h-6 rounded-full transition-all duration-300 ${
            color === c.id
              ? "ring-2 ring-white/80 ring-offset-2 ring-offset-black scale-110"
              : "ring-1 ring-white/10 hover:ring-white/40"
          }`}
          style={{ backgroundColor: c.hex }}
        >
          {c.premium && (
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-300 shadow-[0_0_8px_rgba(252,211,77,0.8)]" />
          )}
        </button>
      ))}
    </div>
  );
}