import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import MachineControlPanel from "./MachineControlPanel";

export default function StampMachine({
  loading,
  imageUrl,
  rotation = 0,
  code,
  controlProps,
}) {
  const ledColors = [
    "bg-red-500",
    "bg-amber-400",
    "bg-emerald-400",
    "bg-cyan-400",
    "bg-indigo-400",
    "bg-fuchsia-500",
  ];

  return (
    <div className="relative w-full max-w-xl mx-auto flex flex-col items-center">

      {/* 🌸 MACHINE BACKGROUND (image réaliste) */}
      <div className="relative w-full rounded-[40px] overflow-hidden shadow-[0_40px_120px_-20px_rgba(0,0,0,0.9)]">

        {/* IMAGE PRINCIPALE */}
        <div
          className="absolute inset-0 bg-center bg-cover"
          style={{
            backgroundImage: `url('/aime-machine-bg.png')`, // 🔥 remplace par ton image exportée
          }}
        />

        {/* OVERLAY NACRE */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-white/10 mix-blend-overlay pointer-events-none" />

        {/* REFLET HAUT */}
        <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />

        {/* GLOW CENTRAL */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[70%] h-[70%] rounded-full blur-3xl bg-amber-200/10" />
        </div>

        {/* CONTENU */}
        <div className="relative z-10 p-6 flex items-stretch gap-4">

          {/* LEDs gauche */}
          <SideLeds colors={ledColors} loading={loading} />

          {/* 🧠 CORE INTERFACE */}
          <div className="flex-1 rounded-2xl backdrop-blur-xl bg-black/60 border border-white/10 shadow-[inset_0_0_40px_rgba(0,0,0,0.8),0_0_20px_rgba(255,215,180,0.1)] p-4">

            {/* ANIMATION LENTE VIVANTE */}
            <motion.div
              animate={{ scale: [1, 1.015, 1] }}
              transition={{ duration: 6, repeat: Infinity }}
            >
              <MachineControlPanel loading={loading} {...controlProps} />
            </motion.div>

          </div>

          {/* LEDs droite */}
          <SideLeds colors={[...ledColors].reverse()} loading={loading} />
        </div>

        {/* SLOT IMPRESSION */}
        <div className="relative z-10 flex justify-center pb-0">
          <div className="w-2/3 h-5 bg-black rounded-t-md shadow-[inset_0_3px_8px_rgba(0,0,0,0.9)] border-t border-white/10 relative overflow-hidden">
            <AnimatePresence>
              {loading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.8, 0.3] }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="absolute inset-0 bg-gradient-to-t from-amber-300/40 to-transparent"
                />
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* 🧾 SORTIE TIMBRE */}
      <div className="relative w-full min-h-[18rem] -mt-2 flex justify-center">
        <AnimatePresence mode="wait">

          {imageUrl && !loading && (
            <motion.div
              key={imageUrl}
              initial={{ y: -80, opacity: 0, scale: 0.8 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="relative flex flex-col items-center pt-6"
            >
              <img
                src={imageUrl}
                alt="Stamp"
                crossOrigin="anonymous"
                style={{
                  transform: `rotate(${rotation}deg)`,
                  filter: "drop-shadow(0 20px 40px rgba(0,0,0,0.6))",
                }}
                className="w-56 h-56 object-contain"
              />

              {code && (
                <div className="mt-3 flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-white/[0.05] font-mono text-[11px] tracking-[0.25em] text-white/70 backdrop-blur-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {code}
                </div>
              )}
            </motion.div>
          )}

          {loading && (
            <motion.div
              key="printing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-2 flex flex-col items-center gap-2"
            >
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: 80 }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  repeatType: "reverse",
                }}
                className="w-24 bg-gradient-to-b from-amber-50 to-amber-100 rounded-b-sm shadow-md"
              />
              <p className="text-[10px] text-white/50 tracking-[0.2em] uppercase">
                Impression…
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

const SideLeds = ({ colors, loading }) => (
  <div className="flex flex-col items-center justify-center gap-2 py-2 px-2 rounded-xl bg-black/40 backdrop-blur-md border border-white/10">
    {colors.map((c, i) => (
      <motion.div
        key={i}
        className={`w-2 h-2 rounded-full ${c}`}
        animate={
          loading
            ? {
                opacity: [0.25, 1, 0.25],
                boxShadow: [
                  "0 0 0px currentColor",
                  "0 0 12px currentColor",
                  "0 0 0px currentColor",
                ],
              }
            : { opacity: 0.3 }
        }
        transition={{
          duration: 1.2,
          repeat: loading ? Infinity : 0,
          delay: i * 0.1,
        }}
      />
    ))}
  </div>
);