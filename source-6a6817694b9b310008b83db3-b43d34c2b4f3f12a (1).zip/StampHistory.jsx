import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { History, Trash2, Loader2 } from "lucide-react";

const WEAR_LABELS = ["Neuf", "Léger", "Usé", "Vieilli", "Très vieilli"];

export default function StampHistory({ refreshKey, onSelect }) {
  const [stamps, setStamps] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const list = await base44.entities.Stamp.list();
    const sorted = [...list].sort(
      (a, b) => new Date(b.created_date) - new Date(a.created_date)
    );
    setStamps(sorted.slice(0, 50));
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [refreshKey]);

  const handleDelete = async (e, id) => {
    e.stopPropagation();
    await base44.entities.Stamp.delete(id);
    setStamps((prev) => prev.filter((s) => s.id !== id));
  };

  if (loading) {
    return (
      <div className="w-full max-w-5xl mt-24 flex justify-center">
        <Loader2 className="w-5 h-5 animate-spin text-white/30" />
      </div>
    );
  }

  if (stamps.length === 0) return null;

  return (
    <div className="w-full max-w-5xl mt-24 relative z-10">
      <div className="flex items-center gap-2 mb-6 text-white/50">
        <History className="w-4 h-4" />
        <h2 className="text-xs uppercase tracking-[0.2em]">
          Historique ({stamps.length})
        </h2>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {stamps.map((stamp, idx) => (
          <motion.div
            key={stamp.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.03 }}
            onClick={() => onSelect?.(stamp)}
            className="group relative aspect-square rounded-xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/15 cursor-pointer transition-all overflow-hidden p-3"
          >
            <button
              onClick={(e) => handleDelete(e, stamp.id)}
              className="absolute top-2 right-2 z-10 p-1.5 rounded-full bg-black/60 border border-white/10 opacity-0 group-hover:opacity-100 hover:bg-red-500/80 transition-all"
              title="Supprimer"
            >
              <Trash2 className="w-3 h-3 text-white" />
            </button>

            <div className="w-full h-full flex items-center justify-center">
              <img
                src={stamp.image_url}
                alt={stamp.text}
                style={{
                  transform: `rotate(${stamp.rotation || 0}deg)`,
                }}
                className="max-w-full max-h-full object-contain transition-transform group-hover:scale-105"
              />
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/90 to-transparent">
              {stamp.code && (
                <p className="font-mono text-[9px] tracking-[0.15em] text-white/70 truncate">
                  {stamp.code}
                </p>
              )}
              <p className="text-[10px] text-white/40 truncate mt-0.5">
                {WEAR_LABELS[stamp.wear ?? 2]} · {stamp.color}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}