import React, { useState, useRef } from "react";
import { Upload, Download, X, Move, Stamp as StampIcon } from "lucide-react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";
import { base44 } from "@/api/base44Client";
import CancellationMark from "./CancellationMark";

export default function DocumentEditor({ stampUrl, rotation }) {
  const [docUrl, setDocUrl] = useState(null);
  const [docType, setDocType] = useState(null); // 'image' | 'pdf'
  const [stampPos, setStampPos] = useState({ x: 50, y: 50 }); // % position
  const [stampSize, setStampSize] = useState(30); // % of doc width
  const [dragging, setDragging] = useState(null); // null | 'stamp' | 'cancel'
  const [uploading, setUploading] = useState(false);
  const [showCancel, setShowCancel] = useState(false);
  const [cancelPos, setCancelPos] = useState({ x: 60, y: 45 });
  const [cancelCity, setCancelCity] = useState("PARIS");
  const containerRef = useRef(null);
  const fileInputRef = useRef(null);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const isPdf = file.type === "application/pdf";
      if (isPdf) {
        // Upload PDF and convert first page to image via Base44
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setDocUrl(file_url);
        setDocType("pdf");
      } else {
        const reader = new FileReader();
        reader.onloadend = () => {
          setDocUrl(reader.result);
          setDocType("image");
          setUploading(false);
        };
        reader.readAsDataURL(file);
        return;
      }
    } catch (err) {
      console.error(err);
    }
    setUploading(false);
  };

  const handlePointerDown = (which) => (e) => {
    setDragging(which);
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e) => {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    const clamped = {
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y)),
    };
    if (dragging === "stamp") setStampPos(clamped);
    else if (dragging === "cancel") setCancelPos(clamped);
  };

  const handlePointerUp = (e) => {
    setDragging(null);
    e.currentTarget.releasePointerCapture(e.pointerId);
  };

  const handleDownloadPNG = async () => {
    if (!containerRef.current) return;
    const canvas = await html2canvas(containerRef.current, {
      backgroundColor: "#ffffff",
      useCORS: true,
      scale: 2,
    });
    canvas.toBlob((blob) => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `document-stamped-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
    });
  };

  const handleDownloadPDF = async () => {
    if (!containerRef.current) return;
    const canvas = await html2canvas(containerRef.current, {
      backgroundColor: "#ffffff",
      useCORS: true,
      scale: 2,
    });
    const imgData = canvas.toDataURL("image/png");
    const orientation = canvas.width > canvas.height ? "landscape" : "portrait";
    const pdf = new jsPDF({ orientation, unit: "mm", format: "a4" });
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    const ratio = Math.min(pageW / canvas.width, pageH / canvas.height);
    const w = canvas.width * ratio;
    const h = canvas.height * ratio;
    pdf.addImage(imgData, "PNG", (pageW - w) / 2, (pageH - h) / 2, w, h);
    pdf.save(`document-stamped-${Date.now()}.pdf`);
  };

  const handleReset = () => {
    setDocUrl(null);
    setDocType(null);
    setStampPos({ x: 50, y: 50 });
  };

  if (!docUrl) {
    return (
      <div className="w-full mt-6">
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="w-full py-6 rounded-2xl border-2 border-dashed border-white/15 bg-white/[0.02] hover:border-white/30 hover:bg-white/[0.04] transition-all flex flex-col items-center gap-2 text-white/60"
        >
          <Upload className="w-5 h-5" />
          <span className="text-sm">
            {uploading ? "Chargement…" : "Importer un document (image ou PDF)"}
          </span>
          <span className="text-[11px] text-white/30">
            Pour placer votre timbre dessus
          </span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,application/pdf"
          onChange={handleUpload}
          className="hidden"
        />
      </div>
    );
  }

  return (
    <div className="w-full mt-6 flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full">
        <span className="text-[11px] text-white/40 uppercase tracking-[0.15em]">
          <Move className="w-3 h-3 inline mr-1" />
          Glissez le timbre sur le document
        </span>
        <button
          onClick={handleReset}
          className="text-white/40 hover:text-white/80 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div
        ref={containerRef}
        className="relative w-full max-w-2xl bg-white rounded-xl overflow-hidden shadow-2xl"
        style={{ aspectRatio: "1 / 1.414" }}
      >
        {docType === "image" ? (
          <img
            src={docUrl}
            alt="Document"
            className="w-full h-full object-contain"
            draggable={false}
          />
        ) : (
          <iframe
            src={docUrl}
            title="Document PDF"
            className="w-full h-full pointer-events-none"
          />
        )}

        {/* Draggable stamp */}
        <div
          onPointerDown={handlePointerDown("stamp")}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          style={{
            position: "absolute",
            left: `${stampPos.x}%`,
            top: `${stampPos.y}%`,
            width: `${stampSize}%`,
            transform: `translate(-50%, -50%) rotate(${rotation}deg)`,
            cursor: dragging === "stamp" ? "grabbing" : "grab",
            touchAction: "none",
          }}
        >
          <img
            src={stampUrl}
            alt="Stamp"
            className="w-full h-auto select-none pointer-events-none"
            draggable={false}
            style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.15))" }}
          />
        </div>

        {/* Draggable cancellation mark */}
        {showCancel && (
          <div
            onPointerDown={handlePointerDown("cancel")}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            style={{
              position: "absolute",
              left: `${cancelPos.x}%`,
              top: `${cancelPos.y}%`,
              transform: `translate(-50%, -50%) rotate(-12deg)`,
              cursor: dragging === "cancel" ? "grabbing" : "grab",
              touchAction: "none",
            }}
          >
            <CancellationMark city={cancelCity} size={Math.max(80, stampSize * 4)} />
          </div>
        )}
      </div>

      {/* Cancellation mark toggle */}
      <div className="w-full max-w-md flex items-center gap-3 flex-wrap justify-center">
        <button
          onClick={() => setShowCancel((v) => !v)}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border text-xs transition-all ${
            showCancel
              ? "bg-white text-black border-white"
              : "bg-white/5 text-white/70 border-white/10 hover:bg-white/10"
          }`}
        >
          <StampIcon className="w-3.5 h-3.5" />
          Oblitération
        </button>
        {showCancel && (
          <input
            value={cancelCity}
            onChange={(e) => setCancelCity(e.target.value)}
            placeholder="Ville"
            maxLength={15}
            className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-white/90 placeholder:text-white/30 focus:outline-none focus:border-white/30 w-32"
          />
        )}
      </div>

      {/* Size slider */}
      <div className="w-full max-w-xs flex items-center gap-3">
        <span className="text-[10px] uppercase tracking-[0.15em] text-white/40">
          Taille
        </span>
        <input
          type="range"
          min={10}
          max={70}
          value={stampSize}
          onChange={(e) => setStampSize(Number(e.target.value))}
          className="flex-1 h-1 appearance-none bg-white/10 rounded-full cursor-pointer
            [&::-webkit-slider-thumb]:appearance-none
            [&::-webkit-slider-thumb]:w-3
            [&::-webkit-slider-thumb]:h-3
            [&::-webkit-slider-thumb]:rounded-full
            [&::-webkit-slider-thumb]:bg-white"
        />
      </div>

      <div className="flex gap-3">
        <button
          onClick={handleDownloadPNG}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white/80 hover:bg-white/10 hover:text-white transition-all"
        >
          <Download className="w-4 h-4" />
          Document PNG
        </button>
        <button
          onClick={handleDownloadPDF}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white/80 hover:bg-white/10 hover:text-white transition-all"
        >
          <Download className="w-4 h-4" />
          Document PDF
        </button>
      </div>
    </div>
  );
}