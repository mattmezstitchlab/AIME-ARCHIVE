import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router';
import { CaseList, Case } from '../components/CaseList';
import { PersonCard, Person } from '../components/PersonCard';
import { Timeline, TimelineEvent } from '../components/Timeline';
import { IntelligentAnalysis } from '../components/IntelligentAnalysis';
import { CreateDossierModal } from '../components/CreateDossierModal';
import { AddEventModal } from '../components/AddEventModal';
import { EditPersonModal } from '../components/EditPersonModal';
import { extractTextFromImage, interpretText } from '../components/ocr';
import { Activity, ArrowLeft, Zap } from 'lucide-react';

const API = '/api';
const authHeaders = {
  'Content-Type': 'application/json',
  Authorization: 'Bearer public',
};

type Priority = 'Prioritaire' | 'Alerte' | 'Cohérent';

type ServerDossier = {
  id: string;
  name: string;
  relationStatus: Person['relationStatus'];
  participation: Person['participation'];
  // MSA extended
  statut_pro?: string | null;
  participation_agricole?: string | null;
  createdAt: string;
  updatedAt: string;
  priority?: Priority;
};

const priorityToStatus: Record<Priority, Case['status']> = {
  Prioritaire: 'critical',
  Alerte:      'warning',
  Cohérent:    'coherent',
};

type ServerEvent = {
  id: string;
  dossierId: string;
  type: TimelineEvent['type'];
  date: string;
  description: string;
  metadata?: Record<string, unknown>;
};

type ServerDocument = {
  id: string;
  name: string;
  status: 'manquant' | 'reçu' | 'validé';
};

type ServerAnalysis = {
  status: 'coherent' | 'warning' | 'critical';
  suggestions: string[];
  actions: string[];
};

type DossierDetail = {
  dossier: ServerDossier;
  events: ServerEvent[];
  documents: ServerDocument[];
  analysis: ServerAnalysis;
};

function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "À l'instant";
  if (m < 60) return `Il y a ${m}min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `Il y a ${h}h`;
  return `Il y a ${Math.floor(h / 24)}j`;
}

function formatDateFr(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

const HEADER_H = 61;

export default function Dashboard() {
  const [dossiers, setDossiers] = useState<ServerDossier[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<DossierDetail | null>(null);
  const [search, setSearch] = useState('');
  const [loadingList, setLoadingList] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ocrStatus, setOcrStatus] = useState<string | null>(null);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAddEventModal, setShowAddEventModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  const loadDossiers = async (selectFirst = false) => {
    setLoadingList(true);
    try {
      const res = await fetch(`${API}/dossiers`, { headers: authHeaders });
      if (!res.ok) throw new Error(`Liste dossiers: ${res.status} ${await res.text()}`);
      const data = await res.json();
      setDossiers(data.dossiers ?? []);
      if (selectFirst && data.dossiers?.length && !selectedId) {
        setSelectedId(data.dossiers[0].id);
      }
    } catch (err) {
      console.log('loadDossiers error:', err);
      setError(String(err));
    } finally {
      setLoadingList(false);
    }
  };

  const loadDetail = async (id: string) => {
    setLoadingDetail(true);
    try {
      const res = await fetch(`${API}/dossiers/${id}`, { headers: authHeaders });
      if (!res.ok) throw new Error(`Détail dossier: ${res.status} ${await res.text()}`);
      setDetail((await res.json()) as DossierDetail);
    } catch (err) {
      console.log('loadDetail error:', err);
      setError(String(err));
    } finally {
      setLoadingDetail(false);
    }
  };

  useEffect(() => {
    (async () => {
      try { await fetch(`${API}/seed`, { method: 'POST', headers: authHeaders }); } catch {}
      await loadDossiers(true);
    })();
  }, []);

  useEffect(() => {
    if (selectedId) loadDetail(selectedId);
    else setDetail(null);
  }, [selectedId]);

  const handleCreate = async (data: { name: string; relationStatus: string; participation: string }) => {
    const res = await fetch(`${API}/dossiers`, {
      method: 'POST', headers: authHeaders, body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`Création: ${res.status} ${await res.text()}`);
    const body = await res.json();
    await loadDossiers();
    setSelectedId(body.dossier.id);
  };

  const handleUpdatePerson = async (data: { name: string; relationStatus: string; participation: string }) => {
    if (!selectedId) return;
    const res = await fetch(`${API}/dossiers/${selectedId}`, {
      method: 'PUT', headers: authHeaders, body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`Mise à jour: ${res.status} ${await res.text()}`);
    await loadDetail(selectedId);
    await loadDossiers();
  };

  const handleAddEvent = async (data: { type: TimelineEvent['type']; date: string; description: string }) => {
    if (!selectedId) return;
    const res = await fetch(`${API}/dossiers/${selectedId}/events`, {
      method: 'POST', headers: authHeaders, body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`Ajout événement: ${res.status} ${await res.text()}`);
    await loadDetail(selectedId);
    await loadDossiers();
  };

  const handleDeleteEvent = async (eventId: string) => {
    if (!selectedId) return;
    try {
      const res = await fetch(`${API}/dossiers/${selectedId}/events/${eventId}`, {
        method: 'DELETE', headers: authHeaders,
      });
      if (!res.ok) throw new Error(`Suppression: ${res.status} ${await res.text()}`);
      await loadDetail(selectedId);
      await loadDossiers();
    } catch (err) { setError(String(err)); }
  };

  const handleOCRUpload = async (file: File) => {
    if (!selectedId) return;
    setOcrStatus(`Lecture OCR de "${file.name}"…`);
    try {
      const text = await extractTextFromImage(file);
      const detected = interpretText(text);
      if (!detected.length) {
        setOcrStatus('OCR terminé · aucun événement détecté');
        setTimeout(() => setOcrStatus(null), 4000);
        return;
      }
      const today = new Date().toISOString().slice(0, 10);
      for (const ev of detected) {
        const res = await fetch(`${API}/dossiers/${selectedId}/events`, {
          method: 'POST', headers: authHeaders, body: JSON.stringify({ ...ev, date: today }),
        });
        if (!res.ok) throw new Error(`OCR insert: ${res.status} ${await res.text()}`);
      }
      setOcrStatus(`✓ ${detected.length} événement(s) détecté(s)`);
      setTimeout(() => setOcrStatus(null), 5000);
      await loadDetail(selectedId);
      await loadDossiers();
    } catch (err) { setError(String(err)); setOcrStatus(null); }
  };

  const handleAddDocument = async (name: string) => {
    if (!selectedId) return;
    try {
      const res = await fetch(`${API}/dossiers/${selectedId}/documents`, {
        method: 'POST', headers: authHeaders, body: JSON.stringify({ name, status: 'manquant' }),
      });
      if (!res.ok) throw new Error(`Ajout document: ${res.status} ${await res.text()}`);
      await loadDetail(selectedId);
    } catch (err) { setError(String(err)); }
  };

  const handleUpdateDocStatus = async (docId: string, status: 'reçu' | 'manquant' | 'validé') => {
    if (!selectedId) return;
    try {
      const res = await fetch(`${API}/dossiers/${selectedId}/documents/${docId}`, {
        method: 'PATCH', headers: authHeaders, body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error(`Mise à jour doc: ${res.status} ${await res.text()}`);
      await loadDetail(selectedId);
    } catch (err) { setError(String(err)); }
  };

  const handleDeleteDocument = async (docId: string) => {
    if (!selectedId) return;
    try {
      const res = await fetch(`${API}/dossiers/${selectedId}/documents/${docId}`, {
        method: 'DELETE', headers: authHeaders,
      });
      if (!res.ok) throw new Error(`Suppression doc: ${res.status} ${await res.text()}`);
      await loadDetail(selectedId);
    } catch (err) { setError(String(err)); }
  };

  const cases: Case[] = useMemo(() => {
    const q = search.trim().toLowerCase();
    return dossiers
      .filter((d) => !q || d.name.toLowerCase().includes(q))
      .map((d) => ({
        id: d.id,
        name: d.name,
        status: d.priority ? priorityToStatus[d.priority] : 'coherent',
        lastUpdate: relativeTime(d.updatedAt ?? d.createdAt),
      }));
  }, [dossiers, search]);

  const priorityCounts = useMemo(() => ({
    critical: dossiers.filter((d) => d.priority === 'Prioritaire').length,
    warning:  dossiers.filter((d) => d.priority === 'Alerte').length,
  }), [dossiers]);

  const person: Person | null = detail
    ? {
        name: detail.dossier.name,
        relationStatus: detail.dossier.relationStatus,
        participation: detail.dossier.participation,
        statut_pro: detail.dossier.statut_pro,
        participation_agricole: detail.dossier.participation_agricole,
      }
    : null;

  const events: TimelineEvent[] = detail
    ? detail.events.map((e) => ({
        id: e.id,
        type: e.type,
        date: formatDateFr(e.date),
        description: e.description,
        metadata: e.metadata,
      }))
    : [];

  const stickyStyle = { top: `${HEADER_H}px`, height: `calc(100vh - ${HEADER_H}px)` };

  return (
    // Pure white, no dark mode — matches landing's aesthetic
    <div className="w-full min-h-screen bg-[#FAFAFA] text-black">

      {/* ── Header — same style as landing nav ── */}
      <header
        className="sticky top-0 z-30 bg-white/90 backdrop-blur-xl border-b border-gray-100 px-6"
        style={{ height: `${HEADER_H}px` }}
      >
        <div className="flex items-center justify-between gap-4 h-full">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="flex items-center justify-center w-7 h-7 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Accueil"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-gray-400" />
            </Link>
            <div className="w-7 h-7 rounded-lg bg-black flex items-center justify-center flex-shrink-0">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-black font-bold tracking-tight">ORBIT</span>
              <span className="hidden sm:block text-gray-300">·</span>
              <span className="hidden sm:block text-xs text-gray-400 tracking-wide">
                Pilotage des dossiers humains
              </span>
            </div>
          </div>

          {/* Stats */}
          {!loadingList && dossiers.length > 0 && (
            <div className="hidden md:flex items-center gap-5 text-xs">
              <span className="text-gray-500">
                <span className="font-semibold text-black">{dossiers.length.toLocaleString('fr-FR')}</span>{' '}
                dossiers
              </span>
              {priorityCounts.critical > 0 && (
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-black" />
                  <span className="font-semibold text-black">{priorityCounts.critical}</span>
                  <span className="text-gray-400">prioritaire{priorityCounts.critical > 1 ? 's' : ''}</span>
                </span>
              )}
              {priorityCounts.warning > 0 && (
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-500" />
                  <span className="font-semibold text-gray-700">{priorityCounts.warning}</span>
                  <span className="text-gray-400">alerte{priorityCounts.warning > 1 ? 's' : ''}</span>
                </span>
              )}
            </div>
          )}
        </div>
      </header>

      {/* Error bar */}
      {error && (
        <div className="bg-black text-white px-6 py-2 text-sm flex items-center justify-between z-20 relative">
          <span className="truncate">{error}</span>
          <button onClick={() => setError(null)} className="ml-4 underline hover:no-underline flex-shrink-0">
            Fermer
          </button>
        </div>
      )}

      {/* ── 3-column layout — page scrolls, sidebars sticky ── */}
      <div className="flex">

        {/* LEFT */}
        <aside className="sticky self-start flex-shrink-0 w-72 xl:w-80 overflow-hidden" style={stickyStyle}>
          <CaseList
            cases={cases}
            selectedId={selectedId ?? ''}
            onSelect={setSelectedId}
            search={search}
            onSearchChange={setSearch}
            onCreate={() => setShowCreateModal(true)}
            loading={loadingList}
          />
        </aside>

        {/* CENTER — page scrolls */}
        <main className="flex-1 min-w-0 px-10 py-10">
          {loadingDetail && !detail && (
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-8">
              <div className="w-4 h-4 rounded-full border-2 border-gray-200 border-t-black animate-spin" />
              Chargement du dossier…
            </div>
          )}

          {person && (
            <>
              <PersonCard
                person={person}
                onEdit={() => setShowEditModal(true)}
                eventCount={events.length}
                documentCount={detail?.documents.length}
              />
              <Timeline
                events={events}
                onAddEvent={() => setShowAddEventModal(true)}
                onDeleteEvent={handleDeleteEvent}
              />
              <div className="h-24" />
            </>
          )}

          {!loadingDetail && !person && !loadingList && (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
              <div className="w-20 h-20 rounded-3xl bg-gray-100 flex items-center justify-center mb-6">
                <Activity className="w-10 h-10 text-gray-300" />
              </div>
              <h3 className="text-black font-bold text-lg tracking-tight mb-2">
                Aucun dossier sélectionné
              </h3>
              <p className="text-sm text-gray-500 max-w-xs">
                Sélectionnez un dossier dans la liste ou créez-en un nouveau pour commencer.
              </p>
            </div>
          )}
        </main>

        {/* RIGHT */}
        <aside className="sticky self-start flex-shrink-0 w-80 xl:w-96 overflow-hidden" style={stickyStyle}>
          <IntelligentAnalysis
            status={detail?.analysis.status ?? 'coherent'}
            suggestions={detail?.analysis.suggestions ?? []}
            actions={detail?.analysis.actions ?? []}
            documents={detail?.documents.map((d) => ({ id: d.id, name: d.name, status: d.status })) ?? []}
            onOCRUpload={handleOCRUpload}
            ocrStatus={ocrStatus}
            onAddDocument={handleAddDocument}
            onUpdateDocStatus={handleUpdateDocStatus}
            onDeleteDocument={handleDeleteDocument}
          />
        </aside>
      </div>

      {/* Modals */}
      <CreateDossierModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onCreate={handleCreate} />
      <AddEventModal open={showAddEventModal} onClose={() => setShowAddEventModal(false)} onAdd={handleAddEvent} />
      <EditPersonModal open={showEditModal} onClose={() => setShowEditModal(false)} person={person} onSave={handleUpdatePerson} />
    </div>
  );
}
