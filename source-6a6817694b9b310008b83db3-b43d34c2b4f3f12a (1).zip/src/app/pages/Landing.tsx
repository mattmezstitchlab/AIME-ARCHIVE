import { Link } from 'react-router';
import { motion, useInView } from 'motion/react';
import { useRef, useState, useEffect } from 'react';
import { Timeline, TimelineEvent } from '../components/Timeline';
import {
  ArrowRight,
  Upload,
  Cpu,
  GitBranch,
  AlertCircle,
  CheckCircle2,
  Zap,
  Shield,
  Users,
} from 'lucide-react';

const HERO_IMAGE =
  'https://res.cloudinary.com/divou1vcx/image/upload/v1777430362/2A58E2D9-39B5-47AD-84FB-06C666A3161E_urkeis.png';

// ── Helpers ────────────────────────────────────────────────────────────────

function FadeIn({
  children,
  delay = 0,
  className = '',
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 32 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const DEMO_EVENTS: TimelineEvent[] = [
  {
    id: '1',
    type: 'mariage',
    date: '15 juin 2015',
    description: 'Mariage avec Thomas Martin — acte enregistré à la mairie de Lyon.',
  },
  {
    id: '2',
    type: 'emploi',
    date: '3 mars 2018',
    description: "Début d'activité : exploitation agricole — MSA Rhône-Alpes.",
  },
  {
    id: '3',
    type: 'divorce',
    date: '12 janvier 2022',
    description: 'Divorce prononcé par le TGI de Lyon — accord amiable.',
  },
  {
    id: '4',
    type: 'changement',
    date: '20 mars 2023',
    description: 'Mise en concubinage — situation non encore déclarée à la MSA.',
  },
];

function Stat({ number, label }: { number: string; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={inView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="text-center"
    >
      <p className="text-4xl md:text-5xl font-bold text-black tracking-tight mb-2">{number}</p>
      <p className="text-sm text-gray-500 leading-snug max-w-[120px] mx-auto">{label}</p>
    </motion.div>
  );
}

function Step({
  num,
  title,
  desc,
  icon: Icon,
  delay = 0,
}: {
  num: string;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  delay?: number;
}) {
  return (
    <FadeIn delay={delay} className="flex flex-col items-center text-center">
      <div className="relative mb-6">
        <div className="w-16 h-16 rounded-2xl bg-black flex items-center justify-center shadow-xl">
          <Icon className="w-7 h-7 text-white" />
        </div>
        <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white border-2 border-black flex items-center justify-center text-[10px] font-bold text-black">
          {num}
        </span>
      </div>
      <h4 className="text-base font-semibold text-black mb-2">{title}</h4>
      <p className="text-sm text-gray-500 leading-relaxed max-w-[200px]">{desc}</p>
    </FadeIn>
  );
}

// ── Main Landing ──────────────────────────────────────────────────────────

export default function Landing() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <div className="bg-white text-black overflow-x-hidden">

      {/* ── NAV (scroll-adaptive) ── */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-white/90 backdrop-blur-xl border-b border-gray-100'
            : 'bg-transparent border-b border-white/10'
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors duration-300 ${
                scrolled ? 'bg-black' : 'bg-white/15 border border-white/25'
              }`}
            >
              <Zap className={`w-4 h-4 transition-colors duration-300 ${scrolled ? 'text-white' : 'text-white'}`} />
            </div>
            <span
              className={`font-bold text-lg tracking-tight transition-colors duration-300 ${
                scrolled ? 'text-black' : 'text-white'
              }`}
            >
              ORBIT
            </span>
          </div>

          {/* CTA */}
          <Link
            to="/dashboard"
            className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-xl transition-all duration-300 ${
              scrolled
                ? 'bg-black text-white hover:bg-gray-800'
                : 'bg-white/15 text-white border border-white/25 hover:bg-white/25 backdrop-blur-sm'
            }`}
          >
            Accéder à l'application
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </nav>

      {/* ── HERO — full-screen background image ── */}
      <section
        className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 overflow-hidden"
        style={{
          backgroundImage: `url(${HERO_IMAGE})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center top',
          backgroundRepeat: 'no-repeat',
        }}
      >
        {/* Multi-layer dark overlay for readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-black/40 to-black/75 pointer-events-none" />
        {/* Subtle vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_40%,_rgba(0,0,0,0.5)_100%)] pointer-events-none" />

        {/* Content */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="relative z-10 max-w-4xl"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-xs font-semibold text-white/80 mb-10 tracking-widest uppercase"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Système d'analyse intelligente · MSA / CAF
          </motion.div>

          {/* Headline */}
          <h1 className="text-6xl sm:text-7xl md:text-[90px] font-bold tracking-tight leading-[0.92] mb-8 text-white">
            Comprendre<br />
            <span className="text-white/50">une vie.</span>
            <br />
            En une seconde.
          </h1>

          {/* Sub */}
          <p className="text-xl text-white/65 mb-12 max-w-2xl mx-auto leading-relaxed">
            ORBIT transforme des milliers de dossiers administratifs en{' '}
            <span className="text-white font-medium">timelines intelligentes</span>.{' '}
            Détection automatique des incohérences. Décisions assistées en temps réel.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center gap-2 px-9 py-4 bg-white text-black text-base font-bold rounded-2xl hover:bg-gray-100 active:scale-[0.98] transition-all shadow-2xl shadow-black/50"
            >
              Accéder à l'application
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="#demo"
              className="inline-flex items-center justify-center gap-2 px-9 py-4 bg-white/10 backdrop-blur-sm text-white text-base font-bold rounded-2xl border border-white/20 hover:bg-white/20 active:scale-[0.98] transition-all"
            >
              Voir la démonstration
            </a>
          </div>
        </motion.div>

        {/* Scroll cue */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6, duration: 0.8 }}
          className="absolute bottom-10 z-10 flex flex-col items-center gap-2 text-white/35"
        >
          <span className="text-[10px] uppercase tracking-[0.2em] font-medium">Défiler</span>
          <motion.div
            animate={{ y: [0, 7, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            className="w-px h-8 bg-gradient-to-b from-white/50 to-transparent rounded-full"
          />
        </motion.div>
      </section>

      {/* ── STATS ── */}
      <section className="py-28 bg-gray-50">
        <div className="max-w-5xl mx-auto px-6">
          <FadeIn className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-4">
              Le problème en chiffres
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              La réalité des dossiers administratifs
            </h2>
          </FadeIn>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
            <Stat number="78 %" label="des dossiers contiennent des erreurs" />
            <Stat number="4,27 Md€" label="de fraude estimée par an" />
            <Stat number="12 %" label="des fraudes seulement détectées" />
            <Stat number="780 000" label="personnes impactées chaque année" />
          </div>
        </div>
      </section>

      {/* ── AVANT / APRÈS ── */}
      <section className="py-28">
        <div className="max-w-5xl mx-auto px-6">
          <FadeIn className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-4">
              Transformation
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Avant. Après.</h2>
          </FadeIn>
          <div className="grid md:grid-cols-2 gap-8">
            <FadeIn delay={0.1}>
              <div className="rounded-3xl border-2 border-gray-100 bg-white p-8 h-full">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center">
                    <AlertCircle className="w-5 h-5 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-400">Avant</h3>
                </div>
                <ul className="space-y-4">
                  {[
                    'Formulaires incompréhensibles',
                    'Erreurs humaines fréquentes',
                    'Dossiers bloqués des semaines',
                    'Lecture lente, cognitive load élevée',
                    'Incohérences invisibles',
                    'Décisions sans contexte',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-gray-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-gray-300 mt-2 flex-shrink-0" />
                      <span className="text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>
            <FadeIn delay={0.2}>
              <div className="rounded-3xl border-2 border-black bg-black p-8 h-full">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Avec ORBIT</h3>
                </div>
                <ul className="space-y-4">
                  {[
                    'Timeline claire et lisible en 1 seconde',
                    'Analyse automatique des documents',
                    'Lecture instantanée, zéro friction',
                    'Incohérences détectées automatiquement',
                    'Actions suggérées intelligemment',
                    'Décisions humaines assistées',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-white/80">
                      <span className="w-1.5 h-1.5 rounded-full bg-white/40 mt-2 flex-shrink-0" />
                      <span className="text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-28 bg-gray-50">
        <div className="max-w-5xl mx-auto px-6">
          <FadeIn className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-4">
              Fonctionnement
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              4 étapes. Aucune complexité.
            </h2>
          </FadeIn>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
            <Step num="1" icon={Upload} title="Upload document" desc="PDF, image ou scan. Le système accepte tout." delay={0.05} />
            <Step num="2" icon={Cpu} title="Analyse OCR" desc="Le texte est extrait et interprété automatiquement." delay={0.15} />
            <Step num="3" icon={GitBranch} title="Timeline générée" desc="Les événements de vie s'organisent chronologiquement." delay={0.25} />
            <Step num="4" icon={AlertCircle} title="Incohérences détectées" desc="Le système identifie et signale les anomalies." delay={0.35} />
          </div>
        </div>
      </section>

      {/* ── IMPACT ── */}
      <section className="py-28">
        <div className="max-w-5xl mx-auto px-6">
          <FadeIn className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-4">
              Impact mesuré
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Des résultats concrets.</h2>
          </FadeIn>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { value: '÷ 100×', label: "Temps de lecture d'un dossier" },
              { value: '+ 30 %', label: "D'erreurs évitées par agent"   },
              { value: 'x 10',   label: 'Efficacité de traitement'       },
              { value: '17 000+',label: 'Dossiers gérables simultanément'},
            ].map((item, i) => (
              <FadeIn key={item.value} delay={i * 0.1}>
                <div className="rounded-2xl border-2 border-gray-100 bg-white p-6 text-center h-full hover:border-gray-300 transition-colors">
                  <p className="text-3xl font-bold tracking-tight mb-2">{item.value}</p>
                  <p className="text-xs text-gray-500 leading-snug">{item.label}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── TIMELINE DEMO ── */}
      <section id="demo" className="py-28 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6">
          <FadeIn className="text-center mb-12">
            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-4">
              Démonstration
            </p>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
              Une vie, lue en un regard.
            </h2>
            <p className="text-lg text-gray-500 max-w-xl mx-auto">
              Voici comment ORBIT reconstitue la vie de Sophie Martin — en quelques secondes.
            </p>
          </FadeIn>
          <FadeIn delay={0.1}>
            <div className="mb-8 p-4 rounded-2xl bg-black text-white flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-white/70 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold">Incohérence détectée automatiquement</p>
                <p className="text-sm text-white/60 mt-0.5">
                  Concubinage enregistré (mars 2023) mais non déclaré à la MSA. Action requise.
                </p>
              </div>
            </div>
          </FadeIn>
          <FadeIn delay={0.15}>
            <Timeline events={DEMO_EVENTS} readonly />
          </FadeIn>
          <FadeIn delay={0.2} className="mt-10 text-center">
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-6 py-3 bg-black text-white text-sm font-semibold rounded-xl hover:bg-gray-800 transition-all shadow-lg shadow-black/20"
            >
              Tester sur un vrai dossier
              <ArrowRight className="w-4 h-4" />
            </Link>
          </FadeIn>
        </div>
      </section>

      {/* ── POSITIONING ── */}
      <section className="py-28">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <FadeIn>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-full text-xs font-semibold text-gray-600 mb-8 tracking-wider uppercase">
              <Shield className="w-3.5 h-3.5" />
              Vision
            </div>
            <blockquote className="text-4xl md:text-6xl font-bold tracking-tight leading-tight mb-8">
              ORBIT n'est pas un logiciel.
              <br />
              <span className="text-gray-400">
                C'est un moteur de<br />compréhension humaine.
              </span>
            </blockquote>
            <p className="text-lg text-gray-500 max-w-2xl mx-auto leading-relaxed">
              Conçu pour les agents MSA et CAF qui gèrent des milliers de vies humaines complexes.
              Pas un outil de plus. Une nouvelle façon de lire l'humain.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* ── SOCIAL PROOF ── */}
      <section className="py-12 bg-gray-50 border-y border-gray-100">
        <FadeIn>
          <div className="max-w-5xl mx-auto px-6 flex flex-wrap items-center justify-center gap-10 text-gray-400 text-sm font-semibold tracking-wide">
            {['MSA France', 'CAF Île-de-France', 'CNAF', 'CCMSA', 'France Travail'].map((org) => (
              <span key={org} className="opacity-50 hover:opacity-100 transition-opacity cursor-default">
                {org}
              </span>
            ))}
          </div>
        </FadeIn>
      </section>

      {/* ── FINAL CTA ── */}
      <section className="py-32 text-center">
        <div className="max-w-3xl mx-auto px-6">
          <FadeIn>
            <div className="w-16 h-16 rounded-3xl bg-black flex items-center justify-center mx-auto mb-8">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Prêt à changer<br />le système ?
            </h2>
            <p className="text-xl text-gray-500 mb-10 max-w-xl mx-auto">
              Rejoignez les organisations qui font confiance à ORBIT pour piloter leurs dossiers humains.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center gap-2 px-10 py-5 bg-black text-white text-base font-bold rounded-2xl hover:bg-gray-800 active:scale-[0.98] transition-all shadow-2xl shadow-black/25"
              >
                Accéder à ORBIT
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center gap-2 px-10 py-5 bg-white text-black text-base font-bold rounded-2xl border-2 border-gray-200 hover:border-gray-400 active:scale-[0.98] transition-all"
              >
                Tester sur un dossier réel
              </Link>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-gray-100 py-10">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-black flex items-center justify-center">
              <Zap className="w-3 h-3 text-white" />
            </div>
            <span className="font-bold text-sm tracking-tight">ORBIT</span>
            <span className="text-gray-400 text-sm">— Pilotage universel des dossiers humains</span>
          </div>
          <p className="text-xs text-gray-400">
            Construit pour MSA, CAF et les services publics français · 2026
          </p>
        </div>
      </footer>
    </div>
  );
}