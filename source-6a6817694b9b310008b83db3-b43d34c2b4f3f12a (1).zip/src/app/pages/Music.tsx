import { useEffect, useState } from "react";
import { motion } from "motion/react";

type Track = {
  id: string;
  title: string;
  artist: string;
  energy: number; // pour animation
};

const MOCK_TRACKS: Track[] = [
  { id: "1", title: "Perfect", artist: "Ed Sheeran", energy: 0.4 },
  { id: "2", title: "All of Me", artist: "John Legend", energy: 0.3 },
  { id: "3", title: "I Wanna Dance With Somebody", artist: "Whitney Houston", energy: 0.8 },
  { id: "4", title: "Titanium", artist: "David Guetta", energy: 0.9 },
  { id: "5", title: "A Sky Full of Stars", artist: "Coldplay", energy: 0.7 },
];

export default function Music() {
  const [tracks, setTracks] = useState<Track[]>(MOCK_TRACKS);

  // simulation flux mondial
  useEffect(() => {
    const interval = setInterval(() => {
      setTracks((prev) => {
        const newTrack: Track = {
          id: Math.random().toString(),
          title: ["Love Story", "Thinking Out Loud", "Can't Help Falling"][Math.floor(Math.random() * 3)],
          artist: ["Taylor Swift", "Elvis Presley", "Ed Sheeran"][Math.floor(Math.random() * 3)],
          energy: Math.random(),
        };
        return [newTrack, ...prev.slice(0, 7)];
      });
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">

      {/* HEADER */}
      <div className="p-6 border-b border-white/10">
        <h1 className="text-2xl font-semibold">
          🌍 Mariages en cours
        </h1>
        <p className="text-sm text-white/40 mt-1">
          Les musiques jouées en ce moment dans le monde
        </p>
      </div>

      {/* ZONE VIVANTE */}
      <div className="relative h-[calc(100vh-80px)]">

        {/* HALO GLOBAL */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 40, ease: "linear" }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-[600px] h-[600px] border border-white/5 rounded-full" />
        </motion.div>

        {/* TRACKS */}
        {tracks.map((track, i) => {
          const angle = (i / tracks.length) * 360;
          const radius = 120 + i * 30;

          return (
            <motion.div
              key={track.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute left-1/2 top-1/2"
              style={{
                transform: `rotate(${angle}deg) translate(${radius}px) rotate(-${angle}deg)`
              }}
            >
              <motion.div
                animate={{
                  scale: [1, 1 + track.energy * 0.3, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                }}
                className="bg-white/5 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10 shadow-lg"
              >
                <p className="text-sm font-medium">{track.title}</p>
                <p className="text-xs text-white/50">{track.artist}</p>
              </motion.div>
            </motion.div>
          );
        })}

        {/* CENTRE */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="w-32 h-32 rounded-full bg-white/10 backdrop-blur-xl flex items-center justify-center border border-white/20"
          >
            <span className="text-xs text-white/70 text-center">
              Flux<br />global
            </span>
          </motion.div>
        </div>
      </div>
    </div>
  );
}