import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import {
  TrendingUp, FileText, CheckCircle, Clock,
  Calendar, ChevronRight, Plus, ArrowUpRight,
} from 'lucide-react';
import { adminGet, fmtEur, fmtDate, QUOTE_STATUS, CONTRACT_STATUS, type AdminQuote, type AdminContract } from '../../lib/adminApi';

type Stats = {
  totalQuotes: number; pendingQuotes: number;
  confirmedContracts: number; totalRevenue: number;
  upcoming: AdminContract | null;
  recentQuotes: AdminQuote[];
  recentContracts: AdminContract[];
};

function StatCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string; sub?: string; color: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-bold text-black mb-1">{value}</p>
      <p className="text-xs font-semibold text-gray-800">{label}</p>
      {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
    </motion.div>
  );
}

export default function AdminDashboard() {
  const [stats,   setStats]   = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminGet('/stats')
      .then(r => r.json())
      .then(d => setStats(d))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-8 max-w-6xl mx-auto">

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-xs font-bold text-gray-400 tracking-[0.2em] uppercase mb-1">
            AIME Wedding OS
          </p>
          <h1
            style={{ fontFamily: "'Playfair Display', serif" }}
            className="text-3xl font-semibold text-black"
          >
            Bonjour, Matt 👋
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            {new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>
        <Link
          to="/admin/quotes"
          className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-800 transition-colors"
        >
          <Plus className="w-4 h-4" /> Nouveau devis
        </Link>
      </div>

      {/* Stats grid */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 p-6 h-36 animate-pulse">
              <div className="w-10 h-10 bg-gray-100 rounded-xl mb-4" />
              <div className="w-20 h-6 bg-gray-100 rounded mb-1" />
              <div className="w-28 h-3 bg-gray-100 rounded" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={FileText} label="Devis créés" value={String(stats?.totalQuotes ?? 0)}
            sub={`${stats?.pendingQuotes ?? 0} en attente`}
            color="bg-blue-50 text-blue-600"
          />
          <StatCard
            icon={CheckCircle} label="Contrats confirmés" value={String(stats?.confirmedContracts ?? 0)}
            color="bg-green-50 text-green-600"
          />
          <StatCard
            icon={TrendingUp} label="Chiffre d'affaires" value={fmtEur(stats?.totalRevenue ?? 0)}
            sub="contrats confirmés"
            color="bg-purple-50 text-purple-600"
          />
          <StatCard
            icon={Calendar} label="Prochain événement"
            value={stats?.upcoming ? fmtDate(stats.upcoming.eventDate) : '—'}
            sub={stats?.upcoming?.clientName}
            color="bg-orange-50 text-orange-600"
          />
        </div>
      )}

      {/* Next event banner */}
      {stats?.upcoming && (
        <motion.div
          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          className="bg-black text-white rounded-2xl p-5 mb-6 flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-white/50 font-medium uppercase tracking-wider mb-0.5">Prochain événement</p>
              <p className="font-semibold">{stats.upcoming.clientName} · {stats.upcoming.service}</p>
              <p className="text-sm text-white/60">{fmtDate(stats.upcoming.eventDate)} · {stats.upcoming.eventVenue}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm text-white/50">Montant</p>
              <p className="font-bold text-lg">{fmtEur(stats.upcoming.amount)}</p>
            </div>
            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${CONTRACT_STATUS[stats.upcoming.status].color}`}>
              {CONTRACT_STATUS[stats.upcoming.status].label}
            </span>
          </div>
        </motion.div>
      )}

      {/* Recent activity */}
      <div className="grid lg:grid-cols-2 gap-6">

        {/* Recent quotes */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-sm text-black">Derniers devis</h2>
            <Link to="/admin/quotes" className="text-xs text-gray-400 hover:text-black flex items-center gap-1 transition-colors">
              Voir tout <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
          {!stats?.recentQuotes?.length ? (
            <div className="p-8 text-center text-sm text-gray-400">
              Aucun devis pour l'instant.
              <Link to="/admin/quotes" className="block mt-2 text-black font-medium hover:underline">
                Créer le premier →
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {stats.recentQuotes.map(q => (
                <div key={q.id} className="px-5 py-3.5 flex items-center justify-between hover:bg-gray-50/50 transition-colors">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-black truncate">{q.clientName || '—'}</p>
                    <p className="text-xs text-gray-400">{fmtDate(q.eventDate)} · {q.service}</p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0 ml-3">
                    <span className="text-sm font-semibold text-black">{fmtEur(q.amount)}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${QUOTE_STATUS[q.status].color}`}>
                      {QUOTE_STATUS[q.status].label}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent contracts */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-sm text-black">Derniers contrats</h2>
            <Link to="/admin/quotes" className="text-xs text-gray-400 hover:text-black flex items-center gap-1 transition-colors">
              Voir tout <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
          {!stats?.recentContracts?.length ? (
            <div className="p-8 text-center text-sm text-gray-400">
              Aucun contrat généré.
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {stats.recentContracts.map(c => (
                <div key={c.id} className="px-5 py-3.5 flex items-center justify-between hover:bg-gray-50/50 transition-colors">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-black truncate">{c.clientName}</p>
                    <p className="text-xs text-gray-400">{fmtDate(c.eventDate)} · {c.eventVenue}</p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0 ml-3">
                    <span className="text-sm font-semibold text-black">{fmtEur(c.amount)}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${CONTRACT_STATUS[c.status].color}`}>
                      {CONTRACT_STATUS[c.status].label}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick links */}
      <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Mon profil',      to: '/admin/profile', desc: 'Matt Mez Sax' },
          { label: 'Nouveau devis',   to: '/admin/quotes',  desc: 'Pipeline commercial' },
          { label: 'Contenu site',    to: '/admin/content', desc: 'Textes & visuels' },
          { label: 'Config Cerise',   to: '/admin/cerise',  desc: 'Paramètres IA' },
        ].map(item => (
          <Link
            key={item.to}
            to={item.to}
            className="bg-white border border-gray-100 rounded-xl p-4 hover:border-gray-300 hover:shadow-sm transition-all group"
          >
            <div className="flex items-start justify-between mb-2">
              <p className="text-sm font-semibold text-black">{item.label}</p>
              <ArrowUpRight className="w-3.5 h-3.5 text-gray-300 group-hover:text-black transition-colors" />
            </div>
            <p className="text-xs text-gray-400">{item.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
