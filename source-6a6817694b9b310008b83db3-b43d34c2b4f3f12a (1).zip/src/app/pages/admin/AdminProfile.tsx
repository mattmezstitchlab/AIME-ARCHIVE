import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Trash2, Save, Globe, Check, Music2, Image } from 'lucide-react';
import { adminGet, adminPut, type AdminProfile } from '../../lib/adminApi';

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
        {label}
      </label>
      {children}
    </div>
  );
}

const inp = 'w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors bg-white';

export default function AdminProfile() {
  const [profile, setProfile] = useState<AdminProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [saved,   setSaved]   = useState(false);

  useEffect(() => {
    adminGet('/profile')
      .then(r => r.json())
      .then(d => setProfile(d.profile))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    if (!profile) return;
    setSaving(true);
    await adminPut('/profile', profile);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    setSaving(false);
  };

  const upd = (patch: Partial<AdminProfile>) =>
    setProfile(p => p ? { ...p, ...patch } : p);

  if (loading) return (
    <div className="p-8 flex items-center justify-center min-h-64">
      <div className="w-6 h-6 border-2 border-gray-200 border-t-gray-500 rounded-full animate-spin" />
    </div>
  );

  if (!profile) return null;

  return (
    <div className="p-8 max-w-4xl mx-auto">

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-xs font-bold text-gray-400 tracking-[0.2em] uppercase mb-1">Prestataire</p>
          <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-semibold text-black">
            Mon profil
          </h1>
          <p className="text-sm text-gray-500 mt-1">Fiche prestataire · Matt Mez Sax</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => upd({ published: !profile.published })}
            className={`flex items-center gap-2 text-xs font-semibold px-3.5 py-2 rounded-xl border transition-all ${
              profile.published
                ? 'bg-green-50 text-green-700 border-green-200'
                : 'bg-gray-50 text-gray-600 border-gray-200 hover:border-gray-400'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            {profile.published ? 'Publié' : 'Non publié'}
          </button>
          <button
            onClick={save} disabled={saving}
            className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-800 disabled:opacity-50 transition-all"
          >
            {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            {saving ? 'Sauvegarde…' : saved ? 'Sauvegardé !' : 'Sauvegarder'}
          </button>
        </div>
      </div>

      <div className="space-y-6">

        {/* ── Identité ─────────────────────────────────────────────────── */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center gap-2 mb-5">
            <Music2 className="w-4 h-4 text-gray-400" />
            <h2 className="text-sm font-semibold text-black">Identité</h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Nom artiste">
              <input className={inp} value={profile.name} onChange={e => upd({ name: e.target.value })} placeholder="Matt Mez Sax" />
            </Field>
            <Field label="Tagline">
              <input className={inp} value={profile.tagline} onChange={e => upd({ tagline: e.target.value })} placeholder="Saxophoniste & musicien…" />
            </Field>
            <Field label="Email">
              <input className={inp} type="email" value={profile.email ?? ''} onChange={e => upd({ email: e.target.value })} placeholder="matt@aime.fr" />
            </Field>
            <Field label="Téléphone">
              <input className={inp} value={profile.phone ?? ''} onChange={e => upd({ phone: e.target.value })} placeholder="+33 6 …" />
            </Field>
            <div className="sm:col-span-2">
              <Field label="Bio">
                <textarea
                  rows={4}
                  className={`${inp} resize-none`}
                  value={profile.bio}
                  onChange={e => upd({ bio: e.target.value })}
                  placeholder="Présentation, style musical, expérience…"
                />
              </Field>
            </div>
          </div>
        </section>

        {/* ── Services ─────────────────────────────────────────────────── */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-sm font-semibold text-black">Services</h2>
            <button
              onClick={() => upd({ services: [...profile.services, { id: uid(), title: '', description: '', price: 0 }] })}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 px-3 py-1.5 rounded-lg transition-all"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter
            </button>
          </div>
          <div className="space-y-3">
            {profile.services.map((svc, i) => (
              <motion.div
                key={svc.id}
                initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                className="flex gap-3 items-start bg-gray-50/70 rounded-xl p-3.5"
              >
                <div className="flex-1 grid sm:grid-cols-3 gap-2.5">
                  <input className={inp} value={svc.title} placeholder="Cocktail Sax" onChange={e => {
                    const s = [...profile.services]; s[i] = { ...s[i], title: e.target.value }; upd({ services: s });
                  }} />
                  <input className={inp} value={svc.description} placeholder="Description (durée…)" onChange={e => {
                    const s = [...profile.services]; s[i] = { ...s[i], description: e.target.value }; upd({ services: s });
                  }} />
                  <div className="relative">
                    <input
                      className={`${inp} pr-8`}
                      type="number" value={svc.price}
                      onChange={e => { const s = [...profile.services]; s[i] = { ...s[i], price: +e.target.value }; upd({ services: s }); }}
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">€</span>
                  </div>
                </div>
                <button
                  onClick={() => upd({ services: profile.services.filter((_, j) => j !== i) })}
                  className="p-2 text-gray-300 hover:text-red-500 transition-colors mt-0.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            ))}
            {!profile.services.length && (
              <p className="text-sm text-gray-400 text-center py-4">Aucun service. Ajoutez-en un.</p>
            )}
          </div>
        </section>

        {/* ── Tarifs ───────────────────────────────────────────────────── */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-sm font-semibold text-black">Suppléments & Frais</h2>
            <button
              onClick={() => upd({ tarifs: [...profile.tarifs, { id: uid(), label: '', price: 0, details: '' }] })}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 px-3 py-1.5 rounded-lg transition-all"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter
            </button>
          </div>
          <div className="space-y-2.5">
            {profile.tarifs.map((t, i) => (
              <div key={t.id} className="flex gap-2.5 items-center">
                <input className={`${inp} flex-1`} value={t.label} placeholder="Déplacement > 100km"
                  onChange={e => { const a = [...profile.tarifs]; a[i] = { ...a[i], label: e.target.value }; upd({ tarifs: a }); }} />
                <input className={`${inp} w-24`} type="number" value={t.price} placeholder="0"
                  onChange={e => { const a = [...profile.tarifs]; a[i] = { ...a[i], price: +e.target.value }; upd({ tarifs: a }); }} />
                <input className={`${inp} flex-1`} value={t.details} placeholder="Précisions…"
                  onChange={e => { const a = [...profile.tarifs]; a[i] = { ...a[i], details: e.target.value }; upd({ tarifs: a }); }} />
                <button onClick={() => upd({ tarifs: profile.tarifs.filter((_, j) => j !== i) })}
                  className="p-2 text-gray-300 hover:text-red-500 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {!profile.tarifs.length && (
              <p className="text-sm text-gray-400 text-center py-4">Aucun supplément.</p>
            )}
          </div>
        </section>

        {/* ── Galerie ──────────────────────────────────────────────────── */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Image className="w-4 h-4 text-gray-400" />
              <h2 className="text-sm font-semibold text-black">Galerie médias</h2>
            </div>
            <button
              onClick={() => upd({ gallery: [...profile.gallery, { id: uid(), type: 'image', url: '', caption: '' }] })}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-black border border-gray-200 hover:border-gray-400 px-3 py-1.5 rounded-lg transition-all"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter
            </button>
          </div>
          <div className="space-y-3">
            {profile.gallery.map((item, i) => (
              <div key={item.id} className="flex gap-3 items-start bg-gray-50/70 rounded-xl p-3.5">
                <select
                  value={item.type}
                  onChange={e => { const g = [...profile.gallery]; g[i] = { ...g[i], type: e.target.value as 'image' | 'video' | 'audio' }; upd({ gallery: g }); }}
                  className="border border-gray-200 rounded-xl px-2.5 py-2.5 text-xs text-gray-600 focus:outline-none bg-white w-24"
                >
                  <option value="image">🖼 Image</option>
                  <option value="video">🎬 Vidéo</option>
                  <option value="audio">🎵 Audio</option>
                </select>
                <input className={`${inp} flex-1`} value={item.url} placeholder="URL (Cloudinary, YouTube…)"
                  onChange={e => { const g = [...profile.gallery]; g[i] = { ...g[i], url: e.target.value }; upd({ gallery: g }); }} />
                <input className={`${inp} w-40`} value={item.caption ?? ''} placeholder="Légende"
                  onChange={e => { const g = [...profile.gallery]; g[i] = { ...g[i], caption: e.target.value }; upd({ gallery: g }); }} />
                <button onClick={() => upd({ gallery: profile.gallery.filter((_, j) => j !== i) })}
                  className="p-2 text-gray-300 hover:text-red-500 transition-colors mt-0.5">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {/* Aperçu images */}
            {profile.gallery.filter(g => g.type === 'image' && g.url).length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mt-4 pt-4 border-t border-gray-100">
                {profile.gallery.filter(g => g.type === 'image' && g.url).map(g => (
                  <img key={g.id} src={g.url} alt={g.caption} className="w-full aspect-square object-cover rounded-xl" />
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
