import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plus, FileText, FileSignature, CreditCard, CheckCheck,
  X, ChevronRight, Trash2, User, Calendar, MapPin, Clock,
  StickyNote, Copy, ExternalLink, Zap, RefreshCw, Bot,
  PenLine, AlertCircle, Check, Loader2,
} from 'lucide-react';
import {
  pipelineList, pipelineGet, pipelineCreate, pipelineAcceptQuote,
  pipelineRefuseQuote, pipelineSign, pipelineConfirmPayment, pipelineDelete,
  clientPortalUrl,
  STAGE_CONFIG, ACTOR_CONFIG, fmtEur, fmtDate, fmtTs,
  type PipelineDossier, type FullDossier, type PipelineLog,
} from '../../lib/pipelineApi';

// ── Helpers ───────────────────────────────────────────────────────────────────

const inp = 'w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm text-black focus:outline-none focus:border-gray-400 transition-colors bg-white';

const EMPTY_FORM = {
  clientName: '', clientEmail: '', clientPhone: '',
  eventDate: '', eventVenue: '', service: 'Matt Mez Sax',
  duration: 3, amount: 0, deposit: 0, notes: '',
};

// ── Pipeline Steps Bar ────────────────────────────────────────────────────────

const STEPS = ['Devis', 'Accepté', 'Contrat', 'Signé ×2', 'Paiement', 'Confirmé'];

function PipelineBar({ step }: { step: number }) {
  return (
    <div className="flex items-center gap-0.5 mb-6">
      {STEPS.map((label, i) => {
        const done    = i < step;
        const active  = i === step - 1;
        return (
          <div key={label} className="flex items-center gap-0.5 flex-1 min-w-0">
            <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
              done   ? 'bg-black text-white' :
              active ? 'bg-black text-white ring-2 ring-black ring-offset-2' :
                       'bg-gray-100 text-gray-400'
            }`}>
              {done ? <Check className="w-3 h-3" /> : i + 1}
            </div>
            <span className={`text-[9px] font-medium truncate hidden sm:block ${i < step ? 'text-black' : 'text-gray-400'}`}>{label}</span>
            {i < STEPS.length - 1 && (
              <div className={`h-px flex-1 min-w-1 transition-colors ${i < step - 1 ? 'bg-black' : 'bg-gray-200'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Log Timeline ──────────────────────────────────────────────────────────────

function LogTimeline({ logs }: { logs: PipelineLog[] }) {
  if (!logs.length) return (
    <div className="text-xs text-gray-400 py-4 text-center">Aucune action enregistrée</div>
  );
  return (
    <div className="space-y-0">
      {[...logs].reverse().map((log, i) => {
        const actor = ACTOR_CONFIG[log.actor] ?? ACTOR_CONFIG.system;
        return (
          <motion.div
            key={log.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.04 }}
            className="flex gap-3 py-2.5 border-b border-gray-50 last:border-0"
          >
            {/* Actor badge */}
            <div className={`flex-shrink-0 mt-0.5 w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold ${actor.color}`}>
              {actor.emoji}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <p className={`text-xs font-medium leading-snug ${log.auto ? 'text-violet-700' : 'text-black'}`}>
                  {log.auto && <span className="inline-flex items-center gap-0.5 mr-1 text-[9px] bg-violet-100 text-violet-600 px-1 py-0.5 rounded-full font-semibold">AUTO</span>}
                  {log.action}
                </p>
                <span className="text-[10px] text-gray-400 whitespace-nowrap flex-shrink-0">{fmtTs(log.timestamp)}</span>
              </div>
              {log.detail && <p className="text-[11px] text-gray-400 mt-0.5 truncate">{log.detail}</p>}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

// ── Contract Viewer ───────────────────────────────────────────────────────────

function ContractView({ full, onSign, signing }: {
  full: FullDossier;
  onSign: (party: 'client' | 'vendor') => void;
  signing: boolean;
}) {
  const { contract } = full;
  if (!contract) return null;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      {/* Contract header */}
      <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Contrat v{contract.version}</p>
            <p className="text-sm font-semibold text-black">
              {contract.service} · {fmtDate(contract.eventDate)}
            </p>
          </div>
          <span className={`text-[10px] px-2.5 py-1 rounded-xl font-semibold ${
            contract.status === 'fully_signed' ? 'bg-green-100 text-green-700' :
            contract.status === 'client_signed' ? 'bg-yellow-100 text-yellow-700' :
            'bg-gray-100 text-gray-500'
          }`}>
            {contract.status === 'fully_signed' ? 'Signé ×2' :
             contract.status === 'client_signed' ? 'Signé client' : 'En attente'}
          </span>
        </div>
      </div>

      {/* Parties */}
      <div className="px-6 py-4 border-b border-gray-100 grid grid-cols-2 gap-4">
        <div>
          <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Client</p>
          <p className="text-sm font-medium text-black">{contract.client.name}</p>
          <p className="text-xs text-gray-400">{contract.client.email}</p>
          {contract.client.phone && <p className="text-xs text-gray-400">{contract.client.phone}</p>}
        </div>
        <div>
          <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Prestataire</p>
          <p className="text-sm font-medium text-black">{contract.prestataire.name}</p>
          <p className="text-xs text-gray-400">{contract.prestataire.email}</p>
        </div>
      </div>

      {/* Financials */}
      <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-6">
        <div>
          <p className="text-[10px] text-gray-400 mb-0.5">Montant total</p>
          <p className="text-lg font-bold text-black">{fmtEur(contract.amount)}</p>
        </div>
        <div>
          <p className="text-[10px] text-gray-400 mb-0.5">Acompte ({contract.depositPercent}%)</p>
          <p className="text-base font-semibold text-black">{fmtEur(contract.deposit)}</p>
        </div>
        <div>
          <p className="text-[10px] text-gray-400 mb-0.5">Solde</p>
          <p className="text-base font-semibold text-black">{fmtEur(contract.amount - contract.deposit)}</p>
        </div>
      </div>

      {/* Conditions (collapsible) */}
      <details className="px-6 py-3 border-b border-gray-100">
        <summary className="text-xs font-semibold text-gray-500 cursor-pointer select-none">
          Conditions générales ({contract.conditions.length} articles)
        </summary>
        <ol className="mt-3 space-y-2">
          {contract.conditions.map((c, i) => (
            <li key={i} className="text-[11px] text-gray-600 leading-relaxed">
              <span className="font-semibold text-gray-400 mr-1">Art. {i + 1}.</span>{c}
            </li>
          ))}
        </ol>
      </details>

      {/* Signatures */}
      <div className="px-6 py-4 space-y-2.5">
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Signatures</p>

        {/* Client */}
        <div className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${
          contract.signatures.client ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
              contract.signatures.client ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
            }`}>
              {contract.signatures.client ? '✓' : '1'}
            </div>
            <div>
              <p className="text-xs font-medium text-black">Signature client</p>
              {contract.signatures.client && (
                <p className="text-[10px] text-gray-400">
                  {contract.signatures.client.name} · {fmtDate(contract.signatures.client.signedAt)}
                </p>
              )}
            </div>
          </div>
          {!contract.signatures.client && (
            <button onClick={() => onSign('client')} disabled={signing}
              className="text-xs font-semibold bg-black text-white px-3 py-1.5 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-1 disabled:opacity-50">
              {signing ? <Loader2 className="w-3 h-3 animate-spin" /> : <PenLine className="w-3 h-3" />} Signer
            </button>
          )}
        </div>

        {/* Vendor */}
        <div className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${
          contract.signatures.vendor ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
              contract.signatures.vendor ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
            }`}>
              {contract.signatures.vendor ? '✓' : '2'}
            </div>
            <div>
              <p className="text-xs font-medium text-black">Ma signature (Matt)</p>
              {contract.signatures.vendor && (
                <p className="text-[10px] text-gray-400">
                  {contract.signatures.vendor.name} · {fmtDate(contract.signatures.vendor.signedAt)}
                </p>
              )}
            </div>
          </div>
          {!contract.signatures.vendor && (
            <button onClick={() => onSign('vendor')} disabled={signing}
              className="text-xs font-semibold bg-black text-white px-3 py-1.5 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-1 disabled:opacity-50">
              {signing ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCheck className="w-3 h-3" />} Signer
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Payment Block ─────────────────────────────────────────────────────────────

function PaymentBlock({ full, onConfirm, confirming }: {
  full: FullDossier;
  onConfirm: () => void;
  confirming: boolean;
}) {
  const { payment } = full;
  if (!payment) return null;
  const paid = payment.status === 'paid';

  return (
    <div className={`rounded-2xl border overflow-hidden ${paid ? 'border-green-200 bg-green-50' : 'border-gray-100 bg-white'}`}>
      <div className="px-5 py-4">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Paiement acompte</p>
          <span className={`text-[10px] px-2.5 py-1 rounded-xl font-semibold ${
            paid ? 'bg-green-100 text-green-700' :
            payment.status === 'checkout_created' ? 'bg-indigo-100 text-indigo-700' :
            'bg-amber-100 text-amber-700'
          }`}>
            {paid ? '✓ Payé' : payment.status === 'checkout_created' ? 'Lien Stripe créé' : 'En attente'}
          </span>
        </div>
        <p className="text-2xl font-bold text-black mb-1">{fmtEur(payment.amountEur)}</p>
        {paid && payment.paidAt && (
          <p className="text-xs text-green-600">Reçu le {fmtDate(payment.paidAt)}</p>
        )}
      </div>

      {!paid && (
        <div className="px-5 pb-4 space-y-2.5">
          {payment.checkoutUrl && (
            <a href={payment.checkoutUrl} target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-colors">
              <ExternalLink className="w-3.5 h-3.5" /> Ouvrir le lien Stripe
            </a>
          )}
          <button onClick={onConfirm} disabled={confirming}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl transition-colors disabled:opacity-50">
            {confirming ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CreditCard className="w-3.5 h-3.5" />}
            Confirmer manuellement
          </button>
        </div>
      )}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function AdminPipeline() {
  const [list,     setList]     = useState<PipelineDossier[]>([]);
  const [selected, setSelected] = useState<FullDossier | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form,     setForm]     = useState(EMPTY_FORM);
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [signing,  setSigning]  = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [copied,   setCopied]   = useState(false);
  const [filter,   setFilter]   = useState<'all' | 'active' | 'confirmed'>('all');
  const [activeTab, setActiveTab] = useState<'detail' | 'contract' | 'logs'>('detail');

  const load = useCallback(async () => {
    try {
      const dossiers = await pipelineList();
      setList(dossiers);
    } catch (e) {
      console.error('Pipeline list error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const selectDossier = async (d: PipelineDossier) => {
    try {
      const full = await pipelineGet(d.id);
      setSelected(full);
      setShowForm(false);
      setActiveTab('detail');
    } catch (e) { console.error(e); }
  };

  const updForm = (patch: Partial<typeof EMPTY_FORM>) => {
    setForm(f => {
      const next = { ...f, ...patch };
      if ('amount' in patch && !('deposit' in patch))
        next.deposit = Math.round(next.amount * 0.3);
      return next;
    });
  };

  const handleCreate = async () => {
    if (!form.clientName || !form.eventDate) return;
    setSaving(true);
    try {
      const res = await pipelineCreate(form);
      await load();
      const full = await pipelineGet(res.dossier.id);
      setSelected(full);
      setShowForm(false);
      setForm(EMPTY_FORM);
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleAccept = async () => {
    if (!selected?.quote) return;
    setSaving(true);
    try {
      const full = await pipelineAcceptQuote(selected.quote.id);
      setSelected(full);
      setActiveTab('contract');
      await load();
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleRefuse = async () => {
    if (!selected?.quote) return;
    await pipelineRefuseQuote(selected.quote.id);
    await load();
    setSelected(null);
  };

  const handleSign = async (party: 'client' | 'vendor') => {
    if (!selected?.contract) return;
    setSigning(true);
    try {
      const full = await pipelineSign(selected.contract.id, party);
      setSelected(full);
      await load();
      // If both signed, switch to payment tab
      if (full.payment) setActiveTab('detail');
    } catch (e) { console.error(e); }
    setSigning(false);
  };

  const handleConfirmPayment = async () => {
    if (!selected?.payment) return;
    setConfirming(true);
    try {
      const full = await pipelineConfirmPayment(selected.payment.id);
      setSelected(full);
      await load();
    } catch (e) { console.error(e); }
    setConfirming(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce dossier ?')) return;
    await pipelineDelete(id);
    await load();
    if (selected?.dossier.id === id) setSelected(null);
  };

  const copyPortalLink = (token: string) => {
    navigator.clipboard.writeText(clientPortalUrl(token));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filtered list
  const filtered = list.filter(d => {
    if (filter === 'active')    return !['confirmed', 'cancelled'].includes(d.stage);
    if (filter === 'confirmed') return d.stage === 'confirmed';
    return true;
  });

  const stageConfig = selected ? STAGE_CONFIG[selected.dossier.stage] : null;
  const pipelineStep = stageConfig?.step ?? 0;

  return (
    <div className="flex h-full" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── LEFT: Dossier list ──────────────────────────────────────────────── */}
      <div className="w-72 flex-shrink-0 bg-white border-r border-gray-100 flex flex-col">

        {/* Header */}
        <div className="px-4 py-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="font-semibold text-sm text-black">Pipeline</h1>
              <p className="text-[10px] text-gray-400">{list.length} dossier{list.length > 1 ? 's' : ''}</p>
            </div>
            <button
              onClick={() => { setShowForm(true); setSelected(null); setForm(EMPTY_FORM); }}
              className="w-7 h-7 bg-black rounded-lg flex items-center justify-center hover:bg-gray-800 transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
          {/* Filter tabs */}
          <div className="flex bg-gray-100 rounded-xl p-0.5 text-[10px]">
            {(['all', 'active', 'confirmed'] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)}
                className={`flex-1 py-1.5 rounded-[10px] font-medium transition-all ${filter === f ? 'bg-white text-black shadow-sm' : 'text-gray-400'}`}>
                {f === 'all' ? 'Tous' : f === 'active' ? 'Actifs' : '✓ Confirmés'}
              </button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="p-4 space-y-2">
              {[...Array(4)].map((_, i) => <div key={i} className="h-16 bg-gray-50 rounded-xl animate-pulse" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-6 text-center text-xs text-gray-400">
              Aucun dossier.<br />
              <button onClick={() => setShowForm(true)} className="mt-2 text-black font-medium hover:underline">
                Créer le premier →
              </button>
            </div>
          ) : (
            filtered.map(d => {
              const sc = STAGE_CONFIG[d.stage];
              return (
                <button
                  key={d.id}
                  onClick={() => selectDossier(d)}
                  className={`w-full text-left px-4 py-3.5 border-b border-gray-50 hover:bg-gray-50/70 transition-colors ${
                    selected?.dossier.id === d.id ? 'bg-gray-50 border-l-2 border-l-black' : ''
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-black truncate">{d.clientName || 'Sans nom'}</p>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full flex-shrink-0 ml-1 font-semibold ${sc.color}`}>
                      {sc.label}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] text-gray-400 truncate">
                      {fmtDate(d.quote?.eventDate)} · {d.quote?.service}
                    </p>
                    {d.createdBy === 'cerise' && (
                      <span className="flex-shrink-0 ml-1 text-[9px] bg-violet-100 text-violet-600 px-1.5 py-0.5 rounded-full font-semibold">
                        ✦ Cerise
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-semibold text-black mt-0.5">{fmtEur(d.quote?.amount ?? 0)}</p>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* ── RIGHT: Detail panel ─────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto bg-[#F9F8F6]">
        <AnimatePresence mode="wait">

          {/* ── New dossier form ── */}
          {showForm && (
            <motion.div key="form" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
              className="p-8 max-w-2xl mx-auto">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Nouveau dossier
                  </h2>
                  <p className="text-xs text-gray-400 mt-0.5 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-violet-500" />
                    Devis envoyé automatiquement à la création
                  </p>
                </div>
                <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                  <X className="w-4 h-4 text-gray-500" />
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
                {/* Client */}
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <User className="w-3 h-3" /> Client
                  </p>
                  <div className="grid sm:grid-cols-3 gap-3">
                    <input className={inp} placeholder="Nom complet *" value={form.clientName} onChange={e => updForm({ clientName: e.target.value })} />
                    <input className={inp} type="email" placeholder="Email *" value={form.clientEmail} onChange={e => updForm({ clientEmail: e.target.value })} />
                    <input className={inp} placeholder="Téléphone" value={form.clientPhone} onChange={e => updForm({ clientPhone: e.target.value })} />
                  </div>
                </div>
                {/* Événement */}
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <Calendar className="w-3 h-3" /> Événement
                  </p>
                  <div className="grid sm:grid-cols-3 gap-3">
                    <input className={inp} type="date" value={form.eventDate} onChange={e => updForm({ eventDate: e.target.value })} />
                    <input className={inp} placeholder="Lieu / Domaine" value={form.eventVenue} onChange={e => updForm({ eventVenue: e.target.value })} />
                    <input className={inp} placeholder="Service" value={form.service} onChange={e => updForm({ service: e.target.value })} />
                  </div>
                </div>
                {/* Tarifs */}
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <Clock className="w-3 h-3" /> Tarifs
                  </p>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="relative">
                      <input className={`${inp} pr-8`} type="number" placeholder="Durée" value={form.duration} onChange={e => updForm({ duration: +e.target.value })} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">h</span>
                    </div>
                    <div className="relative">
                      <input className={`${inp} pr-6`} type="number" placeholder="Montant HT" value={form.amount || ''} onChange={e => updForm({ amount: +e.target.value })} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">€</span>
                    </div>
                    <div className="relative">
                      <input className={`${inp} pr-6`} type="number" placeholder="Acompte (30%)" value={form.deposit || ''} onChange={e => updForm({ deposit: +e.target.value })} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">€</span>
                    </div>
                  </div>
                </div>
                {/* Notes */}
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <StickyNote className="w-3 h-3" /> Notes
                  </p>
                  <textarea rows={2} className={`${inp} resize-none`} placeholder="Notes internes…"
                    value={form.notes} onChange={e => updForm({ notes: e.target.value })} />
                </div>
                <div className="flex justify-end pt-1">
                  <button onClick={handleCreate} disabled={!form.clientName || !form.eventDate || saving}
                    className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:bg-gray-800 disabled:opacity-40 transition-all">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                    {saving ? 'Création…' : 'Créer & envoyer'}
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ── Dossier detail ── */}
          {selected && !showForm && (
            <motion.div key={selected.dossier.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
              className="p-8 max-w-2xl mx-auto">

              {/* Pipeline bar */}
              {selected.dossier.stage !== 'cancelled' && <PipelineBar step={pipelineStep} />}

              {/* Header */}
              <div className="flex items-start justify-between mb-5">
                <div>
                  <h2 className="text-2xl font-semibold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {selected.dossier.clientName}
                  </h2>
                  <div className="flex items-center gap-2 mt-1">
                    {stageConfig && (
                      <span className={`text-xs px-2.5 py-1 rounded-xl font-semibold ${stageConfig.color}`}>
                        {stageConfig.label}
                      </span>
                    )}
                    {selected.dossier.createdBy === 'cerise' && (
                      <span className="text-xs px-2.5 py-1 rounded-xl font-semibold bg-violet-100 text-violet-700 flex items-center gap-1">
                        <Bot className="w-3 h-3" /> Créé par Cerise
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => copyPortalLink(selected.dossier.clientToken)}
                    className="flex items-center gap-1.5 text-xs px-3 py-1.5 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
                    title="Copier le lien portail client">
                    {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5 text-gray-500" />}
                    {copied ? 'Copié !' : 'Lien client'}
                  </button>
                  <button onClick={() => handleDelete(selected.dossier.id)}
                    className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex bg-white border border-gray-200 rounded-xl p-0.5 mb-5">
                {(['detail', 'contract', 'logs'] as const).map(t => (
                  <button key={t} onClick={() => setActiveTab(t)}
                    className={`flex-1 text-xs py-2 rounded-[10px] font-medium transition-all ${activeTab === t ? 'bg-black text-white shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}>
                    {t === 'detail'   ? 'Détails & Actions' :
                     t === 'contract' ? `Contrat${selected.contract ? ' ✓' : ''}` :
                     `Journal (${selected.logs.length})`}
                  </button>
                ))}
              </div>

              <AnimatePresence mode="wait">

                {/* ── TAB: Detail & Actions ── */}
                {activeTab === 'detail' && (
                  <motion.div key="detail" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">

                    {/* Info cards */}
                    {selected.quote && (
                      <>
                        <div className="grid grid-cols-2 gap-3">
                          {[
                            { icon: User,    label: 'Email',    value: selected.quote.clientEmail },
                            { icon: User,    label: 'Tél.',     value: selected.quote.clientPhone || '—' },
                            { icon: Calendar, label: 'Date',   value: fmtDate(selected.quote.eventDate) },
                            { icon: MapPin,  label: 'Lieu',     value: selected.quote.eventVenue || '—' },
                          ].map(({ icon: Icon, label, value }) => (
                            <div key={label} className="bg-white rounded-xl border border-gray-100 p-3.5">
                              <p className="text-xs text-gray-400 mb-0.5">{label}</p>
                              <p className="text-sm font-medium text-black truncate">{value}</p>
                            </div>
                          ))}
                        </div>

                        {/* Amount card */}
                        <div className="bg-black text-white rounded-2xl p-5 flex items-center justify-between">
                          <div>
                            <p className="text-xs text-white/50 mb-1">Montant total</p>
                            <p className="text-3xl font-bold">{fmtEur(selected.quote.amount)}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-white/50 mb-1">Acompte ({selected.quote.depositPercent}%)</p>
                            <p className="text-xl font-semibold">{fmtEur(selected.quote.deposit)}</p>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Payment info */}
                    {selected.payment && (
                      <PaymentBlock full={selected} onConfirm={handleConfirmPayment} confirming={confirming} />
                    )}

                    {/* ── Action buttons ── */}
                    <div className="space-y-2.5">

                      {/* Accept quote */}
                      {selected.dossier.stage === 'quoted' && (
                        <>
                          <button onClick={handleAccept} disabled={saving}
                            className="w-full flex items-center justify-between px-5 py-4 bg-violet-600 hover:bg-violet-700 text-white rounded-2xl transition-colors disabled:opacity-60">
                            <div className="flex items-center gap-3">
                              <Zap className="w-5 h-5" />
                              <div className="text-left">
                                <p className="font-semibold">Accepter + générer le contrat</p>
                                <p className="text-xs text-violet-100">Le contrat est créé automatiquement</p>
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <button onClick={handleRefuse}
                            className="w-full flex items-center gap-3 px-5 py-3 border border-red-200 text-red-500 hover:bg-red-50 rounded-2xl transition-colors text-sm">
                            <X className="w-4 h-4" /> Refuser le devis
                          </button>
                        </>
                      )}

                      {/* Go sign contract */}
                      {(selected.dossier.stage === 'contract' || selected.dossier.stage === 'accepted') && selected.contract && (
                        <button onClick={() => setActiveTab('contract')}
                          className="w-full flex items-center justify-between px-5 py-4 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl transition-colors">
                          <div className="flex items-center gap-3">
                            <FileSignature className="w-5 h-5" />
                            <div className="text-left">
                              <p className="font-semibold">Signer le contrat</p>
                              <p className="text-xs text-amber-100">
                                {selected.contract.signatures.client ? '✓ Client signé' : '⏳ En attente client'} · {selected.contract.signatures.vendor ? '✓ Vous avez signé' : '⏳ Votre signature manquante'}
                              </p>
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      )}

                      {/* Confirmed state */}
                      {selected.dossier.stage === 'confirmed' && (
                        <div className="flex items-center gap-3 px-5 py-4 bg-green-50 border border-green-200 rounded-2xl">
                          <CheckCheck className="w-5 h-5 text-green-600" />
                          <div>
                            <p className="font-semibold text-green-700">Prestation confirmée ✓</p>
                            <p className="text-xs text-green-500">Acompte reçu · Contrat signé</p>
                          </div>
                        </div>
                      )}

                      {/* Portal link */}
                      <div className="flex items-center gap-2 px-4 py-3 bg-white border border-gray-100 rounded-xl">
                        <ExternalLink className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                        <p className="text-xs text-gray-500 flex-1 truncate">
                          Portail client : {clientPortalUrl(selected.dossier.clientToken)}
                        </p>
                        <button onClick={() => copyPortalLink(selected.dossier.clientToken)}
                          className="text-xs text-black font-semibold hover:underline flex-shrink-0">
                          {copied ? '✓ Copié' : 'Copier'}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* ── TAB: Contract ── */}
                {activeTab === 'contract' && (
                  <motion.div key="contract" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    {selected.contract ? (
                      <ContractView full={selected} onSign={handleSign} signing={signing} />
                    ) : (
                      <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
                        <FileText className="w-8 h-8 text-gray-200 mx-auto mb-3" />
                        <p className="text-sm text-gray-500">Contrat pas encore généré.</p>
                        <p className="text-xs text-gray-400 mt-1">Acceptez le devis pour le créer automatiquement.</p>
                      </div>
                    )}
                  </motion.div>
                )}

                {/* ── TAB: Logs ── */}
                {activeTab === 'logs' && (
                  <motion.div key="logs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                      <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                          Journal des actions
                        </p>
                        <div className="flex items-center gap-1.5 text-[10px] text-violet-600 bg-violet-50 px-2 py-1 rounded-full font-medium">
                          <Zap className="w-2.5 h-2.5" /> AUTO = déclenché par le système
                        </div>
                      </div>
                      <div className="px-5 py-2">
                        <LogTimeline logs={selected.logs} />
                      </div>
                    </div>
                  </motion.div>
                )}

              </AnimatePresence>
            </motion.div>
          )}

          {/* ── Empty state ── */}
          {!selected && !showForm && (
            <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center h-full min-h-96 text-center p-8">
              <div className="w-14 h-14 bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
                <Zap className="w-7 h-7 text-gray-400" />
              </div>
              <p className="text-base font-semibold text-black mb-1">Pipeline automatisé</p>
              <p className="text-sm text-gray-400 mb-1">Devis → Contrat → Paiement</p>
              <p className="text-xs text-gray-300 mb-4">Chaque transition se déclenche automatiquement</p>
              <button onClick={() => setShowForm(true)}
                className="flex items-center gap-2 bg-black text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-800 transition-colors">
                <Plus className="w-4 h-4" /> Nouveau dossier
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
}
