import { useEffect, useState } from 'react';
import { Navigate } from 'react-router';
import { adminGet, TOKEN_KEY } from '../../lib/adminApi';
import { AdminLayout } from '../../components/admin/AdminLayout';

export default function AdminRoot() {
  const [status, setStatus] = useState<'checking' | 'ok' | 'unauth'>('checking');

  useEffect(() => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) { setStatus('unauth'); return; }
    adminGet('/verify')
      .then(r => setStatus(r.ok ? 'ok' : 'unauth'))
      .catch(() => setStatus('unauth'));
  }, []);

  if (status === 'checking') {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-white/15 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  if (status === 'unauth') return <Navigate to="/admin/login" replace />;

  return <AdminLayout />;
}
