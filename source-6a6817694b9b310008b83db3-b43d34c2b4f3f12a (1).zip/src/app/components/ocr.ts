import Tesseract from 'tesseract.js';

export type DetectedEvent = {
  type: 'mariage' | 'divorce' | 'naissance' | 'emploi' | 'pacs' | 'changement';
  description: string;
};

export async function extractTextFromImage(file: File): Promise<string> {
  const { data } = await Tesseract.recognize(file, 'fra');
  return data.text ?? '';
}

export function interpretText(raw: string): DetectedEvent[] {
  const text = raw.toLowerCase();
  const events: DetectedEvent[] = [];
  if (/\bmariage\b|mari[ée]/.test(text)) {
    events.push({ type: 'mariage', description: 'Mariage détecté par OCR' });
  }
  if (/\bdivorce\b/.test(text)) {
    events.push({ type: 'divorce', description: 'Divorce détecté par OCR' });
  }
  if (/concubinage|concubin[e]?/.test(text)) {
    events.push({ type: 'changement', description: 'Concubinage détecté par OCR' });
  }
  if (/\bpacs\b/.test(text)) {
    events.push({ type: 'pacs', description: 'PACS détecté par OCR' });
  }
  if (/naissance|n[ée] le/.test(text)) {
    events.push({ type: 'naissance', description: 'Naissance détectée par OCR' });
  }
  if (/emploi|contrat de travail|salari[eé]/.test(text)) {
    events.push({ type: 'emploi', description: 'Emploi détecté par OCR' });
  }
  return events;
}
