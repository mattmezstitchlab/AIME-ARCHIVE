import { motion, AnimatePresence } from 'motion/react';

export default function EntryPopup({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-2xl p-8 w-[90%] max-w-md text-center"
          >
            <h2 className="text-xl font-semibold mb-3">
              Bienvenue sur AIME
            </h2>

            <p className="text-sm text-gray-500 mb-6">
              Crée ton mariage ou retrouve ton espace
            </p>

            <div className="flex flex-col gap-3">
              <button
                onClick={() => window.location.href = '/app'}
                className="bg-black text-white py-3 rounded-xl"
              >
                Créer mon mariage
              </button>

              <button
                onClick={() => window.location.href = '/app'}
                className="border py-3 rounded-xl"
              >
                Se connecter
              </button>
            </div>

            <button
              onClick={onClose}
              className="mt-4 text-xs text-gray-400"
            >
              Continuer sans compte
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}