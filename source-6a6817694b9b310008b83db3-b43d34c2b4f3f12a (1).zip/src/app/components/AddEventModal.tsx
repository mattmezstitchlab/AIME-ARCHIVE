import { useState } from 'react';
import { X, Calendar, Heart, HeartCrack, Baby, Briefcase, Users, FileText, Link2 } from 'lucide-react';

export type EventType = 'mariage' | 'divorce' | 'naissance' | 'emploi' | 'pacs' | 'changement' | 'concubinage';

interface AddEventModalProps {
  open: boolean;
  onClose: () => void;
  onAdd: (data: { type: EventType; date: string; description: string }) => Promise<void>;
}

const EVENT_TYPES: { value: EventType; label: string; icon: React.ComponentType<{ className?: string }>; color: string }[] = [
  { value: 'mariage',     label: 'Mariage',     icon: Heart,      color: 'text-black bg-gray-100 border-gray-300' },
  { value: 'divorce',     label: 'Divorce',     icon: HeartCrack, color: 'text-black bg-gray-100 border-gray-300' },
  { value: 'concubinage', label: 'Concubinage', icon: Link2,      color: 'text-black bg-gray-100 border-gray-300' },
  { value: 'pacs',        label: 'PACS',        icon: Users,      color: 'text-black bg-gray-100 border-gray-300' },
  { value: 'emploi',      label: 'Emploi',      icon: Briefcase,  color: 'text-black bg-gray-100 border-gray-300' },
  { value: 'naissance',   label: 'Naissance',   icon: Baby,       color: 'text-black bg-gray-100 border-gray-300' },
  { value: 'changement',  label: 'Changement',  icon: FileText,   color: 'text-black bg-gray-100 border-gray-300' },
];

export function AddEventModal({ open, onClose, onAdd }: AddEventModalProps) {
  const [type, setType] = useState<EventType>('changement');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      setError('La description est obligatoire.');
      return;
    }
    if (!date) {
      setError('La date est obligatoire.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await onAdd({ type, date, description: description.trim() });
      setType('changement');
      setDate(new Date().toISOString().slice(0, 10));
      setDescription('');
      onClose();
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  };

  const handleBackdrop = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };

  const selectedType = EVENT_TYPES.find((t) => t.value === type)!;
  const Icon = selectedType.icon;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
      onClick={handleBackdrop}
    >
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-black flex items-center justify-center">
              <Icon className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-black text-base font-bold tracking-tight">
                Ajouter un événement
              </h2>
              <p className="text-xs text-gray-400">Événement de vie de l'assuré</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="px-3 py-2 bg-black text-white rounded-xl text-sm">
              {error}
            </div>
          )}

          {/* Type */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Type d'événement
            </label>
            <div className="grid grid-cols-3 gap-2">
              {EVENT_TYPES.map((t) => {
                const TIcon = t.icon;
                const isSelected = type === t.value;
                return (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setType(t.value)}
                    className={`flex flex-col items-center gap-1.5 px-2 py-3 text-xs rounded-xl border transition-all ${
                      isSelected
                        ? 'bg-black text-white border-black font-medium'
                        : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <TIcon className="w-4 h-4" />
                    {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Date
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-black focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-gray-400 transition-all"
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Décrivez l'événement…"
              rows={3}
              autoFocus
              className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-black placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-gray-400 resize-none transition-all"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 text-sm text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-all active:scale-[0.99]"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || !description.trim() || !date}
              className="flex-1 px-4 py-2.5 text-sm font-semibold text-white bg-black rounded-xl hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.99]"
            >
              {loading ? 'Ajout…' : "Ajouter l'événement"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}