import { motion } from 'motion/react';

/**
 * Formes définies en polygon() à 12 points — indispensable pour que Motion
 * puisse interpoler fluide entre elles (même type, même nombre de points).
 * Sens horaire cohérent sur toutes les formes.
 */

// Cœur — notch central + épaules + courbes basses + pointe
const HEART =
  'polygon(50% 25%, 63% 14%, 80% 14%, 93% 28%, 93% 47%, 76% 65%, 50% 88%, 24% 65%, 7% 47%, 7% 28%, 20% 14%, 37% 14%)';

// Cercle — dodécagone régulier (30° entre chaque point)
const CIRCLE =
  'polygon(50% 0%, 75% 7%, 93% 25%, 100% 50%, 93% 75%, 75% 93%, 50% 100%, 25% 93%, 7% 75%, 0% 50%, 7% 25%, 25% 7%)';

// Carré — 12 points répartis uniformément sur le périmètre
const SQUARE =
  'polygon(0% 0%, 33% 0%, 67% 0%, 100% 0%, 100% 33%, 100% 67%, 100% 100%, 67% 100%, 33% 100%, 0% 100%, 0% 67%, 0% 33%)';

// Triangle équilatéral — 4 points par côté (apex partagé)
const TRIANGLE =
  'polygon(50% 0%, 63% 25%, 75% 50%, 88% 75%, 100% 100%, 75% 100%, 50% 100%, 25% 100%, 0% 100%, 13% 75%, 25% 50%, 38% 25%)';

// Séquence : revient au cœur pour que la boucle soit continue
const SEQUENCE = [HEART, CIRCLE, SQUARE, TRIANGLE, HEART];

interface AimeLogoIconProps {
  /** Taille en px — défaut 16 */
  size?: number;
  /** Couleur de remplissage — défaut blanc */
  color?: string;
}

export function AimeLogoIcon({ size = 16, color = 'white' }: AimeLogoIconProps) {
  return (
    <motion.div
      aria-hidden
      animate={{ clipPath: SEQUENCE }}
      whileHover={{ scale: 1.14, opacity: 1 }}
      transition={{
        clipPath: {
          duration: 8,
          ease: 'easeInOut',
          times: [0, 0.25, 0.5, 0.75, 1],
          repeat: Infinity,
          repeatType: 'loop',
        },
        scale:   { duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] },
        opacity: { duration: 0.2 },
      }}
      style={{
        width:           size,
        height:          size,
        backgroundColor: color,
        opacity:         0.9,
        flexShrink:      0,
      }}
    />
  );
}
