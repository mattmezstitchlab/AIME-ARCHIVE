import { useRef, useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  FileText,
  Upload,
  Sparkles,
  Loader2,
  Trash2,
  ChevronRight,
  Plus,
  Check,
} from 'lucide-react';

interface DocumentItem {
  id: string;
  name: string;
  status: 'reçu' | 'manquant' | 'validé';
}

interface AnalysisProps {
  status: 'coherent' | 'warning' | 'critical';
  suggestions: string[];
  actions: string[];
  documents: DocumentItem[];
  onOCRUpload: (file: File) => void;
  ocrStatus: string | null;
  onAddDocument: (name: string) => void;
  onUpdateDocStatus: (docId: string, status: 'reçu' | 'manquant' | 'validé') => void;
  onDeleteDocument: (docId: string) => void;
}

// Strict black / white / gray — inverted card for critical (maximum hierarchy)
const statusMeta = {
  coherent: {
    icon: CheckCircle2,
    label: 'Dossier cohérent',
    sub: 'Aucune incohérence détectée',
    cardClass: 'bg-white border-gray-200',
    iconClass: 'text-gray-400',
    labelClass: 'text-black',
    subClass: 'text-gray-500',
  },
  warning: {
    icon: AlertTriangle,
    label: 'Incohérence détectée',
    sub: 'Vérification recommandée',
    cardClass: 'bg-gray-50 border-gray-300',
    iconClass: 'text-gray-700',
    labelClass: 'text-black',
    subClass: 'text-gray-600',
  },
  critical: {
    icon: AlertCircle,
    label: 'Action requise',
    sub: 'Prioritaire — traitement immédiat',
    cardClass: 'bg-black border-black',
    iconClass: 'text-white',
    labelClass: 'text-white',
    subClass: 'text-white/60',
  },
} as const;

const docStatusConfig: Record<
  DocumentItem['status'],
  { label: string; badge: string; next: DocumentItem['status'] }
> = {
  manquant: { label: 'Manquant', badge: 'bg-gray-100 text-gray-500',     next: 'reçu'     },
  reçu:     { label: 'Reçu',     badge: 'bg-gray-200 text-gray-700',     next: 'validé'   },
  validé:   { label: 'Validé',   badge: 'bg-black text-white',           next: 'manquant' },
};

export function IntelligentAnalysis({
  status, suggestions, actions, documents,
  onOCRUpload, ocrStatus, onAddDocument, onUpdateDocStatus, onDeleteDocument,
}: AnalysisProps) {
  const m = statusMeta[status];
  const Icon = m.icon;
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [addDocName, setAddDocName] = useState('');
  const [showAddDoc, setShowAddDoc] = useState(false);

  const handleAddDoc = () => {
    const n = addDocName.trim();
    if (!n) return;
    onAddDocument(n);
    setAddDocName('');
    setShowAddDoc(false);
  };

  const missingDocs = documents.filter((d) => d.status === 'manquant').length;

  return (
    <div className="h-full flex flex-col bg-white border-l border-gray-100 overflow-y-auto">
      <div className="p-5 space-y-5">

        {/* Header */}
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-gray-400" />
          <h3 className="text-black font-semibold text-base tracking-tight">Analyse intelligente</h3>
        </div>

        {/* Status banner — inverted for critical */}
        <div className={`p-4 rounded-2xl border ${m.cardClass}`}>
          <div className="flex items-center gap-3">
            <Icon className={`w-5 h-5 flex-shrink-0 ${m.iconClass}`} />
            <div>
              <div className={`text-sm font-semibold ${m.labelClass}`}>{m.label}</div>
              <div className={`text-xs mt-0.5 ${m.subClass}`}>{m.sub}</div>
            </div>
          </div>
        </div>

        {/* Detected issues */}
        {suggestions.length > 0 && (
          <div>
            <h4 className="text-xs uppercase tracking-widest font-semibold text-gray-400 mb-2.5">
              Incohérences
            </h4>
            <div className="space-y-2">
              {suggestions.map((s, i) => (
                <div
                  key={i}
                  className="flex items-start gap-2.5 p-3 bg-white rounded-xl border border-gray-200 shadow-sm"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-gray-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700 leading-snug">{s}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        {actions.length > 0 && (
          <div>
            <h4 className="text-xs uppercase tracking-widest font-semibold text-gray-400 mb-2.5">
              Actions recommandées
            </h4>
            <div className="space-y-2">
              {actions.map((a, i) => (
                <button
                  key={i}
                  className="w-full flex items-center justify-between gap-2 p-3 bg-white border border-gray-200 shadow-sm rounded-xl text-sm text-gray-700 text-left hover:bg-black hover:text-white hover:border-black active:scale-[0.99] transition-all group"
                >
                  <span>{a}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-white flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Documents */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <h4 className="text-xs uppercase tracking-widest font-semibold text-gray-400 flex items-center gap-2">
              Documents
              {missingDocs > 0 && (
                <span className="px-1.5 py-0.5 bg-black text-white rounded-md text-[9px] font-bold">
                  {missingDocs} manquant{missingDocs > 1 ? 's' : ''}
                </span>
              )}
            </h4>
          </div>

          {/* OCR upload */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,application/pdf"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onOCRUpload(f);
              e.target.value = '';
            }}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full mb-2 px-3 py-3 border border-dashed border-gray-200 rounded-xl hover:border-gray-400 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2 text-gray-500 text-sm group"
          >
            {ocrStatus?.includes('Lecture') ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                <span className="text-xs">{ocrStatus}</span>
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 group-hover:text-black transition-colors" />
                <span className="group-hover:text-black transition-colors">Importer document (OCR)</span>
              </>
            )}
          </button>

          {ocrStatus && !ocrStatus.includes('Lecture') && (
            <div className="mb-2 px-3 py-1.5 bg-gray-50 border border-gray-100 rounded-xl text-xs text-gray-500">
              {ocrStatus}
            </div>
          )}

          {/* Add document */}
          {showAddDoc ? (
            <div className="mb-2 flex gap-2">
              <input
                type="text"
                value={addDocName}
                onChange={(e) => setAddDocName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddDoc();
                  if (e.key === 'Escape') setShowAddDoc(false);
                }}
                placeholder="Nom du document…"
                autoFocus
                className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-black placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-gray-400 transition-all"
              />
              <button
                onClick={handleAddDoc}
                disabled={!addDocName.trim()}
                className="px-3 py-2 bg-black text-white rounded-xl disabled:opacity-40 hover:bg-gray-800 transition-all"
              >
                <Check className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowAddDoc(true)}
              className="w-full mb-3 px-3 py-2 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2 text-gray-500 text-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              Ajouter un document
            </button>
          )}

          {/* Document list */}
          <div className="space-y-1.5">
            {documents.length === 0 && (
              <div className="text-xs text-gray-400 px-1 py-2 text-center">
                Aucun document dans ce dossier.
              </div>
            )}
            {documents.map((doc) => {
              const conf = docStatusConfig[doc.status];
              return (
                <div
                  key={doc.id}
                  className="group px-3 py-2.5 bg-white rounded-xl border border-gray-200 shadow-sm flex items-center justify-between gap-2 hover:shadow-md transition-all"
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <FileText className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    <span className="text-sm text-gray-700 truncate">{doc.name}</span>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => onUpdateDocStatus(doc.id, conf.next)}
                      title={`Marquer comme "${conf.next}"`}
                      className={`px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-semibold cursor-pointer hover:opacity-75 transition-opacity ${conf.badge}`}
                    >
                      {conf.label}
                    </button>
                    <button
                      onClick={() => onDeleteDocument(doc.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-100 rounded-lg transition-all text-gray-400 hover:text-black"
                      aria-label="Supprimer le document"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
