import {
  Heart,
  HeartCrack,
  Baby,
  Briefcase,
  Users,
  FileText,
  Link2,
  Plus,
  Trash2,
  AlertTriangle,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface TimelineEvent {
  id: string;
  type: 'mariage' | 'divorce' | 'naissance' | 'emploi' | 'pacs' | 'changement' | 'concubinage';
  date: string;
  description: string;
  metadata?: {
    declared?: boolean;
    sector?: string;
    source?: string;
    [key: string]: unknown;
  };
}

interface TimelineProps {
  events: TimelineEvent[];
  onAddEvent?: () => void;
  onDeleteEvent?: (id: string) => void;
  readonly?: boolean;
}

const meta: Record<
  TimelineEvent['type'],
  { icon: React.ComponentType<{ className?: string }>; label: string }
> = {
  mariage:    { icon: Heart,      label: 'Mariage'      },
  divorce:    { icon: HeartCrack, label: 'Divorce'      },
  naissance:  { icon: Baby,       label: 'Naissance'    },
  emploi:     { icon: Briefcase,  label: 'Emploi'       },
  pacs:       { icon: Users,      label: 'PACS'         },
  changement: { icon: FileText,   label: 'Changement'   },
  concubinage:{ icon: Link2,      label: 'Concubinage'  },
};

export function Timeline({ events, onAddEvent, onDeleteEvent, readonly }: TimelineProps) {
  return (
    <div>
      {/* Header */}
      {!readonly && (
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-black font-semibold tracking-tight">Timeline de vie</h3>
            {events.length > 0 && (
              <p className="text-xs text-gray-400 mt-0.5">
                {events.length} événement{events.length > 1 ? 's' : ''} · ordre chronologique
              </p>
            )}
          </div>
          {onAddEvent && (
            <button
              onClick={onAddEvent}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-white border border-gray-200 text-gray-700 rounded-xl hover:bg-black hover:text-white hover:border-black active:scale-[0.99] transition-all shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              Ajouter
            </button>
          )}
        </div>
      )}

      {/* Empty state */}
      {events.length === 0 && !readonly && (
        <div className="bg-white rounded-2xl border border-dashed border-gray-200 p-12 text-center">
          <div className="text-4xl mb-4">📋</div>
          <div className="text-sm font-medium text-gray-700 mb-1">Aucun événement enregistré</div>
          <div className="text-xs text-gray-400">Ajoutez manuellement ou importez un document.</div>
        </div>
      )}

      {events.length > 0 && (
        <div className="relative py-4">
          {/* Central line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2 bg-gradient-to-b from-gray-200 via-gray-200 to-transparent" />

          <AnimatePresence mode="popLayout">
            <div className="space-y-10">
              {events.map((event, i) => {
                const m = meta[event.type] ?? meta.changement;
                const Icon = m.icon;
                const isLeft = i % 2 === 0;
                const isUndeclared = event.metadata?.declared === false;

                return (
                  <motion.div
                    key={event.id}
                    initial={{ opacity: 0, y: 24, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.15 } }}
                    transition={{ duration: 0.35, delay: i * 0.06, ease: [0.25, 0.46, 0.45, 0.94] }}
                    className={`relative flex w-full ${isLeft ? 'justify-start' : 'justify-end'}`}
                  >
                    {/* Central dot */}
                    <div className={`absolute left-1/2 top-6 z-10 h-3 w-3 -translate-x-1/2 rounded-full border-[3px] border-white shadow-md ${isUndeclared ? 'bg-gray-500' : 'bg-black'}`} />

                    {/* Connector */}
                    <div className={`absolute top-[27px] h-px w-[5%] bg-gray-200 ${isLeft ? 'left-[45%]' : 'right-[45%]'}`} />

                    {/* Card */}
                    <div className="w-[45%] group">
                      <motion.div
                        whileHover={{ y: -2 }}
                        transition={{ duration: 0.2 }}
                        className={`rounded-2xl border bg-white p-5 shadow-sm hover:shadow-md transition-shadow duration-300 ${
                          isUndeclared ? 'border-gray-400 border-dashed' : 'border-gray-200'
                        }`}
                      >
                        {/* Top row */}
                        <div className="flex items-center justify-between gap-2 mb-3">
                          <div className="flex items-center gap-1.5">
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gray-100">
                              <Icon className="w-3 h-3 text-gray-600" />
                              <span className="text-xs font-semibold text-gray-700">{m.label}</span>
                            </div>
                            {/* Non déclaré badge */}
                            {isUndeclared && (
                              <div className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-black text-white">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                <span className="text-[10px] font-semibold uppercase tracking-wide">Non déclaré</span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-gray-400 tabular-nums">{event.date}</span>
                            {onDeleteEvent && (
                              <button
                                onClick={() => {
                                  if (window.confirm('Supprimer cet événement ?')) {
                                    onDeleteEvent(event.id);
                                  }
                                }}
                                className="opacity-0 group-hover:opacity-100 ml-1 p-0.5 hover:bg-gray-100 rounded-md transition-all text-gray-400 hover:text-gray-900"
                                aria-label="Supprimer"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Description */}
                        <p className="text-sm text-gray-600 leading-relaxed">{event.description}</p>

                        {/* Sector badge */}
                        {event.metadata?.sector && (
                          <div className="mt-2.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-gray-50 border border-gray-100">
                            <Briefcase className="w-2.5 h-2.5 text-gray-400" />
                            <span className="text-[10px] text-gray-500 font-medium capitalize">{event.metadata.sector}</span>
                          </div>
                        )}
                      </motion.div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
