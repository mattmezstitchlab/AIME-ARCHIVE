import { Edit2, Calendar, FileText, Briefcase, Wheat } from 'lucide-react';

export interface Person {
  name: string;
  relationStatus: 'célibataire' | 'concubinage' | 'pacs' | 'marié' | 'divorcé';
  participation: 'participant' | 'non-participant';
  // MSA extended
  statut_pro?: string | null;
  participation_agricole?: string | null;
}

interface PersonCardProps {
  person: Person;
  onEdit: () => void;
  eventCount?: number;
  documentCount?: number;
}

function initials(name: string) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
}

function nameToShade(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) & 0x7fffffff;
  }
  const shades = [
    'bg-black text-white',
    'bg-gray-800 text-white',
    'bg-gray-700 text-white',
    'bg-gray-600 text-white',
    'bg-gray-500 text-white',
    'bg-gray-400 text-white',
  ];
  return shades[hash % shades.length];
}

const relationStatusLabel: Record<Person['relationStatus'], string> = {
  célibataire: 'Célibataire',
  marié:       'Marié(e)',
  pacs:        'Pacsé(e)',
  concubinage: 'Concubinage',
  divorcé:     'Divorcé(e)',
};

const statutProLabel: Record<string, string> = {
  exploitant:                 'Exploitant agricole',
  salarie_agricole:           'Salarié agricole',
  conjoint_participant:       'Conjoint participant',
  conjoint_non_participant:   'Conjoint non participant',
};

const participationAgricoleLabel: Record<string, string> = {
  participant:    'Participation active',
  non_participant:'Non participant',
  inconnu:        'Participation inconnue',
};

export function PersonCard({ person, onEdit, eventCount, documentCount }: PersonCardProps) {
  const avatarClass = nameToShade(person.name);
  const proLabel    = person.statut_pro ? (statutProLabel[person.statut_pro] ?? person.statut_pro) : null;
  const agriLabel   = person.participation_agricole
    ? (participationAgricoleLabel[person.participation_agricole] ?? person.participation_agricole)
    : null;

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 mb-8">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-4 min-w-0">
          {/* Avatar */}
          <div className={`w-12 h-12 rounded-2xl ${avatarClass} flex items-center justify-center font-semibold text-base flex-shrink-0`}>
            {initials(person.name)}
          </div>

          {/* Info */}
          <div className="min-w-0">
            <h2 className="text-black text-lg font-bold tracking-tight leading-tight truncate mb-2">
              {person.name}
            </h2>
            <div className="flex flex-wrap items-center gap-1.5">
              {/* Relation status */}
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                {relationStatusLabel[person.relationStatus]}
              </span>
              {/* Pro status — MSA field */}
              {proLabel && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                  <Briefcase className="w-2.5 h-2.5 text-gray-400" />
                  {proLabel}
                </span>
              )}
              {/* Participation agricole — MSA field */}
              {agriLabel && (
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                  person.participation_agricole === 'participant'
                    ? 'bg-black text-white'
                    : person.participation_agricole === 'non_participant'
                    ? 'bg-gray-100 text-gray-500'
                    : 'bg-gray-100 text-gray-400'
                }`}>
                  <Wheat className="w-2.5 h-2.5 opacity-60" />
                  {agriLabel}
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={onEdit}
          className="p-2 hover:bg-gray-100 rounded-xl transition-colors flex-shrink-0"
          aria-label="Modifier le dossier"
        >
          <Edit2 className="w-4 h-4 text-gray-500" />
        </button>
      </div>

      {/* Stats */}
      {(eventCount !== undefined || documentCount !== undefined) && (
        <div className="mt-4 pt-4 border-t border-gray-100 flex gap-5">
          {eventCount !== undefined && (
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Calendar className="w-3.5 h-3.5 text-gray-400" />
              <span>
                <span className="font-semibold text-black">{eventCount}</span>{' '}
                événement{eventCount !== 1 ? 's' : ''}
              </span>
            </div>
          )}
          {documentCount !== undefined && (
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <FileText className="w-3.5 h-3.5 text-gray-400" />
              <span>
                <span className="font-semibold text-black">{documentCount}</span>{' '}
                document{documentCount !== 1 ? 's' : ''}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
