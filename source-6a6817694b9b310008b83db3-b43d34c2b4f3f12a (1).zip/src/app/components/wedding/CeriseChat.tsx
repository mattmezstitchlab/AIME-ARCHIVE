import {
  useEffect,
  useRef,
  useState,
  type ComponentType,
  type KeyboardEvent,
} from 'react';
import {
  X,
  Send,
  Star,
  MapPin,
  Sparkles,
  Camera,
  Music,
  Utensils,
  Flower2,
  Building2,
  Heart,
  Mic2,
  Shirt,
  Scissors,
  Cake,
  Car,
  Palette,
  Loader2,
  Bookmark,
  Eye,
  PlusCircle,
  WalletCards,
  CheckCircle2,
  Plus,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { ChatMessage } from './WeddingEngine';
import { AimeLogoIcon } from '../AimeLogoIcon';
import './cerise-chat-shell.css';

type ProviderCategory =
  | 'venue'
  | 'planner'
  | 'photo'
  | 'catering'
  | 'music'
  | 'dj'
  | 'flowers'
  | 'dress'
  | 'beauty'
  | 'decor'
  | 'cake'
  | 'transport';

export type CeriseProviderSuggestion = {
  id: string;
  name: string;
  category: ProviderCategory;
  location: string;
  description: string;
  priceFrom: string;
  rating: number;
  tags?: string[];
  available?: boolean;
  image: string;
};

export type ProviderAction =
  | 'view'
  | 'remember'
  | 'interested'
  | 'no_budget'
  | 'add_to_timeline';

export type CeriseTimelinePayload = {
  source: 'cerise_provider_card';
  action: ProviderAction;
  providerId: string;
  title: string;
  time: string;
  category: string;
  vendor: string;
  location: string;
  description: string;
  rawPriceFrom: string;
  estimatedBudget?: number;
  rating: number;
  available: boolean;
  tags: string[];
  status: 'pending';
  timelineCommand: string;
};

interface CeriseChatProps {
  messages: ChatMessage[];
  onSend: (text: string) => void;
  disabled?: boolean;

  providerSuggestions?: CeriseProviderSuggestion[];
  providerLoading?: boolean;
  hasTimeline?: boolean;

  /**
   * Nouveau :
   * Le 3e argument contient toutes les infos prêtes à être injectées dans WeddingTimeline.
   */
  onProviderAction?: (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => void;

  /**
   * Optionnel :
   * Permet de calculer les budgets "par invité".
   */
  guestCount?: number;
}

const SUGGESTIONS = [
  "Qu'est-ce qui manque encore à mon organisation ?",
  'Ajoute un DJ pour la soirée',
  'Quel est mon budget estimé ?',
  'Mes préparatifs sont à quelle heure ?',
  'Décale le dîner à 20h30',
  'Je cherche un saxophoniste pour le cocktail',
  'Trouve-moi un photographe naturel à Lille',
];

const CATEGORY_ICONS: Record<
  ProviderCategory,
  ComponentType<{ className?: string }>
> = {
  venue: Building2,
  planner: Heart,
  photo: Camera,
  catering: Utensils,
  music: Music,
  dj: Mic2,
  flowers: Flower2,
  dress: Shirt,
  beauty: Scissors,
  decor: Palette,
  cake: Cake,
  transport: Car,
};

const CATEGORY_LABELS: Record<ProviderCategory, string> = {
  venue: 'Lieu',
  planner: 'Wedding planner',
  photo: 'Photographe',
  catering: 'Traiteur',
  music: 'Musicien',
  dj: 'DJ',
  flowers: 'Fleuriste',
  dress: 'Tenue',
  beauty: 'Beauté',
  decor: 'Décoration',
  cake: 'Pâtisserie',
  transport: 'Transport',
};

function timelineCategoryForProvider(category: ProviderCategory) {
  switch (category) {
    case 'photo':
      return 'photo';
    case 'catering':
    case 'cake':
      return 'catering';
    case 'music':
    case 'dj':
      return 'music';
    case 'transport':
      return 'transport';
    case 'venue':
    case 'flowers':
    case 'decor':
      return 'reception';
    case 'dress':
    case 'beauty':
      return 'preparation';
    case 'planner':
    default:
      return 'other';
  }
}

function suggestedTimeForProvider(category: ProviderCategory) {
  switch (category) {
    case 'beauty':
    case 'dress':
      return '10:00';
    case 'flowers':
    case 'decor':
      return '11:00';
    case 'photo':
      return '14:00';
    case 'venue':
      return '15:00';
    case 'music':
      return '16:30';
    case 'dj':
      return '22:00';
    case 'catering':
    case 'cake':
      return '19:30';
    case 'transport':
      return '13:30';
    case 'planner':
    default:
      return '18:00';
  }
}

function parseBudget(priceFrom: string, guestCount = 80): number | undefined {
  const value = parseInt(priceFrom.replace(/\D/g, ''), 10);

  if (!Number.isFinite(value)) return undefined;

  const lower = priceFrom.toLowerCase();
  const isPerGuest =
    lower.includes('invité') ||
    lower.includes('invite') ||
    lower.includes('personne') ||
    lower.includes('part') ||
    lower.includes('/ invité') ||
    lower.includes('/ personne');

  if (isPerGuest) return value * guestCount;

  return value;
}

function buildTimelineCommand(
  provider: CeriseProviderSuggestion,
  payload: CeriseTimelinePayload
) {
  return [
    `Ajoute ce prestataire à ma timeline : ${provider.name}.`,
    `Catégorie : ${CATEGORY_LABELS[provider.category]}.`,
    `Horaire suggéré : ${payload.time}.`,
    `Lieu : ${provider.location}.`,
    `Budget estimé : ${
      payload.estimatedBudget ? `${payload.estimatedBudget} €` : provider.priceFrom
    }.`,
    `Prix affiché : ${provider.priceFrom}.`,
    `Description : ${provider.description}.`,
    provider.tags?.length ? `Tags : ${provider.tags.join(', ')}.` : '',
    `Statut : à confirmer.`,
  ]
    .filter(Boolean)
    .join(' ');
}

function buildTimelinePayload(
  action: ProviderAction,
  provider: CeriseProviderSuggestion,
  guestCount = 80
): CeriseTimelinePayload {
  const estimatedBudget = parseBudget(provider.priceFrom, guestCount);
  const time = suggestedTimeForProvider(provider.category);
  const category = timelineCategoryForProvider(provider.category);
  const tags = provider.tags ?? [];

  const payload: CeriseTimelinePayload = {
    source: 'cerise_provider_card',
    action,
    providerId: provider.id,
    title: provider.name,
    time,
    category,
    vendor: provider.name,
    location: provider.location,
    description: [
      provider.description,
      `Lieu : ${provider.location}`,
      `Prix : ${provider.priceFrom}`,
      tags.length ? `Tags : ${tags.join(', ')}` : '',
      `Note : ${provider.rating.toFixed(1)}/5`,
      provider.available === false ? 'Disponibilité : à vérifier' : 'Disponibilité : à confirmer',
    ]
      .filter(Boolean)
      .join(' · '),
    rawPriceFrom: provider.priceFrom,
    estimatedBudget,
    rating: provider.rating,
    available: provider.available ?? true,
    tags,
    status: 'pending',
    timelineCommand: '',
  };

  payload.timelineCommand = buildTimelineCommand(provider, payload);

  return payload;
}

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-3 py-2.5">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-gray-400"
          animate={{ y: [0, -4, 0] }}
          transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.12 }}
        />
      ))}
    </div>
  );
}

function ProviderLoadingCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-[1.35rem] border border-[#303030] bg-white/[.035] p-3"
    >
      <div className="flex items-center gap-2 text-xs text-white/60">
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        Cerise cherche les bonnes cartes…
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-16 rounded-[1rem] bg-white/[0.06] animate-pulse"
          />
        ))}
      </div>
    </motion.div>
  );
}

function ProviderSuggestionCard({
  provider,
  hasTimeline,
  guestCount,
  onAction,
}: {
  provider: CeriseProviderSuggestion;
  hasTimeline: boolean;
  guestCount: number;
  onAction?: (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => void;
}) {
  const Icon = CATEGORY_ICONS[provider.category] ?? Sparkles;
  const [feedback, setFeedback] = useState('');

  const runAction = (action: ProviderAction) => {
    const payload = buildTimelinePayload(action, provider, guestCount);

    onAction?.(action, provider, payload);

    if (action === 'add_to_timeline') {
      setFeedback('Ajouté à la timeline');
    }

    if (action === 'remember') {
      setFeedback('Gardé en mémoire');
    }

    if (action === 'interested') {
      setFeedback('Piste marquée intéressante');
    }

    if (action === 'no_budget') {
      setFeedback('Budget refusé');
    }

    if (action !== 'view') {
      window.setTimeout(() => setFeedback(''), 1800);
    }
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.28 }}
      className="w-[210px] flex-shrink-0 rounded-[1.35rem] overflow-hidden bg-white/[0.035] border border-[#303030]"
    >
      <div className="relative h-24 overflow-hidden bg-black">
        <img
          src={provider.image}
          alt={provider.name}
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/5" />

        <div className="absolute top-2 left-2 w-7 h-7 rounded-full bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white">
          <Icon className="w-3 h-3" />
        </div>

        <div className="absolute top-2 right-2 flex items-center gap-1 text-[9px] text-white bg-black/40 backdrop-blur-md px-2 py-0.5 rounded-full">
          <Star className="w-2.5 h-2.5 fill-current" />
          {provider.rating.toFixed(1)}
        </div>

        <div className="absolute left-3 right-3 bottom-2.5">
          <p className="text-[9px] uppercase tracking-[0.18em] text-white/40 mb-0.5">
            {CATEGORY_LABELS[provider.category]}
          </p>

          <h3 className="text-white text-xs font-medium leading-tight truncate">
            {provider.name}
          </h3>

          <div className="flex items-center gap-1 text-white/50 text-[9px] mt-0.5">
            <MapPin className="w-2.5 h-2.5 flex-shrink-0" />
            <span className="truncate">{provider.location}</span>
          </div>
        </div>
      </div>

      <div className="p-3">
        <p className="text-xs text-white/52 leading-[1.5] h-[36px] overflow-hidden">
          {provider.description}
        </p>

        <div className="mt-3 flex items-end justify-between gap-2">
          <div>
            <p className="text-[9px] text-white/40 uppercase tracking-[0.18em]">
              À partir de
            </p>
            <p className="text-xs font-semibold text-white">{provider.priceFrom}</p>
          </div>

          <span className="text-[9px] text-white/50 bg-white/[0.06] px-2 py-0.5 rounded-full">
            {provider.available ? 'Disponible' : 'À vérifier'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-1.5 mt-3">
          <button
            type="button"
            onClick={() => runAction('interested')}
            className="min-h-8 px-2 rounded-full bg-white text-black text-[11px] hover:bg-white/85 transition-colors"
          >
            Intéressé
          </button>

          <button
            type="button"
            onClick={() => runAction('view')}
            className="min-h-8 px-2 rounded-full border border-[#303030] bg-white/[.035] text-white/75 text-[11px] hover:border-[#454545] hover:text-white transition-colors flex items-center justify-center gap-1"
          >
            <Eye className="w-3 h-3" />
            Voir
          </button>

          <button
            type="button"
            onClick={() => runAction('remember')}
            className="min-h-8 px-2 rounded-full border border-[#303030] bg-white/[.035] text-white/75 text-[11px] hover:border-[#454545] hover:text-white transition-colors flex items-center justify-center gap-1"
          >
            <Bookmark className="w-3 h-3" />
            Garder
          </button>

          <button
            type="button"
            onClick={() => runAction('no_budget')}
            className="min-h-8 px-2 rounded-full border border-[#303030] bg-white/[.035] text-white/75 text-[11px] hover:border-[#454545] hover:text-white transition-colors"
          >
            Pas budget
          </button>
        </div>

        {hasTimeline && (
          <button
            type="button"
            onClick={() => runAction('add_to_timeline')}
            className="mt-1.5 w-full min-h-8 px-2 rounded-full bg-white text-black text-[11px] hover:bg-white/85 transition-colors flex items-center justify-center gap-1"
          >
            <PlusCircle className="w-3 h-3" />
            Ajouter à la timeline
          </button>
        )}

        <AnimatePresence>
          {feedback && (
            <motion.div
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              className="mt-2 flex items-center justify-center gap-1.5 text-[10px] text-white/50"
            >
              <CheckCircle2 className="w-3 h-3" />
              {feedback}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.article>
  );
}

function ProviderSuggestionsStrip({
  providers,
  providerLoading,
  hasTimeline,
  guestCount,
  onProviderAction,
}: {
  providers: CeriseProviderSuggestion[];
  providerLoading?: boolean;
  hasTimeline?: boolean;
  guestCount: number;
  onProviderAction?: (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => void;
}) {
  if (providerLoading) {
    return <ProviderLoadingCard />;
  }

  if (!providers.length) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-[1.35rem] border border-[#303030] bg-white/[.035] p-3"
    >
      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <WalletCards className="w-3.5 h-3.5 text-white/40" />
          <p className="text-[9px] uppercase tracking-[0.2em] text-white/40">
            Cartes trouvées
          </p>
        </div>

        <span className="text-[10px] text-white/40">
          {providers.length} piste{providers.length > 1 ? 's' : ''}
        </span>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {providers.map((provider) => (
          <ProviderSuggestionCard
            key={provider.id}
            provider={provider}
            hasTimeline={!!hasTimeline}
            guestCount={guestCount}
            onAction={onProviderAction}
          />
        ))}
      </div>
    </motion.div>
  );
}

export function CeriseChat({
  messages,
  onSend,
  disabled,
  providerSuggestions = [],
  providerLoading = false,
  hasTimeline = false,
  onProviderAction,
  guestCount = 80,
}: CeriseChatProps) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const ceriseMessagesCount = messages.filter(
    (m) => m.role === 'cerise' && !m.typing
  ).length;

  useEffect(() => {
    if (open) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [open, messages, providerSuggestions, providerLoading]);

  useEffect(() => {
    const closeOnEscape = (event: globalThis.KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };

    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, []);

  const handleSend = () => {
    const text = input.trim();

    if (!text || disabled) return;

    setInput('');
    onSend(text);
  };

  const handleKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestion = (suggestion: string) => {
    if (disabled) return;
    onSend(suggestion);
  };

  const handleProviderAction = (
    action: ProviderAction,
    provider: CeriseProviderSuggestion,
    timelinePayload?: CeriseTimelinePayload
  ) => {
    onProviderAction?.(action, provider, timelinePayload);

    /**
     * Sécurité :
     * Si le parent n’a pas encore branché onProviderAction,
     * Cerise envoie une commande texte structurée au moteur existant.
     */
    if (!onProviderAction && timelinePayload && action === 'add_to_timeline') {
      onSend(timelinePayload.timelineCommand);
    }
  };

  return (
    <div className="cerise-chat-shell">
      <AnimatePresence>
        {open && (
          <motion.div
            className="cerise-chat-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) setOpen(false);
            }}
          >
            <motion.section
              role="dialog"
              aria-modal="true"
              aria-label="Conversation avec Cerise"
              className="cerise-chat-panel"
              initial={{ opacity: 0, y: 28, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 28, scale: 0.985 }}
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            >
              <header className="cerise-chat-header">
                <div className="cerise-chat-header__identity">
                  <span className="cerise-chat-header__badge">
                    <AimeLogoIcon size={14} color="white" />
                  </span>
                  <div className="min-w-0">
                    <p>Agent orchestrateur</p>
                    <h2>Cerise</h2>
                  </div>
                </div>
                <button onClick={() => setOpen(false)} aria-label="Fermer Cerise">
                  <X size={16} strokeWidth={1.8} />
                </button>
              </header>

              <div className="cerise-chat-content">
                {messages.length === 0 && (
                  <div className="cerise-chat-intro">
                    <span className="cerise-chat-avatar">
                      <AimeLogoIcon size={14} color="white" />
                    </span>
                    <p>
                      Décrivez votre mariage librement : je relie les lieux,
                      prestataires, budgets et moments sans perdre le fil de vos choix.
                    </p>
                  </div>
                )}

                {messages.length === 0 && (
                  <div className="cerise-chat-suggestions">
                    {SUGGESTIONS.slice(0, 3).map((suggestion) => (
                      <button
                        key={suggestion}
                        onClick={() => handleSuggestion(suggestion)}
                        disabled={disabled}
                      >
                        <Sparkles size={13} strokeWidth={1.8} />
                        {suggestion}
                      </button>
                    ))}
                  </div>
                )}

                <div className="cerise-chat-messages">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`cerise-chat-message cerise-chat-message--${msg.role}`}
                    >
                      {msg.typing ? (
                        <div className="cerise-chat-typing"><TypingDots /></div>
                      ) : (
                        <>
                          <div className="cerise-chat-bubble">{msg.text}</div>
                          {msg.role === 'cerise' && msg.suggestion && (
                            <button
                              onClick={() => handleSuggestion(msg.suggestion!)}
                              disabled={disabled}
                              className="cerise-chat-followup"
                            >
                              <span>↳</span>
                              {msg.suggestion}
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  ))}
                </div>

                {(providerLoading || providerSuggestions.length > 0) && (
                  <div className="cerise-chat-providers">
                    <ProviderSuggestionsStrip
                      providers={providerSuggestions}
                      providerLoading={providerLoading}
                      hasTimeline={hasTimeline}
                      guestCount={guestCount}
                      onProviderAction={handleProviderAction}
                    />
                  </div>
                )}
                <div ref={bottomRef} />
              </div>

              <div className="cerise-chat-composer">
                <span className="cerise-chat-composer__mark">
                  <Plus size={20} />
                </span>
                <input
                  ref={inputRef}
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={handleKey}
                  placeholder="Parler à Cerise…"
                  disabled={disabled}
                />
                <button onClick={handleSend} disabled={!input.trim() || disabled} aria-label="Envoyer">
                  {disabled ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                </button>
              </div>
            </motion.section>
          </motion.div>
        )}
      </AnimatePresence>

      {!open && (
        <motion.button
          className="cerise-chat-trigger"
          onClick={() => setOpen(true)}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.99 }}
          aria-label="Ouvrir Cerise"
        >
          <span className="cerise-chat-trigger__mark"><Plus size={20} /></span>
          <span className="cerise-chat-trigger__label">Parler à Cerise…</span>
          {ceriseMessagesCount > 0 && (
            <span className="cerise-chat-trigger__count">
              {Math.min(ceriseMessagesCount, 9)}
            </span>
          )}
          <span className="cerise-chat-trigger__send"><Send size={16} /></span>
        </motion.button>
      )}
    </div>
  );
}
