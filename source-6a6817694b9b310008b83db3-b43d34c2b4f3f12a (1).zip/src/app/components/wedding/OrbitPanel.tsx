import { AlertTriangle, AlertCircle, ChevronRight, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { WeddingAnalysis } from './WeddingEngine';
import { formatEuro } from './WeddingEngine';

interface OrbitPanelProps {
  analysis: WeddingAnalysis;
  guestCount: number;
  venue: string;
  daysLeft: number | null;
  onActionClick: (action: string) => void;
}

// ─── Score Ring ───────────────────────────────────────────────────────────────

function ScoreRing({ score, confirmed, total }: { score: number; confirmed: number; total: number }) {
  const r    = 34;
  const circ = 2 * Math.PI * r;
  const dash = circ - (score / 100) * circ;
  const strokeColor = score >= 80 ? '#0a0a0a' : score >= 50 ? '#555' : '#999';

  return (
    <div className="flex items-center gap-5">
      <div className="relative w-20 h-20 flex-shrink-0">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r={r} fill="none" stroke="#f0efec" strokeWidth="5" />
          <motion.circle
            cx="40" cy="40" r={r}
            fill="none" stroke={strokeColor} strokeWidth="5" strokeLinecap="round"
            strokeDasharray={circ}
            initial={{ strokeDashoffset: circ }}
            animate={{ strokeDashoffset: dash }}
            transition={{ duration: 1.1, ease: [0.25, 0.46, 0.45, 0.94], delay: 0.3 }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.span className="text-xl font-bold text-black leading-none"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            {score}%
          </motion.span>
        </div>
      </div>

      <div className="flex-1">
        <p className="text-sm font-semibold text-black leading-snug mb-1">
          {score >= 80 ? 'Vous êtes bien avancé ✓' : score >= 50 ? 'Vous progressez bien' : 'Quelques points à définir'}
        </p>
        <p className="text-[11px] text-gray-400 leading-snug">
          Votre mariage est prêt à {score}%
        </p>
        <div className="flex items-center gap-1.5 mt-2">
          <div className="flex-1 h-1 bg-gray-100 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-black rounded-full"
              initial={{ width: '0%' }}
              animate={{ width: `${score}%` }}
              transition={{ duration: 0.9, ease: 'easeOut', delay: 0.4 }}
            />
          </div>
          <span className="text-[10px] text-gray-400 tabular-nums whitespace-nowrap">
            {confirmed}/{total} confirmés
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Panel ────────────────────────────────────────────────────────────────────

export function OrbitPanel({ analysis, guestCount, venue, daysLeft, onActionClick }: OrbitPanelProps) {
  const criticals = analysis.alerts.filter((a) => a.severity === 'critical');
  const topBudget = [...analysis.budgetLines].sort((a, b) => b.amount - a.amount).slice(0, 4);

  return (
    <motion.div
      initial={{ opacity: 0, x: 18 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden"
    >
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.2em]">Vue d'ensemble</p>
        {analysis.alerts.length > 0 && (
          <span className="flex items-center gap-1.5">
            {criticals.length > 0 && <span className="w-1.5 h-1.5 rounded-full bg-black animate-pulse" />}
            <span className="text-[10px] text-gray-500">
              {analysis.alerts.length} point{analysis.alerts.length > 1 ? 's' : ''} à régler
            </span>
          </span>
        )}
      </div>

      {/* Countdown */}
      {daysLeft !== null && daysLeft > 0 && (
        <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between bg-black">
          <div>
            <p className="text-[9px] font-bold text-white/40 uppercase tracking-widest">Compte à rebours</p>
            <p className="text-white text-sm mt-0.5">Avant le grand jour</p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-white leading-none">J-{daysLeft}</p>
          </div>
        </div>
      )}
      {daysLeft !== null && daysLeft <= 0 && (
        <div className="px-5 py-3 border-b border-gray-100 text-center">
          <p className="text-sm font-semibold text-black">🎉 Votre grand jour est arrivé !</p>
        </div>
      )}

      {/* Score */}
      <div className="px-5 py-5 border-b border-gray-100">
        <ScoreRing score={analysis.score} confirmed={analysis.confirmedCount} total={analysis.totalCount} />
      </div>

      {/* Context pills */}
      {(guestCount > 0 || venue) && (
        <div className="px-5 py-3 border-b border-gray-100 flex flex-wrap gap-2">
          {guestCount > 0 && (
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-gray-600 bg-gray-100 px-2.5 py-1 rounded-full">
              <span className="font-bold text-black">{guestCount}</span> invités
            </span>
          )}
          {venue && (
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-gray-600 bg-gray-100 px-2.5 py-1 rounded-full">
              {venue}
            </span>
          )}
        </div>
      )}

      {/* Alerts */}
      <div className="px-5 py-4 border-b border-gray-100">
        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-3">
          {analysis.alerts.length > 0 ? 'Points à corriger' : 'Points vérifiés'}
        </p>
        {analysis.alerts.length === 0 ? (
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-black flex-shrink-0" />
            <p className="text-xs text-gray-600">Tout est cohérent — rien ne manque.</p>
          </div>
        ) : (
          <div className="space-y-1.5">
            <AnimatePresence>
              {analysis.alerts.map((alert, i) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -6 }}
                  transition={{ delay: i * 0.04 }}
                  className={`flex items-start gap-2.5 px-3 py-2.5 rounded-xl text-xs leading-snug ${
                    alert.severity === 'critical'
                      ? 'bg-black text-white'
                      : 'bg-gray-50 text-gray-700 border border-gray-100'
                  }`}
                >
                  {alert.severity === 'critical'
                    ? <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-white/70" />
                    : <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-gray-400" />}
                  <span>{alert.message}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="px-5 py-4 border-b border-gray-100">
        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-2">À faire maintenant</p>
        <div className="space-y-0.5">
          {analysis.actions.map((action, i) => (
            <motion.button
              key={action}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.04 }}
              onClick={() => onActionClick(action)}
              className="w-full flex items-center justify-between gap-2 px-3 py-2.5 text-xs text-gray-700 hover:bg-black hover:text-white rounded-xl transition-all duration-200 group text-left"
            >
              <span className="font-medium">{action}</span>
              <ChevronRight className="w-3 h-3 flex-shrink-0 text-gray-400 group-hover:text-white transition-colors" />
            </motion.button>
          ))}
        </div>
      </div>

      {/* Budget estimate */}
      {analysis.budgetLines.length > 0 && (
        <div className="px-5 py-4">
          <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-3">Budget estimé</p>
          <div className="space-y-1.5 mb-3">
            {topBudget.map((line) => (
              <div key={line.label} className="flex items-center justify-between text-xs">
                <span className="text-gray-500 truncate mr-2">{line.label}</span>
                <span className={`tabular-nums font-medium flex-shrink-0 ${line.isEstimate ? 'text-gray-400' : 'text-black'}`}>
                  {line.isEstimate ? '~' : ''}{formatEuro(line.amount)}
                </span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between pt-2.5 border-t border-gray-100">
            <span className="text-xs font-semibold text-black">Total indicatif</span>
            <span className="text-base font-bold text-black">~{formatEuro(analysis.totalBudget)}</span>
          </div>
          <p className="text-[9px] text-gray-400 mt-1.5">Estimation non contractuelle</p>
        </div>
      )}

    </motion.div>
  );
}
