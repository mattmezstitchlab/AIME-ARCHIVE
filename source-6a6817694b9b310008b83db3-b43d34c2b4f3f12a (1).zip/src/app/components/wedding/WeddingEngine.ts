// ─── TYPES ────────────────────────────────────────────────────────────────────

export type EventCategory =
  | 'ceremony'
  | 'reception'
  | 'catering'
  | 'music'
  | 'photo'
  | 'preparation'
  | 'transport'
  | 'accommodation'
  | 'other';

export type EventStatus  = 'pending' | 'in_progress' | 'done';
export type TaskStatus   = 'todo' | 'done';

export interface EventTask {
  id: string;
  label: string;
  status: TaskStatus;
}

export interface WeddingEvent {
  id: string;
  title: string;
  time: string;        // "HH:MM"
  description: string;
  status: EventStatus;
  category: EventCategory;
  vendor?: string;
  budget?: number;
  tasks?: EventTask[];
  isNew?: boolean;
}

export interface WeddingConfig {
  guestCount: number;
  season: string;
  style: string;
  venue: string;
  weddingDate?: string;
  rawInput: string;
}

export type AlertSeverity = 'critical' | 'warning' | 'info';

export interface WeddingAlert {
  id: string;
  severity: AlertSeverity;
  message: string;
  action?: string;
}

export interface BudgetLine {
  label: string;
  amount: number;
  isEstimate: boolean;
}

export interface WeddingAnalysis {
  alerts: WeddingAlert[];
  score: number;         // 0–100
  actions: string[];
  confirmedCount: number;
  totalCount: number;
  budgetLines: BudgetLine[];
  totalBudget: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'cerise';
  text: string;
  suggestion?: string;   // Clickable suggestion button
  typing?: boolean;
}

// ─── UTILS ────────────────────────────────────────────────────────────────────

export const cuid = () => Math.random().toString(36).slice(2, 9);

export function sortByTime(evts: WeddingEvent[]): WeddingEvent[] {
  return [...evts].sort((a, b) => a.time.localeCompare(b.time));
}

function fmt(h: number): string {
  const hours   = Math.floor(h);
  const minutes = h % 1 === 0.5 ? '30' : '00';
  return `${String(hours).padStart(2, '0')}:${minutes}`;
}

function toMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export function formatEuro(n: number): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency', currency: 'EUR', maximumFractionDigits: 0,
  }).format(n);
}

// ─── TASK TEMPLATES ───────────────────────────────────────────────────────────

const TASK_TEMPLATES: Record<EventCategory, string[]> = {
  preparation:   ['Réserver coiffeur/coiffeuse', 'Réserver maquilleur/se', 'Essai réalisé', 'Confirmer les horaires'],
  ceremony:      ['Confirmer l\'officiant', 'Choisir les lectures / vœux', 'Préparer les alliances', 'Confirmer le lieu'],
  catering:      ['Demander des devis', 'Dégustation réalisée', 'Menu validé', 'Contrat signé', 'Acompte versé'],
  music:         ['Contacter les prestataires', 'Devis reçu', 'Contrat signé', 'Playlist / brief envoyé'],
  photo:         ['Contacter les photographes', 'Devis reçu', 'Contrat signé', 'Liste de clichés envoyée'],
  reception:     ['Confirmer le lieu', 'Menu cocktail validé', 'Décoration planifiée'],
  transport:     ['Réserver les véhicules', 'Confirmer les horaires', 'Informer les invités'],
  accommodation: ['Identifier les hébergements', 'Réserver les chambres', 'Confirmer les arrivées'],
  other:         ['À traiter'],
};

export function makeTasks(cat: EventCategory): EventTask[] {
  return (TASK_TEMPLATES[cat] || ['À traiter']).map((label) => ({
    id: cuid(), label, status: 'todo' as TaskStatus,
  }));
}

// ─── BUDGET ESTIMATES ─────────────────────────────────────────────────────────

function categoryEstimate(cat: EventCategory, guestCount: number, title = '', isLuxe = false): number {
  const luxeFactor = isLuxe ? 1.6 : 1;
  switch (cat) {
    case 'catering':      return Math.round(guestCount * (isLuxe ? 130 : 80) * luxeFactor);
    case 'photo':         return Math.round((/vidéo|video/i.test(title) ? 3800 : 2200) * luxeFactor);
    case 'music':
      if (/orchestre|orchestra/i.test(title)) return Math.round(5500 * luxeFactor);
      if (/groupe|band|quartet/i.test(title)) return Math.round(3200 * luxeFactor);
      return Math.round(1600 * luxeFactor);
    case 'ceremony':      return Math.round(700 * luxeFactor);
    case 'reception':     return Math.round(guestCount * (isLuxe ? 28 : 18) * luxeFactor);
    case 'preparation':   return Math.round(900 * luxeFactor);
    case 'transport':     return Math.round(guestCount > 100 ? 1200 : 600);
    case 'accommodation': return 0;
    default:              return 350;
  }
}

// ─── IMPROVED PARSER ──────────────────────────────────────────────────────────

export function parseWeddingInput(raw: string): {
  events: WeddingEvent[];
  config: WeddingConfig;
} {
  const t = raw.toLowerCase();

  // ── Guest count ──────────────────────────────────────────────────────────
  const guestMatch =
    raw.match(/(\d{1,4})\s*(personnes?|guests?|invités?|convives?)/i) ||
    raw.match(/\b(\d{2,4})\b/);
  const guestCount = guestMatch ? Math.min(parseInt(guestMatch[1]), 2000) : 80;

  // ── Season ───────────────────────────────────────────────────────────────
  const season =
    /été|summer|juin|juillet|août/i.test(t)          ? 'Été'       :
    /automne|autumn|fall|octobre|novembre/i.test(t)  ? 'Automne'   :
    /printemps|spring|avril|mai/i.test(t)            ? 'Printemps' :
    /hiver|winter|décembre|janvier|février/i.test(t) ? 'Hiver'     : '';

  // ── Venue ────────────────────────────────────────────────────────────────
  const venue =
    /château|manoir/i.test(t)              ? 'Château'            :
    /grange|barn/i.test(t)                 ? 'Grange'             :
    /plage|beach/i.test(t)                 ? 'Plage'              :
    /jardin|garden/i.test(t)               ? 'Jardin'             :
    /domaine/i.test(t)                     ? 'Domaine'            :
    /villa/i.test(t)                       ? 'Villa'              :
    /salle|réception/i.test(t)             ? 'Salle de réception' :
    /loft|industriel/i.test(t)             ? 'Loft'               : '';

  // ── Style ────────────────────────────────────────────────────────────────
  const style =
    /champêtre|rustique/i.test(t) ? 'Champêtre' :
    /luxe|chic|prestige|gala/i.test(t) ? 'Luxe' :
    /intime|intimate/i.test(t)    ? 'Intime'    :
    /bohème|boho/i.test(t)        ? 'Bohème'    :
    /moderne|contemporain/i.test(t) ? 'Moderne' : '';

  // ── Date extraction ──────────────────────────────────────────────────────
  let weddingDate: string | undefined;
  const isoMatch  = raw.match(/(\d{4}-\d{2}-\d{2})/);
  const slashDate = raw.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  const verbDate  = raw.match(/(\d{1,2})\s+(janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)\s+(\d{4})/i);
  const MONTHS: Record<string, string> = {
    janvier:'01', février:'02', mars:'03', avril:'04', mai:'05', juin:'06',
    juillet:'07', août:'08', septembre:'09', octobre:'10', novembre:'11', décembre:'12',
  };
  if (isoMatch)       weddingDate = isoMatch[1];
  else if (slashDate) weddingDate = `${slashDate[3]}-${slashDate[2].padStart(2,'0')}-${slashDate[1].padStart(2,'0')}`;
  else if (verbDate)  weddingDate = `${verbDate[3]}-${MONTHS[verbDate[2].toLowerCase()]}-${verbDate[1].padStart(2,'0')}`;

  // ── Context flags ─────────────────────────────────────────────────────────
  const isIntimate   = guestCount <= 40 || /intime|intimate|petit comité/i.test(t);
  const isLuxe       = /luxe|chic|prestige|gala|haut de gamme/i.test(t);
  const isCastle     = /château|manoir/i.test(t);
  const isGarden     = /jardin|garden/i.test(t);
  const isBeach      = /plage|beach/i.test(t);
  const isOutdoor    = /extérieur|outdoor|plein air/i.test(t) || isGarden || isBeach;
  const isReligious  = /église|religieux|church|catholique|protestant|messe/i.test(t);
  const isCivil      = /civil|mairie/i.test(t);
  const hasDJ        = /\bdj\b|dj\s/i.test(t);
  const hasLiveMusic = /groupe|orchestre|quartet|trio|band|live.?music|musicien/i.test(t);
  const hasSax       = /saxophone|saxo|\bsax\b/i.test(t);
  const hasPhoto     = /photo|photographe|photographer/i.test(t);
  const hasVideo     = /vidéo|video|vidéaste|cinéaste|filming/i.test(t);
  const hasTransport = /navette|limousine|voiture de mariée|bus invités/i.test(t) || guestCount > 150;
  const hasDomaine   = /domaine|château|manoir|villa/i.test(t);
  const hasLunch     = /déjeuner|brunch|lunch/i.test(t);
  const hasAfterparty = /afterparty|after.?party|brunch|lendemain/i.test(t);

  // ── Timings based on context ──────────────────────────────────────────────
  const prepHour      = isIntimate ? 10   : isLuxe ? 9   : 10;
  const mairie        = isCivil && !isReligious ? 11.0 : isReligious && isCivil ? 10.5 : null;
  const ceremonyHour  = isBeach ? 17 : isCastle ? 16 : isLuxe ? 16 : isIntimate ? 15 : 15;
  const photoHour     = ceremonyHour + (isLuxe ? 1 : 0.5);
  const cocktailHour  = ceremonyHour + (isCastle || isLuxe ? 1.5 : 1);
  const dinnerHour    = isLuxe ? 20 : isIntimate ? 19 : 19.5;
  const eveningHour   = isLuxe ? 22 : 21.5;

  const events: WeddingEvent[] = [];

  // 1. Préparatifs (toujours en premier)
  events.push({
    id: cuid(),
    title: isLuxe ? 'Préparatifs — suite nuptiale' : 'Préparatifs',
    time: fmt(prepHour),
    description: isLuxe
      ? 'Coiffure, maquillage et habillage — suite nuptiale avec l\'équipe beauté.'
      : 'Coiffure, maquillage et habillage des mariés.',
    status: 'pending', category: 'preparation',
    tasks: makeTasks('preparation'),
  });

  // 2. Mairie / Cérémonie civile
  if (mairie !== null) {
    events.push({
      id: cuid(),
      title: !isReligious ? 'Cérémonie civile — Mairie' : 'Mairie',
      time: fmt(mairie),
      description: !isReligious
        ? `Cérémonie officielle à la mairie — ${guestCount} proches.`
        : 'Passage à la mairie avant la cérémonie religieuse.',
      status: 'pending', category: 'ceremony',
      tasks: makeTasks('ceremony'),
    });
  }

  // 3. Déjeuner famille (si gap important)
  if (hasLunch || (isCivil && ceremonyHour >= 15.5)) {
    events.push({
      id: cuid(),
      title: 'Déjeuner famille',
      time: fmt(13),
      description: 'Repas intime avec les familles des mariés avant la cérémonie.',
      status: 'pending', category: 'catering',
      tasks: makeTasks('catering'),
    });
  }

  // 4. Cérémonie principale
  events.push({
    id: cuid(),
    title: isReligious
      ? 'Cérémonie religieuse'
      : isOutdoor && isGarden ? 'Cérémonie — Jardin'
      : isOutdoor && isBeach  ? 'Cérémonie — Face à la mer'
      : isOutdoor             ? 'Cérémonie en plein air'
      : 'Cérémonie',
    time: fmt(ceremonyHour),
    description: isReligious
      ? `Cérémonie à l'église — ${guestCount} invités.`
      : isOutdoor
        ? `Cérémonie en plein air${isGarden?' dans le jardin':isBeach?' face à la mer':''} — ${guestCount} invités.`
        : `Cérémonie de mariage — ${guestCount} invités.`,
    status: 'pending', category: 'ceremony',
    tasks: makeTasks('ceremony'),
  });

  // 5. Séance photo / vidéo
  if (hasPhoto || hasVideo) {
    events.push({
      id: cuid(),
      title: hasVideo && hasPhoto ? 'Séance photo & vidéo' : hasVideo ? 'Tournage vidéo' : 'Séance photo',
      time: fmt(photoHour),
      description: hasVideo && hasPhoto
        ? 'Portraits et plans cinématographiques des mariés et des familles.'
        : hasVideo
          ? 'Plans cinématographiques pour le film de mariage.'
          : 'Portraits officiels des mariés, familles et cortège.',
      status: 'pending', category: 'photo',
      tasks: makeTasks('photo'),
    });
  }

  // 6. Saxophone — cocktail (si mentionné)
  if (hasSax) {
    events.push({
      id: cuid(),
      title: 'Saxophone — ambiance cocktail',
      time: fmt(cocktailHour),
      description: 'Animation saxophone en fond sonore pendant le vin d\'honneur.',
      status: 'pending', category: 'music',
      tasks: makeTasks('music'),
    });
  }

  // 7. Vin d'honneur / Cocktail
  events.push({
    id: cuid(),
    title: isLuxe ? 'Cocktail — Vin d\'honneur' : 'Vin d\'honneur',
    time: fmt(hasSax ? cocktailHour + 0.5 : cocktailHour),
    description: isLuxe
      ? `Cocktail premium — verrines, champagne millésimé, canapés fins — ${guestCount} invités.`
      : `Cocktail de bienvenue — ${guestCount} invités.`,
    status: 'pending', category: 'reception',
    tasks: makeTasks('reception'),
  });

  // 8. Dîner
  events.push({
    id: cuid(),
    title: isLuxe ? 'Dîner de gala' : isCastle ? `Dîner — ${venue}` : 'Dîner',
    time: fmt(dinnerHour),
    description: isLuxe
      ? `Dîner gastronomique — service à table — ${guestCount} convives.`
      : `Repas de mariage${venue ? ` — ${venue}` : ''} — ${guestCount} convives.`,
    status: 'pending', category: 'catering',
    tasks: makeTasks('catering'),
  });

  // 9. Musique live (pendant dîner, si groupe mentionné)
  if (hasLiveMusic) {
    const musicTitle =
      /orchestre/i.test(t) ? 'Orchestre' :
      /quartet/i.test(t)   ? 'Quartet — pendant le dîner' :
      /trio/i.test(t)      ? 'Trio jazz — pendant le dîner' :
      'Groupe live — animation dîner';
    events.push({
      id: cuid(), title: musicTitle,
      time: fmt(dinnerHour + 0.5),
      description: 'Animation musicale live — performance pendant le repas.',
      status: 'pending', category: 'music',
      tasks: makeTasks('music'),
    });
  }

  // 10. Soirée DJ ou live
  if (hasDJ) {
    events.push({
      id: cuid(), title: 'Soirée dansante — DJ',
      time: fmt(eveningHour),
      description: 'Soirée dansante — set DJ jusqu\'à la fin de la nuit.',
      status: 'pending', category: 'music',
      tasks: makeTasks('music'),
    });
  } else if (hasLiveMusic && !hasDJ) {
    // Groupe live pour la soirée
    events.push({
      id: cuid(), title: 'Soirée — groupe live',
      time: fmt(eveningHour),
      description: 'Soirée dansante — concert et ambiance live.',
      status: 'pending', category: 'music',
      tasks: makeTasks('music'),
    });
  }

  // 11. Navettes retour
  if (hasTransport) {
    events.push({
      id: cuid(), title: 'Navettes retour invités',
      time: fmt(eveningHour + 2),
      description: guestCount > 150
        ? `Navettes organisées en plusieurs rotations — ${guestCount} invités.`
        : 'Navettes de retour pour les invités.',
      status: 'pending', category: 'transport',
      tasks: makeTasks('transport'),
    });
  }

  // 12. Hébergement (château, domaine, destination)
  if (hasDomaine || guestCount > 150) {
    events.push({
      id: cuid(), title: 'Hébergement — nuit sur place',
      time: fmt(eveningHour + 3),
      description: `Organisation des nuits sur place ou à proximité${isCastle?' — chambres du château':''}. `,
      status: 'pending', category: 'accommodation',
      tasks: makeTasks('accommodation'),
    });
  }

  // 13. Afterparty / brunch
  if (hasAfterparty) {
    events.push({
      id: cuid(), title: 'Brunch du lendemain',
      time: '11:00',
      description: 'Brunch avec les proches restés sur place.',
      status: 'pending', category: 'catering',
      tasks: makeTasks('catering'),
    });
  }

  return {
    events: sortByTime(events),
    config: { guestCount, season, style, venue, weddingDate, rawInput: raw },
  };
}

// ─── ORBIT ANALYSIS (Weighted + Temporal Logic) ───────────────────────────────

/** Score weights — critical elements weigh more */
const SCORE_WEIGHTS: Partial<Record<EventCategory, number>> = {
  catering:    18,
  ceremony:    15,
  photo:       12,
  music:       12,
  preparation: 10,
  reception:   8,
  transport:   6,
  accommodation: 4,
};
const VENUE_WEIGHT      = 15;  // from config.venue
const CONFIRMATION_MAX  = 10;  // bonus for confirmed events
// Max possible = 15 + 18 + 15 + 12 + 12 + 10 + 8 + 6 + 4 = 100 (with confirmation bonus)

export function analyzeWedding(events: WeddingEvent[], config: WeddingConfig): WeddingAnalysis {
  const cats   = new Set(events.map((e) => e.category));
  const sorted = sortByTime(events);
  const alerts: WeddingAlert[] = [];

  // ── 1. Missing critical elements ─────────────────────────────────────────
  if (!cats.has('catering'))
    alerts.push({ id: cuid(), severity: 'critical', message: "Vous n'avez pas encore de traiteur prévu", action: 'Trouver un traiteur' });
  if (!config.venue)
    alerts.push({ id: cuid(), severity: 'critical', message: "Le lieu de réception n'est pas encore défini", action: 'Choisir votre lieu' });
  if (!cats.has('photo'))
    alerts.push({ id: cuid(), severity: 'warning', message: "Aucun photographe n'est encore prévu", action: 'Réserver un photographe' });
  if (!cats.has('music'))
    alerts.push({ id: cuid(), severity: 'warning', message: "L'animation musicale n'est pas encore planifiée", action: "Planifier l'animation musicale" });

  // ── 2. Temporal logic — order validation ─────────────────────────────────
  const get = (cat: EventCategory) => sorted.find((e) => e.category === cat);

  const prepEvt      = get('preparation');
  const ceremonyEvt  = sorted.find((e) => e.category === 'ceremony' && !/mairie|civile/i.test(e.title.toLowerCase()));
  const cocktailEvt  = get('reception');
  const dinnerEvt    = get('catering');
  const eveningEvt   = sorted.filter((e) => e.category === 'music').pop();

  if (prepEvt && ceremonyEvt && toMinutes(prepEvt.time) >= toMinutes(ceremonyEvt.time))
    alerts.push({ id: cuid(), severity: 'warning', message: `Les préparatifs (${prepEvt.time}) sont planifiés après la cérémonie (${ceremonyEvt.time})` });

  if (cocktailEvt && ceremonyEvt && toMinutes(cocktailEvt.time) <= toMinutes(ceremonyEvt.time))
    alerts.push({ id: cuid(), severity: 'warning', message: `Le vin d'honneur (${cocktailEvt.time}) est avant la cérémonie (${ceremonyEvt.time})` });

  if (dinnerEvt && cocktailEvt && toMinutes(dinnerEvt.time) < toMinutes(cocktailEvt.time))
    alerts.push({ id: cuid(), severity: 'warning', message: `Le dîner (${dinnerEvt.time}) est planifié avant le vin d'honneur (${cocktailEvt.time})` });

  if (eveningEvt && toMinutes(eveningEvt.time) < toMinutes('20:00'))
    alerts.push({ id: cuid(), severity: 'warning', message: `La soirée commence à ${eveningEvt.time} — vérifiez que c'est intentionnel` });

  // ── 3. Capacity warning ───────────────────────────────────────────────────
  if (config.guestCount > 150 && !config.venue)
    alerts.push({ id: cuid(), severity: 'warning', message: `Vérifiez la capacité du lieu pour ${config.guestCount} invités — commencez la recherche tôt` });

  // ── 4. Timeline gap > 3h ─────────────────────────────────────────────────
  const mins = sorted.map((e) => toMinutes(e.time));
  for (let i = 0; i < mins.length - 1; i++) {
    if (mins[i + 1] - mins[i] > 180) {
      alerts.push({ id: cuid(), severity: 'info', message: `Temps libre de ${Math.round((mins[i+1]-mins[i])/60)}h dans votre journée (${sorted[i].time} → ${sorted[i+1].time})` });
      break;
    }
  }

  // ── 5. Weighted score ─────────────────────────────────────────────────────
  let score = 0;
  if (config.venue) score += VENUE_WEIGHT;
  for (const cat of cats) {
    score += SCORE_WEIGHTS[cat] ?? 0;
  }
  const confirmedCount = events.filter((e) => e.status === 'done').length;
  const confirmRatio   = events.length > 0 ? confirmedCount / events.length : 0;
  score += Math.round(confirmRatio * CONFIRMATION_MAX);
  score  = Math.min(100, score);

  // ── 6. Actions prioritaires ───────────────────────────────────────────────
  const actions: string[] = [
    ...alerts.filter((a) => a.action && a.severity !== 'info').map((a) => a.action as string),
    ...(confirmedCount === 0 ? ['Confirmer votre premier prestataire'] : []),
    ...(events.length > 0 && !events.some((e) => e.vendor) ? ['Renseigner vos prestataires'] : []),
  ].slice(0, 5);

  // ── 7. Budget ─────────────────────────────────────────────────────────────
  const isLuxe = /luxe|chic|prestige|gala/i.test(config.style);
  const budgetLines: BudgetLine[] = events
    .filter((e) => e.category !== 'accommodation')
    .map((e) => ({
      label: e.title,
      amount: e.budget ?? categoryEstimate(e.category, config.guestCount, e.title, isLuxe),
      isEstimate: !e.budget,
    }));
  const totalBudget = budgetLines.reduce((s, l) => s + l.amount, 0);

  return {
    alerts, score, actions,
    confirmedCount, totalCount: events.length,
    budgetLines, totalBudget,
  };
}

// ─── OFFLINE CHAT FALLBACK ────────────────────────────────────────────────────
// Used only when Claude API is unavailable

export function parseChatCommand(
  text: string,
  events: WeddingEvent[],
  config: WeddingConfig,
): { updatedEvents: WeddingEvent[]; response: string } {
  const t = text.toLowerCase();

  const timeMatch = text.match(/(\d{1,2})[h:](\d{2})?/);
  const timeStr   = timeMatch ? `${String(parseInt(timeMatch[1])).padStart(2,'0')}:${timeMatch[2]||'00'}` : null;

  const add = (title: string, time: string, desc: string, cat: EventCategory) => ({
    updatedEvents: sortByTime([...events, {
      id: cuid(), title, time, description: desc,
      status: 'pending' as EventStatus, category: cat,
      tasks: makeTasks(cat), isNew: true,
    }]),
    response: `Ajouté — "${title}" à ${time}.`,
  });

  if (/\bajoute[rz]?\b|add\b/i.test(t)) {
    if (/\bdj\b|soirée danc/i.test(t))          return add('Soirée DJ',       timeStr||'22:00', 'Animation musicale — soirée dansante.', 'music');
    if (/photo/i.test(t))                        return add('Séance photo',    timeStr||'14:30', 'Séance photo des mariés.', 'photo');
    if (/traiteur|repas|dîner|cater/i.test(t))  return add('Dîner',          timeStr||'19:30', 'Repas de mariage.', 'catering');
    if (/cocktail|vin d.?honneur/i.test(t))      return add("Vin d'honneur",  timeStr||'17:00', 'Cocktail de bienvenue.', 'reception');
    if (/groupe|orchestre|musicien/i.test(t))    return add('Groupe live',    timeStr||'21:00', 'Animation musicale live.', 'music');
    if (/transport|navette/i.test(t))            return add('Navettes',       timeStr||'23:30', 'Navettes retour invités.', 'transport');
    if (/saxo/i.test(t))                         return add('Saxophone',      timeStr||'17:30', 'Animation saxophone — cocktail.', 'music');
    const clean = text.replace(/ajoute[rz]?|add/gi,'').replace(/à \d+h\d*/gi,'').trim();
    if (clean.length > 2) return add(clean.charAt(0).toUpperCase()+clean.slice(1), timeStr||'18:00', clean, 'other');
  }

  if (/décale[rz]?|déplace[rz]?|move\b|change[rz]?|modifie/i.test(t) && timeStr) {
    const mv = (cat: EventCategory, name: string) => ({
      updatedEvents: sortByTime(events.map((e) => e.category === cat ? { ...e, time: timeStr! } : e)),
      response: `${name} déplacé à ${timeStr}.`,
    });
    if (/cérémonie|ceremony/i.test(t)) return mv('ceremony',  'Cérémonie');
    if (/dîner|dinner|repas/i.test(t)) return mv('catering',  'Dîner');
    if (/cocktail|vin/i.test(t))       return mv('reception', "Vin d'honneur");
    if (/dj|soirée/i.test(t))          return mv('music',     'Soirée');
    if (/photo/i.test(t))              return mv('photo',     'Séance photo');
  }

  if (/confirm|valide[rz]?|done/i.test(t)) {
    const confirm = (cat: EventCategory, name: string) => ({
      updatedEvents: events.map((e) => e.category===cat ? {...e,status:'done' as EventStatus} : e),
      response: `${name} marqué comme confirmé.`,
    });
    if (/cérémonie|ceremony/i.test(t)) return confirm('ceremony', 'Cérémonie');
    if (/photo/i.test(t))              return confirm('photo',    'Photographe');
    if (/traiteur|dîner/i.test(t))     return confirm('catering', 'Traiteur');
    if (/dj|soirée/i.test(t))          return confirm('music',    'Animation');
  }

  if (/supprime[rz]?|enlève[rz]?|remove\b|retire[rz]?/i.test(t)) {
    if (/dj|soirée/i.test(t))      return { updatedEvents: events.filter((e)=>e.category!=='music'), response: 'Soirée retirée.' };
    if (/photo/i.test(t))          return { updatedEvents: events.filter((e)=>e.category!=='photo'), response: 'Photo retirée.' };
    if (/traiteur|dîner/i.test(t)) return { updatedEvents: events.filter((e)=>e.category!=='catering'), response: 'Dîner retiré.' };
  }

  if (/budget|coût|prix/i.test(t)) {
    const { totalBudget } = analyzeWedding(events, config);
    return { updatedEvents: events, response: `Budget estimé : environ ${formatEuro(totalBudget)} — chiffre indicatif.` };
  }

  if (/score|pourcent|complet|fini/i.test(t)) {
    const { score, alerts } = analyzeWedding(events, config);
    return { updatedEvents: events, response: `Organisation à ${score}%.${alerts.length>0 ? ` Il reste ${alerts.length} point${alerts.length>1?'s':''} à régler.` : ' Tout est en ordre !'}` };
  }

  return {
    updatedEvents: events,
    response: "Je suis en mode hors-ligne. Essayez : \"Ajoute un DJ à 22h\", \"Décale le dîner à 20h\", ou \"Quel est mon budget ?\".",
  };
}