import {
  Heart, Utensils, Music, Camera, Sparkles, Car, Wine,
  Circle, Pencil, Trash2, Clock, Building2, ChevronDown, CheckSquare, Square,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState, type ComponentType } from 'react';
import type { WeddingEvent, EventCategory, EventStatus, EventTask, TaskStatus } from './WeddingEngine';
import { formatEuro } from './WeddingEngine';

// ─── Category meta ────────────────────────────────────────────────────────────

const CAT_META: Record<EventCategory, {
  icon: ComponentType<{ className?: string }>;
  label: string;
  border: string;
}> = {
  ceremony:      { icon: Heart,     label: 'Cérémonie',   border: 'border-l-gray-900' },
  catering:      { icon: Utensils,  label: 'Repas',       border: 'border-l-gray-600' },
  music:         { icon: Music,     label: 'Musique',     border: 'border-l-gray-500' },
  photo:         { icon: Camera,    label: 'Photo',       border: 'border-l-gray-800' },
  preparation:   { icon: Sparkles,  label: 'Préparatifs', border: 'border-l-gray-400' },
  reception:     { icon: Wine,      label: 'Réception',   border: 'border-l-gray-500' },
  transport:     { icon: Car,       label: 'Transport',   border: 'border-l-gray-300' },
  accommodation: { icon: Building2, label: 'Hébergement', border: 'border-l-gray-300' },
  other:         { icon: Circle,    label: 'Autre',       border: 'border-l-gray-200' },
};

// ─── Status helpers ───────────────────────────────────────────────────────────

const STATUS_CFG: Record<EventStatus, { label: string; dot: string; pill: string }> = {
  pending:     { label: 'En attente',  dot: 'bg-white border-2 border-gray-400', pill: 'bg-gray-100 text-gray-500' },
  in_progress: { label: 'En cours',    dot: 'bg-gray-600',                       pill: 'bg-gray-800 text-white' },
  done:        { label: 'Confirmé',    dot: 'bg-black',                          pill: 'bg-black text-white' },
};

const STATUS_ORDER: EventStatus[] = ['pending', 'in_progress', 'done'];

function nextStatus(s: EventStatus): EventStatus {
  const i = STATUS_ORDER.indexOf(s);
  return STATUS_ORDER[(i + 1) % STATUS_ORDER.length];
}

// ─── Inline Edit Panel ────────────────────────────────────────────────────────

function EditPanel({
  event,
  onSave,
  onClose,
}: {
  event: WeddingEvent;
  onSave: (fields: Partial<WeddingEvent>) => void;
  onClose: () => void;
}) {
  const [title, setTitle] = useState(event.title);
  const [time, setTime] = useState(event.time);
  const [desc, setDesc] = useState(event.description);
  const [vendor, setVendor] = useState(event.vendor ?? '');
  const [budget, setBudget] = useState(event.budget ? String(event.budget) : '');

  const [musicTitle, setMusicTitle] = useState(event.music?.title ?? '');
  const [musicArtist, setMusicArtist] = useState(event.music?.artist ?? '');

  return (
    <motion.div
      initial={{ opacity: 0, y: -6, scale: 0.99 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.16 }}
      className="mt-3 pt-3 border-t border-gray-100 space-y-2"
    >
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Titre"
        className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-400"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <div>
          <p className="text-[9px] text-gray-400 mb-1 uppercase">Horaire</p>
          <input
            value={time}
            onChange={(e) => setTime(e.target.value)}
            type="time"
            className="w-full text-xs px-2.5 py-2 bg-gray-50 border border-gray-200 rounded-xl"
          />
        </div>

        <div>
          <p className="text-[9px] text-gray-400 mb-1 uppercase">Budget €</p>
          <input
            value={budget}
            onChange={(e) => setBudget(e.target.value.replace(/\D/g, ''))}
            className="w-full text-xs px-2.5 py-2 bg-gray-50 border border-gray-200 rounded-xl"
          />
        </div>
      </div>

      <input
        value={vendor}
        onChange={(e) => setVendor(e.target.value)}
        placeholder="Prestataire"
        className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl"
      />

      <textarea
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
        rows={2}
        placeholder="Description"
        className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl resize-none"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <input
          value={musicTitle}
          onChange={(e) => setMusicTitle(e.target.value)}
          placeholder="Titre musique"
          className="w-full text-xs px-2.5 py-2 bg-gray-50 border border-gray-200 rounded-xl"
        />
        <input
          value={musicArtist}
          onChange={(e) => setMusicArtist(e.target.value)}
          placeholder="Artiste"
          className="w-full text-xs px-2.5 py-2 bg-gray-50 border border-gray-200 rounded-xl"
        />
      </div>

      <div className="flex flex-wrap gap-2 justify-end pt-1">
        <button
          onClick={onClose}
          className="text-xs px-3 py-1.5 text-gray-500 hover:bg-gray-100 rounded-xl"
        >
          Annuler
        </button>

        <button
          onClick={() => {
            onSave({
              title,
              time,
              description: desc,
              vendor: vendor.trim() || undefined,
              budget: budget ? parseInt(budget) : undefined,
              music: musicTitle
                ? { title: musicTitle, artist: musicArtist }
                : undefined,
            });

            onClose();
          }}
          className="text-xs px-4 py-1.5 bg-black text-white rounded-xl"
        >
          Enregistrer
        </button>
      </div>
    </motion.div>
  );
}

// ─── Tasks Panel ──────────────────────────────────────────────────────────────

function TasksPanel({
  tasks,
  onToggle,
}: {
  tasks: EventTask[];
  onToggle: (taskId: string, status: TaskStatus) => void;
}) {
  const doneCount = tasks.filter((t) => t.status === 'done').length;

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.2 }}
      className="overflow-hidden"
    >
      <div className="mt-2 pt-2.5 border-t border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.15em]">
            Étapes
          </p>
          <span className="text-[9px] text-gray-400 tabular-nums">
            {doneCount}/{tasks.length}
          </span>
        </div>

        <div className="h-0.5 bg-gray-100 rounded-full mb-2.5 overflow-hidden">
          <motion.div
            className="h-full bg-black rounded-full"
            initial={{ width: '0%' }}
            animate={{ width: `${tasks.length > 0 ? (doneCount / tasks.length) * 100 : 0}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>

        <div className="space-y-1">
          {tasks.map((task) => (
            <button
              key={task.id}
              onClick={() => onToggle(task.id, task.status === 'done' ? 'todo' : 'done')}
              className="w-full flex items-center gap-2 py-1 hover:bg-gray-50 rounded-lg transition-colors text-left"
            >
              {task.status === 'done'
                ? <CheckSquare className="w-3.5 h-3.5 text-black flex-shrink-0" />
                : <Square className="w-3.5 h-3.5 text-gray-300 flex-shrink-0" />
              }

              <span className={`text-xs ${task.status === 'done' ? 'line-through text-gray-400' : 'text-gray-600'}`}>
                {task.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────

function TimelineCard({
  event,
  isLeft,
  onDelete,
  onUpdate,
}: {
  event: WeddingEvent;
  isLeft: boolean;
  onDelete: () => void;
  onUpdate: (fields: Partial<WeddingEvent>) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [showTasks, setShowTasks] = useState(false);

  const meta = CAT_META[event.category] ?? CAT_META.other;
  const Icon = meta.icon;
  const sCfg = STATUS_CFG[event.status];

  const tasks = event.tasks ?? [];
  const tasksDone = tasks.filter((t) => t.status === 'done').length;
  const hasTasks = tasks.length > 0;

  const handleTaskToggle = (taskId: string, newStatus: TaskStatus) => {
    const updated = tasks.map((t) =>
      t.id === taskId ? { ...t, status: newStatus } : t
    );
    onUpdate({ tasks: updated });
  };

  return (
    <div
      className={`
        relative flex w-full pl-9 md:pl-0
        ${isLeft ? 'md:justify-start' : 'md:justify-end'}
      `}
    >
      {/* DOT — à gauche sur mobile, au centre sur desktop */}
      <div className="absolute left-3 md:left-1/2 top-[26px] -translate-x-1/2 z-10 w-2.5 h-2.5 rounded-full bg-black" />

      {/* TIME — affichée au centre uniquement sur desktop */}
      <div className="hidden md:block absolute left-1/2 top-[42px] -translate-x-1/2 text-[10px] text-gray-400">
        {event.time}
      </div>

      {/* CARD */}
      <div
        className={`
          w-full md:w-[44%]
          ${isLeft ? 'md:mr-[6%]' : 'md:ml-[6%]'}
        `}
      >
        <motion.div
          whileHover={{ y: -2 }}
          transition={{ duration: 0.18 }}
          className={`
            group relative bg-white/95 backdrop-blur-sm rounded-2xl border border-gray-200
            border-l-[3px] ${meta.border}
            shadow-sm hover:shadow-md transition
            ${event.isNew ? 'ring-2 ring-black/10' : ''}
          `}
        >
          {event.isNew && (
            <span className="absolute -top-px right-4 text-[9px] font-bold bg-black text-white px-2 py-0.5 rounded-b-lg tracking-wider">
              NOUVEAU
            </span>
          )}

          <div className="p-3.5 sm:p-4">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2 min-w-0 pt-0.5">
                <Icon className="w-3.5 h-3.5 text-gray-600 flex-shrink-0" />
                <span className="text-sm font-semibold text-black truncate">
                  {event.title}
                </span>
              </div>

              {/* Actions visibles sur mobile, au hover sur desktop */}
              <div className="flex gap-1 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition flex-shrink-0">
                <button
                  onClick={() => setEditing((v) => !v)}
                  className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400"
                  aria-label="Modifier"
                >
                  <Pencil className="w-3 h-3" />
                </button>

                <button
                  onClick={() =>
                    window.confirm('Supprimer cet événement ?') && onDelete()
                  }
                  className="p-1.5 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500"
                  aria-label="Supprimer"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>

            {event.description && (
              <p className="text-xs text-gray-600 mb-2 leading-relaxed">
                {event.description}
              </p>
            )}

            {event.music && (
              <div className="mt-2 flex items-start gap-2 text-xs text-gray-500 border-t pt-2">
                <Music className="w-3 h-3 mt-0.5 flex-shrink-0" />
                <span className="leading-relaxed">
                  {event.music.title}
                  {event.music.artist && ` — ${event.music.artist}`}
                </span>
              </div>
            )}

            {hasTasks && (
              <div className="mt-2 text-xs text-gray-400">
                {tasksDone}/{tasks.length} tâches
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-gray-100 mt-2">
              <div className="flex items-center gap-2 min-w-0">
                <Clock className="w-3 h-3 text-gray-400 flex-shrink-0" />
                <span className="text-[11px] text-gray-400">{event.time}</span>

                {hasTasks && (
                  <button
                    onClick={() => setShowTasks((v) => !v)}
                    className="text-[10px] text-gray-400 hover:text-black flex items-center gap-1"
                  >
                    {tasksDone}/{tasks.length}
                    <ChevronDown
                      className={`w-3 h-3 transition ${
                        showTasks ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                )}
              </div>

              <button
                onClick={() =>
                  onUpdate({
                    status: nextStatus(event.status),
                    isNew: false,
                  })
                }
                className={`text-[10px] px-2 py-0.5 rounded-full ${sCfg.pill}`}
              >
                {sCfg.label}
              </button>
            </div>

            <AnimatePresence>
              {showTasks && hasTasks && (
                <TasksPanel tasks={tasks} onToggle={handleTaskToggle} />
              )}
            </AnimatePresence>

            <AnimatePresence>
              {editing && (
                <EditPanel
                  event={event}
                  onSave={(fields) => onUpdate(fields)}
                  onClose={() => setEditing(false)}
                />
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

// ─── Timeline ────────────────────────────────────────────────────────────────

interface WeddingTimelineProps {
  events: WeddingEvent[];
  onDeleteEvent: (id: string) => void;
  onUpdateEvent: (id: string, fields: Partial<WeddingEvent>) => void;
}

export function WeddingTimeline({
  events,
  onDeleteEvent,
  onUpdateEvent,
}: WeddingTimelineProps) {
  if (events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 md:py-24 text-center px-4">
        <div className="text-5xl mb-4">💍</div>
        <p className="text-gray-400 text-sm">
          Décrivez votre mariage pour générer votre journée.
        </p>
      </div>
    );
  }

  return (
    <div className="relative pb-12 md:pb-16 w-full max-w-full overflow-hidden">
      {/* Ligne verticale — gauche sur mobile, centre sur desktop */}
      <div className="absolute left-3 md:left-1/2 top-0 bottom-0 w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-gray-200 to-transparent pointer-events-none" />

      <motion.div
        className="space-y-5 md:space-y-7"
        variants={{ show: { transition: { staggerChildren: 0.07 } } }}
        initial="hidden"
        animate="show"
      >
        {events.map((event, i) => (
          <TimelineCard
            key={event.id}
            event={event}
            isLeft={i % 2 === 0}
            onDelete={() => onDeleteEvent(event.id)}
            onUpdate={(fields) => onUpdateEvent(event.id, fields)}
          />
        ))}
      </motion.div>

      <div className="relative flex justify-start md:justify-center mt-8 md:mt-10 pl-9 md:pl-0">
        <div className="flex items-center gap-2 text-[10px] text-gray-400 bg-white/90 backdrop-blur-sm border border-gray-200 px-4 py-2 rounded-full shadow-sm">
          <Heart className="w-3 h-3" />
          <span>Fin de votre journée</span>
          <Heart className="w-3 h-3" />
        </div>
      </div>
    </div>
  );
}