import { useState } from 'react';
import { X, UserPlus } from 'lucide-react';

interface CreateDossierModalProps {
  open: boolean;
  onClose: () => void;
  onCreate: (data: { name: string; relationStatus: string; participation: string }) => Promise<void>;
}

const RELATION_OPTIONS = [
  { value: 'célibataire',  label: 'Célibataire' },
  { value: 'marié',        label: 'Marié(e)'    },
  { value: 'pacs',         label: 'Pacsé(e)'    },
  { value: 'concubinage',  label: 'Concubinage' },
  { value: 'divorcé',      label: 'Divorcé(e)'  },
];

const PARTICIPATION_OPTIONS = [
  { value: 'participant',     label: "Participant à l'exploitation" },
  { value: 'non-participant', label: 'Non participant'               },
];

export function CreateDossierModal({ open, onClose, onCreate }: CreateDossierModalProps) {
  const [name, setName] = useState('');
  const [relationStatus, setRelationStatus] = useState('célibataire');
  const [participation, setParticipation] = useState('non-participant');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { setError('Le nom est obligatoire.'); return; }
    setLoading(true);
    setError(null);
    try {
      await onCreate({ name: name.trim(), relationStatus, participation });
      setName(''); setRelationStatus('célibataire'); setParticipation('non-participant');
      onClose();
    } catch (err) { setError(String(err)); } finally { setLoading(false); }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-black flex items-center justify-center">
              <UserPlus className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-black text-base font-bold tracking-tight">Nouveau dossier</h2>
              <p className="text-xs text-gray-400">Créer un dossier assuré</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="px-3 py-2 bg-black text-white rounded-xl text-sm">{error}</div>
          )}

          {/* Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Nom complet
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="ex. Marie Dupont"
              autoFocus
              className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-black placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-gray-400 transition-all"
            />
          </div>

          {/* Relation status */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Situation familiale
            </label>
            <div className="grid grid-cols-3 gap-2">
              {RELATION_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setRelationStatus(opt.value)}
                  className={`px-3 py-2 text-xs rounded-xl border transition-all ${
                    relationStatus === opt.value
                      ? 'bg-black text-white border-black font-semibold'
                      : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Participation */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Participation
            </label>
            <div className="grid grid-cols-2 gap-2">
              {PARTICIPATION_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setParticipation(opt.value)}
                  className={`px-3 py-2 text-xs rounded-xl border transition-all ${
                    participation === opt.value
                      ? 'bg-black text-white border-black font-semibold'
                      : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-1">
            <button
              type="button" onClick={onClose}
              className="flex-1 px-4 py-2.5 text-sm text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-all active:scale-[0.99]"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || !name.trim()}
              className="flex-1 px-4 py-2.5 text-sm font-semibold text-white bg-black rounded-xl hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.99]"
            >
              {loading ? 'Création…' : 'Créer le dossier'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
