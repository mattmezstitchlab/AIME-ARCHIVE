import { useState } from 'react';
import { Search, Plus } from 'lucide-react';

export interface Case {
  id: string;
  name: string;
  status: 'coherent' | 'warning' | 'critical';
  lastUpdate: string;
}

interface CaseListProps {
  cases: Case[];
  selectedId: string;
  onSelect: (id: string) => void;
  search: string;
  onSearchChange: (value: string) => void;
  onCreate: () => void;
  loading?: boolean;
}

type Filter = 'all' | 'critical' | 'warning' | 'coherent';

// Strict black/white/gray — dot intensity indicates severity
const statusDot: Record<Case['status'], string> = {
  critical: 'bg-black',
  warning:  'bg-gray-500',
  coherent: 'bg-gray-300',
};

const statusLabel: Record<Case['status'], string> = {
  critical: 'Prioritaire',
  warning:  'Alerte',
  coherent: 'Cohérent',
};

// Badge shown on unselected row
const statusBadge: Record<Case['status'], string> = {
  critical: 'bg-black text-white',
  warning:  'bg-gray-200 text-gray-700',
  coherent: 'bg-gray-100 text-gray-500',
};

export function CaseList({
  cases, selectedId, onSelect, search, onSearchChange, onCreate, loading,
}: CaseListProps) {
  const [filter, setFilter] = useState<Filter>('all');

  const counts = {
    all:      cases.length,
    critical: cases.filter((c) => c.status === 'critical').length,
    warning:  cases.filter((c) => c.status === 'warning').length,
    coherent: cases.filter((c) => c.status === 'coherent').length,
  };

  const filtered = filter === 'all' ? cases : cases.filter((c) => c.status === filter);

  const filters: { key: Filter; label: string }[] = [
    { key: 'all',      label: 'Tous'       },
    { key: 'critical', label: 'Prioritaire'},
    { key: 'warning',  label: 'Alerte'     },
    { key: 'coherent', label: 'Cohérent'   },
  ];

  return (
    <div className="h-full flex flex-col bg-white border-r border-gray-100">
      {/* Top controls */}
      <div className="p-4 border-b border-gray-100 space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          <input
            type="text"
            placeholder="Rechercher un dossier…"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-transparent rounded-xl text-sm text-black placeholder:text-gray-400 focus:outline-none focus:bg-white focus:border-gray-200 focus:ring-2 focus:ring-black/5 transition-all"
          />
        </div>
        <button
          onClick={onCreate}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-black text-white text-sm font-semibold rounded-xl hover:bg-gray-800 active:scale-[0.99] transition-all"
        >
          <Plus className="w-4 h-4" />
          Nouveau dossier
        </button>
      </div>

      {/* Filter chips */}
      <div className="px-3 py-2.5 border-b border-gray-100 flex gap-1 overflow-x-auto">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              filter === f.key
                ? 'bg-black text-white'
                : 'text-gray-500 hover:bg-gray-100'
            }`}
          >
            {f.label}
            {counts[f.key] > 0 && (
              <span className={`tabular-nums ${filter === f.key ? 'text-white/60' : 'text-gray-400'}`}>
                {counts[f.key]}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-2 py-2">
        {loading && (
          <div className="space-y-1.5 px-1">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="px-3 py-3 rounded-xl bg-gray-50 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-gray-200 flex-shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 w-3/4 bg-gray-200 rounded-full" />
                    <div className="h-2.5 w-1/2 bg-gray-100 rounded-full" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <div className="px-3 py-8 text-center">
            <div className="text-sm text-gray-400">Aucun dossier trouvé.</div>
          </div>
        )}

        <div className="space-y-0.5">
          {filtered.map((c) => {
            const selected = selectedId === c.id;
            return (
              <button
                key={c.id}
                onClick={() => onSelect(c.id)}
                className={`group w-full px-3 py-3 rounded-xl text-left transition-all ${
                  selected
                    ? 'bg-black text-white shadow-sm'
                    : 'hover:bg-gray-50 text-black'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-2 ${
                    selected ? 'bg-white/60' : statusDot[c.status]
                  }`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-sm font-medium leading-snug truncate">{c.name}</span>
                      <span className={`text-[9px] uppercase tracking-wider font-semibold flex-shrink-0 px-1.5 py-0.5 rounded-md mt-0.5 ${
                        selected ? 'bg-white/15 text-white/70' : statusBadge[c.status]
                      }`}>
                        {statusLabel[c.status]}
                      </span>
                    </div>
                    <div className={`text-xs mt-0.5 truncate ${selected ? 'text-white/50' : 'text-gray-400'}`}>
                      {c.lastUpdate}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
