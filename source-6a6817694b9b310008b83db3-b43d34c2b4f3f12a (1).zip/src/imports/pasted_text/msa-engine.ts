AIME — MOTEUR MSA RÉEL (INTÉGRÉ APPLICATION)

━━━━━━━━━━━━━━━━━━━
0. INTÉGRATION DANS TON APP
━━━━━━━━━━━━━━━━━━━

TON UI EXISTANTE :
- Sidebar = dossiers
- Core = timeline (events)
- AI Panel = analyse

👉 Le moteur MSA alimente :
- la timeline (events structurés)
- le panel IA (alerts + actions)

RÈGLE :
UI = affichage
ENGINE = vérité

━━━━━━━━━━━━━━━━━━━
1. EXTENSION MODÈLE DATA (SPÉCIFIQUE MSA)
━━━━━━━━━━━━━━━━━━━

Ajouter dans "dossiers" :

- regime (agricole, general)
- statut_relationnel (celibataire, marie, divorce, concubinage, pacs)
- statut_pro (exploitant, salarie_agricole, conjoint_participant, conjoint_non_participant)
- participation_agricole (participant, non_participant, inconnu)
- date_statut_relationnel

Ajouter dans events.metadata :

{
  "declared": true | false,
  "source": "msa" | "caf" | "user",
  "confidence": 0.0 → 1.0
}

━━━━━━━━━━━━━━━━━━━
2. RÈGLES MÉTIER MSA (VERSION RÉALISTE V1)
━━━━━━━━━━━━━━━━━━━

IMPORTANT :
Ce ne sont PAS des lois exhaustives,
mais des règles cohérentes et testables.

RÈGLE 1 — Cohérence relationnelle

SI :
- statut_relationnel = "marié"
ET aucun event "mariage"

→ ALERTE :
"Statut marié sans événement mariage"

---

RÈGLE 2 — Divorce non propagé

SI :
- event divorce existe
ET statut_relationnel != "divorce"

→ ALERTE :
"Statut non mis à jour après divorce"

---

RÈGLE 3 — Concubinage non déclaré

SI :
- event concubinage
ET metadata.declared = false

→ ALERTE :
"Concubinage non déclaré (impact prestations)"

---

RÈGLE 4 — Conjoint agricole incohérent

SI :
- statut_pro = conjoint_participant
ET participation_agricole != "participant"

→ ALERTE :
"Incohérence statut conjoint participant"

---

RÈGLE 5 — Activité agricole sans statut

SI :
- event emploi.type = "agricole"
ET statut_pro est vide

→ ALERTE :
"Statut professionnel manquant (activité agricole détectée)"

---

RÈGLE 6 — Chevauchement relation

SI :
- mariage actif
ET concubinage actif

→ ALERTE :
"Relations simultanées incohérentes"

---

RÈGLE 7 — Documents critiques manquants

SI :
- divorce détecté
ET aucun document "acte_divorce"

→ ALERTE :
"Acte de divorce manquant"

━━━━━━━━━━━━━━━━━━━
3. MOTEUR D’ANALYSE COMPLET
━━━━━━━━━━━━━━━━━━━

export function analyzeMSA(dossier, events, documents) {

  const alerts = []

  const get = (type) => events.filter(e => e.type === type)
  const has = (type) => get(type).length > 0

  // 1. Statut vs événements
  if (dossier.statut_relationnel === "marie" && !has("mariage")) {
    alerts.push({
      type: "status_error",
      message: "Statut marié sans événement mariage",
      severity: "high"
    })
  }

  // 2. Divorce non propagé
  if (has("divorce") && dossier.statut_relationnel !== "divorce") {
    alerts.push({
      type: "status_update",
      message: "Statut non mis à jour après divorce",
      severity: "high"
    })
  }

  // 3. Concubinage non déclaré
  const concubinage = get("concubinage")[0]
  if (concubinage && concubinage.metadata?.declared === false) {
    alerts.push({
      type: "declaration",
      message: "Concubinage non déclaré",
      severity: "medium"
    })
  }

  // 4. Conjoint agricole incohérent
  if (
    dossier.statut_pro === "conjoint_participant" &&
    dossier.participation_agricole !== "participant"
  ) {
    alerts.push({
      type: "agri_status",
      message: "Statut conjoint agricole incohérent",
      severity: "high"
    })
  }

  // 5. Activité agricole sans statut
  const agriEvent = events.find(e => e.type === "emploi" && e.metadata?.sector === "agricole")
  if (agriEvent && !dossier.statut_pro) {
    alerts.push({
      type: "missing_status",
      message: "Statut professionnel agricole manquant",
      severity: "medium"
    })
  }

  // 6. Documents manquants
  const hasDivorceDoc = documents.find(d => d.type === "acte_divorce")
  if (has("divorce") && !hasDivorceDoc) {
    alerts.push({
      type: "missing_doc",
      message: "Acte de divorce manquant",
      severity: "high"
    })
  }

  return alerts
}

━━━━━━━━━━━━━━━━━━━
4. GÉNÉRATION D’ACTIONS (MSA)
━━━━━━━━━━━━━━━━━━━

export function generateMSAActions(alerts) {

  return alerts.map(a => {

    if (a.type === "declaration") {
      return {
        label: "Demander déclaration de concubinage",
        type: "request_declaration"
      }
    }

    if (a.type === "missing_doc") {
      return {
        label: "Demander acte de divorce",
        type: "request_document"
      }
    }

    if (a.type === "status_update") {
      return {
        label: "Mettre à jour statut relationnel",
        type: "update_status"
      }
    }

    return {
      label: "Analyser dossier",
      type: "review"
    }
  })
}

━━━━━━━━━━━━━━━━━━━
5. PIPELINE RÉEL DANS TON APP
━━━━━━━━━━━━━━━━━━━

UPLOAD DOCUMENT
↓
OCR (option)
↓
events créés
↓
analyzeMSA()
↓
alerts
↓
generateMSAActions()
↓
affichage dans AI PANEL

━━━━━━━━━━━━━━━━━━━
6. VÉRITÉ (IMPORTANTE)
━━━━━━━━━━━━━━━━━━━

Ce moteur :

✔ est réaliste
✔ est cohérent
✔ est testable

MAIS :

❌ ce n’est PAS encore une vérité juridique officielle
❌ il nécessite validation métier MSA réelle

━━━━━━━━━━━━━━━━━━━
7. POURQUOI C’EST DÉJÀ PUISSANT
━━━━━━━━━━━━━━━━━━━

Parce que tu passes de :

“lecture humaine lente”

à :

“détection automatique d’incohérences”

👉 c’est déjà une révolution opérationnelle

━━━━━━━━━━━━━━━━━━━
8. CE QUI RESTE POUR ÊTRE 100% RÉEL
━━━━━━━━━━━━━━━━━━━

1. valider règles avec agent MSA
2. ajouter cas réels (20–50 dossiers)
3. affiner exceptions
4. intégrer workflow humain

━━━━━━━━━━━━━━━━━━━
CONCLUSION
━━━━━━━━━━━━━━━━━━━

Oui :
👉 c’est intégré à ton app
👉 c’est cohérent
👉 c’est déjà utile

Non :
👉 ce n’est pas encore validé institutionnellement

Mais :

👉 tu es maintenant sur une base réelle exploitable
━━━━━━━━━━━━━━━━━━━