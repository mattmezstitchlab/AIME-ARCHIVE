AIME — PRODUIT SIGNATURE MONDIALE
Pilotage universel des dossiers humains (France → Monde)

OBJECTIF
Créer une interface unique permettant de traiter des milliers de dossiers administratifs (MSA, CAF, situations familiales complexes) avec une lecture humaine, visuelle et intelligente.
Transformer un système administratif rigide en expérience fluide, intuitive et décisionnelle.

ADN PRODUIT
• Simplicité radicale (zéro charge cognitive)
• Lecture visuelle immédiate
• IA utile (pas gadget)
• Esthétique premium (Apple / Linear / Notion AI)
• Cohérence totale (Landing = App)

━━━━━━━━━━━━━━━━━━━
ARCHITECTURE GLOBALE
━━━━━━━━━━━━━━━━━━━

Structure en 3 zones fixes :

[ SIDEBAR ]   → navigation dossiers
[ CORE ]      → timeline (cœur du système)
[ AI PANEL ]  → analyse intelligente

Layout :

| Sidebar (20%) | Timeline (50%) | AI Panel (30%) |

Fond global :
- sombre profond (#0B0F1A)
- dégradé cosmique subtil
- halo dynamique centré sur la timeline

━━━━━━━━━━━━━━━━━━━
DESIGN SYSTEM
━━━━━━━━━━━━━━━━━━━

Couleurs :

--bg: #0B0F1A
--panel: rgba(255,255,255,0.05)
--glass: rgba(255,255,255,0.08)

--text: #FFFFFF
--muted: rgba(255,255,255,0.6)

--accent: #6C5CE7
--success: #00D084
--warning: #FFB020
--danger: #FF5A5F

Typo :
- Inter (UI)
- tracking légèrement augmenté
- titres nets et larges

Cartes :
- border-radius 16–24px
- backdrop-blur léger
- ombre douce + glow subtil

━━━━━━━━━━━━━━━━━━━
SIDEBAR (GAUCHE)
━━━━━━━━━━━━━━━━━━━

Objectif :
Navigation rapide, compacte, sans débordement.

Structure :

[ Champ recherche ]
[ Bouton + Nouveau dossier ]

[ Filtres horizontaux scrollables ]
→ Tous / Prioritaire / Alerte

[ Liste dossiers ]

Correction UX clé :
- supprimer filtres en ligne cassés
- utiliser chips scroll horizontal

Ex :

<div class="flex gap-2 overflow-x-auto pb-2">
  <Chip> Tous </Chip>
  <Chip> Prioritaire </Chip>
  <Chip> Alerte </Chip>
</div>

Dossier actif :
- fond plus lumineux
- glow léger
- bordure accent

Hover :
- montée légère
- transition 150ms

━━━━━━━━━━━━━━━━━━━
TIMELINE (CENTRE — SIGNATURE)
━━━━━━━━━━━━━━━━━━━

C’est LE cœur du produit.

Concept :
ligne verticale centrale lumineuse + événements alternés gauche/droite

Structure :

      ●
      │
      │
  ┌───┘   └───┐
  Event       Event
      │
      ●

Caractéristiques :

• Ligne centrale :
  - fine (2px)
  - glow violet subtil

• Événements :
  - cards flottantes
  - alternance gauche/droite
  - padding large
  - respiration forte

• Types d’événements :
  - ❤️ relation (mariage / divorce / concubinage)
  - 💼 emploi
  - 📄 administratif

• Couleurs associées :
  - violet = relation
  - orange = administratif
  - bleu = pro

• Chaque bloc contient :
  - date
  - titre
  - description courte

• Interaction :
  - hover = agrandissement léger + glow
  - clic = focus + zoom doux

━━━━━━━━━━━━━━━━━━━
AI PANEL (DROITE)
━━━━━━━━━━━━━━━━━━━

Objectif :
Transformer l’analyse en action.

Structure :

[ Statut global ]
→ cohérent / incohérent / prioritaire

[ Suggestions ]
→ messages clairs

[ Actions recommandées ]
→ boutons cliquables

[ Documents ]
→ upload + statut

Transformation clé :
→ passer de “texte” à “actions”

Ex :

[ Corriger statut relationnel ]
[ Demander justificatif ]
[ Vérifier CAF ]

Chaque bouton :
- full width
- hover lumineux
- transition fluide

━━━━━━━━━━━━━━━━━━━
IMMERSION VISUELLE
━━━━━━━━━━━━━━━━━━━

Ajout clé :

Halo dynamique :

background:
radial-gradient(circle at center, rgba(108,92,231,0.15), transparent 60%)

Effet :
- suit le dossier actif
- donne une sensation vivante

Scroll :
- scrollbar invisible

━━━━━━━━━━━━━━━━━━━
COHÉRENCE LANDING
━━━━━━━━━━━━━━━━━━━

Landing = miroir du produit

Sections :

1. HERO
- titre fort :
  “17000 dossiers. Une seule lecture.”
- fond cosmique
- CTA :
  “Accéder au pilotage”

2. STATISTIQUES
- dossiers bloqués
- temps perdu
- erreurs humaines

3. TRANSFORMATION
- avant / après
- visuel timeline

4. DÉMO PRODUIT
- capture interactive

5. CTA FINAL

Design identique :
- même couleurs
- même glow
- mêmes cartes

━━━━━━━━━━━━━━━━━━━
NIVEAU SUPÉRIEUR (SIGNATURE MONDIALE)
━━━━━━━━━━━━━━━━━━━

Ajouts différenciants :

1. ANIMATION TIMELINE
- apparition progressive (1.2s)
- ligne qui se dessine
- blocs qui émergent

2. MODE FOCUS
- clic sur dossier →
  zoom léger sur timeline
  fond assombri autour

3. IA CONTEXTUELLE
- messages dynamiques :
  “Incohérence détectée après divorce”
- adaptation selon données

4. TRANSITIONS FLUIDES
- changement dossier = morphing
- aucune coupure brutale

5. FEEDBACK VISUEL
- validation = glow vert
- erreur = vibration légère

6. SYSTÈME VIVANT
- timeline évolutive
- ajout événement instantané

━━━━━━━━━━━━━━━━━━━
POSITIONNEMENT
━━━━━━━━━━━━━━━━━━━

Aujourd’hui :
- interfaces administratives rigides
- erreurs fréquentes
- lenteur

Avec AIME :
+ lecture instantanée
+ correction rapide
+ expérience humaine

Demain :
→ standard mondial de gestion des dossiers humains

━━━━━━━━━━━━━━━━━━━
CONCLUSION
━━━━━━━━━━━━━━━━━━━

Ce produit devient :

• un outil administratif
• une interface émotionnelle
• une machine à simplifier le réel

Ce n’est pas un logiciel.
C’est une nouvelle façon de comprendre la vie administrative.

AIME = Lecture vivante du réel.