
  # Pilotage Dossiers Universel UI

  This is a code bundle for Pilotage Dossiers Universel UI. The original project is available at https://www.figma.com/design/trn5V8Ag9zLOOg2WkQmKC0/Pilotage-Dossiers-Universel-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  