import React from "react";
import { Circle, Square, Egg } from "lucide-react";

const SHAPES = [
  { id: "round", label: "Rond", Icon: Circle },
  { id: "rectangle", label: "Rectangle", Icon: Square },
  { id: "oval", label: "Ovale", Icon: Egg },
];

export default function ShapePicker({ shape, onChange }) {
  return (
    <div className="flex items-center gap-1 p-1 rounded-full border border-white/10 bg-white/[0.02]">
      {SHAPES.map(({ id, label, Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          title={label}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all ${
            shape === id
              ? "bg-white text-black"
              : "text-white/50 hover:text-white/90"
          }`}
        >
          <Icon className="w-3.5 h-3.5" />
          {label}
        </button>
      ))}
    </div>
  );
}