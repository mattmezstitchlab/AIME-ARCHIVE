import React, { useEffect } from "react";
import { Mic, MicOff } from "lucide-react";
import useVoiceDictation from "@/hooks/useVoiceDictation";

/**
 * Compact mic button that dictates text into a setter.
 * Replaces the value entirely on each new dictation.
 */
export default function MicButton({ onText, className = "", title = "Dicter" }) {
  const { supported, listening, transcript, start, stop } = useVoiceDictation();

  useEffect(() => {
    if (transcript) onText(transcript);
    // eslint-disable-next-line
  }, [transcript]);

  if (!supported) return null;

  return (
    <button
      type="button"
      onClick={listening ? stop : start}
      title={listening ? "Arrêter" : title}
      className={`flex-shrink-0 w-8 h-8 rounded flex items-center justify-center border transition-all ${
        listening
          ? "bg-red-500/30 border-red-400/60 text-red-200 animate-pulse"
          : "bg-black/40 border-emerald-400/30 text-emerald-300/80 hover:text-emerald-200 hover:border-emerald-400/60"
      } ${className}`}
    >
      {listening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
    </button>
  );
}