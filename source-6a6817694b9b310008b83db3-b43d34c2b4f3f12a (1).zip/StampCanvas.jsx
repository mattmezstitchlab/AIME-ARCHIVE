import React, { forwardRef } from "react";

const StampCanvas = forwardRef(({ imageUrl, rotation = 0 }, ref) => {
  return (
    <div
      ref={ref}
      className="relative flex items-center justify-center p-16"
    >
      {/* OMBRE AU SOL */}
      <div className="absolute bottom-6 w-56 h-10 bg-black/40 blur-2xl rounded-full opacity-60" />

      {/* TIMBRE */}
      <div className="relative">

        {/* TEXTURE PAPIER */}
        <div className="absolute inset-0 rounded-md pointer-events-none opacity-[0.12] mix-blend-overlay"
          style={{
            backgroundImage:
              "url('https://www.transparenttextures.com/patterns/paper-fibers.png')",
          }}
        />

        {/* IMAGE */}
        <img
          src={imageUrl}
          alt="Generated stamp"
          crossOrigin="anonymous"
          style={{
transform: `
  rotate(${rotation + (Math.random() * 2 - 1)}deg)
  scale(1)
`,            filter: `
              drop-shadow(0 2px 2px rgba(0,0,0,0.4))
              drop-shadow(0 10px 25px rgba(0,0,0,0.5))
            `,
          }}
          className="relative z-10 w-72 h-72 md:w-80 md:h-80 object-contain"
        />

        {/* DENTELURE (illusion via mask) */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            WebkitMaskImage:
              "radial-gradient(circle at 4px 4px, transparent 2px, black 2.5px)",
            WebkitMaskSize: "8px 8px",
            WebkitMaskRepeat: "repeat",
            maskImage:
              "radial-gradient(circle at 4px 4px, transparent 2px, black 2.5px)",
            maskSize: "8px 8px",
          }}
        />

        {/* MICRO IMPERFECTIONS */}
        <div className="absolute inset-0 rounded-md pointer-events-none opacity-[0.08] bg-[radial-gradient(circle_at_30%_20%,white,transparent_60%)]" />

      </div>
    </div>
  );
});

StampCanvas.displayName = "StampCanvas";
export default StampCanvas;