import React from "react";
import { Lock, Calendar } from "lucide-react";

export default function TimeCapsulePanel({ enabled, onToggle, unlockDate, onDateChange, message, onMessageChange }) {
  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="w-full mt-4 rounded-2xl border border-indigo-400/20 bg-gradient-to-b from-indigo-500/[0.06] to-indigo-500/[0.02] p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 text-indigo-200">
          <Lock className="w-3.5 h-3.5" />
          <span className="text-xs uppercase tracking-[0.15em]">Time Capsule</span>
        </div>
        <button
          onClick={() => onToggle(!enabled)}
          className={`relative w-9 h-5 rounded-full transition-all ${
            enabled ? "bg-indigo-400" : "bg-white/10"
          }`}
        >
          <span
            className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${
              enabled ? "left-[18px]" : "left-0.5"
            }`}
          />
        </button>
      </div>

      {enabled && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-black/30 border border-white/5">
            <Calendar className="w-3.5 h-3.5 text-indigo-300/70" />
            <input
              type="date"
              min={today}
              value={unlockDate || ""}
              onChange={(e) => onDateChange(e.target.value)}
              className="flex-1 bg-transparent text-xs text-white/90 focus:outline-none"
              style={{ colorScheme: "dark" }}
            />
          </div>
          <textarea
            value={message || ""}
            onChange={(e) => onMessageChange(e.target.value)}
            placeholder="Message scellé jusqu'à cette date…"
            rows={2}
            className="w-full px-3 py-2 rounded-lg bg-black/30 border border-white/5 text-xs text-white/90 placeholder:text-white/30 focus:outline-none focus:border-indigo-400/40 resize-none"
          />
          <p className="text-[10px] text-indigo-200/50 italic">
            Le message restera invisible jusqu'à la date choisie.
          </p>
        </div>
      )}
    </div>
  );
}