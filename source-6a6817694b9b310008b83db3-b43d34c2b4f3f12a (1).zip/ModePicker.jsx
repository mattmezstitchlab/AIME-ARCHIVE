import React from "react";
import { Stamp, Mail } from "lucide-react";

const MODES = [
  { id: "rubber", label: "Tampon", Icon: Stamp },
  { id: "postage", label: "Timbre-poste", Icon: Mail },
];

export default function ModePicker({ mode, onChange }) {
  return (
    <div className="inline-flex items-center gap-1 p-1 rounded-full border border-white/10 bg-white/[0.03]">
      {MODES.map(({ id, label, Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs tracking-wide transition-all ${
            mode === id
              ? "bg-white text-black"
              : "text-white/50 hover:text-white/90"
          }`}
        >
          <Icon className="w-3.5 h-3.5" />
          {label}
        </button>
      ))}
    </div>
  );
}