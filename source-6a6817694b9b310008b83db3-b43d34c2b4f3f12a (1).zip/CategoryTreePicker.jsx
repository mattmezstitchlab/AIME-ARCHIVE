import React from "react";
import { ChevronRight } from "lucide-react";
import { CATEGORIES } from "./CategoryPicker";
import { CATEGORY_TREE } from "@/lib/categoryTree";

/**
 * Hierarchical category picker: category → subcategory → (optional) domain.
 */
export default function CategoryTreePicker({
  category, setCategory,
  subcategory, setSubcategory,
  domain, setDomain,
}) {
  const node = CATEGORY_TREE[category];
  const subs = node?.sub ? Object.entries(node.sub) : [];
  const subNode = subcategory ? node?.sub?.[subcategory] : null;
  const domains = subNode?.domains || [];

  const handleCategory = (id) => {
    setCategory(id);
    setSubcategory("");
    setDomain("");
  };

  const handleSubcategory = (id) => {
    setSubcategory(id);
    setDomain("");
  };

  return (
    <div className="space-y-2">
      {/* Catégories principales */}
      <div>
        <p className="text-[9px] text-emerald-400/60 uppercase tracking-wider mb-1.5">
          Catégorie
        </p>
        <div className="grid grid-cols-3 gap-1.5">
          {CATEGORIES.map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => handleCategory(id)}
              className={`flex flex-col items-center gap-1 px-2 py-2 rounded text-[10px] transition-all ${
                category === id
                  ? "bg-emerald-400/20 border border-emerald-400/60 text-emerald-200"
                  : "bg-black/40 border border-emerald-400/15 text-emerald-400/60 hover:text-emerald-300 hover:border-emerald-400/40"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Sous-catégories */}
      {subs.length > 0 && (
        <div>
          <div className="flex items-center gap-1 text-[9px] text-emerald-400/60 uppercase tracking-wider mb-1.5">
            <ChevronRight className="w-2.5 h-2.5" />
            Sous-catégorie
          </div>
          <div className="flex flex-wrap gap-1">
            {subs.map(([id, sub]) => (
              <button
                key={id}
                onClick={() => handleSubcategory(id)}
                className={`px-2 py-1 rounded text-[10px] border transition-all ${
                  subcategory === id
                    ? "bg-emerald-400/25 border-emerald-400/70 text-emerald-100"
                    : "bg-black/40 border-emerald-400/15 text-emerald-400/60 hover:text-emerald-300 hover:border-emerald-400/40"
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Domaines (prestataires) */}
      {domains.length > 0 && (
        <div>
          <div className="flex items-center gap-1 text-[9px] text-emerald-400/60 uppercase tracking-wider mb-1.5">
            <ChevronRight className="w-2.5 h-2.5" />
            <ChevronRight className="w-2.5 h-2.5 -ml-1.5" />
            Domaine
          </div>
          <div className="flex flex-wrap gap-1">
            {domains.map((d) => (
              <button
                key={d}
                onClick={() => setDomain(d)}
                className={`px-2 py-1 rounded text-[10px] border transition-all ${
                  domain === d
                    ? "bg-amber-400/20 border-amber-300/60 text-amber-100"
                    : "bg-black/40 border-amber-400/15 text-amber-400/50 hover:text-amber-200 hover:border-amber-400/40"
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}