import React, { useState } from "react";
import { Wand2, Loader2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";

/**
 * Lets the user refine an already-generated stamp with a natural-language
 * instruction (e.g. "rends-le plus rouge", "ajoute une couronne").
 * Calls GenerateImage with the existing stamp as reference.
 */
export default function StampRefineButton({ stamp, onRefined }) {
  const [open, setOpen] = useState(false);
  const [instruction, setInstruction] = useState("");
  const [busy, setBusy] = useState(false);

  const SUGGESTIONS = [
    "Rends-le plus rouge",
    "Ajoute une couronne royale",
    "Plus vieilli, plus de craquelures",
    "Change la couleur en bleu nuit",
    "Ajoute une étoile dorée",
  ];

  const handleRefine = async () => {
    if (!instruction.trim() || busy) return;
    setBusy(true);
    try {
      const prompt = `Edit this existing stamp image while preserving its overall composition, perforated edges, code "${stamp.code}", and main text "${stamp.text}". Apply the following modification: ${instruction}. Keep PNG with fully transparent background, no paper, no shadow, isolated cutout, photographic vintage philatelic style, high detail.`;
      const res = await base44.integrations.Core.GenerateImage({
        prompt,
        existing_image_urls: [stamp.image_url],
      });
      if (res?.url) {
        await base44.entities.Stamp.update(stamp.id, { image_url: res.url }).catch(() => {});
        onRefined(res.url);
        setOpen(false);
        setInstruction("");
      }
    } catch (e) {
      console.error(e);
    }
    setBusy(false);
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-b from-violet-500/20 to-violet-700/10 border border-violet-300/30 text-sm text-violet-100 hover:from-violet-500/30 hover:to-violet-700/20 transition-all"
      >
        <Wand2 className="w-4 h-4" />
        Retoucher (IA)
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => !busy && setOpen(false)}
        >
          <div
            className="relative w-full max-w-md rounded-2xl border border-white/10 bg-zinc-950 p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOpen(false)}
              className="absolute top-3 right-3 text-white/40 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-sm uppercase tracking-[0.2em] text-white/70 mb-1">
              Retouche IA
            </h3>
            <p className="text-xs text-white/40 mb-4">
              Décrivez la modification à apporter au timbre existant.
            </p>

            <textarea
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              rows={3}
              placeholder="ex. Ajoute une couronne dorée et plus de rouge…"
              className="w-full bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/40 resize-none"
            />

            <div className="flex flex-wrap gap-1.5 mt-3">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => setInstruction(s)}
                  className="text-[10px] text-white/50 hover:text-white px-2 py-1 rounded border border-white/10 hover:border-white/30 transition-all"
                >
                  {s}
                </button>
              ))}
            </div>

            <button
              onClick={handleRefine}
              disabled={!instruction.trim() || busy}
              className="mt-4 w-full py-2.5 rounded-lg bg-gradient-to-b from-violet-400 to-violet-600 text-white text-sm font-medium hover:from-violet-300 hover:to-violet-500 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {busy ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Retouche en cours…
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  Appliquer la retouche
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </>
  );
}