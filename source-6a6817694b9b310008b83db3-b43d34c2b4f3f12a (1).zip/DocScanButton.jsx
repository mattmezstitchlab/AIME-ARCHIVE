import React, { useRef, useState } from "react";
import { ScanLine, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

/**
 * Scans a real paper document (photo or PDF), extracts metadata via AI,
 * and pre-fills the stamp form.
 */
export default function DocScanButton({ onExtracted }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const schema = {
        type: "object",
        properties: {
          doc_type: {
            type: "string",
            enum: ["devis", "facture", "attestation", "paiement", "contrat", "autre"],
          },
          person_name: { type: "string" },
          event_name: { type: "string" },
          doc_amount: { type: "number" },
          doc_reference: { type: "string" },
          doc_date: { type: "string" },
          summary: { type: "string" },
        },
      };
      const res = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: schema,
      });
      if (res?.status === "success" && res.output) {
        onExtracted(res.output);
      }
    } catch (err) {
      console.error(err);
    }
    setBusy(false);
    e.target.value = "";
  };

  return (
    <>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={busy}
        className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded text-[10px] uppercase tracking-wider bg-black/40 border border-emerald-400/30 text-emerald-300/80 hover:text-emerald-200 hover:border-emerald-400/60 transition-all disabled:opacity-50"
      >
        {busy ? (
          <>
            <Loader2 className="w-3 h-3 animate-spin" />
            Analyse IA…
          </>
        ) : (
          <>
            <ScanLine className="w-3 h-3" />
            Scanner un document
          </>
        )}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*,application/pdf"
        className="hidden"
        onChange={handleFile}
      />
    </>
  );
}