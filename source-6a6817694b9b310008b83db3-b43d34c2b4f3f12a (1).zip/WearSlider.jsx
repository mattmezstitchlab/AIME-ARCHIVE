import React from "react";

const LABELS = ["Neuf", "Léger", "Usé", "Vieilli", "Très vieilli"];

export default function WearSlider({ wear, onChange }) {
  return (
    <div className="w-full max-w-xs px-4 py-2.5 rounded-full border border-white/10 bg-white/[0.02]">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[10px] uppercase tracking-[0.15em] text-white/40">
          Usure
        </span>
        <span className="text-[11px] text-white/70">{LABELS[wear]}</span>
      </div>
      <input
        type="range"
        min={0}
        max={4}
        step={1}
        value={wear}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-1 appearance-none bg-white/10 rounded-full cursor-pointer accent-white
          [&::-webkit-slider-thumb]:appearance-none
          [&::-webkit-slider-thumb]:w-3
          [&::-webkit-slider-thumb]:h-3
          [&::-webkit-slider-thumb]:rounded-full
          [&::-webkit-slider-thumb]:bg-white
          [&::-webkit-slider-thumb]:cursor-pointer
          [&::-moz-range-thumb]:w-3
          [&::-moz-range-thumb]:h-3
          [&::-moz-range-thumb]:rounded-full
          [&::-moz-range-thumb]:bg-white
          [&::-moz-range-thumb]:border-0"
      />
    </div>
  );
}