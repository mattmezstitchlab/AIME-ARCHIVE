import React, { useRef, useState } from "react";
import { Plus, X, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

/**
 * Lets the user upload multiple photos for a "group" stamp
 * (couple, family, team). Returns array of urls via onChange.
 */
export default function MultiPersonUploader({ photos = [], onChange }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const handleFiles = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setBusy(true);
    const uploaded = [];
    for (const file of files) {
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        uploaded.push(file_url);
      } catch (err) {
        console.error(err);
      }
    }
    onChange([...photos, ...uploaded].slice(0, 6));
    setBusy(false);
    e.target.value = "";
  };

  const removeAt = (i) => onChange(photos.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 flex-wrap">
        {photos.map((url, i) => (
          <div key={i} className="relative">
            <img
              src={url}
              alt=""
              className="w-10 h-10 rounded object-cover border border-emerald-400/40"
            />
            <button
              onClick={() => removeAt(i)}
              className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500/90 text-white flex items-center justify-center hover:bg-red-400"
            >
              <X className="w-2.5 h-2.5" />
            </button>
          </div>
        ))}
        {photos.length < 6 && (
          <button
            onClick={() => inputRef.current?.click()}
            disabled={busy}
            className="w-10 h-10 rounded border border-dashed border-emerald-400/40 text-emerald-300/70 hover:border-emerald-400/70 hover:text-emerald-200 flex items-center justify-center transition-all disabled:opacity-50"
          >
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>
      <p className="text-[9px] text-emerald-400/50">
        {photos.length === 0
          ? "Photos multiples (couple, équipe, famille…)"
          : `${photos.length} photo${photos.length > 1 ? "s" : ""} · max 6`}
      </p>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleFiles}
      />
    </div>
  );
}