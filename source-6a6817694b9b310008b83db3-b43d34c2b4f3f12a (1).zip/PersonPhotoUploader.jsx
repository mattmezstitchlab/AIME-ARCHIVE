import React, { useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Upload, Loader2, X, User } from "lucide-react";

export default function PersonPhotoUploader({ photoUrl, personName, onPhotoChange, onNameChange }) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onPhotoChange(file_url);
    } catch (err) {
      console.error(err);
    }
    setUploading(false);
  };

  return (
    <div className="flex items-center gap-3 p-3 rounded-2xl border border-white/10 bg-white/[0.02]">
      <button
        onClick={() => inputRef.current?.click()}
        className="relative w-14 h-14 rounded-xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.06] transition-all flex items-center justify-center overflow-hidden shrink-0"
      >
        {uploading ? (
          <Loader2 className="w-5 h-5 animate-spin text-white/60" />
        ) : photoUrl ? (
          <img src={photoUrl} alt="" className="w-full h-full object-cover" />
        ) : (
          <Upload className="w-4 h-4 text-white/50" />
        )}
        {photoUrl && !uploading && (
          <span
            onClick={(e) => {
              e.stopPropagation();
              onPhotoChange("");
            }}
            className="absolute top-0.5 right-0.5 p-0.5 rounded-full bg-black/70 hover:bg-red-500"
          >
            <X className="w-2.5 h-2.5 text-white" />
          </span>
        )}
      </button>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-1">
          <User className="w-3 h-3 text-white/40" />
          <span className="text-[10px] uppercase tracking-[0.15em] text-white/40">
            Prestataire / personne
          </span>
        </div>
        <input
          value={personName}
          onChange={(e) => onNameChange(e.target.value)}
          placeholder="Nom (ex: DJ Paolo, Marie Dupont…)"
          className="w-full bg-transparent text-xs text-white/90 placeholder:text-white/30 focus:outline-none"
        />
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={handleFile}
        className="hidden"
      />
    </div>
  );
}